"""Regression cases for the first rail, event timing and retained reentry on a data gap."""
import json
import unittest
from dataclasses import replace
from datetime import datetime,timedelta,timezone
from functools import lru_cache

from book_pair_recovery import observe, summary
from book_viewport_structure import inspect_close, stamp
from replay_summer_book import OUT, history
from worker import NativeBar


class ConsecutiveBreak(unittest.TestCase):
    def test_summer_cases(self):
        bars=history()
        ix={stamp(b.time):i for i,b in enumerate(bars)}
        ends={stamp(b.closed_at):i for i,b in enumerate(bars)}
        @lru_cache(maxsize=16)
        def checked(i):
            return inspect_close(bars[i-511:i+1])
        source=json.loads((OUT/'summer_prefixes.json').read_text('utf8'))
        proof=[]
        for row in source['rows']:
            i=ends[row['clock']]
            if not any(p['event']=='later_line' for p in row['windows']['512']['events']):
                continue
            out=observe(bars,ix,i,i+3,checked(i),checked)
            for age in range(4):
                prefix=bars[:i+age+1]
                records=observe(prefix,ix,i,i+age,checked(i),checked)
                self.assertEqual([r['owner'] for r in records],[r['owner'] for r in out])
                for a,b in zip(records,out):
                    self.assertEqual(a['observations'],b['observations'][:age+1])
            proof.append(dict(clock=row['clock'],observations=out,note=summary(out) if out else None))
        accepted=[r for c in proof for r in c['observations'] if r.get('consecutive_break')]
        self.assertEqual(len(accepted),3)
        self.assertTrue(all(r['event']=='2026-07-29T22:00:00Z' for r in accepted))
        self.assertEqual(sum(r['consecutive_break']['source_alive'] for r in accepted),1)
        note=next(r['note'] for r in proof if r['clock']=='2026-07-29T22:00:00Z')
        self.assertIn('缺柱前已收回拐点线',note)
        (OUT/'short_sequences.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),'utf8')

    def test_mirrors_and_counterexamples(self):
        for sign in (1,-1):
            for trend_first in (True,False):
                anchor=datetime(2026,1,1,tzinfo=timezone.utc)
                px=lambda v: 100+sign*v
                bars=[NativeBar(anchor+timedelta(hours=i),px(p),px(p),px(p),px(p),0,3600)
                      for i,p in enumerate([8,8,8,10,10,13,10])]
                ix={stamp(b.time):i for i,b in enumerate(bars)}
                lower,higher=(9,12) if trend_first else (12,9)
                line=lambda v:[[stamp(bars[i].time),px(v)] for i in (0,1)]
                pair=dict(owner='trial',origin=[0,px(16)],terminal=[1,px(5)],direction='down' if sign==1 else 'up',
                          trend=line(lower),turning=line(higher)+[[stamp(bars[2].time),px(higher)]],
                          pair_known=stamp(bars[3].time),bars_between=2,event='later_line',source_alive=True,same_terminal=True,
                          trend_break_bar=stamp(bars[3 if trend_first else 5].time),turning_break_bar=stamp(bars[5 if trend_first else 3].time))
                report=dict(clock=stamp(bars[5].closed_at),pairs=[pair])
                def prior(i):
                    label=('trend_only' if trend_first else 'turn_only') if i==3 else 'no_new_cross'
                    return dict(clock=stamp(bars[i].closed_at),pairs=[dict(pair,event=label)])
                run=lambda series,callback:observe(series,ix,5,5,report,callback)
                self.assertEqual(run(bars,prior)[0]['consecutive_break']['bars'],3)
                for j,p in [(4,8),(4,9),(5,12)]:
                    other=list(bars)
                    other[j]=replace(other[j],open=px(p),high=px(p),low=px(p),close=px(p))
                    self.assertFalse(run(other,prior))
                other=list(bars)
                other[4]=replace(other[4],time=bars[4].time+timedelta(minutes=1))
                self.assertFalse(run(other,prior))
                self.assertFalse(run(bars,lambda j:dict(clock=stamp(bars[j].closed_at),pairs=[])))
                self.assertFalse(run(bars,lambda j:dict(prior(j),pairs=[dict(pair,event='no_new_cross')])))
                self.assertFalse(run(bars,lambda j:dict(prior(j),pairs=[dict(prior(j)['pairs'][0],origin=[2,3])])))


if __name__=='__main__':
    unittest.main()

