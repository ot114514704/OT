"""Create a new immutable backup after r5 native acceptance."""
from pathlib import Path
import hashlib,json,zipfile
B=Path(__file__).parent;V=B/'verification/reply_refresh_r5'
read=lambda p:json.loads(p.read_text('utf8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
required={p:read(V/p) for p in ('native_refresh_acceptance.json','deployment_acceptance.json','deployed/native_readiness.json','deployed/visual_acceptance.json')}
assert all(x['passed'] for x in required.values())
assert required['deployment_acceptance.json']['worker_sha256']==sha(B/'worker.py')
assert required['deployment_acceptance.json']['experiment_ex5_sha256']==sha(B/'source/Book302_Consolidation_Experiment.ex5')
sources=('worker.py','source/BookExperimentGuard.mqh','source/BookExperimentReplyPolicy.mqh','source/Book302_Consolidation_Experiment.ex5','native_scripts/Book302_ReplyPolicy_Regression.mq5','native_scripts/Book302_ReplyPolicy_Regression.ex5')
metadata={'revision':'1.230-r5','native_protocol':'BEXP_RESULT 2, optional ninth-field UTF8 payload SHA256; legacy 8-field supported',
 'change':'Reload changed full results under the same request token; retain verified results on invalid payload.',
 'source_sha256':{p:sha(B/p) for p in sources},'evidence':required,
 'limits':['Native acceptance limited to current November H1 viewport.','Other dates/line families, historical data quality and full-model latency remain open.'],
 'uploaded_at_packaging':False}
(B/'REVISION_R5.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),'utf8')
prior=B.parent/'备份/Book302_盘整融合1.230-r4_缺口后外层续观_20261118.zip'
with zipfile.ZipFile(prior) as z:files={B/p for p in z.namelist() if p!='R4_PACKAGE_MANIFEST.json'}
files.update(p for p in V.rglob('*') if p.is_file())
files.update(B/p for p in (*sources,'prepare_reply_refresh_r5.py','test_reply_revision.py','verify_reply_refresh_r5.py','verify_reply_deployment_r5.py','package_reply_r5.py','README_R5.txt','REVISION_R5.json'))
manifest=[{'path':p.relative_to(B).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
out=B.parent/'备份/Book302_盘整融合1.230-r5_同视窗自动续接刷新_20261118.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,p.relative_to(B).as_posix())
 z.writestr('R5_PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
receipt={'path':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'files_verified':len(manifest),'uploaded':False,
 'git_blob_sha':hashlib.sha1(b'blob '+str(out.stat().st_size).encode()+b'\0'+out.read_bytes()).hexdigest()}
(B/'PACKAGE_R5.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8');print(json.dumps(receipt))
