"""Restore the pinned Book calculation dependency from the user's local source archive."""
import argparse
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

ROOT=Path(__file__).resolve().parent


def restore(archive):
    manifest=json.loads((ROOT/'book_reference_manifest.json').read_text('utf8'))
    dest=ROOT/'book_archive_runtime'
    if dest.exists():
        for name,digest in manifest.items():
            if hashlib.sha256((dest/name).read_bytes()).hexdigest()!=digest:
                raise ValueError(f'Existing dependency differs: {name}')
        return
    with TemporaryDirectory(dir=ROOT) as staging, ZipFile(archive) as z:
        unpacked=Path(staging)/'book_archive_runtime'
        for name,digest in manifest.items():
            data=z.read('forex-ai-source-main/'+name)
            if hashlib.sha256(data).hexdigest()!=digest:
                raise ValueError(f'Archive dependency differs: {name}')
            target=unpacked/name
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(data)
        unpacked.rename(dest)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('archive',nargs='?',type=Path,default=Path.home()/'Downloads/forex-ai-source-main.zip')
    restore(parser.parse_args().archive)
