import unittest,json
from datetime import datetime,timezone
from pathlib import Path
from worker import NativeBar,classify,parse_request,encode_reply,recognize,solve,epoch,BASE,pa_note
from research_cases import load_bars
FIXTURE=BASE/'testdata'/'native_history_H1.tsv'
class GuardTests(unittest.TestCase):
 def test_outline_exit_side_is_independent_of_trend(self):
  for direction,state,side in [(1,1,'下轨下方'),(1,2,'上轨上方'),(-1,1,'上轨上方'),(-1,2,'下轨下方')]:
   p=dict(event_id='__CURRENT',category=4,trend=0,direction=direction,state=state,start=5,end=10,known=20,event=30)
   note=pa_note([p],dict(id='__CURRENT',clock=30),None,29,[])
   self.assertIn('越轨当根收在'+side,note)
   self.assertNotIn('失效',note)
 def test_outline_does_not_backdate_its_exit(self):
  p=dict(event_id='__CURRENT',category=4,trend=0,direction=-1,state=2,start=5,end=10,known=20,event=30)
  note=lambda pat,t:pa_note([pat],dict(id='__CURRENT',clock=t),None,t-1,[])
  self.assertIn('收盘越轨待核',note(p,29))
  self.assertIn('首次可知当根收在下轨下方',note(dict(p,event=20),20))
  self.assertIn('越轨早于六点可知',note(dict(p,state=3,event=19),20))
 def setUp(self):
  self.bar=NativeBar(datetime(2026,1,1,12,tzinfo=timezone.utc),4004,4009,4001,4005,0,3600)
  self.t=int(self.bar.closed_at.timestamp());self.event=dict(id='old',clock=self.t,known=self.t-7200,state='closed_bar_cross_observed',line=4004)
  self.box=dict(id='frozen',kind='dense',known=self.t-7200,start=self.t-18000,end=self.t,active=True,low=4000,high=4010,low0=4000,high0=4010,atr=10,event='',status='横盘候选·区间内往返',fixed_low=4000,fixed_high=4010,shape='rectangle')
 def check(self,box=None,event=None,patterns=()):return classify(event or self.event,[self.bar],[box or self.box],patterns)
 def test_old_line_cross_inside_stays_unconfirmed(self):self.assertEqual(self.check()['code'],2)
 def test_price_mirror_same_constraint(self):
  b=NativeBar(self.bar.time,3996,3999,3991,3995,0,3600);box={**self.box,'low':3990,'high':4000}
  self.assertEqual(classify(self.event,[b],[box])['code'],2)
 def test_mature_range_distinguished(self):self.assertEqual(self.check({**self.box,'kind':'local'})['code'],1)
 def test_first_outside_not_breakout(self):self.assertEqual(self.check({**self.box,'high':4004})['code'],3)
 def test_candidate_exit_not_mature_breakout(self):self.assertEqual(self.check({**self.box,'active':False,'status':'向上离开横盘观察区'})['code'],5)
 def test_mature_engine_breakout_requires_own_event(self):self.assertEqual(self.check({**self.box,'kind':'local','active':False,'event':'breakout_confirmed'})['code'],4)
 def test_range_not_known_before_cross(self):self.assertEqual(self.check({**self.box,'known':self.t})['code'],6)
 def test_line_not_known_before_cross(self):self.assertEqual(self.check(event={**self.event,'known':self.t})['code'],7)
 def test_gap_cannot_assert_range(self):self.assertEqual(self.check({**self.box,'status':'数据间隔中止'})['code'],0)
 def test_pa_break_never_overrides_inside(self):
  p=dict(event_id='old',known=self.t-7200,end=self.t-10800,start=self.t-15000,
         category=1,state=1,event=self.t,direction=1)
  event=dict(self.event,owner_a=self.t-20000,owner_b=self.t-7200)
  r=self.check(event=event,patterns=[p])
  self.assertEqual(r['code'],2)
  self.assertIn('已收盘越轨',r['pa'])
  self.assertIn('趋势方向依 Book 结构判定',r['pa'])
  self.assertIn('归属待核',self.check(patterns=[p])['pa'])
 def test_outer_range_overrules_inner_exit(self):
  inner={**self.box,'id':'inner','kind':'local','active':False,'event':'breakout_confirmed'}
  self.assertEqual(classify(self.event,[self.bar],[inner,self.box])['code'],8)
 def test_forming_and_wrong_token_rejected(self):
  text=f'BEXP\t1\tx\t3600\t{self.t-1}\t20\t1\tXAUUSD\t0.01\nB\t{int(self.bar.time.timestamp())}\t4004\t4009\t4001\t4005\t0\nEND\tx'
  with self.assertRaises(ValueError):parse_request(text)
 def test_marker_direction_is_geometric_cross_only(self):
  r=self.check();self.assertEqual(r['side'],1);self.assertIn('新方向未确认',r['label'])
 def test_encoded_reply_has_native_annotation_fields(self):
  r=self.check();req=dict(token='native',cutoff=self.t);lines=encode_reply(req,[r],.01).splitlines()
  self.assertEqual(len(lines[1].split('\t')),19);self.assertEqual(lines[-1],'END\tnative\t1')
class NativeRegression(unittest.TestCase):
 def test_five_original_examples_with_event_time_prefix_only(self):
  bars=load_bars(FIXTURE);cases=json.loads((BASE/'all_example_candidates.json').read_text(encoding='utf8'))
  selected=[0,2,4,6,7];receipts=[]
  for i in selected:
   c=cases[i];end=next(k+1 for k,b in enumerate(bars) if int(b.closed_at.timestamp())==c['clock']);start=max(0,int(c['original']['window'])-1100)
   prefix=tuple(bars[start:end]);contexts,_=recognize(prefix)
   e=dict(id=str(i),clock=c['clock'],known=int(c['original']['known']),state=c['original']['state'],line=c['line'])
   r=classify(e,prefix,contexts);self.assertIn(r['code'],(1,2,8));self.assertTrue(r['context']['known']<=c['bar']);receipts.append(dict(clock=c['clock'],code=r['code'],label=r['label'],context=r['context']))
  (BASE/'examples'/'guard_regression.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2),encoding='utf8')
 def test_future_bars_do_not_relabel_cross(self):
  bars=load_bars(FIXTURE);c=json.loads((BASE/'all_example_candidates.json').read_text(encoding='utf8'))[0]
  end=next(k+1 for k,b in enumerate(bars) if int(b.closed_at.timestamp())==c['clock']);start=max(0,int(c['original']['window'])-1100)
  event=dict(id='case1',clock=c['clock'],known=int(c['original']['known']),state=c['original']['state'],line=c['line'])
  common=dict(events=[event],patterns=[],token='offline',chart='offline',symbol='XAUUSD',seconds=3600)
  a=solve(dict(**common,bars=bars[start:end],cutoff=c['clock']))[0]
  b=solve(dict(**common,bars=bars[start:end+12],cutoff=int(bars[end+11].closed_at.timestamp())))[0]
  for key in ('code','label','context','side'):self.assertEqual(a[key],b[key],key)
if __name__=='__main__':unittest.main(verbosity=2)
