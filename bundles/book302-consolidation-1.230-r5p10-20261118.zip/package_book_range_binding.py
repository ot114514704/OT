from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent
review = root / 'verification/book_range_binding_20261118'
bridge = root / 'runtime/bridge'
key = '102923304041429_3600'

def read(path):
    return json.loads(path.read_text('utf-8-sig'))

def lines(path):
    return path.read_text('utf-8-sig').splitlines()

def sha(data):
    return hashlib.sha256(data).hexdigest()

rows = lines(bridge / f'reply_{key}.tsv')
header = rows[0].split('\t')
rev = lines(bridge / f'reply_revision_{key}.tsv')[0].split('\t')
render = lines(bridge / f'render_state_{key}.tsv')[0].split('\t')
audit = read(bridge / f'audit_{key}.json')
identity = read(bridge / 'worker_identity.json')
assert header[2] == audit['token'] == rev[2] == render[3] == render[4]
assert header[7] == rev[3] == render[5] == 'full' and audit['full_model']['available']
assert header[8] == rev[4] == sha(('\n'.join(rows[1:])+'\n').encode())
assert int(rev[5]) >= int(identity['started'])
assert identity['script_sha256'] == sha((root/'worker.py').read_bytes())
notes = [r['detail'] for r in audit['results'] if r['detail'].startswith('Book原线')]
assert notes and sum(row.startswith('R\t') for row in rows) == int(header[3]) == len(audit['results'])
assert sum(row.startswith('C\t') for row in rows) == int(render[11])
receipt = dict(token=header[2], revision=rev[4], stage=header[7], rows=int(header[3]), continuation_rows=int(render[11]),
               annotated=len(notes), native_received_at=rev[5], worker_sha256=identity['script_sha256'],
               rule_sha256=sha((root/'book_auxiliary.py').read_bytes()))
(review/'native_receipt.json').write_text(json.dumps(receipt, indent=2), 'utf8')
assert 'OK' in lines(review/'regression.txt')
previous = read(root/'PACKAGE_R5P2.json')
base = Path(previous['path'])
assert sha(base.read_bytes()) == previous['sha256']
with zipfile.ZipFile(base) as z:
    files = {k:z.read(k) for k in z.namelist() if k != 'R5P2_PACKAGE_MANIFEST.json'}
extra = ['worker.py','worker_binding_candidate.py','book_auxiliary.py','test_book_auxiliary.py',
         'verify_book_range_binding.py','draw_book_range_review.py','package_book_range_binding.py',
         'source/BookExperimentGuard.mqh','source/Book302_Consolidation_Experiment.ex5']
extra += [p.relative_to(root).as_posix() for p in sorted(review.iterdir())
          if p.is_file() and p.name not in ('worker_preinstall.py','OT_receipt.json')]
for name in extra:
    files[name] = (root/name).read_bytes()
manifest = {name:sha(data) for name,data in files.items()}
out = base.parent/'Book302_1.230-r5p3_通道三角与原线同区复盘_20261118.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
    for name,data in files.items():
        z.writestr(name,data)
    z.writestr('R5P3_PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None and all(sha(z.read(name)) == h for name,h in manifest.items())
data = out.read_bytes()
result = dict(path=str(out),sha256=sha(data),bytes=len(data),files_verified=len(manifest),
              git_blob_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
(root/'PACKAGE_R5P3.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(result,ensure_ascii=False))
