"""Match summer chart candidates to pre-existing Book lines and direct counterlegs."""
import csv
import hashlib
import json
from datetime import datetime
from functools import lru_cache

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from book_pair_recovery import line_at
from book_viewport_structure import load_reference, stamp
from replay_book_adjustment_A import response
from replay_summer_book import OUT, ROOT, history
from worker import recognize, select_book_range
from ict_trader.boundary_shapes import observe as shapes


def marked_shapes(bars):
    warm=[b for b in bars if '2026-07-01'<=stamp(b.time)<'2026-08-09']
    closed={b.closed_at.isoformat():i for i,b in enumerate(warm)}
    targets=[('2026-07-30T08','falling_wedge'),('2026-08-06T05','channel')]
    records=shapes(warm,warm[-1].closed_at)['ranges']
    matched=[]
    for start,kind in targets:
        r=min((r for r in records if r['observed_from'].startswith(start) and r['geometry']['subtype']==kind),
              key=lambda r:r['known_at'])
        first=closed[r['known_at']]
        end=closed[r['end_at']]
        status=[]
        for i in range(first-1,end+1):
            rows=shapes(warm[:i+1],warm[i].closed_at)['ranges']
            row=next((row for row in rows if row['id']==r['id']),None)
            if i<first:
                assert row is None
            else:
                assert row and row['geometry']==r['geometry'] and row['active']==(i<end)
            status.append(dict(clock=stamp(warm[i].closed_at),status=row['status'] if row else None))
        matched.append(dict(id=r['id'],kind=kind,start=r['observed_from'],known=r['known_at'],
                            end=r['end_at'],geometry=r['geometry'],states=status))
    return matched


def counterleg(p, bars, freeze, end, n):
    # Only up to the first crossing bar's OPEN is available for selecting the level.
    data=bars[freeze-n+1:freeze]
    cut=stamp(bars[freeze].time)
    if not data or data[-1].closed_at!=bars[freeze].time:
        return dict(status='gap_before_first')
    rows=[dict(timestamp_utc=stamp(b.time),timeframe='H1',symbol='XAUUSD',provider='MT5_experiment',
               open=b.open,high=b.high,low=b.low,close=b.close) for b in data]
    scopes=load_reference()[0](rows,'H1',cut)
    owners=[o for o in scopes['active'] if o['origin']==p['origin'] and o['terminal']==p['terminal']
            and o['direction']==p['direction'] and o['known_at_utc']<=cut]
    if len(owners)!=1:
        return dict(status='owner_not_unique_or_absent')
    children=[response(c,rows,p['direction']) for c in scopes['active']+scopes['retired']
              if c.get('parent_scope_id')==owners[0]['scope_id'] and c.get('terminal') and
              c['direction']!=p['direction'] and c['membership_known_at_utc']<=cut]
    if not children:
        return dict(status='no_owned_counterleg')
    children.sort(key=lambda c:c['extreme'])
    c=children[-1]
    if sum(k['extreme']==c['extreme'] for k in children)!=1:
        return dict(status='ambiguous_last_adjustment')
    if c['relation']!='internal_return_stage' or not c['resumed_close_time'] or c['retirement_state']!='completed_excursion_before_origin_breach':
        return dict(status='incomplete_counterleg')
    sign=1 if p['direction']=='down' else -1
    if any(sign*(r['close']-c['price'])>0 for r in rows if r['timestamp_utc']>c['extreme']):
        return dict(status='reference_already_crossed')
    return dict(status='candidate',price=c['price'],extreme=c['extreme'],resumed=c['resumed_close_time'],
                freeze=cut,dual_close_outside=sign*(bars[end].close-c['price'])>0)


def main():
    bars=tuple(history())
    ranges=marked_shapes(bars)
    index={stamp(b.time):i for i,b in enumerate(bars)}
    closes={stamp(b.closed_at):i for i,b in enumerate(bars)}
    source=json.loads((OUT/'summer_prefixes.json').read_text('utf8'))
    pa_file=ROOT/'verification/native_initial/CompanionBookThreePushPA_102923304041429.tsv'
    lines=pa_file.read_text('utf-16').splitlines()
    h=next(i for i,r in enumerate(lines) if r.startswith('known\tstart\t'))
    pa=list(csv.DictReader([lines[h],*(r for r in lines[h+1:] if r[:1].isdigit())],delimiter='\t'))
    @lru_cache(maxsize=8)
    def backgrounds(i):
        return recognize(bars[i-512:i])[0],recognize(bars[i-512:i+1])[0]
    findings=[]
    for row in source['rows']:
        i=closes[row['clock']]
        for p in row['windows']['512']['events']:
            if p['event'] not in ('same_bar','later_line'):
                continue
            before,now=backgrounds(i)
            allowed=[]
            for role in ('trend','turning'):
                rail=p[role]
                anchor=rail[0] if role=='trend' else rail[2]
                y=line_at(rail,anchor,i,index)
                slope=y-line_at(rail,anchor,i-1,index)
                event=dict(clock=int(bars[i].closed_at.timestamp()),known=int(datetime.fromisoformat(p['pair_known']).timestamp()),
                           id=p['owner']+'/'+role,owner_a=p['origin'][0],owner_b=p['terminal'][0],state='first_close_break',
                           line=float(y),slope=float(slope))
                selected=select_book_range(event,bars[i-1],bars[i],before,now)
                allowed.append({e['range']['id']:e['kind'] for e in [selected['primary'],*selected['alternatives']] if e})
            start=index[min(p['trend_break_bar'],p['turning_break_bar'])]
            candidate={n:counterleg(p,bars,start,i,n) for n in (256,512,768)}
            outlines=[{k:o[k] for k in ('start','end','known','category')} for o in pa if
                      int(o['category'])>0 and p['origin'][0]<=int(o['start'])<=int(o['end'])<=p['terminal'][0]
                      and int(o['end'])<=int(o['known'])<=bars[i].time.timestamp()]
            findings.append(dict(clock=row['clock'],owner=p['owner'],direction=p['direction'],event=p['event'],
                                 first_close=stamp(bars[start].closed_at),span=p['bars_between'],candidate_A=candidate,
                                 common_ranges={k:s for k,s in allowed[0].items() if k in allowed[1]},
                                 time_matched_outlines=outlines))
    for r in ranges:
        r['within']=[dict(clock=e['clock'],event=e['event'],bound=r['id'] in e['common_ranges']) for e in findings
                     if datetime.fromisoformat(r['known'])<datetime.fromisoformat(e['clock'])<=datetime.fromisoformat(r['end'])]
    report=dict(marked=ranges,dual_events=findings,pa_export_sha256=hashlib.sha256(pa_file.read_bytes()).hexdigest())
    (OUT/'summer_context.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
    draw(bars,ranges)
    print([(x['clock'],x['event'],x['span'],x['candidate_A'][512],list(x['common_ranges'].values())) for x in findings])


def draw(bars,ranges):
    plt.rcParams.update({'font.sans-serif':['Microsoft YaHei'],'axes.unicode_minus':False})
    fig,axes=plt.subplots(2,1,figsize=(11,7.3),layout='constrained')
    for ax,r,title in zip(axes,ranges,('7 月底至 8 月初的下降收敛区','8 月上旬的下降通道')):
        starts={b.time.isoformat():i for i,b in enumerate(bars)}
        ends={b.closed_at.isoformat():i for i,b in enumerate(bars)}
        a,f,z=starts[r['start']],ends[r['known']],ends[r['end']]
        for j in range(a-3,z+5):
            b=bars[j]
            shade='#1c7764' if b.close>=b.open else '#ab5042'
            ax.vlines(j,b.low,b.high,color=shade,lw=.9)
            ax.vlines(j,b.open,b.close,color=shade,lw=3.2)
        for key in ('upper','lower'):
            lo,hi=r['geometry'][key]
            x,y=starts[lo['time']],starts[hi['time']]
            slope=(hi['price']-lo['price'])/(y-x)
            level=lambda j:lo['price']+slope*(j-x)
            ax.plot([a,f],[level(a),level(f)],color='#345ba1',ls=':',lw=1.6)
            ax.plot([f,z],[level(f),level(z)],color='#345ba1',lw=1.7)
        ax.axvline(f,color='#9b7128',ls='--',lw=1,label='边界首次可知')
        ax.axvline(z,color='#5b6171',ls='-.',lw=1,label='向上离开观察区')
        ax.set_title(title,loc='left')
        ax.set_ylabel('XAUUSD')
        ticks=sorted(set([a,f,z]+[j for j in range(a+8,z,12) if min(abs(j-f),abs(j-z))>5]))
        ax.set_xticks(ticks,[bars[j].closed_at.strftime('%m-%d %H:%M') for j in ticks],fontsize=9)
        ax.legend(loc='upper left',fontsize=8)
        ax.grid(alpha=.15)
    fig.supxlabel('MT5 H1 收盘时刻　·　点线为形成段，实线为边界可知后的观察段',fontsize=10)
    fig.savefig(OUT/'夏季红线区逐根复核.png',dpi=140)
    plt.close(fig)


if __name__=='__main__':
    main()

