"""Compare the new native November viewport before a candidate deployment."""
from pathlib import Path
from unittest.mock import patch
import json,hashlib,shutil,time,sys
import worker
from outer_gap_candidate import handoff_chain
from research_adapter import summary
B=Path(__file__).parent;R=B/'runtime/bridge';V=B/'verification/outer_gap_20261118';P=V/'november_before';P.mkdir(exist_ok=True)
sys.stdout.reconfigure(encoding='utf8');scope='102923304041429_3600';started=time.perf_counter()
path=R/f'request_{scope}.tsv';raw=path.read_text('utf-8-sig');req=worker.parse_request(raw)
assert any(e['id']=='b0aad2b41ae9e9a0e97b6a6e' for e in req['events']),'Required November event not on this viewport'
with patch.object(worker,'outer_handoff',handoff_chain):
 after=worker.solve(req,lambda message:print(message,flush=True))
assert path.read_text('utf-8-sig')==raw,'Viewport changed'
audit=json.loads((R/f'audit_{scope}.json').read_text('utf8'));model=json.loads((R/f'full_model_{scope}.json').read_text('utf8'))
assert audit['token']==model['token']==req['token'] and audit['full_model']['available'],'Baseline full model not yet ready'
for row in after:row['detail']+='；'+(summary(model['report'],'H1') if row['id']=='__CURRENT' else '原研究全模型只作当前快照旁证，不回填此历史事件')
before=audit['results'];assert len(before)==len(after);changes=[]
for a,z in zip(before,after):
 assert {k:v for k,v in a.items() if k not in ('outer_continuation','follow')}=={k:v for k,v in z.items() if k not in ('outer_continuation','follow')},a['id']
 old,new=a.get('outer_continuation'),z.get('outer_continuation')
 if old:
  assert new and new['segments'][:len(old['segments'])]==old['segments']
  assert new['range_chain'][:len(old['range_chain'])]==old['range_chain']
 if old!=new:changes.append({'id':a['id'],'prior_segments':len(old['segments']) if old else 0,'new_segments':len(new['segments']) if new else 0})
assert any(x['id']=='b0aad2b41ae9e9a0e97b6a6e' for x in changes),'Target gap omission not repaired on actual current native request'
for name in [f'request_{scope}.tsv',f'audit_{scope}.json',f'full_model_{scope}.json',f'reply_{scope}.tsv','worker_identity.json',f'experiment_{scope}.png']:
 shutil.copy2(R/name,P/name)
assert path.read_text('utf-8-sig')==raw
(V/'november_expected_results.json').write_text(json.dumps(after,ensure_ascii=False,indent=2),'utf8')
receipt={'passed':True,'token':req['token'],'records':len(after),'changes':changes,'original_classifications_inner_and_existing_outer_segments_exact':True,
         'expected_results_sha256':hashlib.sha256((V/'november_expected_results.json').read_bytes()).hexdigest(),
         'candidate_sha256':hashlib.sha256((B/'outer_gap_candidate.py').read_bytes()).hexdigest(),
         'elapsed_seconds':time.perf_counter()-started,'deployed':False,'scope':'Actual November H1 viewport with native Book event; offline candidate comparison, not its native rendering yet.'}
(V/'november_acceptance.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8');print(json.dumps(receipt),flush=True)
