"""Independent Book 1.302 experiment. Original research recognizers are imported

only from the bundled, hashed snapshot. Requests contain native CLOSED bars.

No broker SDK, network access, order calls, or writes to production projects.

"""

from pathlib import Path

from datetime import datetime,timezone

from dataclasses import dataclass

from functools import lru_cache

import argparse,hashlib,json,os,sys,time,traceback

BASE=Path(__file__).resolve().parent

sys.path.insert(0,str(BASE/'research_snapshot'))

from ict_trader.core import Bar

from ict_trader.ipda_ranges import observe_ranges,phase_evidence

from ict_trader.macro_consolidation import PARAMETERS as MACRO_PARAMETERS

from ict_trader.dense_pauses import observe_dense_pauses

from ict_trader.structural_ranges import observe_structures

from ict_trader.long_geometry import observe_long_geometry,line_value

from ict_trader.history_generation import CALCULATION_VERSION

VERSION='Book302-consolidation-experiment-1.230'
from fusion_publication import publish_model_state,completed_stage

from continuation import observe as observe_continuation
from outer_gap_candidate import handoff_chain as outer_handoff

@dataclass(frozen=True)

class NativeBar(Bar):

    calendar_weekends:bool=True

from geometry_window_memo import GeometryWindowMemo
from ict_trader import long_geometry as _geometry_source,oscillation as _oscillation_source

# Reuse pure window evidence only; all lifecycle scans and frozen-range
# selection still restart at each decision close. Exact keys include native
# prices, time labels, flags and all candidate/oscillation parameters.
_geometry_candidates=GeometryWindowMemo(_geometry_source.candidate,NativeBar,
    lambda:(_geometry_source.PARAMETERS,_oscillation_source.PARAMETERS))

from native_dense_memo import NativeDenseMemo
_dense_candidates=NativeDenseMemo(NativeBar)
# Keep the callable explicit so offline comparisons can select the unchanged
# direct scanner. The native memo reuses metrics, never range lifecycle state.
observe_dense_pauses=_dense_candidates.observe

def epoch(value):return int(datetime.fromisoformat(value).timestamp())

def clean(value):return str(value).replace('\t',' ').replace('\r',' ').replace('\n','；') or '-'

def atomic(path,text):

    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(text,encoding='utf8')

    for attempt in range(8):

        try:os.replace(tmp,path);return

        except PermissionError:

            if attempt==7:raise

            time.sleep(min(.025*2**attempt,.25))



def publish_heartbeat(folder):

    # MT5 may briefly hold a Windows handle that denies replacement. A stale

    # heartbeat is explicit in the UI; this transient must not kill the worker.

    try:atomic(folder/'worker_heartbeat.txt',str(int(time.time())))

    except OSError as exc:print('Heartbeat publication deferred: '+str(exc),file=sys.stderr,flush=True)

def parse_request(text):

    lines=text.splitlines();h=lines[0].split('\t')

    if len(h)!=9 or h[:2]!=['BEXP','1']:raise ValueError('Invalid request header')

    token,seconds,cutoff,n,chart,symbol,point=h[2],int(h[3]),int(h[4]),int(h[5]),h[6],h[7],float(h[8])

    if symbol!='XAUUSD' or seconds not in (900,3600) or not 20<=n<=12000 or not point>0:raise ValueError('Only native XAUUSD H1/M15 supported')

    if lines[-1]!='END\t'+token:raise ValueError('Truncated request')

    bars=[];events=[];patterns=[];background={}

    for line in lines[1:-1]:

        p=line.split('\t')

        if p[0]=='B':

            b=NativeBar(datetime.fromtimestamp(int(p[1]),timezone.utc),*(float(v) for v in p[2:6]),float(p[6])*point,seconds)

            if int(b.closed_at.timestamp())>cutoff or (bars and bars[-1].closed_at>b.time):raise ValueError('Future/forming/out-of-order bar')

            bars.append(b)

        elif p[0]=='T':

            if len(p)!=8 or int(p[1]) not in (900,3600):raise ValueError('Invalid native background row')

            sec=int(p[1]);b=NativeBar(datetime.fromtimestamp(int(p[2]),timezone.utc),*(float(v) for v in p[3:7]),float(p[7])*point,sec)

            items=background.setdefault(sec,[])

            if int(b.closed_at.timestamp())>cutoff or (items and items[-1].closed_at>b.time):raise ValueError('Future/out-of-order background')

            items.append(b)

        elif p[0]=='E':

            if len(p)!=10:raise ValueError('Invalid Book event')

            events.append(dict(id=p[1],family=p[2],known=int(p[3]),clock=int(p[4]),state=p[5],owner_a=int(p[6]),owner_b=int(p[7]),line=float(p[8]),slope=float(p[9])))

        elif p[0]=='P':

            if len(p)!=10:raise ValueError('Invalid PA snapshot')

            patterns.append(dict(event_id=p[1],category=int(p[2]),trend=int(p[3]),direction=int(p[4]),known=int(p[5]),event=int(p[6]),state=int(p[7]),start=int(p[8]),end=int(p[9])))

        else:raise ValueError('Unknown request row')

    if len(bars)!=n:raise ValueError('Wrong candle count')

    closes={int(b.closed_at.timestamp()) for b in bars}

    if any(e['clock'] not in closes or e['clock']>cutoff or e['known']>cutoff for e in events):raise ValueError('Book event is outside the exact closed input')

    return dict(token=token,seconds=seconds,cutoff=cutoff,chart=chart,symbol=symbol,bars=bars,events=events,patterns=patterns,background=background)

def geometry_value(points,time,geometry,bars):

    if geometry.get('axis')!='observed_native_bar_index':return line_value(points,time)

    positions={int(b.time.timestamp()):i for i,b in enumerate(bars)}

    a,b=points;x,y=positions[epoch(a['time'])],positions[epoch(b['time'])]

    target=positions[epoch(time) if isinstance(time,str) else int(time.timestamp())]

    if x==y:raise ValueError('Native geometry anchors must differ')

    return a['price']+(b['price']-a['price'])*(target-x)/(y-x)



def normalize(r,kind,clock,bars,event=''):

    g=r.get('geometry');low=r.get('low',r.get('observed_low'));high=r.get('high',r.get('observed_high'));low0=low;high0=high

    if kind=='structural':

        low=r.get('last_lower',low);high=r.get('last_upper',high)

    if g and g.get('upper') and g.get('lower'):

        low0=geometry_value(g['lower'],r['observed_from'],g,bars);high0=geometry_value(g['upper'],r['observed_from'],g,bars)

        if kind=='geometric':

            low=geometry_value(g['lower'],bars[-1].time,g,bars);high=geometry_value(g['upper'],bars[-1].time,g,bars)

    return dict(id=r['id'],kind=kind,known=epoch(r['known_at']),start=epoch(r['observed_from']),end=epoch(r['end_at']),

        active=r.get('active',True),low=low,high=high,low0=low0,high0=high0,atr=r.get('frozen_atr',0),event=event,

        status=r['status'],fixed_low=r.get('observed_low',r.get('liquidity_low',low0)),fixed_high=r.get('observed_high',r.get('liquidity_high',high0)),

        gaps=r.get('gaps',[]),shape=r.get('shape','rectangle'))

@lru_cache(maxsize=128)

def recognize(bars):

    """Every call has already been truncated at its own decision close."""

    clock=int(bars[-1].closed_at.timestamp());result=[];archive={}

    for kind,params,basis in [('local',None,'body'),('macro',MACRO_PARAMETERS,'liquidity')]:

        obs=observe_ranges(bars,bars[-1].closed_at,parameters=params,level=kind,breakout_basis=basis)

        for row in obs['rows']:

            ev=phase_evidence(row,bars)

            r=ev['range'] or ev['ended']

            if r:

                x=normalize(r,kind,clock,bars,ev['event']);x['active']=ev['range'] is not None

                x['low']=r['liquidity_low'] if kind=='macro' else r['low'];x['high']=r['liquidity_high'] if kind=='macro' else r['high']

                x['low0']=x['low'];x['high0']=x['high'];archive[x['id']]=x

                if epoch(row['known_at'])==clock:result.append(x)

    raw=[('dense',r) for r in observe_dense_pauses(bars,bars[-1].closed_at)]

    raw += [('structural',r) for r in observe_structures(bars,bars[-1].closed_at,short_channels=True)['ranges']]

    raw += [('geometric',r) for r in observe_long_geometry(bars,bars[-1].closed_at,compact_scales=True,candidate_at=_geometry_candidates)['ranges']]

    for kind,r in raw:

        x=normalize(r,kind,clock,bars);archive[x['id']]=x

        if r['active'] or x['end']==clock:result.append(x)

    return result,archive

PA_NAMES={1:'三推反转楔形候选',2:'三推旗形中继候选',3:'三推楔形旗中继候选',4:'三推几何轮廓，背景未验证'}

def pa_note(patterns, event, context, opening, bars):
    clock = event['clock']
    snapshot = event['id'] == '__CURRENT'
    if not snapshot:
        owner_start = event.get('owner_a', 0)
        owner_end = event.get('owner_b', 0)
        if not 0 < owner_start < owner_end <= opening or not 0 < event['known'] <= opening or 'retrospective' in event['state']:
            return '三推旗楔：原线事前归属待核'
    candidates = []
    for pattern in patterns:
        if pattern['event_id'] != event['id'] or pattern['category'] not in PA_NAMES:
            continue
        if not 0 < pattern['start'] < pattern['end'] <= pattern['known'] <= clock:
            continue
        if not snapshot and (pattern['end'] < owner_start or pattern['start'] > owner_end):
            continue
        if context and (pattern['end'] < context['start'] or pattern['start'] > context['end']):
            continue
        candidates.append(pattern)
    if not candidates:
        return '三推旗楔：未取得同时段合格旁证'
    pattern = max(candidates, key=lambda item: (item['end'], item['known']))
    text = PA_NAMES[pattern['category']]
    if not snapshot:
        text += '（与原波段时间重叠，归属待核）'
        if pattern['known'] > opening:
            text += '，本根收盘才可知'
    state = pattern['state']
    if state in (1, 2) and not pattern['known'] <= pattern['event'] <= clock:
        state = 0
    if pattern['event'] > clock:
        state = 0
    text += {1: '，已收盘越轨', 2: '，反向失效', 3: '，已结束或越轨早于形态可知'}.get(state, '，等待后续破局')
    if not snapshot and pattern['direction'] in (-1, 1):
        from wave2116_swings import confirmed_swings
        swings = confirmed_swings(bars)
        anchors = [(pattern['start'], -pattern['direction']), (pattern['end'], pattern['direction'])]
        hits = sum(swings.get(key, clock+1) <= clock for key in anchors)
        text += f'。Wave 2.116 在本次收盘前已确认三推首尾摆点 {hits}/2'
    return text + '。趋势方向依 Book 结构判定。'

def classify(event,bars,contexts,patterns=()):

    clock=event['clock'];b=bars[-1];seconds=b.seconds;close=b.close;opening=int(b.time.timestamp())

    if int(b.closed_at.timestamp())!=clock:raise ValueError('Event close is not covered exactly')

    valid=[x for x in contexts if x['known']<=opening and x['end']>=clock and x['high']>x['low'] and '数据间隔' not in x['status'] and '交会' not in x['status']]

    inside=[x for x in valid if x['active'] and x['low']<=close<=x['high']]

    exits=[x for x in valid if not x['active'] and (x['event']=='breakout_confirmed' or x['status'].startswith(('向上离开','向下离开')))]

    pending=[x for x in valid if x['active'] and not x['low']<=close<=x['high']]

    context=None;code=0;label='盘整背景不足｜仅记录几何穿线'

    if event['known']>opening or 'retrospective' in event['state']:

        code=7;label='线在事后/本根收盘才可知｜不倒签有效突破'

    elif inside:

        context=min(inside,key=lambda x:(x['kind'] not in ('local','macro'),x['high']-x['low']))

        mature=context['kind'] in ('local','macro');code=1 if mature else 2

        label='旧线穿越｜仍在'+('成熟实体平衡区' if mature else '盘整候选区')+'｜新方向未确认'

        if exits:code=8;label='内层已离区、外层仍包容｜范围证据冲突'

    elif pending:

        context=min(pending,key=lambda x:(x['kind'] not in ('local','macro'),abs(close-(x['high'] if close>x['high'] else x['low']))))

        code=3;label='价格越界待跟进｜尚未确认离开盘整'

    elif exits:

        context=min(exits,key=lambda x:(x['kind'] not in ('local','macro'),x['high']-x['low']))

        mature=context['kind'] in ('local','macro');code=4 if mature else 5

        label='实体平衡突破条件触发｜新趋势仍待结构证据' if mature else '已离开形态观察区｜不能替代实体平衡突破'

    elif any(x['known']==clock and x['low']<=close<=x['high'] for x in contexts):

        context=next(x for x in contexts if x['known']==clock and x['low']<=close<=x['high']);code=6;label='本根刚识别盘整候选｜不冒充事前过滤'

    detail=f"收盘 {close:.2f}；旧线 {event.get('line',close):.2f}；同周期范围 {len(valid)} 个"

    if len(bars)<200:detail+='；历史预热不足200根，背景可能遗漏'

    detail+='；仅'+('H1' if seconds==3600 else 'M15')+'本周期，未验证高周期方向'

    fixed='固定形成区极值：暂无可比范围'

    if context:

        cleared=close>context['fixed_high'] or close<context['fixed_low']

        fixed=('已越形成区固定极值' if cleared else '仍未越形成区固定极值')+f" {context['fixed_low']:.2f}～{context['fixed_high']:.2f}"

        if context['shape']=='tilted' and not cleared:fixed+='；警惕斜轨自行穿价'

        detail+=f"；冻结范围 {context['low']:.2f}～{context['high']:.2f}；{context['status']}"

    if event['id']=='__CURRENT':

        label=('仍在成熟实体平衡区' if code==1 else '仍在盘整候选区' if code==2 else '越界待跟进' if code==3 else '实体平衡离区条件触发' if code==4 else '形态候选已离区' if code==5 else '本根首次识别观察区' if code==6 else '范围证据冲突' if code==8 else '当前没有合格盘整范围；不推测方向')

    line=event.get('line',close);side=1 if close>line else -1 if close<line else 0

    return dict(id=event['id'],clock=clock,code=code,label=label,detail=detail,context=context,side=side,

        pa=pa_note(patterns,event,context,opening,bars),fixed=fixed,nmatches=len(valid),follow='后续状态待计算')

def solve(request,progress=None):

    bars=request['bars'];events=request['events']

    # A line first known after its crossing cannot admit a causal continuation.

    # Preserve its original code-7 explanation, without running expensive range

    # recognizers for a time at which the Book line did not yet exist.

    causal=lambda e:e['known']<=e['clock']-request['seconds'] and 'retrospective' not in e['state']

    clocks=sorted(set([e['clock'] for e in events if causal(e)]+[request['cutoff']]))

    snapshots={};byclose={int(b.closed_at.timestamp()):i for i,b in enumerate(bars)}

    for number,clock in enumerate(clocks,1):

        if clock not in byclose:continue

        prefix=tuple(bars[:byclose[clock]+1]);snapshots[clock]=recognize(prefix)

        if progress:progress(f'{number}/{len(clocks)} 个收盘时刻，已算至 {datetime.fromtimestamp(clock,timezone.utc):%m.%d %H:%M}')

    current=snapshots.get(request['cutoff'],([],{}));results=[]

    for event in events:

        if event['clock'] not in byclose:continue

        index=byclose[event['clock']]

        if not causal(event):

            r=classify(event,bars[:index+1],[],request['patterns'])

            r['detail']='原线在穿线前尚不可知；跳过盘整背景重算，不据此断言不存在盘整'

            r['follow']='不倒签事前有效线；不产生实验续观';r['continuation']=None

            results.append(r);continue

        r=classify(event,bars[:index+1],snapshots[event['clock']][0],request['patterns'])

        c=r['context'];follow=current[1].get(c['id']) if c else None

        if follow:r['follow']='截至视窗末端：'+follow['status']+'（后续事实，未改写穿线时判断）'

        elif c:r['follow']='截至视窗末端：原范围续态不可用，不推测'

        else:r['follow']='无事前冻结范围，不推测后续突破'

        r['continuation']=observe_continuation(event,r,snapshots[event['clock']][0],bars,request['cutoff'])

        r['outer_continuation']=outer_handoff(event,r,snapshots[event['clock']][0],bars,request['cutoff'])
        if r['continuation']:r['follow']+='；实验续观：'+r['continuation']['label']
        if r['outer_continuation']:r['follow']+='；'+r['outer_continuation']['label']

        results.append(r)

    event=dict(id='__CURRENT',clock=request['cutoff'],known=0,state='current',line=bars[-1].close)

    results.append(classify(event,bars,current[0],request['patterns']))

    return results

def encode_reply(request,results,elapsed,stage="full"):

    lines=[f"BEXP_RESULT\t2\t{request['token']}\t{len(results)}\t{int(elapsed*1000)}\t{request['cutoff']}\t{VERSION}\t{stage}"]

    for r in results:

        c=r['context'] or {};fields=['R',r['id'],r['clock'],r['code'],c.get('start',0),c.get('known',0),c.get('low0',0),c.get('high0',0),c.get('low',0),c.get('high',0),r['label'],r['detail'],c.get('id','-'),r['pa'],r['follow'],r['fixed'],r['nmatches'],c.get('kind','-'),r['side']]

        lines.append('\t'.join(map(clean,fields)))

        for c in (r.get('continuation'),r.get('outer_continuation')):
            if not c:continue

            for segment in c.get('segments',[c]):

                fields=['C',r['id'],segment['start'],segment['end'],segment['price0'],segment['price1'],segment.get('low',c['low']),segment.get('high',c['high']),segment['state'],segment['label'],c['policy'],c['family']]

                lines.append('\t'.join(map(clean,fields)))

    lines.append(f"END\t{request['token']}\t{len(results)}")
    # Stable payload revision: elapsed timing alone must not trigger redraws.
    # The native reader verifies this digest before replacing loaded objects.
    payload='\n'.join(lines[1:])+'\n'
    lines[0]+='\t'+hashlib.sha256(payload.encode('utf8')).hexdigest()
    return lines[0]+'\n'+payload

def serve(folder):

    folder.mkdir(parents=True,exist_ok=True);seen={};stop=folder/'worker.stop';started=time.time()

    atomic(folder/'worker_identity.json',json.dumps(dict(pid=os.getpid(),version=VERSION,calculation=CALCULATION_VERSION,started=started,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),ensure_ascii=False))

    import multiprocessing

    from ict_trader.viewport_history import serve as history_serve

    children={}

    while not stop.exists():

        for directory in folder.glob('companion_*'):

            if directory.is_dir() and directory not in children:

                child=multiprocessing.get_context('spawn').Process(target=history_serve,args=(str(directory),),daemon=True);child.start();children[directory]=child

        publish_heartbeat(folder)

        for directory in folder.glob('companion_*'):

            heartbeat=directory/'heartbeat.tsv'

            if heartbeat.exists():

                fields=heartbeat.read_text(encoding='utf8').strip().split('\t')

                if len(fields)>=13:

                    fields[2]=str(int(time.time()));fields[12]=str(int(time.time()))

                    try:atomic(heartbeat,'\t'.join(fields)+'\n')

                    except OSError as exc:print('Companion heartbeat deferred: '+str(exc),file=sys.stderr,flush=True)

        for path in sorted(folder.glob('request_*.tsv'),key=lambda p:p.stat().st_mtime,reverse=True):

            try:

                raw=path.read_text(encoding='utf-8-sig');key=hashlib.sha256(raw.encode()).hexdigest()

                if seen.get(path)==key:continue

                req=parse_request(raw);t=time.monotonic();prefix=path.name.replace('request_','').replace('.tsv','')

                def progress(message):

                    atomic(folder/f'progress_{prefix}.txt',req['token']+'\t'+message);publish_heartbeat(folder)

                # Pending state supersedes the last published viewport. If
                # this calculation is abandoned and that viewport returns,
                # it must republish a complete model instead of keeping the
                # abandoned request's pending heartbeat forever.
                seen.pop(path,None)
                publish_model_state(folder/f'companion_{prefix}',req,'pending','当前视窗综合模型计算中；历史图形不作本帧确认',atomic)
                progress('开始按各事件时刻独立截断重算')

                results=solve(req,progress)

                if path.read_text(encoding='utf-8-sig')!=raw:continue

                atomic(folder/f'reply_{prefix}.tsv',encode_reply(req,results,time.monotonic()-t,'core'))

                progress('范围约束已发布；原研究全模型综合计算中')

                from research_adapter import run,summary,export_companion

                try:

                    report,charts=run(req['bars'],req.get('background',{}))

                    period='H1' if req['seconds']==3600 else 'M15'

                    for r in results:

                        r['detail']+='；'+(summary(report,period) if r['id']=='__CURRENT' else '原研究全模型只作当前快照旁证，不回填此历史事件')

                    if path.read_text(encoding='utf-8-sig')!=raw:continue
                    atomic(folder/f'full_model_{prefix}.json',json.dumps(dict(token=req['token'],report=report,charts=charts),ensure_ascii=False))

                    if charts:export_companion(folder/f'companion_{prefix}',req,charts)

                except Exception as exc:

                    report=dict(available=False,error=str(exc));progress('范围约束可用；综合模型计算失败，未替代历史判断')

                    for r in results:r['detail']+='；综合模型不可用：'+str(exc)

                if path.read_text(encoding='utf-8-sig')!=raw:continue

                if not report.get('available'):
                    publish_model_state(folder/f'companion_{prefix}',req,'unavailable',report.get('reason',report.get('error','综合模型不可用')),atomic)
                atomic(folder/f'reply_{prefix}.tsv',encode_reply(req,results,time.monotonic()-t,completed_stage(report)))

                atomic(folder/f'audit_{prefix}.json',json.dumps(dict(version=VERSION,input_sha256=key,token=req['token'],results=results,full_model=report,elapsed_seconds=time.monotonic()-t),ensure_ascii=False,indent=2))

                seen[path]=key;progress('完成；范围和原研究综合旁证已发布' if report.get('available') else '范围约束可用；综合模型未完成，等待原生数据补齐')

            except Exception:

                atomic(folder/'worker_error.txt',traceback.format_exc());seen[path]=key

        time.sleep(.5)

if __name__=='__main__':

    p=argparse.ArgumentParser();p.add_argument('--folder',type=Path,required=True);a=p.parse_args();serve(a.folder)

