"""Closed-bar follow-through for the frozen Book ruler exported at a crossing."""
from math import isfinite, ulp


def book_close_follow(event, bars, index, cutoff):
    if event.get('family') not in ('GUIDED_SHIFT', 'GUIDED_TURNING') or not 0 <= index < len(bars):
        return None
    first = bars[index]
    clock = int(first.closed_at.timestamp())
    if (event['clock'] != clock or cutoff < clock or 'retrospective' in event['state']
            or not 0 < event['known'] <= int(first.time.timestamp())):
        return None
    level, slope = event['line'], event['slope']
    if not isfinite(level) or not isfinite(slope) or slope == 0:
        return None
    direction = -1 if slope > 0 else 1
    consecutive = 0
    last_close = clock
    status = 'waiting'
    for offset, bar in enumerate(bars[index:index+3]):
        when = int(bar.closed_at.timestamp())
        if when > cutoff:
            break
        if offset and (int(bar.time.timestamp()) != last_close or bar.seconds != first.seconds):
            status = 'gap'
            break
        rail = level + slope * offset
        # Tolerate only roundoff of exported prices and the frozen line evaluation.
        tolerance = 32 * max(ulp(level), ulp(rail), ulp(bar.close))
        if direction * (bar.close - rail) <= tolerance:
            if offset == 0:
                return None
            status = 'returned'
            last_close = when
            break
        consecutive += 1
        last_close = when
        if consecutive == 3:
            status = 'held'
    motion = 'unavailable'
    if index and bars[index-1].closed_at == first.time and bars[index-1].seconds == first.seconds:
        previous = bars[index-1].close
        previous_level = level - slope
        tolerance = 32 * max(ulp(previous_level), ulp(first.close), ulp(previous))
        if direction * (previous - previous_level) <= tolerance:
            if direction * (first.close - previous) <= tolerance:
                motion = 'rail_overtook_price'
            elif direction * (first.close - previous_level) <= tolerance:
                motion = 'price_and_rail'
            else:
                motion = 'past_prior_level'
    return dict(status=status, consecutive=consecutive, last_close=last_close, motion=motion)


def book_close_note(result):
    count = result['consecutive']
    status = result['status']
    if status == 'gap':
        evidence = f'连续{count}根线外收盘后行情缺柱，停止核验'
    elif status == 'returned':
        evidence = f'连续{count}根线外收盘，第{count+1}根触线或收回'
    elif status == 'held':
        evidence = '连续3根线外收盘'
    else:
        evidence = f'已有{count}根线外收盘，等待第{count+1}根'
    motion = {'rail_overtook_price': '本根收盘未向破线方向推进，斜轨越过价格',
              'price_and_rail': '价格向破线方向推进，尚未越过前一根线位',
              'past_prior_level': '收盘同时越过前一根线位',
              'unavailable': '前一根线位对照待核'}[result['motion']]
    return 'Book单线：' + motion + '；' + evidence + '；同源双线与分界点A待核'
