from pathlib import Path
import json, hashlib, zipfile
root=Path(__file__).parent
v=root/'verification/book_close_follow_20261118'
b=root/'runtime/bridge'
key='102923304041429_3600'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
digest=lambda data:hashlib.sha256(data).hexdigest()
tsv=lambda p:p.read_text('utf-8-sig').splitlines()
rows=tsv(b/f'reply_{key}.tsv')
hdr=rows[0].split('\t')
rev=tsv(b/f'reply_revision_{key}.tsv')[0].split('\t')
render=tsv(b/f'render_state_{key}.tsv')[0].split('\t')
model=read(b/f'audit_{key}.json')
identity=read(b/'worker_identity.json')
assert hdr[2]==model['token']==rev[2]==render[3]==render[4]
assert hdr[7]==rev[3]==render[5]=='full' and model['full_model']['available']
assert hdr[8]==rev[4]==digest(('\n'.join(rows[1:])+'\n').encode())
assert int(rev[5])>=int(identity['started']) and identity['script_sha256']==digest((root/'worker.py').read_bytes())
notes=[r['follow'] for r in model['results'] if r['follow'].startswith('Book单线')]
assert notes and any('前一根线位' in note or '斜轨越过价格' in note for note in notes)
(v/'native_receipt.json').write_text(json.dumps(dict(token=hdr[2],revision=rev[4],stage=hdr[7],rows=len(model['results']),annotated=len(notes),native_received_at=rev[5],worker_sha256=identity['script_sha256'],rule_sha256=digest((root/'book_close_follow.py').read_bytes())),indent=2),'utf8')
assert 'OK' in (v/'regression.txt').read_text('utf-8-sig').splitlines()
prev=read(root/'PACKAGE_R5P1.json'); base=Path(prev['path']);assert digest(base.read_bytes())==prev['sha256']
with zipfile.ZipFile(base) as z:files={k:z.read(k) for k in z.namelist() if k!='R5P1_PACKAGE_MANIFEST.json'}
extra=['worker.py','worker_close_candidate.py','book_close_follow.py','test_experiment.py','verify_book_close_follow.py','verify_book_close_integration.py','package_book_close_follow.py','verification/line_families_20261118/inventory.json']
extra += [x.relative_to(root).as_posix() for x in sorted(v.iterdir()) if x.is_file()]
for p in extra:files[p]=(root/p).read_bytes()
manifest={p:digest(data) for p,data in files.items()}
out=base.parent/'Book302_1.230-r5p2_单线穿越与断头复盘_20261118.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
    for p,data in files.items():z.writestr(p,data)
    z.writestr('R5P2_PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None and all(digest(z.read(p))==h for p,h in manifest.items())
data=out.read_bytes()
receipt=dict(path=str(out),sha256=digest(data),bytes=len(data),files_verified=len(manifest),git_blob_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
(root/'PACKAGE_R5P2.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
print(receipt)
