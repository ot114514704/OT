"""Plot matched closed H1 and M15 evidence on the original H1 price scale."""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from screen_three_book_closes import OUT

screen=json.loads((OUT/'screen.json').read_text('utf8'))
quarters=json.loads((OUT/'native_quarters.json').read_text('utf8'))['cases']
plt.rcParams.update({'font.sans-serif':['Microsoft YaHei'],'axes.unicode_minus':False})
fig,axes=plt.subplots(1,2,figsize=(12.6,4.8),layout='constrained')
for ax,clock,title in zip(axes,['2026-04-02T09:00:00Z','2026-11-06T21:00:00Z'],
                          ['4 月 2 日　第一条线连续守住','11 月 6 日　中间一根先收回']):
    c=next(c for w in screen['periods'] for c in w['cases'] if c['event']==clock)
    vals=c['values'][:3]
    for i,row in enumerate(vals):
        o=row['open'];close=row['close']
        color='#14765d' if close>=o else '#b04d44'
        ax.vlines(i,row['low'],row['high'],color=color,lw=1.15)
        ax.vlines(i,o,close,color=color,lw=6.5)
        ss=next(q for q in quarters if q['owner']==c['owner'] and q['clock']==row['clock'])['quarters']
        xx=[i+(k-3)*.25 for k in range(4)]
        ax.scatter(xx,[p['close'] for p in ss],s=18,marker='o',color='#393939',zorder=4,
                   label='M15 收盘（每小时四点）' if i==0 else None)
    for key,label,color in [('trend','趋势线','#305da1'),('turning','拐点线','#996420')]:
        ax.plot(range(3),[r[key] for r in vals],color=color,lw=1.5,label=label)
    ax.set_xticks(range(3),[v['clock'][11:16] for v in vals])
    ax.set_ylabel('XAUUSD')
    ax.set_title(title)
    ax.grid(alpha=.15)
    ax.set_xlabel('H1 收盘时刻')
    ax.legend(fontsize=8,loc='best')
fig.savefig(OUT/'连续三根与中途收回.png',dpi=145)
plt.close(fig)

