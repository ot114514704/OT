import hashlib, json, zipfile
from pathlib import Path

root=Path.cwd()
v=root/'verification/book_auxiliary_20261118'
base=json.loads((root/'PACKAGE_R5.json').read_text('utf8'))
digest=lambda data:hashlib.sha256(data).hexdigest()
s='102923304041429_3600'
receipt=json.loads((v/'pa_binding/observed_native_receipt.json').read_text('utf-8-sig'))
assert receipt['worker']==digest((root/'worker.py').read_bytes())
assert receipt['render_receipt_time']>receipt['runtime_started']
assert receipt['model']=='full' and receipt['rows']==86
basepath=Path(base['path'])
assert digest(basepath.read_bytes())==base['sha256']
out=basepath.parent/'Book302_1.230-r5p1_波浪旁证与通道复盘_20261118.zip'
files=['package_wave_review.py','worker.py','worker_pa_candidate.py','wave2116_swings.py','review_close_filter.py','audit_book_geometry.py','book_auxiliary.py','test_book_auxiliary.py','review_book_auxiliary.py','replay_pa_binding.py','testdata/book_scan.tsv','testdata/native_history_H1.tsv']
files += [p.relative_to(root).as_posix() for p in v.rglob('*') if p.is_file() and p.name!='worker_preinstall.py']
old=root/'verification/outer_gap_20261118'
files += [p.relative_to(root).as_posix() for p in [old/'november_expected_results.json',old/'november_before'/f'request_{s}.tsv',old/'november_before'/f'full_model_{s}.json']]
updates={f:(root/f).read_bytes() for f in files}
with zipfile.ZipFile(basepath) as prior:
    blob={n:prior.read(n) for n in prior.namelist() if n!='R5_PACKAGE_MANIFEST.json'}
blob.update(updates)
manifest={n:digest(data) for n,data in sorted(blob.items())}
blob['R5P1_PACKAGE_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
    for n,data in blob.items():z.writestr(n,data)
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None and all(digest(z.read(n))==h for n,h in manifest.items())
data=out.read_bytes()
receipt=dict(path=str(out),sha256=digest(data),bytes=len(data),entries=len(blob),base_sha256=base['sha256'],git_blob_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
(root/'PACKAGE_R5P1.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
print(receipt)
