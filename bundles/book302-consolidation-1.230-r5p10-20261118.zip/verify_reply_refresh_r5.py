"""Bounded reversible native-reader test on the unchanged experiment viewport.

Republish two reviewed historical result sets; always restore the actual worker
reply. No UI operations, market-data edits, orders or recognition recomputation.
"""
from pathlib import Path
import csv, hashlib, json, shutil, time
import worker

B=Path(__file__).parent; R=B/'runtime/bridge'; V=B/'verification/reply_refresh_r5'
S='102923304041429_3600'; reply=R/f'reply_{S}.tsv'; receipt=R/f'reply_revision_{S}.tsv'
sha=lambda b:hashlib.sha256(b).hexdigest()
request=(R/f'request_{S}.tsv').read_bytes(); req=worker.parse_request(request.decode('utf8'))
original=reply.read_bytes(); wire=original.decode('utf8').replace('\r\n','\n')
header,payload=wire.split('\n',1); fields=header.split('\t')
assert len(fields)==9 and fields[2]==req['token'] and fields[7]=='full'
assert fields[8]==sha(payload.encode('utf8'))
assert (R/f'progress_{S}.txt').read_text('utf8').startswith(req['token']+'\t完成')
old=json.loads((B/f'verification/outer_gap_20261118/november_before/audit_{S}.json').read_text('utf8'))
assert old['token']==req['token']
baseline=worker.encode_reply(req,old['results'],1,'full'); base_digest=baseline.splitlines()[0].split('\t')[8]
assert base_digest!=fields[8]
V.mkdir(exist_ok=True); (V/'worker_reply_before_test.tsv').write_bytes(original)
book_files=list((R/'NativeBookAudit').glob('*.tsv'))+list(R.glob('CompanionBook*.tsv'))
book_before={str(p.relative_to(R)):sha(p.read_bytes()) for p in book_files}
transitions=[]

def snapshot(name):
 out=V/name;out.mkdir(exist_ok=True)
 for p in [receipt,R/f'render_state_{S}.tsv',R/f'continuation_render_{S}.tsv']:
  shutil.copy2(p,out/p.name)
 rows=list(csv.DictReader((out/f'continuation_render_{S}.tsv').read_text('utf-8-sig').splitlines(),delimiter='\t'))
 return {'segments':len(rows),'outer':sum(r['state'].startswith('outer_') for r in rows)}

def await_revision(digest,name):
 start=time.monotonic()
 while time.monotonic()-start<20:
  assert (R/f'request_{S}.tsv').read_bytes()==request,'Viewport changed during native test'
  try:
   row=receipt.read_text('utf-8-sig').strip().split('\t')
   if row[2:5]==[req['token'],'full',digest]:
    result={'name':name,'seconds':time.monotonic()-start,'receipt':row,**snapshot(name)}
    transitions.append(result);return result
  except (OSError,IndexError):pass
  time.sleep(.2)
 raise AssertionError('Native revision not accepted: '+name)

try:
 await_revision(fields[8],'initial')
 worker.atomic(reply,baseline)
 a=await_revision(base_digest,'baseline_full')
 worker.atomic(reply,wire)
 b=await_revision(fields[8],'updated_full')
 assert b['segments']==a['segments']+4 and b['outer']==a['outer']+4
 accepted=receipt.read_bytes()
 # Elapsed-only metadata must not cause another payload acceptance/redraw.
 h=fields.copy();h[4]=str(int(h[4])+999)
 worker.atomic(reply,'\t'.join(h)+'\n'+payload);time.sleep(2)
 assert receipt.read_bytes()==accepted,'Elapsed-only update reloaded payload'
 # Advertise a different valid digest with the unchanged body: reject it.
 h[8]='0'*64
 worker.atomic(reply,'\t'.join(h)+'\n'+payload);time.sleep(2)
 assert receipt.read_bytes()==accepted,'Digest mismatch replaced verified results'
 assert snapshot('invalid_preserved')['segments']==b['segments']
finally:
 worker.atomic(reply,wire)

await_revision(fields[8],'restored')
assert reply.read_bytes()==original,'Original completed reply not restored exactly'
book_after={str(p.relative_to(R)):sha(p.read_bytes()) for p in book_files}
assert book_before==book_after,'Book/companion receipt geometry changed'
policy=list(csv.DictReader((R/'reply_policy_tests.tsv').read_text('utf-8-sig').splitlines(),delimiter='\t'))[0]
assert policy['passed']=='11' and policy['failed']=='0'
assert policy['utf8_digest']==sha('R\t原生\nEND\t同图\t1\n'.encode('utf8'))
report={'passed':True,'token':req['token'],'transitions':transitions,'same_token_full_to_full':True,
        'elapsed_only_no_reload':True,'invalid_digest_preserves_loaded_results':True,
        'original_worker_reply_restored_exactly':True,'book_and_companion_receipts_unchanged':book_before,
        'native_policy':policy,'native_policy_utf8_matches_python':True,
        'scope':'Current approved November H1 viewport; two real preserved result sets. No pan, toggle, reload or period switch during update.'}
(V/'native_refresh_acceptance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({k:v for k,v in report.items() if k!='book_and_companion_receipts_unchanged'},ensure_ascii=False))
