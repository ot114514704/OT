from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import worker
from book_auxiliary import select
root=Path(__file__).parent
output=root/'verification/book_range_binding_20261118'
req=worker.parse_request((root/'verification/outer_gap_20261118/november_before/request_102923304041429_3600.tsv').read_text('utf-8-sig'))
reviews=json.loads((output/'integration_replay.json').read_text('utf8'))[0]['examples']
plt.rcParams.update({'font.sans-serif':['Microsoft YaHei'],'axes.unicode_minus':False})
fig,axes=plt.subplots(1,2,figsize=(11,4.6))
dates=['2026-10-21 21:00','2026-10-23 18:00']
series=[]
for ax,date in zip(axes,dates):
    review=next(r for r in reviews if r['at']==date)
    event=next(r for r in req['events'] if r['id']==review['id'])
    i=next(i for i,b in enumerate(req['bars']) if int(b.closed_at.timestamp())==event['clock'])
    bars=req['bars'][i-1:i+1]
    previous,at=[worker.recognize(tuple(req['bars'][:n]))[0] for n in (i,i+1)]
    selected=select(event,*bars,previous,at)['primary']
    old_id=review['prior_context']
    old=[next(r for r in snap if r['id']==old_id) for snap in (previous,at)]
    ax.fill_between([0,1],[r['low'] for r in old],[r['high'] for r in old],color='#c9a256',alpha=.26,label='原先按收盘价选取的范围')
    if selected:
        ref=[selected['before'],selected['range']]
        for bound in ('low','high'):
            ax.plot([0,1],[r[bound] for r in ref],color='#20715b',lw=2,label='核对后所选三角的边界' if bound=='low' else None)
    line=[event['line']-event['slope'],event['line']]
    ax.plot([0,1],line,color='#263d88',lw=2,marker='o',label='Book 原线在两根柱上的线位')
    for j,b in enumerate(bars):
        color='#247456' if b.close>=b.open else '#ac4136'
        ax.vlines(j,b.low,b.high,color=color,lw=1)
        ax.add_patch(Rectangle((j-.034,min(b.open,b.close)),.068,max(abs(b.close-b.open),.03),facecolor=color,edgecolor=color,zorder=3))
    series.append(dict(id=event['id'],date=date,book_rail=line,closes=[b.close for b in bars],old_edges=[[r['low'],r['high']] for r in old],verified_edges=[[r['low'],r['high']] for r in ref] if selected else None))
    ax.set_title(date+' 收盘');ax.set_xticks([0,1],['前一根 H1','穿线当根 H1']);ax.set_xlim(-.23,1.23);ax.grid(axis='y',alpha=.18)
    ax.legend(fontsize=8,loc='best')
fig.suptitle('XAUUSD H1　Book 穿线与盘整位置复核',fontsize=15)
fig.tight_layout();fig.savefig(output/'两处穿线复核.png',dpi=150);plt.close(fig)
(output/'chart_values.json').write_text(json.dumps(series,ensure_ascii=False,indent=2),'utf8')
print(series)
