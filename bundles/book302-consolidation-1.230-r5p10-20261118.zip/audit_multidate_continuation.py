"""Finite saved-native line audit. No terminal, orders, or production writes.

The candidate catalogue is selected, not an unbiased accuracy sample. Rebuild
contexts at the original event close; never reuse its historical saved context.
"""
from pathlib import Path
from datetime import datetime, timezone
import collections, copy, hashlib, json, math, time, sys, argparse
import worker
from research_cases import load_bars
from continuation import observe
from outer_continuation import handoff_chain

B=Path(__file__).parent
V=B/'verification/multidate_continuation_20261118'
V.mkdir(exist_ok=True)
sys.stdout.reconfigure(encoding='utf8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stamp=lambda b:int(b.closed_at.timestamp())

def independent_stop(bars,origin,low,high):
    """Small independent lifecycle oracle: return last drawable index/state.

    Uses adjacent closes for exits and adjacent bodies for gap recovery. No
    reuse of production continuation counters, segment builder, or helpers.
    """
    last=origin; paused=False; resumed=False
    for i in range(origin+1,len(bars)):
        b,p=bars[i],bars[i-1]
        delta=(b.time-p.closed_at).total_seconds()
        if b.seconds!=bars[origin].seconds or delta<0:return last,'invalid_bar'
        if delta:
            paused=True
            if delta>96*3600:return last,'long_gap'
        if not all(math.isfinite(v) for v in (b.open,b.high,b.low,b.close)) or not b.low<=min(b.open,b.close)<=max(b.open,b.close)<=b.high:
            return last,'invalid_bar'
        consecutive=not delta
        paired_exit=consecutive and ((b.close>high and p.close>high) or (b.close<low and p.close<low))
        if paused:
            if paired_exit:return last,'gap_exit'
            if consecutive and all(low<=v<=high for v in (p.open,p.close,b.open,b.close)):
                paused=False;resumed=True;last=i
            continue
        last=i
        # The crossing/origin bar is not the first future exit observation.
        if i>origin+1 and paired_exit:return last,'fixed_envelope_exit'
    return last,'gap' if paused else 'resumed' if resumed else 'observing'

def check_observation(obs,event,contexts,bars,cutoff):
    if not obs:return
    visible=[b for b in bars if stamp(b)<=cutoff]
    positions={int(b.time.timestamp()):i for i,b in enumerate(visible)}
    origin=next(i for i,b in enumerate(visible) if stamp(b)==event['clock'])
    chosen=next(c for c in contexts if c['id']==obs['range_ids'][0])
    assert chosen['known']<=int(visible[origin].time.timestamp())
    low=min(chosen['low'],chosen['fixed_low']);high=max(chosen['high'],chosen['fixed_high'])
    assert (obs['low'],obs['high'])==(low,high)
    end,state=independent_stop(visible,origin,low,high)
    assert obs['state']==state,('lifecycle',obs['state'],state,event['id'],cutoff)
    assert obs['end']==int(visible[end].time.timestamp()),('end',event['id'],cutoff)
    for s in obs['segments']:
        a,z=positions[s['start']],positions[s['end']]
        assert a<=z and s['known']<=cutoff and stamp(visible[z])<=cutoff
        assert all(visible[k].time==visible[k-1].closed_at for k in range(a+1,z+1)), 'Joined missing bars'
        for key,i in [('price0',a),('price1',z)]:
            assert math.isclose(s[key],event['line']+event['slope']*(i-origin),rel_tol=0,abs_tol=1e-8)

def check_outer(out,event,inner,contexts,bars,cutoff):
    if not out:return
    lookup={c['id']:c for c in contexts};prev_low,prev_high=inner['low'],inner['high'];prev_known=event['clock']
    origin=next(i for i,b in enumerate(bars) if stamp(b)==event['clock'])
    for link in out['range_chain']:
        c=lookup[link['parent_range_id']]
        assert c['known']<=int(bars[origin].time.timestamp())
        assert link['low']<=prev_low and link['high']>=prev_high and (link['low'],link['high'])!=(prev_low,prev_high)
        assert prev_known<link['known']<=cutoff
        i=next(i for i,b in enumerate(bars) if stamp(b)==link['known'])
        assert bars[i].time==bars[i-1].closed_at
        assert all(link['low']<=v<=link['high'] for b in bars[i-1:i+1] for v in (b.open,b.close))
        # Replaying the selected outer independently must not have already
        # exited before this handoff. It must never revive a terminated range.
        _,state=independent_stop(bars[:i+1],origin,link['low'],link['high'])
        assert state in ('observing','resumed')
        prev_low,prev_high,prev_known=link['low'],link['high'],link['known']
    positions={int(b.time.timestamp()):i for i,b in enumerate(bars)}
    for s in out['segments']:
        assert s['known']<=cutoff and stamp(bars[positions[s['end']]])<=cutoff
        a,z=positions[s['start']],positions[s['end']]
        assert all(bars[k].time==bars[k-1].closed_at for k in range(a+1,z+1))
        for key,i in [('price0',a),('price1',z)]:
            assert math.isclose(s[key],event['line']+event['slope']*(i-origin),rel_tol=0,abs_tol=1e-8)

def main():
    global V
    parser=argparse.ArgumentParser();parser.add_argument('--candidate',action='store_true');args=parser.parse_args()
    selected_handoff=handoff_chain
    if args.candidate:
        from outer_gap_candidate import handoff_chain as selected_handoff
        V=B/'verification/outer_gap_20261118/multidate';V.mkdir(parents=True,exist_ok=True)
    start_time=time.perf_counter()
    raw=load_bars(B/'testdata/native_history_H1.tsv')
    bars=[worker.NativeBar(b.time,b.open,b.high,b.low,b.close,b.spread,b.seconds) for b in raw]
    catalogue=json.loads((B/'all_example_candidates.json').read_text('utf8'))
    byclose={stamp(b):i for i,b in enumerate(bars)};reports=[];checks=0;future_checks=0
    for case_number,c in enumerate(catalogue):
        end=byclose[c['clock']]+1;start=max(0,int(c['original']['window'])-1100)
        assert start<end
        prefix=tuple(bars[start:end]);window=bars[start:min(len(bars),end+240)]
        contexts,_=worker.recognize(prefix)
        event=dict(id=c['original']['id'],family=c['original']['family'],clock=c['clock'],known=int(c['original']['known']),state=c['original']['state'],line=c['line'],slope=c['slope'])
        result=worker.classify(event,prefix,contexts)
        frozen=copy.deepcopy((event,result,contexts));states=collections.Counter();outer_states=collections.Counter();chains=0;max_chain=0;last=None
        for n in range(len(prefix),len(window)+1):
            visible=window[:n];cutoff=stamp(visible[-1])
            inner=observe(event,result,contexts,visible,cutoff)
            check_observation(inner,event,contexts,visible,cutoff)
            outer=selected_handoff(event,{**result,'continuation':inner},contexts,visible,cutoff)
            if args.candidate:
                old_outer=handoff_chain(event,{**result,'continuation':inner},contexts,visible,cutoff)
                if old_outer:
                    assert outer and outer['segments'][:len(old_outer['segments'])]==old_outer['segments'],('Old outer changed',case_number,cutoff)
                    assert outer['range_chain'][:len(old_outer['range_chain'])]==old_outer['range_chain']
            check_outer(outer,event,inner,contexts,visible,cutoff)
            checks+=1;states[inner['state'] if inner else 'not_admitted']+=1
            if outer:chains+=1;max_chain=max(max_chain,len(outer['range_chain']));outer_states[outer['state']]+=1
            if n==len(prefix) or n==len(window) or (n-len(prefix))%12==0:
                future=observe(event,result,contexts,window,cutoff)
                future_outer=selected_handoff(event,{**result,'continuation':future},contexts,window,cutoff)
                assert inner==future and outer==future_outer,('future suffix affected past',case_number,cutoff)
                future_checks+=1
            assert frozen==(event,result,contexts),'Input mutation'
            last={'inner':inner,'outer':outer}
        report={'case':case_number,'event':event,'event_native_label':datetime.fromtimestamp(c['clock'],timezone.utc).isoformat(),
                'prefix_bars':len(prefix),'following_bars':len(window)-len(prefix),'context_count':len(contexts),
                'classification':result['code'],'states':dict(states),'outer_states':dict(outer_states),'outer_prefixes':chains,'max_chain':max_chain,'final':last,
                'contexts_at_original_event':contexts,'classification_record':result}
        reports.append(report)
        (V/f'case_{case_number:02}.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
        print(json.dumps({k:v for k,v in report.items() if k not in ('event','final','contexts_at_original_event','classification_record')},ensure_ascii=False),flush=True)
    receipt={'passed':True,'candidate_gap_handoff':args.candidate,'cases':len(reports),'closed_prefix_checks':checks,'future_suffix_checks':future_checks,
             'classifications':dict(collections.Counter(x['classification'] for x in reports)),
             'cases_with_outer_handoff':sum(x['outer_prefixes']>0 for x in reports),'max_chain':max(x['max_chain'] for x in reports),
             'elapsed_seconds':time.perf_counter()-start_time,
             'source_sha256':{p:sha(B/p) for p in ('worker.py','continuation.py','outer_continuation.py','outer_gap_candidate.py','testdata/native_history_H1.tsv','all_example_candidates.json','audit_multidate_continuation.py')},
             'limits':['Selected saved GUIDED_TURNING examples only; not all families or unbiased accuracy.','Up to240 subsequent observed bars, not the whole future.','Offline native data/causal logic audit, not fresh chart visual acceptance.','Does not certify missing regions without captured Book events.']}
    (V/'acceptance.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
    print(json.dumps(receipt,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
