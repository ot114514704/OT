"""Create hashed full backups with and without the locally supplied Book sources."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from package_book_outline_side import ROOT, read, sha

OUT=ROOT/'verification/book_recovery_r5p8'


def main():
    base=read(ROOT/'PACKAGE_R5P7.json')
    meta={}
    assert read(OUT/'october_A.json')['warmup_equal']
    assert read(OUT/'native.json')['rows']==136
    assert len(read(OUT/'rolling_requests.json'))==5
    assert 'OK' in (OUT/'regression.txt').read_text('utf-8-sig').splitlines()
    for kind,details in base.items():
        archive=Path(details['path'])
        assert sha(archive.read_bytes())==details['sha256']
        with ZipFile(archive) as z:
            files={n:z.read(n) for n in z.namelist() if n!='R5P7_PACKAGE_MANIFEST.json'}
        additions=['worker.py','book_pair_recovery.py','test_book_pair_recovery.py','verify_pair_recovery.py',
                   'replay_recovery_requests.py','replay_frozen_book_closes.py','trace_october_recovery.py','package_pair_recovery.py']
        for p in OUT.iterdir():
            if p.is_file() and p.name!='OT_receipt.json':
                additions.append(p.relative_to(ROOT).as_posix())
        for n in additions:
            files[n]=(ROOT/n).read_bytes()
        files['README_R5P8.txt']=(OUT/'复核与恢复.txt').read_bytes()
        path=archive.parent/f'Book302_1.230-r5p8_H1双破收回_{kind}_20261118.zip'
        manifest={k:sha(v) for k,v in files.items()}
        with ZipFile(path,'x',ZIP_DEFLATED) as z:
            for k,v in files.items():
                z.writestr(k,v)
            z.writestr('R5P8_PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
        with ZipFile(path) as z:
            assert z.testzip() is None and all(sha(z.read(k))==v for k,v in manifest.items())
        data=path.read_bytes()
        meta[kind]=dict(path=str(path),sha256=sha(data),bytes=len(data),files_verified=len(files),
                        git_blob_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
    (ROOT/'PACKAGE_R5P8.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),'utf8')
    print(meta)


if __name__=='__main__':
    main()

