"""Screen two fixed H1 chart windows for three-bar breaks and test their original rails."""
from collections import Counter
from functools import lru_cache
from hashlib import sha256
import json

from book_pair_recovery import line_at,short_sequence
from book_viewport_structure import inspect_close,stamp
from replay_summer_book import ROOT,history
from review_summer_context import counterleg

OUT=ROOT/'verification/book_three_closes_20261118'
PERIODS=[('2026-03-16','2026-04-11'),('2026-11-02','2026-11-14')]


def details(bars,indices,i,pair,checked):
    sign=1 if pair['direction']=='down' else -1
    event=short_sequence(bars,indices,i,pair,checked)
    values=[]
    for j in range(i-2,i+4):
        if j>i and bars[j].time!=bars[j-1].closed_at:
            break
        seen=checked(j)
        identity=('origin','terminal','direction','pair_known','trend','turning')
        equivalent=[p for p in seen.get('pairs',[]) if all(p[k]==pair[k] for k in identity)]
        row=dict(clock=stamp(bars[j].closed_at),close=bars[j].close,open=bars[j].open,
                 high=bars[j].high,low=bars[j].low,continuous=bars[j].time==bars[j-1].closed_at,
                 source_event=equivalent[0]['event'] if len(equivalent)==1 else None)
        for name,anchor in [('trend',0),('turning',2)]:
            rail=pair[name]
            level=line_at(rail,rail[anchor],j,indices)
            row[name]=float(level)
            from fractions import Fraction
            row[name+'_outside']=sign*(Fraction(str(row['close']))-level)>0
        values.append(row)
    return dict(owner=pair['owner'],direction=pair['direction'],origin=pair['origin'],terminal=pair['terminal'],
                trend=pair['trend'],turning=pair['turning'],known=pair['pair_known'],first_rail='trend' if
                pair['trend_break_bar']<pair['turning_break_bar'] else 'turning',event=stamp(bars[i].closed_at),
                active=pair['source_alive'],terminal_unchanged=pair['same_terminal'],accepted=bool(event),
                values=values,A={n:counterleg(pair,bars,i-2,i,n) for n in (256,512,768)})


def main():
    OUT.mkdir(exist_ok=True)
    bars=history()
    ix={stamp(b.time):i for i,b in enumerate(bars)}
    @lru_cache(maxsize=20)
    def checked(i):
        return inspect_close(bars[i-511:i+1])
    periods=[]
    for begin,end in PERIODS:
        cases=[]
        count=Counter()
        for i,b in enumerate(bars):
            if not begin<=stamp(b.closed_at)[:10]<end:
                continue
            report=checked(i)
            count['bars']+=1
            count[report['status']]+=1
            for p in report.get('pairs',[]):
                if p.get('bars_between')!=2:
                    continue
                count[p['event']]+=1
                if p['event']=='later_line':
                    cases.append(details(bars,ix,i,p,checked))
        periods.append(dict(begin=begin,end_exclusive=end,counts=count,cases=cases))
        print(begin,dict(count),[(c['event'],c['accepted']) for c in cases],flush=True)
    result=dict(periods=periods,history_sha256=sha256((ROOT/'testdata/native_history_H1.tsv').read_bytes()).hexdigest(),
                worker_component=sha256((ROOT/'book_pair_recovery.py').read_bytes()).hexdigest())
    (OUT/'screen.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),'utf8')


if __name__=='__main__':
    main()

