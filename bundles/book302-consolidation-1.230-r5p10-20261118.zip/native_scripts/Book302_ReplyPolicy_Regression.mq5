#property strict
#property version "1.000"
#include "../source/BookExperimentReplyPolicy.mqh"
void OnStart(){
 string a="R\t原生\nEND\t同图\t1\n",b="R\t闭盘\nEND\t同图\t1\n";
 string da=BKNHash(a),db=BKNHash(b);
 bool checks[]={BEXReplyDigestValid(da),!BEXReplyDigestValid(""),!BEXReplyDigestValid("0123"),
 BEXReplyPayloadValid(da,a),!BEXReplyPayloadValid(da,b),!BEXReplyPayloadValid(da,a+"truncated"),
 BEXReplyUnchanged("view","full",da,"view","full",da),
 !BEXReplyUnchanged("view","full",da,"view","full",db),
 !BEXReplyUnchanged("view","core",da,"view","full",da),
 !BEXReplyUnchanged("old","full",da,"new","full",da),
 !BEXReplyUnchanged("view","full","","view","full","")};
 int passed=0,failed=0;for(int i=0;i<ArraySize(checks);i++){if(checks[i])passed++;else failed++;}
 int f=FileOpen("Book302Experiment1230\\reply_policy_tests.tsv",FILE_WRITE|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);
 if(f!=INVALID_HANDLE){FileWrite(f,"version","passed","failed","utf8_digest","time");FileWrite(f,"r5",passed,failed,da,(long)TimeGMT());FileClose(f);}
 PrintFormat("REPLY_POLICY_R5 passed=%d failed=%d",passed,failed);
}
