import copy,hashlib,json,unittest
from pathlib import Path
import worker

class ReplyRevisionTests(unittest.TestCase):
 def setUp(self):
  self.req={'token':'原生同一视窗','cutoff':1794582000}
  self.records=json.loads((worker.BASE/'verification/outer_gap_20261118/november_expected_results.json').read_text('utf8'))
 def wire(self,records=None,seconds=1,stage='full'):
  return worker.encode_reply(self.req,self.records if records is None else records,seconds,stage)
 def test_digest_covers_exact_utf8_payload_including_end(self):
  wire=self.wire();header,payload=wire.split('\n',1)
  self.assertEqual(len(header.split('\t')),9)
  self.assertEqual(header.split('\t')[8],hashlib.sha256(payload.encode('utf8')).hexdigest())
  self.assertTrue(payload.endswith('END\t原生同一视窗\t107\n'))
 def test_elapsed_time_does_not_change_content_revision(self):
  a,b=self.wire(seconds=1),self.wire(seconds=99)
  self.assertEqual(a.split('\n',1)[1],b.split('\n',1)[1])
  self.assertEqual(a.splitlines()[0].split('\t')[8],b.splitlines()[0].split('\t')[8])
 def test_same_length_result_change_changes_revision(self):
  edited=copy.deepcopy(self.records);target=next(r for r in edited if '收盘' in r['detail']);target['detail']=target['detail'].replace('收盘','闭盘',1)
  self.assertNotEqual(edited,self.records)
  a,b=self.wire(),self.wire(edited)
  self.assertEqual(len(a.encode('utf8')),len(b.encode('utf8')))
  self.assertNotEqual(a.splitlines()[0].split('\t')[8],b.splitlines()[0].split('\t')[8])
 def test_payload_is_exact_original_protocol_payload(self):
  expected=(worker.BASE/'verification/outer_gap_20261118/deployed/reply_102923304041429_3600.tsv').read_text('utf-8-sig').split('\n',1)[1]
  # Only replace the test token, not fields, line order or original geometry.
  expected=expected.replace('6d2869c6c4a6becb1119edc9856ef838c29c85f05d61c83532d1c0c1d8b0e14d',self.req['token'])
  self.assertEqual(self.wire().split('\n',1)[1],expected)
 def test_new_outer_segment_changes_revision(self):
  old=copy.deepcopy(self.records)
  next(r for r in old if r['id']=='b0aad2b41ae9e9a0e97b6a6e')['outer_continuation']=None
  self.assertNotEqual(self.wire().splitlines()[0].split('\t')[8],self.wire(old).splitlines()[0].split('\t')[8])

if __name__=='__main__':unittest.main()
