"""Closed-bar CSSRaw/CSSObserve from the supplied Wave 2.116 archive.

Only the fine swing ledger is used. Start fresh after missing native bars.
Return the confirmation clock separately from the timestamp of the extreme.
"""
from dataclasses import dataclass, replace
from math import sqrt, isfinite


@dataclass(frozen=True)
class Point:
    index: int
    side: int
    price: float
    noise: float
    total: float
    known: int


def confirmed_swings(bars):
    result = {}
    last_close = None
    base = tip = reaction = None
    scale = 1.75
    for index, bar in enumerate(bars):
        if last_close != bar.time:
            origin = index
            avg = background = total = 0.0
            base = tip = reaction = highest = lowest = None
            peer = {-1: 0., 1: 0.}
        if not all(isfinite(x) for x in (bar.high,bar.low,bar.close,bar.open)) or not bar.low <= min(bar.open,bar.close) <= max(bar.open,bar.close) <= bar.high:
            last_close = None
            continue
        width = bar.high - bar.low
        if index > origin:
            width = max(width, abs(bar.high-bars[index-1].close), abs(bar.low-bars[index-1].close))
        last_close = bar.closed_at
        count = index-origin+1
        avg += (width-avg)/min(24,count)
        background += (width-background)/min(192,count)
        total += bar.close
        clock = int(bar.closed_at.timestamp())
        high = Point(index,1,bar.high,sqrt(avg*min(avg,background)),total,clock)
        low = replace(high,side=-1,price=bar.low)

        def confirm(point):
            key = (int(bars[point.index].time.timestamp()), point.side)
            result.setdefault(key,clock)

        if tip is None:
            if highest is None or high.price > highest.price: highest = high
            if lowest is None or low.price < lowest.price: lowest = low
            if highest.index == lowest.index or highest.price-lowest.price < scale*avg:
                continue
            base, tip = sorted((highest,lowest),key=lambda p:p.index)
            confirm(base)
            continue
        for q in ((high,low) if tip.side>0 else (low,high)):
            side = tip.side
            if q.side==side and side*(q.price-tip.price)>=0:
                if reaction is not None and reaction.index<q.index:
                    depth = side*(tip.price-reaction.price)
                    lead = side*(tip.price-base.price)
                    resume = side*(q.price-reaction.price)
                    unit = max(tip.noise,reaction.noise)
                    typical = peer[-side]
                    gate = scale*(max(.8,min(1.35,typical/scale)) if typical else 1.)
                    if depth>0 and unit>0 and depth>=.26*scale*unit and lead>depth and resume>=depth and sqrt(depth*min(lead,resume))>=gate*unit:
                        confirm(tip)
                        confirm(reaction)
                        base,tip = reaction,q
                if side*(q.price-tip.price)>0: tip=q
                reaction=None
                continue
            if q.index==tip.index: continue
            if q.side!=side and (reaction is None or side*(reaction.price-q.price)>0): reaction=q
            if reaction is None: continue
            depth = side*(tip.price-reaction.price)
            leg = side*(tip.price-base.price)
            unit = max(tip.noise,q.noise)
            if min(depth,leg,unit)<=0: continue
            span = q.index-tip.index
            mean_depth=max(0.,side*(tip.price-(q.total-tip.total)/span))
            extent,ratio=depth/unit,depth/leg
            persistence=min(1.,mean_depth/depth)*sqrt(min(2.,span/max(1,tip.index-base.index)))
            typical=peer[reaction.side]
            budget=scale*(max(.75,min(1.5,typical/scale)) if typical else 1.)
            if extent<.48*scale or (extent*(1+.55*persistence+.45*min(1.,ratio))<budget and ratio<1.): continue
            confirm(tip)
            sample=max(.65*scale,min(1.6*scale,extent))
            peer[reaction.side]=.8*typical+.2*sample if typical else sample
            base,tip=tip,reaction
            reaction=q if q.index>tip.index and q.side!=tip.side else None
    return result
