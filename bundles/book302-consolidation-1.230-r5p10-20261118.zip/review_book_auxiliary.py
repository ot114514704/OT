"""Generate a separate Book-primary review from an immutable native snapshot.

No live writes, imports of archive programs, orders or chart navigation.
The default November reference is NOT the moving current viewport.
"""
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, sys, time
import worker
from book_auxiliary import VERSION, select

sys.stdout.reconfigure(encoding='utf8')
B = Path(__file__).parent
SOURCE = B/'verification/outer_gap_20261118/november_before'
V = B/'verification/book_auxiliary_20261118/november_reference'
V.mkdir(parents=True, exist_ok=True)
S = '102923304041429_3600'
raw = (SOURCE/f'request_{S}.tsv').read_text('utf8')
req = worker.parse_request(raw)
full = json.loads((SOURCE/f'full_model_{S}.json').read_text('utf8'))
assert req['token'] == full['token']
start = int(datetime(2026,11,3,tzinfo=timezone.utc).timestamp())
events = [e for e in req['events'] if e['clock'] >= start]
positions = {int(b.closed_at.timestamp()): i for i,b in enumerate(req['bars'])}
clocks = set()
for e in events:
    i = positions[e['clock']]
    if i and e['known'] <= e['clock']-req['seconds'] and 'retrospective' not in e['state']:
        clocks.update([e['clock'], int(req['bars'][i-1].closed_at.timestamp())])
snapshots = {}
started = time.monotonic()
for n, clock in enumerate(sorted(clocks),1):
    p = V/f'context_{clock}.json'
    prefix = tuple(req['bars'][:positions[clock]+1])
    context, _ = worker.recognize(prefix)
    p.write_text(json.dumps(context, ensure_ascii=False, indent=2), 'utf8')
    snapshots[clock] = context
    print(json.dumps({'snapshot': n,'total':len(clocks),'clock':clock}), flush=True)
results = []
for e in events:
    i = positions[e['clock']]
    if not i: continue
    prev, bar = req['bars'][i-1:i+1]
    r = select(e, prev, bar, snapshots.get(int(prev.closed_at.timestamp()), []),
               snapshots.get(e['clock'], []), req['patterns'])
    results.append(r)
report = {'version':VERSION,'source_token':req['token'],
    'source_request_sha256':hashlib.sha256(raw.encode('utf8')).hexdigest(),
    'reference_period':'2026-11-03 through saved 2026-11-13 cutoff; native chart clock',
    'current_viewport':False,'deployed':False,'chart_changed':False,
    'book_priority':True,'book_core_changed':False,'events':len(results),
    'linked':sum(r['primary'] is not None for r in results),
    'pa_linked':sum(bool(r['pa']) for r in results),'results':results,
    'elapsed_seconds':time.monotonic()-started,
    'source_sha256':{p:hashlib.sha256((B/p).read_bytes()).hexdigest() for p in ('book_auxiliary.py','worker.py')}}
(V/'review.json').write_text(json.dumps(report, ensure_ascii=False, indent=2),'utf8')
print(json.dumps({k:v for k,v in report.items() if k!='results'},ensure_ascii=False),flush=True)
