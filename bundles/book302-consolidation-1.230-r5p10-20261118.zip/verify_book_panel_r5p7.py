"""Compare the r5p7 native H1 receipt to the pre-upgrade request and replay marked closes."""
import csv
import json
import shutil
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

import prepare_book_reference as installer
from book_viewport_structure import WINDOW, inspect_close, note
from package_book_outline_side import ROOT, BRIDGE, KEY, read, sha, tsv
from worker import NativeBar

OUT = ROOT / 'verification/book_panel_r5p7'


def verify_native():
    request = f'request_{KEY}.tsv'
    assert (OUT/request).read_bytes() == (BRIDGE/request).read_bytes()
    def contents(folder):
        return read(folder/f'audit_{KEY}.json'), tsv(folder/f'reply_{KEY}.tsv')
    old, oldlines = contents(OUT)
    current, lines = contents(BRIDGE)
    revision = tsv(BRIDGE/f'reply_revision_{KEY}.tsv')[0].split('\t')
    render = tsv(BRIDGE/f'render_state_{KEY}.tsv')[0].split('\t')
    head = lines[0].split('\t')
    identity = read(BRIDGE/'worker_identity.json')
    assert head[2] == revision[2] == render[3] == render[4] == current['token'] == old['token']
    assert head[7] == revision[3] == render[5] == 'full' and current['full_model']['available']
    assert head[8] == revision[4] == sha(('\n'.join(lines[1:])+'\n').encode())
    assert identity['script_sha256'] == sha((ROOT/'worker.py').read_bytes())
    assert min(int(revision[5]),int(render[12])) >= int(identity['started'])
    assert len(lines) == len(oldlines)
    assert len(old['results']) == len(current['results']) == int(head[3])
    assert int(render[11]) == sum(r.startswith('C\t') for r in lines)
    clocks = {}
    updates = 0
    for before, after in zip(old['results'],current['results']):
        row = dict(after)
        context = row.pop('book_structure',None)
        if context:
            prefix = note(context)+'；'
            assert context['status'] != 'unavailable' and row['detail'].startswith(prefix)
            row['detail'] = row['detail'][len(prefix):]
            clock = row['clock']
            assert clocks.setdefault(clock,context) == context
            updates += 1
        else:
            assert row['code'] == 7
        assert row == before, row['id']
    for before, after in zip(oldlines[1:],lines[1:]):
        a,b = before.split('\t'),after.split('\t')
        if a[0] == 'R':
            assert b[11].endswith(a[11])
            b[11] = a[11]
        assert a == b
    for name in [f'render_state_{KEY}.tsv',f'reply_revision_{KEY}.tsv',f'experiment_{KEY}.png']:
        shutil.copyfile(BRIDGE/name,OUT/name)
    return dict(rows=int(head[3]), updated=updates, clocks=len(clocks), continuations=int(render[11]),
                status=dict(Counter(c['status'] for c in clocks.values())),
                current_note=note(next(r['book_structure'] for r in current['results'] if r['id']=='__CURRENT')),
                token=head[2], revision=head[8], worker=identity['script_sha256'])


def historical():
    bars=[]
    with (ROOT/'testdata/native_history_H1.tsv').open(encoding='utf-8-sig') as f:
        for r in csv.DictReader(f,delimiter='\t'):
            bars.append(NativeBar(datetime.fromtimestamp(int(r['time']), timezone.utc),
                        *(float(r[k]) for k in ('open','high','low','close')),float(r['spread'])*0.01,3600))
    cases = [('08-28T10','trend_only'),('09-01T12','later_line'),('10-02T19','same_bar'),
             ('10-29T09','same_bar'),('11-10T19','same_bar')]
    records = {}
    for cut,event in cases:
        clock = '2026-'+cut+':00:00+00:00'
        i = next(i for i,b in enumerate(bars) if b.closed_at.isoformat()==clock)
        report = inspect_close(bars[max(0,i-WINDOW+1):i+1])
        assert report['counts'].get(event,0)>0,(cut,report['counts'])
        assert all(p['pair_known'] <= bars[i].time.isoformat().replace('+00:00','Z') for p in report['pairs'])
        records[clock] = dict(counts=report['counts'],detail=note(report))
    assert inspect_close([bars[0],bars[1],bars[4]])['status']=='gap'
    return records


def restore_test():
    with TemporaryDirectory(dir=OUT) as tmp, patch.object(installer,'ROOT',Path(tmp)):
        shutil.copyfile(ROOT/'book_reference_manifest.json',Path(tmp)/'book_reference_manifest.json')
        archive = Path.home()/'Downloads/forex-ai-source-main.zip'
        installer.restore(archive)
        installer.restore(archive)
        manifest=read(Path(tmp)/'book_reference_manifest.json')
        file=Path(tmp)/'book_archive_runtime'/next(iter(manifest))
        file.write_bytes(b'digest test')
        try:
            installer.restore(archive)
        except ValueError:
            return len(manifest)
        raise AssertionError('Modified dependency accepted')


if __name__=='__main__':
    report=dict(native=verify_native(),history=historical(),restore_verified=restore_test())
    result=json.dumps(report,ensure_ascii=False,indent=2)
    (OUT/'r5p7_verification.json').write_text(result,'utf8')
    print(result)

