"""Plot the three August candidates on the native observed-bar axis."""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from replay_august_overlap import OUT,HISTORY,load_bars,stamp

rows=json.loads((OUT/'august_replay.json').read_text('utf8'))['checks']
bars=load_bars(HISTORY)
indices={int(b.time.timestamp()):i for i,b in enumerate(bars)}
closing={int(b.closed_at.timestamp()):i for i,b in enumerate(bars)}
plt.rcParams.update({'font.sans-serif':['Microsoft YaHei'],'axes.unicode_minus':False})
fig,axes=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
for ax,roles,begin,end,title in [(axes[0],['channel','box'],'2026-08-24T18','2026-08-28T22','下降通道与末端箱体'),
                               (axes[1],['triangle'],'2026-08-28T18','2026-09-01T14','下跌后的收敛三角')]:
    view=[(i,b) for i,b in enumerate(bars) if begin<=b.time.isoformat()<end]
    for i,b in view:
        color='#317661' if b.close>=b.open else '#aa453a'
        ax.vlines(i,b.low,b.high,color=color,lw=.7)
        ax.add_patch(Rectangle((i-.28,min(b.open,b.close)),.56,max(.08,abs(b.close-b.open)),facecolor=color,edgecolor=color,lw=.5))
    for role in roles:
        obs=[r['shapes'][role]['current'] for r in rows if r['shapes'][role]['current'] and r['shapes'][role]['current']['high']>r['shapes'][role]['current']['low']]
        first,last=obs[0],obs[-1]
        a,b=closing[first['known']],closing[last['end']]
        start=indices[first['start']]
        color,label={'channel':('#294e85','通道'),'box':('#9a641e','局部箱体'),'triangle':('#765a99','三角')}[role]
        for k in ['high','low']:
            slope=(last[k]-first[k])/(b-a)
            for x in obs:
                assert abs(x[k]-first[k]-slope*(closing[x['end']]-a))<1e-6,(role,k)
            ax.plot([start,a],[first[k]+slope*(start-a),first[k]],ls=':',lw=1.4,color=color)
            ax.plot([a,b],[first[k],last[k]],lw=1.8,color=color,label=label if k=='high' else None)
            ax.scatter(a,first[k],s=15,color=color,zorder=5)
        ax.fill_between([a,b],[first['low'],last['low']],[first['high'],last['high']],color=color,alpha=.08)
    ticks=view[::max(1,len(view)//4)]
    ax.set_xticks([i for i,_ in ticks],[b.closed_at.strftime('%m-%d\n%H:%M') for _,b in ticks],fontsize=8)
    ax.set_title(title)
    ax.set_xlabel('H1 收盘时刻')
    ax.grid(axis='y',alpha=.16)
    ax.legend(loc='best')
axes[0].set_ylabel('XAUUSD 价格')
fig.suptitle('8 月 H1 盘整复盘　虚线为形成区间，实线从首次识别的收盘开始',fontsize=14)
fig.savefig(OUT/'八月通道箱体与三角.png',dpi=145)
plt.close(fig)
