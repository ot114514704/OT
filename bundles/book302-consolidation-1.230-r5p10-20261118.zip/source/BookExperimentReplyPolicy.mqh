#ifndef BOOK_EXPERIMENT_REPLY_POLICY
#define BOOK_EXPERIMENT_REPLY_POLICY
#include "book_native/BookNativeIdentity.mqh"
bool BEXReplyDigestValid(string digest){
 if(StringLen(digest)!=64)return false;
 for(int i=0;i<64;i++){ushort c=StringGetCharacter(digest,i);if(!((c>='0'&&c<='9')||(c>='a'&&c<='f')))return false;}
 return true;
}
bool BEXReplyUnchanged(string loaded_token,string loaded_stage,string loaded_digest,string token,string stage,string digest){
 return BEXReplyDigestValid(digest)&&loaded_token==token&&loaded_stage==stage&&loaded_digest==digest;
}
bool BEXReplyPayloadValid(string digest,string payload){return BEXReplyDigestValid(digest)&&BKNHash(payload)==digest;}
#endif
