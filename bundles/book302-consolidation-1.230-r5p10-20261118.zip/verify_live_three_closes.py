"""Record the live range decision against independently queried closed native H1/M15 bars."""
import json
from datetime import datetime
import time
import MetaTrader5 as mt
from inspect_current_book_structure import fetch
from screen_three_book_closes import OUT


def main():
    state=fetch('state')
    if state['status']!='connected' or state['model_input_origin']!='native':
        raise RuntimeError('No connected native model')
    if not mt.initialize(path='C:/Program Files/MetaTrader 5/terminal64.exe',timeout=10000):
        raise RuntimeError(str(mt.last_error()))
    result={}
    try:
        assert mt.terminal_info().connected and mt.account_info().server==state['market_source']['server']
        for frame,period in [('H1',mt.TIMEFRAME_H1),('M15',mt.TIMEFRAME_M15)]:
            r=state['current_consolidation'][frame]
            assert r['availability']=='live' and not r['analysis_pending'] and r['bar_sync']['status']=='aligned'
            chart=state['charts'][frame]['bars'][-1]
            assert chart['closed_at']==r['known_at']==state['forming'][frame]['time']
            native=mt.copy_rates_range('XAUUSD',period,datetime.fromisoformat(chart['time']),datetime.fromisoformat(chart['time']))
            assert native is not None and len(native)==1 and int(native[0]['time'])==int(datetime.fromisoformat(chart['time']).timestamp())
            assert all(float(native[0][k])==chart[k] for k in ('open','high','low','close'))
            result[frame]=dict(clock=r['known_at'],close=chart['close'],verdict=r['label'],reason=r['reason'],
                               missing=r['missing'],candidates=[{k:o.get(k) for k in ('kind','shape','known_at','closed_position','confirmed')}
                                                                for o in r['candidate_observations']])
    finally:
        mt.shutdown()
    samples=[]
    for i in range(4):
        if i:
            time.sleep(2)
        now=fetch('live')
        samples.append(dict(tick=now['quote']['raw_epoch'],model=now['model_revision'],
                            verdicts={p:r['label'] for p,r in now['current_consolidation'].items()},
                            clocks=now['latest_closed_end']))
    same=all(s['model']==state['model_revision'] and s['clocks']==state['latest_closed_end'] and
             s['verdicts']=={p:r['verdict'] for p,r in result.items()} for s in samples)
    report=dict(server=state['market_source']['server'],periods=result,raw_quote_updated=len({s['tick'] for s in samples})>1,
                closed_model_stable=same,samples=samples)
    (OUT/'live_native_sample.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
    print([(p,r['clock'],r['verdict'],len(r['candidates'])) for p,r in result.items()],same,report['raw_quote_updated'])


if __name__=='__main__':
    main()

