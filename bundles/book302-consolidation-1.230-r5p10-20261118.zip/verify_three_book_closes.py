"""Replay real sustained and reclaimed three-bar examples with physically truncated MT5 requests."""
import json
from datetime import datetime
from functools import lru_cache

from book_pair_recovery import observe,summary,line_at
from book_viewport_structure import inspect_close,stamp
from screen_three_book_closes import OUT,history
from worker import parse_request,solve,encode_reply,recognize,select_book_range

DATES=('2026-03-18T14:00:00Z','2026-04-02T09:00:00Z','2026-11-06T21:00:00Z')


def review():
    bars=history()
    index={stamp(b.time):i for i,b in enumerate(bars)}
    ends={stamp(b.closed_at):i for i,b in enumerate(bars)}
    screened=json.loads((OUT/'screen.json').read_text('utf8'))
    expected={c['event'] for p in screened['periods'] for c in p['cases']}
    assert expected==set(DATES)
    outcome=[]
    for clock in DATES:
        i=ends[clock]
        sensitivity=[]
        for n in (256,512,768):
            @lru_cache(maxsize=10)
            def checked(j):
                return inspect_close(bars[j-n+1:j+1])
            report=checked(i)
            observations=observe(bars,index,i,i+3,report,checked)
            selected=[o for o in observations if 'renewed_dual_close' in o or 'consecutive_break' in o]
            items=[]
            for o in selected:
                p=next(q for q in report['pairs'] if q['owner']==o['owner'])
                path='renewed_dual_close' if 'renewed_dual_close' in o else 'consecutive_break'
                items.append(dict(origin=p['origin'],terminal=p['terminal'],trend=p['trend'],turning=p['turning'],
                                  path=path,proof=o[path],observations=o['observations'],first_reentry=o['first_reentry']))
                if n==512:
                    at=recognize(tuple(bars[i-512:i+1]))[0]
                    before=recognize(tuple(bars[i-512:i]))[0]
                    sets=[]
                    for rail_name,origin in [('trend',0),('turning',2)]:
                        rail=p[rail_name]
                        value=line_at(rail,rail[origin],i,index)
                        slope=value-line_at(rail,rail[origin],i-1,index)
                        event=dict(id=p['owner']+'/'+rail_name,known=int(datetime.fromisoformat(p['pair_known']).timestamp()),
                                   clock=int(bars[i].closed_at.timestamp()),line=float(value),slope=float(slope),
                                   owner_a=p['origin'][0],owner_b=p['terminal'][0],state='first_close_break')
                        context=select_book_range(event,bars[i-1],bars[i],before,at)
                        sets.append({r['range']['id']:r['kind'] for r in [context['primary'],*context['alternatives']] if r})
                    items[-1]['common_ranges']={k:v for k,v in sets[0].items() if k in sets[1]}
            sensitivity.append(dict(n=n,paths=items))
        def signature(items):
            return sorted(json.dumps({k:v for k,v in p.items() if k!='common_ranges'},sort_keys=True) for p in items)
        assert all(signature(w['paths'])==signature(sensitivity[0]['paths']) for w in sensitivity)
        active=sensitivity[1]['paths']
        if clock==DATES[1]:
            assert len(active)==3 and all(p['path']=='consecutive_break' and p['proof']['bars']==3 for p in active)
        else:
            assert all(p['path']=='renewed_dual_close' for p in active)
            assert len(active)==(1 if clock==DATES[0] else 2)
        if clock==DATES[2]:
            assert sorted(p['proof']['opening_outside'] for p in active)==[0,1]
        requests=[]
        for end in range(i-1,i+3):
            portion=bars[i-514:end+1]
            cutoff=int(portion[-1].closed_at.timestamp())
            token='three-H1-'+str(cutoff)
            rows=[f'BEXP\t1\t{token}\t3600\t{cutoff}\t{len(portion)}\thistory\tXAUUSD\t0.01']
            rows.extend('\t'.join(map(str,('B',int(b.time.timestamp()),b.open,b.high,b.low,b.close,round(b.spread/.01)))) for b in portion)
            request=parse_request('\n'.join([*rows,'END\t'+token]))
            results=solve(request)
            view=results[-1]
            assert view['id']=='__CURRENT' and view['follow'] in encode_reply(request,results,0)
            data=[p for p in view.get('book_pair_recovery',[]) if p['event']==clock and
                  ('renewed_dual_close' in p or 'consecutive_break' in p)]
            assert len(data)==(len(active) if end>=i else 0)
            assert all(p['observations'][-1]['clock']<=stamp(portion[-1].closed_at) for p in data)
            if end==i:
                assert all(len(p['observations'])==1 for p in data)
            requests.append(dict(clock=stamp(portion[-1].closed_at),matches=len(data),follow=view['follow']))
        outcome.append(dict(clock=clock,warmups=[w['n'] for w in sensitivity],exact_agreement=True,paths=active,requests=requests))
        print(clock,[(p['path'],p['proof'],list(p['common_ranges'].values())) for p in active],flush=True)
    (OUT/'verified_paths.json').write_text(json.dumps(outcome,indent=2,ensure_ascii=False),'utf8')


if __name__=='__main__':
    review()

