"""Replay the requested two/three-close filters against a frozen single line."""
import csv
import json
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parent
out = root / "verification/book_auxiliary_20261118/geometry_replay"
observations = json.loads((out / "observations.json").read_text("utf8"))
with (root / "testdata/native_history_H1.tsv").open(encoding="utf-8-sig") as handle:
    bars = {int(row["time"]): row for row in csv.DictReader(handle, delimiter="\t")}

results = []
for event in observations:
    if not event["causal_cross"] or event["checks_failed"]:
        continue
    r = event["original"]
    bar_time = int(r["cross"]) - 3600
    assert bar_time == int(r["b"])
    # Anchor intervals are contiguous native H1 bars in this audited set.
    slope = (float(r["price_b"]) - float(r["price_a"])) / ((int(r["anchor_b"]) - int(r["anchor_a"])) / 3600)
    sign = 1 if slope > 0 else -1
    checks = []
    for offset in range(3):
        start = bar_time + offset * 3600
        bar = bars.get(start)
        if bar is None:
            break
        rail = float(r["pb"]) + offset * slope
        checks.append({"close_time": start + 3600,
                       "outside": (float(bar["close"]) - rail) * sign < -1e-7})
    assert checks and checks[0]["outside"]
    def outcome(n):
        if any(not c["outside"] for c in checks[:n]):
            return "returned_or_touched"
        return "held" if len(checks) >= n else "missing_contiguous_bar"
    results.append({"id": r["id"], "cross": r["cross"], "two": outcome(2), "three": outcome(3), "checks": checks})
report = {"scope": "Single frozen geometric line projected for review only. First outside close counts as bar one. No Book double break or A is inferred.",
          "observations": len(results), "two": dict(Counter(r["two"] for r in results)),
          "three": dict(Counter(r["three"] for r in results)), "results": results}
(out / "close_filter.json").write_text(json.dumps(report,ensure_ascii=False,indent=2), "utf8")
print(report["observations"], report["two"], report["three"])
