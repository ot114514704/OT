"""Verify the current MT5 bridge result and build the independent r5p5 backup."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'verification/book_outline_side_20261118'
BRIDGE=ROOT/'runtime/bridge'
KEY='102923304041429_3600'
def read(path):
    return json.loads(path.read_text('utf-8-sig'))
def sha(data):
    return hashlib.sha256(data).hexdigest()
def tsv(path):
    return path.read_text('utf-8-sig').splitlines()

def verify_native():
    before=read(OUT/'before_notes.json')
    audit=read(BRIDGE/f'audit_{KEY}.json')
    worker=read(BRIDGE/'worker_identity.json')
    rows=tsv(BRIDGE/f'reply_{KEY}.tsv')
    header=rows[0].split('\t')
    revision=tsv(BRIDGE/f'reply_revision_{KEY}.tsv')[0].split('\t')
    render=tsv(BRIDGE/f'render_state_{KEY}.tsv')[0].split('\t')
    assert header[2]==before['token']==audit['token']==revision[2]==render[3]==render[4]
    assert header[7]==revision[3]==render[5]=='full' and audit['full_model']['available']
    assert header[8]==revision[4]==sha(('\n'.join(rows[1:])+'\n').encode())
    assert worker['script_sha256']==sha((ROOT/'worker.py').read_bytes())
    assert min(int(revision[5]),int(render[12]))>=int(worker['started'])
    assert len(before['rows'])==len(audit['results'])==int(header[3])==sum(r.startswith('R\t') for r in rows)
    assert int(render[11])==sum(r.startswith('C\t') for r in rows)
    changes=[]
    for row in audit['results']:
        old=before['rows'][row['id']]
        other={k:v for k,v in row.items() if k!='pa'}
        assert old['other']==sha(json.dumps(other,ensure_ascii=False,sort_keys=True).encode())
        if old['pa']!=row['pa']:
            assert row['pa'].startswith('三推几何轮廓') and '反向失效' not in row['pa']
            changes.append(dict(id=row['id'],old=old['pa'],new=row['pa']))
    assert changes
    (OUT/'native_receipt.json').write_text(json.dumps(dict(token=header[2],revision=revision[4],
        rows=int(header[3]),continuations=int(render[11]),render_at=render[12],changes=changes,
        worker_sha256=worker['script_sha256']),ensure_ascii=False,indent=2),'utf8')

def main():
    verify_native()
    records=read(OUT/'native_rail_replay.json')['records']
    assert len(records)==32 and sum(r['category']==4 for r in records)==23
    assert 'OK' in (OUT/'regression.txt').read_text('utf-8-sig').splitlines()
    prior=read(ROOT/'PACKAGE_R5P4.json')
    base=Path(prior['path'])
    assert sha(base.read_bytes())==prior['sha256']
    with zipfile.ZipFile(base) as z:
        files={n:z.read(n) for n in z.namelist() if n!='R5P4_PACKAGE_MANIFEST.json'}
    extra=['worker.py','test_experiment.py','package_book_outline_side.py','replay_book_outline_side.py',
           'review_september_channel.py','verification/native_initial/CompanionBookThreePushPA_102923304041429.tsv',
           'verification/september_channel_review/review.json','verification/september_channel_review/H1通道与右侧三推复核.png',
           'testdata/native_history_H1.tsv']
    extra.extend(p.relative_to(ROOT).as_posix() for p in OUT.iterdir() if p.is_file() and p.name!='OT_receipt.json')
    files.update({n:(ROOT/n).read_bytes() for n in extra})
    manifest={k:sha(v) for k,v in files.items()}
    archive=base.parent/'Book302_1.230-r5p5_三推轮廓越轨复核_20261118.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for k,v in files.items():
            z.writestr(k,v)
        z.writestr('R5P5_PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and all(sha(z.read(k))==h for k,h in manifest.items())
    data=archive.read_bytes()
    receipt=dict(path=str(archive),sha256=sha(data),bytes=len(data),files_verified=len(manifest),
                 git_blob_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
    (ROOT/'PACKAGE_R5P5.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
    print(receipt)

if __name__=='__main__':
    main()
