"""Verify the August native replay and back up the complete independent experiment."""
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from package_book_outline_side import ROOT, BRIDGE, KEY, read, sha, tsv

OUT = ROOT / 'verification/august_overlap_20261118'


def verify_native():
    old = read(OUT / 'before_notes.json')
    audit = read(BRIDGE / f'audit_{KEY}.json')
    identity = read(BRIDGE / 'worker_identity.json')
    rows = tsv(BRIDGE / f'reply_{KEY}.tsv')
    header = rows[0].split('\t')
    revision = tsv(BRIDGE / f'reply_revision_{KEY}.tsv')[0].split('\t')
    render = tsv(BRIDGE / f'render_state_{KEY}.tsv')[0].split('\t')
    assert header[2] == old['token'] == audit['token'] == revision[2] == render[3] == render[4]
    assert header[7] == revision[3] == render[5] == 'full' and audit['full_model']['available']
    assert header[8] == revision[4] == sha(('\n'.join(rows[1:])+'\n').encode())
    assert identity['script_sha256'] == sha((ROOT/'worker.py').read_bytes())
    assert min(int(revision[5]), int(render[12])) >= int(identity['started'])
    assert len(old['rows']) == len(audit['results']) == int(header[3]) == sum(r.startswith('R\t') for r in rows) == 136
    assert int(render[11]) == sum(r.startswith('C\t') for r in rows) == 79
    assert {r['id'] for r in audit['results']} == old['rows'].keys()
    changes = []
    for row in audit['results']:
        before = old['rows'][row['id']]
        other = {k:v for k,v in row.items() if k not in ('detail','label')}
        assert sha(json.dumps(other, ensure_ascii=False, sort_keys=True).encode()) == before['other']
        if (row['detail'], row['label']) != (before['detail'], before['label']):
            assert row['code'] == 8 and '前后两次收盘的区间关系' in row['detail']
            changes.append(dict(id=row['id'], clock=datetime.fromtimestamp(row['clock'],timezone.utc).isoformat(),
                                old_label=before['label'], old_detail=before['detail'], label=row['label'], detail=row['detail']))
    assert {r['id'] for r in changes} == {'b2fa7d5139bcd36117697dbb','b23df36497f2670f9aab3fe0'}
    receipt = dict(token=header[2], revision=revision[4], rows=136, continuations=79,
                   render_at=render[12], changes=changes, worker_sha256=identity['script_sha256'],
                   auxiliary_sha256=sha((ROOT/'book_auxiliary.py').read_bytes()),
                   ex5_sha256=sha((ROOT/'source/Book302_Consolidation_Experiment.ex5').read_bytes()))
    (OUT/'native_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2),'utf8')


def main():
    verify_native()
    replay = read(OUT/'august_replay.json')
    triangles = read(OUT/'triangle_exit_audit.json')
    assert len(replay['checks']) == 17 and replay['native_records'] == 22 and replay['causal'] == 0
    assert triangles['bars'] == 6000 and triangles['candidates'] == len(triangles['records']) == 1591
    assert triangles['target']['geometric']['time'] == '2026-09-01T08:00:00+00:00' and triangles['target']['buffered'] is None
    assert 'OK' in (OUT/'regression.txt').read_text('utf-8-sig').splitlines()
    assert '0 errors, 0 warnings' in (OUT/'compile.log').read_text('utf-16')
    prior = read(ROOT/'PACKAGE_R5P5.json')
    base = Path(prior['path'])
    assert sha(base.read_bytes()) == prior['sha256']
    with zipfile.ZipFile(base) as z:
        files = {n:z.read(n) for n in z.namelist() if n != 'R5P5_PACKAGE_MANIFEST.json'}
    changed = ['book_auxiliary.py','worker.py','test_book_auxiliary.py','draw_august_overlap.py',
               'replay_august_overlap.py','audit_triangle_exits.py','package_august_overlap.py',
               'source/BookExperimentGuard.mqh','source/Book302_Consolidation_Experiment.ex5',
               'testdata/book_scan.tsv','testdata/native_history_H1.tsv']
    changed += [p.relative_to(ROOT).as_posix() for p in OUT.iterdir() if p.is_file() and p.name!='OT_receipt.json']
    files.update({name:(ROOT/name).read_bytes() for name in changed})
    manifest = {k:sha(v) for k,v in files.items()}
    archive = base.parent/'Book302_1.230-r5p6_通道箱体重叠与三角复核_20261118.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for name,data in files.items():
            z.writestr(name,data)
        z.writestr('R5P6_PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and all(sha(z.read(k))==h for k,h in manifest.items())
    data = archive.read_bytes()
    receipt = dict(path=str(archive),sha256=sha(data),bytes=len(data),files_verified=len(manifest),
                   git_blob_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
    (ROOT/'PACKAGE_R5P6.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
    print(receipt)


if __name__=='__main__':
    main()
