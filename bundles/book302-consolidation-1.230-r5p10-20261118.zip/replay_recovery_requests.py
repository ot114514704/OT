"""Exercise the actual worker and reply encoder on rolling MT5 requests around a fast reentry."""
from datetime import datetime
import json
from worker import parse_request, solve, encode_reply
from test_book_pair_recovery import history, OUT

bars=history()
i=next(i for i,b in enumerate(bars) if b.closed_at==datetime.fromisoformat('2026-10-02T19:00:00+00:00'))
samples=[]
for age in range(5):
    data=bars[i-511:i+age+1]
    clock=int(data[-1].closed_at.timestamp())
    token='book-recovery-prefix-'+str(age)
    rows=[f'BEXP\t1\t{token}\t3600\t{clock}\t{len(data)}\treplay\tXAUUSD\t0.01']
    for b in data:
        rows.append('\t'.join(map(str,('B',int(b.time.timestamp()),b.open,b.high,b.low,b.close,round(b.spread/.01)))))
    req=parse_request('\n'.join([*rows,'END\t'+token]))
    result=solve(req)
    current=result[-1]
    assert current['id']=='__CURRENT'
    event='2026-10-02T19:00:00Z'
    facts=[p for p in current.get('book_pair_recovery',[]) if p['event']==event]
    assert len(facts)==(3 if age<=3 else 0)
    for p in facts:
        assert len(p['observations'])==age+1
        if age:
            assert p['first_reentry']=='2026-10-02T20:00:00Z'
        else:
            assert p['first_reentry'] is None
    reply=encode_reply(req,result,0)
    assert current['follow'] in reply
    samples.append(dict(clock=data[-1].closed_at.isoformat(),matched=len(facts),follow=current['follow']))
(OUT/'rolling_requests.json').write_text(json.dumps(samples,ensure_ascii=False,indent=2),'utf8')
print([(s['clock'],s['matched']) for s in samples])

