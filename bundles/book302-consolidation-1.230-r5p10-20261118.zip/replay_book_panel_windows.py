"""Run paired, close-by-close Book structural replays with different H1 lookbacks."""
import csv
import json
from collections import Counter
from datetime import datetime, timezone
from book_viewport_structure import inspect_close
from verify_book_panel_r5p7 import ROOT, OUT, NativeBar


def signature(report):
    return {(tuple(p['origin']),tuple(p['terminal']),p['direction'],p['event'],
             p['trend_break_bar'],p['turning_break_bar'])
            for p in report.get('pairs',[]) if p['event'] not in ('no_new_cross','unknown')}


def main():
    with (ROOT/'testdata/native_history_H1.tsv').open(encoding='utf-8-sig') as f:
        bars=[NativeBar(datetime.fromtimestamp(int(r['time']),timezone.utc),
                        *(float(r[k]) for k in ('open','high','low','close')),float(r['spread'])*0.01,3600)
              for r in csv.DictReader(f,delimiter='\t')]
    start=next(i for i,b in enumerate(bars) if b.time.date().isoformat()=='2026-09-23')
    counts=Counter()
    differences=[]
    events=[]
    gaps=0
    length=144
    for i in range(start,start+length):
        a,b=(inspect_close(bars[i-size+1:i+1]) for size in (512,256))
        if a['status']=='gap':
            assert b['status']=='gap'
            gaps+=1
            continue
        assert a['status']==b['status']=='ok'
        counts.update(a['counts'])
        clock=bars[i].closed_at.isoformat()
        sa,sb=signature(a),signature(b)
        if sa:
            events.append(dict(clock=clock,counts=a['counts']))
        if sa!=sb:
            differences.append(dict(clock=clock,only_512=sorted(sa-sb,key=str),only_256=sorted(sb-sa,key=str)))
    summary=dict(start=bars[start].closed_at.isoformat(),end=bars[start+length-1].closed_at.isoformat(),bars=length,
                 gap_skipped=gaps,closes_with_new_events=len(events),pair_observations=counts,
                 differing_closes=len(differences),events=events,differences=differences)
    (OUT/'continuous_replay.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),'utf8')
    print({k:v for k,v in summary.items() if k not in ('differences','events')})


if __name__=='__main__':
    main()

