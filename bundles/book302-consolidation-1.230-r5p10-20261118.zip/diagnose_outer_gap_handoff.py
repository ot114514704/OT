"""Check whether a stopped inner gap observation still has an eligible outer.

Read-only saved native input. A found candidate is not a deployed rule change.
"""
from pathlib import Path
import json,sys
import worker
from continuation import observe
from research_cases import load_bars
sys.stdout.reconfigure(encoding='utf8')
B=Path(__file__).parent;V=B/'verification/multidate_continuation_20261118'
raw=load_bars(B/'testdata/native_history_H1.tsv')
bars=[worker.NativeBar(b.time,b.open,b.high,b.low,b.close,b.spread,b.seconds) for b in raw]
cases=json.loads((B/'all_example_candidates.json').read_text('utf8'));reports=[]
for choice in (0,1):
 c=cases[choice];end=next(i+1 for i,b in enumerate(bars) if int(b.closed_at.timestamp())==c['clock']);start=max(0,int(c['original']['window'])-1100)
 prefix=tuple(bars[start:end]);window=bars[start:min(len(bars),end+240)]
 contexts,_=worker.recognize(prefix)
 event=dict(id=c['original']['id'],family=c['original']['family'],clock=c['clock'],known=int(c['original']['known']),state=c['original']['state'],line=c['line'],slope=c['slope'])
 r=worker.classify(event,prefix,contexts);found=[];at=None;inner=None
 for n in range(len(prefix),len(window)+1):
  inner=observe(event,r,contexts,window[:n],int(window[n-1].closed_at.timestamp()))
  if inner and inner['state']=='gap_exit':at=n-1;break
 if at is not None:
  for context in contexts:
   low=min(context['low'],context['fixed_low']);high=max(context['high'],context['fixed_high'])
   if context['id'] not in inner['outer_range_ids'] or low>inner['low'] or high<inner['high'] or (low,high)==(inner['low'],inner['high']):continue
   outer=observe(event,{'code':r['code'],'context':context},contexts,window[:at+1],int(window[at].closed_at.timestamp()))
   inside=all(low<=v<=high for b in window[at-1:at+1] for v in (b.open,b.close))
   found.append({'range_id':context['id'],'low':low,'high':high,'two_bodies_inside':inside,'outer_state_at_inner_exit':outer['state'] if outer else None,
                 'outer':outer,'candidate':inside and outer is not None and outer['state']=='resumed'})
 report={'case':choice,'event':event,'gap_exit_known':int(window[at].closed_at.timestamp()) if at is not None else None,'inner':inner,'outer_checks':found}
 reports.append(report);print(json.dumps({'case':choice,'outer_checked':len(found),'candidates':sum(x['candidate'] for x in found)}),flush=True)
(V/'gap_handoff_diagnosis.json').write_text(json.dumps({'cases':reports,'deployed':False,'scope':'Two saved native November examples; candidate gap handoff only, not confirmed reversal.'},ensure_ascii=False,indent=2),'utf8')
