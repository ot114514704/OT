"""Verify and back up the complete Book experiment after the summer replay."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from package_book_outline_side import ROOT, read, sha
from replay_summer_book import OUT


def main():
    assert read(OUT/'summer_prefixes.json')['summary']['closed_bars']==229
    assert read(OUT/'native.json')['rows']==136
    assert [r['sequential'] for r in read(OUT/'requests.json')]==[0,3,3,3,3]
    assert 'OK' in (OUT/'regression.txt').read_text('utf-8-sig').splitlines()
    additions=['worker.py','book_pair_recovery.py','replay_summer_book.py','review_summer_context.py',
               'test_consecutive_book_break.py','verify_summer_release.py','package_summer_book.py']
    additions.extend(p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='OT_receipt.json')
    results={}
    for kind,prior in read(ROOT/'PACKAGE_R5P8.json').items():
        base=Path(prior['path'])
        assert sha(base.read_bytes())==prior['sha256']
        with ZipFile(base) as z:
            files={k:z.read(k) for k in z.namelist() if k!='R5P8_PACKAGE_MANIFEST.json'}
        files.update({k:(ROOT/k).read_bytes() for k in additions})
        files['README_R5P9.txt']=(OUT/'复核与恢复.txt').read_bytes()
        manifest={k:sha(v) for k,v in files.items()}
        path=base.parent/f'Book302_1.230-r5p9_H1连续收破_{kind}_20261118.zip'
        with ZipFile(path,'x',ZIP_DEFLATED) as z:
            for k,v in files.items():
                z.writestr(k,v)
            z.writestr('R5P9_PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
        with ZipFile(path) as z:
            assert z.testzip() is None and all(sha(z.read(k))==v for k,v in manifest.items())
        data=path.read_bytes()
        results[kind]=dict(path=str(path),bytes=len(data),files_verified=len(files),sha256=sha(data),
                           git_blob_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
    (ROOT/'PACKAGE_R5P9.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),'utf8')


if __name__=='__main__':
    main()

