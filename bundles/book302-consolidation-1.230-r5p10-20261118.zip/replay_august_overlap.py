"""Replay the three August annotations with native H1 prefixes and frozen Book events."""
import csv
import json
from datetime import datetime,timezone
from pathlib import Path
from research_cases import load_bars
from worker import NativeBar, recognize
from book_auxiliary import select

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'verification/august_overlap_20261118'
HISTORY=ROOT/'testdata/native_history_H1.tsv'
SCAN=ROOT/'testdata/book_scan.tsv'
SHAPES={'channel':'price_structure_candidate_v5:48:auto:2026-08-26T23:00:00+00:00',
       'box':'dense_horizontal_pause_v1:body16:2026-08-28T06:00:00+00:00',
       'triangle':'native_session_triangle_candidate_v1:edge:28:2026-09-01T02:00:00+00:00'}

def iso(t):return datetime.fromtimestamp(t,timezone.utc).isoformat()
def stamp(t):return int(datetime.fromisoformat(t).timestamp())
def main():
    bars=tuple(NativeBar(b.time,b.open,b.high,b.low,b.close,b.spread*.01,3600) for b in load_bars(HISTORY))
    pos={int(b.closed_at.timestamp()):i for i,b in enumerate(bars)}
    opens={int(b.time.timestamp()):i for i,b in enumerate(bars)}
    native={}
    with SCAN.open(encoding='utf-8-sig') as handle:
        for r in csv.DictReader(handle,delimiter='\t'):
            clock,known=int(r['cross']),int(r['known'])
            if not stamp('2026-08-24T21:00:00+00:00')<=clock<=stamp('2026-09-01T14:00:00+00:00'):
                continue
            a,b=opens[int(r['anchor_a'])],opens[int(r['anchor_b'])]
            slope=(float(r['price_b'])-float(r['price_a']))/(b-a)
            event=dict(id=r['id'],known=known,clock=clock,state=r['state'],family=r['family'],owner_a=int(r['owner_a']),owner_b=int(r['owner_b']),slope=slope,line=float(r['pb']))
            if event['id'] in native:assert native[event['id']]==event
            native[event['id']]=event
    causal=[e for e in native.values() if 'retrospective' not in e['state'] and 0<e['known']<=e['clock']-3600]
    dates=['08-26T23','08-28T06','08-28T18','08-28T19','08-28T20','09-01T02','09-01T10','09-01T11','09-01T12','09-01T13']
    clocks={stamp('2026-'+t+':00:00+00:00') for t in dates}|{e['clock'] for e in causal}
    clocks.update(stamp(f'2026-09-01T{hour:02}:00:00+00:00') for hour in range(2,12))
    checks=[]
    for count in (256,512):
        cache={}
        def at(clock,start):
            key=clock,start
            if key not in cache:cache[key]=recognize(bars[start:pos[clock]+1])[0]
            return cache[key]
        for clock in sorted(clocks):
            i=pos[clock];start=i-count;prev=bars[i-1]
            before=at(int(prev.closed_at.timestamp()),start);current=at(clock,start)
            shapes={}
            for role,rid in SHAPES.items():
                def one(snap):
                    r=next((x for x in snap if x['id']==rid),None)
                    return None if not r else {k:r[k] for k in ('id','start','known','end','low','high','status','active')}
                shapes[role]=dict(previous=one(before),current=one(current))
            events=[]
            for e in causal:
                if e['clock']!=clock:continue
                sel=select(e,prev,bars[i],before,current)
                allowed=[r for r in [sel['primary'],*sel['alternatives']] if r]
                events.append(dict(id=e['id'],family=e['family'],line=e['line'],known=e['known'],
                    associated=[role for role,rid in SHAPES.items() if any(hit['range']['id']==rid for hit in allowed)],
                    primary=sel['primary']['range']['id'] if sel['primary'] else None))
            result=dict(clock=iso(clock),close=bars[i].close,shapes=shapes,events=events)
            if count==256:checks.append(result)
            else:assert result==next(r for r in checks if r['clock']==iso(clock)),(clock,result)
    OUT.mkdir(exist_ok=True)
    (OUT/'august_replay.json').write_text(json.dumps(dict(native_records=len(native),native_events=sorted(native.values(),key=lambda e:(e['clock'],e['id'])),causal=len(causal),checks=checks),ensure_ascii=False,indent=2),'utf8')
    for r in checks:
        print(r['clock'][5:16],r['close'],[(k,v['current']['status']) for k,v in r['shapes'].items() if v['current']],[(e['family'],e['associated']) for e in r['events']])
if __name__=='__main__':main()
