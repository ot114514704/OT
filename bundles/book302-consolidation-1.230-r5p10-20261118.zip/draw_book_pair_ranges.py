"""Plot the actual event candle, both Book levels and the two frozen range snapshots."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parent
FOLDER=ROOT/'verification/book_pair_range_20261118'
ranges=json.loads((FOLDER/'same_bar_ranges.json').read_text('utf8'))['samples']
book=json.loads((ROOT/'verification/book_pair_replay_20261118/paired_replay.json').read_text('utf8'))
records={r['id']:r for w in book['windows'] for r in w['records']}
events={}
for sample in ranges:
    events.setdefault(sample['when'],sample)
names={'box':'箱体','triangle':'三角','channel':'通道','wedge':'楔形'}
plt.rcParams.update({'font.sans-serif':['Microsoft YaHei'],'axes.unicode_minus':False})
fig,axes=plt.subplots(2,2,figsize=(11,7.2),layout='constrained')
for ax,case in zip(axes.flat,events.values()):
    rec=records[case['owner']]
    before,now=[b for b in rec['chart'] if b['close_time']<=case['when']][-2:]
    assert now['close_time']==case['when']
    primary=case['common'][0]
    other=([r for r in case['common'][1:] if r['detector']=='dense'] or
           [r for r in case['common'][1:] if r['shape']=='box'])
    other=(max(other,key=lambda r:r['previous'][1]-r['previous'][0]) if primary['shape']=='box' and other
           else next(iter(other),None))
    for r,color in [(other,'#99681c'),(primary,'#427766')]:
        if not r: continue
        lo,hi=zip(r['previous'],r['current'])
        label=('密集箱体' if r['detector']=='dense' else names[r['shape']])+'候选'
        ax.fill_between([0,1],lo,hi,color=color,alpha=.13)
        ax.plot([0,1],lo,color=color,lw=1.1)
        ax.plot([0,1],hi,color=color,lw=1.1,label=label)
    for j,b in enumerate((before,now)):
        color='#15674d' if b['close']>=b['open'] else '#aa3d37'
        ax.vlines(j,b['low'],b['high'],color=color,zorder=3)
        ax.add_patch(Rectangle((j-.037,min(b['open'],b['close'])),.074,abs(b['close']-b['open']),facecolor=color,zorder=3))
    for key,style,color in [('outer','-','#293c86'),('turning','--','#822d70')]:
        ax.plot([0,1],[before[key],now[key]],style,color=color,lw=1.8)
    ax.set_xticks([0,1],['前一根 '+before['close_time'][11:16],'双破当根 '+now['close_time'][11:16]])
    ax.set_title(case['when'][:10]+'　'+('向下收破' if rec['direction']=='up' else '向上收破'))
    ax.set_xlim(-.23,1.23)
    ax.legend(loc='upper center',fontsize=8,ncol=2,framealpha=.7)
    ax.grid(axis='y',alpha=.15)
fig.legend([Line2D([],[],color='#293c86'),Line2D([],[],color='#822d70',linestyle='--')],
           ['Book 趋势线','Book 拐点线'],loc='outside lower center',ncol=2,frameon=False)
fig.suptitle('XAUUSD H1　同一根 K 线收破两条 Book 原线时的盘整位置',fontsize=15)
fig.savefig(FOLDER/'四处双破与盘整.png',dpi=145)
plt.close(fig)
