from pathlib import Path
import hashlib
import json
import zipfile

root=Path(__file__).resolve().parent
v=root/'verification/book_pair_range_20261118'
b=root/'runtime/bridge'
key='102923304041429_3600'

def read(p):
    return json.loads(p.read_text('utf-8-sig'))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def tsv(path):
    return path.read_text('utf-8-sig').splitlines()

old=read(v/'before_notes.json')
audit=read(b/f'audit_{key}.json')
rows=tsv(b/f'reply_{key}.tsv')
hdr=rows[0].split('\t')
rev=tsv(b/f'reply_revision_{key}.tsv')[0].split('\t')
render=tsv(b/f'render_state_{key}.tsv')[0].split('\t')
worker=read(b/'worker_identity.json')
assert old['token']==audit['token']==hdr[2]==rev[2]==render[3]==render[4]
assert hdr[7]==rev[3]==render[5]=='full' and audit['full_model']['available']
assert sha(('\n'.join(rows[1:])+'\n').encode())==hdr[8]==rev[4]
assert int(rev[5])>=int(worker['started']) and int(render[12])>=int(worker['started'])
assert int(hdr[3])==len(audit['results'])==len(old['rows'])
assert int(render[11])==sum(row.startswith('C\t') for row in rows)
changed=0
for result in audit['results']:
    previous=old['rows'][result['id']]
    other={k:value for k,value in result.items() if k!='detail'}
    assert sha(json.dumps(other,sort_keys=True,ensure_ascii=False).encode())==previous['other']
    if previous['detail']!=result['detail']:
        assert ('重叠箱体 ' in result['detail'] or '外层箱体 ' in result['detail'])
        assert previous['detail'].partition('。')[2]==result['detail'].partition('。')[2]
        changed+=1
assert changed and 'OK' in (v/'regression.txt').read_text('utf-8-sig').splitlines()
samples=read(v/'same_bar_ranges.json')['samples']
assert len(samples)==12 and len({s['owner'] for s in samples})==6
for s in samples[:6]:
    twin=next(t for t in samples if t['owner']==s['owner'] and t['warmup_bars']!=s['warmup_bars'])
    assert s['common']==twin['common'] and s['prices']==twin['prices']
(v/'native_receipt.json').write_text(json.dumps(dict(token=hdr[2],revision=rev[4],rows=int(hdr[3]),continuation=int(render[11]),updated_details=changed,
    render_time=render[12],worker_started=worker['started'],auxiliary_sha256=sha((root/'book_auxiliary.py').read_bytes())),indent=2),'utf8')
base_receipt=read(root/'PACKAGE_R5P3.json')
base=Path(base_receipt['path'])
assert sha(base.read_bytes())==base_receipt['sha256']
out=base.parent/'Book302_1.230-r5p4_双线盘整与重叠箱体复盘_20261118.zip'
extra=['book_auxiliary.py','test_book_auxiliary.py','replay_book_pair_evidence.py','draw_book_pair_replay.py','replay_book_pair_ranges.py','draw_book_pair_ranges.py','package_book_pair_ranges.py']
for folder in [v,root/'verification/book_pair_replay_20261118']:
    extra.extend(p.relative_to(root).as_posix() for p in folder.iterdir() if p.is_file() and p.name!='OT_receipt.json')
with zipfile.ZipFile(base) as z:
    files={name:z.read(name) for name in z.namelist() if name!='R5P3_PACKAGE_MANIFEST.json'}
files.update({name:(root/name).read_bytes() for name in extra})
manifest={k:sha(v) for k,v in files.items()}
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
    for name,content in files.items():
        z.writestr(name,content)
    z.writestr('R5P4_PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None and all(sha(z.read(k))==v for k,v in manifest.items())
data=out.read_bytes()
receipt=dict(path=str(out),sha256=sha(data),bytes=len(data),files_verified=len(manifest),
             git_blob_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
(root/'PACKAGE_R5P4.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
print(receipt,changed)
