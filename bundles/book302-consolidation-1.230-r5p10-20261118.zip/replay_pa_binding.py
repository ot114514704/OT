from pathlib import Path
import json
from datetime import datetime, timezone
import worker_pa_candidate as engine
from research_adapter import summary

root = Path(__file__).parent / 'verification'
output = root / 'book_auxiliary_20261118/pa_binding'
nov = root / 'outer_gap_20261118'
suffix = '102923304041429_3600'
read = lambda path: json.loads(path.read_text('utf-8-sig'))
captured = next(p for p in output.iterdir() if p.is_dir() and (p/'request').exists())
cases = [(nov/'november_before'/f'request_{suffix}.tsv',nov/'november_expected_results.json',
          nov/'november_before'/f'full_model_{suffix}.json'),
         (captured/'request',captured/'audit',captured/'full_model')]
report = []
for request, baseline, model in cases:
    req = engine.parse_request(request.read_text('utf-8-sig'))
    full = read(model)
    assert req['token'] == full['token']
    expected = read(baseline)
    if isinstance(expected, dict):
        assert req['token'] == expected['token']
        expected = expected['results']
    actual = engine.solve(req)
    assert len(actual) == len(expected)
    changes = []
    for a, b in zip(actual, expected):
        a['detail'] += '；' + (summary(full['report'], 'H1') if a['id']=='__CURRENT'
                           else '原研究全模型只作当前快照旁证，不回填此历史事件')
        assert {k:v for k,v in a.items() if k!='pa'} == {k:v for k,v in b.items() if k!='pa'}, a['id']
        if a['pa'] != b['pa']:
            changes.append(dict(id=a['id'], clock=a['clock'], before=b['pa'], after=a['pa']))
    report.append(dict(token=req['token'],records=len(actual),only_pa_changed=True,changes=changes))
    print(req['token'][:12],len(actual),len(changes),flush=True)
assert all(any(x['id']==i and '未取得' in x['after'] for x in report[0]['changes'])
           for i in ('b77e4b07a8224be14b800831','b246e33e2a6c537582d51a71'))
(output/'replay.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
