import json
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import worker_close_candidate as engine
from research_adapter import summary
root=Path(__file__).parent
v=root/'verification/book_auxiliary_20261118/pa_binding'
nov=root/'verification/outer_gap_20261118'
s='102923304041429_3600'
fixtures=next(p for p in v.iterdir() if (p/'request').exists())
read=lambda p:json.loads(p.read_text('utf-8-sig'))
baseline_notes={r['token']:{x['id']:x['after'] for x in r['changes']} for r in read(v/'replay.json')}
reports=[]
for request,audit,model in [(nov/'november_before'/f'request_{s}.tsv',nov/'november_expected_results.json',nov/'november_before'/f'full_model_{s}.json'),(fixtures/'request',fixtures/'audit',fixtures/'full_model')]:
    req=engine.parse_request(request.read_text('utf-8-sig'))
    expected=read(audit); expected=expected['results'] if isinstance(expected,dict) else expected
    full=read(model); assert full['token']==req['token']
    results=engine.solve(req)
    assert len(expected)==len(results)
    counts=Counter(); examples=[]
    for old,new in zip(expected,results):
        old['pa']=baseline_notes[req['token']].get(old['id'],old['pa'])
        new['detail']+='；'+(summary(full['report'],'H1') if new['id']=='__CURRENT' else '原研究全模型只作当前快照旁证，不回填此历史事件')
        if new['follow']!=old['follow']:
            prefix,sep,rest=new['follow'].partition('。')
            assert sep and rest==old['follow'] and prefix.startswith('Book单线：')
            counts[prefix]+=1
            if not any(e['note']==prefix for e in examples):
                examples.append(dict(id=new['id'],date=datetime.fromtimestamp(new['clock'],timezone.utc).isoformat(),note=prefix))
        assert {k:v for k,v in old.items() if k!='follow'}=={k:v for k,v in new.items() if k!='follow'},new['id']
    reports.append(dict(token=req['token'],rows=len(results),changed=sum(counts.values()),counts=dict(counts),examples=examples))
    print(len(results),sum(counts.values()),flush=True)
(root/'verification/book_close_follow_20261118/worker_replay.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),'utf8')
