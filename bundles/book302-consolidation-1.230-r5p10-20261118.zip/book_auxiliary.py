"""Book-primary, causal auxiliary associations; never adjudicates Book trend.

Consumes original frozen Book events and two already-truncated range snapshots.
It selects references, never refits/removes shapes or turns geometry into A.
"""
from copy import deepcopy
from math import isfinite, ulp

VERSION = 'book-primary-auxiliary-v3'
PA_NAMES = {1: '三推反转楔形候选', 2: '三推旗形中继候选',
            3: '三推楔形旗中继候选', 4: '三推几何轮廓，背景待核'}

def shape_kind(context):
    subtype = context.get('rail_subtype')
    if subtype in ('triangle','ascending_triangle','descending_triangle'): return 'triangle'
    if subtype in ('rising_wedge','falling_wedge'): return 'wedge'
    if subtype == 'channel': return 'channel'
    shape = context.get('shape')
    if shape == 'converging':
        start_width = context['high0'] - context['low0']
        current_width = context['high'] - context['low']
        tolerance = 8 * max(ulp(context[k]) for k in ('high', 'low', 'high0', 'low0'))
        if current_width < start_width - tolerance:
            return 'triangle'
        if abs(current_width - start_width) <= tolerance:
            return 'channel' if abs(context['high'] - context['high0']) > tolerance else 'box'
        return 'expanding'
    if shape in ('tilted', 'channel', 'parallel'): return 'channel'
    return 'box'

def _inside(value, low, high):
    tolerance = 4 * max(ulp(value), ulp(low), ulp(high))
    return low - tolerance <= value <= high + tolerance

def range_relation_note(selected, exits, previous, opening, clock):
    """Compare the chosen surviving range with each departed range on two closes."""
    prior={r['id']:r for r in previous if r.get('active') and r['end']==opening}
    def matched(r):
        p=prior.get(r['id'])
        frozen=('kind','known','start','fixed_low','fixed_high','low0','high0','rail_subtype')
        if (p and r['end']==clock and 0<r['known']<=opening and
            all(p.get(k)==r.get(k) for k in frozen) and p['low']<p['high'] and r['low']<r['high']):
            return p
        return None
    def relation(a,b):
        lo,hi=a['low'],a['high']
        l,h=b['low'],b['high']
        eps=4*max(map(ulp,(lo,hi,l,h)))
        if abs(lo-l)<=eps and abs(hi-h)<=eps:return '边界重合'
        if lo<=l+eps and hi>=h-eps:return '所选区间包住离开区间'
        if l<=lo+eps and h>=hi-eps:return '离开区间包住所选区间'
        if min(hi,h)<max(lo,l)-eps:return '边界分离'
        if min(hi,h)<=max(lo,l)+eps:return '边界相接'
        return '部分重叠'
    counts={}
    first=matched(selected)
    for other in exits:
        earlier=matched(other)
        if first and earlier:
            a,b=relation(first,earlier),relation(selected,other)
            result=a if a==b else f'{a}转为{b}'
        else:
            result='两次收盘的边界证据不足'
        counts[result]=counts.get(result,0)+1
    return '前后两次收盘的区间关系：'+'、'.join(k+(f'（{v}组）' if v>1 else '') for k,v in sorted(counts.items()))

def select(book_event, previous_bar, event_bar, before, at_event, patterns=()):
    """Rank only by pre-event facts. Post-event outcomes never enter the rank.

    Prefer a converging alternative over a channel for the SAME local crossing;
    keep a separately selected box as a secondary reference. These preferences
    choose auxiliary references only, not the original chart representatives.
    """
    e = deepcopy(book_event)
    result = {'version': VERSION, 'book': e, 'primary': None, 'box': None,
              'alternatives': [], 'rejected': [], 'pa': [],
              'book_state': 'geometric_event_only',
              'missing': ['同源趋势线与独立拐点线的合格双破证据', 'Book 完整调整分界点 A'],
              'trend_override': False, 'confirmed_reversal': False,
              'automatic_trade_permission': False, 'changes_original_geometry': False}
    opening = int(event_bar.time.timestamp())
    if (e.get('clock') != int(event_bar.closed_at.timestamp()) or
        not 0 < e.get('known', 0) <= opening or 'retrospective' in e.get('state', '') or
        previous_bar.closed_at != event_bar.time):
        result['missing'].append('穿线前可知的有效 Book 原线及连续已收盘输入')
        return result
    if any(not isfinite(float(e.get(k, float('nan')))) for k in ('line', 'slope')):
        result['missing'].append('有效原线方程'); return result
    previous = {c['id']: c for c in before}
    candidates = []
    for c in at_event:
        p = previous.get(c['id'])
        why = ''
        if not p or not p.get('active', False): why = '穿线前未见有效范围'
        elif not 0 < c.get('known', 0) <= opening: why = '范围在穿线前尚不可知'
        elif any(c.get(k) != p.get(k) for k in ('known', 'start', 'low0', 'high0', 'fixed_low', 'fixed_high', 'rail_subtype')):
            why = '范围身份或冻结边界变化'
        elif c.get('end', 0) != e['clock'] or p.get('end', 0) != opening: why = '两次边界未对齐各自收盘'
        elif any(word in c.get('status', '') for word in ('数据间隔', '交会')): why = '范围数据或交会终止'
        elif e.get('owner_a', 0) and c['end'] < e['owner_a']: why = '不属本次 Book 观察时段'
        elif not all(isfinite(float(x[k])) for x in (c,p) for k in ('low','high')): why = '无效边界'
        elif not p['low'] < p['high'] or not c['low'] < c['high']: why = '上下轨无有效间距'
        elif not _inside(previous_bar.close, p['low'], p['high']): why = '前一收盘不在盘整内'
        elif not _inside(e['line']-e['slope'], p['low'], p['high']): why = 'Book 原线不在该盘整内'
        elif not _inside(e['line'], c['low'], c['high']): why = '穿线当根原线已在盘整外'
        if why:
            result['rejected'].append({'id': c['id'], 'reason': why}); continue
        body_inside = _inside(previous_bar.open, p['low'], p['high'])
        kind = shape_kind(p)
        candidates.append({'range': deepcopy(c), 'before': deepcopy(p), 'kind': kind,
                           'pre_body_inside': body_inside,
                           'pre_width': p['high']-p['low'],
                           'event_close_inside': _inside(event_bar.close, c['low'], c['high']),
                           'book_event_id': e['id'], 'association_known': e['clock']})
    # Group geometry preferences first, then choose narrowest with ULP-only
    # tie handling. Never impose a price-scale dependent decimal tolerance.
    ordered = []
    while candidates:
        priority = lambda c: (not c['pre_body_inside'],
                             {'triangle': 0, 'channel': 1, 'wedge': 2, 'box': 3, 'expanding': 4}[c['kind']])
        group_key = min(map(priority, candidates))
        group = [x for x in candidates if priority(x) == group_key]
        narrow = min(group, key=lambda x: x['pre_width'])
        p = narrow['before']
        tied = [x for x in group if x['pre_width'] - narrow['pre_width'] <=
                4*max(ulp(p['low']), ulp(p['high']),
                      ulp(x['before']['low']), ulp(x['before']['high']))]
        chosen = min(tied, key=lambda x: (-x['range']['known'], x['range']['id']))
        ordered.append(chosen); candidates.remove(chosen)
    candidates = ordered
    if candidates:
        result['primary'] = candidates[0]
        result['alternatives'] = candidates[1:]
        if candidates[0]['kind'] != 'box':
            result['box'] = next((x for x in candidates if x['kind'] == 'box'), None)
    seen_patterns = set()
    for p in patterns:
        if (p.get('event_id') != e['id'] or p.get('category') not in PA_NAMES or
            not 0 < p.get('known', 0) <= opening or p.get('end', 0) > opening or
            not p.get('start', 0) < p.get('end', 0)):
            continue
        # The legacy exporter tags EVERY available push with event_id. That
        # tag alone proves neither temporal relevance nor same-wave ownership.
        if not 0 < e.get('owner_a', 0) <= e.get('owner_b', 0) <= opening:
            continue
        if p['end'] < e['owner_a'] or p['start'] > e['owner_b']: continue
        ref = result['primary']
        if ref and (p['end'] < ref['range']['start'] or p['start'] > e['clock']): continue
        identity = tuple(p.get(k) for k in ('category','trend','direction','known','event','state','start','end'))
        if identity in seen_patterns: continue
        seen_patterns.add(identity)
        q = deepcopy(p)
        # A latest-snapshot state cannot be backfilled into an earlier event.
        event_known = 0 < p.get('event', 0) <= e['clock']
        q['observed_state'] = p['state'] if event_known else 0
        q['later_state_withheld'] = bool(p.get('event', 0) > e['clock'])
        q['label'] = PA_NAMES[p['category']]
        q['book_A_equivalence'] = False
        q['binding_basis'] = 'time_overlap_only_no_original_owner_id_exported'
        q['book_scope_membership_verified'] = False
        q['confirmed_reversal'] = False
        result['pa'].append(q)
    return result


def range_evidence_note(selection):
    hit = selection['primary']
    if not hit:
        return 'Book原线与盘整：缺少连续两收盘的同区证据'
    names = {'channel':'通道', 'triangle':'三角', 'wedge':'楔形', 'box':'箱体', 'expanding':'扩张区间'}
    shape = names[hit['kind']]
    low, high = hit['range']['low'], hit['range']['high']
    location = '收盘在区内' if hit['event_close_inside'] else '收盘在区外'
    box = selection['box']
    box_label = '重叠箱体'
    if hit['kind'] == 'box':
        # Show the enclosing scale, chosen by pre-break width independent of
        # which side the event closes on. Check enclosure at both closes.
        enclosing = [x for x in selection['alternatives'] if x['kind']=='box'
                     and x['pre_width'] > hit['pre_width']
                     and all(x[t]['low'] <= hit[t]['low'] and hit[t]['high'] <= x[t]['high']
                             for t in ('before','range'))]
        box = max(enclosing,key=lambda x:x['pre_width'],default=None)
        box_label = '外层箱体'
    overlap = ''
    if box:
        zone = box['range']
        where = '内' if box['event_close_inside'] else '外'
        overlap = f"；{box_label} {zone['low']:.2f}～{zone['high']:.2f}，收盘在箱{where}"
    return f'Book原线两收盘均在{shape}内；当根边界 {low:.2f}～{high:.2f}，{location}{overlap}'
