"""Finite original-Book geometry replay, independent of consolidation selection.

Checks saved native coordinates/owners against actual OHLC. Author wave degree,
complete adjustment A and visual representativeness cannot be proved by this.
No orders, terminal writes or profitability claims.
"""
from pathlib import Path
from datetime import datetime, timezone
import csv, json, hashlib, collections
from research_cases import load_bars

B=Path(__file__).parent
V=B/'verification/book_auxiliary_20261118/geometry_replay';V.mkdir(parents=True,exist_ok=True)
bars=load_bars(B/'testdata/native_history_H1.tsv')
bytime={int(b.time.timestamp()):i for i,b in enumerate(bars)}
rows=list(csv.DictReader((B/'testdata/book_scan.tsv').open(encoding='utf-8-sig'),delimiter='\t'))
unique={tuple(r[k] for k in ('family','owner_a','owner_b','anchor_a','anchor_b','a','pa','b','pb','known','cross','state')):r for r in rows}
counts=collections.Counter();issues=[];details=[]
for number,r in enumerate(unique.values()):
    counts['unique_observations']+=1
    required=('owner_a','owner_b','anchor_a','anchor_b','a','b')
    if any(int(r[k]) not in bytime for k in required):
        counts['missing_native_context']+=1;continue
    origin,last,aa,ab,start,end=[bytime[int(r[k])] for k in required]
    bad=[];uncertain=[];tol=1e-7
    if not origin<=aa<ab<=last:bad.append('contacts_outside_declared_owner')
    if not origin<=start<=end:bad.append('invalid_display_interval')
    owner=bars[origin:last+1]
    up=bool(owner and all(x.low>=bars[origin].low-tol and x.high<=bars[last].high+tol for x in owner)
            and bars[last].high>bars[origin].low)
    down=bool(owner and all(x.high<=bars[origin].high+tol and x.low>=bars[last].low-tol for x in owner)
              and bars[last].low<bars[origin].high)
    if up==down:bad.append('declared_owner_direction_or_enclosure_unresolved')
    if ab<=aa:bad.append('invalid_anchor_span');continue
    slope=(float(r['price_b'])-float(r['price_a']))/(ab-aa)
    native_source=lambda i:float(r['price_a'])+slope*(i-aa)
    drawn=lambda i:float(r['pa'])+slope*(i-start)
    family=r['family']
    if up!=down:
        if (1 if up else -1)*slope<=0:bad.append('slope_opposes_owner_direction')
        upper=up if family=='GUIDED_SHIFT' else not up
        field='high' if upper else 'low'
        if any(abs(float(r[k])-getattr(bars[i],field))>tol for k,i in [('price_a',aa),('price_b',ab)]):
            bad.append('contacts_not_native_correct_side_wicks')
        violated=[i for i in range(origin,last+1) if
                  (getattr(bars[i],field)-native_source(i))*(1 if upper else -1)>tol]
        if violated:
            # Forward-only split/prefix rulers may deliberately omit their
            # imaginary backward segment. The scan lacks this contract flag.
            if family=='GUIDED_TURNING' and all(i<aa for i in violated):
                uncertain.append('needs_forward_only_display_contract')
            else:bad.append('source_line_cuts_declared_formation_wicks')
        if family=='GUIDED_SHIFT':
            qfield='low' if up else 'high'
            if abs(float(r['pa'])-getattr(bars[start],qfield))>tol:
                bad.append('translated_rail_not_started_at_actual_opposite_contact')
            if any((drawn(i)-getattr(bars[i],qfield))*(1 if up else -1)>tol for i in range(origin,last+1)):
                bad.append('translated_rail_cuts_declared_formation_wicks')
    if abs(drawn(end)-float(r['pb']))>tol:bad.append('display_endpoint_not_on_original_equation')
    if any(int(owner[i].time.timestamp()-owner[i-1].time.timestamp())!=3600 for i in range(1,len(owner))):
        bad.append('formation_spans_missing_native_bars')
    # Recompute first opposite close or gap without extending original line.
    expected_end=last;expected_cross=0;expected_reason='formation_only'
    if up!=down:
        for i in range(last+1,len(bars)):
            if bars[i].time-bars[i-1].time!=__import__('datetime').timedelta(hours=1):
                expected_reason='gap';break
            expected_end=i
            if (bars[i].close-drawn(i))*(1 if up else -1)<-tol:
                expected_cross=int(bars[i].closed_at.timestamp());expected_reason='cross';break
            if i>=end:
                expected_reason='observing';break
        if int(r['cross']) and expected_cross!=int(r['cross']):bad.append('reported_cross_not_first_native_opposite_close')
        if end!=expected_end and int(r['cross']):bad.append('reported_cross_endpoint_mismatch')
    known=int(r['known']);cross=int(r['cross'])
    causal=bool(cross and known<=cross-3600 and 'retrospective' not in r['state'])
    row={'id':r['id'],'family':family,'known':known,'cross':cross,'causal_cross':causal,
         'owner_start':datetime.fromtimestamp(int(r['owner_a']),timezone.utc).isoformat(),
         'owner_end':datetime.fromtimestamp(int(r['owner_b']),timezone.utc).isoformat(),
         'checks_failed':bad,'unverified':uncertain,'original':r}
    details.append(row)
    if bad or uncertain:issues.append(row)
    counts['checked']+=1;counts['violations']+=bool(bad);counts['needs_contract']+=bool(uncertain)
    counts['causal_observations']+=causal
    counts.update('violation:'+x for x in bad)
report={'scope':'All unique saved native line observations; original endpoints and equations only',
        'raw_rows':len(rows),'counts':dict(counts),'issues':issues,
        'author_logic_certified':False,'deployed':False,'orders':False,
        'not_proven':['author trend/degree ownership','complete adjustment A','all Book families',
                      'contact representativeness','fresh native visual acceptance'],
        'source_sha256':{p:hashlib.sha256((B/p).read_bytes()).hexdigest() for p in
                         ['audit_book_geometry.py','testdata/book_scan.tsv','testdata/native_history_H1.tsv']}}
(V/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
(V/'observations.json').write_text(json.dumps(details,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({'raw_rows':len(rows),'counts':dict(counts),'first_issues':issues[:2]},ensure_ascii=False))
