"""Candidate: separate outer observation after an inner post-gap exit.

Never bridge missing bars, revive a terminated outer, or move the old endpoint.
This module is not wired to the running worker until native acceptance.
"""
import math
from continuation import observe
from outer_continuation import handoff as ordinary_handoff

def handoff(event,result,contexts,bars,cutoff):
    inner=result.get('continuation')
    if not inner or inner['state']!='gap_exit':
        return ordinary_handoff(event,result,contexts,bars,cutoff)
    visible=[b for b in bars if int(b.closed_at.timestamp())<=cutoff]
    origin=next((i for i,b in enumerate(visible) if int(b.closed_at.timestamp())==event['clock']),None)
    if origin is None:return None
    # gap_exit is terminal. Locate its first knowable close, not the last
    # drawable point before the gap stored in the original continuation.
    lo,hi=origin,len(visible)-1
    original={'code':result['code'],'context':next((c for c in contexts if c['id'] in inner['range_ids']),None)}
    if not original['context']:return None
    while lo<hi:
        mid=(lo+hi)//2
        observation=observe(event,original,contexts,visible[:mid+1],int(visible[mid].closed_at.timestamp()))
        if observation and observation['state']=='gap_exit':hi=mid
        else:lo=mid+1
    at=lo;known=int(visible[at].closed_at.timestamp());start=int(visible[at].time.timestamp())
    if at<=origin or visible[at].time!=visible[at-1].closed_at:return None
    final=observe(event,original,contexts,visible[:at+1],known)
    if not final or final['state']!='gap_exit':return None
    choices=[]
    for c in contexts:
        if c['id'] not in inner['outer_range_ids'] or c['id'] in inner['range_ids']:continue
        low=min(c['low'],c['fixed_low']);high=max(c['high'],c['fixed_high'])
        if not all(math.isfinite(v) for v in (low,high)):continue
        if low>inner['low'] or high<inner['high'] or (low,high)==(inner['low'],inner['high']):continue
        if not c['active'] or c['known']>int(visible[origin].time.timestamp()):continue
        if not all(low<=b.open<=high and low<=b.close<=high for b in visible[at-1:at+1]):continue
        prefix=observe(event,{'code':result['code'],'context':c},contexts,visible[:at+1],known)
        if not prefix or prefix['state']!='resumed':continue
        choices.append((high-low,-c['known'],c['id'],c))
    if not choices:return None
    selected=min(choices,key=lambda x:x[:3])[3]
    outer=observe(event,{'code':result['code'],'context':selected},contexts,visible,cutoff)
    segments=[]
    for s in outer['segments']:
        if s['end']<start:continue
        segment=dict(s)
        if segment['start']<start:
            segment['start']=start;segment['price0']=event['line']+event['slope']*(at-origin)
        segment['known']=max(segment['known'],known)
        segment['state']='outer_'+s['state'];segment['label']='缺口后外层续观；'+s['label']
        segment['low']=outer['low'];segment['high']=outer['high'];segment['range_id']=selected['id']
        segments.append(segment)
    if not segments:return None
    return dict(id=event['id'],family=event['family'],known=known,parent_range_id=selected['id'],
        inner_range_ids=inner['range_ids'],low=outer['low'],high=outer['high'],state='outer_'+outer['state'],
        label='缺口后外层续观；'+outer['label'],segments=segments,scope_observation=outer,
        policy='原线和内层终点不变；缺口后两根连续实体仍在事前已知外层，从第二根收盘单独起线；不连接缺口、不代表趋势确认')

def handoff_chain(event,result,contexts,bars,cutoff):
    step=handoff(event,result,contexts,bars,cutoff)
    if not step:return None
    combined=dict(step);combined['segments']=list(step['segments']);chain=[];seen=set()
    while step:
        selected=step['parent_range_id']
        if selected in seen:raise ValueError('Non-growing outer range chain')
        seen.add(selected)
        chain.append({k:step[k] for k in ('parent_range_id','known','low','high','state')})
        inner=step['scope_observation']
        if inner['state'] not in ('fixed_envelope_exit','gap_exit'):break
        next_step=handoff(event,{'code':result['code'],'continuation':inner},contexts,bars,cutoff)
        if not next_step:break
        if next_step['known']<=step['known']:raise ValueError('Non-forward outer handoff')
        combined['segments'].extend(next_step['segments']);step=next_step
    combined['range_chain']=chain
    combined['final_state']=step['state'];combined['state']=step['state'];combined['label']=step['label']
    combined.pop('scope_observation',None)
    return combined
