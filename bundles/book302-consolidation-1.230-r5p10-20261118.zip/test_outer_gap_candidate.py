import copy,unittest
import test_continuation
from continuation import observe
from outer_gap_candidate import handoff_chain
from outer_continuation import handoff_chain as baseline
from worker import NativeBar

class GapOuterTests(unittest.TestCase):
 def setUp(self):
  self.f=test_continuation.ContinuationTests();self.f.setUp()
  self.event=self.f.event;self.inner=self.f.box
  self.outer={**self.inner,'id':'larger','high':4020,'fixed_high':4020}
  self.contexts=[self.inner,self.outer]
  self.bars=[self.f.bar(0,4005),self.f.bar(1,4005),self.f.bar(50,4011),self.f.bar(51,4012),self.f.bar(52,4013)]
 def run_case(self,cutoff=None,bars=None):
  bars=self.bars if bars is None else bars;cutoff=cutoff or int(bars[-1].closed_at.timestamp())
  r={'code':2,'context':self.inner}
  r['continuation']=observe(self.event,r,self.contexts,bars,cutoff)
  before=copy.deepcopy((self.event,r,self.contexts,bars))
  out=handoff_chain(self.event,r,self.contexts,bars,cutoff)
  self.assertEqual(before,(self.event,r,self.contexts,bars))
  return out,r
 def test_confirming_bar_starts_separate_segment(self):
  out,r=self.run_case();self.assertEqual(r['continuation']['state'],'gap_exit')
  self.assertEqual(out['known'],int(self.bars[3].closed_at.timestamp()))
  s=out['segments'][0];self.assertEqual(s['start'],int(self.bars[3].time.timestamp()))
  self.assertGreater(s['start'],r['continuation']['end']);self.assertEqual(s['price0'],4001)
  self.assertIsNone(baseline(self.event,r,self.contexts,self.bars,int(self.bars[-1].closed_at.timestamp())))
 def test_one_return_not_enough_and_future_suffix_cannot_help(self):
  cutoff=int(self.bars[2].closed_at.timestamp())
  self.assertEqual(self.run_case(cutoff)[0],self.run_case(cutoff,self.bars[:3])[0])
  self.assertIsNone(self.run_case(cutoff)[0])
 def test_prefix_invariant_after_handoff(self):
  cutoff=int(self.bars[3].closed_at.timestamp())
  a=self.run_case(cutoff)[0]
  self.bars[-1]=self.f.bar(52,9000)
  self.assertEqual(a,self.run_case(cutoff)[0])
 def test_late_outer_not_allowed(self):
  self.outer['known']=self.event['clock']+3600;self.assertIsNone(self.run_case()[0])
 def test_overlap_without_containment_not_allowed(self):
  self.outer['low']=4001;self.outer['fixed_low']=4001;self.assertIsNone(self.run_case()[0])
 def test_long_gap_no_revival(self):
  self.bars=self.bars[:2]+[self.f.bar(i,4012) for i in (120,121,122)]
  self.assertIsNone(self.run_case()[0])
 def test_outer_already_exited_not_revived(self):
  self.bars=[self.f.bar(0,4005),self.f.bar(1,4021),self.f.bar(2,4022),self.f.bar(50,4011),self.f.bar(51,4012)]
  self.assertIsNone(self.run_case()[0])
 def test_outer_ends_at_its_own_confirmed_exit(self):
  self.bars.extend([self.f.bar(53,4021),self.f.bar(54,4022),self.f.bar(55,4011)])
  out,_=self.run_case();self.assertEqual(out['state'],'outer_fixed_envelope_exit')
  self.assertEqual(out['segments'][-1]['end'],int(self.bars[-2].time.timestamp()))
 def test_no_forward_knowledge_in_choice(self):
  self.contexts.append({**self.outer,'id':'largest','high':4050,'fixed_high':4050})
  self.bars.extend([self.f.bar(53,4030),self.f.bar(54,4030)])
  out,_=self.run_case();self.assertEqual(out['range_chain'][0]['parent_range_id'],'larger')
  self.assertEqual([x['parent_range_id'] for x in out['range_chain']],['larger','largest'])
 def test_price_mirror(self):
  out,_=self.run_case()
  self.bars=[NativeBar(b.time,8000-b.open,8000-b.low,8000-b.high,8000-b.close,b.spread,b.seconds) for b in self.bars]
  for c in self.contexts:
   for low,high in [('low','high'),('fixed_low','fixed_high'),('low0','high0')]:c[low],c[high]=8000-c[high],8000-c[low]
  self.event={**self.event,'line':8000-self.event['line'],'slope':-self.event['slope']}
  other,_=self.run_case();self.assertEqual(out['known'],other['known'])
  self.assertAlmostEqual(out['segments'][0]['price0']+other['segments'][0]['price0'],8000)

if __name__=='__main__':unittest.main()
