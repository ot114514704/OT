"""Replay Book's single-line check with fixed inputs, independent labels and cutoffs."""
import csv
import json
from collections import Counter
from dataclasses import replace
from pathlib import Path

from book_close_follow import book_close_follow, book_close_note
from research_cases import load_bars

root = Path(__file__).parent
out = root/'verification/book_close_follow_20261118'
source = root/'verification/book_auxiliary_20261118/geometry_replay'
inventory = json.loads((root/'verification/line_families_20261118/inventory.json').read_text('utf8'))['events']
prior = json.loads((source/'close_filter.json').read_text('utf8'))['results']
expected = {(r['id'],int(r['cross'])):r for r in prior}
bars = load_bars(root/'testdata/native_history_H1.tsv')
indices = {int(b.closed_at.timestamp()):i for i,b in enumerate(bars)}
end = int(bars[-1].closed_at.timestamp())
counts = Counter()
motions = Counter()
by_motion = {}
examples = {}
symmetry = 0
prefixes = 0
for sample in inventory:
    event = sample['event']
    wanted = expected[(event['id'],event['clock'])]
    i = indices[event['clock']]
    result = book_close_follow(event,bars,i,end)
    assert result is not None, event
    for n,field in ((2,'two'),(3,'three')):
        actual = ('held' if result['consecutive']>=n else
                  'returned_or_touched' if result['status']=='returned' else 'missing_contiguous_bar')
        assert actual == wanted[field], (event,n,result,wanted)
        counts[f'{n}/{actual}']+=1
    motions[result['motion']]+=1
    by_motion.setdefault(result['motion'],Counter())[wanted['three']]+=1
    examples[result['motion']]=dict(id=event['id'],clock=event['clock'],previous_close=bars[i-1].close,
        close=bars[i].close,previous_line=event['line']-event['slope'],line=event['line'])
    short=bars[i-1:i+3]
    mirror=[replace(b,open=10000-b.open,high=10000-b.low,low=10000-b.high,close=10000-b.close) for b in short]
    opposite=dict(event,slope=-event['slope'],line=10000-event['line'])
    for k,bar in enumerate(short[1:],1):
        when=int(bar.closed_at.timestamp())
        truncated=book_close_follow(event,short[:k+1],1,when)
        assert truncated==book_close_follow(event,bars,i,when)
        assert truncated==book_close_follow(opposite,mirror,1,when)
        assert truncated['last_close']<=when
        prefixes+=1;symmetry+=1
    assert book_close_follow(dict(event,known=event['clock']),bars,i,end) is None
    assert book_close_follow(dict(event,state='retrospective'),bars,i,end) is None
    assert book_close_follow(event,bars,i,event['clock']-1) is None

families = Counter()
contractsets = {}
# Only use each native file's recorded eligibility. A and B coordinates in a
# guided ruler contract are line anchors; they do not identify adjustment A.
for path in sorted(root.glob('runtime/bridge/NativeBookAudit/*.line_contracts.tsv')):
    data=path.read_bytes()
    text=data.decode('utf16' if data.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
    counts_by_role=Counter()
    for row in csv.DictReader(text.splitlines(),delimiter='\t'):
        fields=dict(part.split('=',1) for part in row['line_contract'].split(';') if '=' in part)
        key=(row['id'],fields.get('formation_revision'),fields.get('observation_revision'))
        contractsets[key]=(fields.get('role'),fields.get('event'),fields.get('pair'))
        counts_by_role[fields.get('role')]+=1
for role,event,pair in contractsets.values():
    families[(role,event,pair)]+=1
report=dict(cases=len(inventory),counts=dict(counts),motions=dict(motions),third_close_by_motion=by_motion,examples=examples,closed_prefix_checks=prefixes,mirror_checks=symmetry,
            contract_observations=[dict(role=k[0],event=k[1],pair=k[2],count=v) for k,v in sorted(families.items())],
            trading_signals=False)
(out/'close_replay.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(report,ensure_ascii=False))
