"""Build and verify both the local self-contained bundle and the OT restoration bundle."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from package_book_outline_side import ROOT, read, sha

OUT = ROOT/'verification/book_panel_r5p7'


def build(target,files):
    manifest={k:sha(v) for k,v in files.items()}
    with ZipFile(target,'x',ZIP_DEFLATED) as z:
        for name,data in files.items():
            z.writestr(name,data)
        z.writestr('R5P7_PACKAGE_MANIFEST.json',json.dumps(manifest,indent=2,ensure_ascii=False).encode())
    with ZipFile(target) as z:
        assert z.testzip() is None and all(sha(z.read(k))==v for k,v in manifest.items())
    data=target.read_bytes()
    return dict(path=str(target),bytes=len(data),sha256=sha(data),files_verified=len(files),
                git_blob_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())


def main():
    base=read(ROOT/'PACKAGE_R5P6.json')
    old=Path(base['path'])
    assert sha(old.read_bytes())==base['sha256']
    with ZipFile(old) as z:
        files={k:z.read(k) for k in z.namelist() if k!='R5P6_PACKAGE_MANIFEST.json'}
    names=['worker.py','book_reference_manifest.json','prepare_book_reference.py','book_viewport_structure.py',
           'verify_book_panel_r5p7.py','replay_book_panel_windows.py','package_book_panel.py',
           'source/Book302_Consolidation_Experiment.ex5','source/BookExperimentGuard.mqh',
           'audit_august_pair_life.py','book_boundary_sequence.py','check_book_boundary_sequence.py',
           'compare_book_native_owners.py','compare_triangle_book_events.py','compare_triangle_followthrough.py',
           'draw_august_book_sequence.py','draw_book_native_contacts.py','inspect_current_book_structure.py',
           'inspect_native_shift_supports.py','map_book_native_contacts.py','replay_august_book_prefixes.py',
           'review_august_book_A.py','verify_current_book_native.py']
    for folder in (OUT,ROOT/'verification/book_native_mapping_20261118',
                   ROOT/'verification/book_august_prefix_20261118',ROOT/'verification/triangle_followthrough_20261118'):
        names.extend(p.relative_to(ROOT).as_posix() for p in folder.iterdir() if p.is_file() and p.name!='OT_receipt.json')
    files.update({k:(ROOT/k).read_bytes() for k in names})
    assert read(OUT/'continuous_replay.json')['bars']==144
    assert read(OUT/'r5p7_verification.json')['restore_verified']==153
    assert 'OK' in (OUT/'regression.txt').read_text('utf-8-sig').splitlines()
    assert '0 errors, 0 warnings' in (OUT/'compile.log').read_text('utf-16')
    files['README_R5P7.txt']=(OUT/'本轮复核与恢复.txt').read_bytes()
    remote=build(old.parent/'Book302_1.230-r5p7_H1双线核验_OT_20261118.zip',files)
    for name,digest in read(ROOT/'book_reference_manifest.json').items():
        key='book_archive_runtime/'+name
        files[key]=(ROOT/key).read_bytes()
        assert sha(files[key])==digest
    local=build(old.parent/'Book302_1.230-r5p7_H1双线核验_含依赖_20261118.zip',files)
    meta=dict(local=local,ot=remote)
    (ROOT/'PACKAGE_R5P7.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),'utf8')
    print(meta)


if __name__=='__main__':
    main()

