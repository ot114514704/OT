"""Check native MT5 publication, live input and the context of the four closed-bar examples."""
import csv
import json
from datetime import datetime
from pathlib import Path

from book_pair_recovery import line_at, summary
from book_viewport_structure import inspect_close, load_reference, stamp
from book_auxiliary import select
from inspect_current_book_structure import fetch, verified
from package_book_outline_side import BRIDGE, KEY, ROOT, read, sha, tsv
from test_book_pair_recovery import OUT, history
from worker import NativeBar, recognize
from replay_book_adjustment_A import response


def native():
    old=read(OUT/f'audit_{KEY}.json')
    new=read(BRIDGE/f'audit_{KEY}.json')
    base=tsv(OUT/f'reply_{KEY}.tsv')
    now=tsv(BRIDGE/f'reply_{KEY}.tsv')
    head=now[0].split('\t')
    rev=tsv(BRIDGE/f'reply_revision_{KEY}.tsv')[0].split('\t')
    rend=tsv(BRIDGE/f'render_state_{KEY}.tsv')[0].split('\t')
    worker=read(BRIDGE/'worker_identity.json')
    assert worker['script_sha256']==sha((ROOT/'worker.py').read_bytes())
    assert min(int(rev[5]),int(rend[12]))>=int(worker['started'])
    assert head[2]==old['token']==new['token']==rend[3]==rend[4]==rev[2]
    assert head[7]==rev[3]==rend[5]=='full'
    assert (OUT/f'request_{KEY}.tsv').read_bytes()==(BRIDGE/f'request_{KEY}.tsv').read_bytes()
    assert head[8]==rev[4]==sha(('\n'.join(now[1:])+'\n').encode())
    assert len(old['results'])==len(new['results'])==int(head[3])
    changed=[]
    for a,b in zip(old['results'],new['results']):
        r=dict(b)
        follow=r.pop('book_pair_recovery',None)
        if follow:
            prefix=summary(follow)+'。'
            assert r['follow'].startswith(prefix)
            r['follow']=r['follow'][len(prefix):]
            changed.append(dict(id=r['id'],event=r['clock'],note=prefix))
        assert a==r,r['id']
    assert len(base)==len(now)
    for a,b in zip(base[1:],now[1:]):
        aa,bb=a.split('\t'),b.split('\t')
        if aa[0]=='R':
            assert bb[14].endswith(aa[14])
            bb[14]=aa[14]
        assert aa==bb
    return dict(rows=int(head[3]),continuations=int(rend[11]),revision=head[8],changes=changed,
                worker=worker['script_sha256'],worker_started=worker['started'],native_render=rend[12])


def live():
    state=fetch('state')
    reports=state['current_consolidation']
    details={k:dict(label=r['label'],availability=r['availability'],clock=r['known_at'],
                    synced=r['bar_sync']['status']) for k,r in reports.items()}
    if not verified(state):
        return dict(periods=details,book_status='native H1 not available')
    bars=[NativeBar(datetime.fromisoformat(b['time']),*(b[k] for k in ('open','high','low','close')),0,3600)
          for b in state['charts']['H1']['bars']]
    signal=inspect_close(bars[-512:])
    again=fetch('live')
    return dict(periods=details,stable=verified(again) and again['latest_closed_end']==state['latest_closed_end']
                and again['model_revision']==state['model_revision'],book=signal['counts'],
                book_clock=signal['clock'],quote_source=state['market_source']['server'])


def auxiliary():
    records=read(OUT/'native_prefixes.json')
    bars=tuple(history())
    ix={stamp(b.time):i for i,b in enumerate(bars)}
    closes={stamp(b.closed_at):i for i,b in enumerate(bars)}
    adjustments=read(ROOT/'verification/book_adjustment_A_20261118/frozen_adjustments.json')['cases']
    export=next(BRIDGE.glob('CompanionBookThreePushPA_*.tsv'))
    lines=export.read_text('utf-16').splitlines()
    header=next(i for i,l in enumerate(lines) if l.startswith('known\tstart\t'))
    end=next(i for i in range(header+1,len(lines)) if lines[i].startswith('summary\t'))
    outlines=list(csv.DictReader(lines[header:end],delimiter='\t'))
    checks=[]
    for clock in sorted({r['event'] for r in records}):
        i=closes[clock]
        before=recognize(bars[i-512:i])[0]
        now=recognize(bars[i-512:i+1])[0]
        pairs=inspect_close(bars[i-511:i+1])['pairs']
        pre=[dict(timestamp_utc=stamp(b.time),timeframe='H1',symbol='XAUUSD',provider='MT5_experiment',
                  open=b.open,high=b.high,low=b.low,close=b.close) for b in bars[i-511:i]]
        cut=stamp(bars[i].time)
        scopes=load_reference()[0](pre,'H1',cut)
        for p in pairs:
            if p['event']!='same_bar':
                continue
            context={}
            for role in ('trend','turning'):
                rail=p[role]
                anchor=rail[0] if role=='trend' else rail[2]
                y=line_at(rail,anchor,i,ix)
                slope=y-line_at(rail,anchor,i-1,ix)
                event=dict(clock=int(bars[i].closed_at.timestamp()),known=int(datetime.fromisoformat(p['pair_known']).timestamp()),
                           id=p['owner']+'/'+role,owner_a=p['origin'][0],owner_b=p['terminal'][0],state='first_close_break',
                           line=float(y),slope=float(slope))
                selected=select(event,bars[i-1],bars[i],before,now)
                context[role]={m['range']['id']:m['kind'] for m in
                               [selected['primary'],*selected['alternatives']] if m}
            common={k:v for k,v in context['trend'].items() if k in context['turning']}
            a=next((a for a in adjustments if a['id']==p['owner'] and a['dual_close']==clock
                    and a['terminal_price']==p['terminal'][1]),None)
            children=[response(c,pre,p['direction']) for c in scopes['active']+scopes['retired']
                      if c.get('parent_scope_id')==p['owner'] and c.get('terminal')
                      and c['direction']!=p['direction'] and c['membership_known_at_utc']<=cut]
            children.sort(key=lambda c:c['extreme'])
            candidates=[]
            for o in outlines:
                if not (0<int(o['category']) and p['origin'][0]<=int(o['start'])<=int(o['end'])<=p['terminal'][0]
                        and int(o['end'])<=int(o['known'])<=bars[i].time.timestamp()):
                    continue
                candidates.append({k:o[k] for k in ('start','end','known','category')})
            checks.append(dict(event=clock,owner=p['owner'],common_ranges=common,
                               three_push_outlines_inside_time_scope=candidates,
                               directly_owned_counterlegs_at_open=children,
                               archived_adjustment=a['adjustment_review']['status'] if a else None,
                               verified_A=a['archived_boundary']['author_boundary_verified'] if a else None))
    return checks


if __name__=='__main__':
    for name,fn in [('auxiliary',auxiliary),('live',live),('native',native)]:
        result=fn()
        (OUT/(name+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
        print(name,result,flush=True)

