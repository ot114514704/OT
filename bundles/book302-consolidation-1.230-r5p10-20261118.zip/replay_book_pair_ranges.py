"""Match a previously verified Book pair to the same causal H1 range on both rails."""
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from book_auxiliary import select
from worker import NativeBar, recognize

ROOT = Path(__file__).resolve().parent
FOLDER = ROOT/'verification/book_pair_range_20261118'
SOURCE = ROOT/'verification/book_pair_replay_20261118/paired_replay.json'
HISTORY = ROOT/'testdata/native_history_H1.tsv'
NATIVE_REQUEST = ROOT/'verification/outer_gap_20261118/november_before/request_102923304041429_3600.tsv'

def stamp(text):
    return int(datetime.fromisoformat(text).timestamp())

def joint_ranges(record, bars, before, now):
    if not (record['bars_between']==0 and record['source_reproduced_before_first'] and
            record['source_alive_at_second'] and record['both_outside_at_second']):
        raise ValueError('Need a verified same-source same-bar double close')
    previous, current = bars[-2:]
    if previous.closed_at != current.time:
        raise ValueError('Need the preceding contiguous closed H1')
    clock = stamp(record['second_close'])
    assert clock==int(current.closed_at.timestamp()) and stamp(record['pair_known'])<=int(current.time.timestamp())
    chart = {stamp(row['close_time']):row for row in record['chart']}
    p,c = chart[int(previous.closed_at.timestamp())],chart[clock]
    for b,point in [(previous,p),(current,c)]:
        assert all(getattr(b,k)==point[k] for k in ('open','high','low','close'))
    owners = list(map(stamp, record['owner']))
    candidates = {}
    reasons = {}
    for role in ('outer','turning'):
        event = dict(id=record['id']+'/'+role,clock=clock,owner_a=owners[0],owner_b=owners[1],
                     known=stamp(record['pair_known']),line=c[role],slope=c[role]-p[role],state='first_close_break')
        selection = select(event,previous,current,before,now)
        candidates[role] = {r['range']['id']:r for r in [selection['primary'],*selection['alternatives']] if r}
        reasons[role] = {r['id']:r['reason'] for r in selection['rejected']}
    common=[(rid,r) for rid,r in candidates['outer'].items() if rid in candidates['turning']]
    accepted=[]
    for rid,r in common:
        zone=r['range']
        accepted.append(dict(id=rid,shape=r['kind'],detector=zone['kind'],previous=[r['before']['low'],r['before']['high']],
                             current=[zone['low'],zone['high']],known=zone['known'],start=zone['start'],
                             close_inside=r['event_close_inside'],event_status=zone['status']))
    return dict(owner=record['id'],direction=record['direction'],when=record['second_close'],
                prices=dict(previous_close=p['close'],current_close=c['close'],outer=[p['outer'],c['outer']],turning=[p['turning'],c['turning']]),
                prior_active_count=sum(r['active'] for r in before),prior_dense_count=sum(r['active'] and r['kind']=='dense' for r in before),
                current_ids=len({r['id'] for r in now}),common=accepted,
                allowed_per_rail={k:list(v) for k,v in candidates.items()},rejected_per_rail=reasons)

def main():
    audit=json.loads(SOURCE.read_text('utf8'))
    assert audit['history_sha256']==hashlib.sha256(HISTORY.read_bytes()).hexdigest()
    with NATIVE_REQUEST.open(encoding='utf-8-sig') as f:
        header=f.readline().strip().split('\t')
    assert header[3]=='3600' and header[7]=='XAUUSD'
    point=float(header[8])
    with HISTORY.open(encoding='utf-8-sig') as f:
        history=[NativeBar(datetime.fromtimestamp(int(r['time']),timezone.utc),
                   *(float(r[k]) for k in ('open','high','low','close')),float(r['spread'])*point,3600)
                 for r in csv.DictReader(f,delimiter='\t')]
    indices={int(b.closed_at.timestamp()):i for i,b in enumerate(history)}
    records=[r for w in audit['windows'] for r in w['records'] if r.get('chart')]
    samples=[]
    for count in (256,512):
        for time in sorted({r['second_close'] for r in records}):
            end=indices[stamp(time)]
            bars=tuple(history[end-count:end+1])
            assert len(bars)==count+1
            before=recognize(bars[:-1])[0]
            now=recognize(bars)[0]
            for r in records:
                if r['second_close']!=time:
                    continue
                case=joint_ranges(r,bars,before,now)
                case['warmup_bars']=count
                samples.append(case)
                print(count,time,case['owner'],case['prior_active_count'],case['prior_dense_count'],
                      [(a['shape'],a['detector']) for a in case['common']],flush=True)
    by_owner={}
    for sample in samples:
        invariant = {k:sample[k] for k in ('when','prices','common','allowed_per_rail')}
        assert by_owner.setdefault(sample['owner'],invariant)==invariant, sample['owner']
    FOLDER.mkdir(exist_ok=True)
    report=dict(history_sha256=audit['history_sha256'],paired_source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                point=point,samples=samples)
    (FOLDER/'same_bar_ranges.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')

if __name__=='__main__':
    main()
