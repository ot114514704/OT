"""Follow a Book dual close on frozen rails for three subsequent H1 bars."""
from collections import Counter
from fractions import Fraction

from book_viewport_structure import stamp


def line_at(anchors, anchor, position, index):
    left, right = anchors[:2]
    first, last = index[left[0]], index[right[0]]
    slope = (Fraction(str(right[1])) - Fraction(str(left[1]))) / (last - first)
    return Fraction(str(anchor[1])) + slope * (position - index[anchor[0]])


def crossing_path(bars, index, event, pair, check_at):
    """Verify the first break, then separate a sustained break from a fresh dual close."""
    span = pair.get('bars_between')
    if span not in (1, 2) or check_at is None or event < span:
        return None
    first = event - span
    trend_first = pair['trend_break_bar'] < pair['turning_break_bar']
    rail = pair['trend'] if trend_first else pair['turning']
    anchor = rail[0] if trend_first else rail[2]
    clocks = sorted((pair['trend_break_bar'], pair['turning_break_bar']))
    if clocks != [stamp(bars[first].time), stamp(bars[event].time)] or pair['pair_known'] > clocks[0]:
        return None
    sign = 1 if pair['direction'] == 'down' else -1
    identity = ('origin','terminal','direction','pair_known','trend','turning')
    retained = True
    for j in range(first,event):
        if bars[j].closed_at != bars[j+1].time:
            return None
        earlier = check_at(j)
        matches = [p for p in earlier.get('pairs',[]) if all(p[key]==pair[key] for key in identity)]
        if earlier.get('clock') != stamp(bars[j].closed_at) or len(matches) != 1:
            return None
        if j == first and matches[0]['event'] != ('trend_only' if trend_first else 'turn_only'):
            return None
        if sign * (Fraction(str(bars[j].close))-line_at(rail,anchor,j,index)) <= 0:
            if j == first:
                return None
            retained = False
    close = Fraction(str(bars[event].close))
    opening = Fraction(str(bars[event].open))
    previous = Fraction(str(bars[event-1].close))
    open_sides = []
    for role, anchor_index in [('trend',0),('turning',2)]:
        line = pair[role]
        at_event = line_at(line,line[anchor_index],event,index)
        if sign * (close-at_event) <= 0:
            return None
        if not retained and sign * (previous-line_at(line,line[anchor_index],event-1,index)) >= 0:
            return None
        open_sides.append(sign * (opening-at_event))
    proof = dict(first_close=stamp(bars[first].closed_at),bars=span+1,
                source_alive=pair['source_alive'],same_terminal=pair['same_terminal'])
    if retained:
        return 'consecutive_break',proof
    proof.update(reentry_close=stamp(bars[event-1].closed_at),
                 opening_outside=sum(s>0 for s in open_sides),opening_touched=sum(s==0 for s in open_sides))
    return 'renewed_dual_close',proof


def short_sequence(bars, index, event, pair, check_at):
    """Return only a sustained sequence for historical callers."""
    path = crossing_path(bars,index,event,pair,check_at)
    return path[1] if path and path[0]=='consecutive_break' else None


def observe(bars, index, event, last, report, check_at=None):
    """Read through last only. Preserve separate clocks for the cross and later evidence."""
    observations = []
    for pair in report.get('pairs', []):
        path = crossing_path(bars,index,event,pair,check_at) if pair['event']=='later_line' else None
        if pair['event'] != 'same_bar' and path is None:
            continue
        event_close = stamp(bars[event].closed_at)
        if report['clock'] != event_close or pair['pair_known'] > stamp(bars[event].time):
            raise ValueError('Book pair was not frozen before this event')
        sign = 1 if pair['direction'] == 'down' else -1
        former_extreme = Fraction(str(pair['terminal'][1]))
        first_reentry = None
        new_extreme = None
        records = []
        gap = None
        for j in range(event, min(event + 3, last) + 1):
            if j > event and bars[j-1].closed_at != bars[j].time:
                gap = stamp(bars[j].time)
                break
            clock = stamp(bars[j].closed_at)
            close = Fraction(str(bars[j].close))
            trend = line_at(pair['trend'], pair['trend'][0], j, index)
            turning = line_at(pair['turning'], pair['turning'][2], j, index)
            trend_side = sign * (close - trend)
            turning_side = sign * (close - turning)
            outside = trend_side > 0 and turning_side > 0
            if j == event and not outside:
                raise ValueError('Frozen rails do not reproduce the original close')
            # Returning to the safe side of the turning line requires a strict close.
            # A later close must clear the old wave extreme to document both observations.
            if first_reentry and not new_extreme and sign * (close - former_extreme) < 0:
                new_extreme = clock
            if turning_side < 0 and first_reentry is None:
                first_reentry = clock
            records.append(dict(clock=clock, close=float(close), trend=float(trend), turning=float(turning),
                                outside_both=outside, turning_relation='outside' if turning_side > 0 else
                                'inside' if turning_side < 0 else 'touch'))
        observations.append(dict(owner=pair['owner'], direction=pair['direction'], event=event_close,
                                 former_extreme=float(former_extreme), observations=records, gap_at=gap,
                                 first_reentry=first_reentry, later_directional_extreme=new_extreme))
        if path:
            observations[-1][path[0]] = path[1]
    return observations


def summary(items):
    groups = Counter()
    for item in items:
        records = item['observations']
        count = len(records) - 1
        if item['later_directional_extreme']:
            status = '收回拐点线后再收过原波段极值'
        elif item['gap_at']:
            prefix = '缺柱前已收回拐点线，' if item['first_reentry'] else ''
            status = prefix + f'已跟踪{count}根，缺柱中止'
        elif not count:
            status = '双破后待下一收盘'
        elif item['first_reentry']:
            status = f'已收回拐点线，现居线{dict(inside="内",outside="外",touch="上")[records[-1]["turning_relation"]]}'
        elif all(r['outside_both'] for r in records[1:]):
            status = f'后续连续{count}根仍收在双线外'
        else:
            status = '双线外收盘未持续，尚无拐点线收回'
        sequence = item.get('consecutive_break')
        if sequence:
            source = '，原波段已退场' if not sequence['source_alive'] else '，原波段端点已更新' if not sequence['same_terminal'] else ''
            status = f"{sequence['bars']}根先后收破{source}，" + status
        renewed = item.get('renewed_dual_close')
        if renewed:
            if renewed['opening_touched']:
                body = '开盘触线'
            else:
                body = ('开收跨双线','开盘已越一线','开盘已越双线')[renewed['opening_outside']]
            source = '，原波段待复核' if not renewed['source_alive'] or not renewed['same_terminal'] else ''
            status = f'前柱收回，本柱重收双线外（{body}）{source}，' + status
        groups[status] += 1
    return 'Book双破跟踪：' + '、'.join(f'{s} {n}组' for s,n in groups.items()) + '；A点另核'

