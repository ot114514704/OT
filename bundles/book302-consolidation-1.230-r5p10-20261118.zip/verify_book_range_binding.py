from collections import Counter
from pathlib import Path
from datetime import datetime,timezone
import json
from importlib.util import spec_from_file_location, module_from_spec
import sys
import worker_binding_candidate as new
from book_auxiliary import select
root=Path(__file__).parent
v=root/'verification/book_range_binding_20261118'
spec=spec_from_file_location('r5p2_binding_baseline',v/'worker_before.py')
old=module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
prev=root/'verification/book_auxiliary_20261118/pa_binding'
requests=[root/'verification/outer_gap_20261118/november_before/request_102923304041429_3600.tsv',next(p/'request' for p in prev.iterdir() if (p/'request').exists())]
def stamp(t): return datetime.fromtimestamp(t,timezone.utc).strftime('%Y-%m-%d %H:%M')
captured={}
def observe(e,*args,**kwargs):
    result=select(e,*args,**kwargs)
    captured[e['id']]=result
    return result
new.select_book_range=observe
reports=[]
for p in requests:
    raw=p.read_text('utf-8-sig')
    req=new.parse_request(raw)
    baseline=old.solve(req)
    captured.clear()
    updated=new.solve(req)
    assert len(baseline)==len(updated)
    seen=Counter(); examples=[]
    for a,b in zip(baseline,updated):
        assert {k:v for k,v in a.items() if k!='detail'}=={k:v for k,v in b.items() if k!='detail'},a['id']
        if b['id'] not in captured:
            assert b['detail']==a['detail'];continue
        link=captured[b['id']]
        assert b['detail']==new.range_evidence_note(link)+'。'+a['detail']
        primary=link['primary']; original=a.get('context') or {}
        eligible=[c for c in [primary,*link['alternatives']] if c]
        rejects={c['id']:c['reason'] for c in link['rejected']}
        old_relation=('none' if not original else 'overlap' if any(x['range']['id']==original['id'] for x in eligible) else 'unproven')
        seen['old_context/'+old_relation]+=1;seen['link/'+(primary['kind'] if primary else 'none')]+=1
        if link['box']:seen['overlap_box']+=1
        examples.append(dict(id=b['id'],at=stamp(b['clock']),prior_context=original.get('id'),prior_context_evidence=old_relation,
             prior_rejection=rejects.get(original.get('id')),selected=primary['range']['id'] if primary else None,description=new.range_evidence_note(link)))
    reports.append(dict(token=req['token'],count=len(updated),checked=len(captured),counts=dict(seen),examples=examples))
    print(len(updated),dict(seen),flush=True)
(v/'integration_replay.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),'utf8')
