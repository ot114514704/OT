"""Targeted native reader patch, separate from immutable Book drawing code."""
from pathlib import Path
B=Path(__file__).parent;p=B/'source/BookExperimentGuard.mqh'
s=p.read_text('utf8')
def replace(old,new):
 global s
 assert s.count(old)==1,old[:120]
 s=s.replace(old,new)
replace('#include "BookExperimentRequestPolicy.mqh"','#include "BookExperimentRequestPolicy.mqh"\n#include "BookExperimentReplyPolicy.mqh"')
replace('string bex_selected="",bex_stage="";','string bex_selected="",bex_stage="",bex_reply_revision="";')
replace('bex_loaded="";bex_stage="";bex_selected="";','bex_loaded="";bex_stage="";bex_reply_revision="";bex_selected="";')
start=s.index(' if(bex_loaded==bex_token&&(bex_stage=="full"||bex_stage=="limited"))')
end=s.index('\n',start)
old=s[start:end]
body=old[old.index('{')+1:-1]
assert body.endswith('return;')
helper='void BEXLoadedReplyStatus(){'+body+'}\n\n'
replace(old,' // Re-read the small reply header even after full completion: the\n // backend can publish a different result for the same native request.')
replace('void BEXPoll(bool busy,string viewport){',helper+'void BEXPoll(bool busy,string viewport){')
replace('   if(bex_loaded==bex_token&&bex_stage==h[7]){FileClose(f);BEXPanel();return;}',
'''   string advertised=ArraySize(h)>=9?h[8]:"";
   if(ArraySize(h)>=9&&!BEXReplyDigestValid(advertised)){FileClose(f);bex_note="回包摘要格式无效；保留上次核验图形";BEXPanel();return;}
   if(BEXReplyUnchanged(bex_loaded,bex_stage,bex_reply_revision,h[2],h[7],advertised)){
    FileClose(f);if(bex_stage=="full"||bex_stage=="limited")BEXLoadedReplyStatus();else BEXPanel();return;
   }
   string payload="";''')
replace("    string p[];StringSplit(FileReadString(f),'\\t',p);if(ArraySize(p)==0)continue;",
"    string row=FileReadString(f);payload+=row+\"\\n\";string p[];StringSplit(row,'\\t',p);if(ArraySize(p)==0)continue;")
needle='   if(valid&&ended&&ArraySize(records)==expected){'
replace(needle,'''   string revision=BKNHash(payload);
   if(ArraySize(h)>=9&&!BEXReplyPayloadValid(advertised,payload)){FileClose(f);bex_note="回包摘要不匹配；保留上次核验图形";BEXPanel();return;}
   // Legacy eight-field replies are verified by hashing the parsed payload.
   if(valid&&ended&&ArraySize(records)==expected&&BEXReplyUnchanged(bex_loaded,bex_stage,bex_reply_revision,h[2],h[7],revision)){
    FileClose(f);if(bex_stage=="full"||bex_stage=="limited")BEXLoadedReplyStatus();else BEXPanel();return;
   }
'''+needle)
replace('bex_loaded=bex_token;bex_stage=h[7];bex_elapsed=', 'bex_loaded=bex_token;bex_stage=h[7];bex_reply_revision=revision;bex_elapsed=')
replace('FileClose(f);BEXDraw();return;}',
'''FileClose(f);BEXDraw();
    int receipt=FileOpen(BEXRoot()+"reply_revision_"+bex_scope+".tsv",FILE_WRITE|FILE_CSV|FILE_ANSI,'\\t',CP_UTF8);
    if(receipt!=INVALID_HANDLE){FileWrite(receipt,"BEX_REPLY_REVISION",1,bex_token,bex_stage,bex_reply_revision,(long)TimeGMT());FileClose(receipt);}
    return;}''')
p.write_text(s,'utf8')
print('Patched native reply polling; BEXDraw and Book core unchanged')
