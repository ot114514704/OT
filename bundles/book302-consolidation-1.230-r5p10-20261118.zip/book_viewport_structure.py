"""Book chapter 3/4 context for one closed H1 bar in the experiment's own viewport."""
import hashlib
import json
from collections import Counter
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WINDOW = 512


@lru_cache(maxsize=1)
def load_reference():
    manifest = json.loads((ROOT/'book_reference_manifest.json').read_text('utf8'))
    for name, digest in manifest.items():
        if hashlib.sha256((ROOT/'book_archive_runtime'/name).read_bytes()).hexdigest() != digest:
            raise ValueError('资料版本不符')
    from book_archive_runtime.src.book_native_wave_process import recognize_wave_process
    from book_archive_runtime.src.trend_wave_state_adjudication import fit_native_wave_scope
    from book_archive_runtime.src.book_trend_structure_judgement import judge_book_trend_structure
    return recognize_wave_process, fit_native_wave_scope, judge_book_trend_structure


def stamp(t):
    return t.isoformat().replace('+00:00','Z')


def inspect_close(bars):
    if len(bars)<3 or bars[-2].closed_at!=bars[-1].time:
        return dict(status='gap',bars=len(bars))
    recognize, fit, judge = load_reference()
    rows=[dict(timestamp_utc=stamp(b.time),timeframe='H1',symbol='XAUUSD',provider='MT5_experiment',
               open=b.open,high=b.high,low=b.low,close=b.close) for b in bars]
    before=rows[:-1]
    opening=rows[-1]['timestamp_utc']
    closed=stamp(bars[-1].closed_at)
    owners=recognize(before,'H1',opening)['active']
    now={o['scope_id']:o for o in recognize(rows,'H1',closed)['active']}
    stamps={int(b.time.timestamp()):stamp(b.time) for b in bars}
    counts=Counter()
    facts=[]
    previous_owners={}
    for owner in owners:
        if not owner.get('terminal'):
            continue
        def contact(key):
            t,price=owner[key]
            return [stamps[t],price]
        pair=fit(before,'H1',opening,contact('origin'),contact('terminal'),owner['known_at_utc'])
        turn=pair.get('parallel_projection')
        if not (pair['qualified'] and turn):
            continue
        trend=pair['outer_line']
        if max(trend['known_at_utc'],turn['known_at_utc'])>opening:
            raise ValueError('原线时刻晚于本根开盘')
        result=judge(rows,'H1',closed,trend,turn)
        sid=owner['scope_id']
        new_owner=now.get(sid)
        span=None
        if result['stage']=='unknown':
            label='unknown'
        else:
            trend_at=result['outer_break'].get('break_utc')
            turn_at=result['turning_break'].get('break_utc')
            if trend_at==turn_at==opening:
                label='same_bar'
            elif opening in (trend_at,turn_at):
                label=('later_line' if trend_at and turn_at else 'trend_only' if trend_at==opening else 'turn_only')
                if label=='later_line':
                    first=min(result['outer_break']['break_index'],result['turning_break']['break_index'])
                    span=len(rows)-1-first
                    first_open=rows[first]['timestamp_utc']
                    if first not in previous_owners:
                        previous_owners[first]={o['scope_id']:o for o in recognize(rows[:first],'H1',first_open)['active']} if first else {}
                    old=previous_owners[first].get(sid)
                    # This archive fits exclusively on the frozen origin-to-terminal interval.
                    if not (old and old.get('origin')==owner['origin'] and old.get('terminal')==owner['terminal']
                            and old['known_at_utc']==owner['known_at_utc'] and owner['known_at_utc']<=first_open):
                        label='earlier_unverified'
            else:
                label='no_new_cross'
        counts[label]+=1
        facts.append(dict(owner=sid,origin=owner['origin'],terminal=owner['terminal'],direction=owner['direction'],
                          trend=[[before[trend[k+'_index']]['timestamp_utc'],trend[k+'_price']] for k in ('start','end')],
                          turning=[[before[turn[k+'_index']]['timestamp_utc'],turn[k+'_price']] for k in ('extension_start','extension_end','start')],
                          source_alive=bool(new_owner),same_terminal=bool(new_owner and new_owner.get('terminal')==owner['terminal']),
                          pair_known=max(trend['known_at_utc'],turn['known_at_utc']),event=label,
                          bars_between=span,
                          trend_break_bar=result.get('outer_break',{}).get('break_utc'),
                          turning_break_bar=result.get('turning_break',{}).get('break_utc')))
    return dict(status='ok',clock=closed,bars=len(bars),active_owners=len(owners),pairs=facts,counts=dict(counts))


def note(report):
    if report['status']=='gap':
        return 'Book双线：前收盘缺失或不连续，暂缓判定'
    if report['status']=='unavailable':
        return 'Book双线：独立核验暂不可用'
    counts=report['counts']
    total=sum(counts.values())
    if total==0:
        return f"Book双线：此前 {report['bars']-1} 根内无可复核线对"
    labels=[(k,txt) for k,txt in [('same_bar','同柱双破'),('later_line','先后收破，本柱补破'),('earlier_unverified','本柱破线，前次归属待核'),
            ('trend_only','仅趋势线首次收破'),('turn_only','仅拐点线首次收破'),('unknown','证据不足')] if counts.get(k)]
    summary='、'.join(f'{txt} {counts[k]} 组' for k,txt in labels)
    if not summary:
        summary='本柱未见首次收破'
    elif counts.get('no_new_cross'):
        summary+=f"、其余 {counts['no_new_cross']} 组无新收破"
    note_text=f'Book双线：{summary}（{total}组事前线对）'
    spans=sorted({p['bars_between'] for p in report['pairs'] if p['event']=='later_line'})
    if spans:
        note_text+='，两次相隔'+'、'.join(str(n) for n in spans)+'根已记录H1'
    if counts.get('same_bar') or counts.get('later_line'):
        note_text+='，分界点A待核'
    return note_text
