"""Verify the deployed candidate against saved November baseline and oracle."""
from pathlib import Path
import json,hashlib,time,shutil
B=Path(__file__).parent;R=B/'runtime/bridge';V=B/'verification/outer_gap_20261118';P=V/'november_before';scope='102923304041429_3600'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((R/'worker_identity.json').read_text('utf8'))
assert identity['script_sha256']==sha(B/'worker.py')
assert sha(B/'outer_gap_candidate.py')==json.loads((V/'november_acceptance.json').read_text('utf8'))['candidate_sha256']
assert (R/f'request_{scope}.tsv').read_bytes()==(P/f'request_{scope}.tsv').read_bytes()
path=R/f'audit_{scope}.json';assert path.stat().st_mtime>=identity['started']
audit=json.loads(path.read_text('utf8'));expected=json.loads((V/'november_expected_results.json').read_text('utf8'))
assert audit['results']==expected,'Deployed results differ from reviewed candidate'
assert audit['full_model']['available']
old=json.loads((P/f'full_model_{scope}.json').read_text('utf8'));new=json.loads((R/f'full_model_{scope}.json').read_text('utf8'))
assert old==new,'Original full H1/M15 model changed'
companion=R/f'companion_{scope}'
heartbeat=(companion/'heartbeat.tsv').read_text('utf8').strip().split('\t')
assert heartbeat[3]==audit['token'] and heartbeat[5]==heartbeat[8]=='snapshot','Companion status is stale/pending'
assert (R/f'progress_{scope}.txt').read_text('utf8').startswith(audit['token']+'\t完成')
reply_header=(companion/'viewport_102923304041429_H1.reply.tsv').read_text('utf-8-sig').splitlines()[0].split('\t')
loaded_header=(companion/'viewport_102923304041429_H1.loaded.tsv').read_text('utf-8-sig').splitlines()[0].split('\t')
# The final header field is wall-clock computation time; a cache re-export
# changes it without changing token, bounds, verdict, bar/shape counts.
assert len(reply_header)==len(loaded_header)==14 and reply_header[:2]==['IPDA_VIEW','1']
assert reply_header[:13]==loaded_header[:13],'Companion loaded identity/geometry summary differs'
assert float(reply_header[13])>=0 and float(loaded_header[13])>=0
state=(R/f'render_state_{scope}.tsv').read_text('utf-8-sig').strip().split('\t')
assert state[3:6]==[audit['token'],audit['token'],'full'] and state[7:11]==['0','1','1','1']
assert int(state[12])>=identity['started'] and time.time()-int(state[12])<120
out=V/'deployed';out.mkdir(exist_ok=True)
for name in ['worker_identity.json',f'request_{scope}.tsv',f'audit_{scope}.json',f'reply_{scope}.tsv',f'render_state_{scope}.tsv',f'continuation_render_{scope}.tsv',f'experiment_{scope}.png']:
 shutil.copy2(R/name,out/name)
receipt={'passed':True,'worker_pid':identity['pid'],'worker_sha256':identity['script_sha256'],'candidate_sha256':sha(B/'outer_gap_candidate.py'),
         'token':audit['token'],'records':len(expected),'reviewed_candidate_exact':True,'original_full_H1_M15_model_exact':True,'fresh_native_render':True,'elapsed_seconds':audit['elapsed_seconds'],
         'companion_snapshot_current':True,'complete_progress_current':True,
         'companion_loaded_header_semantics_exact':True,'companion_elapsed_reply_loaded':[reply_header[13],loaded_header[13]],
         'scope':'Current November H1 viewport; coordinate and visual checks are separate required evidence.'}
(V/'deployment_acceptance.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8');print(json.dumps(receipt))
