"""Causal dual-line replay over the two summer H1 chart examples, before parameter changes."""
import hashlib
import json
from collections import Counter
from pathlib import Path

from book_pair_recovery import observe
from book_viewport_structure import inspect_close, stamp
from test_book_pair_recovery import history

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'verification/book_summer_replay_20261118'
FIRST, END = '2026-07-27','2026-08-08'


def event_identity(p):
    return (tuple(p['origin']),tuple(p['terminal']),p['direction'],tuple(map(tuple,p['trend'])),
            tuple(map(tuple,p['turning'])),p['event'],p['trend_break_bar'],p['turning_break_bar'])


def sweep():
    OUT.mkdir(exist_ok=True)
    bars=history()
    index={stamp(b.time):i for i,b in enumerate(bars)}
    positions=[i for i,b in enumerate(bars) if FIRST<=stamp(b.closed_at)[:10]<END]
    output=[]
    for i in positions:
        windows={}
        for n in (256,512):
            report=inspect_close(bars[i-n+1:i+1])
            events=[p for p in report.get('pairs',[]) if p['event'] not in ('unknown','no_new_cross')]
            windows[n]=dict(status=report['status'],counts=report.get('counts',{}),events=events)
            if n==512:
                recent=observe(bars,index,i,min(i+3,positions[-1]),report)
        w1,w2=windows.values()
        same={event_identity(p) for p in w1['events']}=={event_identity(p) for p in w2['events']}
        output.append(dict(clock=stamp(bars[i].closed_at),windows=windows,events_agree=same,following=recent))
    meta=dict(start=FIRST,end_exclusive=END,closed_bars=len(positions),
              history_sha256=hashlib.sha256((ROOT/'testdata/native_history_H1.tsv').read_bytes()).hexdigest(),
              source_sha256=hashlib.sha256((ROOT/'book_viewport_structure.py').read_bytes()).hexdigest(),
              counts=dict(Counter(p['event'] for r in output for p in r['windows'][512]['events'])),
              gap=sum(r['windows'][512]['status']=='gap' for r in output),
              differing_closes=sum(not r['events_agree'] for r in output),
              same_bar_closes=sum(bool(r['following']) for r in output))
    (OUT/'summer_prefixes.json').write_text(json.dumps(dict(summary=meta,rows=output),ensure_ascii=False,indent=2),'utf8')
    print(meta,flush=True)


if __name__=='__main__':
    sweep()

