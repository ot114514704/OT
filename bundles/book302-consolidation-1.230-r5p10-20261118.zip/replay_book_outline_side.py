"""Replay native adaptive PA rail fits and check displayed exits against actual H1 closes."""
import csv
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from research_cases import load_bars
from worker import pa_note, recognize, NativeBar, parse_request

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'verification/book_outline_side_20261118'
HISTORY=ROOT/'testdata/native_history_H1.tsv'
EXPORT=ROOT/'verification/native_initial/CompanionBookThreePushPA_102923304041429.tsv'
def utc(t):
    return datetime.fromtimestamp(t,timezone.utc).isoformat()

def fit(points,bars,strict):
    a,b=points[0][0],points[-1][0]
    scale=sum(k.high-k.low for k in bars[max(0,a-30):a])/min(30,a)
    direction=1 if points[0][1]<points[1][1] else -1
    h=1 if direction==1 else 0
    for first in range(1 if strict else 3):
        for second in range(1 if strict else 3):
            def rail(side,pair):
                x,y=points[side+(2 if pair==2 else 0)]
                xx,yy=points[side+(2 if pair==1 else 4)]
                slope=(yy-y)/(xx-x)
                return y+slope*(a-x),slope
            u,us=rail(h,first if h==0 else second)
            l,ls=rail(1-h,second if h==0 else first)
            w=u-l;end=u+us*(b-a)-(l+ls*(b-a))
            if min(w,end)<=0 or min(direction*us,direction*ls)<=0:
                continue
            tol=max(scale*(.25 if strict else .5),min(w,end)*(.15 if strict else .35))
            if any(abs(y-((u+us*(i-a)) if j%2==h else (l+ls*(i-a))))>tol for j,(i,y) in enumerate(points)):
                continue
            inside=sum(max(k.open,k.close)<=u+us*(i-a)+tol and min(k.open,k.close)>=l+ls*(i-a)-tol for i,k in enumerate(bars[a:b+1],a))
            if inside/(b-a+1)<(.85 if strict else .7):
                continue
            tolerance=.15 if strict else .25
            geo='parallel' if abs(end-w)<=tolerance*w else 'converging' if end<(1-tolerance)*w else None
            if geo:
                return dict(u=u,l=l,us=us,ls=ls,shape=geo,width_change=(end-w)/w,body_share=inside/(b-a+1),pairs=[first,second])

def main():
    raw=EXPORT.read_text('utf-16').splitlines()
    cutoff=int(next(l.split('\t')[1] for l in raw if l.startswith('cutoff\t')))
    start=next(i for i,l in enumerate(raw) if l.startswith('known\tstart\t'))
    native=[r for r in csv.DictReader(raw[start:],delimiter='\t') if r['category'] in ('1','2','3','4')]
    raw_request=(OUT/'request.tsv').read_text('utf-8-sig')
    native_request=parse_request(raw_request)
    point=float(raw_request.splitlines()[0].split('\t')[8])
    base=[NativeBar(k.time,k.open,k.high,k.low,k.close,k.spread*point,3600) for k in load_bars(HISTORY)]
    bar_map={b.time:b for b in base}
    for k in native_request['bars']:
        other=bar_map.get(k.time)
        if other:
            assert (k.open,k.high,k.low,k.close)==(other.open,other.high,other.low,other.close)
        else:
            bar_map[k.time]=k
    bars=[k for _,k in sorted(bar_map.items()) if k.closed_at.timestamp()<=cutoff]
    pos={int(b.time.timestamp()):i for i,b in enumerate(bars)}
    records=[]
    for r in native:
        pts=[(pos[int(t)],float(p)) for t,p in (x.split('@') for x in r['original_anchors'].split(';'))]
        a,b=pts[0][0],pts[-1][0]
        direction=1 if pts[1][1]>pts[0][1] else -1
        assert all(y==getattr(bars[i],'low' if (j%2==0)==(direction==1) else 'high') for j,(i,y) in enumerate(pts))
        g=fit(pts,bars,False);assert g
        state,clock,side=0,0,0
        exit_bar=None
        for i in range(b+1,len(bars)):
            u=g['u']+g['us']*(i-a);l=g['l']+g['ls']*(i-a)
            if u<=l:
                state=3
                break
            side=1 if bars[i].close>u else -1 if bars[i].close<l else 0
            if side:
                clock=int(bars[i].closed_at.timestamp())
                state=3 if clock<int(r['known']) else 1 if side==-direction else 2
                exit_bar=dict(close=bars[i].close,upper=u,lower=l)
                break
        assert (state,clock)==(int(r['state']),int(r['event'])),r['start']
        known=int(r['known'])
        p=dict(event_id='__CURRENT',category=int(r['category']),trend=0,direction=direction,state=state,start=int(r['start']),end=int(r['end']),known=known,event=clock)
        def note(t):
            return pa_note([p],dict(id='__CURRENT',clock=t),None,t-3600,[])
        item=dict(start=utc(p['start']),end=utc(p['end']),category=p['category'],known=utc(known),
                  crossing=utc(clock) if clock else None,state=state,side=side,fit=g,strict_rail_fit=fit(pts,bars,True),
                  exit_bar=exit_bar,note=note(cutoff),amplitudes=[round(abs(pts[j+1][1]-pts[j][1]),2) for j in (0,2,4)])
        if p['category']==4 and state in (1,2):
            assert ('上轨上方' if side==1 else '下轨下方') in item['note']
            if clock>known:
                assert '收盘越轨待核' in note(clock-1)
        records.append(item)
    target=json.loads((ROOT/'verification/september_channel_review/review.json').read_text('utf8'))['channel']
    def native_channel(horizon):
        t=datetime.fromisoformat(target['known_at'])
        end=next(i for i,k in enumerate(bars) if k.closed_at==t)
        batch=tuple(bars[end-horizon:end+1])
        before=recognize(batch[:-1])[0];at=recognize(batch)[0]
        assert not any(k['id']==target['id'] for k in before)
        found=next(k for k in at if k['id']==target['id'])
        assert found['active'] and found['rail_subtype']=='channel'
        return {k:found[k] for k in ('id','known','start','end','low','high','rail_subtype')}
    left=native_channel(256)
    assert native_channel(512)==left
    result=dict(source_sha256=hashlib.sha256(EXPORT.read_bytes()).hexdigest(),cutoff=utc(cutoff),left_channel=left,records=records)
    OUT.mkdir(exist_ok=True)
    (OUT/'native_rail_replay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
    print(len(records),Counter((r['state'],r['side']) for r in records if r['category']==4),left,flush=True)

if __name__=='__main__':
    main()
