"""Verify nine historical H1 bars against their own native M15 constituents."""
import json
from datetime import datetime,timedelta,timezone
import MetaTrader5 as mt
from screen_three_book_closes import OUT


def main():
    screen=json.loads((OUT/'screen.json').read_text('utf8'))
    checks=[]
    if not mt.initialize(path='C:/Program Files/MetaTrader 5/terminal64.exe',timeout=10000):
        raise RuntimeError(str(mt.last_error()))
    try:
        assert mt.terminal_info().connected and mt.account_info().server=='TradeMaxGlobal-Live'
        forming=int(mt.copy_rates_from_pos('XAUUSD',mt.TIMEFRAME_H1,0,1)[0]['time'])
        for window in screen['periods']:
            for case in window['cases']:
                side=1 if case['direction']=='down' else -1
                for row in case['values'][:3]:
                    stop=datetime.fromisoformat(row['clock'])
                    start=stop-timedelta(hours=1)
                    assert int(stop.timestamp())<=forming
                    bars=mt.copy_rates_range('XAUUSD',mt.TIMEFRAME_M15,start,stop-timedelta(seconds=1))
                    if bars is None or len(bars)!=4 or any(int(b['time'])!=int(start.timestamp())+k*900 for k,b in enumerate(bars)):
                        checks.append(dict(clock=row['clock'],owner=case['owner'],status='incomplete_native_quarters'))
                        continue
                    aggregate=[float(bars[0]['open']),float(max(bars['high'])),float(min(bars['low'])),float(bars[-1]['close'])]
                    if aggregate!=[row[k] for k in ('open','high','low','close')]:
                        checks.append(dict(clock=row['clock'],owner=case['owner'],status='hourly_ohlc_mismatch',aggregate=aggregate))
                        continue
                    quarters=[]
                    for b in bars:
                        close=float(b['close'])
                        quarters.append(dict(clock=datetime.fromtimestamp(int(b['time'])+900,timezone.utc).isoformat(),
                                             close=close,trend_outside=side*(close-row['trend'])>0,
                                             turning_outside=side*(close-row['turning'])>0))
                    checks.append(dict(clock=row['clock'],event=case['event'],owner=case['owner'],status='verified',quarters=quarters))
    finally:
        mt.shutdown()
    result=dict(verified=len({c['clock'] for c in checks if c['status']=='verified'}),
                method='Native M15 closes compared with fixed H1 levels at the corresponding H1 bar index.',
                cases=checks)
    (OUT/'native_quarters.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),'utf8')
    print(result['verified'],{c['status'] for c in checks})


if __name__=='__main__':
    main()

