"""Audit closed-bar exits of frozen native triangle candidates across the saved H1 archive."""
import json
from collections import Counter
from replay_august_overlap import HISTORY, OUT, SHAPES, load_bars, NativeBar
from ict_trader.native_triangles import observe_triangles


def main():
    bars = tuple(NativeBar(b.time, b.open, b.high, b.low, b.close, b.spread * .01, 3600)
                 for b in load_bars(HISTORY))
    positions = {b.time.isoformat(): i for i, b in enumerate(bars)}
    closes = {b.closed_at.isoformat(): i for i, b in enumerate(bars)}
    shapes = observe_triangles(bars, bars[-1].closed_at)['ranges']
    records = []
    for shape in shapes:
        geometry = shape['geometry']
        def rail(side, i):
            a, b = geometry[side]
            x, y = positions[a['time']], positions[b['time']]
            return a['price'] + (b['price'] - a['price']) * (i - x) / (y - x)
        streak = [0, 0]
        previous = [0, 0]
        first = [None, None]
        details = []
        begin = closes[shape['known_at']]
        last = closes[shape['end_at']]
        for i in range(begin + 1, last + 1):
            b = bars[i]
            lo, hi = rail('lower', i), rail('upper', i)
            if hi <= lo or (b.time - bars[i-1].closed_at).total_seconds() > 96*3600:
                break
            for n, margin in enumerate((0, .15 * shape['frozen_atr'])):
                side = 1 if b.close > hi + margin else -1 if b.close < lo - margin else 0
                streak[n] = streak[n] + 1 if side and previous[n] == side else int(bool(side))
                previous[n] = side
                if streak[n] == 2 and first[n] is None:
                    first[n] = {'time': b.closed_at.isoformat(), 'side': side}
            if shape['id'] == SHAPES['triangle']:
                details.append(dict(time=b.closed_at.isoformat(), close=b.close, lower=lo, upper=hi,
                                    geometric_side=previous[0], buffered_side=previous[1]))
        exit_side = {'向下离开三角观察区': -1, '向上离开三角观察区': 1}.get(shape['status'])
        if exit_side:
            assert first[1] == dict(time=shape['end_at'], side=exit_side), shape['id']
        else:
            assert first[1] is None, shape['id']
        row = dict(id=shape['id'], status=shape['status'], end=shape['end_at'],
                   geometric=first[0], buffered=first[1])
        if details:
            row.update(tolerance=.15*shape['frozen_atr'], detail=details)
        records.append(row)
    counts = Counter(r['status'] for r in records)
    missed = [r for r in records if r['geometric'] and not r['buffered']]
    result = dict(start=bars[0].time.isoformat(), end=bars[-1].closed_at.isoformat(), bars=len(bars),
                  candidates=len(records), status_counts=counts, two_raw_without_buffer=len(missed),
                  missed_by_status=Counter(r['status'] for r in missed),
                  target=next(r for r in records if r['id']==SHAPES['triangle']), records=records)
    (OUT/'triangle_exit_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
    print({k:v for k,v in result.items() if k not in ('records','target')})
    print(result['target']['tolerance'])

if __name__=='__main__':
    main()
