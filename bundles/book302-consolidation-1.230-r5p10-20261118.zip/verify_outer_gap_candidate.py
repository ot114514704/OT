"""Saved-native acceptance of additive post-gap outer handoffs."""
from pathlib import Path
from unittest.mock import patch
import copy,json,hashlib,time,sys
import worker
from continuation import observe
from outer_gap_candidate import handoff_chain
from research_cases import load_bars
from audit_multidate_continuation import check_observation,check_outer

B=Path(__file__).parent;V=B/'verification/outer_gap_20261118';V.mkdir(exist_ok=True)
sys.stdout.reconfigure(encoding='utf8');began=time.perf_counter()
raw=load_bars(B/'testdata/native_history_H1.tsv')
bars=[worker.NativeBar(b.time,b.open,b.high,b.low,b.close,b.spread,b.seconds) for b in raw]
cases=json.loads((B/'all_example_candidates.json').read_text('utf8'));native=[]
for choice in (0,1):
 c=cases[choice];end=next(i+1 for i,b in enumerate(bars) if int(b.closed_at.timestamp())==c['clock']);start=max(0,int(c['original']['window'])-1100)
 prefix=tuple(bars[start:end]);window=bars[start:min(len(bars),end+240)];contexts,_=worker.recognize(prefix)
 event=dict(id=c['original']['id'],family=c['original']['family'],clock=c['clock'],known=int(c['original']['known']),state=c['original']['state'],line=c['line'],slope=c['slope'])
 r=worker.classify(event,prefix,contexts);snap=copy.deepcopy(r);checks=0;first=None
 for n in range(len(prefix),len(window)+1):
  cut=int(window[n-1].closed_at.timestamp());inner=observe(event,r,contexts,window[:n],cut)
  out=handoff_chain(event,{**r,'continuation':inner},contexts,window[:n],cut)
  check_observation(inner,event,contexts,window[:n],cut);check_outer(out,event,inner,contexts,window[:n],cut)
  future=handoff_chain(event,{**r,'continuation':inner},contexts,window,cut)
  assert out==future
  if out and first is None:first=out
  if out:
   assert out['segments'][0]['start']>inner['end'],'Gap was bridged'
  checks+=1
 assert r==snap and first is not None
 row={'case':choice,'prefix_checks':checks,'first_handoff':first,'final_handoff':out,'event':event}
 native.append(row);print(json.dumps({'case':choice,'prefix_checks':checks,'handoff_known':first['known']}),flush=True)
(V/'native_cases.json').write_text(json.dumps(native,ensure_ascii=False,indent=2),'utf8')

req=worker.parse_request((B/'verification/native_dense_performance_20261118/deployed/request_102923304041429_3600.tsv').read_text('utf-8-sig'))
before=json.loads((B/'verification/native_dense_performance_20261118/deployed/audit_102923304041429_3600.json').read_text('utf8'))['results']
with patch.object(worker,'outer_handoff',handoff_chain):
 after=worker.solve(req,lambda message:print(message,flush=True))
from research_adapter import summary
report=json.loads((B/'verification/native_r3/final/full_model_102923304041429_3600.json').read_text('utf8'))['report']
for row in after:
 row['detail']+='；'+(summary(report,'H1') if row['id']=='__CURRENT' else '原研究全模型只作当前快照旁证，不回填此历史事件')
(V/'current_request_results.json').write_text(json.dumps(after,ensure_ascii=False,indent=2),'utf8')
assert len(before)==len(after)
changes=[]
for a,z in zip(before,after):
 assert {k:v for k,v in a.items() if k not in ('outer_continuation','follow')}=={k:v for k,v in z.items() if k not in ('outer_continuation','follow')},a['id']
 old,new=a.get('outer_continuation'),z.get('outer_continuation')
 if old:
  assert new
  assert new['segments'][:len(old['segments'])]==old['segments'],('Prior segment changed',a['id'])
  assert new['range_chain'][:len(old['range_chain'])]==old['range_chain'],('Prior handoff changed',a['id'])
 if old!=new:changes.append({'id':a['id'],'prior_segments':len(old['segments']) if old else 0,'new_segments':len(new['segments']) if new else 0})
(V/'current_request_results.json').write_text(json.dumps(after,ensure_ascii=False,indent=2),'utf8')
receipt={'passed':True,'native_cases':2,'native_prefix_checks':sum(r['prefix_checks'] for r in native),'current_request_records':len(after),
         'original_classification_inner_and_existing_outer_segments_unchanged':True,'changes':changes,
         'elapsed_seconds':time.perf_counter()-began,
         'source_sha256':{p:hashlib.sha256((B/p).read_bytes()).hexdigest() for p in ('outer_gap_candidate.py','worker.py','outer_continuation.py','continuation.py')},
         'deployed':False,'limits':['Saved native cases and current request only. No native display acceptance of new gap segments yet.','Independent original Book anchors and inner segments remain unchanged; added outer segments are experimental observations, not reversals.']}
(V/'acceptance.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(receipt,ensure_ascii=False),flush=True)
