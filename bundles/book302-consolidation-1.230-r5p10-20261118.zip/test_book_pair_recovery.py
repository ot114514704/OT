"""Replay pre-frozen Book dual breaks as each later close actually arrives."""
import csv
import json
import unittest
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

from worker import NativeBar
from book_viewport_structure import WINDOW, inspect_close, stamp
from book_pair_recovery import observe, summary

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'verification/book_recovery_r5p8'


def history():
    with (ROOT/'testdata/native_history_H1.tsv').open(encoding='utf-8-sig') as f:
        return [NativeBar(datetime.fromtimestamp(int(r['time']),timezone.utc),
                          *(float(r[k]) for k in ('open','high','low','close')),float(r['spread'])*.01,3600)
                for r in csv.DictReader(f,delimiter='\t')]


class FrozenRecovery(unittest.TestCase):
    def test_native_prefixes(self):
        bars=history()
        index={stamp(b.time):i for i,b in enumerate(bars)}
        baseline=json.loads((ROOT/'verification/book_panel_r5p7/frozen_pair_followthrough.json').read_text('utf8'))
        observations=[]
        for clock in sorted({r['clock'] for r in baseline['reports']}):
            i=next(i for i,b in enumerate(bars) if stamp(b.closed_at).startswith(clock+':'))
            pair_report=inspect_close(bars[i-WINDOW+1:i+1])
            for age in range(4):
                closed=bars[:i+age+1]
                pos={stamp(b.time):j for j,b in enumerate(closed)}
                got=observe(closed,pos,i,i+age,pair_report)
                self.assertEqual(got,observe(bars,index,i,i+age,pair_report))
                for item in got:
                    old=next(r for r in baseline['reports'] if r['owner']==item['owner'] and r['clock']==clock)
                    self.assertEqual([r['outside_both'] for r in item['observations']],
                                     [r['outside_both'] for r in old['records'][:age+1]])
                    self.assertEqual([r['turning'] for r in item['observations']],
                                     [r['turning'] for r in old['records'][:age+1]])
                if age==3:
                    observations.extend(got)
        self.assertEqual(len(observations),6)
        (OUT/'native_prefixes.json').write_text(json.dumps(observations,ensure_ascii=False,indent=2),'utf8')

    def test_touch_gap_and_mirror(self):
        for sign in (1,-1):
            prices=[10,11,12,6,7,10,14]
            anchor=datetime(2026,1,1,tzinfo=timezone.utc)
            def px(v): return 100+sign*v
            bars=[NativeBar(anchor+timedelta(hours=i),px(p),px(p),px(p),px(p),0,3600) for i,p in enumerate(prices)]
            pos={stamp(b.time):i for i,b in enumerate(bars)}
            def point(i,v): return [stamp(bars[i].time),px(v)]
            p=dict(owner='test',event='same_bar',direction='up' if sign==1 else 'down',terminal=[0,px(13)],
                   pair_known=stamp(bars[2].closed_at),trend=[point(0,9),point(1,9)],
                   turning=[point(0,12),point(1,12),point(2,7)])
            report=dict(clock=stamp(bars[3].closed_at),pairs=[p])
            def one(last, data=bars): return observe(data,pos,3,last,report)[0]
            self.assertIsNone(one(4)['first_reentry'])
            self.assertEqual(one(4)['observations'][-1]['turning_relation'],'touch')
            self.assertEqual(one(5)['first_reentry'],stamp(bars[5].closed_at))
            self.assertIsNone(one(5)['later_directional_extreme'])
            self.assertEqual(one(6)['later_directional_extreme'],stamp(bars[6].closed_at))
            gapped=bars[:5]+[replace(bars[5],time=bars[6].time)]
            gap=one(5,gapped)
            self.assertEqual(len(gap['observations']),2)
            self.assertEqual(gap['gap_at'],stamp(bars[6].time))
            self.assertIn('缺柱中止',summary([gap]))


if __name__=='__main__':
    unittest.main()

