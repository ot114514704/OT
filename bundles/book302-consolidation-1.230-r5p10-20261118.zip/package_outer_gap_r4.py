"""Immutable verified r4 backup; never rewrites a published prior bundle."""
from pathlib import Path
import hashlib,json,zipfile
B=Path(__file__).parent;V=B/'verification/outer_gap_20261118'
read=lambda p:json.loads(p.read_text('utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
required={p:read(V/p) for p in ('acceptance.json','november_acceptance.json','multidate/acceptance.json','deployment_acceptance.json','deployed/native_readiness.json','deployed/visual_acceptance.json','regressions.json','return_view_fix.json')}
assert all(x['passed'] for x in required.values())
assert required['multidate/acceptance.json']['candidate_gap_handoff']
assert required['deployment_acceptance.json']['worker_sha256']==sha(B/'worker.py')
assert required['deployment_acceptance.json']['candidate_sha256']==sha(B/'outer_gap_candidate.py')
provenance=read(B/'FUSION_PROVENANCE.json')
assert all(sha(Path(p))==h for p,h in provenance['production_files_unchanged'].items())
assert all(sha(B/'source/book_native'/p)==h for p,h in provenance['book_headers'].items())
metadata={'revision':'1.230-r4','native_protocol_version':'1.230; unchanged r3 rendering protocol',
          'change':'Separate causal outer-range observation after an inner gap_exit; never bridge missing bars.',
          'source_sha256':{p:sha(B/p) for p in ('worker.py','outer_gap_candidate.py','outer_continuation.py','continuation.py')},
          'evidence':required,'production_files_unchanged':70,'book_core_headers_unchanged':41,
          'limits':['Selected native historical cases, not all-history accuracy.','Full-model latency and original broad goal remain open.'], 'uploaded_at_packaging':False}
(B/'REVISION_R4.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),'utf8')
readme='''Book＋盘整融合实验 1.230-r4，2026-11-18

修复一类盘整内断头：缺口后内层已离区，但连续两根已收盘实体仍在事前已知且严格包容的外层范围内时，从第二根确认柱单独开始外层续观。此前外层已经终止、超过96小时间隔、只有影线回区、范围事后才出现、交叠但不包容，均不续接。原Book端点、原内层续线、已有外层线段及分类保持不变；缺失区间保持空白，不合并范围，也不代表三推反转确认。

两个原生11月样本的243个逐根截断位置通过；当前11月H1视窗107条记录只增加两组共四段外层续观。此前10月视窗111条结果完全不变。42个已筛选原生样本做9883个逐根检查和863个未来后缀检查，保留原有线段；78项回归通过。结果不代表未采集日期、所有Book线族或整体识别准确率。

另修复翻页返回后的状态缓存：新请求发布pending时撤销旧的“已完成”标记，避免新请求被放弃后，返回旧视窗永远保留错误的重算提示。真实服务循环A→B→A测试先复现失败，修复后通过，另有15项相关检查。原生指标同token仍会缓存已加载回包；仅替换后台逻辑后需重载指标或前后翻页触发读取，本轮已翻页返回原视窗并逐坐标验证。

独立后台已接入 outer_gap_candidate.py，具体部署哈希及实图验收见 verification/outer_gap_20261118。MQL界面、Book41个核心文件和原生产70个文件保持原样，协议仍1.230/r3以兼容原生指标。当前实验保持H1，各自按钮保留；普通箱体、通道和三角布局不变。

回退：停止独立后台，恢复verification/outer_gap_20261118/before_deploy/worker.py，再启动；也可使用保留的r3p2备份完整恢复。旧ZIP均保留，不改写。此包内uploaded=false是打包前状态，后续真实发布以remote_receipt.json为准。

其他日期的实图检查、原始历史粒度/覆盖、精确手绘边界及完整模型延迟继续保留为未完成。没有下单、收益回测或新增无人值守监控。
'''
(B/'README_R4.txt').write_text(readme,'utf8')
prior=B.parent/'备份/Book302_盘整融合1.230-r3p2_普通盘整窗口复用_20261118.zip'
with zipfile.ZipFile(prior) as z:files={B/p for p in z.namelist() if p!='R3P2_PACKAGE_MANIFEST.json'}
files.update(p for p in V.rglob('*') if p.is_file())
files.update(p for p in (B/'verification/multidate_continuation_20261118').rglob('*') if p.is_file())
files.update(B/p for p in ('outer_gap_candidate.py','test_outer_gap_candidate.py','test_request_return.py','audit_multidate_continuation.py','diagnose_outer_gap_handoff.py','verify_outer_gap_candidate.py','verify_outer_gap_november.py','verify_outer_gap_deployment.py','package_outer_gap_r4.py','README_R4.txt','REVISION_R4.json'))
manifest=[{'path':p.relative_to(B).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
out=B.parent/'备份/Book302_盘整融合1.230-r4_缺口后外层续观_20261118.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,p.relative_to(B).as_posix())
 z.writestr('R4_PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
receipt={'path':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'files_verified':len(manifest),'uploaded':False,
         'git_blob_sha':hashlib.sha1(b'blob '+str(out.stat().st_size).encode()+b'\0'+out.read_bytes()).hexdigest()}
(B/'PACKAGE_R4.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8');print(json.dumps(receipt))
