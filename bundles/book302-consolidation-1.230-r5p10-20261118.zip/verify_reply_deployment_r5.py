"""Read-only deployment and preservation gates for the native reply refresh."""
from pathlib import Path
import hashlib,json,shutil,time,zipfile
B=Path(__file__).parent;R=B/'runtime/bridge';V=B/'verification/reply_refresh_r5'
S='102923304041429_3600';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf8'))
identity=read(R/'worker_identity.json');assert identity['script_sha256']==sha(B/'worker.py')
audit=read(R/f'audit_{S}.json')
assert (R/f'audit_{S}.json').stat().st_mtime>=identity['started']
assert audit['results']==read(B/'verification/outer_gap_20261118/november_expected_results.json')
assert audit['full_model']['available']
assert read(R/f'full_model_{S}.json')==read(B/f'verification/outer_gap_20261118/november_before/full_model_{S}.json')
assert (R/f'request_{S}.tsv').read_bytes()==(B/f'verification/outer_gap_20261118/november_before/request_{S}.tsv').read_bytes()
wire=(R/f'reply_{S}.tsv').read_text('utf8');header,payload=wire.split('\n',1)
h=header.split('\t');assert len(h)==9 and h[2]==audit['token'] and h[7]=='full'
assert h[8]==hashlib.sha256(payload.encode('utf8')).hexdigest()
revision=(R/f'reply_revision_{S}.tsv').read_text('utf-8-sig').strip().split('\t')
assert revision[2:5]==[audit['token'],'full',h[8]]
native=read(B/'verification/outer_full_request_r3/native_readiness.json');assert native['passed'] and native['request_token']==audit['token']
state=(R/f'render_state_{S}.tsv').read_text('utf-8-sig').strip().split('\t')
assert state[3:6]==[audit['token'],audit['token'],'full'] and state[7:11]==['0','1','1','1']
assert int(state[12])>=identity['started'] and time.time()-int(state[12])<120
c=R/f'companion_{S}'
heartbeat=(c/'heartbeat.tsv').read_text('utf8').strip().split('\t')
assert heartbeat[3]==audit['token'] and heartbeat[5]==heartbeat[8]=='snapshot'
assert (R/f'progress_{S}.txt').read_text('utf8').startswith(audit['token']+'\t完成')
rh=(c/'viewport_102923304041429_H1.reply.tsv').read_text('utf-8-sig').splitlines()[0].split('\t')
lh=(c/'viewport_102923304041429_H1.loaded.tsv').read_text('utf-8-sig').splitlines()[0].split('\t')
assert len(rh)==len(lh)==14 and rh[:13]==lh[:13]
provenance=read(B/'FUSION_PROVENANCE.json')
assert all(sha(Path(p))==v for p,v in provenance['production_files_unchanged'].items())
assert all(sha(B/'source/book_native'/p)==v for p,v in provenance['book_headers'].items())
before=(V/'before/BookExperimentGuard.mqh').read_text('utf-8-sig')
after=(B/'source/BookExperimentGuard.mqh').read_text('utf-8-sig')
def function(s,name):
 start=s.index('void '+name+'(');opening=s.index('{',start);depth=0
 for i in range(opening,len(s)):
  if s[i]=='{':depth+=1
  elif s[i]=='}':
   depth-=1
   if depth==0:return s[start:i+1]
 raise AssertionError('Unclosed function')
assert function(before,'BEXDraw')==function(after,'BEXDraw')
unchanged=[]
with zipfile.ZipFile(B.parent/'备份/Book302_盘整融合1.230-r4_缺口后外层续观_20261118.zip') as z:
 for name in z.namelist():
  if name.endswith('.ex5') and name!='source/Book302_Consolidation_Experiment.ex5' and (name.startswith('companions/') or name.startswith('native_scripts/')):
   assert (B/name).read_bytes()==z.read(name),name
   unchanged.append(name)
assert len(unchanged)==4
assert read(V/'native_refresh_acceptance.json')['passed']
out=V/'deployed';out.mkdir(exist_ok=True)
for name in ['worker_identity.json',f'request_{S}.tsv',f'audit_{S}.json',f'reply_{S}.tsv',f'render_state_{S}.tsv',f'continuation_render_{S}.tsv',f'reply_revision_{S}.tsv','reply_policy_tests.tsv',f'experiment_{S}.png']:
 shutil.copy2(R/name,out/name)
shutil.copy2(B/'verification/outer_full_request_r3/native_readiness.json',out/'native_readiness.json')
report={'passed':True,'revision':'1.230-r5','worker_pid':identity['pid'],'worker_sha256':sha(B/'worker.py'),
        'experiment_ex5_sha256':sha(B/'source/Book302_Consolidation_Experiment.ex5'),
        'result_records':len(audit['results']),'results_exact_r4':True,'original_full_H1_M15_model_exact':True,
        'book_headers_unchanged':41,'production_files_unchanged':len(provenance['production_files_unchanged']),
        'BEXDraw_unchanged':True,'unchanged_other_ex5':unchanged,'fresh_native_coordinates':native,
        'companion_snapshot_current':True,'companion_loaded_semantics_exact':True,
        'full_model_elapsed_seconds':audit['elapsed_seconds'],'native_reply_revision':revision}
(V/'deployment_acceptance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(report,ensure_ascii=False))
