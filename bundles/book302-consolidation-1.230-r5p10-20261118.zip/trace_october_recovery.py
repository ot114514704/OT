"""Check when the October 1 internal counterleg was available on its parent wave."""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from book_viewport_structure import inspect_close, load_reference, stamp
from replay_book_adjustment_A import response
from test_book_pair_recovery import history, OUT


def main():
    bars=history()
    i=next(i for i,b in enumerate(bars) if stamp(b.closed_at)=='2026-10-01T06:00:00Z')
    ref=next(p for p in inspect_close(bars[i-511:i+1])['pairs'] if p['event']=='same_bar')
    checks=[]
    for n in (256,512,768):
        for end in range(i-3,i+1):
            data=bars[i-n+1:end]
            cutoff=stamp(data[-1].closed_at)
            rows=[dict(timestamp_utc=stamp(b.time),timeframe='H1',symbol='XAUUSD',provider='MT5_experiment',
                       open=b.open,high=b.high,low=b.low,close=b.close) for b in data]
            scopes=load_reference()[0](rows,'H1',cutoff)
            parents=[o for o in scopes['active'] if o['origin']==ref['origin'] and o['terminal']==ref['terminal']]
            children=[]
            if parents:
                assert len(parents)==1
                children=[response(o,rows,ref['direction']) for o in scopes['active']+scopes['retired']
                          if o.get('parent_scope_id')==parents[0]['scope_id'] and o.get('terminal') and
                          o['direction']!=ref['direction'] and o['membership_known_at_utc']<=cutoff]
                children.sort(key=lambda c:c['extreme'])
            child=children[-1] if children else None
            fresh=bool(child and sum(c['extreme']==child['extreme'] for c in children)==1 and
                       child['relation']=='internal_return_stage' and child['resumed_close_time'] and
                       child['retirement_state']=='completed_excursion_before_origin_breach' and
                       not any(r['close']>child['price'] for r in rows if r['timestamp_utc']>child['extreme']))
            checks.append(dict(lookback=n,clock=cutoff,parent_visible=bool(parents),latest_child=child,
                               observable_completed_candidate=fresh))
    by_clock={c['clock']:{(x['observable_completed_candidate'], x['latest_child']['price'] if x['latest_child'] else None)
              for x in checks if x['clock']==c['clock']} for c in checks}
    source=next(c['latest_child'] for c in checks if c['lookback']==512 and c['clock']==stamp(bars[i].time))
    values=[dict(clock=stamp(b.closed_at),high=b.high,close=b.close,close_above=b.close>source['price']) for b in bars[i:i+4]]
    record=dict(checks=checks,reference=source['price'],source_direction=ref['direction'],
                warmup_equal=all(len(s)==1 for s in by_clock.values()),after=values,author_degree_verified=False)
    (OUT/'october_A.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),'utf8')
    print(record['reference'],record['warmup_equal'],[(k,str(v)) for k,v in by_clock.items()],values)
    events=json.loads((OUT/'native_prefixes.json').read_text('utf8'))
    plt.rcParams.update({'font.sans-serif':['Microsoft YaHei'],'axes.unicode_minus':False})
    fig,axes=plt.subplots(1,2,figsize=(11,4.5),layout='constrained')
    for ax,day,title in zip(axes,('10-01','10-02'),('10 月 1 日　下一根才收过调整高点候选','10 月 2 日　下一根收回拐点线上方')):
        event=next(r for r in events if r['event'][5:10]==day)
        pts=event['observations']
        for key,label,color in [('close','H1 收盘','#222222'),('trend','冻结趋势线','#305b9c'),('turning','冻结拐点线','#987040')]:
            ax.plot(range(4),[r[key] for r in pts],marker='o' if key=='close' else None,label=label,color=color,lw=2)
        if day=='10-01':
            ax.axhline(record['reference'],ls='--',color='#168060',label=f"调整高点候选 {record['reference']:.2f}")
        ax.set_xticks(range(4),[r['clock'][11:16] for r in pts])
        ax.set_xlabel('MT5 的 H1 收盘时刻')
        ax.set_ylabel('XAUUSD 价格')
        ax.set_title(title)
        ax.legend(fontsize=9)
        ax.grid(alpha=.18)
    fig.savefig(OUT/'双破后收盘对照.png',dpi=145)
    plt.close(fig)


if __name__=='__main__':
    main()

