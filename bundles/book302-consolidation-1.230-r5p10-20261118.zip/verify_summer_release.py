"""Verify the active H1 worker response and independently replay the July window through its request protocol."""
import json
from pathlib import Path

from book_pair_recovery import summary
from package_book_outline_side import ROOT,KEY,BRIDGE,tsv,read,sha
from replay_summer_book import OUT,history
from verify_pair_recovery import live
from book_viewport_structure import stamp
from worker import parse_request,solve,encode_reply


def check_native():
    before=OUT/'before'
    req=f'request_{KEY}.tsv'
    assert (before/req).read_bytes()==(BRIDGE/req).read_bytes()
    old,new=[read(d/f'audit_{KEY}.json') for d in (before,BRIDGE)]
    old_lines,lines=[tsv(d/f'reply_{KEY}.tsv') for d in (before,BRIDGE)]
    header=lines[0].split('\t')
    rev=tsv(BRIDGE/f'reply_revision_{KEY}.tsv')[0].split('\t')
    render=tsv(BRIDGE/f'render_state_{KEY}.tsv')[0].split('\t')
    identity=read(BRIDGE/'worker_identity.json')
    assert identity['script_sha256']==sha((ROOT/'worker.py').read_bytes())
    assert min(int(rev[5]),int(render[12]))>=int(identity['started'])
    assert header[2]==old['token']==new['token']==rev[2]==render[3]==render[4]
    assert header[7]==rev[3]==render[5]=='full' and new['full_model']['available']
    assert header[8]==rev[4]==sha(('\n'.join(lines[1:])+'\n').encode())
    assert len(lines)==len(old_lines) and len(old['results'])==len(new['results'])==int(header[3])
    assert int(render[11])==sum(line.startswith('C\t') for line in lines)
    changes=[]
    for a,b in zip(old['results'],new['results']):
        if a==b: continue
        assert b.get('book_pair_recovery') and 'follow' in b
        assert {k:v for k,v in a.items() if k not in ('book_pair_recovery','follow')}=={
            k:v for k,v in b.items() if k not in ('book_pair_recovery','follow')}
        old_note=a['follow'].split('。',1)[1] if a.get('book_pair_recovery') else a['follow']
        prefix=summary(b['book_pair_recovery'])+'。'
        assert b['follow']==prefix+old_note
        changes.append(dict(id=b['id'],follow=prefix))
    for a,b in zip(old_lines[1:],lines[1:]):
        aa,bb=a.split('\t'),b.split('\t')
        if aa[0]=='R':bb[14]=aa[14]
        assert aa==bb
    return dict(rows=len(new['results']),continuations=int(render[11]),changes=changes,
                loaded_at=render[12],revision=rev[4],worker=identity['script_sha256'])


def requests():
    bars=history()
    i=next(j for j,b in enumerate(bars) if stamp(b.closed_at)=='2026-07-29T21:00:00Z')
    samples=[]
    for end in range(i,i+5):
        portion=bars[i-511:end+1]
        clock=int(portion[-1].closed_at.timestamp())
        token=f'summer-real-request-{clock}'
        rows=[f'BEXP\t1\t{token}\t3600\t{clock}\t{len(portion)}\tsummer\tXAUUSD\t0.01']
        rows.extend('\t'.join(map(str,('B',int(b.time.timestamp()),b.open,b.high,b.low,b.close,round(b.spread/.01)))) for b in portion)
        request=parse_request('\n'.join([*rows,'END\t'+token]))
        results=solve(request)
        current=results[-1]
        assert current['id']=='__CURRENT'
        observations=current.get('book_pair_recovery',[])
        assert all(o['observations'][-1]['clock']<=stamp(portion[-1].closed_at) for o in observations)
        data=[o for o in observations if o.get('consecutive_break')]
        assert len(data)==(0 if end==i else 3)
        assert all(o['event']=='2026-07-29T22:00:00Z' and o['consecutive_break']['first_close']=='2026-07-29T21:00:00Z'
                   for o in data)
        assert current['follow'] in encode_reply(request,results,0)
        samples.append(dict(clock=stamp(portion[-1].closed_at),sequential=len(data),follow=current['follow']))
    return samples


if __name__=='__main__':
    for name,fn in [('native',check_native),('requests',requests),('live',live)]:
        result=fn()
        (OUT/(name+'.json')).write_text(json.dumps(result,indent=2,ensure_ascii=False),'utf8')
        print(name,result,flush=True)

