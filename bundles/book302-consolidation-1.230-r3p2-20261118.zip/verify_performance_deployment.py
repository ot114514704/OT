"""Read-only finite worker-deployment receipt comparison."""
from pathlib import Path
import hashlib,json,time,shutil,argparse

B=Path(__file__).parent;R=B/'runtime/bridge'
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=B/'verification/performance_r3_20261118')
V=parser.parse_args().output_dir
V.mkdir(parents=True,exist_ok=True)
old=B/'verification/native_r3/final';scope='102923304041429_3600'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((R/'worker_identity.json').read_text('utf8'))
assert identity['script_sha256']==sha(B/'worker.py')
audit_path=R/f'audit_{scope}.json'
assert audit_path.stat().st_mtime>=identity['started'],'New worker has not published a complete audit yet'
raw=(R/f'request_{scope}.tsv').read_text('utf-8-sig')
assert raw==(old/f'request_{scope}.tsv').read_text('utf-8-sig'),'Viewport/input changed; needs a new baseline'
token=raw.splitlines()[0].split('\t')[2]
before=json.loads((old/f'audit_{scope}.json').read_text('utf8'))
after=json.loads(audit_path.read_text('utf8'))
assert before['token']==after['token']==token and after['full_model']['available']
assert before['results']==after['results'],'Recognition or continuation result differs'
prior=json.loads((old/f'full_model_{scope}.json').read_text('utf8'))
latest=json.loads((R/f'full_model_{scope}.json').read_text('utf8'))
assert latest['token']==prior['token']==token
assert latest['charts']==prior['charts'],'H1/M15 chart payload differs'
assert latest['report']==prior['report'],'Full model interpretation differs'
state=(R/f'render_state_{scope}.tsv').read_text('utf-8-sig').strip().split('\t')
assert state[3:6]==[token,token,'full'] and state[7:11]==['0','1','1','1']
assert int(state[12])>=identity['started'],'Native receipt predates this worker restart'
loaded=R/'companion_102923304041429_3600'
assert (loaded/'viewport_102923304041429_H1.loaded.tsv').read_text('utf-8-sig').splitlines()[0]==(loaded/'viewport_102923304041429_H1.reply.tsv').read_text('utf-8-sig').splitlines()[0]
out=V/'deployed';out.mkdir(exist_ok=True)
for name in ['worker_identity.json',f'audit_{scope}.json',f'request_{scope}.tsv',f'reply_{scope}.tsv',f'render_state_{scope}.tsv',f'continuation_render_{scope}.tsv']:
    shutil.copy2(R/name,out/name)
result={'passed':True,'worker_pid':identity['pid'],'worker_sha256':identity['script_sha256'],
        'request_token':token,'records_unchanged':len(after['results']),'full_H1_M15_chart_payloads_exact':True,
        'full_model_interpretation_exact':True,'fresh_native_render_after_restart':True,
        'elapsed_seconds':after['elapsed_seconds'],
        'scope':'One finite post-restart request. Exact old/new results and chart payloads; not universal latency, future uptime or another UI inspection.'}
(V/'deployment_acceptance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(result),flush=True)
