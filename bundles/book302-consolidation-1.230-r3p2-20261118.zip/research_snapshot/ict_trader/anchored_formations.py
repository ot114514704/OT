"""H1 formations anchored to an observed turn or a closed displacement.

Independent observers retain the first qualifying rails. Session closures have
no invented candles; geometries use native candle positions, as the MT5 chart.
"""
from copy import deepcopy
from statistics import median
from .core import visible
from .structural_ranges import candidate as channel_candidate,PARAMETERS as CHANNEL
from .long_geometry import candidate as convergence_candidate,indexed_line_value,native_axis_gap,PARAMETERS as CONVERGENCE

CHANNEL_VERSION='anchored_channel_candidate_v1'
CONVERGENCE_VERSION='anchored_convergence_candidate_v1'


def turning_point(bars,start,direction):
    if start<12 or start+2>=len(bars):return None
    pivot=bars[start];left=bars[start-12:start];right=bars[start+1:start+3]
    if not all(native_axis_gap(a.closed_at,b.time,3600) for a,b in zip(bars[start-12:start+3],bars[start-11:start+3])):return None
    if direction==1:
        valid=all(pivot.high>b.high for b in left) and all(pivot.high>=b.high for b in right);price=pivot.high
    else:
        valid=all(pivot.low<b.low for b in left) and all(pivot.low<=b.low for b in right);price=pivot.low
    if not valid:return None
    return dict(time=pivot.time.isoformat(),price=price,direction=direction,
                known_at=right[-1].closed_at.isoformat(),left_bars=12,right_bars=2)


def anchored_channel(bars,start,end,direction):
    window=bars[start:end+1]
    if not 16<=len(window)<=96:return None
    pivot=turning_point(bars[:end+1],start,direction)
    if pivot is None:return None
    if any(not native_axis_gap(a.closed_at,b.time,3600) for a,b in zip(window,window[1:])):return None
    # The turn must own the outer rail, rather than merely precede a later,
    # stronger turn inside a regression window.
    extreme=max(b.high for b in window) if direction>0 else min(b.low for b in window)
    if pivot['price']!=extreme:return None
    c=channel_candidate(window,'auto',qualified_only=True)
    if not c or not c['qualified'] or c['shape']!='tilted' or c['slope_per_bar']*direction>=0:return None
    edge=c['high'] if direction>0 else c['low']
    if abs(edge-pivot['price'])>.15*c['frozen_atr']:return None
    c['geometry']['starting_pivot']=pivot;c['checks']['confirmed_starting_pivot']=True
    c['checks']['starting_turn_owns_outer_rail']=True
    return c


def anchored_convergence(bars,start,end):
    window=bars[start:end+1]
    if start<1 or not 16<=len(window)<=48:return None
    prior=bars[start-1];first=window[0]
    body=abs(prior.close-prior.open);atr=median(b.high-b.low for b in window)
    if prior.closed_at!=first.time or body<1.2*atr or body<.6*(prior.high-prior.low) or abs(first.close-first.open)>.5*body:return None
    c=convergence_candidate(window,compact=True,edge_start=True,native_axis=True)
    if not c or c['geometry']['validation']['overlap_bars']<len(window)/2:return None
    c['metrics']['preceding_displacement']=dict(time=prior.time.isoformat(),known_at=prior.closed_at.isoformat(),
        open=prior.open,close=prior.close,body=body,direction=1 if prior.close>prior.open else -1)
    c['checks']['closed_displacement_then_small_body']=True
    c['missing'].append('周末和短休市只连接已观察边线，不验证缺柱期间的价格；回画边线不冒充当时已知边界')
    return c


def observe_anchored_formations(bars,asof):
    bars=visible(bars,asof)
    output=dict(structural_ranges=[],structural_current=[],geometric_ranges=[],geometric_current=[],history=[])
    if not bars or bars[0].seconds!=3600:return output
    if any(a.time>=b.time or a.seconds!=b.seconds for a,b in zip(bars,bars[1:])):raise ValueError('Ordered homogeneous H1 bars required')
    pending={};active={}
    for i,b in enumerate(bars):
        if i>=14:
            for direction in (1,-1):
                start=i-2
                if turning_point(bars[:i+1],start,direction):pending[('channel',start,direction)]=None
        if i>=1:
            prior=bars[i-1];body=abs(prior.close-prior.open)
            if body>0 and prior.closed_at==b.time and body>=.6*(prior.high-prior.low) and abs(b.close-b.open)<=.5*body:
                pending[('converging',i,0)]=None
        for key,box in list(active.items()):
            kind,start,direction=key;index=i-start;g=box['geometry']
            if kind=='channel':
                upper=box['high']+box['slope_per_bar']*index;lower=box['low']+box['slope_per_bar']*index
                margin=CHANNEL['breakout_atr']*box['frozen_atr']
            else:
                upper=indexed_line_value(g['upper'],index);lower=indexed_line_value(g['lower'],index)
                margin=CONVERGENCE['boundary_tolerance_atr']*box['frozen_atr']
            gap=not native_axis_gap(bars[i-1].closed_at,b.time,3600)
            side=1 if b.close>upper+margin else -1 if b.close<lower-margin else 0
            box['streak']=box['streak']+1 if side and side==box['side'] else int(bool(side))
            box.update(side=side,end_at=b.closed_at.isoformat())
            box.update(last_upper=upper,last_lower=lower,last_bar_index=index)
            reason='数据间隔中止锚定候选' if gap else '边线交会，锚定候选失效' if upper<=lower else ('向上离开锚定整理区' if side>0 else '向下离开锚定整理区') if box['streak']>=2 else None
            if reason:
                box.update(active=False,status=reason);del active[key]
                output['history'].append(dict(known_at=b.closed_at.isoformat(),event='anchored_formation_ended',range_id=box['id'],title=reason,detail='只结束独立候选，不充当IPDA或反转确认',confirmed_bar_only=True))
            elif not side:
                display=deepcopy(g);first=display['frame'][0];last=display['frame'][3]
                display['frame']=[first,dict(time=b.time.isoformat(),price=upper),dict(time=b.time.isoformat(),price=lower),last]
                display.update(display_through=b.closed_at.isoformat(),basis='frozen_rails_through_native_observed_bars')
                box['display_geometry']=display
        for key in list(pending):
            kind,start,direction=key;n=i-start+1
            if n>(96 if kind=='channel' else 48):del pending[key];continue
            # A fixed starting turn can never regain ownership after a later
            # observed bar exceeds it: every future window retains that bar.
            # This only retires unqualified pending starts, never active rails.
            if kind=='channel' and (b.high>bars[start].high if direction>0 else b.low<bars[start].low):
                del pending[key];continue
            if n<16:continue
            c=anchored_channel(bars,start,i,direction) if kind=='channel' else anchored_convergence(bars,start,i)
            if c is None:continue
            version=CHANNEL_VERSION if kind=='channel' else CONVERGENCE_VERSION
            prefix=version+(':'+('high' if direction>0 else 'low') if kind=='channel' else '')
            box={**deepcopy(c),'id':prefix+':'+str(n)+':'+b.closed_at.isoformat(),
                'active':True,'status':'转折起点通道候选' if kind=='channel' else '位移后完整收敛候选',
                'side':0,'streak':0,'end_at':b.closed_at.isoformat(),'last_bar_index':n-1}
            if kind=='channel':
                box.update(last_upper=box['high']+box['slope_per_bar']*(n-1),last_lower=box['low']+box['slope_per_bar']*(n-1))
            box['display_geometry']=deepcopy(box['geometry'])
            output['structural_ranges' if kind=='channel' else 'geometric_ranges'].append(box)
            active[key]=box;del pending[key]
            output['history'].append(dict(known_at=b.closed_at.isoformat(),event='anchored_formation_entered',range_id=box['id'],title=box['status'],detail='完整已观察整理段；边界首次满足条件时冻结；不计确认分',confirmed_bar_only=True))
    output['structural_current']=[v for k,v in active.items() if k[0]=='channel']
    output['geometric_current']=[v for k,v in active.items() if k[0]=='converging']
    return output
