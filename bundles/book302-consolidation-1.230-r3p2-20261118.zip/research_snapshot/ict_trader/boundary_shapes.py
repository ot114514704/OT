"""Independent closed-pivot channel/convergence candidates, not IPDA balance.

This observer separates a repeatedly tested price boundary from small-body
balance confirmation. Existing observers and their frozen records are untouched.
"""
from copy import deepcopy
from statistics import median
from .core import visible,instant

VERSION='native_boundary_shape_candidate_v1'
RADII=(2,4,8)
COUNTS=(4,6,8)


def pivots(bars,radius):
    out=[]
    for k in range(radius,len(bars)-radius):
        p=confirmed_pivot(bars,k,radius)
        if p:append_pivot(out,p)
    return out


def confirmed_pivot(bars,k,radius):
    b=bars[k];around=bars[k-radius:k]+bars[k+1:k+radius+1]
    hi=all(b.high>x.high for x in around)
    lo=all(b.low<x.low for x in around)
    if hi==lo:return None
    return dict(index=k,time=b.time.isoformat(),known_at=bars[k+radius].closed_at.isoformat(),
                price=b.high if hi else b.low,side=1 if hi else -1)


def append_pivot(out,p):
    if out and out[-1]['side']==p['side']:
        if p['side']*(p['price']-out[-1]['price'])>0:out[-1]=p
    else:out.append(p)


def qualify(bars,turns,radius,count):
    if len(turns)<count or not bars or bars[0].seconds!=3600:return None
    points=turns[-count:];start=points[0]['index'];end=len(bars)-1
    if not 12<=end-start+1<=160:return None
    segment=bars[start:]
    if any(a.seconds!=b.seconds or not 0<=(b.time-a.closed_at).total_seconds()<=96*3600 for a,b in zip(segment,segment[1:])):return None
    upper=[p for p in points if p['side']==1];lower=[p for p in points if p['side']==-1]
    if min(len(upper),len(lower))<2:return None
    def slope(ps):return (ps[-1]['price']-ps[0]['price'])/(ps[-1]['index']-ps[0]['index'])
    hs,ls=slope(upper),slope(lower)
    def rail(ps,s,k):return ps[0]['price']+s*(k-ps[0]['index'])
    u0,l0=rail(upper,hs,start),rail(lower,ls,start)
    u1,l1=rail(upper,hs,end),rail(lower,ls,end)
    width=u0-l0
    if min(width,u1-l1)<=0:return None
    ratio=(u1-l1)/width
    if hs*ls>0 and .75<=ratio<=1.25:
        subtype='channel'
        # A parallel envelope is explicitly fitted, not an invented pivot.
        hs=ls=(hs+ls)/2
        u0=max(b.high-hs*j for j,b in enumerate(segment))
        l0=min(b.low-ls*j for j,b in enumerate(segment))
        u1=u0+hs*(end-start);l1=l0+ls*(end-start);width=u0-l0
    elif ratio<=.85:
        flat=.05*width;du=u1-u0;dl=l1-l0
        subtype='ascending_triangle' if abs(du)<=flat<dl else 'descending_triangle' if abs(dl)<=flat and du<-flat else 'triangle' if du<0<dl else 'rising_wedge' if du>0 and dl>0 else 'falling_wedge' if du<0 and dl<0 else None
        if subtype is None:return None
    else:return None
    atr=median(b.high-b.low for b in segment)
    if atr<=0:return None
    tolerance=.15*atr;touch_tolerance=max(tolerance,.20*min(width,u1-l1))
    def value(high,k):return (u0 if high else l0)+(hs if high else ls)*(k-start)
    contacts=[]
    for p in points:
        if abs(p['price']-value(p['side']==1,p['index']))<=touch_tolerance:
            if not contacts or contacts[-1]['side']!=p['side']:contacts.append(p)
    wick=sum(value(False,k)-tolerance<=b.low and b.high<=value(True,k)+tolerance for k,b in enumerate(bars) if k>=start)/len(segment)
    close=sum(value(False,k)-tolerance<=b.close<=value(True,k)+tolerance for k,b in enumerate(bars) if k>=start)/len(segment)
    checks=dict(four_alternating_boundary_tests=len(contacts)>=4,
                two_tests_each_side=min(sum(p['side']==side for p in contacts) for side in (-1,1))>=2,
                structural_width=1.25<=min(width,u1-l1)/atr and max(width,u1-l1)/atr<=18,
                bounded_drift=max(abs(u1-u0),abs(l1-l0))<=2*width,
                wick_coverage=wick>=.90,close_coverage=close>=.95,
                last_close_inside=value(False,end)-tolerance<=bars[-1].close<=value(True,end)+tolerance,
                no_dominant_body=max(abs(b.close-b.open) for b in segment)<=.8*width)
    if not all(checks.values()):return None
    known=bars[-1].closed_at.isoformat()
    def point(k,price):return dict(time=bars[k].time.isoformat(),price=price)
    strip=lambda p:{k:v for k,v in p.items() if k!='index'}
    frame=[point(start,u0),point(end,u1),point(end,l1),point(start,l0)]
    anchors=([dict(**frame[0],known_at=known),dict(**frame[1],known_at=known)],
             [dict(**frame[3],known_at=known),dict(**frame[2],known_at=known)]) if subtype=='channel' else ([strip(upper[0]),strip(upper[-1])],[strip(lower[0]),strip(lower[-1])])
    gaps=[dict(after=a.closed_at.isoformat(),before=b.time.isoformat()) for a,b in zip(segment,segment[1:]) if a.closed_at!=b.time]
    geometry=dict(upper=anchors[0],lower=anchors[1],frame=frame,ready=True,validated=True,
       subtype=subtype,projected=False,axis='observed_native_bar_index',known_at=known,
       basis='frozen_pivot_supported_parallel_envelope' if subtype=='channel' else 'frozen_alternating_boundary_pairs',
       reason='至少四次交替的已确认边界测试；平行通道为支撑这些测试的冻结包络，收敛边界来自实际锚点；均非实体平衡确认',
       pivot_radius=radius,gaps=gaps,validation=dict(overlap_bars=len(segment),wick_coverage=wick,close_coverage=close,tolerance=tolerance))
    return dict(observed_from=segment[0].time.isoformat(),first_observed_at=known,known_at=known,
       window=len(segment),shape='converging',geometry=geometry,observed_high=max(b.high for b in segment),
       observed_low=min(b.low for b in segment),frozen_atr=atr,checks=checks,
       metrics=dict(boundary_radius=radius,boundary_count=count,boundary_tests=[strip(p) for p in contacts],
                    wick_coverage=wick,close_coverage=close,width_atr=width/atr),
       confirmed=False,score_included=False,missing=['独立价格边界候选，未通过IPDA实体平衡确认','后续方向及三推反转未确认']+(['缺口内价格路径与覆盖未知，未填造K线'] if gaps else []))


def observe(bars,asof):
    bars=visible(bars,asof)
    if not bars or bars[0].seconds!=3600:return {'ranges':[],'current':[],'history':[]}
    if any(a.time>=b.time or a.seconds!=b.seconds for a,b in zip(bars,bars[1:])):raise ValueError('Ordered homogeneous bars required')
    positions={b.time.isoformat():i for i,b in enumerate(bars)}
    ledgers={r:[] for r in RADII};active={};ranges=[]
    def rail(points,k):
        a,b=points;x,y=positions[a['time']],positions[b['time']]
        return a['price']+(b['price']-a['price'])*(k-x)/(y-x)
    for i,b in enumerate(bars):
        changed=set()
        for radius in RADII:
            if i<2*radius:continue
            p=confirmed_pivot(bars,i-radius,radius)
            if p:append_pivot(ledgers[radius],p);changed.add(radius)
        for radius in RADII:
            for count in COUNTS:
                key=(radius,count);box=active.get(key)
                if box:
                    g=box['geometry'];upper=rail(g['upper'],i);lower=rail(g['lower'],i)
                    gap=i and (b.time-bars[i-1].closed_at).total_seconds()>96*3600
                    side=1 if b.close>upper+.15*box['frozen_atr'] else -1 if b.close<lower-.15*box['frozen_atr'] else 0
                    box['streak']=box['streak']+1 if side and side==box['side'] else 1 if side else 0
                    box.update(end_at=b.closed_at.isoformat(),side=side)
                    if gap or upper<=lower or box['streak']>=2:
                        box.update(active=False,status='数据间隔中止' if gap else '边界交会结束' if upper<=lower else '向上离开边界观察区' if side>0 else '向下离开边界观察区');del active[key]
                    elif not side:
                        frame=deepcopy(g['frame']);frame[1]=dict(time=b.time.isoformat(),price=upper);frame[2]=dict(time=b.time.isoformat(),price=lower)
                        box['display_geometry']={**deepcopy(g),'frame':frame,'display_through':b.closed_at.isoformat()}
                    continue
                if radius not in changed:continue
                c=qualify(bars[:i+1],ledgers[radius],radius,count)
                if not c:continue
                # A shorter viewport may have a different first confirmed
                # turn. Its distinct formation must not overwrite another
                # frozen identity merely because both became known together.
                origin=int(instant(c['observed_from']).timestamp())
                box={**c,'id':f'{VERSION}:r{radius}:p{count}:s{origin}:'+b.closed_at.isoformat(),'active':True,
                     'end_at':b.closed_at.isoformat(),'status':'交替边界盘整候选','side':0,'streak':0}
                active[key]=box;ranges.append(box)
    return {'version':VERSION,'ranges':ranges,'current':list(active.values()),'history':[]}
