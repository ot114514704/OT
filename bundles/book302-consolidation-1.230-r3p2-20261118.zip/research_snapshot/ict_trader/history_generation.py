"""Calculation and archive identity; incompatible generations remain separate."""

CALCULATION_VERSION = 'viewport-history-1.17-backup-standard:preserved-layout-boundary-shapes-v24-20261116'
