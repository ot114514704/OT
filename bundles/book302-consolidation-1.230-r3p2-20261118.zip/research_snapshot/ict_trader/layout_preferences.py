"""User-specified local layout; select eligible records, never create geometry."""
import json
from pathlib import Path
from functools import lru_cache

@lru_cache(maxsize=1)
def preferences():
    path=Path(__file__).resolve().parents[1]/'research/layout_preferences.json'
    return json.loads(path.read_text('utf-8'))['rules'] if path.exists() else []

def reference_fit(row,region):
    x,y=int(row[13]),int(row[15]);l,h=region['left'],region['right']
    low=min(float(row[18]),float(row[20]));high=max(float(row[14]),float(row[16]));lo,hi=region['low'],region['high']
    return max(0,min(h,y)-max(l,x))/max(1,max(h,y)-min(l,x))*max(0,min(hi,high)-max(lo,low))/max(1,max(hi,high)-min(lo,low))

def apply_preferences(lines,baseline):
    from .display_selection import triangle_row,same_triangle_formation
    raw=[r.split('\t') for r in lines];chosen=[r.split('\t') for r in baseline]
    for rule in preferences():
        candidates=[]
        for a in raw:
            if a[11]!=rule['period'] or a[3]=='intraday':continue
            requested=rule['requested_shape']
            matches=(a[2]=='channel') if requested=='channel' else (a[2]=='converging' and float(a[16])<float(a[14]) and float(a[18])<float(a[20])) if requested=='falling_wedge' else triangle_row(a)
            if not matches:continue
            fit=reference_fit(a,rule['reference_bounds'])
            if fit>=rule['minimum_reference_fit']:candidates.append((a[12]==rule['preferred_record_id'],fit,-int(a[5]),a[1],a))
        if not candidates:continue
        a=max(candidates,key=lambda c:c[:4])[-1]
        if rule['requested_shape'] in ('triangle','falling_wedge'):
            # Only comparable alternatives for this marked formation change.
            chosen=[b for b in chosen if b[1]==a[1] or
                    (rule['requested_shape']=='triangle' and b[2]=='rectangle') or
                    not same_triangle_formation(a,b)]
        chosen=[b for b in chosen if b[1]!=a[1]]
        # Protocol extension is display metadata, outside frozen recognition.
        chosen.append(a[:24]+['USER_LAYOUT_V1'])
    return ['\t'.join(r) for r in sorted(chosen,key=lambda r:(int(r[5]),r[1]))]
