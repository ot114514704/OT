"""Read-only check of anchor-aware display rails against native closed bars."""
from .core import instant
from .long_geometry import indexed_line_value


def anchored_display_errors(box,bars):
    if not box.get('id','').startswith('anchored_'):return []
    errors=[]
    def require(ok,code):
        if not ok:errors.append(code)
    try:
        frozen=box['geometry'];display=box['display_geometry'];frame=display['frame']
        start=instant(box['observed_from']);end=instant(box['end_at'])
        source=[b for b in bars if start<=b.time and b.closed_at<=end]
        bytime={b.time:(i,b) for i,b in enumerate(source)}
        require(bool(source) and source[0].time==start,'display_source_coverage')
        require(display.get('projected') is False,'display_future_projection')
        require(len(frame)==4,'display_frame_size')
        if errors:return errors
        extended=display.get('basis')=='frozen_rails_through_native_observed_bars'
        ignored={'frame','basis','display_through'} if extended else set()
        require({k:v for k,v in display.items() if k not in ignored}==
                {k:v for k,v in frozen.items() if k not in ignored},'display_frozen_evidence_changed')
        require(extended or display==frozen,'display_extension_basis')
        require(frame[0]==frozen['frame'][0] and frame[3]==frozen['frame'][3],'display_start_changed')
        require(frame[0]['time']==frame[3]['time'] and frame[1]['time']==frame[2]['time'],'display_frame_alignment')
        if extended:
            require(instant(box['first_observed_at'])<=instant(display['display_through'])<=end,'display_extension_future')
            require(instant(frame[1]['time']) in bytime and
                    bytime[instant(frame[1]['time'])][1].closed_at==instant(display['display_through']),
                    'display_extension_not_closed_bar')
        for k,point in enumerate(frame):
            located=bytime.get(instant(point['time']))
            require(located is not None,'display_frame_not_observed')
            if located is None:continue
            i,b=located
            expected=(box['high' if k<2 else 'low']+box['slope_per_bar']*i
                      if box['shape']=='tilted' else indexed_line_value(frozen['upper' if k<2 else 'lower'],i))
            require(abs(point['price']-expected)<1e-6,'display_rail_refitted')
    except (KeyError,TypeError,ValueError,ZeroDivisionError):errors.append('display_geometry_invalid')
    return errors
