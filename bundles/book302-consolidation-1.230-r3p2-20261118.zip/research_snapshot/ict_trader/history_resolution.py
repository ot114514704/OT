"""Evidence-bound historical source review. No price or timestamp repair.

The bundled review documents a particular broker/symbol history snapshot.
It does not certify unlisted history. Revised OHLC at a previously conflicted
open still requires re-verification; a price revision is not resolution proof.
Archive exclusions bind to exact scope, input digest and original record bytes.
"""
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path


class ResolutionReview:
    def __init__(self, revision='', bars=(), exclusions=()):
        self.revision=revision
        self.times=frozenset(row['time'] for row in bars)
        self.exclusions=frozenset((r['scope'],r['evidence'],r['line_sha256']) for r in exclusions)

    def accept_record(self, scope, evidence, line):
        if not self.exclusions:return True
        return (scope,evidence,sha256(line.encode()).hexdigest()) not in self.exclusions

    def excluded(self, bar):
        return int(bar.time.timestamp()) in self.times


@lru_cache(maxsize=1)
def _reviews():
    raw=Path(__file__).with_name('history_resolution_evidence.json').read_bytes()
    data=json.loads(raw)
    if data['version']!='native-resolution-review-v1' or data['symbol']!='XAUUSD':
        raise ValueError('Invalid historical resolution review')
    revision=sha256(raw).hexdigest()
    return {(data['source'],period):ResolutionReview(revision,entry['conflict_bars'],entry['archive_exclusions'])
            for period,entry in data['periods'].items()}


def review_for(source, period):
    return _reviews().get((source,period),ResolutionReview())


def recognize_reviewed(request, recognize):
    review=review_for(request.get('source'),request['period'])
    bars=request['bars'];excluded=[review.excluded(b) for b in bars]
    if not any(excluded):return recognize(request)
    segments=[];segment=[]
    for bar,blocked in zip(bars,excluded):
        if blocked:
            if segment:segments.append(segment);segment=[]
        else:segment.append(bar)
    if segment:segments.append(segment)
    records=[];tail_state='证据不足：历史源周期待核验'
    for segment in segments:
        part=recognize({**request,'bars':segment})
        is_tail=segment[-1] is bars[-1]
        if is_tail:tail_state=part['state']
        for line in part['records']:
            if not is_tail:
                a=line.split('\t');a[10]='0'
                a[21]+='·数据缺口前历史观察'
                a[23]+='~n~后续源周期证据不足，不能解释为突破或失效'
                line='\t'.join(a)
            records.append(line)
    state=tail_state if excluded[-1] else '部分历史证据不足；'+tail_state
    return dict(records=records,state=state,count=len(bars),
                start=int(bars[0].time.timestamp()),end=int(bars[-1].closed_at.timestamp()),
                version='viewport-history-1.17-backup-standard',
                resolution_review=dict(revision=review.revision,excluded_bars=sum(excluded),
                    usable_bars=len(bars)-sum(excluded),valid_segments=len(segments),
                    status='source_resolution_review_required',historical_rows_preserved=True))
