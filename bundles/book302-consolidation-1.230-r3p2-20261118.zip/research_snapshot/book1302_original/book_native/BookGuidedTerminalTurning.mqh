#ifndef BOOK_GUIDED_TERMINAL_TURNING
#define BOOK_GUIDED_TERMINAL_TURNING
#include "BookGuidedScopePhases.mqh"
// A composite cannot reuse the same origin to flatten a previously broken
// impulse ruler with a later correction contact. This is a retrospective
// ownership test at parent.known, not a claim the pivot was confirmed at B.
// The independently owned child remains drawn by the ordinary detail path.
bool BKNGuideCrossedOriginRuler(const MqlRates &rows[],const BKNScope &parent,
 const BKNGuidedPair &whole,int seconds,datetime cutoff,BKNScope &prior){
 ZeroMemory(prior);
 if(!whole.valid||parent.ambiguous||!parent.envelope)return false;
 if(BKNGuideScopeReason(rows,parent.a.index,parent.b.index,parent.up,seconds,parent.known,cutoff)!="")return false;
 BKNPoint ledger[],points[];BKNScope legs[];
 if(!BKNSLedger(rows,seconds,parent.known,2,ledger)||!BKNSBuildPath(rows,ledger,seconds,parent.known,0,points,legs))return false;
 for(int i=0;i<ArraySize(legs);i++){
  BKNScope child;BKNScopeCopy(child,legs[i]);
  if(child.a.time!=parent.a.time||child.b.time>=parent.b.time||child.up!=parent.up||child.ambiguous||!child.envelope)continue;
  BKNGuidedPair earlier=BKNGuideSelectBoundary(rows,child.a.index,child.b.index,child.up,!child.up,seconds,child.known,parent.known);
  if(!earlier.valid||whole.second<=child.b.index||whole.first>child.b.index)continue;
  if(MathAbs(whole.slope)>=MathAbs(earlier.slope)-BKNGeometryTolerance(whole.slope,earlier.slope))continue;
  BKNGuidedTurningLife life=BKNGuideObserveTurning(rows,earlier,seconds,parent.known);
  if(!life.valid||life.cross<0||life.cross>whole.second||life.cross>=parent.b.index)continue;
  BKNScopeCopy(prior,child);return true;
 }
 return false;
}
// Purple only: replace an existing whole ruler only for supported late
// acceleration. If the whole ruler is unavailable, an independently valid
// terminal subscope does NOT need to accelerate to exist. It owns only its
// own native interval, never the missing whole-parent boundary. Thresholds
// below are engineering policies, not numeric rules attributed to the book.
BKNGuidedPair BKNGuideTerminalTurning(const MqlRates &rows[],const BKNScope &parent,
 const BKNGuidedPair &whole,int seconds,datetime cutoff,BKNScope &selected){
 BKNScopeCopy(selected,parent);
 if(parent.ambiguous||!parent.envelope)return whole;
 if(BKNGuideScopeReason(rows,parent.a.index,parent.b.index,parent.up,seconds,parent.known,cutoff)!="")return whole;
 int first=parent.a.index,last=parent.b.index,span=last-first;
 if(span<8)return whole;
 BKNAxis axis=BKNMeasureAxis(rows,first,last);
 double direction=parent.up?1.0:-1.0;
 if(whole.valid&&(!axis.valid||direction*axis.slope<=0.0))return whole;
 // Keep enough length to represent a phase, not a two-candle terminal spike.
 int minimum=(int)MathMax(4.0,MathCeil(span*0.20));
 int earliest=first+(int)MathCeil(span*0.35);
 // Latest independently confirmed native turning origin first. An earlier
 // original A receives no exception and cannot flatten a later valid phase.
 for(int k=last-minimum;k>=earliest;k--){
  if(!BKNBookSwingContact(rows,k,parent.up,seconds,parent.known))continue;
  BKNScope tail;BKNScopeCopy(tail,parent);
  BKNSNew(tail.a,rows[k].time,parent.known,parent.up?rows[k].low:rows[k].high,parent.up?-1:1,k);
  tail.degree=0;tail.envelope=BKNSEnvelope(rows,tail.a,tail.b);
  if(!tail.envelope||BKNGuideScopeReason(rows,k,last,parent.up,seconds,parent.known,cutoff)!="")continue;
  BKNAxis terminal=BKNMeasureAxis(rows,k,last);
  if(!terminal.valid||direction*terminal.slope<=0.0)continue;
  if(whole.valid&&MathAbs(terminal.slope)<1.25*MathAbs(axis.slope))continue;
  BKNGuidedPair pair=BKNGuideSelectBoundary(rows,k,last,parent.up,!parent.up,seconds,parent.known,cutoff);
  if(!pair.valid)pair=BKNGuideSelectForwardTurning(rows,k,last,parent.up,seconds,parent.known,cutoff);
  if(!pair.valid||pair.axis_error>1.0)continue;
  if(whole.valid&&MathAbs(pair.slope)<1.15*MathAbs(whole.slope))continue;
  BKNScopeCopy(selected,tail);return pair;
 }
 return whole;
}
#endif
