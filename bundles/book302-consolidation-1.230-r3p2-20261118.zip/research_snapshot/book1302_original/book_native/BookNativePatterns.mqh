#ifndef BOOK_NATIVE_PATTERNS
#define BOOK_NATIVE_PATTERNS
// Causal auxiliary morphology. These are observations, not Book source-wave
// assignments, breakout confirmations, probabilities or entry permissions.
// Every call consumes one CLOSED bar; no external scene or Python is used.
struct BKNPattern {
 string code,title,kind;
 int first,last;
 double pa,pb;
 datetime known;
};
void BKNPatternAdd(BKNPattern &out[],string code,string title,string kind,int a,double pa,int b,double pb,datetime known){
 BKNPattern p;p.code=code;p.title=title;p.kind=kind;p.first=a;p.last=b;p.pa=pa;p.pb=pb;p.known=known;
 int n=ArraySize(out);ArrayResize(out,n+1);out[n]=p;
}
void BKNCandlePatterns(const MqlRates &rows[],int i,int seconds,datetime cutoff,BKNPattern &out[]){
 ArrayResize(out,0);if(i<0||i>=ArraySize(rows)||rows[i].time+seconds>cutoff)return;
 double o=rows[i].open,c=rows[i].close,h=rows[i].high,l=rows[i].low;
 double range=h-l,body=MathAbs(c-o),upper=h-MathMax(o,c),lower=MathMin(o,c)-l;
 if(range<=0)return;datetime known=rows[i].time+seconds;
 if(body<=range*0.12)BKNPatternAdd(out,"doji","十字线","point",i,h,i,h,known);
 if(body>range*0.12&&lower>=MathMax(2*body,0.45*range)&&upper<=MathMax(0.75*body,0.15*range))
  BKNPatternAdd(out,"hammer","长下影锤形候选","point",i,l,i,l,known);
 if(body>range*0.12&&upper>=MathMax(2*body,0.45*range)&&lower<=MathMax(0.75*body,0.15*range))
  BKNPatternAdd(out,"shooting_star","长上影星形候选","point",i,h,i,h,known);
 if(i<1||rows[i].time-rows[i-1].time!=seconds)return;
 double po=rows[i-1].open,pc=rows[i-1].close,mid=(po+pc)*0.5;
 if(c>o&&pc<po&&o<=pc&&c>=po&&(o<pc||c>po))BKNPatternAdd(out,"bullish_engulfing","看涨吞没候选","point",i,l,i,l,known);
 if(c<o&&pc>po&&o>=pc&&c<=po&&(o>pc||c<po))BKNPatternAdd(out,"bearish_engulfing","看跌吞没候选","point",i,h,i,h,known);
 if(pc>po&&c<o&&o>=pc&&c<mid&&c>po)BKNPatternAdd(out,"dark_cloud","乌云盖顶候选","point",i,h,i,h,known);
 if(pc<po&&c>o&&o<=pc&&c>mid&&c<po)BKNPatternAdd(out,"piercing","刺透候选","point",i,l,i,l,known);
 if(i<2||rows[i-1].time-rows[i-2].time!=seconds)return;
 double ao=rows[i-2].open,ac=rows[i-2].close,ab=MathAbs(ac-ao),mb=MathAbs(pc-po);
 // Continuous FX often has no session gap: explicitly call this a three-bar
 // reversal candidate, not a confirmed textbook gapped morning/evening star.
 if(ab>0&&mb<=ab*0.5&&ac<ao&&c>o&&c>(ao+ac)*0.5&&MathMin(po,pc)<=ac)
  BKNPatternAdd(out,"morning_reversal","三根晨星式反转候选","point",i,l,i,l,known);
 if(ab>0&&mb<=ab*0.5&&ac>ao&&c<o&&c<(ao+ac)*0.5&&MathMax(po,pc)>=ac)
  BKNPatternAdd(out,"evening_reversal","三根暮星式反转候选","point",i,h,i,h,known);
}
void BKNChartPatterns(const MqlRates &rows[],int end,int seconds,datetime cutoff,BKNPattern &out[]){
 ArrayResize(out,0);if(end<8||end>=ArraySize(rows)||rows[end].time+seconds>cutoff)return;
 int start=(int)MathMax(0,end-95),n=0;int ix[];int side[];double price[];ArrayResize(ix,96);ArrayResize(side,96);ArrayResize(price,96);
 // Never join a chart pattern across a market/session/data gap.
 for(int k=start+1;k<=end;k++)if(rows[k].time-rows[k-1].time!=seconds)start=k;
 if(end-start<8)return;
 double scale=0;int scale_n=0;
 for(int k=(int)MathMax(start,end-31);k<=end;k++){scale+=rows[k].high-rows[k].low;scale_n++;}
 if(scale_n<1||scale<=0)return;scale/=scale_n;
 for(int k=start+2;k<=end-2;k++){
  bool hi=true,lo=true;
  for(int j=k-2;j<=k+2;j++){if(j==k)continue;if(rows[j].high>=rows[k].high)hi=false;if(rows[j].low<=rows[k].low)lo=false;}
  if(hi==lo)continue; // outside bar has unknown high/low order
  int s=hi?1:-1;double p=hi?rows[k].high:rows[k].low;
  if(n>0&&side[n-1]==s){if((s>0&&p>price[n-1])||(s<0&&p<price[n-1])){ix[n-1]=k;price[n-1]=p;}continue;}
  ix[n]=k;side[n]=s;price[n]=p;n++;
 }
 // Emit only when a new strict radius-2 pivot has just become known. Its
 // identity uses actual endpoints, so it is not repeated on every later bar.
 if(n<3||ix[n-1]!=end-2)return;
 datetime known=rows[end].time+seconds;int a=n-3,b=n-2,c=n-1;
 double tol=scale*1.5;
 if(MathAbs(price[a]-price[b])>=scale*1.5&&MathAbs(price[c]-price[b])>=scale*1.5){
  string v=side[b]<0?"V底候选":"V顶候选";
  BKNPatternAdd(out,"v_left",v,"line",ix[a],price[a],ix[b],price[b],known);
  BKNPatternAdd(out,"v_right",v,"line",ix[b],price[b],ix[c],price[c],known);
 }
 if(MathAbs(price[a]-price[c])<=tol&&MathAbs(price[a]-price[b])>2*tol&&MathAbs(price[c]-price[b])>2*tol)
  BKNPatternAdd(out,side[c]>0?"double_top":"double_bottom",side[c]>0?"双顶候选·未验颈线":"双底候选·未验颈线","line",ix[a],price[a],ix[c],price[c],known);
 if(n>=5){
  a=n-5;int m=n-3;
  double spread=MathMax(price[a],MathMax(price[m],price[c]))-MathMin(price[a],MathMin(price[m],price[c]));
  if(spread<=tol&&MathAbs(price[a]-price[a+1])>2*tol&&MathAbs(price[c]-price[c-1])>2*tol)
   BKNPatternAdd(out,side[c]>0?"triple_top":"triple_bottom",side[c]>0?"三顶候选·未验颈线":"三底候选·未验颈线","line",ix[a],price[a],ix[c],price[c],known);
  bool head=side[c]>0?price[m]>MathMax(price[a],price[c])+tol:price[m]<MathMin(price[a],price[c])-tol;
  if(head&&MathAbs(price[a]-price[c])<=tol){
   string code=side[c]>0?"head_shoulders":"inverse_head_shoulders",title=side[c]>0?"头肩顶候选·未验颈线":"头肩底候选·未验颈线";
   BKNPatternAdd(out,code+"_neck",title,"line",ix[a+1],price[a+1],ix[c-1],price[c-1],known);
   BKNPatternAdd(out,code+"_head",title,"point",ix[m],price[m],ix[m],price[m],known);
  }
 }
 if(n>=6){
  int hh[],ll[],nh=0,nl=0;ArrayResize(hh,3);ArrayResize(ll,3);
  for(int k=n-6;k<n;k++){if(side[k]>0)hh[nh++]=k;else ll[nl++]=k;}
  if(nh==3&&nl==3&&price[hh[1]]>price[hh[0]]&&price[hh[2]]<price[hh[1]]&&
     price[ll[1]]<price[ll[0]]&&price[ll[2]]>price[ll[1]]){
   for(int k=0;k<2;k++){
    BKNPatternAdd(out,"diamond_upper_"+IntegerToString(k),"菱形整理候选·未验突破","line",ix[hh[k]],price[hh[k]],ix[hh[k+1]],price[hh[k+1]],known);
    BKNPatternAdd(out,"diamond_lower_"+IntegerToString(k),"菱形整理候选·未验突破","line",ix[ll[k]],price[ll[k]],ix[ll[k+1]],price[ll[k+1]],known);
   }
  }
 }
 if(n<4)return;
 int h1=-1,h2=-1,l1=-1,l2=-1;
 for(int k=n-4;k<n;k++){if(side[k]>0){h1=h2;h2=k;}else{l1=l2;l2=k;}}
 if(h1<0||l1<0)return;
 double hs=(price[h2]-price[h1])/(ix[h2]-ix[h1]),ls=(price[l2]-price[l1])/(ix[l2]-ix[l1]);
 int left=(int)MathMax(ix[h1],ix[l1]),right=(int)MathMin(ix[h2],ix[l2]);if(right<=left)return;
 double width0=price[h1]+hs*(left-ix[h1])-price[l1]-ls*(left-ix[l1]);
 double width1=price[h1]+hs*(right-ix[h1])-price[l1]-ls*(right-ix[l1]);
 if(width0<=0||width1<=0)return;
 // Both finite rails must actually bound every candle between their anchors.
 for(int k=ix[h1]+1;k<ix[h2];k++)if(rows[k].high>price[h1]+hs*(k-ix[h1])+scale*0.05)return;
 for(int k=ix[l1]+1;k<ix[l2];k++)if(rows[k].low<price[l1]+ls*(k-ix[l1])-scale*0.05)return;
 string code="",title="";
 if(hs<0&&ls>0){code="triangle";title="收敛三角候选";}
 else if(hs>0&&ls<0){code="expanding";title="扩张三角候选";}
 else if(hs>0&&ls>hs&&width1<width0){code="rising_wedge";title="上升楔形候选";}
 else if(ls<0&&hs<ls&&width1<width0){code="falling_wedge";title="下降楔形候选";}
 else if(hs*ls>0&&MathAbs(hs-ls)<=0.35*MathMax(MathAbs(hs),MathAbs(ls))){code="parallel_pattern";title="平行整理候选·旗杆未验";}
 if(code=="")return;
 BKNPatternAdd(out,code+"_upper",title,"line",ix[h1],price[h1],ix[h2],price[h2],known);
 BKNPatternAdd(out,code+"_lower",title,"line",ix[l1],price[l1],ix[l2],price[l2],known);
}
#endif
