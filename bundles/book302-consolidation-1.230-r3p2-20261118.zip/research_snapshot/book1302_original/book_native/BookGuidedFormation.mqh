#ifndef BOOK_GUIDED_FORMATION
#define BOOK_GUIDED_FORMATION
#include "BookGuidedTerminalTurning.mqh"
// Book figure 3-3: the opposite-side contact must PRECEDE the directional
// extreme. A later equal high/low is not a new extreme and must not expand
// the formation window over the intervening pullback. Keep knowledge clocks
// conservative; this helper never claims a pivot before it was observable.
bool BKNGuideTurningFormation(const MqlRates &rows[],const BKNScope &supplied,
 int seconds,datetime cutoff,BKNScope &formation,string &reason){
 BKNScopeCopy(formation,supplied);
 reason=BKNGuideScopeReason(rows,supplied.a.index,supplied.b.index,supplied.up,seconds,supplied.known,cutoff);
 if(reason!="")return false;
 int first=supplied.a.index,last=supplied.b.index,extreme=first;
 for(int k=first+1;k<=last;k++){
  double previous=supplied.up?rows[extreme].high:rows[extreme].low;
  double current=supplied.up?rows[k].high:rows[k].low;
  double tolerance=BKNGeometryTolerance(current,previous);
  if(supplied.up?current>previous+tolerance:current<previous-tolerance)extreme=k;
 }
 if(extreme<=first){reason="directional_extreme_not_after_origin";return false;}
 if(extreme<last){
  BKNSNew(formation.b,rows[extreme].time,supplied.b.known,
   supplied.up?rows[extreme].high:rows[extreme].low,supplied.up?1:-1,extreme);
  formation.envelope=BKNSEnvelope(rows,formation.a,formation.b);
 }
 reason=BKNGuideScopeReason(rows,first,extreme,supplied.up,seconds,supplied.known,cutoff);
 if(reason!="")return false;
 reason=extreme<last?"equal_extreme_does_not_admit_later_pullback_contact":"first_directional_extreme_formation";
 return true;
}
#endif
