#ifndef BOOK_NATIVE_WAVE_DEGREE
#define BOOK_NATIVE_WAVE_DEGREE
#include "BookNativeWaveCount.mqh"
// Chapter7 PDF189-194,218-220. The parent is an explicit native reduction
// level, not a timeframe or an author degree. Internal 5/3 counts must use
// ONE immediately lower reduction and the SAME named endpoints throughout.
struct BKNWaveDegree {
 string form,degree_state,subdivision,reason;
 int parent_resolution,child_resolution,legs[3];
 datetime known;
 bool nested_verified;
};
struct BKNWaveInternal { string form;int legs;datetime known; };
BKNWaveInternal BKNWaveInternalLeg(const BKNPoint &path[],int first,double pa,int last,double pb,
                         datetime cutoff,int decimals){
 BKNWaveInternal out;ZeroMemory(out);if(last<=first||pa==pb){out.form="invalid_interval";return out;}
 int direction=pb>pa?1:-1;BKNPoint points[];
 for(int i=0;i<ArraySize(path);i++){
  BKNPoint p;BKNSCopy(p,path[i]);
  if(p.index<=first||p.index>last||p.known>cutoff)continue;
  if(p.kind!=(ArraySize(points)%2==0?direction:-direction)){out.form="internal_order_unresolved";return out;}
  BKNSAppend(points,p);out.known=(datetime)MathMax((long)out.known,(long)p.known);
 }
 out.legs=ArraySize(points);
 if(out.legs==0||points[out.legs-1].index!=last||points[out.legs-1].price!=pb){out.form="internal_terminal_unbound";return out;}
 if(out.legs!=3&&out.legs!=5){out.form="internal_subdivision_unresolved";return out;}
 long q0;long q[];ArrayResize(q,5);if(!BKNPriceTicks(pa,decimals,q0)){out.form="quote_grid_review";return out;}
 for(int i=0;i<out.legs;i++)if(!BKNPriceTicks(points[i].price,decimals,q[i])){out.form="quote_grid_review";return out;}
 for(int i=0;i<out.legs;i++){
  long previous=i==0?q0:q[i-1];int sign=i%2==0?direction:-direction;
  if(sign*(q[i]-previous)<=0){out.form="internal_direction_invalid";return out;}
 }
 if(out.legs==3){out.form="three_leg_candidate";return out;}
 if(direction*(q[1]-q0)<=0||direction*(q[2]-q[0])<=0||direction*(q[3]-q[0])<=0)
  {out.form="impulse_overlap_or_origin_review";return out;}
 if(direction*(q[4]-q[2])<=0){out.form="internal_failed_fifth_review";return out;}
 long w1=(long)MathAbs((double)(q[0]-q0)),w3=(long)MathAbs((double)(q[2]-q[1])),w5=(long)MathAbs((double)(q[4]-q[3]));
 if(w3<MathMin(w1,w5)){out.form="internal_third_shortest_rejected";return out;}
 if(w3==MathMin(w1,w5)){out.form="internal_length_tie_review";return out;}
 {out.form="five_leg_impulse_candidate";return out;}
}
void BKNAnalyzeWaveDegree(const MqlRates &rows[],const BKNPoint &ledger[],int seconds,datetime cutoff,
                         int resolution,int first,double pa,int last,double pb,int decimals,BKNWaveDegree &out){
 ZeroMemory(out);out.form="complex_adjustment_unresolved";out.degree_state="relative_degree_unresolved";
 out.parent_resolution=resolution;out.child_resolution=resolution-1;out.subdivision="unknown";
 out.reason="same_source_same_endpoints_lower_level_required";
 if(seconds<=0||first<0||last<=first||last>=ArraySize(rows)||rows[last].time+seconds>cutoff)return;
 if(BKNWaveCountAmbiguous(ledger,first,last,cutoff)){out.reason="same_bar_extrema_order_unknown";return;}
 BKNPoint parent[];BKNScope scopes[];
 if(!BKNSBuildPath(rows,ledger,seconds,cutoff,resolution,parent,scopes))return;
 BKNPoint selected[];int direction=pb>pa?1:-1;
 bool origin_bound=false;
 for(int i=0;i<ArraySize(parent);i++)if(parent[i].index==first&&parent[i].price==pa&&parent[i].kind==-direction&&parent[i].known<=cutoff){origin_bound=true;out.known=parent[i].known;}
 if(!origin_bound){out.reason="parent_origin_unbound";return;}
 for(int i=0;i<ArraySize(parent);i++){
  BKNPoint p;BKNSCopy(p,parent[i]);
  if(p.index<=first||p.index>last||p.known>cutoff)continue;
  if(p.kind!=(ArraySize(selected)%2==0?direction:-direction)){out.reason="parent_order_unresolved";return;}
  BKNSAppend(selected,p);out.known=(datetime)MathMax((long)out.known,(long)p.known);
 }
 int n=ArraySize(selected);
 if(n==0||selected[n-1].index!=last||selected[n-1].price!=pb){out.reason="parent_terminal_unbound";return;}
 if(n==1)out.form="simple_return_candidate";
 if(n==3)out.form="ABC_candidate";
 if(n==5){
  bool contracting=true,expanding=true;
  for(int i=2;i<5;i++){
   double d=selected[i].kind*(selected[i].price-selected[i-2].price);
   if(d>=0)contracting=false;if(d<=0)expanding=false;
  }
  out.form=contracting?"contracting_triangle_candidate":expanding?"expanding_triangle_candidate":"five_pivot_complex_review";
 }
 if(resolution<=0){out.degree_state="lower_degree_unavailable";out.reason="native_raw_pivots_have_no_verified_lower_degree";return;}
 if(n!=3){out.reason="non_ABC_morphology_no_535_or_335_claim";return;}
 BKNPoint child[];BKNScope child_scopes[];
 if(!BKNSBuildPath(rows,ledger,seconds,cutoff,resolution-1,child,child_scopes))return;
 string forms[];ArrayResize(forms,3);int start=first;double price=pa;
 for(int j=0;j<3;j++){
  BKNWaveInternal internal=BKNWaveInternalLeg(child,start,price,selected[j].index,selected[j].price,cutoff,decimals);
  forms[j]=internal.form;out.legs[j]=internal.legs;
  out.known=(datetime)MathMax((long)out.known,(long)internal.known);
  start=selected[j].index;price=selected[j].price;
 }
 out.subdivision=IntegerToString(out.legs[0])+"-"+IntegerToString(out.legs[1])+"-"+IntegerToString(out.legs[2]);
 if(forms[1]=="three_leg_candidate"&&forms[2]=="five_leg_impulse_candidate"){
  if(forms[0]=="five_leg_impulse_candidate")out.form=direction*(pb-selected[0].price)>0?"zigzag_535_candidate":"zigzag_terminal_not_beyond_A_review";
  else if(forms[0]=="three_leg_candidate")out.form="flat_335_candidate";
 }
 out.nested_verified=out.form=="zigzag_535_candidate"||out.form=="flat_335_candidate";
 out.degree_state=out.nested_verified?"native_nested_levels_verified_author_degree_unselected":"native_nested_structure_review";
 out.reason=forms[0]+"|"+forms[1]+"|"+forms[2];
}
string BKNWaveDegreeLabel(const BKNWaveDegree &d){
 string form=d.form=="zigzag_535_candidate"?"5-3-5锯齿候选":d.form=="flat_335_candidate"?"3-3-5平坦候选":
  d.form=="contracting_triangle_candidate"?"收敛三角候选":d.form=="expanding_triangle_candidate"?"扩张三角候选":
  d.form=="simple_return_candidate"?"单段调整":d.form=="ABC_candidate"?"ABC内部待核":"复杂调整待核";
 return form+" | 同周期结构层 "+IntegerToString(d.parent_resolution)+"→"+(d.child_resolution>=0?IntegerToString(d.child_resolution):"无更低层")+
  " | 形态可知 "+IntegerToString((long)d.known)+" | 内部 "+d.subdivision+" | "+d.degree_state+" | "+d.reason+"；不等于作者浪级确认";
}
#endif
