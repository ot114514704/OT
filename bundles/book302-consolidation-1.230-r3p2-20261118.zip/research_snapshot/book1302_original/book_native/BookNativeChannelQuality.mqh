#ifndef BOOK_NATIVE_CHANNEL_QUALITY
#define BOOK_NATIVE_CHANNEL_QUALITY
#include "BookNativeGeometry.mqh"
// Current _parallel_intelligence numeric port. Actual enclosing contacts and
// native full-wave ownership are supplied separately; a geometry score cannot
// qualify author direction, reversal, force or an entry.
struct BKNChannelQuality {
 bool valid,range_like,axis_review;
 int lower_touches,upper_touches,body_fit,wick_excursions,touch_events,ambiguous_touches,sequence_count,alternations;
 double typical,tolerance,width_atr,formation_fit,body_ratio,wick_ratio;
 double components[5],base_score,adjustment,score,alternation_ratio,residual,residual_fit,slope_width_ratio;
 string quality,reason,grade,axis_review_reason;
};
double BKNChannelUnit(double value){return MathMax(0.0,MathMin(1.0,value));}
BKNChannelQuality BKNMeasureChannel(const MqlRates &rows[],const BKNBoundary &line,
                                    int seconds,datetime cutoff){
 BKNChannelQuality out;ZeroMemory(out);out.quality="unknown";out.grade="unknown";out.reason="empty_formation";out.axis_review=line.axis_review;out.axis_review_reason=line.axis_review_reason;
 int a=line.origin,b=line.terminal,n=b-a+1;
 if(!line.qualified||seconds<=0||a<0||b>=ArraySize(rows)||b<a||line.first<a||line.second> b||line.first>=line.second||
   line.known_at>cutoff||rows[b].time+seconds>line.known_at)return out;
 double positive[],residuals[];ArrayResize(residuals,n);
 for(int i=a;i<=b;i++){
  if(!BKNValidRate(rows[i])||(i>a&&rows[i].time<=rows[i-1].time)){out.reason="invalid_native_channel_input";return out;}
  double range=rows[i].high-rows[i].low;
  if(range>0){int count=ArraySize(positive);ArrayResize(positive,count+1);positive[count]=range;}
 }
 out.typical=BKNMedian(positive);double offset=line.parallel_offset;
 out.tolerance=MathMax(out.typical*.20,MathMax(MathAbs(offset)*.025,1e-9));
 int previous_event=0,last_sequence=0;bool have_event=false;
 for(int i=a;i<=b;i++){
  double base=BKNBoundaryLevel(line,i,false),lo=line.up?base:base+offset,hi=line.up?base+offset:base;
  if(lo>hi){double tmp=lo;lo=hi;hi=tmp;}
  double body_low=MathMin(rows[i].open,rows[i].close),body_high=MathMax(rows[i].open,rows[i].close);
  if(body_low>=lo-1e-12&&body_high<=hi+1e-12)out.body_fit++;
  if(rows[i].low<lo-out.tolerance||rows[i].high>hi+out.tolerance)out.wick_excursions++;
  bool lower=MathAbs(rows[i].low-lo)<=out.tolerance,upper=MathAbs(rows[i].high-hi)<=out.tolerance;
  if(lower)out.lower_touches++;if(upper)out.upper_touches++;
  double mid=(rows[i].open+rows[i].close)/2.0;
  residuals[i-a]=MathAbs(mid-(lo+hi)/2.0)/MathMax(MathAbs(offset),MathMax(out.typical,1e-9));
  if(!lower&&!upper)continue;
  int rail=lower&&upper?0:lower?-1:1;
  if(rail==0)out.ambiguous_touches++;
  else if(out.sequence_count==0||last_sequence!=rail){out.sequence_count++;last_sequence=rail;}
  if(have_event&&rail!=0&&previous_event!=0&&rail!=previous_event)out.alternations++;
  previous_event=rail;have_event=true;out.touch_events++;
 }
 out.width_atr=MathAbs(offset)/MathMax(out.typical,1e-9);
 double width_fit=out.width_atr>=1&&out.width_atr<=8?1.0:MathMax(0.0,1.0-MathAbs(out.width_atr-4.0)/8.0);
 out.formation_fit=BKNChannelUnit((n-4.0)/20.0);int touches=(int)MathMin(out.lower_touches,out.upper_touches);
 out.body_ratio=out.body_fit/(double)n;out.wick_ratio=out.wick_excursions/(double)n;
 out.components[0]=NormalizeDouble(out.body_ratio,4);
 out.components[1]=NormalizeDouble(MathMin(1.0,touches/2.0),4);
 out.components[2]=NormalizeDouble(width_fit,4);
 out.components[3]=NormalizeDouble(MathMax(0.0,1.0-out.wick_ratio),4);
 out.components[4]=NormalizeDouble(out.formation_fit,4);
 double base=28*out.components[0]+25*out.components[1]+17*out.components[2]+12*out.components[3]+18*out.components[4];
 out.residual=BKNMedian(residuals);out.residual_fit=BKNChannelUnit(1.0-out.residual);
 out.alternation_ratio=out.touch_events>0?out.alternations/MathMax(1.0,out.touch_events-1.0):0;
 out.slope_width_ratio=MathAbs(line.slope*MathMax(1,b-a))/MathMax(MathAbs(offset),MathMax(out.typical,1e-9));
 out.range_like=out.slope_width_ratio<.20&&out.alternations>=2;
 double slope_quality=BKNChannelUnit(out.slope_width_ratio);if(out.range_like)slope_quality*=.35;
 double advanced=.40*out.alternation_ratio+.35*out.residual_fit+.25*slope_quality;
 double adjustment=(advanced-.5)*12.0;if(out.range_like)adjustment-=8.0;
 out.score=NormalizeDouble(MathMax(0.0,MathMin(100.0,base+adjustment)),1);
 out.base_score=NormalizeDouble(base,1);out.adjustment=NormalizeDouble(adjustment,1);
 out.grade=out.score>=70?"strong":out.score>=50?"medium":"weak";
 if(touches>=2&&out.score>=70){out.quality="confirmed";out.reason="repeated_opposite_edge_touches";}
 else if(touches>=1&&out.score>=50){out.quality="candidate";out.reason="single_edge_touch_or_partial_distribution";}
 else {out.quality="unknown";out.reason="enclosing_edge_not_repeatedly_witnessed";}
 if(line.axis_review){out.quality="review_pending";out.grade="unknown";out.reason="轴线偏差待复核；"+out.reason;}
 out.valid=true;return out;
}
#endif
