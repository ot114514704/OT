#ifndef BOOK_NATIVE_LABELS
#define BOOK_NATIVE_LABELS
#include "BookNativeFrame.mqh"
// Caption selection is independent of measurement and object generation.
// A label budget never deletes geometry, scores or the complete tooltip.
int BKNLabelPriority(const BKNShape &shape,string selected){
 if(shape.id==selected)return 0;
 if(shape.layer=="wave_count")return 1;
 if(shape.layer=="force")return shape.has_score?1:2;
 if(shape.has_score)return 3;
 if(shape.layer=="wave")return 6;
 return 5;
}
bool BKNLabelBefore(const BKNShape &a,const BKNShape &b,string selected){
 int ap=BKNLabelPriority(a,selected),bp=BKNLabelPriority(b,selected);
 if(ap!=bp)return ap<bp;
 if(a.b!=b.b)return a.b>b.b;
 if(a.known!=b.known)return a.known>b.known;
 return StringCompare(a.id,b.id)<0;
}
void BKNChooseLabels(const BKNShape &shapes[],const bool &visible[],datetime left,datetime right,
                      string selected,int maximum,int &indices[]){
 ArrayResize(indices,0);maximum=(int)MathMax(0,MathMin(128,maximum));
 if(maximum==0||right<left||ArraySize(visible)!=ArraySize(shapes))return;
 for(int i=0;i<ArraySize(shapes);i++){
  if(shapes[i].layer=="wave_count"&&shapes[i].kind!="point")continue;
  if(!visible[i]||shapes[i].layer=="zigzag"||shapes[i].label==""||shapes[i].b<left||shapes[i].a>right)continue;
  // Multiple producers may describe the exact same force segment. Preserve
  // every record/tooltip, but allocate one caption for identical measurements.
  bool duplicate=false;
  if(shapes[i].layer=="wave_count")for(int j=0;j<ArraySize(indices);j++){
   int p=indices[j];
   if(shapes[p].layer=="wave_count"&&shapes[p].group==shapes[i].group&&shapes[p].a==shapes[i].a&&
      shapes[p].pa==shapes[i].pa&&shapes[p].status==shapes[i].status){
    if(BKNLabelBefore(shapes[i],shapes[p],selected))indices[j]=i;
    duplicate=true;break;
   }
  }
  if(shapes[i].layer=="force")for(int j=0;j<ArraySize(indices);j++){
   int p=indices[j];
   if(shapes[p].layer=="force"&&shapes[p].a==shapes[i].a&&shapes[p].b==shapes[i].b&&
      shapes[p].pa==shapes[i].pa&&shapes[p].pb==shapes[i].pb&&shapes[p].has_score==shapes[i].has_score&&
      (!shapes[i].has_score||shapes[p].score==shapes[i].score)){
    if(BKNLabelBefore(shapes[i],shapes[p],selected))indices[j]=i;
    duplicate=true;break;
   }
  }
  if(duplicate)continue;
  int n=ArraySize(indices),at=0;
  while(at<n&&!BKNLabelBefore(shapes[i],shapes[indices[at]],selected))at++;
  if(at>=maximum)continue;
  int next=(int)MathMin(maximum,n+1);ArrayResize(indices,next);
  for(int k=next-1;k>at;k--)indices[k]=indices[k-1];indices[at]=i;
 }
}
struct BKNLabelPlacement {bool placed;int x,y,w,h;};
BKNLabelPlacement BKNPlaceLabel(int x,int y,int w,int h,int chart_width,int chart_height,int minimum_y,
                                const BKNLabelPlacement &used[]){
 BKNLabelPlacement out;ZeroMemory(out);
 if(w<=0||h<=0||chart_width<w+12||chart_height<minimum_y+h+6)return out;
 x=(int)MathMax(6,MathMin(chart_width-w-6,x));int offsets[9]={0,-1,1,-2,2,-3,3,-4,4};
 for(int k=0;k<9;k++){
  int candidate=y+offsets[k]*(h+3);if(candidate<minimum_y||candidate+h>chart_height-6)continue;
  bool collision=false;
  for(int j=0;j<ArraySize(used);j++)if(used[j].placed&&x<used[j].x+used[j].w+4&&x+w+4>used[j].x&&
       candidate<used[j].y+used[j].h+3&&candidate+h+3>used[j].y){collision=true;break;}
  if(collision)continue;
  out.placed=true;out.x=x;out.y=candidate;out.w=w;out.h=h;return out;
 }
 return out;
}
#endif
