#ifndef BOOK_NATIVE_WAVE_PROCESS
#define BOOK_NATIVE_WAVE_PROCESS
#include "BookNativeSource.mqh"
#include "BookNativeForce.mqh"
// Numeric/topology port of recognize_wave_process. These are native source
// hypotheses, not author wave degrees. Parent price containment remains a
// candidate relation and NEVER authorizes a parent score or an entry.
struct BKNExcursion {
 int origin,terminal,broken,observed_through,parent,ambiguous_parents,ancestor_count;
 bool up,envelope,has_score,score_eligible,break_both_extremes,broken_before_origin_known;
 double origin_price,terminal_price,score,retention;
 datetime origin_known,known,broken_known,membership_known;
 string state,relation,grade;
 BKNForce force;
};
struct BKNWaveDescription {
 bool valid_scope,measured,interior_order_unknown,force_admission,author_degree_verified;
 string reason;
 BKNForce force;
};
// A native A..B numerical description does not need to guess the order of
// every interior outside candle. Keep that unknown fact, but do not erase the
// independently verified interval or borrow an after-B adjustment for force.
// This is the original native_completed_wave_description scoring domain;
// it grants neither strict-source qualification nor parent/entry permission.
bool BKNVerifyWaveScope(const MqlRates &rows[],const BKNScope &scope,int seconds,datetime cutoff){
 int first=scope.a.index,last=scope.b.index;
 if(!scope.envelope||seconds<=0||first<0||last<=first||last>=ArraySize(rows))return false;
 if(rows[first].time!=scope.a.time||rows[last].time!=scope.b.time||scope.a.price==scope.b.price||
   scope.known>cutoff||scope.known<scope.a.known||scope.known<scope.b.known||rows[last].time+seconds>scope.known)return false;
 bool up=scope.b.price>scope.a.price;
 if(scope.up!=up||scope.a.kind!=(up?-1:1)||scope.b.kind!=(up?1:-1)||
   (up?rows[first].low:rows[first].high)!=scope.a.price||(up?rows[last].high:rows[last].low)!=scope.b.price)return false;
 double low=MathMin(scope.a.price,scope.b.price),high=MathMax(scope.a.price,scope.b.price);
 for(int i=first;i<=last;i++)if(!BKNSourceRateValid(rows[i])||rows[i].low<low-1e-8||rows[i].high>high+1e-8||
   (i>first&&rows[i].time<=rows[i-1].time))return false;
 return true;
}
BKNWaveDescription BKNDescribeVerifiedWave(const MqlRates &rows[],const BKNScope &scope,
                                          int seconds,datetime cutoff){
 BKNWaveDescription out;ZeroMemory(out);out.reason="native_description_scope_unverified";
 out.force.score=EMPTY_VALUE;out.force.grade="unknown";
 if(!BKNVerifyWaveScope(rows,scope,seconds,cutoff))return out;
 out.valid_scope=true;out.interior_order_unknown=scope.ambiguous;
 out.force=BKNMeasureForce(rows,scope.a.time,scope.a.price,scope.b.time,scope.b.price,scope.known,seconds,true);
 out.measured=out.force.observed;out.reason=out.measured?"":out.force.status;return out;
}
void BKNFirstStrictCrossings(const MqlRates &rows[],bool high,int &cross[]){
 int n=ArraySize(rows),stack[];ArrayResize(cross,n);ArrayInitialize(cross,-1);
 ArrayResize(stack,n);int used=0;
 for(int i=0;i<n;i++){
  while(used>0&&(high?rows[i].high>rows[stack[used-1]].high:rows[i].low<rows[stack[used-1]].low))
   cross[stack[--used]]=i;
  stack[used++]=i;
 }
}
int BKNEarlierExtreme(const MqlRates &rows[],int a,int b,bool up){
 if(a<0)return b;if(b<0)return a;
 double av=up?rows[a].high:rows[a].low,bv=up?rows[b].high:rows[b].low;
 if(av==bv)return a<b?a:b;
 return (up?av>bv:av<bv)?a:b;
}
void BKNExtremeTree(const MqlRates &rows[],bool up,int &tree[],int &size){
 size=1;while(size<ArraySize(rows))size*=2;
 ArrayResize(tree,size*2);ArrayInitialize(tree,-1);
 for(int i=0;i<ArraySize(rows);i++)tree[size+i]=i;
 for(int i=size-1;i>0;i--)tree[i]=BKNEarlierExtreme(rows,tree[i*2],tree[i*2+1],up);
}
int BKNRangeExtreme(const MqlRates &rows[],const int &tree[],int size,int first,int last,bool up){
 int lo=first+size,hi=last+size,found=-1;
 while(lo<=hi){
  if(lo%2==1)found=BKNEarlierExtreme(rows,found,tree[lo++],up);
  if(hi%2==0)found=BKNEarlierExtreme(rows,found,tree[hi--],up);
  lo/=2;hi/=2;
 }
 return found;
}
bool BKNRecognizeNative(const MqlRates &bars[],int seconds,datetime cutoff,BKNExcursion &out[],
                        int bound_origin=-1,bool bound_up=true,datetime bound_known=0){
 ArrayResize(out,0);if(seconds<=0||cutoff<=0)return false;
 MqlRates rows[];int n=0;datetime previous=0;
 for(int i=0;i<ArraySize(bars);i++){
  if(bars[i].time+seconds>cutoff)continue;
  if(i!=n||bars[i].time<=previous||!BKNSourceRateValid(bars[i])||bars[i].low<=0)return false;
  ArrayResize(rows,n+1);rows[n++]=bars[i];previous=bars[i].time;
 }
 if(n==0)return false;
 BKNPoint origins[];if(!BKNSLedger(rows,seconds,cutoff,2,origins))return false;
 if(bound_origin>=0){
  if(bound_origin>=n||bound_known<rows[bound_origin].time+seconds||bound_known>cutoff)return false;
  double price=bound_up?rows[bound_origin].low:rows[bound_origin].high;bool exists=false;
  for(int i=0;i<ArraySize(origins);i++)
   if(origins[i].index==bound_origin&&origins[i].kind==(bound_up?-1:1)&&origins[i].price==price){exists=true;break;}
  if(!exists){BKNPoint p;BKNSNew(p,rows[bound_origin].time,bound_known,price,bound_up?-1:1,bound_origin);BKNSAppend(origins,p);}
 }
 int cross_high[],cross_low[],high_tree[],low_tree[],high_size,low_size;
 BKNFirstStrictCrossings(rows,true,cross_high);BKNFirstStrictCrossings(rows,false,cross_low);
 BKNExtremeTree(rows,true,high_tree,high_size);BKNExtremeTree(rows,false,low_tree,low_size);
 for(int p=0;p<ArraySize(origins);p++){
  int a=origins[p].index;bool up=origins[p].kind==-1;
  BKNExcursion r;ZeroMemory(r);r.relation="";r.origin=a;r.terminal=-1;r.parent=-1;r.broken=up?cross_low[a]:cross_high[a];
  r.up=up;r.origin_price=origins[p].price;r.origin_known=origins[p].known;r.known=r.origin_known;
  r.grade="unknown";r.score=EMPTY_VALUE;r.retention=EMPTY_VALUE;
  r.force.score=EMPTY_VALUE;r.force.grade="unknown";r.force.status="range_not_yet_available";
  int stop=r.broken>=0?r.broken:n;r.observed_through=stop-1;
  if(r.broken>=0){r.broken_known=rows[r.broken].time+seconds;r.broken_before_origin_known=r.broken_known<r.origin_known;}
  r.state=r.broken>=0?"origin_broken":"awaiting_post_origin_bar";
  if(a+1<stop){
   int b=up?BKNRangeExtreme(rows,high_tree,high_size,a+1,stop-1,true):BKNRangeExtreme(rows,low_tree,low_size,a+1,stop-1,false);
   r.terminal=b;r.terminal_price=up?rows[b].high:rows[b].low;
   double low=MathMin(r.origin_price,r.terminal_price),high=MathMax(r.origin_price,r.terminal_price);
   r.envelope=true;
   for(int k=a;k<=b;k++)if(rows[k].low<low||rows[k].high>high){r.envelope=false;break;}
   r.known=(datetime)MathMax((double)r.origin_known,(double)(rows[b].time+seconds));
   // A..B and pre-A ATR only. The return after B never enters this force.
   MqlRates measured[];int begin=(int)MathMax(0,a-21);ArrayResize(measured,b-begin+1);
   for(int k=begin;k<=b;k++)measured[k-begin]=rows[k];
   r.force=BKNMeasureForce(measured,rows[a].time,r.origin_price,rows[b].time,r.terminal_price,r.known,seconds,true);
   r.has_score=r.envelope&&r.force.observed;
   if(r.has_score){r.score=r.force.score;r.grade=r.force.grade;}
   r.score_eligible=r.broken<0&&r.has_score&&r.force.gap_count==0;
   if(r.terminal_price!=r.origin_price)r.retention=(rows[stop-1].close-r.origin_price)/(r.terminal_price-r.origin_price);
   r.state=r.broken>=0?"origin_broken":b==n-1?"extending":"return_after_observed_extreme";
   if(r.broken>=0)r.break_both_extremes=up?rows[r.broken].high>r.terminal_price:rows[r.broken].low<r.terminal_price;
  }
  int count=ArraySize(out);ArrayResize(out,count+1);out[count]=r;
 }
 // Select the smallest observed enclosing native excursion. Equal breadth
 // and height remain ambiguous; no ID hash or child grade resolves the tie.
 for(int c=0;c<ArraySize(out);c++){
  if(!out[c].envelope)continue;
  long best_span=LONG_MAX;double best_height=DBL_MAX;int selected=-1,ties=0;
  for(int p=0;p<ArraySize(out);p++){
   if(!out[p].envelope||out[p].origin>=out[c].origin||out[p].observed_through<0)continue;
   if(rows[out[c].terminal].time+seconds>rows[out[p].observed_through].time+seconds)continue;
   double low=MathMin(out[p].origin_price,out[p].terminal_price),high=MathMax(out[p].origin_price,out[p].terminal_price);
   if(MathMin(out[c].origin_price,out[c].terminal_price)<low||MathMax(out[c].origin_price,out[c].terminal_price)>high)continue;
   long span=(long)(rows[out[p].terminal].time-rows[out[p].origin].time);double height=high-low;
   if(span<best_span||(span==best_span&&height<best_height)){selected=p;best_span=span;best_height=height;ties=1;}
   else if(span==best_span&&height==best_height)ties++;
  }
  if(ties>1){out[c].ambiguous_parents=ties;continue;}
  if(selected<0)continue;
  out[c].parent=selected;
  out[c].relation=out[c].terminal<=out[selected].terminal?
   (out[c].up==out[selected].up?"internal_forward_stage":"internal_return_stage"):"post_extreme_return_candidate";
 }
 for(int c=0;c<ArraySize(out);c++){
  datetime known=out[c].known;int p=out[c].parent;
  while(p>=0){known=(datetime)MathMax((double)known,(double)out[p].known);out[c].ancestor_count++;p=out[p].parent;}
  out[c].membership_known=known;
 }
 return true;
}
#endif
