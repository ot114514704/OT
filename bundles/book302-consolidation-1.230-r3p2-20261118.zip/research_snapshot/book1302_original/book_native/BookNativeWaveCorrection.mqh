#ifndef BOOK_NATIVE_WAVE_CORRECTION
#define BOOK_NATIVE_WAVE_CORRECTION
#include "BookNativeWaveBranches.mqh"
// Chapter7 PDF225-227: an ABC adjustment and a new opposite impulse can
// share A/1, B/2, C/3 geometry. Keep that ambiguity explicit. This is NOT
// a 5-3-5/3-3-5 degree certificate or proof that the whole correction ended.
struct BKNWaveCorrection {
 string id,parent_id,source_id,state,reason;
 int points,anchor[4],cross,failure;
 double price[4];datetime known[4],state_known;
 bool confirmed[4],geometry_valid,expanded_b;
};
void BKNBuildWaveCorrection(const MqlRates &bars[],const BKNPoint &ledger[],int seconds,datetime cutoff,
                            const BKNBookWaveCount &seed,const BKNWaveBranch &branch,int decimals,BKNWaveCorrection &out){
 ZeroMemory(out);out.cross=-1;out.failure=-1;out.state="unavailable";
 for(int j=0;j<4;j++)out.anchor[j]=-1;
 if(seconds<=0||!branch.geometry_valid||!branch.fifth_confirmed||branch.fifth<0||
    branch.parent_id!=seed.count_id||branch.source_id!=seed.source_id||branch.fifth_known>cutoff)return;
 MqlRates rows[];int n=0;datetime previous=0;bool future=false;
 for(int k=0;k<ArraySize(bars);k++){
  if(bars[k].time+seconds>cutoff){future=true;continue;}
  if(future||bars[k].time<=previous||!BKNValidRate(bars[k]))return;
  ArrayResize(rows,n+1,256);rows[n++]=bars[k];previous=bars[k].time;
 }
 if(branch.fifth>=n)return;
 BKNPoint path[];BKNScope ignored[];
 if(!BKNSBuildPath(rows,ledger,seconds,cutoff,seed.resolution,path,ignored))return;
 out.id="book_wave_correction:"+BKNHash(branch.id+"|"+BKNPointKey(rows,branch.fifth,branch.fifth_price,decimals));
 out.parent_id=branch.id;out.source_id=seed.source_id;out.points=1;
 out.anchor[0]=branch.fifth;out.price[0]=branch.fifth_price;out.known[0]=branch.fifth_known;out.confirmed[0]=true;
 out.state_known=branch.fifth_known;out.state="post_fifth_correction_developing";
 out.reason="ABC_or_new_opposite_impulse_degree_unresolved";
 int adverse=seed.up?-1:1,motive=-adverse;double sign=seed.up?1.0:-1.0;
 for(int ordinal=1;ordinal<=3;ordinal++){
  int start=out.anchor[ordinal-1],kind=ordinal==2?motive:adverse;
  int next=BKNWaveCountNext(path,start,kind,cutoff),end=next>=0?path[next].index:n-1;
  // Before the C break, a new fifth-direction extreme invalidates this
  // simple ABC branch. Expanded/complex corrections need their own proof.
  int limit=n-1;
  // Do not infer an index from wall time across session gaps.
  if(next>=0){limit=end;while(limit+1<n&&rows[limit+1].time+seconds<=path[next].known)limit++;}
  double boundary=ordinal==3&&out.expanded_b?out.price[2]:out.price[0];
  for(int k=start+1;k<=limit;k++)if(sign*(BKNResponseFavourable(rows[k],seed.up)-boundary)>0){
   // A known A followed by B beyond wave5 is an expanded-adjustment OR
   // extension alternative. Retain that branch instead of deleting A/B.
   // Before A is known, or after B is confirmed, the old branch is invalid.
   if(ordinal==2&&out.confirmed[1]&&out.known[1]<=rows[k].time+seconds)out.expanded_b=true;
   else {out.failure=k;break;}
  }
  if(out.failure>=0){out.state="post_fifth_extension_or_expanded_review";out.reason="fifth_extreme_revisited_no_simple_ABC_selection";out.state_known=rows[out.failure].time+seconds;return;}
  if(ordinal==3){
   for(int k=start+1;k<=end;k++)if(sign*(rows[k].close-out.price[1])<0){out.cross=k;break;}
   if(out.cross<0){out.state="post_fifth_C_trigger_pending";out.reason="B_rebound_or_complex_adjustment_C_not_triggered";return;}
   if(out.known[2]>rows[out.cross].time+seconds){out.state="post_fifth_B_confirmation_review";out.reason="B_not_known_at_first_C_break";return;}
  }
  int at=next>=0?path[next].index:start+1;
  if(at>=n)return;
  double price=next>=0?path[next].price:(kind==1?rows[at].high:rows[at].low);
  if(next<0)for(int k=at+1;k<n;k++){
   double p=kind==1?rows[k].high:rows[k].low;
   if(kind==1?p>price:p<price){at=k;price=p;}
  }
  if(kind*(price-out.price[ordinal-1])<=0)return;
  datetime known=(datetime)MathMax((long)out.known[ordinal-1],(long)(next>=0?path[next].known:rows[n-1].time+seconds));
  if(BKNWaveCountAmbiguous(ledger,start,at,known)){out.state="post_fifth_intrabar_order_review";out.reason="opposing_extrema_same_bar";return;}
  out.anchor[ordinal]=at;out.price[ordinal]=price;out.known[ordinal]=known;out.confirmed[ordinal]=next>=0;
  out.points=ordinal+1;out.state_known=known;
  out.state=ordinal==1?"post_fifth_A_candidate":ordinal==2?"post_fifth_B_candidate":"post_fifth_ABC_candidate";
  if(next<0){out.state="post_fifth_"+(ordinal==1?"A":ordinal==2?"B":"C")+"_developing";return;}
  if(ordinal==3){
   out.geometry_valid=!out.expanded_b;
   if(out.expanded_b){out.state="post_fifth_expanded_ABC_review";out.reason="expanded_correction_or_new_impulse_not_selected";}
  }
 }
}
#endif
