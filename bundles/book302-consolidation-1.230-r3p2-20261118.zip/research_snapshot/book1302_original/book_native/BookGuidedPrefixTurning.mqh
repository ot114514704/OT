#ifndef BOOK_GUIDED_PREFIX_TURNING
#define BOOK_GUIDED_PREFIX_TURNING
#include "BookGuidedTurningLife.mqh"
// Recover a ruler that really existed on an earlier CLOSED prefix. Later
// wicks/corrections cannot retrospectively erase it. This is an independently
// identified prefix, not a claim that it encloses the entire supplied parent.
// Earliest valid construction wins: never select the steepest hindsight fit.
BKNGuidedPair BKNGuidePrefixTurning(const MqlRates &rows[],const BKNScope &parent,
 const BKNGuidedPair &whole,int seconds,datetime cutoff,BKNScope &selected){
 BKNScopeCopy(selected,parent);
 BKNGuidedPair none;ZeroMemory(none);none.first=-1;none.second=-1;
 none.reason="no_prior_closed_prefix_ruler";
 if(parent.ambiguous||!parent.envelope)return none;
 if(BKNGuideScopeReason(rows,parent.a.index,parent.b.index,parent.up,seconds,parent.known,cutoff)!="")return none;
 for(int end=parent.a.index+4;end<parent.b.index;end++){
  datetime prefix_known=(datetime)MathMax((long)parent.a.known,(long)(rows[end].time+seconds));
  if(prefix_known>parent.known)continue;
  BKNGuidedPair pair=BKNGuideSelectBoundary(rows,parent.a.index,end,parent.up,!parent.up,seconds,prefix_known,prefix_known);
  if(!pair.valid)continue;
  // Preserve the first actual ruler even if later prefixes stop supporting
  // it. Its subsequent lifetime is evaluated with its immutable equation.
  if(whole.valid&&whole.first==pair.first&&whole.second==pair.second)return none;
  if(whole.valid&&MathAbs(whole.slope)>=MathAbs(pair.slope)-BKNGeometryTolerance(whole.slope,pair.slope))return none;
  BKNGuidedTurningLife life=BKNGuideObserveTurning(rows,pair,seconds,parent.known);
  if(!life.valid)return none;
  // A flatter final ruler is not rejected merely for being flatter. There
  // must be an actual opposite close through the earlier ruler first.
  if(whole.valid&&(life.cross<0||life.cross>whole.second))return none;
  selected.b.index=end;selected.b.time=rows[end].time;
  selected.b.price=parent.up?rows[end].high:rows[end].low;
  selected.b.kind=parent.up?1:-1;selected.b.known=prefix_known;
  selected.degree=0;selected.known=parent.known;
  // Parent discovery can be retrospective. Keep its conservative clock,
  // record the earlier construction separately in the emitted contract.
  pair.known=parent.known;return pair;
 }
 return none;
}
#endif
