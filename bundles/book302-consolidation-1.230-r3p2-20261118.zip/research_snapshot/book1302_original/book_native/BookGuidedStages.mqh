#ifndef BOOK_GUIDED_STAGES
#define BOOK_GUIDED_STAGES
#include "BookGuidedGeometry.mqh"
#include "BookNativePhases.mqh"
#include "BookNativeIdentity.mqh"
// Native successor stages retain their root and event proof. They are NOT
// replacement whole waves or author-degree admissions. The user's new three
// geometric roles are selected independently within each stage's own range.
struct BKNGuidedStage {
 bool valid,up,prospective;
 BKNScope scope;
 int d,e,f,recovery,root_first,root_last;
 datetime occurrence_known,known;
 string root_owner,root_phase_id,previous_phase_id,phase_id,event_id;
};
void BKNGuideAppendStage(BKNGuidedStage &out[],const BKNGuidedStage &stage){
 int n=ArraySize(out);ArrayResize(out,n+1,16);out[n]=stage;
}
string BKNGuideStageScopes(const MqlRates &rows[],const BKNScope &root,const BKNGuidedPair &turning,
 int seconds,datetime cutoff,string market,int decimals,string root_owner,BKNGuidedStage &out[]){
 ArrayResize(out,0);
 // A caller's geometric range is not sufficient proof of an unambiguous
 // native root. Recheck the source contract at this integration boundary;
 // do not rely on the Frame having filtered it before invoking this helper.
 if(root.ambiguous)return "stage_root_same_bar_order_unknown";
 if(!root.envelope)return "stage_root_enclosure_unavailable";
 if(root.a.known<=0||root.b.known<=0)return "stage_root_endpoint_knowledge_unavailable";
 string proof=BKNGuideScopeReason(rows,root.a.index,root.b.index,root.up,seconds,root.known,cutoff);
 if(proof!="")return proof;
 if(root.a.time!=rows[root.a.index].time||root.b.time!=rows[root.b.index].time||
  root.a.price!=BKNPhaseSide(rows[root.a.index],root.up)||root.b.price!=BKNPhaseOther(rows[root.b.index],root.up)||
  root.a.known>root.known||root.b.known>root.known)return "stage_root_native_endpoints_or_clock_mismatch";
 if(!turning.valid||turning.upper==root.up||turning.up!=root.up||turning.owner_first!=root.a.index||
  turning.owner_last!=root.b.index||turning.known!=root.known)return "stage_independent_turning_seed_unavailable";
 if(turning.first<root.a.index||turning.second<=turning.first||turning.second>=root.b.index)
  return "stage_turning_contacts_outside_root_or_at_terminal";
 if(turning.first_price!=BKNPhaseSide(rows[turning.first],root.up)||
  turning.second_price!=BKNPhaseSide(rows[turning.second],root.up))return "stage_turning_contacts_not_native";
 double native_slope=(turning.second_price-turning.first_price)/(turning.second-turning.first);
 if(!MathIsValidNumber(turning.slope)||MathAbs(native_slope-turning.slope)>BKNGeometryTolerance(native_slope,turning.slope))
  return "stage_turning_equation_mismatch";
 for(int k=root.a.index;k<=root.b.index;k++){
  double actual=BKNPhaseSide(rows[k],root.up),level=turning.first_price+turning.slope*(k-turning.first);
  if((root.up?actual-level:level-actual)<-BKNGeometryTolerance(actual,level))return "stage_turning_crosses_root";
 }
 BKNPhaseRuler seed,selected;ZeroMemory(seed);seed.qualified=true;seed.up=root.up;
 seed.start=turning.first;seed.end=turning.second;seed.start_price=turning.first_price;seed.end_price=turning.second_price;
 seed.slope=turning.slope;seed.known=turning.known;
 BKNPhaseEvent admitted[],candidates[];string reason;
 if(!BKNReviewSuccessors(rows,seconds,cutoff,seed,admitted,candidates,selected,reason,root.a.index))return reason;
 string root_phase="guided_native_seed:"+BKNHash(market+"|"+root_owner+"|"+
  BKNPointKey(rows,seed.start,seed.start_price,decimals)+">"+BKNPointKey(rows,seed.end,seed.end_price,decimals));
 string previous=root_phase;datetime dependency=root.known;
 for(int p=0;p<ArraySize(admitted);p++){
  BKNPhaseEvent event=admitted[p];
  if(!event.admitted||event.failures!=0||!event.f_confirmed||event.d<0||event.f<=event.d||
   event.e<=event.d||event.e>=event.f||event.recovery<=event.f||event.recovery>=ArraySize(rows)||event.previous_admission!=p-1){ArrayResize(out,0);return "stage_native_chain_invalid";}
  BKNGuidedStage stage;ZeroMemory(stage);stage.up=root.up;
  stage.d=event.d;stage.e=event.e;stage.f=event.f;stage.recovery=event.recovery;
  stage.root_first=root.a.index;stage.root_last=root.b.index;stage.root_owner=root_owner;
  stage.root_phase_id=root_phase;stage.previous_phase_id=previous;stage.occurrence_known=event.recovery_known;
  stage.known=(datetime)MathMax((double)dependency,(double)event.admission_known);
  stage.prospective=dependency<=rows[event.recovery].time&&event.f_known<=rows[event.recovery].time;
  // D is the actual new local origin. Use the actual favourable extreme in
  // D..the FIRST eligible recovery, not today's terminal or an infinite ray.
  int end=event.d;double sign=root.up?1.0:-1.0;
  for(int k=event.d+1;k<=event.recovery;k++)
   if(sign*BKNPhaseOther(rows[k],root.up)>sign*BKNPhaseOther(rows[end],root.up))end=k;
  BKNSNew(stage.scope.a,rows[event.d].time,stage.known,BKNPhaseSide(rows[event.d],root.up),root.up?-1:1,event.d);
  BKNSNew(stage.scope.b,rows[end].time,stage.known,BKNPhaseOther(rows[end],root.up),root.up?1:-1,end);
  stage.scope.known=stage.known;stage.scope.up=root.up;stage.scope.degree=0;
  stage.scope.envelope=BKNSEnvelope(rows,stage.scope.a,stage.scope.b);stage.scope.ambiguous=false;
  string check=BKNGuideScopeReason(rows,event.d,end,root.up,seconds,stage.known,cutoff);
  if(check!=""){ArrayResize(out,0);return "stage_owned_range_rejected:"+check;}
  string contacts=BKNPointKey(rows,event.d,BKNPhaseSide(rows[event.d],root.up),decimals)+">"+
   BKNPointKey(rows,event.f,BKNPhaseSide(rows[event.f],root.up),decimals);
  stage.phase_id="guided_native_stage:"+BKNHash(root_phase+"|"+contacts);
  stage.event_id="guided_stage_recovery:"+BKNHash(previous+"|"+stage.phase_id+"|"+
   BKNPointKey(rows,event.e,BKNPhaseOther(rows[event.e],root.up),decimals)+"|"+
   BKNPointKey(rows,event.recovery,rows[event.recovery].close,decimals)+"|"+IntegerToString((long)stage.known));
  stage.valid=true;BKNGuideAppendStage(out,stage);previous=stage.phase_id;dependency=stage.known;
 }
 return ArraySize(out)>0?"native_stage_scopes_registered":reason;
}
#endif
