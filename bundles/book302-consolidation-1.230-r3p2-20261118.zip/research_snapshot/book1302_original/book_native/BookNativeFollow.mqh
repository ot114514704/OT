#ifndef BOOK_NATIVE_FOLLOW
#define BOOK_NATIVE_FOLLOW
#include "BookNativeEvents.mqh"
// Port of classify_pullback_and_retest / invalidate_structure without a
// supplied chapter-5 B. Reference is the actual crossing price AT THE BREAK,
// not the later projected line and not the breaking candle's close.
// A B-stop source must be separately admitted before using its wick rule;
// this fallback cannot silently manufacture such a B or stop permission.
struct BKNFollow {
 bool evaluated,retouched,invalidated,automatic_trade_permission;
 int broken,last,touch,invalid;
 double reference;
 datetime known,invalid_known;
 string status,invalid_status,basis,reason;
};
BKNFollow BKNObserveFollow(const MqlRates &bars[],const BKNFrozenRuler &r,
                           const BKNBoundaryEvents &event,int seconds,datetime cutoff,int decimals){
 BKNFollow out;ZeroMemory(out);out.status="unknown";out.invalid_status="unknown";
 out.broken=-1;out.touch=-1;out.invalid=-1;out.last=-1;out.reference=EMPTY_VALUE;
 out.basis="closed_bar_recovered_through_break_level";out.reason="break_unknown";
 if(seconds<=0||!r.qualified||!event.evaluated||event.broken<0)return out;
 out.reason="unbound_native_break";
 int i=event.broken,n=0;datetime previous=0;bool future_seen=false;
 for(int k=0;k<ArraySize(bars);k++){
  if(bars[k].time+seconds>cutoff){future_seen=true;continue;}
  if(future_seen||bars[k].time<=previous||!BKNValidRate(bars[k])||bars[k].low<=0)return out;
  previous=bars[k].time;n++;
 }
 if(i>=n||r.first<0||r.second<=r.first||r.second>=n||r.start<0||r.start>=n||
    r.construction_known<=0||event.break_known<r.construction_known||
    event.break_known<bars[i].time+seconds||event.break_known>cutoff)return out;
 long gap;
 if(!BKNGapNumerator(bars[i].close,r,i,decimals,gap)||gap>=0)return out;
 out.broken=i;out.last=n-1;out.reference=BKNFrozenLevel(r,i);
 out.known=(datetime)MathMax((double)event.break_known,(double)(bars[n-1].time+seconds));
 out.reason="";out.evaluated=true;
 if(i+1>=n){out.status="pending";out.invalid_status="pending";return out;}
 // Evaluate ALL closed bars. A later price gap does not count as a retest
 // unless the candle range actually contains the fixed price.
 for(int k=i+1;k<n;k++){
  long low,high,close;
  // k deliberately remains i in the ruler call: frozen horizontal price.
  if(!BKNGapNumerator(bars[k].low,r,i,decimals,low)||
     !BKNGapNumerator(bars[k].high,r,i,decimals,high)||
     !BKNGapNumerator(bars[k].close,r,i,decimals,close)){
   out.evaluated=false;out.status="unknown";out.invalid_status="unknown";
   out.reason="follow_native_quote_grid_unavailable";out.retouched=false;out.invalidated=false;
   out.touch=-1;out.invalid=-1;return out;
  }
  bool inside=r.up?(low<=0&&high>=0):(high<=0&&low>=0);
  if(out.touch<0&&inside)out.touch=k;
  // Positive gap is back on the prior trend's side. With no admitted B,
  // only a strict CLOSE recovery invalidates, never a wick or equality.
  if(out.invalid<0&&close>0)out.invalid=k;
 }
 out.retouched=out.touch>=0;out.invalidated=out.invalid>=0;
 out.status=out.retouched?"retest_observed":"not_observed";
 out.invalid_status=out.invalidated?"invalidated":"not_invalidated";
 out.invalid_known=out.invalidated?(datetime)MathMax((double)event.break_known,(double)(bars[out.invalid].time+seconds)):out.known;
 return out;
}
#endif
