#ifndef BOOK_GUIDED_TURNING_LIFE
#define BOOK_GUIDED_TURNING_LIFE
#include "BookGuidedGeometry.mqh"
// The equation is fixed by the supplied formation owner. Subsequent bars
// observe that equation; they are NEVER fed back as replacement contacts.
// A close across the line is a geometric observation, not author-confirmed
// reversal, a double-line break, wave admission, or permission to trade.
struct BKNGuidedTurningLife {
 bool valid,retrospective;
 int last,touch,cross;
 datetime display_known,touch_known,cross_known;
 string state,reason;
};
BKNGuidedTurningLife BKNGuideObserveTurning(const MqlRates &rows[],const BKNGuidedPair &pair,
 int seconds,datetime cutoff){
 BKNGuidedTurningLife out;ZeroMemory(out);out.last=-1;out.touch=-1;out.cross=-1;
 out.reason="turning_formation_unavailable";if(!pair.valid)return out;
 out.reason="turning_formation_wrong_side";if(pair.upper==pair.up)return out;
 out.reason=BKNGuideScopeReason(rows,pair.owner_first,pair.owner_last,pair.up,seconds,pair.known,cutoff);
 if(out.reason!="")return out;
 out.reason="turning_contacts_outside_formation";
 if(pair.first<pair.owner_first||pair.second>=pair.owner_last||pair.second<=pair.first)return out;
 double pa=pair.upper?rows[pair.first].high:rows[pair.first].low;
 double pb=pair.upper?rows[pair.second].high:rows[pair.second].low;
 out.reason="turning_equation_not_native";
 double slope=(pb-pa)/(pair.second-pair.first);
 if(pa!=pair.first_price||pb!=pair.second_price||
    MathAbs(slope-pair.slope)>BKNGeometryTolerance(slope,pair.slope)||(pair.up?slope<=0:slope>=0))return out;
 for(int i=(pair.forward_only?pair.first:pair.owner_first);i<=pair.owner_last;i++){
  double level=BKNGuideLevel(pair,i),actual=pair.upper?rows[i].high:rows[i].low;
  out.reason="turning_crosses_formation";
  if(pair.upper?actual>level+BKNGeometryTolerance(actual,level):actual<level-BKNGeometryTolerance(actual,level))return out;
 }
 out.valid=true;out.reason="";out.last=pair.owner_last;
 out.display_known=pair.known;out.state="formation_only";
 for(int i=pair.owner_last+1;i<ArraySize(rows);i++){
  // Do not read OHLC of a forming or future bar, even when the caller retains
  // more rows than its requested prefix. Do not bridge missing native bars.
  if(rows[i].time+seconds>cutoff)break;
  if(rows[i].time-rows[i-1].time!=seconds){out.state="observation_gap";break;}
  if(!BKNValidRate(rows[i])){out.state="observation_invalid_bar";break;}
  double line=BKNGuideLevel(pair,i),extreme=pair.upper?rows[i].high:rows[i].low;
  double tolerance=BKNGeometryTolerance(extreme,line);
  bool touched=pair.upper?extreme>=line-tolerance:extreme<=line+tolerance;
  double close_tolerance=BKNGeometryTolerance(rows[i].close,line);
  bool crossed=pair.upper?rows[i].close>line+close_tolerance:rows[i].close<line-close_tolerance;
  out.last=i;out.display_known=(datetime)MathMax((long)pair.known,(long)(rows[i].time+seconds));
  if(touched&&out.touch<0){out.touch=i;out.touch_known=rows[i].time+seconds;}
  out.state=out.touch>=0?"wick_contact_observed":"awaiting_opposite_cross";
  if(crossed){
   out.cross=i;out.cross_known=rows[i].time+seconds;
   out.retrospective=out.cross_known<pair.known;
   out.state=out.retrospective?"retrospective_close_cross":"closed_bar_cross_observed";
   break;
  }
 }
 return out;
}
#endif
