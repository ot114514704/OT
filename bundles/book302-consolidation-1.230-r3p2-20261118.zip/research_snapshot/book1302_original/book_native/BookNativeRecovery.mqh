#ifndef BOOK_NATIVE_RECOVERY
#define BOOK_NATIVE_RECOVERY
#include "BookNativeEvents.mqh"
// Independent chapter4 D-F shifted to ORIGINAL C. Not the C-E/D boundary,
// not a same-slope channel, not a replacement for a failed first F.
struct BKNRecovery {
 bool qualified;
 int c,d,e,f,observable,display_end,target_contact,source_contact,invalid;
 double c_price,d_price,f_price,slope;
 datetime construction_known,display_known,state_known,known;
 string parent_wave_id,status,reason,event_order,display_basis;
};
bool BKNValidateCDE(const MqlRates &rows[],const BKNTurning &t,int decimals,string &reason){
 reason="CDE_construction_not_qualified";if(!t.qualified)return false;
 int c=t.c,d=t.d,e=t.e,z=t.observable;
 reason="CDE_native_order_invalid";
 if(t.origin<0||c<0||c>=d||d>=e||e>z||z>=ArraySize(rows)||t.origin>=e)return false;
 if(c<t.origin){
  reason="C_not_adjacent_parent_context";
  int seconds=(int)(rows[c+1].time-rows[c].time);
  if(d!=t.origin||BKNAdjacentConstructionStart(rows,t.origin,t.terminal,t.up,seconds)!=c)return false;
 }
 reason="CDE_anchor_price_not_native";
 if(t.c_price<=0||t.d_price<=0||t.e_price<=0||!MathIsValidNumber(t.c_price)||!MathIsValidNumber(t.d_price)||!MathIsValidNumber(t.e_price)||
   t.c_price!=BKNTurnSide(rows[c],t.up)||t.d_price!=BKNTurnSide(rows[d],t.up,true)||t.e_price!=BKNTurnSide(rows[e],t.up))return false;
 double slope=(t.e_price-t.c_price)/(e-c),sign=t.up?1.0:-1.0;
 reason="CDE_slope_mismatch";if(!MathIsValidNumber(t.slope)||MathAbs(t.slope-slope)>1e-10*MathMax(1,MathAbs(slope)))return false;
 reason="CDE_extension_not_advancing_in_parent_direction";if(sign*slope<=0)return false;
 int actual=c+1;
 for(int k=c+2;k<e;k++)if(sign*BKNTurnSide(rows[k],t.up,true)<sign*BKNTurnSide(rows[actual],t.up,true))actual=k;
 reason="D_not_C_E_adjustment_extreme";if(d!=actual)return false;
 int confirmation_first=(int)MathMax(0,MathMin(t.origin,c)-2);
 reason="D_confirmation_not_inside_C_E";if(d-2<confirmation_first||d+2>e)return false;
 reason="D_local_extreme_unconfirmed";if(!BKNLocalExtremum(rows,confirmation_first,z,d,t.up,2))return false;
 BKNFrozenRuler ruler;ZeroMemory(ruler);ruler.first=c;ruler.second=e;ruler.start=c;
 ruler.first_price=t.c_price;ruler.second_price=t.e_price;ruler.start_price=t.c_price;ruler.up=!t.up;
 long gap;
 for(int k=0;k<=z;k++)if(!BKNValidRate(rows[k])||rows[k].low<=0){reason="CDE_native_prices_invalid";return false;}
 // Same source-envelope contract as the producer: extra exact tangencies
 // are permitted. Use native quote-grid integer proof for all consumers.
 // The same tangent-versus-crossing distinction applies after shifting to D.
 reason="C_E_extension_crosses_native_bar";
 for(int k=c+1;k<=z;k++)if(k!=e){
  if(!BKNGapNumerator(BKNTurnSide(rows[k],t.up),ruler,k,decimals,gap)){reason="CDE_native_quote_grid_unavailable";return false;}
  if(gap<0)return false;
 }
 reason="earlier_parent_wave_outside_C_E_extension";
 for(int k=t.origin;k<c;k++){
  if(!BKNGapNumerator(BKNTurnSide(rows[k],t.up),ruler,k,decimals,gap)){reason="CDE_native_quote_grid_unavailable";return false;}
  if(gap<0)return false;
 }
 ruler.start=d;ruler.start_price=t.d_price;ruler.up=t.up;
 reason="shifted_D_line_crosses_C_E_leg";
 for(int k=d+1;k<=e;k++){
  if(!BKNGapNumerator(BKNTurnSide(rows[k],t.up,true),ruler,k,decimals,gap)){reason="CDE_native_quote_grid_unavailable";return false;}
  if(gap<0)return false;
 }
 reason="";return true;
}
BKNRecovery BKNRecoveryProjection(const MqlRates &bars[],const BKNTurning &turning,string parent_wave_id,
                                   int seconds,datetime cutoff,int decimals){
 BKNRecovery out;ZeroMemory(out);out.f=-1;out.target_contact=-1;out.source_contact=-1;out.invalid=-1;
 out.reason="C_D_E_unknown";if(!turning.qualified)return out;
 out.reason="parent_wave_identity_unknown";if(parent_wave_id=="")return out;
 out.parent_wave_id=parent_wave_id;
 MqlRates rows[];int n=0;datetime previous=0;
 for(int k=0;k<ArraySize(bars);k++){
  if(bars[k].time+seconds>cutoff)continue;
  if(k!=n||bars[k].time<=previous||!BKNValidRate(bars[k])){out.reason="invalid_native_recovery_prefix";return out;}
  ArrayResize(rows,n+1,256);rows[n++]=bars[k];previous=bars[k].time;
 }
 string proof;out.reason="source_CDE_not_reproduced";if(!BKNValidateCDE(rows,turning,decimals,proof))return out;
 out.reason="CDE_dependency_clock_unbound";
 if(seconds<=0||rows[turning.observable].time+seconds>turning.known_at||turning.known_at>cutoff)return out;
 int c=turning.c,d=turning.d,e=turning.e,terminal=(int)MathMax(e,turning.terminal);bool up=turning.up;
 out.reason="C_D_E_order_unknown";if(terminal>=n)return out;
 double sign=up?1.0:-1.0,dp=BKNTurnSide(rows[d],up,true),cp=BKNTurnSide(rows[c],up);
 int f=-1;
 for(int k=terminal+1;k<n;k++){
  if(sign*(BKNTurnSide(rows[k],up,true)-dp)<=0){out.reason="D_breached_before_F_confirmation";return out;}
  if(k<terminal+3)continue;
  int p=k-2;double price=BKNTurnSide(rows[p],up,true);bool strict=true;
  for(int j=p-2;j<=p+2;j++)if(j!=p&&sign*(BKNTurnSide(rows[j],up,true)-price)<=0){strict=false;break;}
  if(strict){f=p;break;}
 }
 out.reason="F_not_confirmed";if(f<0)return out;
 double fp=BKNTurnSide(rows[f],up,true),slope=(fp-dp)/(f-d);
 out.reason="DF_direction_mismatch";if(sign*slope<=0)return out;
 int observable=f+2;
 // Formation support is allowed to touch an additional wick. A genuine
 // crossing is negative on the native quote-grid numerator. Do not reuse
 // the later-observation contact rule here, or reject exact tangencies as
 // though D/F had pierced price. F confirmation and post-formation events
 // deliberately retain their distinct, existing rules.
 BKNFrozenRuler formation;ZeroMemory(formation);
 formation.first=d;formation.second=f;formation.start=d;
 formation.first_price=dp;formation.second_price=fp;formation.start_price=dp;formation.up=up;
 long formation_gap;
 out.reason="DF_not_outer_extension";
 for(int k=d+1;k<=observable;k++)if(k!=f){
  if(!BKNGapNumerator(BKNTurnSide(rows[k],up,true),formation,k,decimals,formation_gap)){out.reason="DF_native_quote_grid_unavailable";return out;}
  if(formation_gap<0)return out;
 }
 formation.start=c;formation.start_price=cp;formation.up=!up;
 out.reason="C_shift_crosses_established_prices";
 for(int k=c+1;k<=observable;k++){
  if(!BKNGapNumerator(BKNTurnSide(rows[k],up),formation,k,decimals,formation_gap)){out.reason="C_shift_native_quote_grid_unavailable";return out;}
  if(formation_gap<0)return out;
 }
 datetime known=(datetime)MathMax((double)(rows[observable].time+seconds),(double)turning.known_at);
 out.reason="construction_not_yet_known";if(known>cutoff)return out;
 // Formation and observation use the SAME exact native quote equation.
 // A binary rounding tail must neither miss equality nor split a same-bar
 // two-sided contact. Keep independent D/F and D/F shifted to original C.
 BKNFrozenRuler source_ruler=formation;
 source_ruler.start=d;source_ruler.start_price=dp;source_ruler.up=up;
 BKNFrozenRuler target_ruler=formation;
 int terminal_event=-1;
 for(int k=observable+1;k<n;k++){
  long source_gap,target_gap;
  if(!BKNGapNumerator(BKNTurnSide(rows[k],up,true),source_ruler,k,decimals,source_gap)||
     !BKNGapNumerator(BKNTurnSide(rows[k],up),target_ruler,k,decimals,target_gap)){
   out.reason="recovery_observation_native_quote_grid_unavailable";return out;
  }
  // Observe ALL boundaries on this candle; OHLC supplies no event ordering.
  if(sign*(BKNTurnSide(rows[k],up,true)-dp)<=0)out.invalid=k;
  if(source_gap<=0)out.source_contact=k;
  if(target_gap<=0)out.target_contact=k;
  if(out.invalid>=0||out.source_contact>=0||out.target_contact>=0){terminal_event=k;break;}
 }
 out.c=c;out.d=d;out.e=e;out.f=f;out.observable=observable;out.c_price=cp;out.d_price=dp;out.f_price=fp;out.slope=slope;
 out.display_end=terminal_event>=0?terminal_event-1:n-1;
 out.construction_known=known;out.display_known=(datetime)MathMax((double)known,(double)(rows[out.display_end].time+seconds));
 out.display_basis="last_clean_display_extent";
 out.state_known=terminal_event>=0?(datetime)MathMax((double)known,(double)(rows[terminal_event].time+seconds)):known;
 out.known=(datetime)MathMax((double)out.display_known,(double)out.state_known);
 out.status=out.invalid>=0&&out.target_contact>=0?"source_D_invalidated_and_target_contact_same_bar":
  out.invalid>=0?"source_D_invalidated":out.source_contact>=0&&out.target_contact>=0?"both_boundaries_contact_same_bar":
  out.source_contact>=0?"source_DF_contact_observed":out.target_contact>=0?"target_contact_observed":"theoretical_target_pending";
 int events=(out.invalid>=0?1:0)+(out.source_contact>=0?1:0)+(out.target_contact>=0?1:0);
 out.event_order=events>1?"unknown_same_native_bar":events==1?"single_event":"no_terminal_event";
 out.qualified=true;out.reason="";return out;
}
#endif
