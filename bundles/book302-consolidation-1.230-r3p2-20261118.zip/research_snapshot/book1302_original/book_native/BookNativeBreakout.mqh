#ifndef BOOK_NATIVE_BREAKOUT
#define BOOK_NATIVE_BREAKOUT
#include "BookNativeEvents.mqh"
#include "BookNativeForce.mqh"
// Original two-candle boundary score and current frozen-line observation.
// This explicitly unfitted domain must never borrow full-wave calibration.
struct BKNBoundaryMotion {
 bool measured;
 string state,reason;
 int age,hold_run,reentries,reclaims;
 double distance_atr,progress_atr,maximum_progress_atr,giveback_atr,outside_fraction;
 double price_contribution,line_contribution,distance_change;
 datetime known,first_return_known,latest_reclaim_known;
};
struct BKNBoundaryScore {
 string status,reason,grade;
 bool scored,follow_directional,follow_holds,prospective;
 int broken;
 double score,atr,height_atr,speed_atr,efficiency,directional_close,body,close_location,overlap;
 datetime event_known,known,normalised_through,score_event_close;
 BKNBoundaryMotion motion;
};
BKNBoundaryMotion BKNObserveBoundary(const MqlRates &rows[],const BKNFrozenRuler &r,int index,
                                    int seconds,datetime cutoff,int decimals,double atr,datetime known){
 BKNBoundaryMotion out;ZeroMemory(out);out.state="unknown";out.reason="invalid_break_index";
 int n=0;for(int i=0;i<ArraySize(rows);i++)if(rows[i].time+seconds<=cutoff)n++;
 if(index<0||index>=n)return out;
 out.reason="invalid_frozen_normalisation";if(atr<=0||!MathIsValidNumber(atr))return out;
 out.reason="boundary_not_known_at_cutoff";if(known>cutoff)return out;
 out.reason="follow_close_unavailable";if(n-index<2)return out;
 int begin=(int)MathMax(0,index-15);
 for(int k=begin;k<n;k++){
  if(!BKNValidRate(rows[k])||rows[k].low<=0){out.reason="invalid_native_OHLC";return out;}
  if(k>begin&&rows[k].time-rows[k-1].time!=seconds){out.reason="native_history_gap";return out;}
 }
 int sign=r.up?-1:1,span=r.second-r.first;long last=0,previous=0;int outside=0;double peak=0,current=0;
 for(int k=index;k<n;k++){
  long gap;
  if(!BKNGapNumerator(rows[k].close,r,k,decimals,gap)){out.reason="native_decimal_gap_unavailable";return out;}
  gap=-gap; // positive means outside in the break direction.
  if(k>index){
   if(gap<=0&&previous>0){out.reentries++;if(out.first_return_known==0)out.first_return_known=rows[k].time+seconds;}
   if(gap>0&&previous<=0){out.reclaims++;out.latest_reclaim_known=rows[k].time+seconds;}
  }
  if(gap>0){outside++;out.hold_run++;}else out.hold_run=0;
  current=sign*(rows[k].close-rows[index].close);peak=MathMax(peak,current);last=gap;previous=gap;
 }
 out.state=last==0?"on_boundary":last<0?"returned_inside":out.reentries>0?"reclaimed_after_return":"holding_outside";
 out.age=n-index-1;out.distance_atr=((double)last)/MathPow(10.0,decimals)/span/atr;
 out.progress_atr=current/atr;out.maximum_progress_atr=peak/atr;out.giveback_atr=(peak-current)/atr;
 out.outside_fraction=outside/(double)(n-index);
 out.price_contribution=current;out.line_contribution=-sign*(BKNFrozenLevel(r,n-1)-BKNFrozenLevel(r,index));
 out.distance_change=out.price_contribution+out.line_contribution;
 out.known=(datetime)MathMax((double)known,(double)(rows[n-1].time+seconds));out.measured=true;out.reason="";return out;
}
BKNBoundaryScore BKNScoreBoundary(const MqlRates &rows[],const BKNFrozenRuler &r,int observable,
                                 int break_index,int seconds,datetime cutoff,int decimals,datetime event_known=0){
 BKNBoundaryScore out;ZeroMemory(out);out.status="waiting_boundary";out.grade="unknown";out.score=EMPTY_VALUE;out.broken=-1;
 if(!r.qualified||seconds<=0){out.status="unknown";out.reason="native_boundary_unavailable";return out;}
 if(break_index<0)return out;
 int n=0;for(int k=0;k<ArraySize(rows);k++)if(rows[k].time+seconds<=cutoff)n++;
 out.status="unknown";out.reason="event_does_not_match_native_boundary";
 if(observable<0||break_index<=observable||break_index>=n)return out;
 long gap;
 if(!BKNGapNumerator(rows[break_index].close,r,break_index,decimals,gap)||gap>=0)return out;
 out.reason="event_not_first_native_closed_break";
 for(int k=observable+1;k<break_index;k++){
  if(!BKNGapNumerator(rows[k].close,r,k,decimals,gap)||gap<0)return out;
 }
 datetime close=rows[break_index].time+seconds;
 datetime known=(datetime)MathMax((double)close,MathMax((double)r.construction_known,(double)event_known));
 out.reason="source_knowledge_unavailable";if(known>cutoff)return out;
 out.broken=break_index;out.event_known=known;out.prospective=r.construction_known<=rows[break_index].time;out.known=known;
 if(break_index+1>=n){out.status="pending_follow_close";out.reason="";return out;}
 out.reason="follow_native_continuity_unknown";
 if(rows[break_index+1].time-rows[break_index].time!=seconds)return out;
 out.reason="insufficient_pre_break_normalisation";if(break_index<15)return out;
 double atr=0;
 for(int k=break_index-14;k<break_index;k++)atr+=MathMax(rows[k].high-rows[k].low,
  MathMax(MathAbs(rows[k].high-rows[k-1].close),MathAbs(rows[k].low-rows[k-1].close)));
 atr/=14.0;out.reason="zero_pre_break_range";if(atr<=0)return out;
 int i=break_index,j=i+1;double sign=r.up?-1.0:1.0,move=sign*(rows[j].close-rows[i].close);
 double range0=rows[i].high-rows[i].low,range1=rows[j].high-rows[j].low;
 double overlap=MathMax(0.0,MathMin(rows[i].high,rows[j].high)-MathMax(rows[i].low,rows[j].low));
 out.height_atr=MathMax(0.0,move)/atr;out.speed_atr=out.height_atr;
 out.efficiency=move>0?1:0;out.directional_close=out.efficiency;
 out.body=(MathMax(0.0,sign*(rows[i].close-rows[i].open))+MathMax(0.0,sign*(rows[j].close-rows[j].open)))/MathMax(range0+range1,1e-12);
 out.close_location=((r.up?rows[i].high-rows[i].close:rows[i].close-rows[i].low)/MathMax(range0,1e-12)+
  (r.up?rows[j].high-rows[j].close:rows[j].close-rows[j].low)/MathMax(range1,1e-12))/2.0;
 out.overlap=overlap/MathMax(MathMin(range0,range1),1e-12);
 out.score=NormalizeDouble(100*(.15*BKNClampUnit(out.height_atr/4)+.15*BKNClampUnit(out.speed_atr)+
  .20*BKNClampUnit(out.efficiency)+.10*BKNClampUnit(out.directional_close)+.15*BKNClampUnit(out.body)+
  .10*BKNClampUnit(out.close_location)+.15*BKNClampUnit(1-out.overlap)),2);
 out.grade=BKNForceGrade(out.score);out.atr=atr;out.normalised_through=rows[i-1].time+seconds;
 out.score_event_close=rows[j].time+seconds;out.known=(datetime)MathMax((double)known,(double)out.score_event_close);
 out.follow_directional=move>0;out.follow_holds=BKNGapNumerator(rows[j].close,r,j,decimals,gap)&&gap<0;
 out.scored=true;out.status="scored";out.reason="";
 out.motion=BKNObserveBoundary(rows,r,i,seconds,cutoff,decimals,atr,out.known);return out;
}
#endif
