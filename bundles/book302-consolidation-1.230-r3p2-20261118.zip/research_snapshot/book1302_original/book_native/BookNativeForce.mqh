#ifndef BOOK_NATIVE_FORCE
#define BOOK_NATIVE_FORCE
// Pure MQL5 measurements. No file, IPC, network, DLL or order calls.
// Book-owned numerical force port; the latest adverse-origin gate is required.
// No Machine1 1:1/three-push family. Source discovery/author degree remain
// separate from these descriptive measurements and embedded 45/70 thresholds.
// Measurement and whole-wave display both use the continuous seven-feature
// BKNImpulseScore v2. Saturated v1 fixture scores remain historical evidence.
struct BKNForce {
 string status,grade;
 double score,height_atr,speed_atr,efficiency,directional_close,body,close_location,overlap,atr;
 datetime normalised_through,terminal_close,known_at,earlier_extreme_time,adverse_extreme_time;
 double earlier_extreme_price,adverse_extreme_price;
 int bars,gap_count;
 bool observed;
};
double BKNClampUnit(double x){return MathMax(0.0,MathMin(1.0,x));}
double BKNClampScore(double x){return MathMax(0.0,MathMin(100.0,x));}
string BKNForceGrade(double score,double low=45,double high=70){
 return score<low?"weak":(score>=high?"strong":"medium");
}
// Whole-wave engineering display v2: preserve the seven original weights and
// raw features, but do not collapse every >4ATR wave and >1ATR/bar speed to
// the same maximum30points. The former scale constants become half-response
// scales. Each finite increase still contributes; there is no fitted model,
// author-labelled threshold, later retracement input or cross-wave hindsight.
double BKNImpulseScore(const BKNForce &f){
 if(!f.observed||f.height_atr<0||f.speed_atr<0||
    !MathIsValidNumber(f.height_atr)||!MathIsValidNumber(f.speed_atr))return EMPTY_VALUE;
 return NormalizeDouble(100.0*(.15*f.height_atr/(f.height_atr+4.0)+
  .15*f.speed_atr/(f.speed_atr+1.0)+.20*BKNClampUnit(f.efficiency)+
  .10*BKNClampUnit(f.directional_close)+.15*BKNClampUnit(f.body)+
  .10*BKNClampUnit(f.close_location)+.15*BKNClampUnit(1.0-f.overlap)),2);
}
// Array order must be chronological, even if its caller uses series arrays.
// Anchors and known_at must use the same native clock as the bars.
BKNForce BKNMeasureForce(const MqlRates &rows[],const datetime a,const double pa,
 const datetime b,const double pb,const datetime known,const int seconds,
 const bool observed_bars_only=false){
 BKNForce f;ZeroMemory(f);f.status="endpoint_or_close_not_yet_known";f.grade="unknown";f.score=EMPTY_VALUE;
 if(seconds<=0||b+seconds>known||a>=b||pa==pb)return f;
 int first=-1,last=-1,prior=-1,count=ArraySize(rows);
 for(int i=0;i<count;i++){
  if(rows[i].time+seconds>known)continue;
  if(rows[i].time<a)prior=i;
  if(rows[i].time>=a&&rows[i].time<=b){if(first<0)first=i;last=i;}
 }
 f.status="incomplete_source_window";
 if(first<0||last<=first||rows[first].time!=a||rows[last].time!=b)return f;
 f.status="unverified_source_continuity";
 for(int i=first+1;i<=last;i++){
  if(rows[i].time<=rows[i-1].time)return f;
  if(rows[i].time-rows[i-1].time!=seconds){f.gap_count++;if(!observed_bars_only)return f;}
 }
 f.status="endpoint_price_outside_native_bar";
 if(pa<rows[first].low-1e-7||pa>rows[first].high+1e-7||pb<rows[last].low-1e-7||pb>rows[last].high+1e-7)return f;
 bool up=pb>pa;int extreme=-1;
 for(int i=first+1;i<last;i++){
  if(up?rows[i].high>pb+1e-7:rows[i].low<pb-1e-7){
   if(extreme<0||(up?rows[i].high>rows[extreme].high:rows[i].low<rows[extreme].low))extreme=i;
  }
 }
 if(extreme>=0){f.status="source_terminal_preceded_by_further_extreme";f.earlier_extreme_time=rows[extreme].time;f.earlier_extreme_price=up?rows[extreme].high:rows[extreme].low;return f;}
 int adverse=-1;
 for(int i=first+1;i<last;i++)if(up?rows[i].low<pa-1e-7:rows[i].high>pa+1e-7){
  if(adverse<0||(up?rows[i].low<rows[adverse].low:rows[i].high>rows[adverse].high))adverse=i;
 }
 if(adverse>=0){f.status="source_origin_overtaken_by_adverse_extreme";
  f.adverse_extreme_time=rows[adverse].time;f.adverse_extreme_price=up?rows[adverse].low:rows[adverse].high;return f;}
 f.status="insufficient_pre_source_normalisation";
 if(prior<14)return f;
 double atr=0;
 for(int i=prior-13;i<=prior;i++)atr+=MathMax(rows[i].high-rows[i].low,MathMax(MathAbs(rows[i].high-rows[i-1].close),MathAbs(rows[i].low-rows[i-1].close)));
 atr/=14.0;f.status="zero_pre_source_range";if(atr<=0)return f;
 double travel=0,overlap=0,direction=0,bodies=0,ranges=0,location=0,sign=up?1.0:-1.0;
 for(int i=first;i<=last;i++){
  double range=rows[i].high-rows[i].low;ranges+=range;
  bodies+=MathMax(0.0,sign*(rows[i].close-rows[i].open));
  location+=(up?rows[i].close-rows[i].low:rows[i].high-rows[i].close)/MathMax(1e-12,range);
  if(i==first)continue;
  travel+=MathAbs(rows[i].close-rows[i-1].close);
  if(sign*(rows[i].close-rows[i-1].close)>0)direction++;
  overlap+=MathMax(0.0,MathMin(rows[i].high,rows[i-1].high)-MathMax(rows[i].low,rows[i-1].low))/MathMax(1e-12,MathMin(range,rows[i-1].high-rows[i-1].low));
 }
 f.bars=last-first+1;double steps=f.bars-1;
 f.height_atr=MathAbs(pb-pa)/atr;f.speed_atr=f.height_atr/steps;
 f.efficiency=travel>0?MathAbs(rows[last].close-rows[first].close)/travel:0;
 f.directional_close=direction/steps;f.body=ranges>0?bodies/ranges:0;
 f.close_location=location/f.bars;f.overlap=overlap/steps;f.atr=atr;
 // Keep the measured score and the displayed impulse score on one formula.
 // The old inline expression saturated height/speed early, while
 // BKNImpulseScore() is the current continuous whole-wave v2 definition.
 // Set observed before calling it because the helper deliberately rejects
 // unconfirmed records.
 f.normalised_through=rows[prior].time+seconds;
 f.terminal_close=b+seconds;f.known_at=known;f.status="observed";f.observed=true;
 f.score=BKNImpulseScore(f);f.grade=BKNForceGrade(f.score);return f;
}

#endif
