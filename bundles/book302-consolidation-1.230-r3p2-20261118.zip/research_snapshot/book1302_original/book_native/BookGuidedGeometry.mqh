#ifndef BOOK_GUIDED_GEOMETRY
#define BOOK_GUIDED_GEOMETRY
#include "BookNativeGeometry.mqh"
// The frozen geometry header's legacy observation helper calls the original
// turning primitives. Include their definitions for standalone compilation.
#include "BookNativeTurning.mqh"
// Implementation of the user-confirmed 2026-10-31 geometry roles.
// Caller supplies an independently established A/B owner. These functions
// validate that supplied scope; they do not infer an author trend or degree.
// No files, Python, network, snapshots, DLLs or order APIs are used.
struct BKNGuidedPair {
 bool valid,upper,up,axis_review,position_review,forward_only;
 int owner_first,owner_last,first,second,candidates,span,swing_contacts;
 double first_price,second_price,slope,axis_slope,axis_error,center_error;
 datetime known;
 string reason,contact_evidence;
};
struct BKNGuidedChannel {
 bool valid,up;
 int owner_first,owner_last,source_first,source_second,contact;
 double source_first_price,source_second_price,slope,offset,contact_price;
 datetime known;
 string reason;
};
string BKNGuideScopeReason(const MqlRates &rows[],int first,int last,bool up,
                          int seconds,datetime known,datetime cutoff){
 if(seconds<=0||first<0||last<=first||last>=ArraySize(rows))return "native_owner_range_invalid";
 if(known<=0||known>cutoff||rows[last].time+seconds>known)return "native_owner_clock_invalid";
 double origin=up?rows[first].low:rows[first].high;
 double terminal=up?rows[last].high:rows[last].low;
 if(up?terminal<=origin:terminal>=origin)return "native_owner_direction_invalid";
 double lo=MathMin(origin,terminal),hi=MathMax(origin,terminal);
 for(int k=first;k<=last;k++){
  if(!BKNValidRate(rows[k]))return "native_owner_OHLC_invalid";
  if(k>first&&rows[k].time-rows[k-1].time!=seconds)return "native_owner_time_gap";
  if(rows[k].time+seconds>known)return "native_owner_bar_not_known";
  if(rows[k].low<lo-BKNGeometryTolerance(rows[k].low,lo)||
     rows[k].high>hi+BKNGeometryTolerance(rows[k].high,hi))return "native_owner_envelope_invalid";
 }
 return "";
}
double BKNGuideLevel(const BKNGuidedPair &pair,int index){
 return pair.first_price+pair.slope*(index-pair.first);
}
// All admissible real outer-wick pairs are considered. No automatic origin
// exception, hull adjacency restriction, D selection or opposite-rail score
// can decide which boundary is selected. Native swing confirmation is separate
// evidence; the optional swing gate and default 22% breadth are engineering
// policies, not quoted rules. A wick envelope is not an author wave admission.
BKNGuidedPair BKNGuideSelectBoundary(const MqlRates &rows[],int first,int last,
 bool up,bool upper,int seconds,datetime known,datetime cutoff,double span_fraction=0.22,bool require_native_swing=false,bool validate_before_first=true){
 BKNGuidedPair out;ZeroMemory(out);out.first=-1;out.second=-1;
 out.owner_first=first;out.owner_last=last;out.up=up;out.upper=upper;
 out.reason=BKNGuideScopeReason(rows,first,last,up,seconds,known,cutoff);
 if(out.reason!="")return out;
 if(!MathIsValidNumber(span_fraction)||span_fraction<0.0||span_fraction>1.0){out.reason="span_policy_invalid";return out;}
 BKNAxis axis=BKNMeasureAxis(rows,first,last);
 if(!axis.valid){out.reason=axis.reason;return out;}
 int contacts[],span=last-first;
 int minimum=(int)MathMax(2.0,MathCeil(span*span_fraction));
 // The ordinary trend-side second touch precedes directional terminal B.
 // The opposite channel-source side may use the supplied owner's closed B.
 // Owner confirmation remains the caller's independent responsibility.
 bool trend_side=upper!=up;
 for(int k=first;k<=last;k++){
  if(trend_side&&k==last)continue;
  if(require_native_swing&&!BKNBookSwingContact(rows,k,!upper,seconds,known))continue;
  int n=ArraySize(contacts);ArrayResize(contacts,n+1);contacts[n]=k;
 }
 if(ArraySize(contacts)<2){out.reason=require_native_swing?"fewer_than_two_native_swing_contacts":"fewer_than_two_native_outer_contacts";return out;}
 double scale=MathMax(MathAbs(axis.slope),axis.price_scale/(double)span);
 double sign=up?1.0:-1.0,best=DBL_MAX,best_center=DBL_MAX;
 int witnesses[];BKNHull(rows,first,last,!upper,witnesses);
 double minimum_price=rows[first].low,maximum_price=rows[first].high;
 for(int k=first+1;k<=last;k++){
  minimum_price=MathMin(minimum_price,rows[k].low);maximum_price=MathMax(maximum_price,rows[k].high);
 }
 // Every candidate slope is bounded by this owner's native price range
 // because distinct contacts are at least one bar apart. Thus this bounds
 // abs(pa+slope*(k-a)) for every candidate in the entire owner. A generous
 // multiple of its floating-point tolerance makes the slope interval a
 // SUPerset of all full-wick-admissible equations, never a new admission gate.
 double bound=MathMax(MathAbs(minimum_price),MathAbs(maximum_price))+(maximum_price-minimum_price)*span;
 double interval_tolerance=BKNGeometryTolerance(bound,bound)*16.0;
 bool bounded=MathIsValidNumber(bound)&&MathIsValidNumber(interval_tolerance);
 for(int i=0;i<ArraySize(contacts)-1;i++){
  int a=contacts[i];double pa=upper?rows[a].high:rows[a].low;
  double slope_min=-DBL_MAX,slope_max=DBL_MAX;
  if(bounded)for(int h=0;h<ArraySize(witnesses);h++){
   int k=witnesses[h],distance=k-a;if(distance==0||(!validate_before_first&&k<a))continue;
   double actual=upper?rows[k].high:rows[k].low;
   double edge=(actual-pa+(upper?-interval_tolerance:interval_tolerance))/distance;
   if(upper?(distance>0):(distance<0))slope_min=MathMax(slope_min,edge);
   else slope_max=MathMin(slope_max,edge);
  }
  // Only actual witness contradictions can eliminate a first contact. We do
  // not require hull adjacency or replace any real/collinear contact pair.
  if(slope_min>slope_max)continue;
  for(int j=i+1;j<ArraySize(contacts);j++){
  int b=contacts[j],width=b-a;
  if(width<minimum)continue;
  double pb=upper?rows[b].high:rows[b].low;
  double slope=(pb-pa)/width;
  if(sign*slope<=0.0)continue;
  if(slope<slope_min||slope>slope_max)continue;
  bool valid=true;
  // These are rejection witnesses from this exact owner, not an adjacency
  // admission gate. Every pair remains eligible; every survivor still passes
  // the full native OHLC check. This avoids cubic work on obvious crossings.
  for(int h=0;h<ArraySize(witnesses);h++){
   int k=witnesses[h];if(!validate_before_first&&k<a)continue;
   double actual=upper?rows[k].high:rows[k].low,expected=pa+slope*(k-a);
   double clearance=upper?expected-actual:actual-expected;
   if(clearance<-BKNGeometryTolerance(actual,expected)){valid=false;break;}
  }
  if(!valid)continue;
  for(int k=(validate_before_first?first:a);k<=last;k++){
   double actual=upper?rows[k].high:rows[k].low,expected=pa+slope*(k-a);
   double clearance=upper?expected-actual:actual-expected;
   if(clearance<-BKNGeometryTolerance(actual,expected)){valid=false;break;}
  }
  if(!valid)continue;
  out.candidates++;
  double error=MathAbs(slope-axis.slope)/scale;
  double center=MathAbs((double)(a+b-first-last))/(2.0*span);
  // Preserve axis alignment as declared engineering ranking, but record
  // concentration separately. Better distribution wins equal-alignment
  // ties before span; no shortest/first pair is selected just by scan order.
  bool equal=MathAbs(error-best)<=BKNGeometryTolerance(error,best);
  bool better=out.first<0||(!equal&&error<best)||
   (equal&&(center<best_center||(center==best_center&&
    (width>out.span||(width==out.span&&a<out.first)))));
  if(!better)continue;
  out.first=a;out.second=b;out.span=width;out.first_price=pa;out.second_price=pb;
  out.slope=slope;out.axis_slope=axis.slope;out.axis_error=error;out.center_error=center;
  best=error;best_center=center;
  }
 }
 if(out.first<0){out.reason="no_same_owner_non_crossing_broad_pair";return out;}
 out.swing_contacts=(BKNBookSwingContact(rows,out.first,!upper,seconds,known)?1:0)+
  (BKNBookSwingContact(rows,out.second,!upper,seconds,known)?1:0);
 out.contact_evidence=out.swing_contacts==2?"two_native_swing_contacts":"native_outer_wick_supports_structure_pending";
 out.axis_review=out.axis_error>0.5;
 out.position_review=(2*(out.second-first)<span||2*(out.first-first)>span);
 out.known=known;out.valid=true;out.reason="";return out;
}
// Independent terminal purple is a forward finite line from its first real
// contact. Its invisible backward extrapolation does not veto that line.
// Ownership, known-at, native contacts, breadth, direction and every wick
// from the first contact THROUGH owner B remain mandatory. This option is
// deliberately not used for the full-owner parallel channel.
BKNGuidedPair BKNGuideSelectForwardTurning(const MqlRates &rows[],int first,int last,
 bool up,int seconds,datetime known,datetime cutoff){
 BKNGuidedPair pair=BKNGuideSelectBoundary(rows,first,last,up,!up,seconds,known,cutoff,0.22,false,false);
 if(pair.valid){pair.forward_only=true;pair.contact_evidence+=";forward_from_first_native_contact";}
 return pair;
}
// Down: source is the independently selected LOWER pair, shift UP.
// Up: source is the independently selected UPPER pair, shift DOWN.
// Select the full-owner farthest opposite residual, never the largest raw
// price between C/E. Source is passed by const reference and never moved.
BKNGuidedChannel BKNGuideTranslateChannel(const MqlRates &rows[],const BKNGuidedPair &source,
 int seconds,datetime known,datetime cutoff){
 BKNGuidedChannel out;ZeroMemory(out);out.contact=-1;out.up=source.up;
 out.owner_first=source.owner_first;out.owner_last=source.owner_last;
 out.reason="channel_source_unavailable";if(!source.valid)return out;
 if(source.forward_only){out.reason="channel_requires_full_owner_source";return out;}
 out.reason="channel_source_wrong_side";if(source.upper!=source.up)return out;
 out.reason=BKNGuideScopeReason(rows,source.owner_first,source.owner_last,source.up,seconds,known,cutoff);
 if(out.reason!="")return out;
 if(source.known<=0||source.known>known){out.reason="channel_source_clock_invalid";return out;}
 if(source.first<source.owner_first||source.second>source.owner_last||source.second<=source.first){out.reason="channel_source_contact_range_invalid";return out;}
 double pa=source.upper?rows[source.first].high:rows[source.first].low;
 double pb=source.upper?rows[source.second].high:rows[source.second].low;
 if(pa!=source.first_price||pb!=source.second_price){out.reason="channel_source_not_native_wicks";return out;}
 double slope=(pb-pa)/(source.second-source.first);
 if(MathAbs(slope-source.slope)>BKNGeometryTolerance(slope,source.slope)){out.reason="channel_source_equation_mismatch";return out;}
 double sign=source.up?-1.0:1.0,extreme=-DBL_MAX;
 for(int k=source.owner_first;k<=source.owner_last;k++){
  double base=BKNGuideLevel(source,k),actual=source.up?rows[k].low:rows[k].high;
  double offset=actual-base,value=sign*offset;
  double tolerance=BKNGeometryTolerance(value,extreme);
  if(out.contact<0||value>extreme+tolerance){out.contact=k;out.offset=offset;out.contact_price=actual;extreme=value;}
 }
 if(out.contact<0||sign*out.offset<=0.0){out.reason="channel_offset_not_outward";return out;}
 // Verify BOTH rails on the entire same owner. A finite shifted target
 // that only fits after an internal D is not a full-owner channel.
 for(int k=source.owner_first;k<=source.owner_last;k++){
  double base=BKNGuideLevel(source,k),shifted=base+out.offset;
  double lower=source.up?shifted:base,upper=source.up?base:shifted;
  if(rows[k].low<lower-BKNGeometryTolerance(rows[k].low,lower)||
     rows[k].high>upper+BKNGeometryTolerance(rows[k].high,upper)){
   out.reason="channel_full_owner_envelope_invalid";return out;
  }
 }
 out.source_first=source.first;out.source_second=source.second;
 out.source_first_price=source.first_price;out.source_second_price=source.second_price;
 out.slope=source.slope;out.known=known;out.valid=true;out.reason="";return out;
}
#endif
