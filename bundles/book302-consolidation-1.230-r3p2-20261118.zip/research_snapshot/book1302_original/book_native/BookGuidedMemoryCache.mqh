#ifndef BOOK_GUIDED_MEMORY_CACHE
#define BOOK_GUIDED_MEMORY_CACHE
#include "BookGuidedFrame.mqh"
struct BKNGuidedMemorySlot {string identity;ulong used;BKNShape shapes[];BKNGeometryCoverage coverage[];};
class BKNGuideMemoryCache {
private:
 BKNGuidedMemorySlot m_slots[];ulong m_clock;
public:
 BKNGuideMemoryCache(){m_clock=0;}
 void Clear(){ArrayResize(m_slots,0);m_clock=0;}
 bool Get(string identity,BKNShape &out[],BKNGeometryCoverage &coverage[]){
  ArrayResize(out,0);ArrayResize(coverage,0);
  for(int i=0;i<ArraySize(m_slots);i++)if(identity!=""&&m_slots[i].identity==identity){
   m_slots[i].used=++m_clock;ArrayResize(out,ArraySize(m_slots[i].shapes));ArrayResize(coverage,ArraySize(m_slots[i].coverage));
   for(int k=0;k<ArraySize(out);k++)out[k]=m_slots[i].shapes[k];for(int k=0;k<ArraySize(coverage);k++)coverage[k]=m_slots[i].coverage[k];return true;
  }return false;
 }
 void Put(string identity,const BKNShape &shapes[],const BKNGeometryCoverage &coverage[],int capacity=4){
  if(identity==""||capacity<1)return;capacity=(int)MathMin(8,capacity);int target=-1;
  for(int i=0;i<ArraySize(m_slots);i++)if(m_slots[i].identity==identity){target=i;break;}
  if(target<0&&ArraySize(m_slots)<capacity){target=ArraySize(m_slots);ArrayResize(m_slots,target+1);}
  if(target<0){target=0;for(int i=1;i<ArraySize(m_slots);i++)if(m_slots[i].used<m_slots[target].used)target=i;}
  m_slots[target].identity=identity;m_slots[target].used=++m_clock;
  ArrayResize(m_slots[target].shapes,ArraySize(shapes));ArrayResize(m_slots[target].coverage,ArraySize(coverage));
  for(int k=0;k<ArraySize(shapes);k++)m_slots[target].shapes[k]=shapes[k];for(int k=0;k<ArraySize(coverage);k++)m_slots[target].coverage[k]=coverage[k];
 }
};
#endif
