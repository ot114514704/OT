#ifndef BOOK_NATIVE_STRUCTURE
#define BOOK_NATIVE_STRUCTURE
#include "BookNativePair.mqh"
// Original book_trend_structure_judgement precedence, independently of all
// force/geometry scores. This supplied native scope is not author degree or
// parent trend. No author-verified adjustment A is provided by this port yet;
// a dual break therefore leaves the next direction explicitly unresolved.
struct BKNStructure {
 bool evaluated,prior_ended_known,prior_ended,outer_outside,turning_outside;
 bool source_retired,prospective,automatic_trade_permission;
 int outer_break,turning_break,origin_break;
 datetime known,ended_known,origin_known;
 string stage,reason,order;
};
bool BKNStructureBreak(const MqlRates &rows[],const BKNFrozenRuler &r,int observable,
                       int decimals,int &broken,string &reason){
 broken=-1;reason="native_boundary_event_unavailable";
 if(observable<0||observable>=ArraySize(rows))return false;
 long gap;if(!BKNGapNumerator(rows[observable].close,r,observable,decimals,gap))return false;
 if(gap<0){reason="boundary_already_broken_when_observable";return false;}
 for(int i=observable+1;i<ArraySize(rows);i++){
  if(!BKNGapNumerator(rows[i].close,r,i,decimals,gap))return false;
  if(gap<0){broken=i;break;}
 }
 reason="";return true;
}
BKNStructure BKNJudgeStructure(const MqlRates &bars[],const BKNScope &scope,
 const BKNBoundary &outer,const BKNTurning &turning,const BKNSourceReference &source,
 int seconds,datetime cutoff,int decimals){
 BKNStructure out;ZeroMemory(out);out.stage="unknown";out.reason="native_market_or_source_unavailable";out.order="";
 out.outer_break=-1;out.turning_break=-1;out.origin_break=-1;
 if(seconds<=0||source.seconds!=seconds||StringLen(source.provider)==0||StringLen(source.symbol)==0)return out;
 MqlRates rows[];int n=0;datetime previous=0;bool future=false;
 for(int i=0;i<ArraySize(bars);i++){
  if(bars[i].time+seconds>cutoff){future=true;continue;}
  if(future||bars[i].time<=previous||!BKNValidRate(bars[i])||bars[i].low<=0){out.reason="invalid_closed_native_structure_prefix";return out;}
  ArrayResize(rows,n+1,256);rows[n++]=bars[i];previous=bars[i].time;
 }
 BKNSourceReference actual=BKNReference(scope,source.provider,source.symbol,seconds);
 if(!BKNReferenceMatches(actual,source)){out.reason="outer_owned_scope_binding_mismatch";return out;}
 if(!BKNOuterNativeProof(rows,scope,outer,seconds,cutoff,decimals,out.reason))return out;
 // A valid supporting hull is not necessarily an advancing trend boundary.
 // The original structure adjudicator checks this independently of scores.
 if((outer.up?1.0:-1.0)*outer.slope<=0){out.reason="outer_not_advancing_in_source_direction";return out;}
 // The original structure adjudicator requires strict internal clearance;
 // an additional collinear hull contact may remain drawable geometry but
 // cannot silently inherit the stricter structure qualification.
 BKNFrozenRuler o=BKNFreezeOuter(outer);long gap;
 for(int i=outer.first+1;i<outer.second;i++){
  if(!BKNGapNumerator(outer.up?rows[i].low:rows[i].high,o,i,decimals,gap)||gap<=0){out.reason="outer_internal_cross_or_contact";return out;}
 }
 if(turning.origin!=scope.a.index||turning.terminal!=scope.b.index||turning.up!=scope.up){out.reason="turning_parent_scope_mismatch";return out;}
 if(turning.c<scope.a.index||turning.d<scope.a.index||turning.e>scope.b.index||turning.d>scope.b.index){
  out.reason="CDE_adjacent_context_not_current_owner";return out;
 }
 if(!BKNValidateCDE(rows,turning,decimals,out.reason))return out;
 if(turning.known_at<scope.known||turning.known_at>cutoff||rows[turning.observable].time+seconds>turning.known_at){out.reason="turning_construction_clock_unavailable";return out;}
 // Reproduce retirement in actual native OHLC instead of trusting a cached
 // state or interpreting a line re-entry as a new phase or revival.
 for(int i=scope.b.index+1;i<n;i++)if(scope.up?rows[i].low<scope.a.price:rows[i].high>scope.a.price){out.origin_break=i;break;}
 if(out.origin_break>=0){
  out.stage="source_scope_retired";out.source_retired=true;out.origin_known=rows[out.origin_break].time+seconds;
  out.known=(datetime)MathMax(MathMax((double)scope.known,(double)out.origin_known),MathMax((double)outer.known_at,(double)turning.known_at));
  out.evaluated=true;out.reason="native_origin_strictly_crossed_parent_not_adjudicated";return out;
 }
 BKNFrozenRuler t=BKNFreezeTurning(turning);
 if(!BKNStructureBreak(rows,o,outer.second,decimals,out.outer_break,out.reason)||
    !BKNStructureBreak(rows,t,turning.observable,decimals,out.turning_break,out.reason))return out;
 long outer_gap,turn_gap;
 if(!BKNGapNumerator(rows[n-1].close,o,n-1,decimals,outer_gap)||!BKNGapNumerator(rows[n-1].close,t,n-1,decimals,turn_gap)){
  out.reason="current_native_boundary_relation_unavailable";return out;
 }
 out.outer_outside=outer_gap<0;out.turning_outside=turn_gap<0;
 out.evaluated=true;out.prior_ended_known=true;out.known=cutoff;out.reason="";
 bool ob=out.outer_break>=0,tb=out.turning_break>=0;
 if(!ob&&!tb){out.stage="no_boundary_break_observed";return out;}
 if(!ob||!tb){out.stage=ob?"outer_only_warning":"turning_only_warning";out.reason="second_boundary_not_broken";return out;}
 out.prior_ended=true;out.stage="old_trend_ended_direction_unresolved";out.reason="complete_author_adjustment_A_required";
 out.ended_known=(datetime)MathMax(MathMax((double)outer.known_at,(double)turning.known_at),
  MathMax((double)(rows[out.outer_break].time+seconds),(double)(rows[out.turning_break].time+seconds)));
 out.order=out.outer_break==out.turning_break?"same_bar":out.outer_break<out.turning_break?"outer_then_turning":"turning_then_outer";
 int first=(int)MathMin(out.outer_break,out.turning_break);
 out.prospective=outer.known_at<=rows[first].time&&turning.known_at<=rows[first].time;
 return out;
}
string BKNStructureLabel(const BKNStructure &s){
 if(!s.evaluated)return "结构未知 · "+s.reason;
 if(s.source_retired)return "本波段起点已被穿越；父趋势未裁定";
 if(s.stage=="no_boundary_break_observed")return "本来源尚未观察到双线收破";
 if(s.stage=="outer_only_warning")return "仅外侧趋势线收破；第二边界未破";
 if(s.stage=="turning_only_warning")return "仅独立拐点线收破；第二边界未破";
 return "同源双线已收破，旧来源趋势结束；完整调整A未验证，后续方向未定";
}
#endif
