#ifndef BOOK_GUIDED_SHIFT_LIFE
#define BOOK_GUIDED_SHIFT_LIFE
#include "BookGuidedTurningLife.mqh"
// A translated rail starts at its own actual opposite-side contact Q.
// Its equation still encloses the complete formation owner, but the
// imaginary backward part is not drawn. Later CLOSED prices observe the
// fixed equation until the first opposite close or native session gap.
// This is a geometric display lifecycle, not author/event admission.
BKNGuidedTurningLife BKNGuideObserveShift(const MqlRates &rows[],const BKNGuidedPair &source,
 const BKNGuidedChannel &channel,int seconds,datetime cutoff){
 BKNGuidedTurningLife out;ZeroMemory(out);out.last=-1;out.touch=-1;out.cross=-1;
 out.reason="shift_formation_unavailable";if(!source.valid||!channel.valid)return out;
 BKNGuidedChannel verified=BKNGuideTranslateChannel(rows,source,seconds,channel.known,cutoff);
 out.reason="shift_formation_equation_mismatch";
 if(!verified.valid||verified.owner_first!=channel.owner_first||verified.owner_last!=channel.owner_last||
    verified.source_first!=channel.source_first||verified.source_second!=channel.source_second||
    verified.contact!=channel.contact||verified.offset!=channel.offset||
    verified.slope!=channel.slope||verified.contact_price!=channel.contact_price)return out;
 out.valid=true;out.reason="";out.last=source.owner_last;out.display_known=channel.known;
 out.state="shift_formation_only";
 for(int k=source.owner_last+1;k<ArraySize(rows);k++){
  if(rows[k].time+seconds>cutoff)break;
  if(rows[k].time-rows[k-1].time!=seconds){out.state="shift_observation_gap";break;}
  if(!BKNValidRate(rows[k])){out.state="shift_observation_invalid_bar";break;}
  double level=BKNGuideLevel(source,k)+channel.offset;
  double extreme=source.up?rows[k].low:rows[k].high;
  double tolerance=BKNGeometryTolerance(extreme,level);
  bool touched=source.up?extreme<=level+tolerance:extreme>=level-tolerance;
  double close_tolerance=BKNGeometryTolerance(rows[k].close,level);
  bool crossed=source.up?rows[k].close<level-close_tolerance:rows[k].close>level+close_tolerance;
  out.last=k;out.display_known=(datetime)MathMax((long)channel.known,(long)(rows[k].time+seconds));
  if(touched&&out.touch<0){out.touch=k;out.touch_known=rows[k].time+seconds;}
  out.state=out.touch>=0?"shift_wick_contact_observed":"shift_awaiting_opposite_cross";
  if(crossed){out.cross=k;out.cross_known=rows[k].time+seconds;out.retrospective=out.cross_known<channel.known;
   out.state=out.retrospective?"shift_retrospective_close_cross":"shift_closed_bar_cross_observed";break;}
 }
 return out;
}
#endif
