#ifndef BOOK_NATIVE_LINE_CONTRACT
#define BOOK_NATIVE_LINE_CONTRACT
// Unified line-role/permission transport for the native Book scene.
// This module does not choose new market pivots. It makes each existing
// producer state explicit before events, pairs and consumers read it.
string BKNLineContractRole(const BKNShape &s){
 if(s.line_family=="OUTER")return "OUTER";
 if(s.line_family=="CHANNEL")return "CHANNEL";
 if(s.line_family=="RETURN_CE_D"||s.group=="book_CE_D")return "CE_D";
 if(s.line_family=="RESUME_DF_C"||s.group=="book_DF_C")return "DF_C";
 if(s.group=="book_CE_reference")return "CE_SOURCE";
 if(s.group=="book_first_response")return "RESPONSE";
 if(s.layer=="force")return "FORCE";
 if(s.layer=="pullback")return "FOLLOW_PULLBACK";
 if(s.layer=="invalidation")return "FOLLOW_INVALIDATION";
 if(s.layer=="stop_reference")return "STOP_REFERENCE";
 if(s.layer=="risk_fact")return "RISK_FACT";
 if(s.layer=="wave_count")return "WAVE";
 if(s.layer=="wave")return "WAVE_SCOPE";
 return "";
}
void BKNLineContractBindCommon(BKNShape &s,int seconds,string provider,string symbol){
 s.line_seconds=seconds;s.line_provider=provider;s.line_symbol=symbol;
 if(s.line_owner_relation=="")s.line_owner_relation="same_owner";
 if(s.line_admission_mode=="")s.line_admission_mode="native_geometry";
 if(s.line_a_time<=0){s.line_a_time=s.a;s.line_a_price=s.pa;}
 if(s.line_b_time<=0){s.line_b_time=s.b;s.line_b_price=s.pb;}
 if(s.line_display_first<=0)s.line_display_first=s.a;
 if(s.line_display_last<=0)s.line_display_last=s.b;
 if(s.line_event_first<=0&&s.line_event_known>0)s.line_event_first=s.line_event_known;
 if(s.line_event_break<=0&&s.event_occurrence_known>0)s.line_event_break=s.event_occurrence_known;
 if(s.line_invalidation_reason==""&&s.line_event_unknown!="")s.line_invalidation_reason=s.line_event_unknown;
 if(s.line_state_known<=0)s.line_state_known=s.known;
}
bool BKNLineContractGeometry(const BKNShape &s,datetime cutoff){
 if(s.a<=0||s.b<s.a||s.known<=0||s.known>cutoff)return false;
 if(s.line_seconds<=0||s.line_provider==""||s.line_symbol=="")return false;
  if(s.line_anchor_time<=0||s.line_anchor_price<=0||!MathIsValidNumber(s.line_anchor_price))return false;
 if(s.line_state_known<=0||s.line_state_known>cutoff)return false;
 if(s.line_owner_relation=="adjacent_context"){
  if(s.line_host_owner==""||s.line_host_a<=0||s.line_host_b<=s.line_host_a||s.owner==s.line_host_owner)return false;
  if(s.owner_a<=0||s.owner_b<s.owner_a||s.line_c_time<s.owner_a||s.line_e_time>s.owner_b||s.line_e_time<=s.line_c_time)return false;
 }
 if(s.line_clocks_supported){
  if(s.line_construction_known<=0||s.line_construction_known>s.known)return false;
  if(s.line_display_known>0&&(s.line_display_known<s.line_construction_known||s.line_display_known>s.known))return false;
  if(s.line_event_known>0&&(s.line_event_known<s.line_construction_known||s.line_event_known>s.known))return false;
  if(s.line_state_known<s.line_construction_known||s.line_state_known>s.known)return false;
 }
 return true;
}
void BKNStampLineContract(BKNShape &s,datetime cutoff,string input_revision){
 string role=BKNLineContractRole(s);if(role=="")return;
 s.line_role=role;
 s.line_event_eligible=false;s.line_pair_eligible=false;
 // Normalize permissions before deriving identity. Otherwise a stale host
 // pair changes the first contract hash, is then removed, and changes the
 // hash again on the next stamp of the very same line.
 if(s.status=="source_inspection_only"||s.line_admission_mode=="source_only_without_outer"||(s.line_owner_relation=="adjacent_context"&&(role=="CE_SOURCE"||role=="CE_D"))){
  s.phase_id="";s.pair_id="";
  s.pair_state=s.status=="source_inspection_only"?"historical_source_inspection":
   s.line_admission_mode=="source_only_without_outer"?"source_only_without_outer_diagnostic":"adjacent_context_diagnostic";
  s.pair_has_score=false;s.pair_score=EMPTY_VALUE;s.has_score=false;s.score=EMPTY_VALUE;
  s.delivery_measured=false;s.delivery_qualified=false;s.force_coverage=EMPTY_VALUE;
 }
 s.line_anchor_role=role=="OUTER"?"A":role=="CHANNEL"?"Q":role=="CE_SOURCE"?"C":role=="CE_D"?"D":role=="DF_C"?"C_shifted_from_D":
  role=="RESPONSE"?"B_to_C":role=="FORCE"?"A_to_B":role=="WAVE_SCOPE"?"A_to_B":
  role=="WAVE"?"wave_origin":role;
  s.line_anchor_index=-1;s.line_anchor_time=0;s.line_anchor_price=0;
 if(role=="OUTER"&&s.line_a_time>0){s.line_anchor_index=s.line_a_index;s.line_anchor_time=s.line_a_time;s.line_anchor_price=s.line_a_price;}
 else if(role=="CHANNEL"&&s.line_q_time>0){s.line_anchor_index=s.line_q_index;s.line_anchor_time=s.line_q_time;s.line_anchor_price=s.line_q_price;}
 else if(role=="CE_SOURCE"&&s.line_c_time>0){s.line_anchor_index=s.line_c_index;s.line_anchor_time=s.line_c_time;s.line_anchor_price=s.line_c_price;}
 else if(role=="CE_D"&&s.line_d_time>0){s.line_anchor_index=s.line_d_index;s.line_anchor_time=s.line_d_time;s.line_anchor_price=s.line_d_price;}
 else if(role=="DF_C"&&s.line_c_time>0){s.line_anchor_role="C";s.line_anchor_index=s.line_c_index;s.line_anchor_time=s.line_c_time;s.line_anchor_price=s.line_c_price;}
  else if((role=="WAVE"||role=="WAVE_SCOPE")&&s.line_a_time>0){s.line_anchor_index=s.line_a_index;s.line_anchor_time=s.line_a_time;s.line_anchor_price=s.line_a_price;}
  else if(role=="RESPONSE"||role=="FORCE"||role=="FOLLOW_PULLBACK"||role=="FOLLOW_INVALIDATION"||role=="STOP_REFERENCE"||role=="RISK_FACT"){
   s.line_anchor_index=s.line_a_index;s.line_anchor_time=s.line_a_time;s.line_anchor_price=s.line_a_price;
  }
 s.line_geometry_valid=BKNLineContractGeometry(s,cutoff);
 if(s.construction_revision=="")s.construction_revision=input_revision;
 if(s.formation_input_revision=="")
  s.formation_input_revision=BKNHash("formation|"+role+"|"+s.construction_id+"|"+s.source_id+"|"+
   IntegerToString((long)s.a)+"@"+DoubleToString(s.pa,12)+"|"+IntegerToString((long)s.b)+"@"+
   DoubleToString(s.pb,12)+"|"+IntegerToString((long)s.known));
 // Time endpoints alone are not a complete line identity. A historical
 // equation segment and an active segment can share the same bars while
 // carrying different prices or consumer semantics. Keep those distinctions
 // in the contract identity so a panel/export consumer cannot alias them.
 string basis=role+"|group="+s.group+"|kind="+s.kind+"|admission="+s.line_admission_mode+"|owner="+s.owner+"|owner_relation="+s.line_owner_relation+"|host="+s.line_host_owner+"|source="+s.source_id+"|phase="+s.phase_id+"|pair="+s.pair_id+"|"+
  IntegerToString((long)s.a)+"@"+DoubleToString(s.pa,12)+">"+IntegerToString((long)s.b)+"@"+DoubleToString(s.pb,12)+"|anchor="+s.line_anchor_role;
 s.line_contract_id="book_line_contract:"+BKNHash(basis);
 s.line_contract_revision=BKNHash(basis+"|formation="+s.formation_input_revision+"|observation="+s.construction_revision);
 if(!s.line_geometry_valid){s.line_contract_state="invalid";s.line_contract_reason="line_geometry_or_clock_invalid";return;}
 // Historical event clocks may be retained as facts, especially for DF_C.
 // They do not turn an explicitly requested diagnostic into a live event.
 if(s.status=="source_inspection_only"){
  s.line_contract_state="diagnostic";
  s.line_contract_reason="historical_source_inspection_no_event_permission";
  return;
 }
 // Native OUTER failure does not disprove the independent C/E geometry.
 // Retain its finite ruler as research evidence, without borrowing the
 // qualified-OUTER event/structure/score admission path.
 if(s.line_admission_mode=="source_only_without_outer"){
  s.line_contract_state="diagnostic";
  s.line_contract_reason="qualified_outer_unavailable_research_source_only";
  return;
 }
 if(s.line_owner_relation=="adjacent_context"){
  s.line_event_eligible=false;s.line_pair_eligible=false;
  if(role=="CE_SOURCE"||role=="CE_D"){
   s.line_contract_state="diagnostic";
   s.line_contract_reason="adjacent_context_owner_not_current_scope";
   return;
  }
 }
 if(role!="OUTER"&&role!="CHANNEL"&&role!="CE_D"){
  s.line_contract_state="diagnostic";s.line_contract_reason=role=="WAVE"?"native_wave_candidate_not_author_line":
   role=="RESPONSE"?"engineering_response_not_structure_pair":role=="FORCE"?"measurement_line_not_structure_pair":
   role=="WAVE_SCOPE"?"native_wave_scope_not_author_degree":"reference_or_risk_line_not_structure_pair";return;
 }
 if(role=="CHANNEL"){
  s.line_contract_state=s.pair_id!=""?"admitted_geometry":"candidate";
  s.line_contract_reason="legacy_outer_Q_auxiliary_cannot_replace_independent_CE_source_or_CE_D";return;
 }
 if(role=="CE_D"&&s.status=="historical_CE_D_construction"){
  s.line_contract_state="historical_construction";
  s.line_contract_reason="finite_CE_D_source_construction_no_forecast_event";return;
 }
 if(role=="CE_D"&&s.status=="projected_candidate"&&
    !(s.line_event_known>0&&s.line_event_kind!=""&&s.line_event_unknown=="")){
  s.line_contract_state="prospective_candidate";
  s.line_contract_reason=s.line_event_unknown!=""?"prospective_CE_D_projection_"+s.line_event_unknown:
   "prospective_CE_D_projection_waiting_terminal_event";return;
 }
 if(s.line_event_known>0&&s.line_event_kind!=""&&s.line_event_unknown==""){
  s.line_event_eligible=true;s.line_pair_eligible=s.pair_id!=""&&s.phase_id!="";
  s.line_contract_state="admitted_event";s.line_contract_reason="role_event_clock_and_pair_identity_bound";return;
 }
 s.line_contract_state="candidate";s.line_contract_reason="event_or_pair_clock_not_yet_bound";
}
bool BKNLineContractPairEligible(const BKNShape &outer,const BKNShape &turning,datetime cutoff,string &reason){
 reason="pair_unavailable";
 if(outer.line_role!="OUTER"||turning.line_role!="CE_D"){reason="pair_requires_outer_and_CE_D";return false;}
 if(!outer.line_event_eligible||!turning.line_event_eligible){reason="pair_event_not_admitted";return false;}
 if(!outer.line_pair_eligible||!turning.line_pair_eligible){reason="pair_identity_missing";return false;}
 if(outer.line_seconds<=0||outer.line_seconds!=turning.line_seconds||outer.line_provider==""||outer.line_provider!=turning.line_provider||outer.line_symbol==""||outer.line_symbol!=turning.line_symbol){reason="pair_source_or_period_mismatch";return false;}
 if(outer.source_id==""||turning.source_id==""||outer.source_id!=turning.source_id){reason="pair_source_identity_missing";return false;}
 if(outer.owner!=turning.owner||outer.phase_id!=turning.phase_id||outer.pair_id!=turning.pair_id){reason="pair_owner_phase_identity_mismatch";return false;}
 if(outer.known>cutoff||turning.known>cutoff){reason="pair_clock_after_cutoff";return false;}
 reason="";return true;
}
// One display-window policy for every finite line family. A CHANNEL belongs
// to the same owned A..B wave that supplied its Q offset. It must never be
// allowed to become a long blue ray through a later leg simply because the
// event observer has not seen a terminal contact yet. Successor retirement
// and axis review still clamp all other finite families. Recovery DF_C uses
// its own lifecycle and does not call this policy.
int BKNLineContractDisplayEnd(string role,int owner_last,int requested,int event_bar,
                              bool axis_review,datetime successor_known,string &basis){
 basis="closed_prefix";if(requested<0)return -1;
 int end=requested;
 if(role=="CHANNEL"&&owner_last>=0){
  basis="owned_wave_Q_to_B_finite";
  return (int)MathMin(end,owner_last);
 }
 if(successor_known>0){basis="successor_owner_retired";return owner_last>=0?(int)MathMin(end,owner_last):end;}
 if(axis_review){basis="axis_review_owned_finite";return owner_last>=0?(int)MathMin(end,owner_last):end;}
 if(event_bar>=0)basis=role+"_first_native_terminal_event";
 return end;
}
int BKNLineDuplicatePriority(const BKNShape &s){
 if(s.status=="independent_extension_observation"||s.status=="finite_geometry_review")return 0;
 if(s.group=="book_channel_history"||s.group=="book_outer_review")return 0;
 return 1;
}
bool BKNLineSameGeometry(const BKNShape &a,const BKNShape &b){
 return a.line_role!=""&&a.line_role==b.line_role&&a.owner==b.owner&&a.group==b.group&&
  a.a==b.a&&a.b==b.b&&MathAbs(a.pa-b.pa)<=BKNGeometryTolerance(a.pa,b.pa)&&
  MathAbs(a.pb-b.pb)<=BKNGeometryTolerance(a.pb,b.pb);
}
void BKNMarkLineDuplicates(BKNShape &shapes[]){
 for(int i=0;i<ArraySize(shapes);i++){
  if(shapes[i].line_role==""||shapes[i].line_duplicate)continue;
  for(int j=i+1;j<ArraySize(shapes);j++){
   if(!BKNLineSameGeometry(shapes[i],shapes[j]))continue;
   int pi=BKNLineDuplicatePriority(shapes[i]),pj=BKNLineDuplicatePriority(shapes[j]);
   int duplicate=(pj>pi)?i:j;
   shapes[duplicate].line_duplicate=true;
   shapes[duplicate].line_contract_state="duplicate_diagnostic";
   shapes[duplicate].line_contract_reason="same_native_line_geometry_emitted_twice";
   shapes[duplicate].line_event_eligible=false;shapes[duplicate].line_pair_eligible=false;
  }
 }
}
string BKNLineContractSummary(const BKNShape &s){
 return "role="+s.line_role+";anchor="+s.line_anchor_role+";anchor_time="+IntegerToString((long)s.line_anchor_time)+";anchor_price="+DoubleToString(s.line_anchor_price,12)+
  ";id="+s.line_contract_id+";revision="+s.line_contract_revision+";formation_revision="+s.formation_input_revision+";observation_revision="+s.construction_revision+";state="+s.line_contract_state+";reason="+s.line_contract_reason+
  ";family="+s.line_family+";display_basis="+s.line_display_basis+";admission="+s.line_admission_mode+";owner_relation="+s.line_owner_relation+";owner_a="+IntegerToString((long)s.owner_a)+";owner_b="+IntegerToString((long)s.owner_b)+
  ";host_owner="+s.line_host_owner+";host_a="+IntegerToString((long)s.line_host_a)+";host_b="+IntegerToString((long)s.line_host_b)+
  ";construction_known="+IntegerToString((long)s.line_construction_known)+";display_known="+IntegerToString((long)s.line_display_known)+";event_known="+IntegerToString((long)s.line_event_known)+
   ";geometry="+(s.line_geometry_valid?"1":"0")+";event="+(s.line_event_eligible?"1":"0")+";pair="+(s.line_pair_eligible?"1":"0")+";duplicate="+(s.line_duplicate?"1":"0")+
   ";provider="+s.line_provider+";symbol="+s.line_symbol+";seconds="+IntegerToString(s.line_seconds)+";state_known="+IntegerToString((long)s.line_state_known)+
   ";A="+IntegerToString((long)s.line_a_time)+"@"+DoubleToString(s.line_a_price,12)+";B="+IntegerToString((long)s.line_b_time)+"@"+DoubleToString(s.line_b_price,12)+
   ";C="+IntegerToString((long)s.line_c_time)+"@"+DoubleToString(s.line_c_price,12)+";D="+IntegerToString((long)s.line_d_time)+"@"+DoubleToString(s.line_d_price,12)+
   ";E="+IntegerToString((long)s.line_e_time)+"@"+DoubleToString(s.line_e_price,12)+";F="+IntegerToString((long)s.line_f_time)+"@"+DoubleToString(s.line_f_price,12)+
   ";Q="+IntegerToString((long)s.line_q_time)+"@"+DoubleToString(s.line_q_price,12)+";display="+IntegerToString((long)s.line_display_first)+">"+IntegerToString((long)s.line_display_last)+
   ";event_span="+IntegerToString((long)s.line_event_first)+">"+IntegerToString((long)s.line_event_break)+";invalidation="+s.line_invalidation_reason;
}
#endif
