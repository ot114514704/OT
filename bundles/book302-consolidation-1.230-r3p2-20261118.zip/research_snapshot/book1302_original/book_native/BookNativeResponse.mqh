#ifndef BOOK_NATIVE_RESPONSE
#define BOOK_NATIVE_RESPONSE
// Book-owned numeric/clock port of book_first_response_leg.first_response_leg.
// Frozen primitive reference SHA256: a824152bc9c1e0479198de9f90533a03459de47980cfba31cde75ed10d7ff4e1
// Matches the current response numeric fields; chapter7 source adjudication,
// protective stop plans and semantic IDs are separate pending consumers.
// BC is the engineering first response, NOT author chapter-7 wave 1.
// The caller must provide a qualified same-source outer line and closed break.
struct BKNResponse {
 string status,reason;
 int origin,terminal,confirmed,response_start,prior_extreme,failure;
 double origin_price,terminal_price,prior_price,response_price;
 datetime known_at,confirmation_at,invalidated_at,state_known_at;
 bool source_complete;
};
double BKNResponseAdverse(const MqlRates &r,bool up){return up?r.low:r.high;}
double BKNResponseFavourable(const MqlRates &r,bool up){return up?r.high:r.low;}
BKNResponse BKNFirstBookResponse(const MqlRates &bars[],int seconds,datetime cutoff,
 bool qualified,int line_start,int line_end,bool break_observed,int break_index,
 bool up,datetime line_known,datetime break_known,int radius=2){
 BKNResponse r;ZeroMemory(r);r.status="unknown";r.reason="unbound_break_direction_or_ruler";
 r.origin=-1;r.terminal=-1;r.confirmed=-1;r.response_start=-1;r.prior_extreme=-1;r.failure=-1;
 if(seconds<=0||radius<1)return r;
 MqlRates rows[];int n=0;
 // Capacity reserve only: retain the identical closed prefix and its indexes.
 for(int k=0;k<ArraySize(bars);k++)if(bars[k].time+seconds<=cutoff){ArrayResize(rows,n+1,256);rows[n++]=bars[k];}
 if(!qualified||!break_observed||line_end<0||line_end>=break_index||break_index>=n)return r;
 datetime dependency=(datetime)MathMax((long)line_known,(long)(break_known>0?break_known:rows[break_index].time+seconds));
 if(dependency>cutoff){r.reason="break_dependency_not_yet_known";return r;}
 double sign=up?1.0:-1.0;int origin=line_end+1;
 for(int k=origin+1;k<=break_index;k++)if(sign*BKNResponseAdverse(rows[k],up)<sign*BKNResponseAdverse(rows[origin],up))origin=k;
 r.origin=origin;r.origin_price=BKNResponseAdverse(rows[origin],up);
 if(line_start>=0&&line_start<=line_end){
  int prior=line_start;
  for(int k=line_start+1;k<=break_index;k++)if(sign*BKNResponseAdverse(rows[k],up)<sign*BKNResponseAdverse(rows[prior],up))prior=k;
  r.prior_extreme=prior;r.prior_price=BKNResponseAdverse(rows[prior],up);
 }
 for(int k=MathMax(break_index,origin+1);k<n-radius;k++){
  if(k-radius<origin)continue;
  double v=sign*BKNResponseFavourable(rows[k],up);bool peak=true;
  for(int z=k-radius;z<k;z++)if(v<sign*BKNResponseFavourable(rows[z],up))peak=false;
  for(int z=k+1;z<=k+radius;z++)if(v<=sign*BKNResponseFavourable(rows[z],up))peak=false;
  if(peak){r.terminal=k;r.confirmed=k+radius;break;}
 }
 if(r.terminal<0){
  for(int k=MathMax(break_index,origin+1);k<n;k++)
   if(r.terminal<0||sign*BKNResponseFavourable(rows[k],up)>sign*BKNResponseFavourable(rows[r.terminal],up))r.terminal=k;
 }
 if(r.terminal<0||sign*(BKNResponseFavourable(rows[r.terminal],up)-r.origin_price)<=0){r.reason="directional_response_missing";return r;}
 r.terminal_price=BKNResponseFavourable(rows[r.terminal],up);
 r.known_at=(datetime)MathMax((long)dependency,(long)(rows[r.confirmed>=0?r.confirmed:n-1].time+seconds));
 r.response_start=origin;
 for(int k=MathMax(origin+radius,break_index+radius);k<=r.terminal-radius;k++){
  double v=BKNResponseAdverse(rows[k],up);bool local=true;
  for(int z=k-radius;z<k;z++)if(up?v>rows[z].low:v<rows[z].high)local=false;
  for(int z=k+1;z<=k+radius;z++)if(up?v>=rows[z].low:v<=rows[z].high)local=false;
  if(local&&(up?v>r.origin_price:v<r.origin_price))r.response_start=k;
 }
 r.response_price=BKNResponseAdverse(rows[r.response_start],up);
 for(int k=origin+1;k<n;k++)if(sign*(BKNResponseAdverse(rows[k],up)-r.origin_price)<0){r.failure=k;r.invalidated_at=rows[k].time+seconds;break;}
 r.source_complete=r.confirmed>=0;
 r.confirmation_at=r.source_complete?r.known_at:0;
 r.state_known_at=(datetime)MathMax((long)r.known_at,(long)r.invalidated_at);
 r.status=r.failure>=0?"source_invalidated":(r.source_complete?"confirmed_source":"developing_source");r.reason="";
 return r;
}
#endif
