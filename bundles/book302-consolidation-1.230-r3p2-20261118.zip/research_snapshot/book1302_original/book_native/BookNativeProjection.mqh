#ifndef BOOK_NATIVE_PROJECTION
#define BOOK_NATIVE_PROJECTION
#include "BookNativeEvents.mqh"
// One frozen lifecycle determines display extent AND its stop clock.
// A price leaving the old A..B rectangle is not a boundary event.
struct BKNProjection {
 bool valid;
 int end,event_bar,contact,support_exit,resume;
 datetime occurrence,known;
 string basis,event_kind,reason;
};
BKNProjection BKNProjectionEmpty(int terminal){
 BKNProjection p;ZeroMemory(p);p.end=terminal;p.event_bar=-1;p.contact=-1;p.support_exit=-1;p.resume=-1;
 p.event_kind="unknown";p.reason="no_terminal_event_observed_at_this_prefix";return p;
}
BKNProjection BKNObserveChannelProjection(const MqlRates &rows[],const BKNFrozenRuler &support,
 int terminal,int q,double qp,bool axis_review,int seconds,datetime cutoff,int decimals){
 BKNProjection p=BKNProjectionEmpty(terminal);p.basis="owned_corridor_projection";
 if(!support.qualified||seconds<=0||terminal<0||terminal>=ArraySize(rows)||q<0||q>terminal||
    support.construction_known<=0||support.construction_known>cutoff||rows[terminal].time+seconds>cutoff){p.reason="invalid_channel_projection_scope";return p;}
 if(axis_review){p.end=q;p.basis="axis_review_actual_Q_only";p.reason="axis_review_no_active_projection";p.valid=true;return p;}
 BKNFrozenRuler opposite=support;opposite.shifted=true;opposite.start=q;opposite.start_price=qp;opposite.up=!support.up;
 for(int k=terminal+1;k<ArraySize(rows);k++){
  if(rows[k].time+seconds>cutoff)break;
  if(!BKNValidRate(rows[k])||rows[k].time<=rows[k-1].time){p.reason="invalid_native_projection_prefix";return p;}
  long wick,close;
  if(!BKNGapNumerator(support.up?rows[k].high:rows[k].low,opposite,k,decimals,wick)||
     !BKNGapNumerator(rows[k].close,support,k,decimals,close)){p.reason="channel_projection_quote_grid_unavailable";return p;}
  bool hit=wick<=0,exit=close<0;
  if(hit||exit){
   p.event_bar=k;p.contact=hit?k:-1;p.support_exit=exit?k:-1;
   p.occurrence=rows[k].time+seconds;p.known=(datetime)MathMax((long)p.occurrence,(long)support.construction_known);
   p.basis=hit&&exit?"display_stopped_two_sides_same_bar":hit?"display_stopped_opposite_contact":"display_stopped_support_close_exit";
   p.event_kind=hit&&exit?"opposite_contact_and_support_exit_same_bar_order_unknown":hit?"opposite_wick_contact":"support_close_exit";
   p.reason="";break;
  }
  p.end=k;
 }
 p.valid=true;return p;
}
BKNProjection BKNObserveTurningProjection(const MqlRates &rows[],const BKNTurning &turn,
 int seconds,datetime cutoff,int decimals){
 BKNProjection p=BKNProjectionEmpty(turn.terminal);p.basis="known_CE_D_projection_closed_prefix";
 if(!turn.qualified||seconds<=0||turn.terminal<0||turn.terminal>=ArraySize(rows)||
    turn.known_at<=0||turn.known_at>cutoff||rows[turn.terminal].time+seconds>cutoff){p.reason="invalid_turning_projection_scope";return p;}
 if(turn.axis_drift>0.5){p.end=turn.e;p.basis="axis_review_finite_CE_D_only";p.reason="axis_review_no_active_projection";p.valid=true;return p;}
 BKNFrozenRuler ruler=BKNFreezeTurning(turn);int f=-1;
 double terminal_price=turn.up?rows[turn.terminal].high:rows[turn.terminal].low;
 // E can be an earlier supporting touch. The correction belongs AFTER
 // this source's actual terminal, not after an internal C/E anchor.
 for(int k=turn.terminal+1;k<ArraySize(rows);k++){
  if(rows[k].time+seconds>cutoff)break;
  if(!BKNValidRate(rows[k])||rows[k].time<=rows[k-1].time){p.reason="invalid_native_projection_prefix";return p;}
  int candidate=k-2;
  if(f<0&&candidate-2>=turn.terminal){
   bool strict=true;double price=turn.up?rows[candidate].low:rows[candidate].high;
   for(int j=candidate-2;j<=candidate+2;j++)if(j!=candidate&&
    (turn.up?rows[j].low<=price:rows[j].high>=price)){strict=false;break;}
   if(strict)f=candidate;
  }
  bool resumed=f>=0&&(turn.up?rows[k].close>terminal_price:rows[k].close<terminal_price);
  long gap;if(!BKNGapNumerator(turn.up?rows[k].low:rows[k].high,ruler,k,decimals,gap)){
   p.reason="turning_projection_quote_grid_unavailable";return p;
  }
  if(gap<=0||resumed){
   p.event_bar=k;p.contact=gap<=0?k:-1;p.resume=resumed?k:-1;
   p.occurrence=rows[k].time+seconds;p.known=(datetime)MathMax((long)p.occurrence,(long)turn.known_at);
   p.event_kind=gap<=0&&resumed?"turning_contact_and_resumption_same_bar_order_unknown":gap<=0?"turning_wick_contact":"correction_resumed_before_target";
   p.basis=gap<=0?"known_CE_D_projection_stopped_before_first_contact":"known_CE_D_projection_stopped_before_confirmed_resumption";
   p.reason="";break;
  }
  p.end=k;
 }
 p.valid=true;return p;
}
#endif
