#ifndef BOOK_NATIVE_WHOLE_SOURCES
#define BOOK_NATIVE_WHOLE_SOURCES
#include "BookNativeSource.mqh"
#include "BookNativeForce.mqh"
// Original connected same-period source_wave_scope and Book's independent
// completed local-wave screen. Scope is native geometry, never author degree.
// Coarse and local rulers remain separate even when they share A.
struct BKNWholeSource {
 BKNPoint a,b;
 int first_component,last_component,unordered_components;
 bool up;
 datetime known;
};
struct BKNCompletedWave {
 BKNWholeSource source;
 int witness;
 datetime known;
 bool coarse;
 BKNForce force;
};
// A source-inspection request names both original endpoint times. Return a
// unique confirmed source or an explicit reason: never select the nearest
// wave, collapse same-time alternatives, or infer a parent/author degree.
struct BKNWholeSourceLookup {int index;string reason;};
int BKNFindWholeSourceByTimes(const BKNWholeSource &sources[],datetime a,datetime b,
                              datetime cutoff,BKNWholeSourceLookup &result){
 result.index=-1;result.reason="invalid_source_request";
 if(a<=0||b<=a||cutoff<=0)return 0;
 int matches=0;bool future=false;
 for(int i=0;i<ArraySize(sources);i++){
  if(sources[i].a.time!=a||sources[i].b.time!=b)continue;
  if(sources[i].known<=0||sources[i].known>cutoff){future=true;continue;}
  matches++;result.index=i;
 }
 if(matches>1){result.index=-1;result.reason="ambiguous_source_endpoints";return 0;}
 if(matches==0){result.reason=future?"source_not_known_at_cutoff":"source_not_found";return 0;}
 if(sources[result.index].unordered_components>0){result.index=-1;result.reason="source_internal_order_unknown";return 0;}
 result.reason="";return 1;
}
bool BKNPointEqual(const BKNPoint &a,const BKNPoint &b){
 return a.time==b.time&&a.known==b.known&&a.price==b.price&&a.kind==b.kind;
}
bool BKNComponentKnown(const MqlRates &rows[],const BKNPoint &a,const BKNPoint &b,
                      int seconds,datetime known){
 if(a.known>known||b.known>known||a.time+seconds>a.known||b.time+seconds>b.known||
   a.index<0||b.index<0||a.index>=ArraySize(rows)||b.index>=ArraySize(rows)||
   rows[a.index].time!=a.time||rows[b.index].time!=b.time||a.kind==b.kind||a.price==b.price)return false;
 if((a.kind!=1&&a.kind!=-1)||(b.kind!=1&&b.kind!=-1))return false;
 if((a.kind==1?rows[a.index].high:rows[a.index].low)!=a.price||
    (b.kind==1?rows[b.index].high:rows[b.index].low)!=b.price)return false;
 // Same-candle high/low remains an unordered bound, not a sequential leg.
 return a.time<=b.time&&BKNSourceRateValid(rows[a.index])&&BKNSourceRateValid(rows[b.index]);
}
bool BKNFullSourceEnvelope(const MqlRates &rows[],const BKNPoint &a,const BKNPoint &b){
 if(a.index<0||b.index<=a.index||b.index>=ArraySize(rows))return false;
 double low=MathMin(a.price,b.price),high=MathMax(a.price,b.price);
 for(int k=a.index;k<=b.index;k++)
  if(!BKNSourceRateValid(rows[k])||rows[k].low<low||rows[k].high>high)return false;
 return true;
}
// One terminal at a time, preserving original source order and clocks.
// The frame scheduler may yield between terminals without rebuilding sources.
bool BKNAppendWholeSourceAt(const MqlRates &rows[],const BKNPoint &context[],int seconds,
                            datetime cutoff,int end,BKNWholeSource &out[]){
 if(seconds<=0||cutoff<=0||end<0||end+1>=ArraySize(context))return false;
  BKNPoint a,b;BKNSCopy(a,context[end]);BKNSCopy(b,context[end+1]);
  datetime known=(datetime)MathMax((double)a.known,(double)b.known);
  if(known>cutoff||a.time>=b.time||!BKNComponentKnown(rows,a,b,seconds,known))return true;
  bool up=a.kind==-1;int start=end,cursor=end;
  // No retroactive filtering of the final reduced path: every extension is
  // checked at THIS native terminal's original confirmation clock.
  while(cursor>=2){
   bool valid=true;
   for(int part=cursor-2;part<=cursor;part++)
    if(!BKNComponentKnown(rows,context[part],context[part+1],seconds,known)){valid=false;break;}
   if(!valid||context[cursor-2].kind!=(up?-1:1)||context[cursor].kind!=(up?-1:1)||
      context[cursor-1].kind==(up?-1:1))break;
   const bool terminal_extends=up?b.price>=context[cursor-1].price:b.price<=context[cursor-1].price;
   if(!terminal_extends)break;
   const bool origin_extends=up?context[cursor-2].price<context[start].price:context[cursor-2].price>context[start].price;
   if(origin_extends&&BKNFullSourceEnvelope(rows,context[cursor-2],b))start=cursor-2;
   cursor-=2;
  }
  BKNSCopy(a,context[start]);
  if(a.time>=b.time||!BKNFullSourceEnvelope(rows,a,b))return true;
  bool contiguous=true;
  for(int k=a.index+1;k<=b.index;k++)if(rows[k].time-rows[k-1].time!=seconds){contiguous=false;break;}
  // This matches the strict supplied-native source policy. Broker-specific
  // closed-session research exceptions require a separately verified calendar;
  // they are NOT inferred from today's offset or a missing candle.
  if(!contiguous)return true;
  bool duplicate=false;
  for(int j=0;j<ArraySize(out);j++)
   if(out[j].first_component==start&&out[j].last_component==end){duplicate=true;break;}
  if(duplicate)return true;
  BKNWholeSource source;ZeroMemory(source);BKNSCopy(source.a,a);BKNSCopy(source.b,b);
  source.first_component=start;source.last_component=end;source.known=known;source.up=b.price>a.price;
  for(int part=start;part<=end;part++)if(context[part].time==context[part+1].time)source.unordered_components++;
  int n=ArraySize(out);ArrayResize(out,n+1);out[n]=source;

 return true;
}
bool BKNBuildWholeSources(const MqlRates &rows[],const BKNPoint &context[],int seconds,
                         datetime cutoff,BKNWholeSource &out[]){
 ArrayResize(out,0);if(seconds<=0||cutoff<=0)return false;
 for(int end=0;end+1<ArraySize(context);end++)
  if(!BKNAppendWholeSourceAt(rows,context,seconds,cutoff,end,out))return false;
 return true;
}
void BKNAppendCompleted(BKNCompletedWave &out[],const BKNCompletedWave &wave){
 int n=ArraySize(out);ArrayResize(out,n+1);out[n]=wave;
}
bool BKNCompletedOriginSeen(const BKNCompletedWave &out[],const BKNWholeSource &source){
 for(int i=0;i<ArraySize(out);i++)if(out[i].source.a.time==source.a.time&&
   out[i].source.a.price==source.a.price&&out[i].source.up==source.up&&!out[i].coarse)return true;
 return false;
}
bool BKNCompletedTerminalSeen(const BKNCompletedWave &out[],const BKNCompletedWave &wave){
 for(int i=0;i<ArraySize(out);i++)if(out[i].coarse==wave.coarse&&out[i].source.b.time==wave.source.b.time&&
   out[i].source.b.price==wave.source.b.price&&out[i].source.up==wave.source.up)return true;
 return false;
}
// broker_force_wave_scope's original local screen, distinct from force
// qualification. Earliest qualifying B per A, then first confirmed material
// return BEFORE any later larger B. 4ATR/.382 are engineering parameters.
// Consider one source against the same immutable native path. Selected
// origins remain in `chosen` until all source candidates have been visited.
bool BKNConsiderCompletedLocal(const MqlRates &rows[],const BKNWholeSource &source,
                               const BKNPoint &native_path[],int seconds,datetime cutoff,
                               BKNCompletedWave &chosen[],double minimum_atr=4.0,double minimum_return=.382){
 if(seconds<=0||minimum_atr<0||minimum_return<=0)return false;
  if(source.known>cutoff||BKNCompletedOriginSeen(chosen,source))return true;
  BKNForce force=BKNMeasureForce(rows,source.a.time,source.a.price,source.b.time,source.b.price,source.known,seconds,false);
  if(!force.observed||force.height_atr<minimum_atr)return true;
  double height=MathAbs(source.b.price-source.a.price);int witness=-1;
  for(int p=0;p<ArraySize(native_path);p++){
   const BKNPoint point=native_path[p];if(point.time<=source.b.time||point.known>cutoff)continue;
   if(source.up?point.price>source.b.price:point.price<source.b.price)break;
   if(point.kind!=(source.up?-1:1))continue;
   double depth=(source.up?source.b.price-point.price:point.price-source.b.price)/height;
   if(depth>=minimum_return){witness=p;break;}
  }
  if(witness<0)return true;
  BKNCompletedWave wave;ZeroMemory(wave);wave.source=source;wave.witness=witness;wave.force=force;
  wave.known=(datetime)MathMax((double)source.known,(double)native_path[witness].known);
  BKNAppendCompleted(chosen,wave);
 return true;
}
void BKNFinishCompletedLocal(BKNCompletedWave &chosen[],BKNCompletedWave &out[]){
 ArrayResize(out,0);
 // Original output picks the earliest enclosing A for a shared local B.
 for(int i=1;i<ArraySize(chosen);i++){
  BKNCompletedWave wave=chosen[i];int j=i-1;
  while(j>=0&&chosen[j].source.a.time>wave.source.a.time){chosen[j+1]=chosen[j];j--;}
  chosen[j+1]=wave;
 }
 for(int i=0;i<ArraySize(chosen);i++)if(!BKNCompletedTerminalSeen(out,chosen[i]))BKNAppendCompleted(out,chosen[i]);
}
bool BKNSelectCompletedLocal(const MqlRates &rows[],const BKNWholeSource &sources[],
                            const BKNPoint &native_path[],int seconds,datetime cutoff,
                            BKNCompletedWave &out[],double minimum_atr=4.0,double minimum_return=.382){
 ArrayResize(out,0);if(seconds<=0||minimum_atr<0||minimum_return<=0)return false;
 BKNCompletedWave chosen[];
 for(int i=0;i<ArraySize(sources);i++)
  if(!BKNConsiderCompletedLocal(rows,sources[i],native_path,seconds,cutoff,chosen,minimum_atr,minimum_return))return false;
 BKNFinishCompletedLocal(chosen,out);return true;
}

#endif
