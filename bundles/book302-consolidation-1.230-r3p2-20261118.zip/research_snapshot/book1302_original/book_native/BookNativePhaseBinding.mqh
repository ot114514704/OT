#ifndef BOOK_NATIVE_PHASE_BINDING
#define BOOK_NATIVE_PHASE_BINDING
#include "BookNativePhases.mqh"
#include "BookNativePair.mqh"
// Bind the existing native successor replay to an independently verified
// whole-wave source. Root geometry contacts do not replace the owned A/B.
// These are native event phases, never author degree or parent-score votes.
struct BKNBoundPhase {
 string source_id,root_phase_id,previous_phase_id,phase_id,event_id;
 int d,e,f,recovery,previous_admission;
 bool up,prospective,author_degree_verified,automatic_trade_permission;
 datetime known,occurrence_known;
};
bool BKNBindSuccessors(const MqlRates &rows[],const BKNScope &scope,
 const BKNBoundary &outer,const BKNSourceReference &source,int seconds,
 datetime cutoff,int decimals,BKNBoundPhase &phases[],string &reason){
 ArrayResize(phases,0);
 reason="native_successor_market_or_clock_unavailable";
 if(seconds<=0||source.seconds!=seconds||StringLen(source.provider)==0||StringLen(source.symbol)==0)return false;
 BKNSourceReference actual=BKNReference(scope,source.provider,source.symbol,seconds);
 if(!BKNReferenceMatches(actual,source)){reason="native_successor_owned_scope_mismatch";return false;}
 if(!BKNOuterNativeProof(rows,scope,outer,seconds,cutoff,decimals,reason))return false;
 if((outer.up?1.0:-1.0)*outer.slope<=0){reason="native_successor_outer_not_advancing";return false;}
 // Owned A and the two ruler contacts have separate roles. The proof above
 // validates the entire original scope even when L2 starts at a later swing.
 // Pass that original A through replay; never re-root ownership at L2.
 BKNPhaseRuler seed,selected;ZeroMemory(seed);
 seed.qualified=true;seed.up=outer.up;seed.start=outer.first;seed.end=outer.second;
 seed.start_price=outer.first_price;seed.end_price=outer.second_price;seed.slope=outer.slope;seed.known=outer.known_at;
 BKNPhaseEvent admitted[],candidates[];
 if(!BKNReviewSuccessors(rows,seconds,cutoff,seed,admitted,candidates,selected,reason,scope.a.index))return false;
 string market=source.provider+"|"+source.symbol+"|"+IntegerToString(seconds)+"|";
 string owned=BKNPointKey(rows,scope.a.index,scope.a.price,decimals)+">"+BKNPointKey(rows,scope.b.index,scope.b.price,decimals);
 string root=BKNPointKey(rows,outer.first,outer.first_price,decimals)+">"+BKNPointKey(rows,outer.second,outer.second_price,decimals);
 string source_id="book_native_declared_scope:"+BKNHash(market+owned);
 string root_id="book_native_event_root:"+BKNHash(source_id+"|"+root),previous=root_id;
 datetime dependency=outer.known_at;
 for(int i=0;i<ArraySize(admitted);i++){
  BKNPhaseEvent event=admitted[i];
  reason="native_successor_event_chain_unavailable";
  if(!event.admitted||event.failures!=0||!event.f_confirmed||event.recovery<=event.f||event.recovery>=ArraySize(rows)||
     event.d<outer.first||event.f<=event.d||event.e<=event.d||event.e>=event.f||event.previous_admission!=i-1){ArrayResize(phases,0);return false;}
  BKNBoundPhase phase;ZeroMemory(phase);phase.source_id=source_id;phase.root_phase_id=root_id;phase.previous_phase_id=previous;
  phase.d=event.d;phase.e=event.e;phase.f=event.f;phase.recovery=event.recovery;phase.previous_admission=event.previous_admission;phase.up=outer.up;
  phase.occurrence_known=event.occurrence_known;
  // Replay can discover an old recovery after this seed becomes known.
  // Preserve the event, but never backdate its source-dependent admission.
  phase.known=(datetime)MathMax((double)dependency,(double)event.admission_known);
  if(phase.known<=0||phase.known>cutoff){reason="native_successor_event_clock_unavailable";ArrayResize(phases,0);return false;}
  phase.prospective=dependency<=rows[event.recovery].time&&event.f_known<=rows[event.recovery].time;
  string contacts=BKNPointKey(rows,event.d,BKNPhaseSide(rows[event.d],outer.up),decimals)+">"+
   BKNPointKey(rows,event.f,BKNPhaseSide(rows[event.f],outer.up),decimals);
  phase.phase_id="book_native_event_phase:"+BKNHash(source_id+"|"+root+"|"+contacts);
  phase.event_id="book_native_phase_receipt:"+BKNHash(previous+"|"+phase.phase_id+"|"+
   BKNPointKey(rows,event.e,BKNPhaseOther(rows[event.e],outer.up),decimals)+"|"+
   BKNPointKey(rows,event.recovery,rows[event.recovery].close,decimals)+"|"+IntegerToString((long)phase.known));
  int n=ArraySize(phases);ArrayResize(phases,n+1,16);phases[n]=phase;
  previous=phase.phase_id;dependency=phase.known;
 }
 reason=ArraySize(phases)>0?"":"successor_event_dependencies_incomplete";return true;
}
#endif
