#ifndef BOOK_GUIDED_SESSION_SCOPE
#define BOOK_GUIDED_SESSION_SCOPE
#include "BookGuidedGeometry.mqh"
#include "BookNativeSource.mqh"
// Recover an EARLIER continuous session independently. Both endpoints must
// be supplied confirmed native pivots; a session boundary is never a pivot.
// Endpoint selection uses directional price extremes, not fitted line slope.
bool BKNGuideSessionPiece(const MqlRates &rows[],const BKNPoint &ledger[],
 const BKNScope &parent,int first,int last,int seconds,datetime cutoff,BKNScope &selected){
 ZeroMemory(selected);
 if(seconds<=0||first<parent.a.index||last>=parent.b.index||last<=first||last>=ArraySize(rows)||parent.known<=0||parent.known>cutoff)return false;
 for(int k=first+1;k<=last;k++)if(rows[k].time-rows[k-1].time!=seconds)return false;
 for(int i=0;i<ArraySize(ledger);i++){
  BKNPoint origin;BKNSCopy(origin,ledger[i]);
  if(origin.index<first||origin.index>=last||origin.known>parent.known||origin.kind!=(parent.up?-1:1))continue;
  int best=-1;
  for(int j=i+1;j<ArraySize(ledger);j++){
   BKNPoint end;BKNSCopy(end,ledger[j]);
   if(end.index<=origin.index||end.index>last||end.known>parent.known||end.kind!=(parent.up?1:-1))continue;
   if(best<0){best=j;continue;}
   double tolerance=BKNGeometryTolerance(end.price,ledger[best].price);
   if(parent.up?end.price>ledger[best].price+tolerance:end.price<ledger[best].price-tolerance)best=j;
  }
  if(best<0||!BKNSEnvelope(rows,origin,ledger[best])||BKNSUnknownBetween(ledger,origin.time,ledger[best].time))continue;
  if(BKNGuideScopeReason(rows,origin.index,ledger[best].index,parent.up,seconds,parent.known,cutoff)!="")continue;
  BKNScopeCopy(selected,parent);BKNSCopy(selected.a,origin);BKNSCopy(selected.b,ledger[best]);
  selected.degree=0;selected.envelope=true;selected.ambiguous=false;return true;
 }
 return false;
}
// A gap-spanning parent cannot be drawn as continuous geometry. Its final
// continuous session may nevertheless have its OWN confirmed native origin.
// Recover that scope, not a synthetic boundary at the first session candle.
bool BKNGuideSessionSuffix(const MqlRates &rows[],const BKNPoint &ledger[],
 const BKNScope &parent,int seconds,datetime cutoff,BKNScope &selected){
 ZeroMemory(selected);
 int a=parent.a.index,b=parent.b.index;
 if(seconds<=0||a<0||b<=a||b>=ArraySize(rows)||!parent.envelope||parent.known>cutoff||parent.known<=0)return false;
 int first=a;
 for(int i=a+1;i<=b;i++)if(rows[i].time-rows[i-1].time!=seconds)first=i;
 if(first==a)return false;
 for(int j=0;j<ArraySize(ledger);j++){
  BKNPoint p;BKNSCopy(p,ledger[j]);
  if(p.index<first||p.index>=b||p.known>parent.known||p.kind!=(parent.up?-1:1))continue;
  if(!BKNSEnvelope(rows,p,parent.b)||BKNSUnknownBetween(ledger,p.time,parent.b.time))continue;
  if(BKNGuideScopeReason(rows,p.index,b,parent.up,seconds,parent.known,cutoff)!="")continue;
  BKNScopeCopy(selected,parent);BKNSCopy(selected.a,p);
  selected.degree=0;selected.envelope=true;selected.ambiguous=false;return true;
 }
 return false;
}
#endif
