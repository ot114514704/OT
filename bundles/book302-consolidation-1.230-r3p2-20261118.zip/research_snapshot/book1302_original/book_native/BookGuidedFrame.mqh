#ifndef BOOK_GUIDED_FRAME
#define BOOK_GUIDED_FRAME
#include "BookNativeFrame.mqh"
#include "BookGuidedGeometry.mqh"
#include "BookGuidedStages.mqh"
#include "BookGuidedTurningLife.mqh"
#include "BookGuidedShiftLife.mqh"
#include "BookGuidedScopePhases.mqh"
#include "BookGuidedTerminalTurning.mqh"
#include "BookGuidedFormation.mqh"
#include "BookGuidedPrefixTurning.mqh"
#include "BookGuidedSessionScope.mqh"
// Isolated 1.302 drawing integration. Existing force/wave/entry consumers are
// not repurposed. No new geometry is silently promoted to a Book author phase.
bool BKNGuideShapeClocksValid(const BKNShape &s,datetime cutoff){
 if(s.line_family!="GUIDED_SOURCE"&&s.line_family!="GUIDED_SHIFT"&&s.line_family!="GUIDED_TURNING")return false;
 bool observed=(s.line_family=="GUIDED_TURNING"&&s.line_display_basis=="fixed_formation_equation_observed_after_owner")||
  (s.line_family=="GUIDED_SHIFT"&&s.line_display_basis=="forward_from_opposite_contact_fixed_channel_equation");
 bool point=s.line_family=="GUIDED_SHIFT"&&s.kind=="point"&&s.a==s.b&&s.a==s.line_q_time&&s.pa==s.line_q_price;
 bool event_clock=observed?(s.line_event_known>=0&&s.line_event_known<=s.line_display_known):s.line_event_known==0;
 return s.a>0&&(s.b>s.a||point)&&s.owner_a>0&&s.owner_b>s.owner_a&&s.a>=s.owner_a&&(observed||s.b<=s.owner_b)&&
  s.line_construction_known>0&&s.line_construction_known<=s.known&&s.known<=cutoff&&
  s.line_display_known>=s.line_construction_known&&s.line_display_known==s.known&&s.b<s.line_display_known&&event_clock&&
  !s.line_event_eligible&&!s.line_pair_eligible&&s.line_anchor_time>0&&
  s.line_a_time>=s.owner_a&&s.line_b_time<=s.owner_b&&s.line_b_time>s.line_a_time;
}
class BKNGuideFrameBuilder {
private:
 MqlRates m_rows[];
 BKNScope m_scopes[];
 bool m_developing[];
 BKNGuidedStage m_stage_basis[];
 BKNScope m_phase_hosts[];
 bool m_split_phase[];
 bool m_session_suffix[];
 BKNWholeSource m_sources[];
 BKNPoint m_context[];
 int m_starts[],m_stops[];
 int m_stage,m_emit,m_segment,m_source_end,m_seconds,m_decimals,m_degree,m_detail;
 datetime m_cutoff;
 string m_provider,m_symbol,m_input,m_namespace,m_failure;
 bool m_cancelled,m_context_ready;
 string Owner(const BKNScope &s){
  int index=ScopeIndex(s);
  if(index>=0&&m_developing[index])
   return "book_guided_developing_scope:"+BKNHash(m_namespace+"|"+BKNPointKey(m_rows,s.a.index,s.a.price,m_decimals)+"|"+IntegerToString((int)s.up));
  return "book_guided_scope:"+BKNHash(m_namespace+"|"+BKNPointKey(m_rows,s.a.index,s.a.price,m_decimals)+">"+
   BKNPointKey(m_rows,s.b.index,s.b.price,m_decimals));
 }
 int ScopeIndex(const BKNScope &s){
  for(int i=0;i<ArraySize(m_scopes);i++)if(m_scopes[i].a.time==s.a.time&&m_scopes[i].b.time==s.b.time&&
   m_scopes[i].a.price==s.a.price&&m_scopes[i].b.price==s.b.price)return i;
  return -1;
 }
 int AddScope(const BKNScope &s,bool developing=false){
  int existing=ScopeIndex(s);if(existing>=0)return existing;
  int n=ArraySize(m_scopes);BKNScopeAppend(m_scopes,s);ArrayResize(m_developing,n+1);m_developing[n]=developing;
  ArrayResize(m_stage_basis,n+1);ZeroMemory(m_stage_basis[n]);
  ArrayResize(m_phase_hosts,n+1);ZeroMemory(m_phase_hosts[n]);ArrayResize(m_split_phase,n+1);m_split_phase[n]=false;
  ArrayResize(m_session_suffix,n+1);m_session_suffix[n]=false;return n;
 }
 bool BuildScopes(){
  // Pivot evidence uses neighboring actual trading bars, including those
  // across a session gap. Geometry still belongs to one continuous segment.
  // Rebuilding the ledger after slicing used to lose opening-session peaks.
  BKNPoint full_ledger[],full_points[];BKNScope full_scopes[],full_legs[];
  if(!BKNSLedger(m_rows,m_seconds,m_cutoff,2,full_ledger))return false;
  if(!BKNGeometryScopes(m_rows,full_ledger,m_seconds,m_cutoff,m_degree,full_scopes)||
     !BKNAppendGeometryDetails(m_rows,full_ledger,m_seconds,m_cutoff,m_degree,m_detail,full_scopes)||
     !BKNSBuildPath(m_rows,full_ledger,m_seconds,m_cutoff,0,full_points,full_legs))return false;
  BKNScope recovered[],gap_hosts[];int supplied=ArraySize(full_scopes);
  for(int i=0;i<supplied;i++){
   for(int part=0;part<ArraySize(m_starts);part++){
    int first=(int)MathMax(full_scopes[i].a.index,m_starts[part]),last=m_stops[part];
    if(last>=full_scopes[i].b.index||last<=first)continue;
    BKNScope piece;if(!BKNGuideSessionPiece(m_rows,full_ledger,full_scopes[i],first,last,m_seconds,m_cutoff,piece))continue;
    bool found=false;for(int j=0;j<ArraySize(full_scopes);j++)if(full_scopes[j].a.time==piece.a.time&&full_scopes[j].b.time==piece.b.time){found=true;break;}
    if(found)continue;
    BKNScopeAppend(recovered,piece);BKNScopeAppend(gap_hosts,full_scopes[i]);BKNScopeAppend(full_scopes,piece);
   }
   BKNScope child;
   if(!BKNGuideSessionSuffix(m_rows,full_ledger,full_scopes[i],m_seconds,m_cutoff,child))continue;
   bool exists=false;for(int j=0;j<ArraySize(full_scopes);j++)if(full_scopes[j].a.time==child.a.time&&full_scopes[j].b.time==child.b.time){exists=true;break;}
   if(exists)continue;
   BKNScopeAppend(recovered,child);BKNScopeAppend(gap_hosts,full_scopes[i]);BKNScopeAppend(full_scopes,child);
  }
  for(int part=0;part<ArraySize(m_starts);part++){
   int first=m_starts[part],last=m_stops[part];MqlRates rows[];ArrayResize(rows,last-first+1);
   for(int k=first;k<=last;k++)rows[k-first]=m_rows[k];
   BKNPoint ledger[];BKNScope scopes[];
   for(int j=0;j<ArraySize(full_ledger);j++)if(full_ledger[j].index>=first&&full_ledger[j].index<=last){
    BKNPoint p;BKNSCopy(p,full_ledger[j]);p.index-=first;BKNSAppend(ledger,p);
   }
   // Reduction also needs the original neighbor context. Select first,
   // then retain only owners wholly inside this actual continuous segment.
   for(int j=0;j<ArraySize(full_scopes);j++)if(full_scopes[j].a.index>=first&&full_scopes[j].b.index<=last){
    BKNScope s;BKNScopeCopy(s,full_scopes[j]);s.a.index-=first;s.b.index-=first;BKNScopeAppend(scopes,s);
   }
   // A rejected gap-spanning composite must not erase its independent
   // continuous children, including when optional detail drawing is off.
   for(int j=0;j<ArraySize(full_legs);j++)if(full_legs[j].a.index>=first&&full_legs[j].b.index<=last){
    bool covered=false;for(int k=0;k<ArraySize(scopes);k++)if(full_legs[j].a.time>=scopes[k].a.time&&full_legs[j].b.time<=scopes[k].b.time){covered=true;break;}
    if(!covered){BKNScope s;BKNScopeCopy(s,full_legs[j]);s.a.index-=first;s.b.index-=first;BKNScopeAppend(scopes,s);}
   }
   for(int i=0;i<ArraySize(scopes);i++){
    BKNScope phases[];
    string split=scopes[i].degree>0?BKNGuideSplitComposite(rows,ledger,scopes[i],m_seconds,m_cutoff,phases):"native_base_leg";
    if(split=="composite_scope_replaced_by_observed_phases"){
     BKNScope host;BKNScopeCopy(host,scopes[i]);host.a.index+=first;host.b.index+=first;
     BKNGeometryCoverage c;ZeroMemory(c);c.a=host.a.time;c.b=host.b.time;c.known=host.known;
     c.reason=split;c.extension_reason="parent_retained_as_provenance;phase_count="+IntegerToString(ArraySize(phases));
     int n=ArraySize(coverage);ArrayResize(coverage,n+1);coverage[n]=c;
     for(int j=0;j<ArraySize(phases);j++){
      phases[j].a.index+=first;phases[j].b.index+=first;
      int existing=ScopeIndex(phases[j]),added=AddScope(phases[j]);
      if(existing<0){BKNScopeCopy(m_phase_hosts[added],host);m_split_phase[added]=true;}
     }
     continue;
    }
    scopes[i].a.index+=first;scopes[i].b.index+=first;
    // Exact native ranges are drawn once. Degree remains engineering view
    // metadata, not another owner/parent simply because an interval contains it.
    AddScope(scopes[i]);
   }
   // Confirmed path endpoints deliberately lag. Also expose the currently
   // developing native leg from its last independently confirmed origin to
   // a real CLOSED extreme. This is a revisable candidate, not a confirmed
   // terminal, author phase or event source. No synthetic viewport endpoint.
   BKNPoint points[];BKNScope legs[];
   if(!BKNSBuildPath(rows,ledger,m_seconds,m_cutoff,0,points,legs))return false;
   if(part==ArraySize(m_starts)-1&&ArraySize(points)>0){
    datetime confirmed_tail=points[ArraySize(points)-1].time;
    for(int origin_index=ArraySize(points)-1;origin_index>=0;origin_index--){
     BKNPoint origin=points[origin_index],end;
     // A plateau can prevent a new strict radius-2 pivot while the last
     // confirmed origin has already been exceeded. Re-evaluate prior real
     // origins; do not freeze a now-invalid last pivot or invent a new one.
     if(!BKNSDeveloping(rows,m_seconds,m_cutoff,origin,end)||end.time<=confirmed_tail)continue;
     BKNScope tail;ZeroMemory(tail);BKNSCopy(tail.a,origin);BKNSCopy(tail.b,end);
     tail.up=end.price>origin.price;tail.known=m_cutoff;tail.degree=0;
     tail.envelope=BKNSEnvelope(rows,tail.a,tail.b);
     if(!tail.envelope)continue;
     tail.ambiguous=BKNSUnknownBetween(ledger,origin.time,rows[ArraySize(rows)-1].time);
     tail.a.index+=first;tail.b.index+=first;AddScope(tail,true);break;
    }
   }
  }
  for(int i=0;i<ArraySize(recovered);i++){
   int at=ScopeIndex(recovered[i]);
   if(at>=0&&!m_split_phase[at]){m_session_suffix[at]=true;BKNScopeCopy(m_phase_hosts[at],gap_hosts[i]);}
  }
  return true;
 }
 bool SourceContext(){
  ArrayResize(m_context,0);if(m_segment>=ArraySize(m_starts))return true;
  int first=m_starts[m_segment],last=m_stops[m_segment];MqlRates rows[];ArrayResize(rows,last-first+1);
  for(int i=first;i<=last;i++)rows[i-first]=m_rows[i];
  BKNPoint raw[];if(!BKNSLedger(rows,m_seconds,m_cutoff,2,raw))return false;
  BKNSAlternate(raw,m_context);for(int i=0;i<ArraySize(m_context);i++)m_context[i].index+=first;
  m_source_end=0;m_context_ready=true;return true;
 }
 void Emit(const BKNScope &scope,const BKNGuidedPair &pair,const BKNGuidedChannel &channel,int role,bool developing_host=false){
  if(!pair.valid||(role==1&&!channel.valid))return;
  int first=pair.first,last=scope.b.index;
  // Q may occur before OR after source A. A translated rail starts at Q,
  // never at an imaginary backward extension copied from source A.
  if(role==1){
   if(channel.contact<scope.a.index||channel.contact>scope.b.index)return;
   first=channel.contact;
  }
  if(last<first||(role!=1&&last==first))return;
  BKNGuidedTurningLife life;ZeroMemory(life);
  if(role==1){
   life=BKNGuideObserveShift(m_rows,pair,channel,m_seconds,m_cutoff);
   if(!life.valid){m_failure="guided_shift_lifecycle_"+life.reason;return;}
   last=life.last;
  }
  if(role==2){
   life=BKNGuideObserveTurning(m_rows,pair,m_seconds,m_cutoff);
   if(!life.valid){m_failure="guided_turning_lifecycle_"+life.reason;return;}
   last=life.last;
  }
  datetime display_known=role>0?life.display_known:scope.known;
  string family=role==0?"GUIDED_SOURCE":role==1?"GUIDED_SHIFT":"GUIDED_TURNING";
  string layer=role==0?"trend":role==1?"channel":"turning_point";
  string owner=Owner(scope);double offset=role==1?channel.offset:0.0;
  int scope_index=ScopeIndex(scope);bool developing=developing_host||(scope_index>=0&&m_developing[scope_index]);
  bool native_stage=scope_index>=0&&m_stage_basis[scope_index].valid;
  bool split_phase=scope_index>=0&&m_split_phase[scope_index];
  string label=(role==0?"通道源线":role==1?"通道平移轨":"独立拐点")+
   (native_stage?(m_stage_basis[scope_index].prospective?" | 后继阶段；事前依赖已知；非作者浪级":" | 后继阶段；事后回看；非作者浪级"):developing?" | 发展中；终点未确认":" | 已确认原生端点")+
   " | 同周期原生范围 "+TimeToString(scope.a.time,TIME_DATE|TIME_MINUTES)+">"+TimeToString(scope.b.time,TIME_DATE|TIME_MINUTES)+
   " | 接点 "+TimeToString(m_rows[pair.first].time,TIME_MINUTES)+">"+TimeToString(m_rows[pair.second].time,TIME_MINUTES)+
   " | "+pair.contact_evidence+" | 几何观察；波段语义仍待核";
  if(split_phase)label+=" | 已观察结构重置后分段；父范围仅留归属证据";
  int start=ArraySize(shapes);
  BKNShapeAppend(shapes,m_namespace,family,layer,(role==1&&last==first)?"point":"line",owner,"book_guided_"+family,
   m_rows[first].time,role==1?channel.contact_price:BKNGuideLevel(pair,first)+offset,m_rows[last].time,(role==1&&last==first)?channel.contact_price:BKNGuideLevel(pair,last)+offset,
   display_known,native_stage?"guided_native_stage_geometry":developing?"guided_developing_same_owner_geometry":"guided_same_owner_geometry",label);
  if(ArraySize(shapes)==start)return;
  BKNShape s=shapes[start];
  s.owner_a=scope.a.time;s.owner_b=scope.b.time;s.owner_known=scope.known;s.owner_degree=scope.degree;
  s.source_id=owner;s.author_degree_verified=false;
  s.line_family=family;s.line_role=family;s.line_clocks_supported=true;
  s.line_provider=m_provider;s.line_symbol=m_symbol;s.line_seconds=m_seconds;
  s.line_construction_known=scope.known;s.line_display_known=scope.known;s.line_state_known=scope.known;
  s.line_display_unknown="";s.line_event_unknown="guided_geometry_no_event_admission";s.line_event_kind="unknown";
  s.line_event_known=0;s.line_event_eligible=false;s.line_pair_eligible=false;
  s.line_display_basis="finite_same_owner_from_actual_source_contact";
  if(role==1){
   s.line_display_basis="forward_from_opposite_contact_fixed_channel_equation";
   s.line_display_known=display_known;s.line_state_known=display_known;
   s.line_event_kind=life.state;s.line_event_known=life.cross_known;
   s.line_event_unknown=life.cross>=0?"geometric_channel_close_cross_not_author_reversal":"no_closed_bar_cross_observed";
   s.label+=" | 自实际Q向前；不倒画；"+life.state;
   if(last==first)s.label+=" | Q触点已成立；等待后续原生K线";
  }
  if(role==2){
   s.line_display_known=display_known;s.line_state_known=display_known;
   s.line_display_basis="fixed_formation_equation_observed_after_owner";
   s.line_event_kind=life.state;s.line_event_known=life.cross_known;
   s.line_event_unknown=life.cross>=0?"geometric_close_cross_not_author_reversal":"no_closed_bar_cross_observed";
   s.label+=" | "+life.state+" | 后继行情只观察，不更换原接点";
  }
  s.line_display_first=s.a;s.line_display_last=s.b;s.line_admission_mode="guided_geometry_only";
  s.line_owner_relation="same_supplied_native_scope";
  BKNSetLineEndpoint(m_rows,pair.first,pair.first_price,s.line_a_index,s.line_a_time,s.line_a_price);
  BKNSetLineEndpoint(m_rows,pair.second,pair.second_price,s.line_b_index,s.line_b_time,s.line_b_price);
  if(role==1){
   BKNSetLineEndpoint(m_rows,channel.contact,channel.contact_price,s.line_q_index,s.line_q_time,s.line_q_price);
   s.line_anchor_role="opposite_residual_contact";s.line_anchor_index=s.line_q_index;
   s.line_anchor_time=s.line_q_time;s.line_anchor_price=s.line_q_price;
  }else{
   s.line_anchor_role="first_actual_outer_contact";s.line_anchor_index=s.line_a_index;
   s.line_anchor_time=s.line_a_time;s.line_anchor_price=s.line_a_price;
  }
  s.axis_review=pair.axis_review||pair.position_review;
  s.axis_review_reason=pair.axis_review?"axis_alignment_pending":pair.position_review?"contact_distribution_pending":"";
  s.axis_evidence="guided_independent_native_contacts;axis="+DoubleToString(pair.axis_slope,12)+
   ";slope="+DoubleToString(pair.slope,12)+";swing_contacts="+IntegerToString(pair.swing_contacts)+
   ";owner_semantics=unverified";
  s.construction_id="book_guided_ruler:"+BKNHash(owner+"|"+family+"|"+
   BKNPointKey(m_rows,pair.first,pair.first_price,m_decimals)+">"+BKNPointKey(m_rows,pair.second,pair.second_price,m_decimals)+
   "|offset="+DoubleToString(offset,12));
  s.construction_revision=m_input;s.formation_input_revision=m_input;
  s.line_contract_id=s.construction_id;s.line_contract_revision=BKNHash(s.construction_id+"|"+m_input);
  s.line_contract_state="geometry_only";s.line_contract_reason=developing?"developing_scope_endpoint_unconfirmed":"native_owner_semantics_not_author_confirmed";
  if(split_phase){
   BKNScope host;BKNScopeCopy(host,m_phase_hosts[scope_index]);
   s.line_host_owner=Owner(host);s.line_host_a=host.a.time;s.line_host_b=host.b.time;
   s.line_owner_relation="observed_reset_phase_inside_supplied_parent";
   s.line_contract_reason="confirmed_native_reset_decomposition_not_author_degree";
   s.assessment_known=host.known;
  }
  if(scope_index>=0&&m_session_suffix[scope_index]){
   BKNScope host;BKNScopeCopy(host,m_phase_hosts[scope_index]);
   s.line_host_owner=Owner(host);s.line_host_a=host.a.time;s.line_host_b=host.b.time;
   bool earlier=scope.b.time<host.b.time;
   s.line_owner_relation=earlier?"continuous_session_subscope_from_confirmed_native_endpoints":"continuous_session_subscope_from_confirmed_native_origin";
   s.line_contract_reason=earlier?"gap_parent_not_drawn;earlier_session_confirmed_endpoints":"gap_parent_not_drawn;independent_enclosed_native_session_suffix";
   s.label+=" | 时段内独立原生范围；缺口父范围不连线";
  }
  if(native_stage){
   BKNGuidedStage stage=m_stage_basis[scope_index];
   s.phase_id=stage.phase_id;s.root_phase_id=stage.root_phase_id;s.previous_phase_id=stage.previous_phase_id;
   s.event_id=stage.event_id;s.event_occurrence_known=stage.occurrence_known;s.assessment_known=stage.known;
   BKNSetLineEndpoint(m_rows,stage.d,BKNPhaseSide(m_rows[stage.d],stage.up),s.line_d_index,s.line_d_time,s.line_d_price);
   BKNSetLineEndpoint(m_rows,stage.e,BKNPhaseOther(m_rows[stage.e],stage.up),s.line_e_index,s.line_e_time,s.line_e_price);
   BKNSetLineEndpoint(m_rows,stage.f,BKNPhaseSide(m_rows[stage.f],stage.up),s.line_f_index,s.line_f_time,s.line_f_price);
   s.line_host_owner=stage.root_owner;s.line_host_a=m_rows[stage.root_first].time;s.line_host_b=m_rows[stage.root_last].time;
   s.line_owner_relation="native_event_stage_with_root_provenance";
   s.line_contract_reason="native_successor_stage_not_author_wave_or_event_permission";
  }
  s.line_geometry_valid=BKNGuideShapeClocksValid(s,m_cutoff);
  if(!s.line_geometry_valid)m_failure="guided_emitted_line_contract_invalid";
  // The same terminal phase may also exist as an ordinary smaller scope.
  // Keep one immutable ruler rather than drawing it again for each host.
  if(role==2)for(int i=0;i<start;i++)if(shapes[i].line_family==family&&shapes[i].construction_id==s.construction_id){
   ArrayResize(shapes,start);return;
  }
  shapes[start]=s;
 }
 void Draw(const BKNScope &scope){
  BKNGeometryCoverage c;ZeroMemory(c);c.a=scope.a.time;c.b=scope.b.time;c.known=scope.known;
  int start=ArraySize(shapes);
  c.reason=scope.ambiguous?"same_bar_order_unknown":BKNGuideScopeReason(m_rows,scope.a.index,scope.b.index,scope.up,m_seconds,scope.known,m_cutoff);
  if(c.reason==""){
   BKNGuidedPair upper=BKNGuideSelectBoundary(m_rows,scope.a.index,scope.b.index,scope.up,true,m_seconds,scope.known,m_cutoff);
   BKNGuidedPair lower=BKNGuideSelectBoundary(m_rows,scope.a.index,scope.b.index,scope.up,false,m_seconds,scope.known,m_cutoff);
   BKNGuidedPair source=scope.up?upper:lower,turning=scope.up?lower:upper;
   BKNGuidedChannel channel=BKNGuideTranslateChannel(m_rows,source,m_seconds,scope.known,m_cutoff);
   Emit(scope,source,channel,0);c.outer=ArraySize(shapes)-start;
   int shift=ArraySize(shapes);Emit(scope,source,channel,1);c.channel=ArraySize(shapes)-shift;c.channel_lines=c.channel;
   BKNScope formation;string formation_reason;
   bool formation_valid=BKNGuideTurningFormation(m_rows,scope,m_seconds,m_cutoff,formation,formation_reason);
   if(formation_valid)turning=BKNGuideSelectBoundary(m_rows,formation.a.index,formation.b.index,
    formation.up,!formation.up,m_seconds,formation.known,m_cutoff);
   else{turning.valid=false;turning.reason=formation_reason;}
   BKNScope turning_scope;BKNScopeCopy(turning_scope,formation);
   BKNGuidedPair displayed_turning=turning;
   if(formation_valid)displayed_turning=BKNGuideTerminalTurning(m_rows,formation,turning,m_seconds,m_cutoff,turning_scope);
   BKNScope prior_impulse;
   bool crossed_origin=formation_valid&&BKNGuideCrossedOriginRuler(m_rows,formation,turning,m_seconds,m_cutoff,prior_impulse);
   int parent_index=ScopeIndex(scope);bool developing_parent=parent_index>=0&&m_developing[parent_index];
   // Splitting a reset parent must not erase its previously visible finite
   // terminal ruler merely because the new independent scope is shorter.
   // No backward extension is drawn; channel sources retain full enclosure.
   bool split_forward=false;
   if(formation_valid&&!displayed_turning.valid&&parent_index>=0&&m_split_phase[parent_index]&&
      formation.b.index-formation.a.index>=4){
    BKNGuidedPair finite=BKNGuideSelectForwardTurning(m_rows,formation.a.index,formation.b.index,
     formation.up,m_seconds,formation.known,m_cutoff);
    if(finite.valid&&finite.axis_error<=1.0){
     displayed_turning=finite;BKNScopeCopy(turning_scope,formation);split_forward=true;
    }
   }
   // A late acceleration is an additional independently owned ruler. It
   // must not erase the valid broad decline requested in the red-line cases.
   int broad_start=ArraySize(shapes),broad_count=0;
   if(crossed_origin){
    BKNGuidedPair retained=BKNGuideSelectBoundary(m_rows,prior_impulse.a.index,prior_impulse.b.index,prior_impulse.up,!prior_impulse.up,m_seconds,prior_impulse.known,m_cutoff);
    Emit(prior_impulse,retained,channel,2);broad_count=ArraySize(shapes)-broad_start;
   }
   if(turning.valid&&!crossed_origin&&turning_scope.a.time!=formation.a.time){
    Emit(formation,turning,channel,2,developing_parent);broad_count=ArraySize(shapes)-broad_start;
   }
   if(crossed_origin&&turning_scope.a.time==formation.a.time){
    displayed_turning.valid=false;displayed_turning.reason="same_origin_refit_after_prior_impulse_cross";
   }
   int turn=ArraySize(shapes);Emit(turning_scope,displayed_turning,channel,2,developing_parent);c.turning=ArraySize(shapes)-turn;
   if(c.turning>0&&turning_scope.a.time!=scope.a.time){
    shapes[turn].line_host_owner=Owner(scope);shapes[turn].line_host_a=scope.a.time;shapes[turn].line_host_b=scope.b.time;
    shapes[turn].line_owner_relation=turning.valid?"terminal_acceleration_inside_supplied_parent":"independent_terminal_subscope_whole_boundary_unavailable";
    shapes[turn].line_contract_reason=developing_parent?"developing_terminal_phase_endpoint_unconfirmed":turning.valid?"native_terminal_phase_engineering_candidate_not_author_degree":"native_terminal_subscope_not_whole_parent_boundary";
    shapes[turn].label+=turning.valid?" | 末端加速段独立接点；较早接点不拉平末端线":" | 末段独立范围；整段紫线缺点；不代表整段边界";
    shapes[turn].assessment_known=scope.known;
   }
   if(c.turning>0&&formation.b.time!=scope.b.time){
    shapes[turn].line_host_owner=Owner(scope);shapes[turn].line_host_a=scope.a.time;shapes[turn].line_host_b=scope.b.time;
    if(turning_scope.a.time==scope.a.time)shapes[turn].line_owner_relation="first_directional_extreme_inside_supplied_parent";
    shapes[turn].label+=" | "+formation_reason+" | later equal extreme cannot move contacts";
   }
   c.outer_reason=source.reason;c.channel_reason=channel.reason;c.turning_reason=displayed_turning.reason;
   if(displayed_turning.valid&&c.turning==0)c.turning_reason="same_terminal_ruler_already_retained";
   if(!source.valid||!displayed_turning.valid||!channel.valid)c.reason="incomplete_outer_contact_geometry";
   if(c.turning>0&&split_forward){
    c.turning_reason="split_phase_finite_forward_boundary;"+turning.reason;
    c.reason="finite_forward_turning_not_backward_owner_envelope";
    shapes[turn].line_contract_reason="split_phase_forward_from_native_contact_no_backward_extension";
   }else if(c.turning>0&&!turning.valid){
    c.turning_reason="whole_boundary_unavailable;independent_terminal_subscope_drawn;"+turning.reason;
    c.reason="partial_owner_terminal_subscope_only";
   }
   c.turning+=broad_count;
   // The final full-owner envelope is not a veto on a previously formed
   // ruler. Preserve it under its own prefix identity and conservative
   // discovery clock; do not refit it to later correction contacts.
   if(formation_valid){
    BKNScope prefix_scope;
    BKNGuidedPair prefix=BKNGuidePrefixTurning(m_rows,formation,turning,m_seconds,m_cutoff,prefix_scope);
    int prefix_start=ArraySize(shapes);
    if(prefix.valid){
     Emit(prefix_scope,prefix,channel,2);
     if(ArraySize(shapes)>prefix_start){
      shapes[prefix_start].line_host_owner=Owner(scope);
      shapes[prefix_start].line_host_a=scope.a.time;shapes[prefix_start].line_host_b=scope.b.time;
      shapes[prefix_start].line_owner_relation="retained_closed_prefix_ruler_not_whole_parent";
      shapes[prefix_start].line_contract_reason="prefix_constructed_then_observed;parent_discovery_clock_retained";
      shapes[prefix_start].assessment_known=prefix_scope.b.known;
      shapes[prefix_start].status="guided_retained_prefix_geometry";
      StringReplace(shapes[prefix_start].label,"已确认原生端点","闭合前缀端点；非已确认波段终点");
      shapes[prefix_start].label+=" | 原闭合前缀尺保留；后续回调不重拟合；非整段边界";
      c.turning+=ArraySize(shapes)-prefix_start;
      c.extension_reason+="|prior_closed_prefix_ruler_retained";
     }
    }
   }
   if(crossed_origin){
    c.turning_reason="same_origin_refit_after_prior_impulse_cross;original_impulse_retained_by_detail_path";
    c.reason="composite_purple_refit_rejected";
   }
   int scope_index=ScopeIndex(scope);
   if(scope_index>=0&&!m_developing[scope_index]&&!m_stage_basis[scope_index].valid&&turning.valid&&!crossed_origin){
    BKNGuidedStage stages[];
    c.extension_reason=BKNGuideStageScopes(m_rows,formation,turning,m_seconds,m_cutoff,m_namespace,m_decimals,Owner(formation),stages);
    for(int j=0;j<ArraySize(stages);j++){
     int existing=ScopeIndex(stages[j].scope);
     if(existing<0){int added=AddScope(stages[j].scope);m_stage_basis[added]=stages[j];}
     // The same native range is drawn once; the witness remains on the root
     // coverage record instead of pretending it is another independent wave.
     c.extension_reason+="|"+stages[j].phase_id+":"+stages[j].event_id+":"+IntegerToString((long)stages[j].known);
    }
   }
  }
  int scope_index=ScopeIndex(scope);
  if(scope_index>=0&&m_developing[scope_index])c.extension_reason="developing_scope_endpoint_unconfirmed";
  c.count=ArraySize(shapes)-start;c.recovery_reason="outside_guided_three_line_scope";
  int n=ArraySize(coverage);ArrayResize(coverage,n+1,128);coverage[n]=c;
 }
 void RetireSupersededTurning(){
  for(int i=0;i<ArraySize(shapes);i++){
   BKNShape old=shapes[i];
   if(old.line_family!="GUIDED_TURNING"||old.line_b_index<=old.line_a_index)continue;
   double slope=(old.line_b_price-old.line_a_price)/(old.line_b_index-old.line_a_index);
   datetime replacement=0;
   for(int j=0;j<ArraySize(shapes);j++){
    BKNShape next=shapes[j];
    if(i==j||next.line_family!="GUIDED_TURNING"||next.owner_a!=old.owner_a||next.owner_b<=old.owner_b||
       next.line_owner_relation=="retained_closed_prefix_ruler_not_whole_parent"||next.line_b_index<=next.line_a_index)continue;
    double newer=(next.line_b_price-next.line_a_price)/(next.line_b_index-next.line_a_index);
    if(slope*newer<=0||MathAbs(newer)<=MathAbs(slope)+BKNGeometryTolerance(newer,slope))continue;
    int earlier=-1,later=-1;
    for(int k=0;k<ArraySize(m_rows);k++){
     if(m_rows[k].time==old.owner_b)earlier=k;if(m_rows[k].time==next.owner_b)later=k;
    }
    if(earlier<0||later<0)continue;
    double before=slope>0?m_rows[earlier].high:m_rows[earlier].low;
    double after=slope>0?m_rows[later].high:m_rows[later].low;
    if(slope>0?after<=before+BKNGeometryTolerance(after,before):after>=before-BKNGeometryTolerance(after,before))continue;
    datetime known=(datetime)MathMax((long)old.line_construction_known,(long)next.line_construction_known);
    if(known>m_cutoff||known<=old.line_b_time)continue;
    if(replacement==0||known<replacement)replacement=known;
   }
   if(replacement==0||old.b<replacement)continue;
   int end=-1;for(int k=old.line_b_index;k<ArraySize(m_rows);k++){
    if(m_rows[k].time+m_seconds>replacement)break;end=k;
   }
   if(end<old.line_b_index||m_rows[end].time>=old.b)continue;
   old.b=m_rows[end].time;old.pb=old.line_a_price+slope*(end-old.line_a_index);
   old.known=replacement;old.line_display_known=replacement;old.line_state_known=replacement;old.line_display_last=old.b;
   if(old.line_event_kind!="")StringReplace(old.label,old.line_event_kind,"superseded_same_origin_new_extreme");
   old.line_event_known=0;old.line_event_kind="superseded_same_origin_new_extreme";
   old.line_event_unknown="replacement_not_reversal_or_trade_event";
   old.status="guided_retired_same_origin_geometry";
   old.label+=" | 同起点创新极值的新陡尺已成立；旧尺停止延伸；非反转信号";
   shapes[i]=old;
  }
 }
public:
 BKNShape shapes[];
 BKNGeometryCoverage coverage[];
 BKNGuideFrameBuilder(){m_stage=0;m_cancelled=false;m_failure="";}
 bool Begin(const MqlRates &rows[],int seconds,datetime cutoff,string provider,string symbol,int decimals,string input_revision,int degree=1,int detail=1){
  Cancel();ArrayResize(shapes,0);ArrayResize(coverage,0);ArrayResize(m_scopes,0);ArrayResize(m_developing,0);ArrayResize(m_stage_basis,0);ArrayResize(m_phase_hosts,0);ArrayResize(m_split_phase,0);ArrayResize(m_session_suffix,0);ArrayResize(m_sources,0);ArrayResize(m_starts,0);ArrayResize(m_stops,0);
  m_failure="";m_cancelled=false;m_stage=0;m_emit=0;m_segment=0;m_context_ready=false;
  m_seconds=seconds;m_cutoff=cutoff;m_provider=provider;m_symbol=symbol;m_input=input_revision;m_decimals=decimals;m_degree=degree;m_detail=detail;
  m_namespace=provider+"|"+symbol+"|"+IntegerToString(seconds)+"|guided_0302";
  if(seconds<=0||cutoff<=0||ArraySize(rows)<5||degree<0||degree>3||detail<0||detail>3){m_failure="guided_native_input_invalid";return false;}
  ArrayResize(m_rows,ArraySize(rows));ArrayCopy(m_rows,rows);
  int begin=0;
  for(int i=0;i<ArraySize(m_rows);i++){
   if(!BKNValidRate(m_rows[i])||m_rows[i].time+seconds>cutoff||(i>0&&m_rows[i].time<=m_rows[i-1].time)){m_failure="guided_native_rows_invalid";return false;}
   if(i>0&&m_rows[i].time-m_rows[i-1].time!=seconds){
    int n=ArraySize(m_starts);ArrayResize(m_starts,n+1);ArrayResize(m_stops,n+1);m_starts[n]=begin;m_stops[n]=i-1;begin=i;
   }
  }
  int n=ArraySize(m_starts);ArrayResize(m_starts,n+1);ArrayResize(m_stops,n+1);m_starts[n]=begin;m_stops[n]=ArraySize(m_rows)-1;
  m_stage=1;return true;
 }
 void Cancel(){m_cancelled=true;m_stage=0;}
 bool Failed(){return m_failure!="";}
 string Failure(){return m_failure;}
 int Stage(){return m_stage;}
 string Progress(){return "Book1.302 原生画线 · "+IntegerToString(m_stage)+" · 已绘 "+IntegerToString(ArraySize(shapes))+" · 归属语义待核";}
 void StampCurrentContracts(){
  for(int i=0;i<ArraySize(shapes);i++)if(!BKNGuideShapeClocksValid(shapes[i],m_cutoff)){shapes[i].line_geometry_valid=false;m_failure="guided_frame_contract_invalid";}
 }
 bool Step(uint budget=40){
  if(m_cancelled||Failed()||m_stage==0)return false;if(m_stage==9)return true;
  ulong started=GetTickCount64();
  do{
   if(m_stage==1){if(!BuildScopes()){m_failure="guided_native_scope_build_failed";return false;}m_stage=2;}
   else if(m_stage==2){if(m_emit<ArraySize(m_scopes)){BKNScope current;BKNScopeCopy(current,m_scopes[m_emit++]);Draw(current);}else{m_stage=3;m_emit=0;}}
   else if(m_stage==3){
    if(m_segment>=ArraySize(m_starts)){m_stage=4;m_emit=0;continue;}
    if(!m_context_ready&&!SourceContext()){m_failure="guided_connected_context_failed";return false;}
    if(m_source_end+1>=ArraySize(m_context)){m_segment++;m_context_ready=false;continue;}
    if(!BKNAppendWholeSourceAt(m_rows,m_context,m_seconds,m_cutoff,m_source_end++,m_sources)){m_failure="guided_connected_inventory_failed";return false;}
   }else if(m_stage==4){
    if(m_emit>=ArraySize(m_sources)){RetireSupersededTurning();StampCurrentContracts();m_stage=9;return !Failed();}
    BKNWholeSource source=m_sources[m_emit++];BKNScope s;ZeroMemory(s);BKNSCopy(s.a,source.a);BKNSCopy(s.b,source.b);s.up=source.up;s.known=source.known;
    if(ScopeIndex(s)>=0)continue;
    BKNGeometryCoverage c;ZeroMemory(c);c.a=source.a.time;c.b=source.b.time;c.known=source.known;
    c.reason="connected_source_registered_not_selected_parent_unknown";
    int n=ArraySize(coverage);ArrayResize(coverage,n+1,128);coverage[n]=c;
   }
  }while(GetTickCount64()-started<budget&&!Failed());
  return m_stage==9&&!Failed();
 }
 bool AppendConnectedSourceInspection(datetime a,datetime b,string &reason){
  BKNWholeSourceLookup found;
  if(BKNFindWholeSourceByTimes(m_sources,a,b,m_cutoff,found)!=1){reason=found.reason;return false;}
  BKNWholeSource source=m_sources[found.index];BKNScope s;ZeroMemory(s);BKNSCopy(s.a,source.a);BKNSCopy(s.b,source.b);s.known=source.known;s.up=source.up;s.envelope=true;
  if(ScopeIndex(s)<0)Draw(s);reason="";return !Failed();
 }
};
#endif
