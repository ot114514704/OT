#ifndef BOOK_NATIVE_PHASES
#define BOOK_NATIVE_PHASES
#include "BookNativeSource.mqh"
// Numeric/state port of review_outer_successors. Source/root/phase semantic
// hashes and original plan consumers are still separate integration work.
// Radius2 confirmation and strict recovery are explicit engineering policies.
// Admission here means a native successor construction, never author degree,
// a containment-based parent score gate, reversal completion or trade entry.
enum BKNPhaseFailure {
 BKN_PHASE_AMBIGUOUS=1,BKN_PHASE_GAP=2,BKN_PHASE_GEOMETRY=4,
 BKN_PHASE_ANCESTOR_ORIGIN=8,BKN_PHASE_ANCESTOR_CLOSE=16,
 BKN_PHASE_PREDECESSOR_CLOSE=32,BKN_PHASE_NO_RECOVERY=64,
 BKN_PHASE_RECOVERY_BEFORE_F=128,BKN_PHASE_F_UNCONFIRMED=256
};
struct BKNPhaseRuler {
 bool qualified,up;
 int start,end,first_break,parallel_contact;
 double start_price,end_price,slope,min_clearance,mean_clearance,parallel_offset;
 datetime known;
};
struct BKNPhaseEvent {
 int d,e,f,recovery,previous_admission,failures;
 bool admitted,geometry_available,f_confirmed;
 datetime f_known,occurrence_known,recovery_known,admission_known;
 double slope,min_clearance,mean_clearance;
};
void BKNAppendPhase(BKNPhaseEvent &out[],const BKNPhaseEvent &event){
 int n=ArraySize(out);ArrayResize(out,n+1,16);out[n]=event;
}
double BKNPhaseSide(const MqlRates &row,bool up){return up?row.low:row.high;}
double BKNPhaseOther(const MqlRates &row,bool up){return up?row.high:row.low;}
bool BKNReviewSuccessors(const MqlRates &bars[],int seconds,datetime cutoff,const BKNPhaseRuler &seed,
                        BKNPhaseEvent &admissions[],BKNPhaseEvent &candidates[],BKNPhaseRuler &selected,string &reason,int owned_origin=-1){
 ArrayResize(admissions,0);ArrayResize(candidates,0);ZeroMemory(selected);
 reason="qualified_native_seed_unavailable";if(seconds<=0||!seed.qualified)return false;
 MqlRates rows[];int n=0;datetime previous_time=0;
 for(int i=0;i<ArraySize(bars);i++){
  if(bars[i].time+seconds>cutoff)continue;
  if(i!=n||bars[i].time<=previous_time||!BKNSourceRateValid(bars[i])||bars[i].low<=0){reason="invalid_native_phase_prefix";return false;}
  ArrayResize(rows,n+1,256);rows[n++]=bars[i];previous_time=bars[i].time;
 }
 int a=seed.start,d=seed.end;bool up=seed.up;double sign=up?1.0:-1.0;
 reason="seed_native_anchors_unavailable";if(a<0||a>=d||d>=n)return false;
 // A later L2 contact is a ruler anchor, not a replacement wave origin.
 // Standalone legacy callers retain their seed-origin convention; the
 // source-bound caller supplies the independently verified original A.
 int ancestor=owned_origin<0?a:owned_origin;
 if(ancestor<0||ancestor>a){reason="seed_owned_origin_unavailable";return false;}
 double ancestor_price=BKNPhaseSide(rows[ancestor],up);
 if(d-a<2){reason="native_successor_identity_clock_or_geometry_unavailable";return false;}
 double pa=BKNPhaseSide(rows[a],up),pd=BKNPhaseSide(rows[d],up),slope=(pd-pa)/(d-a);
 reason="seed_native_geometry_mismatch";
 if(pa!=seed.start_price||pd!=seed.end_price||sign*slope<=0||MathAbs(slope-seed.slope)>1e-10)return false;
 for(int k=a+1;k<d;k++)if(sign*(BKNPhaseSide(rows[k],up)-(pa+slope*(k-a)))<=0){reason="seed_native_outer_cross_or_contact";return false;}
 BKNPoint points[];if(!BKNSLedger(rows,seconds,cutoff,2,points))return false;
 bool adverse[],favourable[];datetime adverse_known[],favourable_known[];
 ArrayResize(adverse,n);ArrayInitialize(adverse,false);ArrayResize(favourable,n);ArrayInitialize(favourable,false);
 ArrayResize(adverse_known,n);ArrayInitialize(adverse_known,0);ArrayResize(favourable_known,n);ArrayInitialize(favourable_known,0);
 for(int p=0;p<ArraySize(points);p++){
  int i=points[p].index;
  if(points[p].kind==(up?-1:1)){adverse[i]=true;adverse_known[i]=points[p].known;}
  else {favourable[i]=true;favourable_known[i]=points[p].known;}
 }
 reason="seed_native_origins_not_confirmed";if(!adverse[a]||!adverse[d])return false;
 int c=a+1;for(int k=a+2;k<d;k++)if(sign*BKNPhaseOther(rows[k],up)>sign*BKNPhaseOther(rows[c],up))c=k;
 reason="seed_prior_extreme_not_confirmed";if(!favourable[c])return false;
 datetime previous_known=(datetime)MathMax((double)adverse_known[a],MathMax((double)adverse_known[d],(double)favourable_known[c]));
 BKNPhaseRuler preceding=seed;int last_admission=d;
 while(true){
  bool admitted=false;
  for(int f=d+1;f<n;f++){
   if(!adverse[f])continue;
   int e=-1;
   for(int k=d+1;k<f;k++)if(favourable[k]&&(e<0||sign*BKNPhaseOther(rows[k],up)>sign*BKNPhaseOther(rows[e],up)))e=k;
   if(e<0||e<=last_admission||sign*(BKNPhaseOther(rows[e],up)-BKNPhaseOther(rows[c],up))<=0)continue;
   bool superseded=false;
   for(int k=d+1;k<f;k++)if(sign*(BKNPhaseOther(rows[k],up)-BKNPhaseOther(rows[e],up))>0){superseded=true;break;}
   if(superseded)continue;
   BKNPhaseEvent event;ZeroMemory(event);event.d=d;event.e=e;event.f=f;event.recovery=-1;
   event.previous_admission=ArraySize(admissions)-1;event.f_confirmed=true;event.f_known=adverse_known[f];
   event.occurrence_known=rows[f].time+seconds;
   for(int k=f+1;k<n;k++)if(sign*(rows[k].close-BKNPhaseOther(rows[e],up))>0){event.recovery=k;event.recovery_known=rows[k].time+seconds;break;}
   int end=event.recovery>=0?event.recovery:n-1;
   for(int k=e+1;k<=end;k++)if(sign*(BKNPhaseSide(rows[k],up)-BKNPhaseSide(rows[f],up))<0){superseded=true;break;}
   if(superseded)continue;
   double m=(BKNPhaseSide(rows[f],up)-BKNPhaseSide(rows[d],up))/(f-d),minimum=DBL_MAX,total=0;int count=0;
   for(int k=d+1;k<=end;k++)if(k!=f){
    double gap=sign*(BKNPhaseSide(rows[k],up)-(BKNPhaseSide(rows[d],up)+m*(k-d)));
    minimum=MathMin(minimum,gap);total+=gap;count++;
   }
   event.slope=m;event.min_clearance=minimum;event.mean_clearance=count>0?total/count:0;
   if(favourable[d]||favourable[f])event.failures|=BKN_PHASE_AMBIGUOUS;
   for(int k=ancestor+1;k<=end;k++)if(rows[k].time-rows[k-1].time!=seconds){event.failures|=BKN_PHASE_GAP;break;}
   if(sign*m<=0||count==0||minimum<=1e-9)event.failures|=BKN_PHASE_GEOMETRY;
   else event.geometry_available=true;
   for(int k=ancestor+1;k<=end;k++)if(sign*(BKNPhaseSide(rows[k],up)-ancestor_price)<0){event.failures|=BKN_PHASE_ANCESTOR_ORIGIN;break;}
   for(int k=seed.end+1;k<=end;k++)if(sign*(rows[k].close-(seed.start_price+seed.slope*(k-a)))<0){event.failures|=BKN_PHASE_ANCESTOR_CLOSE;break;}
   for(int k=preceding.end+1;k<=end;k++)if(sign*(rows[k].close-(preceding.start_price+preceding.slope*(k-preceding.start)))<0){event.failures|=BKN_PHASE_PREDECESSOR_CLOSE;break;}
   if(event.recovery<0)event.failures|=BKN_PHASE_NO_RECOVERY;
   else if(event.f_known>event.recovery_known)event.failures|=BKN_PHASE_RECOVERY_BEFORE_F;
   datetime known=(datetime)MathMax((double)previous_known,MathMax((double)event.f_known,MathMax((double)favourable_known[e],(double)event.recovery_known)));
   if(event.failures!=0){BKNAppendPhase(candidates,event);continue;}
   event.admitted=true;event.admission_known=known;BKNAppendPhase(admissions,event);
   ZeroMemory(selected);selected.qualified=true;selected.up=up;selected.start=d;selected.end=f;
   selected.start_price=BKNPhaseSide(rows[d],up);selected.end_price=BKNPhaseSide(rows[f],up);
   selected.slope=m;selected.known=known;selected.min_clearance=minimum;selected.mean_clearance=event.mean_clearance;selected.first_break=-1;
   for(int k=event.recovery+1;k<n;k++)if(sign*(rows[k].close-(selected.start_price+m*(k-d)))<0){selected.first_break=k;break;}
   int reference=d;double offset=BKNPhaseOther(rows[d],up)-selected.start_price;
   for(int k=d+1;k<=event.recovery;k++){
    double distance=BKNPhaseOther(rows[k],up)-(selected.start_price+m*(k-d));
    if(sign*distance>sign*offset){reference=k;offset=distance;}
   }
   selected.parallel_contact=reference;selected.parallel_offset=offset;
   preceding=selected;d=f;c=e;previous_known=known;last_admission=event.recovery;admitted=true;break;
  }
  if(admitted)continue;
  int e=-1;
  for(int k=d+1;k<n-1;k++)if(favourable[k]&&k>last_admission&&(e<0||sign*BKNPhaseOther(rows[k],up)>sign*BKNPhaseOther(rows[e],up)))e=k;
  if(e>=0&&sign*(BKNPhaseOther(rows[e],up)-BKNPhaseOther(rows[c],up))>0){
   int f=e+1;for(int k=e+2;k<n;k++)if(sign*BKNPhaseSide(rows[k],up)<sign*BKNPhaseSide(rows[f],up))f=k;
   if(!adverse[f]){
    BKNPhaseEvent event;ZeroMemory(event);event.d=d;event.e=e;event.f=f;event.recovery=-1;
    event.previous_admission=ArraySize(admissions)-1;event.failures=BKN_PHASE_F_UNCONFIRMED;
    event.occurrence_known=rows[f].time+seconds;BKNAppendPhase(candidates,event);
   }
  }
  break;
 }
 reason=selected.qualified?"":"successor_event_dependencies_incomplete";return true;
}
#endif
