#ifndef BOOK_NATIVE_EVENTS
#define BOOK_NATIVE_EVENTS
#include "BookNativeGeometry.mqh"
#include "BookNativeTurning.mqh"
#include "BookNativeResponse.mqh"
// Frozen native ruler observations, ported from book_boundary_events.
// Source construction, contact, break, response confirmation and failure have
// separate clocks. A one-line close break cannot confirm a trend reversal.
struct BKNFrozenRuler {
 bool qualified,up,turning,shifted;
 int first,second,start;
 double first_price,second_price,start_price;
 datetime construction_known;
};
struct BKNBoundaryEvents {
 bool evaluated,emit_contact,same_bar;
 int born,contact,broken;
 datetime contact_known,break_known;
 double contact_level,break_level;
 string reason;
};
BKNFrozenRuler BKNFreezeOuter(const BKNBoundary &boundary){
 BKNFrozenRuler r;ZeroMemory(r);r.qualified=boundary.qualified;r.up=boundary.up;
 r.first=boundary.first;r.second=boundary.second;r.start=boundary.first;
 r.first_price=boundary.first_price;r.second_price=boundary.second_price;r.start_price=boundary.first_price;
 r.construction_known=boundary.known_at;return r;
}
BKNFrozenRuler BKNFreezeTurning(const BKNTurning &boundary){
 BKNFrozenRuler r;ZeroMemory(r);r.qualified=boundary.qualified;r.up=boundary.up;r.turning=true;r.shifted=true;
 r.first=boundary.c;r.second=boundary.e;r.start=boundary.d;
 r.first_price=boundary.c_price;r.second_price=boundary.e_price;r.start_price=boundary.d_price;
 r.construction_known=boundary.known_at;return r;
}
// Native symbol-decimal prices are converted exactly once. Integer gap
// numerators preserve true equality at a frozen rail, unlike an epsilon that
// can turn a touch into a close break. Off-grid prices are unknown, not rounded
// into a different event. Scales/lengths are bounded before any multiplication.
bool BKNPriceTicks(double value,int decimals,long &ticks){
 if(decimals<0||decimals>8||!MathIsValidNumber(value))return false;
 double scale=MathPow(10.0,decimals),raw=value*scale;
 if(MathAbs(raw)>1e12)return false;
 ticks=(long)MathRound(raw);
 // CopyRates prices can differ by a few binary ULPs from ticks/scale (notably
 // five-digit FX). Admit only representation roundoff, never a tick-relative
 // geometry tolerance; the subsequent contact/break arithmetic stays integer.
 double canonical=((double)ticks)/scale;
 double roundoff=4.0*2.2204460492503131e-16*MathMax(MathAbs(value),MathAbs(canonical));
 return MathAbs(value-canonical)<=roundoff;
}
bool BKNGapNumerator(double value,const BKNFrozenRuler &r,int index,int decimals,long &result){
 int span=r.second-r.first;
 if(span<=0||span>1000000||MathAbs(index-r.start)>1000000)return false;
 long price,a,b,anchor;
 if(!BKNPriceTicks(value,decimals,price)||!BKNPriceTicks(r.first_price,decimals,a)||
    !BKNPriceTicks(r.second_price,decimals,b)||!BKNPriceTicks(r.start_price,decimals,anchor))return false;
 // Each difference <=2e12, each index <=1e6: |result|<=4e18<INT64_MAX.
 result=(price-anchor)*(long)span-(b-a)*(long)(index-r.start);
 if(!r.up)result=-result;
 return true;
}
double BKNFrozenLevel(const BKNFrozenRuler &r,int index){
 return r.start_price+(r.second_price-r.first_price)*(index-r.start)/(r.second-r.first);
}
BKNBoundaryEvents BKNScanBoundary(const MqlRates &rows[],const BKNFrozenRuler &r,
                                 int seconds,datetime cutoff,int decimals){
 BKNBoundaryEvents out;ZeroMemory(out);out.born=-1;out.contact=-1;out.broken=-1;
 out.reason="UNKNOWN_CONSTRUCTION_CLOCK";
 if(!r.qualified||seconds<=0||r.construction_known<=0)return out;
 if(r.construction_known>cutoff){out.reason="CONSTRUCTION_NOT_YET_KNOWN";return out;}
 int n=ArraySize(rows);
 if(r.first<0||r.second<=r.first||r.second>=n||r.start<0||r.start>=n){out.reason="INVALID_ANCHOR_ORDER";return out;}
 // The current C/E/D producer enforces C<D<E. The generic frozen observer
 // also consumes previously constructed translated rulers; their start may
 // lie after E. Observing an existing ruler cannot re-admit its geometry.
 if(!r.shifted&&r.start!=r.first){
  out.reason="INVALID_NATIVE_SHIFT_ANCHOR";return out;
 }
 if(rows[r.second].time+seconds>r.construction_known||rows[r.start].time+seconds>r.construction_known){
  out.reason="ANCHOR_NOT_KNOWN_AT_CONSTRUCTION";return out;
 }
 int closed=0;datetime previous=0;
 for(int i=0;i<n;i++){
  if(rows[i].time+seconds>cutoff)continue;
  if(i!=closed||rows[i].time<=previous||!BKNValidRate(rows[i])){out.reason="INVALID_NATIVE_PREFIX";return out;}
  previous=rows[i].time;closed++;
  if(i>=r.start&&rows[i].time+seconds<=r.construction_known)out.born=i;
 }
 if(out.born<0){out.reason="CONSTRUCTION_OUTSIDE_CONTEXT";return out;}
 long gap;
 if(!BKNGapNumerator(rows[out.born].close,r,out.born,decimals,gap)){
  out.reason="NATIVE_DECIMAL_GAP_UNAVAILABLE";return out;
 }
 if(gap<0){out.reason="ALREADY_BROKEN_WHEN_CONSTRUCTION_KNOWN";return out;}
 // Validate every scanned native close/wick before admitting any event.
 for(int i=out.born+1;i<closed;i++){
  long wick;
  if(!BKNGapNumerator(r.up?rows[i].low:rows[i].high,r,i,decimals,wick)||
     !BKNGapNumerator(rows[i].close,r,i,decimals,gap)){
   out.reason="NATIVE_DECIMAL_GAP_UNAVAILABLE";return out;
  }
  if(out.contact<0&&wick<=0)out.contact=i;
  if(gap<0){out.broken=i;break;}
 }
 out.same_bar=out.contact>=0&&out.contact==out.broken;
 out.emit_contact=out.contact>=0&&!out.same_bar;
 if(out.contact>=0){out.contact_known=rows[out.contact].time+seconds;out.contact_level=BKNFrozenLevel(r,out.contact);}
 if(out.broken>=0){out.break_known=rows[out.broken].time+seconds;out.break_level=BKNFrozenLevel(r,out.broken);}
 out.evaluated=true;out.reason="";return out;
}
BKNResponse BKNRespondToBoundary(const MqlRates &rows[],const BKNFrozenRuler &r,
                               const BKNBoundaryEvents &event,int seconds,datetime cutoff,int radius=2){
 // C/E are real slope contacts; D is the translation anchor. D+(E-C)
 // is only a parameter point on that parallel equation, NOT an observed
 // candle that must precede a break. Search the response extreme after
 // actual E, including the break candle. This also retains a later source
 // terminal Z when E<Z. Do not change the frozen ruler or dependency clocks.
 int pre_break_extreme_first_index=(r.turning&&r.shifted)?r.second+1:r.start+r.second-r.first+1;
 return BKNFirstBookResponse(rows,seconds,cutoff,r.qualified,r.start,
  pre_break_extreme_first_index-1,event.evaluated&&event.broken>=0,event.broken,!r.up,
  r.construction_known,event.break_known,radius);
}
#endif
