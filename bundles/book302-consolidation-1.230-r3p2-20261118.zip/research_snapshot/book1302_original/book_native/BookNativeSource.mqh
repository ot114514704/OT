#ifndef BOOK_NATIVE_SOURCE
#define BOOK_NATIVE_SOURCE
// Book-owned native point primitives; no transport/files/DLL/web/order calls.
// Frozen reference: mt5/unified_native/Machine1_UnifiedNativeKernel.mqh
// Reference SHA256: 8d2a018e65e1e2de612d83d0a0361cc2d13af29e14485bb02cd577ed1e6d1411
// Raw ledger intentionally preserves all confirmations. Historical queries
// filter by their clocks BEFORE alternation/reduction, never after it.
// Full Book source/phase admission remains separate from these primitives.
// Port references: live_xauusd_multitimeframe radius2/alternating ledger;
// arrow_wave_scope.js alternate/reduce/build/developingBackground.
struct BKNPoint {
 datetime time,known,replaced_time,left_boundary,right_boundary;
 double price,replaced_price;
 int kind,index;
 bool restored;
};
void BKNSCopy(BKNPoint &to,const BKNPoint &from){
 to.time=from.time;to.known=from.known;to.price=from.price;
 to.kind=from.kind;to.index=from.index;to.restored=from.restored;
 to.replaced_time=from.replaced_time;to.replaced_price=from.replaced_price;
 to.left_boundary=from.left_boundary;to.right_boundary=from.right_boundary;
}
void BKNSNew(BKNPoint &p,datetime time,datetime known,double price,int kind,int index){
 p.time=time;p.known=known;p.price=price;p.kind=kind;p.index=index;
 p.restored=false;p.replaced_time=0;p.replaced_price=0;p.left_boundary=0;p.right_boundary=0;
}
void BKNSAppend(BKNPoint &points[],const BKNPoint &p){
 int n=ArraySize(points);ArrayResize(points,n+1);BKNSCopy(points[n],p);
}
void BKNSCopyPoints(const BKNPoint &from[],BKNPoint &to[]){
 ArrayResize(to,ArraySize(from));for(int i=0;i<ArraySize(from);i++)BKNSCopy(to[i],from[i]);
}
void BKNSSort(BKNPoint &points[]){
 // Stable chronological ordering: keep the original equal-time OHLC order.
 // Reduce() collects highs then lows, making insertion sort quadratic on a
 // wide historical window at EVERY confirmation clock. Merge runs instead.
 int n=ArraySize(points);bool ordered=true;
 for(int i=1;i<n;i++)if(points[i].time<points[i-1].time){ordered=false;break;}
 if(ordered)return;
 BKNPoint buffer[];ArrayResize(buffer,n);
 for(int width=1;width<n;width*=2){
  for(int start=0;start<n;start+=2*width){
   int middle=(int)MathMin(n,start+width),end=(int)MathMin(n,start+2*width),a=start,b=middle;
   for(int k=start;k<end;k++){
    if(a<middle&&(b>=end||points[a].time<=points[b].time))BKNSCopy(buffer[k],points[a++]);
    else BKNSCopy(buffer[k],points[b++]);
   }
  }
  for(int k=0;k<n;k++)BKNSCopy(points[k],buffer[k]);
 }
}
// All paths supplied to Reduce are chronological. Return the first point
// with time >= value; equal-time native extrema stay one indivisible group.
int BKNSLowerTime(const BKNPoint &points[],datetime value){
 int lo=0,hi=ArraySize(points);
 while(lo<hi){int mid=(lo+hi)/2;if(points[mid].time<value)lo=mid+1;else hi=mid;}
 return lo;
}
void BKNSAlternate(const BKNPoint &points[],BKNPoint &out[]){
 BKNPoint ordered[];BKNSCopyPoints(points,ordered);BKNSSort(ordered);ArrayResize(out,0);
 for(int i=0;i<ArraySize(ordered);i++){
  int n=ArraySize(out);int kind=ordered[i].kind;
  if(n>0&&out[n-1].kind==kind){
   if(kind==1?ordered[i].price>=out[n-1].price:ordered[i].price<=out[n-1].price)BKNSCopy(out[n-1],ordered[i]);
  }else BKNSAppend(out,ordered[i]);
 }
}
bool BKNSourceRateValid(const MqlRates &r){
 return MathIsValidNumber(r.open)&&MathIsValidNumber(r.high)&&MathIsValidNumber(r.low)&&MathIsValidNumber(r.close)
  &&r.low<=MathMin(r.open,r.close)&&MathMax(r.open,r.close)<=r.high;
}
bool BKNSLedger(const MqlRates &rates[],int seconds,datetime cutoff,int radius,BKNPoint &out[]){
 ArrayResize(out,0);if(seconds<=0||radius<1||cutoff<=0)return false;
 int closed[];datetime previous=0;
 for(int i=0;i<ArraySize(rates);i++){
  if(rates[i].time+seconds>cutoff)continue;
  if(rates[i].time<=previous||!BKNSourceRateValid(rates[i]))return false;
  int n=ArraySize(closed);ArrayResize(closed,n+1);closed[n]=i;previous=rates[i].time;
 }
 BKNPoint raw[];
 for(int i=radius;i<ArraySize(closed)-radius;i++){
  int at=closed[i];bool high=true,low=true;
  for(int k=i-radius;k<=i+radius;k++){
   if(k==i)continue;
   if(rates[at].high<=rates[closed[k]].high)high=false;
   if(rates[at].low>=rates[closed[k]].low)low=false;
  }
  datetime known=rates[closed[i+radius]].time+seconds;
  BKNPoint p;
  // Python's equal-time lexical order is high then low. Keep both in the
  // ledger; their intrabar order is unresolved, never inferred.
  if(high){BKNSNew(p,rates[at].time,known,rates[at].high,1,at);BKNSAppend(raw,p);}
  if(low){BKNSNew(p,rates[at].time,known,rates[at].low,-1,at);BKNSAppend(raw,p);}
 }
 BKNSCopyPoints(raw,out);return true;
}
void BKNSArrowPoints(const BKNPoint &ledger[],BKNPoint &out[]){
 BKNPoint unique[];
 for(int i=0;i<ArraySize(ledger);i++){
  bool ambiguous=false;
  for(int j=0;j<ArraySize(ledger);j++)if(i!=j&&ledger[i].time==ledger[j].time&&
    (ledger[i].kind!=ledger[j].kind||ledger[i].price!=ledger[j].price)){ambiguous=true;break;}
  if(!ambiguous)BKNSAppend(unique,ledger[i]);
 }
 BKNSAlternate(unique,out);
}
void BKNSReduce(const BKNPoint &points[],BKNPoint &out[]){
 BKNPoint selected[];
 for(int pass=0;pass<2;pass++){
  int kind=pass==0?1:-1;BKNPoint same[];
  for(int j=0;j<ArraySize(points);j++)if(points[j].kind==kind)BKNSAppend(same,points[j]);
  for(int j=1;j<ArraySize(same)-1;j++){
   bool choose=kind==1?(same[j].price>same[j-1].price&&same[j].price>=same[j+1].price)
    :(same[j].price<same[j-1].price&&same[j].price<=same[j+1].price);
   if(choose){BKNPoint p;BKNSCopy(p,same[j]);p.known=(datetime)MathMax((double)same[j-1].known,MathMax((double)p.known,(double)same[j+1].known));BKNSAppend(selected,p);}
  }
 }
 BKNSSort(selected);BKNPoint bridges[];
 for(int i=1;i<ArraySize(selected);i++){
  if(selected[i-1].kind!=selected[i].kind)continue;
  int kind=-selected[i].kind,reference=-1,extreme=-1;
  int left=BKNSLowerTime(points,selected[i-1].time),right=BKNSLowerTime(points,selected[i].time);
  for(int j=left-1;j>=0;j--)if(points[j].kind==kind){reference=j;break;}
  for(int j=left;j<right;j++){
   if(points[j].kind!=kind)continue;
   if(points[j].time>selected[i-1].time&&
     (extreme<0||(kind==1?points[j].price>points[extreme].price:points[j].price<points[extreme].price)))extreme=j;
  }
  if(reference<0||extreme<0)continue;
  if(kind==1?points[extreme].price>points[reference].price:points[extreme].price<points[reference].price){
   BKNPoint p;BKNSCopy(p,points[extreme]);
   p.known=(datetime)MathMax(MathMax((double)p.known,(double)points[reference].known),MathMax((double)selected[i-1].known,(double)selected[i].known));
   BKNSAppend(bridges,p);
  }
 }
 for(int i=0;i<ArraySize(bridges);i++)BKNSAppend(selected,bridges[i]);
 BKNSAlternate(selected,out);if(ArraySize(out)<2)return;
 datetime first=out[0].time,last=out[ArraySize(out)-1].time;bool changed=true;
 while(changed){
  changed=false;
  for(int i=0;i<ArraySize(out);i++){
   datetime left=i>0?out[i-1].time:first-1,right=i+1<ArraySize(out)?out[i+1].time:last+1;
   int extreme=-1;
   int first_candidate=BKNSLowerTime(points,left+1),after_candidate=BKNSLowerTime(points,right);
   for(int j=first_candidate;j<after_candidate;j++)if(points[j].kind==out[i].kind&&
     (extreme<0||(out[i].kind==1?points[j].price>points[extreme].price:points[j].price<points[extreme].price)))extreme=j;
   if(extreme<0)continue;
   if(out[i].kind==1?points[extreme].price>out[i].price:points[extreme].price<out[i].price){
    BKNPoint p;BKNSCopy(p,points[extreme]);
    p.known=(datetime)MathMax((double)p.known,(double)out[i].known);
    if(i>0)p.known=(datetime)MathMax((double)p.known,(double)out[i-1].known);
    if(i+1<ArraySize(out))p.known=(datetime)MathMax((double)p.known,(double)out[i+1].known);
    p.restored=true;p.replaced_time=out[i].time;p.replaced_price=out[i].price;
    p.left_boundary=i>0?out[i-1].time:0;p.right_boundary=i+1<ArraySize(out)?out[i+1].time:0;
    BKNSCopy(out[i],p);changed=true;
   }
  }
 }
}
bool BKNSEnvelope(const MqlRates &rates[],const BKNPoint &a,const BKNPoint &b){
 if(a.index<0||b.index<=a.index||b.index>=ArraySize(rates)||rates[a.index].time!=a.time||rates[b.index].time!=b.time)return false;
 double low=MathMin(a.price,b.price),high=MathMax(a.price,b.price);
 for(int i=a.index+1;i<b.index;i++)if(rates[i].low<low||rates[i].high>high)return false;
 return true;
}
bool BKNSUnknownBetween(const BKNPoint &ledger[],datetime from,datetime through){
 for(int i=1;i<ArraySize(ledger);i++)if(ledger[i].time==ledger[i-1].time&&from<=ledger[i].time&&ledger[i].time<=through)return true;
 return false;
}
bool BKNSDeveloping(const MqlRates &rates[],int seconds,datetime cutoff,const BKNPoint &origin,BKNPoint &end){
 if(seconds<=0||origin.known>cutoff||origin.index<0||origin.index>=ArraySize(rates)||rates[origin.index].time!=origin.time)return false;
 if(origin.kind!=1&&origin.kind!=-1)return false;
 if((origin.kind==1?rates[origin.index].high:rates[origin.index].low)!=origin.price)return false;
 int sign=-origin.kind,extreme=-1,last=origin.index;
 for(int i=origin.index+1;i<ArraySize(rates);i++){
  if(rates[i].time+seconds>cutoff)continue;
  if(rates[i].time-rates[last].time!=seconds||!BKNSourceRateValid(rates[i]))return false;
  if(sign==1?rates[i].low<origin.price:rates[i].high>origin.price)return false;
  double price=sign==1?rates[i].high:rates[i].low;
  if(extreme<0||(price-(sign==1?rates[extreme].high:rates[extreme].low))*sign>0)extreme=i;
  last=i;
 }
 if(extreme<0)return false;
 double price=sign==1?rates[extreme].high:rates[extreme].low;
 if((price-origin.price)*sign<=0)return false;
 BKNSNew(end,rates[extreme].time,rates[extreme].time+seconds,price,sign,extreme);return true;
}
// Original NativeStructureGraph timeline's witness inventory comes from the
// complete _candidate_wave_ledger alternating endpoints. Preserve that input
// contract for original-context parity, separately from raw confirmation facts.
// It must NOT replace the raw ledger for unknown same-bar order adjudication.
bool BKNSOriginalContextInventory(const MqlRates &rates[],int seconds,datetime cutoff,
                                  BKNPoint &out[],int max_bars=0){
 // Default is the whole supplied native viewport. Pass8192 explicitly ONLY
 // for original graph comparison; never silently paint only the chart tail.
 ArrayResize(out,0);if(max_bars<0||seconds<=0)return false;
 int closed=0;for(int i=0;i<ArraySize(rates);i++)if(rates[i].time+seconds<=cutoff){if(i!=closed)return false;closed++;}
 int begin=max_bars>0?(int)MathMax(0,closed-max_bars):0;MqlRates visible[];ArrayResize(visible,closed-begin);
 for(int i=begin;i<closed;i++)visible[i-begin]=rates[i];
 BKNPoint raw[];if(!BKNSLedger(visible,seconds,cutoff,2,raw))return false;
 for(int i=0;i<ArraySize(raw);i++)raw[i].index+=begin;
 BKNSAlternate(raw,out);
 // With one point the original ledger has no leg endpoints, so its regime
// inventory and timeline witnesses are empty rather than a fabricated leg.
 if(ArraySize(out)<2)ArrayResize(out,0);
 return true;
}
struct BKNScope {
 BKNPoint a,b;
 datetime known;
 int degree;
 bool up,envelope,ambiguous;
};
void BKNScopeCopy(BKNScope &to,const BKNScope &from){
 BKNSCopy(to.a,from.a);BKNSCopy(to.b,from.b);to.known=from.known;
 to.degree=from.degree;to.up=from.up;to.envelope=from.envelope;to.ambiguous=from.ambiguous;
}
void BKNScopeAppend(BKNScope &out[],const BKNScope &scope){
 int n=ArraySize(out);ArrayResize(out,n+1);BKNScopeCopy(out[n],scope);
}
// Input is the explicit native point inventory. Do not pass a final reduced
// path as if it were a replayable confirmation ledger.
bool BKNSBuildPath(const MqlRates &rows[],const BKNPoint &inventory[],int seconds,
                  datetime cutoff,int degree,BKNPoint &points[],BKNScope &legs[]){
 ArrayResize(points,0);ArrayResize(legs,0);
 if(seconds<=0||cutoff<=0||degree<0)return false;
 BKNPoint available[],unique[];
 for(int i=0;i<ArraySize(inventory);i++){
  BKNPoint p;BKNSCopy(p,inventory[i]);
  if(p.known>cutoff||p.time+seconds>cutoff)continue;
  if(!MathIsValidNumber(p.price)||(p.kind!=1&&p.kind!=-1)||p.known<p.time+seconds||
    p.index<0||p.index>=ArraySize(rows)||rows[p.index].time!=p.time||
    (p.kind==1?rows[p.index].high:rows[p.index].low)!=p.price)return false;
  BKNSAppend(available,p);
 }
 BKNSSort(available);
 BKNPoint ambiguous[];
 // Deduplicate only within equal-time groups, retaining the first original
 // witness and its clock exactly. Normally each group has one or two items.
 // Opposite extrema remain ambiguous; sorting does not choose their order.
 for(int i=0;i<ArraySize(available);){
  int end=i+1;while(end<ArraySize(available)&&available[end].time==available[i].time)end++;
  BKNPoint group[];
  for(int j=i;j<end;j++){
   bool duplicate=false;
   for(int k=0;k<ArraySize(group);k++)if(group[k].kind==available[j].kind&&group[k].price==available[j].price){duplicate=true;break;}
   if(!duplicate)BKNSAppend(group,available[j]);
  }
  for(int j=0;j<ArraySize(group);j++){
   if(ArraySize(group)>1)BKNSAppend(ambiguous,group[j]);else BKNSAppend(unique,group[j]);
  }
  i=end;
 }
 BKNSAlternate(unique,points);
 for(int k=0;k<degree;k++){
  BKNPoint next[];BKNSReduce(points,next);BKNSCopyPoints(next,points);
 }
 for(int i=1;i<ArraySize(points);i++){
  BKNScope scope;ZeroMemory(scope);BKNSCopy(scope.a,points[i-1]);BKNSCopy(scope.b,points[i]);
  scope.known=(datetime)MathMax((double)scope.a.known,(double)scope.b.known);
  scope.degree=degree;scope.up=scope.b.price>scope.a.price;
  scope.envelope=BKNSEnvelope(rows,scope.a,scope.b);
  int unknown=BKNSLowerTime(ambiguous,scope.a.time);
  scope.ambiguous=unknown<ArraySize(ambiguous)&&ambiguous[unknown].time<=scope.b.time;
  BKNScopeAppend(legs,scope);
 }
 return true;
}
// One declared native path owns the displayed geometry. Historical source
// hypotheses are evidence, not extra simultaneous waves. Reduction is an
// engineering view level, never a claim about the author's wave degree.
// Outside the confirmed reduced path keep the native legs; never stretch a
// reduced endpoint to the viewport edge or borrow an adjacent wave's point.
bool BKNGeometryScopes(const MqlRates &rows[],const BKNPoint &ledger[],int seconds,
                       datetime cutoff,int degree,BKNScope &out[]){
 ArrayResize(out,0);if(degree<0||degree>3)return false;
 BKNPoint base_points[],major_points[];BKNScope base[],major[];
 if(!BKNSBuildPath(rows,ledger,seconds,cutoff,0,base_points,base))return false;
 if(!BKNSBuildPath(rows,ledger,seconds,cutoff,degree,major_points,major))return false;
 if(ArraySize(major)==0){for(int i=0;i<ArraySize(base);i++)BKNScopeAppend(out,base[i]);return true;}
 datetime first=major[0].a.time,last=major[ArraySize(major)-1].b.time;
 for(int i=0;i<ArraySize(base);i++)if(base[i].b.time<=first)BKNScopeAppend(out,base[i]);
 for(int i=0;i<ArraySize(major);i++){
  if(major[i].envelope){BKNScopeAppend(out,major[i]);continue;}
  // Reduction can join across an outside bar and lose the enclosing A/B
  // contract. Such an interval is NOT a geometry owner. Keep its already
  // independently confirmed native children instead of leaving a blank span
  // or cropping candles to make the invalid parent pass. No parent claim is
  // inherited and no child outside this exact interval is added.
  for(int j=0;j<ArraySize(base);j++)
   if(base[j].envelope&&base[j].a.time>=major[i].a.time&&base[j].b.time<=major[i].b.time)
    BKNScopeAppend(out,base[j]);
 }
 for(int i=0;i<ArraySize(base);i++)if(base[i].a.time>=last)BKNScopeAppend(out,base[i]);
 return true;
}
bool BKNHistoryHasOrigin(const BKNScope &history[],const BKNScope &scope){
 for(int i=0;i<ArraySize(history);i++)
  if(history[i].a.time==scope.a.time&&history[i].a.price==scope.a.price&&history[i].up==scope.up)return true;
 return false;
}
// Additional drawing resolution, NOT additional parent/phase claims. A detail
// interval must already exist on the independently confirmed lower native path
// and fit completely inside one of the selected path's owners. Never crop an
// interval to pass enclosure. Exact A/B duplicates retain the primary owner.
bool BKNAppendGeometryDetails(const MqlRates &rows[],const BKNPoint &ledger[],int seconds,
 datetime cutoff,int degree,int detail_levels,BKNScope &out[]){
 int primary=ArraySize(out);
 if(detail_levels<0||detail_levels>3)return false;
 for(int level=degree-1;level>=0&&level>=degree-detail_levels;level--){
  BKNPoint points[];BKNScope legs[];
  if(!BKNSBuildPath(rows,ledger,seconds,cutoff,level,points,legs))return false;
  for(int i=0;i<ArraySize(legs);i++){
   if(!legs[i].envelope||legs[i].ambiguous)continue;
   bool contained=false,duplicate=false;
   for(int j=0;j<primary;j++)
    if(legs[i].a.time>=out[j].a.time&&legs[i].b.time<=out[j].b.time){contained=true;break;}
   if(!contained)continue;
   for(int j=0;j<ArraySize(out);j++)
    if(legs[i].a.time==out[j].a.time&&legs[i].b.time==out[j].b.time&&
       legs[i].a.price==out[j].a.price&&legs[i].b.price==out[j].b.price){duplicate=true;break;}
   if(!duplicate)BKNScopeAppend(out,legs[i]);
  }
 }
 return true;
}
// Original book_scope_history: replay every confirmation clock; first valid
// native interval per A+price+direction. Boundary history may retain explicit
// interior ambiguity; strict force history cannot. Neither proves author degree.
bool BKNSourceHistory(const MqlRates &rows[],const BKNPoint &inventory[],int seconds,
                     datetime cutoff,int degree,BKNScope &geometry[],BKNScope &strict[]){
 ArrayResize(geometry,0);ArrayResize(strict,0);long clocks[];
 if(seconds<=0||cutoff<=0||degree<0)return false;
 for(int i=0;i<ArraySize(inventory);i++){
  long t=(long)MathMax((double)inventory[i].known,(double)(inventory[i].time+seconds));
  if(t>cutoff)continue;
  int n=ArraySize(clocks);ArrayResize(clocks,n+1);clocks[n]=t;
 }
 ArraySort(clocks);
 for(int i=0;i<ArraySize(clocks);i++){
  if(i>0&&clocks[i]==clocks[i-1])continue;
  BKNPoint points[];BKNScope legs[];
  if(!BKNSBuildPath(rows,inventory,seconds,(datetime)clocks[i],degree,points,legs))return false;
  for(int k=0;k<ArraySize(legs);k++){
   if(!legs[k].envelope)continue;
   BKNScope scope;BKNScopeCopy(scope,legs[k]);scope.known=(datetime)clocks[i];
   if(!scope.ambiguous&&!BKNHistoryHasOrigin(strict,scope))BKNScopeAppend(strict,scope);
   if(scope.a.time<scope.b.time&&scope.b.time+seconds<=scope.known&&!BKNHistoryHasOrigin(geometry,scope))
    BKNScopeAppend(geometry,scope);
  }
 }
 return true;
}
#endif
