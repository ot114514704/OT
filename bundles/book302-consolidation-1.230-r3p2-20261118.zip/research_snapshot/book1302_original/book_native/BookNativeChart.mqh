#ifndef BOOK_NATIVE_CHART
#define BOOK_NATIVE_CHART
#include "BookNativeFrame.mqh"
#include "BookNativeLabels.mqh"
// Book's existing action-button, visibility, theme and Shape[] conventions
// adapted to native in-memory records. No external scene/card reader.
// Development integration surface; full original plan/semantic cards pending.
input group "图层与信息开关"
input bool ShowZigzag=false;
input bool ShowForce=true;
input bool ShowInformationPanels=true;
input bool ShowGuidedChannelSource=true;
input bool ShowBookWave=true;
input bool ShowBookWaveCount=true; // 第7章同源数浪候选，作者浪级仍须核对
input bool ShowGuidedChannelShift=true;
input bool ShowGuidedTurning=true;
input bool ShowBookRecoveryTarget=true;
input bool ShowBookBreakout=true;
input bool ShowBookPullback=false;
input bool ShowBookInvalidation=false;
input bool ShowBookCandlestick=false;
input bool ShowBookChartPattern=false;
input bool ShowBookStopReference=false;
input bool ShowBookRiskFact=false;
input bool ShowLabels=false;
input bool ShowOlderWaveProjections=true;
input bool ShowUnqualifiedGeometryLive=false; // 斜率待核的有限诊断线按需打开；不污染默认蓝/紫主图
input bool ShowBookConstructionReferences=false; // 历史通道方程是诊断参考，不冒充活动拐点
input bool ShowTrendParallelReference=false; // 旧OUTER-Q辅助/历史重建按需打开；独立C-E源线仍显示
input bool ShowCompleteWaveGeometry=true; // 各波段已成立的有限构造；待核用虚线，缺真实锚点不补线
input bool BookOnlyThreeBlueLines=true; // 简化版：只保留外侧趋势、通道外延、回调拐点三项蓝色控制
input group "图表与信息面板外观"
input int GeometryLineWidth=2;
input int ForceLineWidth=2;
input int MaximumVisibleLabels=24;
input int MaximumVisibleWaveLabels=48; // 数浪独立额度，不被力度标签挤掉
input int StructureFontSize=10;
input int InformationFontSize=9;
input int InformationCardWidth=410;
input bool AutomaticPanelColours=true;
input color InformationTextColour=clrLightSteelBlue;
input color InformationBackgroundColour=C'10,25,38';
// This deliverable is intentionally a three-button Book build. MT5 keeps
// input values inside chart profiles, so an older profile can otherwise
// restore BookOnlyThreeBlueLines=false after recompilation. Keep the input
// for compatibility/inspection, but make the product mode authoritative.
bool BKNThreeBlueMode(){return true;}
datetime BKNGeometryOwnerEnd(const BKNShape &s){
 // A shortened/dashed OUTER display is not the end of its source wave.
 // Use the declared owner extent so scrolling inside that wave does not
 // accidentally suppress its CHANNEL or independent C-E/D construction.
 return s.owner_b>=s.owner_a&&s.owner_a>0?s.owner_b:s.b;
}
class BKNChartView {
private:
 string m_prefix,m_status,m_selected,m_view_key,m_controls_key,m_visibility;
 BKNShape m_shapes[];
 bool m_enabled[18],m_collapsed,m_information,m_labels,m_focus,m_controls_ready,m_overview;
 int m_available[18],m_in_view[18];
 string m_feature_key;
 string m_layers[18],m_captions[18];
 string m_draw_ids[],m_draw_keys[];
 string m_owner_ids[],m_owner_ends[];
 string RenderKey(const BKNShape &s){
  string base=s.id+"|"+s.layer+"|"+s.group+"|"+s.kind+"|"+IntegerToString((long)s.a)+"|"+IntegerToString((long)s.b)+"|"+
   DoubleToString(s.pa,12)+"|"+DoubleToString(s.pb,12)+"|"+s.status+"|"+s.label+"|"+s.owner+"|"+IntegerToString((long)s.known)+"|"+IntegerToString((int)s.axis_review)+
   "|"+s.phase_id+"|"+s.pair_id+"|"+s.pair_state+"|"+IntegerToString((long)s.assessment_known)+"|"+DoubleToString(s.pair_score,2)+
   "|"+s.line_family+"|"+IntegerToString(s.line_construction_known)+"|"+IntegerToString(s.line_display_known)+"|"+IntegerToString(s.line_event_known)+
   "|"+s.line_display_unknown+"|"+s.line_event_kind+"|"+s.line_event_unknown+"|"+s.line_role+"|"+s.line_anchor_role+"|"+
   s.line_contract_id+"|"+s.line_contract_revision+"|"+s.line_contract_state+"|"+s.line_contract_reason+"|"+
   s.line_owner_relation+"|"+s.line_admission_mode+"|"+s.line_host_owner+"|"+IntegerToString((long)s.line_host_a)+"|"+IntegerToString((long)s.line_host_b)+"|"+
    IntegerToString((long)s.line_anchor_time)+"|"+DoubleToString(s.line_anchor_price,12)+
    "|"+s.line_provider+"|"+s.line_symbol+"|"+IntegerToString(s.line_seconds)+"|"+IntegerToString((long)s.line_state_known)+
    "|"+IntegerToString((long)s.line_a_time)+"@"+DoubleToString(s.line_a_price,12)+"|"+IntegerToString((long)s.line_b_time)+"@"+DoubleToString(s.line_b_price,12)+
    "|"+IntegerToString((long)s.line_c_time)+"@"+DoubleToString(s.line_c_price,12)+"|"+IntegerToString((long)s.line_d_time)+"@"+DoubleToString(s.line_d_price,12)+
    "|"+IntegerToString((long)s.line_e_time)+"@"+DoubleToString(s.line_e_price,12)+"|"+IntegerToString((long)s.line_f_time)+"@"+DoubleToString(s.line_f_price,12)+
    "|"+IntegerToString((long)s.line_q_time)+"@"+DoubleToString(s.line_q_price,12)+"|"+IntegerToString((long)s.line_display_first)+">"+IntegerToString((long)s.line_display_last)+
    "|"+IntegerToString((long)s.line_event_first)+">"+IntegerToString((long)s.line_event_break)+"|"+s.line_invalidation_reason+
    "|"+IntegerToString((int)s.line_geometry_valid)+"|"+IntegerToString((int)s.line_event_eligible)+"|"+IntegerToString((int)s.line_pair_eligible)+"|"+IntegerToString((int)s.line_duplicate);
  // PairInfo and ClockInfo contribute to the object tooltip. Their inputs
  // must invalidate the cached object even when its geometry is unchanged.
  return base+"|"+s.count_form+"|"+s.count_degree+"|"+IntegerToString((long)s.count_degree_known)+"|"+s.source_id+"|"+IntegerToString((long)s.owner_a)+"|"+IntegerToString((long)s.owner_b)+"|"+IntegerToString(s.owner_degree)+
   "|"+IntegerToString((int)s.pair_has_score)+"|"+IntegerToString((int)s.line_clocks_supported)+"|"+s.line_display_basis+
   "|"+s.construction_id+"|"+s.construction_revision+"|"+s.formation_input_revision+"|"+s.root_phase_id+"|"+s.previous_phase_id+"|"+s.event_id+"|"+IntegerToString((long)s.event_occurrence_known)+
   "|"+s.recovery_status+"|"+s.recovery_event_order+"|"+IntegerToString(s.recovery_c)+"|"+IntegerToString(s.recovery_d)+"|"+IntegerToString(s.recovery_e)+"|"+IntegerToString(s.recovery_f)+
   "|"+IntegerToString(s.recovery_observable)+"|"+IntegerToString(s.recovery_display_end)+"|"+IntegerToString(s.recovery_target_contact)+"|"+IntegerToString(s.recovery_source_contact)+"|"+IntegerToString(s.recovery_invalid);
 }
 string ScoreGrade(string layer,double score){return layer=="force"||layer=="breakout"?BKNForceGrade(score):score>=70?"strong":score>=50?"medium":"weak";}
 string ScoreCaption(const BKNShape &s){
  if(s.layer=="candlestick"||s.layer=="chart_pattern"){
   int separator=StringFind(s.label," | ");return separator>=0?StringSubstr(s.label,0,separator):s.label;
  }
  if(s.layer=="wave_count"){
   string form=(s.group=="book_wave_count_4"||s.group=="book_wave_count_C")?
    (s.count_form=="zigzag_535_candidate"?" · 535":s.count_form=="flat_335_candidate"?" · 335":
     s.count_form=="contracting_triangle_candidate"?" · 收敛":s.count_form=="expanding_triangle_candidate"?" · 扩张":""):"";
   return s.status=="wave1_predecessor_review"?"第一浪待选":
   "浪"+StringSubstr(s.group,StringLen("book_wave_count_"))+"?"+(s.status=="failed_fifth_candidate"?" · 失败5候选":
    s.status=="failed_fifth_or_internal_B_review"?"失败5/B待核":s.status=="wave5_recovery_review"?"5/B待核":
     s.status=="native_endpoint_developing"?" · 形成中":"")+form;
  }
  if(s.status=="source_inspection_only")return "完整来源 · 历史诊断";
  if(s.status=="finite_geometry_review")return s.layer=="trend"?"外侧构造 · 待核":s.layer=="channel"?"平行构造 · 待核":
   s.group=="book_CE_reference"?"C–E 源尺 · 待核":"D 平移线 · 待核";
  if(s.group=="book_CE_reference")return s.status=="independent_extension_observation"?"外延源线 · 待D":"独立外延 C–E";
  if(s.status=="correction_resumed_before_target")return "回调已恢复 · 旧目标结束";
  if(s.status=="stopped_before_price_contact")return "回调目标已触及";
  if(s.status=="historical_CE_D_construction")return s.axis_review?"D平移构造 · 斜率待核":"D平移构造";
  if(s.group=="book_channel_history")return s.axis_review?"通道构造 · 斜率待核":"历史通道 · 回看";
  if(s.axis_review)return s.layer=="channel"?"Q · 斜率待核":"外侧两点 · 斜率待核";
  if(s.layer=="channel"&&s.kind=="point")return "通道触点Q";
  if(!s.has_score)return s.group=="book_first_response"?"响应待核":(ShapeLayer(s)>=0?m_captions[ShapeLayer(s)]:s.layer);
  string value=DoubleToString(s.score,1)+"/100";
  if(s.layer=="force")return BKNGradeLabel(BKNForceGrade(s.score))+" "+value;
  if(s.layer=="channel")return "通道几何 "+value+(s.axis_review?" · 轴线待核":"");
  if(s.layer=="turning_point")return "拐点几何 "+value;
  if(s.layer=="breakout")return "边界响应 "+value;
  return value;
 }
 string PairInfo(const BKNShape &s){
  if(s.layer=="wave_count")return "\n数浪候选："+s.phase_id+"\n原生来源："+s.source_id+
   "\n本段端点可知："+TimeToString(s.leg_known,TIME_DATE|TIME_MINUTES)+
   "\n整组当前状态："+s.count_state+" · "+TimeToString(s.count_known,TIME_DATE|TIME_MINUTES)+
   (s.count_form!=""?"\n调整形态："+s.count_form+"\n层级核验："+s.count_degree+"\n形态可知："+(s.count_degree_known>0?TimeToString(s.count_degree_known,TIME_DATE|TIME_MINUTES):"待核"):"")+"\n来源绑定："+s.count_binding+"\n父计数："+s.previous_phase_id+"\n各分支独立计算；作者浪级与分支选择待核";
  if(s.phase_id=="")return "";
  string phase=StringFind(s.phase_id,"book_native_event_phase:")==0?"原生事件阶段（非作者浪级）：":"几何阶段：";
  string result=(s.owner_a>0?"\n所属波段："+TimeToString(s.owner_a,TIME_DATE|TIME_MINUTES)+" → "+TimeToString(s.owner_b,TIME_DATE|TIME_MINUTES)+"（原生归并层 "+IntegerToString(s.owner_degree)+"）":"")+"\n原生来源："+s.source_id+"\n"+phase+s.phase_id+"\n双线："+s.pair_state;
  if(s.pair_has_score)result+=" · 两线较弱分 "+DoubleToString(s.pair_score,2)+"/100";
  result+="\n配对："+s.pair_id+"\n观察可知："+TimeToString(s.assessment_known,TIME_DATE|TIME_MINUTES)+"；非入场许可";
  return result;
 }
 string ClockInfo(const BKNShape &s){
  if(!s.line_clocks_supported&&s.line_role=="")return "";
  string result="\n线族："+s.line_family+"\n统一角色："+s.line_role+" · 锚点："+s.line_anchor_role+
   "\n实际锚点："+(s.line_anchor_time>0?TimeToString(s.line_anchor_time,TIME_DATE|TIME_MINUTES):"未知")+" @ "+DoubleToString(s.line_anchor_price,_Digits)+
   "\n合同："+s.line_contract_state+" · 事件资格 "+(s.line_event_eligible?"是":"否")+" · Pair资格 "+(s.line_pair_eligible?"是":"否")+
   "\n合同依据："+s.line_contract_reason+"\n准入口径："+
   (s.line_admission_mode=="source_only_without_outer"?"外侧量尺未准入，仅源线诊断":
    s.line_admission_mode=="historical_inspection"?"历史诊断":"原生几何；事件与结构另核")+
   (s.line_owner_relation=="adjacent_context"?"\n相邻上下文构造；观察宿主："+TimeToString(s.line_host_a,TIME_DATE|TIME_MINUTES)+" → "+TimeToString(s.line_host_b,TIME_DATE|TIME_MINUTES):"");
  if(!s.line_clocks_supported)return result;
  return result+"\n构造可知："+TimeToString(s.line_construction_known,TIME_DATE|TIME_MINUTES)+
   "\n显示范围可知："+(s.line_display_known>0?TimeToString(s.line_display_known,TIME_DATE|TIME_MINUTES):"未知 · "+s.line_display_unknown)+" · "+s.line_display_basis+
   "\n事件可知："+(s.line_event_known>0?TimeToString(s.line_event_known,TIME_DATE|TIME_MINUTES):"未知 · "+s.line_event_unknown)+" · "+s.line_event_kind+
   (s.line_family=="RESUME_DF_C"?"\n终止事件发生柱收盘："+(s.event_occurrence_known>0?TimeToString(s.event_occurrence_known,TIME_DATE|TIME_MINUTES):"尚未观察到终止事件"):"")+
   "\n事件口径："+(s.status=="finite_geometry_review"?"有限构造待核；未评估事件":
    s.line_family=="RESUME_DF_C"?"恢复目标终端观察；非恢复确认":s.group=="book_channel_history"||s.status=="source_inspection_only"?"历史回看；未评估事件":"构造后原生冻结观察");
 }
 void SortKeys(string &ids[],string &keys[],int lo,int hi){
  int i=lo,j=hi;string pivot=ids[(lo+hi)/2];
  while(i<=j){
   while(StringCompare(ids[i],pivot)<0)i++;
   while(StringCompare(ids[j],pivot)>0)j--;
   if(i<=j){string v=ids[i];ids[i]=ids[j];ids[j]=v;v=keys[i];keys[i]=keys[j];keys[j]=v;i++;j--;}
  }
  if(lo<j)SortKeys(ids,keys,lo,j);if(i<hi)SortKeys(ids,keys,i,hi);
 }
 int KeyIndex(const string &ids[],string id){
  int lo=0,hi=ArraySize(ids)-1;
  while(lo<=hi){int mid=(lo+hi)/2,c=StringCompare(ids[mid],id);if(c==0)return mid;if(c<0)lo=mid+1;else hi=mid-1;}
  return -1;
 }
 int Layer(string layer){for(int i=0;i<18;i++)if(m_layers[i]==layer)return i;return -1;}
 int ShapeLayer(const BKNShape &s){
  // Chapter 4 source rail belongs to the independent extension-channel
  // control; its D-shift stays under the correction-target control. The
  // old OUTER->Q auxiliary rail is never substituted for this source.
  if(s.group=="book_CE_reference")return 7;
  if(s.layer=="turning_point"&&(s.line_clocks_supported?s.line_family=="RESUME_DF_C":s.group=="book_DF_C"))return 16;
  return Layer(s.layer);
 }
 bool Light(){color c=(color)ChartGetInteger(0,CHART_COLOR_BACKGROUND);return 299*(int)(c&255)+587*(int)((c>>8)&255)+114*(int)((c>>16)&255)>150000;}
 color TextColour(){return !AutomaticPanelColours?InformationTextColour:Light()?C'39,55,72':clrLightSteelBlue;}
 color CardColour(){return !AutomaticPanelColours?InformationBackgroundColour:Light()?C'242,246,250':C'10,25,38';}
 int Width(){return (int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS);}
 int Height(){return (int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS);}
 int Columns(){return (int)MathMax(1,MathMin(7,(Width()-24)/108));}
 bool NarrowPanel(){return Width()<430;}
 int LayerTop(){return NarrowPanel()?94:64;}
 int HeaderBottom(){return LayerTop()+((15+Columns()-1)/Columns())*26+30;}
 void Button(string id,string text,int x,int y,int w,int h,color background){
  string name=m_prefix+id;
  if(ObjectFind(0,name)<0)ObjectCreate(0,name,OBJ_BUTTON,0,0,0);
  ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);
  ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);ObjectSetInteger(0,name,OBJPROP_XSIZE,w);ObjectSetInteger(0,name,OBJPROP_YSIZE,h);
  ObjectSetInteger(0,name,OBJPROP_COLOR,clrWhite);ObjectSetInteger(0,name,OBJPROP_BGCOLOR,background);
  ObjectSetInteger(0,name,OBJPROP_ZORDER,2000);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
  ObjectSetInteger(0,name,OBJPROP_STATE,false);ObjectSetString(0,name,OBJPROP_TEXT,text);
 }
 void Label(string id,string text,int x,int y,int font,color colour){
  string name=m_prefix+id;if(ObjectFind(0,name)<0)ObjectCreate(0,name,OBJ_LABEL,0,0,0);
  ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
  ObjectSetInteger(0,name,OBJPROP_FONTSIZE,font);ObjectSetInteger(0,name,OBJPROP_COLOR,colour);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
  ObjectSetString(0,name,OBJPROP_TEXT,text);ObjectSetString(0,name,OBJPROP_TOOLTIP,text);
 }
 color GeometryColour(int layer){
  if(layer==0)return clrTomato;if(layer==3)return Light()?C'150,98,0':clrGold;
  if(layer==5)return clrLimeGreen;if(layer==6)return clrOrange;if(layer==7)return clrDeepSkyBlue;
  if(layer==8)return clrViolet;if(layer==9)return clrCoral;if(layer==10)return clrMediumSeaGreen;
  // Wave-count candidates are live native observations, but their author
  // wave-level assignment is still unresolved. Keep them visible without
  // presenting the provisional line as an active purple turning signal.
  if(layer==17)return Light()?C'70,86,115':C'190,205,225';
  if(layer==16)return clrDarkOrange;
  if(layer==12)return Light()?C'140,70,10':clrKhaki;
  if(layer==13)return Light()?C'110,70,160':clrMediumPurple;
  if(layer==14)return clrCoral;if(layer==15)return Light()?C'150,50,70':clrLightPink;
  return clrSlateGray;
 }
 bool Visible(const BKNShape &s){
  if(s.line_duplicate)return false;
  // A stamped line contract with invalid geometry stays in the native
  // receipt/sidecar for diagnosis, but it must never become a chart object.
  // Otherwise a clock-invalid or malformed endpoint can look like a real
  // trend/channel line while the contract already says it is unusable.
  if(s.line_role!=""&&!s.line_geometry_valid)return false;
   int l=ShapeLayer(s);if(l<0||!m_enabled[l])return false;
   if(BKNThreeBlueMode()&&(l!=5&&l!=7&&l!=8))return false;
  // Guided Q is an explicit actual contact, not a fabricated finite rail.
  // Keep that contact visible until a subsequent closed native bar permits
  // the forward fixed-equation segment. Legacy point policies are unchanged.
  if(BKNThreeBlueMode()&&l==7&&s.kind=="point"&&s.group!="book_CE_reference"&&s.line_family!="GUIDED_SHIFT")return false;
  // Source rulers and historical channel equations are evidence for the
  // construction audit, not additional live turning/channel signals. Keep
  // them available in the native export and behind an explicit input, but do
  // not let them pollute the active purple/blue scene by default.
  // Keep the owned blue channel visible by default. The reference switch controls only auxiliary source/history rails; hiding every channel here made the calculated channel layer disappear from MT5.
  if(!ShowTrendParallelReference&&(s.group=="book_channel_history"||s.group=="book_channel_review"||s.group=="book_outer_review"||s.group=="book_source_inspect_channel"))return false;
  if(s.group=="book_channel_history"&&!ShowBookConstructionReferences&&!ShowCompleteWaveGeometry)return false;
  // A valid enclosing construction is not erased by a quality-review flag.
  // Primary OUTER/CHANNEL geometry remains visible as a bounded dashed line;
  // only the separate finite review candidates stay hidden by default.
  // Otherwise every axis-drift case disappears from MT5 even though its
  // contacts and clocks are valid, which creates the false "missing lines"
  // impression. The Render path already marks admitted review geometry as
  // dashed and the contract keeps it unscored.
  if(s.status=="finite_geometry_review"&&!ShowUnqualifiedGeometryLive&&!ShowCompleteWaveGeometry)return false;
  return true;
 }
 bool ProjectionVisible(const BKNShape &s,datetime left){
  if(s.status=="source_inspection_only")return true; // still clipped to the visible native viewport
  // A finite correction/target observation can outlive its source A..B, but
  // an old historical construction must still obey the user's older-wave
  // filter. The old unconditional bypass made every prior purple CED line
  // survive in the current scene and look like a live projection.
  if(s.status=="historical_CE_D_construction"&&m_focus&&s.b<left)return false;
  if((s.group=="book_CE_D"||s.group=="book_DF_C")&&s.b>=left)return true;
  if(!m_focus||s.a>=left||(s.layer!="channel"&&s.layer!="turning_point"))return true;
  int p=KeyIndex(m_owner_ids,s.owner);
  // The whole-wave OUTER stops at its owned B. A much older owner's
  // projected rail is optional context, not the visible wave's channel.
  // Its stored geometry is untouched and is restored when that wave enters
  // the viewport or the user requests all older projections.
  return p<0||(datetime)StringToInteger(m_owner_ends[p])>=left;
 }
 void DetailCard(){
  ObjectsDeleteAll(0,m_prefix+"detail_");
  if(m_collapsed||!m_information||Width()<300||Height()<250)return;
  int selected=-1;for(int i=0;i<ArraySize(m_shapes);i++)if(m_shapes[i].id==m_selected){selected=i;break;}
  if(selected<0&&!m_overview)return;
  BKNShape s;ZeroMemory(s);if(selected>=0)s=m_shapes[selected];int w=(int)MathMax(220,MathMin(InformationCardWidth,Width()-28));
  int x=Width()-w-14,y=Width()<1100?HeaderBottom()+48:34;
  int font=(int)MathMax(7,MathMin(16,InformationFontSize)),line=font+11;
  string rows[14];int count=7,slot=ShapeLayer(s);rows[0]=(slot>=0?m_captions[slot]:s.layer)+" · "+s.status;
  rows[1]=s.has_score?ScoreCaption(s):"此项没有可用评分";
  rows[2]="起点 "+TimeToString(s.a,TIME_DATE|TIME_MINUTES)+"  "+DoubleToString(s.pa,_Digits);
  rows[3]="终点 "+TimeToString(s.b,TIME_DATE|TIME_MINUTES)+"  "+DoubleToString(s.pb,_Digits);
  rows[4]="当前记录可知 "+TimeToString(s.known,TIME_DATE|TIME_MINUTES);
  rows[5]="原生周期 "+EnumToString(_Period)+" · 图表品种 "+_Symbol;
  rows[6]="完整依据保留在对应线段的悬停文字";
  if(s.line_clocks_supported){
   count=9;rows[4]="构造可知 "+TimeToString(s.line_construction_known,TIME_DATE|TIME_MINUTES);
   rows[5]="显示可知 "+(s.line_display_known>0?TimeToString(s.line_display_known,TIME_DATE|TIME_MINUTES):"未知 · "+s.line_display_unknown);
   rows[6]="事件可知 "+(s.line_event_known>0?TimeToString(s.line_event_known,TIME_DATE|TIME_MINUTES):"未知 · "+s.line_event_unknown);
   rows[7]="原生周期 "+EnumToString(_Period)+" · "+s.line_family;rows[8]="完整事件类型及来源见线段悬停依据";
  }
  if(m_overview){
   int layers[9]={9,10,11,12,13,14,15,16,17};count=14;
   rows[0]="栏目状态 · 本窗口 / 已计算图形记录";
   for(int j=0;j<9;j++){
    int l=layers[j];rows[j+1]=m_captions[l]+"："+IntegerToString(m_in_view[l])+" / "+IntegerToString(m_available[l])+" · "+(m_enabled[l]?"开启":"关闭");
   }
   rows[10]="0 = 当前数据未观察到；可移动历史视窗";
   rows[11]="形态仅候选；计数不等于作者浪级已确认";
   rows[12]="完整计划/父级背景卡：尚未完整迁入";
   rows[13]="复杂4浪/扩延/ABC：独立候选，浪级待核";
  }
  if(y+line*count+14>Height())return;
  string box=m_prefix+"detail_box";ObjectCreate(0,box,OBJ_RECTANGLE_LABEL,0,0,0);
  ObjectSetInteger(0,box,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,box,OBJPROP_YDISTANCE,y);
  ObjectSetInteger(0,box,OBJPROP_XSIZE,w);ObjectSetInteger(0,box,OBJPROP_YSIZE,line*count+14);
  ObjectSetInteger(0,box,OBJPROP_BGCOLOR,CardColour());ObjectSetInteger(0,box,OBJPROP_COLOR,clrSlateGray);
  ObjectSetInteger(0,box,OBJPROP_BACK,false);ObjectSetInteger(0,box,OBJPROP_SELECTABLE,false);
  for(int i=0;i<count;i++)Label("detail_"+IntegerToString(i),rows[i],x+8,y+6+i*line,font,TextColour());
 }
 void Controls(){
  // A price-axis/viewport redraw is not a toolbar edit. Rewriting all button
  // properties here used to flood the chart queue on every tick and scroll.
  string controls_key=IntegerToString(Width())+"|"+IntegerToString(Height())+"|"+
   IntegerToString((int)m_collapsed)+IntegerToString((int)m_information)+IntegerToString((int)m_labels)+IntegerToString((int)m_focus)+IntegerToString((int)m_overview)+"|"+m_selected+"|"+IntegerToString((int)Light())+"|"+m_feature_key;
  for(int i=0;i<18;i++)controls_key+=IntegerToString((int)m_enabled[i]);
  if(m_controls_ready&&controls_key==m_controls_key)return;
  m_controls_key=controls_key;
  m_controls_ready=true;
   if(BKNThreeBlueMode()){
    // The simplified build exposes only the three blue line-family switches.
    // Remove every legacy toolbar object so an old chart instance cannot leave
    // grey controls active after recompilation or parameter changes.
    ObjectsDeleteAll(0,m_prefix+"toggle_");ObjectDelete(0,m_prefix+"arrow");ObjectDelete(0,m_prefix+"info");ObjectDelete(0,m_prefix+"focus");
    ObjectDelete(0,m_prefix+"labels");ObjectDelete(0,m_prefix+"overview");ObjectDelete(0,m_prefix+"status");ObjectDelete(0,m_prefix+"identity");
    ObjectsDeleteAll(0,m_prefix+"detail_");
    int blue_layers[3]={5,7,8};int columns=(int)MathMax(1,MathMin(3,(Width()-24)/108));
    for(int slot=0;slot<3;slot++){
     int layer=blue_layers[slot];Button("toggle_"+IntegerToString(layer),(m_enabled[layer]?"隐藏":"显示")+m_captions[layer],
      12+(slot%columns)*108,30+(slot/columns)*26,104,24,m_enabled[layer]?clrDarkSlateBlue:clrDimGray);
     ObjectSetString(0,m_prefix+"toggle_"+IntegerToString(layer),OBJPROP_TOOLTIP,m_captions[layer]+" · 本窗口 "+IntegerToString(m_in_view[layer])+" / 已计算 "+IntegerToString(m_available[layer])+" 个图形记录。点此"+(m_enabled[layer]?"隐藏":"显示"));
    }
    GuidedStatus();
    return;
   }
  Button("arrow",m_collapsed?">":"<",2,30,24,20,clrDarkSlateBlue);
  // Delete every other control when collapsed. OBJPROP_HIDDEN only affects
  // the object list and cannot serve as chart visibility.
  if(m_collapsed){
   ObjectsDeleteAll(0,m_prefix+"toggle_");ObjectDelete(0,m_prefix+"info");ObjectDelete(0,m_prefix+"focus");
   ObjectDelete(0,m_prefix+"labels");ObjectDelete(0,m_prefix+"overview");ObjectDelete(0,m_prefix+"status");ObjectDelete(0,m_prefix+"identity");
   ObjectsDeleteAll(0,m_prefix+"detail_");return;
  }
  int columns=Columns();
  int header_width=(int)MathMax(120,Width()-46);
  if(NarrowPanel()){
   Button("info",m_information?"隐藏全部文字面板":"显示全部文字面板",34,28,header_width,24,clrDarkGreen);
   Button("focus",m_focus?"显示较早波段延伸":"隐藏较早波段延伸",34,56,header_width,24,clrDarkSlateBlue);
  }else{
   Button("info",m_information?"隐藏全部文字面板":"显示全部文字面板",34,28,210,28,clrDarkGreen);
   Button("focus",m_focus?"显示较早波段延伸":"隐藏较早波段延伸",252,28,170,28,clrDarkSlateBlue);
  }
  int layers[15]={3,5,6,17,7,8,16,9,10,11,12,13,14,15,0};
  for(int slot=0;slot<15;slot++){
   int layer=layers[slot];Button("toggle_"+IntegerToString(layer),(m_enabled[layer]?"隐藏":"显示")+m_captions[layer],
    12+(slot%columns)*108,LayerTop()+(slot/columns)*26,104,24,m_enabled[layer]?clrDarkSlateBlue:clrDimGray);
   ObjectSetString(0,m_prefix+"toggle_"+IntegerToString(layer),OBJPROP_TOOLTIP,m_captions[layer]+" · 本窗口 "+IntegerToString(m_in_view[layer])+" / 已计算 "+IntegerToString(m_available[layer])+" 个图形记录。0表示当前数据未观察到，非加载中；点此"+(m_enabled[layer]?"隐藏":"显示"));
  }
  Button("labels",m_labels?"隐藏结构文字":"显示结构文字",12,LayerTop()+((15+columns-1)/columns)*26,170,26,clrDarkSlateBlue);
  if(Width()>=360)Button("overview",m_overview?"隐藏栏目状态":"查看栏目状态",190,LayerTop()+((15+columns-1)/columns)*26,150,26,clrDarkSlateBlue);
  else ObjectDelete(0,m_prefix+"overview");
  if(m_information){
   Label("status",m_status+" · "+m_visibility,12,HeaderBottom()+4,9,TextColour());
   Label("identity","Book 原生实时指标 · 当前图表周期",12,HeaderBottom()+23,9,TextColour());
  }else {ObjectDelete(0,m_prefix+"status");ObjectDelete(0,m_prefix+"identity");}
  DetailCard();
 }
public:
 BKNChartView(){
  m_prefix="";m_collapsed=false;m_information=ShowInformationPanels;m_labels=ShowLabels;m_focus=!ShowOlderWaveProjections;m_controls_ready=false;m_overview=false;m_feature_key="";
  string names[18]={"zigzag","one_to_one","three_push","force","ict","trend","wave","channel","turning_point","breakout","pullback","invalidation","candlestick","chart_pattern","stop_reference","risk_fact","resume_target","wave_count"};
  string captions[18]={"ZigZag","","","力度","","通道源线","波段","通道平移","独立拐点","突破","回调","失效","K线形态","图表形态","止损参考","风险事实","恢复目标","波浪计数"};
  for(int i=0;i<18;i++){m_layers[i]=names[i];m_captions[i]=captions[i];m_enabled[i]=false;m_available[i]=0;m_in_view[i]=0;}
   if(BKNThreeBlueMode()){
    m_enabled[5]=ShowGuidedChannelSource;m_enabled[7]=ShowGuidedChannelShift;m_enabled[8]=ShowGuidedTurning;
   }else{
    m_enabled[0]=ShowZigzag;m_enabled[3]=ShowForce;m_enabled[5]=ShowGuidedChannelSource;m_enabled[6]=ShowBookWave;
    m_enabled[7]=ShowGuidedChannelShift;m_enabled[8]=ShowGuidedTurning;m_enabled[9]=ShowBookBreakout;m_enabled[10]=ShowBookPullback;
    m_enabled[11]=ShowBookInvalidation;m_enabled[12]=ShowBookCandlestick;m_enabled[13]=ShowBookChartPattern;
    m_enabled[14]=ShowBookStopReference;m_enabled[15]=ShowBookRiskFact;
    m_enabled[16]=ShowBookRecoveryTarget;
    m_enabled[17]=ShowBookWaveCount;
   }
 }
 void Init(bool reclaim_single_book=false){
  Destroy();ArrayResize(m_shapes,0);ArrayResize(m_draw_ids,0);ArrayResize(m_draw_keys,0);
  m_selected="";m_status="";m_visibility="";m_view_key="";m_controls_ready=false;
  string chart_prefix="BKN_"+IntegerToString(ChartID())+"_";
  // A single production Book may reclaim its own chart-scoped stale output
  // after recompile/reinitialization. Never sweep another chart or a chart
  // containing several indicators, and never match user objects by colour.
  if(reclaim_single_book&&ChartIndicatorsTotal(0,0)<=1)ObjectsDeleteAll(0,chart_prefix);
  m_prefix=chart_prefix+IntegerToString((long)GetMicrosecondCount())+"_";
 }
 // Deinitialization normally removes only this instance's micro-prefix.
 // When the Book indicator itself is removed or reloaded, reclaim the chart
 // scope too, but only while it is the sole indicator on the chart. This
 // prevents old random-prefix blue/purple rails from surviving a reload and
 // being mistaken for the current wave owner, without touching other
 // indicators or user-drawn objects.
 void Destroy(bool reclaim_chart=false){
  if(m_prefix!="")ObjectsDeleteAll(0,m_prefix);
  if(reclaim_chart&&ChartIndicatorsTotal(0,0)<=1){
   string chart_prefix="BKN_"+IntegerToString(ChartID())+"_";
   ObjectsDeleteAll(0,chart_prefix);
  }
  m_controls_ready=false;
 }
 void GuidedStatus(){
  int columns=(int)MathMax(1,MathMin(3,(Width()-24)/108));
  ObjectDelete(0,m_prefix+"status");
  int top=30+((3+columns-1)/columns)*26;
  Label("guided_status","Book1.302 · "+m_status,12,top,10,TextColour());
  Label("guided_visibility",m_visibility+" · 波段归属待核",12,top+18,9,TextColour());
 }
 void Status(string text){
  if(text==m_status&&m_controls_ready)return;
  m_status=text;if(Width()<=0||Height()<=0)return;
  if(BKNThreeBlueMode()){if(!m_controls_ready)Controls();else GuidedStatus();return;}
  if(!m_controls_ready)Controls();
  else if(!m_collapsed&&m_information)Label("status",m_status+" · "+m_visibility,12,HeaderBottom()+4,9,TextColour());
 }
 void Apply(const BKNShape &shapes[]){
  // Keep only this instance's objects. Never remove another indicator or a
  // user drawing simply because its colour or name resembles Book geometry.
  string ids[],keys[];ArrayResize(ids,ArraySize(shapes));ArrayResize(keys,ArraySize(shapes));
  for(int i=0;i<ArraySize(shapes);i++){ids[i]=shapes[i].id;keys[i]="";}
  if(ArraySize(ids)>1)SortKeys(ids,keys,0,ArraySize(ids)-1);
  for(int i=0;i<ArraySize(m_shapes);i++)
   if(KeyIndex(ids,m_shapes[i].id)<0){ObjectDelete(0,m_prefix+"g_"+m_shapes[i].id);ObjectDelete(0,m_prefix+"t_"+m_shapes[i].id);ObjectDelete(0,m_prefix+"v_"+m_shapes[i].id);}
  ArrayResize(m_shapes,ArraySize(shapes));for(int i=0;i<ArraySize(shapes);i++)m_shapes[i]=shapes[i];
  ArrayResize(m_owner_ids,0);ArrayResize(m_owner_ends,0);int owners=0;
  for(int i=0;i<ArraySize(shapes);i++)if(shapes[i].layer=="trend"&&shapes[i].group=="book_owned_axis"){
   ArrayResize(m_owner_ids,owners+1,256);ArrayResize(m_owner_ends,owners+1,256);
   m_owner_ids[owners]=shapes[i].owner;m_owner_ends[owners++]=IntegerToString((long)BKNGeometryOwnerEnd(shapes[i]));
  }
  if(owners>1)SortKeys(m_owner_ids,m_owner_ends,0,owners-1);
  int unique=0;
  for(int i=0;i<owners;i++){
   if(unique>0&&m_owner_ids[i]==m_owner_ids[unique-1]){
    if(StringToInteger(m_owner_ends[i])>StringToInteger(m_owner_ends[unique-1]))m_owner_ends[unique-1]=m_owner_ends[i];
   }else{m_owner_ids[unique]=m_owner_ids[i];m_owner_ends[unique++]=m_owner_ends[i];}
  }
  ArrayResize(m_owner_ids,unique);ArrayResize(m_owner_ends,unique);
  if(m_selected!="")m_controls_key=""; // refresh the selected record's facts
  Render();
 }
 void Clear(){
  ArrayResize(m_shapes,0);m_selected="";ObjectsDeleteAll(0,m_prefix+"g_");ObjectsDeleteAll(0,m_prefix+"t_");ObjectsDeleteAll(0,m_prefix+"v_");Controls();
  ArrayResize(m_draw_ids,0);ArrayResize(m_draw_keys,0);
 }
 string ViewKey(){
  return IntegerToString(Width())+"|"+IntegerToString(Height())+"|"+
   IntegerToString(ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR))+"|"+IntegerToString(ChartGetInteger(0,CHART_VISIBLE_BARS))+"|"+
   DoubleToString(ChartGetDouble(0,CHART_PRICE_MIN),_Digits)+"|"+DoubleToString(ChartGetDouble(0,CHART_PRICE_MAX),_Digits);
 }
 void RenderIfChanged(){if(ViewKey()!=m_view_key)Render();}
 int ExportNativeCoordinates(string file){
  int f=FileOpen(file,FILE_WRITE|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);if(f==INVALID_HANDLE)return -1;
  int contract_file=FileOpen(file+".line_contracts.tsv",FILE_WRITE|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);
  if(contract_file!=INVALID_HANDLE)FileWrite(contract_file,"id","line_contract");
  // Append clock/source evidence after the existing columns. This remains a
  // receipt for drawn objects only, not the full computed source inventory.
   FileWrite(f,"id","layer","owner","expected_a","expected_pa","expected_b","expected_pb","actual_a","actual_pa","actual_b","actual_pb","score_known","score","x1","y1","x2","y2","pixels_mappable","group","status","label","axis_review","kind","native_type","owner_a","owner_b","owner_known","owner_degree","display_basis","construction_id","construction_revision","root_phase_id","previous_phase_id","event_id","event_occurrence_known","recovery_status","recovery_event_order","recovery_c","recovery_d","recovery_e","recovery_f","recovery_observable","recovery_display_end","recovery_target_contact","recovery_source_contact","recovery_invalid","source_id","line_family","line_clocks_supported","line_construction_known","line_display_known","line_display_unknown","line_event_known","line_event_unknown","line_event_kind","assessment_known","count_state","count_known","leg_known","source_known","count_retrospective","count_binding","axis_evidence");
  int tail_file=FileOpen(file+".turning_display.tsv",FILE_WRITE|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);
  if(tail_file!=INVALID_HANDLE)FileWrite(tail_file,"id","contact_a","contact_b","owner_b","extension_a","extension_pa","extension_b","extension_pb","extension_style","errors");
  int errors=0;
  for(int i=0;i<ArraySize(m_shapes);i++){
   BKNShape s=m_shapes[i];if(KeyIndex(m_draw_ids,s.id)<0)continue;
   string name=m_prefix+"g_"+s.id;
   bool split_purple=s.line_family=="GUIDED_TURNING"&&s.line_b_time>s.a&&s.line_b_time<s.b;
   datetime solid_b=split_purple?s.line_b_time:s.b;double solid_pb=split_purple?s.line_b_price:s.pb;
   if(split_purple){
    string extension=m_prefix+"v_"+s.id;int tail_errors=0;
    long ea=ObjectGetInteger(0,extension,OBJPROP_TIME,0),eb=ObjectGetInteger(0,extension,OBJPROP_TIME,1);
    double epa=ObjectGetDouble(0,extension,OBJPROP_PRICE,0),epb=ObjectGetDouble(0,extension,OBJPROP_PRICE,1);
    long style=ObjectGetInteger(0,extension,OBJPROP_STYLE);
    if(ObjectFind(0,extension)<0||ea!=(long)solid_b||eb!=(long)s.b||MathAbs(epa-solid_pb)>1e-8||MathAbs(epb-s.pb)>1e-8||style!=STYLE_DASH)tail_errors++;
    if(s.line_b_time>=s.owner_b)tail_errors++;
    errors+=tail_errors;
    if(tail_file!=INVALID_HANDLE)FileWrite(tail_file,s.id,(long)s.line_a_time,(long)s.line_b_time,(long)s.owner_b,ea,DoubleToString(epa,12),eb,DoubleToString(epb,12),style,tail_errors);
   }
   long a=ObjectGetInteger(0,name,OBJPROP_TIME,0),b=ObjectGetInteger(0,name,OBJPROP_TIME,1);
   double pa=ObjectGetDouble(0,name,OBJPROP_PRICE,0),pb=ObjectGetDouble(0,name,OBJPROP_PRICE,1);
   long native_type=ObjectGetInteger(0,name,OBJPROP_TYPE);
   // MT5 arrow objects have one actual coordinate. Report the same measured
   // coordinate twice for the existing segment audit, never an invented end.
   if(s.kind=="point"){b=a;pb=pa;if(native_type!=OBJ_ARROW)errors++;}
   int x1=0,y1=0,x2=0,y2=0;bool mapped=ChartTimePriceToXY(0,0,(datetime)a,pa,x1,y1)&&ChartTimePriceToXY(0,0,(datetime)b,pb,x2,y2);
   if(a!=(long)s.a||b!=(long)solid_b||MathAbs(pa-s.pa)>0.00000001||MathAbs(pb-solid_pb)>0.00000001)errors++;
    FileWrite(f,s.id,s.layer,s.owner,(long)s.a,DoubleToString(s.pa,12),(long)solid_b,DoubleToString(solid_pb,12),a,DoubleToString(pa,12),b,DoubleToString(pb,12),s.has_score,(s.has_score?DoubleToString(s.score,3):""),x1,y1,x2,y2,mapped,s.group,s.status,s.label,s.axis_review,s.kind,native_type,(long)s.owner_a,(long)s.owner_b,(long)s.owner_known,s.owner_degree,s.line_display_basis,s.construction_id,s.construction_revision,s.root_phase_id,s.previous_phase_id,s.event_id,(long)s.event_occurrence_known,s.recovery_status,s.recovery_event_order,s.recovery_c,s.recovery_d,s.recovery_e,s.recovery_f,s.recovery_observable,s.recovery_display_end,s.recovery_target_contact,s.recovery_source_contact,s.recovery_invalid,s.source_id,s.line_family,s.line_clocks_supported,(long)s.line_construction_known,(long)s.line_display_known,s.line_display_unknown,(long)s.line_event_known,s.line_event_unknown,s.line_event_kind,(long)s.assessment_known,s.count_state,(long)s.count_known,(long)s.leg_known,(long)s.source_known,s.count_retrospective,s.count_binding,s.axis_evidence);
   if(contract_file!=INVALID_HANDLE)FileWrite(contract_file,s.id,BKNLineContractSummary(s));
  }
  if(contract_file!=INVALID_HANDLE)for(int i=0;i<ArraySize(m_shapes);i++){
   BKNShape s=m_shapes[i];if(s.line_role==""||KeyIndex(m_draw_ids,s.id)>=0)continue;
   FileWrite(contract_file,s.id,BKNLineContractSummary(s));
  }
  FileClose(f);if(tail_file!=INVALID_HANDLE)FileClose(tail_file);if(contract_file!=INVALID_HANDLE)FileClose(contract_file);return errors;
 }
 void Render(){
  if(m_prefix==""||Width()<=0||Height()<=0)return;
  int first_bar=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR),visible_bars=(int)ChartGetInteger(0,CHART_VISIBLE_BARS);
  datetime left=iTime(_Symbol,_Period,first_bar),right=iTime(_Symbol,_Period,(int)MathMax(0,first_bar-visible_bars+1));
  for(int l=0;l<18;l++){m_available[l]=0;m_in_view[l]=0;}
  for(int i=0;i<ArraySize(m_shapes);i++){
   if(m_shapes[i].line_duplicate)continue;
   if(m_shapes[i].line_role!=""&&!m_shapes[i].line_geometry_valid)continue;
   int l=ShapeLayer(m_shapes[i]);if(l<0)continue;m_available[l]++;
   if(m_shapes[i].b>=left&&m_shapes[i].a<=right)m_in_view[l]++;
  }
  m_feature_key="";for(int l=0;l<18;l++)m_feature_key+=IntegerToString(m_available[l])+":"+IntegerToString(m_in_view[l])+"|";
  bool eligible[],wave_eligible[];ArrayResize(eligible,ArraySize(m_shapes));ArrayResize(wave_eligible,ArraySize(m_shapes));
  for(int i=0;i<ArraySize(m_shapes);i++){
   bool shown=m_labels&&Visible(m_shapes[i])&&ProjectionVisible(m_shapes[i],left);
   eligible[i]=shown&&m_shapes[i].layer!="wave_count";wave_eligible[i]=shown&&m_shapes[i].layer=="wave_count";
  }
  // Wave ordinals get first placement and their own budget. Other families
  // retain their existing independent quota and calculations.
  int captions[],other_captions[];BKNChooseLabels(m_shapes,wave_eligible,left,right,m_selected,MaximumVisibleWaveLabels,captions);
  BKNChooseLabels(m_shapes,eligible,left,right,m_selected,MaximumVisibleLabels,other_captions);
  int wave_captions=ArraySize(captions);ArrayResize(captions,wave_captions+ArraySize(other_captions));
  for(int k=0;k<ArraySize(other_captions);k++)captions[wave_captions+k]=other_captions[k];
  string next_ids[],next_keys[];int drawn=0,outer_count=0,channel_count=0,turn_count=0,review_count=0,wave_count=0;
  for(int i=0;i<ArraySize(m_shapes);i++){
   BKNShape s=m_shapes[i];string name=m_prefix+"g_"+s.id,text=m_prefix+"t_"+s.id;int layer=ShapeLayer(s);
   // Keep the complete scene in memory, but submit only viewport-intersecting
   // geometry to MT5. A scroll calls Render and restores the relevant objects.
   // Otherwise every timer slice synchronously queried thousands of offscreen
   // objects, delaying visible paint despite native calculation being ready.
   if(!Visible(s)||!ProjectionVisible(s,left)||s.b<left||s.a>right){
    if(KeyIndex(m_draw_ids,s.id)>=0){ObjectDelete(0,name);ObjectDelete(0,text);ObjectDelete(0,m_prefix+"v_"+s.id);}
    continue;
   }
   bool split_purple=s.line_family=="GUIDED_TURNING"&&s.line_b_time>s.a&&s.line_b_time<s.b;
   datetime solid_b=split_purple?s.line_b_time:s.b;double solid_pb=split_purple?s.line_b_price:s.pb;
   string extension=m_prefix+"v_"+s.id;
   if(split_purple){
    if(ObjectFind(0,extension)<0)ObjectCreate(0,extension,OBJ_TREND,0,solid_b,solid_pb,s.b,s.pb);
    ObjectSetInteger(0,extension,OBJPROP_TIME,0,solid_b);ObjectSetDouble(0,extension,OBJPROP_PRICE,0,solid_pb);
    ObjectSetInteger(0,extension,OBJPROP_TIME,1,s.b);ObjectSetDouble(0,extension,OBJPROP_PRICE,1,s.pb);
    ObjectSetInteger(0,extension,OBJPROP_COLOR,GeometryColour(layer));ObjectSetInteger(0,extension,OBJPROP_WIDTH,1);
    ObjectSetInteger(0,extension,OBJPROP_STYLE,STYLE_DASH);ObjectSetInteger(0,extension,OBJPROP_RAY_LEFT,false);
    ObjectSetInteger(0,extension,OBJPROP_RAY_RIGHT,false);ObjectSetInteger(0,extension,OBJPROP_SELECTABLE,true);
    ObjectSetString(0,extension,OBJPROP_TOOLTIP,"固定方程观察延伸：不是新接点，不重画原线\n"+s.label);
   }else ObjectDelete(0,extension);
   ENUM_OBJECT type=s.kind=="point"?OBJ_ARROW:s.kind=="box"||s.kind=="band"?OBJ_RECTANGLE:OBJ_TREND;
   string key=RenderKey(s);int old=KeyIndex(m_draw_ids,s.id);bool exists=ObjectFind(0,name)>=0;
   if(exists&&(ENUM_OBJECT)ObjectGetInteger(0,name,OBJPROP_TYPE)!=type){ObjectDelete(0,name);exists=false;}
   if(!exists)ObjectCreate(0,name,type,0,s.a,s.pa,solid_b,solid_pb);
   // Stable closed geometry receives no repeated object writes on toolbar
   // clicks, price-scale changes or a result whose candles are unchanged.
   if(!exists||old<0||m_draw_keys[old]!=key){
   ObjectSetInteger(0,name,OBJPROP_TIME,0,s.a);ObjectSetDouble(0,name,OBJPROP_PRICE,0,s.pa);
   if(s.kind!="point"){ObjectSetInteger(0,name,OBJPROP_TIME,1,solid_b);ObjectSetDouble(0,name,OBJPROP_PRICE,1,solid_pb);}
   else{ObjectSetInteger(0,name,OBJPROP_ARROWCODE,159);ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_CENTER);}
   bool reference=s.axis_review||s.group=="book_CE_reference"||s.group=="book_channel_history"||s.status=="source_inspection_only"||s.status=="historical_CE_D_construction"||(s.status=="stopped_before_price_contact"||s.status=="correction_resumed_before_target")||s.layer=="wave_count";
   color line_colour=GeometryColour(layer);
   // Keep finite D-shift constructions auditable without presenting them as
   // the live purple ruler. The confirmed projection remains violet; the
   // historical D-to-E construction is a neutral dashed reference.
   if(s.status=="stopped_before_price_contact"||s.status=="correction_resumed_before_target")line_colour=Light()?C'118,128,142':C'126,145,160';
   ObjectSetInteger(0,name,OBJPROP_COLOR,line_colour);ObjectSetInteger(0,name,OBJPROP_WIDTH,reference?1:(int)MathMax(1,MathMin(5,layer==3?ForceLineWidth:GeometryLineWidth)));
   ObjectSetInteger(0,name,OBJPROP_STYLE,reference?STYLE_DASH:STYLE_SOLID);
   ObjectSetInteger(0,name,OBJPROP_RAY_LEFT,false);ObjectSetInteger(0,name,OBJPROP_RAY_RIGHT,false);
   ObjectSetInteger(0,name,OBJPROP_BACK,false);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,true);ObjectSetInteger(0,name,OBJPROP_FILL,false);
   ObjectSetString(0,name,OBJPROP_TOOLTIP,s.label+"\n来源："+s.owner+"\n当前记录可知："+TimeToString(s.known,TIME_DATE|TIME_MINUTES)+ClockInfo(s)+PairInfo(s));
   }
   ArrayResize(next_ids,drawn+1,256);ArrayResize(next_keys,drawn+1,256);next_ids[drawn]=s.id;next_keys[drawn++]=key;
   if(s.layer=="trend")outer_count++;
   if(layer==7)channel_count++;
   if(layer==8||layer==16)turn_count++;
   if(s.layer=="wave_count"&&s.kind=="point")wave_count++;
   if(s.axis_review)review_count++;
   bool caption=false;for(int j=0;j<ArraySize(captions);j++)if(captions[j]==i){caption=true;break;}
   if(!caption)ObjectDelete(0,text);
  }
  BKNLabelPlacement occupied[];
  for(int j=0;j<ArraySize(captions);j++){
   BKNShape s=m_shapes[captions[j]];string text=m_prefix+"t_"+s.id;int layer=ShapeLayer(s),x,y;
   datetime at=s.b;double price=s.pb;
   // An endpoint outside the visible range is projected by native bar ordinal,
   // never by elapsed seconds across a weekend/session gap.
   if(at>right){
    at=right;int a=iBarShift(_Symbol,_Period,s.a,true),b=iBarShift(_Symbol,_Period,s.b,true),p=iBarShift(_Symbol,_Period,at,true);
    if(a<0||b<0||p<0||a==b){ObjectDelete(0,text);continue;}
    price=s.pa+(s.pb-s.pa)*(a-p)/(double)(a-b);
   }
   if(!ChartTimePriceToXY(0,0,at,price,x,y)){ObjectDelete(0,text);continue;}
   string caption=ScoreCaption(s);int font=(int)MathMax(8,MathMin(16,StructureFontSize)),line_height=font+10;
   int label_width=(int)MathMin(280,MathMax(80,StringLen(caption)*(font+1)+8));
   BKNLabelPlacement place=BKNPlaceLabel(x+6,y-line_height,label_width,line_height,Width(),Height(),m_collapsed?24:HeaderBottom()+40,occupied);
   if(!place.placed){ObjectDelete(0,text);continue;}
   int count=ArraySize(occupied);ArrayResize(occupied,count+1);occupied[count]=place;
   color label_colour=GeometryColour(layer);
   // Historical C-E constructions and stopped projections are retained as
   // auditable context, but must not look like the live purple projection.
   if(s.status=="stopped_before_price_contact"||s.status=="correction_resumed_before_target")
      label_colour=Light()?C'118,128,142':C'126,145,160';
   Label("t_"+s.id,caption,place.x,place.y,font,label_colour);
   ObjectSetString(0,text,OBJPROP_TOOLTIP,s.label+ClockInfo(s)+PairInfo(s));
  }
  if(drawn>1)SortKeys(next_ids,next_keys,0,drawn-1);
  ArrayResize(m_draw_ids,drawn);ArrayResize(m_draw_keys,drawn);
  if(drawn>0){ArrayCopy(m_draw_ids,next_ids);ArrayCopy(m_draw_keys,next_keys);}
  string visibility="本视窗：源线 "+IntegerToString(outer_count)+" · 平移 "+IntegerToString(channel_count)+" · 独立拐点 "+IntegerToString(turn_count);
  if(wave_count>0)visibility+=" · 数浪标记 "+IntegerToString(wave_count);
  if(review_count>0)visibility+=" · 虚线待核 "+IntegerToString(review_count);
  if(m_visibility!=visibility){m_visibility=visibility;m_controls_key="";}
  Controls();m_view_key=ViewKey();ChartRedraw(0);
 }
 bool Event(const int id,const string name){
  if(id!=CHARTEVENT_OBJECT_CLICK||StringFind(name,m_prefix)!=0)return false;
  string key=StringSubstr(name,StringLen(m_prefix));
  if(key=="arrow")m_collapsed=!m_collapsed;
  else if(key=="info")m_information=!m_information;
  else if(key=="labels")m_labels=!m_labels;
  else if(key=="overview"){m_overview=!m_overview;if(m_overview){m_information=true;m_selected="";}}
  else if(key=="focus")m_focus=!m_focus;
  else if(StringFind(key,"toggle_")==0){int layer=(int)StringToInteger(StringSubstr(key,7));if(layer>=0&&layer<18)m_enabled[layer]=!m_enabled[layer];}
  else if(StringFind(key,"g_")==0||StringFind(key,"t_")==0){m_selected=StringSubstr(key,2);m_overview=false;}
  else return false;
  Render();return true;
 }
};
#endif
