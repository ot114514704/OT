#ifndef BOOK_GUIDED_SCOPE_PHASES
#define BOOK_GUIDED_SCOPE_PHASES
#include "BookGuidedTurningLife.mqh"
#include "BookNativeSource.mqh"
// Engineering decomposition of a supplied composite range, not author's
// wave degree. Only confirmed native child legs known at the parent clock
// are inspected. Later opposite highs cannot retrospectively create a split.
// A reset needs BOTH loss of same-direction extreme progression and a
// previously formed child ruler already crossed before the new origin.
bool BKNGuidePhaseAppend(const MqlRates &rows[],const BKNScope &first,const BKNScope &last,
 const BKNScope &parent,int seconds,BKNScope &out[]){
 BKNScope s;ZeroMemory(s);BKNSCopy(s.a,first.a);BKNSCopy(s.b,last.b);
 s.up=parent.up;s.degree=0;s.known=parent.known;
 s.envelope=BKNSEnvelope(rows,s.a,s.b);s.ambiguous=false;
 if(!s.envelope||BKNGuideScopeReason(rows,s.a.index,s.b.index,s.up,seconds,s.known,s.known)!="")return false;
 BKNScopeAppend(out,s);return true;
}
string BKNGuideSplitComposite(const MqlRates &rows[],const BKNPoint &ledger[],const BKNScope &parent,
 int seconds,datetime cutoff,BKNScope &out[]){
 ArrayResize(out,0);
 if(parent.ambiguous||!parent.envelope)return "parent_ambiguous_or_not_enclosed";
 string invalid=BKNGuideScopeReason(rows,parent.a.index,parent.b.index,parent.up,seconds,parent.known,cutoff);
 if(invalid!="")return invalid;
 BKNPoint points[];BKNScope legs[],same[];
 if(!BKNSBuildPath(rows,ledger,seconds,parent.known,0,points,legs))return "native_child_path_failed";
 for(int i=0;i<ArraySize(legs);i++){
  BKNScope leg;BKNScopeCopy(leg,legs[i]);
  if(leg.a.time<parent.a.time||leg.b.time>parent.b.time)continue;
  if(leg.ambiguous||!leg.envelope)return "native_child_membership_pending";
  if(leg.up==parent.up)BKNScopeAppend(same,leg);
 }
 int n=ArraySize(same);
 if(n<2)return "single_native_direction_leg";
 if(same[0].a.time!=parent.a.time||same[n-1].b.time!=parent.b.time)return "child_path_does_not_cover_parent_endpoints";
 int start=0,splits=0;double sign=parent.up?1.0:-1.0;
 for(int i=1;i<n;i++){
  bool advancing_origin=sign*(same[i].a.price-same[i-1].a.price)>BKNGeometryTolerance(same[i].a.price,same[i-1].a.price);
  bool advancing_terminal=sign*(same[i].b.price-same[i-1].b.price)>BKNGeometryTolerance(same[i].b.price,same[i-1].b.price);
  if(advancing_origin&&advancing_terminal)continue;
  BKNScope previous;BKNScopeCopy(previous,same[i-1]);
  BKNGuidedPair ruler=BKNGuideSelectBoundary(rows,previous.a.index,previous.b.index,parent.up,!parent.up,seconds,previous.known,parent.known);
  if(!ruler.valid)continue;
  BKNGuidedTurningLife life=BKNGuideObserveTurning(rows,ruler,seconds,parent.known);
  // A terminal pivot may be confirmed after its ruler has already crossed.
  // Do not simply accept that retrospective cross. Reconstruct the SAME
  // contacts from the closed-price prefix, with the origin already known.
  // Only a ruler actually computable before that cross is a reset witness.
  if(life.valid&&life.retrospective){
   datetime prefix_known=(datetime)MathMax((long)previous.a.known,(long)(rows[previous.b.index].time+seconds));
   BKNGuidedPair prefix=BKNGuideSelectBoundary(rows,previous.a.index,previous.b.index,parent.up,!parent.up,seconds,prefix_known,prefix_known);
   if(prefix.valid&&prefix.first==ruler.first&&prefix.second==ruler.second&&
      prefix.first_price==ruler.first_price&&prefix.second_price==ruler.second_price){
    BKNGuidedTurningLife causal=BKNGuideObserveTurning(rows,prefix,seconds,parent.known);
    if(causal.valid&&!causal.retrospective)life=causal;
   }
  }
  // Confirmation may happen after the new origin but must be available
  // at the parent's decision clock. The actual cross must precede origin.
  if(!life.valid||life.cross<0||life.retrospective||rows[life.cross].time>=same[i].a.time)continue;
  if(!BKNGuidePhaseAppend(rows,same[start],same[i-1],parent,seconds,out)){
   ArrayResize(out,0);return "split_phase_enclosure_failed";
  }
  start=i;splits++;
 }
 if(splits==0)return "no_confirmed_structural_reset";
 if(!BKNGuidePhaseAppend(rows,same[start],same[n-1],parent,seconds,out)){
  ArrayResize(out,0);return "split_phase_enclosure_failed";
 }
 return "composite_scope_replaced_by_observed_phases";
}
#endif
