#ifndef BOOK_NATIVE_PAIR
#define BOOK_NATIVE_PAIR
#include "BookNativeIdentity.mqh"
#include "BookNativeWaveProcess.mqh"
#include "BookNativeRecovery.mqh"
#include "BookNativeBreakout.mqh"
// Explicit owned-range binding, separate from actual rail contacts. Neither
// a shared owner label nor equal-looking lines may substitute this record.
// This is a declared native geometry scope, not an author/admitted phase.
struct BKNSourceReference {
 string provider,symbol;
 int seconds;
 datetime a,b;
 double pa,pb;
};
struct BKNBoundaryPair {
 bool evaluated,turning_bound,dual_scored,both_directional,both_hold,prospective;
 bool author_degree_verified,automatic_trade_permission;
 string status,reason,turning_reason,state,source_id,phase_id,pair_id,outer_id,turning_id;
 double weakest_score;
 datetime known,construction_known;
 BKNBoundaryScore outer,turning;
 BKNBoundaryEvents outer_event,turning_event;
};
BKNSourceReference BKNReference(const BKNScope &scope,string provider,string symbol,int seconds){
 BKNSourceReference out;out.provider=provider;out.symbol=symbol;out.seconds=seconds;
 out.a=scope.a.time;out.b=scope.b.time;out.pa=scope.a.price;out.pb=scope.b.price;return out;
}
bool BKNReferenceMatches(const BKNSourceReference &a,const BKNSourceReference &b){
 return StringLen(a.provider)>0&&StringLen(a.symbol)>0&&a.seconds>0&&a.provider==b.provider&&a.symbol==b.symbol&&a.seconds==b.seconds&&
  a.a==b.a&&a.b==b.b&&a.pa==b.pa&&a.pb==b.pb;
}
// Scoring reconstruction, separate from BKNScanBoundary's prospective frozen
// observer. A ruler first established after a historical break may describe
// that break, but its source timing remains retrospective and grants no live
// setup. Do not silently backdate the construction clock to get a green score.
BKNBoundaryEvents BKNPairScoreEvent(const MqlRates &rows[],const BKNFrozenRuler &r,int observable,
                                   int seconds,datetime cutoff,int decimals){
 BKNBoundaryEvents event;ZeroMemory(event);event.born=observable;event.contact=-1;event.broken=-1;
 event.reason="assessment_boundary_unavailable";
 if(!r.qualified||observable<0||observable>=ArraySize(rows)||r.construction_known<=0||r.construction_known>cutoff)return event;
 for(int k=observable+1;k<ArraySize(rows);k++){
  long wick,close;
  if(!BKNGapNumerator(r.up?rows[k].low:rows[k].high,r,k,decimals,wick)||
     !BKNGapNumerator(rows[k].close,r,k,decimals,close)){
   event.reason="assessment_native_quote_grid_unavailable";return event;
  }
  if(event.contact<0&&wick<=0)event.contact=k;
  if(close<0){event.broken=k;break;}
 }
 if(event.contact>=0){event.contact_known=(datetime)MathMax((double)r.construction_known,(double)(rows[event.contact].time+seconds));event.contact_level=BKNFrozenLevel(r,event.contact);}
 if(event.broken>=0){event.break_known=(datetime)MathMax((double)r.construction_known,(double)(rows[event.broken].time+seconds));event.break_level=BKNFrozenLevel(r,event.broken);}
 event.same_bar=event.contact>=0&&event.contact==event.broken;event.emit_contact=event.contact>=0&&!event.same_bar;
 event.evaluated=true;event.reason="";return event;
}
bool BKNOuterNativeProof(const MqlRates &rows[],const BKNScope &scope,const BKNBoundary &line,
                         int seconds,datetime cutoff,int decimals,string &reason){
 reason="native_outer_source_unavailable";if(!line.qualified)return false;
 reason="owned_native_scope_unverified";if(!BKNVerifyWaveScope(rows,scope,seconds,cutoff))return false;
 int a=scope.a.index,b=scope.b.index,i=line.first,j=line.second;
 reason="outer_owned_scope_mismatch";
 if(line.origin!=a||line.terminal!=b||line.up!=scope.up||i<a||j<=i||j>b)return false;
 reason="outer_anchor_price_not_native";
 if(line.first_price!=(line.up?rows[i].low:rows[i].high)||line.second_price!=(line.up?rows[j].low:rows[j].high))return false;
 double slope=(line.second_price-line.first_price)/(j-i);
 reason="outer_slope_mismatch";
 if(!MathIsValidNumber(line.slope)||MathAbs(slope-line.slope)>1e-10*MathMax(1,MathAbs(slope)))return false;
 reason="outer_dependency_clock_unbound";
 if(line.known_at<scope.known||line.known_at>cutoff||rows[b].time+seconds>line.known_at)return false;
 BKNFrozenRuler ruler=BKNFreezeOuter(line);long gap;
 // Preserve actual native contacts. All other candles in the complete owned
 // interval must be on/inside the support line; no floating epsilon crossing.
 // Additional collinear contacts are allowed by the owned-envelope producer.
 reason="outer_whole_scope_cross_or_contact";
 for(int k=a;k<=b;k++){
  if(!BKNGapNumerator(line.up?rows[k].low:rows[k].high,ruler,k,decimals,gap)){
   reason="outer_native_quote_grid_unavailable";return false;
  }
  if(k==i||k==j){if(gap!=0)return false;}else if(gap<0)return false;
 }
 reason="";return true;
}
BKNBoundaryPair BKNAssessPair(const MqlRates &bars[],const BKNScope &scope,const BKNBoundary &line,
                              const BKNSourceReference &outer_source,const BKNTurning &turning,
                              const BKNSourceReference &turning_source,int seconds,datetime cutoff,int decimals){
 BKNBoundaryPair out;ZeroMemory(out);out.status="unknown";out.state="unknown";out.weakest_score=EMPTY_VALUE;
 out.reason="";out.turning_reason="";out.source_id="";out.phase_id="";out.pair_id="";out.outer_id="";out.turning_id="";
 out.outer.status="unknown";out.turning.status="unknown";out.outer.score=EMPTY_VALUE;out.turning.score=EMPTY_VALUE;
 out.outer_event.contact=-1;out.outer_event.broken=-1;out.turning_event.contact=-1;out.turning_event.broken=-1;
 out.reason="native_market_identity_unavailable";
 if(seconds<=0||outer_source.seconds!=seconds||StringLen(outer_source.provider)==0||StringLen(outer_source.symbol)==0)return out;
 MqlRates rows[];int n=0;datetime previous=0;bool future_seen=false;
 for(int k=0;k<ArraySize(bars);k++){
  if(bars[k].time+seconds>cutoff){future_seen=true;continue;}
  out.reason="invalid_closed_native_pair_prefix";
  if(future_seen||bars[k].time<=previous||!BKNValidRate(bars[k])||bars[k].low<=0)return out;
  // Closed-prefix validation is unchanged. Reserve storage so each boundary
  // pair does not repeatedly copy a wide MqlRates array one element at a time.
  ArrayResize(rows,n+1,256);rows[n++]=bars[k];previous=bars[k].time;
 }
 BKNSourceReference actual=BKNReference(scope,outer_source.provider,outer_source.symbol,seconds);
 out.reason="outer_owned_scope_binding_mismatch";if(!BKNReferenceMatches(actual,outer_source))return out;
 if(!BKNOuterNativeProof(rows,scope,line,seconds,cutoff,decimals,out.reason))return out;
 string market=outer_source.provider+"|"+outer_source.symbol+"|"+IntegerToString(seconds)+"|";
 string wave=BKNPointKey(rows,scope.a.index,scope.a.price,decimals)+">"+BKNPointKey(rows,scope.b.index,scope.b.price,decimals);
 out.source_id="book_native_declared_scope:"+BKNHash(market+wave);
 string contacts=BKNPointKey(rows,line.first,line.first_price,decimals)+">"+BKNPointKey(rows,line.second,line.second_price,decimals);
 out.phase_id="book_native_geometry_phase:"+BKNHash(out.source_id+"|"+contacts);
 out.outer_id="outer:"+BKNHash(out.phase_id+"|"+contacts);
 BKNFrozenRuler outer=BKNFreezeOuter(line);
 out.outer_event=BKNPairScoreEvent(rows,outer,line.second,seconds,cutoff,decimals);
 out.outer=BKNScoreBoundary(rows,outer,line.second,out.outer_event.broken,seconds,cutoff,decimals,out.outer_event.break_known);
 if(!out.outer_event.evaluated){out.outer.status="unknown";out.outer.reason=out.outer_event.reason;}
 out.known=(datetime)MathMax((double)line.known_at,(double)out.outer.known);
 if(out.outer.motion.measured)out.known=(datetime)MathMax((double)out.known,(double)out.outer.motion.known);
 out.construction_known=line.known_at;
 out.turning_reason="turning_owned_scope_binding_mismatch";
 bool bound=BKNReferenceMatches(actual,turning_source);
 if(bound){
  out.turning_reason="CDE_parent_wave_mismatch";
  bound=turning.origin==scope.a.index&&turning.terminal==scope.b.index&&turning.up==scope.up;
 }
 if(bound){
  out.turning_reason="CDE_adjacent_context_not_current_owner";
  bound=turning.c>=scope.a.index&&turning.d>=scope.a.index&&turning.e<=scope.b.index&&turning.d<=scope.b.index;
 }
 if(bound)bound=BKNValidateCDE(rows,turning,decimals,out.turning_reason);
 if(bound){
  out.turning_reason="CDE_dependency_clock_unbound";
  bound=turning.known_at>=scope.known&&rows[turning.observable].time+seconds<=turning.known_at&&turning.known_at<=cutoff;
 }
 out.turning_bound=bound;
 if(bound){
  string ce=BKNPointKey(rows,turning.c,turning.c_price,decimals)+">"+BKNPointKey(rows,turning.e,turning.e_price,decimals)+
   "@"+BKNPointKey(rows,turning.d,turning.d_price,decimals);
  out.pair_id="book_native_boundary_pair:"+BKNHash(out.phase_id+"|"+ce);
  out.turning_id="turning:"+BKNHash(out.phase_id+"|"+ce);
  BKNFrozenRuler ruler=BKNFreezeTurning(turning);
  out.turning_event=BKNPairScoreEvent(rows,ruler,turning.observable,seconds,cutoff,decimals);
  out.turning=BKNScoreBoundary(rows,ruler,turning.observable,out.turning_event.broken,seconds,cutoff,decimals,out.turning_event.break_known);
  if(!out.turning_event.evaluated){out.turning.status="unknown";out.turning.reason=out.turning_event.reason;}
  out.construction_known=(datetime)MathMax((double)out.construction_known,(double)turning.known_at);
  out.known=(datetime)MathMax((double)out.known,MathMax((double)turning.known_at,(double)out.turning.known));
  if(out.turning.motion.measured)out.known=(datetime)MathMax((double)out.known,(double)out.turning.motion.known);
  out.turning_reason="";
 }else {out.turning.reason=out.turning_reason;}
 out.dual_scored=bound&&out.outer.scored&&out.turning.scored;
 out.state=out.dual_scored?"dual_scored":"waiting_two_source_bound_scores";
 if(out.dual_scored){
  out.weakest_score=MathMin(out.outer.score,out.turning.score);
  out.both_directional=out.outer.follow_directional&&out.turning.follow_directional;
  out.both_hold=out.outer.follow_holds&&out.turning.follow_holds;
  out.prospective=out.outer.prospective&&out.turning.prospective;
 }
 out.status="evaluated";out.evaluated=true;out.reason="";return out;
}
#endif
