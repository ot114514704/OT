#ifndef BOOK_NATIVE_STOP
#define BOOK_NATIVE_STOP
#include "BookNativeEvents.mqh"
// Chapter5 protective B: adverse extreme after the second outer contact and
// through the first close break. Never relocate it to a later return extreme,
// a channel offset, or chapter7's independently selected author first wave.
struct BKNStopReference {
 bool observed,response_up,breached,backtrack_required,prospective,automatic_trade_permission;
 int origin,prior,broken,failure,last;
 double price,prior_price;
 datetime known,state_known,failure_known;
 string source_id,status,reason,basis,protection;
};
BKNStopReference BKNBuildStopReference(const MqlRates &bars[],const BKNFrozenRuler &r,
                                      const BKNBoundaryEvents &event,string source_id,
                                      int seconds,datetime cutoff,int decimals){
 BKNStopReference out;ZeroMemory(out);out.status="unknown";out.protection="unknown";
 out.origin=-1;out.prior=-1;out.broken=-1;out.failure=-1;out.last=-1;
 out.price=EMPTY_VALUE;out.prior_price=EMPTY_VALUE;out.reason="no_closed_break_for_B";
 if(!event.evaluated||event.broken<0)return out;
 out.reason="pre_break_B_ruler_unbound";
 if(seconds<=0||!r.qualified||r.turning||r.shifted||r.start!=r.first||source_id=="")return out;
 int n=0;datetime previous=0;bool future_seen=false;
 for(int k=0;k<ArraySize(bars);k++){
  if(bars[k].time+seconds>cutoff){future_seen=true;continue;}
  if(future_seen||bars[k].time<=previous||!BKNValidRate(bars[k])||bars[k].low<=0)return out;
  n++;previous=bars[k].time;
 }
 int i=event.broken,j=r.second;
 if(r.first<0||j<=r.first||j>=i||i>=n||r.construction_known<=0||
    bars[j].time+seconds>r.construction_known||r.construction_known>cutoff||
    event.break_known<r.construction_known||event.break_known<bars[i].time+seconds||event.break_known>cutoff)return out;
 if(r.first_price!=(r.up?bars[r.first].low:bars[r.first].high)||
    r.second_price!=(r.up?bars[j].low:bars[j].high)||r.start_price!=r.first_price)return out;
 long gap;
 if(!BKNGapNumerator(bars[i].close,r,i,decimals,gap)||gap>=0)return out;
 for(int k=j+1;k<i;k++)if(!BKNGapNumerator(bars[k].close,r,k,decimals,gap)||gap<0)return out;
 bool up=!r.up;int origin=j+1,prior=r.first;
 for(int k=origin+1;k<=i;k++)if(up?bars[k].low<bars[origin].low:bars[k].high>bars[origin].high)origin=k;
 for(int k=r.first+1;k<=i;k++)if(up?bars[k].low<bars[prior].low:bars[k].high>bars[prior].high)prior=k;
 double price=up?bars[origin].low:bars[origin].high;long b_ticks;
 if(!BKNPriceTicks(price,decimals,b_ticks)){out.reason="B_native_quote_grid_unavailable";return out;}
 int failure=-1;
 // B failure is sticky. A touch/equality is not a crossing or a stop fill.
 for(int k=i+1;k<n;k++){
  long native;
  if(!BKNPriceTicks(up?bars[k].low:bars[k].high,decimals,native)){
   out.reason="B_protection_native_quote_grid_unavailable";return out;
  }
  if(up?native<b_ticks:native>b_ticks){failure=k;break;}
 }
 out.observed=true;out.response_up=up;out.origin=origin;out.prior=prior;out.broken=i;out.last=n-1;
 out.price=price;out.prior_price=up?bars[prior].low:bars[prior].high;
 out.backtrack_required=out.price!=out.prior_price;
 out.prospective=r.construction_known<=bars[i].time;
 out.known=event.break_known;out.source_id=source_id;out.basis="frozen_pre_break_extreme_B";
 out.failure=failure;out.breached=failure>=0;
 out.failure_known=out.breached?bars[failure].time+seconds:0;
 out.state_known=(datetime)MathMax((double)out.known,(double)(out.breached?out.failure_known:bars[n-1].time+seconds));
 out.status="observed_candidate";out.protection=out.breached?"stop_line_breached":"protected_at_cutoff";out.reason="";
 return out;
}
struct BKNRiskFact {
 bool measured,automatic_trade_permission;
 double close_price,stop_reference,distance,range_reference;
 datetime known;
 string status,reason;
};
BKNRiskFact BKNMeasureRiskFact(const MqlRates &rows[],const BKNStopReference &stop,int seconds,datetime cutoff){
 BKNRiskFact out;ZeroMemory(out);out.status="unknown";out.reason="stop_reference_unknown";
 out.distance=EMPTY_VALUE;out.range_reference=EMPTY_VALUE;
 if(!stop.observed||seconds<=0||stop.known>cutoff||stop.last<0||stop.last>=ArraySize(rows))return out;
 int last=stop.last;if(rows[last].time+seconds>cutoff)return out;
 double ranges[];int first=(int)MathMax(0,last-13);ArrayResize(ranges,last-first+1);
 for(int k=first;k<=last;k++){
  if(!BKNValidRate(rows[k])){out.reason="invalid_native_risk_input";return out;}
  ranges[k-first]=rows[k].high-rows[k].low;
 }
 out.close_price=rows[last].close;out.stop_reference=stop.price;out.distance=MathAbs(out.close_price-stop.price);
 out.range_reference=BKNMedian(ranges);out.known=(datetime)MathMax((double)stop.known,(double)(rows[last].time+seconds));
 out.measured=true;out.status="descriptive_only";out.reason="";return out;
}
#endif
