#ifndef BOOK_NATIVE_DELIVERY
#define BOOK_NATIVE_DELIVERY
#include "BookNativeGeometry.mqh"
#include "BookNativeWholeSources.mqh"
// Original live_force_coverage + live_force_wave_review momentum/admission.
// These are provisional own-period delivery screens, separate from raw force
// scores, author degree, preceding structure context and any entry decision.
struct BKNDeliveryFacts {
 double speed,efficiency,directional_closes,body_share,directional_body_share,body_to_displacement;
};
struct BKNDelivery {
 bool valid,coverage_available,coverage_qualified,strong_coverage,legacy_qualified,qualified,departure_held,admitted;
 bool impulse,sustained,balanced,whole_period,sweep_like;
 int baseline_bars,intervals,force_intervals,active_blocks,delivery_blocks;
 double coverage,baseline,body_share,directional_body_share,close_ratio,range_expansion,body_expansion;
 double amplitude_over_typical,rate_over_typical,burst_range_share;
 string coverage_reason,reason,mask;
 BKNDeliveryFacts whole;
};
bool BKNCarryingForce(const BKNDeliveryFacts &f){
 return f.speed>=.70&&f.efficiency>=.68&&f.directional_closes>=.65&&f.body_share>=.50&&
  f.directional_body_share>=.65&&f.body_to_displacement>=.60;
}
BKNDeliveryFacts BKNDeliveryInterval(const MqlRates &rows[],int first,int last,bool up,double baseline){
 BKNDeliveryFacts out;ZeroMemory(out);double sign=up?1.0:-1.0;
 double net=0,travel=0,direction=0,body=0,directed_body=0,span=0;
 int n=last-first+1;
 for(int i=first;i<=last;i++){
  double d=sign*(rows[i].close-rows[i-1].close),b=sign*(rows[i].close-rows[i].open);
  net+=d;travel+=MathAbs(d);if(d>0)direction++;
  body+=MathAbs(b);directed_body+=MathMax(0.0,b);span+=rows[i].high-rows[i].low;
 }
 out.speed=net/n/baseline;out.efficiency=travel>0?net/travel:0;
 out.directional_closes=direction/n;out.body_share=span>0?body/span:0;
 out.directional_body_share=body>0?directed_body/body:0;out.body_to_displacement=net>0?body/net:0;
 return out;
}
BKNDelivery BKNMeasureDelivery(const MqlRates &rows[],const BKNWholeSource &source,
                               int seconds,datetime cutoff){
 BKNDelivery out;ZeroMemory(out);out.reason="native_source_or_clock_unavailable";
 // MQL ZeroMemory gives string members NULL, which differs from "" in
 // equality checks. Unknown/no intervals is an empty mask, never a null one.
 out.mask="";out.coverage_reason="";
 out.coverage=EMPTY_VALUE;out.burst_range_share=EMPTY_VALUE;out.active_blocks=-1;out.delivery_blocks=-1;
 int a=source.a.index,b=source.b.index,n=b-a+1;
 if(seconds<=0||a<0||b>=ArraySize(rows)||b<=a||source.known>cutoff||
   rows[a].time!=source.a.time||rows[b].time!=source.b.time||rows[b].time+seconds>source.known)return out;
 if(!BKNFullSourceEnvelope(rows,source.a,source.b))return out;
 bool up=source.b.price>source.a.price;double sign=up?1.0:-1.0,amplitude=MathAbs(source.b.price-source.a.price);
 for(int i=a;i<=b;i++)if(!BKNValidRate(rows[i])||(i>a&&rows[i].time-rows[i-1].time!=seconds))return out;
 int prior=(int)MathMax(0,a-20);
 for(int i=a;i>prior;i--)if(rows[i].time-rows[i-1].time!=seconds){prior=i;break;}
 double baseline_ranges[],ranges[],positive_ranges[],bodies[],directional[],opposite[];
 ArrayResize(baseline_ranges,a-prior);out.baseline_bars=a-prior;
 for(int i=prior;i<a;i++){
  if(!BKNValidRate(rows[i]))return out;
  baseline_ranges[i-prior]=rows[i].high-rows[i].low;
 }
 out.valid=true;out.coverage_reason="invalid_or_insufficient_native_ohlc";
 if(n>=3){
  out.coverage_reason="predeparture_native_baseline_unavailable";
  if(out.baseline_bars>=5&&(out.baseline=BKNMedian(baseline_ranges))>0){
   out.coverage_available=true;out.intervals=n-1;
   for(int i=a+1;i<=b;i++){
    BKNDeliveryFacts f=BKNDeliveryInterval(rows,(int)MathMax(a+1,i-2),i,up,out.baseline);
    bool force=BKNCarryingForce(f);if(force)out.force_intervals++;out.mask+=force?"1":"0";
   }
   out.coverage=out.force_intervals/(double)out.intervals;
   out.whole=BKNDeliveryInterval(rows,a+1,b,up,out.baseline);
   out.coverage_qualified=out.coverage>=.80&&BKNCarryingForce(out.whole)&&amplitude>=2*out.baseline;
   out.strong_coverage=out.coverage_qualified&&out.coverage>=.90;
   out.coverage_reason=out.coverage_qualified?"sustained_whole_wave_delivery":"insufficient_whole_wave_force_coverage";
  }
 }
 ArrayResize(ranges,n);ArrayResize(bodies,n);ArrayResize(directional,n);ArrayResize(opposite,n);
 double total_range=0,total_body=0,total_direction=0,total_opposite=0,max_range=0,max_body=0,close_direction=0;
 for(int i=0;i<n;i++){
  int k=a+i;double d=sign*(rows[k].close-rows[k].open),range=rows[k].high-rows[k].low,body=MathAbs(d);
  ranges[i]=range;bodies[i]=body;directional[i]=MathMax(0.0,d);opposite[i]=MathMax(0.0,-d);
  total_range+=range;total_body+=body;total_direction+=directional[i];total_opposite+=opposite[i];
  max_range=MathMax(max_range,range);max_body=MathMax(max_body,body);
  if(range>0){int count=ArraySize(positive_ranges);ArrayResize(positive_ranges,count+1);positive_ranges[count]=range;}
  if(i>0&&sign*(rows[k].close-rows[k-1].close)>0)close_direction++;
 }
 double typical=BKNMedian(positive_ranges);
 if(n>=3&&typical>0){
  out.directional_body_share=total_direction+total_opposite>0?total_direction/(total_direction+total_opposite):0;
  out.body_share=total_body/MathMax(1e-12,total_range);out.close_ratio=close_direction/(n-1);
  out.range_expansion=max_range/typical;out.body_expansion=max_body/typical;
  out.amplitude_over_typical=amplitude/typical;out.rate_over_typical=amplitude/(n-1)/typical;
  out.impulse=out.range_expansion>=2.5&&out.body_expansion>=2.0;
  out.sustained=out.rate_over_typical>=.55&&out.close_ratio>=.50&&out.body_expansion>=1.5;
  out.balanced=out.body_share>=.60&&out.directional_body_share>=.57&&out.close_ratio>=.55&&out.rate_over_typical>=.35;
  out.whole_period=out.sustained||out.balanced||(out.impulse&&out.rate_over_typical>=.35);
  bool base=out.body_share>=.50&&out.directional_body_share>=.55&&out.amplitude_over_typical>=4.0&&out.whole_period;
  if(base&&n>=8&&total_range>0){
   double prefix[];ArrayResize(prefix,n+1);prefix[0]=0;
   for(int i=0;i<n;i++)prefix[i+1]=prefix[i]+ranges[i];
   out.burst_range_share=0;
   for(int i=0;i<=n-3;i++)out.burst_range_share=MathMax(out.burst_range_share,(prefix[i+3]-prefix[i])/total_range);
   int block_size=(n+2)/3;out.active_blocks=0;out.delivery_blocks=0;
   for(int start=0;start<n;start+=block_size){
    int stop=(int)MathMin(n,start+block_size);
    if((prefix[stop]-prefix[start])/total_range>=.16)out.active_blocks++;
    double range=0,body=0,direction=0,opposition=0;
    for(int i=start;i<stop;i++){range+=ranges[i];body+=bodies[i];direction+=directional[i];opposition+=opposite[i];}
    double body_ratio=range>0?body/range:0,direction_ratio=direction+opposition>0?direction/(direction+opposition):0;
    if(body_ratio>=.30&&direction_ratio>=.52)out.delivery_blocks++;
   }
   out.sweep_like=out.body_share<.60&&(out.burst_range_share>=.60||out.active_blocks<2||out.delivery_blocks<2);
  }
  out.legacy_qualified=out.body_share>=.50&&out.directional_body_share>=.55&&out.amplitude_over_typical>=4.0&&
   !out.sweep_like&&out.whole_period;
 }
 out.qualified=out.legacy_qualified&&out.coverage_qualified;
 out.reason=out.qualified?"momentum_body_rate_and_impulse":!out.coverage_qualified?out.coverage_reason:"low_liquidity_or_wick_drift";
 // Origin candle's far edge becomes known at A close. Retain the latest
 // distinct crossing attempt; earlier follow-through cannot rescue a failed
 // crossing followed only by a single latest close.
 double edge=up?rows[a].high:rows[a].low;int crossing=-1,follow=-1;
 bool last_beyond=false,previous_beyond=false,have_previous=false;
 for(int i=a+1;i<=b;i++){
  bool beyond=sign*(rows[i].close-edge)>0;
  if(i==a+1&&! (sign*(rows[a].close-edge)>0)&&beyond)crossing=i;
  if(have_previous&&!previous_beyond&&beyond)crossing=i;
  else if(have_previous&&previous_beyond&&beyond)follow=i;
  previous_beyond=beyond;have_previous=true;last_beyond=beyond;
 }
 out.departure_held=crossing>=0&&follow>crossing&&last_beyond;
 out.admitted=out.departure_held&&out.qualified;return out;
}
#endif
