#ifndef BOOK_NATIVE_TURNING
#define BOOK_NATIVE_TURNING
#include "BookNativeGeometry.mqh"
// Current Book chapter-4 numeric port, not the older origin/35%-window scan.
// C/E enclose the entire declared native movement; D is its actual intervening
// correction extreme. No response candle can relocate a frozen construction.
// Source/phase admission and later boundary events are separate consumers.
struct BKNTurning {
 bool qualified,up;
 int origin,terminal,c,d,e,observable,eligible,rejected,shift_failures;
 double c_price,d_price,e_price,slope,clearance,axis,axis_drift;
 double score,components[4],d_position,typical,extension_strength,clearance_strength;
 datetime known_at;
 string reason,quality,grade;
 double axis_ols,alternate_slope;
 int alternate_c,alternate_d,alternate_e;
 string axis_model_state;
};
struct BKNCE {
 int c,e;
 double slope,clearance,mismatch;
};
double BKNTurnSide(const MqlRates &row,bool up,bool opposite=false){
 return (up!=opposite)?row.high:row.low;
}
bool BKNLocalExtremum(const MqlRates &rows[],int first,int last,int at,bool low,int radius){
 if(radius<1||at-radius<first||at+radius>last)return false;
 double value=low?rows[at].low:rows[at].high;
 for(int k=at-radius;k<=at+radius;k++){
  if(k==at)continue;
  double other=low?rows[k].low:rows[k].high;
  if(low?value>other:value<other)return false;
 }
 return true;
}
// Fig.4-14: the opposite-side source can begin BEFORE the owned directional
// extreme. Admit only the immediately preceding confirmed opposite pivot,
// without crossing an earlier equal/more-extreme owner-side price or a gap.
// Ownership remains [first,last]; this is construction context, not a new wave.
int BKNAdjacentConstructionStart(const MqlRates &rows[],int first,int last,bool up,int seconds){
 if(first<3||last>=ArraySize(rows)||seconds<=0)return first;
 double origin=up?rows[first].low:rows[first].high;
 for(int k=first-1;k>=2;k--){
  if(rows[k+1].time-rows[k].time!=seconds||!BKNValidRate(rows[k]))break;
  double side=up?rows[k].low:rows[k].high;
  if(up?side<=origin:side>=origin)break;
  if(k+2<=first&&BKNLocalExtremum(rows,0,first,k,!up,2))return k;
 }
 return first;
}
bool BKNCEBetter(const BKNCE &a,const BKNCE &b){
 // Original descending (-axis_mismatch, E-C, n-C, minimum_clearance).
 if(a.mismatch!=b.mismatch)return a.mismatch<b.mismatch;
 if(a.e-a.c!=b.e-b.c)return a.e-a.c>b.e-b.c;
 if(a.c!=b.c)return a.c<b.c;
 if(a.clearance!=b.clearance)return a.clearance>b.clearance;
 if(a.e!=b.e)return a.e>b.e;
 return a.slope>b.slope;
}
double BKNTurnUnit(double v){return MathMax(0.0,MathMin(1.0,v));}
BKNTurning BKNTurningBoundary(const MqlRates &rows[],int first,int last,bool up,
                             int seconds,datetime source_known,datetime cutoff,bool display_geometry_only=false,bool adjacent_context=true,int formation_last=-1){
 int formation_end=(formation_last>=first&&formation_last<last)?formation_last:last;
 BKNTurning out;ZeroMemory(out);out.c=-1;out.d=-1;out.e=-1;out.up=up;
 out.origin=first;out.terminal=formation_end;out.reason="source_scope_or_clock_unavailable";
 if(seconds<=0||first<0||formation_end>=ArraySize(rows)||first>=formation_end)return out;
 if(rows[formation_end].time+seconds>source_known||source_known>cutoff)return out;
 int extreme=first;
 for(int k=first;k<=formation_end;k++){
  if(!BKNValidRate(rows[k])||(k>first&&rows[k].time<=rows[k-1].time)){
   out.reason="invalid_native_scope_input";return out;
  }
  if(up?rows[k].high>rows[extreme].high:rows[k].low<rows[extreme].low)extreme=k;
 }
 out.terminal=extreme;int n=extreme-first+1;
 int context=adjacent_context?BKNAdjacentConstructionStart(rows,first,extreme,up,seconds):first;
 int search_first=context<first?context:first;
 int local_first=adjacent_context?(int)MathMax(0,search_first-2):first;
 // The independently owned wave-count module retains its existing input
 // contract in this four-line-family change. Do not silently migrate it.
 if(!adjacent_context&&n<(display_geometry_only?5:12)){out.reason=display_geometry_only?"insufficient_C_D_E_anchor_confirmation":"insufficient_established_wave";return out;}
 if(extreme-search_first<4){out.reason="insufficient_C_D_E_anchor_confirmation";return out;}
 int radius=(int)MathMax(1,MathMin(6,n/20)),vertices[];
 // The opposite-side envelope is high/upper for up and low/lower for down.
 BKNHull(rows,search_first,extreme,!up,vertices);
 bool pivots[];ArrayResize(pivots,extreme-search_first+1);ArrayInitialize(pivots,false);
 for(int k=search_first;k<=extreme;k++)
  if(BKNLocalExtremum(rows,local_first,extreme,k,!up,radius))pivots[k-search_first]=true;
 for(int k=0;k<ArraySize(vertices);k++)if(adjacent_context||vertices[k]>first)pivots[vertices[k]-search_first]=true;
 // Hull compression is an acceleration detail, not permission to erase a
 // real chapter-4 C/E touch. A collinear native peak may fail the wider
 // adaptive pivot radius even though it passes the actual C/E role below.
 // Restore only true local extrema on an already supporting hull equation;
 // D confirmation, whole-owner enclosure and source-known remain mandatory.
 // Keep the separate legacy wave-count branch unchanged.
 if(adjacent_context)for(int h=1;h<ArraySize(vertices);h++){
  int left=vertices[h-1],right=vertices[h];
  double price=BKNTurnSide(rows[left],up),slope=(BKNTurnSide(rows[right],up)-price)/(right-left);
  for(int k=left+1;k<right;k++){
   double actual=BKNTurnSide(rows[k],up),expected=price+slope*(k-left);
   if(MathAbs(actual-expected)<=BKNGeometryTolerance(actual,expected)&&
      BKNLocalExtremum(rows,local_first,extreme,k,!up,1))pivots[k-search_first]=true;
  }
 }
 if(search_first<first){
  int owned_vertices[];BKNHull(rows,first,extreme,!up,owned_vertices);
  for(int k=0;k<ArraySize(owned_vertices);k++)pivots[owned_vertices[k]-search_first]=true;
  for(int h=1;h<ArraySize(owned_vertices);h++){
   int left=owned_vertices[h-1],right=owned_vertices[h];
   double price=BKNTurnSide(rows[left],up),slope=(BKNTurnSide(rows[right],up)-price)/(right-left);
   for(int k=left+1;k<right;k++){
    double actual=BKNTurnSide(rows[k],up),expected=price+slope*(k-left);
    if(MathAbs(actual-expected)<=BKNGeometryTolerance(actual,expected)&&
       BKNLocalExtremum(rows,local_first,extreme,k,!up,1))pivots[k-search_first]=true;
   }
  }
 }
 pivots[extreme-search_first]=true;
 double ranges[];ArrayResize(ranges,n);
 for(int k=0;k<n;k++)ranges[k]=rows[first+k].high-rows[first+k].low;
 out.typical=BKNMedian(ranges);
 // The body axis is still defined for flat-range diagnostic input.
 int half=n/2;double left[],right[];ArrayResize(left,half);ArrayResize(right,half);
 for(int k=0;k<half;k++){
  left[k]=(rows[first+k].open+rows[first+k].close)/2.0;
  right[k]=(rows[extreme-half+1+k].open+rows[extreme-half+1+k].close)/2.0;
 }
 out.axis=(BKNMedian(right)-BKNMedian(left))/(n-half);
 BKNAxis comparison_axis=BKNMeasureAxis(rows,first,extreme);
 out.axis_ols=comparison_axis.ols;out.alternate_c=-1;out.alternate_d=-1;out.alternate_e=-1;
 out.axis_model_state="unknown";
 double axis_scale=MathMax(MathAbs(out.axis),MathMax(out.typical/(n-1),1e-9));
 double sign=up?1.0:-1.0;BKNCE pairs[];
 for(int i=search_first;i<=extreme;i++){
  if(!pivots[i-search_first])continue;
  // No arbitrary older contacts: the sole permitted pre-owner C is the
  // adjacent confirmed pivot. Its intervening D must be the owner origin.
  if(i<first&&i!=context)continue;
  // A hull kink along uninterrupted movement is not chapter-4 peak C.
  // Require an actual native local high/low before its intervening correction.
  if(!BKNLocalExtremum(rows,local_first,extreme,i,!up,1))continue;
  for(int j=i+1;j<=extreme;j++){
   int minimum_span=adjacent_context?4:(display_geometry_only?3:(int)MathMax(6,(int)(n*.22)));
   if(!pivots[j-search_first]||j-i<minimum_span||j<=first)continue;
   if(!adjacent_context&&!display_geometry_only&&j-first<(int)(n*.45))continue;
   // Terminal E inherits the source's confirmed endpoint clock. An earlier
   // E must itself be a price extremum; do not pick a wick mid-impulse merely
   // because it bends the envelope. Existing D confirmation stays unchanged.
   if(j!=extreme&&!BKNLocalExtremum(rows,first,extreme,j,!up,1))continue;
   // C/D/E order, real extrema and envelope are the admission proof. The
   // old 22%/45% time gates were not book rules and erased short valid legs.
   double a=BKNTurnSide(rows[i],up),b=BKNTurnSide(rows[j],up),slope=(b-a)/(j-i);
   if(sign*slope<=0.0)continue;
   // Cheap rejection witnesses only: these are actual candles from the
   // original full-scope test, evaluated with the identical expression.
   // No hull adjacency assumption, angle threshold or candidate admission
   // changes: a survivor still passes EVERY original native-candle check.
   bool hull_clear=true;
   for(int h=0;h<ArraySize(vertices);h++){
    int witness=vertices[h];if(witness==i||witness==j||(i>=first&&witness<first))continue;
    double expected=a+slope*(witness-i),actual=BKNTurnSide(rows[witness],up);
    double clearance=sign*(expected-actual);
    if(clearance<-BKNGeometryTolerance(actual,expected)){hull_clear=false;break;}
   }
   if(!hull_clear)continue;
   double gap=DBL_MAX;bool valid=true;int checked=0;
   for(int k=i+1;k<=extreme;k++){
    if(k==j)continue;
    double expected=a+slope*(k-i),actual=BKNTurnSide(rows[k],up);
    double clearance=sign*(expected-actual);
    if(clearance<-BKNGeometryTolerance(actual,expected)){valid=false;break;}
    gap=MathMin(gap,MathMax(0.0,clearance));checked++;
   }
   if(!valid||checked==0)continue;
   for(int k=(i<first?search_first:first);k<i;k++){
    double expected=a+slope*(k-i),actual=BKNTurnSide(rows[k],up);
    if(sign*(expected-actual)<-BKNGeometryTolerance(actual,expected)){valid=false;break;}
   }
   if(!valid)continue;
   BKNCE p;p.c=i;p.e=j;p.slope=slope;p.clearance=gap;p.mismatch=MathAbs(slope-out.axis)/axis_scale;
   int size=ArraySize(pairs);ArrayResize(pairs,size+1);pairs[size]=p;
  }
 }
 out.eligible=ArraySize(pairs);
 if(out.eligible==0){out.reason=display_geometry_only?"no_opposite_outer_extension":"no_broad_opposite_outer_extension";return out;}
 // Sort once, then retain each C/E's fixed actual D while testing its shift.
 for(int i=1;i<ArraySize(pairs);i++){
  BKNCE p=pairs[i];int j=i-1;
  while(j>=0&&BKNCEBetter(p,pairs[j])){pairs[j+1]=pairs[j];j--;}
  pairs[j+1]=p;
 }
 BKNCE alternate;ZeroMemory(alternate);alternate.mismatch=DBL_MAX;
 for(int p=0;p<ArraySize(pairs);p++){
  int c=pairs[p].c,e=pairs[p].e,d=c+1;
  for(int k=c+2;k<e;k++)
   if(up?rows[k].low<rows[d].low:rows[k].high>rows[d].high)d=k;
  if(c<first&&d!=first){if(out.d<0)out.rejected++;continue;}
  if(!BKNLocalExtremum(rows,local_first,extreme,d,up,2)||d+2>e){if(out.d<0)out.rejected++;continue;}
  double price=BKNTurnSide(rows[d],up,true);bool valid=true;
  // E may be an interior supporting touch rather than the source terminal.
  // The D-shift must enclose the rest of this SAME declared movement too;
  // otherwise it was already crossed during formation but painted later as
  // a live correction target. Extra tangent contacts remain legal.
  for(int k=d+1;k<=extreme;k++){
   double actual=BKNTurnSide(rows[k],up,true),expected=price+pairs[p].slope*(k-d);
   // A later wick may touch this original D-shifted ruler. Only a crossing
   // invalidates it; never move D or replace C/E to manufacture clearance.
   if(sign*(actual-expected)<-BKNGeometryTolerance(actual,expected)){valid=false;break;}
  }
  if(!valid){if(out.d<0){out.shift_failures++;out.rejected++;}continue;}
  if(out.d<0){
   out.c=c;out.d=d;out.e=e;out.c_price=BKNTurnSide(rows[c],up);
   out.e_price=BKNTurnSide(rows[e],up);out.d_price=price;out.slope=pairs[p].slope;
   out.clearance=pairs[p].clearance;out.axis_drift=pairs[p].mismatch;
  }
  // Keep the separate legacy wave-count producer's contract and cost.
  if(!adjacent_context)break;
  BKNCE alternative=pairs[p];alternative.mismatch=MathAbs(alternative.slope-out.axis_ols);
  if(comparison_axis.valid&&(out.alternate_c<0||BKNCEBetter(alternative,alternate))){
   alternate=alternative;out.alternate_c=c;out.alternate_d=d;out.alternate_e=e;
   out.alternate_slope=alternative.slope;
  }
 }
 if(out.d<0){
  out.reason=out.shift_failures==out.eligible?"confirmed_D_shifted_boundary_invalid":"clear_confirmed_adjustment_D_between_C_E_unknown";
  return out;
 }
 if(out.alternate_c>=0)out.axis_model_state=(out.c==out.alternate_c&&out.d==out.alternate_d&&out.e==out.alternate_e)?"agreement":"estimator_disagreement";
 int span=out.e-out.c;out.d_position=(out.d-out.c)/(double)span;
 double counter=MathAbs(out.e_price-out.c_price);
 out.extension_strength=counter/MathMax(out.typical*span,1e-9);
 out.clearance_strength=out.clearance/MathMax(out.typical,1e-9);
 if(span>=(int)MathMax(8,(int)(n*.22))&&out.d_position>=.20&&out.d_position<=.90&&out.clearance_strength>=.15)
  out.quality="confirmed";
 else if(span>=6&&out.d_position>.10)out.quality="candidate";
 else out.quality="unknown";
 out.components[0]=NormalizeDouble(BKNTurnUnit(span/MathMax(8.0,n*.22)),4);
 out.components[1]=NormalizeDouble(MathMax(0.0,1.0-MathAbs(out.d_position-.55)/.55),4);
 out.components[2]=NormalizeDouble(BKNTurnUnit(out.extension_strength/.75),4);
 out.components[3]=NormalizeDouble(BKNTurnUnit(out.clearance_strength/.50),4);
 out.score=NormalizeDouble(MathMax(0.0,MathMin(100.0,35*out.components[0]+25*out.components[1]+20*out.components[2]+20*out.components[3])),1);
 out.grade=out.score>=70?"strong":out.score>=50?"medium":"weak";
 out.observable=(int)MathMax(extreme,out.d+2);out.known_at=source_known;
 if(display_geometry_only){out.quality="review_pending";out.grade="unknown";out.score=0.0;}
 out.qualified=true;out.reason="";return out;
}
double BKNTurningLevel(const BKNTurning &line,int native_index){
 return line.d_price+line.slope*(native_index-line.d);
}
#endif
