#ifndef BOOK_NATIVE_GEOMETRY
#define BOOK_NATIVE_GEOMETRY
// Native numeric port of book_complete_wave_channels.owned_outer_pair.
// Compiled into EX5; no files, network, DLL, Python/Node or order calls.
// Declared native scope is geometry ownership, not author degree admission.
struct BKNAxis {
 bool valid;
 int first,last,bars;
 double slope,ols,price_scale;
 string reason;
};
struct BKNBoundary {
 bool qualified,up;
 int origin,terminal,first,second,parallel_contact,eligible;
 double first_price,second_price,slope,parallel_offset,parallel_price,axis_drift;
 bool axis_review;
 datetime known_at;
 string reason,axis_review_reason;
 // Both estimators rank the SAME admissible real-contact candidates.
 // The alternate is evidence, never an averaged/replacement price ruler.
 double axis_slope,axis_ols,alternate_slope;
 int alternate_first,alternate_second;
 string axis_model_state;
};
// Numeric round-off allowance only, not a market/tick or author threshold.
// A supporting edge may TOUCH another wick; it must not cross that wick.
double BKNGeometryTolerance(double actual,double expected){
 return 16.0*2.2204460492503131e-16*MathMax(MathAbs(actual),MathMax(MathAbs(expected),1e-100));
}
// Radius-2 native confirmation is an engineering aid for ranking legal
// support contacts. The author's rule is terminal order and non-crossing,
// not a requirement to choose the last local ZigZag pivot.
bool BKNBookConfirmedPivot(const MqlRates &rows[],int index,bool up,int seconds,datetime cutoff){
 if(seconds<=0||index<2||index+2>=ArraySize(rows)||rows[index].time+seconds>cutoff)return false;
 double value=up?rows[index].low:rows[index].high;
 for(int k=index-2;k<=index+2;k++){
  if(k==index)continue;
  if(rows[k].time+seconds>cutoff)return false;
  if(rows[k].time!=rows[index].time+(k-index)*seconds)return false;
  double other=up?rows[k].low:rows[k].high;
  // Strict ZigZag confirmation: equal wicks are unresolved and cannot be
  // promoted to the book's second structural anchor.
  if(up?value>=other:value<=other)return false;
 }
 return true;
}
// Minimum native swing evidence for a ruler contact (engineering policy).
// A hull vertex alone may be a wick on an uninterrupted move, not a peak or
// trough. Compare the nearest unequal closed neighbour on each side so a
// plateau in an uninterrupted move cannot masquerade as a reversal.
bool BKNBookSwingContact(const MqlRates &rows[],int index,bool up,int seconds,datetime known){
 if(seconds<=0||index<1||index+1>=ArraySize(rows))return false;
 double v=up?rows[index].low:rows[index].high;
 int left=index-1,right=index+1;
 while(left>=0&&(up?rows[left].low:rows[left].high)==v)left--;
 while(right<ArraySize(rows)&&(up?rows[right].low:rows[right].high)==v)right++;
 if(left<0||right>=ArraySize(rows)||rows[right].time+seconds>known)return false;
 for(int k=left+1;k<=right;k++)if(rows[k].time-rows[k-1].time!=seconds)return false;
 double l=up?rows[left].low:rows[left].high,r=up?rows[right].low:rows[right].high;
 return up?(v<l&&v<r):(v>l&&v>r);
}
// A parallel rail is selected from quoted OHLC values.  The slope itself is
// a native-bar equation, so its residual can differ by a few floating-point
// ulps after a long mirror/replay.  Use the symbol's quote grid only for the
// equality band and keep the original prices for the actual equation.  This
// makes an equal outer touch deterministic (earliest native bar wins) without
// changing which price is drawn.
double BKNQuoteGrid(){
 double p=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
 return (MathIsValidNumber(p)&&p>0.0)?p:1e-8;
}
bool BKNValidRate(const MqlRates &r){
 return MathIsValidNumber(r.open)&&MathIsValidNumber(r.high)&&MathIsValidNumber(r.low)&&MathIsValidNumber(r.close)
  &&r.low<=MathMin(r.open,r.close)&&MathMax(r.open,r.close)<=r.high;
}
double BKNMedian(double &values[]){
 int n=ArraySize(values);if(n==0)return 0.0;
 double sorted[];ArrayCopy(sorted,values);ArraySort(sorted);
 return n%2==1?sorted[n/2]:(sorted[n/2-1]+sorted[n/2])/2.0;
}
BKNAxis BKNMeasureAxis(const MqlRates &rows[],int first,int last){
 BKNAxis out;ZeroMemory(out);out.reason="invalid_owned_native_range";
 if(first<0||last>=ArraySize(rows)||last-first<1)return out;
 int n=last-first+1,half=n/2;double left[],right[],ranges[];
 ArrayResize(left,half);ArrayResize(right,half);int positive=0;double total=0.0;
 for(int i=0;i<n;i++){
  if(!BKNValidRate(rows[first+i])){out.reason="invalid_native_OHLC";return out;}
  if(i>0&&rows[first+i].time<=rows[first+i-1].time){out.reason="unordered_native_rows";return out;}
  double mid=(rows[first+i].open+rows[first+i].close)/2.0;total+=mid;
  if(i<half)left[i]=mid;
  if(i>=n-half)right[i-(n-half)]=mid;
  double range=rows[first+i].high-rows[first+i].low;
  if(range>0){ArrayResize(ranges,positive+1);ranges[positive++]=range;}
 }
 if(positive==0){out.reason="zero_native_price_scale";return out;}
 out.first=first;out.last=last;out.bars=n;out.price_scale=BKNMedian(ranges);
 out.slope=(BKNMedian(right)-BKNMedian(left))/(n-half);
 double xm=(n-1)/2.0,ym=total/n,numerator=0.0,denominator=0.0;
 for(int i=0;i<n;i++){
  double x=i-xm,mid=(rows[first+i].open+rows[first+i].close)/2.0;
  numerator+=x*(mid-ym);denominator+=x*x;
 }
 out.ols=numerator/denominator;out.valid=true;out.reason="";return out;
}
void BKNHull(const MqlRates &rows[],int first,int last,bool up,int &hull[]){
 ArrayResize(hull,0);double sign=up?-1.0:1.0;
 for(int k=first;k<=last;k++){
  double value=up?rows[k].low:rows[k].high;
  int n=ArraySize(hull);
  while(n>=2){
   int a=hull[n-2],b=hull[n-1];
   double av=up?rows[a].low:rows[a].high,bv=up?rows[b].low:rows[b].high;
   double cross=(b-a)*sign*(value-av)-sign*(bv-av)*(k-a);
   double roundoff=BKNGeometryTolerance(value,av)*(b-a)+BKNGeometryTolerance(bv,av)*(k-a);
   if(cross<-roundoff)break;
   ArrayResize(hull,--n);
  }
  ArrayResize(hull,n+1);hull[n]=k;
 }
}
BKNBoundary BKNWholeBoundary(const MqlRates &rows[],int first,int last,bool up,
                            int seconds,datetime source_known,datetime cutoff,bool display_geometry_only=false,int parallel_last=-1){
 BKNBoundary out;ZeroMemory(out);out.reason="source_scope_or_clock_unavailable";
 out.first=-1;out.second=-1;out.parallel_contact=-1;out.origin=first;out.terminal=last;out.up=up;
 if(seconds<=0||first<0||last>=ArraySize(rows)||last-first<(display_geometry_only?2:3))return out;
 if(rows[last].time+seconds>source_known||source_known>cutoff)return out;
 double origin=up?rows[first].low:rows[first].high,terminal=up?rows[last].high:rows[last].low;
 double sign=up?1.0:-1.0;
 if(sign*(terminal-origin)<=0.0){out.reason="native_scope_direction_mismatch";return out;}
 double lo=MathMin(origin,terminal),hi=MathMax(origin,terminal);
 for(int i=first;i<=last;i++){
  if(!BKNValidRate(rows[i])||rows[i].time+seconds>cutoff){out.reason="invalid_native_scope_input";return out;}
  if(rows[i].low<lo-1e-8||rows[i].high>hi+1e-8){out.reason="incomplete_native_wave_envelope";return out;}
 }
 BKNAxis axis=BKNMeasureAxis(rows,first,last);
 if(!axis.valid){out.reason=axis.reason;return out;}
 out.axis_slope=axis.slope;out.axis_ols=axis.ols;
 out.alternate_first=-1;out.alternate_second=-1;out.axis_model_state="unknown";
 double alternate_best=DBL_MAX;int alternate_span=-1;
 int hull[];BKNHull(rows,first,last,up,hull);int span=last-first;
 // Compare slopes on a slope scale. Dividing only by one candle's range /
 // whole-wave length made the same modest relative slope error grow with
 // the length/strength of a wave, hiding its valid enclosing channel.
 // This is the same relative-axis scale used by the independent C/E family.
 double scale=MathMax(MathAbs(axis.slope),axis.price_scale/(double)span),best=DBL_MAX;int best_span=-1;
 // Radius-2 confirmation is an engineering aid, not an author rule that
 // every valid boundary must use the LAST local pivot. Only compare pivots
 // known when this source formed; later bars cannot change its admission.
 int best_pivot_rank=-1,alternate_pivot_rank=-1;
 for(int h=1;h<ArraySize(hull);h++){
  int left=hull[h-1],right=hull[h],a=-1,b=-1;
  double lp=up?rows[left].low:rows[left].high,rp=up?rows[right].low:rows[right].high;
  double edge=(rp-lp)/(right-left);
  // Recover collinear swing contacts on EVERY support edge, not just the
  // terminal edge. Hull compression must not erase a legitimate pivot.
  // Only the independently verified owner origin is allowed without a
  // left neighbour. Later starts and every second contact must be swings.
  for(int k=left;k<=right&&k<last;k++){
   if(k!=first&&!BKNBookSwingContact(rows,k,up,seconds,source_known))continue;
   double actual=up?rows[k].low:rows[k].high,expected=lp+edge*(k-left);
   if(MathAbs(actual-expected)>BKNGeometryTolerance(actual,expected))continue;
   if(a<0)a=k;else b=k;
  }
  if(a<0||b<=a)continue;
  int width=b-a;
  double av=up?rows[a].low:rows[a].high,bv=up?rows[b].low:rows[b].high;
  double slope=(bv-av)/width;
  // Broadness/balance are admission preferences, not a licence to erase
  // real supporting contacts. The optional branch is FINITE review display
  // only; ordinary producers keep their exact previous admission contract.
  if(sign*slope<=0.0||b>=last||width<1)continue;
  int pivot_rank=(BKNBookConfirmedPivot(rows,a,up,seconds,source_known)?1:0)+
   (BKNBookConfirmedPivot(rows,b,up,seconds,source_known)?1:0);
  // Fig.3-28: a tiny contact pair cannot stand for the entire movement,
  // including the review path. 22% is the existing engineering breadth
  // policy, not a number supplied by the author.
  if(width<(int)MathMax(2.0,MathCeil(span*.22)))continue;
  // Fig.3-29 L2 can use later contacts. Requiring the pair to straddle the
  // exact temporal midpoint rejected a broad, better-aligned L2 before
  // comparing slopes and silently kept the earlier L1. Validate the full
  // original owner below; never shorten its range to make L2 pass.
  bool valid=true;int gaps=0;
  for(int i=first;i<=last;i++)if(i!=a&&i!=b){
   double value=up?rows[i].low:rows[i].high;
   double expected=av+slope*(i-a);
   if(sign*(value-expected)<-BKNGeometryTolerance(value,expected)){valid=false;break;}
   gaps++;
  }
  if(!valid||gaps==0)continue;
  double alternate_error=MathAbs(slope-axis.ols);
  // Fig.3-29 axis alignment ranks legal pairs first. A local-pivot flag
  // breaks equal-alignment ties; it cannot keep L1 ahead of the better L2.
  if(out.alternate_first<0||alternate_error<alternate_best||(alternate_error==alternate_best&&
    (pivot_rank>alternate_pivot_rank||(pivot_rank==alternate_pivot_rank&&(width>alternate_span||(width==alternate_span&&a<out.alternate_first)))))){
   out.alternate_first=a;out.alternate_second=b;out.alternate_slope=slope;
   alternate_best=alternate_error;alternate_span=width;alternate_pivot_rank=pivot_rank;
  }
  out.eligible++;double mismatch=MathAbs(slope-axis.slope)/scale;
  if(out.first<0||mismatch<best||(mismatch==best&&
    (pivot_rank>best_pivot_rank||(pivot_rank==best_pivot_rank&&(width>best_span||(width==best_span&&a<out.first)))))){
   out.first=a;out.second=b;out.first_price=av;out.second_price=bv;out.slope=slope;
   out.axis_drift=mismatch;best=mismatch;best_span=width;best_pivot_rank=pivot_rank;
  }
 }
 if(out.first<0){out.reason="no_broad_outer_pair_before_terminal";return out;}
 out.axis_model_state=(out.first==out.alternate_first&&out.second==out.alternate_second)?"agreement":"estimator_disagreement";
 // For an upward wave the opposite rail is the greatest positive offset;
 // for a downward wave it is the most negative offset.  Initialising both
 // directions with -DBL_MAX silently selected the first candle on down waves
 // because sign*(-DBL_MAX) became +DBL_MAX.  That made the channel contact
 // depend on array order instead of the actual outermost opposite wick.
 // Q must be the outermost residual over its declared frozen range.
 // Never replace a terminal Q with an interior wick merely to lengthen
 // the displayed line: that moves the parallel rail through price.
 int q_end=(parallel_last>=first&&parallel_last<=last)?parallel_last:last;
 double outward=sign>0.0?-DBL_MAX:DBL_MAX;int reference=-1;

 double grid_tie=BKNQuoteGrid()*1e-7;
 for(int i=first;i<=q_end;i++){
  double value=up?rows[i].high:rows[i].low;
  double offset=value-(out.first_price+out.slope*(i-out.first));
  if(reference<0){reference=i;outward=offset;}
  if(reference<0)continue;
  double candidate=sign*offset,current=sign*outward;
  double tie=MathMax(grid_tie,BKNGeometryTolerance(offset,outward));
  if(candidate>current+tie || (MathAbs(candidate-current)<=tie&&i<reference)){
   reference=i;outward=offset;
  }
 }

 if(!MathIsValidNumber(outward)||sign*outward<=0.0){out.reason="invalid_parallel_offset";return out;}
 out.parallel_contact=reference;out.parallel_offset=outward;
 out.parallel_price=up?rows[reference].high:rows[reference].low;
 out.axis_review=out.axis_drift>0.5;out.axis_review_reason=out.axis_review?"normalized_axis_drift_over_engineering_review_band":"";
 if(display_geometry_only){out.axis_review=true;out.axis_review_reason="finite_support_contacts_admission_pending";}
 out.known_at=source_known;out.qualified=true;out.reason="";return out;
}
double BKNBoundaryLevel(const BKNBoundary &line,int native_index,bool channel){
 return line.first_price+line.slope*(native_index-line.first)+(channel?line.parallel_offset:0.0);
}
// Stable-time evidence survives viewport index shifts. Estimator agreement
// is a reproducibility fact, not author confirmation or a trading signal.
string BKNAxisEvidence(const MqlRates &rows[],int first,int last,datetime known,
 double axis,double alternate_axis,int a,int b,int alternate_a,int alternate_b,string state){
 if(first<0||last>=ArraySize(rows)||a<0||b<0)return "";
 string result="basis=body_half_median_v1;scope="+IntegerToString((long)rows[first].time)+">"+
  IntegerToString((long)rows[last].time)+";known="+IntegerToString((long)known)+";slope="+DoubleToString(axis,12)+
  ";alternate_basis=body_OLS_v1;alternate_slope="+DoubleToString(alternate_axis,12)+";state="+state+
  ";selected="+IntegerToString((long)rows[a].time)+">"+IntegerToString((long)rows[b].time);
 if(alternate_a>=0&&alternate_b>=0)result+=";alternate="+IntegerToString((long)rows[alternate_a].time)+">"+IntegerToString((long)rows[alternate_b].time);
 return result;
}
// Chapter 4's independent opposite-side source rail can be observed before
// a qualified intervening D exists. It is NOT an OUTER->Q translation and
// grants no target, break event, score or author wave-degree qualification.
BKNBoundary BKNObservedExtension(const MqlRates &rows[],int first,int last,bool up,
 int seconds,datetime known,datetime cutoff,bool adjacent_context=true){
 BKNBoundary out;ZeroMemory(out);out.first=-1;out.second=-1;out.parallel_contact=-1;
 out.origin=first;out.terminal=last;out.up=up;out.reason="independent_extension_unavailable";
 if(seconds<=0||first<0||last<=first||last>=ArraySize(rows)||rows[last].time+seconds>known||known>cutoff)return out;
 BKNAxis axis=BKNMeasureAxis(rows,first,last);if(!axis.valid){out.reason=axis.reason;return out;}
 out.axis_slope=axis.slope;out.axis_ols=axis.ols;out.alternate_first=-1;out.alternate_second=-1;
 out.axis_model_state="unknown";double alternate_best=DBL_MAX;int alternate_span=-1,real_extrema_pairs=0;
 int construction_first=adjacent_context?BKNAdjacentConstructionStart(rows,first,last,up,seconds):first;
 BKNBoundary local;ZeroMemory(local);
 if(construction_first<first)local=BKNObservedExtension(rows,first,last,up,seconds,known,cutoff,false);
 int hull[];BKNHull(rows,construction_first,last,!up,hull);double sign=up?1.0:-1.0,best=DBL_MAX;
 double scale=MathMax(MathAbs(axis.slope),axis.price_scale/(last-first));
 for(int h=1;h<ArraySize(hull);h++){
  int a=hull[h-1],b=hull[h];double pa=up?rows[a].high:rows[a].low,pb=up?rows[b].high:rows[b].low;
  if(b<=first)continue; // the second touch must belong to this wave
  // A convex-hull kink on an uninterrupted impulse is not chapter-4 C/E.
  // Use the same native-extremum roles as the independent C/E/D producer.
  // The completed source endpoint may serve as E at source-known; an
  // interior E needs an actual extremum. No future candle confirms it.
  int local_first=(int)MathMax(0,construction_first-2);
  // Hull compression removes collinear intermediate touches. Recover the
  // earliest real C and last real E on this SAME enclosing equation before
  // rejecting the edge; otherwise the correction would erase legal C/E.
  double edge_slope=(pb-pa)/(b-a);int actual_c=-1,actual_e=-1;
  for(int k=a;k<=b;k++){
   double price=up?rows[k].high:rows[k].low,expected=pa+edge_slope*(k-a);
   if(MathAbs(price-expected)>BKNGeometryTolerance(price,expected))continue;
   bool extremum=BKNLocalExtremum(rows,local_first,last,k,!up,1);
   if(actual_c<0&&k<b&&extremum&&(k>=first||k==construction_first))actual_c=k;
   if(actual_c>=0&&k>actual_c&&(k==last||extremum))actual_e=k;
  }
  if(actual_c<0||actual_e<0)continue;
  a=actual_c;b=actual_e;pa=up?rows[a].high:rows[a].low;pb=up?rows[b].high:rows[b].low;
  if(b<=first)continue;
  real_extrema_pairs++;
  // The observation fallback is not exempt from chapter-3 breadth. A
  // one-bar hull edge is not a whole-wave channel, however exterior it is.
  if(b-a<(int)MathMax(2.0,MathCeil((last-first)*.22)))continue;
  double slope=(pb-pa)/(b-a);if(sign*slope<=0)continue;
  bool valid=true;
  for(int k=construction_first;k<=last;k++){
   double actual=up?rows[k].high:rows[k].low,expected=pa+slope*(k-a);
   if(sign*(expected-actual)<-BKNGeometryTolerance(actual,expected)){valid=false;break;}
  }
  if(!valid)continue;out.eligible++;double error=MathAbs(slope-axis.slope)/scale;
  double alternate_error=MathAbs(slope-axis.ols);
  if(out.alternate_first<0||alternate_error<alternate_best||(alternate_error==alternate_best&&b-a>alternate_span)){
   out.alternate_first=a;out.alternate_second=b;out.alternate_slope=slope;
   alternate_best=alternate_error;alternate_span=b-a;
  }
  if(out.first<0||error<best||(error==best&&b-a>out.second-out.first)){
   best=error;out.first=a;out.second=b;out.first_price=pa;out.second_price=pb;out.slope=slope;out.axis_drift=error;
  }
 }
 // Context adds a candidate; it must not erase valid wave-local contacts.
 if(local.qualified){
  int aa=out.alternate_first,ab=out.alternate_second;double aslope=out.alternate_slope;
  double local_error=MathAbs(local.alternate_slope-axis.ols);
  if(aa<0||local_error<alternate_best||
    (local_error==alternate_best&&local.alternate_second-local.alternate_first>ab-aa)){
   aa=local.alternate_first;ab=local.alternate_second;aslope=local.alternate_slope;
  }
  if(out.first<0||local.axis_drift<=out.axis_drift)out=local;
  out.alternate_first=aa;out.alternate_second=ab;out.alternate_slope=aslope;
 }
 if(out.first<0){out.reason=real_extrema_pairs==0?"no_observed_C_E_extrema_in_owned_prefix":"observed_C_E_extrema_fail_outer_direction_or_span";return out;}
 out.axis_model_state=(out.first==out.alternate_first&&out.second==out.alternate_second)?"agreement":"estimator_disagreement";
 out.known_at=known;out.qualified=true;out.axis_review=true;
 out.axis_review_reason="opposite_source_only_no_confirmed_D_shift";out.reason="";return out;
}
// Native ordinal slope never becomes a wall-clock chord over a session gap.
// Consumers draw a separate segment for each [start,end] returned here.
// Deprecated compatibility shell: the active Book path uses
// BKNObserveChannelProjection + BKNLineContractDisplayEnd. Keep this symbol
// for older mechanical harnesses without reintroducing a second stop policy.
int BKNChannelDisplayEnd(const MqlRates &rows[],int terminal,int first,
 double price,double slope,double offset,bool up,bool axis_review,
 int seconds,datetime cutoff,int &observation,string &basis){
 observation=-1;basis="deprecated_unified_caller_required";
 if(terminal<0||first<0||terminal>=ArraySize(rows)||first>terminal||seconds<=0)return -1;
 return terminal;
}
int BKNFiniteSegments(const MqlRates &rows[],int first,int last,int seconds,int &starts[],int &stops[],bool preserve_singletons=false){
 ArrayResize(starts,0);ArrayResize(stops,0);
 if(first<0||last>=ArraySize(rows)||first>last||seconds<=0)return 0;
 if(first==last){
  if(!preserve_singletons)return 0;
  ArrayResize(starts,1);ArrayResize(stops,1);starts[0]=first;stops[0]=last;return 1;
 }
 int begin=first,count=0;
 for(int k=first;k<=last;k++){
  if(k<last&&rows[k+1].time-rows[k].time==seconds)continue;
  if(begin<k||(preserve_singletons&&begin==k)){ArrayResize(starts,count+1);ArrayResize(stops,count+1);starts[count]=begin;stops[count++]=k;}
  begin=k+1;
 }
 return count;
}
// A parallel rail is anchored at its own actual touch, never at an earlier
// coefficient origin. If there is no clean span after Q yet, preserve Q as
// a point instead of inventing a backwards line or losing the construction.
int BKNChannelSegments(const MqlRates &rows[],int contact,int last,int seconds,int &starts[],int &stops[],bool preserve_singletons=false){
 int count=BKNFiniteSegments(rows,contact,last,seconds,starts,stops,preserve_singletons);
 if(contact<0||contact>=ArraySize(rows)||last<contact||last>=ArraySize(rows)||seconds<=0)return count;
 if(count==0||starts[0]>contact){
  ArrayResize(starts,count+1);ArrayResize(stops,count+1);
  for(int k=count;k>0;k--){starts[k]=starts[k-1];stops[k]=stops[k-1];}
  starts[0]=contact;stops[0]=contact;count++;
 }
 return count;
}
// A finite drawing of an owned construction is not its infinite mathematical
// ruler. Preserve the exact slope and Q/D, but clip activity by owner TIME
// extent only. A future equation value leaving the old A-B price envelope is
// not itself a contact, close break, or trend invalidation. Event scanning
// remains independent on the frozen ruler; price-envelope inspection belongs
// to diagnostics and must never erase an otherwise valid channel projection.
int BKNOwnedDrawingEnd(const MqlRates &rows[],int anchor,int requested,int owner_first,int owner_last,
 double anchor_price,double slope){
 if(owner_first<0||owner_last>=ArraySize(rows)||owner_last<owner_first||
    anchor<owner_first||anchor>owner_last||requested<anchor)return -1;
 return (int)MathMin(requested,owner_last);
}
#endif

