#ifndef BOOK_NATIVE_IDENTITY
#define BOOK_NATIVE_IDENTITY
// Stable native keys deliberately omit observation/cutoff clocks. A hash is
// an identity only: it is never proof of author degree or source admission.
string BKNHash(string text){
 uchar source[],key[],digest[];StringToCharArray(text,source,0,WHOLE_ARRAY,CP_UTF8);
 if(ArraySize(source)>0)ArrayResize(source,ArraySize(source)-1);
 if(CryptEncode(CRYPT_HASH_SHA256,source,key,digest)<=0)return "";
 string result="";for(int i=0;i<ArraySize(digest);i++)result+=StringFormat("%02x",(int)digest[i]);return result;
}
string BKNPointKey(const MqlRates &rows[],int at,double price,int decimals){
 return IntegerToString((long)rows[at].time)+"@"+DoubleToString(price,decimals);
}
#endif
