#ifndef BOOK_NATIVE_FRAME
#define BOOK_NATIVE_FRAME
#include "BookNativeGeometry.mqh"
#include "BookNativeChannelQuality.mqh"
#include "BookNativeRecovery.mqh"
#include "BookNativeWholeSources.mqh"
#include "BookNativeWaveProcess.mqh"
#include "BookNativeDelivery.mqh"
#include "BookNativeBreakout.mqh"
#include "BookNativePair.mqh"
#include "BookNativeFollow.mqh"
#include "BookNativeStop.mqh"
#include "BookNativeStructure.mqh"
#include "BookNativePhaseBinding.mqh"
#include "BookNativeWaveCount.mqh"
#include "BookNativeWaveBranches.mqh"
#include "BookNativeWaveCorrection.mqh"
#include "BookNativeWaveDegree.mqh"
#include "BookNativePatterns.mqh"
#include "BookNativeProjection.mqh"
// In-memory native scene. No external analysis packet or archived drawings.
// The shape fields intentionally match the existing Book renderer's contract.
// Full chapter7/plan/model/context layers are still separate migration work;
// incomplete products expose that state instead of claiming full acceptance.
struct BKNShape {
 string id,layer,kind,status,owner,group,label,sceneToken;
 string source_id,phase_id,pair_id,pair_state;
 string construction_id,construction_revision,formation_input_revision,root_phase_id,previous_phase_id,event_id;
 string recovery_status,recovery_event_order;
 string count_state,count_binding,count_form,count_degree;
 datetime count_degree_known;
 datetime count_known,leg_known,source_known;
 bool count_retrospective;
 string line_family,line_display_unknown,line_display_basis,line_event_unknown,line_event_kind,axis_review_reason;
 string line_provider,line_symbol,line_invalidation_reason;
 string line_host_owner;
 string line_admission_mode;
 datetime line_host_a,line_host_b;
 int line_seconds;
 int line_a_index,line_b_index,line_c_index,line_d_index,line_e_index,line_f_index,line_q_index;
 datetime line_a_time,line_b_time,line_c_time,line_d_time,line_e_time,line_f_time,line_q_time;
 double line_a_price,line_b_price,line_c_price,line_d_price,line_e_price,line_f_price,line_q_price;
 string axis_evidence;
 datetime a,b,known,assessment_known;
 datetime owner_a,owner_b,owner_known;
 int owner_degree;
 datetime line_construction_known,line_display_known,line_event_known;
 datetime line_state_known,line_display_first,line_display_last,line_event_first,line_event_break;
 datetime event_occurrence_known,source_retired_known;
 int recovery_c,recovery_d,recovery_e,recovery_f,recovery_observable,recovery_display_end;
 int recovery_target_contact,recovery_source_contact,recovery_invalid;
 double pa,pb,score,pair_score,force_coverage;
 bool has_score,pair_has_score,delivery_measured,delivery_qualified;
 bool line_clocks_supported,axis_review,author_degree_verified;
 string line_role,line_anchor_role,line_contract_id,line_contract_revision,line_contract_state,line_contract_reason,line_owner_relation;
 bool line_geometry_valid,line_event_eligible,line_pair_eligible,line_duplicate;
 int line_anchor_index;
 datetime line_anchor_time;double line_anchor_price;
};
#include "BookNativeLineContract.mqh"
bool BKNLineClocksValid(const BKNShape &s,datetime cutoff){
 if(!s.line_clocks_supported)return true;
 if(s.line_family!="OUTER"&&s.line_family!="CHANNEL"&&s.line_family!="CE_SOURCE"&&s.line_family!="RETURN_CE_D"&&s.line_family!="RESUME_DF_C")return false;
 if((s.line_family=="OUTER"&&s.layer!="trend")||(s.line_family=="CHANNEL"&&s.layer!="channel")||
    (s.line_family=="CE_SOURCE"&&(s.layer!="turning_point"||s.group!="book_CE_reference"))||
    (s.line_family=="RETURN_CE_D"&&(s.layer!="turning_point"||s.group!="book_CE_D"))||
    (s.line_family=="RESUME_DF_C"&&(s.layer!="turning_point"||s.group!="book_DF_C")))return false;
 if(s.line_construction_known<=0||s.line_construction_known>s.known||s.known>cutoff)return false;
 if(s.line_display_known>0){
  if(s.line_display_known<s.line_construction_known||s.line_display_known>s.known||StringLen(s.line_display_unknown)>0)return false;
 }else if(StringLen(s.line_display_unknown)==0)return false;
 if(s.line_family=="RESUME_DF_C"&&s.line_display_basis!="last_clean_display_extent")return false;
 if(s.line_event_known>0){
  if(s.line_event_known<s.line_construction_known||s.line_event_known>s.known||StringLen(s.line_event_unknown)>0||StringLen(s.line_event_kind)==0)return false;
 }else if(StringLen(s.line_event_unknown)==0)return false;
 return true;
}
bool BKNSetLineClocks(BKNShape &shapes[],int start,int end,string family,
 datetime construction,datetime display,string display_unknown,
 datetime event,string event_kind,string event_unknown,datetime cutoff){
 if(start<0||end<start||end>ArraySize(shapes))return false;
 for(int i=start;i<end;i++){
  shapes[i].line_clocks_supported=true;shapes[i].line_family=family;
  shapes[i].line_display_basis=family=="RESUME_DF_C"?"last_clean_display_extent":"line_display_state_extent";
  shapes[i].line_construction_known=construction;shapes[i].line_display_known=display;shapes[i].line_display_unknown=display_unknown;
  shapes[i].line_event_known=event;shapes[i].line_event_kind=event_kind;shapes[i].line_event_unknown=event_unknown;
  shapes[i].known=(datetime)MathMax((double)shapes[i].known,MathMax((double)construction,MathMax((double)display,(double)event)));
  if(!BKNLineClocksValid(shapes[i],cutoff))return false;
 }
 return true;
}
void BKNLineEventClock(const BKNBoundaryEvents &event,datetime &known,string &kind,string &unknown){
 known=0;kind="unknown";unknown=event.reason;
 if(!event.evaluated)return;
 unknown="";
 if(event.broken>=0){known=event.break_known;kind=event.same_bar?"contact_and_close_break_same_bar_order_unknown":"first_close_break";}
 else if(event.contact>=0){known=event.contact_known;kind="wick_contact_without_close_break";}
 else {kind="not_observed";unknown="no_boundary_event_observed_at_this_prefix";}
}
string BKNGradeLabel(string grade){return grade=="strong"?"强":grade=="medium"?"中":grade=="weak"?"弱":"未知";}
datetime BKNFollowingScopeKnown(const BKNScope &scope,const BKNScope &owners[],datetime cutoff){
 for(int k=0;k<ArraySize(owners);k++)
  if(owners[k].envelope&&owners[k].degree==scope.degree&&owners[k].a.time==scope.b.time&&owners[k].b.time>scope.b.time&&
     owners[k].up!=scope.up&&owners[k].known<=cutoff)return owners[k].known;
 return 0;
}
void BKNShapeAppend(BKNShape &out[],string ns,string family,string layer,string kind,
                   string owner,string group,datetime a,double pa,datetime b,double pb,
                   datetime known,string status,string label,bool measured=false,double score=0){
 if(a<=0||b<a||!MathIsValidNumber(pa)||!MathIsValidNumber(pb))return;
 string id=BKNHash(ns+"|"+family+"|"+owner+"|"+IntegerToString((long)a)+"|"+IntegerToString((long)b));
 if(id=="")return;
 BKNShape s;ZeroMemory(s);s.id="b"+StringSubstr(id,0,23);s.layer=layer;s.kind=kind;s.owner=owner;s.group=group;
 // Optional absence must remain an actual empty string after ZeroMemory.
 // NULL != "" on MT5 can otherwise falsely advertise a geometry binding.
 s.sceneToken="";s.source_id="";s.phase_id="";s.pair_id="";s.pair_state="";
 s.construction_id=BKNHash(ns+"|construction|"+family+"|"+owner+"|"+IntegerToString((long)a)+"|"+IntegerToString((long)b));
 s.construction_revision="";s.formation_input_revision="";s.root_phase_id="";s.previous_phase_id="";s.event_id="";
 s.recovery_status="";s.recovery_event_order="";
 s.count_state="";s.count_binding="";
 s.line_provider="";s.line_symbol="";s.line_invalidation_reason="";s.line_seconds=0;
 s.line_host_owner="";s.line_host_a=0;s.line_host_b=0;
 s.line_admission_mode="native_geometry";
 s.line_a_index=s.line_b_index=s.line_c_index=s.line_d_index=s.line_e_index=s.line_f_index=s.line_q_index=-1;
 s.line_a_time=s.line_b_time=s.line_c_time=s.line_d_time=s.line_e_time=s.line_f_time=s.line_q_time=0;
 s.line_a_price=s.line_b_price=s.line_c_price=s.line_d_price=s.line_e_price=s.line_f_price=s.line_q_price=EMPTY_VALUE;
 s.line_state_known=0;s.line_display_first=s.line_display_last=s.line_event_first=s.line_event_break=0;
 s.recovery_c=-1;s.recovery_d=-1;s.recovery_e=-1;s.recovery_f=-1;s.recovery_observable=-1;s.recovery_display_end=-1;
 s.recovery_target_contact=-1;s.recovery_source_contact=-1;s.recovery_invalid=-1;
 s.line_family="";s.line_display_unknown="";s.line_display_basis="";s.line_event_unknown="";s.line_event_kind="";s.axis_review_reason="";
 s.axis_evidence="";
 s.line_role="";s.line_anchor_role="";s.line_contract_id="";s.line_contract_revision="";s.line_contract_state="";s.line_contract_reason="";s.line_owner_relation="same_owner";
 s.line_geometry_valid=false;s.line_event_eligible=false;s.line_pair_eligible=false;s.line_duplicate=false;
 s.line_anchor_index=-1;s.line_anchor_time=0;s.line_anchor_price=0;
 s.a=a;s.b=b;s.pa=pa;s.pb=pb;s.known=known;s.status=status;s.label=label;s.has_score=measured;s.score=measured?score:EMPTY_VALUE;
 s.line_a_time=a;s.line_b_time=b;s.line_a_price=pa;s.line_b_price=pb;
 // Shape records contain many reference-counted strings. Growing by one
 // without reserve repeatedly reallocates/copies the full historical scene.
 // Reserve capacity only; logical count and every emitted record are equal.
 int n=ArraySize(out);ArrayResize(out,n+1,256);out[n]=s;
}
void BKNSetLineEndpoint(const MqlRates &rows[],int index,double price,int &out_index,datetime &out_time,double &out_price){
 if(index<0||index>=ArraySize(rows)||!MathIsValidNumber(price))return;
 out_index=index;out_time=rows[index].time;out_price=price;
}
void BKNBindScopeLineEndpoints(BKNShape &s,const BKNScope &scope,const MqlRates &rows[]){
 BKNSetLineEndpoint(rows,scope.a.index,scope.a.price,s.line_a_index,s.line_a_time,s.line_a_price);
 BKNSetLineEndpoint(rows,scope.b.index,scope.b.price,s.line_b_index,s.line_b_time,s.line_b_price);
}
void BKNBindOuterLineEndpoints(BKNShape &s,const BKNScope &scope,const BKNBoundary &line,const MqlRates &rows[]){
 // Ownership A..B and the two support contacts are different coordinates.
 // Keep owner_a/owner_b for scope; export the actual ruler contacts here.
 BKNSetLineEndpoint(rows,line.first,line.first_price,s.line_a_index,s.line_a_time,s.line_a_price);
 BKNSetLineEndpoint(rows,line.second,line.second_price,s.line_b_index,s.line_b_time,s.line_b_price);
 BKNSetLineEndpoint(rows,line.parallel_contact,line.parallel_price,s.line_q_index,s.line_q_time,s.line_q_price);
}
void BKNBindTurningLineEndpoints(BKNShape &s,const BKNTurning &turning,const MqlRates &rows[]){
 BKNSetLineEndpoint(rows,turning.c,turning.c_price,s.line_c_index,s.line_c_time,s.line_c_price);
 BKNSetLineEndpoint(rows,turning.d,turning.d_price,s.line_d_index,s.line_d_time,s.line_d_price);
 BKNSetLineEndpoint(rows,turning.e,turning.e_price,s.line_e_index,s.line_e_time,s.line_e_price);
}
void BKNBindRecoveryLineEndpoints(BKNShape &s,const BKNRecovery &recovery,const BKNTurning &turning,const MqlRates &rows[]){
 BKNSetLineEndpoint(rows,recovery.c,recovery.c_price,s.line_c_index,s.line_c_time,s.line_c_price);
 BKNSetLineEndpoint(rows,recovery.d,recovery.d_price,s.line_d_index,s.line_d_time,s.line_d_price);
 BKNSetLineEndpoint(rows,recovery.e,turning.e_price,s.line_e_index,s.line_e_time,s.line_e_price);
 BKNSetLineEndpoint(rows,recovery.f,recovery.f_price,s.line_f_index,s.line_f_time,s.line_f_price);
}
// Construction context and observation host are different identities. C..E
// here is a source-ruler interval, not an author-confirmed wave degree.
void BKNBindAdjacentLineOwner(BKNShape &s,const BKNScope &host,const MqlRates &rows[],
 int first,int last,datetime known,string host_owner){
 if(first<0||last<first||last>=ArraySize(rows))return;
 s.line_owner_relation="adjacent_context";
 s.line_host_owner=host_owner;s.line_host_a=host.a.time;s.line_host_b=host.b.time;
 s.owner="book_native_adjacent_context:"+BKNHash(host_owner+"|"+
  IntegerToString((long)rows[first].time)+">"+IntegerToString((long)rows[last].time));
 s.source_id=s.owner;s.owner_a=rows[first].time;s.owner_b=rows[last].time;
 s.owner_known=known;s.owner_degree=-1;
}
struct BKNGeometryCoverage {
 datetime a,b,known;
 int count,outer,channel,turning,recovery,channel_lines,channel_points,extension;
 string reason,outer_reason,channel_reason,turning_reason,recovery_reason,extension_reason;
};
class BKNFrameBuilder {
private:
 MqlRates m_rows[];
 BKNPoint m_raw[],m_context[],m_native[];
 BKNWholeSource m_sources[];
 BKNCompletedWave m_local[],m_local_chosen[];
 BKNScope m_geometry[],m_strict[],m_drawn_geometry[],m_owned_geometry[];
 BKNScope m_phase_scopes[];
 BKNBoundary m_phase_roots[];
 long m_clocks[];
 int m_stage,m_clock,m_scope,m_seconds,m_decimals,m_source_end,m_local_next,m_emit,m_phase_job,m_geometry_degree,m_detail_levels,m_primary_geometry_count;
 datetime m_cutoff;
 string m_namespace,m_failure,m_symbol,m_provider,m_input_revision;
 bool m_cancelled;
 void StampLifecycle(){
  for(int i=0;i<ArraySize(shapes);i++){
   if(shapes[i].construction_id=="")
    shapes[i].construction_id=BKNHash(m_namespace+"|construction|"+shapes[i].id);
   // Producer-owned rule/anchor revisions must survive delivery. Frame
   // input identity remains in the receipt; it is only a fallback here.
   if(shapes[i].construction_revision=="")shapes[i].construction_revision=m_input_revision;
   BKNLineContractBindCommon(shapes[i],m_seconds,m_provider,m_symbol);
   BKNStampLineContract(shapes[i],m_cutoff,m_input_revision);
   // CE_SOURCE can also arrive from the independent-extension/source
   // inspection producers, not only the primary GeometryShape path. Give
   // every such source ruler the same finite formation/display clock so a
   // consumer never sees an unclocked C-E line beside a clocked one.
   if(shapes[i].line_role=="CE_SOURCE"&&!shapes[i].line_clocks_supported){
    datetime reference_known=shapes[i].known;
    if(!BKNSetLineClocks(shapes,i,i+1,"CE_SOURCE",reference_known,reference_known,"",0,
       "unknown","source_reference_no_event_evaluation",m_cutoff)){
     m_failure="ce_source_clock_invalid";return;
    }
    shapes[i].line_display_basis="finite_CE_source_C_to_E";
    BKNLineContractBindCommon(shapes[i],m_seconds,m_provider,m_symbol);
    BKNStampLineContract(shapes[i],m_cutoff,m_input_revision);
   }
   // A source can be retired only when a separate lifecycle receipt proves
   // it.  The native frame has no such receipt, so zero remains explicit
   // unknown instead of being inferred from the current observation.
   shapes[i].source_retired_known=0;
  }
  BKNMarkLineDuplicates(shapes);
 }
 void LineClocks(int start,string family,datetime construction,datetime display,const BKNBoundaryEvents &event){
  datetime at;string kind,unknown;BKNLineEventClock(event,at,kind,unknown);
  if(!BKNSetLineClocks(shapes,start,ArraySize(shapes),family,construction,display,"",at,kind,unknown,m_cutoff))
   m_failure="native_line_clock_contract_invalid";
 }
 void AppendScope(BKNScope &history[],const BKNScope &scope){
  if(!BKNHistoryHasOrigin(history,scope))BKNScopeAppend(history,scope);
 }
 void QueueSuccessor(const BKNScope &scope,const BKNBoundary &outer){
  // Existing radius2 confirmation is a necessary seed condition. Raw hull
  // contacts cannot be promoted to phase pivots by their geometry score.
  // Keep the independently verified owner alongside later L2 contacts.
  // The binder passes that original origin into successor replay. Generated
  // D-F shapes are not queued here, so they cannot recursively create roots.
  for(int i=0;i<ArraySize(m_phase_roots);i++)
   if(m_phase_scopes[i].a.time==scope.a.time&&m_phase_scopes[i].a.price==scope.a.price&&
      m_phase_roots[i].up==outer.up&&m_phase_roots[i].first==outer.first&&m_phase_roots[i].second==outer.second&&
      m_phase_roots[i].first_price==outer.first_price&&m_phase_roots[i].second_price==outer.second_price){
    if(outer.known_at<m_phase_roots[i].known_at){m_phase_roots[i]=outer;BKNScopeCopy(m_phase_scopes[i],scope);}
    return;
   }
  bool first=false,second=false;int kind=outer.up?-1:1;
  for(int i=0;i<ArraySize(m_raw);i++)if(m_raw[i].kind==kind){
   if(m_raw[i].index==outer.first)first=true;
   if(m_raw[i].index==outer.second)second=true;
  }
  if(!first||!second)return;
  int n=ArraySize(m_phase_roots);ArrayResize(m_phase_roots,n+1,32);m_phase_roots[n]=outer;
  ArrayResize(m_phase_scopes,n+1,32);BKNScopeCopy(m_phase_scopes[n],scope);
 }
 void BindPhaseShapes(int start,const BKNBoundPhase &phase,datetime observation){
  for(int i=start;i<ArraySize(shapes);i++){
   shapes[i].source_id=phase.source_id;shapes[i].phase_id=phase.phase_id;
   shapes[i].pair_id="";shapes[i].pair_has_score=false;shapes[i].pair_score=EMPTY_VALUE;
   shapes[i].pair_state="native_successor_independent_CDE_unverified";
   shapes[i].root_phase_id=phase.root_phase_id;shapes[i].previous_phase_id=phase.previous_phase_id;shapes[i].event_id=phase.event_id;
   shapes[i].event_occurrence_known=phase.occurrence_known;shapes[i].author_degree_verified=phase.author_degree_verified;
   shapes[i].assessment_known=(datetime)MathMax((double)phase.known,(double)observation);
  }
 }
 void SuccessorShapes(const BKNScope &scope,const BKNBoundary &outer){
  BKNSourceReference source=BKNReference(scope,m_provider,m_symbol,m_seconds);
  BKNBoundPhase phases[];string reason;
  if(!BKNBindSuccessors(m_rows,scope,outer,source,m_seconds,m_cutoff,m_decimals,phases,reason))return;
  for(int p=0;p<ArraySize(phases);p++){
   BKNBoundPhase phase=phases[p];int d=phase.d,f=phase.f,recovery=phase.recovery;
   double pd=BKNPhaseSide(m_rows[d],phase.up),pf=BKNPhaseSide(m_rows[f],phase.up),slope=(pf-pd)/(f-d),sign=phase.up?1.0:-1.0;
   int phase_start=ArraySize(shapes),end=recovery,contact=-1;
   // An admitted D/F is a successor PHASE of the original source, not a
   // replacement whole A/B wave. Draw its independently proven D..recovery
   // interval; later event observations cannot extend it through new waves.
   datetime observed=m_rows[end].time+m_seconds;
   if(contact>=0)observed=m_rows[contact].time+m_seconds;
   datetime known=(datetime)MathMax((double)phase.known,(double)observed);
   string label="原生后继D-F · F已确认且收盘收复E；"+(phase.prospective?"来源事前已知":"历史重算，来源未提前已知");
   label+=" | 同源 "+phase.source_id+" | 原种子 "+phase.root_phase_id+" | 前阶段 "+phase.previous_phase_id;
   label+=" | 准入可知 "+TimeToString(phase.known,TIME_DATE|TIME_MINUTES)+" | 回执 "+phase.event_id;
   label+=" | 独立C-E/D及作者浪级待核；不改变完整A-B力度";
   int starts[],stops[],start=ArraySize(shapes);BKNFiniteSegments(m_rows,d,end,m_seconds,starts,stops);
   for(int k=0;k<ArraySize(starts);k++){
    int a=starts[k],b=stops[k];
    BKNShapeAppend(shapes,m_namespace,"successor_outer:"+phase.phase_id+":"+IntegerToString(k),"trend","line",phase.phase_id,"book_native_successor_outer",
     m_rows[a].time,pd+slope*(a-d),m_rows[b].time,pd+slope*(b-d),known,contact>=0?"successor_stopped_before_contact":"native_event_admitted_successor",label);
   }
   BKNFrozenRuler ruler;ZeroMemory(ruler);ruler.qualified=true;ruler.up=phase.up;ruler.first=d;ruler.second=f;ruler.start=d;
   ruler.first_price=pd;ruler.second_price=pf;ruler.start_price=pd;ruler.construction_known=phase.known;
   BKNBoundaryEvents outer_event=BKNScanBoundary(m_rows,ruler,m_seconds,m_cutoff,m_decimals);
   LineClocks(start,"OUTER",phase.known,known,outer_event);
   for(int k=start;k<ArraySize(shapes);k++)
    shapes[k].construction_id="book_native_successor_outer:"+BKNHash(phase.phase_id+"|"+
     BKNPointKey(m_rows,d,pd,m_decimals)+">"+BKNPointKey(m_rows,f,pf,m_decimals));
    for(int k=start;k<ArraySize(shapes);k++){
     BKNSetLineEndpoint(m_rows,d,pd,shapes[k].line_a_index,shapes[k].line_a_time,shapes[k].line_a_price);
     BKNSetLineEndpoint(m_rows,f,pf,shapes[k].line_b_index,shapes[k].line_b_time,shapes[k].line_b_price);
    }
   BindPhaseShapes(start,phase,known);
   // The opposite rail passes through an actual native extreme in D..the
   // recovery prefix, not an invented offset on the original whole-wave A.
   int opposite=d;double offset=BKNPhaseOther(m_rows[d],phase.up)-pd;
   for(int k=d+1;k<=recovery;k++){
    double candidate=BKNPhaseOther(m_rows[k],phase.up)-(pd+slope*(k-d));
    if(sign*candidate>sign*offset){opposite=k;offset=candidate;}
   }
   BKNProjection channel_projection=BKNObserveChannelProjection(m_rows,ruler,recovery,opposite,
    BKNPhaseOther(m_rows[opposite],phase.up),false,m_seconds,m_cutoff,m_decimals);
   if(!channel_projection.valid){m_failure=channel_projection.reason;return;}
   int channel_contact=channel_projection.event_bar,channel_end=channel_projection.end;string channel_basis=channel_projection.basis;
   observed=m_rows[channel_end].time+m_seconds;
   if(channel_contact>=0)observed=m_rows[channel_contact].time+m_seconds;
   known=(datetime)MathMax((double)phase.known,(double)observed);start=ArraySize(shapes);
   BKNChannelSegments(m_rows,opposite,channel_end,m_seconds,starts,stops);
   for(int k=0;k<ArraySize(starts);k++){
    int a=starts[k],b=stops[k];
    BKNShapeAppend(shapes,m_namespace,"successor_channel:"+phase.phase_id+":"+IntegerToString(k),"channel",a==b?"point":"line",phase.phase_id,"book_native_successor_channel",
     m_rows[a].time,pd+slope*(a-d)+offset,m_rows[b].time,pd+slope*(b-d)+offset,known,
     channel_basis,label+" | 同斜率平移到原生最外侧异侧触点"+
     " | 外侧实点 "+TimeToString(m_rows[d].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(pd,m_decimals)+
     "→"+TimeToString(m_rows[f].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(pf,m_decimals)+
     " | 对侧平移实点Q "+TimeToString(m_rows[opposite].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(BKNPhaseOther(m_rows[opposite],phase.up),m_decimals));
   }
   if(!BKNSetLineClocks(shapes,start,ArraySize(shapes),"CHANNEL",phase.known,known,"",channel_projection.known,
    channel_projection.event_kind,channel_projection.reason,m_cutoff))m_failure="channel_projection_clock_invalid";
   for(int k=start;k<ArraySize(shapes);k++){
    shapes[k].line_display_basis=channel_basis;
    shapes[k].event_occurrence_known=channel_projection.occurrence;
     BKNSetLineEndpoint(m_rows,d,pd,shapes[k].line_a_index,shapes[k].line_a_time,shapes[k].line_a_price);
     BKNSetLineEndpoint(m_rows,f,pf,shapes[k].line_b_index,shapes[k].line_b_time,shapes[k].line_b_price);
     BKNSetLineEndpoint(m_rows,opposite,BKNPhaseOther(m_rows[opposite],phase.up),shapes[k].line_q_index,shapes[k].line_q_time,shapes[k].line_q_price);
    shapes[k].construction_id="book_native_successor_channel:"+BKNHash(phase.phase_id+"|"+
     BKNPointKey(m_rows,d,pd,m_decimals)+">"+BKNPointKey(m_rows,f,pf,m_decimals)+"@"+
     BKNPointKey(m_rows,opposite,BKNPhaseOther(m_rows[opposite],phase.up),m_decimals));
   }
   BindPhaseShapes(start,phase,known);
   // Phase admission and this channel's later stop are separate events.
   // BindPhaseShapes transports the admission identity; do not let that
   // overwrite the terminal occurrence belonging to the blue rail.
   for(int k=start;k<ArraySize(shapes);k++){
    shapes[k].event_occurrence_known=channel_projection.occurrence;
    shapes[k].event_id=channel_projection.event_bar>=0?"book_native_channel_stop:"+BKNHash(shapes[k].construction_id+"|"+
     channel_projection.event_kind+"|"+IntegerToString((long)channel_projection.occurrence)):"";
   }
  for(int k=phase_start;k<ArraySize(shapes);k++){
    shapes[k].owner_a=m_rows[d].time;shapes[k].owner_b=m_rows[recovery].time;
    shapes[k].owner_known=phase.known;shapes[k].owner_degree=scope.degree;
   }
  }
 }
 void BindScopeShapes(int start,const BKNBoundaryPair &pair,const BKNStructure &structure){
  int outer_index=-1,turning_index=-1;
  for(int k=start;k<ArraySize(shapes);k++){
   if(shapes[k].line_owner_relation=="adjacent_context"){
    BKNLineContractBindCommon(shapes[k],m_seconds,m_provider,m_symbol);
    BKNStampLineContract(shapes[k],m_cutoff,m_input_revision);
    continue;
   }
   shapes[k].source_id=pair.source_id;shapes[k].phase_id=pair.phase_id;shapes[k].pair_id=pair.pair_id;
   shapes[k].pair_state=pair.state;
   // "No closed break observed" includes this assessment's closed prefix;
   // keep it separate from the original geometry construction clock.
   shapes[k].assessment_known=(datetime)MathMax((double)pair.known,(double)structure.known);
   shapes[k].pair_has_score=pair.dual_scored;shapes[k].pair_score=pair.weakest_score;
   if(shapes[k].group=="book_channel_history"){
    shapes[k].pair_has_score=false;shapes[k].pair_score=EMPTY_VALUE;
    shapes[k].pair_state="historical_equation_no_pair_score";
   }
   shapes[k].label+=" | 结构："+BKNStructureLabel(structure)+"；结构独立于力度分";
    BKNLineContractBindCommon(shapes[k],m_seconds,m_provider,m_symbol);
    BKNStampLineContract(shapes[k],m_cutoff,m_input_revision);
   if(shapes[k].line_role=="OUTER"&&outer_index<0)outer_index=k;
   if(shapes[k].line_role=="CE_D"&&turning_index<0)turning_index=k;
  }
  if(outer_index<0||turning_index<0){
   for(int k=start;k<ArraySize(shapes);k++)if(shapes[k].line_pair_eligible){
    shapes[k].line_pair_eligible=false;shapes[k].line_contract_state="candidate";shapes[k].line_contract_reason="pair_requires_same_scope_outer_and_CE_D";
   }
  }else{
   string pair_reason;bool pair_ok=BKNLineContractPairEligible(shapes[outer_index],shapes[turning_index],m_cutoff,pair_reason);
   for(int k=start;k<ArraySize(shapes);k++)if(shapes[k].line_pair_eligible&&!pair_ok){
    shapes[k].line_pair_eligible=false;shapes[k].line_contract_state="candidate";shapes[k].line_contract_reason=pair_reason;
   }
  }
 }
 void PatternShapes(int index){
  BKNPattern found[];
  for(int family=0;family<2;family++){
   if(family==0)BKNCandlePatterns(m_rows,index,m_seconds,m_cutoff,found);
   else BKNChartPatterns(m_rows,index,m_seconds,m_cutoff,found);
   for(int i=0;i<ArraySize(found);i++){
    BKNPattern p=found[i];string owner="book_native_pattern:"+BKNHash(m_namespace+"|"+p.code+"|"+IntegerToString((long)p.known));
    BKNShapeAppend(shapes,m_namespace,p.code,family==0?"candlestick":"chart_pattern",p.kind,owner,"book_pattern_"+p.code,
     m_rows[p.first].time,p.pa,m_rows[p.last].time,p.pb,p.known,"morphology_candidate",p.title+" | 原生已收盘数据；辅助形态，不代替波段/双线确认，不代表入场许可");
   }
  }
 }
 void WaveBranchShapes(const BKNBookWaveCount &count,const BKNBoundaryPair &pair,const BKNWaveBranch &branch){
  // Retired terminal alternatives stay in the calculation ledger, rather
  // than continuing to paint a false fourth/fifth on the active chart.
  if(branch.state=="wave4_terminal_revisited"||branch.state=="branch_source_invalidated"||branch.state=="intrabar_order_review")return;
  BKNWaveDegree degree;
  BKNAnalyzeWaveDegree(m_rows,m_raw,m_seconds,branch.fourth_known,count.resolution,branch.third,branch.third_price,branch.fourth,branch.fourth_price,m_decimals,degree);
  for(int ordinal=branch.extension?3:4;ordinal<=5;ordinal++){
   if(ordinal==5&&branch.fifth<0)continue;
   int a=ordinal==3?count.anchor[2]:ordinal==4?branch.third:branch.fourth;
   int b=ordinal==3?branch.third:ordinal==4?branch.fourth:branch.fifth;
   double pa=ordinal==3?count.price[2]:ordinal==4?branch.third_price:branch.fourth_price;
   double pb=ordinal==3?branch.third_price:ordinal==4?branch.fourth_price:branch.fifth_price;
   datetime known=ordinal==3?branch.third_known:ordinal==4?branch.fourth_known:branch.fifth_known;
   if(a<0||b<=a||b>=ArraySize(m_rows)||known>m_cutoff)continue;
   string role=IntegerToString(ordinal),state="native_endpoint_confirmed_count_review";
   bool provisional=(ordinal==4&&!branch.fourth_confirmed)||(ordinal==5&&!branch.fifth_confirmed);
   if(provisional)state="native_endpoint_developing";
   else if(ordinal==5&&!branch.geometry_valid)state=branch.state;
   string label="浪"+role+"? · "+(branch.extension?"第三浪扩延替代分支":"基础第三浪分支")+
    " | 独立分支 "+branch.id+" | 父计数 "+branch.parent_id+
    " | 第四浪 "+branch.correction+" | "+branch.state+" / "+branch.reason+
    " | 每条分支使用自己的3/4/5端点；作者浪级与分支选择未裁定 | "+BKNWaveDegreeLabel(degree);
   if(provisional)label+=" | 当前已收盘前缀极值：端点形成中，不能当作已完成浪";
   else if(ordinal==5&&!branch.geometry_valid)label+=" | 可能为复杂第四浪内部B；第五浪尚未确认";
   if(ordinal==5&&branch.geometry_valid){
    double h=MathAbs(count.price[1]-count.price[0]),sign=count.up?1.0:-1.0;
    label+=" | 若第三浪扩延，第五浪条件量尺从本分支4起算：0.618H1 "+DoubleToString(branch.fourth_price+sign*0.618*h,m_decimals)+
     " / 1H1 "+DoubleToString(branch.fourth_price+sign*h,m_decimals)+"；未选择预测目标";
   }
   int start=ArraySize(shapes),starts[],stops[];
   // Reviews retain a wick marker, not a falsely certified fifth-wave leg.
   bool span=ordinal<5||branch.geometry_valid||(provisional&&branch.state=="wave5_developing");
   if(branch.state=="wave4_overlap_review"||branch.state=="wave4_morphology_review")span=false;
   if(span){
    BKNFiniteSegments(m_rows,a,b,m_seconds,starts,stops);
    for(int piece=0;piece<ArraySize(starts);piece++){
     int x=starts[piece],y=stops[piece];double slope=(pb-pa)/(b-a);
     BKNShapeAppend(shapes,m_namespace,"wave_branch:"+role+":span:"+IntegerToString(piece),"wave_count","line",branch.id,"book_wave_count_span",
      m_rows[x].time,pa+slope*(x-a),m_rows[y].time,pa+slope*(y-a),known,state,label);
    }
   }
   BKNShapeAppend(shapes,m_namespace,"wave_branch:"+role+":marker","wave_count","point",branch.id,"book_wave_count_"+role,
    m_rows[b].time,pb,m_rows[b].time,pb,known,state,label);
   for(int k=start;k<ArraySize(shapes);k++){
    shapes[k].source_id=count.source_id;shapes[k].phase_id=branch.id;shapes[k].previous_phase_id=count.count_id;shapes[k].root_phase_id=pair.phase_id;
    shapes[k].leg_known=known;shapes[k].source_known=count.source_known;shapes[k].count_known=branch.state_known;
    shapes[k].count_state=branch.state;shapes[k].count_retrospective=count.retrospective;
    shapes[k].count_binding=provisional?"provisional_branch_endpoint_not_confirmed":"count_source_bound_only_author_degree_unverified";
    shapes[k].count_form=degree.form;shapes[k].count_degree=BKNWaveDegreeLabel(degree);shapes[k].count_degree_known=degree.known;
    shapes[k].pair_state="not_assessed_for_wave_count";shapes[k].assessment_known=branch.state_known;
    shapes[k].axis_review=true;shapes[k].axis_review_reason="independent_wave_branch_author_degree_unverified";
    shapes[k].construction_id="book_native_wave_branch_leg:"+BKNHash(branch.id+"|"+role+"|"+
     BKNPointKey(m_rows,a,pa,m_decimals)+">"+BKNPointKey(m_rows,b,pb,m_decimals));
   }
  }
 }
 void WaveCorrectionShapes(const BKNBookWaveCount &count,const BKNBoundaryPair &pair,const BKNWaveBranch &branch){
  BKNWaveCorrection correction;
  BKNBuildWaveCorrection(m_rows,m_raw,m_seconds,m_cutoff,count,branch,m_decimals,correction);
  if(correction.points<2||correction.state=="post_fifth_extension_or_expanded_review"||correction.state=="post_fifth_intrabar_order_review")return;
  BKNWaveDegree degree;
  int terminal=correction.points-1;
  BKNAnalyzeWaveDegree(m_rows,m_raw,m_seconds,correction.state_known,count.resolution,correction.anchor[0],correction.price[0],correction.anchor[terminal],correction.price[terminal],m_decimals,degree);
  for(int ordinal=1;ordinal<correction.points;ordinal++){
   int a=correction.anchor[ordinal-1],b=correction.anchor[ordinal];
   if(a<0||b<=a||b>=ArraySize(m_rows))continue;
   double pa=correction.price[ordinal-1],pb=correction.price[ordinal];
   datetime known=correction.known[ordinal];string role=ordinal==1?"A":ordinal==2?"B":"C";
   string state=correction.confirmed[ordinal]?"post_fifth_endpoint_confirmed_review":"native_endpoint_developing";
   string label="调整"+role+"? · "+(correction.confirmed[ordinal]?"端点确认，调整归属待核":"形成中")+
    " | 五浪分支 "+branch.id+" | "+correction.state+" / "+correction.reason+
    " | A/1、B/2、C/3仍有两种解释；非已完成调整、非已确认反转；双线及作者浪级另核 | "+BKNWaveDegreeLabel(degree);
   int start=ArraySize(shapes),starts[],stops[];BKNFiniteSegments(m_rows,a,b,m_seconds,starts,stops);
   for(int piece=0;piece<ArraySize(starts);piece++){
    int x=starts[piece],y=stops[piece];double slope=(pb-pa)/(b-a);
    BKNShapeAppend(shapes,m_namespace,"wave_correction:"+role+":span:"+IntegerToString(piece),"wave_count","line",correction.id,"book_wave_count_span",
     m_rows[x].time,pa+slope*(x-a),m_rows[y].time,pa+slope*(y-a),known,state,label);
   }
   BKNShapeAppend(shapes,m_namespace,"wave_correction:"+role+":marker","wave_count","point",correction.id,"book_wave_count_"+role,
    m_rows[b].time,pb,m_rows[b].time,pb,known,state,label);
   for(int k=start;k<ArraySize(shapes);k++){
    shapes[k].source_id=count.source_id;shapes[k].phase_id=correction.id;shapes[k].previous_phase_id=branch.id;shapes[k].root_phase_id=pair.phase_id;
    shapes[k].leg_known=known;shapes[k].source_known=count.source_known;shapes[k].count_known=correction.state_known;
    shapes[k].count_state=correction.state;shapes[k].count_retrospective=count.retrospective;
    shapes[k].count_binding="post_fifth_correction_or_opposite_impulse_unselected";
    shapes[k].count_form=degree.form;shapes[k].count_degree=BKNWaveDegreeLabel(degree);shapes[k].count_degree_known=degree.known;
    shapes[k].pair_state="not_assessed_for_wave_count";shapes[k].assessment_known=correction.state_known;
    shapes[k].axis_review=true;shapes[k].axis_review_reason="correction_degree_and_dual_break_unverified";
    shapes[k].construction_id=correction.id+"|"+role;
    shapes[k].construction_revision=BKNHash(BKNPointKey(m_rows,a,pa,m_decimals)+">"+BKNPointKey(m_rows,b,pb,m_decimals)+"|"+IntegerToString((long)known));
   }
  }
 }
 void WaveDevelopingShapes(const BKNBookWaveCount &count,const BKNBoundaryPair &pair){
  int a=count.origin,b=count.developing_index;
  if(count.status!="wave1_developing"||count.points!=1||a<0||b<=a||b>=ArraySize(m_rows))return;
  int start=ArraySize(shapes),starts[],stops[];double pa=count.price[0],pb=count.developing_price;
  string label="第一浪形成中 · 当前前缀临时极值，尚非确认A端点；不据此启动第二浪或目标"+
   " | 稳定来源 "+count.count_id+" | 观察修订 "+count.developing_revision;
  BKNFiniteSegments(m_rows,a,b,m_seconds,starts,stops);
  for(int piece=0;piece<ArraySize(starts);piece++){
   int x=starts[piece],y=stops[piece];double slope=(pb-pa)/(b-a);
   BKNShapeAppend(shapes,m_namespace,"wave1_observation:span:"+IntegerToString(piece),"wave_count","line",count.count_id,"book_wave_count_span",
    m_rows[x].time,pa+slope*(x-a),m_rows[y].time,pa+slope*(y-a),count.developing_known,"native_endpoint_developing",label);
  }
  BKNShapeAppend(shapes,m_namespace,"wave1_observation:marker","wave_count","point",count.count_id,"book_wave_count_1",
   m_rows[b].time,pb,m_rows[b].time,pb,count.developing_known,"native_endpoint_developing",label);
  for(int k=start;k<ArraySize(shapes);k++){
   shapes[k].source_id=count.source_id;shapes[k].phase_id=count.count_id;shapes[k].root_phase_id=pair.phase_id;
   shapes[k].leg_known=count.developing_known;shapes[k].source_known=count.source_known;
   shapes[k].count_known=count.known;shapes[k].count_state=count.status;shapes[k].count_retrospective=count.retrospective;
   shapes[k].count_binding="provisional_observation_not_confirmed_first_wave";
   shapes[k].pair_state="not_assessed_for_wave_count";shapes[k].assessment_known=count.known;
   shapes[k].axis_review=true;shapes[k].axis_review_reason="first_wave_terminal_unconfirmed";
   shapes[k].construction_id=count.count_id+"|first_wave_provisional";shapes[k].construction_revision=count.developing_revision;
   shapes[k].id="b"+StringSubstr(BKNHash(m_namespace+"|first_wave_provisional|"+count.count_id+"|"+shapes[k].kind+"|"+
    (shapes[k].kind=="point"?"marker":IntegerToString((long)shapes[k].a))),0,23);
  }
 }
 void WaveBacktrackShapes(const BKNBookWaveCount &count,const BKNBoundaryPair &pair){
  // Prior A alternatives are observations of a frozen predecessor interval.
  // A later developing rebound clock and prepended ledger indices must not
  // change their identity or claim that an author first wave was selected.
  int n=ArraySize(m_rows);
  if(!count.bound||!count.backtrack_review||count.count_id==""||count.source_id==""||m_seconds<=0||
     count.source_known<=0||count.source_known>m_cutoff||count.prior_origin<0||count.origin<=count.prior_origin||count.origin>=n)return;
  int kind=count.up?1:-1;
  double prior_price=BKNResponseAdverse(m_rows[count.prior_origin],count.up);
  for(int i=0;i<ArraySize(m_raw);i++){
   BKNPoint p;BKNSCopy(p,m_raw[i]);
   if(p.index<=count.prior_origin||p.index>=count.origin||p.kind!=kind||p.known>m_cutoff||
      p.time!=m_rows[p.index].time||p.known<p.time+m_seconds||
      p.price!=BKNResponseFavourable(m_rows[p.index],count.up))continue;
   datetime known=(datetime)MathMax((long)count.source_known,(long)p.known);
   string candidate="book_native_wave_backtrack:"+BKNHash(count.count_id+"|"+
    BKNPointKey(m_rows,count.prior_origin,prior_price,m_decimals)+">"+BKNPointKey(m_rows,p.index,p.price,m_decimals));
   int start=ArraySize(shapes);
   BKNShapeAppend(shapes,m_namespace,"wave_count_backtrack:marker","wave_count","point",candidate,"book_wave_count_1",
    p.time,p.price,p.time,p.price,known,"wave1_predecessor_review",
    "第一浪待选 · 此前B→A的回溯备选；不是已选第一浪，不据此启动第二浪或目标 | 来源 "+count.source_id+
    " | 候选 "+candidate+" | 原生端点可知 "+TimeToString(p.known,TIME_DATE|TIME_MINUTES));
   for(int k=start;k<ArraySize(shapes);k++){
    shapes[k].source_id=count.source_id;shapes[k].phase_id=count.count_id;shapes[k].root_phase_id=pair.phase_id;
    shapes[k].leg_known=known;shapes[k].source_known=count.source_known;shapes[k].count_known=known;
    shapes[k].count_state="wave1_predecessor_review";shapes[k].count_retrospective=count.retrospective;
    shapes[k].count_binding="predecessor_A_alternative_not_selected_first_wave";
    shapes[k].pair_state="not_assessed_for_wave_count";shapes[k].assessment_known=known;
    shapes[k].axis_review=true;shapes[k].axis_review_reason="author_predecessor_B_A_selection_unresolved";
    shapes[k].construction_id=candidate;
    shapes[k].construction_revision=BKNHash(candidate+"|"+IntegerToString((long)known)+"|wave1_predecessor_review");
   }
  }
 }
 void WaveCountShapes(const BKNScope &scope){
  // Keep adjacent native hierarchies as independent source-bound counts.
  // The first-wave endpoints must themselves survive that hierarchy.
  WaveCountAtResolution(scope,0);
  WaveCountAtResolution(scope,1);
 }
 void WaveCountAtResolution(const BKNScope &scope,int resolution){
  if(!scope.envelope||scope.ambiguous)return;
  BKNBoundary outer=BKNWholeBoundary(m_rows,scope.a.index,scope.b.index,scope.up,m_seconds,scope.known,m_cutoff);
  BKNTurning turning=BKNTurningBoundary(m_rows,scope.a.index,scope.b.index,scope.up,m_seconds,scope.known,m_cutoff,false,false);
  if(!outer.qualified||!turning.qualified)return;
  BKNSourceReference source=BKNReference(scope,m_provider,m_symbol,m_seconds);
  BKNBoundaryPair pair=BKNAssessPair(m_rows,scope,outer,source,turning,source,m_seconds,m_cutoff,m_decimals);
  BKNBookWaveCount count=BKNCountBookWaves(m_rows,m_raw,scope,outer,turning,pair,source,m_seconds,m_cutoff,m_decimals,resolution);
  if(!count.bound||count.count_id=="")return;
  if(resolution>0&&(count.status=="wave_degree_endpoints_unbound"||count.backtrack_review||count.points<2))return;
  BKNWaveBranch branches[];BKNBuildWaveBranches(m_rows,m_raw,m_seconds,m_cutoff,count,m_decimals,branches);
  count=BKNWaveBaseView(m_rows,m_raw,m_seconds,count);
  // Count resolution is the native radius2 path, not the geometry reduction
  // level or an author degree. Source-bound alternatives are never combined.
  string context="第7章原生数浪候选 · "+count.status+" | "+count.reason+
   " | 同周期原生结构层 "+IntegerToString(resolution)+"；作者浪级/3浪扩延替代计数未裁定"+
   " | 来源双破可知 "+TimeToString(count.source_known,TIME_DATE|TIME_MINUTES)+
   (count.retrospective?" · 历史来源回看":"")+
   " | 浪2 "+count.correction2+"；后续各分支有独立状态，不作入场依据";
  if(count.backtrack_review){
   WaveBacktrackShapes(count,pair);
   return;
  }
  WaveDevelopingShapes(count,pair);
  BKNBookWaveTargets targets=BKNBookWaveTargetFacts(count);
  // Never render the old first-adverse-point 4/5/ABC as the chosen count.
  // Alternative fourth terminals and third extensions own their own legs.
  for(int ordinal=1;ordinal<(int)MathMin(count.points,4);ordinal++){
   int a=count.anchor[ordinal-1],b=count.anchor[ordinal];if(a<0||b<=a)continue;
   double pa=count.price[ordinal-1],pb=count.price[ordinal];int start=ArraySize(shapes),starts[],stops[];
   datetime leg_known=(datetime)MathMax((long)count.source_known,MathMax((long)count.anchor_known[ordinal-1],(long)count.anchor_known[ordinal]));
   string leg_state=count.confirmed[ordinal]?"native_endpoint_confirmed_count_review":"native_endpoint_developing";
   if(ordinal==5&&count.failed_fifth)leg_state="failed_fifth_candidate";
   string role=ordinal<=5?IntegerToString(ordinal):(ordinal==6?"A":ordinal==7?"B":"C");
   string label="浪"+role+"? · "+(count.confirmed[ordinal]?"原生端点已确认，数浪归属待核":"端点形成中")+" | "+context+
    " | 本段 "+TimeToString(m_rows[a].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(pa,m_decimals)+"→"+
    TimeToString(m_rows[b].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(pb,m_decimals)+
    " | 端点可知 "+TimeToString(count.anchor_known[ordinal],TIME_DATE|TIME_MINUTES);
   if(ordinal==5&&count.failed_fifth)label+=" | 第五浪未超过第三浪端点：失败形态候选";
   if(ordinal==3&&targets.third_available)label+=" | 第3浪条件量尺：原第1浪H从第2浪端点投影，1H "+
    DoubleToString(targets.third_1,m_decimals)+" / 1.618H "+DoubleToString(targets.third_1618,m_decimals)+"；未选定目标";
   if(ordinal==5&&targets.fifth_available)label+=" | 若第3浪扩延：从第4浪端点投影0.618H1 "+
    DoubleToString(targets.fifth_if_third_extended_0618,m_decimals)+" / 1H1 "+DoubleToString(targets.fifth_if_third_extended_1,m_decimals)+
    " | 若第5浪扩延：1.618×原0→3量尺 "+DoubleToString(targets.fifth_if_fifth_extended_1618,m_decimals)+"；扩延情形未裁定、未选定目标";
   BKNFiniteSegments(m_rows,a,b,m_seconds,starts,stops);
   for(int piece=0;piece<ArraySize(starts);piece++){
    int x=starts[piece],y=stops[piece];double slope=(pb-pa)/(b-a);
    BKNShapeAppend(shapes,m_namespace,"wave_count:"+role+":span:"+IntegerToString(piece),"wave_count","line",count.count_id,"book_wave_count_span",
     m_rows[x].time,pa+slope*(x-a),m_rows[y].time,pa+slope*(y-a),leg_known,leg_state,label);
   }
   // Each ordinal keeps one actual wick marker even at a session boundary.
   // Span objects do not compete for duplicate ordinal captions.
   BKNShapeAppend(shapes,m_namespace,"wave_count:"+role+":marker","wave_count","point",count.count_id,"book_wave_count_"+role,
    m_rows[b].time,pb,m_rows[b].time,pb,leg_known,leg_state,label);
   for(int k=start;k<ArraySize(shapes);k++){
    shapes[k].source_id=count.source_id;shapes[k].phase_id=count.count_id;shapes[k].root_phase_id=pair.phase_id;
    // Keep each native endpoint clock separate from the later whole-count
    // outcome. A failed fifth must not relabel legs 1..4 as failed fifths.
    shapes[k].leg_known=leg_known;shapes[k].source_known=count.source_known;
    shapes[k].count_known=count.known;shapes[k].count_state=count.status;
    shapes[k].count_retrospective=count.retrospective;
    shapes[k].count_binding="count_source_bound_only_author_degree_unverified";
    shapes[k].count_degree="native_resolution="+IntegerToString(resolution)+";first_wave_endpoints_bound;author_degree_unselected";
    shapes[k].count_degree_known=count.known;
    shapes[k].pair_state="not_assessed_for_wave_count";shapes[k].assessment_known=count.known;
    shapes[k].axis_review=true;shapes[k].axis_review_reason="native_count_hypothesis_author_degree_unverified";
    shapes[k].construction_id="book_native_wave_count_leg:"+BKNHash(count.count_id+"|"+role+"|"+
     BKNPointKey(m_rows,a,pa,m_decimals)+">"+BKNPointKey(m_rows,b,pb,m_decimals));
   }
  }
  for(int branch=0;branch<ArraySize(branches);branch++){
   WaveBranchShapes(count,pair,branches[branch]);
   WaveCorrectionShapes(count,pair,branches[branch]);
  }
 }
 void ForceShape(const BKNPoint &a,const BKNPoint &b,datetime known,string scale,bool ambiguous,const BKNForce &force){
  string owner="book_native_wave:"+BKNHash(m_namespace+"|"+scale+"|"+BKNPointKey(m_rows,a.index,a.price,m_decimals)+">"+BKNPointKey(m_rows,b.index,b.price,m_decimals));
  string label=scale=="local"?"本级完整波段":"同周期大波段";
  double impulse=BKNImpulseScore(force);
  label+=" · "+BKNGradeLabel(force.observed?BKNForceGrade(impulse):"unknown")+"力度 "+(force.observed?DoubleToString(impulse,2):"?")+"/100";
  label+=" | 连续幅速工程分v2";
  if(!force.observed)label+=" | 力度未准入："+force.status;
  label+=" | A→B独立测量；后续调整不计入";
  if(force.observed){
   label+=" | 原生净幅"+DoubleToString(MathAbs(b.price-a.price),m_decimals)+" / "+IntegerToString(force.bars-1)+"间隔";
   label+=" 每间隔"+DoubleToString(MathAbs(b.price-a.price)/(force.bars-1),m_decimals)+"；前A基准ATR"+DoubleToString(force.atr,m_decimals);
   label+=" | 幅"+DoubleToString(force.height_atr,2)+"ATR 速"+DoubleToString(force.speed_atr,2)+"ATR/根";
   label+=" 效"+DoubleToString(force.efficiency*100,0)+"% 同向收"+DoubleToString(force.directional_close*100,0)+"%";
   label+=" 实体"+DoubleToString(force.body*100,0)+"% 收位"+DoubleToString(force.close_location*100,0)+"% 重叠"+DoubleToString(force.overlap*100,0)+"%";
  }
  BKNWholeSource whole;ZeroMemory(whole);BKNSCopy(whole.a,a);BKNSCopy(whole.b,b);whole.up=b.price>a.price;whole.known=known;
  BKNDelivery delivery=BKNMeasureDelivery(m_rows,whole,m_seconds,m_cutoff);
  if(delivery.coverage_available)label+=" | 全波段力度覆盖 "+DoubleToString(delivery.coverage*100,1)+"%";
  label+=" | 输送筛选 "+(delivery.valid?(delivery.admitted?"本周期工程条件具备":"未具备") :"原生输入不足或不连续")+"；非作者级别确认";
  if(ambiguous)label+=" | 内部同根先后未知";
  label+=" | 工程评分，非胜率";
  BKNShapeAppend(shapes,m_namespace,"force:"+scale,"force","line",owner,"book_native_"+scale,
    a.time,a.price,b.time,b.price,known,"completed_wave_measurement",label,force.observed,impulse);
  int last=ArraySize(shapes)-1;
   if(last>=0){
    shapes[last].delivery_measured=delivery.valid;shapes[last].delivery_qualified=delivery.admitted;shapes[last].force_coverage=delivery.coverage;
    shapes[last].owner_a=a.time;shapes[last].owner_b=b.time;shapes[last].owner_known=known;shapes[last].owner_degree=-1;
   }
  // The separate wave switch exposes this actual complete owned interval.
  // It is not a global high/low box over unrelated historical directions.
   BKNShapeAppend(shapes,m_namespace,"wave:"+scale,"wave","line",owner,"book_native_"+scale+"_scope",
   a.time,a.price,b.time,b.price,known,"native_completed_scope",
   scale=="local"?"本级完整方向波段；与本段力度共用A/B，不含后续调整":"同周期完整大波段；与本段力度共用A/B，非作者级别确认");
   last=ArraySize(shapes)-1;
   if(last>=0){shapes[last].owner_a=a.time;shapes[last].owner_b=b.time;shapes[last].owner_known=known;shapes[last].owner_degree=-1;}
 }
 void FrozenEvents(const BKNFrozenRuler &r,string owner,string family,const BKNBoundaryEvents &event){
  if(!event.evaluated)return;
  if(event.emit_contact){int k=event.contact;
   BKNShapeAppend(shapes,m_namespace,family+":contact","breakout","line",owner,"book_boundary_event",
    m_rows[k].time,m_rows[k].low,m_rows[k].time,m_rows[k].high,event.contact_known,"wick_contact","影线触线 · 尚未收破");
  }
  if(event.broken<0)return;int k=event.broken;
  int observable=r.turning?(int)MathMax(r.second,r.start+2):r.second;
  BKNBoundaryScore quality=BKNScoreBoundary(m_rows,r,observable,event.broken,m_seconds,m_cutoff,m_decimals,event.break_known);
  string caption=event.same_bar?"触线并首次收破 · 同根顺序未知":"首次收破 · 单线事实，非反转确认";
  if(quality.scored)caption+=" | 边界两根评分 "+BKNGradeLabel(quality.grade)+" "+DoubleToString(quality.score,2)+"/100 | 独立未拟合口径";
  if(quality.motion.measured)caption+=" | 当前边界 "+quality.motion.state;
  datetime break_fact=event.break_known;
  if(quality.scored)break_fact=(datetime)MathMax((double)quality.known,(double)quality.motion.known);
  BKNShapeAppend(shapes,m_namespace,family+":break","breakout","line",owner,"book_boundary_event",
    m_rows[k].time,m_rows[k].low,m_rows[k].time,m_rows[k].high,break_fact,"first_close_break",
    caption,quality.scored,quality.score);
  BKNResponse response=BKNRespondToBoundary(m_rows,r,event,m_seconds,m_cutoff);
  if(response.terminal<0||response.status=="unknown")return;
  BKNForce force=BKNMeasureForce(m_rows,m_rows[response.origin].time,response.origin_price,
   m_rows[response.terminal].time,response.terminal_price,response.known_at,m_seconds,false);
  double impulse=BKNImpulseScore(force);
  string label="首段响应 · "+BKNGradeLabel(force.observed?BKNForceGrade(impulse):"unknown")+"力度 "+(force.observed?DoubleToString(impulse,2):"?")+"/100";
  label+=" | 连续幅速工程分v2";
  if(!force.observed)label+=" | 力度未准入："+force.status;
  if(force.observed)label+=" | 原生净幅"+DoubleToString(MathAbs(response.terminal_price-response.origin_price),m_decimals)+" / "+IntegerToString(force.bars-1)+"间隔；前源ATR"+DoubleToString(force.atr,m_decimals);
  label+=" | 完整B→C；第七章作者首浪尚待独立核对";
  if(r.turning&&r.shifted)label+=" | 响应依据v2：真实E之后至首破柱的原生极值窗";
  // A response with a crossed origin/earlier terminal/gap is still an event
  // observation, but must never masquerade as a measured complete force leg.
  int response_begin=ArraySize(shapes);
  BKNShapeAppend(shapes,m_namespace,family+":response",force.observed?"force":"breakout","line",owner,"book_first_response",
   m_rows[response.origin].time,response.origin_price,m_rows[response.terminal].time,response.terminal_price,
   response.state_known_at,response.status,label,force.observed,impulse);
  if(r.turning&&r.shifted){
   string basis="book_response_native_E_v2|"+family+"|"+owner+"|"+
    BKNPointKey(m_rows,r.first,r.first_price,m_decimals)+">"+BKNPointKey(m_rows,r.second,r.second_price,m_decimals)+"@"+
    BKNPointKey(m_rows,r.start,r.start_price,m_decimals)+"|"+
    BKNPointKey(m_rows,response.origin,response.origin_price,m_decimals)+">"+
    BKNPointKey(m_rows,response.terminal,response.terminal_price,m_decimals)+"|"+
    IntegerToString((long)r.construction_known)+"|"+IntegerToString((long)event.break_known)+"|"+
    IntegerToString((long)response.state_known_at)+"|"+response.status;
   for(int i=response_begin;i<ArraySize(shapes);i++)shapes[i].construction_revision=BKNHash(basis);
  }
 }
 void FollowShapes(const BKNFrozenRuler &r,const BKNBoundaryEvents &event,string owner,string family){
  BKNFollow follow=BKNObserveFollow(m_rows,r,event,m_seconds,m_cutoff,m_decimals);
  if(!follow.evaluated)return;
  BKNStopReference stop=BKNBuildStopReference(m_rows,r,event,owner,m_seconds,m_cutoff,m_decimals);
  if(stop.observed){
   int end=stop.breached?stop.failure:stop.last;
   BKNShapeAppend(shapes,m_namespace,family+":B_stop","stop_reference","line",owner,"book_B_stop",
    m_rows[stop.origin].time,stop.price,m_rows[end].time,stop.price,stop.state_known,stop.protection,
    "第5章B参考 · 突破前最后一段的原生极值；后续回调不移动B · "+stop.protection+
    (stop.prospective?" · 来源在突破前已知":" · 历史重算来源")+"；未发生交易");
   BKNRiskFact risk=BKNMeasureRiskFact(m_rows,stop,m_seconds,m_cutoff);
   if(risk.measured)
    BKNShapeAppend(shapes,m_namespace,family+":B_risk","risk_fact","line",owner,"book_B_risk",
     m_rows[stop.last].time,risk.close_price,m_rows[stop.last].time,stop.price,risk.known,risk.status,
     "当前收盘到B距离 "+DoubleToString(risk.distance,m_decimals)+" | 近14根中位跨度 "+DoubleToString(risk.range_reference,m_decimals)+
     " | B状态 "+stop.protection+"；仓位、资金风险、盈亏比未知");
  }
  if(follow.last<=follow.broken)return;
  double price=follow.reference;int first=follow.broken,last=follow.last;
  BKNShapeAppend(shapes,m_namespace,family+":pullback","pullback","line",owner,"book_pullback",
   m_rows[first].time,price,m_rows[last].time,price,follow.known,follow.status,
   follow.retouched?"已回踩突破时固定价位；影线触及，不推断同根先后":"尚未回踩突破时固定价位");
  bool invalidated=stop.observed?stop.breached:follow.invalidated;
  int invalid_end=stop.observed?(stop.breached?stop.failure:stop.last):(follow.invalidated?follow.invalid:last);
  double invalid_price=stop.observed?stop.price:price;
  datetime invalid_known=stop.observed?stop.state_known:follow.invalid_known;
  BKNShapeAppend(shapes,m_namespace,family+":invalidation","invalidation","line",owner,"book_invalidation",
   m_rows[first].time,invalid_price,m_rows[invalid_end].time,invalid_price,invalid_known,invalidated?"invalidated":"not_invalidated",
   stop.observed?(invalidated?"已收盘K线的价格严格穿越原B；同根顺序及成交未知":"原B未被严格穿越；触及不等于失效或成交"):
    (invalidated?"收盘重新穿越突破时固定价位；未绑定第5章B止损线":"未见收盘重新穿越突破时固定价位；B止损依据待核"));
 }
 void GeometryReviewShapes(const BKNScope &scope){
  if(!scope.envelope||!BKNVerifyWaveScope(m_rows,scope,m_seconds,m_cutoff))return;
   int a=scope.a.index,b=scope.b.index;bool have_outer=false,have_turning=false,have_extension=false;
   string owner="book_native_interval:"+BKNHash(m_namespace+"|"+BKNPointKey(m_rows,a,scope.a.price,m_decimals)+">"+BKNPointKey(m_rows,b,scope.b.price,m_decimals)+"|"+IntegerToString((long)scope.known));
  for(int i=0;i<ArraySize(shapes);i++){
    bool same_scope_owner=shapes[i].owner_a==scope.a.time&&shapes[i].owner_b==scope.b.time;
    // An independent C/E source may be built from the adjacent context
    // window. Its real owner is the source's own context interval, while
    // line_host_owner keeps the current A..B interval as observation host so
    // repeated review passes do not emit the same diagnostic line again.
    bool hosted_turning=shapes[i].line_host_owner==owner&&
     (shapes[i].group=="book_CE_reference"||shapes[i].group=="book_CE_D");
    if(!same_scope_owner&&!hosted_turning)continue;
   if(shapes[i].line_family=="OUTER")have_outer=true;
   if(shapes[i].line_family=="RETURN_CE_D")have_turning=true;
   if(shapes[i].group=="book_CE_reference")have_extension=true;
  }
  // Existing admitted constructions are never replaced by review geometry.
  BKNBoundary admitted=BKNWholeBoundary(m_rows,a,b,scope.up,m_seconds,scope.known,m_cutoff);
  BKNTurning admitted_turn=BKNTurningBoundary(m_rows,a,b,scope.up,m_seconds,scope.known,m_cutoff);
  int start=ArraySize(shapes),starts[],stops[];
  if(!have_outer&&(!admitted.qualified||scope.ambiguous)){
   BKNBoundary line=BKNWholeBoundary(m_rows,a,b,scope.up,m_seconds,scope.known,m_cutoff,true);
   if(line.qualified){
    // Only the actual two-contact span, not an extrapolated full-wave trend.
    // The opposite parallel construction is shown over this same span plus
    // its own actual Q. It has no active projection or event qualification.
    for(int rail=0;rail<2;rail++){
     int begin=ArraySize(shapes),first=line.first,last=line.second;
     if(rail==1){first=(int)MathMin(first,line.parallel_contact);last=(int)MathMax(last,line.parallel_contact);}
     BKNFiniteSegments(m_rows,first,last,m_seconds,starts,stops);
     for(int k=0;k<ArraySize(starts);k++){
      BKNShapeAppend(shapes,m_namespace,"review_support:"+IntegerToString(rail)+":"+IntegerToString(k),rail==0?"trend":"channel","line",owner,
       rail==0?"book_outer_review":"book_channel_review",m_rows[starts[k]].time,BKNBoundaryLevel(line,starts[k],rail==1),
       m_rows[stops[k]].time,BKNBoundaryLevel(line,stops[k],rail==1),scope.known,"finite_geometry_review",
       "本段真实外侧构造 · 只画两触点间；内部顺序待核，不外推为全段量尺、不升级评分 | "+admitted.reason+
       " | 实点 "+TimeToString(m_rows[line.first].time,TIME_DATE|TIME_MINUTES)+"→"+TimeToString(m_rows[line.second].time,TIME_DATE|TIME_MINUTES)+
       " | 对侧Q "+TimeToString(m_rows[line.parallel_contact].time,TIME_DATE|TIME_MINUTES));
     }
     if(!BKNSetLineClocks(shapes,begin,ArraySize(shapes),rail==0?"OUTER":"CHANNEL",scope.known,scope.known,"",0,"","review_geometry_not_an_event_ruler",m_cutoff))m_failure="review_geometry_clock_invalid";
     string construction="book_native_review_support:"+BKNHash(owner+"|"+IntegerToString(rail)+"|"+
      BKNPointKey(m_rows,line.first,line.first_price,m_decimals)+">"+BKNPointKey(m_rows,line.second,line.second_price,m_decimals)+"@"+
      BKNPointKey(m_rows,line.parallel_contact,line.parallel_price,m_decimals));
      for(int k=begin;k<ArraySize(shapes);k++){
       shapes[k].construction_id=construction;
       BKNBindOuterLineEndpoints(shapes[k],scope,line,m_rows);
      }
    }
   }
  }
  if(!scope.ambiguous&&!have_turning&&!admitted_turn.qualified){
   BKNTurning turn=BKNTurningBoundary(m_rows,a,b,scope.up,m_seconds,scope.known,m_cutoff,true);
   if(turn.qualified){
    // Even a short construction needs real C/E, confirmed intervening D,
    // correct side/direction and non-crossing on the complete owned prefix.
    // Finite C..E and D..E only: no new forecast, recovery or event promotion.
    for(int rail=0;rail<2;rail++){
     int begin=ArraySize(shapes),first=rail==0?turn.c:turn.d;
     double price=rail==0?turn.c_price:turn.d_price;
      BKNFiniteSegments(m_rows,first,turn.e,m_seconds,starts,stops,true);
     for(int k=0;k<ArraySize(starts);k++){
       BKNShapeAppend(shapes,m_namespace,"review_CED:"+IntegerToString(rail)+":"+IntegerToString(k),"turning_point",starts[k]==stops[k]?"point":"line",owner,
       rail==0?"book_CE_reference":"book_CE_D",m_rows[starts[k]].time,price+turn.slope*(starts[k]-first),
       m_rows[stops[k]].time,price+turn.slope*(stops[k]-first),scope.known,"finite_geometry_review",
       (rail==0?"本段C-E源尺 · 成熟度待核；仅形成段、不作活动预测 | ":"本段C-E平移到D · 成熟度待核；仅形成段、不作活动预测 | ")+admitted_turn.reason+
       " | C "+TimeToString(m_rows[turn.c].time,TIME_DATE|TIME_MINUTES)+" | D "+TimeToString(m_rows[turn.d].time,TIME_DATE|TIME_MINUTES)+" | E "+TimeToString(m_rows[turn.e].time,TIME_DATE|TIME_MINUTES));
     }
     if(rail==1&&!BKNSetLineClocks(shapes,begin,ArraySize(shapes),"RETURN_CE_D",scope.known,scope.known,"",0,"","review_geometry_not_an_event_ruler",m_cutoff))m_failure="review_geometry_clock_invalid";
     string construction="book_native_review_CED:"+BKNHash(owner+"|"+IntegerToString(rail)+"|"+
      BKNPointKey(m_rows,turn.c,turn.c_price,m_decimals)+">"+BKNPointKey(m_rows,turn.e,turn.e_price,m_decimals)+"@"+BKNPointKey(m_rows,turn.d,turn.d_price,m_decimals));
      for(int k=begin;k<ArraySize(shapes);k++){
       shapes[k].construction_id=construction;
       BKNBindTurningLineEndpoints(shapes[k],turn,m_rows);
       bool adjacent=turn.c<a||turn.e>b||(rail==1&&(turn.d<a||turn.d>b));
       if(adjacent){
        BKNBindAdjacentLineOwner(shapes[k],scope,m_rows,turn.c,turn.e,scope.known,owner);
        shapes[k].label+=" | 相邻上下文有限复核构造；当前A/B仅为观察宿主";
       }
      }
    }
   }
  }
  for(int k=start;k<ArraySize(shapes);k++)if(shapes[k].group=="book_CE_reference")have_extension=true;
  if(!have_extension){
   BKNBoundary extension=BKNObservedExtension(m_rows,a,b,scope.up,m_seconds,scope.known,m_cutoff);
   if(extension.qualified){
    int begin=ArraySize(shapes);
     bool extension_adjacent=extension.first<a||extension.second>b;
     string extension_owner=extension_adjacent?
      "book_native_adjacent_context:"+BKNHash(m_namespace+"|"+
       BKNPointKey(m_rows,extension.first,extension.first_price,m_decimals)+">"+
       BKNPointKey(m_rows,extension.second,extension.second_price,m_decimals)):
      owner;
    // This is ONLY an observed two-contact source, with no qualified D.
    // Even a good axis fit does not license extending it past its second
    // real touch as a correction forecast. Qualified C/E -> D projection
    // is separately constructed and keeps its own lifecycle.
    int extension_end=extension.second;
     BKNFiniteSegments(m_rows,extension.first,extension_end,m_seconds,starts,stops,true);
    for(int k=0;k<ArraySize(starts);k++){
      BKNShapeAppend(shapes,m_namespace,"observed_extension:"+IntegerToString(k),"turning_point",starts[k]==stops[k]?"point":"line",owner,"book_CE_reference",
      m_rows[starts[k]].time,BKNBoundaryLevel(extension,starts[k],false),m_rows[stops[k]].time,BKNBoundaryLevel(extension,stops[k],false),
      scope.known,"independent_extension_observation",
      (scope.up?"上侧独立外延源线":"下侧独立外延源线")+" · 由本波段真实外侧两点计算；对应D/顺序未成立，不画平移目标、不作双线突破依据"+
      " | 仅真实两触点间，不作为平移目标延伸"+(extension.axis_drift>0.5?" | 与本段中轴偏离":"")+
      " | 实点 "+TimeToString(m_rows[extension.first].time,TIME_DATE|TIME_MINUTES)+"→"+TimeToString(m_rows[extension.second].time,TIME_DATE|TIME_MINUTES));
    }
    string evidence=BKNAxisEvidence(m_rows,a,b,scope.known,extension.axis_slope,extension.axis_ols,
     extension.first,extension.second,extension.alternate_first,extension.alternate_second,extension.axis_model_state);
    for(int k=begin;k<ArraySize(shapes);k++){
      shapes[k].construction_id="book_native_extension_observation:"+BKNHash(extension_owner+"|host="+owner+"|"+
      BKNPointKey(m_rows,extension.first,extension.first_price,m_decimals)+">"+BKNPointKey(m_rows,extension.second,extension.second_price,m_decimals));
      shapes[k].source_id=owner;
      if(extension_adjacent){
       BKNBindAdjacentLineOwner(shapes[k],scope,m_rows,extension.first,extension.second,scope.known,owner);
       shapes[k].label+=" | C/E来自相邻上下文；当前A/B仅为观察宿主；不参与结构/事件/配对/评分";
      }else{
       shapes[k].line_owner_relation="same_owner";
       shapes[k].line_host_owner=owner;shapes[k].line_host_a=scope.a.time;shapes[k].line_host_b=scope.b.time;
       shapes[k].owner_a=scope.a.time;shapes[k].owner_b=scope.b.time;
       shapes[k].owner_known=scope.known;shapes[k].owner_degree=scope.degree;
      }
     shapes[k].axis_evidence=evidence;
     shapes[k].construction_revision=BKNHash(shapes[k].construction_id+"|observed_native_extrema_v2|"+evidence);
     shapes[k].label+=" | C/E均核对本周期原生峰谷；D未确认，不作回调目标";
     if(extension.axis_model_state=="estimator_disagreement")shapes[k].label+=" | 中轴估计选点有分歧";
       BKNSetLineEndpoint(m_rows,extension.first,extension.first_price,shapes[k].line_c_index,shapes[k].line_c_time,shapes[k].line_c_price);
       BKNSetLineEndpoint(m_rows,extension.second,extension.second_price,shapes[k].line_e_index,shapes[k].line_e_time,shapes[k].line_e_price);
    }
   }
  }
  for(int k=start;k<ArraySize(shapes);k++){
   if(!admitted.qualified&&(shapes[k].group=="book_CE_reference"||shapes[k].group=="book_CE_D")){
    shapes[k].line_admission_mode="source_only_without_outer";
    shapes[k].label+=" | 外侧量尺未准入；工程源线诊断，非活动拐点或结构确认";
   }
    if(shapes[k].line_owner_relation!="adjacent_context"){
     shapes[k].owner_a=scope.a.time;shapes[k].owner_b=scope.b.time;shapes[k].owner_known=scope.known;shapes[k].owner_degree=scope.degree;
     shapes[k].source_id=owner;
    }
    shapes[k].axis_review=true;shapes[k].axis_review_reason="geometry_visible_admission_pending";
   shapes[k].line_display_basis="finite_real_contacts_no_admission_or_projection";
  }
 }
 void GeometryShape(const BKNScope &scope,bool allow_successors=true,bool four_families_only=false){
  int shape_start=ArraySize(shapes);
  int a=scope.a.index,b=scope.b.index;bool up=scope.up;
  if(!scope.envelope||a<0||b<=a)return;
  // Different producers can witness the same native complete A/B interval.
  // Render it once, without conflating other endpoints sharing only origin A.
  bool already_drawn=false;
  for(int i=0;i<ArraySize(m_drawn_geometry);i++)
   if(m_drawn_geometry[i].a.time==scope.a.time&&m_drawn_geometry[i].b.time==scope.b.time&&
      m_drawn_geometry[i].a.price==scope.a.price&&m_drawn_geometry[i].b.price==scope.b.price&&m_drawn_geometry[i].up==up){already_drawn=true;break;}
  if(already_drawn&&!allow_successors)return;
  if(!BKNVerifyWaveScope(m_rows,scope,m_seconds,m_cutoff))return;
  BKNBoundary line=BKNWholeBoundary(m_rows,a,b,up,m_seconds,scope.known,m_cutoff);
  // A detail renderer may have emitted this exact A/B before its connected
  // source reaches the event path. Display deduplication must not suppress
  // the independently verified successor seed. Queue deduplicates roots.
  if(allow_successors&&line.qualified&&!scope.ambiguous)QueueSuccessor(scope,line);
  if(already_drawn)return;
  // Freeze Chapter-4 C/E/D formation at the first opposite close break of
  // the outer ruler.  Bars after that break are lifecycle observations only;
  // they must not improve or relocate the historical turning construction.
  BKNFrozenRuler outer_ruler;ZeroMemory(outer_ruler);
  BKNBoundaryEvents outer_event;ZeroMemory(outer_event);
  int turning_formation_last=b;
  if(line.qualified){
   outer_ruler=BKNFreezeOuter(line);
   outer_event=BKNScanBoundary(m_rows,outer_ruler,m_seconds,m_cutoff,m_decimals);
   // Q is a formation anchor, not a later observation. Re-evaluate only the
   // parallel reference window through the first opposite close break; the
   // outer A/B candidate itself remains frozen. If the frozen pass keeps the
   // same A/B identity, its Q replaces the full-owner provisional Q.
   if(outer_event.broken>line.second){
    BKNBoundary q_frozen=BKNWholeBoundary(m_rows,a,b,up,m_seconds,scope.known,m_cutoff,false,outer_event.broken-1);
    if(q_frozen.qualified&&q_frozen.first==line.first&&q_frozen.second==line.second){
     line.parallel_contact=q_frozen.parallel_contact;
     line.parallel_offset=q_frozen.parallel_offset;
     line.parallel_price=q_frozen.parallel_price;
    }
   }
   if(outer_event.broken>=0)turning_formation_last=outer_event.broken-1;
  }
  BKNTurning turning=BKNTurningBoundary(m_rows,a,b,up,m_seconds,scope.known,m_cutoff,false,true,turning_formation_last);
  bool ce_source_adjacent=turning.qualified&&(turning.c<a||turning.e>b);
  bool ce_d_adjacent=turning.qualified&&(ce_source_adjacent||turning.d<a||turning.d>b);
  bool source_only_without_outer=turning.qualified&&!line.qualified;
  if(!line.qualified&&!turning.qualified)return;
  BKNScopeAppend(m_drawn_geometry,scope);
  string owner="book_native_interval:"+BKNHash(m_namespace+"|"+BKNPointKey(m_rows,a,scope.a.price,m_decimals)+">"+BKNPointKey(m_rows,b,scope.b.price,m_decimals)+"|"+IntegerToString((long)scope.known));
  int starts[],stops[];
  if(line.qualified){
  bool outer_axis_disagreement=line.axis_model_state=="estimator_disagreement";
  string outer_axis_evidence=BKNAxisEvidence(m_rows,a,b,scope.known,line.axis_slope,line.axis_ols,
   line.first,line.second,line.alternate_first,line.alternate_second,line.axis_model_state);
  BKNChannelQuality q=BKNMeasureChannel(m_rows,line,m_seconds,m_cutoff);
  string anchors=" | 所属段 "+TimeToString(m_rows[a].time,TIME_DATE|TIME_MINUTES)+"→"+TimeToString(m_rows[b].time,TIME_DATE|TIME_MINUTES);
  anchors+=" | 外侧实点 "+TimeToString(m_rows[line.first].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(line.first_price,m_decimals);
  anchors+="→"+TimeToString(m_rows[line.second].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(line.second_price,m_decimals);
  anchors+=" | 原生斜率 "+DoubleToString(line.slope,10)+"/bar";
  string description="所属完整波段外侧两点 · 原生几何层级"+IntegerToString(scope.degree)+" · 原生中轴比较"+(line.axis_review?" · 轴线偏差待复核":"")+anchors;
  if(outer_axis_disagreement)description+=" | 中轴估计选点有分歧；保留本段真实构造，不向后延伸";
  // outer_ruler/outer_event were frozen before turning formation above.
  // The optional OUTER-Q auxiliary rail begins at its actual Q contact.
  // The independent C-E source rail is emitted separately as book_CE_reference.
  // A reviewed slope may show its two real contacts, but cannot project a
  // corridor by extrapolating a disputed axis even inside the owned span.
  BKNFiniteSegments(m_rows,line.first,line.axis_review?line.second:b,m_seconds,starts,stops);
  for(int k=0;k<ArraySize(starts);k++){
   int first=starts[k],last=stops[k];
   BKNShapeAppend(shapes,m_namespace,"outer:"+IntegerToString(k),"trend","line",owner,"book_owned_axis",
    m_rows[first].time,BKNBoundaryLevel(line,first,false),m_rows[last].time,BKNBoundaryLevel(line,last,false),scope.known,"native_owned_boundary",description);
  }
  LineClocks(shape_start,"OUTER",line.known_at,scope.known,outer_event);
  for(int k=shape_start;k<ArraySize(shapes);k++){
   // Segment IDs describe drawing pieces; construction identity belongs to
   // the frozen support anchors shared by every piece of this same ruler.
   shapes[k].construction_id="book_native_outer:"+BKNHash(owner+"|"+
    BKNPointKey(m_rows,line.first,line.first_price,m_decimals)+">"+
    BKNPointKey(m_rows,line.second,line.second_price,m_decimals));
   shapes[k].axis_review=line.axis_review;shapes[k].axis_review_reason=line.axis_review_reason;
  }
  int channel_start=ArraySize(shapes);
  BKNProjection channel_projection=BKNObserveChannelProjection(m_rows,outer_ruler,b,line.parallel_contact,
   line.parallel_price,line.axis_review,m_seconds,m_cutoff,m_decimals);
  if(!channel_projection.valid){m_failure=channel_projection.reason;return;}
  int contact=channel_projection.event_bar,end=channel_projection.end;string display_basis=channel_projection.basis;
  // Once the next independently confirmed path leg exists, this completed
  // wave's channel belongs to A..B. It must not remain an active projection
  // across that following wave merely because its old supporting rail has
  // not yet been crossed. This retires DISPLAY only, never the parent trend
  // or its frozen historical events. Preserve the dependency's known time.
  datetime successor_scope_known=BKNFollowingScopeKnown(scope,m_owned_geometry,m_cutoff);
  end=BKNLineContractDisplayEnd("CHANNEL",b,end,channel_projection.event_bar,
   outer_axis_disagreement||line.axis_review,successor_scope_known,display_basis);
  if(successor_scope_known>0)contact=-1;
  // The competing estimator does not replace this ruler or inherit its
  // events. Retain the full owned corridor but withhold a disputed forecast.
  if(outer_axis_disagreement)display_basis="axis_model_disagreement_owned_corridor_only";
  // A review flag limits the line to its owned wave, but must not collapse a
  // real Q→B channel into a single point.  The channel contract also clamps
  // ordinary projections at B: later candles are a new owner and cannot be
  // painted as a continuation of this blue rail.
  if(line.axis_review)display_basis="axis_review_owned_anchor_to_B_finite";
   // Keep the blue rail attached to this exact A→B wave.  An open
   // projection may observe later candles, but those candles belong to a
   // successor wave and must get a new owner/line instead of extending this
   // one across the next segment.
  // The unified end policy above is authoritative and intentionally finite
  // for CHANNEL. Keep this variable for the receipt/diagnostic path; it must
  // never extend the display end beyond the owned B.
  datetime channel_known=(datetime)MathMax((double)scope.known,(double)(m_rows[end].time+m_seconds));
  if(successor_scope_known>0)channel_known=(datetime)MathMax((double)channel_known,(double)successor_scope_known);
  if(contact>=0)channel_known=(datetime)MathMax((double)channel_known,(double)(m_rows[contact].time+m_seconds));
   bool owner_retired=successor_scope_known>0;
   datetime channel_event_known=owner_retired?0:channel_projection.known;
   string channel_event_kind=owner_retired?"unknown":channel_projection.event_kind;
   string channel_event_unknown=owner_retired?"successor_owner_retired":channel_projection.reason;
  // This is the legacy OUTER-Q auxiliary channel. Keep its true Q origin;
  // the independent C-E source line is the default visible channel family.
  BKNChannelSegments(m_rows,line.parallel_contact,end,m_seconds,starts,stops);
  for(int k=0;k<ArraySize(starts);k++){
   int first=starts[k],last=stops[k];
   bool channel_score_admitted=q.valid&&!q.axis_review&&q.quality!="review_pending";
   string channel_score_text=channel_score_admitted?DoubleToString(q.score,1)+"/100":"复核中";
   BKNShapeAppend(shapes,m_namespace,"channel:"+IntegerToString(k),"channel",first==last?"point":"line",owner,"book_owned_axis",
    m_rows[first].time,BKNBoundaryLevel(line,first,true),m_rows[last].time,BKNBoundaryLevel(line,last,true),channel_known,q.quality,
    "通道几何 · "+BKNGradeLabel(q.grade)+" "+channel_score_text+" | "+q.reason+" | 原生外侧平移；非作者状态确认"+anchors+
    " | 对侧平移实点Q "+TimeToString(m_rows[line.parallel_contact].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(line.parallel_price,m_decimals),channel_score_admitted,channel_score_admitted?q.score:0);
   int channel_shape=ArraySize(shapes)-1;if(channel_shape>=0){shapes[channel_shape].line_display_basis=display_basis;shapes[channel_shape].axis_review=q.axis_review;shapes[channel_shape].axis_review_reason=q.axis_review_reason;}
  }
   if(!BKNSetLineClocks(shapes,channel_start,ArraySize(shapes),"CHANNEL",line.known_at,channel_known,"",channel_event_known,
    channel_event_kind,channel_event_unknown,m_cutoff))m_failure="channel_projection_clock_invalid";
  for(int k=channel_start;k<ArraySize(shapes);k++){
   shapes[k].line_display_basis=display_basis;
    shapes[k].event_occurrence_known=owner_retired?0:channel_projection.occurrence;
   shapes[k].construction_id="book_native_channel:"+BKNHash(owner+"|"+
    BKNPointKey(m_rows,line.first,line.first_price,m_decimals)+">"+
    BKNPointKey(m_rows,line.second,line.second_price,m_decimals)+"@"+
    BKNPointKey(m_rows,line.parallel_contact,line.parallel_price,m_decimals));
  }
  // Do not emit a second historical corridor here. The primary channel now
  // owns the whole finite line from its outer anchor through its lifecycle;
  // a second group with the same endpoints created duplicate MT5 geometry
  // and hid the actual origin behind a toggle.
  for(int k=shape_start;k<ArraySize(shapes);k++){
   shapes[k].axis_evidence=outer_axis_evidence;
   shapes[k].construction_revision=BKNHash(shapes[k].construction_id+"|"+outer_axis_evidence+"|axis_observation_v1");
   if(outer_axis_disagreement&&shapes[k].layer=="channel")shapes[k].label+=" | 中轴估计选点有分歧；通道限于原所属波段，不向后延伸";
  }
  if(!four_families_only){
   FrozenEvents(outer_ruler,owner,"outer",outer_event);
   FollowShapes(outer_ruler,outer_event,owner,"outer");
  }
  } // Independent finite C/E -> D geometry remains visible without OUTER.
  BKNSourceReference outer_source=BKNReference(scope,m_provider,m_symbol,m_seconds),turning_source=outer_source;
  BKNBoundaryPair pair=BKNAssessPair(m_rows,scope,line,outer_source,turning,turning_source,m_seconds,m_cutoff,m_decimals);
  if(!line.qualified&&turning.qualified){
   // An independent C/E/D still owns a native interval and construction.
   // Do not manufacture an OUTER id or a two-boundary qualification.
   string market=m_provider+"|"+m_symbol+"|"+IntegerToString(m_seconds)+"|";
   string wave=BKNPointKey(m_rows,a,scope.a.price,m_decimals)+">"+BKNPointKey(m_rows,b,scope.b.price,m_decimals);
   pair.source_id="book_native_declared_scope:"+BKNHash(market+wave);
   pair.phase_id="";pair.turning_id="";pair.pair_id="";
   pair.known=turning.known_at;pair.construction_known=turning.known_at;
   pair.state="independent_CE_D_without_qualified_outer";
  }
  BKNStructure structure=BKNJudgeStructure(m_rows,scope,line,turning,outer_source,m_seconds,m_cutoff,m_decimals);
  // OUTER/Q exist independently of C/E/D. Bind before the no-turning early
  // return, otherwise valid Q channels are stamped as missing-anchor lines.
  for(int k=shape_start;k<ArraySize(shapes);k++)
   if(shapes[k].line_family=="OUTER"||shapes[k].line_family=="CHANNEL")BKNBindOuterLineEndpoints(shapes[k],scope,line,m_rows);
  if(!turning.qualified){BindScopeShapes(shape_start,pair,structure);return;}
  string turning_axis_evidence=BKNAxisEvidence(m_rows,a,turning.terminal,scope.known,turning.axis,turning.axis_ols,
   turning.c,turning.e,turning.alternate_c,turning.alternate_e,turning.axis_model_state);
  bool turning_axis_disagreement=turning.axis_model_state=="estimator_disagreement";
  bool turning_axis_review=turning.axis_drift>0.5;
  // Show the actual independent C/E source ruler, not only its D-shifted
  // projection (which may terminate almost immediately). This finite
  // construction is neither CHANNEL nor a second successor/entry signal.
  // It shares the existing turning-point toggle and never extends beyond E.
    BKNFiniteSegments(m_rows,turning.c,turning.e,m_seconds,starts,stops,true);
  int ce_reference_start=ArraySize(shapes);
  for(int k=0;k<ArraySize(starts);k++){
   int first=starts[k],last=stops[k];
    BKNShapeAppend(shapes,m_namespace,"CE_reference:"+IntegerToString(k),"turning_point",first==last?"point":"line",owner,"book_CE_reference",
    m_rows[first].time,turning.c_price+turning.slope*(first-turning.c),
    m_rows[last].time,turning.c_price+turning.slope*(last-turning.c),turning.known_at,
    "independent_CE_source_ruler",
    "拐点构造的真实外侧C-E；虚线为源尺，不是平移到D的拐点线，不是后继线"+
    " | C "+TimeToString(m_rows[turning.c].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(turning.c_price,m_decimals)+
    " | E "+TimeToString(m_rows[turning.e].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(turning.e_price,m_decimals)+
    " | 原调整D "+TimeToString(m_rows[turning.d].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(turning.d_price,m_decimals));
  }
  for(int k=ce_reference_start;k<ArraySize(shapes);k++)
   shapes[k].construction_id="book_native_ce_reference:"+BKNHash(owner+"|"+
    BKNPointKey(m_rows,turning.c,turning.c_price,m_decimals)+">"+
    BKNPointKey(m_rows,turning.e,turning.e_price,m_decimals));
  // The C-E source ruler is a real historical construction with its own
  // formation/display clock. It is not a RETURN_CE_D event line, but leaving
  // it unclocked made a consumer unable to distinguish a known source ruler
  // from an unbound turning candidate.
  if(!BKNSetLineClocks(shapes,ce_reference_start,ArraySize(shapes),"CE_SOURCE",
     turning.known_at,turning.known_at,"",0,"unknown","source_reference_no_event_evaluation",m_cutoff)){
   m_failure="ce_source_clock_invalid";return;
  }
  for(int k=ce_reference_start;k<ArraySize(shapes);k++)
   shapes[k].line_display_basis="finite_CE_source_C_to_E";
  int turning_start=ArraySize(shapes);
  // D..E has already passed full support validation (including legal extra
  // tangent contacts). Only a contact AFTER formation terminates projection.
  // Event clocks remain independent; this does not backdate construction.
  BKNProjection turning_projection=BKNObserveTurningProjection(m_rows,turning,m_seconds,m_cutoff,m_decimals);
  if(!turning_projection.valid){m_failure=turning_projection.reason;return;}
   int turning_end=turning_projection.end,turning_contact=turning_projection.contact,turning_resume=turning_projection.resume;
   // Keep the purple C-E→D projection attached to this exact A→B owner.
   // Later correction/recovery phases get their own construction instead of
   // silently extending this wave into the next one.
   datetime turning_successor_scope_known=BKNFollowingScopeKnown(scope,m_owned_geometry,m_cutoff);
   bool turning_owner_retired=turning_successor_scope_known>0;
   // A CE_D projection may continue after B until its own first contact or
   // confirmed resumption. A confirmed successor retires this owner's active
   // display; absent that lifecycle fact, do not truncate the line at B.
   turning_end=BKNLineContractDisplayEnd("CE_D",b,turning_end,turning_projection.event_bar,
    turning_axis_review||turning_axis_disagreement,turning_successor_scope_known,turning_projection.basis);
   if(turning_owner_retired){turning_contact=-1;turning_resume=-1;}
  // Chapter 4 C/E -> D observes the correction AFTER E. Source A..B
  // determines ownership/anchors, not an automatic end to that observation.
  // The already-frozen ruler stops at the first observed contact or the
  // current closed cutoff; no ray, later anchor substitution, or price cap.
  datetime turning_fact=turning.known_at;
  if(turning_end>=0)turning_fact=(datetime)MathMax((double)turning_fact,(double)(m_rows[turning_end].time+m_seconds));
  if(turning_resume>=0)turning_fact=(datetime)MathMax((double)turning_fact,(double)(m_rows[turning_resume].time+m_seconds));
   if(turning_contact>=0)turning_fact=(datetime)MathMax((double)turning_fact,(double)(m_rows[turning_contact].time+m_seconds));
   datetime turning_event_known=turning_owner_retired?0:turning_projection.known;
   string turning_event_kind=turning_owner_retired?"unknown":turning_projection.event_kind;
   string turning_event_unknown=turning_owner_retired?"successor_owner_retired":turning_projection.reason;
  // Chapter 4: the original D-shift within C..E is a construction, not
  // a prediction made at D. An observable projection can only start at the
  // first native candle opening at/after the construction became known.
  // Apply the same engineering axis-review band as OUTER: keep the real
  // finite construction visible, but do not project a disputed slope.
  int projection_first=turning.terminal+1;
  while(projection_first<ArraySize(m_rows)&&m_rows[projection_first].time<turning.known_at)projection_first++;
  int history_count=0;
  for(int role=0;role<2;role++){
  bool history=role==0;
   if(!history&&(source_only_without_outer||ce_d_adjacent||turning_axis_review||turning_axis_disagreement||projection_first>turning_end))continue;
  // The historical shifted ruler continues from D through the established
  // opposite extreme (the turning terminal), not merely to E. E is the
  // second source contact; stopping there leaves the whole E→terminal part
  // of the Book turning line absent before the prospective observation.
  int history_end=(int)MathMax(turning.e,turning.terminal);
   BKNChannelSegments(m_rows,history?turning.d:projection_first,history?history_end:turning_end,m_seconds,starts,stops,history);
  for(int k=0;k<ArraySize(starts);k++){
   int first=starts[k],last=stops[k];
   BKNShapeAppend(shapes,m_namespace,(history?"turning_construction:":"turning_projection:")+IntegerToString(k),"turning_point",first==last?"point":"line",owner,"book_CE_D",
    m_rows[first].time,BKNTurningLevel(turning,first),m_rows[last].time,BKNTurningLevel(turning,last),history?turning.known_at:turning_fact,history?"historical_CE_D_construction":turning_contact>=0?"stopped_before_price_contact":turning_resume>=0?"correction_resumed_before_target":"projected_candidate",
     "独立C-E平移到D · 所属A→B "+TimeToString(m_rows[a].time,TIME_DATE|TIME_MINUTES)+"→"+TimeToString(m_rows[b].time,TIME_DATE|TIME_MINUTES)+
     (source_only_without_outer?" · 外侧量尺未准入；工程源线诊断，评分未知":ce_d_adjacent?" · 相邻上下文有限构造；当前来源评分未知":
      " · "+BKNGradeLabel(turning.grade)+" "+DoubleToString(turning.score,1)+"/100 | 几何评分，非反转许可")+
    " | C "+TimeToString(m_rows[turning.c].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(turning.c_price,m_decimals)+
    " | E "+TimeToString(m_rows[turning.e].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(turning.e_price,m_decimals)+
    " | 原调整D "+TimeToString(m_rows[turning.d].time,TIME_DATE|TIME_MINUTES)+"@"+DoubleToString(turning.d_price,m_decimals)+
    (history?" | 有限构造D至所属波段终点；不是D时刻已知的预测":" | 确认可知之后的冻结投影")+
    (!history&&turning_resume>=0?" | 回调已确认且收盘恢复越过原终点，停止本次回调目标；不替换来源": "")+
    (turning_axis_review?" | 斜率偏离本段中轴，保留构造待核、不作延伸":"")+
    (turning_axis_disagreement?" | 中轴估计选点有分歧；保留C/E/D实点构造，不作回调目标延伸":""),!history&&turning_contact<0&&turning_resume<0,turning.score);
   int index=ArraySize(shapes)-1;
   shapes[index].axis_review=turning_axis_review;
   shapes[index].axis_review_reason=turning_axis_review?"normalized_axis_drift_over_engineering_review_band":"";
   if(history)history_count++;
  }
  }
  BKNFrozenRuler turning_ruler=BKNFreezeTurning(turning);
  BKNBoundaryEvents turning_event=BKNScanBoundary(m_rows,turning_ruler,m_seconds,m_cutoff,m_decimals);
  // Retrospective D..E construction and prospective correction observation
  // have independent clocks. Future contact cannot rewrite the old geometry.
  if(!BKNSetLineClocks(shapes,turning_start,turning_start+history_count,"RETURN_CE_D",turning.known_at,turning.known_at,"",0,
   "unknown",turning_axis_review?"axis_review_no_active_projection":"historical_construction_no_event_evaluation",m_cutoff))m_failure="turning_history_clock_invalid";
   if(!BKNSetLineClocks(shapes,turning_start+history_count,ArraySize(shapes),"RETURN_CE_D",turning.known_at,turning_fact,"",turning_event_known,
    turning_event_kind,turning_event_unknown,m_cutoff))m_failure="turning_projection_clock_invalid";
   for(int k=turning_start+history_count;k<ArraySize(shapes);k++)shapes[k].event_occurrence_known=turning_owner_retired?0:turning_projection.occurrence;
  for(int k=turning_start;k<ArraySize(shapes);k++)
   shapes[k].construction_id="book_native_ce_d:"+BKNHash(owner+"|"+
    BKNPointKey(m_rows,turning.c,turning.c_price,m_decimals)+">"+
    BKNPointKey(m_rows,turning.e,turning.e_price,m_decimals)+"@"+
    BKNPointKey(m_rows,turning.d,turning.d_price,m_decimals));
  for(int k=turning_start;k<ArraySize(shapes);k++)
   shapes[k].line_display_basis=k<turning_start+history_count?"finite_CE_D_construction_D_to_terminal":
    turning_contact>=0?"known_CE_D_projection_stopped_before_first_contact":turning_resume>=0?"known_CE_D_projection_stopped_before_confirmed_resumption":"known_CE_D_projection_closed_prefix";
  for(int k=ce_reference_start;k<ArraySize(shapes);k++){
   if(source_only_without_outer){
    shapes[k].line_admission_mode="source_only_without_outer";
    if(shapes[k].group=="book_CE_reference")shapes[k].label+=" | 外侧量尺未准入；工程源线诊断，非活动拐点或结构确认";
   }
   shapes[k].axis_evidence=turning_axis_evidence;
   shapes[k].construction_revision=BKNHash(shapes[k].construction_id+"|"+turning_axis_evidence+"|axis_observation_v1");
    // Axis disagreement suppresses the active projection only. The historical
    // D-shift construction keeps its own canonical D→terminal basis so a
    // review flag cannot silently change which line was actually drawn.
  }
  if(turning_resume>=0){
   datetime occurrence=m_rows[turning_resume].time+m_seconds;
   for(int k=turning_start+history_count;k<ArraySize(shapes);k++){
    shapes[k].event_occurrence_known=occurrence;
    shapes[k].event_id="book_native_correction_resume:"+BKNHash(shapes[k].construction_id+"|"+IntegerToString((long)occurrence));
    shapes[k].label+=" | 恢复事件 "+TimeToString(occurrence,TIME_DATE|TIME_MINUTES)+(turning_contact>=0?" | 同K触线与恢复，先后未知":"");
   }
  }
   // BKNTurningBoundary may use a bounded adjacent context to recover the
   // real C/E/D sequence. Such a line remains useful as a finite diagnostic,
   // but its owner is the actual context C..E interval, never the selected
   // A..B host. Mark it before BindScopeShapes stamps pair/structure fields so
   // every later consumer receives the same owner_relation gate.
   if(ce_source_adjacent||ce_d_adjacent){
    for(int k=ce_reference_start;k<ArraySize(shapes);k++){
     if(shapes[k].group!="book_CE_reference"&&shapes[k].group!="book_CE_D")continue;
     bool adjacent=(shapes[k].group=="book_CE_reference"&&ce_source_adjacent)||
      (shapes[k].group=="book_CE_D"&&ce_d_adjacent);
     if(!adjacent)continue;
     int context_last=shapes[k].group=="book_CE_reference"?turning.e:(int)MathMax(turning.e,turning.terminal);
     BKNBindAdjacentLineOwner(shapes[k],scope,m_rows,turning.c,context_last,turning.known_at,owner);
     shapes[k].label+=" | C/E/D来自相邻上下文；当前A/B仅为观察宿主；不参与结构/事件/配对/评分";
    }
   }
  if(!four_families_only&&!turning_axis_review&&!ce_d_adjacent&&!source_only_without_outer){
   FrozenEvents(turning_ruler,owner,"turning",turning_event);
   FollowShapes(turning_ruler,turning_event,owner,"turning");
  }
   for(int k=shape_start;k<ArraySize(shapes);k++){
    if(shapes[k].line_family=="OUTER"||shapes[k].line_family=="CHANNEL")BKNBindOuterLineEndpoints(shapes[k],scope,line,m_rows);
    if(shapes[k].line_family=="CE_SOURCE"||shapes[k].line_family=="RETURN_CE_D")BKNBindTurningLineEndpoints(shapes[k],turning,m_rows);
   }
  // Only this scope's newly appended objects are visited. Never rescan the
  // full historical scene for every pair, or merge geometry/observation clocks.
  BindScopeShapes(shape_start,pair,structure);
  // Adjacent context remains finite drawing evidence. It cannot seed a
  // recovery or follow/stop phase for the current host wave.
  if(ce_d_adjacent||source_only_without_outer)return;
  BKNRecovery recovery=BKNRecoveryProjection(m_rows,turning,owner,m_seconds,m_cutoff,m_decimals);
  // DF->C is a separate recovery construction. Its display extent belongs
  // to its own first terminal event or closed prefix, not to the parent
  // A->B owner. Clamping it to B erased the very post-owner recovery that
  // this phase is meant to show.
  int recovery_display_end=recovery.display_end;
  if(!recovery.qualified||recovery_display_end<=recovery.c)return;
  int recovery_start=ArraySize(shapes);
  BKNFiniteSegments(m_rows,recovery.c,recovery_display_end,m_seconds,starts,stops);
  for(int k=0;k<ArraySize(starts);k++){
   int first=starts[k],last=stops[k];
   BKNShapeAppend(shapes,m_namespace,"recovery:"+IntegerToString(k),"turning_point","line",owner,"book_DF_C",
    m_rows[first].time,recovery.c_price+recovery.slope*(first-recovery.c),m_rows[last].time,recovery.c_price+recovery.slope*(last-recovery.c),
    recovery.known,recovery.status,"恢复目标D-F平移到原C | "+recovery.status+" | "+recovery.event_order);
  }
  // Recovery is a separate construction and lifecycle phase. Preserve its
  // parent identity, construction clock and observed terminal clock in the
  // same Shape record used by the native chart/export consumers.
  // Native times and prices survive left-window shifts; local array indices do not.
  string recovery_id="book_native_recovery:"+BKNHash(owner+"|"+
   BKNPointKey(m_rows,recovery.c,recovery.c_price,m_decimals)+"|"+
   BKNPointKey(m_rows,recovery.d,recovery.d_price,m_decimals)+"|"+
   BKNPointKey(m_rows,recovery.e,turning.e_price,m_decimals)+"|"+
   BKNPointKey(m_rows,recovery.f,recovery.f_price,m_decimals));
   int recovery_event_bar=(int)MathMax(recovery.target_contact,MathMax(recovery.source_contact,recovery.invalid));
  // Occurrence belongs to the actual terminal candle. state_known may be
  // later because C/D/E/F or the parent source was confirmed afterwards.
  // Pending targets have no terminal occurrence or terminal-event identity.
  datetime recovery_occurrence=recovery_event_bar>=0?m_rows[recovery_event_bar].time+m_seconds:0;
  string recovery_event_id=recovery_event_bar>=0?"book_native_recovery_event:"+
   BKNHash(recovery_id+"|"+recovery.status+"|"+IntegerToString((long)recovery_occurrence)):"";
  for(int k=recovery_start;k<ArraySize(shapes);k++){
   shapes[k].construction_id=recovery_id;shapes[k].construction_revision=identity;
   shapes[k].event_occurrence_known=recovery_occurrence;
   shapes[k].event_id=recovery_event_id;
   if(recovery_occurrence>0&&recovery_occurrence<recovery.construction_known)
    shapes[k].label+=" | 终止柱早于构造可知，仅历史回看";
   shapes[k].recovery_c=recovery.c;shapes[k].recovery_d=recovery.d;shapes[k].recovery_e=recovery.e;shapes[k].recovery_f=recovery.f;
    shapes[k].recovery_observable=recovery.observable;shapes[k].recovery_display_end=recovery_display_end;
   shapes[k].recovery_target_contact=recovery.target_contact;shapes[k].recovery_source_contact=recovery.source_contact;
   shapes[k].recovery_invalid=recovery.invalid;shapes[k].recovery_status=recovery.status;shapes[k].recovery_event_order=recovery.event_order;
  }
   datetime recovery_event=recovery_event_bar>=0?recovery.state_known:0;
   string recovery_unknown=recovery_event==0?"recovery_event_not_observed":"";
   if(!BKNSetLineClocks(shapes,recovery_start,ArraySize(shapes),"RESUME_DF_C",recovery.construction_known,recovery.display_known,"",
       recovery_event,recovery.status,recovery_unknown,m_cutoff))m_failure="native_recovery_clock_contract_invalid";
  for(int k=recovery_start;k<ArraySize(shapes);k++)shapes[k].line_display_basis=recovery.display_basis;
   for(int k=recovery_start;k<ArraySize(shapes);k++)BKNBindRecoveryLineEndpoints(shapes[k],recovery,turning,m_rows);
  BindScopeShapes(recovery_start,pair,structure);
 }
 // The reduced main path is only one view of the source inventory. It must
 // not silently suppress independently confirmed complete native sources.
 // Extra sources use the SAME proofs/rulers and four-family renderer, without
 // creating extra force/events/plans or restarting a successor root chain.
 void SourceWaveShape(const BKNWholeSource &source){
  if(source.a.index<0||source.b.index<=source.a.index||source.b.index>=ArraySize(m_rows)||source.known<=0||source.known>m_cutoff)return;
  string owner="book_native_source_wave:"+BKNHash(m_namespace+"|"+BKNPointKey(m_rows,source.a.index,source.a.price,m_decimals)+">"+BKNPointKey(m_rows,source.b.index,source.b.price,m_decimals));
  for(int i=0;i<ArraySize(shapes);i++)if(shapes[i].layer=="wave"&&shapes[i].owner==owner)return;
  int starts[],stops[];BKNFiniteSegments(m_rows,source.a.index,source.b.index,m_seconds,starts,stops);
  string label="原生完整波段 · A→B 实时来源范围 · 同周期动态重算；不含后续调整、不代表作者浪级";
  for(int i=0;i<ArraySize(starts);i++){
   int first=starts[i],last=stops[i];
   double slope=(source.b.price-source.a.price)/(double)(source.b.index-source.a.index);
   BKNShapeAppend(shapes,m_namespace,"source_wave:"+IntegerToString(i),"wave",first==last?"point":"line",owner,"book_native_source_wave",
    m_rows[first].time,source.a.price+slope*(first-source.a.index),m_rows[last].time,source.a.price+slope*(last-source.a.index),source.known,
    "native_source_wave_scope",label);
    int shape_index=ArraySize(shapes)-1;
    if(shape_index>=0){
     // Source waves are a separate inventory from the selected geometry
     // path. Stamp their exact A/B owner instead of leaving 0/0 metadata.
     shapes[shape_index].owner_a=source.a.time;shapes[shape_index].owner_b=source.b.time;
     shapes[shape_index].owner_known=source.known;shapes[shape_index].owner_degree=-1;
     shapes[shape_index].source_id=owner;
    }
  }
 } void ConnectedGeometry(const BKNWholeSource &source){
  BKNGeometryCoverage item;ZeroMemory(item);item.reason="";
  item.outer_reason="";item.channel_reason="";item.turning_reason="";item.recovery_reason="";
  item.a=source.a.time;item.b=source.b.time;item.known=source.known;
  BKNScope scope;ZeroMemory(scope);BKNSCopy(scope.a,source.a);BKNSCopy(scope.b,source.b);
  scope.known=source.known;scope.up=source.up;scope.envelope=true;scope.degree=-1;
  scope.ambiguous=source.unordered_components>0;
  if(!BKNVerifyWaveScope(m_rows,scope,m_seconds,m_cutoff))item.reason="source_scope_unverified";
  else{
   // Intrabar order is necessary for event/return sequencing, not for the
   // OHLC proof of two supporting contacts and a parallel envelope. Keep
   // ambiguous sources finite and descriptive; never admit their events.
   // Complete connected sources use the same causal D-F replay as primary
   // scopes. Otherwise they only redraw A-to-later-high/low candidates and
   // can never display the confirmed relative-start successor stage.
   int start=ArraySize(shapes);if(!scope.ambiguous)GeometryShape(scope,true,true);GeometryReviewShapes(scope);
   for(int k=start;k<ArraySize(shapes);k++){
     if(shapes[k].line_owner_relation=="adjacent_context")continue;
    shapes[k].owner_a=item.a;shapes[k].owner_b=item.b;
    shapes[k].owner_known=item.known;shapes[k].owner_degree=-1;
   }
   // Include previously drawn identical owners: they already cover this
   // source and should not be duplicated just to increase line counts.
    string host_owner="book_native_interval:"+BKNHash(m_namespace+"|"+BKNPointKey(m_rows,scope.a.index,scope.a.price,m_decimals)+">"+BKNPointKey(m_rows,scope.b.index,scope.b.price,m_decimals)+"|"+IntegerToString((long)scope.known));
    for(int k=0;k<ArraySize(shapes);k++){
     if(shapes[k].group=="book_CE_reference"&&shapes[k].line_owner_relation=="adjacent_context"&&shapes[k].line_host_owner==host_owner){item.extension++;continue;}
     if(shapes[k].owner_a!=item.a||shapes[k].owner_b!=item.b)continue;
    if(shapes[k].group=="book_CE_reference")item.extension++;
    if(shapes[k].line_family=="OUTER")item.outer++;
    else if(shapes[k].line_family=="CHANNEL"){
     item.channel++;
     if(shapes[k].kind=="point"||shapes[k].a==shapes[k].b)item.channel_points++;
     else item.channel_lines++;
    }
    else if(shapes[k].line_family=="RETURN_CE_D")item.turning++;
    else if(shapes[k].line_family=="RESUME_DF_C")item.recovery++;
   }
   item.count=item.outer+item.channel+item.turning+item.recovery+item.extension;
   if(item.extension==0){BKNBoundary ext=BKNObservedExtension(m_rows,scope.a.index,scope.b.index,scope.up,m_seconds,scope.known,m_cutoff);item.extension_reason=ext.qualified?"no_finite_independent_extension_span":ext.reason;}
   if(item.outer==0||item.channel_lines==0||item.turning==0||item.recovery==0){
    // Explain the actual missing display after the review path too. Do not
    // keep blaming a broadness gate after even the raw support proof fails.
    BKNBoundary line=BKNWholeBoundary(m_rows,scope.a.index,scope.b.index,scope.up,m_seconds,scope.known,m_cutoff,true);
    BKNTurning turn=BKNTurningBoundary(m_rows,scope.a.index,scope.b.index,scope.up,m_seconds,scope.known,m_cutoff,true);
    if(item.outer==0)item.outer_reason=line.qualified?"no_finite_outer_span":line.reason;
    if(item.channel_lines==0)item.channel_reason=!line.qualified?line.reason:line.axis_review?"axis_review_actual_Q_only":"actual_Q_without_forward_owned_span";
    if(item.turning==0)item.turning_reason=scope.ambiguous?"source_internal_order_unknown":turn.qualified?"no_finite_CE_D_span":turn.reason;
    if(item.recovery==0){
     if(scope.ambiguous)item.recovery_reason="source_internal_order_unknown";
     else if(!turn.qualified)item.recovery_reason="C_D_E_not_formed:"+turn.reason;
     else{
      BKNTurning admitted_turn=BKNTurningBoundary(m_rows,scope.a.index,scope.b.index,scope.up,m_seconds,scope.known,m_cutoff);
      BKNRecovery recovery=BKNRecoveryProjection(m_rows,admitted_turn,"coverage_source",m_seconds,m_cutoff,m_decimals);
      item.recovery_reason=recovery.qualified?"no_finite_recovery_span":recovery.reason;
      if(!admitted_turn.qualified)item.recovery_reason="C_D_E_admission_pending:"+admitted_turn.reason;
     }
    }
    if(item.count==0)item.reason="OUTER:"+item.outer_reason+"; CE_D:"+item.turning_reason;
   }
  }
  if(item.reason!=""&&item.outer_reason==""){
   item.outer_reason=item.reason;item.channel_reason=item.reason;
   item.turning_reason=item.reason;item.recovery_reason=item.reason;
   item.extension_reason=item.reason;
  }
  int n=ArraySize(coverage);ArrayResize(coverage,n+1,256);coverage[n]=item;
 }
public:
 BKNGeometryCoverage coverage[];
  BKNShape shapes[];
 string identity;
 bool core_finished,full_book_semantics_complete;
 BKNFrameBuilder(){m_stage=0;m_cancelled=false;core_finished=false;full_book_semantics_complete=false;}
 bool Begin(const MqlRates &rows[],int seconds,datetime cutoff,string provider,string symbol,
            int decimals,string input_identity,int geometry_degree=1,int detail_levels=1){
  Cancel();m_cancelled=false;m_failure="";identity=input_identity;m_stage=0;m_clock=0;m_scope=0;
  m_source_end=0;m_local_next=0;m_emit=0;m_phase_job=0;m_geometry_degree=geometry_degree;m_detail_levels=detail_levels;m_primary_geometry_count=0;
  core_finished=false;full_book_semantics_complete=false;m_seconds=seconds;m_cutoff=cutoff;m_decimals=decimals;
  m_provider=provider;m_symbol=symbol;m_input_revision=input_identity;
  m_namespace=provider+"|"+symbol+"|"+IntegerToString(seconds)+"|book_native_1";
  ArrayResize(m_rows,0);ArrayResize(shapes,0);ArrayResize(m_geometry,0);ArrayResize(m_strict,0);ArrayResize(m_drawn_geometry,0);ArrayResize(m_clocks,0);
  ArrayResize(m_sources,0);ArrayResize(m_local,0);ArrayResize(m_local_chosen,0);ArrayResize(coverage,0);
  ArrayResize(m_owned_geometry,0);
  ArrayResize(m_phase_roots,0);ArrayResize(m_phase_scopes,0);
  if(seconds<=0||StringLen(provider)==0||StringLen(symbol)==0||StringLen(input_identity)==0||decimals<0||decimals>8){m_failure="native_frame_identity_unavailable";return false;}
  datetime previous=0;
  for(int i=0;i<ArraySize(rows);i++){
   if(rows[i].time+seconds>cutoff)continue;
   if(rows[i].time<=previous||!BKNValidRate(rows[i])){m_failure="native_frame_order_or_OHLC_invalid";return false;}
   // Capacity changes only; logical input length and validation are unchanged.
   int n=ArraySize(m_rows);ArrayResize(m_rows,n+1,256);m_rows[n]=rows[i];previous=rows[i].time;
  }
  if(ArraySize(m_rows)<5){m_failure="native_frame_history_insufficient";return false;}
  m_stage=1;return true;
 }
 void Cancel(){m_cancelled=true;m_stage=0;}
  void StampCurrentContracts(){
   if(m_cancelled||m_stage==0)return;
   StampLifecycle();
  }
 // Read the completed native source inventory without substituting the
 // selected geometry path or promoting a source into author wave status.
 bool LookupConnectedSource(datetime a,datetime b,BKNWholeSource &source,string &reason){
  ZeroMemory(source);
  if(m_cancelled||m_stage!=5||!core_finished||Failed()){reason="source_inventory_not_ready";return false;}
  BKNWholeSourceLookup lookup;
  if(BKNFindWholeSourceByTimes(m_sources,a,b,m_cutoff,lookup)!=1){reason=lookup.reason;return false;}
  source=m_sources[lookup.index];reason="";return true;
 }
 // Explicit, finite historical inspection. This does not select a new main
 // wave, evaluate lifecycle events, assign an author degree or grant scores.
 bool AppendConnectedSourceInspection(datetime a,datetime b,string &reason){
  BKNWholeSource source;if(!LookupConnectedSource(a,b,source,reason))return false;
  for(int i=0;i<ArraySize(shapes);i++)if(shapes[i].status=="source_inspection_only"){
   reason="source_inspection_already_appended";return false;
  }
  BKNScope scope;ZeroMemory(scope);BKNSCopy(scope.a,source.a);BKNSCopy(scope.b,source.b);
  scope.known=source.known;scope.up=source.up;scope.envelope=true;scope.degree=-1;
  if(!BKNVerifyWaveScope(m_rows,scope,m_seconds,m_cutoff)){reason="source_scope_unverified";return false;}
  int first=scope.a.index,last=scope.b.index;
  string source_id="book_native_declared_scope:"+BKNHash(m_provider+"|"+m_symbol+"|"+IntegerToString(m_seconds)+"|"+
   BKNPointKey(m_rows,first,scope.a.price,m_decimals)+">"+BKNPointKey(m_rows,last,scope.b.price,m_decimals));
  string owner="book_source_inspection:"+BKNHash(source_id);
  string label="完整来源历史诊断；非作者浪级、活动预测或交易许可 | A "+TimeToString(a,TIME_DATE|TIME_MINUTES)+" → B "+TimeToString(b,TIME_DATE|TIME_MINUTES)+" | 来源 "+source_id;
  int overall=ArraySize(shapes),starts[],stops[];
  BKNBoundary line=BKNWholeBoundary(m_rows,first,last,scope.up,m_seconds,scope.known,m_cutoff);
  string proof;
  if(line.qualified&&BKNOuterNativeProof(m_rows,scope,line,m_seconds,m_cutoff,m_decimals,proof)){
   int start=ArraySize(shapes);BKNFiniteSegments(m_rows,line.first,last,m_seconds,starts,stops,true);
   for(int i=0;i<ArraySize(starts);i++)BKNShapeAppend(shapes,m_namespace,"inspect_outer:"+IntegerToString(i),"trend",starts[i]==stops[i]?"point":"line",owner,"book_source_inspect_outer",
    m_rows[starts[i]].time,BKNBoundaryLevel(line,starts[i],false),m_rows[stops[i]].time,BKNBoundaryLevel(line,stops[i],false),scope.known,"source_inspection_only",label+" | 外侧真实点与净空已核");
   if(!BKNSetLineClocks(shapes,start,ArraySize(shapes),"OUTER",scope.known,scope.known,"",0,"unknown","source_inspection_no_event_evaluation",m_cutoff)){ArrayResize(shapes,overall);reason="inspection_clock_invalid";return false;}
   BKNFrozenRuler rail=BKNFreezeOuter(line);rail.shifted=true;rail.start=line.parallel_contact;rail.start_price=line.parallel_price;rail.up=!line.up;
   bool clear=true;long gap=0;
   for(int i=first;i<=last;i++)if(!BKNGapNumerator(scope.up?m_rows[i].high:m_rows[i].low,rail,i,m_decimals,gap)||gap<0){clear=false;break;}
   if(clear){
    // A diagnostic does not license backpainting before the real Q touch.
    // Under axis review retain Q itself without projecting the disputed rail.
    int channel_last=line.axis_review?line.parallel_contact:last;
    start=ArraySize(shapes);BKNChannelSegments(m_rows,line.parallel_contact,channel_last,m_seconds,starts,stops,true);
    for(int i=0;i<ArraySize(starts);i++)BKNShapeAppend(shapes,m_namespace,"inspect_channel:"+IntegerToString(i),"channel",starts[i]==stops[i]?"point":"line",owner,"book_source_inspect_channel",
     m_rows[starts[i]].time,BKNBoundaryLevel(line,starts[i],true),m_rows[stops[i]].time,BKNBoundaryLevel(line,stops[i],true),scope.known,"source_inspection_only",label+" | 历史平行方程，端点非额外触点 | 真实Q "+TimeToString(m_rows[line.parallel_contact].time,TIME_DATE|TIME_MINUTES));
    if(!BKNSetLineClocks(shapes,start,ArraySize(shapes),"CHANNEL",scope.known,scope.known,"",0,"unknown","source_inspection_no_event_evaluation",m_cutoff)){ArrayResize(shapes,overall);reason="inspection_clock_invalid";return false;}
   }
  }
  BKNTurning turn=BKNTurningBoundary(m_rows,first,last,scope.up,m_seconds,scope.known,m_cutoff);
  bool turning_proved=turn.qualified&&BKNValidateCDE(m_rows,turn,m_decimals,proof);
  bool turning_adjacent=turning_proved&&(turn.c<first||turn.d<first||turn.e>last||turn.d>last);
  if(turning_proved){
   int start=ArraySize(shapes);BKNFiniteSegments(m_rows,turn.c,turn.e,m_seconds,starts,stops,true);
   for(int i=0;i<ArraySize(starts);i++)BKNShapeAppend(shapes,m_namespace,"inspect_ce_source:"+IntegerToString(i),"turning_point",starts[i]==stops[i]?"point":"line",owner,"book_CE_reference",
    m_rows[starts[i]].time,turn.c_price+turn.slope*(starts[i]-turn.c),
    m_rows[stops[i]].time,turn.c_price+turn.slope*(stops[i]-turn.c),turn.known_at,"source_inspection_only",label+" | 独立C-E源尺，仅真实C到E；不是Q平移通道");
   if(!BKNSetLineClocks(shapes,start,ArraySize(shapes),"CE_SOURCE",turn.known_at,turn.known_at,"",0,"unknown","source_inspection_no_event_evaluation",m_cutoff)){ArrayResize(shapes,overall);reason="inspection_clock_invalid";return false;}
   int history_last=(int)MathMax(turn.e,turn.terminal);
   start=ArraySize(shapes);BKNFiniteSegments(m_rows,turn.d,history_last,m_seconds,starts,stops,true);
   for(int i=0;i<ArraySize(starts);i++)BKNShapeAppend(shapes,m_namespace,"inspect_ce_d:"+IntegerToString(i),"turning_point",starts[i]==stops[i]?"point":"line",owner,"book_CE_D",
    m_rows[starts[i]].time,BKNTurningLevel(turn,starts[i]),m_rows[stops[i]].time,BKNTurningLevel(turn,stops[i]),turn.known_at,"source_inspection_only",label+" | C-E平移到真实D，保留D至terminal历史构造；非活动预测");
   if(!BKNSetLineClocks(shapes,start,ArraySize(shapes),"RETURN_CE_D",turn.known_at,turn.known_at,"",0,"unknown","source_inspection_no_event_evaluation",m_cutoff)){ArrayResize(shapes,overall);reason="inspection_clock_invalid";return false;}
  }
  BKNRecovery inspect_recovery;ZeroMemory(inspect_recovery);
  if(turning_proved){
   inspect_recovery=BKNRecoveryProjection(m_rows,turn,owner,m_seconds,m_cutoff,m_decimals);
   if(inspect_recovery.qualified&&inspect_recovery.display_end>=inspect_recovery.c){
    int start=ArraySize(shapes);BKNFiniteSegments(m_rows,inspect_recovery.c,inspect_recovery.display_end,m_seconds,starts,stops,true);
    int event_bar=(int)MathMax(inspect_recovery.target_contact,MathMax(inspect_recovery.source_contact,inspect_recovery.invalid));
    string event_note=event_bar>=0&&m_rows[event_bar].time+m_seconds<=inspect_recovery.construction_known?
     " | 终止柱不晚于构造可知，仅回溯":"";
    for(int i=0;i<ArraySize(starts);i++){
     int x=starts[i],y=stops[i];
     BKNShapeAppend(shapes,m_namespace,"inspect_df_c:"+IntegerToString(i),"turning_point",x==y?"point":"line",owner,"book_DF_C",
      m_rows[x].time,inspect_recovery.c_price+inspect_recovery.slope*(x-inspect_recovery.c),
      m_rows[y].time,inspect_recovery.c_price+inspect_recovery.slope*(y-inspect_recovery.c),
      inspect_recovery.known,"source_inspection_only",label+" | D-F平移原C的历史理论目标，非恢复或反转确认 | "+inspect_recovery.status+event_note);
    }
    datetime event_known=event_bar>=0?inspect_recovery.state_known:0;
    if(!BKNSetLineClocks(shapes,start,ArraySize(shapes),"RESUME_DF_C",inspect_recovery.construction_known,inspect_recovery.display_known,"",
       event_known,inspect_recovery.status,event_known>0?"":"no_terminal_event_observed_at_this_prefix",m_cutoff)){
     ArrayResize(shapes,overall);reason="inspection_recovery_clock_invalid";return false;
    }
    for(int i=start;i<ArraySize(shapes);i++){
     shapes[i].line_display_basis=inspect_recovery.display_basis;
     shapes[i].event_occurrence_known=event_bar>=0?m_rows[event_bar].time+m_seconds:0;
     shapes[i].recovery_c=inspect_recovery.c;shapes[i].recovery_d=inspect_recovery.d;shapes[i].recovery_e=inspect_recovery.e;shapes[i].recovery_f=inspect_recovery.f;
     shapes[i].recovery_observable=inspect_recovery.observable;shapes[i].recovery_display_end=inspect_recovery.display_end;
     shapes[i].recovery_target_contact=inspect_recovery.target_contact;shapes[i].recovery_source_contact=inspect_recovery.source_contact;
     shapes[i].recovery_invalid=inspect_recovery.invalid;shapes[i].recovery_status=inspect_recovery.status;shapes[i].recovery_event_order=inspect_recovery.event_order;
    }
   }
  }
  if(ArraySize(shapes)==overall){reason="no_verified_inspection_geometry";return false;}
  for(int i=overall;i<ArraySize(shapes);i++){
   shapes[i].source_id=source_id;shapes[i].owner_a=a;shapes[i].owner_b=b;shapes[i].owner_known=scope.known;shapes[i].owner_degree=-1;
   shapes[i].line_host_owner=owner;shapes[i].line_host_a=a;shapes[i].line_host_b=b;
   shapes[i].line_admission_mode="historical_inspection";
   shapes[i].construction_revision=m_input_revision;
   if(shapes[i].line_family=="OUTER")shapes[i].line_display_basis="finite_source_inspection_outer_owned";
   if(shapes[i].line_family=="CHANNEL"){
    shapes[i].line_display_basis=line.axis_review?"finite_source_inspection_Q_axis_review_only":"finite_source_inspection_Q_to_owner_end";
    shapes[i].axis_review=line.axis_review;shapes[i].axis_review_reason=line.axis_review_reason;
   }
   if(shapes[i].line_family=="CE_SOURCE")shapes[i].line_display_basis="finite_CE_source_C_to_E";
   if(shapes[i].line_family=="RETURN_CE_D")shapes[i].line_display_basis="finite_CE_D_construction_D_to_terminal";
   bool context_family=shapes[i].line_family=="CE_SOURCE"||shapes[i].line_family=="RETURN_CE_D"||shapes[i].line_family=="RESUME_DF_C";
   if(turning_adjacent&&context_family){
    int context_last=shapes[i].line_family=="CE_SOURCE"?turn.e:(int)MathMax(turn.e,turn.terminal);
    if(shapes[i].line_family=="RESUME_DF_C")context_last=(int)MathMax(context_last,inspect_recovery.display_end);
    BKNBindAdjacentLineOwner(shapes[i],scope,m_rows,turn.c,context_last,turn.known_at,owner);
    shapes[i].label+=" | 相邻上下文历史构造；当前A/B仅为观察宿主";
   }
   string anchor_key="";
   if(shapes[i].line_family=="RESUME_DF_C")
    anchor_key=BKNPointKey(m_rows,inspect_recovery.c,inspect_recovery.c_price,m_decimals)+"|"+
     BKNPointKey(m_rows,inspect_recovery.d,inspect_recovery.d_price,m_decimals)+"|"+
     BKNPointKey(m_rows,inspect_recovery.e,turn.e_price,m_decimals)+"|"+
     BKNPointKey(m_rows,inspect_recovery.f,inspect_recovery.f_price,m_decimals);
   else if(shapes[i].line_family=="CE_SOURCE")
    anchor_key=BKNPointKey(m_rows,turn.c,turn.c_price,m_decimals)+">"+BKNPointKey(m_rows,turn.e,turn.e_price,m_decimals);
   else if(shapes[i].line_family=="RETURN_CE_D")
    anchor_key=BKNPointKey(m_rows,turn.c,turn.c_price,m_decimals)+">"+BKNPointKey(m_rows,turn.e,turn.e_price,m_decimals)+"@"+BKNPointKey(m_rows,turn.d,turn.d_price,m_decimals);
   else{
    anchor_key=BKNPointKey(m_rows,line.first,line.first_price,m_decimals)+">"+BKNPointKey(m_rows,line.second,line.second_price,m_decimals);
    if(shapes[i].line_family=="CHANNEL")anchor_key+="@"+BKNPointKey(m_rows,line.parallel_contact,line.parallel_price,m_decimals);
   }
   shapes[i].construction_id="book_source_inspection_construction:"+BKNHash(shapes[i].source_id+"|"+shapes[i].line_family+"|"+anchor_key);
   if(shapes[i].line_family=="OUTER"||shapes[i].line_family=="CHANNEL")BKNBindOuterLineEndpoints(shapes[i],scope,line,m_rows);
   if(shapes[i].line_family=="CE_SOURCE"||shapes[i].line_family=="RETURN_CE_D")BKNBindTurningLineEndpoints(shapes[i],turn,m_rows);
   if(shapes[i].line_family=="RESUME_DF_C")BKNBindRecoveryLineEndpoints(shapes[i],inspect_recovery,turn,m_rows);
   BKNLineContractBindCommon(shapes[i],m_seconds,m_provider,m_symbol);
   BKNStampLineContract(shapes[i],m_cutoff,m_input_revision);
  }
  BKNMarkLineDuplicates(shapes);
  reason="";return true;
 }
 bool Failed(){return m_failure!="";}
 string Failure(){return m_failure;}
 int Stage(){return m_stage;}
 string Progress(){
  if(Failed())return m_failure;
  if(m_stage==1)return "识别当前原生周期波段";
  if(m_stage==11)return "整理原生周期完整历史上下文";
  if(m_stage==12)return "重建原生波段确认路径";
  if(m_stage==13)return "整理所属完整波段来源 "+IntegerToString(m_source_end)+" / "+IntegerToString((int)MathMax(0,ArraySize(m_context)-1));
  if(m_stage==2)return "计算独立完整力度波段 "+IntegerToString(m_local_next)+" / "+IntegerToString(ArraySize(m_sources));
  if(m_stage==20)return "识别原生K线与图表形态 "+IntegerToString(m_emit)+" / "+IntegerToString(ArraySize(m_rows));
  if(m_stage==21)return "装配完整波段与力度图层 "+IntegerToString(m_emit)+" / "+IntegerToString(ArraySize(m_local));
  if(m_stage==22)return "装配原生周期ZigZag "+IntegerToString(m_emit)+" / "+IntegerToString(ArraySize(m_native));
  if(m_stage==23)return "按连续波段绑定通道与拐点 "+IntegerToString(m_emit)+" / "+IntegerToString(ArraySize(m_owned_geometry));
  if(m_stage==25)return "绑定同周期完整来源通道 "+IntegerToString(m_emit)+" / "+IntegerToString(ArraySize(m_sources));
  if(m_stage==3)return "重算历史确认时钟 "+IntegerToString(m_clock)+" / "+IntegerToString(ArraySize(m_clocks));
  if(m_stage==4)return "计算所属波段通道与拐点 "+IntegerToString(m_scope)+" / "+IntegerToString(ArraySize(m_geometry));
  if(m_stage==24)return "核对同源后继换线 "+IntegerToString(m_phase_job)+" / "+IntegerToString(ArraySize(m_phase_roots));
  if(m_stage==5)return "原生核心计算结束；完整Book语义仍在迁移";
  return "等待原生行情";
 }
 // Cooperative stages: source arrays frozen by Begin. New ticks must queue a
 // following generation; they cannot repeatedly restart this historical job.
 bool Step(uint budget_ms=12){
  if(m_cancelled)return false;
  if(Failed()||m_stage==0||m_stage==5)return core_finished;
  ulong started=GetTickCount64();
  do{
   if(m_stage==1){
    if(!BKNSLedger(m_rows,m_seconds,m_cutoff,2,m_raw)){
     m_failure="native_source_calculation_failed";return false;
    }
    int clock_count=0;ArrayResize(m_clocks,ArraySize(m_raw));
    for(int i=0;i<ArraySize(m_raw);i++){
     long clock=(long)MathMax((double)m_raw[i].known,(double)(m_raw[i].time+m_seconds));
     if(clock>m_cutoff)continue;m_clocks[clock_count++]=clock;
    }
    ArrayResize(m_clocks,clock_count);
    ArraySort(m_clocks);m_stage=11;
   }else if(m_stage==11){
    if(!BKNSOriginalContextInventory(m_rows,m_seconds,m_cutoff,m_context)){
     m_failure="native_original_context_inventory_failed";return false;
    }
    m_stage=12;
   }else if(m_stage==12){
    BKNScope ignored[];
    if(!BKNSBuildPath(m_rows,m_context,m_seconds,m_cutoff,0,m_native,ignored)){
     m_failure="native_original_path_failed";return false;
    }
    if(!BKNGeometryScopes(m_rows,m_raw,m_seconds,m_cutoff,m_geometry_degree,m_owned_geometry)){
     m_failure="native_geometry_ownership_path_failed";return false;
    }
    m_primary_geometry_count=ArraySize(m_owned_geometry);
    if(!BKNAppendGeometryDetails(m_rows,m_raw,m_seconds,m_cutoff,m_geometry_degree,m_detail_levels,m_owned_geometry)){
     m_failure="native_geometry_detail_path_failed";return false;
    }
    m_stage=13;
   }else if(m_stage==13){
    if(m_source_end+1>=ArraySize(m_context)){m_stage=2;continue;}
    if(!BKNAppendWholeSourceAt(m_rows,m_context,m_seconds,m_cutoff,m_source_end++,m_sources)){
     m_failure="native_whole_source_calculation_failed";return false;
    }
   }else if(m_stage==2){
    if(m_local_next>=ArraySize(m_sources)){
     BKNFinishCompletedLocal(m_local_chosen,m_local);m_stage=20;m_emit=0;continue;
    }
    if(!BKNConsiderCompletedLocal(m_rows,m_sources[m_local_next++],m_native,m_seconds,m_cutoff,m_local_chosen)){
     m_failure="native_local_wave_calculation_failed";return false;
    }
   }else if(m_stage==20){
    if(m_emit>=ArraySize(m_rows)){m_stage=21;m_emit=0;continue;}
    PatternShapes(m_emit++);
   }else if(m_stage==21){
    if(m_emit>=ArraySize(m_local)){m_stage=22;m_emit=1;continue;}
    int i=m_emit++;
    ForceShape(m_local[i].source.a,m_local[i].source.b,m_local[i].known,"local",false,m_local[i].force);
   }else if(m_stage==22){
    if(m_emit>m_primary_geometry_count){m_stage=23;m_emit=0;continue;}
    int i=m_emit++-1;BKNScope native_scope;BKNScopeCopy(native_scope,m_owned_geometry[i]);
     string owner=BKNHash(m_namespace+"|zigzag|"+BKNPointKey(m_rows,native_scope.a.index,native_scope.a.price,m_decimals)+">"+BKNPointKey(m_rows,native_scope.b.index,native_scope.b.price,m_decimals));
     BKNShapeAppend(shapes,m_namespace,"zigzag","zigzag","line",owner,"book_native_zigzag",
      native_scope.a.time,native_scope.a.price,native_scope.b.time,native_scope.b.price,
      native_scope.known,"confirmed_native_geometry_path","");
    // Raw path remains evidence for force. Geometry uses the declared
    // non-overlapping path below, not every simultaneously available source.
   }else if(m_stage==23){
    if(m_emit>=ArraySize(m_owned_geometry)){m_stage=25;m_emit=0;continue;}
    int i=m_emit++,start=ArraySize(shapes);GeometryShape(m_owned_geometry[i],i<m_primary_geometry_count);GeometryReviewShapes(m_owned_geometry[i]);
    if(i<m_primary_geometry_count)WaveCountShapes(m_owned_geometry[i]);
    for(int k=start;k<ArraySize(shapes);k++){
     if(shapes[k].line_owner_relation=="adjacent_context")continue;
     shapes[k].owner_a=m_owned_geometry[i].a.time;shapes[k].owner_b=m_owned_geometry[i].b.time;
     shapes[k].owner_known=m_owned_geometry[i].known;shapes[k].owner_degree=m_owned_geometry[i].degree;
    }
   }else if(m_stage==25){
    if(m_emit>=ArraySize(m_sources)){m_stage=3;continue;}
    SourceWaveShape(m_sources[m_emit]);
    ConnectedGeometry(m_sources[m_emit++]);
   }else if(m_stage==3){
    if(m_clock>=ArraySize(m_clocks)){m_stage=4;continue;}
    datetime clock=(datetime)m_clocks[m_clock++];
    if(m_clock>1&&m_clocks[m_clock-2]==clock)continue;
    BKNPoint points[];BKNScope legs[];
    if(!BKNSBuildPath(m_rows,m_raw,m_seconds,clock,3,points,legs)){m_failure="native_historical_path_failed";return false;}
    for(int i=0;i<ArraySize(legs);i++){
     if(!legs[i].envelope)continue;BKNScope scope;BKNScopeCopy(scope,legs[i]);scope.known=clock;
     if(!scope.ambiguous)AppendScope(m_strict,scope);
     if(scope.a.time<scope.b.time&&scope.b.time+m_seconds<=clock)AppendScope(m_geometry,scope);
    }
   }else if(m_stage==4){
    if(m_scope>=ArraySize(m_geometry)){m_stage=24;continue;}
    BKNScope scope;BKNScopeCopy(scope,m_geometry[m_scope++]);
    BKNWaveDescription description=BKNDescribeVerifiedWave(m_rows,scope,m_seconds,m_cutoff);
    if(description.valid_scope)ForceShape(scope.a,scope.b,scope.known,"coarse",scope.ambiguous,description.force);
    // Historical coarse force keeps its original confirmation clock. It
    // does not create another geometry owner on top of the selected path.
   }else if(m_stage==24){
    if(m_phase_job>=ArraySize(m_phase_roots)){StampLifecycle();m_stage=5;core_finished=true;continue;}
    int i=m_phase_job++;SuccessorShapes(m_phase_scopes[i],m_phase_roots[i]);
   }
  }while(m_stage!=5&&!Failed()&&GetTickCount64()-started<budget_ms);
  return core_finished;
 }
};
#endif
