#ifndef BOOK_NATIVE_WAVE_COUNT
#define BOOK_NATIVE_WAVE_COUNT
#include "BookNativePair.mqh"
// Chapter 7 native source-bound COUNT HYPOTHESES, not author wave-degree
// adjudication. Source/first-rebound binding precedes the swing-level count.
// No transport, saved scene, service, DLL, order or chart operation is used.
struct BKNBookWaveCount {
 bool bound,up,backtrack_review,retrospective,failed_fifth,geometry_valid;
 int origin,prior_origin,first_break,dual_break,first_cross,failure,resolution,points;
 int anchor[9];double price[9];datetime anchor_known[9];bool confirmed[9];
 datetime source_known,known;
 string source_id,count_id,status,reason,correction2,correction4;
 // An unconfirmed first-wave extreme is a revisable observation, never A.
 int developing_index;double developing_price;datetime developing_known;
 string developing_revision;
};
void BKNWaveCountReset(BKNBookWaveCount &out){
 ZeroMemory(out);out.origin=-1;out.prior_origin=-1;out.first_break=-1;out.dual_break=-1;out.first_cross=-1;out.failure=-1;
 out.source_id="";out.count_id="";out.status="unknown";out.reason="source_bound_dual_break_required";
 out.correction2="unknown";out.correction4="unknown";
 out.developing_index=-1;
 for(int i=0;i<9;i++)out.anchor[i]=-1;
}
double BKNWaveCountSide(const MqlRates &row,bool up,bool motive){
 return up==motive?row.high:row.low;
}
bool BKNWaveCountAmbiguous(const BKNPoint &ledger[],int first,int last,datetime cutoff){
 for(int i=0;i<ArraySize(ledger);i++){
  if(ledger[i].index<first||ledger[i].index>last||ledger[i].known>cutoff)continue;
  for(int j=i+1;j<ArraySize(ledger)&&ledger[j].time==ledger[i].time;j++)
   if(ledger[j].known<=cutoff&&ledger[j].kind!=ledger[i].kind)return true;
 }
 return false;
}
// Morphology is measured inside the named correction, using raw confirmed
// native pivots. Its deepest excursion is NOT substituted for its terminal.
string BKNWaveCountCorrection(const BKNPoint &ledger[],int start,int terminal,bool up,datetime known){
 if(terminal<=start)return "correction_terminal_unavailable";
 if(BKNWaveCountAmbiguous(ledger,start+1,terminal,known))return "ambiguous_native_pivots";
 BKNPoint points[];int adverse=up?-1:1;
 for(int i=0;i<ArraySize(ledger);i++){
  BKNPoint p;BKNSCopy(p,ledger[i]);
  if(p.index<=start||p.index>terminal||p.known>known)continue;
  int n=ArraySize(points);
  if(n==0&&p.kind!=adverse)continue;
  if(n>0&&points[n-1].kind==p.kind){
   if(p.kind==1?p.price>=points[n-1].price:p.price<=points[n-1].price)BKNSCopy(points[n-1],p);
  }else BKNSAppend(points,p);
 }
 int n=ArraySize(points);
 if(n==0||points[n-1].index!=terminal||points[n-1].kind!=adverse)return "correction_terminal_unbound";
 if(n==1)return "simple_return_candidate";
 if(n==3)return "ABC_candidate";
 if(n==5){
  bool triangle=true;double low=0,high=0;bool have_low=false,have_high=false;
  for(int i=0;i<n;i++){
   if(points[i].kind==-1){if(have_low&&points[i].price<=low)triangle=false;low=points[i].price;have_low=true;}
   else {if(have_high&&points[i].price>=high)triangle=false;high=points[i].price;have_high=true;}
  }
  return triangle?"contracting_triangle_candidate":"five_pivot_correction_unresolved";
 }
 return "complex_correction_unresolved";
}
bool BKNWaveCountCorrectionKnown(string form){
 return form=="simple_return_candidate"||form=="ABC_candidate"||form=="contracting_triangle_candidate";
}
void BKNWaveCountPoint(BKNBookWaveCount &out,int ordinal,int at,double price,datetime known,bool confirmed){
 out.anchor[ordinal]=at;out.price[ordinal]=price;out.anchor_known[ordinal]=known;out.confirmed[ordinal]=confirmed;
 out.points=(int)MathMax(out.points,ordinal+1);out.known=(datetime)MathMax((long)out.known,(long)known);
}
int BKNWaveCountNext(const BKNPoint &path[],int after,int kind,datetime cutoff){
 for(int i=0;i<ArraySize(path);i++)if(path[i].index>after&&path[i].kind==kind&&path[i].known<=cutoff)return i;
 return -1;
}
void BKNBindFirstWave(const MqlRates &rows[],int seconds,int decimals,const BKNResponse &response,BKNBookWaveCount &out){
 int n=ArraySize(rows);if(seconds<=0||response.origin<0||response.origin>=n||out.first_break<0||out.first_break>=n)return;
 // Identity binds the source and first break, not a moving provisional high.
 out.origin=response.origin;
 out.count_id="book_native_wave_count:"+BKNHash(out.source_id+"|"+
  BKNPointKey(rows,response.origin,response.origin_price,decimals)+"|break:"+
  IntegerToString((long)rows[out.first_break].time)+"|resolution:"+IntegerToString(out.resolution));
 BKNWaveCountPoint(out,0,response.origin,response.origin_price,out.source_known,true);
 bool stopped=response.failure>=0&&response.failure<n;
 bool confirmed=response.source_complete&&response.terminal>response.origin&&response.terminal<n&&response.confirmed>=response.terminal&&response.confirmed<n;
 if(confirmed&&(!stopped||response.confirmed<response.failure)){
  BKNWaveCountPoint(out,1,response.terminal,response.terminal_price,response.confirmation_at,true);
  return;
 }
 // Freeze the invalidation boundary BEFORE selecting a developing extreme.
 // Later rebounds belong to another source, even if they are much larger.
 int last=stopped?response.failure-1:n-1,first=(int)MathMax(out.first_break,response.origin+1),at=-1;
 double sign=out.up?1.0:-1.0;
 for(int k=first;k<=last;k++)if(at<0||sign*BKNResponseFavourable(rows[k],out.up)>sign*BKNResponseFavourable(rows[at],out.up))at=k;
 if(at>=0&&sign*(BKNResponseFavourable(rows[at],out.up)-response.origin_price)>0){
  out.developing_index=at;out.developing_price=BKNResponseFavourable(rows[at],out.up);
  out.developing_known=(datetime)MathMax((long)out.source_known,(long)(rows[last].time+seconds));
  out.developing_revision=BKNHash(out.count_id+"|observed:"+BKNPointKey(rows,at,out.developing_price,decimals)+"|"+IntegerToString((long)out.developing_known));
 }
 out.status=stopped?"source_invalidated":"wave1_developing";
 out.reason=stopped?"original_B_crossed_before_first_endpoint_confirmation":"provisional_extreme_is_not_confirmed_A";
 out.failure=stopped?response.failure:-1;
 out.known=(datetime)MathMax((long)out.source_known,(long)(stopped?rows[response.failure].time+seconds:rows[n-1].time+seconds));
}
// Base 1..3 observations are independent from the later branch outcome.
// In particular an old single-path failed fifth/ABC must not retimestamp them.
BKNBookWaveCount BKNWaveBaseView(const MqlRates &rows[],const BKNPoint &ledger[],int seconds,const BKNBookWaveCount &whole){
 BKNBookWaveCount out=whole;if(!out.bound||out.backtrack_review)return out;
 out.points=(int)MathMin(out.points,4);out.failed_fifth=false;out.geometry_valid=false;out.correction4="unknown";
 out.known=out.source_known;
 for(int i=0;i<out.points;i++)out.known=(datetime)MathMax((long)out.known,(long)out.anchor_known[i]);
 for(int i=4;i<9;i++){out.anchor[i]=-1;out.price[i]=0;out.anchor_known[i]=0;out.confirmed[i]=false;}
 if(out.points<=1){out.known=whole.known;return out;}
 out.status=out.points==2?"first_wave_anchor_confirmed":out.points==3?(out.confirmed[2]?"second_wave_anchor_review":"wave2_developing"):out.confirmed[3]?"first_three_anchors_branching":"third_wave_endpoint_developing";
 out.reason="later_fourth_fifth_outcomes_are_separate_branches";
 if(out.failure>=0&&out.failure<ArraySize(rows)){
  out.status="source_invalidated";out.reason="original_B_crossed";
  out.known=(datetime)MathMax((long)out.known,(long)(rows[out.failure].time+seconds));
 }else if(BKNWaveCountAmbiguous(ledger,out.origin,out.anchor[out.points-1],out.known)){
  out.status="intrabar_order_review";out.reason="base_anchor_intrabar_order_unresolved";
 }
 return out;
}
void BKNWaveCountDeveloping(const MqlRates &rows[],int seconds,int start,int last,bool up,bool motive,
                            int ordinal,BKNBookWaveCount &out){
 if(start>=last)return;
 double sign=(up==motive)?1.0:-1.0;int at=start+1;
 for(int k=at+1;k<=last;k++)if(sign*BKNWaveCountSide(rows[k],up,motive)>sign*BKNWaveCountSide(rows[at],up,motive))at=k;
 double price=BKNWaveCountSide(rows[at],up,motive);
 if(sign*(price-out.price[ordinal-1])<=0)return;
 BKNWaveCountPoint(out,ordinal,at,price,rows[last].time+seconds,false);
}
// State extension consumes an already source-bound first rebound. Kept separate
// so physical-prefix controls can exercise counting without replacing the
// native source/geometry proofs performed by BKNCountBookWavesCore.
BKNBookWaveCount BKNExtendBookWaveCount(const MqlRates &rows[],const BKNPoint &ledger[],
 int seconds,datetime cutoff,int resolution,const BKNBookWaveCount &seed,int decimals=2){
 BKNBookWaveCount out=seed;int n=ArraySize(rows);double sign=out.up?1.0:-1.0;
 if(seconds<=0||!out.bound||out.points!=2||!out.confirmed[0]||!out.confirmed[1]||out.anchor[0]<0||out.anchor[1]<=out.anchor[0]||out.anchor[1]>=n||
    out.source_known<=0||out.source_known>cutoff||out.known>cutoff||out.anchor_known[1]>cutoff||rows[out.anchor[1]].time+seconds>cutoff){
  out.bound=false;out.reason="count_seed_unbound";return out;
 }
 BKNPoint path[];BKNScope legs[];
 if(!BKNSBuildPath(rows,ledger,seconds,cutoff,resolution,path,legs)){out.reason="native_count_resolution_unavailable";return out;}
 // A first rebound cannot be silently mixed with a different reduction level.
 bool first_on_path=false;int motive=out.up?1:-1,adverse=-motive;
 for(int i=0;i<ArraySize(path);i++)if(path[i].index==out.anchor[1]&&path[i].kind==motive&&path[i].price==out.price[1])first_on_path=true;
 if(!first_on_path){out.status="wave1_resolution_review";out.reason="first_rebound_not_on_requested_native_resolution";return out;}
 for(int k=out.anchor[1]+1;k<n;k++){
  if(sign*(BKNResponseAdverse(rows[k],out.up)-out.price[0])<0){out.failure=k;break;}
  if(sign*(rows[k].close-out.price[1])>0){out.first_cross=k;break;}
 }
 if(out.failure>=0){out.status="source_invalidated";out.reason="original_B_crossed_before_wave3";out.known=(datetime)MathMax((long)out.known,(long)(rows[out.failure].time+seconds));return out;}
 int stop=out.first_cross>=0?out.first_cross:n-1,correction=-1;
 datetime correction_clock=out.first_cross>=0?rows[out.first_cross].time+seconds:cutoff;
 for(int i=0;i<ArraySize(path);i++)if(path[i].index>out.anchor[1]&&path[i].index<stop&&path[i].kind==adverse&&path[i].known<=correction_clock)correction=i;
 if(correction<0){
  out.status="wave2_developing";out.reason="confirmed_corrective_terminal_unavailable";
  BKNWaveCountDeveloping(rows,seconds,out.anchor[1],stop,out.up,false,2,out);return out;
 }
 BKNPoint p2;BKNSCopy(p2,path[correction]);
 // The last named correction terminal may differ from the deepest excursion,
 // but no later equal/deeper wick may be hidden before its claimed recovery.
 for(int k=p2.index+1;k<=stop;k++)if(sign*(BKNResponseAdverse(rows[k],out.up)-p2.price)<=0){
  out.status="wave2_terminal_review";out.reason="corrective_terminal_revisited_before_A_cross";return out;
 }
 out.correction2=BKNWaveCountCorrection(ledger,out.anchor[1],p2.index,out.up,correction_clock);
 BKNWaveCountPoint(out,2,p2.index,p2.price,(datetime)MathMax((long)p2.known,(long)correction_clock),true);
 if(out.first_cross<0){out.status="wave2_developing";out.reason="waiting_closed_A_cross";return out;}
 if(!BKNWaveCountCorrectionKnown(out.correction2)){out.status="wave2_morphology_review";out.reason=out.correction2;return out;}
 int third=-1;
 for(int i=correction+1;i<ArraySize(path);i++)if(path[i].kind==motive&&path[i].index>=out.first_cross&&sign*(path[i].price-out.price[1])>0){third=i;break;}
 if(third<0){out.status="wave3_developing";out.reason="wave1_A_closed_cross_observed";BKNWaveCountDeveloping(rows,seconds,p2.index,n-1,out.up,true,3,out);return out;}
 BKNPoint p3;BKNSCopy(p3,path[third]);BKNWaveCountPoint(out,3,p3.index,p3.price,p3.known,true);
 int fourth=BKNWaveCountNext(path,p3.index,adverse,cutoff);
 if(fourth<0){out.status="wave4_developing";out.reason="wave3_terminal_is_native_candidate";BKNWaveCountDeveloping(rows,seconds,p3.index,n-1,out.up,false,4,out);return out;}
 BKNPoint p4;BKNSCopy(p4,path[fourth]);BKNWaveCountPoint(out,4,p4.index,p4.price,p4.known,true);
 out.correction4=BKNWaveCountCorrection(ledger,p3.index,p4.index,out.up,p4.known);
 if(sign*(p4.price-out.price[1])<=0){out.status="wave4_overlap_review";out.reason="ordinary_wave4_overlaps_wave1_explicit_exception_required";return out;}
 if(!BKNWaveCountCorrectionKnown(out.correction4)){out.status="wave4_morphology_review";out.reason=out.correction4;return out;}
 int fifth=BKNWaveCountNext(path,p4.index,motive,cutoff);
 if(fifth<0){out.status="wave5_developing";out.reason="wave4_terminal_is_native_candidate";BKNWaveCountDeveloping(rows,seconds,p4.index,n-1,out.up,true,5,out);return out;}
 BKNPoint p5;BKNSCopy(p5,path[fifth]);BKNWaveCountPoint(out,5,p5.index,p5.price,p5.known,true);
 out.failed_fifth=sign*(p5.price-p3.price)<=0;
 // Structural equality is quote-grid equality. Double subtraction can turn
 // two native 8.01 legs into 8.010000000000005 and 8.009999999999991.
 long t0,t1,t2,t3,t4,t5;
 if(!BKNPriceTicks(out.price[0],decimals,t0)||!BKNPriceTicks(out.price[1],decimals,t1)||
    !BKNPriceTicks(p2.price,decimals,t2)||!BKNPriceTicks(p3.price,decimals,t3)||
    !BKNPriceTicks(p4.price,decimals,t4)||!BKNPriceTicks(p5.price,decimals,t5)){
  out.status="wave_price_grid_review";out.reason="native_wave_length_quote_grid_unavailable";return out;
 }
 long w1=(long)MathAbs((double)(t1-t0)),w3=(long)MathAbs((double)(t3-t2)),w5=(long)MathAbs((double)(t5-t4));
 if(w3<MathMin(w1,w5)){out.status="wave3_shortest_rejected";out.reason="third_shorter_than_both_first_and_fifth";return out;}
 if(w3==MathMin(w1,w5)){out.status="wave3_length_tie_review";out.reason="equal_shortest_policy_unadjudicated";return out;}
 out.geometry_valid=true;out.status=out.failed_fifth?"failed_fifth_candidate":"five_wave_candidate";
 out.reason="native_same_resolution_candidate_author_degree_and_extension_alternative_unverified";
 int cursor=fifth;
 for(int ordinal=6;ordinal<9;ordinal++){
  int kind=ordinal%2==0?adverse:motive,next=BKNWaveCountNext(path,path[cursor].index,kind,cutoff);
  if(next<0)break;
  BKNPoint p;BKNSCopy(p,path[next]);BKNWaveCountPoint(out,ordinal,p.index,p.price,p.known,true);cursor=next;
 }
 int end=out.anchor[5];
 if(BKNWaveCountAmbiguous(ledger,out.anchor[0],end,out.known)){
  out.geometry_valid=false;out.status="intrabar_order_review";out.reason="opposing_native_extrema_same_bar_unordered";
 }
 return out;
}
// Caller provides the actual same-source pair. Reproduce its two frozen
// break observations and native ownership before using any ordinal labels.
BKNBookWaveCount BKNCountBookWavesCore(const MqlRates &bars[],const BKNPoint &ledger[],
 const BKNScope &scope,const BKNBoundary &outer,const BKNTurning &turning,const BKNBoundaryPair &pair,
 const BKNSourceReference &source,int seconds,datetime cutoff,int decimals,int resolution=0){
 BKNBookWaveCount out;BKNWaveCountReset(out);out.up=!scope.up;out.resolution=resolution;
 if(seconds<=0||resolution<0||resolution>3||!pair.evaluated||!pair.turning_bound||pair.source_id=="")return out;
 BKNSourceReference actual=BKNReference(scope,source.provider,source.symbol,seconds);
 if(!BKNReferenceMatches(actual,source)){out.reason="count_market_or_source_reference_mismatch";return out;}
 MqlRates rows[];int n=0;datetime previous=0;bool future=false;
 for(int k=0;k<ArraySize(bars);k++){
  if(bars[k].time+seconds>cutoff){future=true;continue;}
  if(future||bars[k].time<=previous||!BKNValidRate(bars[k])||bars[k].low<=0){out.reason="invalid_native_count_prefix";return out;}
  ArrayResize(rows,n+1,256);rows[n++]=bars[k];previous=bars[k].time;
 }
 string proof;
 if(!BKNOuterNativeProof(rows,scope,outer,seconds,cutoff,decimals,proof)){out.reason=proof;return out;}
 string market=source.provider+"|"+source.symbol+"|"+IntegerToString(seconds)+"|";
 string wave=BKNPointKey(rows,scope.a.index,scope.a.price,decimals)+">"+BKNPointKey(rows,scope.b.index,scope.b.price,decimals);
 if(pair.source_id!="book_native_declared_scope:"+BKNHash(market+wave)){out.reason="count_pair_source_identity_mismatch";return out;}
 if(turning.origin!=scope.a.index||turning.terminal!=scope.b.index||turning.up!=scope.up||
    !BKNValidateCDE(rows,turning,decimals,proof)){out.reason="count_CDE_source_unbound";return out;}
 if(turning.known_at<scope.known||turning.known_at>cutoff||rows[turning.observable].time+seconds>turning.known_at){out.reason="count_CDE_clock_unbound";return out;}
 BKNFrozenRuler outer_ruler=BKNFreezeOuter(outer),turning_ruler=BKNFreezeTurning(turning);
 BKNBoundaryEvents oe=BKNPairScoreEvent(rows,outer_ruler,outer.second,seconds,cutoff,decimals);
 BKNBoundaryEvents te=BKNPairScoreEvent(rows,turning_ruler,turning.observable,seconds,cutoff,decimals);
 if(!oe.evaluated||!te.evaluated||oe.broken<0||te.broken<0)return out;
 if(oe.broken!=pair.outer_event.broken||te.broken!=pair.turning_event.broken||
    oe.break_known!=pair.outer_event.break_known||te.break_known!=pair.turning_event.break_known){out.reason="count_pair_event_mismatch";return out;}
 out.first_break=(int)MathMin(oe.broken,te.broken);out.dual_break=(int)MathMax(oe.broken,te.broken);
 out.source_known=(datetime)MathMax((long)scope.known,MathMax((long)oe.break_known,(long)te.break_known));out.known=out.source_known;
 if(out.source_known>cutoff){out.reason="count_dependencies_not_yet_known";return out;}
 int first=oe.broken<=te.broken?outer.first:turning.c,second=oe.broken<=te.broken?outer.second:turning.e;
 BKNResponse rebound=BKNFirstBookResponse(rows,seconds,cutoff,true,first,second,true,out.first_break,out.up,
   oe.broken<=te.broken?outer.known_at:turning.known_at,out.source_known);
 if(rebound.origin<0||rebound.terminal<0){out.reason=rebound.reason;return out;}
 out.bound=true;out.source_id=pair.source_id;out.origin=rebound.origin;
 out.retrospective=out.source_known>rows[out.first_break].time+seconds;
 BKNBindFirstWave(rows,seconds,decimals,rebound,out);
 if(out.status=="source_invalidated")return out;
 int prior=scope.a.index;double sign=out.up?1.0:-1.0;
 for(int k=prior+1;k<=out.first_break;k++)
  if(sign*BKNResponseAdverse(rows[k],out.up)<sign*BKNResponseAdverse(rows[prior],out.up))prior=k;
 out.prior_origin=prior;
 if(prior<rebound.origin&&sign*(rebound.origin_price-BKNResponseAdverse(rows[prior],out.up))>0){
  out.backtrack_review=true;out.status="wave1_predecessor_review";out.reason="PDF200_201_prior_B_A_selection_required";return out;
 }
 if(out.points<2||!out.confirmed[1])return out;
 if(resolution>0){
  BKNPoint path[];BKNScope legs[];bool origin_bound=false,first_bound=false;
  if(BKNSBuildPath(rows,ledger,seconds,cutoff,resolution,path,legs))for(int j=0;j<ArraySize(path);j++){
   if(path[j].index==out.anchor[0]&&path[j].price==out.price[0]&&path[j].kind==(out.up?-1:1)){
    origin_bound=true;out.anchor_known[0]=(datetime)MathMax((long)out.anchor_known[0],(long)path[j].known);
   }
   if(path[j].index==out.anchor[1]&&path[j].price==out.price[1]&&path[j].kind==(out.up?1:-1)){
    first_bound=true;out.anchor_known[1]=(datetime)MathMax((long)out.anchor_known[1],(long)path[j].known);
   }
  }
  if(!origin_bound||!first_bound){out.status="wave_degree_endpoints_unbound";out.reason="first_wave_cannot_be_promoted_by_timeframe_or_size";return out;}
  out.known=(datetime)MathMax((long)out.known,MathMax((long)out.anchor_known[0],(long)out.anchor_known[1]));
 }
 return BKNExtendBookWaveCount(rows,ledger,seconds,cutoff,resolution,out,decimals);
}
BKNBookWaveCount BKNFinalizeBookWaveCount(const MqlRates &bars[],const BKNPoint &ledger[],
 int seconds,datetime cutoff,const BKNBookWaveCount &candidate){
 BKNBookWaveCount out=candidate;
 if(!out.bound||out.points<2)return out;
 double sign=out.up?1.0:-1.0;int closed=0;
 for(int k=0;k<ArraySize(bars);k++)if(bars[k].time+seconds<=cutoff)closed=k+1;
 // Completion requires the fifth's confirmation close, not merely its wick.
 // A source failure on that same close has no established intrabar ordering.
 int end=closed-1;
 if(out.points>=6&&out.confirmed[5]){
  datetime completion=(datetime)MathMax((long)out.source_known,(long)out.anchor_known[5]);
  for(int k=out.anchor[5];k<closed;k++)if(bars[k].time+seconds>=completion){end=k;break;}
 }
 for(int k=out.origin+1;k<=end;k++)if(sign*(BKNResponseAdverse(bars[k],out.up)-out.price[0])<0){
  out.failure=k;out.geometry_valid=false;out.status="source_invalidated";out.reason="original_B_crossed_in_count_interval";
  datetime failure_known=bars[k].time+seconds;
  while(out.points>1&&(out.anchor[out.points-1]>=k||out.anchor_known[out.points-1]>=failure_known))out.points--;
  for(int j=out.points;j<9;j++){out.anchor[j]=-1;out.price[j]=0;out.anchor_known[j]=0;out.confirmed[j]=false;}
  out.known=(datetime)MathMax((long)out.source_known,(long)failure_known);
  for(int j=0;j<out.points;j++)out.known=(datetime)MathMax((long)out.known,(long)out.anchor_known[j]);
  return out;
 }
 // Ambiguous high/low ordering must not disappear because the selected path
 // excluded that candle. This applies to developing counts as well as five.
 if(BKNWaveCountAmbiguous(ledger,out.origin,out.anchor[out.points-1],cutoff)){
  out.geometry_valid=false;out.status="intrabar_order_review";out.reason="opposing_native_extrema_same_bar_unordered";
  for(int i=0;i<ArraySize(ledger);i++)if(ledger[i].index>=out.origin&&ledger[i].index<=out.anchor[out.points-1]&&ledger[i].known<=cutoff)
   out.known=(datetime)MathMax((long)out.known,(long)ledger[i].known);
 }
 return out;
}
BKNBookWaveCount BKNCountBookWaves(const MqlRates &bars[],const BKNPoint &ledger[],
 const BKNScope &scope,const BKNBoundary &outer,const BKNTurning &turning,const BKNBoundaryPair &pair,
 const BKNSourceReference &source,int seconds,datetime cutoff,int decimals,int resolution=0){
 BKNBookWaveCount out=BKNCountBookWavesCore(bars,ledger,scope,outer,turning,pair,source,seconds,cutoff,decimals,resolution);
 return BKNFinalizeBookWaveCount(bars,ledger,seconds,cutoff,out);
}
struct BKNBookWaveTargets {
 bool third_available,fifth_available;
 double third_1,third_1618,fifth_if_third_extended_0618,fifth_if_third_extended_1;
 double fifth_if_fifth_extended_1618,fifth_region_from_origin,fifth_region_from_first_top;
 datetime third_known,fifth_known;
 string reason;
};
// PDF207,223,224: retain EACH formula's named ruler and projection origin.
// These conditional facts do not select an extension scenario or a target.
BKNBookWaveTargets BKNBookWaveTargetFacts(const BKNBookWaveCount &count){
 BKNBookWaveTargets out;ZeroMemory(out);out.reason="source_or_correction_not_bound";
 if(!count.bound||count.backtrack_review||count.source_id==""||count.points<3||!count.confirmed[1]||count.first_cross<0||
    count.status=="source_invalidated"||StringFind(count.status,"review")>=0||StringFind(count.status,"rejected")>=0)return out;
 double sign=count.up?1.0:-1.0,h1=sign*(count.price[1]-count.price[0]);
 if(!MathIsValidNumber(h1)||h1<=0||!count.confirmed[2]||!BKNWaveCountCorrectionKnown(count.correction2))return out;
 out.third_available=true;out.third_1=count.price[2]+sign*h1;out.third_1618=count.price[2]+sign*h1*1.618;
 out.third_known=(datetime)MathMax((long)count.source_known,(long)count.anchor_known[2]);out.reason="conditional_formulas_no_selected_scenario";
 if(count.points<5||!count.confirmed[4]||!BKNWaveCountCorrectionKnown(count.correction4)||
    sign*(count.price[4]-count.price[1])<=0)return out;
 double h03=sign*(count.price[3]-count.price[0]);if(h03<=0)return out;
 out.fifth_available=true;
 out.fifth_if_third_extended_0618=count.price[4]+sign*.618*h1;
 out.fifth_if_third_extended_1=count.price[4]+sign*h1;
 out.fifth_if_fifth_extended_1618=count.price[4]+sign*1.618*h03;
 out.fifth_region_from_origin=count.price[0]+sign*3.236*h1;
 out.fifth_region_from_first_top=count.price[1]+sign*3.236*h1;
 out.fifth_known=(datetime)MathMax((long)out.third_known,MathMax((long)count.anchor_known[3],(long)count.anchor_known[4]));
 return out;
}
#endif
