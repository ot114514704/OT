#ifndef BOOK_NATIVE_WAVE_BRANCHES
#define BOOK_NATIVE_WAVE_BRANCHES
#include "BookNativeWaveCount.mqh"
// Six's chapter7 branch review: native alternatives retain their own third,
// fourth and fifth. No geometrical branch is promoted to an author count.
struct BKNWaveBranch {
 string id,parent_id,source_id,scenario,correction,state,reason;
 int third,fourth,fifth,recovery,revisited;
 double third_price,fourth_price,fifth_price;
 datetime third_known,fourth_known,fifth_known,recovery_known,state_known;
 bool failed_fifth,extension,geometry_valid,fourth_confirmed,fifth_confirmed;
};
void BKNBuildWaveBranches(const MqlRates &bars[],const BKNPoint &ledger[],int seconds,datetime cutoff,
                         const BKNBookWaveCount &seed,int decimals,BKNWaveBranch &out[]){
 ArrayResize(out,0);
 if(seconds<=0||!seed.bound||seed.backtrack_review||seed.count_id==""||seed.source_id==""||seed.points<4||
    !seed.confirmed[1]||!seed.confirmed[2]||seed.first_cross<0||seed.source_known>cutoff)return;
 MqlRates rows[];int n=0;datetime previous=0;bool future=false;
 for(int k=0;k<ArraySize(bars);k++){
  if(bars[k].time+seconds>cutoff){future=true;continue;}
  if(future||bars[k].time<=previous||!BKNValidRate(bars[k]))return;
  ArrayResize(rows,n+1,256);rows[n++]=bars[k];previous=bars[k].time;
 }
 int p2=seed.anchor[2];if(p2<0||p2>=n||seed.anchor_known[2]>cutoff)return;
 BKNPoint path[];BKNScope ignored[];
 if(!BKNSBuildPath(rows,ledger,seconds,cutoff,seed.resolution,path,ignored))return;
 int motive=seed.up?1:-1,adverse=-motive;double sign=seed.up?1.0:-1.0;
 int origin_failure=n;
 for(int k=p2+1;k<n;k++)if(sign*(BKNResponseAdverse(rows[k],seed.up)-seed.price[0])<0){origin_failure=k;break;}
 datetime failure_known=origin_failure<n?rows[origin_failure].time+seconds:0;
 int path2=-1;for(int k=0;k<ArraySize(path);k++)if(path[k].index==p2&&path[k].kind==adverse&&path[k].price==seed.price[2])path2=k;
 if(path2<0)return;
 int first3=-1;double record=seed.price[1];
 for(int t=path2+1;t<ArraySize(path);t++){
  BKNPoint p3;BKNSCopy(p3,path[t]);
  if(p3.index>=origin_failure)break;
  if(p3.kind!=motive||p3.known>cutoff||p3.index<seed.first_cross||sign*(p3.price-record)<=0)continue;
  if(failure_known>0&&p3.known>=failure_known)continue;
  if(first3<0)first3=t;
  bool extension=t!=first3;
  record=p3.price;
  // An extension alternative needs at least five alternating native sublegs
  // from wave2, and may not cross that wave2 origin. This is necessary native
  // evidence only, not proof of the author's internal subwave degree.
  if(extension&&t-path2<5)continue;
  bool third_clear=true;
  for(int k=p2+1;k<=p3.index;k++)if(sign*(BKNResponseAdverse(rows[k],seed.up)-seed.price[2])<0)third_clear=false;
  if(!third_clear)continue;
  if(BKNWaveCountAmbiguous(ledger,p2,p3.index,p3.known))continue;
  int cross=n;
  for(int k=p3.index+1;k<origin_failure;k++)if(sign*(rows[k].close-p3.price)>0){cross=k;break;}
  int terminal_limit=(int)MathMin(cross,origin_failure);
  bool active_fourth=false;
  for(int f=t+1;f<ArraySize(path);f++){
   BKNPoint p4;BKNSCopy(p4,path[f]);if(p4.index>=terminal_limit)break;
   if(p4.kind!=adverse||p4.known>cutoff)continue;
   if(failure_known>0&&p4.known>=failure_known)continue;
   // A terminal first known after the recovery cannot be used retroactively
   // to claim a fifth-wave trigger on that earlier candle.
   if(cross<n&&p4.known>rows[cross].time+seconds)continue;
   BKNWaveBranch b;ZeroMemory(b);b.third=p3.index;b.fourth=p4.index;b.fifth=-1;b.recovery=-1;b.revisited=-1;
   b.parent_id=seed.count_id;b.source_id=seed.source_id;b.extension=extension;
   b.fourth_confirmed=true;b.fifth_confirmed=false;
   b.scenario=extension?"third_wave_extension_scenario":"base_third_scenario";
   b.third_price=p3.price;b.fourth_price=p4.price;
   b.third_known=(datetime)MathMax((long)seed.anchor_known[2],MathMax((long)seed.source_known,(long)p3.known));
   b.fourth_known=(datetime)MathMax((long)b.third_known,(long)p4.known);b.state_known=b.fourth_known;
   b.correction=BKNWaveCountCorrection(ledger,p3.index,p4.index,seed.up,b.fourth_known);
   b.state="wave4_terminal_candidate";b.reason="terminal_selection_unresolved";
   b.id="book_wave_branch:"+BKNHash(seed.count_id+"|"+BKNPointKey(rows,p3.index,p3.price,decimals)+"|"+BKNPointKey(rows,p4.index,p4.price,decimals));
   if(sign*(p4.price-seed.price[1])<=0){b.state="wave4_overlap_review";b.reason="explicit_diagonal_exception_required";}
   else if(!BKNWaveCountCorrectionKnown(b.correction)){b.state="wave4_morphology_review";b.reason=b.correction;}
   else{
    int watch=(int)MathMin(terminal_limit,n-1);
    for(int k=p4.index+1;k<=watch;k++)if(sign*(BKNResponseAdverse(rows[k],seed.up)-p4.price)<=0){b.revisited=k;break;}
    if(b.revisited>=0){b.state="wave4_terminal_revisited";b.reason="later_equal_or_deeper_excursion_before_recovery";b.state_known=(datetime)MathMax((long)b.state_known,(long)(rows[b.revisited].time+seconds));}
    else{
     if(cross<n&&cross<origin_failure){b.recovery=cross;b.recovery_known=rows[cross].time+seconds;b.state_known=(datetime)MathMax((long)b.state_known,(long)b.recovery_known);}
     int fifth=BKNWaveCountNext(path,p4.index,motive,cutoff);
     if(fifth>=0&&path[fifth].index<origin_failure&&(failure_known==0||path[fifth].known<failure_known)){
      BKNPoint p5;BKNSCopy(p5,path[fifth]);b.fifth=p5.index;b.fifth_price=p5.price;b.fifth_known=(datetime)MathMax((long)b.fourth_known,(long)p5.known);
      b.fifth_confirmed=true;
      b.state_known=(datetime)MathMax((long)b.state_known,(long)b.fifth_known);b.failed_fifth=sign*(p5.price-p3.price)<=0;
      b.state="wave5_recovery_review";b.reason="could_be_internal_B_of_complex_fourth";
      // No early local rebound is silently promoted to wave5. A completed
      // candidate needs this branch's recovery clock before its fifth pivot.
      if(b.recovery>=0&&b.recovery<=p5.index){
       long q0,q1,q2,q3,q4,q5;
       if(BKNPriceTicks(seed.price[0],decimals,q0)&&BKNPriceTicks(seed.price[1],decimals,q1)&&BKNPriceTicks(seed.price[2],decimals,q2)&&
          BKNPriceTicks(p3.price,decimals,q3)&&BKNPriceTicks(p4.price,decimals,q4)&&BKNPriceTicks(p5.price,decimals,q5)){
        long w1=(long)MathAbs((double)(q1-q0)),w3=(long)MathAbs((double)(q3-q2)),w5=(long)MathAbs((double)(q5-q4));
        b.state=w3<MathMin(w1,w5)?"wave3_shortest_rejected":w3==MathMin(w1,w5)?"wave3_length_tie_review":"five_wave_branch_candidate";
        b.geometry_valid=b.state=="five_wave_branch_candidate";b.reason=b.geometry_valid?"author_degree_and_branch_selection_unresolved":"native_length_rule";
       }else{b.state="wave_price_grid_review";b.reason="native_quote_grid_unavailable";}
      }else if(b.failed_fifth){b.state="failed_fifth_or_internal_B_review";b.reason="failure_alternative_preserved_not_selected";}
     }else if(b.recovery>=0){
      b.state="wave5_developing";b.reason="branch_recovery_observed_terminal_not_confirmed";
      int last=(int)MathMin(origin_failure-1,n-1),at=p4.index+1;
      for(int k=at+1;k<=last;k++)if(sign*BKNResponseFavourable(rows[k],seed.up)>sign*BKNResponseFavourable(rows[at],seed.up))at=k;
      if(at<=last&&sign*(BKNResponseFavourable(rows[at],seed.up)-p4.price)>0){
       b.fifth=at;b.fifth_price=BKNResponseFavourable(rows[at],seed.up);
       b.fifth_known=(datetime)MathMax((long)b.fourth_known,(long)(rows[last].time+seconds));b.state_known=b.fifth_known;
      }
     }
    }
   }
   if(origin_failure<n&&(!b.fifth_confirmed||b.fifth<0||b.fifth>=origin_failure)){
    b.geometry_valid=false;b.state="branch_source_invalidated";b.reason="original_B_crossed_before_branch_confirmation";b.state_known=(datetime)MathMax((long)b.state_known,(long)failure_known);
    if(!b.fifth_confirmed){b.fifth=-1;b.fifth_price=0;b.fifth_known=0;}
   }
   if(BKNWaveCountAmbiguous(ledger,p3.index,b.fifth>=0?b.fifth:p4.index,b.state_known)){
    b.geometry_valid=false;b.state="intrabar_order_review";b.reason="opposing_native_extrema_same_bar_unordered";
   }
   if(b.revisited<0&&b.state!="branch_source_invalidated"&&b.state!="intrabar_order_review")active_fourth=true;
   int size=ArraySize(out);ArrayResize(out,size+1,32);out[size]=b;
  }
  // Before a right-confirmed fourth endpoint exists, retain the evolving
  // adverse extreme. A revisited old terminal is not the current fourth.
  // Recovery or source failure ends this observation; it cannot seed wave5.
  if(!active_fourth&&cross==n&&origin_failure==n&&p3.index<n-1){
   int at=p3.index+1;
   for(int k=at+1;k<n;k++)if(sign*BKNResponseAdverse(rows[k],seed.up)<sign*BKNResponseAdverse(rows[at],seed.up))at=k;
   double price=BKNResponseAdverse(rows[at],seed.up);
   if(sign*(price-p3.price)<0&&!BKNWaveCountAmbiguous(ledger,p3.index,at,cutoff)){
    BKNWaveBranch b;ZeroMemory(b);b.third=p3.index;b.fourth=at;b.fifth=-1;b.recovery=-1;b.revisited=-1;
    b.parent_id=seed.count_id;b.source_id=seed.source_id;b.extension=extension;
    b.scenario=extension?"third_wave_extension_scenario":"base_third_scenario";
    b.third_price=p3.price;b.fourth_price=price;
    b.third_known=(datetime)MathMax((long)seed.source_known,MathMax((long)seed.anchor_known[2],(long)p3.known));
    b.fourth_known=(datetime)MathMax((long)b.third_known,(long)(rows[n-1].time+seconds));b.state_known=b.fourth_known;
    b.state="wave4_developing";b.correction="terminal_unconfirmed";b.reason="provisional_fourth_cannot_start_fifth";
    if(sign*(price-seed.price[1])<=0){b.state="wave4_overlap_review";b.reason="explicit_diagonal_exception_required";}
    b.id="book_wave_branch:"+BKNHash(seed.count_id+"|"+BKNPointKey(rows,p3.index,p3.price,decimals)+"|developing4");
    int size=ArraySize(out);ArrayResize(out,size+1,32);out[size]=b;
   }
  }
 }
}
#endif
