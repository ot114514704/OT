"""Verify preserved native receipts; visual observations are recorded separately."""
from pathlib import Path
import csv, hashlib, json

B = Path(__file__).parent
V = B / 'verification/native_r3'
F = V / 'final'
S = '102923304041429_3600'
read = lambda p: p.read_text('utf-8-sig')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = lambda root: read(root / ('render_state_' + S + '.tsv')).strip().split('\t')
rows = lambda root: list(csv.DictReader(read(root / ('continuation_render_' + S + '.tsv')).splitlines(), delimiter='\t'))
request = read(F / ('request_' + S + '.tsv')).splitlines()[0].split('\t')
token = request[2]
final = state(F)
assert final[:3] == ['BEX_RENDER', '1', '1.230-r3']
assert final[3:7] == [token, token, 'full', request[4]]
assert final[7:11] == ['0', '1', '1', '1']
audit = json.loads(read(F / ('audit_' + S + '.json')))
assert audit['token'] == token and audit['full_model']['available']
identity = json.loads(read(F / 'worker_identity.json'))
assert identity['script_sha256'] == sha(B / 'worker.py')
ready = json.loads(read(F / 'native_readiness.json'))
assert ready['passed'] and ready['request_token'] == token
expected = [line.split('\t') for line in read(F / ('reply_' + S + '.tsv')).splitlines() if line.startswith('C\t')]
assert len(expected) == len(rows(F)) == int(final[11])
for actual, wanted in zip(rows(F), expected):
    assert actual['request_token'] == actual['loaded_token'] == token
    assert actual['id'] == wanted[1] and actual['state'] == wanted[8]
    if wanted[2] == wanted[3]:
        continue
    assert actual['line_present'] == '1'
    for key, index in [('actual_start', 2), ('actual_end', 3), ('actual_price0', 4), ('actual_price1', 5)]:
        assert abs(float(actual[key]) - float(wanted[index])) < 1e-7
for directory, controls, hidden_family in [
    ('continue_off', ['0', '0', '1', '1'], None),
    ('shift_off', ['0', '1', '0', '1'], 'GUIDED_SHIFT'),
    ('turning_off', ['0', '1', '1', '0'], 'GUIDED_TURNING'),
]:
    root = V / directory
    s = state(root)
    assert s[3:7] == final[3:7] and s[7:11] == controls
    for row in rows(root):
        if hidden_family is None or row['family'] == hidden_family:
            assert row['line_present'] == '0'
        elif row['start'] != row['end']:
            assert row['line_present'] == '1'
companion = F / 'companion_102923304041429_3600'
loaded = read(companion / 'viewport_102923304041429_H1.loaded.tsv').splitlines()[0]
reply_header = read(companion / 'viewport_102923304041429_H1.reply.tsv').splitlines()[0]
assert loaded == reply_header
assert read(companion / 'chart_102923304041429.tsv').split('\t')[2] == token
provenance = json.loads(read(B / 'FUSION_PROVENANCE.json'))
assert all(sha(Path(p)) == h for p, h in provenance['production_files_unchanged'].items())
assert all(sha(B / 'source/book_native' / p) == h for p, h in provenance['book_headers'].items())
for build in json.loads(read(B / 'verification/compile.json')):
    assert sha((B / build['file']).with_suffix('.ex5')) == build['sha256']
result = {
    'passed': True, 'revision': '1.230-r3', 'chart': S, 'period': 'H1',
    'request_token': token, 'closed_cutoff': int(request[4]), 'captured_utc': int(final[12]),
    'worker_sha256': identity['script_sha256'], 'segments': len(expected),
    'nonzero_segments': ready['verified_nonzero_segments'], 'outer_segments': ready['verified_outer_segments'],
    'controls_verified': ['continuation OFF/ON', 'Book shift OFF/ON', 'Book turning OFF/ON'],
    'companion_loaded_reply_matches': True, 'production_files_unchanged': 70, 'book_core_headers_unchanged': 41,
    'scope': 'One preserved H1 viewport after native reload; historical-input native rendering, not current-market accuracy or all-history acceptance.',
    'visual_observation_record': 'visual_observations.json',
}
(V / 'acceptance.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), 'utf8')
print(json.dumps(result, ensure_ascii=False))
