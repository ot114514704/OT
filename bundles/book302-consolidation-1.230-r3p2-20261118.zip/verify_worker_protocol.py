from pathlib import Path
import json,time,subprocess,sys
BASE=Path(__file__).resolve().parent
folder=BASE/'verification'/'worker_protocol';folder.mkdir(exist_ok=True)
token='offline_'+str(time.time_ns())
raw=(BASE/'verification'/'all_components_request.tsv').read_text(encoding='utf8').replace('offline_all_components',token)
(folder/'request_offline.tsv').write_text(raw,encoding='utf8')
if (folder/'worker.stop').exists():(folder/'worker.stop').unlink()
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
log=(folder/'process.log').open('w',encoding='utf8')
p=subprocess.Popen([sys.executable,str(BASE/'worker.py'),'--folder',str(folder)],stdout=log,stderr=log,startupinfo=startup)
seen=set();started=time.monotonic();reply=folder/'reply_offline.tsv'
try:
 while time.monotonic()-started<100:
  if p.poll() is not None:raise RuntimeError('Worker exited before completing integration; see process.log')
  if reply.exists():
   lines=reply.read_text(encoding='utf8').splitlines();h=lines[0].split('\t')
   if len(h)<8 or h[2]!=token:
    time.sleep(.1);continue
   assert h[:3]==['BEXP_RESULT','1',token] and lines[-1]=='END\t'+token+'\t'+h[3]
   assert len(lines[1].split('\t'))==19
   seen.add(h[7])
   if h[7]=='full':
    audit=json.loads((folder/'audit_offline.json').read_text(encoding='utf8')) if (folder/'audit_offline.json').exists() else None
    if audit and audit.get('token')==token:
     assert audit['full_model']['available'];assert 'core' in seen
     receipt=dict(passed=True,stages=sorted(seen),elapsed=time.monotonic()-started,full_model_available=True,no_mt5_ui_used=True)
     (BASE/'verification'/'worker_protocol_pass.json').write_text(json.dumps(receipt,indent=2),encoding='utf8');print('WORKER_PROTOCOL_PASS',receipt);break
  time.sleep(.1)
 else:raise TimeoutError('No final same-input reply within 100 seconds')
finally:
 (folder/'worker.stop').write_text('offline verification complete',encoding='utf8')
 try:p.wait(timeout=10)
 except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=5)
 log.close()
