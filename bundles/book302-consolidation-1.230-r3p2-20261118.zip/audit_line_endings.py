"""Read existing native artifacts; never replay trades or change a chart."""
from pathlib import Path
import json,csv,hashlib,collections,sys
from datetime import datetime,timezone
sys.stdout.reconfigure(encoding='utf8')
B=Path(__file__).parent;R=B/'runtime/bridge';V=B/'verification/line_endings_20261117';V.mkdir(exist_ok=True)
scope='102923304041429_3600';files={}
for name in ('request_'+scope+'.tsv','audit_'+scope+'.json','continuation_render_'+scope+'.tsv'):
 p=R/name;data=p.read_bytes();assert data==p.read_bytes(),'Artifact changed during copy'
 (V/name).write_bytes(data);files[name]={'sha256':hashlib.sha256(data).hexdigest(),'mtime':p.stat().st_mtime}
audit=json.loads((V/('audit_'+scope+'.json')).read_text('utf8'))
request=(V/('request_'+scope+'.tsv')).read_text('utf-8-sig').splitlines()
token=request[0].split('\t')[2]
render=list(csv.DictReader((V/('continuation_render_'+scope+'.tsv')).read_text('utf-8-sig').splitlines(),delimiter='\t'))
events={p[1]:dict(family=p[2],known=int(p[3]),clock=int(p[4]),state=p[5]) for line in request if (p:=line.split('\t'))[0]=='E'}
fmt=lambda t:datetime.fromtimestamp(t,timezone.utc).isoformat()
rows=[];missing=[];mismatch=[];matched=0;points=0
for r in audit['results']:
 if r['id']=='__CURRENT':continue
 e=events.get(r['id']);c=r.get('continuation')
 row={'id':r['id'],'event_time_native_label':fmt(r['clock']),'code':r['code'],'label':r['label'],'event':e,'continuation':c}
 if not c:row['disposition']='not_admitted_at_original_event'
 else:
  row['disposition']=c['state']
  for seg in c.get('segments',[c]):
   if seg['start']==seg['end']:points+=1;continue
   found=[x for x in render if x['id']==r['id'] and int(x['start'])==seg['start'] and int(x['end'])==seg['end']]
   if not found:missing.append({'id':r['id'],'start':seg['start'],'end':seg['end']});continue
   x=found[0]
   ok=x['line_present']=='1' and all(abs(float(x[a])-float(seg[b]))<1e-7 for a,b in [('actual_start','start'),('actual_end','end'),('actual_price0','price0'),('actual_price1','price1')])
   if ok:matched+=1
   else:mismatch.append(x)
 rows.append(row)
report={'files':files,'audit_token':audit['token'],'request_token':token,'request_audit_match':audit['token']==token,
 'latest_full_model_available':audit['full_model'].get('available'),'event_count':len(rows),
 'classifications':dict(collections.Counter(r['code'] for r in rows)),
 'continuation_states':dict(collections.Counter(r['disposition'] for r in rows)),
 'nonzero_native_segments_matching':matched,'single_point_segments_without_trend_line':points,
 'segments_missing_from_render_receipt':missing,'coordinate_mismatches':mismatch,'events':rows,
 'limits':['Render receipt has no request token; coordinate matching does not prove a fresh visual acceptance or identify the user-marked location.','Native market timestamps are preserved as labels; ISO formatting is not a broker timezone conversion.','Fixed-range exits and late-known Book geometry are not silently extended to remove apparent cutoffs.']}
(V/'line_endings.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({k:v for k,v in report.items() if k not in ('events','files')},ensure_ascii=False,indent=2))
