from pathlib import Path
import shutil
B=Path(__file__).parent;V=B/'verification/outer_handoff_r3/before';V.mkdir(parents=True,exist_ok=True)
for n in ('worker.py','source/BookExperimentGuard.mqh'):
 p=B/n;q=V/n;assert not q.exists();q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
def edit(n,old,new):
 p=B/n;s=p.read_text('utf8');assert s.count(old)==1,(n,old[:80],s.count(old));p.write_text(s.replace(old,new),'utf8')
edit('worker.py','from continuation import observe as observe_continuation','from continuation import observe as observe_continuation\nfrom outer_continuation import handoff as outer_handoff')
edit('worker.py',"        if r['continuation']:r['follow']+='；实验续观：'+r['continuation']['label']", "        r['outer_continuation']=outer_handoff(event,r,snapshots[event['clock']][0],bars,request['cutoff'])\n        if r['continuation']:r['follow']+='；实验续观：'+r['continuation']['label']\n        if r['outer_continuation']:r['follow']+='；'+r['outer_continuation']['label']")
edit('worker.py',"        c=r.get('continuation')\n\n        if c:\n", "        for c in (r.get('continuation'),r.get('outer_continuation')):\n            if not c:continue\n")
n='source/BookExperimentGuard.mqh'
edit(n,'  string key="continuation_"+IntegerToString(k);','  bool outer=StringFind(c.state,"outer_")==0;\n  color continuation_colour=outer?clrDeepSkyBlue:clrGold;\n  string key="continuation_"+IntegerToString(k);')
edit(n,'BEXLine(key+"line",c.start,c.price0,c.end,c.price1,clrGold,STYLE_DOT,1,tip);','BEXLine(key+"line",c.start,c.price0,c.end,c.price1,continuation_colour,STYLE_DOT,1,tip);')
edit(n,'  ObjectSetString(0,n,OBJPROP_TEXT,"  "+reason);','  if(outer)reason=(c.state=="outer_observing"||c.state=="outer_resumed")?"外层续观":c.state=="outer_gap"?"外层间隔暂停":"外层续观结束";\n  ObjectSetString(0,n,OBJPROP_TEXT,"  "+reason);')
edit(n,'ObjectSetInteger(0,n,OBJPROP_COLOR,clrGold);ObjectSetInteger(0,n,OBJPROP_FONTSIZE,8);','ObjectSetInteger(0,n,OBJPROP_COLOR,continuation_colour);ObjectSetInteger(0,n,OBJPROP_FONTSIZE,8);')
print('Separate outer continuation integrated; original Book and inner continuation unchanged.')
