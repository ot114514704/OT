#ifndef BOOK_EXPERIMENT_REQUEST_POLICY
#define BOOK_EXPERIMENT_REQUEST_POLICY
#include "book_native/BookNativeIdentity.mqh"
// Visible-left is intentionally absent. A crossing outside the screen may
// still own an observation segment inside it. Retain every event available
// in the unchanged original Book frame; the worker decides its lifecycle.
bool BEXEventInScope(string family,datetime event_clock,datetime cutoff){
 return (family=="GUIDED_TURNING"||family=="GUIDED_SHIFT")&&event_clock>0&&event_clock<=cutoff;
}
// Same candles can serve different viewport requests. Never accept a reply
// from the previous viewport merely because its candle hash is identical.
string BEXRequestToken(string input_hash,string viewport,bool show_pa,bool strict_pa,string background_hash=""){
 return BKNHash(input_hash+"|"+viewport+"|"+background_hash+"|1.230-r3-outer-chain|"+IntegerToString((int)show_pa)+"|"+IntegerToString((int)strict_pa));
}
#endif
