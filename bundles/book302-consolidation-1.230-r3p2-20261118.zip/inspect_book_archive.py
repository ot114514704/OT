from pathlib import Path
import zipfile,json,hashlib,difflib,sys
sys.stdout.reconfigure(encoding='utf8')
B=Path(__file__).parent;V=B/'verification/book_archive_20261117';V.mkdir(exist_ok=True)
src=Path('C:/Users/qkn/Downloads/forex-ai-source-main.zip')
prefix='forex-ai-source-main/'
report={'source':str(src),'bytes':src.stat().st_size,'book_core_comparison':{},'reference_files':[]}
with zipfile.ZipFile(src) as z:
 for branch in ('Book_1.302_Compiled','Book_1.302_Pending_Source'):
  root=prefix+'indicators/ALEXANDERDELL2/development/'+branch+'/'
  differences=[];missing=[]
  for p in (B/'source/book_native').glob('*.mqh'):
   n=root+'source/book_native/'+p.name
   if n not in z.namelist():missing.append(p.name);continue
   data=z.read(n)
   if data!=p.read_bytes():
    differences.append(p.name)
    out=V/branch/p.name;out.parent.mkdir(exist_ok=True);out.write_bytes(data)
    (V/(branch+'_'+p.stem+'.diff')).write_text(''.join(difflib.unified_diff(p.read_text('utf8').splitlines(True),data.decode('utf8').splitlines(True),fromfile='fusion/'+p.name,tofile=branch+'/'+p.name)),'utf8')
  report['book_core_comparison'][branch]={'compared':41,'differences':differences,'missing':missing}
  for short in ('README.md','SOURCE_STATUS.json'):
   n=root+short;data=z.read(n);out=V/branch/short;out.parent.mkdir(exist_ok=True);out.write_bytes(data)
   report['reference_files'].append({'archive_path':n,'sha256':hashlib.sha256(data).hexdigest()})
 root=prefix+'deliveries/DTE-JHZ39K3/BookUnified_20261106_Outward1071/'
 for short in ('README.md','ARCHIVE_VERIFICATION_EvidenceR2.json','SOURCE_DEPENDENCIES.json'):
  n=root+short
  if n in z.namelist():
   data=z.read(n);out=V/'unified1071'/short;out.parent.mkdir(exist_ok=True);out.write_bytes(data)
 for n in z.namelist():
  if n.startswith(root) and n.endswith('/BookUnified_CURRENT_FULL_DTE-JHZ39K3_20261106_v1071_Display1074_EvidenceR2.zip'):
   data=z.read(n);meta=json.loads((V/'unified1071/ARCHIVE_VERIFICATION_EvidenceR2.json').read_text('utf-8-sig'))
   assert hashlib.sha256(data).hexdigest()==meta['sha256']
   (V/'unified1071'/Path(n).name).write_bytes(data)
   report['reference_files'].append({'archive_path':n,'sha256':meta['sha256'],'status':'different branch, not installed'})
report['scope']='Read archive contents only. Existing compiled Book core already matches; pending source and different Unified branch are not substituted into the approved layout.'
(V/'archive_comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
