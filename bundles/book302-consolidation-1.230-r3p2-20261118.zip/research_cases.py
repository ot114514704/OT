"""Read native bars and original Book records; never write production inputs."""
from pathlib import Path
from datetime import datetime, timezone
from dataclasses import dataclass
import csv,json,sys,time
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'research_snapshot'))
from ict_trader.core import Bar
from ict_trader.ipda_ranges import observe_ranges,phase_evidence
from ict_trader.macro_consolidation import PARAMETERS as MACRO_PARAMETERS
from ict_trader.dense_pauses import observe_dense_pauses
@dataclass(frozen=True)
class NativeBar(Bar):
    calendar_weekends:bool=True
FILES=Path(r'C:\Users\qkn\AppData\Roaming\MetaQuotes\Terminal\D0E8209F77C8CF37AD8BF550E51FF075\MQL5\Files\Book302Experiment')
def stamp(v):return int(datetime.fromisoformat(v).timestamp())
def load_bars(path):
    with path.open(encoding='utf-8-sig') as f:
        return [NativeBar(datetime.fromtimestamp(int(r['time']),timezone.utc),*(float(r[k]) for k in ('open','high','low','close','spread')),seconds=3600) for r in csv.DictReader(f,delimiter='\t')]
def compute(bars):
    contexts=[];states=[]
    for level,params,basis in [('local',None,'body'),('macro',MACRO_PARAMETERS,'liquidity')]:
        obs=observe_ranges(bars,bars[-1].closed_at,parameters=params,level=level,breakout_basis=basis)
        for row in obs['rows']:
            ev=phase_evidence(row,bars);r=ev['range'] or ev['ended']
            if r:states.append(dict(clock=stamp(row['known_at']),kind=level,event=ev['event'],**r))
        print(level,len(obs['ranges']),flush=True)
    for r in observe_dense_pauses(bars,bars[-1].closed_at):contexts.append(dict(kind='dense',**r))
    print('dense',len(contexts),flush=True)
    return contexts,states
def main():
    bars=load_bars(FILES/'history.tsv');contexts,states=compute(bars)
    (BASE/'native_context.json').write_text(json.dumps(dict(contexts=contexts,states=states),ensure_ascii=False),encoding='utf8')
    byclose={int(b.closed_at.timestamp()):i for i,b in enumerate(bars)};bytime={int(b.time.timestamp()):i for i,b in enumerate(bars)}
    lines=list(csv.DictReader((FILES/'book_scan.tsv').open(encoding='utf-8-sig'),delimiter='\t'))
    seen=set();cases=[]
    for s in lines:
        cross=int(s['cross']);known=int(s['known']);ia=bytime.get(int(s['anchor_a']));ib=bytime.get(int(s['anchor_b']));ix=byclose.get(cross)
        if not cross or ix is None or ia is None or ib is None or ia==ib or known>cross-3600 or 'retrospective' in s['state'] or s['family']!='GUIDED_TURNING':continue
        key=(s['anchor_a'],s['anchor_b'],cross)
        if key in seen:continue
        seen.add(key);b=bars[ix];pa=float(s['price_a']);pb=float(s['price_b']);slope=(pb-pa)/(ib-ia);line=pa+slope*(ix-ia)
        matches=[]
        for r in states:
            if r['clock']!=cross or r['event']=='breakout_confirmed' or stamp(r['known_at'])>int(b.time.timestamp()):continue
            if r['low']<=b.close<=r['high']:matches.append(dict(**r,mature=True))
        for r in contexts:
            if not stamp(r['known_at'])<=int(b.time.timestamp()) or stamp(r['end_at'])<cross or not r['low']<=b.close<=r['high']:continue
            matches.append(dict(**r,mature=False))
        if not matches:continue
        r=sorted(matches,key=lambda x:(not x['mature'],x['high']-x['low']))[0]
        item=dict(original=s,clock=cross,bar=int(b.time.timestamp()),close=b.close,previous_close=bars[ix-1].close,line=line,slope=slope,context=r)
        cases.append(item)
    cases.sort(key=lambda x:x['clock'],reverse=True)
    (BASE/'all_example_candidates.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2),encoding='utf8')
    chosen=[]
    for c in cases:
        if any(abs(c['clock']-x['clock'])<2*86400 or c['context']['id']==x['context']['id'] for x in chosen):continue
        chosen.append(c)
        if len(chosen)==5:break
    (BASE/'five_examples.json').write_text(json.dumps(chosen,ensure_ascii=False,indent=2),encoding='utf8')
    print('candidates',len(cases),'chosen',len(chosen),flush=True)
    for c in chosen:print(datetime.fromtimestamp(c['clock'],timezone.utc).isoformat(),c['close'],c['line'],c['context']['kind'],c['context']['low'],c['context']['high'],flush=True)
if __name__=='__main__':main()
