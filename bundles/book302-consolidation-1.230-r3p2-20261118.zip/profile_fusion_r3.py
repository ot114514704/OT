"""Profile one preserved native request; no live state or trading writes."""
from pathlib import Path
import cProfile, pstats, io, json, time
from worker import parse_request, solve

B=Path(__file__).parent
V=B/'verification/performance_r3_20261118'
V.mkdir(exist_ok=True)
request=parse_request((B/'verification/native_r3/final/request_102923304041429_3600.tsv').read_text('utf-8-sig'))
profile=cProfile.Profile()
start=time.perf_counter()
results=profile.runcall(solve,request,lambda msg:print(msg,flush=True))
elapsed=time.perf_counter()-start
profile.dump_stats(str(V/'solve.pstats'))
output=io.StringIO()
pstats.Stats(profile,stream=output).strip_dirs().sort_stats('cumulative').print_stats(35)
(V/'solve.profile.txt').write_text(output.getvalue(),'utf8')
(V/'baseline_results.json').write_text(json.dumps(results,ensure_ascii=False),'utf8')
(V/'timing.json').write_text(json.dumps({'seconds_with_profiler':elapsed,'results':len(results),'scope':'Offline recognizer profiling of an existing native chart request; not live latency or trading backtest.'},indent=2),'utf8')
print(output.getvalue(),flush=True)
