from pathlib import Path
import shutil,json,hashlib
B=Path(__file__).parent
V=B/'verification/background_refresh_r2';V.mkdir(exist_ok=True)
names=['source/BookExperimentGuard.mqh','source/BookExperimentRequestPolicy.mqh','source/Book302_Consolidation_Experiment.mq5','companions/IPDA_Consolidation_Adapted.mq5','worker.py','research_adapter.py']
before={}
for name in names:
 p=B/name;q=V/'before'/name
 assert not q.exists(), 'Do not reapply this patch'
 q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 before[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(V/'before.json').write_text(json.dumps(before,indent=2),'utf8')
def edit(name,old,new):
 p=B/name;s=p.read_text('utf8');assert s.count(old)==1,(name,old[:90],s.count(old));p.write_text(s.replace(old,new),'utf8')
edit(names[1],'bool show_pa,bool strict_pa){','bool show_pa,bool strict_pa,string background_hash=""){')
edit(names[1],'input_hash+"|"+viewport+"|1.230-offscreen-continuation-r1|"','input_hash+"|"+viewport+"|"+background_hash+"|1.230-background-r2|"')
edit(names[0],' string token=BEXRequestToken(input_hash,viewport,ExperimentShowThreePush,ExperimentStrictThreePush);if(token==bex_token&&viewport==bex_view)return;', ''' // CopyRates may initially return no background while MT5 fetches it.
 // Recheck even when the primary candles are unchanged; hash only closed rows.
 ENUM_TIMEFRAMES background_period=_Period==PERIOD_H1?PERIOD_M15:PERIOD_H1;
 int background_seconds=PeriodSeconds(background_period);
 MqlRates background[];ArraySetAsSeries(background,false);
 int count=CopyRates(_Symbol,background_period,cutoff-background_seconds,background_period==PERIOD_M15?3000:1200,background);
 string background_key=IntegerToString(background_seconds);
 for(int i=0;i<count;i++)if(background[i].time+background_seconds<=cutoff)
  background_key+="|"+IntegerToString((long)background[i].time)+","+StringFormat("%.17g",background[i].open)+","+StringFormat("%.17g",background[i].high)+","+StringFormat("%.17g",background[i].low)+","+StringFormat("%.17g",background[i].close)+","+IntegerToString(background[i].spread);
 string token=BEXRequestToken(input_hash,viewport,ExperimentShowThreePush,ExperimentStrictThreePush,BKNHash(background_key));if(token==bex_token&&viewport==bex_view)return;''')
edit(names[0],''' ENUM_TIMEFRAMES background_period=_Period==PERIOD_H1?PERIOD_M15:PERIOD_H1;int background_seconds=PeriodSeconds(background_period);

 MqlRates background[];int count=CopyRates(_Symbol,background_period,cutoff-background_seconds,background_period==PERIOD_M15?3000:1200,background);
''','')
# Failed publication must be retryable on the next native revision check.
edit(names[0],'if(f==INVALID_HANDLE){bex_note="无法写入独立请求文件";', 'if(f==INVALID_HANDLE){bex_token="";bex_note="无法写入独立请求文件";')
edit(names[0],'if(!FileMove(tmp,0,dest,FILE_REWRITE)){bex_note=', 'if(!FileMove(tmp,0,dest,FILE_REWRITE)){bex_token="";bex_note=')
edit(names[2],'if(identity==applied_input){request_pending=false;view.Status(NativeDataLabel(cutoff)+source_inspection_status);return;}', 'if(identity==applied_input){request_pending=false;BEXSubmit(rows,book.shapes,identity,requested_view,cutoff);view.Status(NativeDataLabel(cutoff)+source_inspection_status);return;}')
edit(names[0],'if(bex_loaded==bex_token&&bex_stage=="full"){', 'if(bex_loaded==bex_token&&(bex_stage=="full"||bex_stage=="limited")){')
edit(names[0],'if(bex_hidden){bex_hidden=false;BEXDraw();}else BEXPanel();return;}', 'if(bex_stage=="limited")bex_note="范围约束可用；综合模型缺少数据或计算失败，待重试";if(bex_hidden){bex_hidden=false;BEXDraw();}else BEXPanel();return;}')
edit(names[0],'if(bex_stage=="core")bex_note="范围约束已核对；原研究全模型旁证计算中（不采用旧输入）";', 'if(bex_stage=="core")bex_note="范围约束已核对；原研究全模型旁证计算中（不采用旧输入）";if(bex_stage=="limited")bex_note="范围约束可用；综合模型缺少数据或计算失败，待重试";')
edit(names[3],'string workingFolder="";', 'string workingFolder="",fusion_model_status="";')
edit(names[3],'string DisplayHealth()\n  {', 'string DisplayHealth()\n  {\n   if(fusion_model_status=="pending")return "融合模型重算中；保留历史图形，非本帧确认";\n   if(fusion_model_status=="unavailable")return "融合模型数据不足或计算失败；历史图形不作当前确认";')
edit(names[3],'heartbeat_written=StringToInteger(a[12]);expected_revision=a[3];','heartbeat_written=StringToInteger(a[12]);expected_revision=a[3];fusion_model_status=a[5];')
print('Background retry and status patch prepared; native reload pending.')
