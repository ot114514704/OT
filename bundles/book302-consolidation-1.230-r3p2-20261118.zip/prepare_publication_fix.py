from pathlib import Path
B=Path(__file__).parent
p=B/'worker.py';s=p.read_text('utf8')
def replace(old,new):
 global s
 assert s.count(old)==1,(old[:90],s.count(old))
 s=s.replace(old,new)
replace("VERSION='Book302-consolidation-experiment-1.230'", "VERSION='Book302-consolidation-experiment-1.230'\nfrom fusion_publication import publish_model_state,completed_stage")
replace("                progress('开始按各事件时刻独立截断重算')", "                publish_model_state(folder/f'companion_{prefix}',req,'pending','当前视窗综合模型计算中；历史图形不作本帧确认',atomic)\n                progress('开始按各事件时刻独立截断重算')")
replace("                    atomic(folder/f'full_model_{prefix}.json'", "                    if path.read_text(encoding='utf-8-sig')!=raw:continue\n                    atomic(folder/f'full_model_{prefix}.json'")
replace("                atomic(folder/f'reply_{prefix}.tsv',encode_reply(req,results,time.monotonic()-t,'full'))", "                if not report.get('available'):\n                    publish_model_state(folder/f'companion_{prefix}',req,'unavailable',report.get('reason',report.get('error','综合模型不可用')),atomic)\n                atomic(folder/f'reply_{prefix}.tsv',encode_reply(req,results,time.monotonic()-t,completed_stage(report)))")
replace("seen[path]=key;progress('完成；范围和原研究综合旁证已发布')", "seen[path]=key;progress('完成；范围和原研究综合旁证已发布' if report.get('available') else '范围约束可用；综合模型未完成，等待原生数据补齐')")
p.write_text(s,'utf8')
print('Publication status fixed; running worker unchanged until explicit restart.')
