import test_continuation as base
import unittest,tempfile
from pathlib import Path
from unittest.mock import patch
from worker import atomic,publish_heartbeat,encode_reply,classify

class GapRecoveryTests(unittest.TestCase):
 setUp=base.ContinuationTests.setUp
 bar=base.ContinuationTests.bar
 run_observation=base.ContinuationTests.run_observation
 def test_two_postgap_bodies_resume_without_joining_gap(self):
  bars=self.bars[:2]+[self.bar(50,4005),self.bar(51,4005),self.bar(52,4006)]
  c=self.run_observation(bars);self.assertEqual(c['state'],'resumed');self.assertEqual(len(c['segments']),2)
  first,second=c['segments'];self.assertEqual(first['end'],int(bars[1].time.timestamp()))
  self.assertEqual(second['start'],int(bars[3].time.timestamp()));self.assertEqual(second['known'],int(bars[3].closed_at.timestamp()))
  self.assertEqual(second['price0'],4001);self.assertEqual(second['price1'],4000)
 def test_one_postgap_close_not_enough(self):
  c=self.run_observation(self.bars[:2]+[self.bar(50,4005)])
  self.assertEqual(c['state'],'gap');self.assertEqual(len(c['segments']),1)
 def test_gap_does_not_use_pre_gap_close_for_resume(self):
  c=self.run_observation(self.bars[:2]+[self.bar(50,4005)])
  self.assertNotEqual(c['state'],'resumed')
 def test_wick_return_does_not_resume_outside_body(self):
  bars=self.bars[:2]+[self.bar(50,4011),self.bar(51,4012)]
  c=self.run_observation(bars);self.assertEqual(c['state'],'gap_exit');self.assertEqual(len(c['segments']),1)
 def test_long_gap_terminates(self):
  c=self.run_observation(self.bars[:2]+[self.bar(120,4005),self.bar(121,4005)])
  self.assertEqual(c['state'],'long_gap');self.assertEqual(len(c['segments']),1)
 def test_second_gap_resets_reentry_confirmation(self):
  c=self.run_observation(self.bars[:2]+[self.bar(50,4005),self.bar(55,4005)])
  self.assertEqual(c['state'],'gap');self.assertEqual(len(c['segments']),1)
 def test_two_outside_after_resume_end_observation(self):
  bars=self.bars[:2]+[self.bar(50,4005),self.bar(51,4005),self.bar(52,4011),self.bar(53,4012),self.bar(54,4005)]
  c=self.run_observation(bars);self.assertEqual(c['state'],'fixed_envelope_exit')
  self.assertEqual(c['segments'][-1]['end'],int(bars[-2].time.timestamp()))
 def test_future_suffix_does_not_resume_past_gap(self):
  bars=self.bars[:2]+[self.bar(50,4005),self.bar(51,4005),self.bar(52,4005)]
  cutoff=int(bars[2].closed_at.timestamp())
  self.assertEqual(self.run_observation(bars[:3],cutoff=cutoff),self.run_observation(bars,cutoff=cutoff))
 def test_completed_pre_gap_segment_never_rewritten(self):
  bars=self.bars[:2]+[self.bar(50,4005),self.bar(51,4005),self.bar(52,4005)]
  a=self.run_observation(bars[:3]);b=self.run_observation(bars)
  self.assertEqual(a['segments'][0],b['segments'][0])
 def test_protocol_segments_remain_separate(self):
  bars=self.bars[:2]+[self.bar(50,4005),self.bar(51,4005),self.bar(52,4005)]
  r=classify(self.event,self.bars[:1],[self.box]);r['continuation']=self.run_observation(bars)
  rows=[x.split('\t') for x in encode_reply(dict(token='gap',cutoff=int(bars[-1].closed_at.timestamp())),[r],0).splitlines() if x.startswith('C\t')]
  self.assertEqual(len(rows),2);self.assertLess(int(rows[0][3]),int(rows[1][2]))

class PublicationTests(unittest.TestCase):
 def test_retry_sharing_violation_then_publish_whole_file(self):
  with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as name:
   path=Path(name)/'beat';path.write_text('old')
   import os
   replace=os.replace
   with patch('worker.os.replace',side_effect=[PermissionError('locked'),None]) as mocked,patch('worker.time.sleep'):
    # Perform a real replace when the simulated second attempt succeeds.
    def attempt(src,dst):
     if mocked.call_count==1:raise PermissionError('locked')
     replace(src,dst)
    mocked.side_effect=attempt;atomic(path,'complete new payload')
   self.assertEqual(path.read_text(),'complete new payload');self.assertEqual(mocked.call_count,2)
 def test_persistent_heartbeat_lock_does_not_exit_worker(self):
  with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as name:
   path=Path(name);(path/'worker_heartbeat.txt').write_text('old')
   with patch('worker.os.replace',side_effect=PermissionError('locked')),patch('worker.time.sleep'),patch('worker.sys.stderr'):
    publish_heartbeat(path)
   self.assertEqual((path/'worker_heartbeat.txt').read_text(),'old')

if __name__=='__main__':unittest.main(verbosity=2)
