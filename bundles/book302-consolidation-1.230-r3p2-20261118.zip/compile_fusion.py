from pathlib import Path
import subprocess,json,hashlib
B=Path(__file__).parent;items=[]
for rel in ('source/Book302_Consolidation_Experiment.mq5','companions/IPDA_Consolidation_Adapted.mq5','companions/original_overlay/Book_ThreePush_Adapted.mq5','companions/pa_shapes/Book_PA_Adapted.mq5','native_scripts/Book302_Open_Experiment.mq5'):
 p=B/rel;log=B/'verification'/(p.stem+'.compile.log')
 if not (p.with_suffix('.ex5').exists() and log.exists() and p.with_suffix('.ex5').stat().st_mtime>=max(x.stat().st_mtime for x in p.parent.rglob('*.mq*'))):
  subprocess.run(['C:/Program Files/MetaTrader 5/MetaEditor64.exe','/compile:'+str(p),'/log:'+str(log)],creationflags=subprocess.CREATE_NO_WINDOW)
 raw=log.read_bytes();s=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
 assert '0 errors, 0 warnings' in s,s[-1500:]
 ex=p.with_suffix('.ex5');assert ex.exists()
 item=dict(file=rel,bytes=ex.stat().st_size,sha256=hashlib.sha256(ex.read_bytes()).hexdigest(),compile='0 errors, 0 warnings');items.append(item);print(json.dumps(item),flush=True)
(B/'verification/compile.json').write_text(json.dumps(items,ensure_ascii=False,indent=2),'utf-8')
