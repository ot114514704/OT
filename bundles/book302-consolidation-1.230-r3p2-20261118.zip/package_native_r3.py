"""Immutable local recovery package and a smaller OT experiment bundle."""
from pathlib import Path
import hashlib, json, zipfile

B = Path(__file__).parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
native = json.loads((B / 'verification/native_r3/acceptance.json').read_text('utf8'))
assert native['passed']
visual = json.loads((B / 'verification/native_r3/visual_observations.json').read_text('utf8'))
assert visual['r3_reload_observed'] and visual['final_channel_triangle_continuation_shift_turning_on']
meta = json.loads((B / 'REVISION_R3.json').read_text('utf8'))
meta.update(native_visual_verified=True, reload_acceptance_pending=False,
            native_acceptance_scope=native['scope'], native_acceptance='verification/native_r3/acceptance.json',
            running_worker_recorded_sha256=native['worker_sha256'])
meta['checks'].append('Native H1 reload: 61 nonzero segments / 31 outer segments matched; three continuation visibility combinations and restoration passed; companion loaded reply matches.')
meta['limits'][2] = 'Full background-data retry transitions, other viewports and exact boundary/layout acceptance remain pending; existing overlapping labels remain.'
(B / 'REVISION_R3.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2), 'utf8')
readme = (B / 'README_R3.txt').read_text('utf8')
start = readme.index('状态：')
end = readme.index('启动入口', start)
readme = readme[:start] + '''状态更新（2026-11-18）：r3 Worker 已重启，独立 H1 图表已重载。当前历史视窗的请求、完整回包、原生绘图及盘整载入回执一致；61段非零续观线包含31段外层线，实际对象坐标全部匹配。实图观察了蓝色外层续观、续观关/开、Book通道及拐点分别关/开；最终通道、三角、续观、Book通道与拐点均开启。截图及回执见 verification/native_r3。原 Book 41个核心文件和70个生产文件再次核对未变。
此结论仅限本次历史视窗。全部日期断头、实时分类、原生背景补齐重试过程、重叠标签与整模延迟仍待验证或优化。没有替换稳定版，没有设置系统自启。

''' + readme[end:]
readme = readme.replace('当前实盘运行记录仍指向旧worker和旧请求规则；这些文件检查不等于r3已经加载。', '当前 r3 原生载入已由 verification/native_r3 的新回执与实图另行验证。')
(B / 'README_R3.txt').write_text(readme, 'utf8')
old = (B / 'README.txt').read_text('utf8')
(B / 'README.txt').write_text('当前修订为 1.230-r3：已完成一个独立 H1 历史视窗的重载、续接坐标与独立开关验收。请先阅读 README_R3.txt、REVISION_R3.json 和 verification/native_r3。以下保留初版历史说明。\n' + old[old.index('\n'):], 'utf8')
files = {B / row['path'] for row in json.loads((B / 'MANIFEST_R3.json').read_text('utf8'))}
files.update(p for p in (B / 'verification/native_r3').rglob('*') if p.is_file())
files.update([B / 'README.txt', B / 'package_native_r3.py', B / 'verify_native_snapshot_r3.py'])
files = sorted(files)
out = B.parent / '备份/Book302_盘整融合1.230-r3_原生有限验收_20261118.zip'
upload = B.parent / '上传/OT_20261118_fusion_r3'
upload.mkdir(parents=True, exist_ok=True)

def pack(destination, items):
    manifest = [{'path':p.relative_to(B).as_posix(), 'bytes':p.stat().st_size, 'sha256':sha(p)} for p in items]
    with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in items:
            z.write(p, p.relative_to(B).as_posix())
        z.writestr('NATIVE_PACKAGE_MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None
        for row in manifest:
            assert hashlib.sha256(z.read(row['path'])).hexdigest() == row['sha256']
    return {'path':str(destination), 'sha256':sha(destination), 'bytes':destination.stat().st_size,
            'files_verified':len(manifest), 'git_blob_sha':hashlib.sha1(b'blob ' + str(destination.stat().st_size).encode() + b'\0' + destination.read_bytes()).hexdigest()}

local = pack(out, files)
# Keep full native model snapshots in the local backup. Ship source, binaries,
# preserved tests, new chart-only image and compact acceptance in the OT bundle.
public = [p for p in files if 'verification/native_r3/' not in p.relative_to(B).as_posix()]
for rel in ['acceptance.json', 'visual_observations.json',
            'final/native_readiness.json', 'final/experiment_102923304041429_3600.png',
            'final/render_state_102923304041429_3600.tsv',
            'final/continuation_render_102923304041429_3600.tsv']:
    public.append(B / 'verification/native_r3' / rel)
remote = pack(upload / 'book302-consolidation-1.230-r3-native-limited-20261118.zip', sorted(set(public)))
receipt = {'local':local, 'ot_bundle':remote, 'native_scope':native['scope'],
           'uploaded':False, 'stable_backup_unchanged':True,
           'full_native_model_snapshots':'Local backup only; compact evidence and chart-only screenshot included in OT bundle.'}
(B / 'PACKAGE_R3_NATIVE.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), 'utf8')
(upload / 'package_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), 'utf8')
print(json.dumps(receipt, ensure_ascii=False))
