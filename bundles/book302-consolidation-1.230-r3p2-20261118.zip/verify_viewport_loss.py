"""Reproduce disappearance using saved native reply/actual chart objects."""
from pathlib import Path
import json,csv
BASE=Path(__file__).resolve().parent
baseline=Path(r'D:\盘整研究资料\Book302_间隔恢复实验_1.220_20261116/verification')
audit=json.loads((baseline/'native_audit_1220.json').read_text(encoding='utf8'))
results={r['id']:r for r in audit['results']}
segments=list(csv.DictReader((baseline/'native_all_on.tsv').open(encoding='utf-8-sig'),delimiter='\t'))
left=1794272400 # 2026-11-10 01:00, before the real 02:00 resumption segment.
lost=[]
for s in segments:
 r=results[s['id']]
 old_accept=r['clock']-3600>=left
 if int(s['end'])>=left and not old_accept:
  lost.append(dict(event=s['id'],cross=r['clock'],segment_start=int(s['start']),segment_end=int(s['end']),state=s['state']))
assert any(x['state']=='resumed' for x in lost),'No genuine offscreen-origin counterexample'
receipt=dict(reproduced=True,visible_left=left,baseline='1.220',lost_visible_segments=lost,
 reason='Original bridge filters by crossing candle >= visible left, although continuation remains visible',
 fix='1.230 submits all original Book frame events; viewport participates in reply identity',native_1230_verified=False)
(BASE/'verification/viewport_disappearance.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
print('REPRODUCED:',len(lost),'visible segments lost by old viewport filter')
