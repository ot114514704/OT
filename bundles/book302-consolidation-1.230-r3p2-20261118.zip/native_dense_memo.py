"""Reuse pristine dense-window metrics on exact immutable native prefixes.

All qualification, range identities, exits and display selection are recomputed
by the unchanged scanner. The independent fusion worker owns the memo; the
production research scanner and its default calls are unchanged.
"""
import json
from ict_trader.core import visible
from ict_trader import dense_pauses,oscillation


class NativeDenseMemo:
    def __init__(self,bar_type,*,window_limit=40000,bar_limit=10000,byte_limit=64*1024*1024):
        if any(type(n) is not int or n<1 for n in (window_limit,bar_limit,byte_limit)):
            raise ValueError('Positive integer limits required')
        self.bar_type=bar_type
        self.window_limit=window_limit;self.bar_limit=bar_limit;self.byte_limit=byte_limit
        self.keys=();self.parameters=None;self.windows={}
        self.calls=0;self.rebuilds=0;self.last_reused=0;self.retained_bytes=0

    def observe(self,bars,asof):
        closed=visible(bars,asof)
        if len(closed)>self.bar_limit or any(type(b) is not self.bar_type for b in closed):
            result=dense_pauses.observe_dense_pauses(closed,asof)
            self.keys=();self.parameters=None;self.windows={};self.retained_bytes=0
            self.calls+=1;self.rebuilds+=1;self.last_reused=0
            return result
        keys=tuple(json.dumps((b.time.isoformat(),b.time.fold,b.closed_at.isoformat(),b.seconds,
                   b.open,b.high,b.low,b.close,b.spread,b.calendar_weekends),allow_nan=False) for b in closed)
        parameters=json.dumps((dense_pauses.PARAMETERS,oscillation.PARAMETERS),sort_keys=True,allow_nan=False)
        reuse=(self.parameters==parameters and len(keys)>=len(self.keys) and keys[:len(self.keys)]==self.keys)
        candidates=dense_pauses._WindowSnapshots(closed,asof)
        if reuse:candidates.windows=self.windows.copy()
        retained=len(candidates.windows)
        # Publish memo state only after successful computation. Qualifiers
        # receive independent copies, including on the first candidate call.
        result=dense_pauses.observe_dense_pauses(closed,asof,_candidate_cache=candidates)
        windows=candidates.windows
        total=sum(len(v) for v in windows.values())
        if len(windows)>self.window_limit or total>self.byte_limit:
            selected={};size=0
            for key in sorted(windows,key=lambda k:(k[1],k[0]),reverse=True):
                value=windows[key]
                if len(value)>self.byte_limit-size:continue
                selected[key]=value;size+=len(value)
                if len(selected)>=self.window_limit:break
            windows=selected;total=size
        self.keys=keys;self.parameters=parameters;self.windows=windows;self.retained_bytes=total
        self.calls+=1;self.rebuilds+=int(not reuse);self.last_reused=retained
        return result

    def metadata(self):
        return dict(calls=self.calls,rebuilds=self.rebuilds,last_reused=self.last_reused,
                    retained_windows=len(self.windows),retained_bytes=self.retained_bytes,
                    retained_bars=len(self.keys),window_limit=self.window_limit,byte_limit=self.byte_limit)
