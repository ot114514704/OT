"""Final checks against captured MT5 objects, immutable source and native bars."""
from pathlib import Path
import csv,json,hashlib,zipfile,time
from datetime import datetime,timezone
from worker import BASE,parse_request
V=BASE/'verification'
def read(name):return json.loads((V/name).read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(name):return list(csv.DictReader((V/name).read_text(encoding='utf-8-sig').splitlines(),delimiter='\t'))
req=parse_request((V/'native_request_1220.tsv').read_text(encoding='utf8'))
audit=read('native_audit_1220.json');render=rows('native_all_on.tsv')
assert audit['token']==req['token']
assert audit['version'].endswith('1.220') and audit['full_model']['available']
assert set(audit['full_model']['periods'])=={'H1','M15'}
assert len(render)==5 and len({r['id'] for r in render})==4
assert any(r['state']=='resumed' for r in render)
positions={int(b.time.timestamp()):i for i,b in enumerate(req['bars'])}
for r in render:
    assert r['line_present']==r['label_present']=='1'
    for expected,actual in [('start','actual_start'),('end','actual_end'),('price0','actual_price0'),('price1','actual_price1')]:
        assert abs(float(r[expected])-float(r[actual]))<1e-8
    a,b=positions[int(r['start'])],positions[int(r['end'])]
    assert all(req['bars'][i].closed_at==req['bars'][i+1].time for i in range(a,b))
for name,family in [('native_shift_off.tsv','GUIDED_SHIFT'),('native_turning_off.tsv','GUIDED_TURNING')]:
    off=rows(name);assert len(off)==len(render)
    for r in off:assert r['line_present']==r['label_present']==('0' if r['family']==family else '1')
assert all(r['line_present']==r['label_present']=='0' for r in rows('native_all_off.tsv'))
archive=Path(r'D:\CodexData\Downloads\forex-ai-source-main.zip')
root='forex-ai-source-main/indicators/ALEXANDERDELL2/development/Book_1.302_Compiled/source/book_native/'
headers=list((BASE/'source/book_native').glob('*.mqh'));assert len(headers)==41
with zipfile.ZipFile(archive) as z:
    for p in headers:assert z.read(root+p.name)==p.read_bytes(),p.name
production=Path(r'D:\盘整研究资料\项目\盘整研究');modules=[];differences=[]
for p in sorted((BASE/'research_snapshot/ict_trader').glob('*.py')):
    current=production/'ict_trader'/p.name
    same=current.exists() and sha(current)==sha(p)
    modules.append(dict(name=p.name,sha256=sha(p),matches_production_at_verification=same))
    if not same:differences.append(p.name)
# The other research chat updated display-only coexistence during acceptance.
# Keep this tested snapshot pinned; never silently mix new code into a live
# verified worker. All recognition/calculation modules must still match.
assert set(differences)<= {'display_selection.py','layout_preferences.py'},differences
assert sha(BASE/'research_snapshot/app_source.py')==sha(production/'app.py')
captured=datetime.now(timezone.utc).isoformat()
(BASE/'LATEST_RESEARCH_IMPORT.json').write_text(json.dumps(dict(stage=str(BASE),source=str(production),verified_at=captured,
    modules=modules,app_sha256=sha(BASE/'research_snapshot/app_source.py'),newer_production_display_only=differences,
    policy='Pinned tested snapshot; production changed two display-only coexistence filters during acceptance. Recognition and app calculation match. No production writes.'),ensure_ascii=False,indent=2),encoding='utf8')
assert read('latest_cache_equivalence.json')['passed']
test_log=(V/'tests_1.220.log').read_text(encoding='utf-8-sig')
assert 'Ran 41 tests' in test_log and test_log.rstrip().endswith('OK')
replay=read('gap_native_1.220.json')
assert len(replay['events'])==5 and sum(len(r['segments']) for r in replay['events'])==11
assert replay['all_segments_avoid_missing_bars']
assert read('windows_file_lock_1.220.json')['passed']
for name in ('compile1220r2.log','compile_opener1220.log'):
    assert '0 errors, 0 warnings' in (BASE/name).read_text(encoding='utf-16')
deliverables=['worker.py','continuation.py','research_adapter.py','source/BookExperimentGuard.mqh',
 'source/Book302_Consolidation_Experiment.mq5','source/Book302_Consolidation_Experiment.ex5',
 'native_scripts/Book302_Open_Experiment.mq5','native_scripts/Book302_Open_Experiment.ex5']
for attempt in range(15):
    try:beat=int((BASE/'runtime/bridge/worker_heartbeat.txt').read_text());break
    except PermissionError:
        if attempt==14:raise
        time.sleep(.1)
assert time.time()-beat<15
receipt=dict(version='1.220',revision='associated-range-gap-cache-r2',verified_at=captured,passed=True,
 original_headers_exact=41,artifact_sha256={name:sha(BASE/name) for name in deliverables},tests_passed=41,historical_events=5,historical_segments=11,
 cache_equivalence_cases=4,native_chart=str(req['chart']),native_token=req['token'],native_cutoff=req['cutoff'],
 native_events=4,native_segments=5,native_gap_resume=True,native_object_coordinates_exact=True,
 native_button_checks=['source off/on','shift off/on with continuation','turning off/on with continuation','H1 ZigZag off/on','all continuation off/on'],
 full_model_native_periods=['H1','M15'],full_model_native_seconds=audit['elapsed_seconds'],newer_production_display_only=differences,
 evidence=['native_request_1220.tsv','native_reply_1220.tsv','native_audit_1220.json','native_all_on.tsv','native_shift_off.tsv','native_turning_off.tsv','native_all_off.tsv','native_1220.png','gap_native_1.220.json','latest_cache_equivalence.json','windows_file_lock_1.220.json'],
 limits=['Native visual acceptance covers this XAUUSD H1 viewport, not all symbols/timeframes.',
 'Original Book endpoints remain unchanged; yellow experimental continuation is separate.',
 'No interpolation across missing bars; gap exit and >96h gaps legitimately terminate observation.',
 'Two-close continuation lifecycle is an experimental rule, not an original-book trend confirmation.',
 'ChartScreenShot export crops rightmost labels differently from the live DPI-scaled UI.',
 'Start the standalone Python worker after reboot; no system autostart installed.'])
(BASE/'VERIFICATION.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
(V/'1.220.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
print('RELEASE_ACCEPTANCE_PASS',len(render),'native segments;',len(modules)-len(differences),'production modules match; display-only differences:',differences,flush=True)
