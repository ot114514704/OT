from pathlib import Path
import json,hashlib,re
B=Path(__file__).parent;R=Path('D:/盘整研究资料/项目/盘整研究')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((B/'FUSION_PROVENANCE.json').read_text('utf-8'))
for path,digest in manifest['production_files_unchanged'].items():assert sha(Path(path))==digest,path
headers=list((B/'source/book_native').glob('*.mqh'));assert len(headers)==41
for p in headers:assert sha(p)==manifest['book_headers'][p.name],p.name
snapshot_differences=[]
for p in (R/'ict_trader').glob('*.py'):
 if p.read_bytes()==(B/'research_snapshot/ict_trader'/p.name).read_bytes():continue
 # The optional pure-window callback is an explicitly verified experiment
 # patch, not a silent change to the stable research engine.
 evidence=json.loads((B/'verification/performance_r3_20261118/integration_acceptance.json').read_text('utf8'))
 key='research_snapshot/ict_trader/'+p.name
 assert p.name in ('long_geometry.py','native_triangles.py') and evidence['passed'] and evidence['full_output_exact']
 assert sha(B/key)==evidence['source_sha256'][key],p.name
 assert p.read_bytes()==(B/'verification/performance_r3_20261118/before_deploy/ict_trader'/p.name).read_bytes(),p.name
 snapshot_differences.append(p.name)
assert (R/'app.py').read_bytes()==(B/'research_snapshot/app_source.py').read_bytes()
for name in ('BookThreePushPA.mqh','BookThreePushReversal.mqh','Machine1_UnifiedNativeLegacyPush.mqh','Machine1_UnifiedNativeKernel.mqh','BookPAVisual.mqh'):
 expected=Path('D:/盘整研究资料/安装/Book_PA_Shapes')/name
 assert expected.read_text('utf-8-sig')==(B/'companions/pa_shapes'/name).read_text('utf-8-sig'),name
for p in (B/'templates').glob('*.tpl'):
 raw=p.read_bytes();enc='utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig'
 s=raw.decode(enc).replace('\r\n','\n').replace('\r','');p.write_bytes(s.replace('\n','\r\n').encode(enc))
 assert '1221' not in s
full=(B/'templates/Book302_All_Research_Experimental.tpl').read_text('utf-16')
assert full.count('name=Custom Indicator')==4
assert 'Book302_Research_Adapters1230' in full
assert 'Book302_All_Research_Experimental.tpl' in (B/'native_scripts/Book302_Open_Experiment.mq5').read_text('utf-8')
result=dict(passed=True,book_core_headers_unchanged=41,latest_research_snapshot_exact=not snapshot_differences,verified_experiment_callback_patches=snapshot_differences,PA_numerical_and_visual_helpers_exact=True,production_files_unchanged=len(manifest['production_files_unchanged']),one_click_template_indicators=4,native_verified=False)
(B/'verification/source_preservation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(result))
