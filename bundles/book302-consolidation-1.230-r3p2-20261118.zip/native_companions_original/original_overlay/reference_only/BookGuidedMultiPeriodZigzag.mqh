#ifndef BOOK_GUIDED_MULTI_PERIOD_ZIGZAG
#define BOOK_GUIDED_MULTI_PERIOD_ZIGZAG

// Display-only multi-period ZigZag. It reads native CopyRates for each
// selected timeframe, excludes the forming bar and never feeds Book scoring,
// channel or turning-point ownership.
input group "多周期 ZigZag（仅显示）"
input bool ShowMultiPeriodZigZag=true;
input string MultiPeriodZigZagPeriods="M1,M5,M15,M30,H1";
input int MultiPeriodZigZagDepth=3;
input int MultiPeriodZigZagMaxBars=12000;

ENUM_TIMEFRAMES bkn_mtf_frames[8]={PERIOD_M1,PERIOD_M5,PERIOD_M15,PERIOD_M30,PERIOD_H1,PERIOD_H4,PERIOD_D1,PERIOD_W1};
string bkn_mtf_names[8]={"M1","M5","M15","M30","H1","H4","D1","W1"};
color bkn_mtf_colors[8]={C'176,201,90',C'73,214,189',C'99,169,255',C'245,140,186',C'196,154,255',C'242,142,43',C'233,196,106',C'240,243,247'};
bool bkn_mtf_selected[8];
datetime bkn_mtf_revision[8];
string bkn_mtf_inputs[8];
string bkn_mtf_status[8];
ulong bkn_mtf_checked=0;
string bkn_mtf_prefix="BookGuided1302_MTFZZ_";

struct BKNMTFPivot { datetime time; double price; bool high; int index; };

bool BKNMTFInit(){
 ArrayInitialize(bkn_mtf_selected,false);ArrayInitialize(bkn_mtf_revision,0);
 string value=MultiPeriodZigZagPeriods;StringReplace(value," ","");StringToUpper(value);
 string tokens[];int count=StringSplit(value,',',tokens);
 if(count<=0)return false;
 for(int j=0;j<count;j++){
  bool found=false;
  for(int i=0;i<8;i++)if(tokens[j]==bkn_mtf_names[i]){bkn_mtf_selected[i]=true;found=true;break;}
  if(tokens[j]=="CURRENT"){
   for(int i=0;i<8;i++)if(bkn_mtf_frames[i]==_Period){bkn_mtf_selected[i]=true;found=true;break;}
  }
  if(!found)return false;
 }
 for(int i=0;i<8;i++){bkn_mtf_inputs[i]="";bkn_mtf_status[i]="等待原生行情";}
 bkn_mtf_checked=0;
 return MultiPeriodZigZagDepth>=1&&MultiPeriodZigZagDepth<=20&&MultiPeriodZigZagMaxBars>=100&&MultiPeriodZigZagMaxBars<=50000;
}

void BKNMTFClear(){
 ObjectsDeleteAll(0,bkn_mtf_prefix);
 for(int i=0;i<8;i++)bkn_mtf_revision[i]=0;
}

void BKNMTFButton(int i){
 string name=bkn_mtf_prefix+"BTN_"+bkn_mtf_names[i];
 if(ObjectFind(0,name)<0)ObjectCreate(0,name,OBJ_BUTTON,0,0,0);
 int col=i%4,row=i/4;
 ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);
 ObjectSetInteger(0,name,OBJPROP_XDISTANCE,12+col*78);
 ObjectSetInteger(0,name,OBJPROP_YDISTANCE,168+row*24);
 ObjectSetInteger(0,name,OBJPROP_XSIZE,74);ObjectSetInteger(0,name,OBJPROP_YSIZE,20);
 ObjectSetInteger(0,name,OBJPROP_FONTSIZE,8);
 ObjectSetInteger(0,name,OBJPROP_COLOR,bkn_mtf_selected[i]?bkn_mtf_colors[i]:clrSilver);
 ObjectSetInteger(0,name,OBJPROP_BGCOLOR,bkn_mtf_selected[i]?C'25,54,66':clrBlack);
 ObjectSetInteger(0,name,OBJPROP_ZORDER,2100);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
 ObjectSetInteger(0,name,OBJPROP_STATE,false);
 ObjectSetString(0,name,OBJPROP_TEXT,(bkn_mtf_selected[i]?"隐藏 ":"显示 ")+"ZZ "+bkn_mtf_names[i]);
 ObjectSetString(0,name,OBJPROP_TOOLTIP,bkn_mtf_names[i]+" · "+bkn_mtf_status[i]+" · 仅显示已确认折线，末端可随新极值修订");
}

void BKNMTFButtons(){
 if(!ShowMultiPeriodZigZag)return;
 for(int i=0;i<8;i++)BKNMTFButton(i);
}

void BKNMTFAppendPivot(BKNMTFPivot &out[],datetime t,double p,bool high,int index){
 int n=ArraySize(out);
 if(n>0&&out[n-1].high==high){
  bool replace=high?(p>=out[n-1].price):(p<=out[n-1].price);
  if(replace){out[n-1].time=t;out[n-1].price=p;out[n-1].index=index;}
  return;
 }
 BKNMTFPivot q;q.time=t;q.price=p;q.high=high;q.index=index;ArrayResize(out,n+1);out[n]=q;
}

// cutoff is the displayed analysis clock, not the wall clock. No bar whose
// closing time exceeds that clock may confirm a pivot in a historical view.
int BKNMTFBuild(const MqlRates &rates[],int seconds,datetime cutoff,int depth,BKNMTFPivot &pivots[]){
 ArrayResize(pivots,0);int closed=0;
 for(int i=0;i<ArraySize(rates);i++){
  if(rates[i].time+seconds>cutoff)break;
  if(i>0&&rates[i].time<=rates[i-1].time)return -1;
  if(!MathIsValidNumber(rates[i].high)||!MathIsValidNumber(rates[i].low)||rates[i].high<rates[i].low)return -1;
  closed++;
 }
 if(depth<1||closed<depth*2+1)return 0;
 for(int i=depth;i<closed-depth;i++){
  bool is_high=true,is_low=true;
  for(int j=1;j<=depth;j++){
   // Rightmost plateau pivot; do not create a point on every equal bar.
   if(rates[i].high<rates[i-j].high||rates[i].high<=rates[i+j].high)is_high=false;
   if(rates[i].low>rates[i-j].low||rates[i].low>=rates[i+j].low)is_low=false;
  }
  // An outside bar cannot establish intrabar order from OHLC alone.
  if(is_high&&!is_low)BKNMTFAppendPivot(pivots,rates[i].time,rates[i].high,true,i);
  else if(is_low&&!is_high)BKNMTFAppendPivot(pivots,rates[i].time,rates[i].low,false,i);
 }
 return ArraySize(pivots);
}

void BKNMTFUnavailable(int fi,string status){
 ObjectsDeleteAll(0,bkn_mtf_prefix+bkn_mtf_names[fi]+"_");
 bkn_mtf_inputs[fi]="";bkn_mtf_status[fi]=status;
}

void BKNMTFRenderOne(int fi){
 string prefix=bkn_mtf_prefix+bkn_mtf_names[fi]+"_";
 if(!ShowMultiPeriodZigZag||!bkn_mtf_selected[fi]){ObjectsDeleteAll(0,prefix);bkn_mtf_inputs[fi]="";bkn_mtf_status[fi]="已隐藏";return;}
 int first=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR),visible=(int)ChartGetInteger(0,CHART_VISIBLE_BARS);
 int right=(int)MathMax(0,first-visible+1),seconds=PeriodSeconds(bkn_mtf_frames[fi]);
 datetime left_time=iTime(_Symbol,_Period,first),right_time=iTime(_Symbol,_Period,right);
 datetime live_open=iTime(_Symbol,_Period,0);
 if(left_time<=0||right_time<=0||live_open<=0){BKNMTFUnavailable(fi,"等待当前视窗行情");return;}
 datetime cutoff=(datetime)MathMin((long)(right_time+PeriodSeconds(_Period)),(long)live_open);
 int from=iBarShift(_Symbol,bkn_mtf_frames[fi],cutoff-1,false),to=iBarShift(_Symbol,bkn_mtf_frames[fi],left_time,false);
 if(from<0||to<from){MqlRates warm[];CopyRates(_Symbol,bkn_mtf_frames[fi],left_time,cutoff,warm);BKNMTFUnavailable(fi,"正在加载历史");return;}
 int required=to-from+1+64+MultiPeriodZigZagDepth*2;
 int wanted=(int)MathMin(required,MultiPeriodZigZagMaxBars);
 MqlRates rates[];ArraySetAsSeries(rates,false);
 int copied=CopyRates(_Symbol,bkn_mtf_frames[fi],from,wanted,rates);
 int depth=MultiPeriodZigZagDepth;
 if(copied<depth*2+1){BKNMTFUnavailable(fi,"历史不足，自动重试");return;}
 // Include OHLC in the key so terminal history corrections invalidate it.
 ulong hash=1469598103934665603;
 for(int i=0;i<copied;i++){
  if(rates[i].time+seconds>cutoff)break;
  hash=(hash^(ulong)rates[i].time)*1099511628211;
  hash=(hash^(ulong)MathRound(rates[i].high/_Point))*1099511628211;
  hash=(hash^(ulong)MathRound(rates[i].low/_Point))*1099511628211;
 }
 string key=IntegerToString(cutoff)+":"+IntegerToString(copied)+":"+IntegerToString(hash);
 if(key==bkn_mtf_inputs[fi])return;
 BKNMTFPivot pivots[];
 int result=BKNMTFBuild(rates,seconds,cutoff,depth,pivots);
 ObjectsDeleteAll(0,prefix);
 if(result<0){BKNMTFUnavailable(fi,"原生OHLC无效，等待补齐");return;}
 for(int i=1;i<ArraySize(pivots);i++){
  string name=prefix+IntegerToString(i);
  if(ObjectCreate(0,name,OBJ_TREND,0,pivots[i-1].time,pivots[i-1].price,pivots[i].time,pivots[i].price)){
   ObjectSetInteger(0,name,OBJPROP_COLOR,bkn_mtf_colors[fi]);ObjectSetInteger(0,name,OBJPROP_WIDTH,1);
   ObjectSetInteger(0,name,OBJPROP_STYLE,STYLE_SOLID);ObjectSetInteger(0,name,OBJPROP_RAY_LEFT,false);ObjectSetInteger(0,name,OBJPROP_RAY_RIGHT,false);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetString(0,name,OBJPROP_TOOLTIP,bkn_mtf_names[fi]+" ZigZag · 已收盘原生端点 · "+TimeToString(pivots[i-1].time,TIME_DATE|TIME_MINUTES)+" → "+TimeToString(pivots[i].time,TIME_DATE|TIME_MINUTES));
  }
 }
 bkn_mtf_inputs[fi]=key;
 bkn_mtf_status[fi]=IntegerToString((int)MathMax(0,result-1))+" 段 · "+TimeToString(cutoff,TIME_DATE|TIME_MINUTES);
 if(required>MultiPeriodZigZagMaxBars)bkn_mtf_status[fi]+=" · 达到根数上限，请增加MaxBars或放大视窗";
 else if(copied<wanted)bkn_mtf_status[fi]+=" · 等待历史补齐";
}

void BKNMTFRender(){
 if(GetTickCount64()-bkn_mtf_checked<500)return;
 bkn_mtf_checked=GetTickCount64();
 for(int i=0;i<8;i++)BKNMTFRenderOne(i);
 BKNMTFButtons();
}

bool BKNMTFClick(string name){
 for(int i=0;i<8;i++)if(name==bkn_mtf_prefix+"BTN_"+bkn_mtf_names[i]){
  bkn_mtf_selected[i]=!bkn_mtf_selected[i];bkn_mtf_inputs[i]="";BKNMTFRenderOne(i);BKNMTFButtons();ChartRedraw(0);return true;
 }
 return false;
}

#endif
