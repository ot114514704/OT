#ifndef BOOK_THREE_PUSH_REVERSAL
#define BOOK_THREE_PUSH_REVERSAL
// Independent evidence for the FIRST reversal attempt. Never modifies Book's
// six anchors, PA category, rails, or the original first-boundary-exit record.
// phase: 0 not eligible, 1 candidate, 2 rail break, 3 structure break,
// 4 later-close follow-through, 5 first attempt failed/reclaimed, 6 data stop.
struct OverlayReversal {
 int phase; datetime known,rail,structure,follow,failed,checked;
 double level,extreme,break_close; string reason;
};
void OverlayReversalEvaluate(const MqlRates &r[],const M1ULegacyPush &p,
 const OverlayPA &o,const int seconds,const datetime cutoff,OverlayReversal &v){
 v.phase=0;v.known=0;v.rail=0;v.structure=0;v.follow=0;v.failed=0;v.checked=0;
 v.level=0;v.extreme=0;v.break_close=0;v.reason="反转背景未验证或属于中继；不确认反转";
 if(o.category==0)v.reason="未建立反转候选："+o.reason;
 else if(o.category==2 || o.category==3)v.reason="当前归为逆前置趋势的回调中继；不冒充同向末端反转";
 if(seconds<=0 || ArraySize(p.points)!=6 || p.known>cutoff || o.category!=1)return;
 if(o.known!=p.known || (p.direction!=1 && p.direction!=-1))return;
 int last=-1;
 for(int j=0;j<6;j++){
  int at=-1;for(int k=0;k<ArraySize(r);k++)if(r[k].time==p.points[j].time){at=k;break;}
  if(at<0 || at<=last || p.points[j].known>p.known || p.points[j].known<r[at].time+seconds ||
     r[at].time+seconds>cutoff || !M1UValidRate(r[at]))return;
  int kind=(j%2==0?-p.direction:p.direction);
  double price=kind==1?r[at].high:r[at].low;
  if(p.points[j].kind!=kind || !MathIsValidNumber(p.points[j].price) ||
     MathAbs(p.points[j].price-price)>MathMax(1e-7,MathAbs(price)*1e-9))return;
  last=at;
 }
 v.known=p.known;v.level=p.points[4].price;v.extreme=p.points[5].price;
 v.phase=1;v.reason="三推反转候选：等待反向收盘破轨";
 if(o.state==0)return;
 if(o.state==3){v.phase=6;v.reason="原轮廓已终止或越轨早于形态可知；不倒签反转证据";return;}
 if(o.event<o.known || o.event>cutoff){v.phase=6;v.reason="越轨时刻无效；停止反转跟进";return;}
 if(o.state==2){v.phase=5;v.failed=o.event;v.checked=o.event;v.reason="首轮沿原推动方向破轨；反转候选失效";return;}
 if(o.state!=1)return;
 int eventIndex=-1;
 for(int k=last+1;k<ArraySize(r);k++)if(r[k].time+seconds==o.event){eventIndex=k;break;}
 if(eventIndex<0){v.phase=6;v.reason="缺少原生越轨柱；不补推后续证据";return;}
 int direction=-p.direction;
 v.phase=2;v.rail=o.event;v.reason="已反向收盘破轨；尚未收盘越过第三推前回撤点";
 for(int k=eventIndex;k<ArraySize(r);k++){
  datetime closeAt=r[k].time+seconds;
  if(closeAt>cutoff)break;
  if(!M1UValidRate(r[k]) || (k>0 && r[k].time<=r[k-1].time)){
   v.phase=6;v.reason="跟进数据无效或时序错误；保留此前证据并停止";return;
  }
  v.checked=closeAt;
  // Closing past the third-push extreme invalidates this attempt; a wick
  // alone cannot establish acceptance or an ordered intrabar path.
  if(direction*(r[k].close-v.extreme)<0){
   v.phase=5;v.failed=closeAt;v.reason="收盘越过第三推极值；首轮反转尝试失效";return;
  }
  bool beyond=direction*(r[k].close-v.level)>0;
  if(v.structure==0){
   if(beyond){v.structure=closeAt;v.break_close=r[k].close;v.phase=3;v.reason="已收盘突破第三推前回撤点；等待后续收盘跟进";}
   continue;
  }
  if(!beyond){
   v.phase=5;v.failed=closeAt;v.reason=v.follow>0?"已有反向跟进，但随后收盘收回关键位；保留历史证据":"首轮结构突破被收回；尚无持续反向跟进";return;
  }
  // A different CLOSED candle must advance beyond the structural-break
  // close. Gaps in native bars are not counted as immediate follow-through.
  if(v.follow==0 && closeAt>v.structure && direction*(r[k].close-v.break_close)>0){
   if(k>0 && r[k].time-r[k-1].time==seconds){
    v.follow=closeAt;v.phase=4;v.reason="反向破轨、关键回撤点突破及后续收盘推进已具备；不等于完整趋势反转";
   }else v.reason="关键位外收盘推进，但相邻原生柱有缺口；等待连续收盘跟进";
  }
 }
}
string OverlayReversalPhase(const OverlayReversal &v){
 if(v.phase==1)return "反转候选";
 if(v.phase==2)return "反向破轨，待结构突破";
 if(v.phase==3)return "结构已破，待收盘跟进";
 if(v.phase==4)return "反向结构与跟进已具备";
 if(v.phase==5)return "首轮反转尝试失效/回收";
 if(v.phase==6)return "证据停止，不能确认";
 return "未建立反转背景";
}
string OverlayReversalTime(const datetime t){return t>0?TimeToString(t,TIME_DATE|TIME_MINUTES):"未发生";}
string OverlayReversalDetail(const OverlayReversal &v){
 string text="反转证据："+OverlayReversalPhase(v);
 if(v.phase==0)return text+"\n"+v.reason;
 return text+"\n关键回撤点 "+DoubleToString(v.level,_Digits)+"；第三推极值 "+DoubleToString(v.extreme,_Digits)+
 "\n反向破轨 "+OverlayReversalTime(v.rail)+"；结构突破 "+OverlayReversalTime(v.structure)+
 "\n后续跟进 "+OverlayReversalTime(v.follow)+"；失效/回收 "+OverlayReversalTime(v.failed)+"\n"+v.reason;
}
#endif
