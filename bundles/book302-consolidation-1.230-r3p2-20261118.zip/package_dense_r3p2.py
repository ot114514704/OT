"""Immutable backup of the exact native dense-prefix memo experiment."""
from pathlib import Path
import hashlib,json,zipfile

B=Path(__file__).parent;V=B/'verification/native_dense_performance_20261118'
names=('acceptance.json','reference_acceptance.json','integration_acceptance.json','regression_observation.json','deployment_acceptance.json')
evidence={n:json.loads((V/n).read_text('utf8')) for n in names}
assert all(x['passed'] for x in evidence.values())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(B/p)==h for p,h in evidence['integration_acceptance.json']['source_sha256'].items())
original=json.loads((B/'FUSION_PROVENANCE.json').read_text('utf8'))
assert all(sha(Path(p))==h for p,h in original['production_files_unchanged'].items())
assert all(sha(B/'source/book_native'/p)==h for p,h in original['book_headers'].items())
meta={'revision':'1.230-r3p2','source_sha256':evidence['integration_acceptance.json']['source_sha256'],
      'offline_comparison':evidence['acceptance.json'],'native_deployment':evidence['deployment_acceptance.json'],
      'regressions':68,'references':'six user areas and 3000 native M15 bars, half/full prefix equality',
      'production_files_unchanged':70,'book_core_headers_unchanged':41,
      'layout_or_threshold_changes':False,'uploaded_at_packaging':False,
      'limits':['One paired core-timing sample, not universal or end-to-end latency.','All-history cutoff coverage and original broad goal remain unfinished.']}
(B/'REVISION_R3P2.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),'utf8')
readme='''Book＋盘整实验1.230-r3p2，2026-11-18

在r3p1通道/三角窗口复用之上，复用完全相同原生已收盘前缀中的普通盘整窗口度量。完整价格、时间标签、周期、休市策略及参数相同时才复用；历史修订、截断、参数或时间标签改变都会重算。所有形态准入、首次可知时间、冻结边界和生命周期仍从头计算，缓存不保存活动盘整状态。返回结果独立，异常计算不会污染上一份成功缓存；保留窗口数和序列化值字节数有上限。

同一请求111条结果全部一致；离线对照80.37秒→67.80秒，约减少16%。实际接入后再次完整对照通过，68项回归通过。六处参考区域与3000根原生M15数据的前半段/全量普通盘整记录完全一致。性能对照脚本已显式选择原始/优化路径，避免部署后误测优化版对优化版。

运行后台已重启，完整H1/M15图表数据、综合解释及111条结果与原生基线一致。MQL指标、Book核心、原生产目录及图形布局没有改动。图表仍H1；同一视窗检查续观关/开并恢复。当前新版本只改变独立实验计算，不宣称全部延迟、其他日期断头及全历史准确率已解决。

入口沿用r3/r3p1。本补丁回退：停止独立后台后恢复verification/native_dense_performance_20261118/before_deploy/worker.py，再启动。原r3p1及更早ZIP保留。完整恢复仍使用独立备份包。已打包ZIP不再改写；后续发布状态看remote_receipt.json。

验证：verification/native_dense_performance_20261118；当前源码标识：REVISION_R3P2.json。旧版计时与验收记录保留为各次历史证据。
'''
(B/'README_R3P2.txt').write_text(readme,'utf8')
prior=B.parent/'备份/Book302_盘整融合1.230-r3p1_等价窗口复用_20261118.zip'
with zipfile.ZipFile(prior) as z:
    files={B/p for p in z.namelist() if p!='R3P1_PACKAGE_MANIFEST.json'}
files.update(p for p in V.rglob('*') if p.is_file())
files.update(B/p for p in ('native_dense_memo.py','test_native_dense_memo.py','verify_native_dense_performance.py','verify_native_dense_references.py','verify_dense_integration.py','package_dense_r3p2.py','README_R3P2.txt','REVISION_R3P2.json'))
manifest=[{'path':p.relative_to(B).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
out=B.parent/'备份/Book302_盘整融合1.230-r3p2_普通盘整窗口复用_20261118.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(files):z.write(p,p.relative_to(B).as_posix())
    z.writestr('R3P2_PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
receipt={'path':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'files_verified':len(manifest),'uploaded':False,
         'git_blob_sha':hashlib.sha1(b'blob '+str(out.stat().st_size).encode()+b'\0'+out.read_bytes()).hexdigest()}
(B/'PACKAGE_R3P2.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(receipt,ensure_ascii=False))
