import copy,unittest
import test_continuation
from continuation import observe
from outer_continuation import handoff,handoff_chain

class HandoffTests(unittest.TestCase):
 def setUp(self):
  self.fixture=test_continuation.ContinuationTests();self.fixture.setUp();f=self.fixture
  self.bars=[f.bar(i,c) for i,c in enumerate([4005,4011,4012,4013,4014,4015])]
  self.inner=f.box;self.outer={**f.box,'id':'larger','high':4020,'fixed_high':4020}
  self.contexts=[self.inner,self.outer];self.event=f.event
 def run_case(self,bars=None,contexts=None,cutoff=None):
  bars=bars or self.bars;contexts=contexts or self.contexts
  cutoff=cutoff or int(bars[-1].closed_at.timestamp())
  r={'code':2,'context':self.inner}
  r['continuation']=observe(self.event,r,contexts,bars,cutoff)
  before=copy.deepcopy(r);out=handoff(self.event,r,contexts,bars,cutoff)
  self.assertEqual(before,r)
  return out,r
 def test_handoff_keeps_original_end_and_equation(self):
  out,r=self.run_case();self.assertEqual(out['parent_range_id'],'larger')
  self.assertEqual(out['known'],r['continuation']['through'])
  self.assertEqual(out['segments'][0]['start'],r['continuation']['end'])
  self.assertEqual(out['segments'][0]['price0'],r['continuation']['price1'])
  self.assertGreater(out['segments'][0]['end'],r['continuation']['end'])
 def test_future_outer_not_admitted(self):
  contexts=[self.inner,{**self.outer,'known':self.event['clock']+3600}]
  self.assertIsNone(self.run_case(contexts=contexts)[0])
 def test_overlapping_but_not_containing_rejected(self):
  self.assertIsNone(self.run_case(contexts=[self.inner,{**self.outer,'low':4001,'fixed_low':4001}])[0])
 def test_outer_exit_before_handoff_cannot_restart(self):
  self.outer['high']=4011;self.outer['fixed_high']=4011
  self.assertIsNone(self.run_case()[0])
 def test_future_does_not_choose_longer_lived_outer(self):
  larger={**self.outer,'id':'largest','high':4050,'fixed_high':4050}
  contexts=[*self.contexts,larger];bars=self.bars[:3]+[self.fixture.bar(i,4030) for i in (3,4,5)]
  out,_=self.run_case(bars,contexts);self.assertEqual(out['parent_range_id'],'larger')
  self.assertEqual(out['state'],'outer_fixed_envelope_exit')
  self.assertEqual(out['segments'][0]['end'],int(bars[4].time.timestamp()))
 def test_future_suffix_cannot_change_prefix(self):
  cutoff=int(self.bars[3].closed_at.timestamp());a=self.run_case(self.bars[:4],cutoff=cutoff)[0]
  bars=self.bars[:4]+[self.fixture.bar(4,9000),self.fixture.bar(5,9000)]
  self.assertEqual(a,self.run_case(bars,cutoff=cutoff)[0])
 def test_gap_is_not_joined(self):
  bars=self.bars[:4]+[self.fixture.bar(50,4015)]
  out,_=self.run_case(bars);self.assertEqual(out['state'],'outer_gap')
  self.assertEqual(out['segments'][-1]['end'],int(bars[3].time.timestamp()))
 def test_price_mirror_has_equal_lifetime(self):
  from worker import NativeBar
  out,_=self.run_case()
  self.bars=[NativeBar(b.time,8000-b.open,8000-b.low,8000-b.high,8000-b.close,b.spread,b.seconds) for b in self.bars]
  for c in self.contexts:
   for low,high in [('low','high'),('fixed_low','fixed_high'),('low0','high0')]:c[low],c[high]=8000-c[high],8000-c[low]
  self.event={**self.event,'line':8000-self.event['line'],'slope':-self.event['slope']}
  mirrored,_=self.run_case()
  self.assertEqual(out['known'],mirrored['known']);self.assertEqual(out['segments'][0]['end'],mirrored['segments'][0]['end'])
  self.assertAlmostEqual(out['segments'][0]['price1']+mirrored['segments'][0]['price1'],8000)
 def test_protocol_keeps_inner_and_outer_as_separate_rows(self):
  from worker import classify,encode_reply
  out,r=self.run_case();record=classify(self.event,self.bars[:1],self.contexts)
  record['continuation']=r['continuation'];record['outer_continuation']=out
  wire=encode_reply({'token':'fixture','cutoff':int(self.bars[-1].closed_at.timestamp())},[record],0)
  rows=[s.split('\t') for s in wire.splitlines() if s.startswith('C\t')]
  self.assertEqual(len(rows),2);self.assertTrue(all(len(s)==12 for s in rows))
  self.assertEqual(rows[0][8],'fixed_envelope_exit');self.assertEqual(rows[1][8],'outer_observing')
 def test_nested_handoffs_have_separate_forward_clocks(self):
  largest={**self.outer,'id':'largest','high':4050,'fixed_high':4050}
  contexts=[*self.contexts,largest];bars=self.bars[:3]+[self.fixture.bar(i,4030) for i in (3,4,5)]
  _,r=self.run_case(bars,contexts);before=copy.deepcopy(r)
  out=handoff_chain(self.event,r,contexts,bars,int(bars[-1].closed_at.timestamp()))
  self.assertEqual(r,before)
  self.assertEqual([x['parent_range_id'] for x in out['range_chain']],['larger','largest'])
  self.assertLess(out['range_chain'][0]['known'],out['range_chain'][1]['known'])
  self.assertEqual(out['segments'][-1]['end'],int(bars[-1].time.timestamp()))
  self.assertEqual(out['segments'][0]['high'],4020)
  self.assertEqual(out['segments'][-1]['high'],4050)
 def test_chain_cannot_admit_later_discovered_range(self):
  later={**self.outer,'id':'later','high':4050,'fixed_high':4050,'known':self.event['clock']+3600}
  contexts=[*self.contexts,later];bars=self.bars[:3]+[self.fixture.bar(i,4030) for i in (3,4,5)]
  _,r=self.run_case(bars,contexts)
  out=handoff_chain(self.event,r,contexts,bars,int(bars[-1].closed_at.timestamp()))
  self.assertEqual(len(out['range_chain']),1)
  self.assertEqual(out['final_state'],'outer_fixed_envelope_exit')

if __name__=='__main__':unittest.main()
