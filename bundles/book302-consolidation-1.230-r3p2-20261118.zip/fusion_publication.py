"""Explicit experiment status, with no live-data permission or geometry edits."""
import time

def publish_model_state(folder,request,status,reason,write):
    if status not in ('pending','unavailable'):
        raise ValueError('Only incomplete model states belong here')
    folder.mkdir(parents=True,exist_ok=True)
    now=int(time.time())
    reason=str(reason).replace('\t',' ').replace('\r',' ').replace('\n',' ')
    fields=['IPDA_LIVE',1,now,request['token'],'experiment_snapshot',
            status,reason,'',status,reason,'','',now]
    write(folder/'heartbeat.tsv','\t'.join(map(str,fields))+'\n')

def completed_stage(report):
    return 'full' if report.get('available') is True else 'limited'
