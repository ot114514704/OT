"""Actual integrated worker versus the preserved full-result baseline."""
from pathlib import Path
import hashlib,json,time
import worker

B=Path(__file__).parent;V=B/'verification/native_dense_performance_20261118'
request=worker.parse_request((B/'verification/native_r3/final/request_102923304041429_3600.tsv').read_text('utf-8-sig'))
expected=json.loads((B/'verification/performance_r3_20261118/baseline_results.json').read_text('utf8'))
worker.recognize.cache_clear();started=time.perf_counter()
result=worker.solve(request,lambda msg:print(msg,flush=True))
elapsed=time.perf_counter()-started
assert result==expected
assert worker._dense_candidates.calls==20 and worker._dense_candidates.last_reused>0
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
provenance=json.loads((B/'FUSION_PROVENANCE.json').read_text('utf8'))
assert all(sha(Path(p))==h for p,h in provenance['production_files_unchanged'].items())
assert all(sha(B/'source/book_native'/p)==h for p,h in provenance['book_headers'].items())
report={'passed':True,'results':len(result),'all_fields_exact':True,'seconds':elapsed,
        'dense_memo':worker._dense_candidates.metadata(),
        'source_sha256':{p:sha(B/p) for p in ('worker.py','native_dense_memo.py','geometry_window_memo.py')},
        'production_files_unchanged':70,'book_headers_unchanged':41,'live_restarted':False}
(V/'integration_acceptance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(report),flush=True)
