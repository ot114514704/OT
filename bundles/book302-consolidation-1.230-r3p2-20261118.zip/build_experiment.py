from pathlib import Path
import hashlib,json,shutil,re
BASE=Path(__file__).resolve().parent
ORIGINAL=BASE/'research_snapshot'/'book1302_original'
RESEARCH=BASE/'research_snapshot'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    source=BASE/'source';source.mkdir(exist_ok=True);pa=source/'pa';pa.mkdir(exist_ok=True)
    shutil.copytree(ORIGINAL/'book_native',source/'book_native',dirs_exist_ok=True)
    provenance=dict(experiment='1.230',original_book='1.302',research_source=str(RESEARCH),original_headers={},research_python={},pa={})
    for p in sorted((ORIGINAL/'book_native').glob('*.mqh')):provenance['original_headers'][p.name]=digest(p)
    provenance['original_entry']=dict(path=str(ORIGINAL/'Machine1_Book.mq5'),sha256=digest(ORIGINAL/'Machine1_Book.mq5'))
    for p in sorted((RESEARCH/'ict_trader').glob('*.py')):provenance['research_python'][p.name]=digest(p)
    for name in ('BookThreePushPA.mqh','Machine1_UnifiedNativeLegacyPush.mqh','Machine1_UnifiedNativeKernel.mqh'):
        p=BASE/'native_companions_original'/'pa_shapes'/name;text=p.read_text(encoding='utf-8-sig')
        # Isolate only the conflicting local ZigZag helper names. Numerical PA
        # rules and original six-point detector are byte-for-byte otherwise.
        text=text.replace('BKNMTFPivot','BXPPivot').replace('BKNMTFAppendPivot','BXPAppendPivot').replace('BKNMTFBuild','BXPBuild')
        (pa/name).write_text(text,encoding='utf8');provenance['pa'][name]=dict(original_sha256=digest(p),copy_sha256=digest(pa/name),change='local helper namespace only' if name=='BookThreePushPA.mqh' else 'encoding/newline normalization only')
    text=(ORIGINAL/'Machine1_Book.mq5').read_text(encoding='utf-8-sig')
    text=text.replace('#property version "1.302"','#property version "1.230"')
    text=text.replace('#include "book_native/BookGuidedMultiPeriodZigzag.mqh"','#include "book_native/BookGuidedMultiPeriodZigzag.mqh"\n#include "BookExperimentGuard.mqh"')
    text=text.replace('void SaveNativeAudit(string audit_reason="completed_frame"){','void SaveNativeAudit(string audit_reason="completed_frame"){\n BEXSubmit(running_rows,book.shapes,running_input,running_view,running_cutoff);')
    text=text.replace('Machine1BookGuided1302Audit','Book302Experiment1230\\\\NativeBookAudit')
    text=text.replace('IndicatorSetString(INDICATOR_SHORTNAME,"Machine1 Book 1.302 Guided Development")','IndicatorSetString(INDICATOR_SHORTNAME,"Book 1.302 Independent Consolidation Experiment 1.230")')
    text=text.replace('view.Init(true);','view.Init(true);BEXInit();')
    text=text.replace('void OnDeinit(const int reason){','void OnDeinit(const int reason){BEXDestroy();')
    text=text.replace('void OnTimer(){','void OnTimer(){\n BEXPoll(calculating||request_pending,ViewportIdentity());')
    text=text.replace('if(id==CHARTEVENT_OBJECT_CLICK&&BKNMTFClick(sparam))return;','if(id==CHARTEVENT_OBJECT_CLICK&&BEXClick(sparam))return;\n if(id==CHARTEVENT_OBJECT_CLICK&&BKNMTFClick(sparam))return;')
    text=text.replace('if(view.Event(id,sparam)){','if(view.Event(id,sparam)){\n  BEXNativeViewEvent(sparam);')
    (source/'Book302_Consolidation_Experiment.mq5').write_text(text,encoding='utf8')
    provenance['geometry_policy']='Original 41 headers unchanged. Separate wrapper, local guard and namespaced PA helpers only. No edits to original archive or production source.'
    (BASE/'PROVENANCE.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2),encoding='utf8')
    print('Built isolated source; original headers',len(provenance['original_headers']))
if __name__=='__main__':main()
