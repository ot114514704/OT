"""Load only the original app's pure calculation functions from its snapshot.
No app service, broker connection, HTTP server, scheduler or publisher is started.
"""
from pathlib import Path
from functools import lru_cache,partial
import ast,hashlib,sys
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'research_snapshot'))
from ict_trader.core import Bar,instant
from ict_trader.calculation_timing import measured
from ict_trader.ipda_phases import detect_phases
from ict_trader.h1_channels import observe_channels
from ict_trader.delivery_context import build_delivery_context
from ict_trader.phase_scores import attach_scores
from ict_trader.retracement_validation import attach_retracement_validation
from ict_trader.retracement_episodes import refine_retracement_phases
from ict_trader.macro_consolidation import analyze_macro
from ict_trader.swing_balance import observe_swing_candidates,swing_history
from ict_trader.structural_ranges import observe_structures
from ict_trader.dense_pauses import observe_dense_pauses,DenseWindowMemo
from ict_trader.long_geometry import observe_long_geometry
from ict_trader.current_consolidation import state_history,current_candidate_overlay,classify
from ict_trader.intraday_projection import attach_intraday_projection
from ict_trader.reference_targets import attach_targets
from ict_trader.mt5_bridge import display_records
SOURCE=BASE/'research_snapshot'/'app_source.py'
tree=ast.parse(SOURCE.read_text(encoding='utf-8-sig'))
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('row','analyze','project','prepare_h1','calculate')]
assert len(functions)==5
ns=dict(globals());exec(compile(ast.Module(body=functions,type_ignores=[]),str(SOURCE),'exec'),ns)
_dense_memos={period:DenseWindowMemo() for period in ('H1','M15')}
def raw(bars):
 return [dict(time=b.time.isoformat(),open=b.open,high=b.high,low=b.low,close=b.close,spread=b.spread) for b in bars]
def run(primary,background):
 """Use real native H1 and M15 rows, separately clipped to the request clock."""
 frames={3600:[],900:[]};frames[primary[0].seconds]=primary
 for seconds,rows in background.items():frames[int(seconds)]=rows
 missing=[name for sec,name in ((3600,'H1'),(900,'M15')) if len(frames[sec])<40]
 if missing:return dict(available=False,missing=missing,reason='真实原生周期样本不足，未补造或聚合行情'),{}
 charts=ns['calculate']({'H1':raw(frames[3600]),'M15':raw(frames[900])},dense_memos=_dense_memos)
 result={}
 for period,c in charts.items():
  verdict=classify(c);latest=c.get('latest') or {};phase=(c.get('phase_rows') or [{}])[-1]
  result[period]=dict(closed_end=c['closed_end'],verdict=verdict['label'],reason=verdict['reason'],phase=phase.get('phase'),
   fit_scores=phase.get('fit_scores'),candidate=c.get('current_candidate'),latest=latest,
   active_macro=c.get('macro_current',[]),active_structural=c.get('structural_current',[]),active_geometric=c.get('geometric_current',[]),
   swing_candidate=(c.get('swing_rows') or [{}])[-1],cisd=c.get('cisd',[])[-4:],reference_targets=c.get('reference_targets'),
   intraday_projection_count=len(c.get('intraday_structures',[])),episodes=c.get('episodes',[])[-3:])
 return dict(available=True,source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),periods=result,
  policy='原研究全模型当前快照；不回填历史穿线判断，不以分数或CISD替代范围约束'),charts
def summary(report,period):
 if not report.get('available'):return '原研究全模型：真实H1/M15输入不足，未作替代计算'
 r=report['periods'][period];return '原研究全模型：'+r['verdict']+'；阶段 '+str(r['phase'])+'；'+r['reason']+'；规则符合度不是胜率，CISD不替代盘整离区'
def export_companion(folder,request,charts):
 folder.mkdir(parents=True,exist_ok=True);revision=request['token'];records=[r for _,r in display_records(charts)]
 text='IPDA_SHAPES\t2\t'+revision+'\tXAUUSD\t'+str(len(records))+'\t'+__import__('ict_trader.history_generation',fromlist=['CALCULATION_VERSION']).CALCULATION_VERSION+'\n'+'\n'.join(records)+'\nEND\t'+revision+'\n'
 tmp=folder/'shapes.tmp';tmp.write_text(text,encoding='utf8');tmp.replace(folder/'shapes.tsv')
 # Historical experiment is never advertised as actionable live data.
 import time
 fields=['IPDA_LIVE',1,int(time.time()),revision,'experiment_snapshot']
 for period in ('H1','M15'):
  c=charts.get(period);fields += ['snapshot','独立实验历史快照，非实时许可',c['closed_end'] if c else '']
 fields+=['',int(time.time())]
 tmp=folder/'heartbeat.tmp';tmp.write_text('\t'.join(map(str,fields))+'\n',encoding='utf8');tmp.replace(folder/'heartbeat.tsv')
