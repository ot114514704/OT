"""Replay preserved native bars and original Book events, not mutable live requests."""
from pathlib import Path
import json,time,hashlib,zipfile
from worker import BASE,recognize,classify
from continuation import observe
from research_cases import load_bars
fixture=BASE/'testdata'/'native_history_H1.tsv';bars=load_bars(fixture)
cases=json.loads((BASE/'all_example_candidates.json').read_text(encoding='utf8'))
began=time.monotonic();rows=[]
for choice in (0,1,2,4,7):
 original=cases[choice];end=next(i+1 for i,b in enumerate(bars) if int(b.closed_at.timestamp())==original['clock'])
 start=max(0,int(original['original']['window'])-1100);prefix=tuple(bars[start:end])
 contexts,_=recognize(prefix)
 event=dict(id=original['original']['id'],family=original['original']['family'],clock=original['clock'],
  known=int(original['original']['known']),state=original['original']['state'],line=original['line'],slope=original['slope'])
 r=classify(event,prefix,contexts);window=bars[start:min(end+100,len(bars))];cutoff=int(window[-1].closed_at.timestamp())
 c=observe(event,r,contexts,window,cutoff);assert c
 indices={int(b.time.timestamp()):i for i,b in enumerate(window)}
 for s in c['segments']:
  a,b=indices[s['start']],indices[s['end']]
  assert s['known']<=s['start']+3600<=cutoff
  assert all(window[i].closed_at==window[i+1].time for i in range(a,b))
  assert s['end']+3600<=cutoff
 rows.append(dict(event=r['id'],state=c['state'],segments=c['segments'],gaps=c['gaps'],low=c['low'],high=c['high']))
assert len(rows)==5
assert any(len(r['segments'])>1 for r in rows),'No real native gap resumed'
archive=Path(r'D:\CodexData\Downloads\forex-ai-source-main.zip')
root='forex-ai-source-main/indicators/ALEXANDERDELL2/development/Book_1.302_Compiled/source/book_native/'
with zipfile.ZipFile(archive) as z:
 for p in (BASE/'source'/'book_native').glob('*.mqh'):assert z.read(root+p.name)==p.read_bytes(),p.name
out=BASE/'verification'
elapsed=time.monotonic()-began
receipt=dict(input_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),elapsed_seconds=elapsed,
 events=rows,original_headers_exact=41,native_visual_verified=False,all_segments_avoid_missing_bars=True)
(out/'gap_native_1.220.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
print('Native replay:',len(rows),'events,',sum(len(r['segments']) for r in rows),'separate segments;',round(elapsed,2),'seconds')
