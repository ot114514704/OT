from pathlib import Path
import json,hashlib,zipfile
from worker import BASE,recognize,classify,VERSION
from continuation import observe
from research_cases import load_bars

bars=load_bars(BASE/'testdata'/'native_history_H1.tsv')
cases=json.loads((BASE/'all_example_candidates.json').read_text(encoding='utf8'))
receipts=[]
for choice in (0,2,4,6,7):
 c=cases[choice];end=next(i+1 for i,b in enumerate(bars) if int(b.closed_at.timestamp())==c['clock'])
 start=max(0,int(c['original']['window'])-1100);prefix=tuple(bars[start:end])
 contexts,_=recognize(prefix)
 event=dict(id=c['original']['id'],family=c['original']['family'],clock=c['clock'],known=int(c['original']['known']),
            state=c['original']['state'],line=c['line'],slope=c['slope'])
 result=classify(event,prefix,contexts)
 window=bars[start:min(end+24,len(bars))];cutoff=int(window[-1].closed_at.timestamp())
 extension=observe(event,result,contexts,window,cutoff)
 assert extension and extension['end']>extension['start'],choice
 early_cutoff=int(window[len(prefix)+2].closed_at.timestamp())
 a=observe(event,result,contexts,window[:len(prefix)+3],early_cutoff)
 b=observe(event,result,contexts,window,early_cutoff)
 assert a==b,('future suffix changes past extension',choice)
 receipts.append(dict(example=choice,event=event,code=result['code'],continuation=extension,prefix_invariance=True))

archive=Path(r'D:\CodexData\Downloads\forex-ai-source-main.zip')
root='forex-ai-source-main/indicators/ALEXANDERDELL2/development/Book_1.302_Compiled/source/'
headers={}
with zipfile.ZipFile(archive) as z:
 for p in sorted((BASE/'source'/'book_native').glob('*.mqh')):
  original=z.read(root+'book_native/'+p.name)
  assert original==p.read_bytes(),p.name
  headers[p.name]=hashlib.sha256(original).hexdigest()
assert len(headers)==41
receipt=dict(version=VERSION,examples=receipts,original_headers_exact=41,headers=headers,
 native_visual_verified=False,buttons_verified=False,source_archive=str(archive),
 policy='Book immutable; experimental continuation is a separate selected overlay; no production writes')
(BASE/'verification'/'1.210.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
print('PASS: five native closed-bar examples, prefix invariance, 41 archive-exact headers')
