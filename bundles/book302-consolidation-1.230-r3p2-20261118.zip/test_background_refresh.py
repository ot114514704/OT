import unittest,tempfile
from pathlib import Path
from fusion_publication import publish_model_state,completed_stage
from worker import atomic,parse_request
from research_adapter import run
B=Path(__file__).parent

class PublicationTests(unittest.TestCase):
 def test_unavailable_supersedes_old_heartbeat_without_deleting_geometry(self):
  with tempfile.TemporaryDirectory(dir=B/'verification') as d:
   p=Path(d);(p/'shapes.tsv').write_text('old anchored geometry','utf8')
   (p/'heartbeat.tsv').write_text('old-model','utf8')
   publish_model_state(p,{'token':'new-view'},'unavailable','缺少 M15',atomic)
   fields=(p/'heartbeat.tsv').read_text('utf8').strip().split('\t')
   self.assertEqual(len(fields),13)
   self.assertEqual(fields[3],'new-view')
   self.assertEqual(fields[5], 'unavailable');self.assertEqual(fields[8],'unavailable')
   self.assertEqual(fields[4],'experiment_snapshot')
   self.assertEqual((p/'shapes.tsv').read_text('utf8'),'old anchored geometry')
 def test_waiting_state_and_hostile_reason_do_not_break_protocol(self):
  with tempfile.TemporaryDirectory(dir=B/'verification') as d:
   p=Path(d);publish_model_state(p,{'token':'next'},'pending','x\ty\nz\r',atomic)
   lines=(p/'heartbeat.tsv').read_text('utf8').splitlines()
   self.assertEqual(len(lines),1);self.assertEqual(len(lines[0].split('\t')),13)
 def test_incomplete_report_is_never_full(self):
  for report in ({'available':False,'missing':['M15']},{'error':'failed'},{}, {'available':1}):
   self.assertEqual(completed_stage(report),'limited')
  self.assertEqual(completed_stage({'available':True}),'full')
 def test_captured_missing_background_remains_explicit(self):
  p=B/'verification/native_initial/request_102923304041429_3600.tsv'
  req=parse_request(p.read_text('utf-8-sig'))
  report,charts=run(req['bars'],req['background'])
  self.assertFalse(report['available']);self.assertIn('M15',report['missing']);self.assertEqual(charts,{})

if __name__=='__main__':unittest.main()
