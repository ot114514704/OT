"""Back up the equivalent geometry memo patch, preserving every prior ZIP."""
from pathlib import Path
import hashlib,json,zipfile

B=Path(__file__).parent;V=B/'verification/performance_r3_20261118'
checks={n:json.loads((V/n).read_text('utf8')) for n in ('geometry_memo_acceptance.json','geometry_memo_reference_acceptance.json','integration_acceptance.json','deployment_acceptance.json','regression_observation.json')}
assert all(x['passed'] for x in checks.values())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(B/name)==h for name,h in checks['integration_acceptance.json']['source_sha256'].items())
meta={'revision':'1.230-r3p1','scope':'Equivalent geometry-window memo in independent fusion worker; MQL guard remains 1.230-r3.',
      'source_sha256':checks['integration_acceptance.json']['source_sha256'],
      'full_results_exact':111,'references':'four native regions / six supplied references, half/full prefixes exact',
      'regressions':61,'offline_seconds':checks['geometry_memo_acceptance.json']['seconds'],
      'deployment':checks['deployment_acceptance.json'],
      'production_unchanged':True,'book_core_unchanged':True,
      'research_snapshot_changes':['long_geometry.py: optional candidate callback','native_triangles.py: optional candidate callback'],
      'limits':['Offline timing is one sample, not end-to-end live latency.','Dense/model computation and historical coverage remain open.','Native UI was checked on the same historical viewport only; continuation was toggled OFF/ON and restored.'],
      'uploaded_to_OT_at_packaging':False}
(B/'REVISION_R3P1.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),'utf8')
readme='''Book＋盘整实验 1.230-r3p1，2026-11-18

在已验收的 r3 外层续观基础上复用完全相同的通道／三角候选窗口。缓存键包含每根原生已收盘K线、时间标签、周期、价格、参数与模式；每次返回独立证据副本。所有生命周期和冻结范围选择仍逐个收盘时刻从头计算。缓存有数量与字节上限，不从文件加载。

同一原生请求111条结果完全一致；离线不带分析器对照95.63秒→75.26秒，约减少21%。另有六处参考对应四份数据的前半段／全量形态字段一致，61项回归通过。运行后台已重启，新请求、完整H1/M15图表数据、综合判断及续观结果均与更新前相同，原生回执晚于重启。

这不是全部延迟已解决，也不是全历史识别质量证明。原Book核心、生产目录、指标EX5、原几何布局均保持；只在独立实验的研究快照两个文件加入可选窗口接口。默认调用行为不变。不要用较早“快照与生产完全相同”的历史记录描述这两个明确的实验补丁。

当前入口与r3相同。旧r3及稳定版备份保留。回退本次性能补丁可使用 verification/performance_r3_20261118/before_deploy 的 worker.py 和两个 ict_trader 文件，在停止独立后台后恢复，再启动。完整r3恢复包仍是之前不可变ZIP。

完整验证见 REVISION_R3P1.json、verification/performance_r3_20261118。r3原生截图与开关验收仍保留在 verification/native_r3。本性能补丁没有重载或移动图表；为刷新同结果标识的原生回执，另观察续观关/开并恢复开启，同一视窗原布局保留。
'''
(B/'README_R3P1.txt').write_text(readme,'utf8')
prior=B.parent/'上传/OT_20261118_fusion_r3/book302-consolidation-1.230-r3-native-limited-20261118.zip'
with zipfile.ZipFile(prior) as z:
    files={B/p for p in z.namelist() if p!='NATIVE_PACKAGE_MANIFEST.json'}
files.update(p for p in V.rglob('*') if p.is_file())
files.update(B/p for p in ('README_R3P1.txt','REVISION_R3P1.json','geometry_window_memo.py','profile_fusion_r3.py','verify_geometry_memo_r4.py','verify_geometry_memo_references.py','verify_geometry_integration.py','verify_performance_deployment.py','package_performance_r3p1.py'))
manifest=[{'path':p.relative_to(B).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
output=B.parent/'备份/Book302_盘整融合1.230-r3p1_等价窗口复用_20261118.zip'
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(files):z.write(p,p.relative_to(B).as_posix())
    z.writestr('R3P1_PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
    for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
receipt={'path':str(output),'sha256':sha(output),'bytes':output.stat().st_size,'files_verified':len(manifest),'uploaded':False,
         'git_blob_sha':hashlib.sha1(b'blob '+str(output.stat().st_size).encode()+b'\0'+output.read_bytes()).hexdigest()}
(B/'PACKAGE_R3P1.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(receipt,ensure_ascii=False))
