"""Complementary scanner: frozen triangle anchors on the observed native bar axis.
No fabricated bars or future extension. Cross-session coverage stays unverified.
"""
from copy import deepcopy
from statistics import median
from .long_geometry import candidate
from .core import visible

VERSION='native_session_triangle_candidate_v1'
WINDOWS=(24,28,32,36,48)
TRIANGLES=('ascending_triangle','descending_triangle','triangle')


def qualify_triangle(window,prior,seeded):
    if not window or window[0].seconds!=3600 or len(window) not in WINDOWS:return None
    # This complementary scanner has always required an observed session gap.
    # Ordinary contiguous triangles remain the responsibility of the main scan.
    if not any(a.closed_at!=b.time for a,b in zip(window,window[1:])):return None
    if seeded:
        if not prior or prior[-1].closed_at!=window[0].time:return None
        atr=median(x.high-x.low for x in window)
        if not any(abs(x.close-x.open)>=1.2*atr and abs(x.close-x.open)>=.6*(x.high-x.low) for x in prior[-6:]):return None
    c=candidate(window,compact=True,edge_start=seeded,native_axis=True,triangle_first=True)
    if not c or c['geometry']['subtype'] not in TRIANGLES:return None
    g=c['geometry']
    if not g['gaps'] or g['validation']['overlap_bars']<12:return None
    g['axis']='observed_native_bar_index'
    g['basis']='native_session_boundary_touch_and_confirmed_pivots' if seeded else 'native_session_confirmed_boundary_pairs'
    g['reason']='按原生已收盘柱序号核验三角双轨；锚点首次可知后冻结，休市及缺柱区间内价格覆盖未验证'
    c['missing']+=['跨时段缺口不补造K线，缺口内价格路径与覆盖未知','仅三角形态候选，不替代IPDA实体平衡确认']
    return c

def observe_triangles(bars,asof):
    bars=visible(bars,asof)
    if not bars:return {'ranges':[],'current':[],'history':[]}
    if any(a.time>=b.time or a.seconds!=b.seconds for a,b in zip(bars,bars[1:])):raise ValueError('Ordered homogeneous native candles required')
    if bars[0].seconds!=3600:return {'ranges':[],'current':[],'history':[]}
    positions={b.time.isoformat():i for i,b in enumerate(bars)}
    active={};ranges=[];history=[]
    def price(points,index):
        a,b=points;x,y=positions[a['time']],positions[b['time']]
        return a['price']+(b['price']-a['price'])*(index-x)/(y-x)
    for i,b in enumerate(bars):
        for n in WINDOWS:
            for seeded in (False,True):
                key=(n,seeded);box=active.get(key)
                if box:
                    g=box['geometry'];upper=price(g['upper'],i);lower=price(g['lower'],i)
                    gap=i and (b.time-bars[i-1].closed_at).total_seconds()>96*3600
                    side=1 if b.close>upper+.15*box['frozen_atr'] else -1 if b.close<lower-.15*box['frozen_atr'] else 0
                    box['streak']=box['streak']+1 if side and side==box['side'] else 1 if side else 0
                    box.update(end_at=b.closed_at.isoformat(),side=side)
                    status='超过96小时数据间隔，三角观察中止' if gap else '两边交会，三角观察终止' if upper<=lower else ('向上离开三角观察区' if side==1 else '向下离开三角观察区') if box['streak']>=2 else None
                    if status:
                        box.update(status=status,active=False);del active[key]
                    elif not side:
                        frame=deepcopy(g['frame']);start=positions[frame[0]['time']]
                        frame=[dict(time=bars[start].time.isoformat(),price=price(g['upper'],start)),dict(time=b.time.isoformat(),price=upper),dict(time=b.time.isoformat(),price=lower),dict(time=bars[start].time.isoformat(),price=price(g['lower'],start))]
                        box['display_geometry']={**deepcopy(g),'frame':frame,'display_through':b.closed_at.isoformat(),'basis':'frozen_native_bar_rails_through_observed_closes'}
                    continue
                if i+1<n:continue
                start=i-n+1;window=bars[start:i+1]
                c=qualify_triangle(window,bars[max(0,start-6):start],seeded)
                if c is None:continue
                box={**deepcopy(c),'id':VERSION+(':edge' if seeded else '')+':'+str(n)+':'+b.closed_at.isoformat(),'end_at':b.closed_at.isoformat(),'active':True,'status':'跨时段三角形态候选','side':0,'streak':0}
                active[key]=box;ranges.append(box)
    return {'version':VERSION,'ranges':ranges,'current':list(active.values()),'history':history}
