# Book_1.302_pending_source · 1.302

上传设备：ALEXANDERDELL2；原冻结时间：2026-11-06T10:40:18.436241-06:00。

- **MQ5源码入口**：[Machine1_Book.mq5](source/Machine1_Book.mq5)，本地MQH依赖已全部展开在同一source目录中。
- EX5：没有为这份源码声称匹配EX5。
- 通道：`development_or_research_not_accepted`；需要后台：`false`。
- 验收范围：Uncompiled ScopePhases source changes; no matchingEX5
- 源码/EX5绑定：No matching binary claimed for pending changes

完整限制和逐文件SHA见 [SOURCE_STATUS.json](SOURCE_STATUS.json)。此目录不是整套理论准确性正式发布；正式里程碑null。不要只拷mq5而丢掉它的mqh。
