# 当前完整组件：Book+Unified 1.071 / 分类显示1.074

设备DTE-JHZ39K3。独立当前组件包包含两个入口全部143份源码/依赖、已安装EX5、详细逻辑说明、编译和实际图面验收、IEEE独立复算及拒绝R1的反例。

复制MQL5/Indicators内本设备两个子目录到MT5数据目录相同位置，刷新导航器；挂载Outward1071/Machine1_TwoScoreLifecycle1071，再挂LayerControls1074/Machine1_LayerControls1074。具体参数和本机位置见docs/CURRENT_INSTALLATION_1071_ZH.md。本机H4已经挂好，不要重复多实例加载。

70组双70配对：新增8组同向接触边突破，原62全部生命周期字段保留。816组历史波浪候选轮廓共3824对象实图坐标一致。25项规则、29项F11后图面、10项分类和10项最终迁移通过。默认8类图形全开，文字和说明隐藏；顶部四按钮可恢复或分类隐藏。面板行数不限制绘图。

这是EURUSD H4闭柱5009窗口有限验证，完整Goal active，正式里程碑null；未证明全部历史/市场/周期及完整递归波浪。5条未合格背景Book差异仍单独记录；父级/延续/反转研究继续。两项70门槛不变。

tests/保持原工作区相对include，需复原mt5/tests布局才能重编译；本机ChartID/一次性收据保护的QA程序不是通用安装脚本。exact-input搜索提示和行情仅为此次验证凭据，不能当成其他图表确认的信号。

固定成果入口：https://github.com/alexander094683-bit/forex-ai-source/tree/main/deliveries/DTE-JHZ39K3

旧完整工作区2128文件、早期波浪7080源码包保留于BookUnified_20261106_LayerControls1065；旧1066/1067完整组件保留于BookUnified_20261106_Render1066，不覆盖旧档。

## 当前下载及证据修订R2

[下载当前完整包](BookUnified_CURRENT_FULL_DTE-JHZ39K3_20261106_v1071_Display1074_EvidenceR2.zip) · [清单](MANIFEST_EvidenceR2.json) · [远端核验](REMOTE_VERIFICATION_EvidenceR2.json)。194文件，主1.071/显示1.074二进制与信号逻辑不变；新增退役后的7030对象清单。FINAL_STACK首项6901是删除旧对象数量，不能记为新对象数量；此统计解释已修正，原包及原收据保留。
