#ifndef BOOK_EXPERIMENT_GUARD
#define BOOK_EXPERIMENT_GUARD
#include "pa/BookThreePushPA.mqh"
#include "BookExperimentRequestPolicy.mqh"
input group "独立盘整实验（原Book几何不变）"
input bool ExperimentGuardEnabled=true;
input bool ExperimentShowRanges=false;
input bool ExperimentShowThreePush=true;
input bool ExperimentDrawThreePush=false; // Calculation remains enabled; outlines are optional.
input bool ExperimentStrictThreePush=false;
input bool ExperimentFocusRangeCrosses=true;
input bool ExperimentShowAllRanges=false;
input bool ExperimentAnnotateRangeCrosses=true;
input int ExperimentMaxAnnotations=12;
input bool ExperimentShowContinuation=true; // Independent observation, original endpoint unchanged.
input bool ExperimentContinuationSelectedOnly=false;
struct BEXRecord {string id,label,detail,context,pa,follow,fixed,kind;datetime clock,start,known;int code,matches,side;double low0,high0,low,high;};
BEXRecord bex_records[];
struct BEXContinuation {string id,state,label,policy,family;datetime start,end;double price0,price1,low,high;};
BEXContinuation bex_continuations[];
bool bex_continue=true;
bool bex_shift_visible=true,bex_turning_visible=true;
string bex_prefix="",bex_scope="",bex_token="",bex_view="",bex_loaded="",bex_note="等待独立研究计算";
string bex_selected="",bex_stage="";
datetime bex_cutoff=0;
ulong bex_poll=0,bex_submitted=0;
int bex_elapsed=0;
bool bex_hidden=false,bex_details=false,bex_markers=true;
int bex_annotation_total=0,bex_annotation_shown=0;
string BEXRoot(){return "Book302Experiment1230\\";}
string BEXClip(string s,int n=100){return StringLen(s)>n?StringSubstr(s,0,n-1)+"…":s;}
color BEXColour(int code){return code==1||code==2||code==8?clrGold:code==3||code==6?clrOrange:code==4?clrDeepSkyBlue:code==5?clrCadetBlue:clrSilver;}
void BEXLabel(string key,string value,int x,int y,color colour,int size=10){
 string name=bex_prefix+key;if(ObjectFind(0,name)<0)ObjectCreate(0,name,OBJ_LABEL,0,0,0);
 ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);ObjectSetInteger(0,name,OBJPROP_COLOR,colour);ObjectSetInteger(0,name,OBJPROP_FONTSIZE,size);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
 ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,name,OBJPROP_TEXT,BEXClip(value));ObjectSetString(0,name,OBJPROP_TOOLTIP,value);
}
string BEXJoint(int code){
 if(code==1||code==2)return "盘整内穿线；三推仅作旁证，新方向未确认";
 if(code==8)return "内层已离区，外层仍包容；三推不解除外层约束";
 if(code==3)return "区间越界待跟进；与三推越轨分别核对";
 if(code==4)return "成熟区间离开条件已触发；趋势反转仍需另证";
 if(code==5)return "仅离开形态候选区；不等于成熟盘整突破";
 if(code==6||code==7)return "当时依据尚未提前可知；不倒填确认";
 return "盘整依据不足；仅保留原Book几何事件";
}
void BEXButton(string key,string caption,int x,int y,int w){
 string n=bex_prefix+key;if(ObjectFind(0,n)<0)ObjectCreate(0,n,OBJ_BUTTON,0,0,0);
 ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);
 ObjectSetInteger(0,n,OBJPROP_XSIZE,w);ObjectSetInteger(0,n,OBJPROP_YSIZE,22);
 ObjectSetInteger(0,n,OBJPROP_BGCOLOR,C'36,45,58');ObjectSetInteger(0,n,OBJPROP_COLOR,clrWhite);
 ObjectSetInteger(0,n,OBJPROP_FONTSIZE,9);ObjectSetInteger(0,n,OBJPROP_STATE,false);ObjectSetString(0,n,OBJPROP_TEXT,caption);
}
void BEXPanel(){
 if(!ExperimentGuardEnabled)return;
 int height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS),width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS);
 if(height<300||width<450)return;
 int w=(int)MathMin(550,width-32),x=width-w-16,y=height-36;
 BEXButton("toggle_marks",bex_markers?"内穿标注 开":"内穿标注 关",x,y,100);
 BEXButton("toggle_details",bex_details?"收起说明":"联合说明",x+106,y,90);
 BEXButton("toggle_continue",bex_continue?"续观 开":"续观 关",x+202,y,76);
 BEXLabel("dock_status",bex_note,x+284,y+3,clrSilver,8);
 ObjectSetString(0,bex_prefix+"dock_status",OBJPROP_TEXT,BEXClip(bex_note,18));
 if(!bex_details){ObjectsDeleteAll(0,bex_prefix+"detail_");return;}
 y=height-310;string n=bex_prefix+"detail_panel";
 if(ObjectFind(0,n)<0)ObjectCreate(0,n,OBJ_RECTANGLE_LABEL,0,0,0);ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x);
 ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);ObjectSetInteger(0,n,OBJPROP_XSIZE,w);ObjectSetInteger(0,n,OBJPROP_YSIZE,265);
 ObjectSetInteger(0,n,OBJPROP_BGCOLOR,C'18,22,29');ObjectSetInteger(0,n,OBJPROP_BORDER_TYPE,BORDER_FLAT);
 BEXLabel("detail_title","独立实验 1.230 · Book / 盘整 / 三推",x+10,y+8,clrGold,10);
 BEXRecord selected;bool found=false;
 for(int i=0;i<ArraySize(bex_records);i++)if(bex_records[i].id==bex_selected){selected=bex_records[i];found=true;break;}
 if(found&&bex_loaded==bex_token&&!bex_hidden){
  ObjectDelete(0,bex_prefix+"detail_wait");
  string lines[7];lines[0]=TimeToString(selected.clock-PeriodSeconds(_Period),TIME_DATE|TIME_MINUTES)+" · "+selected.label;
  lines[1]=BEXJoint(selected.code);lines[2]="范围："+selected.kind+" · 首次可知 "+TimeToString(selected.known,TIME_DATE|TIME_MINUTES);
  lines[3]=selected.fixed;lines[4]="三推旁证："+selected.pa;lines[5]=selected.follow;lines[6]=selected.detail;
  for(int j=0;j<7;j++){string key="detail_row_"+IntegerToString(j);BEXLabel(key,lines[j],x+10,y+34+j*26,j==1?BEXColour(selected.code):clrSilver,9);ObjectSetString(0,bex_prefix+key,OBJPROP_TEXT,BEXClip(lines[j],(w-20)/13));}
 }else {ObjectsDeleteAll(0,bex_prefix+"detail_row_");BEXLabel("detail_wait","等待当前输入的证据；历史判断暂挂",x+10,y+42,clrOrange,9);}
 BEXButton("detail_select_0","前一处",x+10,y+226,70);BEXButton("detail_select_1","后一处",x+86,y+226,70);BEXButton("detail_select_2","最新",x+162,y+226,70);
 BEXLabel("detail_hint","悬停读完整证据 · 候选与确认分开",x+240,y+230,clrSilver,8);
}
void BEXInit(){bex_prefix="BEX_"+IntegerToString(ChartID())+"_"+IntegerToString((long)GetMicrosecondCount())+"_";bex_scope=IntegerToString(ChartID())+"_"+IntegerToString(PeriodSeconds(_Period));bex_continue=ExperimentShowContinuation;bex_shift_visible=ShowGuidedChannelShift;bex_turning_visible=ShowGuidedTurning;FolderCreate("Book302Experiment1230");BEXPanel();}
void BEXDestroy(){if(bex_prefix!="")ObjectsDeleteAll(0,bex_prefix);}
void BEXLine(string name,datetime a,double pa,datetime b,double pb,color colour,int style,int width,string tip){
 if(a>=b)return;ObjectCreate(0,bex_prefix+name,OBJ_TREND,0,a,pa,b,pb);ObjectSetInteger(0,bex_prefix+name,OBJPROP_COLOR,colour);ObjectSetInteger(0,bex_prefix+name,OBJPROP_STYLE,style);ObjectSetInteger(0,bex_prefix+name,OBJPROP_WIDTH,width);ObjectSetInteger(0,bex_prefix+name,OBJPROP_RAY_RIGHT,false);ObjectSetInteger(0,bex_prefix+name,OBJPROP_SELECTABLE,false);ObjectSetString(0,bex_prefix+name,OBJPROP_TOOLTIP,tip);
}
void BEXExportPA(int f,string event_id,const MqlRates &all[],datetime cutoff,bool draw){
 if(!ExperimentShowThreePush)return;
 int n=0;while(n<ArraySize(all)&&all[n].time+PeriodSeconds(_Period)<=cutoff)n++;
 if(n<20)return;MqlRates r[];ArrayCopy(r,all,0,0,n);M1ULegacyPush pushes[];M1ULegacyPushBuild(r,PeriodSeconds(_Period),cutoff,pushes);
 int displayed=0;
 for(int k=ArraySize(pushes)-1;k>=0;k--){
  M1ULegacyPush p=pushes[k];OverlayPA o;OverlayPAEvaluate(r,p,PeriodSeconds(_Period),cutoff,o,ExperimentStrictThreePush);if(o.category==0)continue;
  FileWrite(f,"P",event_id,o.category,o.trend,p.direction,(long)o.known,(long)o.event,o.state,(long)o.start,(long)o.end);
  if(!draw||!ExperimentDrawThreePush||displayed>=8)continue;datetime left=iTime(_Symbol,_Period,(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR));if(o.end<left)continue;
  string id="pa_"+IntegerToString(displayed++);string tip=OverlayPAName(o)+"\n"+o.reason+"\n三推形态不充当实体平衡突破或趋势确认";
  BEXLine(id+"u",o.start,o.upper0,o.end,o.upper1,clrCadetBlue,STYLE_DOT,1,tip);BEXLine(id+"l",o.start,o.lower0,o.end,o.lower1,clrCadetBlue,STYLE_DOT,1,tip);
  ObjectCreate(0,bex_prefix+id+"text",OBJ_TEXT,0,o.end,o.upper1);ObjectSetString(0,bex_prefix+id+"text",OBJPROP_TEXT,OverlayPAName(o));ObjectSetInteger(0,bex_prefix+id+"text",OBJPROP_COLOR,clrCadetBlue);ObjectSetInteger(0,bex_prefix+id+"text",OBJPROP_FONTSIZE,8);ObjectSetString(0,bex_prefix+id+"text",OBJPROP_TOOLTIP,tip);
 }
}
void BEXSubmit(const MqlRates &r[],const BKNShape &shapes[],string input_hash,string viewport,datetime cutoff){
 if(!ExperimentGuardEnabled||ArraySize(r)<20)return;
 if(_Symbol!="XAUUSD"||(PeriodSeconds(_Period)!=900&&PeriodSeconds(_Period)!=3600)){bex_note="本实验只验证 XAUUSD H1/M15；其他品种周期不判盘整";BEXPanel();return;}
 string token=BEXRequestToken(input_hash,viewport,ExperimentShowThreePush,ExperimentStrictThreePush);if(token==bex_token&&viewport==bex_view)return;
 ObjectsDeleteAll(0,bex_prefix+"event_");ObjectsDeleteAll(0,bex_prefix+"pa_");
 ObjectsDeleteAll(0,bex_prefix+"continuation_");ArrayResize(bex_continuations,0);
 bex_token=token;bex_view=viewport;bex_cutoff=cutoff;bex_loaded="";bex_stage="";bex_selected="";bex_submitted=GetTickCount64();bex_note="独立盘整计算中；旧结果不参与本帧判断";ArrayResize(bex_records,0);BEXPanel();
 string tmp=BEXRoot()+"request_"+bex_scope+".tmp",dest=BEXRoot()+"request_"+bex_scope+".tsv";
 int f=FileOpen(tmp,FILE_WRITE|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);if(f==INVALID_HANDLE){bex_note="无法写入独立请求文件";BEXPanel();return;}
 FileWrite(f,"BEXP",1,token,PeriodSeconds(_Period),(long)cutoff,ArraySize(r),ChartID(),_Symbol,_Point);
 for(int i=0;i<ArraySize(r);i++)FileWrite(f,"B",(long)r[i].time,StringFormat("%.17g",r[i].open),StringFormat("%.17g",r[i].high),StringFormat("%.17g",r[i].low),StringFormat("%.17g",r[i].close),r[i].spread);
 // Independent native background for the original complete research model.
 ENUM_TIMEFRAMES background_period=_Period==PERIOD_H1?PERIOD_M15:PERIOD_H1;int background_seconds=PeriodSeconds(background_period);
 MqlRates background[];int count=CopyRates(_Symbol,background_period,cutoff-background_seconds,background_period==PERIOD_M15?3000:1200,background);
 for(int i=0;i<count;i++)if(background[i].time+background_seconds<=cutoff)FileWrite(f,"T",background_seconds,(long)background[i].time,StringFormat("%.17g",background[i].open),StringFormat("%.17g",background[i].high),StringFormat("%.17g",background[i].low),StringFormat("%.17g",background[i].close),background[i].spread);
 for(int k=0;k<ArraySize(shapes);k++){
  BKNShape s=shapes[k];if(!BEXEventInScope(s.line_family,s.line_event_known,cutoff))continue;
  double slope=(s.line_b_index!=s.line_a_index)?(s.line_b_price-s.line_a_price)/(s.line_b_index-s.line_a_index):0;
  FileWrite(f,"E",s.id,s.line_family,(long)s.line_construction_known,(long)s.line_event_known,s.line_event_kind,(long)s.owner_a,(long)s.owner_b,s.pb,slope);
  BEXExportPA(f,s.id,r,s.line_event_known,false);
 }
 BEXExportPA(f,"__CURRENT",r,cutoff,true);FileWrite(f,"END",token);FileClose(f);
 if(!FileMove(tmp,0,dest,FILE_REWRITE)){bex_note="请求发布失败："+IntegerToString(GetLastError());BEXPanel();}
}
void BEXDraw(){
 ObjectsDeleteAll(0,bex_prefix+"event_");
 ObjectsDeleteAll(0,bex_prefix+"continuation_");
 if(bex_continue&&!bex_hidden&&bex_loaded==bex_token)for(int k=0;k<ArraySize(bex_continuations);k++){
  BEXContinuation c=bex_continuations[k];if((ExperimentContinuationSelectedOnly&&c.id!=bex_selected)||c.start>c.end||c.end+PeriodSeconds(_Period)>bex_cutoff)continue;
  if((c.family=="GUIDED_SHIFT"&&!bex_shift_visible)||(c.family=="GUIDED_TURNING"&&!bex_turning_visible))continue;
  string tip="盘整内穿线后的独立续观（原终点保留）\n"+c.label+"\n"+c.policy+"\n穿线时固定边界 "+DoubleToString(c.low,_Digits)+"～"+DoubleToString(c.high,_Digits);
  string key="continuation_"+IntegerToString(k);
  BEXLine(key+"line",c.start,c.price0,c.end,c.price1,clrGold,STYLE_DOT,1,tip);
  string n=bex_prefix+key+"label";ObjectCreate(0,n,OBJ_TEXT,0,c.end,c.price1);
  string reason=c.state=="observing"?"续观":c.state=="resumed"?"缺口后续观":c.state=="gap"?"间隔暂停":c.state=="invalid_bar"?"行情无效":"固定范围已离开";
  ObjectSetString(0,n,OBJPROP_TEXT,"  "+reason);ObjectSetString(0,n,OBJPROP_TOOLTIP,tip);
  ObjectSetInteger(0,n,OBJPROP_COLOR,clrGold);ObjectSetInteger(0,n,OBJPROP_FONTSIZE,8);ObjectSetInteger(0,n,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
 }
 int annotations[];ArrayResize(annotations,0);bex_annotation_total=0;bex_annotation_shown=0;
 for(int k=0;k<ArraySize(bex_records);k++){BEXRecord r=bex_records[k];if(r.id=="__CURRENT"||!(r.code==1||r.code==2||r.code==8))continue;int n=ArraySize(annotations);ArrayResize(annotations,n+1);annotations[n]=k;}
 for(int a=1;a<ArraySize(annotations);a++){int key=annotations[a],j=a-1;while(j>=0&&bex_records[annotations[j]].clock<bex_records[key].clock){annotations[j+1]=annotations[j];j--;}annotations[j+1]=key;}
 if(ExperimentAnnotateRangeCrosses&&bex_markers)for(int a=0;a<ArraySize(annotations);a++){
  int k=annotations[a];BEXRecord r=bex_records[k];bool duplicate=false;
  for(int j=0;j<a;j++)if(bex_records[annotations[j]].clock==r.clock){duplicate=true;break;}
  if(duplicate)continue;
  datetime t=r.clock-PeriodSeconds(_Period);int shift=iBarShift(_Symbol,_Period,t,true),x,y;
  if(shift<1)continue;double price=iClose(_Symbol,_Period,shift);
  if(!ChartTimePriceToXY(0,0,t,price,x,y)||x<0||x>(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS)-60)continue;
  bex_annotation_total++;if(bex_annotation_shown>=(int)MathMax(1,ExperimentMaxAnnotations))continue;
  bex_annotation_shown++;
  string name=bex_prefix+"event_"+IntegerToString(k)+"_caption";
  ObjectCreate(0,name,OBJ_TEXT,0,t,price);ObjectSetString(0,name,OBJPROP_TEXT,"  内穿 #"+IntegerToString(bex_annotation_shown));
  ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_COLOR,clrGold);
  ObjectSetInteger(0,name,OBJPROP_FONTSIZE,8);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
  ObjectSetString(0,name,OBJPROP_TOOLTIP,r.label+"\n"+BEXJoint(r.code)+"\n"+r.detail+"\n"+r.pa+"\n"+r.follow);
 }
 for(int k=0;k<ArraySize(bex_records);k++){
  BEXRecord r=bex_records[k];if(r.id=="__CURRENT"||!bex_markers)continue;
  bool inside=r.code==1||r.code==2||r.code==8;
  if(ExperimentFocusRangeCrosses&&!inside&&r.id!=bex_selected)continue;
  datetime t=r.clock-PeriodSeconds(_Period);int shift=iBarShift(_Symbol,_Period,t,true);if(shift<1)continue;double price=iClose(_Symbol,_Period,shift);
  string id="event_"+IntegerToString(k),name=bex_prefix+id+"dot",tip=r.label+"\n"+r.detail+"\n"+r.pa+"\n"+r.follow+"\n"+r.fixed+"\n范围ID："+r.context;
  ObjectCreate(0,name,OBJ_TEXT,0,t,price);ObjectSetString(0,name,OBJPROP_TEXT,r.code==1||r.code==2||r.code==8?"●":"◇");ObjectSetString(0,name,OBJPROP_FONT,"Arial");ObjectSetInteger(0,name,OBJPROP_FONTSIZE,12);ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_CENTER);ObjectSetInteger(0,name,OBJPROP_COLOR,BEXColour(r.code));ObjectSetString(0,name,OBJPROP_TOOLTIP,tip);
  if(!bex_details||!ExperimentShowRanges||(!ExperimentShowAllRanges&&r.id!=bex_selected)||r.start<=0||r.known>t||r.low>=r.high)continue;
  color colour=BEXColour(r.code);BEXLine(id+"u",r.start,r.high0,t,r.high,colour,STYLE_DOT,1,tip);BEXLine(id+"l",r.start,r.low0,t,r.low,colour,STYLE_DOT,1,tip);
  BEXLine(id+"a",r.start,r.low0,r.start+1,r.high0,colour,STYLE_DOT,1,tip);BEXLine(id+"b",t-1,r.low,t,r.high,colour,STYLE_DOT,1,tip);
 }
 BEXPanel();ChartRedraw(0);
 int audit=FileOpen(BEXRoot()+"continuation_render_"+bex_scope+".tsv",FILE_WRITE|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);
 if(audit!=INVALID_HANDLE){
  FileWrite(audit,"id","family","state","start","end","price0","price1","line_present","label_present","actual_start","actual_end","actual_price0","actual_price1","version");
  for(int k=0;k<ArraySize(bex_continuations);k++){
   BEXContinuation c=bex_continuations[k];string key=bex_prefix+"continuation_"+IntegerToString(k),line=key+"line";
   bool exists=ObjectFind(0,line)>=0;
   FileWrite(audit,c.id,c.family,c.state,(long)c.start,(long)c.end,c.price0,c.price1,(int)exists,(int)(ObjectFind(0,key+"label")>=0),
    exists?(long)ObjectGetInteger(0,line,OBJPROP_TIME,0):0,exists?(long)ObjectGetInteger(0,line,OBJPROP_TIME,1):0,
    exists?ObjectGetDouble(0,line,OBJPROP_PRICE,0):0,exists?ObjectGetDouble(0,line,OBJPROP_PRICE,1):0,"1.230");
  }FileClose(audit);
 }
 string output=BEXRoot()+"experiment_"+bex_scope+".png";ChartScreenShot(0,output,(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS),ALIGN_LEFT);
}
void BEXNativeViewEvent(string name){
 int n=StringLen(name);if(n<9)return;
 string suffix=StringSubstr(name,n-9);
 if(suffix=="_toggle_7")bex_shift_visible=!bex_shift_visible;
 if(suffix=="_toggle_8")bex_turning_visible=!bex_turning_visible;
 if(suffix=="_toggle_7"||suffix=="_toggle_8")BEXDraw();
}
bool BEXClick(string name){
 if(StringFind(name,bex_prefix)!=0)return false;
 if(name==bex_prefix+"toggle_continue"){bex_continue=!bex_continue;BEXDraw();return true;}
 if(name==bex_prefix+"toggle_marks"){bex_markers=!bex_markers;BEXDraw();return true;}
 if(name==bex_prefix+"toggle_details"){bex_details=!bex_details;BEXDraw();return true;}
 if(StringFind(name,bex_prefix+"event_")==0){string p[];StringSplit(StringSubstr(name,StringLen(bex_prefix+"event_")),'_',p);int k=(int)StringToInteger(p[0]);if(k>=0&&k<ArraySize(bex_records))bex_selected=bex_records[k].id;bex_details=true;BEXDraw();return true;}
 if(StringFind(name,bex_prefix+"detail_select_")!=0)return false;
 int mode=(int)StringToInteger(StringSubstr(name,StringLen(bex_prefix+"detail_select_")));datetime selected=0;
 for(int k=0;k<ArraySize(bex_records);k++)if(bex_records[k].id==bex_selected)selected=bex_records[k].clock;
 int choice=-1;
 for(int k=0;k<ArraySize(bex_records);k++){BEXRecord r=bex_records[k];if(r.id=="__CURRENT"||(!(r.code==1||r.code==2||r.code==8)&&ExperimentFocusRangeCrosses))continue;
  if(mode==0&&(selected==0||r.clock<selected)&&(choice<0||r.clock>bex_records[choice].clock))choice=k;
  if(mode==1&&r.clock>selected&&(choice<0||r.clock<bex_records[choice].clock))choice=k;
  if(mode==2&&(choice<0||r.clock>bex_records[choice].clock))choice=k;
 }
 if(choice>=0)bex_selected=bex_records[choice].id;ObjectSetInteger(0,name,OBJPROP_STATE,false);BEXDraw();return true;
}
void BEXPoll(bool busy,string viewport){
 if(!ExperimentGuardEnabled||bex_token==""||GetTickCount64()-bex_poll<750)return;bex_poll=GetTickCount64();
 if(viewport!=bex_view||busy){bex_note="原生视窗/行情重算中，盘整判断暂挂";ObjectsDeleteAll(0,bex_prefix+"event_");ObjectsDeleteAll(0,bex_prefix+"continuation_");bex_hidden=true;BEXPanel();return;}
 if(bex_loaded==bex_token&&bex_stage=="full"){bex_note="已核对至 "+TimeToString(bex_cutoff,TIME_DATE|TIME_MINUTES)+"；计算 "+DoubleToString(bex_elapsed/1000.0,1)+" 秒；独立实验，非交易许可";int hf=FileOpen(BEXRoot()+"worker_heartbeat.txt",FILE_READ|FILE_TXT|FILE_ANSI);if(hf!=INVALID_HANDLE){long beat=StringToInteger(FileReadString(hf));FileClose(hf);if((long)TimeGMT()-beat>60)bex_note+="；worker离线，更新待恢复";}if(bex_hidden){bex_hidden=false;BEXDraw();}else BEXPanel();return;}
 string file=BEXRoot()+"reply_"+bex_scope+".tsv";int f=FileOpen(file,FILE_READ|FILE_TXT|FILE_ANSI,0,CP_UTF8);
 if(f!=INVALID_HANDLE){
  string h[];StringSplit(FileReadString(f),'\t',h);
  if(ArraySize(h)>=8&&h[0]=="BEXP_RESULT"&&h[1]=="2"&&h[6]=="Book302-consolidation-experiment-1.230"&&h[2]==bex_token&&(datetime)StringToInteger(h[5])==bex_cutoff){
   if(bex_loaded==bex_token&&bex_stage==h[7]){FileClose(f);BEXPanel();return;}
   BEXRecord records[];BEXContinuation continuations[];bool valid=true,ended=false;int expected=(int)StringToInteger(h[3]);
   while(!FileIsEnding(f)){
    string p[];StringSplit(FileReadString(f),'\t',p);if(ArraySize(p)==0)continue;
    if(p[0]=="END"){ended=ArraySize(p)==3&&p[1]==bex_token&&(int)StringToInteger(p[2])==expected;break;}
    if(p[0]=="C"){
     if(ArraySize(p)!=12){valid=false;break;}
     BEXContinuation c;c.id=p[1];c.start=(datetime)StringToInteger(p[2]);c.end=(datetime)StringToInteger(p[3]);c.price0=StringToDouble(p[4]);c.price1=StringToDouble(p[5]);c.low=StringToDouble(p[6]);c.high=StringToDouble(p[7]);c.state=p[8];c.label=p[9];c.policy=p[10];c.family=p[11];
     int count=ArraySize(continuations);ArrayResize(continuations,count+1);continuations[count]=c;continue;
    }
    if(ArraySize(p)!=19||p[0]!="R"){valid=false;break;}
    BEXRecord r;r.id=p[1];r.clock=(datetime)StringToInteger(p[2]);r.code=(int)StringToInteger(p[3]);r.start=(datetime)StringToInteger(p[4]);r.known=(datetime)StringToInteger(p[5]);r.low0=StringToDouble(p[6]);r.high0=StringToDouble(p[7]);r.low=StringToDouble(p[8]);r.high=StringToDouble(p[9]);r.label=p[10];r.detail=p[11];r.context=p[12];r.pa=p[13];r.follow=p[14];r.fixed=p[15];r.matches=(int)StringToInteger(p[16]);r.kind=p[17];
    r.side=(int)StringToInteger(p[18]);int n=ArraySize(records);ArrayResize(records,n+1);records[n]=r;
   }
   if(valid&&ended&&ArraySize(records)==expected){ArrayResize(bex_continuations,ArraySize(continuations));for(int ci=0;ci<ArraySize(continuations);ci++)bex_continuations[ci]=continuations[ci];ArrayResize(bex_records,expected);int focus=-1;for(int j=0;j<expected;j++){bex_records[j]=records[j];if(records[j].id!="__CURRENT"&&(records[j].code==1||records[j].code==2||records[j].code==8)&&(focus<0||records[j].clock>records[focus].clock))focus=j;}if(bex_selected==""&&focus>=0)bex_selected=records[focus].id;bex_loaded=bex_token;bex_stage=h[7];bex_elapsed=(int)StringToInteger(h[4]);bex_hidden=false;bex_note="已核对至 "+TimeToString(bex_cutoff,TIME_DATE|TIME_MINUTES)+"；耗时 "+DoubleToString(bex_elapsed/1000.0,1)+" 秒；历史观察，非交易许可";if(bex_stage=="core")bex_note="范围约束已核对；原研究全模型旁证计算中（不采用旧输入）";FileClose(f);BEXDraw();return;}
  }
  FileClose(f);
 }
 int progress=FileOpen(BEXRoot()+"progress_"+bex_scope+".txt",FILE_READ|FILE_TXT|FILE_ANSI,0,CP_UTF8);
 if(progress!=INVALID_HANDLE){string p[];StringSplit(FileReadString(progress),'\t',p);FileClose(progress);if(ArraySize(p)>=2&&p[0]==bex_token)bex_note="计算中 "+p[1];}
 if(GetTickCount64()-bex_submitted>90000)bex_note+="；服务未完成，请检查独立worker（不采用旧结论）";
 BEXPanel();
}
#endif
