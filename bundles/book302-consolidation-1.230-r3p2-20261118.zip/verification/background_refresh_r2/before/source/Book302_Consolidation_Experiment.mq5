#define BKN_GUIDED_BUILD_ID "616db1295220f3015ec83623e2ff213339cebc713a86774cfc1b4eeb6e592675"
#property copyright "Machine1 Book native realtime"
#property version "1.230"
#property indicator_chart_window
#property indicator_plots 0

// Production native Book entry. It reads only the current chart's native
// OHLC through CopyRates and builds an in-memory scene. It never reads the
// Python service, saved scenes, CASE snapshots, DLLs, or order APIs.
#include "book_native/BookNativeChart.mqh"
#include "book_native/BookGuidedFrame.mqh"
#include "book_native/BookGuidedMemoryCache.mqh"
#include "book_native/BookGuidedMultiPeriodZigzag.mqh"
#include "BookExperimentGuard.mqh"

input group "波段归属"
// Same-period native ZigZag reduction, not an author degree label.
input int GeometryWaveReduction=1; // 0原始 / 1完整波段 / 2较大 / 3更大
input int GeometryDetailLevels=1; // 同时显示内部独立波段：0关闭 / 1下一层 / 最多3层
input group "完整来源历史诊断（原生服务器时间）"
input datetime InspectConnectedSourceA=0; // 0关闭；需同时提供来源A和B
input datetime InspectConnectedSourceB=0;
input group "原生历史计算与刷新"
input int HistoricalContextBars=512;
// 0 means use all bars available to the terminal for the requested viewport.
// A positive value is an explicit memory cap, never an implicit history limit.
input int MaximumNativeWindowBars=0;
input int ViewportDebounceMs=350;
input int RefreshIntervalMs=150;
input int CalculationWorkBudgetMs=40;
input int InitialCalculationBudgetMs=200;
input int MemoryViewportCacheSlots=4;
input int DeepHistoryRevisionMs=3000;
input int PreviewIntervalMs=1000;
// Bounded local diagnostic output only; never used as an analysis input.
input bool KeepLastTwoAuditFrames=true;

BKNGuideFrameBuilder book;
BKNChartView view;
BKNGuideMemoryCache memory;
string requested_view="",applied_input="",running_view="",running_input="",applied_view="";
string source_window_note="";
string source_inspection_status="";
ulong view_changed=0,history_revision_checked=0;
bool request_pending=true,calculating=false,initial_view_pending=true;
bool capture_pending=false;
ulong calculation_started=0,last_preview=0;
int preview_count=0,profile_stage=0;
MqlRates running_rows[];
datetime running_cutoff=0;
int audit_slot=0;
ulong calculation_completed_ms=0;
datetime observed_head=0,observed_closed=0;
double observed_open=0,observed_high=0,observed_low=0,observed_close=0;
string applied_symbol="";
ENUM_TIMEFRAMES applied_period=PERIOD_CURRENT;
union BKNInputDouble {double number;ulong bits;};

string ViewportIdentity(){
 int first=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR),visible=(int)ChartGetInteger(0,CHART_VISIBLE_BARS);
 int right=(int)MathMax(0,first-visible+1);
 datetime left_time=iTime(_Symbol,_Period,first),right_time=right>0?iTime(_Symbol,_Period,right):0;
 return _Symbol+"|"+IntegerToString((long)_Period)+"|"+
  (right>0?IntegerToString((long)left_time)+"|"+IntegerToString((long)right_time):"LIVE")+"|"+IntegerToString(visible);
}
string InputIdentity(const MqlRates &rows[],string provider,int seconds,datetime cutoff){
 string text="book_guided_dev_0302|"+BKN_GUIDED_BUILD_ID+"|"+provider+"|"+_Symbol+"|"+IntegerToString(seconds)+"|"+IntegerToString((long)cutoff);
 for(int i=0;i<ArraySize(rows);i++){
  BKNInputDouble o,h,l,c;o.number=rows[i].open;h.number=rows[i].high;l.number=rows[i].low;c.number=rows[i].close;
  text+="|"+IntegerToString((long)rows[i].time)+","+StringFormat("%016I64x",o.bits)+","+StringFormat("%016I64x",h.bits)+","+
   StringFormat("%016I64x",l.bits)+","+StringFormat("%016I64x",c.bits)+","+IntegerToString(rows[i].tick_volume)+","+
   IntegerToString(rows[i].real_volume)+","+IntegerToString(rows[i].spread);
 }
 return BKNHash(text);
}
// Return the number of native bars ending at the viewport's right edge.
// Source A/B are exact native shifts, not nearest-bar substitutions. A source
// later than that edge is never pulled into an earlier historical frame.
int BookSourceInspectionWindow(int wanted,int right,int available,int maximum,
                               int source_a_shift,int source_b_shift,int context,string &note){
 note="";
 if(source_a_shift<0||source_b_shift<0){note="来源端点不在已加载原生历史";return wanted;}
 if(source_b_shift<right||source_b_shift==0){note="来源B尚不在当前视窗已收盘范围";return wanted;}
 if(source_a_shift<source_b_shift){note="来源原生时间顺序无效";return wanted;}
 long required=(long)source_a_shift-(long)right+1+(long)MathMax(0,context);
 long limit=(long)MathMin(maximum,MathMax(0,available-right));
 if(required>limit){note="来源背景超过可用历史或窗口上限";required=limit;}
 if(required>wanted)wanted=(int)required;
 return wanted;
}
bool CaptureNative(MqlRates &out[],datetime &cutoff,string &identity,string &status){
 ArrayResize(out,0);capture_pending=false;source_window_note="";int seconds=PeriodSeconds(_Period);
 if(seconds<=0){status="当前图表周期没有原生秒数";return false;}
 long synchronized=0;
 if(!SeriesInfoInteger(_Symbol,_Period,SERIES_SYNCHRONIZED,synchronized)||synchronized==0){
  MqlRates warm[];CopyRates(_Symbol,_Period,0,2,warm);capture_pending=true;status="MT5正在加载当前品种周期的原生行情";return false;
 }
 int first=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR),visible=(int)ChartGetInteger(0,CHART_VISIBLE_BARS);
 if(first<0||visible<=0){status="等待图表视窗尺寸";return false;}
 int right=(int)MathMax(0,first-visible+1),available=Bars(_Symbol,_Period);
 // Position zero may remain stale even while the symbol's tick stream is
 // advancing. Ask MT5 for the missing TIME range; never fabricate candles
 // from ticks or relabel the old tail as fresh.
 MqlTick latest;ZeroMemory(latest);datetime native_head=iTime(_Symbol,_Period,0);
 if(right==0&&SymbolInfoTick(_Symbol,latest)&&native_head>0&&latest.time-native_head>=seconds*2){
  MqlRates recent[];CopyRates(_Symbol,_Period,(datetime)(latest.time-seconds*4),latest.time,recent);
  // Still calculate the available genuine history. NativeDataLabel explicitly
  // marks its age; this is neither a fresh live receipt nor a saved snapshot.
 }
 int visible_window=first-right+1;
 int wanted=visible_window+(int)MathMax(0,HistoricalContextBars);
 int source_a_native_shift=-1;
 int maximum=MaximumNativeWindowBars<=0?MathMax(128,available-right):(int)MathMax(128,MaximumNativeWindowBars);
 // Never reject an otherwise valid historical position merely because the
 // default window was small. Only an explicit positive cap can reject it.
 if(visible_window>maximum){status="当前视图超过原生窗口上限；请增大MaximumNativeWindowBars";return false;}
 if(InspectConnectedSourceA>0){
  int a_shift=iBarShift(_Symbol,_Period,InspectConnectedSourceA,true),b_shift=iBarShift(_Symbol,_Period,InspectConnectedSourceB,true);
  source_a_native_shift=a_shift;
  // Ask MT5 to load the exact origin if missing; the next scheduled capture
  // will recheck availability. Keep the normal current frame usable meanwhile.
  if((a_shift<0||b_shift<0)&&InspectConnectedSourceB<=iTime(_Symbol,_Period,right)){
   MqlRates warm_source[];
   if(a_shift<0)CopyRates(_Symbol,_Period,InspectConnectedSourceA,1,warm_source);
   if(b_shift<0)CopyRates(_Symbol,_Period,InspectConnectedSourceB,1,warm_source);
  }
  wanted=BookSourceInspectionWindow(wanted,right,available,maximum,a_shift,b_shift,HistoricalContextBars,source_window_note);
 }
 wanted=(int)MathMin(maximum,MathMin(wanted,MathMax(0,available-right)));
 if(wanted<5){status="当前视窗的原生历史不足；等待MT5补齐";return false;}
 MqlRates raw[];ArraySetAsSeries(raw,false);int copied=CopyRates(_Symbol,_Period,right,wanted,raw);
 if(InspectConnectedSourceA>0&&source_window_note==""&&source_a_native_shift>=right&&source_a_native_shift-right>=copied)
  source_window_note="当前MT5复制范围尚未覆盖来源A";
 if(copied<visible_window){
  // A far-left viewport may be outside the terminal's current history cache.
  // Request that exact ordinal range so MT5 can extend the series instead of
  // repeatedly retrying only from bar zero.
  MqlRates warm[];int warm_count=(int)MathMax(visible_window,MathMin(2048,wanted+HistoricalContextBars));
  CopyRates(_Symbol,_Period,right,MathMax(5,warm_count),warm);
  capture_pending=true;status="当前视窗历史正在按位置加载 "+IntegerToString((int)MathMax(0,copied))+" / "+IntegerToString(visible_window);return false;
 }
 datetime live_open=iTime(_Symbol,_Period,0),now=TimeCurrent();
 datetime ceiling=raw[copied-1].time+seconds;if(ceiling<=0)ceiling=now;
 datetime previous=0;int accepted=0;ArrayResize(out,copied);
 for(int i=0;i<copied;i++){
  // The forming bar is never an analysis input. Historical viewports do not
  // contain live_open, so they remain fully usable; the current viewport
  // waits for the next closed bar instead of repainting on every tick.
  if(live_open>0&&raw[i].time>=live_open)continue;
  if(live_open<=0&&raw[i].time+seconds>now)continue;
  if(raw[i].time+seconds>ceiling)continue;
  if(raw[i].time<=previous||!BKNValidRate(raw[i])){status="当前原生行情次序或OHLC无效，等待MT5重新加载";return false;}
  out[accepted++]=raw[i];previous=raw[i].time;
 }
 ArrayResize(out,accepted);if(ArraySize(out)<5){status="当前视窗已收盘历史不足";return false;}
 cutoff=out[ArraySize(out)-1].time+seconds;
 string provider=AccountInfoString(ACCOUNT_SERVER);if(provider=="")provider="native_custom:"+_Symbol;
 identity=InputIdentity(out,provider,seconds,cutoff);status="";return identity!="";
}
void QueueView(bool changed){
 request_pending=true;
 if(changed){
  view_changed=GetTickCount64();
  // Keep the last completed native frame visible while the new chart
  // viewport/period is calculated. Clearing here made every scroll or
  // timeframe switch look like a failed load for several timer slices.
  if(!initial_view_pending)view.Status("当前图表视窗原生重算中 · 保留上一帧");
 }
}
string NativeDataLabel(datetime cutoff){
 string result="已算至 "+TimeToString(cutoff,TIME_DATE|TIME_MINUTES)+" · "+EnumToString(_Period);
 MqlTick tick;ZeroMemory(tick);datetime bar=iTime(_Symbol,_Period,0);
 if(SymbolInfoTick(_Symbol,tick)&&bar>0&&tick.time-bar>=PeriodSeconds(_Period)*2)
  result+=" · MT5 K线同步落后 "+IntegerToString((long)(tick.time-bar)/60)+" 分钟";
 return result;
}
void SaveNativeAudit(string audit_reason="completed_frame"){
 BEXSubmit(running_rows,book.shapes,running_input,running_view,running_cutoff);
 if(!KeepLastTwoAuditFrames||IsStopped())return;
 FolderCreate("Book302Experiment1230\\NativeBookAudit");
 string base="Book302Experiment1230\\NativeBookAudit\\"+IntegerToString(ChartID())+"_"+IntegerToString(audit_slot%2);audit_slot++;
 int f=FileOpen(base+".rates.tsv",FILE_WRITE|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);
 if(f==INVALID_HANDLE)return;
 FileWrite(f,"time","open","high","low","close","tick_volume","real_volume","spread");
 for(int i=0;i<ArraySize(running_rows);i++)FileWrite(f,(long)running_rows[i].time,StringFormat("%.17g",running_rows[i].open),StringFormat("%.17g",running_rows[i].high),StringFormat("%.17g",running_rows[i].low),StringFormat("%.17g",running_rows[i].close),running_rows[i].tick_volume,running_rows[i].real_volume,running_rows[i].spread);
 FileClose(f);
 int errors=view.ExportNativeCoordinates(base+".native.tsv");
 f=FileOpen(base+".coverage.tsv",FILE_WRITE|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);
 if(f!=INVALID_HANDLE){
  FileWrite(f,"owner_a","owner_b","known","geometry_count","channel_source","channel_shift","independent_turning","unused_recovery","omission_reason","channel_lines","channel_points","source_reason","shift_reason","turning_reason","unused_recovery_reason","independent_extension","extension_reason");
  for(int k=0;k<ArraySize(book.coverage);k++){
   BKNGeometryCoverage item=book.coverage[k];
   FileWrite(f,(long)item.a,(long)item.b,(long)item.known,item.count,item.outer,item.channel,item.turning,item.recovery,item.reason,item.channel_lines,item.channel_points,item.outer_reason,item.channel_reason,item.turning_reason,item.recovery_reason,item.extension,item.extension_reason);
  }
  FileClose(f);
 }
 f=FileOpen(base+".receipt.tsv",FILE_WRITE|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);if(f==INVALID_HANDLE)return;
 MqlTick tick;ZeroMemory(tick);SymbolInfoTick(_Symbol,tick);
 FileWrite(f,"provider","symbol","period_seconds","chart","engine","input_hash","closed_cutoff","viewport","quote_time","native_bar_open","shapes","coordinate_errors","elapsed_ms","symbol_tick_time","symbol_bid","symbol_ask","audit_reason","audit_local_time","build_id");
  FileWrite(f,AccountInfoString(ACCOUNT_SERVER),_Symbol,PeriodSeconds(_Period),ChartID(),"book_guided_dev_0302",running_input,(long)running_cutoff,running_view,(long)TimeCurrent(),(long)iTime(_Symbol,_Period,0),ArraySize(book.shapes),errors,calculation_completed_ms,(long)tick.time,DoubleToString(tick.bid,_Digits),DoubleToString(tick.ask,_Digits),audit_reason,(long)TimeLocal(),BKN_GUIDED_BUILD_ID);
 FileClose(f);
 int width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS);
 if(width>0&&height>0){ChartRedraw(0);ChartScreenShot(0,base+".png",width,height,ALIGN_LEFT);}
}
int OnInit(){
 if(GeometryWaveReduction<0||GeometryWaveReduction>3||GeometryDetailLevels<0||GeometryDetailLevels>3||MaximumNativeWindowBars<0||HistoricalContextBars<0)return INIT_PARAMETERS_INCORRECT;
 if((InspectConnectedSourceA==0)!=(InspectConnectedSourceB==0)||
    (InspectConnectedSourceA>0&&InspectConnectedSourceB<=InspectConnectedSourceA))return INIT_PARAMETERS_INCORRECT;
 if(!BKNMTFInit())return INIT_PARAMETERS_INCORRECT;
 calculating=false;request_pending=true;applied_input="";running_input="";running_view="";observed_head=0;observed_closed=0;preview_count=0;applied_view="";
 source_inspection_status="";
 IndicatorSetString(INDICATOR_SHORTNAME,"Book 1.302 Independent Consolidation Experiment 1.230");
  view.Init(true);BEXInit();PrintFormat("BOOK_NATIVE_INIT version=1.302 build=%s chart=%I64d symbol=%s period=%s",BKN_GUIDED_BUILD_ID,ChartID(),_Symbol,EnumToString(_Period));view.Status("等待当前图表原生行情；Book实时计算中");requested_view=ViewportIdentity();view_changed=GetTickCount64();initial_view_pending=true;
 applied_symbol=_Symbol;applied_period=_Period;
 if(!EventSetMillisecondTimer((int)MathMax(100,MathMin(5000,RefreshIntervalMs))))return INIT_FAILED;
 return INIT_SUCCEEDED;
}
void OnDeinit(const int reason){BEXDestroy();EventKillTimer();BKNMTFClear();book.Cancel();memory.Clear();view.Destroy();}
int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[]){
 if(rates_total<2)return rates_total;bool series=ArrayGetAsSeries(time);int head=series?0:rates_total-1,closed=series?1:rates_total-2;
 if(prev_calculated==0||time[head]!=observed_head||time[closed]!=observed_closed||open[closed]!=observed_open||high[closed]!=observed_high||low[closed]!=observed_low||close[closed]!=observed_close){
  observed_head=time[head];observed_closed=time[closed];observed_open=open[closed];observed_high=high[closed];observed_low=low[closed];observed_close=close[closed];QueueView(false);
 }
 return rates_total;
}
void AdvanceNative(uint budget){
  ulong slice_start=GetTickCount64();
  bool done=book.Step(budget);
  if(book.Stage()!=profile_stage){profile_stage=book.Stage();PrintFormat("BOOK_NATIVE_STAGE chart=%I64d period=%s stage=%d elapsed_ms=%I64u slice_ms=%I64u shapes=%d",ChartID(),EnumToString(_Period),profile_stage,GetTickCount64()-calculation_started,GetTickCount64()-slice_start,ArraySize(book.shapes));}
  // Publish finished records from the same frozen input/view, never cache a
  // partial frame or call it complete. All historical clocks still run.
  if(!done&&!book.Failed()&&(applied_view!=running_view||applied_input=="")&&running_view==requested_view&&ArraySize(book.shapes)>preview_count&&GetTickCount64()-last_preview>=(ulong)MathMax(250,PreviewIntervalMs)){
    book.StampCurrentContracts();
   view.Apply(book.shapes);preview_count=ArraySize(book.shapes);last_preview=GetTickCount64();
   PrintFormat("BOOK_NATIVE_PREVIEW chart=%I64d period=%s shapes=%d elapsed_ms=%I64u",ChartID(),EnumToString(_Period),preview_count,last_preview-calculation_started);
  }
  view.Status(book.Progress()+(preview_count>0?" · 已显示 "+IntegerToString(preview_count)+" 项，继续计算":""));
  if(book.Failed()){calculating=false;request_pending=true;applied_input="";view.Clear();view.Status("原生计算未完成："+book.Failure());return;}
  if(done){calculation_completed_ms=GetTickCount64()-calculation_started;calculating=false;if(running_view==requested_view){
   string inspection="";
   if(InspectConnectedSourceA>0){string why;if(book.AppendConnectedSourceInspection(InspectConnectedSourceA,InspectConnectedSourceB,why))inspection=" · 完整来源历史诊断";else inspection=" · 来源诊断不可用: "+why+(source_window_note!=""?" · "+source_window_note:"");}
   else memory.Put(running_input,book.shapes,book.coverage,MemoryViewportCacheSlots);
   source_inspection_status=inspection;
   view.Apply(book.shapes);applied_input=running_input;applied_view=running_view;PrintFormat("BOOK_NATIVE_COMMIT version=1.302 chart=%I64d symbol=%s period=%s input=%s shapes=%d elapsed_ms=%I64u cutoff=%I64d quote=%I64d",ChartID(),_Symbol,EnumToString(_Period),applied_input,ArraySize(book.shapes),GetTickCount64()-calculation_started,(long)running_cutoff,(long)TimeCurrent());view.Status(NativeDataLabel(running_cutoff)+inspection);SaveNativeAudit();}else request_pending=true;}
  return;
 
}
void OnTimer(){
 BEXPoll(calculating||request_pending,ViewportIdentity());
 if(IsStopped())return;BKNMTFRender();string now_view=ViewportIdentity();
 bool identity_changed=(applied_symbol!=_Symbol||applied_period!=_Period);
 if(now_view!=requested_view){
  requested_view=now_view;
  if(identity_changed&&!initial_view_pending){
   // A period/symbol switch changes the meaning of every native bar. Clear
   // only this case; ordinary history scrolling keeps the previous frame
   // visible until its replacement is complete.
   if(calculating){book.Cancel();calculating=false;}
   view.Clear();applied_input="";
  }
  applied_symbol=_Symbol;applied_period=_Period;QueueView(true);
 }
 if(GetTickCount64()-history_revision_checked>=(ulong)MathMax(1000,DeepHistoryRevisionMs)){history_revision_checked=GetTickCount64();QueueView(false);}
 if(initial_view_pending){if(calculating){book.Cancel();calculating=false;}view.Clear();applied_input="";initial_view_pending=false;}
 // A stable new viewport supersedes an expensive old history request.
 // New ticks keep the same identity and never cancel an in-flight job.
 if(calculating&&running_view!=requested_view&&GetTickCount64()-view_changed>=(ulong)MathMax(0,ViewportDebounceMs)){
  book.Cancel();calculating=false;request_pending=true;preview_count=0;
  view.Status("视窗已变化，正在计算当前位置");
 }
 if(calculating){AdvanceNative((uint)MathMax(1,MathMin(250,CalculationWorkBudgetMs)));return;}
 if(!request_pending||GetTickCount64()-view_changed<(ulong)MathMax(0,ViewportDebounceMs))return;
 MqlRates rows[];datetime cutoff;string identity,status;if(!CaptureNative(rows,cutoff,identity,status)){if(!capture_pending){applied_input="";view.Clear();}view.Status(status);return;}
 if(identity==applied_input){request_pending=false;view.Status(NativeDataLabel(cutoff)+source_inspection_status);return;}
 BKNShape cached[];if(InspectConnectedSourceA==0&&memory.Get(identity,cached,book.coverage)){
  ArrayResize(book.shapes,ArraySize(cached));for(int i=0;i<ArraySize(cached);i++)book.shapes[i]=cached[i];
  ArrayResize(running_rows,ArraySize(rows));ArrayCopy(running_rows,rows);running_cutoff=cutoff;
  running_view=requested_view;running_input=identity;calculation_started=GetTickCount64();
  view.Apply(cached);calculation_completed_ms=GetTickCount64()-calculation_started;applied_input=identity;applied_view=requested_view;request_pending=false;
  view.Status(NativeDataLabel(cutoff)+" · 同输入内存复用");SaveNativeAudit();return;
 }
 string provider=AccountInfoString(ACCOUNT_SERVER);if(provider=="")provider="native_custom:"+_Symbol;
 if(!book.Begin(rows,PeriodSeconds(_Period),cutoff,provider,_Symbol,_Digits,identity,GeometryWaveReduction,GeometryDetailLevels)){applied_input="";view.Clear();view.Status("原生输入尚未就绪："+book.Failure());return;}
 ArrayResize(running_rows,ArraySize(rows));ArrayCopy(running_rows,rows);running_cutoff=cutoff;
 request_pending=false;calculating=true;running_view=requested_view;running_input=identity;calculation_started=GetTickCount64();last_preview=0;preview_count=0;profile_stage=0;view.Status(book.Progress());
 // Compute the first slice now, without a second timer dispatch delay.
 AdvanceNative((uint)MathMax(1,MathMin(250,InitialCalculationBudgetMs)));
}
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam){
 if(id==CHARTEVENT_OBJECT_CLICK&&BEXClick(sparam))return;
 if(id==CHARTEVENT_OBJECT_CLICK&&BKNMTFClick(sparam))return;
 if(view.Event(id,sparam)){
  BEXNativeViewEvent(sparam);
  if(!calculating&&applied_input!=""&&running_input==applied_input&&running_view==requested_view)SaveNativeAudit("chart_action");
  return;
 }
 if(id==CHARTEVENT_CHART_CHANGE){
  string actual=ViewportIdentity();
  if(actual!=requested_view){
   bool identity_changed=(applied_symbol!=_Symbol||applied_period!=_Period);
   if(identity_changed&&!initial_view_pending){
    if(calculating){book.Cancel();calculating=false;}
    view.Clear();applied_input="";
   }
   requested_view=actual;applied_symbol=_Symbol;applied_period=_Period;QueueView(true);
   // Price/time objects move natively, but pixel-based captions do not. Remap
   // them immediately to this viewport while its native calculation queues.
   view.RenderIfChanged();
  }else view.RenderIfChanged();
 }
}


