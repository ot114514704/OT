from pathlib import Path
import json,hashlib,zipfile,sys
B=Path(__file__).parent;V=B/'verification/outer_handoff_r3'
full_check='--full-check' in sys.argv
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Ran 54 tests' in (V/'tests.log').read_text('utf8') and (V/'tests.log').read_text('utf8').rstrip().endswith('OK')
assert 'Ran 11 tests' in (V/'chain_tests.log').read_text('utf8') and (V/'chain_tests.log').read_text('utf8').rstrip().endswith('OK')
case=json.loads((V/'captured_case.json').read_text('utf8'));assert case['passed'] and case['original_continuation_exact']
original=json.loads((B/'FUSION_PROVENANCE.json').read_text('utf8'))
assert all(sha(Path(p))==h for p,h in original['production_files_unchanged'].items())
assert all(sha(B/'source/book_native'/p)==h for p,h in original['book_headers'].items())
for row in json.loads((B/'verification/compile.json').read_text('utf8')):
 assert sha((B/row['file']).with_suffix('.ex5'))==row['sha256']
identity=json.loads((B/'runtime/bridge/worker_identity.json').read_text('utf8'))
meta={'revision':'1.230-r3','native_visual_verified':False,'reload_acceptance_pending':True,
 'running_worker_recorded_sha256':identity['script_sha256'],'prepared_worker_sha256':sha(B/'worker.py'),
 'book_core_unchanged':41,'production_files_unchanged':70,
 'checks':['54-test pre-chain regression passed','11 final chain/prefix/gap/mirror/protocol checks passed','one captured native-input case: original continuation exact, three causal outer handoffs','five compiled artifacts checked against zero-error/zero-warning receipt'],
 'limits':['Original late-known/retrospective Book events remain ineligible for original-time continuation.','Outer ranges are candidates unless independently confirmed; handoff is not breakout/reversal confirmation.','Fresh native reload, all controls, final screenshots and observed full background-data retry remain pending.','Historical granularity/coverage and whole-model delay remain unresolved.'],
 'uploaded_to_OT':False,'old_candidate_zip_retained':True}
if full_check:
 full=json.loads((B/'verification/outer_full_request_r3/acceptance.json').read_text('utf8'))
 assert full['passed'] and full['original_fields_exact']
 meta['full_saved_chart']={k:full[k] for k in ('results_compared','new_outer_segments','seconds')}
 meta['full_saved_chart']['outer_chains']=len(full['new_outer_chains'])
 meta['checks'].append('Full saved native chart: all 106 original results exact; 9 outer chains / 31 segments checked for frozen containment, native equation and gap separation')
 meta['native_render_protocol']='r3 request-token salt, per-row request/loaded token and guard revision, plus empty-frame render_state receipt'
(B/'REVISION_R3.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),'utf8')
readme='''Book＋盘整融合实验 1.230-r3 — 盘整内断头处理候选

本次用户确认的问题：Book 通道或拐点线在盘整内提前结束。
本版保留 Book 原线及内层续观终点；当内层退出、但连续两根已收盘实体仍处于事前已知且严格包含内层的外层盘整时，沿原方程新增蓝色点线“外层续观”。按每一层退出时刻逐层接续；每段分别绑定自己的冻结范围。不会把多个候选合并为更大箱体，不读取未来范围来挑最长线，也不跨数据缺口画出未知路径。
10月29日保存的原生输入案例：原续观字节级结果不变，新观察经三层外部范围继续至视窗末端。已有回归通过，最终11项接续/因果/镜像/缺口/协议检查通过。这是候选验证，不代表全部断头已经解决。

同时修复：原生背景 M15 补齐时，即使 H1 主图蜡烛不变，也会生成新请求；综合模型缺数据时标记未完成。保留历史图形，但不将它们当成本帧确认。

你在波浪理论项目提供的 C:/Users/qkn/Downloads/forex-ai-source-main.zip 已读取。包内已编译 Book 1.302 的41个核心文件与本版完全一致；Pending_Source 仅有 ScopePhases 差异，没有匹配 EX5，未冒充成已验收升级。另一设备的 Unified 1.071/显示1.074 是不同分支，已保存来源核对记录，未替换当前原图布局。

状态：代码与编译完成，原生重载和新增蓝线实图验收尚未完成。前次 Escape 中断后，本轮未控制 MT5 窗口；后台旧实例可能仍使用旧代码。不要把 verification/native_initial 的旧截图当作 r3 新线验收。
本版与原稳定版分离；MT5 1230 路径仍指向本目录。要完成安装验收，需要停止并重启本版 Worker、重载本版独立图表后检查新请求、回包、原生对象与开关。未设置系统自启。

启动入口仍为 Start-ExperimentWorker.ps1（D盘 Python），开图脚本为 Book302Research1230/Book302_Open_Experiment，同图保留四个指标按钮。源码中的版本号沿用1.230，本轮精确文件以 REVISION_R3.json 和 MANIFEST_R3.json 为准。
融合前稳定版已上传 OT： https://github.com/ot114514704/OT/commit/1102ca44c5131da19d02e20f3632046493da87b2
此前有限原生候选 ZIP 保留不变。本 r3 修复包只在 D 盘，未上传 OT。
'''
if full_check:
 readme+='\n补充整图验证：同一份已保存 H1 原生请求中，106条原结果的判断、边界及原续观完全一致；9组新增外层接续、31段通过冻结范围逐层包含、原线方程和缺口不跨接检查。新原生绘图回执包含请求标识、载入标识和r3修订号，空绘图也有状态回执。当前实盘运行记录仍指向旧worker和旧请求规则；这些文件检查不等于r3已经加载。\n'
(B/'README_R3.txt').write_text(readme,'utf8')
files=set()
for root in ('source','companions','native_scripts','templates','research_snapshot','native_companions_original','testdata','verification','examples','provenance'):
 for p in (B/root).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo','.zip'):files.add(p)
files.update(p for p in B.glob('*.py'))
files.update(p for p in B.glob('*.ps1'))
for n in ('all_example_candidates.json','FUSION_PROVENANCE.json','PROVENANCE.json','REVISION_R3.json','README_R3.txt'):files.add(B/n)
manifest=[{'path':p.relative_to(B).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
mp=B/'MANIFEST_R3.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),'utf8')
out=B.parent/('Book302_盘整融合实验_1.230-r3_外层续观候选_20261117'+('_整图验证' if full_check else '')+'.zip')
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files|{mp}):z.write(p,p.relative_to(B).as_posix())
with zipfile.ZipFile(out) as z:
 for r in manifest:assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256'],r['path']
receipt={'path':str(out),'bytes':out.stat().st_size,'sha256':sha(out),'files_verified':len(manifest),'native_verified':False,'uploaded':False}
(B/('PACKAGE_R3_FULL.json' if full_check else 'PACKAGE_R3.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8');print(json.dumps(receipt,ensure_ascii=False))
