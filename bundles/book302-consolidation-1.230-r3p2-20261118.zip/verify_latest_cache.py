"""Check production cache adaptation on preserved real native prices."""
from pathlib import Path
import importlib.util,json,time
from dataclasses import replace
from worker import BASE
from research_cases import load_bars
from ict_trader.core import Bar
from ict_trader.dense_pauses import observe_dense_pauses,DenseWindowMemo
spec=importlib.util.spec_from_file_location('ict_trader._previous_dense',BASE/'verification/pre_latest_cache/dense_pauses.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
original=load_bars(BASE/'testdata/native_history_H1.tsv')[-220:]
bars=[Bar(b.time,b.open,b.high,b.low,b.close,b.spread,b.seconds) for b in original]
memo=DenseWindowMemo();rows=[];began=time.monotonic()
for label,window in [('initial',bars[:160]),('append',bars[:180]),('truncate',bars[:140]),('revised',bars[:139]+[replace(bars[139],spread=bars[139].spread+.01)])]:
    clock=window[-1].closed_at
    before=old.observe_dense_pauses(window,clock)
    direct=observe_dense_pauses(window,clock)
    cached=memo.observe(window,clock)
    assert before==direct==cached,label
    rows.append(dict(case=label,count=len(cached),metadata=memo.metadata()))
    if label=='append':assert memo.last_reused>0
    if label in ('truncate','revised'):assert memo.last_reused==0
receipt=dict(passed=True,seconds=time.monotonic()-began,cases=rows)
(BASE/'verification/latest_cache_equivalence.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
print('CACHE_EQUIVALENCE_PASS',round(receipt['seconds'],2),flush=True)
