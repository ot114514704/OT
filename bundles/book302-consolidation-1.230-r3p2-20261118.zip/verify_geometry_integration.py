"""Validate explicit cache injection against preserved complete native results."""
from pathlib import Path
import hashlib,json,time
import worker
from ict_trader import long_geometry,native_triangles
from geometry_window_memo import GeometryWindowMemo

B=Path(__file__).parent;V=B/'verification/performance_r3_20261118'
req=worker.parse_request((B/'verification/native_r3/final/request_102923304041429_3600.tsv').read_text('utf-8-sig'))
expected=json.loads((V/'baseline_results.json').read_text('utf8'))
worker.recognize.cache_clear()
started=time.perf_counter()
actual=worker.solve(req,lambda msg:print(msg,flush=True))
assert actual==expected
seconds=time.perf_counter()-started
sources=['worker.py','geometry_window_memo.py','research_snapshot/ict_trader/long_geometry.py','research_snapshot/ict_trader/native_triangles.py']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
provenance=json.loads((B/'FUSION_PROVENANCE.json').read_text('utf8'))
assert all(sha(Path(p))==h for p,h in provenance['production_files_unchanged'].items())
assert all(sha(B/'source/book_native'/p)==h for p,h in provenance['book_headers'].items())
report={'passed':True,'results':len(actual),'full_output_exact':True,'seconds':seconds,
        'memo':worker._geometry_candidates.metadata(),'production_files_unchanged':70,'book_headers_unchanged':41,
        'source_sha256':{p:sha(B/p) for p in sources},'live_worker_restarted':False,
        'scope':'Explicit callback integration; no process-global monkeypatch in the worker. All fields equal to the profiled pre-change native request. Timing is offline.'}
(V/'integration_acceptance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(report),flush=True)
