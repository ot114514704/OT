"""Experiment-only observation after Book's original geometric endpoint.

Freeze a fixed envelope from ranges ALREADY KNOWN at the crossing. Neither
later range fits nor three-push events may relabel that original observation.
This envelope lifecycle is experimental, not the research engine's breakout.
"""
import math


def observe(event, result, prefix_contexts, bars, cutoff):
    if result['code'] not in (1, 2, 8) or event.get('family') not in ('GUIDED_TURNING', 'GUIDED_SHIFT'):
        return None
    index = next((i for i, b in enumerate(bars) if int(b.closed_at.timestamp()) == event['clock']), None)
    if index is None or event['known'] > int(bars[index].time.timestamp()):
        return None
    origin = bars[index]
    eligible = [c for c in prefix_contexts if c['active'] and c['known'] <= int(origin.time.timestamp())
                and c['end'] >= event['clock'] and c['low'] <= origin.close <= c['high']
                and '数据间隔' not in c['status'] and '交会' not in c['status']]
    if not eligible:
        return None
    # Observe the range actually associated with this crossing. Unrelated
    # outer candidates constrain direction in classify(), but must not widen
    # an old line's display lifetime to the union of every detected range.
    chosen=result.get('context')
    if not chosen or chosen['id'] not in {c['id'] for c in eligible}:return None
    low = min(chosen['low'], chosen['fixed_low'])
    high = max(chosen['high'], chosen['fixed_high'])
    line, slope = event.get('line'), event.get('slope')
    if not all(isinstance(v, (int, float)) and math.isfinite(v) for v in (low, high, line, slope)) or low >= high:
        return None
    last, previous_side, streak = index, 0, 0
    state, label = 'observing', '盘整中继续观察；新方向未确认'
    segments=[];segment_start=index;segment_known=event['clock'];suspended=False;inside_streak=0;gaps=[]
    def segment(end,status,reason):
        return dict(start=int(bars[segment_start].time.timestamp()),end=int(bars[end].time.timestamp()),
                    price0=line+slope*(segment_start-index),price1=line+slope*(end-index),
                    known=segment_known,state=status,label=reason)
    for i in range(index + 1, len(bars)):
        b, previous = bars[i], bars[i - 1]
        if int(b.closed_at.timestamp()) > cutoff:
            break
        gap_seconds=(b.time-previous.closed_at).total_seconds()
        if b.seconds != origin.seconds or gap_seconds<0:
            state,label='invalid_bar','周期或时间顺序无效；停止观察'
            break
        if gap_seconds:
            if not suspended:segments.append(segment(last,'gap','时间间隔；此段到此为止，未补造缺柱路径'))
            suspended=True;inside_streak=0;previous_side=streak=0
            gaps.append(dict(after=int(previous.closed_at.timestamp()),before=int(b.time.timestamp()),known=int(b.closed_at.timestamp())))
            state,label='gap','时间间隔后待核验；需要两根连续收盘实体回到原固定范围'
            if gap_seconds>96*3600:
                state,label='long_gap','超过96小时间隔；原范围续观终止'
                break
        if not all(math.isfinite(x) for x in (b.open, b.high, b.low, b.close)) or not b.low <= min(b.open, b.close) <= max(b.open, b.close) <= b.high:
            state, label = 'invalid_bar', '无效行情中止；未推断突破'
            break
        if suspended:
            inside_streak=inside_streak+1 if low<=b.open<=high and low<=b.close<=high else 0
            side=1 if b.close>high else -1 if b.close<low else 0
            streak=streak+1 if side and side==previous_side else 1 if side else 0
            previous_side=side
            if streak>=2:
                state,label='gap_exit','间隔后两根同侧收盘已离开固定范围；不恢复旧续观'
                break
            if inside_streak<2:continue
            # Start only at the confirming closed bar, never retrospectively
            # connect the missing interval or the first unconfirmed return.
            suspended=False;segment_start=i;segment_known=int(b.closed_at.timestamp());last=i
            state,label='resumed','间隔后两根连续实体回到固定范围；仅从此收盘重新观察，缺口路径未知'
            previous_side=streak=0
            continue
        side = 1 if b.close > high else -1 if b.close < low else 0
        streak = streak + 1 if side and side == previous_side else 1 if side else 0
        previous_side, last = side, i
        if streak >= 2:
            state, label = 'fixed_envelope_exit', '连续两次同侧收盘越过实验固定边界；不等于趋势反转'
            break
        state='resumed' if gaps else 'observing'
        label = '单次越界待跟进；继续观察' if side else '缺口后分段续观；新方向未确认，缺口路径未知' if gaps else '盘整中继续观察；新方向未确认'
    if not suspended:segments.append(segment(last,state,label))
    return dict(id=event['id'],family=event['family'],start=int(origin.time.timestamp()),
                end=int(bars[last].time.timestamp()),known=event['clock'],through=int(bars[last].closed_at.timestamp()),
                price0=line,price1=line+slope*(last-index),slope=slope,low=low,high=high,
                state=state,label=label,range_ids=[chosen['id']],outer_range_ids=sorted(c['id'] for c in eligible if c['id']!=chosen['id']),segments=segments,gaps=gaps,
                policy='独立实验观察段；原Book终点不变；绑定穿线关联范围与形成极值；外层及三推仍另核方向；缺口后两根实体回区重新观察，不声称缺口内未突破')
