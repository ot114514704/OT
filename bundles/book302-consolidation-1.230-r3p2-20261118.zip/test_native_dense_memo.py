from pathlib import Path
from dataclasses import replace
from datetime import timedelta,timezone
from unittest.mock import patch
import unittest
import worker
from native_dense_memo import NativeDenseMemo
from ict_trader import dense_pauses,oscillation

request=worker.parse_request((Path(__file__).parent/'verification/native_r3/final/request_102923304041429_3600.tsv').read_text('utf-8-sig'))


class NativeDenseMemoTests(unittest.TestCase):
    def setUp(self):
        self.bars=request['bars'][-100:]
        self.memo=NativeDenseMemo(worker.NativeBar)

    def compare(self,bars,clock=None):
        clock=clock or bars[-1].closed_at
        direct=dense_pauses.observe_dense_pauses(bars,clock)
        cached=self.memo.observe(bars,clock)
        self.assertEqual(cached,direct)
        return cached

    def test_append_and_forming_bar_filter(self):
        self.compare(self.bars[:70]);self.compare(self.bars[:80])
        self.assertGreater(self.memo.last_reused,0)
        self.compare(self.bars[:81],self.bars[79].closed_at)
        self.assertEqual(len(self.memo.keys),80)

    def test_price_revision_truncation_and_session_reset(self):
        self.compare(self.bars[:80])
        changed=[replace(self.bars[0],high=self.bars[0].high+.1)]+self.bars[1:80]
        self.compare(changed);self.assertEqual(self.memo.last_reused,0)
        self.compare(changed[:70]);self.assertEqual(self.memo.last_reused,0)
        changed=[replace(changed[0],calendar_weekends=False)]+changed[1:70]
        self.compare(changed);self.assertEqual(self.memo.last_reused,0)

    def test_time_label_revision_is_not_price_only_reuse(self):
        self.compare(self.bars[:70])
        shifted=[replace(b,time=b.time.astimezone(timezone(timedelta(hours=2)))) for b in self.bars[:70]]
        self.compare(shifted);self.assertEqual(self.memo.last_reused,0)

    def test_oscillation_parameter_change_invalidates_metrics(self):
        self.compare(self.bars[:70])
        with patch.dict(oscillation.PARAMETERS,minimum_completed_legs=2):
            self.compare(self.bars[:70]);self.assertEqual(self.memo.last_reused,0)

    def test_result_mutation_cannot_change_later_scan(self):
        first=self.compare(self.bars)
        self.assertTrue(first)
        first[0]['low']=-999
        first[0]['gaps'].append({'corrupt':True})
        self.compare(self.bars)

    def test_failed_scan_keeps_previous_successful_state(self):
        self.compare(self.bars[:70])
        state=(self.memo.keys,self.memo.parameters,dict(self.memo.windows),self.memo.metadata())
        with patch.object(dense_pauses,'observe_dense_pauses',side_effect=RuntimeError('injected failure')):
            with self.assertRaises(RuntimeError):self.memo.observe(self.bars,self.bars[-1].closed_at)
        self.assertEqual(state,(self.memo.keys,self.memo.parameters,self.memo.windows,self.memo.metadata()))

    def test_eviction_and_unknown_subclass_fallback(self):
        self.memo=NativeDenseMemo(worker.NativeBar,window_limit=5,byte_limit=4096)
        self.compare(self.bars[:70]);self.compare(self.bars[:80])
        self.assertLessEqual(len(self.memo.windows),5)
        self.assertLessEqual(self.memo.retained_bytes,4096)
        class Unknown(worker.NativeBar):pass
        unknown=[Unknown(b.time,b.open,b.high,b.low,b.close,b.spread,b.seconds) for b in self.bars[:70]]
        self.compare(unknown);self.assertEqual(self.memo.windows,{})


if __name__=='__main__':unittest.main(verbosity=2)
