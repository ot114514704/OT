import unittest
from datetime import datetime, timezone, timedelta
from worker import NativeBar, geometry_value, normalize, encode_reply, classify
from continuation import observe

class ContinuationTests(unittest.TestCase):
 def setUp(self):
  self.start=datetime(2026,1,2,20,tzinfo=timezone.utc)
  self.bars=[self.bar(i,4005) for i in range(6)]
  self.clock=int(self.bars[0].closed_at.timestamp())
  self.event=dict(id='old',family='GUIDED_TURNING',clock=self.clock,known=self.clock-3600,line=4004,slope=-1,state='closed_bar_cross_observed')
  self.box=dict(id='outer',kind='dense',active=True,known=self.clock-3600,start=self.clock-7200,end=self.clock,
   low=4000,high=4010,fixed_low=4000,fixed_high=4010,low0=4000,high0=4010,status='横盘',shape='rectangle')
  self.result={'code':2,'context':self.box}
 def bar(self,i,close):
  return NativeBar(self.start+timedelta(hours=i),close,close+1,close-1,close,0,3600)
 def run_observation(self,bars=None,contexts=None,cutoff=None,event=None):
  bars=self.bars if bars is None else bars
  return observe(event or self.event,self.result,contexts or [self.box],bars,cutoff or int(bars[-1].closed_at.timestamp()))
 def test_sideways_keeps_original_equation(self):
  c=self.run_observation();self.assertEqual(c['state'],'observing');self.assertEqual(c['price1'],3999)
  self.assertEqual(c['end'],int(self.bars[-1].time.timestamp()));self.assertEqual(self.event['line'],4004)
 def test_wick_and_single_close_then_reclaim_do_not_end(self):
  bars=self.bars[:];bars[1]=self.bar(1,4011);bars[2]=NativeBar(bars[2].time,4005,4020,3990,4005,0,3600)
  self.assertEqual(self.run_observation(bars)['state'],'observing')
 def test_two_same_side_closes_end(self):
  bars=self.bars[:];bars[1]=self.bar(1,4011);bars[2]=self.bar(2,4012)
  c=self.run_observation(bars);self.assertEqual(c['state'],'fixed_envelope_exit');self.assertEqual(c['end'],int(bars[2].time.timestamp()))
 def test_opposite_side_closes_not_confirmed(self):
  bars=self.bars[:];bars[1]=self.bar(1,4011);bars[2]=self.bar(2,3999)
  self.assertEqual(self.run_observation(bars)['state'],'observing')
 def test_outer_range_does_not_artificially_widen_line_lifetime(self):
  contexts=[{**self.box,'id':'inner','high':4006,'fixed_high':4006},self.box]
  self.bars[1]=self.bar(1,4008);self.bars[2]=self.bar(2,4009)
  self.result['context']=contexts[0]
  c=self.run_observation(contexts=contexts);self.assertEqual(c['state'],'fixed_envelope_exit');self.assertEqual(c['high'],4006)
  self.assertEqual(c['outer_range_ids'],['outer'])
 def test_fixed_extrema_prevent_rail_drift_exit(self):
  box={**self.box,'high':4006,'fixed_high':4020}
  self.result['context']=box
  self.bars[1]=self.bar(1,4011);self.bars[2]=self.bar(2,4012)
  self.assertEqual(self.run_observation(contexts=[box])['state'],'observing')
 def test_later_range_not_added_retroactively(self):
  later={**self.box,'id':'future','known':self.clock+3600,'fixed_high':4500}
  c=self.run_observation(contexts=[self.box,later]);self.assertEqual(c['range_ids'],['outer']);self.assertEqual(c['high'],4010)
 def test_gap_stops_before_missing_bar(self):
  bars=self.bars[:2]+[self.bar(50,4005)]
  c=self.run_observation(bars);self.assertEqual(c['state'],'gap');self.assertEqual(c['end'],int(bars[1].time.timestamp()))
 def test_forming_and_future_not_read(self):
  cutoff=int(self.bars[2].closed_at.timestamp());a=self.run_observation(self.bars[:3],cutoff=cutoff)
  self.bars[3]=self.bar(3,9000);self.bars[4]=self.bar(4,9001)
  self.assertEqual(a,self.run_observation(cutoff=cutoff))
 def test_late_book_line_not_extended(self):
  self.assertIsNone(self.run_observation(event={**self.event,'known':self.clock}))
 def test_invalid_bar_stops(self):
  from types import SimpleNamespace
  b=self.bars[1];self.bars[1]=SimpleNamespace(time=b.time,closed_at=b.closed_at,seconds=b.seconds,open=4005,high=4000,low=3990,close=4005)
  c=self.run_observation();self.assertEqual(c['state'],'invalid_bar');self.assertEqual(c['end'],c['start'])
 def test_protocol_has_separate_continuation(self):
  r=classify(self.event,self.bars[:1],[self.box]);r['continuation']=self.run_observation()
  lines=encode_reply(dict(token='x',cutoff=self.clock),[r],0).splitlines()
  self.assertEqual(lines[0].split('\t')[1],'2');self.assertEqual(len(lines[2].split('\t')),12);self.assertTrue(lines[2].startswith('C\told\t'))
 def test_native_axis_weekend_not_elapsed_time(self):
  bars=[self.bar(0,4005),self.bar(1,4005),self.bar(50,4005),self.bar(51,4005)]
  points=[dict(time=bars[0].time.isoformat(),price=4000),dict(time=bars[2].time.isoformat(),price=4002)]
  self.assertEqual(geometry_value(points,bars[3].time,{'axis':'observed_native_bar_index'},bars),4003)
  self.assertNotEqual(geometry_value(points,bars[3].time,{},bars),4003)

if __name__=='__main__':unittest.main(verbosity=2)
