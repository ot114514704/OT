"""Exact geometry replay of the six user reference areas, no trading simulation."""
from pathlib import Path
from datetime import datetime,timezone
import json,time,hashlib
from unittest.mock import patch
import worker
from geometry_window_memo import GeometryWindowMemo
from ict_trader import long_geometry,native_triangles,oscillation,viewport_history

B=Path(__file__).parent
V=B/'verification/performance_r3_20261118'
REF=Path('D:/盘整研究资料/2026-11-14/new-chat/work/triangle_preference_20261116')
raw=json.loads(Path('D:/盘整研究资料/验收/历史空缺排查_20261114/H1_native_closed.json').read_text('utf8'))
cases=[]
for name in ('triangle_march','triangle_april','channel_triangle_august'):
    marks=json.loads((REF/(name+'.alignment.json')).read_text('utf8'))['annotations']
    start=min(datetime.fromisoformat(x['first_candle']).timestamp() for x in marks.values())-7*86400
    end=max(datetime.fromisoformat(x['last_closed']).timestamp() for x in marks.values())+86400
    bars=[worker.NativeBar(datetime.fromtimestamp(r['time'],timezone.utc),
          *(r[k] for k in ('open','high','low','close','spread')),3600)
          for r in raw if start<=r['time'] and r['time']+3600<=end]
    cases.append((name,bars))
old=viewport_history.parse_request((REF/'july_august_native.request.tsv').read_text('utf-8-sig'))['bars']
cases.append(('july_august_latest_two',[worker.NativeBar(b.time,b.open,b.high,b.low,b.close,b.spread,b.seconds) for b in old]))
original=long_geometry.candidate
memo=GeometryWindowMemo(original,worker.NativeBar,lambda:(long_geometry.PARAMETERS,oscillation.PARAMETERS))
reports=[]
for name,bars in cases:
    for size in (len(bars)//2,len(bars)):
        window=bars[:size];cutoff=window[-1].closed_at
        before=long_geometry.observe_long_geometry(window,cutoff,compact_scales=True)
        with patch.object(long_geometry,'candidate',memo),patch.object(native_triangles,'candidate',memo):
            after=long_geometry.observe_long_geometry(window,cutoff,compact_scales=True)
        assert after==before,(name,size)
        row={'case':name,'bars':size,'ranges':len(after['ranges']),'all_fields_exact':True,
             'result_sha256':hashlib.sha256(json.dumps(after,ensure_ascii=False,sort_keys=True).encode()).hexdigest()}
        reports.append(row);print(json.dumps(row),flush=True)
receipt={'passed':True,'cases':reports,'memo':memo.metadata(),'live_deployed':False,
         'scope':'Four native input regions cover the six hand-marked references. Half/full prefixes have exact entire geometry outputs. No new native UI rendering or all-history accuracy claim.'}
(V/'geometry_memo_reference_acceptance.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(receipt),flush=True)
