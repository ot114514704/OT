param([string]$Mql5 = 'C:\Users\qkn\AppData\Roaming\MetaQuotes\Terminal\D0E8209F77C8CF37AD8BF550E51FF075\MQL5')
$ErrorActionPreference = 'Stop'
$base = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
if (![IO.Path]::GetPathRoot($base).Equals('D:\',[StringComparison]::OrdinalIgnoreCase)) { throw 'This package must be stored on D drive.' }
$mql = [IO.Path]::GetFullPath($Mql5).TrimEnd('\')
$backup = Join-Path $base ('storage_backups\' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
function Link-OwnedDirectory([string]$relative,[string]$destination) {
 $target = [IO.Path]::GetFullPath((Join-Path $mql $relative))
 $expected = [IO.Path]::GetFullPath((Join-Path $mql $relative))
 $dest = [IO.Path]::GetFullPath($destination)
 if (!$target.Equals($expected,[StringComparison]::OrdinalIgnoreCase) -or !$target.StartsWith($mql+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'MT5 target path escaped the named MQL5 directory.' }
 if (!$dest.StartsWith($base+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Destination escaped this D-drive experiment.' }
 New-Item -ItemType Directory -Path $dest -Force | Out-Null
 if (Test-Path -LiteralPath $target) {
  $item = Get-Item -LiteralPath $target -Force
  if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
   $actual = [IO.Path]::GetFullPath([string]$item.Target)
   if ($actual.TrimEnd('\').Equals($dest.TrimEnd('\'),[StringComparison]::OrdinalIgnoreCase)) { return }
   throw "Existing link points somewhere else; left untouched: $target"
  }
  # Only four explicitly named directories belong to this experimental package.
  $allowed = @('Files\Book302Experiment1230','Indicators\Book302_Independent_Experiment1230','Indicators\Book302_Research_Adapters1230','Scripts\Book302Research1230','Profiles\Templates\Book302Experiment1230')
  if ($relative -notin $allowed) { throw 'Directory is outside the experiment allow-list.' }
  New-Item -ItemType Directory -Path $backup -Force | Out-Null
  $saved = [IO.Path]::GetFullPath((Join-Path $backup ($relative.Replace('\','_'))))
  if (!$saved.StartsWith($base+'\storage_backups\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Backup path escaped the experiment.' }
  if ($relative -eq 'Files\Book302Experiment1230') {
   # Retain previous experimental captures and audit files on D before switching.
   Copy-Item -Path (Join-Path $target '*') -Destination $dest -Recurse -Force
  }
  Move-Item -LiteralPath $target -Destination $saved
  try { New-Item -ItemType Junction -Path $target -Target $dest | Out-Null }
  catch { Move-Item -LiteralPath $saved -Destination $target; throw }
 } else {
  New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
  New-Item -ItemType Junction -Path $target -Target $dest | Out-Null
 }
 Write-Output "$relative -> $dest"
}
Link-OwnedDirectory 'Files\Book302Experiment1230' (Join-Path $base 'runtime\bridge')
Link-OwnedDirectory 'Indicators\Book302_Independent_Experiment1230' (Join-Path $base 'source')
Link-OwnedDirectory 'Indicators\Book302_Research_Adapters1230' (Join-Path $base 'companions')
Link-OwnedDirectory 'Scripts\Book302Research1230' (Join-Path $base 'native_scripts')
Link-OwnedDirectory 'Profiles\Templates\Book302Experiment1230' (Join-Path $base 'templates')
Write-Output 'Only experiment directories were linked. All experimental source, runtime data and backups are physically on D.'
Write-Output 'Original IPDA_Consolidation, Book_Repository_20261108, the ZIP and GitHub are untouched.'
