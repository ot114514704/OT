"""Same preserved request, explicit direct and candidate paths, no live edits."""
from pathlib import Path
import json,time,hashlib,io,unittest
from unittest.mock import patch
import worker
from geometry_window_memo import GeometryWindowMemo
from native_dense_memo import NativeDenseMemo
from ict_trader import dense_pauses,long_geometry,oscillation
from test_native_dense_memo import NativeDenseMemoTests,request

B=Path(__file__).parent;V=B/'verification/native_dense_performance_20261118';V.mkdir(exist_ok=True)
stream=io.StringIO()
tests=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(NativeDenseMemoTests))
(V/'unit_checks.log').write_text(stream.getvalue(),'utf8')
print(stream.getvalue(),flush=True);assert tests.wasSuccessful()
expected=json.loads((B/'verification/performance_r3_20261118/baseline_results.json').read_text('utf8'))
results={};timings={};calls=[0]
def direct(bars,asof):
    calls[0]+=1
    return dense_pauses.observe_dense_pauses(bars,asof)
memo=NativeDenseMemo(worker.NativeBar)
for name,callback in [('direct',direct),('memo',memo.observe)]:
    worker.recognize.cache_clear()
    geometry=GeometryWindowMemo(long_geometry.candidate,worker.NativeBar,lambda:(long_geometry.PARAMETERS,oscillation.PARAMETERS))
    started=time.perf_counter()
    with patch.object(worker,'observe_dense_pauses',callback),patch.object(worker,'_geometry_candidates',geometry):
        results[name]=worker.solve(request,lambda msg:print(name+' '+msg,flush=True))
    timings[name]=time.perf_counter()-started
    assert results[name]==expected,(name,'full output mismatch')
assert memo.calls==calls[0] and memo.calls>1 and memo.last_reused>0
report={'passed':True,'records':len(expected),'all_fields_exact':True,'unit_checks':tests.testsRun,
        'direct_calls':calls[0],'memo':memo.metadata(),'seconds':timings,
        'reduction_fraction':1-timings['memo']/timings['direct'],
        'candidate_sha256':hashlib.sha256((B/'native_dense_memo.py').read_bytes()).hexdigest(),
        'live_deployed':False,'scope':'One preserved H1 request with cold geometry cache in both paths; all lifecycle/result fields equal. Not trading backtest or end-to-end live latency.'}
(V/'acceptance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(report),flush=True)
