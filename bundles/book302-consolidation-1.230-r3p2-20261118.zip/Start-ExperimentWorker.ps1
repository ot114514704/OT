param(

 [string]$Bridge = (Join-Path $PSScriptRoot 'runtime\bridge'),

 [string]$Python = 'D:\盘整研究资料\项目\盘整研究\.venv\Scripts\python.exe'

)

$ErrorActionPreference = 'Stop'

$worker = Join-Path $PSScriptRoot 'worker.py'

if (!(Test-Path -LiteralPath $Python)) { throw 'Bundled Python path has changed. Supply -Python with the current Python executable.' }

New-Item -ItemType Directory -Path $Bridge -Force | Out-Null

$identity = Join-Path $Bridge 'worker_identity.json'

if (Test-Path -LiteralPath $identity) {

 $saved = Get-Content -LiteralPath $identity -Raw | ConvertFrom-Json

 $running = Get-CimInstance Win32_Process -Filter "ProcessId=$($saved.pid)" -ErrorAction SilentlyContinue

 if ($running -and $running.CommandLine.Contains($worker)) {

  $sha = (Get-FileHash -LiteralPath $worker -Algorithm SHA256).Hash.ToLowerInvariant()

  if ($saved.script_sha256 -eq $sha) { Write-Output "Independent worker already running: $($saved.pid)"; return }

  throw 'An earlier independent worker is still running. Use Stop-ExperimentWorker.ps1 first.'

 }

}

$stop = Join-Path $Bridge 'worker.stop'

if (Test-Path -LiteralPath $stop) { Remove-Item -LiteralPath $stop }

$argsList = @('"' + $worker + '"', '--folder', '"' + $Bridge + '"')

$started = Start-Process -FilePath $Python -ArgumentList $argsList -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot 'worker_stdout.log') -RedirectStandardError (Join-Path $PSScriptRoot 'worker_stderr.log') -PassThru

Write-Output "Independent worker started: $($started.Id). No MT5 chart is changed by this script."

