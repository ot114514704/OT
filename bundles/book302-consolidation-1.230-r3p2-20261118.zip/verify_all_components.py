"""Offline integration on real native candles, D-drive outputs only."""
import json,time,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
from worker import NativeBar,parse_request,encode_reply,solve
from research_adapter import run,summary,export_companion
out=BASE/'verification';out.mkdir(exist_ok=True)
text=(out/'all_components_request.tsv').read_text(encoding='utf8')
request=parse_request(text);clock=request['cutoff'];frames={request['seconds']:request['bars'],**request['background']}
assert set(frames)=={900,3600}
began=time.monotonic();report,charts=run(request['bars'],request['background']);elapsed=time.monotonic()-began
assert report['available'] and set(charts)=={'H1','M15'}
for period,chart in charts.items():
 assert datetime.fromisoformat(chart['closed_end']).timestamp()<=clock
 for key in ('phase_rows','episodes','swing_rows','structural_ranges','geometric_ranges','macro_ranges','cisd','current_candidate','reference_targets'):
  assert key in chart,(period,key)
export_companion(out/'companion_offline',request,charts)
shape=(out/'companion_offline'/'shapes.tsv').read_text(encoding='utf8').splitlines();h=shape[0].split('\t');assert len(shape)==int(h[4])+2
results=solve(request);(out/'protocol_reply.tsv').write_text(encode_reply(request,results,elapsed,'full'),encoding='utf8')
assert len((out/'protocol_reply.tsv').read_text(encoding='utf8').splitlines()[1].split('\t'))==19
receipt=dict(passed=True,real_native_input=True,period_counts={str(k):len(v) for k,v in frames.items()},clock=clock,elapsed_seconds=elapsed,report=report,shape_count=int(h[4]),source_sha256=report['source_sha256'],runtime_visual_verified=False)
(out/'all_components_integration.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
print('ALL_COMPONENTS_PASS',round(elapsed,3),'seconds','shapes',int(h[4]),flush=True)
