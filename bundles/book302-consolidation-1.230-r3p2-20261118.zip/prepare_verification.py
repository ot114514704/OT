from pathlib import Path
import shutil
B=Path(__file__).parent;O=Path('D:/盘整研究资料/Book302_回测优化_1.221_20261117')
p=B/'companions/IPDA_Consolidation_Adapted.mq5';s=p.read_text('utf-8')
for a,b in [('OBJPROP_YDISTANCE,44);','OBJPROP_YDISTANCE,68);'),('OBJPROP_YDISTANCE,72);','OBJPROP_YDISTANCE,96);'),('OBJPROP_YDISTANCE,42);','OBJPROP_YDISTANCE,66);'),('OBJPROP_YDISTANCE,22);','OBJPROP_YDISTANCE,118);')]:s=s.replace(a,b)
s=s.replace('prefix+"SCAN_PROGRESS",700,48','prefix+"SCAN_PROGRESS",700,70')
p.write_text(s,'utf-8')
# Existing saved native request is a fixture, not a live result of this version.
choices=list((O/'verification').rglob('request_*_3600.tsv'))
assert choices,'No saved native integration request'
src=max(choices,key=lambda p:p.stat().st_size)
shutil.copy2(src,B/'verification/all_components_request.tsv')
print('Integration fixture:',str(src))
