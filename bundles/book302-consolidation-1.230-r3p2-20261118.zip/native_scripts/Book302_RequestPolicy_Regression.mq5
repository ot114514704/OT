#property strict
#property version "1.000"
#include "../source/BookExperimentRequestPolicy.mqh"
void OnStart(){
 int passed=0,failed=0;
 datetime cutoff=D'2026.11.10 04:00',cross=D'2026.11.09 21:00';
 bool checks[]={BEXEventInScope("GUIDED_TURNING",cross,cutoff),BEXEventInScope("GUIDED_SHIFT",cross,cutoff),
 !BEXEventInScope("GUIDED_SOURCE",cross,cutoff),!BEXEventInScope("GUIDED_SHIFT",cutoff+3600,cutoff),
 !BEXEventInScope("GUIDED_TURNING",0,cutoff),
 BEXRequestToken("same-closed-bars","left-before-cross",true,false)!=BEXRequestToken("same-closed-bars","left-after-cross",true,false),
 BEXRequestToken("same-closed-bars","view",true,false)==BEXRequestToken("same-closed-bars","view",true,false)};
 for(int i=0;i<ArraySize(checks);i++){if(checks[i])passed++;else failed++;}
 int f=FileOpen("Book302Experiment1230\\policy_tests.tsv",FILE_WRITE|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);
 if(f!=INVALID_HANDLE){FileWrite(f,"version","passed","failed","time");FileWrite(f,"1.230",passed,failed,(long)TimeLocal());FileClose(f);}
 PrintFormat("BOOK1230_REQUEST_POLICY passed=%d failed=%d",passed,failed);
}
