#property strict
#property version "1.000"
void OnStart(){
 long c=ChartID();bool owned=false;
 for(int i=0;i<ChartIndicatorsTotal(c,0);i++)if(ChartIndicatorName(c,0,i)=="Book 1.302 Independent Consolidation Experiment 1.230")owned=true;
 if(!owned||ChartSymbol(c)!="XAUUSD"||ChartPeriod(c)!=PERIOD_H1){Print("PAN_TEST_REFUSED: only the independent 1.230 H1 chart is eligible");return;}
 ChartSetInteger(c,CHART_AUTOSCROLL,false);ChartSetInteger(c,CHART_SHIFT,false);ChartSetInteger(c,CHART_SCALE,5);ChartRedraw(c);Sleep(500);
 int visible=(int)ChartGetInteger(c,CHART_VISIBLE_BARS);
 int desired=iBarShift("XAUUSD",PERIOD_H1,D'2026.11.10 01:00',false);
 ChartNavigate(c,CHART_END,-(int)MathMax(0,desired-visible+1));ChartRedraw(c);Sleep(600);
 int first=(int)ChartGetInteger(c,CHART_FIRST_VISIBLE_BAR);visible=(int)ChartGetInteger(c,CHART_VISIBLE_BARS);
 int f=FileOpen("Book302Experiment1230\\pan_test_viewport.tsv",FILE_WRITE|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);
 if(f!=INVALID_HANDLE){FileWrite(f,"chart","left","right_open","visible","version");FileWrite(f,c,(long)iTime("XAUUSD",PERIOD_H1,first),(long)iTime("XAUUSD",PERIOD_H1,(int)MathMax(0,first-visible+1)),visible,"1.230");FileClose(f);}
}
