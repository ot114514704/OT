#property strict

#property version "1.000"

void OnStart(){

 long c=0;int saved=FileOpen("Book302Experiment1230\\experiment_chart.txt",FILE_READ|FILE_CSV|FILE_ANSI,'\t',CP_UTF8);

 if(saved!=INVALID_HANDLE){c=StringToInteger(FileReadString(saved));FileClose(saved);}

 bool owned=false;

 if(c>0&&ChartSymbol(c)=="XAUUSD"&&ChartPeriod(c)==PERIOD_H1)

  for(int i=0;i<ChartIndicatorsTotal(c,0);i++)if(StringFind(ChartIndicatorName(c,0,i),"Book 1.302 Independent Consolidation Experiment 1.230")>=0)owned=true;

 if(!owned)c=ChartOpen("XAUUSD",PERIOD_H1);if(c<=0)return;Sleep(500);

 bool ok=owned||ChartApplyTemplate(c,"Book302Experiment1230\\Book302_All_Research_Experimental.tpl");Sleep(800);

 ChartSetInteger(c,CHART_AUTOSCROLL,false);ChartSetInteger(c,CHART_SHIFT,false);ChartSetInteger(c,CHART_SCALE,4);ChartRedraw(c);Sleep(400);

 int visible=(int)ChartGetInteger(c,CHART_VISIBLE_BARS);int shift=iBarShift("XAUUSD",PERIOD_H1,D'2026.08.27 18:00',false);

 ChartNavigate(c,CHART_END,-(int)MathMax(0,shift-visible/3));ChartSetInteger(c,CHART_BRING_TO_TOP,true);ChartRedraw(c);

 int f=FileOpen("Book302Experiment1230\\experiment_chart.txt",FILE_WRITE|FILE_TXT|FILE_ANSI,0,CP_UTF8);if(f!=INVALID_HANDLE){FileWriteString(f,IntegerToString(c)+"\t"+IntegerToString(ok));FileClose(f);}

}

