from pathlib import Path
import csv,json,hashlib,zipfile,shutil
from collections import Counter
from datetime import datetime,timezone
B=Path(__file__).resolve().parent; V=B/'verification'; R=B/'runtime/bridge'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8')
def load(p):return json.loads(p.read_text(encoding='utf8'))
scope='102395022576553_3600'
out=V/'after_pan';out.mkdir(exist_ok=True)
for n in [f'request_{scope}.tsv',f'reply_{scope}.tsv',f'audit_{scope}.json',f'continuation_render_{scope}.tsv',f'experiment_{scope}.png','pan_test_viewport.tsv','worker_identity.json']:
 if (R/n).exists():shutil.copy2(R/n,out/n)
from worker import parse_request
req=parse_request((out/f'request_{scope}.tsv').read_text(encoding='utf-8-sig'))
audit=load(out/f'audit_{scope}.json')
assert req['token']==audit['token']
assert audit['version'].endswith('1.230') and audit['full_model']['available']
render=list(csv.DictReader((out/f'continuation_render_{scope}.tsv').read_text(encoding='utf-8-sig').splitlines(),delimiter='\t'))
actual_segments=0
for row in render:
 assert row['version']=='1.230'
 if row['start']==row['end']:continue
 assert row['line_present']=='1',row
 for a,b in [('start','actual_start'),('end','actual_end'),('price0','actual_price0'),('price1','actual_price1')]:assert abs(float(row[a])-float(row[b]))<1e-8
 actual_segments+=1
headers=sorted((B/'source/book_native').glob('*.mqh'));assert len(headers)==41
with zipfile.ZipFile(r'D:\CodexData\Downloads\forex-ai-source-main.zip') as z:
 prefix='forex-ai-source-main/indicators/ALEXANDERDELL2/development/Book_1.302_Compiled/source/book_native/'
 for p in headers:assert p.read_bytes()==z.read(prefix+p.name),p.name
assert (B/'continuation.py').read_bytes()==Path(r'D:\盘整研究资料\Book302_间隔恢复实验_1.220_20261116\continuation.py').read_bytes()
unit=(V/'tests_1230_final.log').read_text(encoding='utf-8-sig');assert 'Ran 41 tests' in unit and unit.rstrip().endswith('OK')
sweep=load(V/'native_sweep.json');assert sweep['passed'] and sweep['completed']==195 and not sweep['failures']
eq=load(V/'retrospective_equivalence.json');assert eq['passed']
policy=list(csv.DictReader((V/'policy_tests.tsv').read_text(encoding='utf-8-sig').splitlines(),delimiter='\t'))[0];assert policy['passed']=='7' and policy['failed']=='0'
logs=[B/'compile1230.log',B/'compile_open1230.log',B/'compile_pan1230.log',B/'compile_policy1230.log',*V.glob('compile_*.log')]
for p in logs:assert '0 errors, 0 warnings' in p.read_text(encoding='utf-16'),p
prod=Path(r'D:\盘整研究资料\项目\盘整研究');modules=[]
for p in sorted((B/'research_snapshot/ict_trader').glob('*.py')):
 q=prod/'ict_trader'/p.name;modules.append(dict(name=p.name,sha256=sha(p),matches_production_at_verification=q.exists() and sha(q)==sha(p)))
diff=[x['name'] for x in modules if not x['matches_production_at_verification']]
save(B/'LATEST_RESEARCH_IMPORT.json',dict(stage=str(B),source=str(prod),verified_at=datetime.now(timezone.utc).isoformat(),modules=modules,newer_production_modules=diff,app_matches_production=sha(B/'research_snapshot/app_source.py')==sha(prod/'app.py'),policy='Tested pinned snapshot inherited from 1.220. Current differences are listed, not silently imported. Production read only.'))
summary=dict(total=sweep['total'],checks=sweep['checks'],continuations=sum(e['continuation'] for e in sweep['events']),resumptions=sum(e['contains_resumption'] for e in sweep['events']),states=dict(Counter(e['state'] for e in sweep['events'] if e['continuation'])))
artifacts=[B/'worker.py',B/'continuation.py',B/'research_adapter.py',* (B/'source').glob('*.*'),*(B/'native_scripts').glob('*.*'),*(B/'templates').glob('*.tpl')]
receipt=dict(version='1.230',stage='backtests_passed_native_pan_visual_pending',verified_at=datetime.now(timezone.utc).isoformat(),original_headers_exact=41,continuation_rules_same_as_1220=True,unit_tests=41,native_policy_tests=7,historical_sweep=summary,performance_equivalence=eq,native_chart=req['chart'],native_token=req['token'],native_cutoff=req['cutoff'],native_objects_coordinates_exact=actual_segments,native_full_model_seconds=audit['elapsed_seconds'],native_full_model_periods=audit['full_model'].get('periods'),visual_pan_verified=False,visual_pending_reason='Concurrent computer-use requests and chart changes prevented stable viewport acceptance. Object-level native evidence is captured separately.',production_snapshot_differences=diff,artifact_sha256={str(p.relative_to(B)):sha(p) for p in artifacts},limits=['Saved native XAUUSD H1 historical events; no profitability or all-market certification.','Original Book endpoints remain unchanged; independent yellow continuation.','Missing bars and confirmed frozen-range exits legitimately end segments.','Original buttons retained in unchanged Book source; full toggle regression was baseline 1.220, not repeated in this iteration.','Native template reload and stable offscreen pan acceptance pending.','PA and consolidation snapshots are frozen; newer production display updates excluded.'])
save(B/'VERIFICATION.json',receipt);save(V/'1.230.json',receipt)
print(json.dumps(dict(history=summary,native_objects=actual_segments,research_diff=diff,token=req['token']),ensure_ascii=False))
