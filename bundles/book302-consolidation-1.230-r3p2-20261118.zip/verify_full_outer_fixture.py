"""One saved native chart request: old results exact, new handoffs causal."""
from pathlib import Path
import json,time,hashlib,collections,sys
from worker import parse_request,solve,encode_reply
from outer_continuation import handoff_chain
sys.stdout.reconfigure(encoding='utf8')
B=Path(__file__).parent;V=B/'verification/outer_full_request_r3';V.mkdir(exist_ok=True)
src=B/'verification/line_endings_20261117'
raw=(src/'request_102923304041429_3600.tsv').read_text('utf-8-sig')
request=parse_request(raw)
baseline=json.loads((src/'audit_102923304041429_3600.json').read_text('utf8'))
assert baseline['token']==request['token']
start=time.monotonic()
results=solve(request,lambda message:print(message,flush=True))
by_id={r['id']:r for r in results};mismatches=[];chains=[];segments=0
for old in baseline['results']:
 new=by_id[old['id']]
 # Old audit includes full-model prose appended after solve(). Ignore only
 # that additive prose and current follow-up labels, not coordinates or rules.
 for key in ('code','label','context','side','pa','fixed','nmatches','continuation'):
  if old.get(key)!=new.get(key):mismatches.append({'id':old['id'],'field':key})
 if new.get('outer_continuation'):
  c=new['outer_continuation'];event=next(e for e in request['events'] if e['id']==old['id'])
  previous=new['continuation']['through'];low=new['continuation']['low'];high=new['continuation']['high']
  for index,step in enumerate(c['range_chain']):
   assert step['known']>=previous and (index==0 or step['known']>previous)
   assert step['low']<=low and step['high']>=high and (step['low']<low or step['high']>high)
   previous=step['known'];low=step['low'];high=step['high']
  event_index=next(i for i,b in enumerate(request['bars']) if int(b.closed_at.timestamp())==event['clock'])
  indexes={int(b.time.timestamp()):i for i,b in enumerate(request['bars'])}
  for s in c['segments']:
   assert s['known']<=request['cutoff'] and s['start']<=s['end']
   assert s['end']+request['seconds']<=request['cutoff']
   for stamp,price in ((s['start'],s['price0']),(s['end'],s['price1'])):
    expected=event['line']+event['slope']*(indexes[stamp]-event_index)
    assert abs(expected-price)<1e-8
   for i in range(indexes[s['start']]+1,indexes[s['end']]+1):
    assert request['bars'][i].time==request['bars'][i-1].closed_at,'Segment crosses a missing interval'
   assert s['low']<=s['high'];segments+=1
  chains.append({'id':old['id'],'range_count':len(c['range_chain']),'segments':len(c['segments']),'state':c['final_state']})
assert len(results)==len(baseline['results'])
assert not mismatches,mismatches
wire=encode_reply(request,results,time.monotonic()-start,'core')
(V/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),'utf8')
(V/'reply.tsv').write_text(wire,'utf8')
receipt={'passed':True,'request_token':request['token'],'request_sha256':hashlib.sha256(raw.encode()).hexdigest(),
 'results_compared':len(results),'original_fields_exact':True,'new_outer_chains':chains,'new_outer_segments':segments,
 'seconds':time.monotonic()-start,'native_visual_verified':False,
 'scope':'One previously captured native H1 chart request. Causal range growth, original-equation coordinates, no missing-interval bridges; not a new profitability backtest or all-history certification.'}
(V/'acceptance.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(receipt,ensure_ascii=False,indent=2),flush=True)
