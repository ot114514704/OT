"""Exercise the actual Windows sharing violation that killed version 1.210."""
import ctypes,json,time,threading,tempfile,os
from pathlib import Path
from worker import atomic,publish_heartbeat,BASE
assert os.name=='nt'
api=ctypes.WinDLL('kernel32',use_last_error=True)
api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p]
api.CreateFileW.restype=ctypes.c_void_p
api.CloseHandle.argtypes=[ctypes.c_void_p];api.CloseHandle.restype=ctypes.c_int
with tempfile.TemporaryDirectory(dir=BASE/'verification') as name:
 folder=Path(name);path=folder/'worker_heartbeat.txt';path.write_text('old')
 def lock():
  handle=api.CreateFileW(str(path),0x80000000,1,None,3,0x80,None)
  if handle==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
  return handle
 h=lock();timer=threading.Timer(.15,lambda:api.CloseHandle(h));timer.start()
 start=time.monotonic();atomic(path,'new-complete');elapsed=time.monotonic()-start;timer.join()
 assert path.read_text()=='new-complete' and elapsed>=.1
 h=lock()
 try:publish_heartbeat(folder);assert path.read_text()=='new-complete'
 finally:api.CloseHandle(h)
 publish_heartbeat(folder);assert int(path.read_text())>0
receipt=dict(passed=True,actual_windows_share_denial=True,transient_retry_seconds=elapsed,
 persistent_lock_survived=True,publication_resumed_after_unlock=True)
(BASE/'verification'/'windows_file_lock_1.220.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print('PASS actual Windows lock: retry, worker survival, recovery')
