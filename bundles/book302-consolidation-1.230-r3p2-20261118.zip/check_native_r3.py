"""Read-only current chart/request/worker/geometry acceptance; no UI actions."""
from pathlib import Path
import csv,json,hashlib,time,sys
B=Path(__file__).parent;R=B/'runtime/bridge';scope='102923304041429_3600'
problems=[]
def read(name):return (R/name).read_text('utf-8-sig')
request=read('request_'+scope+'.tsv').splitlines()[0].split('\t');token=request[2]
audit=json.loads(read('audit_'+scope+'.json'))
if audit.get('token')!=token:problems.append('audit_token_mismatch')
if not audit.get('full_model',{}).get('available'):problems.append('full_model_unavailable')
identity=json.loads(read('worker_identity.json'))
worker_sha=hashlib.sha256((B/'worker.py').read_bytes()).hexdigest()
if identity.get('script_sha256')!=worker_sha:problems.append('running_worker_revision_differs')
state_path=R/('render_state_'+scope+'.tsv')
state=[]
if not state_path.exists():problems.append('r3_render_state_missing')
else:
 state=state_path.read_text('utf-8-sig').strip().split('\t')
 if len(state)!=14 or state[:3]!=['BEX_RENDER','1','1.230-r3']:problems.append('invalid_render_state')
 else:
  if state[3]!=token or state[4]!=token:problems.append('render_state_token_mismatch')
  if state[5]!='full' or state[6]!=request[4]:problems.append('render_stage_or_clock_mismatch')
  if state[7:11]!=['0','1','1','1']:problems.append('continuation_controls_not_all_visible')
  if time.time()-int(state[12])>120:problems.append('render_state_not_fresh')
rows=list(csv.DictReader(read('continuation_render_'+scope+'.tsv').splitlines(),delimiter='\t'))
expected=[x.split('\t') for x in read('reply_'+scope+'.tsv').splitlines() if x.startswith('C\t')]
if len(rows)!=len(expected):problems.append('render_segment_count_mismatch')
verified=0;outer=0
for i,(actual,wanted) in enumerate(zip(rows,expected)):
 if actual.get('request_token')!=token or actual.get('loaded_token')!=token or actual.get('guard_revision')!='1.230-r3':
  problems.append('row_'+str(i)+'_not_current_r3');continue
 if actual['id']!=wanted[1] or actual['state']!=wanted[8]:problems.append('row_'+str(i)+'_identity_mismatch');continue
 if wanted[2]==wanted[3]:continue
 if actual['line_present']!='1':problems.append('row_'+str(i)+'_line_missing');continue
 if not all(abs(float(actual[k])-float(wanted[v]))<1e-7 for k,v in [('actual_start',2),('actual_end',3),('actual_price0',4),('actual_price1',5)]):
  problems.append('row_'+str(i)+'_coordinate_mismatch');continue
 verified+=1;outer+=wanted[8].startswith('outer_')
result={'passed':not problems,'request_token':token,'expected_segments':len(expected),'verified_nonzero_segments':verified,
 'verified_outer_segments':outer,'problems':problems,'visual_acceptance':False,
 'scope':'Current file receipts only. Fresh matching r3 native render is required; this cannot replace visual/button acceptance.'}
out=B/'verification/outer_full_request_r3/native_readiness.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({k:v for k,v in result.items() if k!='problems'}|{'problems':problems[:8],'problem_count':len(problems)}))
