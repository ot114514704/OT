param([string]$Bridge = (Join-Path $PSScriptRoot 'runtime\bridge'))
$ErrorActionPreference = 'Stop'
$identity = Join-Path $Bridge 'worker_identity.json'
if (!(Test-Path -LiteralPath $identity)) { Write-Output 'Independent worker has not been started.'; return }
$saved = Get-Content -LiteralPath $identity -Raw | ConvertFrom-Json
$worker = Join-Path $PSScriptRoot 'worker.py'
$running = Get-CimInstance Win32_Process -Filter "ProcessId=$($saved.pid)" -ErrorAction SilentlyContinue
if ($running -and $running.CommandLine.Contains($worker)) {
 Set-Content -LiteralPath (Join-Path $Bridge 'worker.stop') -Value 'User requested independent worker stop'
 Write-Output 'Stop requested. The worker exits after its current calculation.'
} else { Write-Output 'No matching independent worker process is running.' }
