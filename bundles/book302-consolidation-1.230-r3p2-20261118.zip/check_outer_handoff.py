"""Targeted captured-input diagnosis; no new historical sweep or deployment."""
from pathlib import Path
import json,time,sys
from worker import parse_request,recognize
sys.stdout.reconfigure(encoding='utf8')
B=Path(__file__).parent;V=B/'verification/line_endings_20261117'
req=parse_request((V/'request_102923304041429_3600.tsv').read_text('utf-8-sig'))
audit=json.loads((V/'audit_102923304041429_3600.json').read_text('utf8'))
target='b4e48192d4d359124fa8b616'
r=next(x for x in audit['results'] if x['id']==target);c=r['continuation']
bars=req['bars'];idx=next(i for i,b in enumerate(bars) if int(b.closed_at.timestamp())==r['clock'])
t=time.monotonic();contexts,_=recognize(tuple(bars[:idx+1]))
rows=[]
for x in contexts:
 if x['id'] not in c['outer_range_ids']:continue
 low=min(x['low'],x['fixed_low']);high=max(x['high'],x['fixed_high'])
 if low>c['low'] or high<c['high'] or (low==c['low'] and high==c['high']):continue
 after=[b for b in bars if c['through']<=int(b.closed_at.timestamp())<=req['cutoff']]
 rows.append(dict(id=x['id'],kind=x['kind'],known=x['known'],low=low,high=high,
  original_exit_still_inside=bool(after) and low<=after[0].close<=high,
  subsequent_closed_bodies_inside=sum(low<=b.open<=high and low<=b.close<=high for b in after),
  subsequent_count=len(after),status_at_original_event=x['status']))
result=dict(event=target,event_clock=r['clock'],original_continuation=c,outer_candidates=rows,
 seconds=time.monotonic()-t,policy='Diagnostic only: each genuinely containing range is already known at the original crossing; no union, no widening of original continuation, no later candidate admitted retrospectively.',deployed=False)
(V/'outer_handoff_diagnosis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({'event':target,'inner_bounds':[c['low'],c['high']],'outer_candidates':rows,'seconds':result['seconds']},ensure_ascii=False,indent=2))
