from pathlib import Path
import json,sys
from worker import parse_request,recognize,classify,encode_reply
from continuation import observe
from outer_continuation import handoff_chain as handoff
sys.stdout.reconfigure(encoding='utf8')
B=Path(__file__).parent;V=B/'verification/line_endings_20261117';O=B/'verification/outer_handoff_r3'
req=parse_request((V/'request_102923304041429_3600.tsv').read_text('utf-8-sig'))
audit=json.loads((V/'audit_102923304041429_3600.json').read_text('utf8'))
target='b4e48192d4d359124fa8b616';event=next(e for e in req['events'] if e['id']==target)
old=next(r for r in audit['results'] if r['id']==target)
index=next(i for i,b in enumerate(req['bars']) if int(b.closed_at.timestamp())==event['clock'])
contexts,_=recognize(tuple(req['bars'][:index+1]))
r=classify(event,req['bars'][:index+1],contexts,req['patterns'])
r['continuation']=observe(event,r,contexts,req['bars'],req['cutoff'])
assert r['continuation']==old['continuation'],'Original continuation changed'
out=handoff(event,r,contexts,req['bars'],req['cutoff']);assert out,'Expected causal outer handoff on captured case'
r['outer_continuation']=out
wire=encode_reply(req,[r],0);(O/'captured_case_reply.tsv').write_text(wire,'utf8')
report={'passed':True,'event':target,'request_token':req['token'],'original_continuation_exact':True,
 'outer_continuation':out,'native_visual_verified':False,'scope':'One captured native case plus unit invariants; not all-history accuracy or fresh chart acceptance.'}
(O/'captured_case.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
