"""Reference-region and native M15 prefix equivalence for dense metric reuse."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
import worker
from native_dense_memo import NativeDenseMemo
from ict_trader import dense_pauses,viewport_history

B=Path(__file__).parent;V=B/'verification/native_dense_performance_20261118';V.mkdir(exist_ok=True)
REF=Path('D:/盘整研究资料/2026-11-14/new-chat/work/triangle_preference_20261116')
raw=json.loads(Path('D:/盘整研究资料/验收/历史空缺排查_20261114/H1_native_closed.json').read_text('utf8'))
cases=[]
for name in ('triangle_march','triangle_april','channel_triangle_august'):
    marks=json.loads((REF/(name+'.alignment.json')).read_text('utf8'))['annotations']
    start=min(datetime.fromisoformat(x['first_candle']).timestamp() for x in marks.values())-7*86400
    end=max(datetime.fromisoformat(x['last_closed']).timestamp() for x in marks.values())+86400
    bars=[worker.NativeBar(datetime.fromtimestamp(r['time'],timezone.utc),*(r[k] for k in ('open','high','low','close','spread')),3600)
          for r in raw if start<=r['time'] and r['time']+3600<=end]
    cases.append((name,bars))
old=viewport_history.parse_request((REF/'july_august_native.request.tsv').read_text('utf-8-sig'))['bars']
cases.append(('july_august_latest_two',[worker.NativeBar(b.time,b.open,b.high,b.low,b.close,b.spread,b.seconds) for b in old]))
request=worker.parse_request((B/'verification/native_r3/final/request_102923304041429_3600.tsv').read_text('utf-8-sig'))
cases.append(('native_M15',request['background'][900]))
memo=NativeDenseMemo(worker.NativeBar);reports=[]
for name,bars in cases:
    for n in (len(bars)//2,len(bars)):
        window=bars[:n];clock=window[-1].closed_at
        before=dense_pauses.observe_dense_pauses(window,clock)
        after=memo.observe(window,clock)
        assert before==after,(name,n)
        row={'case':name,'bars':n,'period_seconds':window[0].seconds,'records':len(after),'all_fields_exact':True,
             'result_sha256':hashlib.sha256(json.dumps(after,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),
             'memo':memo.metadata()}
        reports.append(row);print(json.dumps(row),flush=True)
receipt={'passed':True,'cases':reports,'scope':'Six user references plus 3000 native M15 bars, half/full prefixes. Complete ordinary-pause outputs equal; does not claim new native UI acceptance or full-history accuracy.'}
(V/'reference_acceptance.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
