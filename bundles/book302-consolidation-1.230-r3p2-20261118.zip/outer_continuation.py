"""Causal handoff to one pre-existing containing range, never a range union.

The original line and inner-range continuation keep their original endpoint.
This separately labelled segment is known only at the inner-range exit close.
"""
import math
from continuation import observe

def handoff(event, result, contexts, bars, cutoff):
    inner=result.get('continuation')
    if not inner or inner['state']!='fixed_envelope_exit':return None
    at=next((i for i,b in enumerate(bars) if int(b.closed_at.timestamp())==inner['through']),None)
    origin=next((i for i,b in enumerate(bars) if int(b.closed_at.timestamp())==event['clock']),None)
    if at is None or origin is None or at<=origin or inner['through']>cutoff:return None
    choices=[]
    for c in contexts:
        if c['id'] in inner['range_ids'] or c['id'] not in inner['outer_range_ids']:continue
        low=min(c['low'],c['fixed_low']);high=max(c['high'],c['fixed_high'])
        if not all(math.isfinite(v) for v in (low,high)):continue
        if low>inner['low'] or high<inner['high'] or (low==inner['low'] and high==inner['high']):continue
        if not c['active'] or c['known']>int(bars[origin].time.timestamp()):continue
        # Both bars of the inner exit must still have their bodies inside the
        # containing range. Do not join a gap or rely on a wick-only return.
        if bars[at].time!=bars[at-1].closed_at:continue
        if not all(low<=b.open<=high and low<=b.close<=high for b in bars[at-1:at+1]):continue
        candidate={'code':result['code'],'context':c}
        prefix=observe(event,candidate,contexts,bars[:at+1],inner['through'])
        if not prefix or prefix['state'] not in ('observing','resumed'):continue
        choices.append((high-low,-c['known'],c['id'],c))
    if not choices:return None
    # Selection uses only information through the handoff close. Future bars
    # can end this chosen range, but cannot pick a larger, longer-lived one.
    selected=min(choices,key=lambda x:x[:3])[3]
    outer=observe(event,{'code':result['code'],'context':selected},contexts,bars,cutoff)
    segments=[]
    for s in outer['segments']:
        if s['end']<inner['end']:continue
        segment=dict(s)
        if segment['start']<inner['end']:
            segment['start']=inner['end']
            segment['price0']=event['line']+event['slope']*(at-origin)
        segment['known']=max(segment['known'],inner['through'])
        segment['state']='outer_'+s['state']
        segment['label']='外层盘整续观；'+s['label']
        segment['low']=outer['low'];segment['high']=outer['high']
        segment['range_id']=selected['id']
        segments.append(segment)
    if not segments:return None
    return dict(id=event['id'],family=event['family'],known=inner['through'],
                parent_range_id=selected['id'],inner_range_ids=inner['range_ids'],
                low=outer['low'],high=outer['high'],state='outer_'+outer['state'],
                label='外层盘整续观；'+outer['label'],segments=segments,
                scope_observation=outer,
                policy='原线及内层终点不变；内层离区收盘后单独续接事前已知外层；不合并范围、不倒填、不代表趋势确认')

def handoff_chain(event,result,contexts,bars,cutoff):
    """Step through strictly containing known ranges at their own exit clocks."""
    step=handoff(event,result,contexts,bars,cutoff)
    if not step:return None
    combined=dict(step);combined['segments']=list(step['segments']);chain=[];seen=set()
    while step:
        selected=step['parent_range_id']
        if selected in seen:raise ValueError('Non-growing outer range chain')
        seen.add(selected)
        chain.append({k:step[k] for k in ('parent_range_id','known','low','high','state')})
        inner=step['scope_observation']
        if inner['state']!='fixed_envelope_exit':break
        next_step=handoff(event,{'code':result['code'],'continuation':inner},contexts,bars,cutoff)
        if not next_step:break
        if next_step['known']<=step['known']:raise ValueError('Non-forward outer handoff')
        combined['segments'].extend(next_step['segments']);step=next_step
    combined['range_chain']=chain
    combined['final_state']=step['state'];combined['state']=step['state'];combined['label']=step['label']
    combined.pop('scope_observation',None)
    return combined
