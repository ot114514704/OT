from pathlib import Path
import json,time
from worker import BASE,parse_request,solve
folder=BASE/'verification/before_pan'
req=parse_request((folder/'request_102395022576553_3600.tsv').read_text(encoding='utf8'))
old=json.loads((folder/'audit_102395022576553_3600.json').read_text(encoding='utf8'))
steps=[];started=time.monotonic();new=solve(req,steps.append);elapsed=time.monotonic()-started
byid={r['id']:r for r in old['results']}
assert len(new)==len(old['results'])
for r in new:
 prior=byid[r['id']]
 for key in ('code','label','side','context','pa','fixed','continuation'):
  assert r.get(key)==prior.get(key),(r['id'],key)
 if r['code']==7:assert r['continuation'] is None and '不据此断言不存在盘整' in r['detail']
skipped=sum(r['code']==7 for r in new)
assert skipped==75 and len(steps)<80
receipt=dict(passed=True,records=len(new),skipped_retrospective=skipped,recognition_clocks=len(steps),old_recognition_clocks=80,
 elapsed_seconds=elapsed,all_causal_decisions_and_continuations_exact=True,
 changed_fields='Only code-7 detail/follow explain skipped background; no claim of zero ranges')
(BASE/'verification/retrospective_equivalence.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(receipt),flush=True)
