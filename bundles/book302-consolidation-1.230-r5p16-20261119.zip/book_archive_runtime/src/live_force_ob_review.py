"""Closed-bar, same-timeframe force-leg and creator-OB geometry review.

This is a *screening* layer, not a probability model or an ICT/Alexander
semantic verdict.  Thresholds below are provisional visual filters; every
candidate retains the component observations so source-image review can
correct them without silently changing the trading rulebook.
"""

from __future__ import annotations

import statistics
from typing import Sequence


def _utc(value: object) -> str:
    return value.isoformat().replace("+00:00", "Z") if hasattr(value, "isoformat") else str(value)


def _prior_pivot(ledger: dict, kind: str, before_utc: str) -> dict | None:
    seen: dict[str, dict] = {}
    for leg in ledger.get("legs") or []:
        for point in (leg.get("origin"), leg.get("terminal")):
            if not isinstance(point, dict) or point.get("kind") != kind:
                continue
            stamp = str(point.get("pivot_timestamp_utc") or "")
            confirmed = str(point.get("confirmed_at_utc") or "")
            if stamp and confirmed and confirmed <= before_utc:
                seen[stamp] = point
    return max(seen.values(), key=lambda row: str(row["pivot_timestamp_utc"])) if seen else None


def review_force_ob_candidates(bars: Sequence, ledger: dict, *, max_candidates: int | None = 40) -> dict:
    """Review each native pivot leg and the open tail using only loaded closes.

    The caller's bars are already closed and time ordered. The pivot ledger
    supplies confirmation times; a pivot confirmed after the purported OB
    cannot be used as pre-existing liquidity/structure evidence.
    """
    if not bars:
        return {"status": "no_closed_bars", "force_leg_candidates": [], "order_block_candidates": [],
                "trade_permission": False}
    try:from .native_force_prefix_index import ForceBarPrefix
    except ImportError:from native_force_prefix_index import ForceBarPrefix
    index = bars if isinstance(bars,ForceBarPrefix) else {_utc(bar.timestamp_utc): i for i, bar in enumerate(bars)}
    frame = bars[-1].timeframe
    source_legs = list(ledger.get("legs") or [])
    tail = (ledger.get("unfinished_tail") or {}).get("from_confirmed_extremum")
    if isinstance(tail, dict) and index.get(tail.get("pivot_timestamp_utc")) is not None:
        source_legs.append({
            "leg_id": f"{frame}:ongoing_force_from:{tail['pivot_timestamp_utc']}",
            "origin": tail,
            "terminal": {"pivot_timestamp_utc": _utc(bars[-1].timestamp_utc),
                         "price": bars[-1].close},
            "terminal_confirmed_at_utc": _utc(bars[-1].timestamp_utc),
            "ongoing": True,
        })
    forces: list[dict] = []
    blocks: dict[tuple[str, str], dict] = {}
    for leg in source_legs:
        origin, terminal = leg.get("origin") or {}, leg.get("terminal") or {}
        start = index.get(str(origin.get("pivot_timestamp_utc")))
        end = index.get(str(terminal.get("pivot_timestamp_utc")))
        if start is None or end is None or not (2 <= end - start <= 32) or start < 5:
            continue
        pre_ranges = [bar.range for bar in bars[max(0, start - 20):start] if bar.range > 0]
        if len(pre_ranges) < 5:
            continue
        baseline = statistics.median(pre_ranges)
        signed = float(terminal["price"]) - float(origin["price"])
        if not signed or baseline <= 0:
            continue
        side = 1 if signed > 0 else -1
        duration = end - start
        close_steps = [bars[i].close - bars[i - 1].close for i in range(start + 1, end + 1)]
        total_travel = sum(abs(step) for step in close_steps)
        close_net = abs(bars[end].close - bars[start].close)
        efficiency = min(1.0, close_net / total_travel) if total_travel else 0.0
        progress = sum(side * step > 0 for step in close_steps)
        body_dominant = sum(
            side * (bars[i].close - bars[i].open) > 0
            and bars[i].body >= .5 * bars[i].range
            for i in range(start + 1, end + 1)
        )
        speed = abs(signed) / duration / baseline
        # A one-bar spike belongs to a later large-K review, not this wave layer.
        if not (speed >= .70 and efficiency >= .68 and progress / duration >= .65
                and body_dominant >= 2 and abs(signed) >= 2 * baseline):
            continue
        strong = (speed >= 1.10 and efficiency >= .80 and progress / duration >= .75
                  and duration <= 12)
        force = {
            "force_leg_id": leg["leg_id"], "timeframe": frame,
            "origin_utc": _utc(bars[start].timestamp_utc),
            "terminal_utc": _utc(bars[end].timestamp_utc),
            "origin_price": float(origin["price"]), "terminal_price": float(terminal["price"]),
            "direction_observation": "up" if side > 0 else "down",
            "bar_count": duration, "median_prior_range": round(baseline, 6),
            "net_points": round(abs(signed), 6),
            "points_per_bar": round(abs(signed) / duration, 6),
            "speed_to_prior_median_range": round(speed, 4),
            "close_path_efficiency": round(efficiency, 4),
            "directional_close_share": round(progress / duration, 4),
            "body_dominant_bar_count": body_dominant,
            "strength_observation": "strong_urgent_candidate" if strong else "force_candidate",
            "leg_state": "ongoing_closed_bars" if leg.get("ongoing") else "pivot_confirmed",
            "known_at_utc": str(leg.get("terminal_confirmed_at_utc") or _utc(bars[end].timestamp_utc)),
            "source_bar_open_times_utc": [_utc(bars[i].timestamp_utc) for i in range(start, end + 1)],
            "status": "closed_bar_force_geometry_not_author_adjudicated",
            "first_force_leg_adjudicated": False, "trade_permission": False,
        }
        forces.append(force)
        # The creator block must be one or two immediately preceding,
        # opposite-close bars; an arbitrary old candle is not bound to this leg.
        departure = next((i for i in range(start + 1, min(end, start + 4) + 1)
                          if side * (bars[i].close - bars[start].close) >= .8 * baseline), None)
        if departure is None:
            continue
        ob_end = departure - 1
        if not (side * (bars[ob_end].close - bars[ob_end].open) < 0):
            continue
        ob_start = ob_end
        if ob_start > 0 and side * (bars[ob_start - 1].close - bars[ob_start - 1].open) < 0:
            ob_start -= 1
        lower = min(bars[i].low for i in range(ob_start, ob_end + 1))
        upper = max(bars[i].high for i in range(ob_start, ob_end + 1))
        ob_time = _utc(bars[ob_start].timestamp_utc)
        swept = _prior_pivot(ledger, "confirmed_swing_low_candidate" if side > 0
                             else "confirmed_swing_high_candidate", ob_time)
        broken = _prior_pivot(ledger, "confirmed_swing_high_candidate" if side > 0
                              else "confirmed_swing_low_candidate", ob_time)
        swept_price = float(swept["price"]) if swept else None
        sweep_excursion = bool(swept and (lower < swept_price if side > 0 else upper > swept_price))
        reclaim = bool(sweep_excursion and any(
            (bars[i].close > swept_price if side > 0 else bars[i].close < swept_price)
            for i in range(ob_end, min(end, departure + 2) + 1)
        ))
        break_price = float(broken["price"]) if broken else None
        break_bar = next((bars[i] for i in range(departure, end + 1)
                          if broken and (bars[i].close > break_price if side > 0
                                         else bars[i].close < break_price)), None)
        fvg = None
        for left in range(ob_start, min(end - 1, departure + 3)):
            right = left + 2
            if right > end:
                break
            gap_low = bars[left].high if side > 0 else bars[right].high
            gap_high = bars[right].low if side > 0 else bars[left].low
            if gap_high > gap_low:
                fvg = {"lower": gap_low, "upper": gap_high,
                       "left_utc": _utc(bars[left].timestamp_utc),
                       "right_utc": _utc(bars[right].timestamp_utc)}
                break
        later = bars[end + 1:]
        closed_through = any((bar.close < lower if side > 0 else bar.close > upper) for bar in later)
        retest = any(bar.low <= upper and bar.high >= lower for bar in later)
        # User's two routes: very strong creator force, or a taken-and-
        # reclaimed prior pivot. A geometric structure close is required for
        # the highlighted class; FVG is separately recorded, not invented.
        highlighted = bool(break_bar and not closed_through and
                           ((strong and fvg) or (reclaim and strong)))
        block = {
            "ob_id": f"{frame}:creator_ob:{ob_time}:{_utc(bars[ob_end].timestamp_utc)}",
            "timeframe": frame, "force_leg_id": force["force_leg_id"],
            "direction_observation": force["direction_observation"],
            "from_utc": ob_time, "through_utc": _utc(bars[ob_end].timestamp_utc),
            "price_low": lower, "price_high": upper,
            "source_bar_open_times_utc": [_utc(bars[i].timestamp_utc) for i in range(ob_start, ob_end + 1)],
            "departure_utc": _utc(bars[departure].timestamp_utc),
            "creator_force_strength": force["strength_observation"],
            "prior_swing_swept": {"price": swept_price,
                                   "pivot_utc": swept.get("pivot_timestamp_utc") if swept else None,
                                   "confirmed_at_utc": swept.get("confirmed_at_utc") if swept else None,
                                   "excursion": sweep_excursion, "reclaimed": reclaim},
            "prior_opposite_swing_close_break": {
                "price": break_price,
                "pivot_utc": broken.get("pivot_timestamp_utc") if broken else None,
                "confirmed_at_utc": broken.get("confirmed_at_utc") if broken else None,
                "first_bar_utc": _utc(break_bar.timestamp_utc) if break_bar else None,
            },
            "immediate_fvg_candidate": fvg,
            "later_retest_observed": retest, "later_close_through_ob": closed_through,
            "priority": "high_priority_geometry_candidate" if highlighted else "ordinary_ob_geometry_candidate",
            "status": "historical_closed_through" if closed_through else "candidate_needs_parent_target_and_author_review",
            "known_at_utc": force["known_at_utc"],
            "author_named_ob_confirmed": False, "empirical_probability_established": False,
            "parent_target_lifecycle_confirmed": False, "trade_permission": False,
        }
        key = (block["from_utc"], block["through_utc"])
        previous = blocks.get(key)
        if previous is None or (highlighted and previous["priority"] != "high_priority_geometry_candidate"):
            blocks[key] = block
    return {
        "status": "closed_bar_force_ob_geometry_candidates",
        "timeframe": frame, "as_of_closed_bar_utc": _utc(bars[-1].timestamp_utc),
        "force_leg_candidates": forces if max_candidates is None else forces[-max_candidates:],
        "order_block_candidates": list(blocks.values()) if max_candidates is None else list(blocks.values())[-max_candidates:],
        "thresholds": {"force_min_duration_bars": 2, "force_max_duration_bars": 32,
                       "normalized_speed_min": .70, "path_efficiency_min": .68,
                       "strong_speed_min": 1.10},
        "boundary": "同周期已收盘几何筛选；斜率按之前本周期 K 线中位波幅归一，不把单根大 K、未知流动性、结构节点或目标生命周期冒充已确认。",
        "trade_permission": False,
    }
