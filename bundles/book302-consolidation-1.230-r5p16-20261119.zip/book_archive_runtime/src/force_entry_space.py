"""Price-pattern space assessment, not an order or a new stop optimiser.

Signal close != last closed OHLC != executable bid/ask. Keep them separate.
No global minimum RR or zero-cost assumption is invented. Optional policies
are source/timeframe/clock bound, explicit research/user scenarios only.
"""
from math import isfinite

from .force_strength_model import epoch,iso


def number(x):
    return isinstance(x,(int,float)) and not isinstance(x,bool) and isfinite(x)


def geometry(price,stop,target,sign):
    if not all(number(x) for x in (price,stop,target)):
        return dict(status='unavailable')
    risk=sign*(price-stop);reward=sign*(target-price)
    return dict(status='observed',reference_price=price,protection_price=stop,target_price=target,
        risk_points=risk,reward_points=reward,valid=risk>0 and reward>0,
        reward_risk=reward/risk if risk>0 and reward>0 else None,
        space_relation='reward_less_than_risk' if 0<reward<risk else 'reward_at_least_risk' if reward>=risk>0 else 'invalid_direction_or_space')


def policy_at(policy,force,when):
    if policy is None:return None,'not_configured'
    if not isinstance(policy,dict):return None,'foreign_future_or_unbound_policy'
    try:
        matching=(bool(force.get('id')) and bool(force.get('source_id')) and
            policy.get('owner_id')==force.get('id') and policy.get('source_id')==force.get('source_id')
            and policy.get('timeframe')==force.get('timeframe') and bool(policy.get('policy_id'))
            and policy.get('basis') in ('user_configured','explicit_research_scenario')
            and epoch(policy['known_at_utc'])<=when)
    except (KeyError,TypeError,ValueError):matching=False
    if not matching:return None,'foreign_future_or_unbound_policy'
    minimum=policy.get('minimum_reward_risk');cost=policy.get('round_trip_price_cost_points')
    if minimum is not None and (not number(minimum) or minimum<=0):return None,'invalid_policy_values'
    if cost is not None and (not number(cost) or cost<0):return None,'invalid_policy_values'
    return policy,'matched'


def scenario_check(g,policy,policy_status):
    minimum=policy.get('minimum_reward_risk') if policy else None
    cost=policy.get('round_trip_price_cost_points') if policy else None
    result=dict(policy_status=policy_status,policy_id=policy.get('policy_id') if policy else None,
        minimum_reward_risk=minimum,round_trip_price_cost_points=cost,
        net_reward_risk=None,net_reward_points=None,net_risk_points=None,
        status='not_configured',costs_are_actual_fills=False)
    if not g.get('valid'):return dict(result,status='no_valid_price_geometry')
    if policy_status not in ('not_configured','matched'):return dict(result,status='policy_rejected')
    if cost is not None:
        # Symmetric round-trip price-cost scenario, charged once per hypothetical
        # winning/losing path. Not a bid/ask reconstruction or currency PnL.
        risk=g['risk_points']+cost;reward=g['reward_points']-cost
        result.update(net_reward_points=reward,net_risk_points=risk,net_reward_risk=reward/risk)
    if minimum is not None and g['reward_risk']<minimum:
        return dict(result,status='below_minimum_even_before_costs')
    if cost is None:
        return dict(result,status='need_cost_scenario' if minimum is not None else 'not_configured')
    if result['net_reward_points']<=0:return dict(result,status='cost_consumes_reward')
    if minimum is None:return dict(result,status='cost_scenario_only_no_minimum')
    return dict(result,status='passes_bound_scenario' if result['net_reward_risk']>=minimum else 'below_minimum_after_scenario_costs')


def assess(force,*,route,band,trigger_at,trigger_price,stop,target,pattern_state,
           current_reference,task_retired,bars,as_of_utc,review_end_utc,historical_only,policy=None):
    now=epoch(as_of_utc);end=epoch(review_end_utc);known=epoch(force['known_at_utc'])
    if not known<=end<=now:raise ValueError('Space/source review clocks out of order')
    if trigger_at and not known<=epoch(trigger_at)<=end:raise ValueError('Space trigger outside known prefix')
    if number(target) and abs(target-force['points'][1][1])>1e-8:
        raise ValueError('Foreign target cannot be labelled original source C')
    sign=1 if force['points'][1][1]>force['points'][0][1] else -1
    signal=geometry(trigger_price,stop,target,sign)
    visible=[r for r in bars if known<=r['t'] and r['closed']<=end]
    quote=max(visible,key=lambda r:r['closed'],default=None)
    current=geometry(quote['close'],stop,target,sign) if quote else dict(status='unavailable')
    p,p_status=policy_at(policy,force,end)
    trigger_policy,trigger_policy_status=(policy_at(policy,force,epoch(trigger_at)) if trigger_at else (None,'not_configured'))
    drift=(sign*(quote['close']-trigger_price)/signal['risk_points'] if quote and signal.get('valid') else None)
    active=bool(current_reference and pattern_state=='confirmed' and trigger_at and signal.get('valid')
                and not historical_only and not task_retired and current.get('valid'))
    if historical_only:status='historical_only'
    elif task_retired:status='old_target_task_retired'
    elif pattern_state in ('invalidated','completed','ambiguous','not_applicable'):status='route_not_current'
    elif pattern_state!='confirmed':status='waiting_price_trigger'
    elif not quote:status='latest_closed_quote_unavailable'
    elif not current.get('valid'):status='invalid_current_price_geometry'
    elif not active:status='no_current_route_reference'
    else:status='current_price_space_observed'
    current_check=scenario_check(current,p,p_status)
    return dict(schema='force_entry_space_v1',owner_id=force.get('id'),source_id=force.get('source_id'),
        timeframe=force['timeframe'],route=route,band=band,as_of_utc=as_of_utc,review_end_utc=review_end_utc,
        status=status,pattern_state=pattern_state,source_target_task_retired=task_retired,
        protection_reference_price=stop if number(stop) else None,
        target_reference_price=target if number(target) else None,
        trigger_at_utc=trigger_at,signal_geometry=signal,current_closed_geometry=current,
        quote_known_at_utc=iso(quote['closed']) if quote else None,
        quote_age_to_review_seconds=end-quote['closed'] if quote else None,
        quote_basis='last_closed_native_OHLC_not_executable_bid_ask',
        quote_scope='archived_response_window' if historical_only else 'as_of_last_closed_candle',
        movement_from_trigger_in_original_risk_units=drift,
        trigger_scenario=scenario_check(signal,trigger_policy,trigger_policy_status),
        current_scenario=current_check,
        current_price_space_available=active,
        passes_bound_space_scenario=active and current_check['status']=='passes_bound_scenario',
        protection_unchanged=True,target_scope='original_source_C_not_parent_DOL',
        automatic_trade_permission=False,fill_price=None,position_size=None)


def entry_space_plan(force,return_observation,context_plan,bars,*,policy=None):
    result={}
    for band,b in return_observation['bands'].items():
        g=b['trigger_geometry']
        # Ordinary source B/C are already known BEFORE an entry trigger. Keep
        # those references available; never invent the independent sweep's
        # protective extreme while that sweep has not established one yet.
        stop=g.get('protection_price',force['points'][0][1] if band!='127.2' else None)
        target=g.get('response_target_price',force['points'][1][1])
        result['ratio:'+band]=assess(force,route='ratio_reclaim',band=band,
            trigger_at=b['trigger_known_at_utc'],trigger_price=g.get('trigger_close_reference'),
            stop=stop,target=target,pattern_state=b['pattern_state'],
            current_reference=b['current_conditional_reference'],task_retired=b['source_target_task_retired'],
            bars=bars,as_of_utc=return_observation['as_of_utc'],review_end_utc=return_observation['review_end_utc'],
            historical_only=return_observation['historical_only'],policy=policy)
        n=context_plan['node_routes'][band]
        attempt=n.get('current_attempt') or n
        result['node:'+band]=assess(force,route='node_retest',band=band,trigger_at=attempt['trigger_at_utc'],
            trigger_price=attempt['closed_reference'],stop=n['protection_price'] if n['pattern_state']!='not_applicable' else None,
            target=n['response_target_price'],
            pattern_state=n['pattern_state'],current_reference=n['current_reference'],
            task_retired=n.get('reason') in ('source_target_delivered_before_node_trigger','source_target_already_traversed_at_trigger_not_fresh_reference'),
            bars=bars,as_of_utc=return_observation['as_of_utc'],review_end_utc=return_observation['review_end_utc'],
            historical_only=return_observation['historical_only'],policy=policy)
        result['node:'+band].update(node_acceptance_state=n.get('node_acceptance_state'),
            current_attempt_id=n['current_attempt']['attempt_id'] if n.get('current_attempt') else None,
            first_trigger_at_utc=n['trigger_at_utc'])
    return dict(schema='force_entry_space_plan_v1',owner_id=force.get('id'),source_id=force.get('source_id'),
        timeframe=force['timeframe'],routes=result,selected_route=None,
        automatic_trade_permission=False)
