"""Chapter7 pp199-202: the rebound terminal A is not chapter5 boundary A."""
from hashlib import sha256
from math import isfinite
from .book_first_response_leg import clock,close_time


def _predecessor_event_membership(bi, ai, outer, turning, known):
    """Native interval evidence only; containing a break is not author degree."""
    events=[('outer',outer['break_index']),('turning',turning['break_index'])]
    covered=[name for name,index in events if bi<=index<=ai]
    first=min(index for _,index in events)
    return dict(schema='chapter7_predecessor_event_membership_v1',
        B_index=bi,A_index=ai,covered_boundaries=covered,
        contains_first_boundary_break=bi<=first<=ai,
        state='contains_first_boundary_break' if bi<=first<=ai else
              'precedes_first_boundary_break' if ai<first else 'outside_first_boundary_interval',
        known_at_utc=known,author_same_wave_verified=False,
        usable_for_target=False,usable_for_entry=False,
        basis='native_closed_bar_interval_not_author_wave_selection')


def _pdf201_backtrack_review(rows, timeframe, cutoff, response, outer, turning, scope, sign, radius):
    """Preserve the page-201 exception as a causal review packet.

    PDF200 says the later break wave's different origin requires review of
    the preceding wave; outer-first is the *usual*, not mandatory, order.
    A native bar sequence cannot decide
    that author same-degree membership by itself.  It can, however, retain
    every causally confirmed B->A candidate needed for a reviewer or a later
    author-rule adjudicator.  This helper never replaces the protective local
    B and never emits a target.
    """
    local = scope.get('local_B_index')
    prior = scope.get('prior_phase_extreme') or {}
    prior_index = prior.get('index')
    base = dict(schema='chapter7_pdf201_backtrack_review_v1',
                source_pdf_pages=[200,201], status='review_required',
                author_wave1_state='unverified', author_degree_verified=False,
                automatic_trade_permission=False,
                prospective_signal_eligible=False,
                local_final_break_wave_B=dict(index=local, price=scope.get('local_B_price')),
                prior_downtrend_extreme_B=prior,
                outer_break_utc=outer.get('break_utc'), turning_break_utc=turning.get('break_utc'))
    base['review_contract'] = dict(
        pdf_exception='when the later break wave origin differs from the prior trend extreme, retain B-A predecessors for review',
        engineering_facts=['native_B_price_and_timestamp', 'native_A_local_extreme_and_confirmation',
                           'dual_break_order_and_clocks', 'causal_dependency_cutoff'],
        required_author_inputs=['author_wave1_degree_or_period_role',
                                'same_author_wave_membership_of_prior_B_A',
                                'selected_author_source_A_when_multiple_candidates',
                                'manual_page_and_rationale'],
        selection_state='unresolved_until_author_adjudication',
        target_and_entry_permission=False,
        automatic_trade_permission=False,
    )
    oi, ti = outer['break_index'], turning['break_index']
    base['break_order'] = 'outer_first' if oi < ti else 'turning_first' if ti < oi else 'simultaneous'
    base['break_order_basis'] = 'PDF200_usual_order_is_not_a_required_condition'
    if (isinstance(local, bool) or isinstance(prior_index, bool) or
            not isinstance(local, int) or not isinstance(prior_index, int) or
            not 0 <= prior_index < local < len(rows)):
        return dict(base, status='review_evidence_unbound',
                    reason='prior_and_local_B_order_unbound', candidates=[])
    adverse = 'low' if sign > 0 else 'high'
    origin_time, origin_price = response['origin_B']['point']
    if (clock(rows[local]['timestamp_utc']).timestamp() != origin_time or
            scope.get('local_B_price') != origin_price or
            rows[local][adverse] != origin_price):
        return dict(base, status='review_evidence_unbound',
                    reason='local_B_does_not_match_native_response', candidates=[])
    b = prior.get('price')
    if (isinstance(b, bool) or not isinstance(b, (int, float)) or
            not isfinite(b) or b <= 0 or b != rows[prior_index][adverse] or
            prior.get('utc') != rows[prior_index]['timestamp_utc'] or
            sign * (origin_price - b) <= 0):
        return dict(base, status='review_evidence_unbound',
                    reason='prior_B_not_native_or_not_more_extreme', candidates=[])
    try:
        if not clock(close_time(rows[prior_index], timeframe)) <= clock(prior['known_at_utc']) <= clock(cutoff):
            raise ValueError('prior B clock')
    except (KeyError, TypeError, ValueError):
        return dict(base, status='review_evidence_unbound',
                    reason='prior_B_clock_unbound', candidates=[])
    dependencies = [response['known_at_utc'], prior['known_at_utc'],
                    outer['known_at_utc'], turning['known_at_utc']]
    field = 'high' if sign > 0 else 'low'
    b = float(b)
    candidates = []
    # Candidate A must precede the low/high from which the final break wave
    # starts.  Its right-hand confirmation may complete later, but no later
    # than this query cutoff because rows are already physically truncated.
    for index in range(prior_index + radius, local):
        if index + radius >= len(rows):
            break
        value = float(rows[index][field])
        if sign * (value - b) <= 0:
            continue
        if not (all(sign * value >= sign * float(rows[j][field]) for j in range(index-radius, index)) and
                all(sign * value > sign * float(rows[j][field]) for j in range(index+1, index+radius+1))):
            continue
        known = close_time(rows[index + radius], timeframe)
        if clock(known) > clock(cutoff):
            continue
        identity = f"{response.get('owner_id')}|pdf201|{prior_index}|{index}|{value}"
        candidate_known=max([known, *dependencies], key=clock)
        candidates.append(dict(
            source_id='chapter7_pdf201_B_A:' + sha256(identity.encode()).hexdigest()[:24],
            timeframe=timeframe,owner_id=response.get('owner_id'),
            source_wave_id=response.get('source_wave_id'),known_at_utc=candidate_known,
            native_event_membership=_predecessor_event_membership(prior_index,index,outer,turning,candidate_known),
            source_B=dict(index=prior_index, utc=rows[prior_index]['timestamp_utc'], price=b,
                          known_at_utc=prior.get('known_at_utc'),
                          basis='prior_downtrend_extreme_before_later_final_break_wave'),
            source_A=dict(index=index, utc=rows[index]['timestamp_utc'], price=value,
                          known_at_utc=known, role='predecessor_rebound_terminal',
                          confirmation_basis='engineering_radius_not_author_degree'),
            amplitude=sign * (value-b),
            later_final_break_wave_B=dict(index=local, utc=rows[local]['timestamp_utc'],
                                          price=scope.get('local_B_price'),
                                          known_at_utc=max(dependencies, key=clock),
                                          status='context_for_pdf201_exception_not_author_wave2'),
            membership_state='requires_author_same_degree_adjudication',
            causal_facts=dict(
                prior_B_precedes_local_B=True,
                prior_B_confirmed_before_local_B=(clock(prior['known_at_utc']) <= clock(rows[local]['timestamp_utc'])),
                candidate_A_after_prior_B=True,
                candidate_A_before_local_B=True,
                candidate_A_confirmed_by_closed_bar=True,
                candidate_A_before_first_boundary_break=(index < min(oi, ti)),
                break_order=base['break_order'],
                all_dependencies_known_by_cutoff=True,
            ),
            author_review_inputs=dict(
                author_wave1_degree_or_period_role='unknown',
                same_author_wave_membership='unknown',
                selected_author_source_A=None,
                manual_page_and_rationale=None,
            ),
            usable_for_target=False, usable_for_entry=False,
        ))
    candidates.sort(key=lambda c: c['source_A']['index'])
    linked=[c['source_id'] for c in candidates if c['native_event_membership']['contains_first_boundary_break']]
    return dict(base, status='review_required_with_native_candidates' if candidates else 'review_required_no_confirmed_predecessor_rebound',
                reason=('author_same_degree_selection_required' if candidates else
                        'no_confirmed_predecessor_rebound_before_later_final_break_wave'),
                exception_condition='local_B_differs_from_prior_downtrend_extreme_author_membership_unresolved',
                review_known_at_utc=max([*dependencies, *(c['known_at_utc'] for c in candidates)], key=clock),
                candidates=candidates, candidate_count=len(candidates),
                event_linked_candidate_ids=linked,event_linked_candidate_count=len(linked),
                candidate_count_semantics='native_predecessor_rebounds_including_unlinked_internal_rebounds_not_author_matches',
                selection_policy='retain_all_native_predecessor_rebounds_do_not_auto_select_author_wave1')


def bind_chapter7_first_wave(bars,timeframe,cutoff,response,outer,turning):
    base=dict(schema='chapter7_first_wave_binding_v1',timeframe=timeframe,as_of_utc=cutoff,
              source_pdf_pages=[199,200,201,202,203,207],status='unknown',
              author_wave1_state='unverified',author_degree_verified=False,
              automatic_trade_permission=False,source_basis='chapter7_first_rebound_B_A')
    def fail(reason):return dict(base,reason=reason)
    try:
        # R14 is called on every closed prefix.  A malformed optional bar or
        # cutoff must remain an explicit unknown; it must not escape before
        # the binding contract can return a causal rejection.
        cutoff_clock=clock(cutoff)
        rows=[]
        for row in bars:
            try:
                if clock(close_time(row,timeframe))<=cutoff_clock:
                    rows.append(row)
            except (KeyError,TypeError,ValueError,OverflowError):
                return fail('native_prefix_clock_invalid')
        if any(e.get('status')!='observed_candidate' for e in (outer,turning)):
            return fail('dual_break_required')
        oi,ti=outer['break_index'],turning['break_index']
        if any(isinstance(i,bool) or not isinstance(i,int) or not 0<=i<len(rows) for i in (oi,ti)):
            return fail('break_indices_unbound')
        dual_index=max(oi,ti)
        if response.get('status')=='source_invalidated':return fail('B_invalidated')
        side=response['direction'];sign=1 if side=='up' else -1 if side=='down' else 0
        if not sign or any(e.get('break_side')!=side for e in (outer,turning)):
            return fail('direction_mismatch')
        if response.get('timeframe')!=timeframe:return fail('cross_period_response')
        for e,i in ((outer,oi),(turning,ti)):
            if e.get('timeframe',timeframe)!=timeframe or e['break_utc']!=rows[i]['timestamp_utc']:
                return fail('break_identity_unbound')
            if not clock(close_time(rows[i],timeframe))<=clock(e['known_at_utc'])<=clock(cutoff):
                return fail('break_clock_unbound')
        bt,b=response['origin_B']['point']
        bi=next(i for i,r in enumerate(rows) if clock(r['timestamp_utc']).timestamp()==bt)
        adverse,favourable=('low','high') if sign>0 else ('high','low')
        # Both the ordinary and exceptional paths consume this response.
        # Do not let an early review return bypass native B / source clocks.
        if isinstance(b,bool) or not isfinite(float(b)) or b<=0 or rows[bi][adverse]!=b:
            return fail('source_not_native')
        if not bi<=min(oi,ti):return fail('B_first_rebound_A_order_unproven')
        if not clock(close_time(rows[bi],timeframe))<=clock(response['known_at_utc'])<=clock(cutoff):
            return fail('response_clock_unbound')
        radius=response['terminal_confirmation_radius']
        if isinstance(radius,bool) or not isinstance(radius,int) or radius<1:
            return fail('first_rebound_confirmation_unbound')
        scope=response.get('chapter7_B_scope_review') or {}
        if scope.get('required'):
            review = _pdf201_backtrack_review(rows, timeframe, cutoff, response, outer, turning, scope, sign, radius)
            return dict(base,reason=(review['reason'] if review['status']=='review_evidence_unbound'
                                    else 'earlier_phase_extreme_requires_backtrack_review'),
                B_scope_review=scope,author_backtrack_review=review,
                unresolved_prebreak_candidates=review.get('candidates',[]),
                source_selection_ambiguity='pdf201_author_same_degree_backtrack_required',
                next_required='author_same_wave_backtrack_before_replacing_local_B')
        # Search from original B, including the rebound before the outer
        # break. The final breakout response may have a different origin.
        ai=None;prebreak_candidates=[];first_break=min(oi,ti)
        for k in range(bi+radius,len(rows)-radius):
            v=sign*float(rows[k][favourable])
            if (v>sign*b and all(v>=sign*float(rows[j][favourable]) for j in range(k-radius,k))
                    and all(v>sign*float(rows[j][favourable]) for j in range(k+1,k+radius+1))):
                if k<first_break:
                    prebreak_candidates.append(dict(index=k,utc=rows[k]['timestamp_utc'],
                        price=float(rows[k][favourable]),role='prebreak_rebound_needs_author_backtrack',
                        known_at_utc=close_time(rows[k+radius],timeframe)))
                    continue
                ai=k;break
        if ai is None:
            return dict(base,reason='event_linked_rebound_unconfirmed',
                unresolved_prebreak_candidates=prebreak_candidates,
                source_selection_policy='engineering_first_confirmed_terminal_covering_first_boundary_break')
        a=float(rows[ai][favourable]);at=clock(rows[ai]['timestamp_utc']).timestamp()
        if not (bi<=min(oi,ti) and bi<ai):return fail('B_first_rebound_A_order_unproven')
        terminal_known=close_time(rows[ai+radius],timeframe)
        if not clock(close_time(rows[ai],timeframe))<=clock(terminal_known)<=clock(cutoff):
            return fail('first_rebound_unconfirmed')
        if clock(response['known_at_utc'])>clock(cutoff):return fail('future_response')
        if any(isinstance(p,bool) or not isfinite(float(p)) or p<=0 for p in (a,b)):
            return fail('invalid_prices')
        if rows[bi][adverse]!=b or rows[ai][favourable]!=a:return fail('source_not_native')
        height=sign*(a-b)
        if height<=0:return fail('source_direction_mismatch')
        from .book_second_wave_observation import observe_second_wave
        correction=observe_second_wave(rows,timeframe,cutoff,dict(index=bi,price=b),
                                      dict(index=ai,price=a),side,radius)
        if correction.get('status')!='observed_candidate':return fail('wave2_origin_not_observed')
        if sign*(correction['adverse_extreme']['price']-b)<=0:return fail('later_origin_breached_original_B')
        terminal=correction.get('terminal_candidate')
        origin=terminal['price'] if terminal else None
        known=max((response['known_at_utc'],outer['known_at_utc'],turning['known_at_utc'],terminal_known),key=clock)
        # Page200 separates provisional B->A from the later passage beyond A.
        # Observe only after both line breaks. A wick alone is not a closed
        # cross; closed-bar observation is our explicit engineering convention.
        crossed=next((i for i in range(max(dual_index,ai+1),len(rows)) if sign*(float(rows[i]['close'])-a)>0),None)
        cross_known=max((known,close_time(rows[crossed],timeframe)),key=clock) if crossed is not None else known
        transition=dict(status='closed_cross_observed' if crossed is not None else 'waiting_A_cross',
            reference_price=a,known_at_utc=cross_known,
            closed_reference_price=float(rows[crossed]['close']) if crossed is not None else None,
            event_closed_at_utc=close_time(rows[crossed],timeframe) if crossed is not None else None,
            cross_utc=rows[crossed]['timestamp_utc'] if crossed is not None else None,
            observation_basis='closed_bar_engineering_convention',
            author_third_wave_confirmed=False)
        ruler_known=response.get('ruler_known_at_utc')
        ruler_timing=('unknown' if not ruler_known else 'known_before_break'
            if clock(ruler_known)<=clock(rows[oi]['timestamp_utc']) else 'historical_reconstruction')
        fact_known=max((cross_known,correction.get('known_at_utc') or cross_known),key=clock)
        from .book_target_path import observe_target_options
        target_options=(observe_target_options(rows,timeframe,cutoff,origin,height,side,
            correction['A_cross_utc'],transition['cross_utc'],fact_known) if terminal else [])
        target_path=(target_options[-1]['target_path_observation'] if target_options else
                     dict(status='unknown',reason='correction_terminal_unresolved'))
        return dict(base,status='candidate_bound_to_prior_B_A' if terminal else 'candidate_source_without_projection_origin',
            reason=None if terminal else 'correction_terminal_unresolved',owner_id=response['owner_id'],
            source_selection_policy='engineering_first_confirmed_terminal_covering_first_boundary_break',
            unresolved_prebreak_candidates=prebreak_candidates,
            source_selection_ambiguity=('prebreak_rebounds_need_author_review' if prebreak_candidates else 'author_degree_still_unknown'),
            source_membership_evidence=dict(native_timeframe=timeframe,
                B_utc=rows[bi]['timestamp_utc'],terminal_A_utc=rows[ai]['timestamp_utc'],
                covered_breaks=[name for name,index in (('outer',oi),('turning',ti)) if bi<=index<=ai],
                basis='native_interval_event_membership_not_author_degree'),
            native_event_membership=_predecessor_event_membership(bi,ai,outer,turning,fact_known),
            source_branch=('prior_rebound_before_dual_completion' if ai<dual_index
                           else 'first_rebound_contains_dual_completion'),
            source_id='chapter7_B_A:'+sha256(f"{response['owner_id']}|{at}|{a}".encode()).hexdigest()[:24],
            source_wave_id=response.get('source_wave_id'),known_at_utc=fact_known,
            source_known_at_utc=known,A_cross_observation=transition,
            target_path_observation=target_path,
            third_wave_target_options=target_options,
            second_wave_observation=correction,
            wave_membership_state=response.get('wave_membership_state','unknown'),
            ruler_known_at_utc=ruler_known,ruler_timing=ruler_timing,
            source_B=dict(index=bi,utc=rows[bi]['timestamp_utc'],price=b),
            source_A=dict(index=ai,utc=rows[ai]['timestamp_utc'],price=a,
                role='chapter7_first_rebound_terminal',known_at_utc=terminal_known,
                confirmation_basis='engineering_radius_not_author_degree'),
            later_response_origin=terminal,
            projection_origin_status=correction['terminal_status'],
            amplitude=height,projection_1618=origin+sign*height*1.618 if terminal else None,
            prospective_signal_eligible=False)
    except (KeyError,TypeError,ValueError,StopIteration):return fail('incomplete_source_binding')
