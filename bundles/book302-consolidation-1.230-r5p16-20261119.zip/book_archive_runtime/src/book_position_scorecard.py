"""Causal, source-bound position measurements, not an entry probability.

Scores have explicit formulas/roles. A risk constraint is not compensated
by unrelated high scores. Research fitting lives outside this module.
"""
from math import isfinite,isclose
from statistics import mean,pstdev
from copy import deepcopy
from .book_first_response_leg import clock,close_time,MINUTES,first_response_leg
from .book_breakout_assessment import assess_breakouts

GROUPS={
    'geometry':['outer_geometry','turning_geometry'],
    'breakout':['outer_breakout','turning_breakout'],
    'boundary':['outer_hold','turning_hold'],
    'momentum':['directional_efficiency_8'],
    'candles':['directional_body_8','path_cleanliness_8','range_stability_8'],
    'pullback':['pullback_zone'], 'space':['gross_target_space'],
    'force':['source_BC_force'], 'one_to_one':['one_to_one','one_to_one_delivery'],
    'parent':['parent_alignment'], 'risk':['quote_risk'],
    'native_wave_scope':['native_source_wave_force','native_parent_wave_force','native_scope_bottleneck']}
FEATURE_NAMES=[k for group in GROUPS.values() for k in group]


def _unified_geometry_observation(book,timeframe,cutoff,unified_geometry):
    """Bind an optional Unified outer audit without borrowing its score.

    The two namespaces stay independent.  A Unified audit can support Book
    geometry only when its explicit wave/phase identity and clock match.  No
    numeric confluence is created from a line that merely happens to be on the
    same chart.
    """
    assessment=book.get('boundary_breakout_assessment') or {}
    book_phase=book.get('phase_id') or assessment.get('phase_id')
    book_source=book.get('source_id') or assessment.get('source_id')
    base=dict(schema='unified_book_geometry_binding_v1',state='unknown',score=None,
        reason='unified_geometry_not_supplied',timeframe=timeframe,as_of_utc=cutoff,
        owner_id=None,wave_id=None,phase_id=book_phase,source_id=book_source,
        source_namespace='Unified',book_namespace='Book',automatic_trade_permission=False,
        contributes_to_composite=False)
    if not isinstance(unified_geometry,(list,tuple)):
        return base
    line=book.get('turning_point_line') or {}
    wave_id=line.get('wave_id')
    phase_id=book_phase
    candidate_wave_ids={
        row.get('canonical_wave_id') or row.get('wave_id')
        for row in (book.get('native_wave_candidates') or [])
        if isinstance(row,dict) and (row.get('canonical_wave_id') or row.get('wave_id'))
    }
    candidate_lineage_ids={
        row.get('wave_lineage_id')
        for row in (book.get('native_wave_candidates') or [])
        if isinstance(row,dict) and row.get('wave_lineage_id')
    }
    # A malformed optional Unified row is untrusted input.  It must become an
    # unavailable candidate, never an exception that aborts the Book scorecard
    # for the current closed prefix.
    try:
        cutoff_clock=clock(cutoff)
    except (TypeError,ValueError,OverflowError):
        cutoff_clock=None
    candidates=[]
    for row in unified_geometry:
        if not isinstance(row,dict):continue
        audit=row.get('audit') if isinstance(row.get('audit'),dict) else row
        known=row.get('known_at_utc') or audit.get('known_at_utc')
        if row.get('timeframe',timeframe)!=timeframe or not known or cutoff_clock is None:
            continue
        try:
            if clock(known)>cutoff_clock:
                continue
        except (TypeError,ValueError,OverflowError):
            # Preserve the valid rows in this batch; a bad optional row does
            # not contaminate the native Book namespace or crash the prefix.
            continue
        candidates.append((row,audit))
    base['candidate_count']=len(candidates)
    matches=[]
    for row,audit in candidates:
        candidate_wave=row.get('canonical_wave_id') or audit.get('canonical_wave_id') or row.get('wave_id') or audit.get('wave_id')
        candidate_phase=row.get('phase_id') or audit.get('phase_id')
        wave_match=(wave_id and candidate_wave==wave_id) or (not wave_id and candidate_wave in candidate_wave_ids)
        # A wave id is not a phase identity.  Missing phase metadata must stay
        # unknown; otherwise a stale Unified object from another phase can be
        # selected merely because its ruler happened to reuse the wave id.
        phase_match=bool(phase_id) and candidate_phase==phase_id
        if wave_match and phase_match:
            matches.append((row,audit))
    if not matches:
        lineage_matches=[]
        for row,audit in candidates:
            lineage=row.get('wave_lineage_id') or audit.get('wave_lineage_id')
            if lineage in candidate_lineage_ids:
                lineage_matches.append((row,audit,lineage))
        if lineage_matches:
            row,audit,lineage=lineage_matches[0]
            book_candidate=next((x for x in (book.get('native_wave_candidates') or [])
                                 if isinstance(x,dict) and x.get('wave_lineage_id')==lineage),{})
            from .book_wave_revision_reconciliation import reconcile_book_unified_revision
            revision = reconcile_book_unified_revision(
                book_candidate,
                dict(audit, direction=row.get('direction') or audit.get('direction'),
                     wave_lineage_id=lineage,
                     known_at_utc=row.get('known_at_utc') or audit.get('known_at_utc'),
                     timeframe=row.get('timeframe',timeframe)),
                timeframe=timeframe, cutoff=cutoff, phase_id=phase_id)
            from .book_revision_rebuild import propose_book_revision_rebuild
            proposal=propose_book_revision_rebuild(
                book_candidate,
                dict(audit,direction=row.get('direction') or audit.get('direction'),
                     canonical_wave_id=row.get('canonical_wave_id') or audit.get('canonical_wave_id'),
                     wave_lineage_id=lineage,
                     known_at_utc=row.get('known_at_utc') or audit.get('known_at_utc'),
                     timeframe=row.get('timeframe',timeframe)),
                timeframe=timeframe,cutoff=cutoff,phase_id=phase_id)
            base['state']='review_unknown'
            base.update(wave_lineage_id=lineage, audit_revision_reconciliation=revision,
                revision_rebuild_proposal=proposal,
                reason=('same_wave_revision_mismatch' if revision.get('reason')=='pivot_revision_mismatch'
                        else revision.get('reason') or 'same_wave_revision_mismatch'),
                revision_status=revision.get('revision_status'),
                common_confirmed_pivot_count=revision.get('common_confirmed_pivot_count'),
                book_revision_pivot_times=revision.get('book_pivot_times'),
                unified_revision_pivot_times=revision.get('unified_pivot_times'),
                book_revision_known_at_utc=revision.get('book_known_at_utc'),
                unified_revision_known_at_utc=revision.get('unified_known_at_utc'),
                phase_match=revision.get('phase_bound',False),
                score_blockers=(['pivot_revision_mismatch'] if not revision.get('exact_pivot_revision') else [])+
                    (['book_phase_unbound'] if not revision.get('phase_bound') else []),
                next_action=revision.get('next_action'))
        else:
            base['reason']='unified_geometry_same_wave_not_bound'
        return base
    if len(matches)>1:
        base['reason']='unified_geometry_duplicate_same_wave'
        base['wave_id']=matches[0][1].get('wave_id')
        return base
    row,audit=matches[0]
    # Even an equal canonical ID must pass the full pivot/clock reconciliation
    # when a Book candidate is available.  This keeps the consumer safe if a
    # producer accidentally reuses an ID while changing the pivot revision.
    book_candidate=next((x for x in (book.get('native_wave_candidates') or [])
                         if isinstance(x,dict) and
                         (x.get('canonical_wave_id') or x.get('wave_id')) in
                         {row.get('canonical_wave_id'),row.get('wave_id'),audit.get('canonical_wave_id'),audit.get('wave_id')}),{})
    if book_candidate:
        from .book_wave_revision_reconciliation import reconcile_book_unified_revision
        revision=reconcile_book_unified_revision(
            book_candidate,
            dict(audit,direction=row.get('direction') or audit.get('direction'),
                 wave_lineage_id=row.get('wave_lineage_id') or audit.get('wave_lineage_id'),
                 known_at_utc=row.get('known_at_utc') or audit.get('known_at_utc'),
                 timeframe=row.get('timeframe',timeframe)),
            timeframe=timeframe,cutoff=cutoff,phase_id=phase_id)
        if revision.get('state')!='same_revision':
            base.update(state='review_unknown',reason='same_wave_revision_mismatch',
                audit_revision_reconciliation=revision,
                revision_status=revision.get('revision_status'),
                common_confirmed_pivot_count=revision.get('common_confirmed_pivot_count'),
                next_action=revision.get('next_action'),contributes_to_composite=False)
            return base
    state=row.get('state') or audit.get('calibrated_state') or audit.get('state') or 'review_unknown'
    score=row.get('geometry_score',audit.get('geometry_score'))
    base.update(state=state,wave_id=row.get('canonical_wave_id') or audit.get('canonical_wave_id') or row.get('wave_id') or audit.get('wave_id'),
        owner_id=row.get('owner_id') or audit.get('owner_id'),
        known_at_utc=row.get('known_at_utc') or audit.get('known_at_utc'),
        audit=deepcopy(audit),score=None,contributes_to_composite=False)
    if state not in ('measured','measured_candidate'):
        base['reason']='unified_geometry_not_calibrated'
        return base
    if isinstance(score,bool) or not isinstance(score,(int,float)) or not isfinite(score) or not 0<=score<=100:
        base['state']='review_unknown';base['reason']='unified_geometry_score_missing_or_invalid'
        return base
    # This is only a candidate. Native reconstruction later decides whether
    # the same *ruler and formula* support the value, independently of wave ID.
    base.update(score=round(float(score),6),reason=None,eligible_for_native_validation=True,
        contributes_to_composite=False,
        calibration=audit.get('calibration','unfitted_descriptive'))
    return base


def _corroborate_unified_geometry(observation,card,native_factor,book,rows,timeframe,cutoff,reason):
    """Never let an external score resurrect or replace unverified geometry.

    Book and Unified keep their own measurements. A duplicate Book vote can
    only be corroborated if its native anchors, boundary, source and formula
    reproduce the supplied value. A different ruler needs its own namespace.
    """
    if not (observation.get('eligible_for_native_validation') or observation.get('contributes_to_composite')):
        return observation
    result=dict(observation,contributes_to_composite=False)
    def reject(why):
        return dict(result,state='review_unknown',reason=why,score=None)
    if reason:return reject('native_scorecard_rejected:'+reason)
    if card.get('vetoes'):return reject('native_scorecard_veto')
    if (native_factor.get('state')!='measured' or native_factor.get('score') is None or
            not card.get('source_id') or not card.get('phase_id')):
        return reject('native_outer_geometry_unavailable')
    if observation.get('phase_id')!=card['phase_id']:
        return reject('unified_geometry_phase_not_native_bound')
    try:
        audit=observation.get('audit') or {}
        line=book['turning_point_line']
        for n,stem in ((1,'start'),(2,'end')):
            anchor=audit.get('outer_anchor_'+str(n)) or {}
            i=line[stem+'_index']; value=anchor.get('price')
            if (type(anchor.get('index')) is not int or anchor['index']!=i or
                    anchor.get('timestamp_utc')!=rows[i]['timestamp_utc'] or
                    isinstance(value,bool) or not isinstance(value,(int,float)) or
                    not isfinite(value) or value!=line[stem+'_price']):
                return reject('unified_geometry_different_or_missing_native_anchors')
        slope=audit.get('selected_slope')
        if (isinstance(slope,bool) or not isinstance(slope,(int,float)) or not isfinite(slope) or
                not isclose(slope,line['slope'],rel_tol=1e-12,abs_tol=1e-12)):
            return reject('unified_geometry_different_native_slope')
        outer=(book['boundary_breakout_assessment']['boundaries']['outer'])
        if (audit.get('boundary_id')!=outer.get('boundary_id') or
                audit.get('source_identity')!=card.get('source_identity')):
            return reject('unified_geometry_native_boundary_not_bound')
        geometry=outer.get('geometry') or {}
        if not geometry.get('score_version') or audit.get('score_version')!=geometry['score_version']:
            return reject('unified_geometry_score_formula_not_reproduced')
        score=observation.get('score')
        if (isinstance(score,bool) or not isinstance(score,(int,float)) or not isfinite(score) or
                not 0<=score<=100 or not isclose(score,native_factor['score'],rel_tol=0,abs_tol=1e-6)):
            return reject('unified_geometry_score_not_native_reproduced')
        known=clock(observation['known_at_utc'])
        if not clock(native_factor['known_at_utc'])<=known<=clock(cutoff):
            return reject('unified_geometry_native_clock_mismatch')
    except (KeyError,TypeError,ValueError,IndexError,ArithmeticError):
        return reject('unified_geometry_native_evidence_incomplete')
    return dict(result,contributes_to_composite=True,native_validation='same_ruler_formula_and_score_reproduced',
        source_id=card['source_id'],boundary_pair_id=card.get('boundary_pair_id'))


def position_scorecard(bars,timeframe,cutoff,book,owned_force=None,one_to_one=None,unified_geometry=None):
    factors={k:dict(state='unknown',score=None,reason='native_bound_measurement_unavailable') for k in FEATURE_NAMES}
    from .book_author_review import author_review_context,author_review_gate
    author=author_review_context(book,timeframe,cutoff,bars)
    result=dict(schema='book_position_scorecard_v1',timeframe=timeframe,as_of_utc=cutoff,
        factors=factors,groups=GROUPS,stage='unknown',vetoes=[],conflicts=[],
        automatic_trade_permission=False,entry_permission=False,calibrated_joint_score=None,
        calibration_status='descriptive_components_joint_model_not_accepted',
        score_semantics='0_100_formula_measurements_not_accuracy_or_win_probability',
        fusion_rules=dict(compensation_between_groups=False,missing_is_not_zero=True,
            dependent_families=[dict(factors=['directional_efficiency_8','directional_body_8'],basis='shared_recent_directional_price_path'),
                dict(factors=['one_to_one','one_to_one_delivery'],basis='shared_delivery_input; separate_local_and_larger_breakout_scopes_not_independent_votes'),
                dict(factors=['pullback_zone','gross_target_space'],basis='same_B_C_current_close; gross_target_space=100*retracement when B<price<C in signed coordinates')],
            independent_votes_from_dependent_factors=False),
        source_pdf_pages=[21,27,28,135,136,137,199,200,201,202,279,280],
        author_review_context=author,
        author_review_gate=author_review_gate(author))
    result['unified_geometry_observation']=_unified_geometry_observation(book,timeframe,cutoff,unified_geometry)
    def finish(reason=None):
        if reason:
            for k in factors:factors[k]=dict(state='unknown',score=None,reason=reason)
        from .book_native_wave_process import score_book_wave_process,FACTORS
        scope=score_book_wave_process(bars,timeframe,cutoff,book,dict(result,reason=reason))
        result['native_wave_process']=scope
        profiles=[scope.get('source_profile'),scope.get('parent_profile')]
        values=[(profiles[0] or {}).get('score'),(profiles[1] or {}).get('score'),scope.get('bottleneck_score')]
        clocks=[scope.get('source_measurement_known_at_utc'),scope.get('parent_measurement_known_at_utc'),scope.get('known_at_utc')]
        for name,value,profile,known in zip(FACTORS,values,[*profiles,None],clocks):
            factors[name]=dict(state='measured' if not reason and value is not None else 'unknown',
                score=value if not reason else None,reason=reason or scope.get('reason'),
                formula='existing native path force; bottleneck=min(source,parent), never child substitution',
                role='native_wave_scope_measurement_not_author_degree',phase_id=result.get('phase_id'),
                source_id=result.get('source_id'),known_at_utc=known,
                raw=dict(scope_id=(profile or {}).get('scope_id'),range_version=(profile or {}).get('range_version'),
                    eligible_for_score_gate=scope.get('eligible_for_score_gate',False),
                    source_scope_id=scope.get('source_scope_id'),parent_scope_id=scope.get('parent_scope_id'),
                    parent_relation=scope.get('parent_relation'),formation_through_utc=scope.get('formation_through_utc'),
                    membership_receipt=scope.get('membership_receipt'),measurement_receipt=scope.get('measurement_receipt')))
        # Unified geometry may replace the Book outer-geometry vote only when
        # the exact native revision and phase were bound.  A lineage match or
        # a merely drawn line is deliberately insufficient; this prevents a
        # later pivot revision from double-voting with the earlier Book ruler.
        unified=_corroborate_unified_geometry(result.get('unified_geometry_observation') or {},result,
            factors['outer_geometry'],book,bars,timeframe,cutoff,reason)
        result['unified_geometry_observation']=unified
        if (unified.get('contributes_to_composite') is True and
                unified.get('state') in ('measured','measured_candidate') and
                isinstance(unified.get('score'),(int,float)) and
                not isinstance(unified.get('score'),bool)):
            factors['outer_geometry']=dict(
                state='measured',score=round(float(unified['score']),6),
                formula='exact_same_revision_unified_outer_geometry',
                role='unified_exact_revision_geometry_replaces_duplicate_outer_vote',
                known_at_utc=unified.get('known_at_utc') or cutoff,
                phase_id=result.get('phase_id'),source_id=result.get('source_id'),
                calibration=unified.get('calibration','unfitted_descriptive'),
                raw=dict(unified_geometry_observation=deepcopy(unified)))
        available=[k for k,v in factors.items() if v['score'] is not None]
        result.update(reason=reason,coverage=dict(measured=len(available),total=len(factors),
            missing=[k for k in factors if k not in available]))
        core=['outer_geometry','turning_geometry','outer_breakout','turning_breakout',
              'outer_hold','turning_hold','source_BC_force','pullback_zone']
        result['joint_diagnostic']=dict(state='complete' if all(k in available for k in core) else 'incomplete',
            bottleneck_floor=min(factors[k]['score'] for k in core) if all(k in available for k in core) else None,
            required=core,missing=[k for k in core if k not in available],
            semantics='minimum_of_complete_same_source_measurements_not_learned_probability',
            may_override_vetoes=False)
        return result
    def put(name,value,formula,role,known=None,raw=None):
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not isfinite(value) or not 0<=value<=100:return
        factors[name]=dict(state='measured',score=round(float(value),6),formula=formula,role=role,
            known_at_utc=known or cutoff,raw=raw,phase_id=result.get('phase_id'),
            source_id=result.get('source_id'),calibration='unfitted_descriptive')
    try:
        rows=[r for r in bars if clock(close_time(r,timeframe))<=clock(cutoff)]
        if book.get('timeframe')!=timeframe or book.get('as_of_utc')!=cutoff:
            return finish('book_clock_or_timeframe_mismatch')
        line_known=(book.get('turning_point_line') or {}).get('known_at_utc')
        if not line_known or clock(line_known)>clock(cutoff):return finish('outer_source_not_known_at_cutoff')
        if not author['r01_same_degree']['native_ruler_review']['native_source_proof']['qualified']:
            return finish('native_outer_ruler_not_reproduced')
        actual=assess_breakouts(rows,timeframe,cutoff,book.get('turning_point_line') or {},
            book.get('turning_boundary') or {},book.get('first_closed_break') or {},book.get('parallel_break') or {})
        supplied=book.get('boundary_breakout_assessment') or {}
        if supplied.get('as_of_utc')!=cutoff or supplied.get('timeframe')!=timeframe:
            return finish('assessment_clock_or_timeframe_mismatch')
        if actual.get('status')!='evaluated':
            return finish(actual.get('reason') or 'native_boundary_source_unavailable')
        if any(actual.get(k)!=supplied.get(k) for k in
                ('phase_id','boundary_pair_id','source_identity','direction')):return finish('source_binding_mismatch')
        result.update(phase_id=actual['phase_id'],boundary_pair_id=actual.get('boundary_pair_id'),
            source_identity=actual['source_identity'],direction=actual['direction'],
            position_price=float(rows[-1]['close']),position_close_utc=close_time(rows[-1],timeframe))
        sign=1 if actual['direction']=='up' else -1
        response=first_response_leg(rows,book['turning_point_line'],book.get('first_closed_break') or {},timeframe,cutoff)
        result['source_id']=response.get('source_id')
        for name,b in actual['boundaries'].items():
            old=(supplied.get('boundaries') or {}).get(name,{})
            if b.get('status')!='scored':
                proof=b.get('rejected_native_construction_validation') or b.get('native_construction_validation') or {}
                for suffix in ('geometry','breakout','hold'):
                    factors[name+'_'+suffix]['reason']=b.get('construction_reason') or proof.get('reason') or b.get('reason') or b.get('status')
                continue
            if any(old.get(k)!=b.get(k) for k in ('boundary_id','geometry_score','breakout_score')):
                return finish('supplied_boundary_score_mismatch')
            if not clock(b['known_at_utc'])<=clock(old['known_at_utc'])<=clock(cutoff):return finish('boundary_clock_mismatch')
            put(name+'_geometry',b['geometry_score'],'existing frozen native geometry components','geometry',old['known_at_utc'])
            put(name+'_breakout',b['breakout_score'],'existing frozen two-close boundary response','initial_response',old['known_at_utc'])
            dynamic=b.get('dynamic_observation') or {}
            if dynamic.get('state')!='unknown' and dynamic.get('features'):
                put(name+'_hold',100*dynamic['features']['outside_close_fraction'],
                    '100 * outside_closes / observed_closes_since_break','historical_hold_fraction',
                    raw=dict(current_state=dynamic['state'],distance_atr=dynamic['features']['current_distance_atr']))
        recent=rows[-8:]
        if len(recent)==8:
            valid=all(all(not isinstance(r[k],bool) and isfinite(float(r[k])) and float(r[k])>0 for k in ('open','high','low','close'))
                and r['low']<=min(r['open'],r['close'])<=max(r['open'],r['close'])<=r['high'] for r in recent)
            contiguous=all((clock(b['timestamp_utc'])-clock(a['timestamp_utc'])).total_seconds()==MINUTES[timeframe]*60 for a,b in zip(recent,recent[1:]))
            if valid and contiguous:
                changes=[float(b['close'])-float(a['close']) for a,b in zip(recent,recent[1:])]
                travel=sum(abs(v) for v in changes);spans=[float(r['high'])-float(r['low']) for r in recent]
                efficiency=sign*sum(changes)/travel if travel else 0.
                body=sign*sum(float(r['close'])-float(r['open']) for r in recent)/sum(spans) if sum(spans) else 0.
                overlaps=[max(0,min(a['high'],b['high'])-max(a['low'],b['low']))/max(min(sa,sb),1e-12)
                          for a,b,sa,sb in zip(recent,recent[1:],spans,spans[1:])]
                put('directional_efficiency_8',50+50*efficiency,'50 + 50 * signed_net_change / total_close_travel','directional_momentum')
                put('directional_body_8',50+50*body,'50 + 50 * signed_sum_bodies / sum_ranges','directional_candles')
                put('path_cleanliness_8',100*(1-mean(overlaps)),'100 * (1 - mean_adjacent_range_overlap)','path_overlap_not_direction')
                if mean(spans)>0:put('range_stability_8',100/(1+pstdev(spans)/mean(spans)),
                    '100 / (1 + range_coefficient_of_variation)','volatility_consistency_not_entry_quality')
            else:
                for name in GROUPS['momentum']+GROUPS['candles']:factors[name]['reason']='recent_native_gap_or_invalid_OHLC'
        result['stage']=response.get('status','unknown')
        if response.get('status')=='source_invalidated':result['vetoes'].append('original_B_invalidated')
        if response.get('status')=='confirmed_source':
            bp=response['origin_B']['point'][1];cp=response['terminal_C']['point'][1];price=float(rows[-1]['close'])
            height=sign*(cp-bp);pullback=sign*(cp-price)/height
            distance=max(.4-pullback,0.,pullback-.8)
            put('pullback_zone',100*max(0.,1-distance/.4),
                '100 inside book40-80; linear descriptive decay to0 over40 percentage points outside','zone_proximity_not_reversal',
                raw=dict(retracement_fraction=pullback,book_zone=[.4,.8],decay_is_engineering=True))
            risk=sign*(price-bp);space=sign*(cp-price)
            if risk>0 and space>0:
                rr=space/risk;put('gross_target_space',100*rr/(1+rr),'100 * gross_RR / (1 + gross_RR)',
                    'close_to_source_C_space_excludes_spread_slippage_and_costs',raw=dict(gross_rr=rr,stop=bp,target=cp))
            else:result['vetoes'].append('source_C_or_B_not_a_forward_plan')
            result['stage']='pullback_in_book_zone' if .4<=pullback<=.8 else 'outside_book_pullback_zone'
        force=owned_force or {}
        if (force.get('source_binding_state')=='same_native_boundary_pair_and_force_verified' and
                force.get('phase_id')==actual['phase_id'] and force.get('source_id')==response.get('source_id') and
                force.get('boundary_pair_id')==actual.get('boundary_pair_id') and
                force.get('source_identity')==actual.get('source_identity') and
                clock(force['force_known_at_utc'])<=clock(cutoff) and
                force.get('as_of_utc')==cutoff and force.get('timeframe')==timeframe):
            put('source_BC_force',force.get('force_score'),'existing native whole BC force components','frozen_source_force',
                force.get('force_known_at_utc'),raw=dict(qualification=force.get('state')))
        review=one_to_one or {}
        if (review.get('state') in ('same_source_developing_reference','same_phase_research_ready') and
                review.get('phase_id')==actual['phase_id'] and review.get('book_source_id')==response.get('source_id') and
                clock(review['known_at_utc'])<=clock(cutoff) and
                review.get('as_of_utc')==cutoff and review.get('working_timeframe')==timeframe):
            quantitative=review.get('quantitative_score')
            local=(review.get('quantitative_score_receipt') or {}).get('local_delivery') or {}
            if local.get('status')=='measured':
                put('one_to_one_delivery',local.get('score'),local.get('formula'),'local_second_leg_delivery_not_larger_structure_breakout',review.get('known_at_utc'),raw=local)
            if (review.get('quantitative_score_state')=='measured' and quantitative is not None):
                put('one_to_one',quantitative,'validated minimum(delivery,frozen structure,current structure); profile/speed/depth diagnostic only','second_leg_research',review.get('known_at_utc'),raw=review.get('quantitative_score_receipt'))
            else:
                factors['one_to_one']['reason']='quantitative_1_to_1_receipt_'+str(review.get('quantitative_score_state','unknown'))
        factors['parent_alignment']['reason']='native_parent_numeric_adapter_not_validated'
        factors['quote_risk']['reason']='no_executable_quote_cost_and_account_risk_in_closed_bar_scorecard'
        if any((b.get('dynamic_observation') or {}).get('state') in ('returned_inside','on_boundary') for b in actual['boundaries'].values()):
            result['conflicts'].append('initial_break_exists_but_current_boundary_not_held')
        momentum=factors['directional_efficiency_8']['score']
        if momentum is not None and momentum<50:result['conflicts'].append('recent_close_path_opposes_break_direction')
        return finish()
    except (KeyError,ValueError,TypeError,IndexError,ArithmeticError):
        # Partial evidence is never re-labelled complete on malformed input.
        for k in factors:factors[k]=dict(state='unknown',score=None,reason='native_source_or_clock_incomplete')
        return finish('native_source_or_clock_incomplete')


def check_position_score_requirements(card,requirements):
    """Explicit AND requirements; no fitted cutoff is invented here."""
    base=dict(schema='book_position_score_gate_v1',automatic_trade_permission=False,
        policy_basis='explicit_unfitted_research_ranges',may_override_other_entry_gates=False)
    # A scorecard can be structurally invalid even when the caller did not
    # request numeric ranges.  ``not_requested`` must never turn a native
    # source/clock mismatch into an entry candidate.
    structural=[]
    if card.get('reason'):structural.append('scorecard:'+str(card['reason']))
    if card.get('vetoes'):structural.extend(str(v) for v in card['vetoes'])
    if structural:
        return dict(base,state='wait',failures=structural,
            reason='scorecard_source_or_upstream_veto',requirements=requirements)
    if requirements is None:return dict(base,state='not_requested',failures=[])
    if not isinstance(requirements,dict) or not requirements:return dict(base,state='invalid_policy',failures=['nonempty_factor_range_map_required'])
    failures=[]
    for name,interval in requirements.items():
        if name not in FEATURE_NAMES or not isinstance(interval,dict) or set(interval)!={'min','max'}:
            return dict(base,state='invalid_policy',failures=['unknown_factor_or_range_schema'])
        lo,hi=interval['min'],interval['max']
        if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not isfinite(v) for v in (lo,hi)) or not 0<=lo<=hi<=100:
            return dict(base,state='invalid_policy',failures=['invalid_factor_range'])
        factor=(card.get('factors') or {}).get(name) or {};v=factor.get('score')
        if name in ('native_source_wave_force','native_parent_wave_force','native_scope_bottleneck') and not (factor.get('raw') or {}).get('eligible_for_score_gate'):
            failures.append(name+':native_scope_not_eligible')
        elif factor.get('state')!='measured' or v is None:failures.append(name+':unknown')
        elif not lo<=v<=hi:failures.append(name+':outside_selected_range')
    if card.get('vetoes'):failures.extend(card['vetoes'])
    return dict(base,state='wait' if failures else 'satisfied',failures=failures,requirements=requirements)
