"""Reuse identical native wave work within one complete Book calculation.

The scope ends with that calculation. No result survives a new quote, request,
history window or engine revision. Copies preserve independent score consumers.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
from .book_evidence_copy import copy_evidence
from .broker_live_engine import canonical
from .book_calculation_cancel import check_current

_SCOPE=ContextVar('book_complete_wave_scope',default=None)
_INDEPENDENT_AXIS=ContextVar('book_independent_axis_policy',default=False)


@contextmanager
def independent_axis_policy():
    """Opt-in for Book producers; ordinary/Unified callers stay unchanged."""
    token=_INDEPENDENT_AXIS.set(True)
    try:yield
    finally:_INDEPENDENT_AXIS.reset(token)


def independent_axis_enabled():return _INDEPENDENT_AXIS.get()


def measure_axis(bars,start,anchor,terminal,slope,*,reference_start=None):
    check_current()
    from .book_complete_wave_channels import owned_axis_measurement
    from .broker_live_engine import SECONDS,iso
    from datetime import datetime
    first=start if reference_start is None else reference_start
    rows=bars[first:terminal+1]
    dependency=bars[max(terminal,anchor)] if rows else None
    tf=dependency.get('timeframe') if dependency else None
    known=(iso(datetime.fromisoformat(dependency['timestamp_utc'].replace('Z','+00:00')).timestamp()+SECONDS[tf])
           if rows and tf in SECONDS else None)
    measured=owned_axis_measurement(rows,slope,known_at=known)
    drift=measured.get('alignment_measure')
    return dict(measured,score=None,ranking_value=-drift if drift is not None else -1e300,
        score_version='book_independent_native_axis_rank_v1',terminal_index=terminal,
        reference_start_index=first,source_contact_index=start,second_contact_index=anchor,
        rank_policy='independent_fixed_native_scope_drift_then_span',
        scope_role=('fixed_selection_prefix_not_author_wave_membership' if reference_start is not None
                    else 'declared_source_interval_not_author_wave_membership'),
        author_degree_verified=False,future_bars_used=False,research_only=True)


@contextmanager
def calculation_scope():
    if _SCOPE.get() is not None:
        yield
        return
    token=_SCOPE.set({})
    try:yield
    finally:_SCOPE.reset(token)


def reuse_native_wave_process(function):
    @wraps(function)
    def call(bars,timeframe,cutoff,*,bound_origin=None):
        check_current()
        scope=_SCOPE.get()
        if scope is None:
            return function(bars,timeframe,cutoff,bound_origin=bound_origin)
        # Exact serialized inputs, including identities and origin knowledge
        # clock. Same timestamps alone never authorize reuse after correction.
        key=canonical([bars,timeframe,cutoff,bound_origin,independent_axis_enabled()])
        if key in scope:return copy_evidence(scope[key])
        result=function(bars,timeframe,cutoff,bound_origin=bound_origin)
        if len(scope)>=8:scope.pop(next(iter(scope)))
        scope[key]=copy_evidence(result)
        return result
    return call
