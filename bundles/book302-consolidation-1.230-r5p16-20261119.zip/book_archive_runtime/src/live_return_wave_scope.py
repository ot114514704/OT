"""Source-connected return paths, not a timeframe-to-wave-degree shortcut.

Source grounding: Alexander 7676543496751127699 (what preceding structure
is handled determines the adjustment), 7605363360134535055 (the return
belongs to the complete blue advance), 7652526864210270350 (return of a
whole earlier 1:1). A native M30 pivot alone proves none of those roles.

This component binds the native path so the structural decision has an
actual object to adjudicate. It does not turn connected geometry into
semantic completion, use M5 anchors on M30, or infer a fixed degree ladder.
"""
from hashlib import sha256

from .live_nested_stage_review import _same, _time, _number, geometric_direction
from .live_source_wave_scope import known_envelope_component


def _key(p):
    return (p['kind'],p['pivot_timestamp_utc'],p['price'],p['confirmed_at_utc'])


def preceding_range_wave(family, projection):
    """Select only this ordinal's named prior actual wave, never a fallback."""
    ordinal=projection.get('ordinal')
    if type(ordinal) is not int or ordinal<3 or family.get('mode')!='range':
        return {}
    span=((family.get('range_second_wave') or {}) if ordinal==3 else
          (family.get('range_measured_waves') or {}).get(str(ordinal-1)) or {})
    matches=[p for p in family['projections']
             if p['projection_id']==span.get('measurement_projection_id')]
    if len(matches)!=1:
        return {}
    previous=matches[0]
    try:
        if (previous['ordinal']!=ordinal-1 or
                not _same(span.get('origin',{}),previous['anchor']) or
                not _time(previous['known_at_utc'])<=_time(span['known_at_utc'])<=_time(projection['known_at_utc'])):
            return {}
    except (KeyError,TypeError,ValueError):
        return {}
    if ordinal==3:
        return span
    completion=span.get('completion_observation') or {}
    if (not previous or previous['ordinal']!=ordinal-1 or
            not _same(span.get('origin',{}),previous['anchor']) or
            completion.get('status')!='reached' or not completion.get('event_known_at_utc') or
            _time(completion['event_known_at_utc'])>_time(span['known_at_utc'])):
        return {}
    return span


def projection_owner(family, projection, timeframe):
    """Resolve the named retraced object, never substitute AB for a third.

    Third-wave bounds require the already native-validated ownership receipt.
    This selects an evidence object, not structural degree or completion.
    """
    if (family['timeframe']!=timeframe or projection.get('anchor_native_timeframe')!=timeframe or
            projection.get('measurement_source_leg_id')!=family['source_leg_id']):
        return None
    if projection.get('ordinal')==2:
        if projection.get('retraces_source_leg_id')!=family['source_leg_id']:
            return None
        return dict(id=family['source_leg_id'],origin=family['source_origin'],
                    terminal=family['source_terminal'],known=family['known_at_utc'],
                    components=family['component_source_leg_ids'],original_AB=True)
    span=preceding_range_wave(family,projection)
    receipt=(family.get('return_ownership_by_projection_id') or {}).get(projection['projection_id']) or {}
    if (not span.get('wave_id') or projection.get('retraces_source_leg_id')!=span['wave_id'] or
            span.get('native_timeframe')!=timeframe or not span.get('native_envelope_ok') or
            not span.get('known_at_utc') or _time(span['known_at_utc'])>_time(projection['known_at_utc']) or
            receipt.get('native_timeframe')!=timeframe or
            receipt.get('measurement_source_leg_id')!=family['source_leg_id'] or
            receipt.get('retraces_source_leg_id')!=span['wave_id'] or
            receipt.get('known_at_utc')!=projection['known_at_utc'] or
            not receipt.get('retraced_wave_origin') or not receipt.get('retraced_wave_terminal') or
            not _same(receipt['retraced_wave_origin'],span['origin']) or
            not _same(receipt['retraced_wave_terminal'],span['terminal'])):
        return None
    return dict(id=span['wave_id'],origin=span['origin'],terminal=span['terminal'],
                known=span['known_at_utc'],components=span['component_source_leg_ids'],original_AB=False)


class ReturnWaveIndex:
    """One already OHLC-validated native ledger; no process cache or I/O.

    The caller supplies legs accepted by _leg against its native bars/cutoff.
    This index checks connectivity/identity, not a second OHLC authority.
    """
    def __init__(self, legs, timeframe, *, source_bounds=None):
        self.timeframe=timeframe
        self.by_origin={}
        self.bounds_by_origin={}
        self.by_id={}
        for leg in legs:
            if leg.get('timeframe')==timeframe:
                self.by_origin.setdefault(_key(leg['origin']),[]).append(leg)
        # An unordered outside bar supplies source bounds, not a traversable
        # directed return edge. Keep these indexes separate. Revalidate the
        # bounds against native OHLC at each source's own knowledge boundary.
        for leg in (legs if source_bounds is None else source_bounds):
            if leg.get('timeframe')==timeframe:
                self.by_id.setdefault(leg['leg_id'],[]).append(leg)
                self.bounds_by_origin.setdefault(_key(leg['origin']),[]).append(leg)

    def bind_native_bounds(self, source_id, start, candidate, known_at_utc, native):
        """Keep externally confirmed B/C bounds when an interior bar is unordered.

        This is NOT a directed traversal of a same-bar high/low. Require the
        same exact native component identities, continuous known OHLC and
        the complete B-close/later-candle envelope. A missing edge, foreign
        component, future point or merely internal rebound cannot be filled
        from an OHLC range. Ordered paths retain their original receipt.
        """
        ordered=self.bind(source_id,start,candidate,known_at_utc)
        if ordered['status']=='connected_native_return_candidate':
            return ordered
        result={**ordered,'bounds_fallback_attempted':True}
        try:
            ta,tc,known=map(_time,(start['pivot_timestamp_utc'],candidate['pivot_timestamp_utc'],known_at_utc))
            if (native.timeframe!=self.timeframe or known>native.cutoff or
                    {start['kind'],candidate['kind']}!={'confirmed_swing_high_candidate','confirmed_swing_low_candidate'} or
                    not ta<tc or not isinstance(source_id,str) or not source_id or
                    not _number(start['price']) or not _number(candidate['price'])):
                return {**result,'reason':'foreign_period_or_wrong_external_return_bounds'}
            direction='up' if candidate['price']>start['price'] else 'down'
            if candidate['price']==start['price'] or geometric_direction(start,candidate)!=direction:
                return {**result,'reason':'external_return_direction_conflicts_with_bounds'}
            for point in (start,candidate):
                stamp=_time(point['pivot_timestamp_utc'])
                field='high' if point['kind']=='confirmed_swing_high_candidate' else 'low'
                if (native.raw.get(stamp,{}).get(field)!=point['price'] or
                        not stamp+native.duration<=_time(point['confirmed_at_utc'])<=known):
                    return {**result,'reason':'unverified_or_future_external_return_endpoint'}
            if not native.return_envelope(start,candidate):
                return {**result,'reason':'incomplete_or_non_extreme_native_return_bounds'}
            cursor,chain,seen=start,[],set()
            while not _same(cursor,candidate):
                options=[leg for leg in self.bounds_by_origin.get(_key(cursor),[]) if
                    _time(leg['terminal']['pivot_timestamp_utc'])<=tc and
                    known_envelope_component(leg,self.timeframe,native.raw,known)]
                if len(options)!=1:
                    return {**result,'reason':'missing_or_ambiguous_bound_component'}
                leg=options[0]
                if leg['leg_id'] in seen or len(self.by_id.get(leg['leg_id'],[]))!=1:
                    return {**result,'reason':'cyclic_or_ambiguous_bound_identity'}
                seen.add(leg['leg_id']);chain.append(leg);cursor=leg['terminal']
            unordered=[leg for leg in chain if leg['temporal_order']=='same_bar_unresolved']
            if not unordered:
                return {**result,'reason':'no_unordered_component_to_explain_missing_directed_path'}
            # Only the external direction is known. Do not label an unordered
            # component as a rebound or a directed first/last return leg.
            ids=[leg['leg_id'] for leg in chain]
            identity=sha256(repr(('native_bounds',self.timeframe,source_id,_key(start),_key(candidate),ids)).encode()).hexdigest()[:24]
            return {**result,'status':'native_return_bounds_candidate','reason':None,
                'return_path_id':identity,'component_leg_ids':ids,'component_count':len(ids),
                'direction_observation':direction,'path_form':'external_bounds_with_unordered_interior',
                'internal_rebound_leg_ids':[leg['leg_id'] for leg in chain if
                    leg['temporal_order']=='sequential_confirmed_extrema' and leg['direction_observation']!=direction],
                'unordered_bar_times':sorted({leg['origin']['pivot_timestamp_utc'] for leg in unordered}),
                'native_envelope_verified':True,'directed_path_adjudicated':False,'intrabar_order_inferred':False,
                'degree_readout':'本级原生整段 B→C 外侧极值及连续覆盖已核齐；内部同根高低先后未知，不裁定同级回调结束。'}
        except (KeyError,TypeError,ValueError):
            return {**result,'reason':'malformed_native_bound_component'}

    def projection_return_ownership(self, family, projection, native):
        """Keep the height source separate from the wave a C retraces.

        Missing or conflicting third-wave ownership stays unresolved; never
        silently fall back to the original AB. This is evidence, not a new
        admission gate or a confirmation of structural degree.
        """
        unknown=dict(status='source_component_ownership_unresolved',
            measurement_source_leg_id=family['source_leg_id'],
            retraces_source_leg_id=projection.get('retraces_source_leg_id'),
            native_timeframe=self.timeframe,known_at_utc=projection['known_at_utc'],
            anchor=projection['anchor'],internal_origin_observations=[],
            structural_degree_adjudicated=False,whole_return_confirmed=False,
            trade_permission=False)
        if (family['timeframe']!=self.timeframe or native.timeframe!=self.timeframe or
                projection.get('anchor_native_timeframe')!=self.timeframe or
                projection.get('measurement_source_leg_id')!=family['source_leg_id']):
            return {**unknown,'reason':'foreign_period_or_measurement_source'}
        if projection['ordinal']==2:
            if projection.get('retraces_source_leg_id')!=family['source_leg_id']:
                return {**unknown,'reason':'wrong_second_leg_return_owner'}
            return self.source_return_ownership(family,projection['anchor'],projection['known_at_utc'],native)
        span=preceding_range_wave(family,projection)
        if (not span.get('wave_id') or span['wave_id']!=projection.get('retraces_source_leg_id') or
                span.get('native_timeframe')!=self.timeframe or not span.get('native_envelope_ok') or
                not span.get('known_at_utc') or _time(span['known_at_utc'])>_time(projection['known_at_utc'])):
            return {**unknown,'reason':'missing_foreign_or_future_actual_second_wave'}
        wave=dict(source_leg_id=span['wave_id'],source_origin=span['origin'],
            source_terminal=span['terminal'],component_source_leg_ids=span['component_source_leg_ids'],
            direction_observation=family['direction_observation'],timeframe=span['native_timeframe'])
        return self.source_return_ownership(family,projection['anchor'],projection['known_at_utc'],native,wave=wave)

    def source_return_ownership(self, family, anchor, known_at_utc, native, *, wave=None):
        """Locate a C against its source's *own* internal push origins.

        Source timeframe is not a structural degree. This records whether C
        still fits inside the terminal component or traverses earlier ones;
        neither circumstance alone confirms/denies a whole-wave return. It
        never substitutes the terminal internal origin for the outer A or B.
        Future return extensions cannot rewrite an earlier C's observation.
        """
        # A range third leg retraces the actual second C2→D2 wave while
        # reusing the first A→B height. Reuse this native ownership check for
        # that wave instead of leaving ordinal 3 without an ownership scope.
        wave = wave or dict(source_leg_id=family['source_leg_id'],
            source_origin=family['source_origin'], source_terminal=family['source_terminal'],
            component_source_leg_ids=family['component_source_leg_ids'],
            direction_observation=family['direction_observation'], timeframe=family['timeframe'])
        result=dict(status='source_component_ownership_unresolved',
            measurement_source_leg_id=family['source_leg_id'],
            retraces_source_leg_id=wave['source_leg_id'],
            native_timeframe=self.timeframe,known_at_utc=known_at_utc,
            anchor=anchor,internal_origin_observations=[],
            structural_degree_adjudicated=False,whole_return_confirmed=False,
            trade_permission=False)
        ids=wave['component_source_leg_ids']
        groups=[self.by_id.get(i,[]) for i in ids]
        if (native.timeframe!=self.timeframe or family['timeframe']!=self.timeframe or wave['timeframe']!=self.timeframe or
                not groups or any(len(g)!=1 for g in groups)):
            return {**result,'reason':'missing_ambiguous_or_foreign_native_components'}
        legs=[g[0] for g in groups]
        a,b=wave['source_origin'],wave['source_terminal']
        known=_time(known_at_utc)
        source_known=max(_time(a['confirmed_at_utc']),_time(b['confirmed_at_utc']))
        if any(not known_envelope_component(l,self.timeframe,native.raw,source_known) for l in legs):
            return {**result,'reason':'source_components_not_verified_at_source_confirmation'}
        if (not _same(legs[0]['origin'],a) or not _same(legs[-1]['terminal'],b) or
                any(not _same(left['terminal'],right['origin']) for left,right in zip(legs,legs[1:])) or
                max(_time(p['confirmed_at_utc']) for l in legs for p in (l['origin'],l['terminal']))>known or
                _time(anchor['confirmed_at_utc'])>known or
                _time(anchor['pivot_timestamp_utc'])<=_time(b['pivot_timestamp_utc'])):
            return {**result,'reason':'disconnected_future_or_wrong_source_endpoints'}
        up=wave['direction_observation']=='up'
        unordered=sorted({l['origin']['pivot_timestamp_utc'] for l in legs if l['temporal_order']=='same_bar_unresolved'})
        internal=[l for l in legs if l['temporal_order']=='sequential_confirmed_extrema' and
                  l['direction_observation']==wave['direction_observation'] and
                  not _same(l['origin'],a)]
        start,end=native.bounds(_time(b['pivot_timestamp_utc']),_time(anchor['pivot_timestamp_utc']))
        observations=[]
        for leg in internal:
            p=leg['origin']
            beyond=lambda price: price<p['price'] if up else price>p['price']
            # B's opposite wick may precede B. No intrabar-order assumption;
            # actual later closes alone supply the close-through witness.
            close=next((row['timestamp_utc'] for row in native.bars[start+1:end]
                        if beyond(row['close'])),None)
            observations.append(dict(component_leg_id=leg['leg_id'],origin=p,
                anchor_beyond_origin=beyond(anchor['price']),
                anchor_touches_origin=anchor['price']==p['price'],
                first_later_close_beyond_origin_utc=close))
        count=sum(o['anchor_beyond_origin'] for o in observations)
        status=('single_component_degree_unresolved' if not observations else
                'beyond_all_internal_push_origins' if count==len(observations) else
                'beyond_some_internal_push_origins' if count else
                'touches_internal_push_origin' if any(o['anchor_touches_origin'] for o in observations) else
                'inside_terminal_push_component')
        # Non-monotonic internal origins can enclose different suffix waves;
        # do not call the terminal component the owner when C lies outside it.
        if observations and not count and not observations[-1]['anchor_touches_origin']:
            terminal=legs[-1]
            lo,hi=sorted((terminal['origin']['price'],terminal['terminal']['price']))
            if not lo<=anchor['price']<=hi:
                status='internal_component_extent_unresolved'
        terminal_origin=legs[-1]['origin']['price']
        relation=('touches_terminal_push_origin' if anchor['price']==terminal_origin else
                  'beyond_terminal_push_origin' if (anchor['price']<terminal_origin if up else anchor['price']>terminal_origin) else
                  'inside_terminal_push_component')
        return {**result,'status':'source_bounds_known_intrabar_order_unresolved' if unordered else status,
            'retraced_wave_origin':a,'retraced_wave_terminal':b,
            'internal_origin_observations':observations,
            'unordered_interior_bar_times':unordered,'intrabar_order_inferred':False,
            'terminal_component_relation':relation,
            'terminal_component':dict(leg_id=legs[-1]['leg_id'],origin=legs[-1]['origin'],terminal=b),
            'interpretation':'只记录回走穿过本来源哪些内部起点；未穿过不等于不能浅回调，穿过也不自动证明整段级别。'}

    def bind(self, source_id, start, candidate, known_at_utc):
        """Find one connected, known path from source terminal to candidate.

        `start` is B for the second measuring leg, or the actual second
        terminal for a range third. An internal bounce is not a new start.
        Full OHLC extreme/continuity checks remain the caller's responsibility.
        """
        result=dict(status='unresolved_native_return_path',native_timeframe=self.timeframe,
            retraces_source_leg_id=source_id,return_origin=start,endpoint_candidate=candidate,
            known_at_utc=known_at_utc,component_leg_ids=[],internal_rebound_leg_ids=[],
            structural_degree_adjudicated=False,return_completion_adjudicated=False,
            trade_permission=False)
        known=_time(known_at_utc)
        end=_time(candidate['pivot_timestamp_utc'])
        if (_time(start['pivot_timestamp_utc'])>=end or
                max(_time(start['confirmed_at_utc']),_time(candidate['confirmed_at_utc']))>known):
            return {**result,'reason':'wrong_order_or_future_endpoint'}
        direction='up' if candidate['price']>start['price'] else 'down'
        cursor=start
        chain=[]
        seen=set()
        while not _same(cursor,candidate):
            options=[leg for leg in self.by_origin.get(_key(cursor),[]) if
                leg.get('temporal_order')=='sequential_confirmed_extrema' and
                _time(cursor['pivot_timestamp_utc'])<_time(leg['terminal']['pivot_timestamp_utc'])<=end and
                max(_time(p['confirmed_at_utc']) for p in (leg['origin'],leg['terminal']))<=known]
            if len(options)!=1:
                return {**result,'reason':'disconnected_or_ambiguous_native_return'}
            leg=options[0]
            if leg['leg_id'] in seen:
                return {**result,'reason':'cyclic_native_return'}
            seen.add(leg['leg_id']); chain.append(leg); cursor=leg['terminal']
        if not chain or chain[0]['direction_observation']!=direction or chain[-1]['direction_observation']!=direction:
            return {**result,'reason':'candidate_is_internal_rebound_not_return_extreme'}
        ids=[leg['leg_id'] for leg in chain]
        identity=sha256(repr((self.timeframe,source_id,_key(start),_key(candidate),ids)).encode()).hexdigest()[:24]
        result.update(status='connected_native_return_candidate',return_path_id=identity,
            component_leg_ids=ids,component_count=len(chain),direction_observation=direction,
            internal_rebound_leg_ids=[leg['leg_id'] for leg in chain if leg['direction_observation']!=direction],
            path_form='single_native_leg' if len(chain)==1 else 'compound_native_return',
            degree_readout='该原生回走路径已绑定来源；内部反弹没有替换外侧起点。波段级别及回调结束仍需结构、力度和被处理节点裁决。')
        return result
