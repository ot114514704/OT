"""Bounded reuse of exact native Book selector windows across new candles.

Only pure window geometry is cached. Each consumed row's complete content,
selector, direction and validation mode belong to the key. Observation clocks,
wave lifecycles, scores/decisions and rendered scenes are never cached here.
Returned indexes follow the original selector's offset convention exactly.
"""
from collections import OrderedDict
from .book_evidence_copy import copy_evidence as deepcopy
from hashlib import sha256
from threading import RLock
import json


def row_fingerprints(rows):
    try:
        return [sha256(json.dumps(r,sort_keys=True,ensure_ascii=False,
            allow_nan=False,separators=(',',':')).encode('utf8')).digest() for r in rows]
    except (TypeError,ValueError):
        # Invalid/non-JSON inputs must still take the original validation path.
        return None


class NativeWindowCache:
    def __init__(self,limit=12288,max_bytes=32*1024*1024):
        self.limit=limit;self.max_bytes=max_bytes;self.bytes=0
        self.entries=OrderedDict();self.lock=RLock();self.hits=0;self.misses=0

    def select(self,selector,rows,end,upward,width,validated,fingerprints):
        from .book_calculation_cancel import check_current
        check_current()
        names={'select_pdf_outer_trendline','select_pdf_wave_relative_outer'}
        if (fingerprints is None or selector.__module__!='src.pdf_trendline_block'
                or selector.__name__ not in names):
            return selector(rows[:end],upward,lookback=width,_validated_rows=validated)
        relative=selector.__name__=='select_pdf_wave_relative_outer'
        offset=max(0,end-(width if relative else max(width,12)))
        key=(selector,upward,width,validated,end-offset,
             sha256(b''.join(fingerprints[offset:end])).digest())
        from .book_calculation_scope import independent_axis_enabled
        if independent_axis_enabled():key+=('book_independent_native_axis_v1',)
        with self.lock:
            entry=self.entries.get(key)
            if entry is not None:
                self.entries.move_to_end(key);self.hits+=1
                result=deepcopy(entry[0])
            else:result=None;self.misses+=1
        if result is None:
            result=selector(rows[offset:end],upward,lookback=width,_validated_rows=validated)
            size=len(json.dumps(result,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode('utf8'))+128
            if size<=self.max_bytes:
                with self.lock:
                    old=self.entries.pop(key,None)
                    if old:self.bytes-=old[1]
                    self.entries[key]=(deepcopy(result),size);self.bytes+=size
                    while len(self.entries)>self.limit or self.bytes>self.max_bytes:
                        _,(_,removed)=self.entries.popitem(last=False);self.bytes-=removed
        # A new rolling chart may contain the identical native window at a
        # different index. Rebase only the fields the original selector does;
        # never cache global indexes or borrow its previous context origin.
        if offset and result.get('qualified'):
            fields=['start_index','end_index','first_break_index']
            if relative:fields+=['established_extreme_index','opposite_extreme_index','second_anchor_index']
            for field in fields:
                if result.get(field) is not None:result[field]+=offset
            if relative:
                proof=result.get('anchor_order_proof') or {}
                for field in ('opposite_extreme_index','second_anchor_index'):
                    if proof.get(field) is not None:proof[field]+=offset
            projection=result.get('parallel_projection') or {}
            if projection.get('reference_index') is not None:projection['reference_index']+=offset
            window=projection.get('reference_window') or {}
            for field in ('start_index','end_index'):
                if window.get(field) is not None:window[field]+=offset
        return result


WINDOWS=NativeWindowCache()
