"""W4 refinement v2: a neckline exception must use the actual adjustment.

Explicit native integer-price/confirmation policy; not an author wave-degree
classifier. Similarity, radius and minimum span stay caller-owned policies.
"""


def neckline_proof(prices, seq, known, radius, tolerance):
    o, c, d, e = seq[:4]
    up = o[1] == 'low'; sign = 1 if up else -1
    side, opposite = ('high', 'low') if up else ('low', 'high')
    fail = lambda reason: dict(qualified=False, reason=reason)
    if not o[0] < c[0] < d[0] < e[0] <= known:
        return fail('NECKLINE_POINT_ORDER')
    if e[0] - c[0] < max(2*radius, 6):
        return fail('NECKLINE_SPAN_POLICY')
    if any(p[0]-radius < 0 or p[0]+radius > known for p in (c,d,e)):
        return fail('NECKLINE_NOT_CONFIRMED')
    for p, field, direction in ((c,side,sign),(e,side,sign),(d,opposite,-sign)):
        if p[2] != prices[p[0]][field] or any(
            direction*(p[2]-prices[k][field]) <= 0
            for k in range(p[0]-radius,p[0]+radius+1) if k!=p[0]):
            return fail('NECKLINE_LOCAL_EXTREME_OR_PLATEAU_POLICY')
    # An outside bar skipped by the alternating-pivot recogniser can still
    # be the real adjustment extreme. Never borrow a prettier later D.
    adjustment = (min if up else max)(prices[k][opposite] for k in range(c[0]+1,e[0]))
    if d[2] != adjustment:
        return fail('D_NOT_ACTUAL_PAIR_NECKLINE')
    absolute = (max if up else min)(p[side] for p in prices[o[0]:known+1])
    extreme = c if sign*(c[2]-e[2]) >= 0 else e
    if extreme[2] != absolute:
        return fail('PAIR_NOT_WAVE_EXTREME')
    if abs(c[2]-e[2]) > tolerance:
        return fail('NECKLINE_PRICE_SIMILARITY')
    return dict(qualified=True, pair_indices=[c[0],e[0]], neckline_index=d[0],
                extreme_index=extreme[0], known_index=max(p[0]+radius for p in (c,d,e)),
                variant='post_extreme_neckline' if d[0]>extreme[0] else 'normal_pre_extreme',
                plateau_policy='requires_separate_policy',
                source_rule_pages=[49,50,60,63],
                still_requires_full_outer_geometry=True)
