"""Identify a return's own rulers without equating local delivery to completion.

Alexander June18 7652526864210270350 describes a downward 1:1 inside the
return of an earlier complete pair. Apr2 7624242017279866958/6952 keeps
competing adjustment ownership despite two local bull legs. This join is
native geometric evidence, not an author task assignment or admission rule.
"""
from .live_nested_stage_review import _same, _time
from .live_return_wave_scope import projection_owner


def _key(point):
    return tuple(point[k] for k in ('kind','pivot_timestamp_utc','price','confirmed_at_utc'))


def attach_return_measurements(families,native):
    by_origin={}
    for family in families:
        key=(family['timeframe'],family['snapshot_id'],_key(family['source_origin']))
        by_origin.setdefault(key,[]).append(family)
    for outer in families:
        for p in outer['projections']:
            result=dict(status='return_measurement_context_unresolved',
                native_timeframe=outer['timeframe'],known_at_utc=p['known_at_utc'],
                retraces_source_leg_id=p['retraces_source_leg_id'],measurements=[],
                coverage='already_admitted_native_families_not_all_theoretical_waves',
                whole_return_completion_adjudicated=False,parent_task_changed=False,
                admission_changed=False,trade_permission=False,
                theory_source_message_ids=['7652526864210270350','7624242017279866958','7624242017279866952'])
            p['return_measurement_context']=result
            owner=projection_owner(outer,p,native.timeframe)
            if not owner:
                result['reason']='named_return_owner_not_bound';continue
            key=(outer['timeframe'],outer['snapshot_id'],_key(owner['terminal']))
            path=p['return_wave_scope'];ids=path.get('component_leg_ids',[])
            known=_time(p['known_at_utc'])
            if (path.get('status')!='connected_native_return_candidate' or not ids or
                    path['native_timeframe']!=native.timeframe or outer['timeframe']!=native.timeframe or
                    p['anchor_native_timeframe']!=native.timeframe or
                    path['retraces_source_leg_id']!=owner['id'] or
                    p['retraces_source_leg_id']!=owner['id'] or
                    _time(path['known_at_utc'])>known or
                    not _same(path['return_origin'],owner['terminal']) or
                    not _same(path['endpoint_candidate'],p['anchor'])):
                result['reason']='return_path_identity_not_bound';continue
            for child in by_origin.get(key,[]):
                components=child['component_source_leg_ids']
                if (child['direction_observation']==outer['direction_observation'] or
                        _time(child['known_at_utc'])>known or
                        not components or ids[:len(components)]!=components or
                        _time(child['source_terminal']['pivot_timestamp_utc'])>_time(p['anchor']['pivot_timestamp_utc'])):
                    continue
                observations=[]
                for q in child['projections']:
                    if _time(q['known_at_utc'])>known:continue
                    # Recompute from native bars only through the outer C's
                    # knowledge time; never copy this child's eventual outcome.
                    outcome=native.outcome(child,q['anchor'],known_override=_time(q['known_at_utc']),as_of=p['known_at_utc'])
                    observations.append(dict(projection_id=q['projection_id'],ordinal=q['ordinal'],
                        anchor=q['anchor'],target=q['target'],known_at_utc=q['known_at_utc'],
                        outcome_as_of_outer_C=outcome))
                result['measurements'].append(dict(measurement_id=child['measurement_id'],
                    source_leg_id=child['source_leg_id'],source_origin=child['source_origin'],
                    source_terminal=child['source_terminal'],source_known_at_utc=child['known_at_utc'],
                    source_height=child['source_height'],source_component_leg_ids=components,
                    starts_at_outer_B=owner['original_AB'],source_is_prefix_of_return_path=True,
                    projections=observations))
            if not owner['original_AB']:
                result['return_origin']=owner['terminal']
                result['return_origin_role']='actual_second_wave_terminal' if p['ordinal']==3 else 'actual_preceding_measured_wave_terminal'
                result['retraced_wave_ordinal']=p['ordinal']-1
            result.update(status='known_native_measurements_inside_return',
                interpretation='回调自身的反向量尺与原来源分开；内部目标到位、失败或未到位均不直接决定整段回调结束。未匹配不等于不存在理论量尺。')
