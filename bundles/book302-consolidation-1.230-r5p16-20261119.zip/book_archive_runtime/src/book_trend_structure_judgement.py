"""Book ch3/4/5/6 structure precedence over unfitted force descriptions.

The original PDF defines dual breaks as the end of the old trend, and A
as the distinction between new direction and range. No numerical force
threshold is imported into that rule. Closed-bar crossing is an explicit
implementation convention, not a threshold specified by the author.
"""
from fractions import Fraction
from math import isfinite

from .book_breakout_assessment import native_turning_source_proof
from .book_first_response_leg import clock, close_time
from .trend_trade_method_full_pipeline import (
    classify_trend_change,
)

VERSION='book_trend_structure_judgement_v1'


def _closed_event(rows,timeframe,cutoff,observable,level,sign,known):
    """Use native decimal anchors, so a rounded slope cannot turn touch into break."""
    if sign*(Fraction(str(rows[observable]['close']))-level(observable))>0:
        return dict(status='unknown',reason='boundary_already_broken_when_observable')
    for i in range(observable+1,len(rows)):
        if sign*(Fraction(str(rows[i]['close']))-level(i))>0:
            return dict(status='observed_candidate',break_index=i,
                break_utc=rows[i]['timestamp_utc'],break_price=rows[i]['close'],
                break_level=float(level(i)),break_side='up' if sign>0 else 'down',
                known_at_utc=max((known,close_time(rows[i],timeframe)),key=clock),
                rule_id=VERSION+':exact_native_closed_break',trade_permission=False)
    return dict(status='not_observed',known_at_utc=cutoff,trade_permission=False)


def judge_book_trend_structure(rows, timeframe, cutoff, outer, turning,
                              adjustment=None, wave_record=None):
    """Recheck native geometry/events. Do not accept a cached score or state.

    Interpretation concerns the supplied native wave only, never an inferred
    author degree/parent. Missing geometry is unknown rather than an intact
    trend. Historical breaks persist after a return inside either line.
    """
    base=dict(schema=VERSION,stage='unknown',prior_trend_ended=None,
        new_direction_status='unknown',boundary_A_state='unknown',
        native_timeframe=timeframe,as_of_utc=cutoff,
        source_pdf_pages=[49,67,68,81,83,90,91,92,93,108,109,133,134,135,198,199,200,201,202],
        evidence_scope='specified_native_wave_not_author_degree_or_parent_trend',
        author_wave_degree_verified=False,parent_trend_status='not_adjudicated',
        force_score_can_change_structure=False,force_score_threshold_required=False,
        crossing_convention='strict_native_closed_price_not_author_numeric_threshold',
        automatic_trade_permission=False,entry_permission=False,future_bars_used=False)
    def fail(reason):return dict(base,reason=reason)
    try:
        # Reuse the existing public native-input contract without importing
        # the adjudicator (which calls this module).
        from .trend_wave_state_adjudication import _closed
        rows=_closed(rows,timeframe,cutoff)
        if not outer.get('qualified') or outer.get('direction') not in ('up','down'):
            return fail('outer_geometry_unavailable')
        a,b=outer['start_index'],outer['end_index']
        if any(type(i) is not int for i in (a,b)) or not 0<=a<b<len(rows):
            return fail('outer_native_indices_invalid')
        field='low' if outer['direction']=='up' else 'high'
        if any(outer[k+'_price']!=rows[i][field] or isinstance(outer[k+'_price'],bool)
               for k,i in [('start',a),('end',b)]):
            return fail('outer_anchor_not_native')
        slope=(Fraction(str(outer['end_price']))-Fraction(str(outer['start_price'])))/(b-a)
        if (isinstance(outer['slope'],bool) or not isfinite(outer['slope']) or
                abs(float(slope)-outer['slope'])>1e-10*max(1,abs(float(slope)))):
            return fail('outer_slope_not_native')
        trend_sign=1 if outer['direction']=='up' else -1
        if trend_sign*slope<=0:
            return fail('outer_not_advancing_in_source_direction')
        outer_level=lambda i:Fraction(str(outer['start_price']))+slope*(i-a)
        if any(trend_sign*(Fraction(str(rows[i][field]))-outer_level(i))<=0 for i in range(a+1,b)):
            return fail('outer_internal_cross_or_contact')
        for source,index in ((outer,b),(turning or {},(turning or {}).get('first_observable_index'))):
            known=source.get('known_at_utc')
            if (type(index) is not int or not 0<=index<len(rows) or not known or
                    not clock(close_time(rows[index],timeframe))<=clock(known)<=clock(cutoff)):
                return fail('construction_clock_unavailable_or_invalid')
        proof=native_turning_source_proof(rows,outer,turning or {})
        base.update(owner_id=(wave_record or {}).get('scope_id') or outer.get('wave_id'),
                    turning_construction_proof=proof,
                    market={k:rows[0][k] for k in ('provider','symbol')})
        if not proof['qualified']:return fail('turning_geometry:'+str(proof.get('reason')))
        if (wave_record or {}).get('state')=='origin_broken':
            return dict(base,stage='source_scope_retired',reason='native_scope_requires_separate_retirement_proof')
        sign=-trend_sign
        turning_slope=(Fraction(str(turning['extension_end_price']))-Fraction(str(turning['extension_start_price'])))/(
            turning['extension_end_index']-turning['extension_start_index'])
        turning_level=lambda i:Fraction(str(turning['start_price']))+turning_slope*(i-turning['start_index'])
        ob=_closed_event(rows,timeframe,cutoff,b,outer_level,sign,outer['known_at_utc'])
        tb=_closed_event(rows,timeframe,cutoff,turning['first_observable_index'],turning_level,sign,turning['known_at_utc'])
        base.update(outer_break=ob,turning_break=tb)
        if 'unknown' in (ob.get('status'),tb.get('status')):
            return fail('native_boundary_event_unavailable')
        seen=[e.get('status')=='observed_candidate' for e in (ob,tb)]
        turn_level=turning_level(len(rows)-1)
        base['current_boundary_relation']={
            'outer_outside':sign*(Fraction(str(rows[-1]['close']))-outer_level(len(rows)-1))>0,
            'turning_outside':sign*(Fraction(str(rows[-1]['close']))-turn_level)>0}
        base['known_at_utc']=cutoff
        if not any(seen):
            return dict(base,stage='no_boundary_break_observed',prior_trend_ended=False,
                        continuation_assumption='retained_for_this_source',reason=None)
        if not all(seen):
            return dict(base,stage='outer_only_warning' if seen[0] else 'turning_only_warning',
                        prior_trend_ended=False,continuation_assumption='under_review',reason='second_boundary_not_broken')
        first=min(ob['break_index'],tb['break_index'])
        base.update(prior_trend_ended=True,
            ended_known_at_utc=max((ob['known_at_utc'],tb['known_at_utc']),key=clock),
            dual_break_order='same_bar' if ob['break_index']==tb['break_index'] else
                'outer_then_turning' if ob['break_index']<tb['break_index'] else 'turning_then_outer',
            construction_timing='known_before_first_break' if all(clock(s['known_at_utc'])<=clock(rows[first]['timestamp_utc'])
                for s in (outer,turning)) else 'historical_reconstruction',
            continuation_assumption='old_source_trend_ended',
            no_automatic_revival_after_line_reentry=True)
        change=classify_trend_change(rows,outer,ob,timeframe,cutoff,turning_break=tb,adjustment=adjustment)
        base['boundary_A_evidence']=change
        if not change.get('author_boundary_verified'):
            return dict(base,stage='old_trend_ended_direction_unresolved',
                        boundary_A_state='unverified',reason='complete_adjustment_A_required')
        if change.get('status')=='trend_confirmed':
            return dict(base,stage='new_direction_candidate',boundary_A_state='crossed_after_dual_break',
                        new_direction_status='down_candidate' if trend_sign>0 else 'up_candidate',reason=None)
        return dict(base,stage='old_trend_ended_range_candidate',boundary_A_state='verified_not_crossed_after_dual_break',
                    new_direction_status='range_candidate_not_permanent_range_confirmation',reason=None)
    except (KeyError,IndexError,TypeError,ValueError,ArithmeticError) as error:
        return fail('native_structure_evidence_invalid:'+str(error))
