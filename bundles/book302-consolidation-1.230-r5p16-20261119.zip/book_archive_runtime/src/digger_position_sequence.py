"""Closed-native-bar position sequence; author hold/fold remains unresolved.

DG-A03 (p343 #6856) distinguishes later tests and next pre-existing levels.
p980 #19584 and p1613 #32255-56 reject one close as sufficient evidence.
Contact clusters and close-side transitions below are project measurements.
"""
from datetime import datetime,timedelta

VERSION='digger_closed_position_sequence_v1'
SOURCES={
    'later_tests_and_levels':'https://www.metalsmine.com/thread/930946-aussi-my-thread-and-anything-i-want-to?page=343',
    'close_not_sufficient':'https://www.metalsmine.com/thread/930946-aussi-my-thread-and-anything-i-want-to?page=980',
    'preexisting_next_objects':'https://www.metalsmine.com/thread/930946-aussi-my-thread-and-anything-i-want-to?page=1613'}


def time(value):
    result=datetime.fromisoformat(value.replace('Z','+00:00'))
    if result.tzinfo is None:raise ValueError('aware_sequence_clock_required')
    return result


def _neighbours(levels,own,row):
    result={'above':[],'below':[],'at':[]}
    for other in levels:
        if other['object_id']==own['object_id'] or time(other['known_at_utc'])>time(row['timestamp_utc']):continue
        delta=other['price']-row['close'];side='above' if delta>0 else 'below' if delta<0 else 'at'
        result[side].append(dict(object_id=other['object_id'],price=other['price'],
            native_timeframe=other['native_timeframe'],known_at_utc=other['known_at_utc'],
            source_id=other['source_id'],distance_price=abs(delta)))
    for key,values in result.items():
        values.sort(key=lambda r:(r['distance_price'],r['object_id']))
        result[key]=[r for r in values if r['distance_price']==values[0]['distance_price']]
    return result


def _sequence(level,rows,levels,tf,minutes):
    known_line=time(level['known_at_utc'])
    eligible=[b for b in rows if time(b['timestamp_utc'])>=known_line]
    left=not eligible or time(eligible[0]['timestamp_utc'])!=known_line
    gaps=[];events=[];last_decisive=None;last_cross=None;prior_touch=False;clusters=0
    known=level['known_at_utc'];first_touch=None;previous=None
    for b in eligible:
        known=max((known,b['known_at_utc']),key=time)
        if previous and time(b['timestamp_utc'])-time(previous['timestamp_utc'])!=timedelta(minutes=minutes):
            gaps.append(dict(left=previous['timestamp_utc'],right=b['timestamp_utc']))
            prior_touch=False
        side=(b['close']>level['price'])-(b['close']<level['price'])
        touch=b['low']<=level['price']<=b['high']
        if touch and not prior_touch:clusters+=1
        cross=last_decisive is not None and side not in (0,last_decisive)
        if touch and first_touch is None:first_touch=b['timestamp_utc']
        if touch or cross:
            event_id=f'{VERSION}:{level["object_id"]}:{tf}:{b["timestamp_utc"]}'
            kind=('close_return_after_cross' if cross and last_cross and side==last_cross['from_side'] else
                'close_cross' if cross else 'touch_close_on_level' if side==0 else
                'probe_closed_on_prior_side' if side==last_decisive else 'touch_without_known_approach')
            events.append(dict(event_id=event_id,kind=kind,native_timeframe=tf,
                bar_open_utc=b['timestamp_utc'],closed_at_utc=b['closed_at_utc'],known_at_utc=known,
                source_ohlc={k:b[k] for k in ('open','high','low','close')},
                touches=touch,close_side=side,previous_bar_close_side=(
                    (previous['close']>level['price'])-(previous['close']<level['price']) if previous else None),
                prior_decisive_close_side=last_decisive,
                crosses_after_on_level=bool(cross and previous and previous['close']==level['price']),
                prior_cross_event_id=last_cross['event_id'] if cross and last_cross else None,
                contact_cluster_number=clusters if touch else None,
                first_visible_contact=touch and first_touch==b['timestamp_utc'],
                first_contact_proven_in_closed_prefix=bool(touch and first_touch==b['timestamp_utc'] and not left and not gaps),
                continuity='gap_or_calendar_unresolved' if gaps else 'contiguous_observed_native_bars',
                intrabar_order='unknown',level_price_traded_witness='bar_range_contains_level' if touch else 'not_observed_gap_cross_possible',
                available_neighbours=_neighbours(levels,level,b),
                neighbour_role='preexisting_geometric_candidates_not_author_next_in_line',
                author_hold_fold='unknown',owner_equivalence=False,entry_permission=False))
            if cross:last_cross=dict(event_id=event_id,from_side=last_decisive,to_side=side)
        if side:last_decisive=side
        prior_touch=touch;previous=b
    return dict(object_id=level['object_id'],source_id=level['source_id'],
        level_native_timeframe=level['native_timeframe'],interaction_timeframe=tf,
        price=level['price'],line_known_at_utc=level['known_at_utc'],known_at_utc=known,
        observation_start_utc=eligible[0]['timestamp_utc'] if eligible else None,
        left_censored=left,timestamp_discontinuities=gaps,first_visible_touch_utc=first_touch,
        observed_contact_clusters=clusters,events=events,
        first_attempt_scope='closed_bar_prefix_only_not_author_or_live_first_seen',
        author_first_attempt_identified=False,author_hold_state='unknown',author_fold_state='unknown',
        author_next_in_line_object_id=None,entry_permission=False)


def build(levels,rows,tf,minutes):
    return dict(schema=VERSION,source_claims=dict(SOURCES),interaction_timeframe=tf,
        source_window_start_utc=rows[0]['timestamp_utc'] if rows else None,
        source_window_end_utc=rows[-1]['closed_at_utc'] if rows else None,
        cluster_definition='consecutive_observed_touching_bars_project_convention',
        on_level_policy='retain_last_decisive_close_side_zero_is_not_an_opposite_side',
        objects=[_sequence(l,rows,levels,tf,minutes) for l in levels],
        map_scope='mapped_period_opens_only_not_complete_author_map',
        read_only=True,automatic_trade_permission=False,future_bars_used=False,entry_permission=False)
