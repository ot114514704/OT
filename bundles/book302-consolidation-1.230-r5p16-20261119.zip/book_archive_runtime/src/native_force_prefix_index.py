"""Call-local immutable OHLC prefixes with exact force timestamp lookups.

This indexes locations only; no force judgement, ratio, threshold or source
eligibility is cached. A lookup outside the physical prefix is unavailable.
"""
from collections.abc import Sequence


class ForcePrefixIndex:
    def __init__(self,bars,formatter):
        self.bars=tuple(bars)
        self.positions={formatter(bar.timestamp_utc):i for i,bar in enumerate(self.bars)}
        if len(self.positions)!=len(self.bars):raise ValueError('duplicate native force timestamp')

    def prefix(self,count):
        if type(count) is not int or not 0<=count<=len(self.bars):raise ValueError('invalid force prefix count')
        return ForceBarPrefix(self,count)


class ForceBarPrefix(Sequence):
    def __init__(self,index,count):self._index=index;self._count=count
    def __len__(self):return self._count
    def __getitem__(self,item):
        if isinstance(item,slice):return tuple(self._index.bars[i] for i in range(*item.indices(self._count)))
        if item<0:item+=self._count
        if not 0<=item<self._count:raise IndexError('force prefix index')
        return self._index.bars[item]
    def position(self,key,default=None):
        value=self._index.positions.get(key)
        return value if value is not None and value<self._count else default
    def get(self,key,default=None):return self.position(key,default)
    def __contains__(self,value):
        # Sequence containment keeps ordinary bars semantics. Timestamp
        # containment for review uses the explicit position() method.
        return any(bar==value for bar in self)
