"""Versioned closed-bar reconstruction of two independently obtained sources.

Source: jrcMOD_Fractals-Reversal-Candle.mq4, MQL5 job 163232 attachment.
The original loop permits an incomplete newer half-window and can erase arrows.
We retain birth/revocation/maturity separately. Full older support is a project
guard; original source permits partial history edges. ATR arrow offsets are UI
coordinates and must never be substituted for the price extreme.
"""
from datetime import datetime,timedelta

VERSION='jrcmod_reversal_candle_closed_bar_observation_v1'
SOURCE_URL='https://c.mql5.com/21/344/jrcMOD_Fractals-Reversal-Candle.mq4?d=1'
SOURCE_SHA256='b46e967e61bf2363d190e064fe7a00db43ffa9afae16b0a883beb7fe4e769d42'
SOURCES={
    'reversal_candle_2022':dict(version=VERSION,url=SOURCE_URL,sha256=SOURCE_SHA256,
        identity='public_reversal_candle_variant_not_ghbdr_original',candle_filter=True),
    'ghbdr_2018':dict(version='jrcmod_ghbdr_2018_closed_bar_observation_v1',
        url='https://forex-station.com/download/file.php?id=3324261',
        sha256='0a61017a9cd33d5b72b346aaa39698f72ad117ba2393abebd2aec757eb4a682a',
        identity='ghbdr_2018_forum_attachment_not_verified_2020_template',candle_filter=False)}


def _time(value):
    t=datetime.fromisoformat(value.replace('Z','+00:00'))
    if t.tzinfo is None:raise ValueError('aware_fractal_clock_required')
    return t


def _known(rows):
    return max((b['known_at_utc'] for b in rows),key=_time)


def observe(rows,tf,minutes,requested_period,source_version='reversal_candle_2022'):
    source=SOURCES[source_version]
    if isinstance(requested_period,bool) or not isinstance(requested_period,int) or requested_period<3:
        raise ValueError('fractal_period_at_least_three_required')
    effective=requested_period+(requested_period%2==0);half=effective//2
    records=[]
    for i,kind in ((i,kind) for i in range(half,len(rows)) for kind in ('high','low')):
        pivot=rows[i];older=rows[i-half:i]
        # In chronological order, ties on the OLDER side are allowed; ties on
        # the NEWER side invalidate. Source's bearish/bullish candle filter is
        # specific to this variant and must not be attributed to the original.
        if source['candle_filter'] and not (pivot['open']>pivot['close'] if kind=='high' else pivot['open']<pivot['close']):continue
        value=pivot[kind]
        if any(b[kind]>value if kind=='high' else b[kind]<value for b in older):continue
        support=rows[i-half:i+1];born=_known(support)
        oid=f'{source["version"]}:{tf}:{requested_period}:{kind}:{pivot["timestamp_utc"]}'
        out=dict(object_id=oid,native_timeframe=tf,requested_period=requested_period,effective_period=effective,
            kind=kind,price=value,pivot_bar_utc=pivot['timestamp_utc'],candidate_known_at_utc=born,
            state='candidate',confirmed_known_at_utc=None,invalidated_known_at_utc=None,
            right_bars_observed=0,required_right_bars=half,known_at_utc=born,
            support_start_utc=older[0]['timestamp_utc'],support_end_utc=pivot['closed_at_utc'],
            event_log=[dict(state='candidate',event_bar_utc=pivot['timestamp_utc'],known_at_utc=born)],
            author_confirmation='unknown',owner_equivalence=False,entry_permission=False,
            visibility_model='closed_bar_replay_not_first_seen_live_witness')
        terminal=i
        for j in range(i+1,min(len(rows),i+half+1)):
            current=rows[j];terminal=j
            out['right_bars_observed']=j-i
            invalid=current[kind]>=value if kind=='high' else current[kind]<=value
            if invalid:
                known=_known(rows[i-half:j+1])
                out.update(state='invalidated',invalidated_known_at_utc=known,
                    invalidating_bar_utc=current['timestamp_utc'],invalidating_price=current[kind])
                out['event_log'].append(dict(state='invalidated',event_bar_utc=current['timestamp_utc'],known_at_utc=known))
                break
            if j==i+half:
                known=_known(rows[i-half:j+1])
                out.update(state='confirmed_window',confirmed_known_at_utc=known,
                           confirmation_bar_utc=current['timestamp_utc'])
                out['event_log'].append(dict(state='confirmed_window',event_bar_utc=current['timestamp_utc'],known_at_utc=known))
        support=rows[i-half:terminal+1]
        out['known_at_utc']=_known(support);out['support_end_utc']=support[-1]['closed_at_utc']
        out['timestamp_discontinuities']=[dict(left=a['timestamp_utc'],right=b['timestamp_utc'])
            for a,b in zip(support,support[1:])
            if _time(b['timestamp_utc'])-_time(a['timestamp_utc'])!=timedelta(minutes=minutes)]
        out['continuity']='gap_or_calendar_unresolved' if out['timestamp_discontinuities'] else 'contiguous_native_bars'
        records.append(out)
    counts={s:sum(r['state']==s for r in records) for s in ('candidate','invalidated','confirmed_window')}
    return dict(schema=source['version'],source_url=source['url'],source_sha256=source['sha256'],
        source_identity=source['identity'],original_attachment_parity='unverified',
        requested_period=requested_period,effective_period=effective,required_right_bars=half,
        native_timeframe=tf,price_basis='native_high_low_not_ATR_shifted_arrow_coordinate',
        incomplete_older_edge_policy='excluded_until_full_older_support_project_guard',
        live_forming_bar_policy='excluded_closed_bar_replay_only',
        confirmation_meaning='bounded_comparison_window_complete_not_author_V_or_MSS',
        immutable_input_assumption='source_history_revision_requires_replay_not_silent_reuse',
        records=records,state_counts=counts,entry_permission=False)


def build(rows,tf,minutes):
    result={str(period):observe(rows,tf,minutes,period) for period in (8,25)}
    result.update({f'ghbdr_2018:{period}':observe(rows,tf,minutes,period,'ghbdr_2018') for period in (8,25)})
    return result
