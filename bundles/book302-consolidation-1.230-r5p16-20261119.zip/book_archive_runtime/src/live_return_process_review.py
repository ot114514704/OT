"""Source-stage and C-stage scenarios, not a frozen range label or trade gate.

Alexander Feb3: local reversal may coexist with higher-period range; Feb27:
force/1:1 do not prove trend breakout. Feb10 names the whole retraced object.
Native origin excursions challenge an *intact* pullback interpretation, but
cannot by themselves decide a liquidity sweep, degree or larger reversal.
"""
from copy import deepcopy
from math import isfinite

from .live_nested_stage_review import _same, _time
from .live_return_wave_scope import projection_owner

RESPONSES = {'not_reached', 'range_reached_no_close_beyond',
             'closed_beyond_then_returned', 'terminal_close_beyond_without_observed_follow',
             'sustained_close_beyond'}


def _stage_bound(stage, known, terminal):
    if (stage.get('basis') != 'same_period_confirmed_swing_order_hypothesis'
            or stage.get('author_adjudicated') is not False
            or stage.get('state') not in ('trend', 'range', 'transition')
            or stage.get('direction') not in ('up', 'down', None)
            or (stage.get('state')=='trend') != (stage.get('direction') in ('up','down'))
            or _time(stage['known_at_utc']) != known):
        return False
    return all(_time(p['confirmed_at_utc']) <= known and
               _time(p['pivot_timestamp_utc']) <= _time(terminal['pivot_timestamp_utc'])
               for p in stage['witnesses'])


def return_process_review(family, projection, current_regime):
    result = dict(status='return_process_unresolved',
        known_at_utc=projection['known_at_utc'], native_timeframe=family['timeframe'],
        measurement_source_leg_id=family['source_leg_id'],
        retraces_source_leg_id=projection.get('retraces_source_leg_id'),
        scenarios=[], outcomes_used=False, admission_changed=False,
        structural_degree_adjudicated=False, return_completion_adjudicated=False,
        liquidity_sweep_adjudicated=False, parent_task_adjudicated=False,
        trade_permission=False)
    try:
        owner=projection_owner(family,projection,family['timeframe'])
        review=projection.get('return_structure_review') or {}
        scope=review.get('accumulated_return_node_ownership') or {}
        known=_time(projection['known_at_utc'])
        if (not owner or scope.get('status')!='named_owner_and_reference_node_delivery_recorded'
                or scope.get('native_timeframe')!=family['timeframe']
                or scope.get('named_owner_id')!=owner['id']
                or _time(scope['known_at_utc'])!=known
                or not _same(scope['return_origin'],owner['terminal'])
                or not _same(scope['return_terminal'],projection['anchor'])):
            return {**result,'reason':'named_owner_or_accumulated_node_scope_unresolved'}
        regime=family['regime_at_source']
        # Source-stage evidence is frozen at B, even when the measurement
        # itself was admitted later by a whole-return reconsideration at C.
        source_known=_time(family.get('source_confirmed_at_utc',family['known_at_utc']))
        if source_known != max(_time(family['source_origin']['confirmed_at_utc']),
                               _time(family['source_terminal']['confirmed_at_utc'])):
            return {**result,'reason':'source_confirmation_time_unbound'}
        if (source_known>known
                or not _stage_bound(regime,source_known,family['source_terminal'])
                or not _stage_bound(current_regime,known,projection['anchor'])):
            return {**result,'reason':'source_or_C_stage_time_unbound'}
        origins=[n for n in scope['nodes'] if n['ownership_role']=='named_owner_origin']
        if (len(origins)!=1 or origins[0]['node_id']!=scope['named_owner_origin_node_id']
                or not _same(origins[0]['pivot'],owner['origin'])):
            return {**result,'reason':'named_origin_unresolved'}
        origin=origins[0]
        outer=[n for n in scope['nodes'] if n['ownership_role']=='preceding_reference_only'
               and n['reference_role']=='preceding_wave_origin']
        if len(outer)>1:return {**result,'reason':'ambiguous_larger_reference_origin'}
        for n in origins+outer:
            if (n.get('response') not in RESPONSES
                    or _time(n['pivot']['confirmed_at_utc'])>known
                    or _time(n['pivot']['pivot_timestamp_utc'])>_time(owner['terminal']['pivot_timestamp_utc'])):
                return {**result,'reason':'node_fact_or_time_unbound'}
        a,b,c=owner['origin']['price'],owner['terminal']['price'],projection['anchor']['price']
        if not all(isfinite(x) for x in (a,b,c)) or a==b:
            return {**result,'reason':'invalid_owner_prices'}
        sign=1 if b>a else -1
        distance=sign*(c-a)
        relation='inside_origin' if distance>0 else 'at_origin' if distance==0 else 'beyond_origin'
        stage_changed=(regime['state'],regime['direction'])!=(current_regime['state'],current_regime['direction'])
        challenged=relation!='inside_origin' or origin['response']!='not_reached'
        outer_node=outer[0] if outer else None
        outer_intact=(outer_node['response']=='not_reached') if outer_node else None
        state=('larger_reference_origin_challenged' if outer_node and not outer_intact else
               'named_origin_challenged_larger_reference_untouched' if challenged and outer_intact else
               'named_origin_challenged_larger_reference_unresolved' if challenged else
               'source_stage_changed_named_origin_untouched' if stage_changed else
               'named_origin_untouched_return_still_candidate')
        # These are tasks/conditional routes, not assertions that recovery,
        # liquidity or an author-named control node has already been proved.
        scenarios=[
            dict(id='measured_direction_recovery',observed=False,
                task='原测量方向恢复／区间探出后恢复候选' if challenged else '原测量方向延续候选',
                requires='同周期恢复力度与回调内部结构处理；若探出起点，还须实际收回与后续保持。',
                cancelled_by='本C失守，或被回调整段起点的外侧收盘继续被接受；需重新选回调对象，不静默挪C。'),
            dict(id='larger_wave_return_continues',observed=False,
                task='更大完整波段仍在回调／重整的竞争路径',
                requires='继续核完整参考的内部反向量尺、节点、左侧位置及上级任务；局部到位不替代整段完成。',
                cancelled_by='对该命名整体出现相应级别的恢复与结构接受；仅没碰外侧起点不构成取消证据。')]
        return {**result,'status':'conditional_return_process_recorded','state':state,
            'source_plan_mode':family['mode'],'source_stage':deepcopy(regime),
            'stage_at_C':deepcopy(current_regime),'swing_order_stage_changed':stage_changed,
            'named_owner_origin':deepcopy(owner['origin']),
            'C_relation_to_named_origin':relation,'named_origin_response':origin['response'],
            'named_origin_challenged':challenged,'larger_reference_origin':deepcopy(outer_node),
            'larger_reference_origin_untouched':outer_intact,
            'ordinary_intact_pullback_supported':False if challenged else None,
            'original_range_third_background_still_supported':
                (current_regime['state']=='range') if projection['ordinal']==3 else None,
            'original_range_sequence_background_still_supported':
                (current_regime['state']=='range') if projection['ordinal']>=3 else None,
            'scenarios':scenarios,
            'interpretation':'区分来源时背景、本C时摆点假设和命名波段起点挑战；保留原量尺作复核，不把几何探出叫已确认扫荡、同级结束或父级反转。'}
    except (KeyError,TypeError,ValueError,OverflowError):
        return {**result,'reason':'malformed_owner_stage_or_node_scope'}
