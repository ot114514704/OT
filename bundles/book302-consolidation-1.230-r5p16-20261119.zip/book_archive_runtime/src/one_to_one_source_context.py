"""Recover source-time predecessor from the EXISTING native ledger.

No new pivots, degree assignment or arbitrary previous chart high. Renderer
anchors can have a later display confirmation; match their physical native
point while retaining both clocks. Never move the original source endpoints.
"""
from .live_nested_stage_review import _native,_time
from .live_regime_one_to_one import _NativeWindow
from .live_wave_structure_context import WaveStructureIndex
from .live_source_wave_scope import source_wave_scope,known_envelope_component
from .native_market_sessions import research_calendar
from .one_to_one_structure_score import canonical_point,epoch


SCHEMA='owned_native_preceding_structure_receipt_v1'


def physical(point):
    p=canonical_point(point)
    return p['kind'],epoch(p['pivot_timestamp_utc']),float(p['price'])


class SourceContextReader:
    def __init__(self,scene):
        self.scene=scene;tf=scene['timeframe'];ctx=scene.get('execution_context') or {}
        state=ctx.get('native_timeframe_state')
        if not state:raise ValueError('original_native_timeframe_state_not_transported')
        snapshot=dict(snapshot_id=scene['snapshot_id'],as_of_utc=scene['cutoff_utc'],provider=scene['provider'],
            instrument=scene.get('symbol') or scene['instrument'],source_clock_alignment=ctx.get('source_clock_alignment') or {},
            timeframe_states={tf:state},chart_history={tf:dict(bars=ctx.get('bars') or [],source_mode='native_period_bars')})
        for key,value in [('provider',snapshot['provider']),('instrument',snapshot['instrument']),
                          ('snapshot_id',snapshot['snapshot_id']),('as_of_utc',snapshot['as_of_utc']),('timeframe',tf)]:
            if key in state and state[key]!=value:raise ValueError('native_state_identity_conflict:'+key)
            ledger=state.get('candidate_wave_ledger') or {}
            if key in ledger and ledger[key]!=value:raise ValueError('native_ledger_identity_conflict:'+key)
        for row in snapshot['chart_history'][tf]['bars']:
            if _time(row['timestamp_utc'])>_time(state['latest_closed_bar']['timestamp_utc']):continue
            if (row.get('symbol',snapshot['instrument'])!=snapshot['instrument'] or
                    row.get('instrument',snapshot['instrument'])!=snapshot['instrument']):
                raise ValueError('foreign_native_bar_symbol')
        _,raw,legs=_native(snapshot,tf,_time(scene['cutoff_utc']))
        self.native=_NativeWindow(raw,tf,_time(scene['cutoff_utc']),research_calendar(snapshot,tf))
        self.legs=legs;self.index=WaveStructureIndex(legs,self.native);self.points={};self.cache={}
        for leg in self.index.legs:
            for p in (leg['origin'],leg['terminal']):
                self.points.setdefault(physical(p),{})[p['confirmed_at_utc']]=p

    def _point(self,declared,known):
        p=canonical_point(declared)
        choices=[q for q in self.points.get(physical(p),{}).values()
                 if epoch(q['confirmed_at_utc'])<=epoch(p['confirmed_at_utc'])<=known]
        if len(choices)!=1:raise ValueError('missing_or_ambiguous_physical_native_anchor')
        return choices[0]

    def read(self,family):
        scene=self.scene;tf=scene['timeframe'];cutoff=scene['cutoff_utc']
        receipt=dict(schema=SCHEMA,status='unavailable',timeframe=tf,source_leg_id=family.get('source_leg_id'),
            measurement_id=family.get('measurement_id'),provider=scene['provider'],symbol=scene.get('symbol') or scene['instrument'],
            snapshot_id=scene['snapshot_id'],as_of_utc=cutoff,source_known_at_utc=family.get('known_at_utc'),
            author_degree_adjudicated=False,automatic_trade_permission=False,source_endpoints_changed=False)
        try:
            if family.get('timeframe')!=tf or not family.get('source_leg_id') or not family.get('measurement_id'):
                raise ValueError('source_identity_unbound')
            known=epoch(family['known_at_utc'])
            if known>epoch(cutoff):raise ValueError('source_not_yet_known')
            a=self._point(family['source_origin'],known);b=self._point(family['source_terminal'],known)
            if epoch(a['pivot_timestamp_utc'])>=epoch(b['pivot_timestamp_utc']):
                raise ValueError('source_anchor_order_unbound')
            key=(physical(a),physical(b),known)
            if key not in self.cache:
                scope=source_wave_scope(self.legs,self.native.raw,tf,a,b,family['known_at_utc'],_window_index=self.native.envelope)
                if scope.get('status')!='observed_same_period_zigzag_envelope':
                    raise ValueError('native_source_envelope_unresolved')
                ta,tb=_time(a['pivot_timestamp_utc']),_time(b['pivot_timestamp_utc'])
                if (not self.native.complete(ta,tb) or not self.native.envelope.contains(self.native.raw,tf,
                        ta,tb,*sorted((a['price'],b['price'])))):
                    raise ValueError('declared_AB_native_coverage_or_extreme_envelope_unresolved')
                components=[self.index.by_id[x] for x in scope['component_source_leg_ids']]
                start=next((i for i,l in enumerate(components) if physical(l['origin'])==physical(a)),None)
                if start is None:raise ValueError('declared_AB_not_bound_to_enclosing_component_chain')
                own=[];cursor=physical(a)
                for leg in components[start:]:
                    if (self.index.component_counts[leg['leg_id']]!=1 or physical(leg['origin'])!=cursor or
                            leg['temporal_order']!='sequential_confirmed_extrema' or
                            not known_envelope_component(leg,tf,self.native.raw,_time(family['known_at_utc']))):
                        raise ValueError('declared_AB_component_chain_unordered_or_unbound')
                    own.append(leg['leg_id']);cursor=physical(leg['terminal'])
                    if cursor==physical(b):break
                if cursor!=physical(b):raise ValueError('declared_AB_component_chain_not_complete')
                context=self.index.review(a,b,family['known_at_utc'])
                self.cache[key]=(scope,context,own)
            scope,context,own=self.cache[key]
            if context['status']!='preceding_wave_and_local_structure_bound':
                return dict(receipt,reason=context.get('reason',context['status']),context=context)
            old=family.get('source_opposing_wave_context') or {}
            if old.get('status')=='preceding_wave_and_local_structure_bound':
                wave=old.get('retraced_wave') or {};new=context['retraced_wave']
                if (old.get('native_timeframe')!=tf or epoch(old['known_at_utc'])!=known or
                        physical(wave['origin'])!=physical(new['origin']) or physical(wave['terminal'])!=physical(new['terminal'])):
                    raise ValueError('existing_named_predecessor_conflicts_with_native_ledger')
            return dict(receipt,status='native_source_predecessor_bound',context=context,
                source_component_ids=own,
                enclosing_native_source=dict(source_leg_id=scope['source_leg_id'],origin=scope['origin'],terminal=scope['terminal'],
                    component_source_leg_ids=scope['component_source_leg_ids']),
                source_scope_relation='same_native_envelope' if physical(scope['origin'])==physical(a) and physical(scope['terminal'])==physical(b)
                                      else 'declared_AB_is_verified_native_component_segment_of_larger_envelope',
                author_same_degree_relation='unadjudicated',
                original_source_origin=family['source_origin'],original_source_terminal=family['source_terminal'],
                native_source_origin=a,native_source_terminal=b,
                binding='existing_named_predecessor_rehydrated' if old.get('status')=='preceding_wave_and_local_structure_bound'
                        else 'existing_native_ledger_connected_to_same_physical_AB',
                node_count=len(context['nodes']),intrabar_order_inferred=False)
        except (KeyError,ValueError,TypeError) as exc:
            return dict(receipt,reason=str(exc))


def attach_source_contexts(scene):
    try:reader=SourceContextReader(scene);error=None
    except (KeyError,ValueError,TypeError) as exc:reader=None;error=str(exc)
    for obj in scene.get('objects',[]):
        e=obj.get('evidence') or {};f=e.get('record')
        if obj.get('layer')!='one_to_one' or 'projection' not in e or not isinstance(f,dict):continue
        e['native_source_structure']=(reader.read(f) if reader else dict(schema=SCHEMA,status='unavailable',
            reason=error,source_leg_id=f.get('source_leg_id'),timeframe=scene['timeframe'],as_of_utc=scene['cutoff_utc'],
            author_degree_adjudicated=False,automatic_trade_permission=False))
    return scene
