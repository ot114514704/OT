"""Same native extrema, converting each high/low once instead of per window.

No persistent result, drawing, observation, resampling or period substitution.
The caller supplies its actual closed native prefix. Python's original ordered
max/min and inclusive ties remain intact, including repeated equal extrema.
"""


def scan(rows,span):
    # Preserve the existing scalar path for unusual radius arguments.
    if type(span) is not int or span<0:return None
    n=len(rows)
    if n<=2*span:return [],[]
    high=[float(row['high']) for row in rows]
    low=[float(row['low']) for row in rows]
    highs=[];lows=[]
    for i in range(span,n-span):
        if high[i]>=max(high[i-span:i+span+1]):highs.append(i)
        if low[i]<=min(low[i-span:i+span+1]):lows.append(i)
    return highs,lows
