"""Closed-price follow observations, separate from frozen source strength.

No new grade, trade gate, timeout, stop movement or reversal inference.
Basic directional follow and close beyond the trigger extreme are distinct.
"""
from .force_strength_model import BANDS,epoch,iso


LABELS={'not_triggered':'未触发','inactive':'当前参考退出','trigger_only':'触发当根',
        'await_follow':'待跟随','directional_progress':'顺向推进','close_extension':'收盘扩张',
        'extension_given_back':'扩张回吐','adverse_close':'反向回吐',
        'trigger_bar_unavailable':'缺触发K'}


def follow(force,space,bars):
    if (space['owner_id']!=force.get('id') or space['source_id']!=force.get('source_id') or
        space['timeframe']!=force['timeframe'] or space['band'] not in BANDS or
        space['route'] not in ('ratio_reclaim','node_retest')):
        raise ValueError('Foreign follow source or route')
    known=epoch(force['known_at_utc']);end=epoch(space['review_end_utc'])
    if not known<=end<=epoch(space['as_of_utc']):raise ValueError('Follow clocks out of order')
    trigger=space['trigger_at_utc'];sign=1 if force['points'][1][1]>force['points'][0][1] else -1
    result=dict(schema='force_post_trigger_v1',owner_id=force.get('id'),source_id=force.get('source_id'),
        timeframe=force['timeframe'],route=space['route'],band=space['band'],as_of_utc=space['as_of_utc'],
        review_end_utc=space['review_end_utc'],trigger_at_utc=trigger,
        attempt_id=space.get('current_attempt_id'),state='not_triggered',
        current_observation=False,post_closed_n=0,first_directional_progress_at_utc=None,
        first_extreme_close_extension_at_utc=None,first_extension_giveback_at_utc=None,
        trigger_extreme_price=None,net_close_progress_points=None,net_close_progress_in_original_R=None,
        signed_close_path_efficiency=None,mean_adjacent_range_overlap=None,directional_body_fraction=None,
        source_grade_changed=False,parent_reversal='not_adjudicated',
        required_for_all_entries=False,automatic_trade_permission=False)
    if not trigger:return result
    t=epoch(trigger)
    if not known<=t<=end:raise ValueError('Follow trigger outside source prefix')
    if not space['current_price_space_available']:return dict(result,state='inactive')
    visible=sorted((b for b in bars if b['closed']<=end),key=lambda b:b['t'])
    signal=[b for b in visible if b['closed']==t]
    if len(signal)!=1:return dict(result,state='trigger_bar_unavailable')
    signal=signal[0];price=space['signal_geometry']['reference_price']
    if signal['close']!=price:raise ValueError('Follow signal close does not match route trigger')
    rows=[b for b in visible if b['t']>=t]
    extreme=signal['high'] if sign>0 else signal['low']
    result.update(current_observation=True,post_closed_n=len(rows),trigger_extreme_price=extreme)
    if not rows:return dict(result,state='trigger_only')
    first_direction=None;first_extension=None;first_giveback=None
    overlap=[];path=0.;previous=signal
    for b in rows:
        directional=sign*(b['close']-b['open'])>0
        if first_direction is None and directional and sign*(b['close']-price)>0:first_direction=iso(b['closed'])
        if first_extension is None and directional and sign*(b['close']-extreme)>0:first_extension=iso(b['closed'])
        if first_extension and first_giveback is None and sign*(b['close']-extreme)<=0:first_giveback=iso(b['closed'])
        union=max(previous['high'],b['high'])-min(previous['low'],b['low'])
        if union>0:
            overlap.append(max(0.,min(previous['high'],b['high'])-max(previous['low'],b['low']))/union)
        path+=abs(b['close']-previous['close']);previous=b
    progress=sign*(rows[-1]['close']-price)
    if first_extension:
        state='close_extension' if sign*(rows[-1]['close']-extreme)>0 else 'extension_given_back'
    elif progress<0:state='adverse_close'
    elif first_direction:state='directional_progress'
    else:state='await_follow'
    return dict(result,state=state,first_directional_progress_at_utc=first_direction,
        first_extreme_close_extension_at_utc=first_extension,first_extension_giveback_at_utc=first_giveback,
        net_close_progress_points=progress,
        net_close_progress_in_original_R=progress/space['signal_geometry']['risk_points'],
        signed_close_path_efficiency=progress/path if path else 0.,
        mean_adjacent_range_overlap=sum(overlap)/len(overlap) if overlap else None,
        directional_body_fraction=sum(sign*(b['close']-b['open'])>0 for b in rows)/len(rows))


def follow_plan(force,space_plan,bars):
    return dict(schema='force_post_trigger_plan_v1',owner_id=force.get('id'),source_id=force.get('source_id'),
        timeframe=force['timeframe'],routes={k:follow(force,s,bars) for k,s in space_plan['routes'].items()},
        selected_route=None,automatic_trade_permission=False)
