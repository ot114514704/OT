"""Join source-only force/structure evidence to an independently owned task.

The geometry ledger is searched automatically; no human source picker is
required. Native delivery feeds a conditional higher-context producer when no
independent background has been supplied. Its hypotheses are not author labels
or calibrated trading decisions. Unresolved context stays unresolved, and all
source evidence stops at B confirmation.
"""
from datetime import timedelta
from bisect import bisect_right
import hashlib
import json

try:
    from .live_nested_stage_review import MINUTES, _native, _leg, _same, _time, _number
    from .live_force_ob_review import review_force_ob_candidates
    from .live_xauusd_multitimeframe import OHLCBar
    from .live_parent_objective_context import build_parent_objective_review
    from .live_one_to_one_admission import build_one_to_one_admission
    from .native_market_sessions import adjacent_native_bars, session_offset, METHOD as SESSION_METHOD
    from .live_source_wave_scope import source_wave_scope, dominant_source_candidates, known_envelope_component, _EnvelopeWindowIndex
    from .native_close_witness_runs import encode_close_witnesses, source_close_witness_encoder
except ImportError:
    from live_nested_stage_review import MINUTES, _native, _leg, _same, _time, _number
    from live_force_ob_review import review_force_ob_candidates
    from live_xauusd_multitimeframe import OHLCBar
    from live_parent_objective_context import build_parent_objective_review
    from live_one_to_one_admission import build_one_to_one_admission
    from native_market_sessions import adjacent_native_bars, session_offset, METHOD as SESSION_METHOD
    from live_source_wave_scope import source_wave_scope, dominant_source_candidates, known_envelope_component, _EnvelopeWindowIndex
    from native_close_witness_runs import encode_close_witnesses, source_close_witness_encoder


METHOD = "source_only_force_structure_task_join_v2"
COMPONENT_FORCE_POLICY = 'all_verified_source_direction_pushes_v1'


def _confirmed_unpaired_sources(snapshot, ledger):
    """Inventory confirmed B legs omitted by the paired A/B/C ledger.

    This is a candidate inventory, not a drawing decision. Every candidate
    still needs its own source-time force, structure and parent-task review.
    """
    timeframe = ledger.get('timeframe')
    if timeframe not in MINUTES:
        return []
    states = snapshot.get('timeframe_states') or {
        row['timeframe']: row for row in (snapshot.get('analysis_report') or {}).get('timeframes', [])
        if isinstance(row, dict) and row.get('timeframe') in MINUTES}
    legs = ((states.get(timeframe) or {}).get('candidate_wave_ledger') or {}).get('legs') or []
    if not legs:
        return []
    paired = {(record.get('source_leg_id'),
               (record.get('source_origin') or {}).get('pivot_timestamp_utc'),
               (record.get('source_origin') or {}).get('price'),
               (record.get('source_terminal') or {}).get('pivot_timestamp_utc'),
               (record.get('source_terminal') or {}).get('price'))
              for record in ledger.get('records') or []}
    candidates = []
    seen = set()
    for source in legs:
        if not isinstance(source, dict):
            continue
        try:
            a, b = source['origin'], source['terminal']
            known = _time(b['confirmed_at_utc'])
            key = (source['leg_id'], a['pivot_timestamp_utc'], a['price'],
                   b['pivot_timestamp_utc'], b['price'])
            if (source.get('timeframe') != timeframe or key in paired or key in seen or
                    known > _time(snapshot['as_of_utc']) or
                    not _time(a['pivot_timestamp_utc']) < _time(b['pivot_timestamp_utc'])):
                continue
            identity = [snapshot['instrument'], snapshot['provider'], timeframe,
                        source['leg_id'], a['pivot_timestamp_utc'], b['pivot_timestamp_utc'],
                        a['price'], b['price']]
        except (KeyError, TypeError, ValueError, AttributeError):
            continue
        seen.add(key)
        measurement_id = f'{timeframe}:confirmed_source_only:' + hashlib.sha256(
            json.dumps(identity, separators=(',', ':')).encode()).hexdigest()[:24]
        candidates.append(dict(snapshot_id=snapshot['snapshot_id'], as_of_utc=snapshot['as_of_utc'],
                               timeframe=timeframe, measurement_id=measurement_id,
                               source_leg_id=source['leg_id'], source_origin=a, source_terminal=b,
                               direction_observation=source.get('direction_observation'),
                               source_geometry='adjacent_native_wave',
                               component_source_leg_ids=[source['leg_id']], trade_permission=False))
    return candidates


def _confirmed_composite_sources(snapshot, ledger):
    """Inventory a two-push NET span before a later C exists.

    Three connected native legs describe push/return/push.  Their outer A/B
    endpoints make one equal-height ruler; the internal travel is never added
    as three absolute distances.  Inventory is not source or trade admission.
    """
    timeframe = ledger.get('timeframe')
    if timeframe not in MINUTES:
        return []
    states = snapshot.get('timeframe_states') or {
        row['timeframe']: row for row in (snapshot.get('analysis_report') or {}).get('timeframes', [])
        if isinstance(row, dict) and row.get('timeframe') in MINUTES}
    legs = ((states.get(timeframe) or {}).get('candidate_wave_ledger') or {}).get('legs') or []
    history = ((snapshot.get('chart_history') or {}).get(timeframe) or {}).get('bars') or []
    if not isinstance(legs, list) or len(legs) < 3 or not isinstance(history, list):
        return []
    try:
        raw = {_time(bar['timestamp_utc']): bar for bar in history}
        cutoff = _time(snapshot['as_of_utc'])
        if len(raw) != len(history):
            return []
        window_index = _EnvelopeWindowIndex(raw,timeframe)
    except (KeyError, ValueError, TypeError, AttributeError):
        return []
    paired = {(row.get('source_leg_id'),
               (row.get('source_origin') or {}).get('pivot_timestamp_utc'),
               (row.get('source_terminal') or {}).get('pivot_timestamp_utc'))
              for row in ledger.get('records') or []}
    candidates = []
    for i in range(len(legs)-2):
        components = legs[i:i+3]
        try:
            first, middle, last = components
            a, b = first['origin'], last['terminal']
            known = _time(b['confirmed_at_utc'])
            if known > cutoff or any(not _leg(part, timeframe, raw, known) for part in components):
                continue
            if (not _same(first['terminal'], middle['origin']) or
                    not _same(middle['terminal'], last['origin']) or
                    first['direction_observation'] != last['direction_observation'] or
                    middle['direction_observation'] == first['direction_observation'] or
                    a['kind'] == b['kind']):
                continue
            upward = b['price'] > a['price']
            if (upward != (first['direction_observation'] == 'up') or
                    (b['price'] <= first['terminal']['price'] if upward else
                     b['price'] >= first['terminal']['price'])):
                continue
            path_start, path_end = _time(a['pivot_timestamp_utc']), _time(b['pivot_timestamp_utc'])
            low, high = sorted((a['price'], b['price']))
            if not window_index.contains(raw,timeframe,path_start,path_end,low,high):
                continue
            ids = [part['leg_id'] for part in components]
            digest = hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()[:24]
            source_id = f'{timeframe}:enclosing:{digest}'
            if (source_id, a['pivot_timestamp_utc'], b['pivot_timestamp_utc']) in paired:
                continue
            identity = [snapshot['instrument'],snapshot['provider'],timeframe,source_id,
                        a['pivot_timestamp_utc'],b['pivot_timestamp_utc'],a['price'],b['price']]
            measurement_id = f'{timeframe}:confirmed_composite_source_only:' + hashlib.sha256(
                json.dumps(identity,separators=(',',':')).encode()).hexdigest()[:24]
            candidates.append(dict(snapshot_id=snapshot['snapshot_id'],as_of_utc=snapshot['as_of_utc'],
                timeframe=timeframe,measurement_id=measurement_id,source_leg_id=source_id,
                source_origin=a,source_terminal=b,direction_observation=first['direction_observation'],
                source_geometry='enclosing_native_wave',component_source_leg_ids=ids,
                composite_span_semantics='outer_A_to_B_net_distance_not_sum_of_push_lengths',
                trade_permission=False))
        except (KeyError, ValueError, TypeError, AttributeError):
            continue
    # The old three-leg inventory leaves a later sub-high/sub-low as the
    # source even when several connected pushes belong to one outer swing.
    for source in dominant_source_candidates(snapshot,timeframe,legs):
        a,b = source['origin'],source['terminal']
        source_id = source['leg_id']
        if ((source_id,a['pivot_timestamp_utc'],b['pivot_timestamp_utc']) in paired
                or any(row['source_leg_id']==source_id for row in candidates)):
            continue
        identity=[snapshot['instrument'],snapshot['provider'],timeframe,source_id,
                  a['pivot_timestamp_utc'],b['pivot_timestamp_utc'],a['price'],b['price']]
        measurement_id=f'{timeframe}:confirmed_composite_source_only:' + hashlib.sha256(
            json.dumps(identity,separators=(',',':')).encode()).hexdigest()[:24]
        candidates.append(dict(snapshot_id=snapshot['snapshot_id'],as_of_utc=snapshot['as_of_utc'],
            timeframe=timeframe,measurement_id=measurement_id,source_leg_id=source_id,
            source_origin=a,source_terminal=b,direction_observation=source['direction_observation'],
            source_geometry='enclosing_native_wave',component_source_leg_ids=source['component_source_leg_ids'],
            composite_span_semantics='outer_A_to_B_net_distance_not_sum_of_push_lengths',trade_permission=False))
    return candidates


def _verified_enclosing_source(timeframe, record, raw, legs, known):
    """Return a synthetic net-span identity only for an exact native chain."""
    ids = record.get('component_source_leg_ids') or []
    if not isinstance(ids, list) or len(ids) < 3 or len(ids) % 2 != 1:
        raise ValueError('enclosing component count invalid')
    positions = [i for i, leg in enumerate(legs) if isinstance(leg, dict) and leg.get('leg_id') in ids]
    if (len(positions) != len(ids) or positions != list(range(positions[0],positions[0]+len(ids)))):
        raise ValueError('enclosing component sequence invalid')
    components = [legs[i] for i in positions]
    digest = hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()[:24]
    if (record.get('source_leg_id') != f'{timeframe}:enclosing:{digest}' or
            [part.get('leg_id') for part in components] != ids or
            not all(known_envelope_component(part,timeframe,raw,known) for part in components) or
            not all(_same(left['terminal'],right['origin']) for left,right in zip(components,components[1:]))):
        raise ValueError('enclosing source chain not native')
    a,b = record['source_origin'],record['source_terminal']
    if not _same(components[0]['origin'],a) or not _same(components[-1]['terminal'],b):
        raise ValueError('enclosing source endpoints differ')
    low,high=sorted((a['price'],b['price']))
    start,end=_time(a['pivot_timestamp_utc']),_time(b['pivot_timestamp_utc'])
    path=[bar for stamp,bar in raw.items() if start<=stamp<=end]
    if not path or any(not low<=bar['low']<=min(bar['open'],bar['close'])<=
                       max(bar['open'],bar['close'])<=bar['high']<=high for bar in path):
        raise ValueError('enclosing OHLC outside source')
    source=dict(leg_id=record['source_leg_id'],timeframe=timeframe,origin=a,terminal=b,
                direction_observation=record['direction_observation'],
                temporal_order='sequential_confirmed_extrema')
    if not _leg(source,timeframe,raw,known):
        raise ValueError('enclosing source identity invalid')
    return source,components


def _iso(value):
    return value.isoformat().replace("+00:00", "Z")


def _path(raw, a, b, tf, *, calendar_offset=None):
    start, end = _time(a["pivot_timestamp_utc"]), _time(b["pivot_timestamp_utc"])
    rows = [raw[t] for t in sorted(raw) if start <= t <= end]
    if not rows or _time(rows[0]["timestamp_utc"]) != start or _time(rows[-1]["timestamp_utc"]) != end:
        raise ValueError("source path incomplete")
    gap = any(not adjacent_native_bars(_time(left['timestamp_utc']),_time(right['timestamp_utc']),MINUTES[tf],calendar_offset)
              for left, right in zip(rows, rows[1:]))
    signed = b["price"]-a["price"]
    sign = 1 if signed > 0 else -1
    minutes = (len(rows)-1)*MINUTES[tf]
    # Keep the adjacent pre-source close as a boundary witness. A can be the
    # high/low of a candle that itself closes through an already-known node;
    # starting comparisons at the next candle would miss that real crossing.
    preceding_bar = raw.get(start-timedelta(minutes=MINUTES[tf]))
    if preceding_bar is None:
        prior=max((t for t in raw if t<start),default=None)
        if prior is not None and adjacent_native_bars(prior,start,MINUTES[tf],calendar_offset):
            preceding_bar=raw[prior]
    return {"amplitude": abs(signed), "net_close_progress": sign*(rows[-1]["close"]-rows[0]["close"]),
            "points_per_minute": None if gap or not minutes else abs(signed)/minutes,
            "rate_basis":"observed_native_bar_intervals_excluding_scheduled_closures",
            "elapsed_calendar_minutes":(end-start).total_seconds()/60,
            "session_coverage_method":SESSION_METHOD if calendar_offset is not None else None,
            "coverage_gap": gap, "bars": rows, "preceding_bar": preceding_bar}


def _close_delivery(path, reference, upward, *, compact_witnesses=False, _witness_encoder=None):
    if reference and reference.get('confirmed_at_utc'):
        # An older pivot may become observable DURING this source. Only
        # crossings after that observation can establish its delivery.
        known = reference['confirmed_at_utc']
        original = path['bars']
        start = next((i for i, bar in enumerate(original) if bar['timestamp_utc'] >= known), len(original))
        path = {**path, 'bars': original[start:],
                'preceding_bar': original[start-1] if start else path.get('preceding_bar')}
    beyond = lambda price: price > reference["price"] if upward else price < reference["price"]
    preceding = path.get("preceding_bar")
    first_cross = bool(reference and path['bars'] and preceding and not beyond(preceding["close"])
                       and beyond(path["bars"][0]["close"]))
    crossings = [path['bars'][0]['timestamp_utc']] if first_cross else []
    sustained, first_touch, any_close_beyond = [], None, False
    if reference:
        previous_beyond = None
        for bar in path['bars']:
            close_beyond = beyond(bar['close'])
            if previous_beyond is not None and not previous_beyond and close_beyond:
                crossings.append(bar['timestamp_utc'])
            elif previous_beyond is not None and previous_beyond and close_beyond:
                sustained.append(bar['timestamp_utc'])
            if first_touch is None and (bar['high'] >= reference['price'] if upward else bar['low'] <= reference['price']):
                first_touch = bar['timestamp_utc']
            any_close_beyond = any_close_beyond or close_beyond
            previous_beyond = close_beyond
    terminal = bool(reference and path['bars'] and beyond(path["bars"][-1]["close"]))
    # A failed earlier crossing cannot lend its follow-through to a later
    # single close. The source must still hold its LAST observed attempt.
    confirmed_follow = [utc for utc in sustained if crossings and utc > crossings[-1]]
    return dict(reference=reference, consecutive_close_witnesses=(
                    (_witness_encoder or encode_close_witnesses)(sustained) if compact_witnesses else sustained),
                first_source_close_through_bar_open_utc=crossings[0] if crossings else None,
                latest_source_close_through_bar_open_utc=crossings[-1] if crossings else None,
                first_range_reach_bar_open_utc=first_touch,
                any_source_close_beyond=bool(any_close_beyond),
                source_first_bar_cross=first_cross,
                pre_source_close_witness=preceding if first_cross else None,
                already_beyond_at_first_source_close=bool(reference and path['bars'] and beyond(path["bars"][0]["close"]) and not first_cross),
                terminal_close_beyond=terminal,
                sustained_source_close=bool(confirmed_follow and terminal and not path["coverage_gap"]))


def _source_node_scope(path, refs, upward, timeframe, named_node, outer_node):
    """Inventory what THIS source changed, without naming a convenient pivot as trend.

    Adding an older, farther extreme may change the outer-envelope diagnostic,
    but cannot erase an already observed local node crossing. These are native
    swing candidates, not automatically SNR, protected nodes, or author labels.
    """
    nodes=[]
    # Pure timestamp parsing is shared only across nodes of this source path.
    # Every node still computes all crossing/follow/return predicates itself.
    witness_encoder = source_close_witness_encoder()
    for point in sorted(refs.values(),key=lambda p:p["pivot_timestamp_utc"]):
        # Only evidence representation changes. All crossing/follow/return
        # predicates above still consume the complete native close sequence.
        delivery=_close_delivery(path,point,upward,compact_witnesses=True, _witness_encoder=witness_encoder)
        status=("sustained_close_through" if delivery["sustained_source_close"] else
            "closed_through_then_returned" if delivery["first_source_close_through_bar_open_utc"] and not delivery["terminal_close_beyond"] else
            "close_through_without_follow" if delivery["first_source_close_through_bar_open_utc"] else
            "already_beyond_before_observed_cross" if delivery["already_beyond_at_first_source_close"] else
            "range_reached_no_close_through" if delivery["first_range_reach_bar_open_utc"] else "not_reached")
        nodes.append(dict(node_id=f'{timeframe}:{point["pivot_timestamp_utc"]}:{point["kind"]}',
            timeframe=timeframe,pivot=point,response=status,**{k:v for k,v in delivery.items() if k!="reference"},
            independent_control_node=bool(named_node and _same(point,named_node)),
            loaded_outer_extreme=bool(outer_node and _same(point,outer_node))))
    crossed=[n for n in nodes if n["sustained_source_close"]]
    ahead=[n for n in nodes if (n["pivot"]["price"]>path["bars"][-1]["close"] if upward else n["pivot"]["price"]<path["bars"][-1]["close"])]
    scope=("local_nodes_crossed_outer_unbroken" if crossed and any(n["loaded_outer_extreme"] for n in ahead) else
           "loaded_outer_and_local_nodes_crossed" if crossed else "no_sustained_source_node_crossing")
    readout=("这段收过局部节点并有后续收盘，前方仍有未越过的旧拐点；不能升级为整段趋势突破。"
        if scope=="local_nodes_crossed_outer_unbroken" else
        "这段也收过了已载外侧极值；是否属于当前趋势控制节点仍须结合背景。"
        if crossed else "这段尚无可核对的节点越过与后续收盘；有幅度不等于突破结构。")
    return dict(status=scope,timeframe=timeframe,nodes=nodes,
        handled_node_ids=[n["node_id"] for n in crossed],remaining_ahead_node_ids=[n["node_id"] for n in ahead],
        control_node_independently_supplied=bool(named_node),readout=readout,
        source_message_ids=["7608052678914466373","7608052678914466367","7685764649186122721"],
        witness_time_semantics="native_bar_open_labels_not_close_times",
        threshold_rule="observed_cross_then_later_close_not_a_fixed_acceptance_rule",trade_permission=False)


def _named_node(context, refs, timeframe, snapshot):
    """Locate the independently selected control node, not a convenient pivot.

    An opaque string cannot establish which price the source changed. The
    node must be a pre-source native point already present in this ledger.
    Role/ownership still belongs to the independent background producer.
    """
    node = context.get("named_structure_node") if isinstance(context, dict) else None
    if not isinstance(node, dict):
        return None
    if (node.get("node_id") != context.get("named_structure_node_id")
            or node.get("timeframe") != timeframe
            or node.get("provider", snapshot["provider"]) != snapshot["provider"]
            or node.get("instrument", snapshot["instrument"]) != snapshot["instrument"]):
        return None
    pivot = node.get("pivot")
    return pivot if isinstance(pivot, dict) and any(_same(pivot, point) for point in refs.values()) else None


def _first_force_retracement_review(relative, node_scope, named_delivery, force):
    """Keep Alexander's first-force branches open until their objects are bound.

    Size/rate comparisons are observations, not a fixed strength score. A
    native pivot is not automatically the preceding 3-3-2 or fourth-wave high.
    This review must not promote a source or supply an entry level.
    """
    def relation(left, right):
        if left is None or right is None:
            return 'unknown'
        return 'larger' if left > right else 'smaller' if left < right else 'similar'

    size = relation(relative.get('source_amplitude'), relative.get('prior_opposing_amplitude'))
    pace = relation(relative.get('source_points_per_minute'), relative.get('prior_opposing_points_per_minute'))
    named = bool(named_delivery.get('sustained_source_close'))
    local = bool(node_scope.get('handled_node_ids'))
    return dict(
        status='comparative_evidence_only_first_force_role_unadjudicated',
        first_force_role_adjudicated=False,
        author_critical_wave_node_bound=False,
        relative_size=size,
        relative_rate=pace,
        structure_delivery=('independently_named_native_node' if named else
                            'local_native_candidate_only' if local else 'not_observed'),
        outer_prior_extreme_still_ahead=bool(node_scope.get('remaining_ahead_node_ids')),
        separate_urgent_force_screen_passed=bool(force),
        branch_selection='both_conditional_families_remain_open',
        conditional_families=[
            dict(name='strong_first_force_retracement_family',
                 requires=['first_force_role_bound','meaningful_left_structure_role_bound',
                           'size_rate_and_delivery_interpreted_in_parent_task'],
                 locations=['author_50_percent_or_above_region_anchor_unbound'],
                 not_an_entry=True),
            dict(name='weak_or_key_high_unbroken_retracement_family',
                 requires=['first_force_role_bound','author_key_high_or_low_bound',
                           'weakness_or_failed_cross_interpreted_in_parent_task'],
                 locations=['OTE_candidate','OB_candidate','second_build_candidate','second_sweep_candidate'],
                 next_check='whether_stopping_location_actually_removed_needed_liquidity',
                 not_an_entry=True)],
        theory_source_message_ids=['7602322931794615203','7602323140890502153',
                                   '7676543496751127699','7676550586231557407'],
        theory_time_role='later_method_can_explain_but_not_backfill_market_observation',
        trade_permission=False)


class _SourcePrefixIndex:
    """Native bar objects shared only inside one immutable attachment.

    Every source still gets its exact B-confirmation prefix. Constructing a
    future bar object here is not admitting it to that prefix or any score.
    No derived source decision, interval or evidence is reused.
    """

    def __init__(self, raw, timeframe):
        duration=timedelta(minutes=MINUTES[timeframe])
        self.items=sorted(raw.items())
        self.ends=[t+duration for t,_ in self.items]
        self.bars=[OHLCBar(timestamp_utc=t,open=b['open'],high=b['high'],low=b['low'],close=b['close'],
                           timeframe=timeframe) for t,b in self.items]
        try:from .native_force_prefix_index import ForcePrefixIndex
        except ImportError:from native_force_prefix_index import ForcePrefixIndex
        self.force_index=ForcePrefixIndex(self.bars,_iso)

    def prefix(self, known):
        count=bisect_right(self.ends,known)
        return dict(self.items[:count]), self.force_index.prefix(count)


def build_source_selection_review(snapshot, timeframe, record, *, parent_task=None, target_graph=None,
                                  _background_reader=None, _native_reader=None, _scope_indexes=None):
    result = dict(method_version=METHOD, status="source_evidence_unavailable",
        component_force_policy=COMPONENT_FORCE_POLICY,
        timeframe=timeframe, snapshot_id=snapshot.get("snapshot_id"), as_of_utc=snapshot.get("as_of_utc"),
        measurement_id=record.get("measurement_id"), source_leg_id=record.get("source_leg_id"),
        source_delivery_evidence_ready=False, eligible_source_for_owned_task=False,
        first_force_leg_adjudicated=False, pullback_completed=False, trade_permission=False,
        source_background_ready_at_confirmation=False,
        blockers=[], market_evidence=[], source_refs=[], background_direction_review=None)
    issues = result["blockers"]
    try:
        # Compact persisted snapshots keep the SAME native state in the report.
        # Never replace a present-but-invalid root state with another source.
        if not snapshot.get("timeframe_states"):
            report_rows=(snapshot.get("analysis_report") or {}).get("timeframes") or []
            snapshot={**snapshot,"timeframe_states":{row["timeframe"]:row for row in report_rows
                       if isinstance(row,dict) and row.get("timeframe") in MINUTES}}
        cutoff = _time(snapshot["as_of_utc"])
        state, raw, legs = (_native_reader(snapshot, timeframe, cutoff)
                            if _native_reader is not None else _native(snapshot, timeframe, cutoff))
        a, b = record["source_origin"], record["source_terminal"]
        known = _time(b["confirmed_at_utc"])
        source = next((leg for leg in legs if leg["leg_id"] == record["source_leg_id"]), None)
        components = None
        if source is None and record.get("source_geometry") == "enclosing_native_wave":
            source,components=_verified_enclosing_source(timeframe,record,raw,legs,known)
        if (not source or not _same(source["origin"],a) or not _same(source["terminal"],b)
                or not _leg(source,timeframe,raw,known) or known > cutoff
                or record.get("snapshot_id") != snapshot.get("snapshot_id")
                or record.get("as_of_utc") != snapshot.get("as_of_utc") or record.get("timeframe") != timeframe):
            raise ValueError("source identity or native path invalid")
        duration = timedelta(minutes=MINUTES[timeframe])
        # Neither C nor the subsequent successful/failed target contributes to selection.
        prepared_bars=None
        if _scope_indexes is None:
            before = {t:bar for t,bar in raw.items() if t+duration <= known}
        else:
            prefix_key=('source_prefix',id(raw),timeframe)
            if prefix_key not in _scope_indexes:
                _scope_indexes[prefix_key]=_SourcePrefixIndex(raw,timeframe)
            before,prepared_bars=_scope_indexes[prefix_key].prefix(known)
        if _scope_indexes is None:
            scope = source_wave_scope(legs,before,timeframe,a,b,_iso(known))
        else:
            # Share only the immutable native OHLC interval index within this
            # attachment. Each scope still validates its own confirmation clock;
            # every queried interval ends at B, before that clock. Future bars
            # outside that interval cannot affect its bounds or validity.
            index_key = (id(raw),timeframe)
            if index_key not in _scope_indexes:
                _scope_indexes[index_key] = _EnvelopeWindowIndex(raw,timeframe)
            scope = source_wave_scope(legs,raw,timeframe,a,b,_iso(known),
                                      _window_index=_scope_indexes[index_key])
        result['source_wave_scope'] = scope
        if scope.get('internal_origin'):
            issues.append('internal_subpivot_not_same_period_wave_origin')
        calendar_offset=session_offset(snapshot)
        path = _path(before,a,b,timeframe,calendar_offset=calendar_offset)
        previous = next((leg for leg in reversed(legs) if _same(leg["terminal"],a)
                         and leg["direction_observation"] != source["direction_observation"]
                         and _leg(leg,timeframe,before,known)), None)
        comparison = _path(before,previous["origin"],previous["terminal"],timeframe,calendar_offset=calendar_offset) if previous else None
        result["source_known_at_utc"] = _iso(known)
        result["source_direction"] = source["direction_observation"]
        result['session_coverage_method']=path['session_coverage_method']
        result["relative_effort"] = dict(
            source_amplitude=path["amplitude"], source_net_close_progress=path["net_close_progress"],
            source_points_per_minute=path["points_per_minute"],
            prior_opposing_leg_id=previous["leg_id"] if previous else None,
            prior_opposing_amplitude=comparison["amplitude"] if comparison else None,
            prior_opposing_points_per_minute=comparison["points_per_minute"] if comparison else None,
            larger_than_previous=comparison is not None and path["amplitude"]>comparison["amplitude"],
            faster_than_previous=bool(comparison and path["points_per_minute"] is not None
                and comparison["points_per_minute"] is not None
                and path["points_per_minute"]>comparison["points_per_minute"]))
        if path["coverage_gap"] or (comparison and comparison["coverage_gap"]):
            issues.append("source_or_counter_path_coverage_gap")
        if path["net_close_progress"] <= 0:
            issues.append("extrema_direction_not_supported_by_close_path")
        if comparison is None:
            issues.append("preceding_counter_delivery_missing")
        bars = prepared_bars if prepared_bars is not None else [
            OHLCBar(timestamp_utc=t, open=bar["open"],high=bar["high"],low=bar["low"],close=bar["close"],
                    timeframe=timeframe) for t,bar in sorted(before.items())]
        forces = review_force_ob_candidates(bars,{"legs":[source]})["force_leg_candidates"]
        force = next((row for row in forces if row["force_leg_id"] == source["leg_id"]), None)
        if not force and components:
            # A verified multi-push net span is not necessarily one urgent
            # impulse. Inspect every native push in its own direction; the
            # internal returns cannot lend their force to this source. The
            # old three-component special case missed larger verified spans.
            push_legs = [part for part in components
                         if part['direction_observation'] == source['direction_observation']
                         and _leg(part,timeframe,before,known)]
            push_forces = review_force_ob_candidates(bars,{"legs":push_legs})["force_leg_candidates"]
            basis_forces = [row for part in push_legs for row in push_forces
                            if row["force_leg_id"] == part["leg_id"]]
            force = next(iter(basis_forces),None)
            result['composite_force_basis_leg_id'] = force['force_leg_id'] if force else None
            result['composite_force_basis_leg_ids'] = list(dict.fromkeys(
                row['force_leg_id'] for row in basis_forces))
        result["force_screen"] = force
        if not force:
            issues.append("source_multibar_force_screen_not_met")
        # Read the actual earlier outer envelope, not just a convenient nearby fractal.
        refs = {}
        for leg in legs:
            for point in (leg["origin"],leg["terminal"]):
                if (point["kind"] == b["kind"] and _time(point["pivot_timestamp_utc"]) < _time(a["pivot_timestamp_utc"])
                        and _time(point["confirmed_at_utc"]) <= known):
                    stamp=_time(point["pivot_timestamp_utc"])
                    bar=before.get(stamp)
                    key="high" if b["kind"]=="confirmed_swing_high_candidate" else "low"
                    if bar is None:
                        continue  # Reference outside the loaded scope remains unknown.
                    if (not _number(point.get("price")) or bar.get(key)!=point["price"]
                            or stamp+duration>_time(point["confirmed_at_utc"])):
                        raise ValueError("prior reference is not native")
                    old=refs.get(point["pivot_timestamp_utc"])
                    if old is not None and not _same(old,point):
                        raise ValueError("conflicting prior reference")
                    refs[point["pivot_timestamp_utc"]] = point
        upward = source["direction_observation"] == "up"
        reference = (max if upward else min)(refs.values(),key=lambda p:p["price"]) if refs else None
        result["outer_structure_evidence"] = {
            **_close_delivery(path,reference,upward),
            "scope":"loaded_prior_native_outer_envelope_not_author_named_control_node",
            "reference_count":len(refs),"named_trend_node_adjudicated":False}
        context = record.get("background_direction_review")
        generated_context = isinstance(context,dict) and context.get('producer_method') == 'automatic_native_parent_source_background_v1'
        if generated_context:
            # Re-evaluate our generated interpretation from native evidence on
            # every replay; it is not an independently supplied manual contract.
            context = None
        node = _named_node(context,refs,timeframe,snapshot)
        result["source_node_scope"] = _source_node_scope(path,refs,upward,timeframe,node,reference)
        result["named_structure_evidence"] = {
            **_close_delivery(path,node,upward),
            "node_id":context.get("named_structure_node_id") if isinstance(context,dict) else None,
            "status":"independent_node_native_delivery" if node else "independent_node_not_native_bound",
            "semantic_role_independently_supplied":True if node else False}
        result['first_force_retracement_review'] = _first_force_retracement_review(
            result['relative_effort'],result['source_node_scope'],result['named_structure_evidence'],force)
        # The loaded outer envelope is diagnostic only. A legitimate local
        # source may change its OWN control node without breaking every older
        # high/low on screen. Conversely an outer break cannot name that node.
        local_delivery = (result["named_structure_evidence"]["sustained_source_close"] if node else
                          bool(result["source_node_scope"]["handled_node_ids"]))
        if not local_delivery:
            issues.append("source_node_cross_and_follow_not_observed")
        local_issues = list(issues)
        result["source_delivery_evidence_ready"] = not local_issues
        witnesses = {row["timestamp_utc"]:row for row in path["bars"]}
        if path.get("preceding_bar"):
            preceding=path["preceding_bar"]
            witnesses[preceding["timestamp_utc"]]=preceding
        if comparison:
            witnesses.update({row["timestamp_utc"]:row for row in comparison["bars"]})
        result["market_evidence"] = [dict(evidence_id=f"{timeframe}:source:{utc}",timeframe=timeframe,
            bar_open_utc=utc,close=row["close"]) for utc,row in sorted(witnesses.items())]
        result["source_refs"] = [row["evidence_id"] for row in result["market_evidence"]]
        if not local_issues:
            # Supply actual top-down node paths at B to the still-incomplete
            # independent background decision; never substitute today's paths.
            try:
                from .live_native_structure_sequence import source_time_background
            except ImportError:
                from live_native_structure_sequence import source_time_background
            result["native_background_at_source"] = (_background_reader(timeframe,_iso(known))
                if _background_reader is not None else source_time_background(snapshot,timeframe,_iso(known)))
        automatic = None
        if not context and not local_issues:
            try:
                from .live_automatic_background import build_automatic_background
            except ImportError:
                from live_automatic_background import build_automatic_background
            automatic=build_automatic_background(snapshot,timeframe,record,result)
            result['automatic_background_review']=automatic
            context=automatic.get('context')
            if context:
                node=_named_node(context,refs,timeframe,snapshot)
                result['background_direction_review']=context
                result['named_structure_evidence']={**_close_delivery(path,node,upward),
                    'node_id':context['named_structure_node_id'],'status':'automatic_node_native_delivery',
                    'semantic_role_independently_supplied':False}
        # Parent objective is checked at the SOURCE confirmation, not today/C.
        projection = snapshot.get("live_structure_projection") or {}
        parent = parent_task if parent_task is not None else projection.get("parent_task")
        graph = target_graph if target_graph is not None else projection.get("target_graph")
        if automatic and automatic.get('context'):
            parent,graph=automatic['parent_task'],automatic['target_graph']
        objective_state = state
        if components:
            # The verified composite is an analysis-only source identity.  It
            # must be visible to the parent-objective join without rewriting
            # the frozen native ledger or pretending it was an adjacent leg.
            native_wave = state.get('candidate_wave_ledger') or {}
            objective_state = {**state,'candidate_wave_ledger':{
                **native_wave,'legs':[*legs,source]}}
        objective = build_parent_objective_review(parent,graph,objective_state,timeframe=timeframe,
            as_of_utc=_iso(known),chart_history=snapshot.get("chart_history"),
            provider=snapshot.get("provider"),instrument=snapshot.get("instrument"))
        result["parent_objective_at_source"] = objective
        owned = (objective["status"] == "validated_parent_objective_context"
                 and source["leg_id"] in objective["supports_source_leg_ids"]
                 and any(target.get('supports_source_direction',objective['parent_direction']) == source['direction_observation']
                         and target['supports_source_leg_id'] == source['leg_id'] for target in objective['targets']))
        if not owned:
            issues.append("source_parent_direction_target_not_bound_at_confirmation")
        current_objective = build_parent_objective_review(parent,graph,objective_state,timeframe=timeframe,
            as_of_utc=snapshot["as_of_utc"],chart_history=snapshot.get("chart_history"),
            provider=snapshot.get("provider"),instrument=snapshot.get("instrument"))
        result["parent_objective_now"] = current_objective
        if owned and current_objective["status"] != "validated_parent_objective_context":
            issues.append("parent_target_current_lifecycle_requires_review")
        # A declared independent decision must survive the existing separate admission
        # gate. It cannot be manufactured from the local envelope or speed thresholds.
        if not isinstance(context,dict) or not context:
            issues.append("independent_named_background_and_trend_decision_missing")
        else:
            if not node or not result["named_structure_evidence"]["sustained_source_close"]:
                issues.append("independent_control_node_native_delivery_not_bound")
            # Check the independent contract without feeding our not-yet-built
            # selection result back into itself as evidence.
            independent={key:value for key,value in record.items()
                         if key not in {"source_selection_review","projection_anchor","projected_level",
                                        "continuation_requires_review","anchor_review"}}
            independent['background_direction_review']=context
            background_gate=build_one_to_one_admission(independent,snapshot)
            result["independent_background_validation"] = background_gate
            if not background_gate["eligible_for_projection"]:
                issues.append("independent_background_evidence_failed_admission")
        result['source_background_ready_at_confirmation']=bool(not local_issues and owned and node
            and result.get('independent_background_validation',{}).get('eligible_for_projection'))
        if context:
            result['background_direction_review']=context
        result["eligible_source_for_owned_task"] = not issues
        result["status"] = ("source_task_join_ready_for_independent_admission" if not issues else
            "source_delivery_ready_background_unresolved" if not local_issues else "source_delivery_rejected")
    except (KeyError,TypeError,ValueError,AttributeError,ZeroDivisionError,OverflowError):
        issues.append("source_native_evidence_invalid")
    result["blockers"] = list(dict.fromkeys(issues))
    return result


def _snapshot_native_reader(snapshot):
    """Reuse native validation only inside one synchronous, immutable review.

    No cross-snapshot cache and no source-time decisions are cached: every
    source still filters its own B-confirmation prefix and runs all gates.
    Compact snapshots normalized into a different mapping use the independent
    validator rather than borrow the original mapping's native objects.
    """
    cache = {}

    def read(candidate, timeframe, cutoff):
        if candidate is not snapshot:
            return _native(candidate, timeframe, cutoff)
        key = (timeframe, cutoff)
        if key not in cache:
            cache[key] = _native(candidate, timeframe, cutoff)
        return cache[key]

    return read


def attach_source_selection_reviews(review,snapshot,*,parent_task=None,target_graph=None):
    """Recompute each source once, then bind its decision to its own C ruler."""
    ledger = review.get("measurement_lifecycle_ledger") or {}
    records = ledger.get("records") or []
    source_only = [*_confirmed_unpaired_sources(snapshot, ledger),
                   *_confirmed_composite_sources(snapshot, ledger)]
    ledger['source_only_records'] = source_only
    cache = {}
    try:
        from .live_native_structure_sequence import source_time_background_reader
    except ImportError:
        from live_native_structure_sequence import source_time_background_reader
    background_reader = source_time_background_reader(snapshot)
    native_reader = _snapshot_native_reader(snapshot)
    scope_indexes = {}
    forming = review.get("forming_pullback_one_to_one")
    for record in [review,*records,*source_only,*([forming] if isinstance(forming,dict) else [])]:
        if not record.get("source_leg_id") or not record.get("source_origin") or not record.get("source_terminal"):
            continue
        # Separate independent contexts/measurement identities are never borrowed.
        # Old ledger records inherit scope from their ledger, not from arbitrary
        # foreign record fields. This is an in-memory recalculation only.
        if (ledger.get("snapshot_id") == snapshot.get("snapshot_id")
                and ledger.get("as_of_utc") == snapshot.get("as_of_utc")
                and ledger.get("timeframe") == record.get("timeframe")):
            record.setdefault("snapshot_id",ledger["snapshot_id"])
            record.setdefault("as_of_utc",ledger["as_of_utc"])
        key=(record["source_leg_id"],repr(record.get("source_origin")),repr(record.get("source_terminal")),
             record.get("snapshot_id"),record.get("as_of_utc"),repr(record.get("background_direction_review")))
        if key not in cache:
            cache[key] = build_source_selection_review(snapshot,record["timeframe"],record,
                parent_task=parent_task,target_graph=target_graph,_background_reader=background_reader,
                _native_reader=native_reader,_scope_indexes=scope_indexes)
        record["source_selection_review"] = {**cache[key],"measurement_id":record.get("measurement_id")}
        generated=record['source_selection_review'].get('background_direction_review')
        existing=record.get('background_direction_review') or {}
        if generated and (not existing or existing.get('producer_method')=='automatic_native_parent_source_background_v1'):
            record['background_direction_review']={**generated,'measurement_id':record.get('measurement_id')}
        elif existing.get('producer_method')=='automatic_native_parent_source_background_v1':
            record.pop('background_direction_review',None)
    ledger["source_selection_method"] = METHOD
    ledger["source_delivery_ready_count"] = sum(bool(r.get("source_selection_review",{}).get("source_delivery_evidence_ready")) for r in records)
    ledger["source_task_join_ready_count"] = sum(bool(r.get("source_selection_review",{}).get("eligible_source_for_owned_task")) for r in records)
    ledger['source_only_ready_count'] = sum(bool(r.get('source_selection_review',{}).get('source_background_ready_at_confirmation')) for r in source_only)
    return review
