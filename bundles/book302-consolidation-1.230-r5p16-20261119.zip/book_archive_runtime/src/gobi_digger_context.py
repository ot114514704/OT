"""Source-bound closed-native-bar observations, consumed by the scene reducer.

Source definitions are GE-001/002/021 (ghbdr early 5,3,3 vs 14,3,3 and
closed V bars) and Digger's named period opens and time-ordered interactions.
Numerical differences are facts, not thresholds for expanding/recovering.
Bar close is a replay availability model, never a live observation witness.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import json
import math
import re

from .build_elasticity_observation_dataset import stochastic_series
from .integrated_reasoning_engine import _gobi_digger_adjudication
from .gobi_digger_indicators import build_indicators, verify_indicators

VERSION = 'gobi_digger_native_context_v4'
SEQUENCE_VERSION = 'gobi_digger_native_context_v3'
WITNESS_VERSION = 'gobi_digger_native_context_v2'
LEGACY_VERSION = 'gobi_digger_native_context_v1'
MINUTES = dict(M1=1, M5=5, M15=15, M30=30, H1=60, H4=240, D1=1440, W1=10080)
GOBI_CLAIMS = ['GE-001', 'GE-002', 'GE-021']
DIGGER_CLAIMS = ['DG-A03', 'digger_period_opens_p454', 'digger_close_not_hold_p980']
SOURCES = {
    'GE-001': 'https://www.forexfactory.com/thread/973872-d1-elasticity-pullback-trading',
    'GE-002': 'https://www.forexfactory.com/thread/973872-d1-elasticity-pullback-trading (page 1, posts 17 and 20)',
    'GE-021': 'https://www.forexfactory.com/thread/973872-d1-elasticity-pullback-trading?page=3',
    'DG-A03': '03_work_queue/local_agent/evidence/digger_primary_observation_audit_v1.jsonl:DG-A03',
    'digger_period_opens_p454': 'https://www.metalsmine.com/thread/930946-aussi-my-thread-and-anything-i-want-to?page=454',
    'digger_close_not_hold_p980': 'https://www.metalsmine.com/thread/930946-aussi-my-thread-and-anything-i-want-to?page=980',
}


def stamp(value):
    try:
        result = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return result.astimezone(timezone.utc) if result.tzinfo is not None else None
    except (ValueError, TypeError):
        return None


def iso(value):
    return value.isoformat().replace('+00:00', 'Z')


def digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def native_prefix(rows, tf, cutoff, provider, instrument):
    """Reject visible identity/price conflicts; ignore future bars before reading OHLC."""
    result, previous = [], None
    for raw in rows:
        start = stamp(raw.get('timestamp_utc'))
        if start is None:
            raise ValueError('native_bar_timestamp_missing_or_naive')
        end = start + timedelta(minutes=MINUTES[tf])
        if end > cutoff:
            continue
        available = stamp(raw.get('known_at_utc')) if 'known_at_utc' in raw else end
        if available is None or available < end:
            raise ValueError('native_bar_availability_invalid')
        if available > cutoff:
            continue
        if raw.get('provider') != provider or raw.get('symbol', instrument) != instrument:
            raise ValueError('native_bar_market_mismatch')
        if raw.get('timeframe', tf) != tf:
            raise ValueError('native_bar_timeframe_mismatch')
        if previous is not None and start <= previous:
            raise ValueError('native_bar_duplicate_or_unordered')
        prices = {k: float(raw[k]) for k in ('open', 'high', 'low', 'close')}
        if not all(math.isfinite(v) for v in prices.values()) or not (
            prices['low'] <= min(prices['open'], prices['close']) <= max(prices['open'], prices['close']) <= prices['high']
        ):
            raise ValueError('native_bar_invalid_ohlc')
        normalized = dict(timestamp_utc=iso(start), closed_at_utc=iso(end),
                          known_at_utc=iso(available), **prices)
        if 'native_epoch' in raw:
            normalized['native_epoch'] = raw['native_epoch']
        result.append(normalized)
        previous = start
    return result


def v_pattern(rows):
    """Report the source's closed shape and inside-bar wait; no trigger/stop inference."""
    if len(rows) < 3:
        return dict(state='unknown', reason='three_closed_bars_required', bar_refs=[])
    a, b, c = rows[-3:]
    bull = a['low'] > b['low'] < c['low']
    bear = a['high'] < b['high'] > c['high']
    inside = c['high'] <= b['high'] and c['low'] >= b['low']
    shapes = []
    if bull:
        shapes.append('bullish_closed_shape' if c['close'] > c['open'] else
                      'bullish_inside_wait_fourth' if inside and c['close'] < c['open'] else 'bullish_shape_wrong_close')
    if bear:
        shapes.append('bearish_closed_shape' if c['close'] < c['open'] else
                      'bearish_inside_wait_fourth' if inside and c['close'] > c['open'] else 'bearish_shape_wrong_close')
    fourth = None
    if len(rows) >= 4:
        p, q, r, s = rows[-4:]
        if r['high'] <= q['high'] and r['low'] >= q['low']:
            if p['low'] > q['low'] < r['low'] and r['close'] < r['open']:
                fourth = dict(shape='bullish_inside_exception', directional_fourth_close=s['close'] > s['open'],
                              bar_refs=[x['timestamp_utc'] for x in (p, q, r, s)])
            elif p['high'] < q['high'] > r['high'] and r['close'] > r['open']:
                fourth = dict(shape='bearish_inside_exception', directional_fourth_close=s['close'] < s['open'],
                              bar_refs=[x['timestamp_utc'] for x in (p, q, r, s)])
    return dict(state='observed' if shapes or fourth else 'none', shapes=shapes, inside_fourth_observation=fourth,
                bar_refs=[r['timestamp_utc'] for r in (a, b, c)],
                known_at_utc=max(r['known_at_utc'] for r in (rows[-4:] if fourth else rows[-3:])),
                trigger_state='not_evaluated', parent_acceptance='unknown')


def _interaction(level, rows):
    # The line must already be known before the interaction bar opens.
    eligible = [r for r in rows if stamp(r['timestamp_utc']) >= stamp(level['known_at_utc'])]
    events, touched = [], False
    prior_side = None
    dependency_known = level['known_at_utc']
    for row in eligible:
        dependency_known = max((dependency_known, row['known_at_utc']), key=stamp)
        price = level['price']
        side = 1 if row['close'] > price else -1 if row['close'] < price else 0
        touch = row['low'] <= price <= row['high']
        crossed = prior_side not in (None, 0) and side not in (0, prior_side)
        if touch or crossed:
            events.append(dict(bar_open_utc=row['timestamp_utc'], closed_at_utc=row['closed_at_utc'],
                known_at_utc=dependency_known, touches=touch, close_side=side,
                previous_close_side=prior_side, crosses_on_close=crossed,
                interaction='retest' if touched and touch else 'touch' if touch else 'close_cross'))
            touched = touched or touch
        prior_side = side
    return dict(events=events, interaction_state=events[-1]['interaction'] if events else 'unknown',
                hold_state='unknown', hold_reason='closed_interactions_do_not_define_author_hold_or_parent_acceptance',
                observation_window_start=eligible[0]['timestamp_utc'] if eligible else None)


def _gobi_observation(bars, tf, source_id):
    """Deterministic legacy measurement; source/shape fields are verified too."""
    window = bars[-19:]
    fast = stochastic_series(window, 5, 3, 3)
    slow = stochastic_series(window, 14, 3, 3)
    gap = None if fast[-1]['k'] is None or slow[-1]['k'] is None else fast[-1]['k'] - slow[-1]['k']
    return dict(native_timeframe=tf, source_id=source_id, source_claim_ids=GOBI_CLAIMS,
        input_window_sha256=digest(window), input_bars=window,
        latest_closed_bar_utc=bars[-1]['closed_at_utc'],
        known_at_utc=max((b['known_at_utc'] for b in window), key=stamp),
        values=dict(fast_5_3_3=fast[-1], slow_14_3_3=slow[-1]),
        fast_minus_slow_k=gap, v_pattern=v_pattern(bars),
        parameter_version='ghbdr_early_dual_stoch_5_3_3_vs_14_3_3',
        source_scope_status=('early_D1_source_scope' if tf=='D1' else 'H4_supporting_observation' if tf=='H4'
                             else 'project_native_period_diagnostic_not_author_trading_rule'),
        calculation_spec='rolling_high_low_percent_K_then_SMA_slowing_then_SMA_D',
        zero_range_policy='legacy_extractor_50_convention_not_author_claim',
        admission='numeric_observation_only' if gap is not None else 'insufficient_history',
        elasticity_state='unknown', state_reason='author_elasticity_sufficiency_has_no_verified_numeric_threshold',
        fractal_state='unknown_source_indicator_confirmation_not_reconstructed')


def _elasticity_transition(frames):
    return dict(source_version='ghbdr_early_d1', source_claim_ids=GOBI_CLAIMS,
        observed_on_closed_bar='yes' if frames else 'unknown', parent_timeframe='D1', child_timeframes=['H4'],
        parent_elasticity_state='unknown', child_elasticity_state='unknown', parent_child_relation='unknown',
        parent_structure_state='unknown', price_action_state='unknown', named_location_context=[],
        permission_effect='requires_wait', source_message_or_post_ids=GOBI_CLAIMS,
        status='context_incomplete', unknown_fields=['parent_elasticity_state', 'child_elasticity_state', 'parent_structure_state'])


def produce_context(periods, *, provider, instrument, cutoff_utc, chart_timeframe,
                    source_id, calendar):
    cutoff = stamp(cutoff_utc)
    if cutoff is None or chart_timeframe not in MINUTES:
        raise ValueError('scene_clock_or_timeframe_invalid')
    if not provider or not instrument or not source_id:
        raise ValueError('explicit_source_market_required')
    packet = dict(schema=VERSION, rule_version=VERSION, producer='src.gobi_digger_context.produce_context',
        provider=provider, instrument=instrument, as_of_utc=iso(cutoff),
        chart_timeframe=chart_timeframe, source_id=source_id, calendar=deepcopy(calendar),
        availability_model='closed_bar_replay_not_live_arrival_witness',
        observed_at_utc=None, read_only=True, automatic_trade_permission=False, future_bars_used=False,
        source_claims=deepcopy(SOURCES), owner_id=None, structure_task_ids=[],
        owner_binding='unbound_indicator_window_not_a_native_structure_leg')
    frames, rejected, clean = {}, {}, {}
    for tf, rows in periods.items():
        if tf not in MINUTES:
            continue
        try:
            clean[tf] = native_prefix(rows, tf, cutoff, provider, instrument)
        except (ValueError, KeyError, TypeError) as error:
            rejected[tf] = str(error)
            continue
        bars = clean[tf]
        if not bars:
            continue
        # K(14,3) and D(3) require 18 bars. Retain 19 to report prior K too.
        frames[tf] = _gobi_observation(bars, tf, source_id)
    packet['rejected_periods'] = rejected
    packet['gobi_observations'] = frames
    transition = _elasticity_transition(frames)
    levels = []
    for tf in ('D1', 'W1'):
        for row in clean.get(tf, [])[-3:]:
            oid = f'{provider}:{instrument}:{tf}:period_open:{row["timestamp_utc"]}'
            levels.append(dict(object_id=oid, semantic_class='period_open', native_timeframe=tf,
                period_start_utc=row['timestamp_utc'], known_at_utc=row['known_at_utc'], price=row['open'],
                source_bar=deepcopy(row), period_role='historical_closed_period_open',
                source_id=source_id, source_claim_ids=DIGGER_CLAIMS, mapping_status='exact_native_period_open',
                same_feed_and_timezone='yes', primary_structure_equivalence='not_claimed'))
    # A current daily open is knowable after the exact boundary M1 closes.
    # A missing midnight bar is unknown; never substitute the first loaded row.
    if calendar.get('day_boundary') == '00:00' and calendar.get('timezone') == 'UTC':
        midnight = cutoff.replace(hour=0, minute=0, second=0, microsecond=0)
        opening = next((r for r in clean.get('M1', []) if stamp(r['timestamp_utc']) == midnight), None)
        if opening:
            oid = f'{provider}:{instrument}:D1:period_open:{iso(midnight)}'
            levels.append(dict(object_id=oid, semantic_class='period_open', native_timeframe='D1',
                period_start_utc=iso(midnight), known_at_utc=opening['known_at_utc'], price=opening['open'],
                source_bar=deepcopy(opening), source_bar_timeframe='M1', period_role='current_day_open',
                source_id=source_id, source_claim_ids=DIGGER_CLAIMS, mapping_status='exact_native_period_open',
                same_feed_and_timezone='yes', primary_structure_equivalence='not_claimed'))
    chart_bars = clean.get(chart_timeframe, [])
    for level in levels:
        level['interaction'] = _interaction(level, chart_bars)
        level['interaction_timeframe'] = chart_timeframe
    packet['elasticity_transition'] = transition
    packet['digger_context'] = dict(source_claim_ids=DIGGER_CLAIMS, mapped_objects=levels,
        interaction_input_bars=deepcopy(chart_bars),
        native_timeframes=sorted({l['native_timeframe'] for l in levels}),
        interaction_timeframe=chart_timeframe, interaction_state='unknown',
        integration_status='observation_only' if levels else 'not_observed', permission_effect='none',
        parent_track_relation='unknown', named_time_window=[], next_in_line_object_id=None,
        autonomous_direction_forbidden=True, chart_identity_verified='yes',
        unresolved_labels=['QH3_formula', 'pivot_formula', 'session_window_definition', 'author_hold_fold_criterion'])
    from .digger_position_sequence import build as build_position_sequence
    packet['digger_sequence_observations']=build_position_sequence(levels,chart_bars,chart_timeframe,MINUTES[chart_timeframe])
    from .digger_inventory_context import build as build_inventory
    packet['digger_event_time_inventory']=build_inventory(clean,provider=provider,instrument=instrument,
        calendar=calendar,cutoff_utc=iso(cutoff),chart_timeframe=chart_timeframe,minutes=MINUTES)
    known = ([r['known_at_utc'] for r in frames.values()] + [l['known_at_utc'] for l in levels]
             + [r['known_at_utc'] for r in chart_bars])
    packet['known_at_utc'] = max(known) if known else None
    packet['process_indicators'] = build_indicators(clean, levels, chart_timeframe, MINUTES)
    process_known = [r['known_at_utc'] for f in packet['process_indicators']['gobi'].values() for r in f['input_bars']]
    process_known.extend(r['known_at_utc'] for r in (packet['process_indicators'].get('task_frame') or {}).get('input_bars',[]))
    if process_known:
        packet['known_at_utc'] = max(known + process_known)
    from .pivotgauge_context import build as build_pivot_map
    packet['pivotgauge_context'] = build_pivot_map(clean, provider=provider, instrument=instrument,
        source_id=source_id, cutoff_utc=iso(cutoff), chart_timeframe=chart_timeframe, calendar=calendar)
    if packet['pivotgauge_context']['known_at_utc']:
        packet['known_at_utc'] = max(filter(None, [packet['known_at_utc'], packet['pivotgauge_context']['known_at_utc']]),key=stamp)
    if packet['digger_event_time_inventory']['known_at_utc']:
        packet['known_at_utc']=max(filter(None,[packet['known_at_utc'],packet['digger_event_time_inventory']['known_at_utc']]),key=stamp)
    packet['input_prefix_sha256'] = digest(clean)
    packet['receipt_id'] = digest(packet)
    return packet


def attach_context(scene, periods, *, source_id, calendar):
    scene['gobi_digger_producer'] = produce_context(periods, provider=scene['provider'],
        instrument=scene['instrument'], cutoff_utc=scene['cutoff_utc'], chart_timeframe=scene['timeframe'],
        source_id=source_id, calendar=calendar)
    return scene


def _consume_context(scene):
    """Validate transport identity and clocks before exposing producer facts to main logic."""
    raw = scene.get('gobi_digger_producer')
    base = dict(schema='gobi_digger_consumer_v1', as_of_utc=scene.get('cutoff_utc'),
        status='not_produced', adjudication='context_incomplete', read_only=True,
        automatic_trade_permission=False, future_bars_used=False, score_effect='none',
        parent_direction_effect='none', entry_permission=False, blockers=[])
    if not isinstance(raw, dict):
        base['blockers'] = ['producer_missing']
        return base
    errors = []
    cutoff = stamp(scene.get('cutoff_utc'))
    if raw.get('schema') not in {VERSION, SEQUENCE_VERSION, WITNESS_VERSION, LEGACY_VERSION}:
        errors.append('producer_version_unknown')
    if raw.get('provider') != scene.get('provider') or raw.get('instrument') != scene.get('instrument'):
        errors.append('producer_market_mismatch')
    if stamp(raw.get('as_of_utc')) != cutoff or cutoff is None:
        errors.append('producer_asof_mismatch')
    if raw.get('chart_timeframe') != scene.get('timeframe'):
        errors.append('producer_chart_timeframe_mismatch')
    if raw.get('read_only') is not True or raw.get('automatic_trade_permission') is not False or raw.get('future_bars_used') is not False:
        errors.append('producer_permission_violation')
    # Hashing only reads nested values; removing the top-level receipt from
    # a private shallow mapping avoids copying every historical witness.
    expected = dict(raw); expected.pop('receipt_id', None)
    if raw.get('receipt_id') != digest(expected):
        errors.append('producer_receipt_hash_mismatch')
    known = stamp(raw.get('known_at_utc'))
    if known is None or cutoff is None or known > cutoff:
        errors.append('producer_known_at_missing_or_future')
    for tf, obs in raw.get('gobi_observations', {}).items():
        if tf not in MINUTES or obs.get('native_timeframe') != tf:
            errors.append('gobi_native_timeframe_mismatch')
        for bar in obs.get('input_bars', []):
            close, available = stamp(bar.get('closed_at_utc')), stamp(bar.get('known_at_utc'))
            if close is None or available is None or cutoff is None or not close <= available <= cutoff:
                errors.append('gobi_bar_clock_invalid')
            start = stamp(bar.get('timestamp_utc'))
            if tf in MINUTES and (start is None or close != start + timedelta(minutes=MINUTES[tf])):
                errors.append('gobi_native_bar_duration_invalid')
        if obs.get('source_claim_ids') != GOBI_CLAIMS:
            errors.append('gobi_source_claim_missing')
        if obs.get('input_window_sha256') != digest(obs.get('input_bars', [])):
            errors.append('gobi_input_hash_mismatch')
        observed_known = stamp(obs.get('known_at_utc'))
        if observed_known is None or cutoff is None or observed_known > cutoff:
            errors.append('gobi_observation_clock_invalid')
    digger = raw.get('digger_context') or {}
    if digger.get('source_claim_ids') != DIGGER_CLAIMS or digger.get('autonomous_direction_forbidden') is not True:
        errors.append('digger_source_or_permission_invalid')
    if digger.get('integration_status') not in {'observation_only', 'not_observed'} or digger.get('permission_effect') != 'none':
        errors.append('digger_unverified_semantic_upgrade')
    for level in digger.get('mapped_objects', []):
        level_known = stamp(level.get('known_at_utc'))
        source = level.get('source_bar') or {}
        if level.get('native_timeframe') not in {'D1', 'W1'} or level.get('source_id') != raw.get('source_id'):
            errors.append('digger_level_source_invalid')
        if level_known is None or cutoff is None or level_known > cutoff or level['price'] != source.get('open'):
            errors.append('digger_level_price_or_clock_invalid')
        for event in (level.get('interaction') or {}).get('events', []):
            opened, closed, available = (stamp(event.get(k)) for k in ('bar_open_utc', 'closed_at_utc', 'known_at_utc'))
            if any(t is None for t in (opened, closed, available, level_known, cutoff)) or not level_known <= opened < closed <= available <= cutoff:
                errors.append('digger_interaction_clock_invalid')
    transition = raw.get('elasticity_transition') or {}
    if any(transition.get(k) != 'unknown' for k in ('parent_elasticity_state', 'child_elasticity_state', 'parent_structure_state')):
        errors.append('gobi_unverified_semantic_upgrade')
    errors.extend(verify_indicators(raw, MINUTES))
    from .pivotgauge_context import verify as verify_pivot_map
    errors.extend(verify_pivot_map(raw, MINUTES))
    errors.extend(_verify_observation_contract(raw, cutoff))
    if errors:
        base.update(status='rejected', blockers=sorted(set(errors)))
        return base
    base.update(status='consumed_native_observations', producer_receipt_id=raw['receipt_id'],
        producer_input_sha256=raw['input_prefix_sha256'], source_id=raw['source_id'], known_at_utc=raw['known_at_utc'],
        calendar=deepcopy(raw['calendar']), source_claims=deepcopy(raw['source_claims']),
        gobi_observations=deepcopy(raw['gobi_observations']),
        elasticity_transition=deepcopy(raw['elasticity_transition']), digger_context=deepcopy(raw['digger_context']),
        owner_id=raw['owner_id'], owner_binding=raw['owner_binding'],
        rejected_periods=deepcopy(raw['rejected_periods']))
    base['process_indicators'] = deepcopy(raw.get('process_indicators'))
    base['pivotgauge_context'] = deepcopy(raw.get('pivotgauge_context'))
    if 'digger_sequence_observations' in raw:
        base['digger_sequence_observations']=deepcopy(raw['digger_sequence_observations'])
    if 'digger_event_time_inventory' in raw:
        base['digger_event_time_inventory']=deepcopy(raw['digger_event_time_inventory'])
    base['adjudication'] = _gobi_digger_adjudication(base['elasticity_transition'], base['digger_context'])
    # Every native task receives a context pointer at its own scene clock.
    # This relation is scope/context only and never a claim of shared ownership.
    refs = []
    for task in (scene.get('structure_logic') or {}).get('tasks', []):
        if task.get('timeframe') not in raw['gobi_observations']:
            continue
        task_known, task_asof = stamp(task.get('known_at_utc')), stamp(task.get('as_of_utc'))
        if task_known is None or task_known > cutoff or task_asof != cutoff:
            continue
        refs.append(dict(task_id=task.get('task_id'), native_timeframe=task['timeframe'],
            task_owner_id=task.get('owner_id'), producer_receipt_id=raw['receipt_id'],
            relation='same_native_period_context_only', as_of_utc=scene['cutoff_utc'],
            known_at_utc=raw['known_at_utc'], owner_equivalence=False))
    base['native_task_context_refs'] = refs
    return base


def _validate_rows(rows, tf, cutoff, calendar):
    if not isinstance(rows, list) or tf not in MINUTES:
        raise ValueError('rows_or_timeframe')
    previous = None
    for row in rows:
        start, closed, known = (stamp(row.get(k)) for k in ('timestamp_utc', 'closed_at_utc', 'known_at_utc'))
        if None in (start, closed, known, cutoff) or not start < closed <= known <= cutoff:
            raise ValueError('source_clock')
        if closed != start + timedelta(minutes=MINUTES[tf]) or (previous is not None and start <= previous):
            raise ValueError('source_duration_or_order')
        values = [row[k] for k in ('low', 'open', 'close', 'high')]
        if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in values):
            raise ValueError('nonfinite_source')
        if not values[0] <= min(values[1:3]) <= max(values[1:3]) <= values[3]:
            raise ValueError('source_ohlc')
        if 'native_epoch' in row:
            offset = calendar.get('server_offset_seconds', 0)
            if (isinstance(offset, bool) or not isinstance(offset, int) or abs(offset)>14*3600 or offset%60
                    or isinstance(row['native_epoch'], bool) or not isinstance(row['native_epoch'], int)
                    or row['native_epoch'] != int(start.timestamp())+offset):
                raise ValueError('source_native_clock')
        previous = start


def _verify_observation_contract(raw, cutoff):
    """Validate retained witnesses, not the authenticity of an external feed.

    v1 has no complete chart interaction witness. It can prove its numeric
    window and event clocks, but cannot independently prove older interactions.
    v2 retains that witness and requires exact event recomputation.
    """
    errors=[]
    if (raw.get('rule_version') != raw.get('schema') or raw.get('source_claims') != SOURCES
            or not isinstance(raw.get('source_id'), str) or not raw['source_id']
            or raw.get('producer') != 'src.gobi_digger_context.produce_context'
            or raw.get('availability_model') != 'closed_bar_replay_not_live_arrival_witness'
            or raw.get('observed_at_utc') is not None):
        errors.append('producer_source_identity_invalid')
    if (raw.get('owner_id') is not None or raw.get('structure_task_ids') != []
            or raw.get('owner_binding') != 'unbound_indicator_window_not_a_native_structure_leg'):
        errors.append('producer_owner_upgrade_forbidden')
    if not re.fullmatch('[0-9a-f]{64}',str(raw.get('input_prefix_sha256', ''))):
        errors.append('producer_prefix_identity_invalid')
    if raw.get('elasticity_transition') != _elasticity_transition(raw.get('gobi_observations')):
        errors.append('gobi_unverified_semantic_upgrade')
    dependencies=[]
    for tf, obs in raw['gobi_observations'].items():
        try:
            rows=obs['input_bars']
            if not 0<len(rows)<=19:raise ValueError('window')
            _validate_rows(rows,tf,cutoff,raw['calendar'])
            if obs != _gobi_observation(rows,tf,raw['source_id']):raise ValueError('recomputation')
            dependencies.extend(b['known_at_utc'] for b in rows)
        except (ValueError,TypeError,KeyError,AttributeError,IndexError,OverflowError):
            errors.append('gobi_observation_source_or_recomputation_invalid')
    try:
        digger=raw['digger_context']; levels=digger['mapped_objects']; seen=set()
        top=dict(source_claim_ids=DIGGER_CLAIMS,mapped_objects=levels,
            native_timeframes=sorted({l['native_timeframe'] for l in levels}),
            interaction_timeframe=raw['chart_timeframe'],interaction_state='unknown',
            integration_status='observation_only' if levels else 'not_observed',permission_effect='none',
            parent_track_relation='unknown',named_time_window=[],next_in_line_object_id=None,
            autonomous_direction_forbidden=True,chart_identity_verified='yes',
            unresolved_labels=['QH3_formula','pivot_formula','session_window_definition','author_hold_fold_criterion'])
        chart=digger.get('interaction_input_bars')
        if raw.get('schema') in (VERSION,SEQUENCE_VERSION,WITNESS_VERSION) and chart is None:raise ValueError('interaction_witness_missing')
        if chart is not None:top['interaction_input_bars']=chart
        if digger!=top:raise ValueError('digger_semantic_upgrade')
        if chart is not None:
            _validate_rows(chart,raw['chart_timeframe'],cutoff,raw['calendar'])
            tail=(raw.get('process_indicators') or {}).get('gobi',{}).get(raw['chart_timeframe'])
            if tail and chart[-96:] != tail['input_bars']:raise ValueError('chart_witness_tail')
            chart_obs=raw['gobi_observations'].get(raw['chart_timeframe'])
            if chart_obs and chart[-19:]!=chart_obs['input_bars']:raise ValueError('observation_tail')
            dependencies.extend(b['known_at_utc'] for b in chart)
        for level in levels:
            tf=level['native_timeframe']; source=level['source_bar']
            source_tf=level.get('source_bar_timeframe',tf)
            fields={'object_id','semantic_class','native_timeframe','period_start_utc','known_at_utc',
                'price','source_bar','period_role','source_id','source_claim_ids','mapping_status',
                'same_feed_and_timezone','primary_structure_equivalence','interaction','interaction_timeframe'}
            if level.get('period_role')=='current_day_open':fields.add('source_bar_timeframe')
            if set(level)!=fields or isinstance(level['price'],bool):raise ValueError('level_fields')
            _validate_rows([source],source_tf,cutoff,raw['calendar'])
            identity=f'{raw["provider"]}:{raw["instrument"]}:{tf}:period_open:{source["timestamp_utc"]}'
            if (level['object_id']!=identity or identity in seen or level['period_start_utc']!=source['timestamp_utc']
                    or level['known_at_utc']!=source['known_at_utc'] or level['price']!=source['open']
                    or level['source_claim_ids']!=DIGGER_CLAIMS or level['semantic_class']!='period_open'
                    or level['mapping_status']!='exact_native_period_open' or level['same_feed_and_timezone']!='yes'
                    or level['primary_structure_equivalence']!='not_claimed'
                    or level['interaction_timeframe']!=raw['chart_timeframe']):raise ValueError('level_identity')
            seen.add(identity);dependencies.append(source['known_at_utc'])
            if level['period_role']=='historical_closed_period_open':
                witness=(raw['gobi_observations'].get(tf) or {}).get('input_bars',[])
                if source_tf!=tf or source not in witness[-3:]:raise ValueError('native_period_source')
            elif level['period_role']=='current_day_open':
                if (tf!='D1' or source_tf!='M1' or raw['calendar'].get('timezone')!='UTC'
                        or raw['calendar'].get('day_boundary')!='00:00'
                        or stamp(source['timestamp_utc'])!=cutoff.replace(hour=0,minute=0,second=0,microsecond=0)):
                    raise ValueError('current_open_boundary')
            else:raise ValueError('unknown_period_role')
            if chart is not None and level['interaction']!=_interaction(level,chart):
                raise ValueError('interaction_recomputation')
            dependencies.extend(e['known_at_utc'] for e in level['interaction']['events'])
        expected_historical={f'{raw["provider"]}:{raw["instrument"]}:{tf}:period_open:{b["timestamp_utc"]}'
            for tf in ('D1','W1') for b in (raw['gobi_observations'].get(tf) or {}).get('input_bars',[])[-3:]}
        if expected_historical!={l['object_id'] for l in levels if l['period_role']=='historical_closed_period_open'}:
            raise ValueError('missing_historical_period_open')
        from .digger_position_sequence import build as build_position_sequence
        sequence=raw.get('digger_sequence_observations')
        if raw.get('schema') in (VERSION,SEQUENCE_VERSION) or sequence is not None:
            if chart is None or sequence!=build_position_sequence(levels,chart,raw['chart_timeframe'],MINUTES[raw['chart_timeframe']]):
                raise ValueError('position_sequence_recomputation')
    except (ValueError,TypeError,KeyError,AttributeError,IndexError,OverflowError):
        errors.append('digger_source_or_recomputation_invalid')
    inventory=raw.get('digger_event_time_inventory')
    if raw.get('schema')==VERSION or inventory is not None:
        try:
            from .digger_inventory_context import build as build_inventory
            inputs=inventory['source_inputs'];tf=raw['chart_timeframe'];chart=raw['digger_context']['interaction_input_bars']
            if set(inputs)!={'D1','W1','M1'}:raise ValueError('inventory_periods')
            for period,rows in inputs.items():
                _validate_rows(rows,period,cutoff,raw['calendar'])
                witness=(raw['gobi_observations'].get(period) or {}).get('input_bars',[])
                if bool(rows)!=bool(witness) or (witness and rows[-len(witness):]!=witness):raise ValueError('inventory_native_tail')
                pivot=raw.get('pivotgauge_context') or {}
                witness=(pivot.get('opening_input_bars',[]) if period=='M1' else pivot.get('source_inputs',{}).get(period,[]))
                if witness and rows[-len(witness):]!=witness:raise ValueError('inventory_pivot_source_tail')
                dependencies.extend(b['known_at_utc'] for b in rows)
            if tf in inputs and inputs[tf]!=chart:raise ValueError('inventory_chart_source')
            if inventory!=build_inventory(dict(inputs,**{tf:chart}),provider=raw['provider'],instrument=raw['instrument'],
                    calendar=raw['calendar'],cutoff_utc=raw['as_of_utc'],chart_timeframe=tf,minutes=MINUTES):
                raise ValueError('inventory_recomputation')
        except (ValueError,TypeError,KeyError,AttributeError,IndexError,OverflowError):
            errors.append('digger_inventory_source_or_recomputation_invalid')
    def clocks(node):
        if isinstance(node,dict):
            for key,value in node.items():
                if key=='known_at_utc' and value is not None:dependencies.append(value)
                else:clocks(value)
        elif isinstance(node,list):
            for value in node:clocks(value)
    clocks(raw.get('process_indicators'));clocks(raw.get('pivotgauge_context'))
    known=stamp(raw.get('known_at_utc'))
    if any(stamp(t) is None or known is None or stamp(t)>known for t in dependencies):
        errors.append('producer_known_at_before_dependency')
    return errors


def consume_context(scene):
    """Malformed producer data is rejected without escaping into the reducer."""
    try:
        return _consume_context(scene)
    except (ValueError,TypeError,KeyError,AttributeError,IndexError,OverflowError):
        return dict(schema='gobi_digger_consumer_v1',as_of_utc=scene.get('cutoff_utc'),
            status='rejected',adjudication='context_incomplete',read_only=True,
            automatic_trade_permission=False,future_bars_used=False,score_effect='none',
            parent_direction_effect='none',entry_permission=False,
            blockers=['producer_contract_malformed'])


def consume_inventory_history(scene,references,directory):
    """Restore observations separately; never merge old data into current map/owner."""
    from .digger_inventory_history import restore,canonical
    base=dict(schema='gobi_digger_inventory_history_review_v1',as_of_utc=scene.get('cutoff_utc'),
        status='rejected',items=[],read_only=True,automatic_trade_permission=False,future_bars_used=False,
        entry_permission=False,owner_equivalence=False,score_effect='none',direction_effect='none',
        current_inventory_replaced=False,live_first_seen_verified=False)
    try:
        if (not isinstance(references,list) or len(references)>20
                or len({digest(r) for r in references})!=len(references)):
            raise ValueError('history_reference_list_invalid_or_duplicate')
        if sha256(canonical({k:v for k,v in scene.items() if k!='scene_id'})).hexdigest()!=scene.get('scene_id'):
            raise ValueError('history_current_scene_not_sealed')
        context=consume_context(scene)
        if context['status']!='consumed_native_observations':raise ValueError('history_current_context_rejected')
        inventory=context.get('digger_event_time_inventory')
        if inventory is None:raise ValueError('history_current_inventory_not_produced')
        results=[restore(directory,ref,as_of_utc=scene['cutoff_utc'],provider=scene['provider'],instrument=scene['instrument'],
            chart_timeframe=scene['timeframe'],feed_id=inventory['feed_identity']['feed_id']) for ref in references]
        base.update(status='historical_observations_reviewed',current_scene_id=scene['scene_id'],
            current_producer_receipt_id=context['producer_receipt_id'],current_inventory_version_id=inventory['current_inventory_version_id'],
            items=results,restored_count=sum(r['status']=='restored_original_observation' for r in results),
            rejected_count=sum(r['status']!='restored_original_observation' for r in results),
            relation='original_receipt_recovery_not_current_inventory_or_native_owner_equivalence')
        base['receipt_id']=digest(base)
    except (ValueError,TypeError,KeyError,AttributeError,OverflowError) as error:
        base['reason']=str(error)
    return base
