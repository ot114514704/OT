"""Bind legacy renderer metadata to the native scoring contract explicitly.

The renderer's owned-return record already states its native timeframe. Some
arrow projections omit the redundant anchor_native_timeframe. Copy ONLY that
existing fact after both source ids agree; never invent an owner or a clock.
"""
from bisect import bisect_left,bisect_right
from .one_to_one_structure_score import (attach_scene_scores,NativeScoreContext,canonical_point,
                                         node_response,epoch)


def attach_existing_native_nodes(scene):
    """Consume the renderer's actual pre-source nodes, without inventing whole waves.

    Arrow sources can lack source_opposing_wave_context but already carry
    independently identified prior same-kind nodes. They are useful partial
    structure, not permission to relabel one as the author's wave2/wave4.
    """
    try:
        ctx=NativeScoreContext(scene.get('execution_context',{}).get('bars',[]),scene['timeframe'],
            scene['provider'],scene.get('symbol') or scene['instrument'])
    except (KeyError,TypeError,ValueError):return
    objects={o['id']:o for o in scene.get('objects',[])}
    scale={'untested':0,'wick_touch_only':0,'reclaimed_after_cross':0,'closed_through':50,'accepted_with_follow':100}
    for r in scene['one_to_one_structure_scores']['readings']:
        if r['status']!='scored':continue
        f=objects[r['object_id']]['evidence']['record'];a=canonical_point(f['source_origin'])
        known=max(epoch(canonical_point(f[k])['confirmed_at_utc']) for k in ('source_origin','source_terminal'))
        observed=f.get('structure_observation') or {};selection=f.get('source_selection_evidence') or {}
        candidates=[];rejected=[]
        if (observed.get('native_timeframe')==scene['timeframe'] and
                observed.get('source_path_leg_id')==f['source_leg_id']):
            candidates.append(('structure_observation.prior_node',observed.get('prior_node')))
        if selection.get('reference_source_leg_id')==f['source_leg_id']:
            candidates.append(('source_selection_evidence.prior_node',selection.get('prior_node')))
        nodes=[];seen=set();end=bisect_right(ctx.times,epoch(scene['cutoff_utc'])-ctx.seconds)
        c=objects[r['object_id']]['evidence']['projection']['anchor'];ci=bisect_left(ctx.times,epoch(c['pivot_timestamp_utc']))
        for provenance,raw in candidates:
            if not raw:continue
            try:
                p=canonical_point(raw);key=(p['pivot_timestamp_utc'],p['price'])
                if key in seen:continue
                if epoch(p['pivot_timestamp_utc'])>=epoch(a['pivot_timestamp_utc']):
                    raise ValueError('reference_not_prior_to_this_source')
                ctx.point_index(p,known)
                if p['kind']!=('confirmed_swing_high_candidate' if r['direction']>0 else 'confirmed_swing_low_candidate'):
                    raise ValueError('reference_not_directional_same_kind_boundary')
                if not ctx.continuous(ci,end-1):raise ValueError('current_return_history_gap_unknown')
                q=node_response(ctx,ctx.bars[ci+1:end],p,r['direction'],c['price'],r['target'])
                q.update(provenance=provenance,measurement_source_leg_id=f['source_leg_id'],
                         reference_scope='existing_pre_source_same_native_period_node',known_at_utc=p['confirmed_at_utc'])
                nodes.append(q);seen.add(key)
            except (KeyError,ValueError,TypeError) as exc:
                rejected.append(dict(provenance=provenance,reason=str(exc)))
        own=(r.get('current_structure',{}).get('nodes') or {}).get('own_retraced_terminal')
        state=('finished_local_measurement' if not r['forecast_eligible'] else
               'current_structure_history_unknown' if not own else
               'native_prior_node_context_unknown' if not nodes else
               'prior_native_node_reclaimed' if any(n['state']=='reclaimed_after_cross' for n in nodes) else
               'observed_native_nodes_accepted' if own['state']=='accepted_with_follow' and all(n['state']=='accepted_with_follow' for n in nodes) else
               'own_native_terminal_not_accepted' if own['state']!='accepted_with_follow' else 'prior_native_nodes_not_accepted')
        available=min([scale[own['state']]]+[scale[n['state']] for n in nodes]) if own and nodes else None
        r['scene_native_structure_embedding']=dict(as_of_utc=scene['cutoff_utc'],source_leg_id=f['source_leg_id'],
            native_timeframe=scene['timeframe'],state=state,prior_nodes=nodes,rejected_references=rejected,
            own_terminal_state=own['state'] if own else 'unknown',observed_nodes_breakout_score=available,
            available_node_count=len(nodes),coverage_scope='partial_existing_nodes_not_complete_preceding_whole_wave',
            whole_wave_structure_score=r['structure_score'],author_control_nodes_adjudicated=False,
            score_is_probability=False,automatic_trade_permission=False)


def attach_owned_scene_scores(scene):
    from .one_to_one_source_context import attach_source_contexts
    attach_source_contexts(scene)
    restored=[];restored_records=[];bindings={}
    try:
        for obj in scene.get('objects', []):
            e=obj.get('evidence') or {};p=e.get('projection');f=e.get('record')
            if obj.get('layer')!='one_to_one' or not isinstance(p,dict) or not isinstance(f,dict):
                continue
            own=(f.get('return_ownership_by_projection_id') or {}).get(p.get('projection_id')) or {}
            displayed=e.get('ownership') or {}
            native=e.get('native_source_structure') or {}
            if (native.get('status')=='native_source_predecessor_bound' and
                    native.get('source_leg_id')==f.get('source_leg_id')):
                restored_records.append((e,f))
                e['record']=dict(f,source_opposing_wave_context=native['context'])
            if ('anchor_native_timeframe' not in p and own.get('native_timeframe')==scene['timeframe'] and
                    displayed.get('native_timeframe')==own['native_timeframe'] and
                    own.get('measurement_source_leg_id')==f.get('source_leg_id')==p.get('measurement_source_leg_id')==displayed.get('measurement_source_leg_id') and
                    own.get('retraces_source_leg_id')==p.get('retraces_source_leg_id')==displayed.get('retraces_source_leg_id')):
                restored.append((e,p));e['projection']=dict(p,anchor_native_timeframe=own['native_timeframe'])
                bindings[obj['id']]='anchor_native_timeframe_from_existing_matching_native_return_ownership'
        attach_scene_scores(scene)
        for reading in scene['one_to_one_structure_scores']['readings']:
            if reading['object_id'] in bindings:
                reading['metadata_binding']=bindings[reading['object_id']]
            obj=next(o for o in scene['objects'] if o['id']==reading['object_id'])
            native=obj.get('evidence',{}).get('native_source_structure') or {}
            reading['native_source_context_binding']={k:native[k] for k in ('status','reason','binding',
                'source_leg_id','timeframe','source_known_at_utc','node_count','source_endpoints_changed') if k in native}
            inventory=reading.get('source_reference_inventory') or {}
            obj['label']+=f" leg2_refs={inventory.get('verified_count','?')} leg2_refs_state={inventory.get('status','unavailable')}"
            embedding=reading.get('second_leg_current_structure_embedding') or {}
            effective=embedding.get('effective_structure_score')
            joint=embedding.get('joint_score')
            obj['label']+=f" leg2_current={embedding.get('disposition','?')} leg2_effective={'?' if effective is None else f'{effective:.1f}'} leg2_joint={'?' if joint is None else f'{joint:.1f}'}"
            quantitative=embedding.get('quantitative_score')
            obj['label']+=f" leg2_quant={'?' if quantitative is None else f'{quantitative:.1f}'} leg2_quant_state={embedding.get('quantitative_score_state','unknown')}（结构接纳分，非成功概率）"
        attach_existing_native_nodes(scene)
        from .one_to_one_continuation_context import attach_scene_continuations
        attach_scene_continuations(scene)
        for reading in scene['one_to_one_structure_scores']['readings']:
            continuation=reading.get('continuation_unit_context') or {}
            obj=next(o for o in scene['objects'] if o['id']==reading['object_id'])
            options=((continuation.get('first_unit_projection_receipt') or {}).get('continuation_alternatives') or {}).get('options',[])
            if options:
                names={'unreached':'未到','reached':'已到','anchor_failed':'锚失效',
                       'same_bar_ambiguous':'同根未知','history_gap_unknown':'缺史'}
                text='/'.join(f"{o['ratio']:g}×{o['target']:.3f}({names.get(o['observation_at_confirmation']['status'],'待核')})" for o in options)
                obj['label']+=' | 确认时条件量尺 '+text+'；作者浪级待核'
            else:
                obj['label']+=' | 条件量尺待核（来源/归属/时钟/原生覆盖）'
            extra=reading.get('scene_native_structure_embedding')
            if extra:
                obj=next(o for o in scene['objects'] if o['id']==reading['object_id'])
                obj['label']+=f" leg2_nodes={extra['available_node_count']} leg2_node_state={extra['state']}"
        return scene
    finally:
        for evidence,projection in restored:evidence['projection']=projection
        for evidence,record in restored_records:evidence['record']=record
