"""W4 v2 production adapter: native coefficients, clean segments, three clocks.

This layer consumes selected lines; it does not invent wave membership. It
keeps source IDs/anchors and force records, and leaves unprovable records
unchanged with an audit reason. All price observations use closed native bars.
"""
from copy import deepcopy
from datetime import datetime, timezone

ROLES = {'historical_book_outer':'OUTER', 'single_outer_trendline':'OUTER',
         'structural_wave_outer':'OUTER', 'parallel_outer_extension':'CHANNEL',
         'book_shifted_turning_boundary':'RETURN_CE_D', 'book_recovery_target':'RESUME_DF_C'}


def route_book_line_roles(objects):
    """Chapter-3 rulers are not chapter-4 shifted targets.

    Route by explicit provenance, never by colour, slope or label keywords.
    Keep source identity, clocks, geometry and force ownership unchanged.
    This is a display correction, not an automatic author-wave classifier.
    """
    layers={'OUTER':'trend','CHANNEL':'channel',
            'RETURN_CE_D':'turning_point','RESUME_DF_C':'turning_point'}
    result=[];changes=[]
    for source in objects:
        family=ROLES.get(source.get('evidence',{}).get('display_role'))
        if (family is None or source.get('kind')!='line'
                or source.get('layer') not in ('trend','channel','turning_point')):
            result.append(source);continue
        target=layers[family]
        if source['layer']==target:
            result.append(source);continue
        obj=deepcopy(source);obj['layer']=target
        obj['evidence']['display_layer_correction']={
            'from':source['layer'],'to':target,'family':family,
            'policy':'chapter3_ruler_chapter4_shifted_target_separate',
            'geometry_changed':False,'author_wave_membership_verified':False}
        changes.append(dict(id=obj['id'],**obj['evidence']['display_layer_correction']))
        result.append(obj)
    return result,dict(changed_layers=len(changes),removed_objects=0,
                       geometry_changes=0,force_changes=0,changes=changes)


def epoch(s):
    return datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()


def iso(t):
    return datetime.fromtimestamp(t,timezone.utc).isoformat().replace('+00:00','Z')


def native_delivery_context(objects,timeframe,cutoff,stamps):
    """Load only the closed native range needed by the composed viewport."""
    from bisect import bisect_left,bisect_right
    import json
    from .build_archive_window_snapshot import ARCHIVE,load_prefix,TIMEFRAME_MINUTES,mt5_weekly_prefix
    seconds=TIMEFRAME_MINUTES[timeframe]*60
    anchors=[float(p[0]) for o in objects if o.get('evidence',{}).get('display_role') in ROLES
             for p in o.get('evidence',{}).get('ruler_identity',[])]
    if not anchors:return []
    count=bisect_right(stamps,epoch(cutoff)-seconds)-bisect_left(stamps,min(anchors))+1
    dataset=next(d for d in json.loads((ARCHIVE/'catalog.json').read_text())['datasets'] if d['id']=='HistData')
    data=(mt5_weekly_prefix(dataset,epoch(cutoff),count) if timeframe=='W1'
          else load_prefix(dataset['periods'][timeframe],epoch(cutoff),count))
    return [dict(timestamp_utc=iso(float(r[0])),
                 closed_at_utc=iso(float(r[0])+seconds),
                 timeframe=timeframe,
                 open=float(r[1]),high=float(r[2]),
                 low=float(r[3]),close=float(r[4])) for r in data]


def deliver_book_lines(objects, bars, timeframe, cutoff, seconds):
    end_clock=epoch(cutoff)
    rows=[r for r in bars if epoch(r['timestamp_utc'])+seconds<=end_clock]
    times=[epoch(r['timestamp_utc']) for r in rows];pos={t:i for i,t in enumerate(times)}
    result=[];checks=[];skipped=[]
    for source in objects:
        ev=source.get('evidence',{});family=ROLES.get(ev.get('display_role'))
        if family is None or source.get('timeframe')!=timeframe:
            result.append(source);continue
        try:
            identity=ev['ruler_identity'];up=ev['direction']=='up'
            if len(identity)!=(3 if family in ('RETURN_CE_D','RESUME_DF_C') else 2):
                raise ValueError('INCOMPLETE_NATIVE_POINT_IDENTITY')
            if any(float(p[0]) not in pos for p in identity+source['points']):
                raise ValueError('EXACT_NATIVE_ANCHOR_OUTSIDE_CONTEXT')
            a,b=identity[:2];i,j=pos[a[0]],pos[b[0]]
            if i>=j:raise ValueError('NATIVE_ANCHOR_ORDER')
            side='low' if up else 'high'
            pair_side=('high' if up else 'low') if family=='RETURN_CE_D' else side
            if any(float(rows[pos[t]][pair_side])!=float(p) for t,p in (a,b)):
                raise ValueError('SOURCE_POINT_NOT_NATIVE_EXTREME')
            slope=(b[1]-a[1])/(j-i)
            start=pos[source['points'][0][0]];end=pos[source['points'][-1][0]]
            anchor_price=a[1];anchor=i;allowed={i,j};lower=up;channel_scope=None
            if family=='CHANNEL':
                anchor_price+=ev['parallel_offset'];lower=not up
                reference=i+ev['parallel_reference_index']-ev['anchor_start_index']
                if not 0<=reference<len(rows):raise ValueError('CHANNEL_REFERENCE_OUTSIDE_CONTEXT')
                if abs(float(rows[reference]['high' if up else 'low'])-(anchor_price+slope*(reference-i)))>1e-7:
                    raise ValueError('CHANNEL_OFFSET_NOT_FROM_REFERENCE')
                # A true contact is necessary but insufficient: it must be
                # the outermost displacement of THIS declared formation.
                # Recheck candles before Q too. Forward-only trimming could
                # otherwise accept an old cached offset while an earlier
                # candle lies outside its claimed channel.
                window=ev.get('reference_window') or {}
                channel_scope=None
                if window:
                    left=window.get('start_index');right=window.get('end_index')
                    if type(left) is not int or type(right) is not int:
                        raise ValueError('CHANNEL_FORMATION_WINDOW_INVALID')
                    left=i+left-ev['anchor_start_index'];right=i+right-ev['anchor_start_index']
                    if not 0<=left<=i<j<=right<len(rows) or not left<=reference<=right:
                        raise ValueError('CHANNEL_FORMATION_WINDOW_INVALID')
                    construction=ev.get('construction_known_at_utc',source['known_at_utc'])
                    if times[right]+seconds>epoch(construction):
                        raise ValueError('CHANNEL_FORMATION_USES_FUTURE_BAR')
                    for k in range(left,right+1):
                        edge=anchor_price+slope*(k-i)
                        gap=edge-float(rows[k]['high']) if up else float(rows[k]['low'])-edge
                        if gap < -1e-7:
                            raise ValueError('CHANNEL_REFERENCE_NOT_OUTERMOST_OF_DECLARED_PHASE')
                        if k not in (i,j):
                            base=a[1]+slope*(k-i)
                            base_gap=float(rows[k][side])-base if up else base-float(rows[k][side])
                            if base_gap<=1e-9:
                                raise ValueError('CHANNEL_PARENT_NOT_OUTER_OF_DECLARED_PHASE')
                    channel_scope=(left,right)
                allowed={reference}
            elif family in ('RETURN_CE_D','RESUME_DF_C'):
                shift=identity[2];anchor=pos[shift[0]];anchor_price=shift[1]
                shift_side=side if family=='RETURN_CE_D' else ('high' if up else 'low')
                if float(rows[anchor][shift_side])!=float(anchor_price):raise ValueError('SHIFT_NOT_NATIVE_EXTREME')
                if family=='RETURN_CE_D' and not i<anchor<j:raise ValueError('C_D_E_ORDER')
                if family=='RESUME_DF_C' and not anchor<i<j:raise ValueError('C_D_F_ORDER')
                if family=='RESUME_DF_C':
                    if ev.get('structural_wave'):
                        eindex=pos[epoch(ev['pivot_times'][3])]
                    else:
                        eindex=anchor+ev['source_E_index']-ev['shift_anchor_index']
                    if not anchor<i<eindex<j:raise ValueError('C_D_E_OBSERVED_F_ORDER')
                    if times[eindex]+seconds>epoch(source['known_at_utc']):
                        raise ValueError('SOURCE_E_NOT_YET_CLOSED')
                lower=up if family=='RETURN_CE_D' else not up
                allowed={anchor}
            level=lambda k:anchor_price+slope*(k-anchor)
            if any(abs(p-level(pos[t]))>1e-7 for t,p in source['points']):
                raise ValueError('DISPLAY_SLOPE_OR_SHIFT_NOT_FROM_NAMED_POINTS')
            parameter_start=start
            if family=='CHANNEL':
                # The line equation's reference origin is not a native touch.
                # Legacy packets may still begin at that synthetic price.
                start=max(start,reference)
                if start>=end:raise ValueError('CHANNEL_HAS_NO_SEGMENT_AFTER_NATIVE_CONTACT')
            source_scope=None;source_scope_end=j
            if family=='CHANNEL' and channel_scope is not None:
                source_scope,source_scope_end=channel_scope
            if family=='RESUME_DF_C':
                # Recovery uses its OWN D/F outside edge, not the ancestor
                # origin or merely a valid-looking line translated through C.
                source_scope=i;pair_sign=1 if up else -1
                for k in range(i+1,j):
                    if pair_sign*(float(rows[k][side])-(a[1]+slope*(k-i)))<=1e-9:
                        raise ValueError('DF_SOURCE_NOT_OUTER_OF_OWN_RECOVERY_PHASE')
            if family=='RETURN_CE_D':
                scope_clock=ev.get('owned_phase_start_utc') or (ev.get('construction_audit') or {}).get('wave_start_utc')
                if scope_clock is None and ev.get('structural_wave'):
                    scope_clock=ev['pivot_times'][0]
                if ev.get('structural_wave') and scope_clock!=ev['pivot_times'][0]:
                    raise ValueError('CE_OWNED_PHASE_IDENTITY_MISMATCH')
                if scope_clock is not None:
                    source_scope=pos[epoch(scope_clock)]
                elif type(ev.get('parent_wave_start_index')) is int:
                    source_scope=ev['parent_wave_start_index']
                if source_scope is not None:
                    if not 0<=source_scope<=i:raise ValueError('CE_OWNED_PHASE_ORDER')
                    end_clock=ev.get('owned_phase_formation_end_utc') or (ev.get('construction_audit') or {}).get('wave_end_utc')
                    if end_clock is not None:
                        source_scope_end=pos[epoch(end_clock)]
                        if source_scope_end<j:raise ValueError('CE_OWNED_PHASE_FORMATION_END_ORDER')
                        if times[source_scope_end]+seconds>epoch(ev.get('construction_known_at_utc',source['known_at_utc'])):
                            raise ValueError('CE_OWNED_PHASE_USES_FUTURE_FORMATION')
                    pair_sign=1 if up else -1;pair_side='high' if up else 'low'
                    for k in range(source_scope,source_scope_end+1):
                        if k in (i,j):continue
                        if pair_sign*(a[1]+slope*(k-i)-float(rows[k][pair_side]))<=1e-9:
                            raise ValueError('CE_SOURCE_NOT_OUTER_OF_DECLARED_PHASE')
            # Contact is excluded from the clean segment and kept separately
            # in the independent event ledger. Never count it as clean price.
            contact=None
            for k in range(start+1,len(rows)):
                if k in allowed:continue
                gap=float(rows[k]['low'])-level(k) if lower else level(k)-float(rows[k]['high'])
                if gap<=1e-9:
                    contact=k;break
            if contact is not None and family=='OUTER' and contact<j:
                raise ValueError('INTERIOR_CONTACT_BEFORE_SECOND_ANCHOR')
            construction=ev.get('construction_known_at_utc',source['known_at_utc'])
            revised=ev.get('display_revision')
            shown_end=min(end,contact-1) if contact is not None else end
            if shown_end<=start:raise ValueError('NO_CLEAN_DISPLAY_SEGMENT')
            obj=deepcopy(source);facts=obj['evidence']
            if family=='CHANNEL':obj['points'][0]=[times[start],level(start)]
            obj['points'][-1]=[times[shown_end],level(shown_end)]
            display_known=iso(times[shown_end]+seconds)
            status_known=construction
            contact_applies=contact is not None and contact<=end+1
            if contact_applies:
                status_known=iso(times[contact]+seconds)
                display_known=max(display_known,status_known)
            # A later close-break stored in evidence is also a later fact,
            # even when the visible clean segment ended on an earlier wick.
            for field in ('first_break_utc','first_close_break_utc'):
                if ev.get(field):status_known=max(status_known,iso(epoch(ev[field])+seconds))
            if revised:
                display_known=max(display_known,revised['successor_known_at'])
                status_known=max(status_known,revised['successor_known_at'])
            # Other source-specific terminal states (e.g. DF contact) may end
            # the target before its own contact. Its next bar proves the stop.
            if end<len(rows)-1 and not contact_applies and not revised:
                display_known=max(display_known,iso(times[end+1]+seconds))
                status_known=max(status_known,iso(times[end+1]+seconds))
            display_known=max(construction,display_known)
            status_known=max(construction,status_known)
            facts.update(construction_known_at_utc=construction,
                         display_state_known_at_utc=display_known,status_known_at_utc=status_known,
                         delivery_contract='w4_three_clock_native_geometry_v2',
                         native_timeframe=timeframe,coefficient_family=family,
                         verified_slope_per_native_bar=slope,
                         coefficient_verification='native_points_and_display_endpoints_match',
                         delivery_original_points=deepcopy(source['points']),
                         retrospective_at_construction=bool(contact_applies and iso(times[contact]+seconds)<construction))
            # Preserve separate source/axis diagnostics in the source audit.
            # This JSON evidence is not proof of final MT5 Shape transport.
            axis_meta = (ev.get('axis_reference') or ev.get('axis_alignment')
                         or {})
            source_axis_slope = axis_meta.get('axis_slope_per_native_bar')
            if source_axis_slope is None:
                source_axis_slope = ev.get('axis_slope_per_native_bar')
            if source_axis_slope is None:
                source_axis_slope = ev.get('midaxis_slope')
            try:
                source_axis_slope = float(source_axis_slope) if source_axis_slope is not None else None
            except (TypeError, ValueError):
                source_axis_slope = None
            axis_mismatch = axis_meta.get('alignment_measure')
            if axis_mismatch is None:
                axis_mismatch = ev.get('axis_slope_mismatch_normalized')
            try:
                axis_mismatch = float(axis_mismatch) if axis_mismatch is not None else None
            except (TypeError, ValueError):
                axis_mismatch = None
            axis_scope = axis_meta.get('axis_scope')
            if axis_scope is None and source_scope is not None:
                axis_scope = dict(start_utc=iso(times[source_scope]),
                                  end_utc=iso(times[source_scope_end]))
            alignment_state = (axis_meta.get('alignment_quality_state')
                               or ev.get('alignment_quality_state')
                               or ('engineering_diagnostic' if source_axis_slope is not None and axis_scope
                                   else 'unknown_missing_owned_phase_axis'))
            facts['native_boundary_source']=dict(family=family,source_points=deepcopy(identity[:2]),
                shift_point=deepcopy(identity[2]) if len(identity)==3 else None,
                parallel_contact=[times[reference],level(reference)] if family=='CHANNEL' else None,
                actual_display_start=[times[start],level(start)],
                parameter_start=[times[parameter_start],level(parameter_start)],
                slope_per_native_bar=slope,
                source_slope_per_native_bar=slope,
                source_slope_known_at_utc=construction,
                phase_id=ev.get('phase_id') or ev.get('native_phase_id'),
                wave_id=ev.get('wave_id'),
                axis_scope=deepcopy(axis_scope),
                axis_method=axis_meta.get('axis_method') or ev.get('axis_method'),
                axis_slope_per_native_bar=source_axis_slope,
                axis_slope_mismatch_normalized=axis_mismatch,
                alignment_quality_state=alignment_state,
                producer_axis_reference=deepcopy(axis_meta) if axis_meta else None,
                source_contact_rule=(('verified_outermost_opposite_native_contact' if channel_scope is not None else 'native_contact_scope_not_supplied')
                                     if family=='CHANNEL' else 'owned_native_source_points'),
                parallel_envelope_scope=(dict(start_utc=iso(times[channel_scope[0]]),end_utc=iso(times[channel_scope[1]]))
                                         if family=='CHANNEL' and channel_scope is not None else None),
                owned_scope_start_utc=iso(times[source_scope]) if source_scope is not None else None,
                owned_scope_end_utc=iso(times[source_scope_end]) if source_scope is not None else None,
                source_outer_envelope='verified_declared_phase' if source_scope is not None else 'scope_not_supplied',
                source_and_shift_roles_distinct=True,author_degree_verified=False)
            if source_scope is not None:
                from .pdf_trendline_block import _native_axis_slope
                owned_rows=rows[source_scope:source_scope_end+1]
                axis=_native_axis_slope(owned_rows)
                scale=max(max(r['high'] for r in owned_rows)-min(r['low'] for r in owned_rows),1e-9)/max(1,len(owned_rows)-1)
                facts['native_boundary_source']['axis_reference']=dict(
                    axis_scope=dict(start_utc=iso(times[source_scope]),end_utc=iso(times[source_scope_end])),
                    axis_method='split_half_native_body_medians',axis_as_of=construction,
                    axis_slope_per_native_bar=axis,alignment_measure=abs(slope-axis)/scale,
                    alignment_quality_state='engineering_diagnostic_not_author_threshold')
                facts['native_boundary_source'].update(axis_scope=dict(start_utc=iso(times[source_scope]),end_utc=iso(times[source_scope_end])),
                    axis_method='split_half_native_body_medians',axis_slope_per_native_bar=axis,
                    axis_slope_mismatch_normalized=abs(slope-axis)/scale,
                    axis_mismatch_normalization='owned_range_per_native_bar',
                    alignment_quality_state='engineering_diagnostic_not_author_threshold')
            if contact_applies:facts['clean_segment_contact_utc']=iso(times[contact])
            obj['known_at_utc']=max(construction,display_known,status_known)
            if shown_end<end:
                obj['status']='clean_segment_before_contact'
                obj['label']+=' | 触线K另标·洁净线止于前根'
            if facts['retrospective_at_construction']:
                obj['label']+=' | 形成时已触线·历史构造'
            checks.append(dict(id=obj['id'],family=family,trimmed_event_endpoint=shown_end<end,
                               construction_known=construction,display_known=display_known,status_known=status_known))
            result.append(obj)
        except (KeyError,ValueError,TypeError,IndexError) as exc:
            skipped.append(dict(id=source['id'],family=family,reason=str(exc)))
            result.append(source)
    return result,dict(verified_lines=len(checks),trimmed_event_endpoints=sum(c['trimmed_event_endpoint'] for c in checks),
                       removed_objects=0,force_objects_modified=0,checks=checks,unverified=skipped)
