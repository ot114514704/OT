"""Source-owned return observations, NOT full entry-route permission.

The 24h calibration review window is a research horizon, not an author stop
or a global rule that an older trading setup must expire after 24h.
"""
from .force_strength_model import BANDS,epoch,iso

NAMES={'50_61.8':'浅','77_88':'深','127.2':'再扫'}
STAGES={'observation':'观察','candidate':'候选','confirmed':'价格触发已确认',
        'invalidated':'失效','completed':'已结束','ambiguous':'顺序未知'}


def trigger_geometry(force,retest,path,bars,ordinary,end):
    """Actual signal-close reference, not a fill or a higher-period target."""
    signal=path.get('signal_at_utc');touch=retest.get('first_touch_utc')
    missing=dict(status='unavailable',reason='no_visible_trigger_candle',fill_price=None)
    if not signal or not touch or epoch(signal)>end:return missing
    candles=[b for b in bars if epoch(force['known_at_utc'])<=b['t'] and b['closed']<=end]
    candle=next((b for b in candles if abs(b['closed']-epoch(signal))<1e-6),None)
    if candle is None:return missing
    a,b=force['points'];sign=1 if b[1]>a[1] else -1
    entry=float(candle['close']);stop=float(a[1]);target=float(b[1])
    if not ordinary:
        swept=[x for x in candles if epoch(touch)<=x['closed']<epoch(signal)]
        if not swept:return dict(missing,reason='sweep_protection_not_observable')
        stop=min([stop]+[x['low'] for x in swept]) if sign>0 else max([stop]+[x['high'] for x in swept])
    risk=sign*(entry-stop);reward=sign*(target-entry)
    return dict(status='observed',direction='long' if sign>0 else 'short',
        trigger_close_reference=entry,trigger_known_at_utc=signal,protection_price=stop,
        protection_basis='frozen_source_origin' if ordinary else 'sweep_extreme_before_follow_close',
        response_target_price=target,target_scope='source_terminal_not_parent_DOL',
        geometry_valid=risk>0 and reward>0,risk_points=risk,reward_points=reward,
        reward_risk=reward/risk if risk>0 and reward>0 else None,
        fill_price=None,costs_or_slippage_included=False,automatic_trade_permission=False)


def return_decision(force,retests,responses,*,as_of_utc,review_end_utc,selection,bars=()):
    now=epoch(as_of_utc);end=epoch(review_end_utc);known=epoch(force['known_at_utc'])
    if not known<=end<=now:raise ValueError('return review/source clocks out of order')
    if len(retests)!=3 or set(responses)!=set(BANDS):raise ValueError('three same-source bands required')
    source=force.get('evidence',{}).get('book_first_response',{})
    failed=source.get('invalidated_at_utc')
    failed=failed if failed and epoch(failed)<=now else None
    historical=now>known+86400
    visible=sorted((r for r in bars if r['t']>=known and r['closed']<=end),key=lambda r:r['t'])
    rows={}
    for (key,_),retest in zip(BANDS.items(),retests):
        expected={'50_61.8':'50–61.8%','77_88':'77–88%','127.2':'127.2% second sweep'}[key]
        if retest.get('band',expected)!=expected:raise ValueError('foreign/reordered return band')
        if retest.get('owner_id',force.get('id'))!=force.get('id'):raise ValueError('foreign return owner')
        if retest.get('timeframe',force.get('timeframe'))!=force.get('timeframe'):raise ValueError('foreign return period')
        if retest.get('source_id',force.get('source_id'))!=force.get('source_id'):raise ValueError('foreign return source')
        a,b=force['points'];sign=1 if b[1]>a[1] else -1
        path=responses[key];ordinary=key!='127.2'
        def seen(value,after_source=False):
            return bool(value and (not after_source or known<=epoch(value)) and epoch(value)<=end)
        touched=seen(retest.get('first_touch_utc'),True)
        signal=path.get('signal_at_utc');trigger=touched and seen(signal,True)
        origin_cross=seen(retest.get('origin_swept_at_utc')) or seen(retest.get('invalidated_at_utc'))
        invalid=bool(ordinary and (failed or origin_cross))
        stage='confirmed' if trigger else 'candidate' if touched else 'observation'
        reason='band_reclaim_close' if ordinary else 'sweep_reclaim_origin_and_later_follow'
        # A completed historical response is not a failure merely because
        # its source is breached LATER. Keep result and source validity apart.
        if trigger and path['state'] in ('success','target_already_passed'):
            stage='completed';reason='target_reached_or_already_passed_not_fresh_entry'
        elif trigger and path['state']=='ambiguous':stage='ambiguous';reason='same_bar_target_stop_order_unknown'
        elif trigger and path['state']=='failed':stage='invalidated';reason='triggered_pattern_protection_failed'
        elif invalid:stage='invalidated';reason='ordinary_source_protection_breached'
        needs=('等待档位触及并收回' if ordinary else '等待127.2扫荡、收回来源B及后续同向收盘')
        if touched:needs='等待所属档收回与所选入口' if ordinary else '已触及127.2，等待回收B及后续同向收盘'
        if trigger:needs='价格触发已有；另核背景、所选入口、止损目标'
        if stage=='invalidated':needs='此普通路线不续用，另看独立扫荡或新来源' if ordinary else '此扫荡路线不续用，等待新结构'
        if stage=='completed':needs='保留历史结果，不重复当新入口'
        if stage=='ambiguous':needs='保留顺序未知，不能据此确认执行结果'
        preferred=selection.get('preferred_band')==key
        # Existing fitted outcomes remain unchanged. Practical reuse of the
        # original-C task is a separate axis: an already delivered objective
        # cannot be offered as a fresh target after a later price trigger.
        target_limit=epoch(signal) if trigger else end
        prior_target=next((r for r in visible if r['closed']<=target_limit and
                           sign*((r['high'] if sign>0 else r['low'])-b[1])>=0),None)
        task_retired=prior_target is not None
        if task_retired:needs='原来源C目标已先完成；新入场须另绑定任务与目标，不复用旧C'
        current=(not historical and not task_retired and stage in ('observation','candidate','confirmed'))
        geometry=(trigger_geometry(force,retest,path,bars,ordinary,end) if trigger else
                  dict(status='unavailable',reason='price_trigger_not_confirmed',fill_price=None))
        reference_current=(current and stage=='confirmed' and geometry.get('geometry_valid',False))
        priority=('历史优先观察' if preferred else '竞争档位') if current else (
                  '已归档·仅统计' if historical else '原C已完成·另选任务' if task_retired else '不可续用·仅统计')
        rows[key]=dict(owner_id=force.get('id'),source_id=force.get('source_id'),
            timeframe=force.get('timeframe'),as_of_utc=as_of_utc,
            family='ordinary_retest' if ordinary else 'independent_second_sweep',
            pattern_state=stage,pattern_trigger_confirmed=trigger,
            trigger_known_at_utc=signal if trigger else None,reason=reason,next_required=needs,
            current_review_state=stage if not historical else 'historical_only',
            statistical_preference=preferred,current_observation_priority=priority,
            ordinary_source_protection_failed=invalid,
            historical_only=historical,confirmation_scope='price_pattern_not_entry_route',
            trigger_geometry=geometry,current_conditional_reference=reference_current,
            source_target_task_retired=task_retired,
            source_target_delivered_before_route_utc=iso(prior_target['closed']) if prior_target else None,
            entry_route_state='not_adjudicated',automatic_trade_permission=False)
    status=' '.join(NAMES[k]+STAGES[v['pattern_state']] for k,v in rows.items())
    caption=('回踩复盘·' if historical else '回踩·')+status
    if not historical and any(v['source_target_task_retired'] for v in rows.values()):caption+='·原C已完成'
    # Never force route A through a subsequently completed force-leg gate.
    return dict(schema='force_return_observation_v1',owner_id=force.get('id'),
        source_id=force.get('source_id'),timeframe=force.get('timeframe'),
        as_of_utc=as_of_utc,review_end_utc=review_end_utc,
        review_policy_end_utc=iso(known+86400),historical_only=historical,
        scope='24h_calibration_response_observation_not_global_trade_expiry',
        source_failed_at_utc=failed,bands=rows,caption=caption,
        current_observation_preferred_band=next((k for k,v in rows.items() if v['statistical_preference']
            and not v['historical_only'] and not v['source_target_task_retired'] and v['pattern_state'] in ('observation','candidate','confirmed')),None),
        selected_entry_band=None,
        direct_return_route='independent_not_evaluated_from_later_force',
        automatic_trade_permission=False)
