"""Causal native wave/return/container graph, shared by indicator consumers.

Alexander Jan28 7674514871451136703/7674515091465949482/7674515523879872601,
Feb6 7603613611321588439/7603613671876987695 and Feb10
7679581120807612849: background, whole wave and internal stages differ.
Exact shared extrema + a connected native path establish *observed* hierarchy.
Direction agreement, price containment or a ZigZag parameter do not establish
author wave degree, institutional accumulation, parent reversal or permission.
Relations become available at their own knowledge time, never backdated.
"""
from datetime import timedelta, datetime, timezone
from bisect import bisect_right
from hashlib import sha256
import json

from .live_nested_stage_review import MINUTES, _native, _leg, _same, _time, _shared_extremum
from .live_source_wave_scope import source_wave_scope
from .live_regime_one_to_one import _NativeWindow, _RegimeIndex, _key, _utc
from .native_market_sessions import research_calendar
from .native_timeframe_state import resolve_native_timeframe_state

SCHEMA = 'causal_native_structure_graph_v1'
PERIODS = tuple(reversed(MINUTES))
SOURCE_REFS = ['msg-7674514871451136703', 'msg-7674515091465949482',
               'msg-7674515523879872601', 'msg-7603613611321588439',
               'msg-7603613671876987695', 'msg-7679581120807612849',
               'msg-7605363360134535055']


def _id(*parts):
    return sha256(json.dumps(parts, sort_keys=True, separators=(',', ':')).encode()).hexdigest()[:24]


def _aggregate_path_role(links):
    """Preserve the named process when alternating components form one source.

    A return containing a bounce is still a return path; a decomposition
    containing an internal return is still inside the parent's A→B. Neither
    observation certifies the author's degree or the parent's current task.
    """
    roles = {link['role'] for link in links}
    kinds = {link['relation_type'] for link in links}
    if len(roles) == 1:
        return next(iter(roles))
    if kinds == {'return'} and roles <= {'parent_return_stage', 'bounce_inside_parent_return'}:
        return 'compound_path_inside_parent_return'
    if kinds == {'decomposition'} and roles <= {'parent_forward_stage', 'internal_return_stage'}:
        return 'compound_path_inside_parent_forward'
    return 'compound_path_inside_parent'


def structure_timeline_at(timeline, through_utc):
    """Query the period at the viewport clock, not at a selected old source B."""
    known = _time(through_utc)
    if known > _time(timeline['as_of_utc']):
        raise ValueError('period structure query exceeds frozen native snapshot')
    millis = int(known.timestamp()*1000)
    observations = timeline['observations']
    index = bisect_right(timeline['observation_at_ms'], millis)-1
    result = dict(timeframe=timeline['timeframe'], known_at_utc=_utc(known), status='unavailable',
                  state='unknown', direction=None, witnesses=[], native_closed_through_utc=None,
                  range_exit=None, author_task_adjudicated=False, trade_permission=False)
    if index >= 0:
        row = observations[index]
        result.update({k:v for k,v in row.items() if k != 'witness_ids'})
        result['witnesses'] = [timeline['points'][i] for i in row['witness_ids']]
        if any(_time(p['confirmed_at_utc']) > known for p in result['witnesses']):
            raise ValueError('future period witness in structure timeline')
        if result['range_exit'] is not None:
            result['range_exit'] = dict(result['range_exit'], known_at_utc=_utc(known))
    closed_index = bisect_right(timeline['closed_at_ms'], millis)-1
    if closed_index >= 0:
        result['native_closed_through_utc'] = _utc(datetime.fromtimestamp(
            timeline['closed_at_ms'][closed_index]/1000, timezone.utc))
    return result


class NativeStructureGraph:
    """Call-local immutable indexes; at() is the shared causal consumer API."""
    def __init__(self, snapshot, *, timeframe_ladder=PERIODS):
        self.snapshot = snapshot
        self.cutoff = _time(snapshot['as_of_utc'])
        ladder = tuple(timeframe_ladder)
        if (not ladder or len(set(ladder)) != len(ladder) or any(tf not in MINUTES for tf in ladder)
                or any(MINUTES[a] <= MINUTES[b] for a, b in zip(ladder, ladder[1:]))):
            raise ValueError('analysis ladder must be unique native periods, large to small')
        self.timeframe_ladder = ladder
        self.direct_parent_map = {tf: ladder[i-1] if i else None for i, tf in enumerate(ladder)}
        self.structure_observations = {}
        self.periods, self.nodes, self.links = {}, {}, []
        for tf in PERIODS:
            self._period(tf)
        for child_tf, child in self.periods.items():
            if child['status'] != 'ready':
                continue
            for parent_tf, parent in self.periods.items():
                if MINUTES[parent_tf] <= MINUTES[child_tf] or parent['status'] != 'ready':
                    continue
                self._cross_period(child_tf, child, parent_tf, parent)
        self.by_child = {}
        for link in self.links:
            self.by_child.setdefault(link['child_node_id'], []).append(link)
        for links in self.by_child.values():
            links.sort(key=lambda link: (MINUTES[link['parent_timeframe']], link['known_at_utc'], link['relation_id']))
        # Attach a compact, causal context to every node after all cross-period
        # paths exist.  Consumers should not have to infer background by
        # voting over unrelated directions or by using containment alone.
        self._attach_observed_contexts()

    def _attach_observed_contexts(self):
        """Annotate nodes with observed parent/background and return ownership.

        This is deliberately weaker than an author wave-degree judgement.  A
        context is present only when the same-period component(s) have a
        complete exact-endpoint path into one parent process and that relation
        was known no later than the node itself.  Thus a later parent
        confirmation cannot backfill an earlier child, and a lower-period
        internal pivot cannot masquerade as the parent-period pullback anchor.
        """
        base_by_source = {}
        for tf, period in self.periods.items():
            for leg, node_id in zip(period.get('legs', []), period.get('base_ids', [])):
                if node_id:
                    base_by_source[(tf, leg['leg_id'])] = node_id

        # Native timeframe and wave scope are separate dimensions. The blue
        # whole versus yellow inner Feb10/D1 example forbids calling an inner
        # segment the complete reference just because both are on one chart.
        # Index exact component identities, never overlapping price rectangles.
        enclosing_by_component = {}
        for enclosing in self.nodes.values():
            if len(enclosing['component_leg_ids']) > 1 and enclosing['native_envelope_verified']:
                for component in enclosing['component_leg_ids']:
                    enclosing_by_component.setdefault((enclosing['timeframe'], component), []).append(enclosing)

        for node in self.nodes.values():
            components = list(node.get('component_leg_ids') or [])
            component_pairs = [(source, base_by_source.get((node['timeframe'], source)))
                               for source in components]
            node['structure_scope'] = dict(
                kind='compound_native_envelope' if len(components) > 1 else 'single_native_leg',
                component_count=len(components),
                basis='same_period_connected_native_components',
                author_wave_degree_adjudicated=False,
                trade_permission=False,
            )
            enclosures = []
            if components and node['native_envelope_verified']:
                for enclosing in enclosing_by_component.get((node['timeframe'], components[0]), []):
                    parts = enclosing['component_leg_ids']
                    if len(parts) <= len(components) or _time(enclosing['known_at_utc']) > _time(node['known_at_utc']):
                        continue
                    first = parts.index(components[0])
                    if parts[first:first+len(components)] == components:
                        enclosures.append(enclosing)
            enclosures.sort(key=lambda parent: (len(parent['component_leg_ids']),
                                                parent['known_at_utc'], parent['node_id']))

            def same_period_reference(parent):
                return dict(node_id=parent['node_id'], timeframe=parent['timeframe'],
                            origin=parent['origin'], terminal=parent['terminal'],
                            direction=parent['direction'], known_at_utc=parent['known_at_utc'],
                            component_count=len(parent['component_leg_ids']))

            node['observed_same_period_context'] = dict(
                status='internal_component_path' if enclosures else 'unbound',
                basis='exact_contiguous_native_components_in_known_complete_envelope',
                immediate=same_period_reference(enclosures[0]) if enclosures else None,
                outer=same_period_reference(enclosures[-1]) if enclosures else None,
                candidate_count=len(enclosures),
                author_wave_degree_adjudicated=False,
                trade_permission=False,
            )

            # Reuse the same all-components rule as at(): a compound source is
            # bound only when every named component belongs to one parent
            # process.  Partial component overlap is intentionally unowned.
            buckets = {}
            for component, base_id in component_pairs:
                if not base_id:
                    continue
                for link in self.by_child.get(base_id, []):
                    if _time(link['known_at_utc']) > _time(node['known_at_utc']):
                        continue
                    key = (link['parent_node_id'], link['process_id'], link['relation_type'])
                    bucket = buckets.setdefault(key, dict(components=set(), links=[]))
                    bucket['components'].add(component)
                    bucket['links'].append(link)
            relations = []
            component_set = set(components)
            for bucket in buckets.values():
                if bucket['components'] != component_set:
                    continue
                latest = max(bucket['links'], key=lambda item: (item['known_at_utc'], item['relation_id']))
                parent = self.nodes.get(latest['parent_node_id'])
                if not parent:
                    continue
                # The role describes the entire named source path, not just
                # the final component. Match at() and the shipped consumer.
                aggregate = dict(latest, role=_aggregate_path_role(bucket['links']))
                relations.append((aggregate, parent))
            # One representative per parent period.  All competing processes
            # remain countable without making the panel a wall of rectangles.
            by_period = {}
            for relation, parent in relations:
                key = parent['timeframe']
                previous = by_period.get(key)
                if previous is None or (relation['known_at_utc'], relation['relation_id']) > (
                        previous[0]['known_at_utc'], previous[0]['relation_id']):
                    by_period[key] = (relation, parent)
            ordered = sorted(by_period.values(), key=lambda pair: (-MINUTES[pair[1]['timeframe']],
                                                                    pair[0]['known_at_utc'], pair[0]['relation_id']))
            # Keep every verified process for ownership decisions.  The
            # compact background view intentionally has one representative per
            # parent timeframe, but a same-timeframe decomposition that was
            # confirmed later must not hide a named return from the pullback
            # owner.  Return ownership therefore searches this uncollapsed set
            # and prefers the nearest larger timeframe, then the latest known
            # process within that timeframe.
            relation_candidates = list(relations)

            def compact(relation, parent):
                parent_regime = parent.get('local_regime') or {}
                return dict(
                    timeframe=parent['timeframe'], node_id=parent['node_id'],
                    origin=parent['origin'], terminal=parent['terminal'],
                    direction=parent['direction'],
                    relation_type=relation['relation_type'], role=relation['role'],
                    process_id=relation['process_id'], known_at_utc=relation['known_at_utc'],
                    parent_regime_state=parent_regime.get('state'),
                    parent_regime_direction=parent_regime.get('direction'),
                )

            expected = self.direct_parent_map.get(node['timeframe'])
            direct_pairs = [(r, p) for r, p in relation_candidates if p['timeframe'] == expected]
            # Reuse named return priority, but never relabel a farther ancestor
            # as the adjacent configured parent when that link is absent.
            direct_returns = [(r, p) for r, p in direct_pairs if r['relation_type'] == 'return']
            direct_pool = direct_returns or direct_pairs
            direct_pair = max(direct_pool, key=lambda pair: (pair[0]['known_at_utc'], pair[0]['relation_id'])) if direct_pool else None
            adjacency = dict(expected_direct_parent_timeframe=expected,
                direct_parent_status='outside_configured_ladder' if node['timeframe'] not in self.direct_parent_map
                    else 'top_of_configured_ladder' if expected is None else 'bound' if direct_pair else 'not_bound',
                bound_direct_parent=compact(*direct_pair) if direct_pair else None,
                outer_contexts=[compact(r, p) for r, p in ordered if p['timeframe'] != expected])

            if ordered:
                # The nearest larger timeframe owns the immediate wave/return;
                # the outermost available relation is retained as background.
                # Keeping both avoids silently replacing a direct M15 pullback
                # with a much broader H1/D1 context when several links exist.
                selected_relation, selected_parent = ordered[-1]
                outer_relation, outer_parent = ordered[0]
                node['observed_background_context'] = dict(
                    status='bound', basis='exact_shared_extremum_and_connected_native_path',
                    selected=compact(selected_relation, selected_parent),
                    immediate=compact(selected_relation, selected_parent),
                    outer=compact(outer_relation, outer_parent),
                    available_parent_timeframes=[parent['timeframe'] for _, parent in ordered],
                    competing_parent_processes=len(relations),
                    author_wave_degree_adjudicated=False, trade_permission=False,
                )
            else:
                node['observed_background_context'] = dict(
                    status='unbound', basis='no_complete_same_endpoint_parent_path_at_node_time',
                    selected=None, immediate=None, outer=None, available_parent_timeframes=[],
                    competing_parent_processes=0,
                    author_wave_degree_adjudicated=False, trade_permission=False,
                )
            node['observed_background_context'].update(adjacency)
            known = _time(node['known_at_utc'])
            node['current_structure_context'] = dict(
                known_at_utc=node['known_at_utc'],
                working=self._structure_at(node['timeframe'], known),
                expected_direct_parent_timeframe=expected,
                direct_parent=self._structure_at(expected, known) if expected else None,
                parent_wave_ownership_proven=direct_pair is not None,
                basis='each_native_period_confirmed_structure_at_same_cutoff_not_future_parent_B',
                working_task_direction=None, direct_parent_task_direction=None,
                target_state='unknown', protected_object_id=None,
                author_task_adjudicated=False, trade_permission=False)
            local_obs = node['current_structure_context']['working']
            parent_obs = node['current_structure_context']['direct_parent']
            if expected is not None and direct_pair is None:
                task_candidate, task_basis = 'direct_parent_unbound', 'configured_adjacent_parent_not_bound_at_cutoff'
            elif local_obs.get('status') != 'native_structure_observed' or local_obs.get('state') in {'unknown', 'transition'}:
                task_candidate, task_basis = 'local_structure_unresolved', 'local_native_coverage_or_transition_not_resolved'
            elif local_obs.get('state') == 'range':
                task_candidate, task_basis = 'local_range_observation', 'local_native_range_witnesses_and_exit_review'
            elif parent_obs and parent_obs.get('status') == 'native_structure_observed' and parent_obs.get('state') == 'range':
                task_candidate, task_basis = 'local_trend_inside_parent_range', 'adjacent_parent_range_and_local_native_trend'
            elif (parent_obs and parent_obs.get('status') == 'native_structure_observed'
                  and parent_obs.get('state') == 'trend' and local_obs.get('state') == 'trend'):
                if local_obs.get('direction') == parent_obs.get('direction'):
                    task_candidate, task_basis = 'aligned_delivery_candidate', 'same_cutoff_adjacent_trend_directions'
                else:
                    task_candidate, task_basis = 'countertrend_pullback_candidate', 'opposite_same_cutoff_adjacent_trend_directions'
            else:
                task_candidate, task_basis = 'structure_relation_unresolved', 'parent_and_local_observations_do_not_form_task'
            node['task_context'] = dict(
                state=task_candidate, basis=task_basis,
                local_structure_state=local_obs.get('state'), local_structure_direction=local_obs.get('direction'),
                direct_parent_structure_state=(parent_obs or {}).get('state'),
                direct_parent_structure_direction=(parent_obs or {}).get('direction'),
                task_direction=None, target_state='unknown', protected_object_id=None,
                wave_role_candidate=None, planned_entry_direction=None,
                author_task_adjudicated=False, trade_permission=False,
                known_at_utc=node['known_at_utc'])

            returns = [(relation, parent) for relation, parent in relation_candidates
                       if relation['relation_type'] == 'return']
            returns.sort(key=lambda pair: (MINUTES[pair[1]['timeframe']],
                                           -_time(pair[0]['known_at_utc']).timestamp(),
                                           pair[0]['relation_id']))
            if returns:
                relation, parent = returns[0]
                outer_relation, outer_parent = max(
                    returns, key=lambda pair: (MINUTES[pair[1]['timeframe']],
                                               _time(pair[0]['known_at_utc']), pair[0]['relation_id']))
                node['observed_pullback_context'] = dict(
                    status='inside_parent_return',
                    basis='named_parent_B_departure_with_connected_native_child_path',
                    owner=compact(relation, parent),
                    outer_owner=compact(outer_relation, outer_parent)
                    if outer_parent['node_id'] != parent['node_id'] else None,
                    author_wave_degree_adjudicated=False, trade_permission=False,
                )
            else:
                decompositions = [(relation, parent) for relation, parent in relation_candidates
                                  if relation['relation_type'] == 'decomposition']
                decompositions.sort(key=lambda pair: (MINUTES[pair[1]['timeframe']],
                                                      -_time(pair[0]['known_at_utc']).timestamp(),
                                                      pair[0]['relation_id']))
                if decompositions:
                    relation, parent = decompositions[0]
                    outer_relation, outer_parent = max(
                        decompositions, key=lambda pair: (MINUTES[pair[1]['timeframe']],
                                                          _time(pair[0]['known_at_utc']), pair[0]['relation_id']))
                    node['observed_pullback_context'] = dict(
                        status='inside_parent_forward_or_internal_return',
                        basis='parent_decomposition_path_without_named_parent_B_departure',
                        owner=compact(relation, parent),
                        outer_owner=compact(outer_relation, outer_parent)
                        if outer_parent['node_id'] != parent['node_id'] else None,
                        author_wave_degree_adjudicated=False, trade_permission=False,
                    )
                else:
                    node['observed_pullback_context'] = dict(
                        status='unbound', basis='no_named_parent_return_path_at_node_time',
                        owner=None, author_wave_degree_adjudicated=False, trade_permission=False,
                    )
            # Direction is an observed relationship, not a vote. It tells the
            # consumers which way the native ruler is facing while preserving
            # a countertrend return as a local entry candidate.
            immediate = adjacency['bound_direct_parent']
            parent_direction = immediate.get('direction') if immediate else None
            local_direction = node.get('direction')
            displacement = node['terminal']['price'] - node['origin']['price']
            net_direction = 'up' if displacement > 0 else 'down' if displacement < 0 else 'flat'
            endpoint_direction_agrees = local_direction == net_direction
            relation_role = immediate.get('role') if immediate else None
            if endpoint_direction_agrees and local_direction in {'up', 'down'} and parent_direction in {'up', 'down'}:
                alignment = 'with_parent_direction' if local_direction == parent_direction else 'countertrend_inside_parent'
            else:
                alignment = 'unbound'
            if local_direction == 'up':
                ruler_bias = 'upward_native_1to1'
            elif local_direction == 'down':
                ruler_bias = 'downward_native_1to1'
            else:
                ruler_bias = 'unbound'
            # The entry-side three-push is opposite the parent background,
            # not automatically opposite the selected ruler. In an upward
            # parent, a downward three-push is the countertrend candidate;
            # an upward child may still be the continuation 1:1.
            if parent_direction == 'up':
                three_push_entry = 'downward_three_push_is_countertrend_entry_candidate'
            elif parent_direction == 'down':
                three_push_entry = 'upward_three_push_is_countertrend_entry_candidate'
            elif local_direction == 'up':
                three_push_entry = 'downward_three_push_parent_unknown'
            elif local_direction == 'down':
                three_push_entry = 'upward_three_push_parent_unknown'
            else:
                three_push_entry = 'unbound'
            if not endpoint_direction_agrees:
                # A native high->low pivot leg can span an upward price gap.
                # Keep its structural orientation/ownership and the signed
                # displacement separately; neither observation proves a
                # continuation/pullback trade role for this incomplete leg.
                three_push_entry = 'unbound'
            node['direction_context'] = dict(
                status='bound' if alignment != 'unbound' else 'unbound',
                local_direction=local_direction,
                net_displacement_direction=net_direction,
                endpoint_direction_agrees=endpoint_direction_agrees,
                parent_direction=parent_direction,
                alignment=alignment,
                parent_relation_role=relation_role,
                ruler_bias=ruler_bias,
                # The opposite entry leg is only an expectation after a
                # caller has identified a current task.  A completed parent
                # A→B sign alone is not that task.
                three_push_entry_observation='unknown_working_task',
                basis='native_endpoint_direction_and_observed_parent_relation',
                author_direction_adjudicated=False,
                trade_permission=False,
            )
            # Keep ruler geometry, measurement purpose and a possible later
            # entry separate. A same-direction bounce after the parent's B
            # is still INSIDE a return, not evidence that parent continuation
            # has resumed. Neither geometry nor a three-push supplies an
            # active target, a wave number, or an already triggered entry.
            if not endpoint_direction_agrees:
                measurement_role = 'endpoint_gap_direction_unresolved'
            elif immediate is None:
                measurement_role = 'unbound'
            elif relation_role == 'compound_path_inside_parent':
                measurement_role = 'compound_path_context'
            elif immediate['relation_type'] == 'return':
                measurement_role = ('return_internal_bounce' if alignment == 'with_parent_direction'
                                    else 'pullback_depth')
            else:
                measurement_role = ('continuation_segment' if alignment == 'with_parent_direction'
                                    else 'internal_return_depth')
            node['direction_context'].update(
                measurement_role=measurement_role,
                working_structure_direction=(node.get('local_regime') or {}).get('direction'),
                role_basis='observed_native_path_not_active_parent_task',
                parent_task_adjudicated=False,
                parent_target_state='unknown',
                parent_wave_number=None,
                # Old parent AB sign is not the current working task. Keep
                # potential pullback expectation separate from observed shape
                # and planned entry until task/target/protection are grounded.
                expected_entry_direction=None,
                entry_state='unknown_working_task',
                entry_three_push_expected_direction=None,
                three_push_observed_direction=None,
                working_structure_pullback_hint=(
                    'down' if node['current_structure_context']['working'].get('direction') == 'up' else
                    'up' if node['current_structure_context']['working'].get('direction') == 'down' else None),
            )

    def _structure_at(self, tf, known, *, cache=True):
        """Observe an unfinished period without borrowing its future terminal.

        The confirmed high/low-order hypothesis and actual native range exit
        are reused. This is an observed structure, NOT a selected active task,
        wave number, protected node or entry. Absence of a geometric owner
        cannot erase these separate, causal period facts.
        """
        key = (tf, _utc(known))
        if cache and key in self.structure_observations:
            return self.structure_observations[key]
        period = self.periods.get(tf, {})
        result = dict(timeframe=tf, known_at_utc=_utc(known), status='unavailable',
                      state='unknown', direction=None, witnesses=[],
                      native_closed_through_utc=None, range_exit=None,
                      author_task_adjudicated=False, trade_permission=False)
        if period.get('status') == 'ready':
            native = period['native']
            last = bisect_right(native.times, known-native.duration)-1
            if last >= 0:
                # The time ceiling supplies no price or unconfirmed pivot.
                regime = period['regime'].at(known, {'pivot_timestamp_utc': _utc(known)})
                points = regime.get('witnesses') or []
                complete = bool(points and native.complete(
                    min(_time(p['pivot_timestamp_utc']) for p in points), native.times[last]))
                exit_review = native.range_at(regime, known) if regime['state'] == 'range' else None
                state, direction = regime['state'], regime.get('direction')
                if exit_review and exit_review['state'] != 'no_accepted_exit_observed':
                    state, direction = 'transition', None
                if not complete:
                    state, direction = 'unknown', None
                result.update(status='native_structure_observed' if complete else 'native_coverage_unresolved',
                              state=state, direction=direction, witnesses=points,
                              reason=regime.get('reason'), basis=regime['basis'], range_exit=exit_review,
                              native_closed_through_utc=_utc(native.times[last]+native.duration))
        if cache:
            self.structure_observations[key] = result
        return result

    def structure_timeline(self, timeframe):
        """Sparse state changes; native candle/witness facts are not duplicated.

        Every native close and confirmation is evaluated, including coverage
        loss and range acceptance. Only material state changes are serialized;
        querying does not run the detector again while the user pans the chart.
        """
        period = self.periods[timeframe]
        native = period.get('native')
        closed = [t+native.duration for t in native.times if t+native.duration <= self.cutoff] if native else []
        clocks = set(closed) | {self.cutoff}
        for rows in period.get('regime').points.values() if period.get('regime') else []:
            clocks.update(confirmation for _point, confirmation in rows if confirmation <= self.cutoff)
        observations, at_ms, points = [], [], {}
        for known in sorted(clocks):
            value = self._structure_at(timeframe, known, cache=False)
            row = {k:v for k,v in value.items() if k not in
                   ('timeframe','known_at_utc','native_closed_through_utc','witnesses',
                    'author_task_adjudicated','trade_permission')}
            row['witness_ids'] = []
            for point in value['witnesses']:
                identity = _id(timeframe, _key(point))
                points[identity] = point
                row['witness_ids'].append(identity)
            if row['range_exit'] is not None:
                row['range_exit'] = {k:v for k,v in row['range_exit'].items() if k != 'known_at_utc'}
            if not observations or row != observations[-1]:
                observations.append(row)
                at_ms.append(int(known.timestamp()*1000))
        return dict(schema='native_period_structure_timeline_v1', timeframe=timeframe,
                    snapshot_id=self.snapshot['snapshot_id'], as_of_utc=self.snapshot['as_of_utc'],
                    observations=observations, observation_at_ms=at_ms, points=points,
                    closed_at_ms=[int(t.timestamp()*1000) for t in closed],
                    author_task_adjudicated=False, trade_permission=False)

    def _period(self, tf):
        result = dict(status='unavailable', timeframe=tf, node_ids=[], rejected_leg_count=0)
        self.periods[tf] = result
        try:
            state = resolve_native_timeframe_state(self.snapshot, tf)
            view = {**self.snapshot, 'timeframe_states': {tf: state}}
            _, raw, legs = _native(view, tf, self.cutoff)
            native = _NativeWindow(raw, tf, self.cutoff, research_calendar(self.snapshot, tf))
        except (KeyError, ValueError, TypeError, AttributeError) as error:
            result['reason'] = str(error)
            return
        # Index each endpoint by its own confirmation clock. Requiring the
        # whole leg to be valid here drops a known origin whenever its next
        # terminal is still future, making a causal prefix disagree with the
        # full graph at the exact origin confirmation time.
        points = {_key(p): p for leg in legs for p in (leg['origin'], leg['terminal'])
                  if _time(p['pivot_timestamp_utc']) <= self.cutoff and
                  _time(p['confirmed_at_utc']) <= self.cutoff and
                  _time(p['pivot_timestamp_utc']) in raw}
        regime = _RegimeIndex(list(points.values()))
        valid, base_ids, canonical = [], [], []
        for leg in legs:
            a, b = leg.get('origin', {}), leg.get('terminal', {})
            ok = _leg(leg, tf, raw, self.cutoff)
            if ok:
                start, end = _time(a['pivot_timestamp_utc']), _time(b['pivot_timestamp_utc'])
                ok = native.complete(start, end)
            valid.append(ok)
            if not ok:
                result['rejected_leg_count'] += 1
                base_ids.append(None)
                continue
            known = max(_time(a['confirmed_at_utc']), _time(b['confirmed_at_utc']))
            base = self._node(tf, leg['leg_id'], a, b, [leg['leg_id']], known, regime, native)
            base_ids.append(base['node_id'])
            scope = source_wave_scope(legs, raw, tf, a, b, known, _window_index=native.envelope)
            if scope.get('status') == 'observed_same_period_zigzag_envelope' and scope.get('internal_origin'):
                whole = self._node(tf, scope['source_leg_id'], scope['origin'], b,
                                   scope['component_source_leg_ids'], known, regime, native)
                whole['interior_unordered_bar_times'] = scope.get('interior_unordered_bar_times', [])
                if whole['native_envelope_verified']:
                    canonical.append(whole)
            else:
                # An ordinary complete leg is still a valid native parent
                # candidate. The ZigZag helper returning an unchanged A is a
                # no-op, not a reason to remove that wave from hierarchy.
                if base['native_envelope_verified']:
                    canonical.append(base)
        result.update(status='ready', raw=raw, legs=legs, valid=valid, regime=regime,
                      base_ids=base_ids, canonical=canonical, native=native,
                      native_bar_count=len(raw), native_closed_through_utc=state['latest_closed_bar_end_utc'])
        result['node_ids'] = [identity for identity, node in self.nodes.items() if node['timeframe'] == tf]
        starts = {}
        for i, leg in enumerate(legs):
            if valid[i]:
                p = leg['origin']
                starts.setdefault((p['kind'], p['price']), []).append(i)
        result['starts'] = starts

    def _node(self, tf, source, a, b, components, known, regime, native):
        identity = _id(self.snapshot['instrument'], self.snapshot['provider'], tf, source,
                       _key(a), _key(b))
        if identity in self.nodes:
            return self.nodes[identity]
        context = regime.at(known, b)
        container = None
        accumulation = None
        if context['state'] == 'range':
            exit_review = native.range_at(context, known)
            container = dict(container_id=_id(tf, [_key(p) for p in context['witnesses']]),
                             low=context['range_low'], high=context['range_high'],
                             witnesses=context['witnesses'], exit=exit_review,
                             institutional_accumulation_adjudicated=False)
            accumulation = dict(
                state='candidate' if exit_review['state'] == 'no_accepted_exit_observed' else 'reassess_after_exit',
                basis='same_period_four_confirmed_swing_witnesses_and_native_range_exit',
                witness_count=len(context['witnesses']),
                exit_state=exit_review['state'],
                institutional_accumulation_adjudicated=False,
                trade_permission=False,
            )
            if exit_review['state'] != 'no_accepted_exit_observed':
                context = {**context, 'state': 'transition', 'direction': None,
                           'reason': 'named_range_exit_or_coverage_loss'}
        node = dict(node_id=identity, timeframe=tf, source_leg_id=source, origin=a, terminal=b,
                    component_leg_ids=components, known_at_utc=_utc(known),
                    direction='up' if a['kind'].endswith('low_candidate') else 'down',
                    local_regime=context, range_container=container,
                    accumulation_context=accumulation,
                    native_envelope_verified=native.envelope.contains(native.raw, tf,
                        _time(a['pivot_timestamp_utc']), _time(b['pivot_timestamp_utc']),
                        min(a['price'], b['price']), max(a['price'], b['price'])),
                    author_wave_degree_adjudicated=False, trade_permission=False)
        self.nodes[identity] = node
        return node

    def _connected(self, child, begin):
        chain = []
        for i in range(begin, len(child['legs'])):
            leg = child['legs'][i]
            if not child['valid'][i] or (chain and not _same(chain[-1][1]['terminal'], leg['origin'])):
                break
            chain.append((i, leg))
            yield chain

    def _cross_period(self, child_tf, child, parent_tf, parent):
        for wave in parent['canonical']:
            a, b = wave['origin'], wave['terminal']
            # Completed two-ended decomposition. Nothing is claimed at the
            # child's earlier B if the parent's B was not confirmed then.
            for begin in child['starts'].get((a['kind'], a['price']), []):
                if not _shared_extremum(child['legs'][begin]['origin'], a, parent_tf):
                    continue
                for chain in self._connected(child, begin):
                    end = chain[-1][1]['terminal']
                    if _time(end['pivot_timestamp_utc']) >= _time(b['pivot_timestamp_utc']) + timedelta(minutes=MINUTES[parent_tf]):
                        break
                    if not _shared_extremum(end, b, parent_tf):
                        continue
                    if self._path_bounds(child, chain, a, b):
                        self._link_chain(child_tf, child, parent_tf, wave, chain, 'decomposition')
                    break
            # A *named departure* from the actual parent B, not any opposite
            # child somewhere inside its price rectangle. Keep forward bounces
            # in that return process distinct from parent continuation.
            for begin in child['starts'].get((b['kind'], b['price']), []):
                first = child['legs'][begin]
                if not _shared_extremum(first['origin'], b, parent_tf):
                    continue
                if first['direction_observation'] == wave['direction']:
                    continue
                for chain in self._connected(child, begin):
                    end = chain[-1][1]['terminal']
                    if not self._path_bounds(child, chain, a, b):
                        # Lower bars challenging an endpoint cannot certify an
                        # upper-period close/acceptance. Don't extend this owner.
                        break
                    self._link_chain(child_tf, child, parent_tf, wave, chain, 'return', last_only=True)

    @staticmethod
    def _path_bounds(child, chain, a, b):
        origin, terminal = chain[0][1]['origin'], chain[-1][1]['terminal']
        start, end = _time(origin['pivot_timestamp_utc']), _time(terminal['pivot_timestamp_utc'])
        low, high = sorted((a['price'], b['price']))
        return child['native'].complete(start, end) and child['native'].envelope.contains(
            child['raw'], chain[0][1]['timeframe'], start, end, low, high)

    def _link_chain(self, child_tf, child, parent_tf, parent, chain, kind, last_only=False):
        known = max([_time(parent['known_at_utc'])] +
                    [_time(point['confirmed_at_utc']) for _, part in chain for point in (part['origin'], part['terminal'])])
        process = _id(kind, parent['node_id'], child_tf, _key(chain[0][1]['origin']))
        # Do not duplicate the whole path on every child. Stable IDs reference
        # actual endpoints/components; the completed version has its own clock.
        for i, part in (chain[-1:] if last_only else chain):
            direction_same = part['direction_observation'] == parent['direction']
            role = ('parent_forward_stage' if direction_same else 'internal_return_stage') if kind == 'decomposition' else (
                'bounce_inside_parent_return' if direction_same else 'parent_return_stage')
            row = dict(relation_id=_id(process, child['base_ids'][i], role, child['base_ids'][chain[-1][0]]),
                       child_node_id=child['base_ids'][i], parent_node_id=parent['node_id'],
                       child_timeframe=child_tf, parent_timeframe=parent_tf,
                       relation_type=kind, role=role, process_id=process,
                       path_origin_node_id=child['base_ids'][chain[0][0]],
                       path_terminal_node_id=child['base_ids'][chain[-1][0]], known_at_utc=_utc(known),
                       parent_close_acceptance_adjudicated=False,
                       author_wave_degree_adjudicated=False, trade_permission=False)
            self.links.append(row)

    def at(self, timeframe, source_leg_id, known_at_utc):
        """Same structure object for rulers, force and SNR endpoint consumers.

        A compound source is attributed only if ALL its named components are
        in the same parent process. Partial coverage remains unowned.
        """
        known = _time(known_at_utc)
        if known > self.cutoff:
            raise ValueError('structure query exceeds frozen native snapshot')
        nodes = [self.nodes[i] for i in self.periods.get(timeframe, {}).get('node_ids', [])
                 if self.nodes[i]['source_leg_id'] == source_leg_id and _time(self.nodes[i]['known_at_utc']) <= known]
        if len(nodes) != 1:
            return dict(status='unresolved_native_source', node_id=None, parent_relations=[])
        node = nodes[0]
        components = set(node['component_leg_ids'])
        base = {self.nodes[i]['source_leg_id']: i for i in self.periods[timeframe]['base_ids'] if i}
        buckets = {}
        for component in components:
            for link in self.by_child.get(base.get(component), []):
                if _time(link['known_at_utc']) <= known:
                    key = (link['parent_node_id'], link['process_id'], link['relation_type'])
                    bucket = buckets.setdefault(key, dict(components=set(), links=[]))
                    bucket['components'].add(component)
                    bucket['links'].append(link)
        relations = []
        for bucket in buckets.values():
            if bucket['components'] != components:
                continue
            links = bucket['links']
            latest = max(links, key=lambda item: (item['known_at_utc'], item['relation_id']))
            relations.append(dict(parent_node_id=latest['parent_node_id'],
                                  process_id=latest['process_id'], relation_type=latest['relation_type'],
                                  parent_timeframe=latest['parent_timeframe'],
                                  role=_aggregate_path_role(links),
                                  known_at_utc=max(link['known_at_utc'] for link in links),
                                  relation_ids=sorted({link['relation_id'] for link in links})))
        relations.sort(key=lambda row: (MINUTES[row['parent_timeframe']], row['known_at_utc'], row['parent_node_id']))
        return dict(status='native_source_bound', node_id=node['node_id'], parent_relations=relations)

    def export(self):
        periods = {tf: {key: value for key, value in row.items() if key in
                   ('status', 'timeframe', 'node_ids', 'rejected_leg_count', 'reason',
                    'native_bar_count', 'native_closed_through_utc')} for tf, row in self.periods.items()}
        return dict(schema=SCHEMA, snapshot_id=self.snapshot['snapshot_id'], as_of_utc=self.snapshot['as_of_utc'],
                    instrument=self.snapshot['instrument'], provider=self.snapshot['provider'],
                    periods=periods, nodes=self.nodes, relations=self.links, condition_source_refs=SOURCE_REFS,
                    timeframe_ladder=list(self.timeframe_ladder), direct_parent_map=self.direct_parent_map,
                    automatic_trade_permission=False, author_accuracy_verified=False,
                    boundary='Observed native hierarchy and named returns; not Elliott wave counts, author degree or institutional inventory.')
