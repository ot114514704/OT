"""Read an upstream-reviewed parent objective; never manufacture one from swings.

This is a record/identity/time contract, not independent semantic verification
of the supplied source references. The producer remains responsible for that
review. A valid context ranks review paths, not entries or completed pullbacks.
"""
from datetime import datetime, timedelta, timezone
import math


FRAMES = ("M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1")
FRAME_MINUTES = {"M1": 1, "M5": 5, "M15": 15, "M30": 30,
                 "H1": 60, "H4": 240, "D1": 1440, "W1": 10080}


def _time(value):
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed.astimezone(timezone.utc) if parsed.tzinfo is not None else None
    except ValueError:
        return None


def _refs(record):
    refs = record.get("source_refs") or record.get("source_evidence_ids")
    return refs if isinstance(refs, list) and refs and all(
        isinstance(ref, str) and ref.strip() for ref in refs) else []


def _known(record, cutoff):
    known = _time(record.get("as_of_utc"))
    return bool(cutoff and known and known <= cutoff and _refs(record))


def _number(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


def _matching_market(record, timeframe, provider, instrument):
    return (record.get('timeframe',timeframe)==timeframe
            and (not provider or record.get('provider',provider)==provider)
            and (not instrument or all(record.get(key,instrument)==instrument
                                      for key in ('instrument','symbol'))))


def counter_task_boundary_review(chart_history, parent_tf, child_tf, boundary,
                                 source_origin, parent_direction, cutoff, *, provider=None, instrument=None):
    """Check a bounded child correction against the parent's native origin.

    This boundary limits the correction interpretation; it does not promote
    a child close into a confirmed parent reversal or name an author SNR.
    """
    result = dict(valid=False, boundary_id=None, breaches=[], trade_permission=False)
    try:
        if (parent_tf not in FRAMES or child_tf not in FRAMES
                or FRAMES.index(parent_tf) <= FRAMES.index(child_tf)
                or parent_direction not in ('up','down') or not isinstance(boundary,dict)):
            return result
        point = boundary['pivot']
        known, opened = _time(point['confirmed_at_utc']), _time(point['pivot_timestamp_utc'])
        start = _time(source_origin['pivot_timestamp_utc'])
        history = (chart_history or {}).get(parent_tf) or {}
        child = (chart_history or {}).get(child_tf) or {}
        kind = 'confirmed_swing_low_candidate' if parent_direction == 'up' else 'confirmed_swing_high_candidate'
        field = 'low' if parent_direction == 'up' else 'high'
        native = [b for b in history.get('bars',[]) if b.get('timestamp_utc') == point['pivot_timestamp_utc']]
        if (not known or not opened or not start or not cutoff or not opened < start
                or not opened+timedelta(minutes=FRAME_MINUTES[parent_tf]) <= known <= cutoff
                or point.get('kind') != kind or boundary.get('timeframe') != parent_tf
                or not boundary.get('boundary_id') or len(native) != 1
                or not _number(point.get('price')) or native[0].get(field) != point['price']
                or not _matching_market(history,parent_tf,provider,instrument)
                or not _matching_market(native[0],parent_tf,provider,instrument)
                or not _matching_market(child,child_tf,provider,instrument)):
            return result
        rows = [b for b in child.get('bars',[]) if start <= _time(b.get('timestamp_utc'))
                and _time(b.get('timestamp_utc'))+timedelta(minutes=FRAME_MINUTES[child_tf]) <= cutoff]
        if not rows or any(not _matching_market(b,child_tf,provider,instrument)
                           or not _number(b.get('close')) for b in rows):
            return result
        sign = 1 if parent_direction == 'up' else -1
        breaches = [dict(timeframe=child_tf,bar_open_utc=b['timestamp_utc'],close=b['close'])
                    for b in rows if sign*(b['close']-point['price']) < 0]
        result.update(valid=not breaches,boundary_id=boundary['boundary_id'],breaches=breaches,
                      price=point['price'],timeframe=parent_tf)
    except (KeyError,TypeError,ValueError,AttributeError):
        pass
    return result


def _finer_contact_after_review(chart_history, parent_tf, parent_open, parent_close,
                                reviewed, cutoff, lo, hi, *, provider=None, instrument=None):
    """Prove a post-review touch inside a spanning parent bar, never its absence.

    Only a fully closed, native lower-period bar starting no earlier than the
    review can establish the order. Incomplete lower-period coverage leaves
    the parent-bar ambiguity intact.
    """
    if not isinstance(chart_history, dict):
        return None
    for finer_tf in FRAMES[:FRAMES.index(parent_tf)]:
        history = chart_history.get(finer_tf)
        if not isinstance(history, dict) or not _matching_market(history,finer_tf,provider,instrument):
            continue
        bars = history.get("bars")
        if not isinstance(bars, list):
            continue
        duration = timedelta(minutes=FRAME_MINUTES[finer_tf])
        eligible = []
        valid = True
        seen = set()
        for bar in bars:
            if not isinstance(bar, dict):
                valid = False
                break
            opened = _time(bar.get("timestamp_utc"))
            if opened is None:
                valid = False
                break
            closed = opened + duration
            if closed > cutoff or closed <= parent_open or opened >= parent_close:
                continue
            low, high, bar_open, bar_close = (bar.get(key) for key in ("low", "high", "open", "close"))
            if (opened in seen or opened < parent_open or closed > parent_close
                    or not _matching_market(bar,finer_tf,provider,instrument)
                    or not all(_number(value) for value in (low, high, bar_open, bar_close))
                    or not low <= min(bar_open, bar_close) <= max(bar_open, bar_close) <= high):
                valid = False
                break
            seen.add(opened)
            if reviewed <= opened and closed <= min(parent_close, cutoff) and low <= hi and high >= lo:
                eligible.append((opened, closed, low, high))
        if valid and eligible:
            opened, closed, low, high = min(eligible, key=lambda item: item[0])
            return {"contact_timeframe": finer_tf,
                    "contact_bar_open_utc": opened.isoformat().replace("+00:00", "Z"),
                    "contact_bar_close_utc": closed.isoformat().replace("+00:00", "Z"),
                    "contact_bar_low": low, "contact_bar_high": high}
    return None


def later_parent_target_contact(chart_history, parent_tf, target, cutoff, *, provider=None, instrument=None):
    """Observe closed native parent bars after or spanning the last review.

    A spanning bar can make contact timing unknowable; it is not a proven
    post-review touch. This is geometry, never target completion evidence.
    A supplied history without a trustworthy matching timeframe is ignored.
    """
    history = chart_history.get(parent_tf) if isinstance(chart_history, dict) else None
    if not isinstance(history, dict) or not _matching_market(history,parent_tf,provider,instrument):
        return None
    bars = history.get("bars")
    if not isinstance(bars, list):
        return None
    reviewed = _time(target.get("as_of_utc"))
    if not reviewed or not cutoff:
        return None
    duration = timedelta(minutes=FRAME_MINUTES[parent_tf])
    lo, hi = target["price_low"], target["price_high"]
    review_boundary_ambiguity = None
    for bar in bars:
        if not isinstance(bar, dict):
            continue
        opened = _time(bar.get("timestamp_utc"))
        low, high, bar_open, bar_close = (bar.get(key) for key in ("low", "high", "open", "close"))
        if (not opened or not _matching_market(bar,parent_tf,provider,instrument)
                or not all(_number(value) for value in (low, high, bar_open, bar_close))
                or not low <= min(bar_open, bar_close) <= max(bar_open, bar_close) <= high):
            continue
        closed = opened + duration
        if closed > cutoff:
            continue
        if low <= hi and high >= lo:
            # A native candle spanning the review can have touched on either
            # side of it. It cannot prove a *later* contact, but neither can
            # its range clear the old target for continued priority.
            if opened < reviewed < closed:
                finer = _finer_contact_after_review(
                    chart_history, parent_tf, opened, closed, reviewed, cutoff, lo, hi,
                    provider=provider, instrument=instrument,
                )
                if finer:
                    return {"parent_bar_open_utc": bar["timestamp_utc"],
                            "parent_bar_close_utc": closed.isoformat().replace("+00:00", "Z"),
                            "bar_low": low, "bar_high": high,
                            "observation": "target_zone_contact_after_last_review", **finer}
                review_boundary_ambiguity = {
                    "parent_bar_open_utc": bar["timestamp_utc"],
                    "parent_bar_close_utc": closed.isoformat().replace("+00:00", "Z"),
                    "bar_low": low, "bar_high": high,
                    "observation": "review_boundary_bar_contact_time_unknown",
                }
                continue
            if opened < reviewed:
                continue
            return {"parent_bar_open_utc": bar["timestamp_utc"],
                    "parent_bar_close_utc": closed.isoformat().replace("+00:00", "Z"),
                    "bar_low": low, "bar_high": high,
                    "observation": "target_zone_contact_after_last_review"}
    # An actually known child candle can touch the price before the enclosing
    # parent candle has closed (or even before that candle is in the history).
    # This proves a price contact only, not a parent close or target completion.
    finer = _finer_contact_after_review(
        chart_history, parent_tf, reviewed, cutoff, reviewed, cutoff, lo, hi,
        provider=provider, instrument=instrument,
    )
    if finer:
        return {'observation':'target_zone_contact_after_last_review',
                'parent_close_evidence':False, **finer}
    return review_boundary_ambiguity


def build_parent_objective_review(parent_task, target_graph, selected_row, *, timeframe, as_of_utc,
                                  chart_history=None, provider=None, instrument=None):
    parent = parent_task if isinstance(parent_task, dict) else {}
    graph = target_graph if isinstance(target_graph, dict) else {}
    cutoff = _time(as_of_utc)
    result = {
        "status": "unbound_parent_objective", "working_timeframe": timeframe,
        "as_of_utc": as_of_utc, "parent_task_id": None, "parent_timeframe": None,
        "parent_direction": None, "target_ids": [], "targets": [],
        "later_target_contacts": [], "review_boundary_ambiguities": [],
        "supports_source_leg_ids": [], "source_refs": [], "binding_issues": [],
        "pullback_completed": False, "trade_permission": False,
        "readout": "上级任务与目标还没有完整的来源、归属和时点绑定；不能靠最近波段方向替它下结论。",
        "boundary": "核对的是上游复核记录的关联与时点，不替代原图/行情语义复核，也不裁定回调结束或进场。",
    }
    issues = result["binding_issues"]
    parent_tf, parent_id = parent.get("timeframe"), parent.get("parent_task_id")
    direction = parent.get("direction_observation")
    if not cutoff:
        issues.append("explicit_snapshot_cutoff_missing")
    if not (isinstance(parent_id, str) and parent_id.strip() and parent.get("state") in {"active", "admitted"}):
        issues.append("active_parent_identity_missing")
    if not (parent_tf in FRAMES and timeframe in FRAMES and FRAMES.index(parent_tf) > FRAMES.index(timeframe)):
        issues.append("higher_parent_timeframe_missing")
    if direction not in ("up", "down"):
        issues.append("parent_delivery_direction_missing")
    if not _known(parent, cutoff):
        issues.append("parent_source_or_time_invalid")
    if not (graph.get("dol_state") == "bound" and graph.get("target_completion_state") == "active" and _known(graph, cutoff)):
        issues.append("active_target_graph_source_or_time_invalid")
    if issues:
        return result

    ledger = selected_row.get("candidate_wave_ledger") or {}
    legs = ledger.get("legs") or []
    legs = legs if isinstance(legs, list) else []
    known_legs = {}
    ambiguous = set()
    for leg in legs:
        if not isinstance(leg, dict):
            continue
        leg_id = leg.get("leg_id")
        if not isinstance(leg_id, str) or not leg_id:
            continue
        if leg_id in known_legs:
            ambiguous.add(leg_id)
        known_legs[leg_id] = leg
    active_targets = graph.get("active_targets") or []
    if not isinstance(active_targets, list):
        issues.append("active_targets_not_list")
        return result
    targets = [target for target in active_targets if isinstance(target, dict)
               and target.get("parent_task_id") == parent_id]
    if not targets:
        issues.append("no_target_owned_by_selected_parent")
        return result
    seen_ids = set()
    accepted = []
    for target in targets:
        target_id = target.get("target_id")
        leg_id = target.get("supports_source_leg_id")
        leg = known_legs.get(leg_id) if isinstance(leg_id, str) else None
        endpoints = [leg.get(endpoint) for endpoint in ("origin", "terminal")] if leg else []
        times = [_time(endpoint.get("confirmed_at_utc")) if isinstance(endpoint, dict) else None
                 for endpoint in endpoints]
        target_known = _time(target.get("as_of_utc"))
        role = target.get('supports_source_task_role', 'trend_delivery')
        child_direction = target.get('supports_source_direction', direction)
        role_bound = role == 'trend_delivery' and child_direction == direction
        if role == 'bounded_pullback' and child_direction in ('up','down') and child_direction != direction and leg:
            boundary = counter_task_boundary_review(chart_history,parent_tf,timeframe,
                target.get('counter_task_boundary'),leg['origin'],direction,cutoff,
                provider=provider,instrument=instrument)
            role_bound = boundary['valid']
            if not role_bound:
                issues.append('counter_task_boundary_unavailable_or_breached')
        valid_leg = bool(leg and leg_id not in ambiguous and leg.get("timeframe") == timeframe
                         and role_bound and leg.get("direction_observation") == child_direction
                         and target_known is not None
                         and all(time is not None and time <= target_known <= cutoff for time in times)
                         and times[0] <= times[1])
        lo, hi = target.get("price_low"), target.get("price_high")
        if not (isinstance(target_id, str) and target_id.strip() and target_id not in seen_ids
                and target.get("state") == "active" and target.get("timeframe") == parent_tf
                and target.get("direction_observation") == direction and _known(target, cutoff)
                and valid_leg and _number(lo) and _number(hi) and lo <= hi):
            issues.append("target_identity_source_direction_or_child_leg_invalid")
            continue
        seen_ids.add(target_id)
        accepted.append({"target_id": target_id, "timeframe": parent_tf,
                         "price_low": lo, "price_high": hi, "supports_source_leg_id": leg_id,
                         "supports_source_task_role": role, "supports_source_direction": child_direction,
                         "counter_task_boundary": target.get('counter_task_boundary'),
                         "as_of_utc": target["as_of_utc"], "source_refs": list(_refs(target))})
    # Do not discard a contradictory same-task record to manufacture coherence.
    if issues or not accepted:
        return result
    refs = list(dict.fromkeys(_refs(parent) + _refs(graph) + [ref for target in accepted for ref in target["source_refs"]]))
    contacts = []
    boundary_ambiguities = []
    for target in accepted:
        touch = later_parent_target_contact(chart_history, parent_tf, target, cutoff,
                                            provider=provider, instrument=instrument)
        if touch:
            item = {"target_id": target["target_id"], **touch}
            if touch["observation"] == "target_zone_contact_after_last_review":
                contacts.append(item)
            else:
                boundary_ambiguities.append(item)
    if contacts:
        result.update(status="target_contact_requires_lifecycle_review",
                      parent_task_id=parent_id, parent_timeframe=parent_tf,
                      parent_direction=direction, targets=accepted,
                      target_ids=[target["target_id"] for target in accepted],
                      supports_source_leg_ids=list(dict.fromkeys(target["supports_source_leg_id"] for target in accepted)),
                      source_refs=refs, later_target_contacts=contacts,
                      readout=f"{parent_tf} 目标区在上次复核后被已收盘同周期 K 线触及；这不等于目标完成，但旧的‘仍待交付’排序须暂停，先复核目标生命周期。")
        return result
    if boundary_ambiguities:
        result.update(status="review_boundary_target_contact_time_unknown",
                      parent_task_id=parent_id, parent_timeframe=parent_tf,
                      parent_direction=direction, targets=accepted,
                      target_ids=[target["target_id"] for target in accepted],
                      supports_source_leg_ids=list(dict.fromkeys(target["supports_source_leg_id"] for target in accepted)),
                      source_refs=refs, review_boundary_ambiguities=boundary_ambiguities,
                      readout=f"{parent_tf} 有一根跨越上次目标复核时刻的已收盘 K 线碰到目标区；无法从整根高低点判定触碰在复核前还是后，旧目标方向暂不排序，先核更细的同源时间路径。")
        return result
    target_read = "、".join(f"{target['price_low']:.2f}—{target['price_high']:.2f}" for target in accepted)
    side = "向上" if direction == "up" else "向下"
    result.update(status="validated_parent_objective_context", parent_task_id=parent_id,
                  parent_timeframe=parent_tf, parent_direction=direction, targets=accepted,
                  target_ids=[target["target_id"] for target in accepted],
                  supports_source_leg_ids=list(dict.fromkeys(target["supports_source_leg_id"] for target in accepted)),
                  source_refs=refs,
                  readout=f"按已有复核记录，{parent_tf} 的{side}任务仍以 {target_read} 为目标，尚未登记完成。")
    return result
