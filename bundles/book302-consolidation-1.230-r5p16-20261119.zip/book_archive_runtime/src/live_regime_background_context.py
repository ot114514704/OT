"""Source/return-time native background facts, never a global direction gate.

Alexander 7676648362667484181, 7676648426376537882 and
7676649229776707833 distinguish the M5 reversal/1:1 from H4 ranging.
Node process, wave degree and parent task are separate questions. A child
price crossing a parent price is NOT a closed parent-candle confirmation.
"""
from .live_native_structure_sequence import ORDER, source_time_background_reader
from .live_nested_stage_review import _time
from copy import deepcopy


class RegimeBackgroundIndex:
    def __init__(self,snapshot,timeframe,*,include_node_inventory=False,_reader=None):
        self.timeframe=timeframe
        self.snapshot=snapshot
        self.include_node_inventory=include_node_inventory
        self.reader=(_reader if _reader is not None else
            source_time_background_reader(snapshot,include_node_inventory=include_node_inventory))

    def at(self,family,known_at_utc,point,phase):
        evidence=self.reader(self.timeframe,known_at_utc)
        frames=evidence.get('frames',[])
        expected=list(ORDER[:ORDER.index(self.timeframe)+1])
        actual={f['timeframe'] for f in frames}
        relations=[]
        for frame in frames:
            if frame['timeframe']==self.timeframe:
                continue
            event=frame.get('selected')
            row=dict(timeframe=frame['timeframe'],closed_through_utc=frame['latest_closed_end_utc'],
                update_pending=_time(frame['latest_closed_end_utc'])<_time(known_at_utc),
                observed_child_point=point,child_point_role=phase,
                direct_parent_of_wave_adjudicated=False,trade_permission=False)
            if not event:
                row.update(relation='no_selected_native_node_process',node_direction=None,
                    process_state=None,task_role_adjudicated=False)
            else:
                active=event['state'] in {'close_through_with_follow','return_held_node'}
                sign=1 if event['direction']=='up' else -1
                opposite=event['direction']!=family['direction_observation']
                adverse=sign*(point['price']-event['origin_boundary']['price'])<0
                relation=('parent_process_failed_or_unconfirmed' if not active else
                    'aligned_with_higher_node_process' if not opposite else
                    'opposite_child_excursion_challenges_higher_origin' if adverse else
                    'opposite_child_excursion_inside_higher_origin')
                row.update(relation=relation,node_direction=event['direction'],process_state=event['state'],
                    node_id=event['node_id'],attempt_id=event['attempt_id'],
                    origin_boundary=event['origin_boundary'],node=event['node'],
                    child_point_beyond_higher_origin_adverse_side=adverse,
                    child_point_is_parent_close_confirmation=False,
                    higher_candidate_extrema=event.get('target_candidates',[]),
                    task_role_adjudicated=False)
            relations.append(row)
        result=dict(method='native_source_anchor_context_v1',phase=phase,
            working_timeframe=self.timeframe,known_at_utc=known_at_utc,
            frames=frames,higher_relations=relations,
            missing_or_invalid_periods=[tf for tf in expected if tf not in actual],
            direction_is_global=False,structural_degree_adjudicated=False,
            parent_task_adjudicated=False,parent_target_adjudicated=False,
            changes_measurement_admission=False,trade_permission=False,
            theory_source_message_ids=['7676648362667484181','7676648426376537882','7676649229776707833'],
            interpretation='各级仅使用该时刻已收K和已确认节点；反向本级波段可以有自己的量尺，不能因此确认或否定更大任务。')
        if self.include_node_inventory:
            # No direction vote or automatic parent assignment. These compact
            # relations refer to the node inventory, without copying witnesses.
            lo,hi=sorted((family['source_origin']['price'],family['source_terminal']['price']))
            def position(price):
                return ('below_source' if price<lo else 'above_source' if price>hi else
                        'at_source_boundary' if price in (lo,hi) else 'inside_source')
            result['node_scope_context']=dict(
                snapshot_id=self.snapshot.get('snapshot_id'),snapshot_as_of_utc=self.snapshot['as_of_utc'],
                source_leg_id=family['source_leg_id'],source_origin=deepcopy(family['source_origin']),
                source_terminal=deepcopy(family['source_terminal']),source_direction=family['direction_observation'],
                selected_is_complete_background=False,parent_owner_adjudicated=False,
                references=[dict(timeframe=frame['timeframe'],node_id=e['node_id'],attempt_id=e['attempt_id'],
                    node_position_relative_to_source=position(e['node']['price']),
                    origin_position_relative_to_source=position(e['origin_boundary']['price']),
                    source_direction_relation='aligned' if e['direction']==family['direction_observation'] else 'opposed',
                    observed_child_point_beyond_origin_adverse_side=(point['price']<e['origin_boundary']['price']
                        if e['direction']=='up' else point['price']>e['origin_boundary']['price']),
                    child_point_is_parent_close_confirmation=False,parent_owner_adjudicated=False)
                    for frame in frames for e in frame['node_process_inventory']['processes']],
                trade_permission=False)
        return result

    def track_source_nodes(self,source_context,anchor_context):
        """Keep each B-selected node's actual state at C, by exact identity.

        The all-node inventory is useful in diagnosis, but repeating it for
        every historical family would multiply thousands of unrelated rows.
        Query only the named B nodes here; this does not replace the optional
        full inventory or assert that these nodes are the semantic parents.
        """
        before,after=source_context['known_at_utc'],anchor_context['known_at_utc']
        result=dict(method='source_selected_node_continuity_v1',status='unavailable',
            before_known_at_utc=before,after_known_at_utc=after,frames=[],
            parent_direction_adjudicated=False,parent_task_adjudicated=False,trade_permission=False)
        if (source_context['working_timeframe']!=self.timeframe or
                anchor_context['working_timeframe']!=self.timeframe or _time(before)>_time(after)):
            return {**result,'reason':'foreign_working_period_or_reverse_time'}
        requested={f['timeframe']:[f['selected']['node_id']] for f in source_context['frames'] if f.get('selected')}
        evidence=self.reader(self.timeframe,after,include_node_inventory=True,node_ids_by_timeframe=requested)
        observed={f['timeframe']:f for f in evidence['frames']}
        newframes={f['timeframe']:f for f in anchor_context['frames']}
        for frame in source_context['frames']:
            tf,old=frame['timeframe'],frame.get('selected')
            if not old:continue
            inventory=observed.get(tf,{}).get('node_process_inventory')
            current=next((e for e in inventory['processes'] if e['node_id']==old['node_id']),None) if inventory and tf in newframes else None
            newest=newframes.get(tf,{}).get('selected')
            same=bool(current and current['attempt_id']==old['attempt_id'])
            result['frames'].append(dict(timeframe=tf,source_node_id=old['node_id'],
                source_node_price=old['node']['price'],source_origin_boundary_price=old['origin_boundary']['price'],
                source_attempt_id=old['attempt_id'],source_state=old['state'],
                at_anchor_attempt_id=current['attempt_id'] if current else None,
                at_anchor_state=current['state'] if current else None,
                state_observation='unavailable' if current is None else 'same_attempt' if same else 'new_attempt_same_node',
                at_anchor_previous_attempt=current.get('previous_attempt') if current else None,
                at_anchor_follow_through_utc=current.get('follow_through_utc') if current else None,
                at_anchor_reclaim_utc=current.get('reclaim_utc') if current else None,
                at_anchor_origin_broken_utc=current.get('origin_broken_utc') if current else None,
                at_anchor_witnesses=current.get('witnesses',[]) if current else [],
                at_anchor_latest_node_id=newest['node_id'] if newest else None,
                another_node_is_latest=bool(newest and newest['node_id']!=old['node_id']),
                old_attempt_resurrected=False,selection_change_is_parent_reversal=False,
                parent_owner_adjudicated=False))
        result['status']='source_nodes_rechecked_at_anchor'
        return result


def compare_node_contexts(before,after):
    """Separate a change of selected node from that node's own lifecycle.

    Missing inventories are unknown, not zero events or a failed old task.
    Exact source/snapshot identities must match; no cross-snapshot stitching.
    """
    result=dict(method='native_node_context_comparison_v1',status='unavailable',
        before_known_at_utc=before['known_at_utc'],after_known_at_utc=after['known_at_utc'],
        frames=[],parent_direction_adjudicated=False,parent_task_adjudicated=False,trade_permission=False)
    left,right=before.get('node_scope_context'),after.get('node_scope_context')
    identity=('snapshot_id','snapshot_as_of_utc','source_leg_id','source_origin','source_terminal','source_direction')
    if (not left or not right or not left.get('snapshot_id') or
            any(left[k]!=right[k] for k in identity) or
            before['working_timeframe']!=after['working_timeframe'] or
            _time(before['known_at_utc'])>_time(after['known_at_utc'])):
        return {**result,'reason':'missing_conflicting_identity_or_reverse_time'}
    bframes={f['timeframe']:f for f in before['frames']}
    aframes={f['timeframe']:f for f in after['frames']}
    for tf in ORDER[:ORDER.index(before['working_timeframe'])+1]:
        bf,af=bframes.get(tf),aframes.get(tf)
        row=dict(timeframe=tf,status='context_unavailable',changes=[],selected_transition=None)
        if not bf or not af or 'node_process_inventory' not in bf or 'node_process_inventory' not in af:
            result['frames'].append(row);continue
        previous={e['node_id']:e for e in bf['node_process_inventory']['processes']}
        current={e['node_id']:e for e in af['node_process_inventory']['processes']}
        row['status']='same_native_node_inventory_compared'
        for node_id in sorted(previous.keys() | current.keys()):
            old,new=previous.get(node_id),current.get(node_id)
            kind=('newly_observed_node_process' if old is None else
                  'node_unavailable_at_later_context' if new is None else
                  'same_node_new_attempt' if old['attempt_id']!=new['attempt_id'] else
                  'same_attempt_state_changed' if old['state']!=new['state'] else
                  'same_attempt_same_state')
            row['changes'].append(dict(node_id=node_id,kind=kind,
                before_attempt_id=old['attempt_id'] if old else None,
                after_attempt_id=new['attempt_id'] if new else None,
                before_state=old['state'] if old else None,after_state=new['state'] if new else None,
                old_attempt_is_resurrected=False,parent_task_adjudicated=False))
        old,new=bf.get('selected'),af.get('selected')
        if old and new:
            old_now=current.get(old['node_id'])
            row['selected_transition']=dict(
                kind='same_attempt' if old['attempt_id']==new['attempt_id'] else
                     'same_node_new_attempt' if old['node_id']==new['node_id'] else 'different_node_selected',
                before_node_id=old['node_id'],after_node_id=new['node_id'],
                before_attempt_id=old['attempt_id'],after_attempt_id=new['attempt_id'],
                previously_selected_node_now_attempt_id=old_now['attempt_id'] if old_now else None,
                previously_selected_node_now_state=old_now['state'] if old_now else None,
                selection_change_is_parent_reversal=False)
        result['frames'].append(row)
    result['status']='compared_without_parent_trend_promotion'
    return result
