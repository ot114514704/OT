"""Current native Book review inputs; engineering evidence grants no author degree."""
from copy import deepcopy


def author_review_context(book, timeframe, cutoff, bars=None):
    line = book.get('turning_point_line') or {}
    setup = book.get('setup_qualification') or {}
    response = book.get('first_response_leg') or {}
    review = line.get('author_same_degree_review') or {}
    input_packet = line.get('author_review_input') or {}
    from .book_r01_native_review import native_ruler_review,validate_attached_review,bind_author_review_input
    current_review=native_ruler_review(bars,line,timeframe,cutoff)
    if input_packet and not review:
        review=bind_author_review_input(current_review,input_packet)
    review_bound,review_reason=(validate_attached_review(review,current_review,timeframe,cutoff)
        if review else (False,'attached_author_review_not_supplied'))
    if book.get('timeframe',timeframe)!=timeframe:review_bound,review_reason=False,'Book_timeframe_mismatch'
    # Rebuild from this owner's current facts, never from the builder's cached
    # author_review_context (which may precede runtime witnesses/rotation).
    native_scope=dict(state='not_recomputed',required=None)
    if bars is not None and line.get('qualified') and (book.get('first_closed_break') or {}).get('status')=='observed_candidate':
        from .book_first_response_leg import first_response_leg
        native_response=first_response_leg(bars,line,book['first_closed_break'],timeframe,cutoff)
        scope=native_response.get('chapter7_B_scope_review') or {}
        native_scope=dict(state='native_scope_recomputed' if scope else 'native_scope_unavailable',
            source_id=native_response.get('source_id'),
            matches_response_source=native_response.get('source_id')==response.get('source_id'),
            response_status=native_response.get('status'),invalidated_at_utc=native_response.get('invalidated_at_utc'),
            required=scope.get('required'),scope=deepcopy(scope))
    return dict(schema='book_author_review_context_v1', timeframe=timeframe,
        as_of_utc=cutoff, source_wave_id=line.get('wave_id'),
        response_source_id=response.get('source_id'),
        response_status=response.get('status'),response_invalidated_at_utc=response.get('invalidated_at_utc'),
        source_pdf_pages=[21,27,28,103,104,199,200,201,202],
        r01_same_degree=dict(state=(review.get('state','unknown') if review_bound else
            'review_not_bound_to_current_ruler' if review else current_review['state'] if
            current_review['native_source_proof']['qualified'] else 'not_available_on_book_ruler'),
            review=deepcopy(review),author_wave_degree='unknown',
            native_ruler_review=current_review,review_binding_reason=review_reason,
            review_bound_to_current_ruler=review_bound,
            author_same_degree_adjudicated=False),
        r14_prior_B_A=deepcopy(response.get('prior_B_A_backtrack') or dict(
            status='unknown',reason='response_backtrack_not_available',
            author_wave1_state='unverified',author_degree_verified=False)),
        r14_B_scope_review=deepcopy(response.get('chapter7_B_scope_review') or {}),
        r14_native_scope_validation=native_scope,
        boundary_A_freeze=deepcopy(setup.get('boundary_A_freeze') or dict(
            status='not_available_until_dual_break',author_boundary_verified=False)),
        author_wave_degree='unknown',author_membership_verified=False,
        entry_permission=False,automatic_trade_permission=False,
        selection_policy='engineering_candidates_are_review_inputs_only; no author auto-selection')


def author_review_gate(context):
    """Read the production chapter7 wrapper, not just its outer status.

    The PDF201 exception deliberately returns status=unknown around an
    author_backtrack_review. Neither a high score nor a cached claim of
    author verification resolves that native-source selection ambiguity.
    """
    r01=context.get('r01_same_degree') or {}
    binding=context.get('r14_prior_B_A') or {}
    review=binding.get('author_backtrack_review') or {}
    scope=context.get('r14_B_scope_review') or binding.get('B_scope_review') or {}
    states={'review_required','review_required_with_native_candidates',
            'review_required_no_confirmed_predecessor_rebound','review_evidence_unbound'}
    native=context.get('r14_native_scope_validation') or {}
    # The current native source's lifecycle has priority over a pending
    # author review. An invalidated source must never be advertised as
    # merely waiting for a target or become active through adjudication.
    from .book_first_response_leg import clock
    invalidated_at=(native.get('invalidated_at_utc') if native.get('matches_response_source') else None) or context.get('response_invalidated_at_utc')
    lifecycle=(native.get('response_status') if native.get('matches_response_source') else None) or context.get('response_status') or 'unknown'
    try:invalidated=bool(lifecycle=='source_invalidated' and invalidated_at and clock(invalidated_at)<=clock(context['as_of_utc']))
    except (KeyError,TypeError,ValueError):invalidated=False
    required=(native.get('required') is True or scope.get('required') is True or bool(review) or
              binding.get('status') in states or
              binding.get('source_selection_ambiguity')=='pdf201_author_same_degree_backtrack_required' or
              binding.get('reason')=='earlier_phase_extreme_requires_backtrack_review')
    return dict(schema='book_author_review_gate_v1',
        source_wave_id=context.get('source_wave_id'),
        response_source_id=context.get('response_source_id'),
        timeframe=context.get('timeframe'),as_of_utc=context.get('as_of_utc'),
        r01_state=r01.get('state'),r01_adjudicated=False,
        r14_binding_state=binding.get('status'),
        r14_state=review.get('status') or binding.get('status'),
        r14_reason=review.get('reason') or binding.get('reason'),
        r14_source_state='invalidated' if invalidated else 'invalidation_not_bound_to_cutoff' if lifecycle=='source_invalidated' else lifecycle,
        r14_invalidated_at_utc=invalidated_at if invalidated else None,
        r14_target_state='source_invalidated' if invalidated else 'waiting_author_backtrack' if required else 'author_degree_unverified',
        r14_predecessor_candidates=review.get('candidate_count',0),
        r14_event_linked_candidates=review.get('event_linked_candidate_count',0),
        r14_native_scope_state=native.get('state'),
        r14_native_scope_required=native.get('required'),
        r14_review_required=required,author_wave_degree_verified=False,
        r14_dependency_scope='chapter7_first_wave_target_selection',
        r14_target_permission=False,
        entry_permission=False,automatic_trade_permission=False,
        policy='PDF202_backtrack_for_chapter7_target; independent_chapter6_source_C_requires_its_own_explicit_engineering_paper_policy')
