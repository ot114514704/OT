"""PDF202 B->A amplitude projected from the later turning-response origin.

A measurement fact for the plan consumer, separate from BC retracement and
risk-bounded trade targets. It never establishes author membership itself.
"""
from math import isfinite
from datetime import datetime


def correction_terminal_binding(binding,known):
    """Refuse stale/deepest-price origins that contradict the actual wave2 end.

    Native pivot counts remain engineering candidates. This only checks that
    the projected origin is the named last corrective terminal, not author
    membership or proof that a live entry was observable then.
    """
    clock=lambda s:datetime.fromisoformat(s.replace('Z','+00:00'))
    correction=binding.get('second_wave_observation') or {}
    terminal=correction.get('terminal_candidate') or {}
    origin=binding.get('later_response_origin') or {}
    try:
        if (correction.get('status')!='observed_candidate' or
                correction.get('form') not in ('simple_return_candidate','abc_candidate',
                    'contracting_triangle_candidate','fast_single_return_candidate') or
                correction.get('terminal_status') not in ('candidate_frozen_at_A_cross','developing_terminal_candidate')):
            return None
        if any(origin[k]!=terminal[k] for k in ('index','utc','price','known_at_utc')):return None
        bi,ai,ti=binding['source_B']['index'],binding['source_A']['index'],terminal['index']
        if any(isinstance(i,bool) or not isinstance(i,int) for i in (bi,ai,ti)) or not bi<ai<ti:return None
        if correction['source_B_index']!=bi or correction['source_A_index']!=ai:return None
        if not (clock(binding['source_A']['utc'])<clock(terminal['utc'])<clock(terminal['known_at_utc'])<=clock(known)):
            return None
        if any(clock(t)>clock(known) for t in (correction['known_at_utc'],binding['source_A']['known_at_utc'])):return None
        return dict(schema='chapter7_correction_terminal_binding_v1',
            status='same_named_terminal',terminal=dict(terminal),
            adverse_extreme=correction.get('adverse_extreme'),
            form=correction['form'],known_at_utc=known,
            terminal_is_interval_deepest=(terminal['index']==(correction.get('adverse_extreme') or {}).get('index')),
            author_correction_end_adjudicated=False,automatic_trade_permission=False)
    except (KeyError,TypeError,ValueError):return None


def first_wave_target_fact(response,timeframe,cutoff):
    base=dict(status='unknown',timeframe=timeframe,source_pdf_pages=[201,202,203,207,208],
              trade_permission=False,executable_target=False)
    b=response.get('prior_B_A_backtrack') or {}
    from .book_author_review import author_review_gate
    gate=author_review_gate(dict(timeframe=timeframe,as_of_utc=cutoff,
        response_source_id=response.get('source_id'),source_wave_id=response.get('source_wave_id'),
        response_status=response.get('status'),response_invalidated_at_utc=response.get('invalidated_at_utc'),
        r14_prior_B_A=b,r14_B_scope_review=response.get('chapter7_B_scope_review') or {}))
    base['author_review_gate']=gate
    if gate['r14_target_state']=='source_invalidated':
        return dict(base,reason='source_invalidated',known_at_utc=gate['r14_invalidated_at_utc'])
    if gate['r14_review_required']:
        return dict(base,reason=b.get('reason') or 'R14_prior_B_A_author_review_required',
            next_required='author_same_wave_backtrack_for_chapter7_target')
    if b.get('status') not in ('candidate_bound_to_prior_B_A','candidate_source_without_projection_origin'):
        return dict(base,reason=b.get('reason','prior_B_A_not_bound'))
    if (b.get('source_A') or {}).get('role')!='chapter7_first_rebound_terminal':
        return dict(base,reason='chapter5_boundary_cannot_substitute_chapter7_wave_terminal')
    try:
        clock=lambda s:datetime.fromisoformat(s.replace('Z','+00:00'))
        if b['timeframe']!=timeframe or response['timeframe']!=timeframe:
            return dict(base,reason='cross_period_source')
        if b['owner_id']!=response['owner_id'] or b.get('source_wave_id')!=response.get('source_wave_id'):
            return dict(base,reason='source_owner_mismatch')
        known=b['known_at_utc']
        if clock(known)>clock(cutoff):return dict(base,reason='source_not_yet_known')
        if response.get('status')=='source_invalidated':return dict(base,reason='source_invalidated')
        if b['status']=='candidate_source_without_projection_origin':
            return dict(base,reason='correction_terminal_unresolved',known_at_utc=known,
                source_id=b['source_id'],owner_id=b['owner_id'],source_B=b['source_B'],source_A=b['source_A'],
                second_wave_observation=b['second_wave_observation'],
                next_required='source_bound_second_wave_terminal_not_interval_extreme')
        terminal_binding=correction_terminal_binding(b,known)
        if terminal_binding is None:
            return dict(base,reason='correction_terminal_binding_mismatch',known_at_utc=known,
                source_id=b.get('source_id'),owner_id=b.get('owner_id'),
                next_required='same_source_last_corrective_terminal_not_stale_or_deepest_origin')
        low,high,origin=(b[k]['price'] for k in ('source_B','source_A','later_response_origin'))
        values=(low,high,origin)
        if any(isinstance(v,bool) or not isfinite(float(v)) or float(v)<=0 for v in values):
            return dict(base,reason='invalid_source_prices')
        sign=1 if response['direction']=='up' else -1 if response['direction']=='down' else 0
        height=sign*(high-low)
        if not sign or height<=0:return dict(base,reason='source_direction_mismatch')
        from .book_target_path import BOOK_THIRD_WAVE_RATIOS
        observed={o['ratio']:o for o in b.get('third_wave_target_options',[])}
        options=[]
        for ratio in BOOK_THIRD_WAVE_RATIOS:
            price=origin+sign*height*ratio
            path=(observed.get(ratio) or {}).get('target_path_observation')
            if path is None and ratio==1.618:path=b.get('target_path_observation')
            path=path or dict(status='unknown',reason='target_path_not_observed')
            if path.get('target_price') is not None and path['target_price']!=price:
                path=dict(status='unknown',reason='target_path_price_mismatch')
            options.append(dict(ratio=ratio,target_price=price,target_path_observation=path,
                source_id=b['source_id'],owner_id=b['owner_id'],known_at_utc=known,
                selected_for_execution=False,source_pdf_pages=[207,208]))
        # Recompute from immutable source prices; do not trust a prefilled target.
        return dict(base,status='theoretical_candidate',source_id=b['source_id'],
            owner_id=b['owner_id'],source_wave_id=b.get('source_wave_id'),
            source_basis='prior_B_to_A_projected_from_later_response_origin',
            source_branch=b.get('source_branch','unknown'),
            source_selection_policy=b.get('source_selection_policy','unknown'),
            source_selection_ambiguity=b.get('source_selection_ambiguity','unknown'),
            source_membership_evidence=b.get('source_membership_evidence',{}),
            unresolved_prebreak_candidates=b.get('unresolved_prebreak_candidates',[]),
            projection_origin_status=b.get('projection_origin_status','unknown'),
            correction_terminal_binding=terminal_binding,
            source_B=low,source_A=high,projection_origin=origin,amplitude=height,
            direction=response['direction'],target_1618=origin+sign*height*1.618,
            target_options=options,selected_target_ratio=None,
            known_at_utc=known,author_wave1_state=b.get('author_wave1_state','unverified'),
            ruler_timing=b.get('ruler_timing','unknown'),
            A_cross_observation=b.get('A_cross_observation',{'status':'unknown'}),
            second_wave_observation=b.get('second_wave_observation',{'status':'unknown'}),
            target_path_observation=b.get('target_path_observation',{'status':'unknown'}),
            formula='later_origin + direction * abs(A-B) * 1.618',
            next_required='author_wave_degree_and_source_adjudication')
    except (KeyError,TypeError,ValueError):
        return dict(base,reason='incomplete_source_binding')
