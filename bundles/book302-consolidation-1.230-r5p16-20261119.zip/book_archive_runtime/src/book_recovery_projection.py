"""Chapter 4 figure 4-6: D--F outer extension shifted to C.

This is a theoretical continuation target, not the C--E to D pullback
boundary and not a same-slope channel. F's two closed neighbours are an
explicit engineering confirmation convention, not a numeric book rule.
"""
from .book_first_response_leg import close_time, clock


def recovery_projection(bars, turning, timeframe, cutoff, *, source_line=None):
    base = dict(qualified=False, status='unknown', timeframe=timeframe,
        rule_id='book_ch4_DF_shift_C_v1', source_rule_pages=[81,83,84,87,88],
        theoretical_projection=True, trade_permission=False,
        semantic_state='chapter4_recovery',
        author_state='unknown_until_DF_and_target_event',
        parent_wave_id=turning.get('parent_wave_id'),
        wave_membership_state=turning.get('wave_membership_state', 'unknown'),
        engineering_conventions=['F_two_closed_neighbours', 'first_confirmed_post_E_extreme',
                                 'freeze_projection_at_first_DF_contact'],
        author_wave_membership_verified=False)
    fail = lambda reason: dict(base, reason=reason)
    if not turning.get('qualified'): return fail('C_D_E_unknown')
    if not turning.get('parent_wave_id'):
        return fail('parent_wave_identity_unknown')
    if any(turning.get(k) is None for k in ('extension_start_index','shift_anchor_index','extension_end_index')):
        return fail('C_D_E_identity_incomplete')
    rows = [b for b in bars if clock(close_time(b,timeframe)) <= clock(cutoff)]
    from .book_breakout_assessment import native_turning_source_proof,native_turning_geometry_proof
    proof=(native_turning_source_proof(rows,source_line,turning) if source_line is not None else
           native_turning_geometry_proof(rows,turning))
    base['native_CDE_validation']=proof
    if not proof['qualified']:return fail('source_CDE_not_reproduced')
    try:
        if not (clock(close_time(rows[turning['first_observable_index']],timeframe))<=clock(turning['known_at_utc'])<=clock(cutoff)):
            return fail('CDE_dependency_clock_unbound')
    except (KeyError,TypeError,ValueError,IndexError):return fail('CDE_dependency_clock_unbound')
    c,d,e = (int(turning[k]) for k in
        ('extension_start_index','shift_anchor_index','extension_end_index'))
    terminal = max(e,int(turning.get('established_wave_end_index',e)))
    if not 0 <= c < d < e <= terminal < len(rows): return fail('C_D_E_order_unknown')
    up = turning.get('direction') == 'up'
    side,opposite = ('low','high') if up else ('high','low')
    sign = 1 if up else -1
    dp,cp = float(rows[d][side]),float(rows[c][opposite])
    # Freeze the first confirmed adjustment after this E. Do not skip a failed
    # F and borrow an unrelated later wave to make the construction fit.
    f = None
    for k in range(terminal+1,len(rows)):
        value = float(rows[k][side])
        if sign*(value-dp) <= 0: return fail('D_breached_before_F_confirmation')
        if k < terminal+3: continue
        p = k-2
        pv = float(rows[p][side])
        neighbours = [float(rows[q][side]) for q in range(p-2,p+3) if q != p]
        if all(sign*(v-pv)>0 for v in neighbours):
            f=p;break
    if f is None: return fail('F_not_confirmed')
    fp=float(rows[f][side]);slope=(fp-dp)/(f-d)
    if sign*slope<=0: return fail('DF_direction_mismatch')
    known_index=f+2
    if any(sign*(float(rows[k][side])-(dp+slope*(k-d)))<=1e-9
           for k in range(d+1,known_index+1) if k!=f):
        return fail('DF_not_outer_extension')
    # C is specified by the original C/D/E structure, not a convenient new
    # maximum-distance point. If shifting to C cuts E, no target is drawn.
    if any(sign*((cp+slope*(k-c))-float(rows[k][opposite]))<=1e-9
           for k in range(c+1,known_index+1)):
        return fail('C_shift_crosses_established_prices')
    known=max((close_time(rows[known_index],timeframe),turning['known_at_utc']),key=clock)
    if clock(known)>clock(cutoff): return fail('construction_not_yet_known')
    # Stop before the first wick contact; a target contact is NOT a reversal
    # confirmation or an entry instruction. Never relocate D/F/C afterwards.
    contact=None;invalid=None;source_contact=None
    for k in range(known_index+1,len(rows)):
        level=cp+slope*(k-c)
        # Observe every boundary on the terminal candle before stopping.
        # OHLC cannot make D failure precede a simultaneous target touch.
        invalid=k if sign*(float(rows[k][side])-dp)<=0 else None
        source_contact=k if sign*(float(rows[k][side])-(dp+slope*(k-d)))<=0 else None
        contact=k if sign*(level-float(rows[k][opposite]))<=0 else None
        if any(e is not None for e in (invalid,source_contact,contact)):break
    terminal_event=invalid if invalid is not None else source_contact if source_contact is not None else contact
    end=terminal_event-1 if terminal_event is not None else len(rows)-1
    status = ('source_D_invalidated_and_target_contact_same_bar' if invalid is not None and contact is not None else
        'source_D_invalidated' if invalid is not None else
        'both_boundaries_contact_same_bar' if source_contact is not None and contact is not None else
        'source_DF_contact_observed' if source_contact is not None else
        'target_contact_observed' if contact is not None else 'theoretical_target_pending')
    author_state = ('source_invalidated_target_contact_order_unknown' if invalid is not None and contact is not None else
        'source_invalidated' if invalid is not None else
        'source_and_target_contact_same_bar' if source_contact is not None and contact is not None else
        'source_contact_observed' if source_contact is not None else
        'target_contact_observed' if contact is not None else 'theoretical_target_pending')
    # Construction is frozen once F is confirmed. Display extent and later
    # contact/invalidity carry their own knowledge; publishing the old
    # construction clock as the whole fact would backdate a later event.
    display_known=close_time(rows[end],timeframe)
    state_known=close_time(rows[terminal_event],timeframe) if terminal_event is not None else known
    fact_known=max((known,display_known,state_known),key=clock)
    events=[]
    for name,index in (('source_D_invalidated',invalid),('source_DF_contact',source_contact),('target_contact',contact)):
        if index is not None:events.append(dict(event=name,utc=rows[index]['timestamp_utc'],
            event_closed_at_utc=close_time(rows[index],timeframe),
            known_at_utc=max((known,close_time(rows[index],timeframe)),key=clock)))
    return dict(base,qualified=True,status=status,author_state=author_state,
        family='RESUME_DF_C',construction_known_at_utc=known,
        display_known_at_utc=max((known,display_known),key=clock),
        state_known_at_utc=max((known,state_known),key=clock),
        terminal_events=events,event_order='unknown_same_native_bar' if len(events)>1 else 'single_event' if events else 'no_terminal_event',
        target_fill_confirmed=False,
        direction='up' if up else 'down', start_index=c,start_price=cp,slope=slope,
        extension_start_index=d,extension_end_index=f,extension_start_price=dp,extension_end_price=fp,
        shift_anchor_index=c,source_E_index=e,first_observable_index=known_index,
        known_at_utc=fact_known,display_end_index=end,contact_index=contact,
        contact_utc=rows[contact]['timestamp_utc'] if contact is not None else None,
        invalidation_index=invalid,
        source_extension_contact_index=source_contact,
        construction='DF_outer_extension_parallel_shift_to_original_C',
        geometry_scope='C_to_before_first_price_contact',no_internal_candle_crossing=True)
