"""One calculation entry point for live prefixes and historical replay.

The broker worker used to expose :class:`PrefixEngine` directly.  That class
is still the deterministic closed-bar kernel, but callers had to decide for
themselves how to handle a forming bar and how to rebuild a history view.
This module keeps those decisions in one small adapter:

* ``step`` returns a confirmed scene plus an optional provisional scene;
* ``recompute_history`` uses the exact same closed-prefix kernel; and
* checkpoints contain only the confirmed prefix.  A forming bar is always
  re-read after a restart, so it cannot become stale durable state.

No terminal, archive, order, or filesystem API is used here.
"""

from copy import deepcopy
from datetime import datetime
from hashlib import sha256
import math

from .broker_live_engine import (
    PrefixEngine,
    SECONDS,
    canonical,
    calculate_prefix,
    iso,
)


def _forming_row(row, timeframe, provider, symbol, offset):
    """Normalize one raw or already-normalized forming bar.

    The live transport may provide either MT5's ``time`` field or the rows
    emitted by ``closed_native_prefix``.  The calculator consumes the latter.
    """
    if not isinstance(row, dict):
        raise ValueError("forming bar must be a mapping")
    stamp = row.get("native_epoch", row.get("time"))
    if stamp is None:
        raise ValueError("forming bar native epoch missing")
    stamp = int(stamp)
    values = {key: float(row[key]) for key in ("open", "high", "low", "close")}
    if (not all(math.isfinite(value) for value in values.values()) or
            not values["low"] <= min(values["open"], values["close"]) <= max(values["open"], values["close"]) <= values["high"]):
        raise ValueError("forming bar OHLC invalid")
    return dict(
        timestamp_utc=row.get("timestamp_utc", iso(stamp - offset)),
        native_epoch=stamp,
        timeframe=timeframe,
        provider=provider,
        symbol=symbol,
        **values,
    )


def _compact_bar(row):
    return {key: row[key] for key in (
        "timestamp_utc", "native_epoch", "timeframe", "provider", "symbol",
        "open", "high", "low", "close",
    ) if key in row}


def history_replay_receipt(bars, timeframe, cutoff_utc, provider, symbol, algorithm):
    """Return compact proof that a historical OHLC window used this kernel."""
    receipt = dict(schema="realtime_history_replay_receipt_v1",
                   timeframe=timeframe, provider=provider, symbol=symbol,
                   algorithm=algorithm, cutoff_utc=cutoff_utc,
                   state="unavailable", reason=None, bars=0,
                   scene_id=None, input_sha256=None)
    if timeframe not in SECONDS or not isinstance(cutoff_utc, str):
        receipt["reason"] = "invalid_history_clock"
        return receipt
    try:
        cutoff_native = int(datetime.fromisoformat(
            cutoff_utc.replace("Z", "+00:00")).timestamp())
    except (TypeError, ValueError, OverflowError):
        receipt["reason"] = "invalid_history_clock"
        return receipt
    rows = []
    for raw in bars or []:
        if not isinstance(raw, dict) or any(key not in raw for key in
                                            ("timestamp_utc", "open", "high", "low", "close")):
            receipt["reason"] = "ohlc_source_missing"
            return receipt
        try:
            stamp = int(datetime.fromisoformat(
                str(raw["timestamp_utc"]).replace("Z", "+00:00")).timestamp())
            row = dict(timestamp_utc=iso(stamp), native_epoch=stamp,
                       timeframe=timeframe, provider=provider, symbol=symbol,
                       open=float(raw["open"]), high=float(raw["high"]),
                       low=float(raw["low"]), close=float(raw["close"]))
        except (TypeError, ValueError, OverflowError):
            receipt["reason"] = "ohlc_source_invalid"
            return receipt
        prices = [row[key] for key in ("open", "high", "low", "close")]
        if (not all(math.isfinite(value) for value in prices) or
                not row["low"] <= min(row["open"], row["close"]) <=
                max(row["open"], row["close"]) <= row["high"]):
            receipt["reason"] = "ohlc_source_invalid"
            return receipt
        if stamp + SECONDS[timeframe] <= cutoff_native:
            rows.append(row)
    if len(rows) < 12:
        receipt["reason"] = "insufficient_closed_history"
        receipt["bars"] = len(rows)
        return receipt
    rows.sort(key=lambda row: row["native_epoch"])
    replay = RealtimeCalculationEngine().recompute_history(
        rows, timeframe, cutoff_native, 0, provider, symbol, algorithm)
    receipt.update(state="confirmed_replay", bars=len(rows),
                   scene_id=replay["scene_id"], input_sha256=replay["input_sha256"])
    return receipt


class RealtimeCalculationEngine(PrefixEngine):
    """Stateful confirmed-prefix engine with explicit forming-bar semantics."""

    schema = "realtime_calculation_engine_v1"

    def compact_snapshot(self, identity):
        """Persist only restart identity; source bars are recomputed on wake."""
        payload = dict(schema="realtime_calculation_checkpoint_v1",
                       identity=list(identity), restart_policy="recompute_from_source",
                       bars=[], input_key=None, latest=None)
        return dict(payload=payload, sha256=sha256(canonical(payload)).hexdigest())

    @classmethod
    def restore(cls, checkpoint, identity):
        payload = checkpoint.get("payload", {}) if isinstance(checkpoint, dict) else {}
        if payload.get("schema") == "realtime_calculation_checkpoint_v1":
            if (checkpoint.get("sha256") != sha256(canonical(payload)).hexdigest() or
                    payload.get("identity") != list(identity) or
                    payload.get("restart_policy") != "recompute_from_source"):
                raise ValueError("realtime compact checkpoint identity or checksum mismatch")
            # Deliberately leave the kernel empty. The next source read is the
            # recovery operation; no stale scene can be published as current.
            return cls()
        return super().restore(checkpoint, identity)

    def _provisional_scene(self, closed_bars, forming_bar, timeframe, cutoff_native,
                           offset, provider, symbol, algorithm, parent_bars=None):
        """Calculate a forming-bar view without changing confirmed state.

        The kernel only accepts closed prefixes.  For a forming view we use
        the forming candle's scheduled close as the analysis horizon, then
        mark the result provisional and retain the real observation clock in
        metadata.  No provisional object is copied into ``self.latest``.
        """
        forming = _forming_row(forming_bar, timeframe, provider, symbol, offset)
        if forming["native_epoch"] != int(cutoff_native):
            raise ValueError("forming bar must start at the confirmed cutoff")
        if closed_bars and forming["native_epoch"] <= int(closed_bars[-1]["native_epoch"]):
            raise ValueError("forming bar must follow the confirmed prefix")
        horizon = forming["native_epoch"] + SECONDS[timeframe]
        rows = list(closed_bars) + [forming]
        scene = calculate_prefix(rows, timeframe, horizon, offset, provider, symbol,
                                 algorithm, parent_bars)
        # A provisional view is useful for the chart, but it must never look
        # like a confirmed close or participate in checkpoint retention.
        scene["realtime_state"] = "provisional"
        scene["confirmed_cutoff_native_epoch"] = int(cutoff_native)
        scene["provisional_bar"] = _compact_bar(forming)
        scene["provisional_analysis_horizon_native_epoch"] = horizon
        scene["provisional_scene_id"] = sha256(canonical(scene)).hexdigest()
        scene["scene_id"] = sha256(canonical(scene)).hexdigest()
        return scene

    def step(self, bars, timeframe, cutoff_native, offset, provider, symbol,
             algorithm, parent_bars=None, *, forming_bar=None,
             observation_clock=None, analysis_cache=None, realtime_native=None):
        """Advance confirmed state and optionally calculate a forming view.

        ``confirmed_scene`` is exactly the historical replay result for the
        supplied closed bars.  ``provisional_scene`` is disposable and is
        recalculated on every forming update.  The returned packet is compact
        enough for a status channel; callers choose whether to publish the
        full scene or only the selected display objects.
        """
        confirmed, kind = self.update(
            bars, timeframe, cutoff_native, offset, provider, symbol, algorithm,
            parent_bars, observation_clock=observation_clock,
            analysis_cache=analysis_cache,
        )
        # Never decorate the retained kernel object itself. Repeated polls
        # must not hash yesterday's realtime packet into today's identity.
        confirmed = deepcopy(confirmed)
        provisional = None
        if forming_bar is not None:
            provisional = self._provisional_scene(
                bars, forming_bar, timeframe, cutoff_native, offset, provider,
                symbol, algorithm, parent_bars,
            )
        observed_native = int(realtime_native if realtime_native is not None else cutoff_native)
        packet = dict(
            schema=self.schema,
            state="provisional" if provisional is not None else "confirmed",
            update_kind=kind,
            observed_native_epoch=observed_native,
            confirmed_cutoff_native_epoch=int(cutoff_native),
            confirmed_scene_id=confirmed["scene_id"],
            confirmed_input_sha256=confirmed["input_sha256"],
            forming_bar=_compact_bar(_forming_row(forming_bar, timeframe, provider, symbol, offset)) if forming_bar is not None else None,
            provisional_scene_id=provisional["scene_id"] if provisional is not None else None,
            provisional_analysis_horizon_native_epoch=(
                provisional.get("provisional_analysis_horizon_native_epoch")
                if provisional is not None else None
            ),
            automatic_trade_permission=False,
            order_api_called=False,
        )
        # Keep the published confirmed scene self-describing without embedding
        # a second full scene in it.  The full provisional object graph stays
        # in the return value for a live display consumer.
        confirmed.pop("scene_id", None)
        packet["confirmed_base_scene_id"] = sha256(canonical(confirmed)).hexdigest()
        # Poll lifecycle (initial/unchanged) is not scene content. Keep it in
        # the returned observation packet, outside the published content hash.
        confirmed["realtime"] = {k: v for k, v in packet.items() if k != 'update_kind'}
        # PrefixEngine checkpoints hash the scene with its id removed. Keep
        # that invariant so a realtime worker can restart safely.
        confirmed["scene_id"] = sha256(canonical(confirmed)).hexdigest()
        return dict(confirmed_scene=confirmed, provisional_scene=provisional,
                    packet=packet, update_kind=kind)

    def recompute_history(self, bars, timeframe, cutoff_native, offset, provider,
                          symbol, algorithm, parent_bars=None, *, analysis_cache=None):
        """Rebuild a historical chart through the same confirmed kernel."""
        replay = type(self)()
        scene, kind = replay.update(
            bars, timeframe, cutoff_native, offset, provider, symbol, algorithm,
            parent_bars, observation_clock=None, analysis_cache=analysis_cache,
        )
        base_scene_id = scene.get("scene_id")
        scene.pop("scene_id", None)
        scene["realtime"] = dict(
            schema=self.schema,
            state="confirmed",
            update_kind=kind,
            observed_native_epoch=int(cutoff_native),
            confirmed_cutoff_native_epoch=int(cutoff_native),
            confirmed_scene_id=base_scene_id,
            confirmed_input_sha256=scene["input_sha256"],
            forming_bar=None,
            provisional_scene_id=None,
            provisional_analysis_horizon_native_epoch=None,
            automatic_trade_permission=False,
            order_api_called=False,
            replay=True,
        )
        scene["scene_id"] = sha256(canonical(scene)).hexdigest()
        return scene

