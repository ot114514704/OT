"""Recompute scene-owned conditional rulers without editing renderer geometry.

Arrow-generated AB/C records use a different producer from Python families.
Their displayed ownership must independently agree with the retained owner;
matching prices alone cannot import another family's receipt.
"""
from math import isclose
from bisect import bisect_right
from .one_to_one_structure_score import NativeScoreContext,canonical_point,epoch
from .live_regime_one_to_one import _NativeWindow,_time,_first_unit_projection_receipt,_continuation_unit_alternatives


def _identity(point):
    p=canonical_point(point)
    return tuple(p[k] for k in ('kind','pivot_timestamp_utc','price','confirmed_at_utc'))


def derive_scene_continuation(family,projection,displayed,context,native,cutoff):
    base=dict(schema='scene_owned_continuation_context_v1',
        measurement_id=family.get('measurement_id'),source_leg_id=family.get('source_leg_id'),
        projection_id=projection.get('projection_id'),native_timeframe=context.tf,
        provider=context.provider,symbol=context.symbol,as_of_utc=cutoff,
        state='unavailable',automatic_trade_permission=False,order_api_called=False,
        author_wave_mapping_adjudicated=False,execution_admission='blocked_research_only')
    try:
        pid=projection['projection_id'];sid=family['source_leg_id']
        owner=(family.get('return_ownership_by_projection_id') or {})[pid]
        if not family.get('measurement_id') or not pid or not sid:raise ValueError('source_identity_missing')
        if family['timeframe']!=context.tf:raise ValueError('foreign_source_timeframe')
        for key,wanted in (('provider',context.provider),('symbol',context.symbol),('instrument',context.symbol)):
            if key in family and family[key]!=wanted:raise ValueError('foreign_source_'+key)
        if projection.get('ordinal')!=2:raise ValueError('later_leg_requires_separate_actual_owner_verification')
        if projection.get('anchor_native_timeframe',context.tf)!=context.tf:raise ValueError('foreign_anchor_timeframe')
        for evidence in (owner,displayed):
            if (not isinstance(evidence,dict) or evidence.get('native_timeframe')!=context.tf or
                    evidence.get('measurement_source_leg_id')!=sid or
                    evidence.get('retraces_source_leg_id')!=sid):
                raise ValueError('retained_or_displayed_owner_mismatch')
        if projection.get('measurement_source_leg_id')!=sid or projection.get('retraces_source_leg_id')!=sid:
            raise ValueError('projection_owner_mismatch')
        a,b,c=[canonical_point(p) for p in (family['source_origin'],family['source_terminal'],projection['anchor'])]
        for evidence in (owner,displayed):
            if _identity(evidence['retraced_wave_origin'])!=_identity(a) or _identity(evidence['retraced_wave_terminal'])!=_identity(b):
                raise ValueError('owner_endpoints_do_not_match_original_AB')
        known=projection['known_at_utc'];clock=epoch(known)
        if clock>epoch(cutoff):raise ValueError('projection_after_cutoff')
        dependencies=[family['known_at_utc'],owner['known_at_utc'],displayed['known_at_utc']]
        dependencies += [p['confirmed_at_utc'] for p in (a,b,c)]
        if any(epoch(t)>clock for t in dependencies):raise ValueError('dependency_after_projection_clock')
        ai,bi,ci=[context.point_index(p,clock) for p in (a,b,c)]
        if not ai<bi<ci or a['kind']!=c['kind'] or a['kind']==b['kind']:
            raise ValueError('native_AB_C_order_or_kind_invalid')
        if not context.continuous(ai,ci):raise ValueError('native_source_or_return_history_gap')
        # The reference can be discovered well after C. Price events between
        # C and that knowledge clock also need native OHLC/market validation.
        # Do not inspect future bars beyond that version's closed prefix.
        for i in range(ci+1,bisect_right(context.times,clock-context.seconds)):
            context._bar(i)
        if not native.return_envelope(a,b):raise ValueError('source_external_extreme_not_verified')
        if not min(a['price'],b['price'])<c['price']<max(a['price'],b['price']):
            raise ValueError('second_leg_anchor_outside_original_AB')
        target=c['price']+b['price']-a['price']
        if not isclose(float(projection['target']),target,rel_tol=0,abs_tol=1e-8):
            raise ValueError('projection_target_not_original_AB')
        if not native.return_envelope(b,c):raise ValueError('return_external_extreme_not_verified')
        # Normalize only local copies. No raw projection field is filled in.
        f=dict(family,source_origin=a,source_terminal=b)
        p=dict(projection,anchor=c)
        owned=dict(id=sid,origin=a,terminal=b,known=owner['known_at_utc'])
        receipt=_first_unit_projection_receipt(f,p,owned,native,True)
        if receipt['state']=='unavailable':return dict(base,reason=receipt['reason'])
        receipt['continuation_alternatives']=_continuation_unit_alternatives(f,p,native)
        return dict(base,state='native_owned_conditional_reference',known_at_utc=known,
            source_kind=family.get('source_kind'),first_unit_projection_receipt=receipt,
            source_membership_scope='native_bounds_and_explicit_owner_not_author_same_degree')
    except (KeyError,TypeError,ValueError,OverflowError) as exc:
        return dict(base,reason=str(exc))


def attach_scene_continuations(scene):
    readings={r['object_id']:r for r in scene['one_to_one_structure_scores']['readings']}
    context=None;failure=None
    try:
        tf=scene['timeframe'];cutoff=scene['cutoff_utc']
        context=NativeScoreContext(scene.get('execution_context',{}).get('bars',[]),tf,
            scene['provider'],scene.get('symbol') or scene['instrument'])
        raw={_time(r['timestamp_utc']):r for r in context.bars if epoch(r['timestamp_utc'])+context.seconds<=epoch(cutoff)}
        native=_NativeWindow(raw,tf,_time(cutoff),None)
    except (KeyError,TypeError,ValueError,IndexError) as exc:failure=str(exc)
    for obj in scene.get('objects',[]):
        e=obj.get('evidence') or {};f=e.get('record');p=e.get('projection')
        if obj.get('layer')!='one_to_one' or not isinstance(f,dict) or not isinstance(p,dict):continue
        receipt=(derive_scene_continuation(f,p,e.get('ownership') or {},context,native,scene['cutoff_utc'])
                 if context is not None and failure is None else
                 dict(schema='scene_owned_continuation_context_v1',state='unavailable',reason=failure,
                      automatic_trade_permission=False,order_api_called=False))
        e['continuation_unit_context']=receipt
        if obj['id'] in readings:readings[obj['id']]['continuation_unit_context']=receipt
    return scene
