"""Broker-prefix Book calculation; no archive reads, terminal calls or orders."""
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json
import math
import ast
from functools import lru_cache
from pathlib import Path

from .trend_trade_method_full_pipeline import (
    build_book_logic_evidence, scene_objects, same_chart_wave_degree_objects,
    detect_trend, detect_major_wave,
)
from .book_wave_inventory import historical_book_objects
from .book_late_turning import late_turning_objects
from .book_structural_anchors import structural_wave_objects
from .book_owned_axis import owned_axis_objects
from .book_boundary_events import boundary_event_objects
from .book_line_delivery import deliver_book_lines, route_book_line_roles, ROLES


SECONDS={'M1':60,'M5':300,'M15':900,'M30':1800,'H1':3600,'H4':14400,'D1':86400,'W1':604800}
PARENT=dict(M1='M5',M5='M15',M15='M30',M30='H1',H1='H4',H4='D1',D1='W1')


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')


def iso(epoch):
    return datetime.fromtimestamp(epoch,timezone.utc).isoformat().replace('+00:00','Z')


ENGINE_REQUIRED_SOURCES=('realtime_calculation_engine.py','broker_realtime_display.py','broker_runtime_retention.py',
                 'broker_realtime_pipeline.py','broker_current_result.py','broker_native_history.py',
                 'broker_book_preview.py','broker_book_structure.py','book_scene_adapter.js','book_scope_history.js',
                 'book_boundary_scopes.py','book_delivery_lane.py','book_realtime_jobs.py','book_parent_preview.py','book_parallel_addons.py',
                 'book_realtime_state.py','book_complete_calculation.py','book_calculation_scope.py','book_calculation_progress.py','book_confirmed_jobs.py','book_native_quote.py','book_current_storage.py','book_publication_projection.py',
                 'unified_current_storage.py','unified_realtime_engine.py','unified_history_source.py','unified_period_timelines.py','unified_evidence_copy.py','unified_render_input.py','unified_render_wire.py','unified_force_review.py',
                 'unified_preview_binding.py','unified_preview_jobs.py','unified_confirmed_jobs.py','unified_process_jobs.py','unified_request_files.py','unified_computation_cache.py','unified_structure_review.py','unified_background_reuse.py','unified_display_cache.py','unified_indicator_live.py','unified_parent_quote.py')
ENGINE_OPTIONAL_SOURCES=('broker_live_engine.py','broker_live_service.py','broker_exact_result_cache.py','broker_native_rates.py','broker_live_supervisor.py','broker_live_ict.py','broker_structure_scene.py','broker_force_wave_scope.py','broker_book_context.py','book_complete_wave_channels.py','book_display_scope.py','broker_live_evidence.py','book_live_context.py','mt5_publication_files.py')


@lru_cache(maxsize=8)
def _identity_source_groups(source):
    """Parse literal lists from freshly read bytes, never execute source code.

    Long-lived HTTP readers and workers must discover the same newly added
    dependency without importing an older registry tuple from module globals.
    Only exact source bytes are cached; mtime/size cannot hide an edit.
    """
    found={}
    for statement in ast.parse(source).body:
        if isinstance(statement,ast.Assign):
            for target in statement.targets:
                if isinstance(target,ast.Name) and target.id in ('ENGINE_REQUIRED_SOURCES','ENGINE_OPTIONAL_SOURCES'):
                    value=ast.literal_eval(statement.value)
                    if not isinstance(value,tuple) or any(not isinstance(n,str) or not n or '/' in n or '\\' in n or n in ('.','..') for n in value):
                        raise ValueError('invalid engine source registry')
                    if target.id in found:raise ValueError('duplicate engine source registry')
                    found[target.id]=value
    if len(found)!=2:raise ValueError('missing engine source registry')
    return found['ENGINE_REQUIRED_SOURCES'],found['ENGINE_OPTIONAL_SOURCES']


def engine_identity():
    from .mt5_scene_store import engine_revision
    source=Path(__file__).read_bytes()
    required,optional=_identity_source_groups(source)
    digest=sha256(engine_revision().encode())
    for name in required:
        digest.update(Path(__file__).with_name(name).read_bytes())
    for name in optional:
        path=Path(__file__).with_name(name)
        if path.exists():digest.update(path.read_bytes())
    if Path(__file__).read_bytes()!=source:raise ValueError('engine source registry changed retry')
    return digest.hexdigest()


def closed_native_prefix(data,timeframe,cutoff_native,offset,provider):
    """Retain native chart epochs as well as explicit measured UTC conversion."""
    if timeframe not in SECONDS or abs(offset)>14*3600 or offset%60:
        raise ValueError('unsupported timeframe or broker clock offset')
    rows=[];last=None
    for row in data:
        stamp=int(row['time'])
        if stamp+SECONDS[timeframe]>cutoff_native:continue
        if last is not None and stamp<=last:raise ValueError('unordered broker prefix')
        prices={k:float(row[k]) for k in ('open','high','low','close')}
        if (not all(math.isfinite(x) for x in prices.values()) or
            not prices['low']<=min(prices['open'],prices['close'])<=max(prices['open'],prices['close'])<=prices['high']):
            raise ValueError('invalid broker OHLC')
        rows.append(dict(timestamp_utc=iso(stamp-offset),native_epoch=stamp,
                         timeframe=timeframe,provider=provider,**prices))
        last=stamp
    return rows


def update_kind(previous,current):
    if not previous:return 'initial'
    before={r['native_epoch']:r for r in previous}
    overlap=[r for r in current if r['native_epoch'] in before]
    if any(r!=before[r['native_epoch']] for r in overlap):return 'history_revision'
    if not overlap:return 'reset'
    if current[-1]['native_epoch']>previous[-1]['native_epoch']:return 'append'
    if current==previous:return 'unchanged'
    return 'history_backfill'


def _finite_segments(objects,bars,seconds):
    times=[datetime.fromisoformat(r['timestamp_utc'].replace('Z','+00:00')).timestamp() for r in bars]
    pos={t:i for i,t in enumerate(times)};result=[];deferred=[]
    for source in objects:
        if source['kind']!='line' or source['points'][0][0]==source['points'][1][0]:
            result.append(source);continue
        a,b=source['points']
        if a[0] not in pos or b[0] not in pos:
            deferred.append(dict(id=source['id'],reason='exact_native_endpoint_unavailable'));continue
        i,j=pos[a[0]],pos[b[0]]
        if i>=j:continue
        ev=source.get('evidence',{})
        if source.get('layer')=='force' and (ev.get('book_first_response') or ev.get('force_leg_id')):
            # These are directional source endpoints, not an interpolated
            # trendline. Splitting at a session boundary manufactured prices
            # outside the native endpoint candle and then scored those pieces.
            obj=deepcopy(source)
            obj.setdefault('evidence',{}).update(native_source_endpoints_preserved=True,
                native_source_gap_count=sum(times[k+1]-times[k]!=seconds for k in range(i,j)))
            result.append(obj);continue
        slope=(b[1]-a[1])/(j-i);start=i
        runs=[]
        for k in range(i,j):
            if times[k+1]-times[k]!=seconds:runs.append((start,k));start=k+1
        runs.append((start,j))
        for start,end in runs:
            if start==end:continue
            obj=deepcopy(source)
            obj['id']='b'+sha256(f"{source['id']}|native-run|{times[start]}".encode()).hexdigest()[:23]
            obj['points']=[[times[k],a[1]+slope*(k-i)] for k in (start,end)]
            obj['evidence'].update(source_object_id=source['id'],
                                   native_segment_start=times[start],native_segment_end=times[end],
                                   native_gaps_bridged=False)
            result.append(obj)
    return result,deferred


def calculate_prefix(bars,timeframe,cutoff_native,offset,provider,symbol,algorithm,parent_bars=None):
    cutoff=iso(cutoff_native-offset)
    # The request already fixes this market. Preserve declared metadata and
    # bind missing symbol fields BEFORE Book creates its native source IDs.
    from .book_scene_event_queue import native_book_rows
    bars=native_book_rows(bars,timeframe,cutoff,provider,symbol,offset)
    if parent_bars:
        parent_bars=native_book_rows(parent_bars,PARENT[timeframe],cutoff,provider,symbol,offset)
    if len(bars)<12:raise ValueError('insufficient closed broker bars')
    input_id=sha256(canonical(dict(provider=provider,symbol=symbol,timeframe=timeframe,
                                   offset=offset,bars=bars,parent_bars=parent_bars or []))).hexdigest()
    book=build_book_logic_evidence(bars,timeframe,cutoff)
    objects=scene_objects(book,bars,timeframe)
    objects+=same_chart_wave_degree_objects(bars,timeframe,cutoff)
    audits={}
    for name,builder in (('historical',historical_book_objects),('late_turning',late_turning_objects),
                         ('structural',structural_wave_objects)):
        extra,audit=builder(bars,timeframe,cutoff,objects)
        objects+=extra;audits[name]=audit
    extra,audits['owned_axis']=owned_axis_objects(bars,timeframe,cutoff)
    objects+=extra
    extra,audits['boundary_events']=boundary_event_objects(bars,timeframe,cutoff,objects)
    objects+=extra
    objects,audits['delivery']=deliver_book_lines(objects,bars,timeframe,cutoff,SECONDS[timeframe])
    objects,audits['roles']=route_book_line_roles(objects)
    # Never label a geometrically unverified ruler as a live accepted line.
    unverified={r['id'] for r in audits['delivery']['unverified']}
    objects=[o for o in objects if o['id'] not in unverified]
    objects,audits['native_segments_deferred']=_finite_segments(objects,bars,SECONDS[timeframe])
    unique={}
    for source in objects:
        obj=deepcopy(source);raw_id=obj['id']
        obj['id']='b'+sha256(f'{provider}|{symbol}|{raw_id}'.encode()).hexdigest()[:23]
        obj['owner_id']=provider+'|'+obj.get('owner_id','unknown')
        ev=obj.setdefault('evidence',{})
        ev.update(data_provider=provider,source_object_id=raw_id,
                  construction_known_at_utc=ev.get('construction_known_at_utc',obj['known_at_utc']),
                  display_state_known_at_utc=ev.get('display_state_known_at_utc',obj['known_at_utc']),
                  status_known_at_utc=ev.get('status_known_at_utc',obj['known_at_utc']),
                  automatic_trade_permission=False,read_only=True)
        obj['native_points']=[[int(t+offset),p] for t,p in obj['points']]
        if any(t>cutoff_native for t,p in obj['native_points']):
            audits.setdefault('future_geometry_rejected',[]).append(obj['id']);continue
        if obj['known_at_utc']>cutoff:
            audits.setdefault('future_knowledge_rejected',[]).append(obj['id']);continue
        unique[obj['id']]=obj
    parent_tf=PARENT.get(timeframe)
    parent=dict(timeframe=parent_tf,status='unknown',reason='same_feed_parent_not_available')
    if parent_bars and parent_tf:
        parent=dict(timeframe=parent_tf,provider=provider,as_of_utc=cutoff,
                    trend=detect_trend(parent_bars,parent_tf,cutoff),
                    wave=detect_major_wave(parent_bars,parent_tf,cutoff),
                    status='same_feed_closed_prefix',trade_permission=False)
    scene=dict(schema='machine1_broker_scene_v1',provider=provider,instrument=symbol,
                timeframe=timeframe,cutoff_utc=cutoff,cutoff_native_epoch=cutoff_native,
                observed_server_utc_offset_seconds=offset,input_sha256=input_id,
                engine_revision=algorithm,book_logic=book,objects=list(unique.values()),
                parent_context=parent,geometry_audit=audits,coverage=dict(bars=len(bars),
                    first_native_epoch=bars[0]['native_epoch'],last_closed_native_epoch=bars[-1]['native_epoch']),
                clock_policy='measured_current_server_offset; original native chart coordinates retained',
                historical_dst_offset_verified=False,read_only=True,
                automatic_trade_permission=False,order_api_called=False)
    # The legacy Book view attaches scoring AFTER collecting all sources.
    # The broker path previously stopped at geometry, omitting the entire
    # strength/return/owned-band chain despite exposing its MT5 controls.
    from .mt5_force_strength import attach_mt5_force_strength
    attach_mt5_force_strength(scene,bars)
    for obj in scene['objects']:
        obj['native_points']=[[int(t+offset),p] for t,p in obj['points']]
        if any(t>cutoff_native for t,p in obj['native_points']) or obj['known_at_utc']>cutoff:
            raise ValueError('force attachment exceeded broker prefix')
        obj.setdefault('evidence',{}).update(data_provider=provider,read_only=True,
                                            automatic_trade_permission=False)
    return scene


def pure_prefix_key(bars,timeframe,cutoff_native,offset,provider,symbol,algorithm,parent_bars=None):
    from .book_calculation_scope import independent_axis_enabled
    policy='book_independent_axis_prefix_v1' if independent_axis_enabled() else 'broker_primary_prefix_v1'
    return sha256(canonical([policy,provider,symbol,
        timeframe,cutoff_native,offset,algorithm,bars,parent_bars])).hexdigest()


class PrefixEngine:
    """Update the input prefix automatically; unchanged inputs reuse calculation."""
    retain_disappeared_geometry=True
    def __init__(self):
        self.bars=[];self.input_key=None;self.latest=None;self.retained={}

    def snapshot(self, identity):
        payload=dict(schema='broker_prefix_checkpoint_v1',identity=list(identity),
                     bars=self.bars,input_key=self.input_key,latest=self.latest)
        return dict(payload=payload,sha256=sha256(canonical(payload)).hexdigest())

    @classmethod
    def restore(cls, checkpoint, identity):
        payload=checkpoint['payload']
        if (checkpoint['sha256']!=sha256(canonical(payload)).hexdigest() or
            payload['schema']!='broker_prefix_checkpoint_v1' or
            payload['identity']!=list(identity)):
            raise ValueError('broker checkpoint identity or checksum mismatch')
        instance=cls()
        latest=payload['latest']
        if latest:
            unhashed={k:v for k,v in latest.items() if k!='scene_id'}
            if sha256(canonical(unhashed)).hexdigest()!=latest['scene_id']:
                raise ValueError('broker checkpoint scene mismatch')
            if 'book_event_queue_state' in latest:
                from .book_scene_event_queue import scene_event_candidates
                if scene_event_candidates(latest)['state']!='verified_observation_packet':
                    raise ValueError('broker checkpoint Book event state mismatch')
            instance.retained={o['id']:o for o in latest['objects']}
        instance.bars=payload['bars'];instance.input_key=payload['input_key'];instance.latest=latest
        return instance

    def update(self,bars,timeframe,cutoff_native,offset,provider,symbol,algorithm,parent_bars=None,*,observation_clock=None,analysis_cache=None):
        basis='broker_processing_wall_clock' if observation_clock is not None else 'native_close_replay'
        from .book_calculation_scope import independent_axis_enabled
        inputs=[provider,symbol,timeframe,cutoff_native,offset,algorithm,bars,parent_bars,basis]
        if independent_axis_enabled():inputs.append('book_independent_axis_prefix_v1')
        key=sha256(canonical(inputs)).hexdigest()
        if key==self.input_key:return self.latest,'unchanged'
        kind=update_kind(self.bars,bars)
        # Only the pure detector may survive worker/viewport changes. Retained
        # objects and first-observation receipts are attached below on EVERY
        # delivery, with the caller's current observation clock.
        pure_key=pure_prefix_key(bars,timeframe,cutoff_native,offset,provider,symbol,algorithm,parent_bars)
        fresh=analysis_cache.get(pure_key) if analysis_cache is not None else None
        if fresh is None:
            fresh=calculate_prefix(bars,timeframe,cutoff_native,offset,provider,symbol,algorithm,parent_bars)
            if analysis_cache is not None:analysis_cache.put(pure_key,fresh)
        active={obj['id']:obj for obj in fresh['objects']}
        # Navigating backwards must reconstruct that prefix alone. Retaining
        # the live scene here leaks later confirmations/lifecycles into history.
        rewind=bool(self.latest and cutoff_native<self.latest['cutoff_native_epoch'])
        reset_reason='historical_viewport_rewind' if rewind else kind if kind in ('history_revision','reset') else None
        if self.latest and any(self.latest.get(k)!=fresh.get(k) for k in
                ('provider','instrument','timeframe','observed_server_utc_offset_seconds','engine_revision')):
            reset_reason=reset_reason or 'stream_identity_changed'
        prior_retained={} if reset_reason or not self.retain_disappeared_geometry else self.retained
        retained=[]
        for oid,old in prior_retained.items():
            if oid in active:continue
            old=deepcopy(old)
            old['evidence']['retained_historical_prefix']=True
            old['evidence']['current_lifecycle_beyond_saved_endpoint']='unverified'
            retained.append(old)
        fresh['active_object_ids']=list(active)
        fresh['objects']=list(active.values())+retained
        fresh['retention_audit']=dict(retained=len(retained),active=len(active),
                                     reset_reason=reset_reason)
        # Source observations belong to the same verified checkpoint as the
        # scene. The worker supplies an actual clock AFTER primary detection;
        # deterministic offline callers explicitly retain the replay basis.
        from .book_scene_event_queue import attach_scene_event_queue
        if observation_clock is not None and not callable(observation_clock):
            raise ValueError('broker observation clock must be callable')
        observed=observation_clock() if observation_clock is not None else None
        attach_scene_event_queue(fresh,bars,self.latest,self.bars,observed_at_utc=observed,
            observation_basis=basis,
            reset_reason=reset_reason)
        fresh['scene_id']=sha256(canonical(fresh)).hexdigest()
        self.retained={obj['id']:obj for obj in fresh['objects']}
        self.latest=fresh;self.bars=deepcopy(bars);self.input_key=key
        return fresh,kind
