"""Read-only shared scene producer, archive exporter and viewport worker."""
import argparse
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time
from copy import deepcopy
from collections import OrderedDict
from datetime import datetime, timezone
from math import isclose
from functools import lru_cache
from .build_archive_window_snapshot import ARCHIVE, TIMEFRAME_MINUTES

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT/'03_work_queue/wells3_live_multitimeframe_vertical_slice_20260928'
OUTPUT = ROOT/'03_work_queue/machine1_unified_mt5'
SYMBOL = 'Machine1.HistData.XAUUSD'
COMMON = Path(os.environ.get('APPDATA',''))/'MetaQuotes/Terminal/Common/Files/Machine1'
from .mt5_scene_store import engine_revision as _source_revision
PROCESS_ENGINE_REVISION = _source_revision()
PHASE_TRANSPORT_CONTRACT = 'unified_book_phase_transport_v1'


class EngineRevisionChanged(RuntimeError):
    """A fresh interpreter is required before producing another scene."""


def _cached_scene_contract_ready(prior):
    """Permit cache reuse only after the current semantic receipt exists."""
    if not isinstance(prior,dict):
        return False
    ids=[obj.get('id') for obj in prior.get('objects',[]) if isinstance(obj,dict)]
    cached_book=prior.get('book_logic') or {}
    return (len(ids)==len(set(ids)) and
            cached_book.get('unified_phase_transport_contract')==PHASE_TRANSPORT_CONTRACT and
            isinstance(cached_book.get('unified_phase_transport_applied'),int))


def _unified_geometry_record(obj):
    """Project one Unified object into the Book candidate namespace.

    Phase is transported only when the producer already supplied it. A wave
    id, owner id, label or object name is never promoted into a phase identity.
    """
    evidence=obj.get('evidence') or {}
    audit=evidence.get('unified_zigzag_channel_audit')
    if not isinstance(audit,dict):
        return None
    projection=evidence.get('unified_structure_projection')
    projection=projection if isinstance(projection,dict) else {}
    phase_id=obj.get('phase_id') or projection.get('phase_id') or audit.get('phase_id')
    return dict(
        object_id=obj.get('id'), owner_id=obj.get('owner_id'),
        source_id=obj.get('source_id'), timeframe=obj.get('timeframe'),
        known_at_utc=obj.get('known_at_utc'), phase_id=phase_id,
        source_identity=(obj.get('source_identity') or projection.get('source_identity')
                         or audit.get('source_identity')),
        wave_id=audit.get('wave_id'), canonical_wave_id=audit.get('canonical_wave_id'),
        wave_lineage_id=audit.get('canonical_wave_lineage_id'),
        direction=audit.get('direction') or ('up' if (audit.get('axis_slope') or 0)>0 else 'down' if (audit.get('axis_slope') or 0)<0 else None),
        state=audit.get('calibrated_state') or audit.get('state') or 'review_unknown',
        audit=audit)


def _native_neckline_receipts(scene, timeframe, cutoff):
    """Index Book-native neckline proofs for exact Unified transport only."""
    result={}
    for obj in scene.get('objects',[]):
        evidence=obj.get('evidence') or {}
        if obj.get('timeframe')!=timeframe:
            continue
        proof=evidence.get('neckline_pair_proof') or evidence.get('neckline_proof') or {}
        receipt=proof.get('native_receipt') if isinstance(proof,dict) else None
        canonical=evidence.get('canonical_wave_id')
        if not canonical or not isinstance(receipt,dict) or receipt.get('schema')!='native_double_extreme_neckline_receipt_v1':
            continue
        try:
            if datetime.fromisoformat(str(obj.get('known_at_utc')).replace('Z','+00:00'))>datetime.fromisoformat(str(cutoff).replace('Z','+00:00')):
                continue
        except (TypeError,ValueError):
            continue
        result.setdefault(canonical,[]).append(deepcopy(receipt))
    return result


def _transport_native_neckline_receipts(records, receipt_index, timeframe, cutoff):
    """Attach only same-canonical-wave Book receipts to Unified records."""
    transported=[]
    for record in records:
        if record.get('timeframe')!=timeframe:
            transported.append(record);continue
        receipts=receipt_index.get(record.get('canonical_wave_id'),[])
        if not receipts:
            transported.append(dict(record,neckline_receipt_transport=dict(
                schema='book_unified_native_neckline_transport_v1',
                state='no_exact_book_wave',candidate_canonical_wave_id=record.get('canonical_wave_id'),
                available_book_canonical_wave_ids=sorted(receipt_index),
                cutoff_utc=cutoff,automatic_trade_permission=False,entry_permission=False)))
            continue
        valid=[]
        for receipt in receipts:
            if receipt.get('native_timeframe')==timeframe and receipt.get('trade_permission') is False:
                valid.append(receipt)
        transported.append(dict(record,native_neckline_receipts=valid,
                                neckline_receipt_transport=dict(
                                    schema='book_unified_native_neckline_transport_v1',
                                    state='exact_canonical_wave',count=len(valid),
                                    cutoff_utc=cutoff,automatic_trade_permission=False,
                                    entry_permission=False)))
    return transported


def _bind_unified_phase_from_book(scene, record):
    """Attach Book phase only for the exact native ruler drawn by Unified.

    A bound Book phase is useful evidence, but it is not a license to label
    every same-wave object.  Both selected outer anchors, their native bar
    timestamps/prices, selected slope, timeframe and known-at clock must agree.
    """
    if not isinstance(record,dict) or record.get('phase_id'):
        return record
    binding=scene.get('book_trend_binding') or {}
    if binding.get('state')!='bound' or not isinstance(binding.get('phase_id'),str):
        return record
    if record.get('timeframe')!=binding.get('native_timeframe'):
        return record
    if (record.get('source_identity') is not None and
            record.get('source_identity')!=binding.get('source_identity')):
        return record
    try:
        cutoff=datetime.fromisoformat(str(binding['as_of_utc']).replace('Z','+00:00'))
        known=datetime.fromisoformat(str(record['known_at_utc']).replace('Z','+00:00'))
        if known>cutoff: return record
    except (KeyError,TypeError,ValueError):
        return record
    line=binding.get('Book_ruler_geometry') or {}
    audit=record.get('audit') or {}; anchors=audit.get('selected_anchors') or []
    bars=(scene.get('execution_context') or {}).get('bars') or []
    if len(anchors)!=2 or not isinstance(bars,list): return record
    try:
        expected=((line['start_index'],line['start_price']),(line['end_index'],line['end_price']))
        for anchor,(index,price) in zip(anchors,expected):
            if (type(anchor.get('index')) is not int or anchor['index']!=index or
                    not 0<=index<len(bars) or anchor.get('timestamp_utc')!=bars[index]['timestamp_utc'] or
                    anchor.get('price')!=price):
                return record
            anchor_known=anchor.get('known_at_utc')
            if anchor_known:
                if datetime.fromisoformat(str(anchor_known).replace('Z','+00:00'))>cutoff:
                    return record
        slope=float(line['slope']); selected=float(audit['selected_slope'])
        if not isclose(slope,selected,rel_tol=1e-12,abs_tol=1e-12): return record
    except (KeyError,TypeError,ValueError,IndexError,ArithmeticError):
        return record
    return dict(record,phase_id=binding['phase_id'],phase_binding='exact_book_ruler')


def _transport_bound_unified_phase(scene, records):
    """Write only exact Book-bound phase evidence back to Unified objects."""
    by_id={r.get('object_id'):r for r in records if isinstance(r,dict)
           and r.get('phase_binding')=='exact_book_ruler' and r.get('phase_id')}
    applied=0
    for obj in scene.get('objects',[]):
        record=by_id.get(obj.get('id'))
        if record is None: continue
        evidence=obj.setdefault('evidence',{})
        obj['phase_id']=record['phase_id']
        evidence['unified_phase_binding']=dict(
            schema='unified_book_phase_binding_v1',namespace='BookUnified',
            state='same_native_book_ruler',phase_id=record['phase_id'],
            source_identity=deepcopy(record.get('source_identity')),
            source_timeframe=obj.get('timeframe'),known_at_utc=obj.get('known_at_utc'),
            automatic_trade_permission=False,entry_permission=False)
        projection=evidence.get('unified_structure_projection')
        if isinstance(projection,dict):
            projection['phase_id']=record['phase_id']
            projection['phase_binding']='exact_book_ruler'
        applied+=1
    return applied


def attach_book_trend_binding_shared(scene):
    """Attach the Book-selected source as a read-only shared scene fact."""
    from .book_trend_wave_binding import resolve_book_trend_binding
    result = deepcopy(scene)
    result['book_trend_binding'] = resolve_book_trend_binding(result)
    result['book_trend_binding_attachment'] = {
        'source': 'book_trend_wave_binding_v1',
        'score_effect': 'none', 'direction_effect': 'none',
        'entry_permission': False, 'automatic_trade_permission': False,
        'default_shared_consumer': True,
    }
    return result


@lru_cache(maxsize=64)
def _foundation_context(timeframe, cutoff):
    """Attach the same read-only as-of background used by foundation review."""
    try:
        from .foundation_review import DEFAULT_SHARD_MANIFEST, load_sharded_packet, query_period
        packet = load_sharded_packet(DEFAULT_SHARD_MANIFEST)
        at = cutoff or packet['snapshot']['as_of_utc']
        review = query_period(packet, timeframe, cutoff=at, limit=1)
        background = review.get('background_judgment') or {}
        return {
            'timeframe': timeframe,
            'as_of_utc': at,
            'state': background.get('state'),
            'direction': background.get('direction'),
            'status': background.get('status'),
            'confidence': background.get('confidence'),
            'candidate_roles': background.get('candidate_roles', {}),
            'complete_wave': background.get('complete_wave', {}),
            'same_period_context': background.get('same_period_context', {}),
            'joint_context': background.get('joint_context', {}),
            'direct_parent': review.get('direct_parent'),
            'parent_context': background.get('parent_context', {}),
            'evidence_ids': background.get('evidence_ids', []),
            'unknown_reason': background.get('unknown_reason'),
            'trade_permission': False,
            'rule_id': background.get('rule_id', 'foundation_background_v1'),
        }
    except (FileNotFoundError, KeyError, TypeError, ValueError, OSError) as error:
        return {
            'timeframe': timeframe, 'as_of_utc': cutoff,
            'state': 'unknown', 'direction': None,
            'status': 'foundation_context_unavailable', 'confidence': 'unknown',
            'candidate_roles': {}, 'complete_wave': {}, 'same_period_context': {},
            'joint_context': {},
            'direct_parent': None, 'parent_context': {}, 'evidence_ids': [],
            'unknown_reason': f'foundation_context_unavailable:{type(error).__name__}',
            'trade_permission': False, 'rule_id': 'foundation_background_v1',
        }


@lru_cache(maxsize=32)
def _foundation_ladder_context(cutoff):
    """Return the eight-period background ladder at one shared as-of clock."""
    try:
        from .foundation_review import DEFAULT_SHARD_MANIFEST, FOUNDATION_PERIODS, load_sharded_packet, query_period
        packet = load_sharded_packet(DEFAULT_SHARD_MANIFEST)
        at = cutoff or packet['snapshot']['as_of_utc']
        ladder = {}
        for tf in FOUNDATION_PERIODS:
            review = query_period(packet, tf, cutoff=at, limit=1)
            background = review.get('background_judgment') or {}
            ladder[tf] = {
                'timeframe': tf,
                'as_of_utc': at,
                'state': background.get('state'),
                'direction': background.get('direction'),
                'status': background.get('status'),
                'confidence': background.get('confidence'),
                'candidate_roles': background.get('candidate_roles', {}),
                'complete_wave': background.get('complete_wave', {}),
                'same_period_context': background.get('same_period_context', {}),
                'joint_context': background.get('joint_context', {}),
                'direct_parent': review.get('direct_parent'),
                'parent_context': background.get('parent_context', {}),
                'evidence_ids': background.get('evidence_ids', []),
                'unknown_reason': background.get('unknown_reason'),
                'trade_permission': False,
                'rule_id': background.get('rule_id', 'foundation_background_v1'),
            }
        return ladder
    except (FileNotFoundError, KeyError, TypeError, ValueError, OSError):
        return {}


def atomic(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, prefix=path.name+'.')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def _dynamic_snr_stop_ladder(snapshot, cutoff):
    """Build the multi-period SNR stop display for the scene's own as-of clock.

    The persisted index is an audit artifact for one frozen clock.  Live tile
    workers can request many historical cutoffs, so a mismatched index must
    not remove the SNR layer.  Recompute the cheap pivot-cluster SNR facts from
    the same closed native snapshot instead of carrying a level from another
    clock.  B-point fields remain unknown here unless the matching frozen
    index supplied them; this preserves the book's causal boundary.
    """
    if not isinstance(snapshot, dict) or not cutoff:
        return None
    chart_history = snapshot.get('chart_history') or {}
    from .trend_trade_method_patterns import build_snr_levels
    periods = []
    for period in ('W1', 'D1', 'H4', 'H1', 'M30', 'M15', 'M5', 'M1'):
        bars = (chart_history.get(period) or {}).get('bars', [])
        snr = build_snr_levels(bars, period, cutoff)
        periods.append({
            'timeframe': period, 'as_of_utc': cutoff,
            'status': 'unknown', 'basis': None, 'b_kind': None,
            'reference_price': None, 'reference_utc': None,
            'known_at_utc': snr.get('known_at_utc', cutoff),
            'unknown_reason': 'B_point_index_not_available_for_scene_clock',
            'snr_status': snr.get('status', 'unknown'),
            'snr_levels': snr.get('levels', []),
            'snr_unknown_reason': snr.get('reason'),
            'rule_id': 'trend_trade_method_book_computable_v1:stop_reference',
            'read_only': True, 'trade_permission': False,
        })
    return {
        'schema': 'trend_trade_method_multitimeframe_stop_reference_v1',
        'as_of_utc': cutoff, 'periods': periods,
        'read_only': True, 'trade_permission': False,
        'automatic_trade_permission': False,
        'unknown_boundary': 'B point requires a matching closed-break index; SNR uses closed pivot clusters only.',
        'source': 'same_scene_closed_native_snapshot',
    }


def build_scene(tf, cutoff=None, count=2048, display_mode='all'):
    if tf not in TIMEFRAME_MINUTES:
        raise ValueError('unsupported period')
    from .mt5_scene_store import engine_revision, archive_revision, cached, save, scene_request_key
    revision=engine_revision()
    if revision != PROCESS_ENGINE_REVISION:
        raise EngineRevisionChanged('Source changed after process start; do not label old loaded code with a new source hash')
    data_revision=archive_revision(cutoff,count) if cutoff else 'frozen_broker_snapshot'
    if display_mode not in ('all','structure','ict'):
        raise ValueError('unsupported display mode')
    # Foundation projections are part of the scene cache identity.  A rebuilt
    # read-only facts/shard packet must invalidate persisted scenes so their
    # background and same-period hierarchy cannot remain on an older snapshot.
    key=scene_request_key(tf,cutoff,count,display_mode,revision=revision,data_revision=data_revision)
    prior=cached(key) if key else None
    if prior:
        # Never trust a cached scene merely because its request key matches:
        # an interrupted layer migration can leave duplicate IDs in an older
        # payload.  The phase-transport receipt is also part of the current
        # object contract; old caches must rebuild once instead of bypassing
        # the exact Book/Unified binding path below.
        if _cached_scene_contract_ready(prior):
            return prior
    if cutoff:
        from .build_archive_window_snapshot import build_archive_window
        from .audit_archive_window_ownership import audit
        from .live_structure_graph import NativeStructureGraph, PERIODS
        payload = build_archive_window(cutoff, tf, count, week_start='sunday')
        # The archive payload supplies rulers but not the main-chart whole
        # force review. Without this, the adapter silently used legacy short
        # impulse segments, contrary to the user's first opposite wave rule.
        from .live_force_wave_review import build_force_wave_review, visible_force_waves
        force_review = build_force_wave_review(payload['snapshot'], tf,
            include_response_evidence=True)
        # Display structural observations separately from strength admission.
        # The old provisional coverage screen can reject every whole wave;
        # keep genuine node-break observations with explicit pending strength.
        force_review['qualified_force_wave_candidates'] = visible_force_waves(force_review, cutoff)
        # The first opposite response is a visible, read-only observation even
        # when provisional strength or outer-node break is not yet proven.
        # This is the missing case for a counter-low-liquidity trend: do not
        # erase the first reverse segment merely because it is not yet a
        # qualified force wave. Keep the qualification fields explicit.
        observations = dict(force_review,
            force_wave_candidates=force_review.get('first_response_candidates', []))
        force_review['force_wave_candidates'] = visible_force_waves(observations, cutoff)
        payload['reviews'][tf]['force_wave_review'] = force_review
        inspected = audit(payload, tf)
        if inspected['packet_errors']:
            raise ValueError('archive packet identity failed')
        rejected = {r['projection_id'] for r in inspected['failed']}
        for family in payload['reviews'][tf]['regime_measurement_review']['families']:
            family['projections'] = [p for p in family['projections'] if p['projection_id'] not in rejected]
        if not audit(payload, tf)['valid_for_delivery']:
            raise ValueError('archive quarantine failed')
        snapshot = payload['snapshot']
        snapshot['analysis_report'] = dict(timeframes=list(snapshot['timeframe_states'].values()))
        snapshot['archive_chart_delivery'] = dict(reviews=payload['reviews'])
        native = NativeStructureGraph(snapshot)
        graph = dict(snapshot_id=snapshot['snapshot_id'], period_structure_timelines={t:native.structure_timeline(t) for t in PERIODS})
    else:
        snapshot = json.loads((PACKAGE/'live_main_one_to_one.json').read_text(encoding='utf8'))
        graph = json.loads(gzip.decompress((PACKAGE/'live_main_structure_background.json.gz').read_bytes()))
        if graph['main_revision'] != snapshot['main_one_to_one_delivery']['revision']:
            raise ValueError('published graph is from another revision')
    OUTPUT.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=OUTPUT) as tmp:
        source = Path(tmp)/'input.json'
        source.write_text(json.dumps(dict(snapshot=snapshot, graph=graph, timeframe=tf)), encoding='utf8')
        result = subprocess.run([shutil.which('node'),str(ROOT/'src/mt5_scene_adapter.js'),str(source)],capture_output=True,text=True,encoding='utf8',timeout=180,
                                creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if result.returncode:
            raise RuntimeError(result.stderr[-4000:])
        scene = json.loads(result.stdout)
    if cutoff:
        scene['quarantine'] = inspected['failed']
        from .mt5_ict_adapter import attach_ict
        if display_mode in ('all','ict'):
            attach_ict(scene)
    validate(scene)
    from .mt5_structure_logic import attach_logic
    attach_logic(scene)
    # The Trend Trade Method layer is a separate, source-traced read-only
    # projection.  It consumes only this scene's closed native bars and never
    # changes the existing structure objects or execution path.
    from .trend_trade_method_full_pipeline import (build_book_logic_evidence,
                                                    scene_objects,
                                                    same_chart_wave_degree_objects,
                                                    multitimeframe_turning_line_objects,
                                                    period_profile,
                                                    period_profile_contract,
                                                    multitimeframe_stop_reference_objects)
    native_bars = (snapshot.get('chart_history', {}).get(tf, {}).get('bars', [])
                   if isinstance(snapshot, dict) else [])
    # Historical rendering now records a replay receipt from the same
    # confirmed-prefix kernel used by the broker worker.  Unified geometry
    # remains its own layer; this receipt prevents a second, hidden history
    # calculator from becoming the source of truth for the Book base window.
    from .realtime_calculation_engine import history_replay_receipt
    scene['realtime_kernel'] = history_replay_receipt(
        native_bars, tf, scene.get('cutoff_utc') or cutoff or snapshot.get('as_of_utc'),
        snapshot.get('provider', 'archive') if isinstance(snapshot, dict) else 'archive',
        snapshot.get('instrument', 'XAUUSD') if isinstance(snapshot, dict) else 'XAUUSD',
        revision,
    )
    unified_geometry = []
    for obj in scene.get('objects', []):
        record=_unified_geometry_record(obj)
        if record is not None:
            unified_geometry.append(record)
    scene['book_logic'] = build_book_logic_evidence(
        native_bars, tf, scene.get('cutoff_utc', cutoff),
        unified_geometry=unified_geometry)
    # Bind the Book-selected native source as a separate, read-only fact layer.
    # This consumes the fully built Book packet but never selects an owner from
    # score, replaces a ruler, mutates objects, or grants execution permission.
    scene = attach_book_trend_binding_shared(scene)
    scene['book_logic']['unified_phase_transport_contract']=PHASE_TRANSPORT_CONTRACT
    scene['book_logic']['unified_phase_transport_applied']=0
    rebound_geometry=[_bind_unified_phase_from_book(scene,record) for record in unified_geometry]
    exact_count=sum(1 for record in rebound_geometry
                    if record.get('phase_binding')=='exact_book_ruler' and record.get('phase_id'))
    candidate_count=len(rebound_geometry)
    book_binding_state=(scene.get('book_trend_binding') or {}).get('state')
    if exact_count:
        summary_state='exact_bindings_applied'
    elif candidate_count:
        summary_state='no_exact_book_ruler_binding'
    elif book_binding_state!='bound':
        summary_state='no_unified_geometry_candidates_book_binding_unknown'
    else:
        summary_state='no_unified_geometry_candidates'
    scene['book_logic']['unified_phase_transport_summary']=dict(
        schema='unified_book_phase_transport_summary_v1',
        candidate_count=candidate_count,exact_binding_count=exact_count,
        withheld_count=candidate_count-exact_count,
        book_binding_state=book_binding_state,state=summary_state,
        automatic_trade_permission=False,entry_permission=False)
    if rebound_geometry != unified_geometry:
        # The first Book pass is needed to construct/validate the native
        # binding.  Once that exact binding exists, refresh only the decision
        # consumer with phase-bound Unified candidates; do not rebuild the
        # Book ruler or let a score select the owner.
        from .book_realtime_decision import observe_entry
        from .book_plan_summary import plan_summary
        unified_geometry=rebound_geometry
        refreshed=observe_entry(native_bars,tf,scene.get('cutoff_utc',cutoff),
                                scene['book_logic'],unified_geometry=unified_geometry)
        scene['book_logic']['realtime_entry_decision']=refreshed
        scene['book_logic']['author_review_context']=deepcopy(refreshed.get('author_review_context') or {})
        scene['book_logic']['display_plan']=plan_summary(
            {'timeframe':tf,'cutoff_utc':scene.get('cutoff_utc',cutoff),
             'book_logic':scene['book_logic']})
        scene['book_logic']['unified_geometry_input_count']=len(unified_geometry)
        scene['book_logic']['unified_phase_transport_applied']=_transport_bound_unified_phase(
            scene,rebound_geometry)
    scene['objects'].extend(scene_objects(scene['book_logic'], native_bars, tf))
    scene['objects'].extend(same_chart_wave_degree_objects(
        native_bars, tf, scene.get('cutoff_utc', cutoff)))
    scene['objects'].extend(multitimeframe_turning_line_objects(
        snapshot, tf, scene.get('cutoff_utc', cutoff)))
    from .book_wave_inventory import load_book_context, historical_book_objects
    book_context=load_book_context(tf,scene.get('cutoff_utc',cutoff),native_bars)
    historical, inventory=historical_book_objects(book_context,tf,scene.get('cutoff_utc',cutoff),scene['objects'])
    scene['objects'].extend(historical)
    scene['book_wave_inventory']=inventory
    # A trend ruler can qualify before its chapter-4 C/D/E construction.
    # Supplement only that missing drawing; do not alter calibrated sources.
    from .book_late_turning import late_turning_objects
    late_turning, late_audit = late_turning_objects(
        book_context, tf, scene.get('cutoff_utc',cutoff), scene['objects'])
    scene['objects'].extend(late_turning)
    scene['book_late_turning_inventory'] = late_audit
    # Structural selection owns all pivots in one native-period swing chain.
    # Exact accepted legacy geometries are deduplicated, never bulk-deleted.
    from .book_structural_anchors import structural_wave_objects
    structural, structural_audit = structural_wave_objects(
        book_context, tf, scene.get('cutoff_utc',cutoff), scene['objects'])
    scene['objects'].extend(structural)
    scene['book_structural_anchor_audit'] = structural_audit
    # Transport PDF49/50 receipts only after the Book structural layer exists.
    # Canonical native wave identity, timeframe and as-of clock are all
    # required; geometric overlap or a shared label cannot bind the exception.
    neckline_index=_native_neckline_receipts(scene,tf,scene.get('cutoff_utc',cutoff))
    unified_geometry=_transport_native_neckline_receipts(
        unified_geometry,neckline_index,tf,scene.get('cutoff_utc',cutoff))
    rebound_geometry=[_bind_unified_phase_from_book(scene,record) for record in unified_geometry]
    scene['book_logic']['native_neckline_receipt_transport']=dict(
        schema='book_unified_native_neckline_transport_v1',
        candidate_count=len(unified_geometry),
        exact_canonical_count=sum(1 for r in unified_geometry if r.get('native_neckline_receipts')),
        receipt_count=sum(len(r.get('native_neckline_receipts',[])) for r in unified_geometry),
        source_objects=sum(len(v) for v in neckline_index.values()),
        no_exact_book_wave_count=sum(1 for r in unified_geometry if
                                     r.get('neckline_receipt_transport',{}).get('state')=='no_exact_book_wave'),
        automatic_trade_permission=False,entry_permission=False,
        state='exact_canonical_wave_only')
    # Geometry can stop at a wick while the frozen ruler remains observable.
    # Keep later close-through facts separate from calibrated force sources.
    from .book_boundary_events import boundary_event_objects
    boundary_events, boundary_audit = boundary_event_objects(
        book_context, tf, scene.get('cutoff_utc',cutoff), scene['objects'])
    scene['objects'].extend(boundary_events)
    scene['book_boundary_event_audit'] = boundary_audit
    # Rebind the score packet only after native structural-wave objects exist.
    # The adapter and Book producers use a canonical ID derived from the same
    # confirmed pivot-time sequence; no time-nearness or chart overlap is
    # accepted as ownership.  A missing phase or exact sequence remains
    # unknown and contributes no composite vote.
    native_wave_candidates=[]
    for obj in scene.get('objects',[]):
        evidence=obj.get('evidence') or {}
        if evidence.get('canonical_wave_id') and evidence.get('source_timeframe')==tf:
            native_wave_candidates.append({
                'object_id':obj.get('id'),'wave_id':evidence.get('wave_id'),
                'canonical_wave_id':evidence.get('canonical_wave_id'),
                'wave_lineage_id':evidence.get('canonical_wave_lineage_id'),
                'direction':evidence.get('direction'),
                'pivot_times':evidence.get('pivot_times'),
                'pivot_roles':evidence.get('pivot_roles'),
                'known_at_utc':obj.get('known_at_utc'),
                'display_role':evidence.get('display_role'),
            })
    scene['book_logic']['native_wave_candidates']=native_wave_candidates
    if unified_geometry:
        from .book_realtime_decision import observe_entry
        refreshed=observe_entry(native_bars,tf,scene.get('cutoff_utc',cutoff),
                                scene['book_logic'],unified_geometry=unified_geometry)
        scene['book_logic']['realtime_entry_decision']=refreshed
        scene['book_logic']['author_review_context']=deepcopy(refreshed.get('author_review_context') or {})
    scene['book_logic']['period_profile'] = period_profile(tf)
    scene['display_alignment']['book_period_profile'] = period_profile_contract(tf)
    scene['display_alignment']['book_logic_contract_schema'] = 'trend_trade_method_mt5_logic_contract_v1'
    # Preserve the same-as-of B-point stop ladder for all native periods in
    # every scene.  Parent-period references remain metadata; they are not
    # projected onto the selected timeframe's price coordinates.
    stop_index = OUTPUT / 'multitimeframe_stop_reference_index_20261019.json'
    if stop_index.exists():
        try:
            ladder = json.loads(stop_index.read_text(encoding='utf-8'))
            if ladder.get('as_of_utc') == scene.get('cutoff_utc'):
                scene['multitimeframe_stop_reference'] = ladder
        except (OSError, ValueError, TypeError):
            scene['multitimeframe_stop_reference'] = {
                'status': 'unknown', 'reason': 'stop_reference_index_unavailable',
                'read_only': True, 'trade_permission': False,
            }
    # Tile workers render many as-of clocks.  If the frozen audit index does
    # not match this scene, keep the stop-reference display alive from the
    # scene's own closed native bars and explicitly mark B-point ownership
    # unknown rather than reusing a different clock's level.
    if not isinstance(scene.get('multitimeframe_stop_reference'), dict) or \
            scene.get('multitimeframe_stop_reference', {}).get('as_of_utc') != scene.get('cutoff_utc', cutoff):
        dynamic_ladder = _dynamic_snr_stop_ladder(snapshot, scene.get('cutoff_utc', cutoff))
        if dynamic_ladder:
            scene['multitimeframe_stop_reference'] = dynamic_ladder
    ladder = scene.get('multitimeframe_stop_reference')
    if isinstance(ladder, dict) and ladder.get('periods'):
        # A persisted scene may already contain parent-period SNR objects from
        # an earlier engine revision.  Remove only those parent projections;
        # keep same-period B/SNR lines from scene_objects() and rebuild the
        # parent set from the current ladder so merged source labels cannot
        # coexist with their old unmerged duplicates.
        scene['objects'] = [obj for obj in scene.get('objects', [])
                            if not (obj.get('layer') == 'stop_reference'
                                    and obj.get('source_timeframe')
                                    and obj.get('source_timeframe') != tf)]
        mtf_objects = multitimeframe_stop_reference_objects(
            ladder, native_bars, tf, scene.get('cutoff_utc', cutoff))
        scene['objects'].extend(mtf_objects)
        # Keep the display contract inspectable without parsing labels.  This
        # is deliberately derived from the projected objects, so a merged
        # shelf is counted once while its source periods remain in the object
        # evidence.  The MT5 button remains a single read-only SNR layer.
        source_timeframe_counts = {}
        same_period_snr_objects = 0
        parent_period_snr_objects = 0
        for obj in scene.get('objects', []):
            if obj.get('layer') != 'stop_reference':
                continue
            source_tfs = obj.get('source_timeframes') or [obj.get('source_timeframe')]
            # B-point/adjustment lines also live in stop_reference, but they
            # do not carry the SNR marker.  Count only actual SNR shelves so
            # the MT5 display contract cannot call every stop line SNR.
            is_snr = obj.get('snr_side') is not None or '止损参考 SNR' in str(obj.get('label', ''))
            if is_snr:
                if tf in source_tfs:
                    same_period_snr_objects += 1
                if any(source_tf and source_tf != tf for source_tf in source_tfs):
                    parent_period_snr_objects += 1
            for source_tf in (obj.get('source_timeframes') or
                              [obj.get('source_timeframe')]):
                if source_tf:
                    source_timeframe_counts[source_tf] = (
                        source_timeframe_counts.get(source_tf, 0) + 1)
        scene['stop_reference_display'] = {
            'multitimeframe_snr_objects': len(mtf_objects),
            'same_period_snr_objects': same_period_snr_objects,
            'parent_period_snr_objects': parent_period_snr_objects,
            'snr_objects_total': same_period_snr_objects + parent_period_snr_objects,
            'periods_considered': [row.get('timeframe') for row in ladder.get('periods', [])],
            'snr_source_periods': sorted(source_timeframe_counts),
            'snr_source_period_count': len(source_timeframe_counts),
            'as_of_utc': scene.get('cutoff_utc', cutoff),
            'source_timeframe_counts': source_timeframe_counts,
            'display_role': 'multi_period_snr_stop_reference',
            'read_only': True, 'trade_permission': False,
        }
    # The scene protocol requires globally unique IDs.  This final guard is
    # intentionally deterministic: if a stale cached tile duplicated an
    # identical object, retain its first causal record and reject the second
    # copy rather than publishing a visually doubled line.
    unique_objects = []
    seen_ids = set()
    for obj in scene.get('objects', []):
        if obj.get('id') in seen_ids:
            continue
        seen_ids.add(obj.get('id'))
        unique_objects.append(obj)
    scene['objects'] = unique_objects
    validate(scene)
    scene['foundation_ladder_context'] = _foundation_ladder_context(cutoff)
    scene['foundation_context'] = scene['foundation_ladder_context'].get(tf) or _foundation_context(tf, cutoff)
    from .pdf_trendline_block import scene_block
    scene['pdf_trendline_block'] = scene_block(scene, scene['foundation_context'])
    context_ref = {
        'timeframe': scene['foundation_context'].get('timeframe'),
        'as_of_utc': scene['foundation_context'].get('as_of_utc'),
        'state': scene['foundation_context'].get('state'),
        'direction': scene['foundation_context'].get('direction'),
        'direct_parent': scene['foundation_context'].get('direct_parent'),
        'joint_status': (scene['foundation_context'].get('joint_context') or {}).get('status'),
        'joint_alignment': (scene['foundation_context'].get('joint_context') or {}).get('alignment'),
        'trade_permission': False,
    }
    # Every displayed force line/box carries the same as-of background pointer
    # as the scene. This keeps a selected object reviewable without relying on
    # mutable chart state or a later snapshot tail.
    for obj in scene.get('objects', []):
        if obj.get('layer') != 'force':
            continue
        obj.setdefault('evidence', {})['foundation_context_ref'] = dict(context_ref)
    scene['display_alignment']['foundation_background_rule'] = 'foundation_background_v1'
    scene['display_alignment']['foundation_context_as_of'] = scene['foundation_context'].get('as_of_utc')
    scene['display_alignment']['foundation_ladder_period_count'] = len(scene['foundation_ladder_context'])
    scene['display_alignment']['foundation_trade_permission'] = False
    scene['display_alignment']['pdf_trendline_block_rule'] = 'trend_trade_method_pdf_ch3_ch4_outer_wave_v1'
    # Four's integrated case is a frozen, same-clock reference projection. It
    # is attached only to the M5 scene at its own as-of clock; other tiles keep
    # the metadata boundary without borrowing future evidence.
    from .wells4_reference_adapter import attach_reference_case
    attach_reference_case(scene)
    from .mt5_force_strength import attach_mt5_force_strength
    attach_mt5_force_strength(scene, book_context)
    # Join the already computed parent, measurement, three-push, force and
    # channel facts at this exact scene clock.  This reducer is read-only and
    # keeps missing/uncalibrated evidence explicit; it never grants a trade.
    from .integrated_market_logic import attach_integrated_logic
    from .gobi_digger_context import attach_context
    archive_provenance = snapshot.get('archive_window_provenance') or {}
    attach_context(scene, {name: history.get('bars', []) for name, history in snapshot.get('chart_history', {}).items()},
        source_id=snapshot['snapshot_id'],
        calendar=dict(timezone='UTC' if cutoff else 'unknown', day_boundary='00:00' if cutoff else 'unknown',
                      week_start=archive_provenance.get('week_start', 'unknown'),
                      bar_time_basis=archive_provenance.get('bar_time_basis', 'provider_native')))
    attach_integrated_logic(scene)
    scene['engine_revision']=revision
    scene['archive_revision']=data_revision
    scene['analysis_policy']={'context_bars_per_period':count,'closed_bars_only':True,'zoom_changes_analysis':False,
        'note':'Context is fixed per request endpoint; earlier history remains accessible by scrolling. Unknown earlier ownership is not inferred.'}
    if engine_revision()!=revision:
        raise EngineRevisionChanged('Source changed during calculation; scene was not cached')
    save(scene,key)
    return scene


def build_view(tf,cutoff,visible_bars=1024,still_current=lambda:True):
    """Wide views compose fixed-size scenes, never re-run a giant strategy window.

    Historical tiles retain their original evaluation clocks. They are not
    retroactively relabelled as decisions at the right edge of the overview.
    """
    from .build_archive_window_snapshot import load_prefix, mt5_weekly_prefix
    from .mt5_scene_store import save
    latest=build_scene(tf,cutoff,1024)
    if visible_bars<=1024:return latest
    end=datetime.fromisoformat(cutoff.replace('Z','+00:00')).timestamp()
    catalog=json.loads((ARCHIVE/'catalog.json').read_text(encoding='utf8'))
    dataset=next(d for d in catalog['datasets'] if d['id']=='HistData')
    # Wide archive views are allowed to span the entire imported period;
    # fixed-size components still keep each calculation bounded.
    count=max(1,int(visible_bars))
    rows=mt5_weekly_prefix(dataset,end,count) if tf=='W1' else load_prefix(dataset['periods'][tf],end,count)
    components=[latest]
    for offset in range(512,len(rows),512):
        if not still_current():raise InterruptedError('viewport superseded')
        at=datetime.fromtimestamp(float(rows[-offset-1,0])+TIMEFRAME_MINUTES[tf]*60,timezone.utc).isoformat()
        components.append(build_scene(tf,at,1024))
    result=json.loads(json.dumps(latest));result.pop('scene_id',None)
    result['component_scene_ids']=[s['scene_id'] for s in components]
    merged={}
    for component in reversed(components):
        for obj in component['objects']:
            merged[obj['id']]=dict(obj,evaluated_at_utc=component['cutoff_utc'],component_scene_id=component['scene_id'])
    from .mt5_history_tiles import _compact_force_channels
    result['objects']=_compact_force_channels(list(merged.values()))
    result['coverage']=dict(latest['coverage'],bars=len(rows),from_epoch=float(rows[0,0]),historical_tiles=len(components),
        overview_semantics='objects retain individual historical evaluation clocks; replay reads component scenes')
    result['coverage']['from']=datetime.fromtimestamp(float(rows[0,0]),timezone.utc).isoformat()
    validate(result);save(result)
    return result


def validate(scene):
    if scene['schema']!='machine1_scene_v1' or scene['automatic_trade_permission'] is not False or scene['order_api_called'] is not False:
        raise ValueError('invalid scene contract')
    cutoff = datetime.fromisoformat(scene['cutoff_utc'].replace('Z','+00:00'))
    ids = set()
    for object_index, obj in enumerate(scene['objects']):
        if obj['id'] in ids or obj['timeframe']!=scene['timeframe']:
            raise ValueError('duplicate or foreign object')
        if not isinstance(obj['id'], str) or len(obj['id']) != 24:
            raise ValueError('invalid MT5 object id length')
        ids.add(obj['id'])
        if datetime.fromisoformat(obj['known_at_utc'].replace('Z','+00:00'))>cutoff:
            raise ValueError('future knowledge')
        if obj['layer'] not in ('zigzag','one_to_one','three_push','force','ict','trend','wave','channel','turning_point','breakout','pullback','invalidation','candlestick','chart_pattern','stop_reference','risk_fact'):
            raise ValueError('unknown layer')
        points=obj['points']
        if (len(points)!=2 or
                any(len(p)!=2 or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in p) for p in points) or
                points[1][0]<points[0][0]):
            raise ValueError(
                f"invalid geometry at object {object_index} "
                f"id={obj.get('id')} layer={obj.get('layer')} "
                f"kind={obj.get('kind')} points={points!r}"
            )
        if obj['kind'] not in ('box','line','band'):raise ValueError('unknown geometry')
        evidence=obj.get('evidence',{})
        if obj['layer']=='one_to_one' and 'projection' in evidence:
            record=evidence['record'];projection=evidence['projection'];owner=evidence['ownership']
            a,b,c=record['source_origin'],record['source_terminal'],projection['anchor']
            clock=lambda p:datetime.fromisoformat((p.get('pivot_timestamp_utc') or p['timestamp_utc']).replace('Z','+00:00'))
            ra=owner.get('retraced_wave_origin') or {};rb=owner.get('retraced_wave_terminal') or {}
            signed=b['price']-a['price']
            try:
                owned_return=(signed!=0 and clock(a)<clock(b)<clock(c) and clock(ra)<clock(rb)<clock(c) and
                    (rb['price']-ra['price'])*signed>0 and (rb['price']-c['price'])*signed>0 and
                    (c['price']-a['price'])*signed>0 and clock(c)<=cutoff and
                    bool(owner.get('retraces_source_leg_id')) and
                    owner.get('retraces_source_leg_id')==projection.get('retraces_source_leg_id') and
                    all(datetime.fromisoformat(x['known_at_utc'].replace('Z','+00:00'))<=cutoff
                        for x in (record,projection,owner)))
            except (KeyError,TypeError,ValueError):
                owned_return=False
            # Original A-B is the ruler length; a later C retraces its own
            # named previous wave, which can extend beyond original B.
            if not (owned_return
                    and owner['measurement_source_leg_id']==record['source_leg_id'] and owner['native_timeframe']==scene['timeframe']
                    and abs(projection['target']-(c['price']+b['price']-a['price']))<1e-7
                    and abs(points[1][1]-projection['target'])<1e-7):
                raise ValueError('direct extension or borrowed C rejected')
    context=scene.get('execution_context',{})
    for tf,bars in [(scene['timeframe'],context.get('bars',[])),(context.get('parent_timeframe'),context.get('parent_bars',[]))]:
        if not tf:continue
        for bar in bars:
            closed=datetime.fromisoformat(bar['timestamp_utc'].replace('Z','+00:00')).timestamp()+TIMEFRAME_MINUTES[tf]*60
            if closed>cutoff.timestamp():raise ValueError('unclosed input candle')


def publish(scene, token, destination=COMMON):
    if not re.fullmatch(r'[0-9_]+',token):
        raise ValueError('invalid request token')
    if scene['provider']!='HistData':
        raise ValueError('broker snapshot cannot be published onto research symbol')
    validate(scene)
    if Path(destination)==COMMON and scene.get('book_trend_binding'):
        from .book_trend_binding_checkpoint import persist_published_binding
        shared_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        # Keep the immutable scene payload/hash unchanged; the publication
        # receipt is a separate checkpoint artifact.
        persist_published_binding(scene, destination, shared_consumer_source_sha256=shared_hash)
    # Complete footer makes truncated/partially read packets non-actionable.
    lines=[f"M1SCENE\t2\t{token}\t{SYMBOL}\t{scene['timeframe']}\t{len(scene['objects'])}"]
    for o in scene['objects']:
        a,b=o['points']
        values=[o['id'],o['layer'],o['kind'],int(a[0]),a[1],int(b[0]),b[1],o['status'],o['owner_id'],o.get('group',''),o.get('label','')]
        lines.append('\t'.join(str(v).replace('\t',' ').replace('\n',' ').replace('\r',' ') for v in values))
    lines.append(f"END\t{token}\t{len(scene['objects'])}")
    raw=json.dumps(scene,ensure_ascii=False,allow_nan=False).encode('utf8')
    from .book_plan_summary import plan_packet
    plan=plan_packet(scene,token)
    tsv=('\n'.join(lines)+'\n').encode('utf8')
    publication_files={'json':raw,'tsv':tsv,'bookplan.tsv':plan}
    if scene.get('gobi_digger_producer'):
        from .gobi_digger_transport import packet as indicator_packet
        publication_files['gobidigger.tsv']=indicator_packet(scene,token,SYMBOL)
    atomic(destination/f'{token}.bookplan.tsv',plan)
    reference = scene.get('wells4_reference') or {}
    panel_lines = reference.get('panel_lines') or []
    if panel_lines:
        rows = [f"W4REF\t1\t{token}\t{reference.get('source_sha256','')}\t{reference.get('status','unknown')}"]
        rows.extend(str(line).replace('\t', ' ').replace('\r', ' ').replace('\n', ' ') for line in panel_lines)
        reference_raw=('\n'.join(rows) + '\n').encode('utf8')
        publication_files['wells4.tsv']=reference_raw
        atomic(destination/f'{token}.wells4.tsv',reference_raw)
    from .mt5_publication_files import write_publication_files
    write_publication_files(destination,token,scene.get('scene_id'),publication_files,atomic)
    atomic(destination/f'{token}.json',raw)
    atomic(destination/f'{token}.tsv',tsv)
    if Path(destination)==COMMON:
        atomic(OUTPUT/'latest-scene.json',raw)


def export_history(destination=COMMON):
    import numpy as np
    catalog=json.loads((ARCHIVE/'catalog.json').read_text(encoding='utf8'))
    period=next(d for d in catalog['datasets'] if d['id']=='HistData')['periods']['M1']
    destination.mkdir(parents=True,exist_ok=True)
    target=destination/'HistData_M1.bin'
    fd,name=tempfile.mkstemp(dir=destination,prefix='history-')
    count=0; previous=-1; sha=hashlib.sha256(); first=None
    try:
        with os.fdopen(fd,'wb') as f:
            for chunk in period['chunks']:
                raw=gzip.decompress((ARCHIVE/chunk['file']).read_bytes())
                rows=np.frombuffer(raw,dtype='<f8').reshape(-1,6)
                if not len(rows):continue
                if not np.isfinite(rows[:,:5]).all() or rows[0,0]<=previous or np.any(np.diff(rows[:,0])<=0):
                    raise ValueError('invalid archive order')
                if np.any(rows[:,2]<np.maximum(rows[:,1],rows[:,4])) or np.any(rows[:,3]>np.minimum(rows[:,1],rows[:,4])):
                    raise ValueError('invalid archive OHLC')
                first=first or int(rows[0,0]);previous=int(rows[-1,0]);count+=len(rows)
                f.write(raw);sha.update(raw)
        if count!=period['rows']:raise ValueError('archive count mismatch')
        os.replace(name,target)
    finally:
        if os.path.exists(name):os.unlink(name)
    receipt=dict(symbol=SYMBOL,provider='HistData',time_basis='UTC',bars=count,start_epoch=first,end_epoch=previous,sha256=sha.hexdigest(),bytes=target.stat().st_size,trade_enabled=False)
    atomic(destination/'history-manifest.json',json.dumps(receipt,indent=2).encode())
    atomic(OUTPUT/'history-manifest.json',json.dumps(receipt,indent=2).encode())
    return receipt


def _process_alive(pid):
    """Read-only liveness probe, including on Windows (never os.kill)."""
    import psutil
    if pid <= 0:
        return False
    try:
        process = psutil.Process(pid)
        return process.is_running() and process.status() != psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        return False
    except psutil.AccessDenied:
        # A process we cannot inspect is not evidence of an abandoned guard.
        return True


def worker():
    COMMON.mkdir(parents=True,exist_ok=True)
    # The historical worker is a single-writer service.  msvcrt byte locks
    # are not reliable across the mixed venv/Anaconda launchers used on this
    # machine, so also claim an explicit PID guard with O_EXCL.
    import os, time
    guard=COMMON/'worker.pid'
    try:
        fd=os.open(str(guard),os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError:
        # A crashed worker can leave the PID file behind.  Do not make a
        # replacement wait for the twelve-hour stale-file window: validate
        # the recorded process first, then only retain the guard when that
        # process is actually alive.  This keeps the single-writer contract
        # while allowing a safe recovery after a terminal/python crash.
        live=False
        try:
            recorded=int(guard.read_text(encoding='ascii').strip())
            if recorded>0 and recorded!=os.getpid():
                live=_process_alive(recorded)
        except (OSError,ValueError):
            live=False
        if live:
            print('Machine1 worker already claimed; exiting duplicate',flush=True)
            return
        try:
            age=time.time()-guard.stat().st_mtime
        except OSError:
            age=0
        # The age is retained as an audit field, but a non-live PID is safe
        # to reclaim immediately.  Only an unreadable guard with a recent
        # timestamp remains conservative.
        if age < 12*3600 and live:
            print('Machine1 worker already claimed; exiting duplicate',flush=True)
            return
        try: guard.unlink()
        except OSError: return
        fd=os.open(str(guard),os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    os.write(fd,str(os.getpid()).encode('ascii'));os.close(fd)
    restart=False
    try:
        from .mt5_scene_store import engine_revision
        loaded_revision=engine_revision()
        from .mt5_history_tiles import run_worker
        lock=(COMMON/'worker.lock').open('a+b')
        restart=run_worker(lock,loaded_revision)=='engine_changed'
    finally:
        try: guard.unlink()
        except OSError: pass
    if restart:
        import sys
        subprocess.Popen([sys.executable,'-m','src.mt5_unified_backend','worker'],
            cwd=str(ROOT),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))



def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['history','scene','worker']);p.add_argument('--timeframe',default='M15');p.add_argument('--cutoff');p.add_argument('--count',type=int,default=2048);a=p.parse_args()
    OUTPUT.mkdir(parents=True,exist_ok=True)
    if a.action=='history':print(json.dumps(export_history()))
    elif a.action=='worker':worker()
    else:
        scene=build_scene(a.timeframe,a.cutoff,a.count)
        atomic(OUTPUT/f'scene-{a.timeframe}.json',json.dumps(scene,ensure_ascii=False).encode())
        print(json.dumps(dict(objects=len(scene['objects']),layers={k:sum(o['layer']==k for o in scene['objects']) for k in ['zigzag','one_to_one','three_push','force']},rejected=len(scene['rejections']))))


if __name__=='__main__':main()

