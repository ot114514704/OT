"""Copy native chapter4 objects to another chart without rebuilding anchors."""
from copy import deepcopy
from hashlib import sha256
import json
from .book_first_response_leg import clock,close_time


def shared_utc_scope(source_rows,chart_rows,source_tf,chart_tf,cutoff):
    """Evidence for already-normalized snapshot UTC; no broker offset inference."""
    try:
        groups=[[r for r in rows if clock(close_time(r,tf))<=clock(cutoff)]
                for rows,tf in ((source_rows,source_tf),(chart_rows,chart_tf))]
        if any(not rows for rows in groups):return None
        identities=set()
        for rows,tf in zip(groups,(source_tf,chart_tf)):
            for row in rows:
                if not row.get('provider') or not row.get('symbol') or row.get('timeframe')!=tf:return None
                if clock(row['timestamp_utc']).utcoffset().total_seconds()!=0:return None
                identities.add((row['provider'],row['symbol']))
        if len(identities)!=1:return None
        provider,symbol=next(iter(identities))
        identity=f'{provider}|{symbol}|normalized_snapshot_UTC'
        digest=sha256(json.dumps(groups,sort_keys=True).encode()).hexdigest()
        return dict(provider=provider,symbol=symbol,source_clock_id=identity,chart_clock_id=identity,
            clock_evidence_id='snapshot_utc_rows:'+digest,
            clock_basis='matching_row_provider_symbol_explicit_UTC_not_offset_inference',
            reaggregated=False,anchors_snapped=False)
    except (KeyError,ValueError,TypeError,AttributeError):return None


def chapter4_lineage_receipt(obj):
    """Expose the named chapter-4 construction without re-selecting it.

    A copied RETURN_CE_D line is the C--E source rail shifted to D; a
    RESUME_DF_C line is the D--F rail shifted to the *original* C.  The
    generic ruler identity is geometrically enough to draw a line, but not
    enough for a chart user or a packet auditor to know which point has which
    role.  This receipt only transports those frozen identities.  It neither
    recalculates an anchor nor treats the roles as author-wave confirmation.
    """
    ev = obj.get('evidence') or {}
    family = ev.get('family') or obj.get('family')
    identity = deepcopy(ev.get('ruler_identity'))
    common = dict(schema='chapter4_named_role_lineage_v1', family=family,
                  native_timeframe=ev.get('native_timeframe') or obj.get('timeframe'),
                  construction_known_at_utc=ev.get('construction_known_at_utc'),
                  display_known_at_utc=ev.get('display_known_at_utc'),
                  state_known_at_utc=ev.get('state_known_at_utc'),
                  author_wave_degree=ev.get('author_wave_degree', 'unknown'),
                  author_confirmation=ev.get('author_confirmation',
                                               'not_granted_by_geometry'),
                  automatic_trade_permission=False,
                  transport_status='frozen_native_roles_transported_not_reselected')
    if not isinstance(identity, list) or len(identity) != 3:
        return dict(common, status='identity_incomplete', named_roles=[])
    if family == 'RETURN_CE_D':
        roles = [
            dict(role='C', native_index=ev.get('extension_start_index'), time_price=identity[0],
                 source_field='extension_start'),
            dict(role='E', native_index=ev.get('extension_end_index'), time_price=identity[1],
                 source_field='extension_end'),
            dict(role='D', native_index=ev.get('shift_anchor_index'), time_price=identity[2],
                 source_field='shift_anchor'),
        ]
        source = ev.get('source_CE_observation') or {}
        return dict(common, status='C_E_shifted_to_D', named_roles=roles,
                    native_order='C<D<E',
                    source_observation=dict(status=source.get('status'),
                                            known_at_utc=source.get('known_at_utc'),
                                            observed_through_utc=source.get('observed_through_utc'),
                                            source_reassessment_required=source.get('source_reassessment_required')),
                    terminal_event_names=[])
    if family == 'RESUME_DF_C':
        roles = [
            dict(role='D', native_index=ev.get('extension_start_index'), time_price=identity[0],
                 source_field='extension_start'),
            dict(role='F', native_index=ev.get('extension_end_index'), time_price=identity[1],
                 source_field='extension_end'),
            dict(role='C', native_index=ev.get('shift_anchor_index'), time_price=identity[2],
                 source_field='original_shift_anchor'),
            dict(role='E', native_index=ev.get('source_E_index'), time_price=None,
                 source_field='original_source_E'),
        ]
        events = ev.get('terminal_events') or []
        return dict(common, status='D_F_shifted_to_original_C', named_roles=roles,
                    native_order='C<D<E<F',
                    source_observation=dict(source_E_index=ev.get('source_E_index'),
                                            target_fill_confirmed=ev.get('target_fill_confirmed', False),
                                            event_order=ev.get('event_order')),
                    terminal_event_names=[e.get('event') for e in events if isinstance(e, dict)])
    return dict(common, status='not_chapter4_named_role_family', named_roles=[])


def chapter4_lineage_errors(obj, rows, source_timeframe, *, require_receipt=False):
    """Check named roles against the exact native bars, without repairing them.

    This deliberately returns stable error codes rather than choosing a new
    C/D/E/F point.  The caller can therefore withhold a bad source or copy
    while retaining the original evidence for review.
    """
    ev = obj.get('evidence') or {}
    family = ev.get('family') or obj.get('family')
    if family not in ('RETURN_CE_D', 'RESUME_DF_C'):
        return []
    errors=[]
    identity=ev.get('ruler_identity')
    if not isinstance(identity,list) or len(identity)!=3:
        return ['CH4_RULER_IDENTITY_INCOMPLETE']
    try:
        if not isinstance(rows,list) or not rows:
            raise ValueError('CH4_NATIVE_ROWS_MISSING')
        epochs=[clock(row['timestamp_utc']).timestamp() for row in rows]
        if any(b<=a for a,b in zip(epochs,epochs[1:])):
            raise ValueError('CH4_NATIVE_ROWS_UNORDERED')
        direction=ev.get('direction')
        if direction not in ('up','down'):
            raise ValueError('CH4_DIRECTION_UNKNOWN')
        def index(name):
            value=ev.get(name)
            if isinstance(value,bool) or not isinstance(value,int) or not 0<=value<len(rows):
                raise ValueError('CH4_'+name.upper()+'_UNBOUND')
            return value
        def same_point(point,i,field):
            if (not isinstance(point,list) or len(point)!=2 or
                    abs(float(point[0])-epochs[i])>1e-6 or
                    abs(float(point[1])-float(rows[i][field]))>1e-7):
                raise ValueError('CH4_NAMED_ROLE_NOT_NATIVE_'+field.upper())
        if family=='RETURN_CE_D':
            c,d,e=(index(name) for name in ('extension_start_index','shift_anchor_index','extension_end_index'))
            if not c<d<e:
                raise ValueError('CH4_C_D_E_ORDER')
            source_side='high' if direction=='up' else 'low'
            same_point(identity[0],c,source_side);same_point(identity[1],e,source_side)
            same_point(identity[2],d,'low' if source_side=='high' else 'high')
            source=ev.get('source_CE_observation') or {}
            points=source.get('source_points')
            if not isinstance(points,list) or len(points)!=2:
                raise ValueError('CH4_RETURN_SOURCE_POINTS_MISSING')
            for observed,i in zip(points,(c,e)):
                if (not isinstance(observed,list) or len(observed)!=2 or
                        observed[0]!=rows[i]['timestamp_utc'] or
                        abs(float(observed[1])-float(rows[i][source_side]))>1e-7):
                    raise ValueError('CH4_RETURN_SOURCE_POINTS_CHANGED')
        else:
            c,d,e,f=(index(name) for name in ('shift_anchor_index','extension_start_index',
                                               'source_E_index','extension_end_index'))
            if not c<d<e<f:
                raise ValueError('CH4_C_D_E_F_ORDER')
            source_side='low' if direction=='up' else 'high'
            same_point(identity[0],d,source_side);same_point(identity[1],f,source_side)
            same_point(identity[2],c,'high' if source_side=='low' else 'low')
            event_indices={'source_D_invalidated':'invalidation_index',
                           'source_DF_contact':'source_extension_contact_index',
                           'target_contact':'contact_index'}
            for event in ev.get('terminal_events') or []:
                if not isinstance(event,dict) or event.get('event') not in event_indices:
                    raise ValueError('CH4_TERMINAL_EVENT_UNKNOWN')
                idx=index(event_indices[event['event']])
                if (event.get('utc')!=rows[idx]['timestamp_utc'] or
                        event.get('event_closed_at_utc')!=close_time(rows[idx],source_timeframe)):
                    raise ValueError('CH4_TERMINAL_EVENT_NOT_NATIVE')
        for name in ('construction_known_at_utc','display_known_at_utc','state_known_at_utc'):
            if not ev.get(name):
                raise ValueError('CH4_'+name.upper()+'_MISSING')
            clock(ev[name])
        if clock(obj['known_at_utc']) < max(clock(ev[name]) for name in
                                            ('construction_known_at_utc','display_known_at_utc','state_known_at_utc')):
            raise ValueError('CH4_FACT_KNOWN_BEFORE_NAMED_CLOCK')
    except (KeyError,TypeError,ValueError,OverflowError) as exc:
        errors.append(str(exc))
    expected=chapter4_lineage_receipt(obj)
    top_receipt=obj.get('chapter4_lineage')
    evidence_receipt=ev.get('chapter4_lineage')
    if top_receipt is not None and evidence_receipt is not None and top_receipt != evidence_receipt:
        errors.append('CH4_NAMED_ROLE_RECEIPT_COPY_MISMATCH')
    receipt=top_receipt or evidence_receipt
    if require_receipt and receipt is None:
        errors.append('CH4_NAMED_ROLE_RECEIPT_MISSING')
    elif receipt is not None and receipt != expected:
        errors.append('CH4_NAMED_ROLE_RECEIPT_CHANGED')
    return errors


def copy_native_book_objects(objects,source_tf,chart_tf,role,profile,scope,cutoff):
    """Project each native family with its original owner, ruler and state.

    OUTER/CHANNEL retain their legacy display IDs so an existing chart can
    update them in place. Display identity is not native ownership.
    """
    if scope is None:return []
    result=[]
    for obj in objects:
        ev=obj.get('evidence') or {};family=ev.get('family')
        family={'single_outer_trendline':'OUTER','parallel_outer_extension':'CHANNEL'}.get(ev.get('display_role'),family)
        roles={'OUTER':'multi_period_outer_trendline','CHANNEL':'multi_period_parallel_extension',
               'RETURN_CE_D':'multi_period_return_boundary','RESUME_DF_C':'multi_period_recovery_target'}
        if family not in roles:continue
        if obj.get('timeframe')!=source_tf or clock(obj['known_at_utc'])>clock(cutoff):continue
        item=deepcopy(obj);native_id=obj['id']
        identity=f'{chart_tf}|{source_tf}|{native_id}'
        if family in ('OUTER','CHANNEL'):
            suffix='outer' if family=='OUTER' else 'parallel'
            identity=f'{chart_tf}|mtf|{source_tf}|{role}|{suffix}|{ev["ruler_identity"]}'
        item.update(id='b'+sha256(identity.encode()).hexdigest()[:23],
                    timeframe=chart_tf)
        metadata=dict(family=family,source_timeframe=source_tf,native_timeframe=source_tf,native_object_id=native_id,
            native_owner_id=obj['owner_id'],native_display_role=ev.get('display_role'),
            display_role=roles[family],
            period_role=role,period_profile=profile,projection_scope=scope,
            automatic_trade_permission=False)
        item.update(metadata);item['evidence'].update(metadata)
        # Preserve a small named-role receipt alongside the ordinary ruler.
        # MT5 transport uses labels as well as the JSON evidence, so give the
        # visible packet the construction roles without embedding an inferred
        # author-wave label or a trading instruction.
        lineage=chapter4_lineage_receipt(item)
        if family in ('RETURN_CE_D','RESUME_DF_C'):
            item['chapter4_lineage']=lineage
            item['evidence']['chapter4_lineage']=deepcopy(lineage)
        item['label']=(f'{family} | {source_tf}->{chart_tf} | {obj["status"]} | '
            f'native_object_id={native_id} native_owner_id={obj["owner_id"]} '
            f'native_source_id={obj["source_id"]} | '+obj['label'])
        if family == 'RETURN_CE_D':
            item['label'] += ' | ch4_roles=C,E,D; C<E source shifted to D'
        elif family == 'RESUME_DF_C':
            event_names=','.join(lineage['terminal_event_names']) or 'none'
            item['label'] += f' | ch4_roles=D,F,C; original_E; events={event_names}'
        result.append(item)
    return result


def copy_native_chapter4_objects(objects,source_tf,chart_tf,role,profile,scope,cutoff):
    """Compatibility route for the historical RETURN/RESUME-only inventory."""
    selected=[o for o in objects if (o.get('evidence') or {}).get('family') in ('RETURN_CE_D','RESUME_DF_C')]
    return copy_native_book_objects(selected,source_tf,chart_tf,role,profile,scope,cutoff)
