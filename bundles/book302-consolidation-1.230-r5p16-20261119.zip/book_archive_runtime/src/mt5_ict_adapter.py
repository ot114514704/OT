"""Original ICT panel logic on bounded, reusable historical week tiles."""
from collections import Counter
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import gzip
import json
from .ict_archive_detail import native, assemble_records, source_metadata
from .ict_archive_window import read_bars


def weeks_covering(start, cutoff):
    """NY calendar weeks, including Sunday evening of the first week."""
    day = start.astimezone(native.NY).date()
    monday = day - timedelta(days=day.weekday())
    if day.weekday() == 6:
        monday += timedelta(days=7)
    while datetime.combine(monday - timedelta(days=1), datetime.min.time(), native.NY).astimezone(timezone.utc) < cutoff:
        yield monday
        monday += timedelta(days=7)


def week_scene(tf, monday, cutoff, revision, data_revision):
    """Cache completed weeks independently of chart pan and zoom.

    Only the incomplete week uses the precise cutoff. Individual known_at
    clocks remain intact; historical observations are not live signals.
    """
    from .mt5_unified_backend import OUTPUT, atomic
    from .mt5_ict_layers import flatten
    end = min(cutoff, datetime.combine(monday + timedelta(days=6), datetime.min.time(), native.NY).astimezone(timezone.utc))
    key = sha256(f'{revision}|{data_revision}|{tf}|{monday}|{end.isoformat()}'.encode()).hexdigest()
    path = OUTPUT / 'ict-week-cache' / (key + '.json.gz')
    if path.exists():
        return json.loads(gzip.decompress(path.read_bytes()))
    first = (monday.replace(day=1) - timedelta(days=1)).replace(day=1)
    start = datetime.combine(first, datetime.min.time(), native.NY).astimezone(timezone.utc)
    m5 = read_bars('M5', start, end)
    periods = {n: native.aggregate_bars(m5, 5, n, end) for n in (5, 15, 60)}
    current = [monday + timedelta(days=i) for i in range(5)]
    previous = [d - timedelta(days=7) for d in current]
    days, weeks = assemble_records(periods, current, previous, current, end)
    month = native.month_overview(periods, min(current[-1], end.astimezone(native.NY).date()), end, {}, [])
    result = dict(timeframe=tf, cutoff_utc=end.isoformat(), objects=[],
                  ict_context=dict(days=days, weeks=[weeks[-1]], month=month))
    flatten(result, native_period_bars=periods)
    # Evidence stays on each object, without duplicated chart OHLC arrays.
    result['ict_context'] = dict(week=str(monday), cutoff_utc=end.isoformat(),
        days=[{k: d.get(k) for k in ('date', 'profile_label', 'profile_status', 'profile_reason', 'po3_research_gate')} for d in days],
        weeks=[{k: weeks[-1].get(k) for k in ('days', 'profile_label', 'profile_reason')}])
    atomic(path, gzip.compress(json.dumps(result, ensure_ascii=False, allow_nan=False).encode(), mtime=0))
    return result


def attach_ict(scene):
    from .mt5_scene_store import engine_revision, archive_revision
    cutoff = datetime.fromisoformat(scene['cutoff_utc'].replace('Z', '+00:00'))
    # Never silently restrict a wide historical structure tile to two weeks.
    first = scene.get('coverage', {}).get('from')
    start = datetime.fromisoformat(first.replace('Z', '+00:00')) if first else cutoff - timedelta(days=14)
    revision = engine_revision()
    data_revision = archive_revision(scene['cutoff_utc'], scene.get('coverage', {}).get('bars', 1024))
    packets = [week_scene(scene['timeframe'], monday, cutoff, revision, data_revision)
               for monday in weeks_covering(start, cutoff)]
    merged = {o['id']: o for p in packets for o in p['objects']}
    scene['objects'].extend(merged.values())
    scene['ict_context'] = dict(sources=source_metadata(), cutoff_utc=scene['cutoff_utc'],
        from_utc=start.isoformat(), weeks=[p['ict_context'] for p in packets],
        days=[d for p in packets for d in p['ict_context']['days']],
        group_counts=dict(Counter(o['group'] for o in merged.values())),
        smt='unavailable_no_same_source_silver', calendar='unavailable_unverified',
        analysis_timeframe='M15', execution_allowed=False,
        history_policy='fixed_NY_week_observations_with_individual_known_at',
        display_timeframe=scene['timeframe'])
