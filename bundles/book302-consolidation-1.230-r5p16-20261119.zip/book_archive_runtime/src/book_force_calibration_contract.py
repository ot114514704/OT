"""Explicit model domain and detector fingerprint for Book first responses."""
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import ast

ROOT=Path(__file__).resolve().parents[1]
BOOK_DOMAIN='book_first_response_radius2_v1'
BOOK_MODEL_PATH=ROOT/'04_wells4_support/W4-20261020-BOOK-FORCE-CALIBRATION/model.json'
FILES=('book_first_response_leg.py','pdf_trendline_block.py','book_wave_inventory.py',
       'trend_trade_method_full_pipeline.py','force_strength_model.py','calibrate_force_strength.py',
       'calibrate_book_force.py','book_force_calibration_contract.py','mt5_force_strength.py')


def pipeline_semantics(source):
    """Fingerprint the inventory's transitive pipeline branch, not plan UI.

    historical_book_objects calls only these pipeline functions. Fail closed
    on a changed branch layout; never silently hash an empty source slice.
    """
    tree=ast.parse(source)
    names={'_time','_closed_at','_closed','detect_first_closed_break',
           'detect_parallel_break','evaluate_break_force','channel_display_extent'}
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names]
    if {n.name for n in nodes}!=names:raise ValueError('Book force pipeline function missing')
    scene=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='scene_objects')
    lines=source.splitlines()
    body='\n'.join(lines[scene.lineno-1:scene.end_lineno])
    anchors=('    line=evidence.get("turning_point_line",{})',
             '    turning = evidence.get("turning_boundary", {})',
             '    force=evidence.get("break_force",{})',
             '    pull=evidence.get("pullback_retest",{})')
    if not all(body.count(a)==1 for a in anchors):raise ValueError('Book force branch anchors changed')
    # Setup includes closed-bar indexing and object identity/evidence helpers.
    setup=body[:body.index('    trend=evidence.get(')]
    parts=[setup,body[body.index(anchors[0]):body.index(anchors[1])],
           body[body.index('    brk=evidence.get("first_closed_break",{})'):body.index(anchors[2])],
           body[body.index(anchors[2]):body.index(anchors[3])]]
    return '\n'.join([ast.dump(n,include_attributes=False) for n in nodes]+parts).encode()


def inventory_semantics(source):
    """Ignore only the independent recovery-target drawing side branch.

    All ruler search, first-source construction, IDs and compaction stay in
    the fingerprint. No generic 'ignore UI' name heuristic is used.
    """
    class WithoutRecovery(ast.NodeTransformer):
        def visit_ImportFrom(self,node):
            return None if node.module=='book_recovery_projection' else self.generic_visit(node)
        def visit_keyword(self,node):
            return None if node.arg=='recovery_target' else self.generic_visit(node)
        def visit_Assign(self,node):
            if (any(isinstance(t,ast.Name) and t.id=='recovery' for t in node.targets)
                and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name)
                and node.value.func.id=='recovery_projection'):return None
            return self.generic_visit(node)
        def visit_AugAssign(self,node):
            if (isinstance(node.target,ast.Name) and node.target.id=='batch'
                and any(isinstance(n,ast.keyword) and n.arg=='recovery_target' for n in ast.walk(node.value))):return None
            return self.generic_visit(node)
        def visit_Set(self,node):
            node.elts=[x for x in node.elts if not(isinstance(x,ast.Constant) and x.value=='book_recovery_target')]
            return self.generic_visit(node)
    return ast.dump(WithoutRecovery().visit(ast.parse(source)),include_attributes=False).encode()


@lru_cache(maxsize=4)
def _signature(stamps):
    h=sha256()
    for name,_,_ in stamps:
        raw=(ROOT/'src'/name).read_bytes()
        if name=='trend_trade_method_full_pipeline.py':raw=pipeline_semantics(raw.decode('utf-8-sig'))
        if name=='book_wave_inventory.py':raw=inventory_semantics(raw.decode('utf-8-sig'))
        if name=='mt5_force_strength.py':
            tree=ast.parse(raw.decode('utf-8-sig'))
            merge=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='merge_book_first_sources')
            raw=ast.dump(merge,include_attributes=False).encode()
        h.update(name.encode());h.update(raw)
    return h.hexdigest()


def detector_signature():
    stamps=tuple((n,(ROOT/'src'/n).stat().st_mtime_ns,(ROOT/'src'/n).stat().st_size) for n in FILES)
    return _signature(stamps)


@lru_cache(maxsize=2)
def _read_model(path,stamp):
    import json
    return json.loads(Path(path).read_text(encoding='utf-8'))


def load_book_model():
    try:return _read_model(str(BOOK_MODEL_PATH),BOOK_MODEL_PATH.stat().st_mtime_ns)
    except (OSError,ValueError):return {}
