"""Native closed-bar lifecycle, separate from source/background admission.

Theory basis: Alexander Feb25 messages 7684838856774972046,
7684840221248997669, 7684841146240587190 and 7684841158346112892.
Contact retires this pending reference, not the parent task, and does not
authorize reversal or reuse of the old ruler as a new entry.
"""
from bisect import bisect_left
from datetime import datetime, timedelta
from math import isfinite, isclose

MINUTES = {"W1": 10080, "D1": 1440, "H4": 240, "H1": 60,
           "M30": 30, "M15": 15, "M5": 5, "M1": 1}
IDENTITY = ("timeframe", "snapshot_id", "as_of_utc", "measurement_id", "source_leg_id")


def _time(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timezone required")
    return parsed


def _price(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value):
        raise ValueError("finite numeric price required")
    return value


class NativeProjectionLifecycle:
    """Index each native series once per response; never amend input evidence."""
    def __init__(self, snapshot):
        self.snapshot = snapshot
        self.cache = {}

    def _series(self, tf):
        if tf in self.cache:
            return self.cache[tf]
        history = (self.snapshot.get("chart_history") or {}).get(tf) or {}
        for key, expected in (("timeframe", tf), ("snapshot_id", self.snapshot.get("snapshot_id")),
                              ("as_of_utc", self.snapshot.get("as_of_utc"))):
            if key in history and history[key] != expected:
                raise ValueError("foreign native history")
        cutoff = _time(self.snapshot["as_of_utc"])
        duration = timedelta(minutes=MINUTES[tf])
        bars, times = [], []
        for bar in history.get("bars") or []:
            opened = _time(bar["timestamp_utc"])
            if bar.get("timeframe", tf) != tf:
                raise ValueError("foreign native candle")
            if times and opened <= times[-1]:
                raise ValueError("duplicate or unsorted native candle")
            # An open candle's OHLC must never affect a closed-bar decision.
            if opened + duration > cutoff:
                continue
            o, h, l, c = [_price(bar[k]) for k in ("open", "high", "low", "close")]
            if not l <= min(o, c) <= max(o, c) <= h:
                raise ValueError("invalid native OHLC")
            times.append(opened)
            bars.append(bar)
        result = times, bars, duration, cutoff
        self.cache[tf] = result
        return result

    def review(self, record):
        result = {k: record.get(k) for k in IDENTITY}
        result.update(method_version="native_reference_lifecycle_v1", status="unavailable",
                      eligible_for_pending_target=False, reference_contact_observed=False,
                      parent_target_completed=False, reversal_confirmed=False,
                      new_entry_permission=False, trade_permission=False,
                      first_contact=None, first_anchor_cross=None,
                      first_source_origin_cross=None,
                      contact_source_origin_order="unavailable", blockers=[],
                      next_observation="量尺后续证据未核齐，不能当作仍待兑现的目标。")
        try:
            tf = record["timeframe"]
            if tf not in MINUTES or any(not record.get(k) for k in IDENTITY):
                raise ValueError("measurement identity missing")
            if any(record[k] != self.snapshot.get(k) for k in ("snapshot_id", "as_of_utc")):
                raise ValueError("measurement snapshot mismatch")
            anchors = [record[k] for k in ("source_origin", "source_terminal", "projection_anchor")]
            a, b, c = [_price(p["price"]) for p in anchors]
            target = _price(record["projected_level"])
            if not b-a or not min(a, b) < c < max(a, b) or not isclose(target, c+b-a, abs_tol=1e-6, rel_tol=0):
                raise ValueError("invalid equal-height anchors")
            times, bars, duration, cutoff = self._series(tf)
            pivots = [_time(p["pivot_timestamp_utc"]) for p in anchors]
            confirms = [_time(p["confirmed_at_utc"]) for p in anchors]
            if not pivots[0] < pivots[1] < pivots[2]:
                raise ValueError("anchor order invalid")
            up = b > a
            for pivot, confirmed, point, field in zip(pivots, confirms, anchors,
                    ("low", "high", "low") if up else ("high", "low", "high")):
                i = bisect_left(times, pivot)
                if (point.get("timeframe", tf) != tf or not pivot < confirmed <= cutoff or
                        i == len(times) or times[i] != pivot or
                        not isclose(bars[i][field], point["price"], abs_tol=1e-6, rel_tol=0)):
                    raise ValueError("anchor not bound to native closed candle")
            known = max(confirms)
            start = bisect_left(times, known)
            result["known_at_utc"] = known.isoformat().replace("+00:00", "Z")
            result["coverage"] = dict(bars_after_confirmation=len(bars)-start,
                through_bar_open_utc=bars[-1]["timestamp_utc"] if bars else None,
                scope="available_native_closed_bars_not_exchange_calendar_completeness")
            for bar in bars[start:]:
                reached = bar["high"] >= target if up else bar["low"] <= target
                crossed = bar["close"] < c if up else bar["close"] > c
                witness = {k: bar[k] for k in ("timestamp_utc", "open", "high", "low", "close")}
                witness["timeframe"] = tf
                if reached and result["first_contact"] is None:
                    result["first_contact"] = witness
                if crossed and result["first_anchor_cross"] is None:
                    result["first_anchor_cross"] = witness
                # A is the bound source origin, not automatically a protected
                # structure node. Preserve this price event for replay without
                # declaring trend failure or retrospectively rejecting A-B.
                origin_crossed = bar["close"] < a if up else bar["close"] > a
                if origin_crossed and result["first_source_origin_cross"] is None:
                    result["first_source_origin_cross"] = witness
            contact, crossed = result["first_contact"], result["first_anchor_cross"]
            origin_cross = result["first_source_origin_cross"]
            if contact and origin_cross:
                contact_time, origin_time = _time(contact["timestamp_utc"]), _time(origin_cross["timestamp_utc"])
                result["contact_source_origin_order"] = (
                    "contact_before_source_origin_cross" if contact_time < origin_time else
                    "source_origin_cross_before_contact" if origin_time < contact_time else
                    "contact_and_source_origin_cross_same_bar")
            elif contact:
                result["contact_source_origin_order"] = "contact_without_observed_source_origin_cross"
            elif origin_cross:
                result["contact_source_origin_order"] = "source_origin_cross_without_observed_contact"
            else:
                result["contact_source_origin_order"] = "neither_observed_in_available_bars"
            result["reference_contact_observed"] = contact is not None
            if contact and (not crossed or contact["timestamp_utc"] < crossed["timestamp_utc"]):
                result.update(status="reference_reached_observe_reaction",
                    next_observation="本级等高参考已到位；观察到位后的延续、回调或反向回应。上级任务另核，再入需新的回调与结构条件。")
            elif crossed:
                ambiguous = contact and contact["timestamp_utc"] == crossed["timestamp_utc"]
                result.update(status="contact_and_anchor_cross_same_bar" if ambiguous else "anchor_crossed_reassess",
                    next_observation="同根 K 同时触及参考并收过回调锚点，先后未知，重审旧路径。" if ambiguous else
                    "旧回调锚点已被收过，先重审这把量尺；不据此认定父任务失效或趋势反转。")
            elif start == len(bars) or times[-1]+duration <= cutoff-duration:
                result["blockers"] = ["no_recent_closed_bar_after_confirmation"]
            else:
                owned = (record.get("projection_admission") or {}).get("eligible_for_projection") is True
                result.update(status="reference_unreached_in_available_bars",
                    eligible_for_pending_target=owned,
                    next_observation="已核本周期收盘历史尚未触及参考；继续观察回调锚点与沿途结构，不能仅凭等高框进场。")
        except (KeyError, ValueError, TypeError, AttributeError, OverflowError) as error:
            result["blockers"] = [str(error)]
        return result


def bound_lifecycle(record):
    """Consumers must not borrow another measurement's lifecycle."""
    value = record.get("current_projection_lifecycle") or {}
    if (value.get("method_version") == "native_reference_lifecycle_v1" and
            all(record.get(k) and value.get(k) == record.get(k) for k in IDENTITY) and
            value.get("trade_permission") is False):
        return value
    return {}
