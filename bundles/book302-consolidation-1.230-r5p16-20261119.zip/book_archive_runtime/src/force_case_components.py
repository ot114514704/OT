"""Load ONE exact-clock case snapshot and render its adjacent-child evidence.

No historical snapshot is promoted to a current/reusable trade permission.
Source/timeframe/owner identities stay separate from display timeframe.
"""
from copy import deepcopy
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path

from .force_parent_prefix_registry import ROOT,key_for,canonical
from .force_strength_model import epoch
from .mt5_structure_logic import PARENTS

REGISTRY=ROOT/'04_wells4_support/force_case_component_registry.json'


def snapshot_key(force,scene):
    return sha256(canonical([key_for(force,scene.get('provider'),scene.get('instrument')),scene['cutoff_utc']])).hexdigest()


@lru_cache(maxsize=4)
def _load(path,mtime,size):
    raw=Path(path).read_bytes();d=json.loads(raw)
    if d.get('schema')!='force_case_component_registry_v1':raise ValueError('Foreign case registry')
    return d,sha256(raw).hexdigest()


def lookup(force,scene,path=None):
    result=dict(status='not_found',record_id=None,registry_sha256=None,context=None)
    try:
        path=Path(path or REGISTRY);stat=path.stat();d,digest=_load(str(path),stat.st_mtime_ns,stat.st_size)
        key=snapshot_key(force,scene);entry=d['entries'].get(key)
        result.update(record_id=key,registry_sha256=digest)
        if not entry:return result
        c=entry['context'];parent=PARENTS.get(force['timeframe']);child=next((k for k,v in PARENTS.items() if v==force['timeframe']),None)
        expected=dict(owner_id=force['id'],source_id=force['source_id'],provider=scene['provider'],instrument=scene['instrument'],
            timeframe=force['timeframe'],as_of_utc=scene['cutoff_utc'],source_known_at_utc=force['known_at_utc'],
            source_points=force['points'],parent_timeframe=parent,child_timeframe=child)
        if (any(c.get(k)!=v for k,v in expected.items()) or c.get('automatic_trade_permission') is not False or
            entry['context_sha256']!=sha256(canonical(c)).hexdigest()):raise ValueError('Case identity/digest mismatch')
        for p in c['child_patterns']:
            if (p['timeframe']!=child or epoch(p['known_at_utc'])>epoch(c['as_of_utc']) or
                not epoch(p['known_at_utc'])<=epoch(p['post_third_response']['known_at_utc'])<=epoch(c['as_of_utc']) or
                len(p['anchors'])!=6 or any(epoch(a['confirmed_at_utc'])>epoch(p['known_at_utc']) for a in p['anchors'])):
                raise ValueError('Foreign/future child')
        if epoch(c['source_known_at_utc'])>epoch(c['as_of_utc']):raise ValueError('Future source')
        for r in c['owned_rulers']:
            if r['timeframe'] not in (force['timeframe'],parent) or epoch(r['known_at_utc'])>epoch(c['as_of_utc']):
                raise ValueError('Foreign/future ruler')
        return dict(result,status='matched',context=deepcopy(c))
    except FileNotFoundError:return dict(result,status='registry_not_present')
    except (OSError,ValueError,TypeError,KeyError,AttributeError,IndexError):return dict(result,status='invalid_registry_or_record')


def projected_children(force,scene,context):
    out=[]
    for p in context['child_patterns']:
        tips=[p['anchors'][i] for i in (1,3,5)]
        state=p['post_third_response']['state'];label='收回已失守' if state=='reclaim_failed' else '几何候选·未许可'
        for i in (0,1):
            source=p['owner_id']+':case-child:'+str(i)
            identifier=sha256((force['id']+'|'+source+'|'+scene['cutoff_utc']).encode()).hexdigest()[:24]
            out.append(dict(id=identifier,layer='three_push',kind='line',timeframe=scene['timeframe'],
                source_timeframe=p['timeframe'],points=[[epoch(tips[j]['pivot_timestamp_utc']),tips[j]['price']] for j in (i,i+1)],
                owner_id=p['owner_id'],source_id=source,known_at_utc=p['post_third_response']['known_at_utc'],
                status='reclaim_failed' if state=='reclaim_failed' else 'candidate',group='case_child_three_push',
                label=f"子{p['timeframe']}三推 {i+1}→{i+2} · {label} · 非完整回调确认",
                evidence=dict(native_timeframe=p['timeframe'],display_timeframe=scene['timeframe'],
                    as_of_utc=scene['cutoff_utc'],known_at_utc=p['known_at_utc'],
                    owner_id=p['owner_id'],source_id=p['source_id'],work_force_owner_id=force['id'],
                    context_relation=p['context_relation'],return_completion='not_adjudicated',
                    post_third_response=p['post_third_response'],automatic_trade_permission=False)))
    return out
