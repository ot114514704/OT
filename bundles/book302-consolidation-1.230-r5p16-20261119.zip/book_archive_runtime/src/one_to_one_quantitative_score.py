"""Validated 1:1 measurements; descriptive scores are never probabilities.

Three completed source pushes are optional background, not required future
legs. Return depth and relative speed stay raw, because no calibrated rule
says slower/equal-speed or a particular depth must be better.
"""
from copy import deepcopy
from math import isfinite


def numeric(value):
    return (not isinstance(value,bool) and isinstance(value,(int,float))
            and isfinite(value) and 0<=value<=100)


def score_one_to_one_quantitatively(*, delivery_score, frozen_structure_score,
                                    current_structure_score, ratio_observation=None,
                                    current_sequence_alignment=None,
                                    target_already_reached=False,
                                    native_source_verified=False,
                                    source_clock_verified=False,
                                    lifecycle='second_leg_observation_unknown'):
    parts=dict(delivery=delivery_score,frozen_structure=frozen_structure_score,
               current_structure=current_structure_score)
    out=dict(schema='one_to_one_quantitative_score_v3',status='unknown',score=None,
        components=deepcopy(parts),unknown_components=[],failures=[],
        diagnostics={},profile_hypotheses={},selected_profile=None,
        score_is_probability=False,calibrated_probability=None,
        calibration_status='no_validated_target_success_or_entry_model',
        score_scope='breakout_acceptance_context_not_local_target_success',
        automatic_trade_permission=False,entry_gate='closed_research_only')
    for name,value in parts.items():
        if value is None:out['unknown_components'].append(name)
        elif not numeric(value):out['failures'].append(name+'_invalid')
    if native_source_verified is not True:out['unknown_components'].append('native_source_unverified')
    if source_clock_verified is not True:out['unknown_components'].append('source_clock_unverified')
    if lifecycle!='developing_second_leg':out['failures'].append('not_a_developing_second_leg')
    if target_already_reached:out['failures'].append('original_context_retired')
    if current_sequence_alignment=='counter_native_sequence':out['failures'].append('current_structure_counter_sequence')
    elif current_sequence_alignment not in ('aligned_native_sequence','range_or_transition_sequence'):
        out['unknown_components'].append('current_sequence_alignment')
    # Local delivery can be measured INSIDE an unbroken larger structure.
    # It is not a second vote for breakout acceptance or a target success
    # probability. Missing larger nodes and counter-sequence stay visible
    # in the top-level context; they do not rewrite this local measurement.
    local_unknown=[];local_failures=[]
    if delivery_score is None:local_unknown.append('delivery')
    elif not numeric(delivery_score):local_failures.append('delivery_invalid')
    if native_source_verified is not True:local_unknown.append('native_source_unverified')
    if source_clock_verified is not True:local_unknown.append('source_clock_unverified')
    if lifecycle!='developing_second_leg':local_failures.append('not_a_developing_second_leg')
    if target_already_reached:local_failures.append('original_context_retired')
    local_state='rejected' if local_failures else 'unknown' if local_unknown else 'measured'
    out['local_delivery']=dict(status=local_state,score=delivery_score if local_state=='measured' else None,
        scope='delivery_on_fixed_C_to_original_AB_target_not_larger_breakout_or_success_probability',
        formula='existing native second-leg delivery score; no new weights',
        unknown_components=local_unknown,failures=local_failures,
        calibration='unvalidated_engineering_measurement',current_sequence_alignment=current_sequence_alignment,
        structure_acceptance_is_independent=True,score_is_probability=False,automatic_trade_permission=False)
    profile=ratio_observation if isinstance(ratio_observation,dict) else {}
    out['input_profile']=deepcopy(profile)
    ratios=profile.get('ratios_to_first_push')
    valid_ratios=(isinstance(ratios,list) and len(ratios)==3 and
        all(not isinstance(v,bool) and isinstance(v,(int,float)) and isfinite(v) and v>0 for v in ratios))
    if valid_ratios:
        p1,p2,p3=ratios
        out['diagnostics']['ratios_to_first_push']=list(ratios)
        out['diagnostics']['equal_unit_absolute_deviations']=[abs(v-1) for v in ratios]
        out['diagnostics']['middle_in_user_1_618_to_2_618_band']=1.618<=p2<=2.618
        out['diagnostics']['last_minus_first_unit']=p3-p1
        out['diagnostics']['last_minus_book_point618']=p3-.618
        # Keep each existing hypothesis visible. No max-score selection,
        # new weighting or author-label assignment is performed.
        out['profile_hypotheses']={k:v for k,v in (profile.get('scores') or {}).items() if numeric(v)}
    depth=profile.get('return_depth') or {}
    out['diagnostics']['deepest_return_to_prior_push']=depth.get('deepest_return_to_prior_push')
    speeds=profile.get('push_speed_per_second')
    if isinstance(speeds,list) and len(speeds)==3 and all(not isinstance(v,bool) and isinstance(v,(int,float)) and isfinite(v) and v>0 for v in speeds):
        out['diagnostics']['speed_relative_first']=[v/speeds[0] for v in speeds]
    out['background_coverage']='three_observed_source_pushes' if valid_ratios else 'source_three_push_profile_unavailable'
    out['background_missing_blocks_second_leg']=False
    out['diagnostics_affect_score']=False
    if out['failures']:out['status']='rejected'
    elif not out['unknown_components']:
        out.update(status='measured',score=round(min(parts.values()),6))
    out['formula']='minimum(delivery,frozen_structure,current_structure); causal/lifecycle/conflict validation before consumption'
    return out
