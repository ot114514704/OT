"""A source-bound measurement object shared by explanation and chart consumers."""
from datetime import datetime
from math import isfinite, isclose
from .live_projection_lifecycle import bound_lifecycle


def build_measurement_map(review):
    result = {
        "status": "unavailable", "timeframe": review.get("timeframe"),
        "snapshot_id": review.get("snapshot_id"), "as_of_utc": review.get("as_of_utc"),
        "nodes": [], "segments": [], "blockers": [], "trade_permission": False,
        "target_arrival_time": None, "task_target_completed": False,
        "eligible_for_analysis": False,
        "eligible_for_pending_target": False,
        "projection_admission": review.get("projection_admission"),
    }
    if review.get("status") != "native_retracement_anchored_equal_distance_geometry":
        return result
    try:
        def timestamp(value):
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                raise ValueError("timezone missing")
            return parsed
        cutoff = timestamp(review["as_of_utc"])
        if not review.get("snapshot_id"):
            raise ValueError("snapshot missing")
        if review.get("timeframe") not in {"W1", "D1", "H4", "H1", "M30", "M15", "M5", "M1"}:
            raise ValueError("timeframe missing")
        anchors = [review[key] for key in ("source_origin", "source_terminal", "projection_anchor")]
        prices, times = [], []
        for anchor in anchors:
            if anchor.get("timeframe", review["timeframe"]) != review["timeframe"]:
                raise ValueError("mixed timeframe anchors")
            price = anchor["price"]
            if isinstance(price, bool) or not isinstance(price, (float, int)) or not isfinite(price):
                raise ValueError("price invalid")
            when, known = timestamp(anchor["pivot_timestamp_utc"]), timestamp(anchor["confirmed_at_utc"])
            if not when <= known <= cutoff:
                raise ValueError("future or invalid confirmation")
            prices.append(price)
            times.append(when)
        a, b, c = prices
        target = review["projected_level"]
        if not times[0] < times[1] < times[2] or not b-a or (b-a)*(c-b) >= 0:
            raise ValueError("not sequential opposing legs")
        if isinstance(target, bool) or not isinstance(target, (float,int)) or not isfinite(target) or not isclose(target, c+b-a, rel_tol=0, abs_tol=1e-6):
            raise ValueError("projection is not C + (B - A)")
        for field in ("first_touch_bar_open_utc", "first_close_beyond_bar_open_utc"):
            if review.get(field) and not max(timestamp(p["confirmed_at_utc"]) for p in anchors) <= timestamp(review[field]) < cutoff:
                raise ValueError("response outside known interval")
    except (KeyError, TypeError, ValueError, AttributeError, OverflowError):
        result["blockers"] = ["anchors_or_projection_not_bound"]
        return result
    invalid_phases = {"retracement_anchor_beyond_source_origin", "close_beyond_source_origin", "source_origin_crossed_then_reclaimed"}
    requires_review = (review.get("phase") in invalid_phases
                       or bool((review.get("anchor_review") or {}).get("requires_anchor_review"))
                       or (review.get("source_structure_review") or {}).get("phase") !=
                           "source_departure_closes_still_beyond_prior_extreme")
    state = "review_required" if requires_review else "reference_reached" if review.get("first_touch_bar_open_utc") or review.get("first_close_beyond_bar_open_utc") else "reference_not_reached"
    state_text = {"review_required": "旧量尺须重审", "reference_reached": "参考已触及", "reference_not_reached": "参考尚未到"}[state]
    lifecycle = bound_lifecycle(review)
    if lifecycle:
        lifecycle_state = lifecycle.get('status')
        if lifecycle_state in {'anchor_crossed_reassess', 'contact_and_anchor_cross_same_bar'}:
            requires_review, state, state_text = True, 'review_required', '旧量尺须重审'
        elif lifecycle.get('reference_contact_observed') and not requires_review:
            state, state_text = 'reference_reached', '参考已触及'
        elif lifecycle_state == 'unavailable' and not requires_review:
            state, state_text = 'unknown', '后续证据未核齐'
    blockers = []
    if not review.get("direction_task_confirmed"):
        blockers.append("direction_task_unconfirmed")
    if not (review.get("source_leg_context") or {}).get("parent_task_bound"):
        blockers.append("parent_task_unbound")
    if not review.get("creator_force_confirmed"):
        blockers.append("source_force_unconfirmed")
    if not review.get("active_target_bound"):
        blockers.append("active_target_unbound")
    if not review.get("pullback_completed"):
        blockers.append("pullback_end_unconfirmed")
    if requires_review:
        blockers.append("origin_or_anchor_requires_review")
    nodes = [
        {"id": label, "role": role, "price": price, "pivot_timestamp_utc": anchor["pivot_timestamp_utc"], "known_at_utc": anchor["confirmed_at_utc"]}
        for label, role, price, anchor in zip(("A","B","C"), ("source_origin","source_terminal","retracement_anchor"), prices, anchors)
    ]
    nodes.append({"id": "D", "role": "equal_distance_reference", "price": target, "pivot_timestamp_utc": None,
                  "known_at_utc": max(timestamp(p["confirmed_at_utc"]) for p in anchors).isoformat().replace("+00:00","Z")})
    result.update(
        status="source_bound_measurement_map", measurement_id=review.get("measurement_id"), nodes=nodes,
        eligible_for_analysis=(review.get("projection_admission") or {}).get("eligible_for_projection") is True,
        eligible_for_pending_target=(lifecycle.get('eligible_for_pending_target') is True and
            not requires_review and (review.get('projection_admission') or {}).get('eligible_for_projection') is True),
        current_projection_lifecycle=lifecycle or None,
        segments=[{"from":"A","to":"B","role":"source_leg"}, {"from":"B","to":"C","role":"retracement"},
                  {"from":"C","to":"D","role":"equal_height_projection","signed_height":b-a}],
        reference_state=state, reference_state_text=state_text, blockers=blockers,
        source_structure_phase=(review.get("source_structure_review") or {}).get("phase"),
        next_observation=lifecycle.get('next_observation') or review.get("next_observation"),
        readout=f"{review['timeframe']}：A {a:.2f} → B {b:.2f}；从 C {c:.2f} 量同样高度到 {target:.2f}。{state_text}。",
    )
    return result
