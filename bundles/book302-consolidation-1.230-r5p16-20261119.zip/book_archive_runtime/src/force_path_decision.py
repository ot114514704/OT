"""Compose source priors and current route facts without inventing selection.

This evaluates executable research/watch branches, NOT an order policy.
Frozen priors, statistical preference and later evidence remain separate.
"""
from .force_strength_model import BANDS,epoch

NAMES={'50_61.8':'浅','77_88':'深','127.2':'再扫'}
LABELS={'archived':'归档','target_retired':'旧目标结束','observation':'观察','candidate':'触及候选',
        'price_reference_advancing':'触发推进','price_reference_under_pressure':'触发回吐',
        'price_reference_wait_follow':'触发待跟随','route_disagreement':'两入口分歧',
        'node_attempt_interrupted':'节点回接中断','invalidated':'失效','completed':'结束','ambiguous':'顺序未知'}
PRESSURE={'adverse_close','extension_given_back'}
ADVANCE={'directional_progress','close_extension'}


def path_decision(force,quality,decision,context,space,following):
    identity=dict(owner_id=force.get('id'),source_id=force.get('source_id'),timeframe=force['timeframe'])
    for plan in (decision,space,following):
        if any(plan.get(k)!=v for k,v in identity.items()):raise ValueError('Foreign path plan')
    ctx=context['context']
    grade_source=force.get('source_id') or force.get('evidence',{}).get('force_leg_id') or force.get('id')
    if (any(ctx.get(k)!=v for k,v in identity.items()) or ctx['source_points']!=force['points'] or
        ctx['source_known_at_utc']!=force['known_at_utc'] or quality['known_at_utc']!=force['known_at_utc'] or
        quality['source_id']!=grade_source or quality['timeframe']!=force['timeframe']):
        raise ValueError('Foreign path source context/grade')
    now=decision['as_of_utc'];end=decision['review_end_utc']
    if not epoch(force['known_at_utc'])<=epoch(end)<=epoch(now):raise ValueError('Path clocks out of order')
    expected={route+':'+band for band in BANDS for route in ('ratio','node')}
    if set(space['routes'])!=expected or set(following['routes'])!=expected:raise ValueError('Six source-owned routes required')
    for key,s in space['routes'].items():
        f=following['routes'][key];route,band=key.split(':',1)
        for r in (s,f):
            if (any(r.get(k)!=v for k,v in identity.items()) or r['as_of_utc']!=now or r['review_end_utc']!=end or
                r['band']!=band or r['route']!=('ratio_reclaim' if route=='ratio' else 'node_retest')):
                raise ValueError('Foreign path route/clock')
        if f['trigger_at_utc']!=s['trigger_at_utc'] or f.get('attempt_id')!=s.get('current_attempt_id'):
            raise ValueError('Path follow belongs to another trigger/attempt')
        if s['trigger_at_utc'] and not epoch(force['known_at_utc'])<=epoch(s['trigger_at_utc'])<=epoch(end):
            raise ValueError('Future path trigger')
        if f['current_observation'] and not s['current_price_space_available']:
            raise ValueError('Inactive route cannot supply current follow')
    source_codes=['grade_'+quality['quality'],'node_'+ctx['local_break']['status'],
                  'left_liquidity_'+ctx['left_liquidity']['status']]
    prior=context['contextual_inclination']
    supported={'50_61.8'} if prior=='shallow_confluence' else {'77_88','127.2'} if prior=='deep_and_sweep_compete' else set()
    shallow_pressure=[k for k in ('ratio:50_61.8','node:50_61.8') if
        space['routes'][k]['current_price_space_available'] and following['routes'][k]['state'] in PRESSURE]
    paths={}
    for band in BANDS:
        raw=decision['bands'][band];node=context['node_routes'][band]
        active=[k for k in ('ratio:'+band,'node:'+band) if space['routes'][k]['current_price_space_available']]
        advancing=[k for k in active if following['routes'][k]['state'] in ADVANCE]
        pressured=[k for k in active if following['routes'][k]['state'] in PRESSURE]
        if decision['historical_only']:stage='archived'
        elif raw['source_target_task_retired']:stage='target_retired'
        elif active:
            stage=('route_disagreement' if advancing and pressured else
                   'price_reference_under_pressure' if pressured else
                   'price_reference_advancing' if advancing else 'price_reference_wait_follow')
        elif node['price_pattern_confirmed'] and node['pattern_state']=='confirmed':stage='node_attempt_interrupted'
        elif raw['pattern_state']=='candidate' or node['pattern_state']=='candidate':stage='candidate'
        elif raw['pattern_state'] in ('invalidated','completed','ambiguous'):stage=raw['pattern_state']
        else:stage='observation'
        reasons=[];cautions=[];next_conditions=[]
        if band in supported:reasons.append('conditional_source_prior_support')
        if raw['statistical_preference']:reasons.append('past_only_statistical_preference')
        if context['statistics_context_relation']=='conflict_requires_context_resolution':
            cautions.append('statistics_context_disagree_not_auto_resolved')
        if active:reasons.append('current_route_price_reference_exists')
        if advancing:reasons.append('route_specific_follow_advancing')
        if pressured:cautions.append('route_specific_giveback_not_automatic_reversal')
        if advancing and pressured:cautions.append('ratio_node_disagreement_keep_both')
        competition=(band!='50_61.8' and bool(shallow_pressure) and stage in ('observation','candidate'))
        if competition:
            reasons.append('shallow_giveback_reopens_competing_watch_not_forecast')
        if stage=='archived':next_conditions=['new_source_or_explicit_research_window_not_old_reference']
        elif stage=='target_retired':next_conditions=['bind_new_task_and_target_do_not_recycle_C']
        elif stage in ('invalidated','completed','ambiguous'):
            next_conditions=['new_independent_setup_not_reactivate_terminal_route']
            if band!='127.2' and stage=='invalidated':next_conditions.append('127.2_requires_own_sweep_reclaim_follow')
        elif active:
            next_conditions=['track_chosen_route_follow_and_original_protection_target']
            if pressured:next_conditions.append('watch_deeper_return_or_new_structure_without_assuming_it')
            if len(active)>1:next_conditions.append('choose_actual_entry_method_separately_not_statistical_winner')
        elif band=='127.2':next_conditions=['touch_127.2_then_reclaim_B_then_later_directional_close_with_sweep_protection']
        else:
            next_conditions=['band_touch_and_directional_close_reclaim_for_ratio_route']
            if node['pattern_state'] not in ('not_applicable','invalidated','completed','ambiguous'):
                next_conditions.append('new_node_touch_and_directional_reclaim_for_node_route')
        paths[band]=dict(stage=stage,source_prior_supported=band in supported,
            source_reason_codes=source_codes,source_prior_known_at_utc=force['known_at_utc'],
            statistical_preference=raw['statistical_preference'],reasons=reasons,cautions=cautions,
            current_reason_known_at_utc=now,current_price_routes=active,advancing_routes=advancing,
            pressured_routes=pressured,competing_watch_reopened=competition,
            competing_watch_from_routes=shallow_pressure if competition else [],next_conditions=next_conditions,
            price_reference_only=True,automatic_trade_permission=False)
    return dict(schema='force_path_decision_v1',**identity,as_of_utc=now,review_end_utc=end,
        source_grade=quality['quality'],source_grade_known_at_utc=force['known_at_utc'],paths=paths,
        caption=('路径复盘·' if decision['historical_only'] else '路径·')+
                '/'.join(NAMES[b]+LABELS[p['stage']] for b,p in paths.items()),
        source_prior_basis='local_engineering_node_and_grade_not_author_fourth_wave',
        statistical_context_relation=context['statistics_context_relation'],
        selected_entry_band=None,selected_route=None,parent_direction='not_adjudicated',
        automatic_trade_permission=False)
