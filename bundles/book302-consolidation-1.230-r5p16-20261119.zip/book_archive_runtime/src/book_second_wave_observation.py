"""Source-bound chapter7 wave2 observations (PDF203-204), not author labels."""
from .book_first_response_leg import clock,close_time


def observe_second_wave(bars,timeframe,cutoff,B,A,direction,radius=2):
    base=dict(status='unknown',source_pdf_pages=[203,204,207],author_wave_degree='unknown',
              author_second_wave_confirmed=False,trade_permission=False,
              pivot_radius=radius,parameter_basis='engineering_confirmation_not_book_threshold')
    rows=[r for r in bars if clock(close_time(r,timeframe))<=clock(cutoff)]
    try:
        ai=A['index'];sign=1 if direction=='up' else -1 if direction=='down' else 0
        height=sign*(A['price']-B['price'])
        if not sign or height<=0 or not 0<=ai<len(rows) or radius<1:return dict(base,reason='source_unbound')
        crossing=next((i for i in range(ai+1,len(rows)) if sign*(float(rows[i]['close'])-A['price'])>0),None)
        stop=crossing if crossing is not None else len(rows)-1
        if stop<=ai:return dict(base,reason='correction_not_observed')
        adverse='low' if sign>0 else 'high'
        extreme=min(range(ai+1,stop+1),key=lambda i:sign*float(rows[i][adverse]))
        price=float(rows[extreme][adverse]);ratio=sign*(A['price']-price)/height
        events=[];ambiguous=[]
        # Count only completed source-native pivots; no unclosed right neighbours.
        for i in range(ai+1,stop-radius+1):
            if i-radius<ai:continue
            neighbours=[j for j in range(i-radius,i+radius+1) if j!=i]
            high=all(float(rows[i]['high'])>=float(rows[j]['high']) for j in neighbours) and any(float(rows[i]['high'])>float(rows[j]['high']) for j in neighbours)
            low=all(float(rows[i]['low'])<=float(rows[j]['low']) for j in neighbours) and any(float(rows[i]['low'])<float(rows[j]['low']) for j in neighbours)
            if high and low:ambiguous.append(i);continue
            if not (high or low):continue
            kind='high' if high else 'low';value=float(rows[i][kind])
            expected='low' if sign>0 else 'high'
            if not events and kind!=expected:continue
            event=dict(index=i,utc=rows[i]['timestamp_utc'],kind=kind,price=value,
                       known_at_utc=close_time(rows[i+radius],timeframe))
            if events and events[-1]['kind']==kind:
                # A confirmed equal-price successor is the end of a flat
                # top/bottom. Keeping the first one makes the tail revisit
                # guard reject an otherwise sealed corrective terminal.
                more_extreme=value>=events[-1]['price'] if kind=='high' else value<=events[-1]['price']
                if more_extreme:events[-1]=event
            else:events.append(event)
        n=len(events);triangle=False
        if n==5:
            lows=[e['price'] for e in events if e['kind']=='low']
            highs=[e['price'] for e in events if e['kind']=='high']
            triangle=(len(lows)>=2 and len(highs)>=2 and
                      all(b>a for a,b in zip(lows,lows[1:])) and all(b<a for a,b in zip(highs,highs[1:])))
        form=('ambiguous_native_pivots' if ambiguous else 'simple_return_candidate' if n==1 else
              'abc_candidate' if n==3 else 'contracting_triangle_candidate' if triangle else
              'five_pivot_nontriangle_unresolved' if n==5 else 'developing_or_complex')
        # PDF203 fig7-16 ends at pivot5, not at the deepest pivot1.
        # PDF207 starts wave3 at the END of wave2. Keep the excursion extreme
        # for retracement/B failure, separately from a provisional terminal.
        terminal=None;terminal_reason='correction_structure_unresolved'
        if form in ('simple_return_candidate','abc_candidate','contracting_triangle_candidate'):
            last=events[-1]
            if last['kind']==adverse:
                tail_breach=next((k for k in range(last['index']+1,stop+1)
                    if sign*(float(rows[k][adverse])-last['price'])<=0),None)
                if tail_breach is None:
                    terminal=dict(index=last['index'],utc=last['utc'],price=last['price'],
                        known_at_utc=last['known_at_utc'],basis='last_confirmed_corrective_pivot_not_interval_extreme')
                    terminal_reason=None
                else:terminal_reason='later_adverse_revisit_requires_new_terminal'
        # A one-bar counter move immediately after A has no left neighbour
        # inside wave2. Do not compare it with the preceding wave1 candle's
        # full range: that suppresses fast returns contained in A's range.
        # Admit only an explicitly sealed single-return ENGINEERING candidate:
        # first adverse extreme, existing right-confirmation radius complete,
        # no adverse revisit, and a subsequent closed passage beyond A.
        if (terminal is None and n==0 and not ambiguous and crossing is not None
                and extreme==ai+1 and extreme+radius<=crossing
                and sign*(A['price']-price)>0
                and sign*(float(rows[extreme]['close'])-A['price'])<0
                and all(sign*(float(rows[k][adverse])-price)>0 for k in range(extreme+1,stop+1))):
            form='fast_single_return_candidate'
            terminal=dict(index=extreme,utc=rows[extreme]['timestamp_utc'],price=price,
                known_at_utc=close_time(rows[crossing],timeframe),
                basis='post_A_single_return_right_confirmation_and_closed_A_cross_engineering')
            terminal_reason=None
        return dict(base,status='observed_candidate',source_B_index=B['index'],source_A_index=ai,
            form=form,pivots=events,ambiguous_indices=ambiguous,
            observation_end_utc=rows[stop]['timestamp_utc'],known_at_utc=close_time(rows[stop],timeframe),
            A_cross_utc=rows[crossing]['timestamp_utc'] if crossing is not None else None,
            adverse_extreme=dict(index=extreme,utc=rows[extreme]['timestamp_utc'],price=price),
            terminal_candidate=terminal,terminal_unknown_reason=terminal_reason,
            terminal_status=('candidate_frozen_at_A_cross' if crossing is not None else 'developing_terminal_candidate') if terminal else 'unknown',
            retracement_ratio=ratio,book_typical_40_80=(0.4<=ratio<=0.8),
            ratio_is_admission_gate=False,B_crossed=sign*(price-B['price'])<0,
            terminal_on_A_cross_bar=extreme==crossing,subdivision_status='unknown')
    except (KeyError,TypeError,ValueError,IndexError):return dict(base,reason='source_unbound')
