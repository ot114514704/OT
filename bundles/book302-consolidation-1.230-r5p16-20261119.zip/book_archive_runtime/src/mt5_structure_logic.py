"""Source-grounded evidence reducer for the shared scene, never a second ZigZag.

Observations are evaluated at the scene cutoff. They do not overwrite the
original author's degree adjudication, price geometry or earlier saved scenes.
"""
from datetime import datetime, timezone
from bisect import bisect_right
from statistics import median
from .build_archive_window_snapshot import TIMEFRAME_MINUTES
from .force_strength_model import evaluate_strength

VERSION = 'integrated_structure_evidence_v2_causal_retests'
PARENTS = dict(M1='M5', M5='M15', M15='M30', M30='H1', H1='H4', H4='D1', D1='W1')
SOURCES = ['Four:W5-20261017-INTEGRATED-REFERENCE-LOGIC',
           'Alexander:B1:299,410,424-435,631-634,1068',
           'https://www.brookstradingcourse.com/trading-strategies/5-steps-to-finding-todays-trades/',
           'https://www.elliottwave.com/waveopedia/motive-waves/']


def epoch(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()


def iso(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat()


def point_time(p):
    return epoch(p.get('pivot_timestamp_utc') or p['timestamp_utc'])


def known(p):
    value = p.get('known_at_utc') or p.get('confirmed_at_utc')
    return epoch(value) if value else float('inf')


def closed_bars(rows, tf, cutoff):
    seconds = TIMEFRAME_MINUTES[tf] * 60
    return [dict(b, t=epoch(b['timestamp_utc']), closed=epoch(b['timestamp_utc'])+seconds)
            for b in rows if epoch(b['timestamp_utc'])+seconds <= cutoff]


def parent_read(scene):
    ctx = scene.get('execution_context', {})
    tf = PARENTS.get(scene['timeframe'])
    result = dict(timeframe=tf, state='unknown', source='confirmed_native_pivot_sequence',
                  protected_node_status='not_inferred_from_swing_alone', parent_reversal_confirmed=False)
    if not tf or ctx.get('parent_timeframe') != tf:
        result['reason'] = 'direct_parent_missing_or_mismatched'
        return result
    end = epoch(scene['cutoff_utc'])
    points = [p for p in ctx.get('parent_structure', {}).get('points', []) if known(p) <= end]
    highs = sorted([p for p in points if p['kind']=='high'], key=point_time)[-2:]
    lows = sorted([p for p in points if p['kind']=='low'], key=point_time)[-2:]
    result.update(highs=highs, lows=lows)
    if len(highs)<2 or len(lows)<2:
        result['reason']='insufficient_confirmed_parent_swings'
        return result
    dh=highs[-1]['price']-highs[0]['price'];dl=lows[-1]['price']-lows[0]['price']
    direction=1 if dh>0 and dl>0 else -1 if dh<0 and dl<0 else 0
    result.update(state='up_sequence' if direction>0 else 'down_sequence' if direction<0 else 'mixed_or_range', direction=direction,
                  known_at_utc=iso(max(known(p) for p in highs+lows)))
    # A broken swing only challenges this sequence; it is not a new parent trend.
    bars=closed_bars(ctx.get('parent_bars', []),tf,end)
    node=lows[-1] if direction>0 else highs[-1] if direction<0 else None
    if node:
        breaks=[b for b in bars if b['t']>=known(node) and direction*(b['close']-node['price'])<0]
        result['reference_node']=node
        if breaks:result.update(state='sequence_boundary_broken', first_break_close=iso(breaks[0]['closed']))
    return result


def force_metrics(bars, a, b):
    start,end=point_time(a),point_time(b)
    part=[r for r in bars if start<=r['t']<=end]
    if not part:return {'state':'missing_native_bars'}
    sign=1 if b['price']>a['price'] else -1
    ranges=[r['high']-r['low'] for r in part]
    travel=sum(abs(y['close']-x['close']) for x,y in zip(part,part[1:]))
    overlaps=[max(0,min(x['high'],y['high'])-max(x['low'],y['low']))/max(1e-12,min(x['high']-x['low'],y['high']-y['low'])) for x,y in zip(part,part[1:])]
    prior=[r['high']-r['low'] for r in bars if r['t']<start][-20:]
    net=abs(b['price']-a['price'])
    return dict(state='observed', bars=len(part),net_points=net,speed_points_per_bar=net/len(part),
                close_path_efficiency=abs(part[-1]['close']-part[0]['close'])/travel if travel else None,
                directional_body_fraction=sum(max(0,sign*(r['close']-r['open'])) for r in part)/sum(ranges) if sum(ranges) else None,
                mean_bar_overlap=sum(overlaps)/len(overlaps) if overlaps else None,
                net_to_prior_median_range=net/median(prior) if prior and median(prior)>0 else None,
                quality_class='not_calibrated', liquidity_depth='unavailable_ohlc_only')


def pattern_read(pattern):
    """Composite endpoint spans are not the sum of overlapping push heights."""
    a=pattern.get('anchors',[])
    if len(a)!=6:return dict(state='incomplete_anchors')
    q=[x['price'] for x in a];h=[abs(q[i+1]-q[i]) for i in (0,2,4)]
    measures=[('P1:P2',h[0],h[1]),('P2:P3',h[1],h[2]),
              ('span(P1,P2):P3',abs(q[3]-q[0]),h[2]),
              ('P1:span(P2,P3)',h[0],abs(q[5]-q[2]))]
    sign=1 if q[1]>q[0] else -1
    pct=[h[i]/abs(q[2*i]) if q[2*i] else None for i in range(3)]
    checks=dict(alternating=all(sign*(1 if i%2==0 else -1)*(q[i+1]-q[i])>0 for i in range(5)),
        wave2_inside_wave1=sign*(q[2]-q[0])>0,
        wave3_beyond_wave1=sign*(q[3]-q[1])>0,
        wave4_inside_wave3=sign*(q[4]-q[2])>0,
        strict_impulse_wave4_no_wave1_overlap=sign*(q[4]-q[1])>0,
        wave3_not_shortest_percentage=all(x is not None for x in pct) and pct[1]>=min(pct[0],pct[2]))
    return dict(state='geometric_hypotheses_only',family='Alexander_overlapping_three_push',
        composite_measurements=[dict(relation=name,left_span=left,right_span=right,relative_mismatch=abs(left-right)/max(left,right) if max(left,right)>0 else None)
                                for name,left,right in measures],
        measurement_policy='endpoint net spans; no tolerance or selected prediction invented',
        elliott=dict(checks=checks,state='fails_strict_impulse_geometry' if not all(checks.values()) else 'geometry_passes_subdivision_and_degree_unverified',
                     diagonal_not_evaluated=True,renames_zigzag=False))


def response(bars, c, sign, pivots, available):
    """Separate a wick sweep, body recovery, following close and later retest."""
    reference_kind='low' if sign>0 else 'high'
    anchor_time=point_time(c)
    refs=[p for p in pivots if p.get('kind')==reference_kind and point_time(p)<anchor_time
          and known(p)<=anchor_time and sign*(c['price']-p['price'])<0]
    result=dict(state='no_preexisting_swept_reference', sweep=None, reclaim=None,follow=None,retest=None)
    if not refs:return result
    ref=max(refs,key=point_time)
    result.update(sweep=dict(reference=ref,tip=c),state='sweep_observed')
    # C's candle order is unknown: response must come from a strictly later bar.
    later=[b for b in bars if b['t']>anchor_time]
    recover=next((b for b in later if sign*(b['close']-ref['price'])>0 and sign*(b['close']-b['open'])>0),None)
    if not recover:return result
    result.update(state='reclaimed',reclaim=iso(recover['closed']),signal_bar=recover,
                  known_at_utc=iso(max(available,recover['closed'])))
    follow=next((b for b in later if b['t']>=recover['closed'] and sign*(b['close']-recover['close'])>0),None)
    # An intervening close back through the reference defeats this attempt.
    failure=next((b for b in later if b['t']>=recover['closed'] and sign*(b['close']-ref['price'])<=0),None)
    if follow and (not failure or follow['t']<failure['t']):
        result.update(state='reclaimed_with_follow',follow=iso(follow['closed']))
    retest=next((b for b in later if b['t']>=recover['closed'] and b['low']<=ref['price']<=b['high'] and sign*(b['close']-ref['price'])>0),None)
    if retest and (not failure or retest['t']<failure['t']):result['retest']=iso(retest['closed'])
    if failure:result.update(state='reclaim_failed',failed_at_utc=iso(failure['closed']))
    return result


def force_retests(bars, force, sign, break_failed=None):
    """Internal retests stop at first structural failure; 127.2 is separate.

    No band edge is invented as a stop. A close beyond the force origin or a
    previously failed boundary ends this ordinary retest setup. A later reclaim
    must be evaluated as a new setup, not resurrect the earlier one.
    """
    x,y=force['points']
    later=[r for r in bars if r['t']>y[0]]
    origin_fail=next((r for r in later if sign*(r['close']-x[1])<=0),None)
    origin_sweep=next((r for r in later
                       if sign*((r['low'] if sign>0 else r['high'])-x[1])<0),None)
    failures=[r for r in (origin_fail,break_failed) if r is not None]
    fail=min(failures,key=lambda r:r['t']) if failures else None
    out=[]
    for label,r1,r2 in [('50–61.8%',.5,.618),('77–88%',.77,.88),('127.2% second sweep',1.272,1.272)]:
        lo,hi=sorted(y[1]-(y[1]-x[1])*r for r in (r1,r2))
        hits=[r for r in later if r['t']>=known(force) and r['low']<=hi and r['high']>=lo]
        internal=r1<1
        accepted=next((r for r in hits if internal and (not fail or r['t']<fail['t'])
                       and (not origin_sweep or r['t']<origin_sweep['t'])
                       and sign*(r['close']-(hi if sign>0 else lo))>0
                       and sign*(r['close']-r['open'])>0),None)
        state=('separate_sweep_setup_required' if not internal and hits else
               'invalidated' if internal and fail else
               'separate_sweep_setup_required' if internal and origin_sweep else
               'close_recovered' if accepted else 'touched' if hits else 'waiting')
        out.append(dict(band=label,low=lo,high=hi,
            first_touch_utc=iso(hits[0]['closed']) if hits else None,
            accepted_close_utc=iso(accepted['closed']) if accepted else None,
            invalidated_at_utc=iso(fail['closed']) if internal and fail else None,
            origin_swept_at_utc=iso(origin_sweep['closed']) if origin_sweep else None,
            state=state,route_family='ordinary_retest' if internal else 'separate_second_sweep',
            selection='unselected_competing_band'))
    return out


def first_break(scene,bars,c,sign,pivots):
    # Two pre-C countertrend pivots define a reproducible resistance/support
    # boundary. It is labelled a boundary candidate, not a fully proved channel.
    kind='high' if sign>0 else 'low'
    anchor_time,anchor_known=point_time(c),known(c)
    pts=sorted([p for p in pivots if p.get('kind')==kind and point_time(p)<anchor_time
                and known(p)<=anchor_known],key=point_time)[-2:]
    out=dict(state='missing_preexisting_channel_boundary',channel_status='two_pivot_boundary_candidate',
             first_event_only=True,force_object_id=None)
    if len(pts)<2 or point_time(pts[0])==point_time(pts[1]):return out
    a,b=pts;first_time,last_time=point_time(a),point_time(b)
    slope=(b['price']-a['price'])/(last_time-first_time)
    if sign*slope>0:return dict(out,state='boundary_not_countertrend')
    level=lambda t:b['price']+slope*(t-last_time)
    # Lock the earliest post-C close crossing, including its failures.
    boundary_known=max(known(a),known(b))
    later=[r for r in bars if r['t']>anchor_time and r['t']>=boundary_known]
    hit=None
    for r in later:
        previous=next((v for v in reversed(bars) if v['t']<r['t']),None)
        if previous and sign*(previous['close']-level(previous['closed']))<=0 and sign*(r['close']-level(r['closed']))>0:
            hit=r;break
    out['boundary']=pts
    if not hit:return dict(out,state='no_opposite_close_break')
    out.update(state='first_close_break',first_close_utc=iso(hit['closed']),first_bar_utc=hit['timestamp_utc'])
    fail=next((r for r in later if r['t']>=hit['closed'] and sign*(r['close']-level(r['closed']))<=0),None)
    if fail:out.update(state='first_break_failed',failed_at_utc=iso(fail['closed']))
    cutoff=epoch(scene['cutoff_utc']) if scene.get('cutoff_utc') else max((r['closed'] for r in bars),default=0)
    forces=[]
    for obj in scene['objects']:
        if obj['layer']!='force' or known(obj)>cutoff:continue
        x,y=obj['points']
        if x[0]==anchor_time and abs(x[1]-c['price'])<1e-7 and sign*(y[1]-x[1])>0 and y[0]>=hit['t']:
            forces.append(obj)
    if not forces:return out
    force=min(forces,key=lambda o:(o['points'][1][0],o['known_at_utc'],o['id']))
    x,y=force['points'];out.update(state='first_complete_force_observed',force_object_id=force['id'],known_at_utc=force['known_at_utc'],
        strength_profile=force.get('strength_profile',{}),
        quality=force_metrics(bars,dict(timestamp_utc=iso(x[0]),price=x[1]),dict(timestamp_utc=iso(y[0]),price=y[1])))
    if fail:out.update(state='first_break_failed',failed_at_utc=iso(fail['closed']))
    out['retests']=force_retests(bars,force,sign,fail)
    return out


def attach_logic(scene):
    cutoff=epoch(scene['cutoff_utc']);tf=scene['timeframe'];bars=closed_bars(scene.get('execution_context',{}).get('bars',[]),tf,cutoff)
    # One immutable observation's time positions only. Never retain a score or
    # future outcome. Unordered legacy rows keep the original predicate path.
    bar_times=[row['t'] for row in bars]
    ordered=all(a<=b for a,b in zip(bar_times,bar_times[1:]))
    strength_rows=[[r['t'],r['open'],r['high'],r['low'],r['close']] for r in bars]
    for obj in scene['objects']:
        if obj.get('layer')=='force' and known(obj)<=cutoff:
            obj['strength_profile']=evaluate_strength(strength_rows,obj,tf,TIMEFRAME_MINUTES[tf]*60,
                                                      provider=scene.get('provider','HistData'))
            q=obj['strength_profile']
            obj['label']=obj.get('label','').split(' | Strength:')[0]+f" | Strength:{q['label']} {q['score'] if q['score'] is not None else '?'} /100"
    pivots={}
    for obj in scene['objects']:
        if obj['layer']=='zigzag':
            for p in obj['evidence'].values():
                if isinstance(p,dict) and 'price' in p and known(p)<=cutoff:pivots[(point_time(p),p.get('kind'))]=p
    pivots=list(pivots.values());parent=parent_read(scene)
    patterns={o['evidence']['pattern_id']:o['evidence'] for o in scene['objects'] if o['layer']=='three_push'}
    tasks=[]
    for obj in scene['objects']:
        if obj['layer']!='one_to_one' or 'projection' not in obj['evidence']:continue
        e=obj['evidence'];r=e['record'];a=r['source_origin'];b=r['source_terminal'];c=e['projection']['anchor'];sign=1 if b['price']>a['price'] else -1
        height=abs(b['price']-a['price']);own=e['ownership']
        projection=e['projection']
        later_copy=(projection.get('ordinal',2)>=3 or
                    bool(projection.get('retraces_source_leg_id') and projection['retraces_source_leg_id']!=r['source_leg_id']))
        return_origin=own.get('retraced_wave_origin') or (None if later_copy else a)
        return_terminal=own.get('retraced_wave_terminal') or (None if later_copy else b)
        return_height=abs(return_terminal['price']-return_origin['price']) if return_origin and return_terminal else 0
        owner_bound=bool(return_origin and return_terminal and return_height and
            point_time(return_origin)<point_time(return_terminal)<point_time(c) and
            sign*(return_terminal['price']-return_origin['price'])>0 and
            (not later_copy or (own.get('retraces_source_leg_id')==projection.get('retraces_source_leg_id') and
                               bool(own.get('retraces_source_leg_id')) and known(own)<=cutoff)))
        valid=bool(owner_bound and point_time(a)<point_time(b)<point_time(c) and
               sign*(c['price']-a['price'])>0 and sign*(return_terminal['price']-c['price'])>0 and
               abs(projection['target']-c['price']-sign*height)<.00001 and
               own.get('native_timeframe')==tf and own.get('measurement_source_leg_id')==r['source_leg_id'])
        anchor_time=point_time(c)
        terminal_time=point_time(return_terminal) if owner_bound else None
        return_bars=(bars[bisect_right(bar_times,terminal_time):bisect_right(bar_times,anchor_time)]
            if ordered else [x for x in bars if terminal_time<x['t']<=anchor_time]) if owner_bound else []
        # The task itself is a first-class evidence row, not merely a join
        # result.  Keep the same five-field identity contract used by the
        # integrated packet so a panel/audit can trace it without inferring
        # timestamps or provenance from nested A/B/C objects.
        task_source_id = f"structure_task:{r['source_leg_id']}"
        task=dict(task_id=obj['id'],owner_id=r['source_leg_id'],source_id=task_source_id,
            timeframe=tf,as_of_utc=scene['cutoff_utc'],
            # evaluated_at is the observation clock; no later outcome is
            # consulted when constructing the task.  It is deliberately
            # explicit as known_at for downstream consumers.
            known_at_utc=scene['cutoff_utc'],evaluated_at_utc=scene['cutoff_utc'],
            own_C_valid=valid,source=dict(A=a,B=b,C=c),direction=sign,target=e['projection']['target'],
            measurement_source_height=height,
            retraced_wave=dict(origin=return_origin,terminal=return_terminal,height=return_height or None,
                source_leg_id=own.get('retraces_source_leg_id') or (None if later_copy else r['source_leg_id']),bound=owner_bound),
            depth_ratio=abs(return_terminal['price']-c['price'])/return_height if owner_bound else None,
            mean_retracement_area=sum(max(0,sign*(return_terminal['price']-x['close']))/return_height for x in return_bars)/len(return_bars) if return_bars else None,
            area_definition='mean directional close distance from owned previous-wave terminal divided by that wave height; terminal-exclusive to C-inclusive; original AB remains projection length',
            parent=parent,three_push_ids=[],degree_status='native_owner_verified_author_degree_unresolved',automatic_trade_permission=False)
        for pid,p in patterns.items():
            anchors=p.get('anchors',[])
            if len(anchors)!=6 or known(p)>cutoff:continue
            opposite=(p['kind'].endswith('_down_candidate') and sign>0) or (p['kind'].endswith('_up_candidate') and sign<0)
            if owner_bound and opposite and point_time(return_terminal)<=point_time(anchors[0]) and point_time(anchors[-1])<=point_time(c):task['three_push_ids'].append(pid)
        task['response']=response(bars,c,sign,pivots,max(known(obj),known(c)))
        task['first_force']=first_break(scene,bars,c,sign,pivots)
        later=bars[bisect_right(bar_times,anchor_time):] if ordered else [x for x in bars if x['t']>anchor_time]
        reached=next((x for x in later if sign*((x['high'] if sign>0 else x['low'])-task['target'])>=0),None)
        invalid=next((x for x in later if sign*(x['close']-a['price'])<=0),None)
        task['target_state']=('same_bar_target_and_invalidation_unknown' if invalid and reached and invalid['t']==reached['t'] else
                              'already_reached' if reached and (not invalid or reached['t']<invalid['t']) else
                              'invalidated_source' if invalid else 'pending')
        task['target_reached_at']=iso(reached['closed']) if reached else None
        task['invalidated_at']=iso(invalid['closed']) if invalid else None
        # Target/invalidation are separate temporal claims.  They retain the
        # same identity and an explicit unknown boundary, so a later outcome
        # cannot be mistaken for a fact known at the task cutoff.
        task['target_evidence'] = dict(
            value=task['target'], state=task['target_state'],
            as_of_utc=scene['cutoff_utc'], known_at_utc=scene['cutoff_utc'],
            source_id=task_source_id, timeframe=tf, owner_id=r['source_leg_id'],
            outcome_known_after_cutoff=bool(reached or invalid),
            unknown_boundary=(None if reached or invalid else 'target_outcome_after_cutoff'),
        )
        task['invalidation_evidence'] = dict(
            state=('invalidated' if invalid else 'not_observed_at_cutoff'),
            as_of_utc=scene['cutoff_utc'], known_at_utc=scene['cutoff_utc'],
            source_id=task_source_id, timeframe=tf, owner_id=r['source_leg_id'],
            price=a['price'], observed_at_utc=(iso(invalid['closed']) if invalid else None),
            unknown_boundary=(None if invalid else 'invalidation_not_observed_at_cutoff'),
        )
        tasks.append(task)
    # Retain every possible owner; do not pick the profitable or nearest target.
    bindings={pid:[t['task_id'] for t in tasks if pid in t['three_push_ids']] for pid in patterns}
    for t in tasks:
        common=[]
        if not t['own_C_valid']:common.append('invalid_own_C')
        if parent['state'] not in ('up_sequence','down_sequence') or parent.get('direction')!=t['direction']:common.append('parent_not_aligned_or_boundary_broken')
        if t['target_state']!='pending':common.append('target_not_pending')
        if any(len(bindings[p])>1 for p in t['three_push_ids']):common.append('multiple_return_owners')
        # Native geometry is established, semantic degree is not guessed.
        common.append('author_degree_not_calibrated')
        a=common.copy();b=common.copy()
        if t['response']['state']!='reclaimed_with_follow':a.append('sweep_reclaim_follow_incomplete')
        f=t['first_force']
        if f['state']!='first_complete_force_observed':b.append('first_force_not_complete_or_failed')
        if not any(x['state']=='close_recovered' and x.get('route_family')=='ordinary_retest'
                   for x in f.get('retests',[])):b.append('no_post_confirmation_retest_acceptance')
        selection=f.get('strength_profile',{}).get('band_selection',{})
        if not selection.get('preferred_band'):b.append('retest_band_selection_not_calibrated')
        elif selection.get('preferred_band')=='127.2':b.append('separate_resweep_setup_required')
        else:
            selected_label={'50_61.8':'50–61.8%','77_88':'77–88%'}[selection['preferred_band']]
            if not any(x['band']==selected_label and x['state']=='close_recovered' for x in f.get('retests',[])):
                b.append('preferred_band_acceptance_missing')
        t['routes']={'A':dict(state='blocked' if a else 'research_ready',blockers=a),
                     'B':dict(state='blocked' if b else 'research_ready',blockers=b)}
    scene['structure_logic']=dict(version=VERSION,as_of_utc=scene['cutoff_utc'],source_refs=SOURCES,parent=parent,tasks=tasks,
        patterns={pid:pattern_read(p) for pid,p in patterns.items()},
        pattern_owner_candidates=bindings,policy=dict(direct_flip='forbidden_by_user',swing_is_protected_node=False,
        three_push_is_elliott_impulse=False,sweep_is_parent_reversal=False,geometry_is_entry_permission=False),
        summary=dict(owned_returns=len(tasks),contained_patterns=sum(bool(x) for x in bindings.values()),
          ambiguous_patterns=sum(len(x)>1 for x in bindings.values()),
          response_with_follow=sum(t['response']['state']=='reclaimed_with_follow' for t in tasks),
          first_force_observed=sum(t['first_force']['state']=='first_complete_force_observed' for t in tasks)))
    for o in scene['objects']:
        ids=[t['task_id'] for t in tasks if o['id']==t['task_id'] or o['id']==t['first_force'].get('force_object_id')
             or (o['layer']=='three_push' and o['evidence'].get('pattern_id') in t['three_push_ids'])]
        o['structure_task_ids']=ids
    from .one_to_one_scene_binding import attach_owned_scene_scores
    attach_owned_scene_scores(scene)
    return scene
