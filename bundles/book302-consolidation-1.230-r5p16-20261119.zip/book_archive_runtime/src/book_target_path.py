"""Native price visits to chapter7 target alternatives (PDF202,207-208).

A visit is neither a fill nor proof of author wave degree. Track from the
first close beyond A that freezes the correction ruler, including visits
before the separately qualified dual-boundary crossing.
"""
from math import isfinite
from .book_first_response_leg import clock,close_time

BOOK_THIRD_WAVE_RATIOS=(1.0,1.618)  # PDF207-208; alternatives, not a chosen exit.


def observe_target_options(bars,timeframe,cutoff,origin,amplitude,direction,
                           freeze_cross_utc,qualified_cross_utc,measurement_known_at):
    sign=1 if direction=='up' else -1
    return [dict(ratio=ratio,target_price=origin+sign*amplitude*ratio,
        target_path_observation=observe_target_path(bars,timeframe,cutoff,
            origin+sign*amplitude*ratio,direction,freeze_cross_utc,qualified_cross_utc,measurement_known_at))
        for ratio in BOOK_THIRD_WAVE_RATIOS]


def observe_target_path(bars,timeframe,cutoff,target,direction,freeze_cross_utc,
                        qualified_cross_utc,measurement_known_at):
    base=dict(status='unknown',timeframe=timeframe,as_of_utc=cutoff,target_price=target,
              automatic_trade_permission=False,fill_confirmed=False,source_pdf_pages=[202,207,208],
              basis='closed_native_OHLC_price_visit_not_execution',
              first_touch=None,first_unambiguous_reach=None)
    if not freeze_cross_utc:return dict(base,status='projection_origin_developing')
    try:
        sign=1 if direction=='up' else -1 if direction=='down' else 0
        if not sign or isinstance(target,bool) or not isfinite(target) or target<=0:
            return dict(base,reason='invalid_target')
        rows=[r for r in bars if clock(close_time(r,timeframe))<=clock(cutoff)]
        start=next(i for i,r in enumerate(rows) if clock(r['timestamp_utc'])==clock(freeze_cross_utc))
        if clock(measurement_known_at)>clock(cutoff):return dict(base,reason='future_measurement')
        first=None;reach=None
        for i in range(start,len(rows)):
            row=rows[i];extreme=float(row['high' if sign>0 else 'low'])
            if not isfinite(extreme) or extreme<=0:return dict(base,reason='invalid_native_price')
            if sign*(extreme-target)<0:continue
            close=float(row['close'])
            at_freeze=i==start
            unambiguous=not at_freeze or sign*(close-target)>=0
            event=dict(utc=row['timestamp_utc'],event_closed_at_utc=close_time(row,timeframe),
                extreme_price=extreme,close_price=close,
                known_at_utc=max((measurement_known_at,close_time(row,timeframe)),key=clock),
                timing=('historical_reconstruction' if clock(measurement_known_at)>clock(close_time(row,timeframe))
                        else 'observed_with_known_measurement'),
                relative_to_qualified_cross=('qualified_cross_not_observed' if not qualified_cross_utc else
                    'before' if clock(row['timestamp_utc'])<clock(qualified_cross_utc) else
                    'same_bar' if clock(row['timestamp_utc'])==clock(qualified_cross_utc) else 'after'),
                order_status=('touch_on_freezing_bar_order_unknown' if not unambiguous else
                              'reached_at_freezing_close' if at_freeze else 'reached_after_freezing_close'))
            if first is None:first=event
            if unambiguous:reach=event;break
        status=('target_reached_observed' if reach else 'freezing_bar_touch_order_unknown' if first else 'not_reached_in_observed_prefix')
        return dict(base,status=status,first_touch=first,first_unambiguous_reach=reach,
            freeze_cross_utc=freeze_cross_utc,known_at_utc=(reach or first or {}).get('known_at_utc',cutoff))
    except (KeyError,TypeError,ValueError,StopIteration):return dict(base,reason='native_path_or_clock_unbound')
