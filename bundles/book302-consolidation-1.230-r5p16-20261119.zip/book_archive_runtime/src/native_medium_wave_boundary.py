"""Research-only native medium-wave boundary selection.

The normal regime reader deliberately keeps a composite outer source.  This
module isolates the one native terminal component that begins at the last
confirmed same-period pullback before that source's B.  It is a review layer:
it never changes trade permission or author degree and is only enabled by an
explicit trial flag.
"""

from __future__ import annotations

from hashlib import sha256
from typing import Any


def _stamp(value: Any) -> str:
    return value if isinstance(value, str) else ""


def _price(point: dict[str, Any] | None) -> float | None:
    value = (point or {}).get("price")
    return value if isinstance(value, (int, float)) else None


def _direction(origin: dict[str, Any], terminal: dict[str, Any]) -> str | None:
    a, b = _price(origin), _price(terminal)
    if a is None or b is None or a == b:
        return None
    return "up" if b > a else "down"


def derive_medium_terminal_component(family: dict[str, Any], legs: list[dict[str, Any]],
                                     timeframe: str, cutoff: str,
                                     *, min_outer_ratio: float = 0.15) -> dict[str, Any] | None:
    """Return one causal medium candidate, or ``None``.

    The candidate is admitted only when the source itself is an explicit
    transition-pair trial, its terminal component is the final component of
    the same-period envelope, both endpoints are confirmed by the observation
    clock, and its height is material relative to the outer composite.  The
    relative guard prevents every small internal turn becoming a box while
    leaving the full outer span in the research inventory.
    """
    trial = family.get("source_admission_trial") or {}
    if trial.get("production_default") is not False:
        return None
    structure = family.get("structure_observation") or {}
    local_id = structure.get("local_leg_id")
    ids = list(family.get("component_source_leg_ids") or structure.get("component_leg_ids") or [])
    if not local_id or not ids or ids[-1] != local_id or len(ids) < 3:
        return None
    by_id = {row.get("leg_id"): row for row in legs if isinstance(row, dict)}
    local = by_id.get(local_id)
    if not local:
        return None
    origin, terminal = local.get("origin"), local.get("terminal")
    outer_origin, outer_terminal = family.get("source_origin"), family.get("source_terminal")
    if not isinstance(origin, dict) or not isinstance(terminal, dict):
        return None
    if not isinstance(outer_origin, dict) or not isinstance(outer_terminal, dict):
        return None
    if _direction(origin, terminal) != _direction(outer_origin, outer_terminal):
        return None
    if terminal.get("pivot_timestamp_utc") != outer_terminal.get("pivot_timestamp_utc"):
        return None
    known = max(_stamp(origin.get("confirmed_at_utc")), _stamp(terminal.get("confirmed_at_utc")),
                _stamp(family.get("known_at_utc")))
    if not known or known > cutoff:
        return None
    local_height = abs((_price(terminal) or 0) - (_price(origin) or 0))
    outer_height = abs((_price(outer_terminal) or 0) - (_price(outer_origin) or 0))
    if not local_height or not outer_height or local_height / outer_height < min_outer_ratio:
        return None
    identity = sha256(repr((timeframe, origin, terminal, family.get("measurement_id"))).encode()).hexdigest()[:24]
    return {
        "measurement_id": f"{timeframe}:medium:{identity}",
        "source_leg_id": local_id,
        "timeframe": timeframe,
        "snapshot_id": family.get("snapshot_id"),
        "as_of_utc": family.get("as_of_utc"),
        "source_origin": origin,
        "source_terminal": terminal,
        "known_at_utc": known,
        "direction_observation": _direction(origin, terminal),
        "source_height": local_height,
        "signed_source_length": local_height if _direction(origin, terminal) == "up" else -local_height,
        "mode": (family.get("regime_at_source") or {}).get("state") or family.get("mode") or "unknown",
        "local_state": (family.get("regime_at_source") or {}).get("state") or "unknown",
        "source_kind": "medium_terminal_component_candidate",
        "component_source_leg_ids": [local_id],
        "nested_child_ids": [],
        "projections": [],
        "return_ownership_by_projection_id": {},
        "interior_unordered_bar_times": [],
        "intrabar_order_inferred": False,
        "eligible_for_measurement": True,
        "parent_measurement_id": family.get("measurement_id"),
        "outer_source_origin": outer_origin,
        "outer_source_terminal": outer_terminal,
        "outer_source_height": outer_height,
        "outer_ratio": local_height / outer_height,
        "boundary_rule": "last_confirmed_same_period pullback origin to the current outer terminal; relative height guard",
        "source_admission_trial": {
            "production_default": False,
            "known_at_utc": known,
            "parent_measurement_id": family.get("measurement_id"),
            "local_component_is_final": True,
            "same_period_only": True,
            "structural_degree_adjudicated": False,
            "trade_permission": False,
        },
        "eligible_for_chart": False,
        "eligible_for_projection": False,
        "structural_degree_adjudicated": False,
        "trade_permission": False,
    }


def derive_medium_terminal_components(families: list[dict[str, Any]], legs: list[dict[str, Any]],
                                      timeframe: str, cutoff: str, **kwargs: Any) -> list[dict[str, Any]]:
    rows = []
    seen = set()
    for family in families:
        row = derive_medium_terminal_component(family, legs, timeframe, cutoff, **kwargs)
        if row and row["measurement_id"] not in seen:
            seen.add(row["measurement_id"])
            rows.append(row)
    return rows
