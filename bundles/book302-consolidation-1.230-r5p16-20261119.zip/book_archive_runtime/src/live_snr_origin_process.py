"""Reconstruct a candidate node's approach and departure, not its author identity.

The coarse close-path can be revised. Its three points are current-cutoff
geometry; their candle closes do not prove when a ZigZag turn was knowable.
Native high/low legs remain a separate layer, linked by interval overlap only.
"""
from datetime import timedelta

try:
    from .live_nested_stage_review import MINUTES, _native, _leg, _time, _number
except ImportError:
    from live_nested_stage_review import MINUTES, _native, _leg, _time, _number


def native_origin_context(snapshot, timeframe):
    """Build once per timeframe; malformed market identity fails closed."""
    try:
        if any(not isinstance(snapshot.get(k), str) or not snapshot[k].strip()
               for k in ("snapshot_id", "instrument", "provider")):
            return None
        cutoff = _time(snapshot["as_of_utc"])
        state, raw, legs = _native(snapshot, timeframe, cutoff)
        return state, raw, [leg for leg in legs if _leg(leg, timeframe, raw, cutoff)]
    except (KeyError, TypeError, ValueError, AttributeError):
        return None


def build_snr_origin_process(snapshot, timeframe, zone, context=None):
    result = {"status": "origin_not_bound", "timeframe": timeframe,
              "snapshot_id": snapshot.get("snapshot_id"), "as_of_utc": snapshot.get("as_of_utc"),
              "zone_id": zone.get("zone_id"), "author_snr_identity_confirmed": False,
              "creator_leg_adjudicated": False, "trade_permission": False,
              "native_interval_segments": [], "readout": "形成这处价带的来回波段还未对齐。"}
    context = context if context is not None else native_origin_context(snapshot, timeframe)
    if context is None:
        return result
    try:
        state, raw, legs = context
        latest = state["latest_closed_bar"]
        evidence = zone["evidence_ref"]
        path = zone["origin_close_path"]
        if (zone.get("timeframe") != timeframe or evidence.get("timeframe") != timeframe
                or evidence.get("as_of_utc") != snapshot["as_of_utc"]
                or evidence.get("window_through_utc") != latest["timestamp_utc"]
                or path.get("selection") != "current_cutoff_close_path_not_causal_pivot_confirmation"):
            return result
        prior, turn, departure = (path[key] for key in ("prior", "turn", "departure"))
        stamps = [_time(point["bar_open_utc"]) for point in (prior, turn, departure)]
        for point, stamp in zip((prior, turn, departure), stamps):
            if not _number(point.get("close")) or raw.get(stamp, {}).get("close") != point["close"]:
                return result
        low, high = zone["price_low"], zone["price_high"]
        if (not stamps[0] < stamps[1] < stamps[2] <= _time(latest["timestamp_utc"])
                or _time(zone["formed_after_utc"]) != stamps[2]
                or not all(_number(p) for p in (low, high)) or not low < high
                or not low <= turn["close"] <= high):
            return result
        kind = ("upper" if turn["close"] > max(prior["close"], departure["close"]) else
                "lower" if turn["close"] < min(prior["close"], departure["close"]) else None)
        if not kind or turn.get("kind") != kind:
            return result
        anchors = zone["turning_points"]
        first = min(anchors, key=lambda point: _time(point["utc"]))
        if (first["utc"] != turn["bar_open_utc"] or first["price"] != turn["close"] or first["kind"] != kind
                or any(not _number(point["price"]) or not low <= point["price"] <= high
                       or raw.get(_time(point["utc"]), {}).get("close") != point["price"]
                       or _time(point["utc"]) > _time(latest["timestamp_utc"]) for point in anchors)):
            return result
        departure_direction = "down" if kind == "upper" else "up"
        departure_side = "below" if departure["close"] < low else "above" if departure["close"] > high else "inside"
        final_side = "below" if latest["close"] < low else "above" if latest["close"] > high else "inside"
        relation = ("departure_not_outside_current_band" if departure_side == "inside" else
                    "testing_origin_area" if final_side == "inside" else
                    "on_departure_side" if final_side == departure_side else "on_other_side_of_origin")
        overlapping = [leg for leg in legs if
                       _time(leg["origin"]["pivot_timestamp_utc"]) < stamps[2] and
                       _time(leg["terminal"]["pivot_timestamp_utc"]) > stamps[1]]
        native_segments = [{key: leg[key] for key in
                           ("leg_id", "timeframe", "origin", "terminal", "direction_observation")}
                           for leg in overlapping]
        source_sequence = f'{prior["close"]:.2f}→{turn["close"]:.2f}→{departure["close"]:.2f}'
        turn_name = "上行在这里转下" if kind == "upper" else "下行在这里转上"
        role = ("原离开端点仍落在如今候选带内，不能据此说已经离开价带" if relation == "departure_not_outside_current_band" else
                "现在又回到转折附近" if relation == "testing_origin_area" else
                "现在仍在当初离开的这一侧" if relation == "on_departure_side" else
                "现在已收在当初离开的另一侧")
        result.update(status="native_checked_close_path_origin", prior=prior, turn=turn, departure=departure,
                      departure_direction=departure_direction, departure_close_side=departure_side,
                      latest_close_side=final_side, origin_relation=relation,
                      departure_bar_end_utc=(stamps[2]+timedelta(minutes=MINUTES[timeframe])).isoformat().replace("+00:00", "Z"),
                      path_selection_known_at_origin=False,
                      band_revised_with_later_turns=any(_time(point["utc"]) > stamps[2] for point in anchors),
                      native_interval_segments=native_segments,
                      native_link_method="overlapping_native_intervals_not_creator_identity",
                      readout=f'{timeframe} 收盘轨迹 {source_sequence}，{turn_name}；{role}。',
                      boundary="三点是当前截点的折线概括，不证明起点时已知转折、支压转换或平衡突破；原生高低点波段单独保留。")
    except (KeyError, TypeError, ValueError, AttributeError):
        return result
    return result
