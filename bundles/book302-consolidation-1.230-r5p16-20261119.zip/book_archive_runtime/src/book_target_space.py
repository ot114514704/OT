"""Same-owner price space for a chapter7 target; no entry/fill/position claim."""
from .book_first_response_leg import clock
from .force_entry_space import geometry,number


def target_space(target,response,stop,quote,timeframe,cutoff):
    base=dict(status='unknown',timeframe=timeframe,trade_permission=False,entry_permission=False,automatic_trade_permission=False,
              costs_status='not_evaluated',minimum_reward_risk=None,position_size=None,
              target_author_state='unverified',reference_is_executable_entry=False)
    if target.get('status')!='theoretical_candidate':return dict(base,reason='target_source_unavailable')
    try:
        if target['owner_id']!=response['owner_id'] or target['source_id']!=(response.get('prior_B_A_backtrack') or {}).get('source_id'):
            return dict(base,reason='target_owner_mismatch')
        bt,b=response['origin_B']['point']
        if target.get('direction') not in ('up','down') or target['direction']!=response.get('direction'):
            return dict(base,reason='source_direction_mismatch')
        if target.get('source_B')!=b:
            return dict(base,reason='target_B_source_mismatch')
        if response.get('status')=='source_invalidated':
            return dict(base,reason='source_invalidated')
        if (stop.get('status')!='observed_candidate' or stop.get('basis')!='frozen_pre_break_extreme_B'
            or stop.get('reference_price')!=b or clock(stop['reference_utc']).timestamp()!=bt):
            return dict(base,reason='protective_B_source_mismatch')
        if any(fact.get('timeframe')!=timeframe for fact in (target,stop,quote)):
            return dict(base,reason='cross_period_reference')
        if any(clock(fact['known_at_utc'])>clock(cutoff) for fact in (target,stop,quote)):
            return dict(base,reason='future_reference')
        sign=1 if target['direction']=='up' else -1
        ratio=target.get('measurement_ratio',1.618)
        target_price=target['target_price'] if 'target_price' in target else target['target_1618']
        if 'measurement_ratio' in target:
            if ratio not in (1.0,1.618) or target_price!=target['projection_origin']+(target['source_A']-b)*ratio:
                return dict(base,reason='target_ratio_or_price_mismatch')
        current=quote['close_price']
        if not all(number(p) and p>0 for p in (b,current,target_price)):
            return dict(base,reason='invalid_prices')
        latest=geometry(current,b,target_price,sign)
        crossing=target.get('A_cross_observation') or {}
        trigger=dict(status='unavailable',reason='A_close_cross_not_observed')
        trigger_timing='not_observed'
        if crossing.get('status')=='closed_cross_observed':
            if clock(crossing['known_at_utc'])>clock(cutoff):return dict(base,reason='future_trigger_reference')
            trigger=geometry(crossing.get('closed_reference_price'),b,target_price,sign)
            event_closed=crossing.get('event_closed_at_utc')
            trigger_timing=('unknown_without_event_close_clock' if not event_closed else
                'historical_reconstruction' if max(clock(target['known_at_utc']),clock(stop['known_at_utc']),
                    clock(crossing['known_at_utc']))>clock(event_closed) else 'references_known_at_cross_close')
            if event_closed and clock(event_closed)>clock(cutoff):return dict(base,reason='future_trigger_reference')
        current_status=('invalid_current_price_geometry' if not latest['valid'] else
            'waiting_A_cross' if crossing.get('status')!='closed_cross_observed' else
            'historical_source_reference' if trigger_timing!='references_known_at_cross_close' else
            'author_source_and_entry_unverified')
        path=target.get('target_path_observation') or {}
        if path.get('known_at_utc') and clock(path['known_at_utc'])>clock(cutoff):
            return dict(base,reason='future_target_path')
        if path.get('target_price') is not None and path['target_price']!=target_price:
            return dict(base,reason='target_path_price_mismatch')
        if path.get('status')=='target_reached_observed':current_status='target_already_reached'
        elif path.get('status')=='freezing_bar_touch_order_unknown':current_status='target_touch_order_unknown'
        return dict(base,status='descriptive_price_space',owner_id=target['owner_id'],
            measurement_ratio=ratio,target_price=target_price,
            source_id=target['source_id'],source_wave_id=target.get('source_wave_id'),
            protective_B=dict(utc=stop['reference_utc'],price=b),
            A_cross_closed_geometry=trigger,current_closed_geometry=latest,
            A_cross_geometry_timing=trigger_timing,A_cross_event_closed_at_utc=crossing.get('event_closed_at_utc'),
            reference_status=current_status,current_entry_available=False,
            target_path_observation=path,
            current_reference_known_at_utc=quote['known_at_utc'],
            known_at_utc=max([f['known_at_utc'] for f in (target,stop,quote)]+([path['known_at_utc']] if path.get('known_at_utc') else []),key=clock),
            source_selection_ambiguity=target.get('source_selection_ambiguity','unknown'),
            projection_origin_status=target.get('projection_origin_status','unknown'),
            next_required='author_source_and_entry_method_risk_cost_review')
    except (KeyError,TypeError,ValueError):return dict(base,reason='reference_identity_or_clock_missing')
