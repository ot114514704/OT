"""Same-period A→B distance projected from both B and confirmed C.

The direct B-origin doubling and the post-pullback C-origin second leg are
separate rulers. Their price difference is observable but does not by itself
prove a reversal. Directional task and force identity remain prerequisites.
"""
from __future__ import annotations

from datetime import datetime
from bisect import bisect_left, bisect_right
import hashlib
import json
from math import isfinite
from typing import Any

try:
    from .live_measurement_map import build_measurement_map
    from .live_measurement_source_context import build_measurement_source_context
    from .live_snr_origin_process import build_snr_origin_process, native_origin_context
    from .live_parent_objective_context import build_parent_objective_review
    from .live_one_to_one_admission import apply_one_to_one_admission
    from .live_one_to_one_source_selection import attach_source_selection_reviews
except ImportError:
    from live_measurement_map import build_measurement_map
    from live_measurement_source_context import build_measurement_source_context
    from live_snr_origin_process import build_snr_origin_process, native_origin_context
    from live_parent_objective_context import build_parent_objective_review
    from live_one_to_one_admission import apply_one_to_one_admission
    from live_one_to_one_source_selection import attach_source_selection_reviews


def _time(value):
    return datetime.fromisoformat(str(value).replace("Z", "+00:00"))


def _number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and isfinite(value)


class _MeasurementHistoryIndex:
    """Exact per-call native windows/first crossings; no persistent decisions.

    Only strictly ordered, valid native OHLC can use the shortcut. Malformed
    input uses the original reference path, including its rejection behavior.
    Queries are bounded by the same source/confirmation/latest timestamps.
    """
    def __init__(self, history, timeframe):
        self.valid = False
        self.history = history
        self.timeframe = timeframe
        self._times = {}
        self.raw = {}
        try:
            self.raw = {bar['timestamp_utc']: bar for bar in history}
            self.times = [self.time(bar['timestamp_utc']) for bar in history]
            if len(self.raw) != len(history) or any(left >= right for left, right in zip(self.times, self.times[1:])):
                return
            if any(bar.get('timeframe', timeframe) != timeframe or
                   not all(_number(bar.get(k)) for k in ('open', 'high', 'low', 'close')) or
                   not bar['low'] <= min(bar['open'], bar['close']) <= max(bar['open'], bar['close']) <= bar['high']
                   for bar in history):
                return
            self.size = 1
            while self.size < len(history):
                self.size *= 2
            self.trees = {}
            for field in ('close', 'high', 'low'):
                lows, highs = [float('inf')] * (2*self.size), [float('-inf')] * (2*self.size)
                for i, bar in enumerate(history):
                    lows[self.size+i] = highs[self.size+i] = bar[field]
                for i in range(self.size-1, 0, -1):
                    lows[i] = min(lows[2*i], lows[2*i+1])
                    highs[i] = max(highs[2*i], highs[2*i+1])
                self.trees[field] = lows, highs
            self.valid = True
        except (KeyError, TypeError, ValueError):
            return

    def time(self, value):
        if value not in self._times:
            self._times[value] = _time(value)
        return self._times[value]

    def bounds(self, start, end, *, exclusive_start=False):
        return ((bisect_right if exclusive_start else bisect_left)(self.times, start),
                bisect_right(self.times, end))

    def window(self, start, end, *, exclusive_start=False):
        lo, hi = self.bounds(start, end, exclusive_start=exclusive_start)
        return self.history[lo:hi]

    def first(self, field, level, upward, lo, hi):
        """First strict crossing in [lo, hi), not an extremum or future bar."""
        lows, highs = self.trees[field]
        def visit(node, left, right):
            if right <= lo or left >= hi or (highs[node] <= level if upward else lows[node] >= level):
                return None
            if right-left == 1:
                return left
            mid = (left+right)//2
            found = visit(2*node, left, mid)
            return found if found is not None else visit(2*node+1, mid, right)
        found = visit(1, 0, self.size)
        return None if found is None else self.history[found]


def _outer_reference_scope(candidates, raw, bars, after_b, reference, latest, timeframe, direction, _history_index=None):
    """Locate an unresolved older outer extreme, not a protected trend node.

    A close through the nearest pivot cannot dispose of a different old pivot.
    Each reference is observed only after its confirmation. Selection is the
    closest unheld price outside that reference, not trend authority. A source
    close followed by a return before the terminal remains unresolved too.
    """
    result = {"status": "loaded_prior_extremes_compared", "timeframe": timeframe,
              "named_trend_node_bound": False, "parent_task_changed": False,
              "force_grade_assigned": False, "trade_permission": False,
              "outer_reference_count": 0, "source_unclosed_outer_count": 0,
              "source_unheld_outer_count": 0,
              "rejected_reference_count": 0, "nearest_unresolved_outer_reference": None,
              "readout": "已载旧节点仍不能代替真正控制趋势的结构。"}
    key = "high" if direction == "up" else "low"
    beyond = lambda price, level: price > level if direction == "up" else price < level
    indexed = _history_index is not None and _history_index.valid and raw is _history_index.raw
    parse = _history_index.time if indexed else _time
    source_end = parse(bars[-1]['timestamp_utc'])
    if indexed:
        source_start = parse(bars[0]['timestamp_utc'])
        _, source_hi = _history_index.bounds(source_start, source_end)
        after_lo, after_hi = _history_index.bounds(source_end, parse(latest['timestamp_utc']), exclusive_start=True)
    pending = []
    for pivot in candidates.values():
        if not _number(pivot.get("price")) or not beyond(pivot["price"], reference["price"]):
            continue
        try:
            timestamp, known = parse(pivot["pivot_timestamp_utc"]), parse(pivot["confirmed_at_utc"])
            original = raw.get(pivot["pivot_timestamp_utc"], {})
            if (not timestamp <= known <= source_end or
                    original.get(key) != pivot["price"] or original.get("timeframe", timeframe) != timeframe or
                    not all(_number(original.get(k)) for k in ("open", "high", "low", "close")) or
                    not original["low"] <= min(original["open"],original["close"]) <= max(original["open"],original["close"]) <= original["high"]):
                raise ValueError("older reference is not native/known")
        except (KeyError, TypeError, ValueError):
            result["rejected_reference_count"] += 1
            continue
        result["outer_reference_count"] += 1
        if indexed:
            observed_lo, _ = _history_index.bounds(max(source_start, known), source_end)
            observed_count = max(0, source_hi-observed_lo)
            source_cross = _history_index.first('close', pivot['price'], direction == 'up', observed_lo, source_hi)
        else:
            observed = [bar for bar in bars if _time(bar["timestamp_utc"]) >= known]
            observed_count = len(observed)
            source_cross = next((bar for bar in observed if beyond(bar["close"], pivot["price"])), None)
        if beyond(bars[-1]["close"], pivot["price"]):
            continue
        result["source_unheld_outer_count"] += 1
        result["source_unclosed_outer_count"] += int(not source_cross)
        if indexed:
            excursion = _history_index.first(key, pivot['price'], direction == 'up', observed_lo, source_hi)
            later_cross = _history_index.first('close', pivot['price'], direction == 'up', after_lo, after_hi)
        else:
            excursion = next((bar for bar in observed if beyond(bar[key], pivot["price"])), None)
            later_cross = next((bar for bar in after_b if beyond(bar["close"], pivot["price"])), None)
        latest_beyond = beyond(latest["close"], pivot["price"])
        current_phase = ("later_close_beyond_outer_reference" if later_cross and latest_beyond else
                         "later_cross_then_returned" if later_cross else
                         "source_cross_then_returned_no_later_cross" if source_cross else
                         "not_closed_beyond_in_loaded_bars")
        pending.append({"reference": dict(pivot), "source_range_exceeded": bool(excursion),
                        "source_close_beyond": bool(source_cross), "source_terminal_close_beyond": False,
                        "first_source_close_beyond_bar_open_utc": source_cross["timestamp_utc"] if source_cross else None,
                        "source_bars_before_reference_confirmation": len(bars)-observed_count,
                        "first_source_excursion_bar_open_utc": excursion["timestamp_utc"] if excursion else None,
                        "first_later_close_beyond_bar_open_utc": later_cross["timestamp_utc"] if later_cross else None,
                        "latest_close_beyond": latest_beyond, "current_phase": current_phase})
    if pending:
        pending.sort(key=lambda item: (abs(item["reference"]["price"]-reference["price"]),
                                      -parse(item["reference"]["pivot_timestamp_utc"]).timestamp()))
        nearest = pending[0]
        result["nearest_unresolved_outer_reference"] = nearest
        node = "旧高点" if direction == "up" else "旧低点"
        price = nearest["reference"]["price"]
        source_read = ("来源段曾收过，但到段末已经收回" if nearest["source_close_beyond"] else
                       "价格范围曾越过，但来源段没有收过" if nearest["source_range_exceeded"] else
                       "来源段没有收过")
        current_read = {"later_close_beyond_outer_reference": "段后已有收盘越过它，仍要看返回和保持。",
                        "later_cross_then_returned": "段后曾收过它，但最新又回到旧侧，不能当作一路保持。",
                        "source_cross_then_returned_no_later_cross": "段末退回以后，尚未重新收过它。",
                        "not_closed_beyond_in_loaded_bars": "到当前已载收盘也还没有收过它。"}[nearest["current_phase"]]
        result["readout"] = (f"更外侧仍有本周期{node} {price:.2f}，{source_read}；{current_read}"
                             "即使过了附近节点，也不等于整段趋势已改变；先看这里的收盘与返回。")
    elif result["rejected_reference_count"]:
        result["readout"] = "部分更外侧旧节点的原生价或确认时间未核齐，不能据此认定外侧结构已清完。"
    else:
        result["readout"] = "已载有效旧节点中未找到来源段末尚未守在新侧的更外侧节点；这不证明趋势节点或更大任务已改变。"
    return result


def _source_structure_review(legs, raw, a, b, c, latest, timeframe, direction, _history_index=None):
    """Compare the measuring leg with a prior native extreme, not a named SNR.

    This is a retrospective observation under the current cutoff. It must not
    promote a fractal to the author's protected trend extreme or creator force.
    """
    result = {
        "status": "unavailable", "timeframe": timeframe,
        "reference_kind": "prior_same_kind_native_geometric_extreme_not_named_trend_node",
        "source_message_ids": ["7685764459885286786", "7685764649186122721", "7685764796256176487"],
        "source_rule_application": "mechanical_analogy_not_author_named_current_case",
        "named_structure_bound": False, "direction_task_confirmed": False,
        "creator_force_confirmed": False, "trade_permission": False,
        "readout": "来源段之前的同周期高低点尚未核齐，不能只凭这把量尺证明方向确立。",
        "next_observation": "先核对第一段过的是哪个同周期节点，而不是先把测量当目标。",
    }
    try:
        indexed = _history_index is not None and _history_index.valid and raw is _history_index.raw
        parse = _history_index.time if indexed else _time
        start, end = parse(a["pivot_timestamp_utc"]), parse(b["pivot_timestamp_utc"])
        candidates = {}
        for leg in legs:
            if leg.get("timeframe") != timeframe:
                continue
            for pivot in (leg.get("origin") or {}, leg.get("terminal") or {}):
                if pivot.get("kind") == b["kind"] and parse(pivot["pivot_timestamp_utc"]) < start:
                    key = pivot["pivot_timestamp_utc"]
                    if key in candidates and candidates[key] != pivot:
                        return result
                    candidates[key] = pivot
        if not candidates:
            result["status"] = "prior_extreme_missing_in_loaded_ledger"
            return result
        ref = max(candidates.values(), key=lambda pivot: parse(pivot["pivot_timestamp_utc"]))
        price_key = "high" if direction == "up" else "low"
        if (not _number(ref.get("price")) or raw.get(ref["pivot_timestamp_utc"], {}).get(price_key) != ref["price"] or
            raw.get(ref["pivot_timestamp_utc"], {}).get("timeframe",timeframe) != timeframe or
            not parse(ref["pivot_timestamp_utc"]) <= parse(ref["confirmed_at_utc"]) <= end):
            return result
        latest_open = parse(latest['timestamp_utc'])
        bars = (_history_index.window(start, end) if indexed else
                sorted((bar for key,bar in raw.items() if start <= _time(key) <= end), key=lambda bar: _time(bar['timestamp_utc'])))
        after_b = (_history_index.window(end, latest_open, exclusive_start=True) if indexed else
                   sorted((bar for key,bar in raw.items() if end < _time(key) <= latest_open), key=lambda bar: _time(bar['timestamp_utc'])))
        if not bars or (not indexed and any(not all(_number(bar.get(k)) for k in ("open","high","low","close")) or
                           not bar["low"] <= min(bar["open"],bar["close"]) <= max(bar["open"],bar["close"]) <= bar["high"] or
                           bar.get("timeframe",timeframe) != timeframe for bar in bars + after_b)):
            return result
        beyond = lambda price: price > ref["price"] if direction == "up" else price < ref["price"]
        reference_known = parse(ref["confirmed_at_utc"])
        observable = [bar for bar in bars if parse(bar['timestamp_utc']) >= reference_known]
        source_crosses = [bar for bar in observable if beyond(bar["close"])]
        wick_crosses = [bar for bar in observable if beyond(bar[price_key])]
        source_final_beyond = beyond(bars[-1]["close"])
        returned = next((bar for bar in after_b if not beyond(bar["close"])), None) if source_final_beyond else None
        phase = ("source_wick_only" if not source_crosses and wick_crosses else
                 "source_did_not_cross_prior_extreme" if not source_crosses else
                 "source_crossed_then_returned_before_terminal" if not source_final_beyond else
                 "source_departure_latest_reclaimed" if returned and beyond(latest["close"]) else
                 "source_departure_latest_returned" if not beyond(latest["close"]) else
                 "source_departure_closes_still_beyond_prior_extreme")
        node = "前一高点" if direction == "up" else "前一低点"
        verb = "上破" if direction == "up" else "下破"
        read = {
            "source_wick_only": f"来源段仅影线越过{node} {ref['price']:.2f}，没有收过；不能据此认定{verb}。",
            "source_did_not_cross_prior_extreme": f"来源段没有越过{node} {ref['price']:.2f}；等距测量不能证明方向已确立。",
            "source_crossed_then_returned_before_terminal": f"来源段曾收过{node} {ref['price']:.2f}，但到段末已收回旧侧，不能按持续{verb}来量。",
            "source_departure_latest_reclaimed": f"来源段收过{node} {ref['price']:.2f}，随后回到旧侧，最新又收出去；不是一路守住的{verb}。",
            "source_departure_latest_returned": f"来源段收过{node} {ref['price']:.2f}，后来已收回旧侧；原延续测量需要重审。",
            "source_departure_closes_still_beyond_prior_extreme": f"来源段收过{node} {ref['price']:.2f}，其后已载收盘仍在新侧；还要核它是否真是控制趋势的节点。",
        }[phase]
        adjacent = list(zip(bars,bars[1:]))
        outer_scope = _outer_reference_scope(candidates, raw, bars, after_b, ref, latest, timeframe, direction, _history_index)
        result.update(status="native_source_leg_prior_extreme_process", phase=phase, reference=ref,
            prior_reference_scope=outer_scope,
            reference_known_before_source_start=reference_known <= start,
            source_bars_before_reference_confirmation=len(bars)-len(observable),
            source_bars_observed_after_reference_confirmation=len(observable),
            source_bar_count=len(bars), source_from_utc=a["pivot_timestamp_utc"], source_through_utc=b["pivot_timestamp_utc"],
            source_origin_price=a["price"], source_terminal_price=b["price"],
            source_directional_body_count=sum(bar["close"] > bar["open"] if direction == "up" else bar["close"] < bar["open"] for bar in bars),
            source_overlap_pair_count=sum(max(left["low"],right["low"]) <= min(left["high"],right["high"]) for left,right in adjacent),
            source_adjacent_pair_count=len(adjacent), source_close_beyond_count=len(source_crosses),
            first_source_close_beyond_bar_open_utc=source_crosses[0]["timestamp_utc"] if source_crosses else None,
            source_terminal_bar_close_beyond=source_final_beyond,
            first_return_after_source_bar_open_utc=returned["timestamp_utc"] if returned else None,
            latest_close_beyond_reference=beyond(latest["close"]),
            current_retracement_anchor_beyond_reference=beyond(c["price"]),
            readout=f"这里核的是 {timeframe} 来源段 {a['price']:.2f}→{b['price']:.2f}。" + read + ("只核对该节点确认后的收盘，不回算更早变化。" if reference_known > start else "") + outer_scope["readout"],
            next_observation=(f"先重审 {timeframe} 对 {ref['price']:.2f} 的收盘与返回，不能仅凭测量长度沿用原方向。"
                if phase != "source_departure_closes_still_beyond_prior_extreme" else
                "再对照原图 SNR、上级任务和这一段的力度；几何前高低被收过，不等于趋势已确认。"))
        pending_outer = outer_scope.get("nearest_unresolved_outer_reference")
        if pending_outer and phase == "source_departure_closes_still_beyond_prior_extreme":
            result["next_observation"] = (
                f"先核 {timeframe} 更外侧旧{'高' if direction == 'up' else '低'}点 "
                f"{pending_outer['reference']['price']:.2f} 的收盘与返回；附近节点已收过，不能替它宣布整段换方向。")
    except (KeyError,TypeError,ValueError):
        return result
    return result


def build_native_source_structure_context(snapshot, timeframe, source_leg_id):
    """Re-read a selected native source leg rather than trust a cached label.

    The caller selects a ruler's leg, not a controlling trend leg. Reuse the
    strict native identity/closed-time checks, then compare real earlier nodes
    with source closes and the actual latest close. No C endpoint is inferred.
    """
    try:
        from .live_nested_stage_review import _native, _leg, _time as strict_time
    except ImportError:
        from live_nested_stage_review import _native, _leg, _time as strict_time
    try:
        if any(not isinstance(snapshot.get(key),str) or not snapshot[key].strip() for key in ("instrument","provider")):
            return {}
        cutoff = strict_time(snapshot["as_of_utc"])
        state, native_raw, legs = _native(snapshot, timeframe, cutoff)
        matches = [leg for leg in legs if leg.get("leg_id") == source_leg_id]
        if len(matches) != 1 or not _leg(matches[0], timeframe, native_raw, cutoff):
            return {}
        leg = matches[0]
        raw = {bar["timestamp_utc"]: bar for bar in native_raw.values()}
        latest = state["latest_closed_bar"]
        valid_legs = [candidate for candidate in legs if _leg(candidate, timeframe, native_raw, cutoff)]
        context = _source_structure_review(valid_legs, raw, leg["origin"], leg["terminal"],
            {"price": latest["close"]}, latest, timeframe, leg["direction_observation"])
        # The internal helper's C-relative observation is not a confirmed C
        # here; only its independently reconstructed node/close process is used.
        context.pop("current_retracement_anchor_beyond_reference", None)
        context.update(source_leg_id=source_leg_id, snapshot_id=snapshot.get("snapshot_id"),
            as_of_utc=snapshot["as_of_utc"], direction_observation=leg["direction_observation"],
            independently_reconstructed_from_native_bars=True)
        return context
    except (KeyError, ValueError, TypeError, AttributeError):
        return {}


def _pivot_matches_raw(pivot: dict[str, Any], raw: dict[str, dict[str, Any]], timeframe: str) -> bool:
    """Return whether a candidate pivot is independently present in loaded OHLC."""
    try:
        kind = pivot.get("kind")
        key = ("low" if kind == "confirmed_swing_low_candidate" else
               "high" if kind == "confirmed_swing_high_candidate" else None)
        bar = raw.get(pivot["pivot_timestamp_utc"], {})
        return bool(key and _number(pivot.get("price")) and bar.get(key) == pivot["price"] and
                    bar.get("timeframe", timeframe) == timeframe and
                    _time(pivot["pivot_timestamp_utc"]) <= _time(pivot["confirmed_at_utc"]))
    except (KeyError, TypeError, ValueError):
        return False


def _band_relation(direction: str, price: float, low: float, high: float) -> str:
    """Read progress along a return without assigning a target or a trade."""
    if low <= price <= high:
        return "inside_candidate_return_area"
    if direction == "up":
        return "not_reached_from_above" if price > high else "moved_below_candidate_area"
    return "not_reached_from_below" if price < low else "moved_above_candidate_area"


def _native_return_locations(snapshot, timeframe, heatmap, a, b, signed, latest, raw):
    """Use actual narrow nodes; depth is a measurement of their location.

    The current heatmap is candidate evidence. A node created during this
    return may be reviewed now, but cannot become a pre-existing forecast.
    Separate nodes retain their widths even when their return tolerances
    overlap. Response classes describe the current return, not old retests.
    """
    if not isinstance(heatmap, dict) or heatmap.get("timeframe") != timeframe or heatmap.get("as_of_utc") != snapshot.get("as_of_utc"):
        return []
    direction = "up" if signed > 0 else "down"
    start, end = _time(b["pivot_timestamp_utc"]), _time(latest["timestamp_utc"])
    source_low, source_high = sorted((a["price"], b["price"]))
    areas = []
    identities = set()
    origin_context = native_origin_context(snapshot, timeframe)
    for zone in heatmap.get("zones") or []:
        try:
            evidence = zone.get("evidence_ref") or {}
            formed_raw = zone.get("formed_after_utc") or evidence["formed_after_utc"]
            formed = _time(formed_raw)
            low, high = zone["price_low"], zone["price_high"]
            if (not zone.get("zone_id") or zone["zone_id"] in identities or
                zone.get("timeframe") != timeframe or evidence.get("timeframe") != timeframe or
                evidence.get("as_of_utc") != snapshot["as_of_utc"] or
                evidence.get("window_through_utc") != latest["timestamp_utc"] or
                not _number(low) or not _number(high) or not low < high or
                formed > end or formed_raw not in raw or
                (evidence.get("formed_after_utc") and _time(evidence["formed_after_utc"]) != formed) or
                high < source_low or low > source_high):
                continue
        except (KeyError, TypeError, ValueError):
            continue
        identities.add(zone["zone_id"])
        episodes = []
        for event in zone.get("independent_return_episodes") or []:
            try:
                first = _time(event["first_utc"])
                exit_time = _time(event["exit_utc"]) if event.get("exit_utc") else None
                if (not max(formed, start) < first <= end or event["first_utc"] not in raw or
                    (exit_time and not first <= exit_time <= end) or
                    (exit_time and event["exit_utc"] not in raw)):
                    continue
                episodes.append(dict(event))
            except (KeyError, TypeError, ValueError):
                continue
        finished = [event for event in episodes if event.get("exit_utc")]
        last_event = max(finished, key=lambda event: _time(event["exit_utc"]), default={})
        last_class = last_event.get("interaction_class")
        supportive = {"within_band_return", "near_miss_return", "wick_overshoot_then_reclaimed",
                      "close_beyond_then_reclaimed", "cross_immediately_reclaimed", "cross_recovery_without_touch"}
        crossed = {"opposite_close_followed_through", "opposite_side_held_without_extension", "gap_cross_without_touch"}
        # This side describes return depth relative to A→B, not the area's
        # creator role. A rising A→B can return through an older resistance.
        expected_side = "above" if direction == "up" else "below"
        latest_side = "above" if latest["close"] > high else "below" if latest["close"] < low else "inside"
        # A historical bounce in this return cannot conceal the latest cross.
        response = ("currently_testing" if latest_side == "inside" else
                    "continued_through_area" if latest_side != expected_side else
                    "local_return_or_reclaim_observed" if last_class in supportive else
                    "opposite_follow_through_observed" if last_class in crossed else
                    "response_still_open" if episodes else "no_completed_response_after_formation")
        response_words = {
            "currently_testing": "价格还在这条窄带内，要看离开后能否保持。",
            "continued_through_area": ("最新收盘已在这条价带下方，向下回调仍可能延伸；再看能否收回带内、带上。" if direction == "up" else
                                       "最新收盘已在这条价带上方，向上反弹仍可能延伸；再看能否收回带内、带下。"),
            "local_return_or_reclaim_observed": "这段回调已在此处返回或收回；再看同周期收盘保持和子周期新的推动。",
            "opposite_follow_through_observed": "此处曾换边并有跟随；先复核返回时的接受方向。",
            "response_still_open": "已出现附近测试，返回和后续跟随仍在发展。",
            "no_completed_response_after_formation": "先看回调在此处是否止住、收回并形成新的推动。",
        }
        origin = build_snr_origin_process(snapshot, timeframe, zone, context=origin_context)
        depths = sorted((abs(b["price"] - low) / abs(signed), abs(b["price"] - high) / abs(signed)))
        areas.append({
            "family_id": f"native_snr:{zone['zone_id']}", "label": f"{timeframe} SNR {zone.get('strength_label', '待核')}",
            "basis": "native_narrow_snr_location", "candidate_anchor_area": {"price_low": low, "price_high": high},
            "possible_second_one_to_one_area": {"price_low": round(low + signed, 6), "price_high": round(high + signed, 6)},
            "return_depth_range": {"low": round(depths[0], 6), "high": round(depths[1], 6)},
            "latest_price_relation": _band_relation(direction, latest["close"], low, high),
            "formed_after_utc": formed_raw,
            "formation_track_precedes_return": formed <= start,
            # Current-cutoff clustering can revise both the pivot and width.
            # An old timestamp is not proof the band was knowable back then.
            "known_at_return_start": False,
            "selection_known_at_return_start": None,
            "latest_close_side": latest_side,
            "source_leg_return_side": expected_side,
            "side_basis": "source_leg_return_geometry_not_snr_creator_role",
            "origin_process": origin,
            "structural_role_adjudicated": False,
            "support_resistance_conversion_confirmed": False,
            "return_response_state": response, "return_response_episodes": episodes,
            "condition_to_keep_live": response_words[response],
            "same_timeframe_snr_candidates": [{key: zone.get(key) for key in (
                "zone_id", "timeframe", "price_low", "price_high", "node_price",
                "strength_grade", "strength_label", "heat_opacity", "identity", "evidence_ref")}],
            "evidence_ref": dict(evidence), "not_a_fixed_entry_or_target": True,
        })
    # Review order follows price proximity; strength only describes each node.
    return sorted(areas, key=lambda item: (max(item["candidate_anchor_area"]["price_low"] - latest["close"],
                          latest["close"] - item["candidate_anchor_area"]["price_high"], 0), item["family_id"]))


def _forming_pullback_one_to_one_candidates(
    snapshot: dict[str, Any], timeframe: str, *,
    parent_task: dict[str, Any] | None = None,
    target_graph: dict[str, Any] | None = None,
    snr_zone_heatmap: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Model C as a moving area before it becomes a confirmed pivot.

    A user may need to watch for the next same-period 1:1 while C is still
    forming.  This provides *return-area -> possible second-leg-area* maps.
    It deliberately does not pick one family until parent task, first-force
    quality, named liquidity and own-period acceptance are actually bound.
    """
    result: dict[str, Any] = {
        "status": "unavailable", "timeframe": timeframe,
        "as_of_utc": snapshot.get("as_of_utc"), "trade_permission": False,
        "projection_family": "forming_retracement_area_then_equal_distance",
        "method_source": "user_described_first_leg_then_provisional_pullback_area_then_same_period_second_one_to_one",
        "source_refs": [
            "7674595968585551109", "7605363360134535065", "7602673068846837342",
            "7683323552137185258", "7683323874463192023", "7687034319489724721",
                "7676550586231557407", "7603613611321588439",
        ],
        "readout": "还没有一段已确认来源腿和反向的未完成回调，暂不能画下一段 1:1 候选区。",
        "next_observation": "先找同周期已确认的第一段和正在反向走、但尚未确认结束的回调。",
        "boundary": "SNR 候选区保留自己的价格；临时 C 及其投射随回调新低/新高更新。",
    }
    state = (snapshot.get("timeframe_states") or {}).get(timeframe) or {}
    ledger = state.get("candidate_wave_ledger") or {}
    source = (ledger.get("legs") or [])[-1:]  # exactly the latest confirmed leg
    latest = state.get("latest_closed_bar") or {}
    history = ((snapshot.get("chart_history") or {}).get(timeframe) or {}).get("bars") or []
    if not source or not history:
        return result
    source = source[0]
    a, b = source.get("origin") or {}, source.get("terminal") or {}
    raw = {bar.get("timestamp_utc"): bar for bar in history if isinstance(bar, dict)}
    tail = ledger.get("unfinished_tail") or {}
    tail_start = tail.get("from_confirmed_extremum") or {}
    try:
        cutoff, latest_open = _time(snapshot["as_of_utc"]), _time(latest["timestamp_utc"])
        latest_end = _time(state["latest_closed_bar_end_utc"])
        if (len(raw) != len(history) or ledger.get("timeframe") != timeframe or
            ledger.get("window_through_utc") != latest.get("timestamp_utc") or
            source.get("timeframe") != timeframe or
            source.get("temporal_order") != "sequential_confirmed_extrema" or
            not (_pivot_matches_raw(a, raw, timeframe) and _pivot_matches_raw(b, raw, timeframe)) or
            not latest_open < latest_end <= cutoff or not _number(latest.get("close")) or
            raw.get(latest["timestamp_utc"], {}).get("close") != latest["close"] or
            tail_start.get("pivot_timestamp_utc") != b.get("pivot_timestamp_utc") or
            tail_start.get("price") != b.get("price") or
            tail.get("to_latest_closed_bar_utc") != latest.get("timestamp_utc") or
            tail.get("to_latest_close") != latest.get("close") or
            _time(b["confirmed_at_utc"]) > latest_end):
            return result
        signed = float(b["price"]) - float(a["price"])
        source_range = abs(signed)
        direction = "up" if signed > 0 else "down" if signed < 0 else "unknown"
        if not source_range or direction == "unknown" or source.get("direction_observation") != direction:
            return result
        # The pivot may only be a confirmed source after B's confirmation.
        # The raw path from B onwards is displayed as a current process, not
        # backfilled as an earlier known prediction.
        tail_bars = sorted((bar for bar in history
                            if _time(b["pivot_timestamp_utc"]) < _time(bar["timestamp_utc"]) <= latest_open),
                           key=lambda bar: _time(bar["timestamp_utc"]))
        if (not tail_bars or any(not all(_number(bar.get(key)) for key in ("open", "high", "low", "close")) or
                                  not bar["low"] <= min(bar["open"], bar["close"]) <= max(bar["open"], bar["close"]) <= bar["high"]
                                  or bar.get("timeframe", timeframe) != timeframe for bar in tail_bars)):
            return result
    except (KeyError, TypeError, ValueError):
        return result

    # Read the closed path, not just B versus the latest close. Returning and
    # then recovering B is materially different from never returning.
    latest_price = float(latest["close"])
    opposing = lambda price: price < float(b["price"]) if direction == "up" else price > float(b["price"])
    first_return = next((bar for bar in tail_bars if opposing(bar["close"])), None)
    extreme_bar = (min(tail_bars, key=lambda bar: float(bar["low"])) if direction == "up" else
                   max(tail_bars, key=lambda bar: float(bar["high"])))
    candidate_anchor = float(extreme_bar["low"] if direction == "up" else extreme_bar["high"])
    beyond_source_origin = candidate_anchor < float(a["price"]) if direction == "up" else candidate_anchor > float(a["price"])
    first_recovery = next((bar for bar in tail_bars if first_return and
        _time(bar["timestamp_utc"]) > _time(first_return["timestamp_utc"]) and not opposing(bar["close"])), None)
    result["return_path_observation"] = {
        "first_opposing_close_bar_open_utc": first_return["timestamp_utc"] if first_return else None,
        "first_recovery_close_bar_open_utc": first_recovery["timestamp_utc"] if first_recovery else None,
        "latest_close_against_source": opposing(latest_price),
        "return_extreme_price": candidate_anchor,
        "return_extreme_bar_open_utc": extreme_bar["timestamp_utc"],
        "source_origin_range_breached": beyond_source_origin,
        "intrabar_order_inferred": False,
    }
    if (direction == "up" and latest_price >= float(b["price"])) or (direction == "down" and latest_price <= float(b["price"])):
        recovered = first_return is not None
        endpoint = "前高" if direction == "up" else "前低"
        movement = "回落" if direction == "up" else "反弹"
        recovery = "回到" if latest_price == float(b["price"]) else "收过"
        result.update(
            status="return_recovered_source_endpoint" if recovered else "source_leg_active_no_opposing_closed_return",
            source_leg_id=source.get("leg_id"), source_origin=a, source_terminal=b,
            direction_observation=direction, latest_closed_price=latest_price,
            source_structure_review=_source_structure_review(ledger.get("legs") or [], raw, a, b,
                {"price": candidate_anchor}, latest, timeframe, direction),
            pullback_completed=False,
            readout=(f"{timeframe} 来源段 {a['price']:.2f}→{b['price']:.2f} 后曾{movement}，"
                     f"期间极值 {candidate_anchor:.2f}；最新收盘 {latest_price:.2f} 已{recovery}{endpoint} {b['price']:.2f}。"
                     + ("期间还越过来源起点，恢复端点不能抹掉这次越界，旧延续量尺仍需重审。" if beyond_source_origin else
                        "接下来核对返回能否守住、是否继续交付；这还不能单独确认 C 或上级任务。")
                     if recovered else
                     f"{timeframe} 已确认来源段 {a['price']:.2f}→{b['price']:.2f}；已载段后收盘没有反向回调，暂不画 C 的候选区域。"
                     + (f"期间价格范围曾探到 {candidate_anchor:.2f}，收盘没有留在端点反侧。" if opposing(candidate_anchor) else "")),
            next_observation=("先重审期间越过来源起点后的结构，再决定哪一段还能作为第一段。" if beyond_source_origin else
                              f"观察 {timeframe} 返回 {b['price']:.2f} 后的收盘与后续推动，再核真实目标是否仍未完成。" if recovered else
                              "等本周期出现反向已收盘回调后，才开始把 C 作为可变区域而不是固定锚点。"),
        )
        return result

    depth = abs(float(b["price"]) - candidate_anchor) / source_range
    parent_task = parent_task or {}
    target_graph = target_graph or {}
    # The inverse C ruler must use the same ownership, source-leg, direction,
    # provenance and target-lifecycle review as the whole-chart thesis. Bare
    # "active" labels, or an unrelated active target, cannot constrain C.
    objective_review = build_parent_objective_review(
        parent_task, target_graph, state, timeframe=timeframe,
        as_of_utc=snapshot.get("as_of_utc"), chart_history=snapshot.get("chart_history"),
        provider=snapshot.get("provider"), instrument=snapshot.get("instrument"),
    )
    later_target_contacts = objective_review["later_target_contacts"]
    review_boundary_ambiguities = objective_review["review_boundary_ambiguities"]
    target_lifecycle_ready = (objective_review["status"] == "validated_parent_objective_context"
                              and any(target["supports_source_leg_id"] == source.get("leg_id")
                                      for target in objective_review["targets"]))
    candidates = _native_return_locations(snapshot, timeframe, snr_zone_heatmap, a, b, signed, latest, raw)
    # This is the inverse of C + AB = target, not a claim that price must
    # retrace there. Only an explicitly sourced active parent target with a
    # named relation to this exact native measuring leg may constrain C.
    # The live candidate target graph currently does not supply this binding;
    # an unbound projection or a target already completed must stay out.
    higher_constraints = []
    frame_order = ["M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1"]
    if target_lifecycle_ready and not beyond_source_origin and timeframe in frame_order:
        for target in objective_review["targets"]:
            target_tf = target.get("timeframe")
            lo, hi = target.get("price_low"), target.get("price_high")
            if not (target_tf in frame_order and frame_order.index(target_tf) > frame_order.index(timeframe)
                    and parent_task.get("timeframe") == target_tf
                    and objective_review["parent_task_id"] == parent_task.get("parent_task_id")
                    and target.get("supports_source_leg_id") == source.get("leg_id")
                    and parent_task.get("direction_observation") == direction
                    and _number(lo) and _number(hi) and lo <= hi):
                continue
            inverse_lo, inverse_hi = lo - signed, hi - signed
            if not (_number(inverse_lo) and _number(inverse_hi)):
                continue
            # Keep the full inferred interval; never clamp it to A/B or an
            # SNR core and silently pretend that it is a compatible return.
            within_source = min(a["price"], b["price"]) <= inverse_lo <= inverse_hi <= max(a["price"], b["price"])
            overlaps = [item["same_timeframe_snr_candidates"][0]["zone_id"] for item in candidates
                        if max(inverse_lo, item["candidate_anchor_area"]["price_low"]) <=
                           min(inverse_hi, item["candidate_anchor_area"]["price_high"])]
            higher_constraints.append({
                "status": "conditional_inverse_measurement_not_pullback_completion",
                "target_id": target["target_id"], "target_timeframe": target_tf,
                "parent_task_id": parent_task["parent_task_id"], "source_leg_id": source["leg_id"],
                "formula": "candidate_C = higher_target - signed_same_timeframe_AB",
                "target_area": {"price_low": lo, "price_high": hi},
                "candidate_anchor_area": {"price_low": round(inverse_lo, 6), "price_high": round(inverse_hi, 6)},
                "compatible_with_source_return_extent": within_source,
                "same_timeframe_snr_overlap_ids": overlaps,
                "source_refs": target.get("source_refs"),
                "known_at_utc": target["as_of_utc"], "anchor_confirmed": False,
                "pullback_completed": False, "trade_permission": False,
                "readout": (f"若下一段按这把 {timeframe} 量尺交付到 {target_tf} 活跃目标 {lo:.2f}—{hi:.2f}，"
                            f"反推 C 要在 {inverse_lo:.2f}—{inverse_hi:.2f}。"
                            + ("这与本周期 SNR 位置有交集，仍须看回调过程。" if overlaps and within_source else
                               "该反推位置不在来源段回调范围内，不能用它证明原段延续。" if not within_source else
                               "当前本周期 SNR 未与该位置重合，不能仅凭反算定回调结束。")),
            })
    # Keep the evidence locations for review, but suspend an old continuation
    # ruler if the provisional return has crossed its own source origin.
    if beyond_source_origin:
        for item in candidates:
            item["possible_second_one_to_one_area"] = None
            item["projection_state"] = "source_origin_review_required"
    current_status = "candidate_anchor_beyond_source_origin" if beyond_source_origin else "forming_against_source_leg"
    overlap_pairs = sum(
        max(float(left["low"]), float(right["low"])) <= min(float(left["high"]), float(right["high"]))
        for left, right in zip(tail_bars, tail_bars[1:])
    )
    opposing_body_count = sum(
        float(bar["close"]) < float(bar["open"]) if direction == "up" else float(bar["close"]) > float(bar["open"])
        for bar in tail_bars
    )
    source_bars = sorted((bar for bar in history if _time(a["pivot_timestamp_utc"]) <= _time(bar["timestamp_utc"]) <= _time(b["pivot_timestamp_utc"])),
                         key=lambda bar: _time(bar["timestamp_utc"]))
    source_seconds = (_time(b["pivot_timestamp_utc"]) - _time(a["pivot_timestamp_utc"])).total_seconds()
    return_seconds = (latest_end - _time(b["pivot_timestamp_utc"])).total_seconds()
    structure = _source_structure_review(ledger.get("legs") or [], raw, a, b, {"price": candidate_anchor}, latest, timeframe, direction)
    result.update(
        status="forming_retracement_candidate_areas",
        source_leg_id=source.get("leg_id"), source_origin=a, source_terminal=b,
        direction_observation=direction, signed_source_length=round(signed, 6),
        source_range_points=round(source_range, 6),
        source_known_at_utc=b.get("confirmed_at_utc"),
        source_structure_review=structure,
        source_force_observation={"source_closed_bar_count": len(source_bars),
            "source_range_points": round(source_range, 6), "source_duration_seconds": source_seconds,
            "quality_adjudicated": False},
        candidate_anchor={"price": round(candidate_anchor, 6), "bar_open_utc": extreme_bar.get("timestamp_utc"),
                          "confirmed": False, "moves_if_return_extends": True},
        current_return_depth_fraction=round(depth, 6), current_return_status=current_status,
        latest_closed_price=latest_price, latest_closed_bar_open_utc=latest.get("timestamp_utc"),
        tail_observation={"closed_bar_count": len(tail_bars), "opposing_body_count": opposing_body_count,
                          "adjacent_ohlc_overlap_pair_count": overlap_pairs,
                          "adjacent_pair_count": max(len(tail_bars) - 1, 0),
                          "return_duration_seconds": return_seconds,
                          "return_duration_to_source_ratio": round(return_seconds / source_seconds, 6),
                          "return_amplitude_to_source_ratio": round(depth, 6),
                          "raw_overlap_is_accumulation_confirmation": False,
                          "liquidity_object_state": "not_named_from_ohlc_only",
                          "accumulation_state": "not_adjudicated_from_overlap_count_alone"},
        parent_target_context={
            "parent_task_state": parent_task.get("state", "unknown"),
            "parent_task_id": parent_task.get("parent_task_id"),
            "target_lifecycle_state": target_graph.get("target_completion_state", "unknown"),
            "objective_review_status": objective_review["status"],
            "objective_binding_issues": objective_review["binding_issues"],
            "later_target_contacts": later_target_contacts,
            "review_boundary_ambiguities": review_boundary_ambiguities,
            "dol_state": target_graph.get("dol_state", "unknown"),
            "source_bound_active_parent_target": bool(target_lifecycle_ready),
            "relation_to_source_leg": "not_yet_adjudicated",
            "readout": ("上级目标在上次复核后已有同周期收盘 K 线触及；触及不等于完成，但旧目标暂不能反推当前回调位置，须先复核生命周期。"
                        if later_target_contacts else
                        "上级 K 线跨越目标复核时刻且触及目标；仅凭整根高低点无法知道触碰先后，旧目标暂不能反推当前回调位置。"
                        if review_boundary_ambiguities else
                        "已命名父任务和仍活跃目标可作为回调深度的背景约束；仍须核第一段力度、SNR和流动性。"
                        if target_lifecycle_ready else
                        "父任务、目标与本周期来源段未核齐；下面的区域只是本周期几何候选，不能用来判断该回调一定会在哪结束。"),
        },
        candidate_families=candidates,
        higher_target_return_constraints=higher_constraints,
        candidate_basis="observed_native_snr_locations_not_fixed_depth_buckets",
        provisional_current_extreme_projection={
            "anchor_price": round(candidate_anchor, 6),
            "projected_level": None if beyond_source_origin else round(candidate_anchor + signed, 6),
            "state": "source_origin_review_required" if beyond_source_origin else "moving_extreme_ruler",
            "anchor_confirmed": False, "known_at_utc": snapshot.get("as_of_utc"),
        },
        pullback_completion_requirements=[
            "先确认来源段破的是哪个同周期结构、第一段力度与上级目标是否仍支持原方向。",
            "在候选 C 区核对命名流动性是否被处理、收回，以及同周期收盘是否接受。",
            "再看小一级是否形成新的反向推动、平衡/积累后的跟随；仅有影线、触价或重叠计数不算回调结束。",
        ],
        pullback_completed=False, active_target_bound=bool(target_lifecycle_ready),
        readout=(f"{timeframe} 来源段 {a['price']:.2f}→{b['price']:.2f}，当前回调临时极值 {candidate_anchor:.2f}，"
                 f"约回补 {depth * 100:.1f}%。"
                 + (f"期间曾收回来源端点 {b['price']:.2f}，最新又回到回调侧；这一段存在往返，不能读成单向回调。" if first_recovery else "")
                 + ("临时极值已越过来源起点，暂停旧延续投射；SNR 位置只留作重审。" if beyond_source_origin else
                    f"当前有 {len(candidates)} 处本周期窄 SNR 可复核；各区按自身价格映射第二段 1:1。" if candidates else
                    "当前尚无来源和时间核齐的本周期 SNR 位置；先保留临时极值量尺。")
                 + "回补比例只描述已经走了多少；回调结束还要看波段、整理和流动性。"),
        next_observation=("当前临时回调极值已越过来源腿起点；先重审原腿和父级任务，旧的 1:1 不可自动沿用。"
                          if beyond_source_origin else
                          "先看回调在候选区内是否处理命名流动性、所属周期能否收住并产生新的同向段；确认后才冻结 C 并把候选区收敛成一把 1:1。"),
    )
    return result


def _build_latest_retracement_measurement_review(
    snapshot: dict[str, Any], timeframe: str, *,
    parent_task: dict[str, Any] | None = None,
    target_graph: dict[str, Any] | None = None,
    snr_zone_heatmap: dict[str, Any] | None = None,
    _include_forming: bool = True,
    _history_index=None,
) -> dict[str, Any]:
    result = {
        "status": "unavailable", "timeframe": timeframe, "as_of_utc": snapshot.get("as_of_utc"),
        "snapshot_id": snapshot.get("snapshot_id"), "projection_family": "equal_distance_from_retracement_anchor",
        "readout": "同周期第一段与回调端点尚未对齐，暂不能给等距投射。",
        "next_observation": "先定位同周期来源段和回调端点，再判断它们是否服务同一方向任务。",
        "direction_task_confirmed": False, "creator_force_confirmed": False,
        "active_target_bound": False, "task_target_completed": False,
        "pullback_completed": False, "trade_permission": False,
        "scope": "latest_adjacent_native_candidate_leg_pair_not_all_targets",
        "method_source": "user_described_same_timeframe_first_leg_projected_from_retracement_extremum",
        "selection_boundary": "邻接已确认几何腿只是锚点候选；用户要求先确立方向，强力度段变体也须另核，不自动选任意腿为第一段。",
        "boundary": "已确认几何转折不等于方向任务确立；投射与触价不等于真实目标、回调结束或进场许可。",
    }
    # A resolved A→B→C ruler and a C-still-forming map answer different
    # questions.  Keep the latter even when the former is unavailable.
    # The dashboard can therefore show a changing return area before there is
    # a confirmed C, without pretending the old endpoint-extension is 1:1.
    result["forming_pullback_one_to_one"] = _forming_pullback_one_to_one_candidates(
        snapshot, timeframe, parent_task=parent_task, target_graph=target_graph,
        snr_zone_heatmap=snr_zone_heatmap,
    ) if _include_forming else {}
    state = (snapshot.get("timeframe_states") or {}).get(timeframe) or {}
    ledger = state.get("candidate_wave_ledger") or {}
    legs = ledger.get("legs") or []
    latest = state.get("latest_closed_bar") or {}
    history = ((snapshot.get("chart_history") or {}).get(timeframe) or {}).get("bars") or []
    if len(legs) < 2 or not history:
        return result
    source_leg, pullback = legs[-2:]
    a, b, c = source_leg.get("origin") or {}, source_leg.get("terminal") or {}, pullback.get("terminal") or {}
    indexed = (_history_index is not None and _history_index.valid and
               _history_index.history is history and _history_index.timeframe == timeframe)
    raw = _history_index.raw if indexed else {bar.get('timestamp_utc'): bar for bar in history if isinstance(bar, dict)}
    if len(raw) != len(history):
        return result
    try:
        cutoff, latest_open = _time(snapshot["as_of_utc"]), _time(latest["timestamp_utc"])
        latest_end = _time(state["latest_closed_bar_end_utc"])
        if (not latest_open < latest_end <= cutoff or ledger.get("timeframe") != timeframe or
            ledger.get("window_through_utc") != latest["timestamp_utc"] or
            not _number(latest.get("close")) or raw.get(latest["timestamp_utc"], {}).get("close") != latest["close"] or
            pullback.get("origin") != b or
            any(leg.get("timeframe") != timeframe or leg.get("temporal_order") != "sequential_confirmed_extrema" for leg in (source_leg,pullback))):
            return result
        if not _time(a["pivot_timestamp_utc"]) < _time(b["pivot_timestamp_utc"]) < _time(c["pivot_timestamp_utc"]) <= latest_open:
            return result
        for pivot in (a,b,c):
            key = "low" if pivot.get("kind") == "confirmed_swing_low_candidate" else "high" if pivot.get("kind") == "confirmed_swing_high_candidate" else None
            bar = raw.get(pivot["pivot_timestamp_utc"], {})
            if (not key or not _number(pivot.get("price")) or bar.get(key) != pivot["price"] or
                bar.get("timeframe", timeframe) != timeframe or
                not _time(pivot["pivot_timestamp_utc"]) <= _time(pivot["confirmed_at_utc"]) <= cutoff):
                return result
        signed_length = b["price"] - a["price"]
        pullback_length = c["price"] - b["price"]
        projected = c["price"] + signed_length
        extension = b["price"] + signed_length
        if (not all(isfinite(value) for value in (signed_length,pullback_length,projected,extension)) or
            not signed_length or signed_length * pullback_length >= 0 or
            a["kind"] != c["kind"] or a["kind"] == b["kind"]):
            return result
        direction = "up" if signed_length > 0 else "down"
        if source_leg.get("direction_observation") != direction or pullback.get("direction_observation") != ("down" if direction == "up" else "up"):
            return result
        known = max(_time(pivot["confirmed_at_utc"]) for pivot in (a,b,c))
        if known > latest_end:
            return result
        following = (_history_index.window(known, latest_open) if indexed else
                     sorted((bar for bar in history if known <= _time(bar['timestamp_utc']) <= latest_open), key=lambda bar: _time(bar['timestamp_utc'])))
        if not indexed and any(not all(_number(bar.get(key)) for key in ("high","low","close")) or
               not bar["low"] <= bar["close"] <= bar["high"] or
               bar.get("timeframe",timeframe) != timeframe for bar in following):
            return result
    except (KeyError,TypeError,ValueError):
        return result
    target = round(projected, 6)
    upward = direction == "up"
    beyond = lambda price: price > target if upward else price < target
    origin_beyond = lambda price: price < a["price"] if upward else price > a["price"]
    touched = next((bar for bar in following if bar["low"] <= target <= bar["high"]), None)
    close_cross = next((bar for bar in following if beyond(bar["close"])), None)
    origin_cross = next((bar for bar in following if origin_beyond(bar["close"])), None)
    anchor_beyond = lambda price: price < c["price"] if upward else price > c["price"]
    anchor_wick = next((bar for bar in following if anchor_beyond(bar["low"] if upward else bar["high"])), None)
    anchor_close = next((bar for bar in following if anchor_beyond(bar["close"])), None)
    close = latest["close"]
    anchor_crossed_origin = origin_beyond(c["price"])
    phase = ("retracement_anchor_beyond_source_origin" if anchor_crossed_origin else
        "no_closed_bars_after_anchor_confirmation" if not following else
        "close_beyond_source_origin" if origin_beyond(close) else
        "source_origin_crossed_then_reclaimed" if origin_cross else
        "close_beyond_projection" if beyond(close) else
        "projection_crossed_then_reclaimed" if close_cross else
        "projection_touched_without_close_beyond" if touched else "projection_not_touched")
    observed = {
        "retracement_anchor_beyond_source_origin": "回调端点已越过来源段起点，不能当作已确立趋势里的普通回调直接沿用。",
        "no_closed_bars_after_anchor_confirmation": "锚点确认后还没有下一根已收盘 K 线可观察。",
        "close_beyond_source_origin": f"最新已收过来源段起点 {a['price']:.2f} 的反侧，原延续测量需要重审。",
        "source_origin_crossed_then_reclaimed": "锚点确认后曾收过来源段起点、后来收回，不能默认原任务完好。",
        "close_beyond_projection": f"最新收盘已越过等距参考 {target:.2f}，仍须核对是否有新的交付任务。",
        "projection_crossed_then_reclaimed": f"曾收过等距参考 {target:.2f}，后来收回；不能继续按已接受扩张来读。",
        "projection_touched_without_close_beyond": f"曾触及等距参考 {target:.2f}，最新尚未收过；不直接认定目标完成或反手。",
        "projection_not_touched": f"锚点确认后的已载 K 线尚未触及等距参考 {target:.2f}。",
    }[phase]
    source_review = _source_structure_review(legs,raw,a,b,c,latest,timeframe,direction, _history_index if indexed else None)
    anchor_phase = ("anchor_no_postconfirmation_bars" if not following else
                    "close_through_anchor" if anchor_beyond(close) and anchor_close else
                    "close_through_anchor_then_reclaimed" if anchor_close else
                    "wick_through_anchor_without_close" if anchor_wick else "anchor_not_crossed_in_observed_bars")
    anchor_read = {
        "anchor_no_postconfirmation_bars": "锚点确认后还没有下一根本周期收盘，不能据此认定起点守住了。",
        "close_through_anchor": f"回调起点 {c['price']:.2f} 已被本周期收盘穿过；旧投射保留作核对，不能自动换起点继续用。",
        "close_through_anchor_then_reclaimed": f"曾收过回调起点 {c['price']:.2f}，最新又收回；要重新核对这个起点，不能自动恢复旧测量。",
        "wick_through_anchor_without_close": f"回调起点 {c['price']:.2f} 有刺穿，但尚无本周期收盘穿过；先看扫回还是继续，不能直接判趋势反转。",
        "anchor_not_crossed_in_observed_bars": f"锚点确认后的已载 K 线尚未穿过回调起点 {c['price']:.2f}；保留原起点，不追着最新价格改量尺。",
    }[anchor_phase]
    identity = [snapshot.get("instrument"),snapshot.get("provider"),timeframe,
                *[[pivot["pivot_timestamp_utc"],float(pivot["price"])] for pivot in (a,b,c)]]
    measurement_id = f"{timeframe}:retracement_equal_distance:" + hashlib.sha256(json.dumps(identity,separators=(",",":")).encode()).hexdigest()[:24]
    direct_level = round(extension, 6)
    spread_low, spread_high = sorted((direct_level, target))
    paired_projection = {
        "status": "two_source_bound_equal_distance_geometries",
        "timeframe": timeframe, "as_of_utc": snapshot["as_of_utc"],
        "snapshot_id": snapshot["snapshot_id"], "measurement_id": measurement_id,
        "source_leg_id": source_leg.get("leg_id"),
        "source_origin_price": a["price"], "source_terminal_price": b["price"],
        "pullback_anchor_price": c["price"], "signed_source_length": signed_length,
        "direct_double_level": direct_level, "post_pullback_level": target,
        "direct_known_at_utc": max(_time(a["confirmed_at_utc"]), _time(b["confirmed_at_utc"])).isoformat().replace("+00:00", "Z"),
        "post_pullback_known_at_utc": known.isoformat().replace("+00:00", "Z"),
        "level_difference": round(abs(direct_level-target), 6),
        "difference_equals_pullback_depth": abs((direct_level-target)-(b["price"]-c["price"])) <= .00001,
        "observation_interval": {"price_low": spread_low, "price_high": spread_high},
        "interval_role": "compare_target_reaction_with_channel_structure_and_snr_not_automatic_reversal",
        "source_basis": ["Alexander:msg-7605363360134535045", "user:2026-10-04:channel_and_two_1to1_variants"],
        "reversal_confirmed": False, "active_target_bound": False, "trade_permission": False,
        "readout": (f"{timeframe} 同一来源段 {a['price']:.2f}→{b['price']:.2f} 有两把量尺："
                    f"从段末直接翻倍到 {direct_level:.2f}；从回调端 {c['price']:.2f} 再走等高到 {target:.2f}。"
                    f"两者差 {abs(direct_level-target):.2f}，先在 {spread_low:.2f}—{spread_high:.2f} 对照通道、结构和 SNR 的实际反应；"
                    "不能只凭差值断言反转。"),
    }
    # A and C are confirmed same-kind pivots; B is the opposite-side touch.
    # Their parallel rails form a reproducible *candidate* channel.  The
    # channel cannot have been known before C's confirmation, and three
    # pivots do not prove the author-drawn channel in a different image.
    native_times = [bar["timestamp_utc"] for bar in history]
    try:
        a_idx, b_idx, c_idx = (native_times.index(point["pivot_timestamp_utc"]) for point in (a,b,c))
        slope = (c["price"] - a["price"]) / (c_idx-a_idx)
        opposite_offset = b["price"] - (a["price"] + slope*(b_idx-a_idx))
        if a_idx < b_idx < c_idx and slope*signed_length > 0 and opposite_offset*signed_length > 0:
            latest_idx = native_times.index(latest["timestamp_utc"])
            same_side_now = a["price"] + slope*(latest_idx-a_idx)
            opposite_now = same_side_now + opposite_offset
            channel_low, channel_high = sorted((same_side_now, opposite_now))
            paired_projection["parallel_channel_candidate"] = {
                "status": "three_native_pivot_parallel_rails_candidate",
                "anchor_A_bar_open_utc": a["pivot_timestamp_utc"],
                "opposite_B_bar_open_utc": b["pivot_timestamp_utc"],
                "same_side_C_bar_open_utc": c["pivot_timestamp_utc"],
                "known_at_utc": known.isoformat().replace("+00:00", "Z"),
                "slope_points_per_loaded_bar": round(slope, 9),
                "rail_offset_points": round(opposite_offset, 9),
                "latest_closed_price": close,
                "latest_rail_price_low": round(channel_low, 6),
                "latest_rail_price_high": round(channel_high, 6),
                "latest_close_location": ("above" if close > channel_high else
                                          "below" if close < channel_low else "inside"),
                "author_channel_identity_confirmed": False,
                "trade_permission": False,
            }
    except (KeyError, ValueError, ZeroDivisionError):
        pass
    result.update(status="native_retracement_anchored_equal_distance_geometry", direction_observation=direction,
        measurement_id=measurement_id, instrument=snapshot.get("instrument"), provider=snapshot.get("provider"),
        source_leg_id=source_leg.get("leg_id"), pullback_leg_id=pullback.get("leg_id"),
        source_origin=a, source_terminal=b, projection_anchor=c, signed_source_length=signed_length,
        projected_level=target, endpoint_extension_level=direct_level,
        paired_projection_review=paired_projection,
        anchors_known_at_utc=known.isoformat().replace("+00:00","Z"),
        latest_bar_open_utc=latest["timestamp_utc"], latest_closed_end_utc=state["latest_closed_bar_end_utc"], latest_closed_price=close,
        observed_closed_bar_count=len(following), first_touch_bar_open_utc=touched.get("timestamp_utc") if touched else None,
        first_close_beyond_bar_open_utc=close_cross.get("timestamp_utc") if close_cross else None,
        first_close_beyond_source_origin_bar_open_utc=origin_cross.get("timestamp_utc") if origin_cross else None,
        phase=phase,
        source_structure_review=source_review,
        anchor_review={"phase":anchor_phase,"readout":anchor_read,
            "first_wick_through_bar_open_utc":anchor_wick["timestamp_utc"] if anchor_wick else None,
            "first_close_through_bar_open_utc":anchor_close["timestamp_utc"] if anchor_close else None,
            "requires_anchor_review":bool(anchor_wick or anchor_close),"automatic_reanchoring":False,
            "parent_task_invalidated":False,"pullback_completed":False,"trade_permission":False},
        continuity={"status":"not_compared","readout":"尚未与上一份可比量尺核对。","trade_permission":False},
        readout=f"{timeframe} 来源段 {a['price']:.2f}→{b['price']:.2f}；从回调端点 {c['price']:.2f} 投射同样高度，等距参考 {target:.2f}。{observed}",
        next_observation=("先重审来源段是否仍属于当前任务，不能沿用旧测量追价。" if anchor_crossed_origin or origin_cross or origin_beyond(close) else
            "触价或收过后先读本周期收盘和更小周期反向段；子级参考到位不取消上级目标，也不保证一定回调。" if touched or close_cross else
            "先核对来源段方向和力度是否确立、回调端点是否有效，再把这条测量接入上级目标与沿途 SNR。"))
    if (source_review.get("status") == "native_source_leg_prior_extreme_process" and
        source_review.get("phase") != "source_departure_closes_still_beyond_prior_extreme" and
        not (anchor_crossed_origin or origin_cross or origin_beyond(close))):
        result["next_observation"] = source_review["next_observation"] + (
            "投射参考已触及或收过，也不能据此认定任务完成、追入或反手。" if touched or close_cross else "")
    if anchor_close and not (anchor_crossed_origin or origin_cross or origin_beyond(close)):
        result["next_observation"] = "先核对回调起点被收过后的新反向段与所属周期 SNR；旧投射不自动换锚续用，父级趋势也不由此直接反转。"
    return result


def _enclosing_source_pairs(snapshot, timeframe, legs):
    """Recover the nearest enclosing swing when C oversteps a local sub-leg.

    The earlier ruler is never reanchored. A separate A->B source must contain
    every intermediate native leg and OHLC extreme. This supplies drawable
    geometry, not proof of trend identity, force or a completed correction.
    """
    history = ((snapshot.get('chart_history') or {}).get(timeframe) or {}).get('bars') or []
    raw = {b.get('timestamp_utc'): b for b in history}
    if len(raw) != len(history):
        return []
    try:
        cutoff = _time(snapshot['as_of_utc'])
        valid = []
        for leg in legs:
            a, b = leg.get('origin') or {}, leg.get('terminal') or {}
            valid.append(leg.get('timeframe') == timeframe and
                leg.get('temporal_order') == 'sequential_confirmed_extrema' and
                all(_pivot_matches_raw(p,raw,timeframe) and _time(p['confirmed_at_utc']) <= cutoff for p in (a,b)) and
                _time(a['pivot_timestamp_utc']) < _time(b['pivot_timestamp_utc']) and
                a['kind'] != b['kind'] and a['price'] != b['price'] and
                leg.get('direction_observation') == ('up' if b['price'] > a['price'] else 'down'))
    except (KeyError,ValueError,TypeError):
        return []
    candidates=[]
    for end in range(1,len(legs)):
        source, pullback = legs[end-1], legs[end]
        if not valid[end-1] or not valid[end] or source['terminal'] != pullback['origin']:
            continue
        local, b, c = source['origin'], source['terminal'], pullback['terminal']
        local_c_inside = min(local['price'],b['price']) < c['price'] < max(local['price'],b['price'])
        for start in range(end-2,-1,-1):
            if not valid[start] or legs[start]['terminal'] != legs[start+1]['origin']:
                break
            a=legs[start]['origin']
            # An ordinary C can also belong to the immediately preceding
            # two-push NET span.  Do not broaden this into every older wave.
            if local_c_inside and start < end-3:
                break
            if local_c_inside and start == end-3:
                first = legs[start]
                if not (b['price'] > first['terminal']['price'] if source['direction_observation']=='up'
                        else b['price'] < first['terminal']['price']):
                    continue
            elif local_c_inside:
                continue
            if a['kind'] != c['kind'] or not min(a['price'],b['price']) < c['price'] < max(a['price'],b['price']):
                continue
            low,high=sorted((a['price'],b['price']))
            components=legs[start:end]
            if any(not low <= p['price'] <= high for item in components for p in (item['origin'],item['terminal'])):
                continue
            path=[bar for bar in history if a['pivot_timestamp_utc'] <= bar['timestamp_utc'] <= b['pivot_timestamp_utc']]
            if not path or any(not all(_number(bar.get(k)) for k in ('open','high','low','close')) or
                not low <= bar['low'] <= min(bar['open'],bar['close']) <= max(bar['open'],bar['close']) <= bar['high'] <= high
                or bar.get('timeframe',timeframe) != timeframe for bar in path):
                continue
            ids=[item['leg_id'] for item in components]
            identity=hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()[:24]
            enclosing=dict(leg_id=f'{timeframe}:enclosing:{identity}',timeframe=timeframe,
                origin=a,terminal=b,direction_observation='up' if b['price']>a['price'] else 'down',
                temporal_order='sequential_confirmed_extrema')
            candidates.append((end,legs[:start]+[enclosing,pullback],ids))
            break
    # Also retain the complete outer excursion when C stays inside the final
    # local leg. Selection must not depend on C overstepping a convenient A.
    from .live_source_wave_scope import dominant_source_candidates
    seen={tuple(ids) for _,_,ids in candidates}
    for enclosing in dominant_source_candidates(snapshot,timeframe,legs):
        ids=enclosing['component_source_leg_ids']
        if tuple(ids) in seen:
            continue
        end=next((i+1 for i,leg in enumerate(legs) if leg['leg_id']==ids[-1]),None)
        start=next((i for i,leg in enumerate(legs) if leg['leg_id']==ids[0]),None)
        if end is None or start is None or end>=len(legs) or not valid[end]:
            continue
        pullback=legs[end]
        a,b,c=enclosing['origin'],enclosing['terminal'],pullback['terminal']
        if (not b==pullback['origin'] or a['kind']!=c['kind'] or
                not min(a['price'],b['price'])<c['price']<max(a['price'],b['price'])):
            continue
        candidates.append((end,legs[:start]+[enclosing,pullback],ids))
        seen.add(tuple(ids))
    return candidates


def build_retracement_measurement_review(
    snapshot: dict[str, Any], timeframe: str, *,
    parent_task: dict[str, Any] | None = None,
    target_graph: dict[str, Any] | None = None,
    snr_zone_heatmap: dict[str, Any] | None = None,
    _use_history_index: bool = True,
    include_regime_research: bool = False,
) -> dict[str, Any]:
    """Keep independent rulers, not just the latest local A→B→C.

    This is a ledger of loaded, adjacent native geometry. It does not select
    the true first force leg, infer parenthood from size, or retire a larger
    task when a smaller ruler is touched. The existing latest-pair view is
    preserved for callers and continuity auditing.
    """
    history = ((snapshot.get('chart_history') or {}).get(timeframe) or {}).get('bars') or []
    history_index = _MeasurementHistoryIndex(history, timeframe) if _use_history_index else None
    result = _build_latest_retracement_measurement_review(
        snapshot, timeframe, parent_task=parent_task, target_graph=target_graph,
        snr_zone_heatmap=snr_zone_heatmap, _history_index=history_index,
    )
    # The archive packet binding audit checks the review envelope as well as
    # each ruler.  Preserve the snapshot's provider/instrument identity here
    # so a HistData review cannot be mistaken for an unbound broker review.
    result.setdefault("instrument", snapshot.get("instrument"))
    result.setdefault("provider", snapshot.get("provider"))
    state = (snapshot.get("timeframe_states") or {}).get(timeframe) or {}
    wave = state.get("candidate_wave_ledger") or {}
    legs = wave.get("legs") or []
    records, rejected_pairs, identities = [], [], set()
    pairs = [(end-1,legs[:end],end == len(legs),None) for end in range(2,len(legs)+1)]
    pairs += [(end,pair_legs,False,ids) for end,pair_legs,ids in _enclosing_source_pairs(snapshot,timeframe,legs)]
    for pair_end, pair_legs, latest_pair, component_ids in pairs:
        if latest_pair:
            reviewed = result
        else:
            # Prior extrema remain available to the source-structure review;
            # current OHLC stays under the original snapshot cutoff.
            pair_state = {**state, "candidate_wave_ledger": {**wave, "legs": pair_legs}}
            pair_snapshot = {**snapshot, "timeframe_states": {timeframe: pair_state}}
            reviewed = _build_latest_retracement_measurement_review(
                pair_snapshot, timeframe, _include_forming=False, _history_index=history_index,
            )
        if reviewed.get("status") != "native_retracement_anchored_equal_distance_geometry":
            rejected_pairs.append({"pair_end_index": pair_end, "reason": "anchors_or_native_evidence_unavailable"})
            continue
        identity = reviewed["measurement_id"]
        if identity in identities:
            continue
        identities.add(identity)
        phase = reviewed["phase"]
        anchor = reviewed["anchor_review"]
        structure = reviewed.get("source_structure_review") or {}
        structure_phase = structure.get("phase")
        source_held_geometric_break = (
            structure.get("status") == "native_source_leg_prior_extreme_process"
            and structure_phase == "source_departure_closes_still_beyond_prior_extreme"
        )
        suspended = phase in {
            "retracement_anchor_beyond_source_origin", "close_beyond_source_origin",
            "source_origin_crossed_then_reclaimed",
        } or bool(anchor.get("first_close_through_bar_open_utc")) or structure_phase in {
            "source_departure_latest_returned", "source_departure_latest_reclaimed",
        }
        touched = bool(reviewed["first_touch_bar_open_utc"])
        crossed = bool(reviewed["first_close_beyond_bar_open_utc"])
        lifecycle = (
            "origin_or_anchor_review_required" if suspended else
            "source_not_established_geometry_only" if not source_held_geometric_break else
            "no_postconfirmation_observation" if not reviewed["observed_closed_bar_count"] else
            "reference_reached_geometry_only" if touched or crossed else
            "reference_not_reached_geometry_only"
        )
        records.append({
            key: reviewed[key] for key in (
                "measurement_id", "timeframe", "source_leg_id", "pullback_leg_id",
                "source_origin", "source_terminal", "projection_anchor", "direction_observation",
                "signed_source_length", "projected_level", "anchors_known_at_utc",
                "latest_closed_end_utc", "latest_closed_price", "observed_closed_bar_count",
                "first_touch_bar_open_utc", "first_close_beyond_bar_open_utc", "phase",
                "anchor_review", "source_structure_review", "paired_projection_review", "readout", "next_observation",
            )
        } | {
            "source_geometry": "enclosing_native_wave" if component_ids else "adjacent_native_wave",
            "component_source_leg_ids": component_ids or [reviewed['source_leg_id']],
            "lifecycle": lifecycle, "continuation_requires_review": suspended,
            "source_held_geometric_break": source_held_geometric_break,
            "reference_reached_after_confirmation": touched or crossed,
            "range_touch_observed": touched,
            "reached_reference_is_task_completion": False,
            "parent_task_id": None, "parent_target_retired": False,
            "first_force_leg_adjudicated": False, "trade_permission": False,
            "observation_scope": "loaded_native_closed_bars_after_anchor_confirmation",
        })
    records.sort(key=lambda row: (row['projection_anchor']['pivot_timestamp_utc'],row['source_origin']['pivot_timestamp_utc']))
    open_records = [row for row in records if row["lifecycle"] == "reference_not_reached_geometry_only"]
    reached_records = [row for row in records if row["reference_reached_after_confirmation"]]
    ledger = {
        "status": "native_adjacent_rulers_reviewed" if records else "unavailable",
        "timeframe": timeframe, "as_of_utc": snapshot.get("as_of_utc"),
        "snapshot_id": snapshot.get("snapshot_id"),
        "scope": "all_loaded_adjacent_native_pairs_not_all_semantic_targets",
        "enclosing_source_count": sum(row['source_geometry']=='enclosing_native_wave' for row in records),
        "records": records, "record_count": len(records),
        "unreached_usable_geometry_count": len(open_records),
        "reached_reference_count": len(reached_records),
        "review_required_count": sum(row["continuation_requires_review"] for row in records),
        "rejected_pairs": rejected_pairs,
        "new_local_ruler_replaces_older_rulers": False,
        "trade_permission": False,
        "readout": (f"{timeframe} 保留 {len(records)} 把独立量尺；"
                    f"已载收盘中，{len(open_records)} 把尚未到参考且未发现起点收穿，"
                    f"{len(reached_records)} 把在确认后触及或收过参考。"
                    "新短段不替换旧量尺，小参考到位也不取消大周期任务。"
                    if records else "该周期暂没有可核齐的独立 A→B→C 量尺。"),
        "boundary": "只覆盖已载相邻几何波段；哪一段是真正第一力度、哪些目标仍属于当前父任务，须另由背景和来源裁决。",
    }
    result["measurement_lifecycle_ledger"] = ledger
    result["source_leg_context"] = build_measurement_source_context(snapshot, timeframe, result)
    # All-native-pair enumeration is a research ledger, not an automatic task
    # selector. Never let its arithmetic silently establish background/trend.
    attach_source_selection_reviews(result,snapshot,parent_task=parent_task,target_graph=target_graph)
    apply_one_to_one_admission(result, snapshot)
    # A measuring family is not an execution approval. Keep the historical
    # legacy decisions intact while supplying independently identified local
    # first-wave / trend-nesting / range-reuse research geometry.
    # Experimental work must not silently add full-history computation on
    # every live refresh. Native timeframe != adjudicated structural degree.
    if include_regime_research:
        from .live_regime_one_to_one import build_regime_one_to_one
        result['regime_measurement_review'] = build_regime_one_to_one(snapshot, timeframe)
    result["measurement_map"] = build_measurement_map(result)
    return result
