"""Causal native-node crossing/return observations for background research.

This producer reads OHLC and confirmed pivots, independently of measurement
boxes. A close and later follow-through are observable witnesses, not a fixed
Alexander entry rule. Local node changes never establish the parent DOL or
authorize a 1:1 source by themselves.
"""
from datetime import timedelta
from bisect import bisect_left, bisect_right
from copy import deepcopy
from math import isfinite

try:
    from .live_nested_stage_review import MINUTES, _time
    from .native_market_sessions import adjacent_native_bars, research_calendar
    from .native_timeframe_state import resolve_native_timeframe_state
except ImportError:
    from live_nested_stage_review import MINUTES, _time
    from native_market_sessions import adjacent_native_bars, research_calendar
    from native_timeframe_state import resolve_native_timeframe_state

METHOD = "native_node_cross_return_attempts_v2"
ORDER = ("W1", "D1", "H4", "H1", "M30", "M15", "M5", "M1")
SOURCE_IDS = ["7676550586231557407", "7608052678914466373", "7685764796256176487"]


def _describe_selected(result):
    selected = result.get('selected')
    if not selected:
        result.pop('name', None)
        result.pop('readout', None)
        result.pop('next_observation', None)
        return result
    direction="上" if selected["direction"]=="up" else "下"
    name={"origin_broken":"破位来源被收破", "crossing_reclaimed":"破位后被收回",
        "close_through_pending_follow":"收过节点，等跟随", "close_through_with_follow":f"向{direction}收过节点并跟随",
        "return_held_node":"破位后回踩守住", "coverage_gap_requires_review":"结构路径缺数据"}[selected["state"]]
    if selected["attempt_number"] > 1:
        name={"close_through_pending_follow":f"重新向{direction}收过节点，等跟随",
            "close_through_with_follow":"重夺节点后出现跟随",
            "return_held_node":"重夺后回踩守住",
            "crossing_reclaimed":"重夺节点后再次失守",
            "origin_broken":"重夺失败，来源边界收破"}.get(selected["state"],name)
    result['name']=name
    result['readout']=f'{result["timeframe"]}：{name}。'
    result['next_observation']=("旧破位已失效；看是否重新夺回图中节点，不沿用旧延续。"
        if selected['state'] in {'origin_broken','crossing_reclaimed'} else
        "看返回图中节点后能否守住；若收回另一侧，撤销这段延续读法。上级目标尚需独立核对。")
    return result


def _utc(value):
    return value.isoformat().replace("+00:00", "Z")


def _crossing_indices(rows, points, duration, point_known, calendar_offset=None):
    """Index the exact close transitions once for this native input/cutoff."""
    highs = sorted((p for p in points if p['kind'] == 'confirmed_swing_high_candidate'), key=lambda p:p['price'])
    lows = sorted((p for p in points if p['kind'] == 'confirmed_swing_low_candidate'), key=lambda p:p['price'])
    high_prices, low_prices = [p['price'] for p in highs], [p['price'] for p in lows]
    found = {id(p): [] for p in points}
    for i in range(1, len(rows)):
        before, current = rows[i-1], rows[i]
        if not adjacent_native_bars(before.timestamp_utc,current.timestamp_utc,int(duration.total_seconds()/60),calendar_offset):
            continue
        if current.close > before.close:
            crossed = highs[bisect_left(high_prices,before.close):bisect_left(high_prices,current.close)]
        elif current.close < before.close:
            crossed = lows[bisect_right(low_prices,current.close):bisect_right(low_prices,before.close)]
        else:
            continue
        for p in crossed:
            if current.timestamp_utc >= point_known[id(p)]:
                found[id(p)].append(i)
    return found


def _node_attempts(rows, points, p, duration, timeframe, *, point_known=None, crossing_indices=None, calendar_offset=None):
    """Each failed attempt stays frozen; a later recross is a NEW attempt.

    This repairs chronological observation, not an acceptance classifier.
    Neither one recross nor a later advancing close proves new-side balance.
    """
    sign = 1 if p["kind"] == "confirmed_swing_high_candidate" else -1
    point_known = (point_known if point_known is not None else
                   {id(q): _time(q["confirmed_at_utc"]) for q in points})
    known = point_known[id(p)]
    crossings = crossing_indices if crossing_indices is not None else [i for i in range(1, len(rows))
        if rows[i].timestamp_utc >= known
        and adjacent_native_bars(rows[i-1].timestamp_utc,rows[i].timestamp_utc,MINUTES[timeframe],calendar_offset)
        and sign*(rows[i-1].close-p["price"]) <= 0
        and sign*(rows[i].close-p["price"]) > 0]
    attempts, covered_through = [], -1
    for first in crossings:
        if first <= covered_through:
            continue  # Touching the line is not another failed/new attempt.
        first_bar_stamp = _utc(rows[first].timestamp_utc)
        opposing = [q for q in points if q["kind"] != p["kind"]
            and p["pivot_timestamp_utc"] < q["pivot_timestamp_utc"] < first_bar_stamp
            and point_known[id(q)] <= rows[first].timestamp_utc]
        if not opposing:
            continue
        origin = (min if sign > 0 else max)(opposing, key=lambda q:q["price"])
        if sign*(p["price"]-origin["price"]) <= 0:
            continue
        node_id = f'{timeframe}:{p["pivot_timestamp_utc"]}:{p["kind"]}'
        previous = attempts[-1] if attempts else None
        event = dict(node_id=node_id, attempt_id=f'{node_id}:{_utc(rows[first].timestamp_utc)}',
            attempt_number=len(attempts)+1, timeframe=timeframe, direction="up" if sign>0 else "down",
            node=p, origin_boundary=origin, first_close_utc=_utc(rows[first].timestamp_utc+duration),
            first_close_bar_utc=_utc(rows[first].timestamp_utc),
            known_at_utc=_utc(rows[first].timestamp_utc+duration),
            state="close_through_pending_follow", follow_through_utc=None,
            retest_utc=None, reclaim_utc=None, origin_broken_utc=None,
            ended_at_utc=None, last_observed_bar_utc=_utc(rows[first].timestamp_utc),
            previous_attempt=({k:previous[k] for k in ("attempt_id","state","ended_at_utc")} if previous else None),
            witnesses=[dict(bar_open_utc=_utc(rows[first].timestamp_utc), close=rows[first].close)],
            target_candidates=[], acceptance_adjudicated=False, trade_permission=False)
        covered_through = len(rows)-1
        for i in range(first+1, len(rows)):
            b = rows[i]
            if not adjacent_native_bars(rows[i-1].timestamp_utc,b.timestamp_utc,MINUTES[timeframe],calendar_offset):
                event["state"] = "coverage_gap_requires_review"
                event["ended_at_utc"] = _utc(rows[i-1].timestamp_utc+duration)
                covered_through = i
                break
            event["last_observed_bar_utc"] = _utc(b.timestamp_utc)
            outside = sign*(b.close-p["price"])
            witness = False
            if sign*(b.close-origin["price"]) < 0:
                event["origin_broken_utc"] = _utc(b.timestamp_utc+duration)
                event["state"] = "origin_broken"
                witness = True
            elif outside < 0:
                event["reclaim_utc"] = _utc(b.timestamp_utc+duration)
                event["state"] = "crossing_reclaimed"
                witness = True
            elif event["follow_through_utc"] is None and sign*(b.close-rows[first].close) > 0:
                event["follow_through_utc"] = _utc(b.timestamp_utc+duration)
                event["state"] = "close_through_with_follow"
                witness = True
            elif event["follow_through_utc"] and event["retest_utc"] is None and b.low<=p["price"]<=b.high and outside>0:
                event["retest_utc"] = _utc(b.timestamp_utc+duration)
                event["state"] = "return_held_node"
                witness = True
            if witness:
                event["witnesses"].append(dict(bar_open_utc=_utc(b.timestamp_utc), close=b.close))
            if event["origin_broken_utc"] or event["reclaim_utc"]:
                event["ended_at_utc"] = _utc(b.timestamp_utc+duration)
                covered_through = i
                break
        if event["state"] in {"close_through_with_follow","return_held_node"}:
            targets = [q for q in points if q["kind"]==p["kind"]
                and point_known[id(q)]<=rows[first].timestamp_utc
                and sign*(q["price"]-rows[-1].close)>0
                and all((b.high<q["price"] if sign>0 else b.low>q["price"]) for b in rows[first:])]
            event["target_candidates"] = sorted(targets,key=lambda q:abs(q["price"]-rows[-1].close))[:2]
        attempts.append(event)
    return attempts


def _node_inventory(events, selected, node_ids=None):
    """Latest observed attempt per node, including failed/unknown attempts.

    This is an optional parallel-process view, not a replacement for the
    latest event. Old attempts remain in the underlying event ledger. Target
    candidates are intentionally not part of this state/identity inventory.
    """
    requested=None if node_ids is None else set(node_ids)
    latest={event['node_id']:event for event in events if requested is None or event['node_id'] in requested}
    processes=sorted(latest.values(),key=lambda e:(e['first_close_utc'],e['node']['pivot_timestamp_utc']))
    result=dict(method='native_node_process_inventory_v1',
        scope='latest_observed_attempt_per_native_node',
        selected_attempt_id=selected['attempt_id'] if selected else None,
        processes=[deepcopy({k:v for k,v in event.items() if k!='target_candidates'}) for event in processes],
        direction_adjudicated=False,parent_task_adjudicated=False,
        trade_permission=False,
        interpretation='各节点独立保存当前已知尝试；新的待跟随或失败事件不会删除另一节点仍存在的过程，也不复活同节点旧失败尝试。')
    if requested is not None:
        result.update(scope='latest_observed_attempt_for_requested_native_nodes',
            requested_node_ids=sorted(requested),missing_requested_node_ids=sorted(requested-latest.keys()))
    return result


def review_native_structure(bars, ledger, *, timeframe, as_of_utc, calendar_offset=None, include_node_inventory=False, node_ids=None):
    result = dict(method_version=METHOD, timeframe=timeframe, as_of_utc=as_of_utc,
        status="unavailable", events=[], selected=None, trade_permission=False,
        direction_adjudicated=False, source_leg_adjudicated=False,
        source_message_ids=SOURCE_IDS,
        interpretation="原生节点的收盘与返回事实；不等于完整趋势、父目标或进场裁决。")
    try:
        duration = timedelta(minutes=MINUTES[timeframe])
        cutoff = _time(as_of_utc)
        rows = [b for b in bars if b.timestamp_utc+duration <= cutoff]
        if not rows or ledger.get("timeframe", timeframe) != timeframe:
            return result
        if any(b.timeframe != timeframe or
               not all(isfinite(v) for v in (b.open,b.high,b.low,b.close)) or
               not b.low <= min(b.open,b.close) <= max(b.open,b.close) <= b.high
               for b in rows):
            return result
        if any(a.timestamp_utc >= b.timestamp_utc for a,b in zip(rows,rows[1:])):
            return result
        index = {_utc(b.timestamp_utc):i for i,b in enumerate(rows)}
        pivots = {}
        for leg in ledger.get("legs") or []:
            if leg.get("timeframe") != timeframe:
                return result
            for p in (leg.get("origin"),leg.get("terminal")):
                if not isinstance(p,dict):
                    return result
                kind = p.get("kind")
                field = {"confirmed_swing_high_candidate":"high", "confirmed_swing_low_candidate":"low"}.get(kind)
                i = index.get(p.get("pivot_timestamp_utc"))
                known = _time(p["confirmed_at_utc"])
                if known > cutoff:
                    continue
                if i is None:
                    continue  # Outside the loaded native window: never invent it.
                if (not field or rows[i].timestamp_utc+duration > known or
                        p.get("price") != getattr(rows[i],field)):
                    return result
                key = (p["pivot_timestamp_utc"],kind)
                if key in pivots and pivots[key] != p:
                    return result
                pivots[key] = p
        points = sorted(pivots.values(),key=lambda p:(p["pivot_timestamp_utc"],p["kind"]))
        point_known = {id(p): _time(p["confirmed_at_utc"]) for p in points}
        crossing_indices = _crossing_indices(rows, points, duration, point_known,calendar_offset)
        events = []
        for p in points:
            events.extend(_node_attempts(rows, points, p, duration, timeframe,
                                         point_known=point_known, crossing_indices=crossing_indices[id(p)],calendar_offset=calendar_offset))
        # Latest event remains visible even when it FAILED. Do not silently
        # replace it with an older surviving direction and call that current.
        events.sort(key=lambda e:(e["first_close_utc"],e["node"]["pivot_timestamp_utc"]))
        selected=events[-1] if events else None
        result.update(status="native_node_sequence_review",events=events,selected=selected,
            through_utc=_utc(rows[-1].timestamp_utc),latest_closed_end_utc=_utc(rows[-1].timestamp_utc+duration))
        if include_node_inventory:
            result['node_process_inventory']=_node_inventory(events,selected,node_ids)
        return _describe_selected(result)
    except (KeyError,TypeError,ValueError,AttributeError,OverflowError):
        return result


def relate_native_background(reviews):
    """Compare actual node sequences without promoting child closes to parent."""
    for i,tf in enumerate(ORDER):
        current=reviews.get(tf,{}).get("native_structure_sequence")
        if not current or not i:
            continue
        ptf=ORDER[i-1]
        parent=reviews.get(ptf,{}).get("native_structure_sequence") or {}
        p,c=parent.get("selected"),current.get("selected")
        if not p or not c:
            continue
        live={"close_through_with_follow","return_held_node"}
        relation=("same_direction_node_paths" if p["direction"]==c["direction"] else "opposing_node_paths")
        if p["state"] not in live or c["state"] not in live:
            relation="failed_or_unconfirmed_path_involved"
        current["parent_relation"]=dict(parent_timeframe=ptf,relation=relation,
            parent_node_id=p["node_id"],parent_state=p["state"],
            parent_attempt_id=p.get("attempt_id"), parent_process_name=parent.get("name"),
            parent_closed_through=parent.get("latest_closed_end_utc"),
            parent_update_pending=parent.get("latest_closed_end_utc","")<current.get("latest_closed_end_utc",""),
            parent_task_adjudicated=False,trade_permission=False)
    return reviews


class NativeStructureTimeline:
    """Reuse exact node attempts while projecting witnesses to an earlier cutoff.

    Owned by ONE immutable snapshot reader. Future state, future contacts and
    future confirmed pivots are never copied into a source-time read. Invalid
    full inputs disable this shortcut and retain the original prefix reviewer.
    """
    def __init__(self, bars, ledger, *, timeframe, as_of_utc, calendar_offset=None):
        self.timeframe = timeframe
        self.ceiling = _time(as_of_utc)
        self.duration = timedelta(minutes=MINUTES[timeframe])
        self.rows = [b for b in bars if b.timestamp_utc+self.duration <= self.ceiling]
        self.ends = [b.timestamp_utc+self.duration for b in self.rows]
        self.index = {_utc(b.timestamp_utc):i for i,b in enumerate(self.rows)}
        self.full = review_native_structure(bars,ledger,timeframe=timeframe,
            as_of_utc=as_of_utc,calendar_offset=calendar_offset)
        self.valid = self.full['status'] == 'native_node_sequence_review'
        self.events = self.full.get('events') or []
        self.event_times = [_time(e['first_close_utc']) for e in self.events]
        points = {}
        for leg in ledger.get('legs') or []:
            for p in (leg.get('origin'),leg.get('terminal')):
                if isinstance(p,dict) and p.get('pivot_timestamp_utc') in self.index:
                    points[(p['pivot_timestamp_utc'],p['kind'])] = p
        self.points = sorted(points.values(),key=lambda p:(p['pivot_timestamp_utc'],p['kind']))
        self.point_known = {id(p):_time(p['confirmed_at_utc']) for p in self.points}
        self.node_events = None  # Build only for explicit parallel-process reads.

    def review(self, as_of_utc, *, include_node_inventory=False, node_ids=None):
        cutoff = _time(as_of_utc)
        if not self.valid or cutoff > self.ceiling:
            return None  # Let the caller use the exact original prefix path.
        n = bisect_right(self.ends,cutoff)
        if not n:
            return None
        result = deepcopy({k:v for k,v in self.full.items()
                           if k not in ('events','selected','name','readout','next_observation')})
        result.update(as_of_utc=as_of_utc,events=[],selected=None,
            through_utc=_utc(self.rows[n-1].timestamp_utc),
            latest_closed_end_utc=_utc(self.ends[n-1]))
        event_count = bisect_right(self.event_times,cutoff)
        if not event_count:
            if include_node_inventory:
                result['node_process_inventory']=_node_inventory([],None,node_ids)
            return result
        original = self.events[event_count-1]
        event = self._project_event(original,n,cutoff)
        result['selected'] = event
        if include_node_inventory:
            if self.node_events is None:
                self.node_events={}
                for e,t in zip(self.events,self.event_times):
                    times,events=self.node_events.setdefault(e['node_id'],([],[]))
                    times.append(t);events.append(e)
            current=[]
            groups=(self.node_events.values() if node_ids is None else
                    (self.node_events[k] for k in sorted(set(node_ids)) if k in self.node_events))
            for times,events in groups:
                count=bisect_right(times,cutoff)
                if count:
                    chosen=events[count-1]
                    current.append(event if chosen is original else
                                   self._project_event(chosen,n,cutoff,include_targets=False))
            result['node_process_inventory']=_node_inventory(current,event,node_ids)
        return _describe_selected(result)

    def _project_event(self, original, n, cutoff, *, include_targets=True):
        """One actual attempt as known then; never copy its final future state."""
        event = deepcopy(original)
        for key in ('follow_through_utc','retest_utc','reclaim_utc','origin_broken_utc','ended_at_utc'):
            if event[key] and _time(event[key]) > cutoff:
                event[key] = None
        # A gap is observed only when the next non-contiguous bar is closed,
        # not at the earlier bar's end that marks the interrupted attempt.
        gap_observed = False
        if original['state'] == 'coverage_gap_requires_review':
            last = self.index[original['last_observed_bar_utc']]
            gap_observed = last+1 < n
            if not gap_observed:
                event['ended_at_utc'] = None
        event['state'] = ('origin_broken' if event['origin_broken_utc'] else
            'crossing_reclaimed' if event['reclaim_utc'] else
            'coverage_gap_requires_review' if gap_observed else
            'return_held_node' if event['retest_utc'] else
            'close_through_with_follow' if event['follow_through_utc'] else
            'close_through_pending_follow')
        if not event['ended_at_utc']:
            event['last_observed_bar_utc'] = _utc(self.rows[n-1].timestamp_utc)
        event['witnesses'] = [w for w in event['witnesses']
            if _time(w['bar_open_utc'])+self.duration <= cutoff]
        event['target_candidates'] = []
        if include_targets and event['state'] in {'close_through_with_follow','return_held_node'}:
            first = self.index[event['first_close_bar_utc']]
            sign = 1 if event['direction']=='up' else -1
            extreme = (max(b.high for b in self.rows[first:n]) if sign>0 else
                       min(b.low for b in self.rows[first:n]))
            close = self.rows[n-1].close
            targets = [p for p in self.points if p['kind']==event['node']['kind']
                and self.point_known[id(p)] <= self.rows[first].timestamp_utc
                and sign*(p['price']-close)>0 and sign*(p['price']-extreme)>0]
            # Projection owns every mutable descendant it returns. Targets
            # come from the immutable ledger and must not leak its references
            # when the reader transfers this freshly built receipt directly.
            event['target_candidates'] = deepcopy(sorted(targets,key=lambda p:abs(p['price']-close))[:2])
        return event


class _SourceFrameInputIndex:
    """One immutable native input's exact coverage/identity/knowledge prefixes.

    A bad future price is NOT rejected here: the timeline may fall back to
    independent prefix validation. Only ordered timestamps permit bisect.
    Equal counts identify equal sets solely within this raw+ledger identity,
    never across a different or mutable snapshot.
    """
    def __init__(self,raw,ledger,timeframe,snapshot):
        duration=timedelta(minutes=MINUTES[timeframe])
        self.ends=[_time(b['timestamp_utc'])+duration for b in raw]
        if any(a>=b for a,b in zip(self.ends,self.ends[1:])):
            raise ValueError('ordered source frame index required')
        self.first_foreign=next((i for i,b in enumerate(raw) if
            b.get('timeframe',timeframe)!=timeframe or
            b.get('provider',snapshot.get('provider'))!=snapshot.get('provider') or
            any(b.get(k,snapshot.get('instrument'))!=snapshot.get('instrument')
                for k in ('instrument','symbol'))),len(raw))
        self.confirmations=sorted(_time(p['confirmed_at_utc'])
            for leg in ledger['legs'] for p in (leg['origin'],leg['terminal']))

    def prefix(self,known):
        return bisect_right(self.ends,known),bisect_right(self.confirmations,known)


def source_time_background(snapshot,timeframe,known_at_utc, *, _frame_cache=None, _timeline_cache=None, _input_cache=None, include_node_inventory=False, node_ids_by_timeframe=None):
    """Reconstruct parent-to-working observations AT source confirmation.

    Does not copy today's state back into an old source. Old raw extrema may
    be used only after their own confirmation. Missing higher data stays absent.
    """
    try:
        from .live_xauusd_multitimeframe import OHLCBar
    except ImportError:
        from live_xauusd_multitimeframe import OHLCBar
    reviews={}
    if timeframe not in ORDER:
        return reviews
    for tf in ORDER[:ORDER.index(timeframe)+1]:
        node_ids=None if node_ids_by_timeframe is None else tuple(sorted(set(node_ids_by_timeframe.get(tf,()))))
        history=(snapshot.get('chart_history') or {}).get(tf) or {}
        raw=history.get('bars') or []
        if not raw:
            continue
        try:
            state=resolve_native_timeframe_state(snapshot,tf)
            if (history.get('timeframe',tf)!=tf
                    or history.get('provider',snapshot.get('provider'))!=snapshot.get('provider')
                    or any(history.get(key,snapshot.get('instrument'))!=snapshot.get('instrument')
                           for key in ('instrument','symbol'))):
                continue
            known = _time(known_at_utc)
            duration = timedelta(minutes=MINUTES[tf])
            ledger = state.get('candidate_wave_ledger') or {}
            input_key=(tf,id(raw),id(ledger))
            indexed=None
            if _input_cache is not None:
                if input_key not in _input_cache:
                    try:
                        _input_cache[input_key]=_SourceFrameInputIndex(raw,ledger,tf,snapshot)
                    except (KeyError,TypeError,ValueError,AttributeError,OverflowError):
                        _input_cache[input_key]=None
                indexed=_input_cache[input_key]
            if indexed is not None:
                eligible_count,confirmed=indexed.prefix(known)
                if indexed.first_foreign<eligible_count:
                    continue
                eligible=None  # no prefix object allocation on timeline success
            else:
                eligible=[b for b in raw if _time(b['timestamp_utc'])+duration<=known]
                eligible_count=len(eligible)
                if any(b.get('timeframe',tf)!=tf or b.get('provider',snapshot.get('provider'))!=snapshot.get('provider') or
                       any(b.get(key,snapshot.get('instrument'))!=snapshot.get('instrument')
                           for key in ('instrument','symbol')) for b in eligible):
                    continue
            cache_key = None
            if _frame_cache is not None:
                # This cache is created inside one immutable source-ledger
                # replay. Equal parent candle coverage is not sufficient:
                # pivot confirmations can occur between parent closes.
                if indexed is None:
                    confirmed = tuple((p.get('pivot_timestamp_utc'),p.get('kind'),p.get('confirmed_at_utc'))
                        for leg in ledger.get('legs') or [] for p in (leg['origin'],leg['terminal'])
                        if _time(p['confirmed_at_utc']) <= known)
                cache_key = (tf,id(raw),id(ledger),eligible_count,confirmed,include_node_inventory,node_ids)
            cached = _frame_cache.get(cache_key) if _frame_cache is not None else None
            if cached is not None:
                review = deepcopy(cached)
                review['as_of_utc'] = known_at_utc
            else:
                review = None
                if _timeline_cache is not None:
                    timeline_key=(tf,id(raw),id(ledger))
                    if timeline_key not in _timeline_cache:
                        try:
                            all_bars=[OHLCBar(timestamp_utc=_time(b['timestamp_utc']),open=b['open'],high=b['high'],low=b['low'],close=b['close'],timeframe=tf) for b in raw]
                            _timeline_cache[timeline_key]=NativeStructureTimeline(all_bars,ledger,
                                timeframe=tf,as_of_utc=snapshot['as_of_utc'],calendar_offset=research_calendar(snapshot,tf))
                        except (KeyError,TypeError,ValueError,AttributeError,OverflowError):
                            # A malformed later bar must not erase a valid
                            # earlier source-time prefix.
                            _timeline_cache[timeline_key]=None
                    timeline=_timeline_cache[timeline_key]
                    if timeline is not None:
                        review=timeline.review(known_at_utc,include_node_inventory=include_node_inventory,node_ids=node_ids)
                if review is None:
                    if eligible is None:
                        eligible=raw[:eligible_count]
                    bars=[OHLCBar(timestamp_utc=_time(b['timestamp_utc']),open=b['open'],high=b['high'],low=b['low'],close=b['close'],timeframe=tf) for b in eligible]
                    review=review_native_structure(bars,ledger,timeframe=tf,as_of_utc=known_at_utc,calendar_offset=research_calendar(snapshot,tf),include_node_inventory=include_node_inventory,node_ids=node_ids)
                    # The independent fallback reviewer references ledger
                    # points. Isolate only the receipt we actually return;
                    # historical attempts are deliberately not part of it.
                    review=deepcopy({k:v for k,v in review.items() if k!='events'})
                if cache_key is not None and review['status']=='native_node_sequence_review':
                    _frame_cache[cache_key] = deepcopy({k:v for k,v in review.items() if k!='events'})
            if review['status']=='native_node_sequence_review':
                # Never copy every historical attempt into each source receipt.
                # The opt-in inventory holds only each node's latest attempt.
                review={k:v for k,v in review.items() if k!='events'}
                reviews[tf]={'native_structure_sequence':review}
        except (KeyError,TypeError,ValueError,AttributeError):
            continue
    relate_native_background(reviews)
    return dict(as_of_utc=known_at_utc,working_timeframe=timeframe,
        frames=[r['native_structure_sequence'] for r in reviews.values()],
        parent_target_adjudicated=False,trade_permission=False)


class _LatestSourceFrameCache:
    """Keep only the last exact prefix receipt for each native timeframe.

    A cache key contains every known pivot identity. Retaining one such tuple
    for every historical source cutoff multiplies that prefix, even though
    the receipts themselves are small. Eviction is only a reuse decision:
    earlier/nonsequential requests reconstruct the same original prefix using
    the existing timeline/reviewer, not a different market or source rule.
    """

    def __init__(self):
        self._frames = {}

    def get(self, key):
        entry = self._frames.get(key[0])
        return entry[1] if entry is not None and entry[0] == key else None

    def __setitem__(self, key, value):
        self._frames[key[0]] = (key, value)

    def __len__(self):
        return len(self._frames)


def source_time_background_reader(snapshot, *, include_node_inventory=False, _frame_cache=None):
    """Own bounded parent-frame reuse inside one replay; never a global cache."""
    frame_cache = _LatestSourceFrameCache() if _frame_cache is None else _frame_cache
    timeline_cache = {}
    input_cache = {}
    default_inventory=include_node_inventory
    def read(timeframe,known_at_utc,*,include_node_inventory=None,node_ids_by_timeframe=None):
        # Hit receipts are copied from private cache storage; timeline
        # projections and fallback receipts already own their descendants.
        # A second full deepcopy here repeated the same historical evidence
        # for every B/C read without providing another isolation boundary.
        return source_time_background(snapshot,timeframe,known_at_utc,
            _frame_cache=frame_cache,_timeline_cache=timeline_cache,_input_cache=input_cache,
            include_node_inventory=default_inventory if include_node_inventory is None else include_node_inventory,
            node_ids_by_timeframe=node_ids_by_timeframe)
    return read
