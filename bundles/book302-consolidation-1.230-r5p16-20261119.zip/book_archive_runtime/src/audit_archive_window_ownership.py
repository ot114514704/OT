"""Audit archive chart families against actual candles and their own C receipts."""
import argparse
import gzip
import json
import math
from datetime import datetime
from pathlib import Path

from .audit_archive_packet_binding import packet_binding_errors


def epoch(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()


def same_point(a, b):
    return bool(a and b) and all(a.get(k) == b.get(k) for k in
        ('kind', 'pivot_timestamp_utc', 'confirmed_at_utc', 'price'))


def audit(payload, timeframe):
    packet_errors = packet_binding_errors(payload, timeframe)
    snapshot = payload['snapshot']
    review = payload['reviews'][timeframe]['regime_measurement_review']
    cutoff = epoch(snapshot['as_of_utc'])
    bars = {b['timestamp_utc']: b for b in snapshot['chart_history'][timeframe]['bars']}
    results = []
    for family in review['families']:
        for projection in family.get('projections', []):
            errors = []
            receipt = family.get('return_ownership_by_projection_id', {}).get(projection['projection_id'], {})
            a, b, c = family['source_origin'], family['source_terminal'], projection['anchor']
            if any(family.get(k) != snapshot.get(k) for k in ('snapshot_id', 'as_of_utc')):
                errors.append('snapshot_identity_mismatch')
            if receipt.get('native_timeframe') != timeframe or projection.get('anchor_native_timeframe') != timeframe:
                errors.append('timeframe_mismatch')
            if not (same_point(receipt.get('retraced_wave_origin'), a) and
                    same_point(receipt.get('retraced_wave_terminal'), b) and
                    same_point(receipt.get('anchor'), c)):
                errors.append('own_C_receipt_mismatch')
            if not (epoch(a['pivot_timestamp_utc']) < epoch(b['pivot_timestamp_utc']) < epoch(c['pivot_timestamp_utc'])):
                errors.append('source_return_order_unresolved')
            if not min(a['price'], b['price']) < c['price'] < max(a['price'], b['price']):
                errors.append('C_not_inside_source')
            for point in (a, b, c):
                bar = bars.get(point['pivot_timestamp_utc'])
                if not bar or not bar['low'] - 1e-8 <= point['price'] <= bar['high'] + 1e-8:
                    errors.append('anchor_not_on_source_candle')
                if epoch(point['confirmed_at_utc']) > epoch(projection['known_at_utc']):
                    errors.append('anchor_not_yet_confirmed')
            if not epoch(receipt.get('known_at_utc', snapshot['as_of_utc'])) <= epoch(projection['known_at_utc']) <= cutoff:
                errors.append('receipt_or_projection_after_cutoff')
            if not math.isclose(projection['target'], c['price'] + b['price'] - a['price'], abs_tol=1e-5):
                errors.append('target_not_own_C_equal_distance')
            if projection.get('retraces_source_leg_id') != family['source_leg_id']:
                errors.append('borrowed_source_identity')
            results.append(dict(measurement_id=family['measurement_id'],
                projection_id=projection['projection_id'], errors=sorted(set(errors))))
    return dict(snapshot_id=snapshot['snapshot_id'], timeframe=timeframe,
        packet_errors=packet_errors,
        valid_for_delivery=not packet_errors and not any(row['errors'] for row in results),
        families=len(review['families']), projections=len(results),
        passed=sum(not row['errors'] for row in results),
        failed=[row for row in results if row['errors']],
        scope='geometry_source_ownership_and_clocks_not_strategy_accuracy',
        rows=results)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('artifact', type=Path)
    parser.add_argument('--timeframe', default='M5')
    args = parser.parse_args()
    with gzip.open(args.artifact, 'rt', encoding='utf-8') as stream:
        result = audit(json.load(stream), args.timeframe)
    target = args.artifact.with_suffix('.ownership.json')
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'rows'}))


if __name__ == '__main__':
    main()
