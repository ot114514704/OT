"""Closed-prefix discovery through the existing native ledger and 1:1 producer.

First runtime observation is separate from a calculable pivot clock. Keep
every observed projection version, including later selector withdrawals;
later C versions never replace the geometry of an earlier observation.
"""
from copy import deepcopy
from hashlib import sha256
import json
from math import isfinite

from .book_first_response_leg import clock,close_time,MINUTES
from .live_xauusd_multitimeframe import OHLCBar,_candidate_wave_ledger
from .live_regime_one_to_one import build_regime_one_to_one
from .one_to_one_structure_score import attach_scene_scores
from .mt5_structure_logic import attach_logic
from .integrated_market_logic import one_to_one_downstream_review
from .book_one_to_one_context import derive_one_to_one_book_context


def digest(value):
    return sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def _point(p):
    return {k:p[k] for k in ('kind','pivot_timestamp_utc','price','confirmed_at_utc')}


def _frozen(family,projection,market):
    fields=('measurement_id','source_leg_id','timeframe','source_origin','source_terminal','known_at_utc',
        'mode','source_opposing_wave_context','same_direction_push_balance')
    f={k:deepcopy(family[k]) for k in fields if k in family}
    f.update(provider=market['provider'],symbol=market['symbol'],return_ownership_by_projection_id={
        projection['projection_id']:deepcopy(family['return_ownership_by_projection_id'][projection['projection_id']])})
    p={k:deepcopy(v) for k,v in projection.items() if k not in ('outcome','first_unit_projection_receipt')}
    identity=dict(A=_point(f['source_origin']),B=_point(f['source_terminal']),C=_point(p['anchor']),
        target=p['target'],ordinal=p['ordinal'],source_known_at_utc=f['known_at_utc'],known_at_utc=p['known_at_utc'],
        retraces_source_leg_id=p.get('retraces_source_leg_id'),ownership=f['return_ownership_by_projection_id'])
    return f,p,identity


def observe_native_one_to_one(bars,timeframe,cutoff,market,registry,*,observed_at_utc=None,max_bars=8192):
    """Pure caller-owned persistence; no IO, quote handling or order permission.

    Rebuild extrema from OHLC at EACH prefix, not by filtering a final ledger.
    A disappearing selector record remains an observed ruler, not a failure.
    Retained rulers are scored from their own frozen source and current bars.
    """
    observed=observed_at_utc or cutoff
    if timeframe not in MINUTES or clock(observed)<clock(cutoff):raise ValueError('native_observation_clock_or_timeframe')
    if isinstance(max_bars,bool) or not isinstance(max_bars,int) or max_bars<8:raise ValueError('native_observation_window')
    if any(not market.get(k) for k in ('provider','symbol')):raise ValueError('native_observation_market')
    rows=[]
    for raw in bars:
        if clock(close_time(raw,timeframe))>clock(cutoff):continue
        row={k:deepcopy(raw[k]) for k in ('timestamp_utc','open','high','low','close')}
        for k,wanted in dict(provider=market['provider'],symbol=market['symbol'],timeframe=timeframe).items():
            if raw.get(k,wanted)!=wanted:raise ValueError('foreign_native_observation_'+k)
            row[k]=wanted
        if raw.get('instrument',market['symbol'])!=market['symbol']:raise ValueError('foreign_native_observation_instrument')
        values=[row[k] for k in ('open','high','low','close')]
        if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not isfinite(v) for v in values):raise ValueError('invalid_native_observation_OHLC')
        if not row['low']<=min(row['open'],row['close'])<=max(row['open'],row['close'])<=row['high']:raise ValueError('invalid_native_observation_OHLC')
        rows.append(row)
    if not rows or any(clock(b['timestamp_utc'])<=clock(a['timestamp_utc']) for a,b in zip(rows,rows[1:])):
        raise ValueError('native_observation_order')
    if clock(close_time(rows[-1],timeframe))!=clock(cutoff):raise ValueError('native_observation_latest_closed_bar_missing')
    rows=rows[-max_bars:]
    identity=dict(provider=market['provider'],symbol=market['symbol'],timeframe=timeframe,max_bars=max_bars)
    state=deepcopy(registry)
    if state.get('identity',identity)!=identity:raise ValueError('native_observation_identity_changed')
    if state.get('cutoff') and clock(cutoff)<clock(state['cutoff']):raise ValueError('native_observation_rewind')
    if state.get('observed_at_utc') and clock(observed)<clock(state['observed_at_utc']):raise ValueError('native_observation_runtime_clock_rewind')
    previous={r['timestamp_utc']:r for r in state.get('previous_bars',[])}
    current={r['timestamp_utc']:r for r in rows}
    if previous:
        overlap=previous.keys()&current.keys()
        if not overlap or any(previous[t]!=current[t] for t in overlap):raise ValueError('native_observation_history_changed')
        if any(rows[0]['timestamp_utc']<=t<=rows[-1]['timestamp_utc'] and t not in current for t in previous):raise ValueError('native_observation_history_missing')
    objects=[OHLCBar(clock(r['timestamp_utc']),r['open'],r['high'],r['low'],r['close'],provider=market['provider'],timeframe=timeframe) for r in rows]
    ledger=_candidate_wave_ledger(objects,max_bars=max_bars)
    snapshot=dict(snapshot_id='native_1to1_prefix:'+digest([identity,rows]),as_of_utc=cutoff,
        provider=market['provider'],instrument=market['symbol'],automatic_trade_permission=False,order_api_called=False,
        chart_history={timeframe:dict(bars=rows,source_mode='native_period_bars')},timeframe_states={timeframe:dict(
            timeframe=timeframe,latest_closed_bar=rows[-1],latest_closed_bar_end_utc=cutoff,candidate_wave_ledger=ledger)})
    review=build_regime_one_to_one(snapshot,timeframe,include_background=False)
    if review.get('status')!='native_regime_measurements_reviewed':raise ValueError('native_observation_producer:'+str(review.get('error')))
    records=state.setdefault('projections',{});sources=state.setdefault('sources',{});present=set();events=[]
    for family in review['families']:
        sid=family['measurement_id']
        sources.setdefault(sid,dict(source_leg_id=family['source_leg_id'],known_at_utc=family['known_at_utc'],first_observed_at_utc=observed,
            first_observed_cutoff_utc=cutoff,has_C_at_first_observation=bool(family['projections'])))
        for projection in family['projections']:
            key=digest([identity,sid,projection['projection_id']]);present.add(key)
            f,p,frozen=_frozen(family,projection,market)
            if key not in records:
                records[key]=dict(object_id='observed_1to1:'+key,measurement_id=sid,projection_id=p['projection_id'],
                    family=f,projection=p,identity=frozen,first_observed_at_utc=observed,first_observed_cutoff_utc=cutoff,
                    calculable_known_at_utc=p['known_at_utc'],first_snapshot_id=snapshot['snapshot_id'],selector_present=True,
                    first_reading=None,first_terminal_observation=None)
                events.append(dict(event='projection_first_observed',object_id=records[key]['object_id']))
            elif records[key]['identity']!=frozen:
                records[key]['identity_conflict']=True
                events.append(dict(event='projection_identity_conflict',object_id=records[key]['object_id']))
            elif not records[key].get('selector_present'):
                events.append(dict(event='selector_reappeared',object_id=records[key]['object_id']))
    scene=dict(timeframe=timeframe,cutoff_utc=cutoff,provider=market['provider'],instrument=market['symbol'],
        execution_context=dict(bars=rows),objects=[],snapshot_id=snapshot['snapshot_id'])
    for leg in ledger['legs']:
        if leg['temporal_order']=='sequential_confirmed_extrema':
            scene['objects'].append(dict(id=leg['leg_id'],layer='zigzag',evidence=dict(origin=leg['origin'],terminal=leg['terminal'])))
    for key,record in records.items():
        if record.get('selector_present') and key not in present:
            events.append(dict(event='selector_withdrew',object_id=record['object_id']))
        record['selector_present']=key in present
        if record.get('identity_conflict'):continue
        family,projection=record['family'],record['projection']
        # Once outside the loaded native window, keep the persistent witness
        # but do not manufacture coverage or feed missing prices to tasks.
        if clock(family['source_origin']['pivot_timestamp_utc'])<clock(rows[0]['timestamp_utc']):continue
        scene['objects'].append(dict(id=record['object_id'],layer='one_to_one',known_at_utc=projection['known_at_utc'],
            evidence=dict(record=deepcopy(family),projection=deepcopy(projection),ownership=deepcopy(
                family['return_ownership_by_projection_id'][projection['projection_id']]))))
    attach_logic(scene)
    attach_scene_scores(scene)
    by_id={r['object_id']:r for r in scene['one_to_one_structure_scores']['readings']}
    for record in records.values():
        reading=by_id.get(record['object_id'])
        if reading is None:continue
        if record['first_reading'] is None:record['first_reading']=deepcopy(reading)
        record['last_reading']=deepcopy(reading)
        embedding=reading.get('second_leg_current_structure_embedding') or {}
        if embedding.get('lifecycle')=='frozen_terminal_observation' and record['first_terminal_observation'] is None:
            record['first_terminal_observation']=dict(observed_at_utc=observed,cutoff_utc=cutoff,reading=deepcopy(reading))
            events.append(dict(event='terminal_first_observed',object_id=record['object_id']))
    downstream=one_to_one_downstream_review(scene['one_to_one_structure_scores']['readings'],cutoff,tasks=scene['structure_logic']['tasks'])
    scene['integrated_market_logic']=dict(one_to_one_downstream_review=downstream)
    summary=dict(schema='native_one_to_one_observation_v1',as_of_utc=cutoff,observed_at_utc=observed,
        snapshot_id=snapshot['snapshot_id'],timeframe=timeframe,provider=market['provider'],symbol=market['symbol'],
        bars=len(rows),source_sha256=digest(rows),source_count=len(sources),observed_projection_count=len(records),
        current_selector_projection_count=len(present),retained_scored_count=len(by_id),events=events,
        identity_conflict_count=sum(bool(r.get('identity_conflict')) for r in records.values()),
        automatic_trade_permission=False,order_api_called=False,author_degree_verified=False)
    state.update(identity=identity,cutoff=cutoff,observed_at_utc=observed,previous_bars=rows,last_summary=summary)
    registry.clear();registry.update(state)
    return dict(summary=summary,scene=scene)


def bind_native_book_context(scene,book):
    return derive_one_to_one_book_context(dict(scene,book_logic=book))
