"""Chapter 8 fig8-23: owned B-E / C-F-through-E boundaries, then >30% EF.

These are native geometry observations inside the existing B/C/E/F/G
candidate. They do not establish author wave degree, adoption, or a fill.
No external/global break event can stand in for these two constructions.
"""
from hashlib import sha256
import json
from decimal import Decimal
from fractions import Fraction
from math import isfinite
from .book_first_response_leg import close_time,clock


def observe_owned_recovery(rows, timeframe, raw):
    base = dict(status='unknown', source_pdf_pages=[266,268,269],
        basis='recovery_strict_0.3_EF_after_owned_dual_break',
        recovery_comparison='strict_greater_than',
        author_wave_degree_verified=False,
        rapid_recovery_assessment='unknown_author_speed_not_quantified',
        automatic_trade_permission=False, external_break_events_used=False)

    def unknown(reason, **facts):
        return dict(base, reason=reason, **facts)

    roles = ('b','c','e','f','g')
    if raw.get('timeframe')!=timeframe:
        return unknown('native_source_timeframe_mismatch')
    indices = [raw.get(f'{r}_index') for r in roles]
    if (any(not isinstance(i,int) or isinstance(i,bool) or not 0<=i<len(rows) for i in indices)
            or any(a>=b for a,b in zip(indices,indices[1:]))):
        return unknown('ordered_native_B_C_E_F_G_unavailable')
    sign = 1 if raw.get('side')=='long' else -1 if raw.get('side')=='short' else 0
    if not sign:
        return unknown('recovery_direction_unknown')
    adverse, favourable = ('low','high') if sign>0 else ('high','low')
    fields = (adverse,favourable,adverse,favourable,adverse)
    prices = []
    for role,i,field in zip(roles,indices,fields):
        price = raw.get(f'{role}_price')
        if price is None or not isfinite(float(price)) or float(price)!=float(rows[i][field]):
            return unknown(f'{role.upper()}_price_not_native_source')
        if raw.get(f'{role}_utc') != rows[i]['timestamp_utc']:
            return unknown(f'{role.upper()}_time_not_native_source')
        prices.append(float(price))
    bi,ci,ei,fi,gi = indices
    bp,cp,ep,fp,gp = prices
    if not (sign*(ep-bp)>0 and sign*(fp-cp)>0 and sign*(gp-ep)>0):
        return unknown('B_E_F_G_not_advancing_native_phase')
    if gi+2>=len(rows):
        return unknown('G_confirmation_unavailable')
    # The original illustration draws the new outer ruler only once C has
    # been exceeded. A half-BC recovery alone is insufficient for this route.
    c_break = next((i for i in range(ei+1,fi+1) if sign*(float(rows[i]['close'])-cp)>0),None)
    if c_break is None:
        return unknown('C_not_closed_crossed_before_F')
    q = lambda value: Fraction(str(value))
    outer_slope = (q(ep)-q(bp))/(ei-bi)
    turning_slope = (q(fp)-q(cp))/(fi-ci)
    # Both exact outer constructions must clear their own candles, not only
    # two convenient endpoint quotes. Equality is a contact, not clearance.
    if any(sign*(q(rows[i][adverse])-(q(bp)+outer_slope*(i-bi)))<=0
            for i in range(bi+1,fi+1) if i!=ei):
        return unknown('B_E_outer_intersects_established_wave')
    if any(sign*((q(cp)+turning_slope*(i-ci))-q(rows[i][favourable]))<=0
            for i in range(ci+1,fi)):
        return unknown('C_F_extension_intersects_established_wave')
    if any(sign*(q(rows[i][adverse])-(q(ep)+turning_slope*(i-ei)))<=0
            for i in range(ei+1,fi+1)):
        return unknown('C_F_shift_through_E_intersects_established_wave')
    phase = dict(timeframe=timeframe, side=raw['side'],
        points={r:dict(utc=rows[i]['timestamp_utc'],price=p) for r,i,p in zip(roles[:4],indices[:4],prices[:4])})
    phase_id = 'ch8phase:'+sha256(json.dumps(phase,sort_keys=True).encode()).hexdigest()[:24]
    construction = max(ei+2,fi+2,c_break)
    if construction>=len(rows):
        return unknown('boundary_construction_confirmation_unavailable')
    known = close_time(rows[construction],timeframe)

    def boundary(name,start,price,slope,anchors):
        hit = next((i for i in range(fi+1,len(rows)) if sign*(q(rows[i]['close'])-(q(price)+slope*(i-start)))<0),None)
        return dict(id=f'{phase_id}:{name}',phase_id=phase_id,source_timeframe=timeframe,
            native_anchor_roles=anchors,start_index=start,start_price=price,slope=float(slope),
            construction_known_at_utc=known,
            break_event=None if hit is None else dict(index=hit,utc=rows[hit]['timestamp_utc'],
                closed_at_utc=close_time(rows[hit],timeframe),price=float(rows[hit]['close']),
                level=float(q(price)+slope*(hit-start)),
                known_at_utc=max((known,close_time(rows[hit],timeframe)),key=clock),
                timing='historical_reconstruction' if hit<construction else 'observed_with_known_geometry'))

    boundaries = dict(outer=boundary('outer_B_E',bi,bp,outer_slope,['B','E']),
        turning=boundary('turning_C_F_through_E',ei,ep,turning_slope,['C','F','E']))
    threshold=abs(Decimal(str(fp))-Decimal(str(ep)))*Decimal('0.3')
    facts = dict(phase_id=phase_id,phase_source=phase,boundaries=boundaries,
        boundary_geometries_distinct=outer_slope!=turning_slope,
        boundary_comparison_arithmetic='exact_native_quote_fraction_per_bar',
        construction_known_at_utc=known,c_break_utc=rows[c_break]['timestamp_utc'],
        recovery_threshold=float(threshold),comparison_arithmetic='decimal_native_quote_values',
        recovery_origin=dict(index=gi,utc=rows[gi]['timestamp_utc'],price=gp))
    events = [b['break_event'] for b in boundaries.values()]
    if any(e is None for e in events):
        return dict(base,status='pending',reason='await_owned_dual_closed_break',**facts)
    dual = max(e['index'] for e in events)
    facts.update(dual_break_index=dual,dual_break_utc=rows[dual]['timestamp_utc'],
        dual_break_known_at_utc=max((e['known_at_utc'] for e in events),key=clock))
    # Recovery must start at the G of this post-break correction. A G which
    # predates the second boundary cannot be relabelled after a later break.
    if gi<dual:
        return unknown('G_precedes_completion_of_owned_dual_break',**facts)
    trigger = next((i for i in range(gi+1,len(rows))
        if sign*(Decimal(str(rows[i][favourable]))-Decimal(str(gp)))>threshold),None)
    if trigger is None:
        return dict(base,status='pending',reason='await_strict_0.3_EF_after_G',**facts)
    ready = max(construction,gi+2,trigger)
    if any(sign*(float(rows[i][adverse])-gp)<0 for i in range(gi+1,ready+1)):
        return unknown('G_revisited_before_30pct_eligibility',**facts)
    return dict(base,status='observed_candidate',reason=None,**facts,
        trigger_index=trigger,trigger_utc=rows[trigger]['timestamp_utc'],
        event_closed_at_utc=close_time(rows[trigger],timeframe),ready_index=ready,
        geometry_and_pivot_known_at_utc=close_time(rows[ready],timeframe),
        recovery_amount=float(sign*(Decimal(str(rows[trigger][favourable]))-Decimal(str(gp)))),
        boundary_event_order='unknown_same_native_bar' if events[0]['index']==events[1]['index'] else 'native_bar_order')
