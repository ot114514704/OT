"""Causal Book/Unified wave revision reconciliation.

This module never chooses an author wave degree and never grants execution.
It only decides whether two native geometry packets describe the exact same
confirmed pivot revision, a later revision of the same lineage, or unrelated
waves.  Geometry scores may enter a composite only for the exact revision.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime


def _clock(value):
    return datetime.fromisoformat(str(value).replace("Z", "+00:00"))


def reconcile_book_unified_revision(book_candidate, unified_packet, *, timeframe, cutoff,
                                    phase_id=None):
    book = book_candidate if isinstance(book_candidate, dict) else {}
    unified = unified_packet if isinstance(unified_packet, dict) else {}
    bp = list(book.get("pivot_times") or [])
    up = list(unified.get("confirmed_pivot_times") or unified.get("pivot_times") or [])
    lineage_b = book.get("wave_lineage_id")
    lineage_u = unified.get("wave_lineage_id") or unified.get("canonical_wave_lineage_id")
    direction_b = book.get("direction")
    direction_u = unified.get("direction")
    base = dict(
        schema="book_unified_wave_revision_reconciliation_v1",
        timeframe=timeframe,
        cutoff_utc=cutoff,
        book_lineage_id=lineage_b,
        unified_lineage_id=lineage_u,
        book_pivot_times=bp,
        unified_pivot_times=up,
        book_known_at_utc=book.get("known_at_utc"),
        unified_known_at_utc=unified.get("known_at_utc"),
        book_direction=direction_b,
        unified_direction=direction_u,
        phase_id=phase_id,
        state="unknown",
        reason=None,
        score_admission=False,
        next_action="wait_for_complete_native_revision_identity",
        automatic_trade_permission=False,
    )

    def fail(reason, action="wait_for_complete_native_revision_identity"):
        return dict(base, state="unknown", reason=reason, next_action=action)

    if not bp or not up:
        return fail("confirmed_pivot_sequence_missing")
    if not lineage_b or not lineage_u:
        return fail("wave_lineage_missing")
    if lineage_b != lineage_u:
        return fail("different_wave_lineage", "do_not_bind_unrelated_wave_geometry")
    if direction_b not in ("up", "down") or direction_u not in ("up", "down"):
        return fail("wave_direction_missing")
    if direction_b != direction_u:
        return fail("wave_direction_conflict", "do_not_bind_opposite_direction_geometry")
    if timeframe != unified.get("timeframe", timeframe):
        return fail("timeframe_mismatch")

    common = 0
    for left, right in zip(bp, up):
        if left != right:
            break
        common += 1
    exact = bp == up
    book_known = book.get("known_at_utc")
    unified_known = unified.get("known_at_utc")
    try:
        if book_known and _clock(book_known) > _clock(cutoff):
            return fail("book_revision_known_after_cutoff")
        if unified_known and _clock(unified_known) > _clock(cutoff):
            return fail("unified_revision_known_after_cutoff")
    except (TypeError, ValueError):
        return fail("revision_clock_invalid")

    base.update(common_confirmed_pivot_count=common,
                exact_pivot_revision=exact,
                phase_bound=bool(phase_id))
    if exact:
        if not phase_id:
            return dict(base, state="review_unknown", reason="book_phase_unbound",
                        next_action="bind_book_phase_before_geometry_score")
        return dict(base, state="same_revision", reason=None, score_admission=True,
                    next_action="allow_source_bound_geometry_score_only")

    if common < 3:
        return dict(base, state="review_unknown", reason="same_lineage_insufficient_common_pivots",
                    next_action="rebuild_native_pivot_chain_before_geometry_score")
    if len(up) > len(bp):
        status = "unified_newer_pivot_revision"
    elif len(bp) > len(up):
        status = "book_newer_pivot_revision"
    else:
        status = "same_length_pivot_revision"
    return dict(base, state="review_unknown", reason="pivot_revision_mismatch",
                revision_status=status,
                next_action="rebuild_book_revision_from_unified_confirmed_pivots_before_geometry_score")

