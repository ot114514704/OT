"""Recompute the current native Book event before presenting scene scores.

Printed pp124/135-136 (PDF135/146-147) describe one set of boundaries,
A/B and its response. They do not license joining unrelated chart maxima.
The existing Book force/card/family formulas remain engineering baselines.
"""
from copy import deepcopy
from .book_first_response_leg import clock, close_time, MINUTES
from .book_owned_force import owned_force_confluence
from .book_position_scorecard import position_scorecard
from .book_composite_assessment import composite_assessment


def scene_event_context(scene):
    tf = scene.get('timeframe')
    cutoff = scene.get('cutoff_utc')
    base = dict(schema='scene_native_event_context_v1', timeframe=tf, as_of_utc=cutoff,
                state='unknown', reason=None, source_binding_state='unverified_native_event',
                automatic_trade_permission=False, entry_permission=False,
                source_pdf_pages=[135, 146, 147], source_printed_pages=[124, 135, 136])

    def fail(reason):
        return dict(base, reason=reason, owned_force=None, scorecard=None, composite=None)

    try:
        book = scene.get('book_logic') or {}
        if tf not in MINUTES or book.get('timeframe') != tf or book.get('as_of_utc') != cutoff:
            return fail('book_scene_period_or_clock_mismatch')
        end = clock(cutoff)
        if end.utcoffset() is None:
            return fail('scene_clock_timezone_missing')
        rows = [r for r in (scene.get('execution_context') or {}).get('bars', [])
                if clock(close_time(r, tf)) <= end]
        if not rows:
            return fail('native_scene_bars_missing')
        stamps = [clock(r['timestamp_utc']) for r in rows]
        if any(t.utcoffset() is None for t in stamps) or any(b <= a for a, b in zip(stamps, stamps[1:])):
            return fail('native_scene_clock_order_invalid')
        provider = scene.get('provider')
        symbol = scene.get('instrument') or scene.get('symbol')
        if not provider or not symbol:
            return fail('scene_market_identity_missing')
        if any(r.get('provider') != provider or r.get('symbol') != symbol or r.get('timeframe') != tf for r in rows):
            return fail('native_scene_market_or_period_mismatch')
        # Neither a supplied decision score nor any drawn force is trusted.
        # Recompute all prices, source/owner identities and boundary scores.
        owned = owned_force_confluence(rows, tf, cutoff, book)
        card = position_scorecard(rows, tf, cutoff, book, owned)
        # This is a closed-bar observation, never an entry decision. The real
        # paper runner separately computes its entry_review and risk receipt.
        composite = composite_assessment(card, 'scene_observation', None,
                                         book.get('setup_qualification') or {})
        native_phase = not card.get('reason') and bool(card.get('phase_id'))
        bound = native_phase and bool(card.get('boundary_pair_id')) and bool(card.get('source_id'))
        identity = card.get('source_identity') or {}
        if native_phase and (identity.get('provider') != provider or identity.get('symbol') != symbol):
            return fail('recomputed_event_market_identity_mismatch')
        return dict(base, state='bound_measurements' if bound else 'partial_native_event' if native_phase else 'unknown',
                    reason=card.get('reason') or (None if bound else owned.get('reason') or 'native_event_source_incomplete'),
                    source_binding_state='same_native_book_event_recomputed' if bound else base['source_binding_state'],
                    phase_id=card.get('phase_id'), boundary_pair_id=card.get('boundary_pair_id'),
                    source_id=card.get('source_id'), source_identity=deepcopy(identity),
                    direction=card.get('direction'), owned_force=owned, scorecard=card, composite=composite)
    except (KeyError, ValueError, TypeError, IndexError, ArithmeticError, AttributeError):
        return fail('native_event_identity_clock_or_history_incomplete')


def event_breakout_confluence(event):
    """A scalar requires the existing complete, qualified same-source receipt."""
    event = event or {}
    owned = event.get('owned_force') or {}
    verified = (event.get('state') == 'bound_measurements'
                and owned.get('source_binding_state') == 'same_native_boundary_pair_and_force_verified'
                and all(owned.get(k) == event.get(k) for k in
                        ('timeframe', 'as_of_utc', 'phase_id', 'boundary_pair_id', 'source_id', 'source_identity')))
    complete = verified and owned.get('state') == 'complete'
    reason = None if complete else owned.get('reason') or event.get('reason') or 'same_native_event_binding_required'
    return dict(schema='scene_event_breakout_confluence_v2',
                state='complete' if complete else 'measurement_only' if verified else 'unknown',
                score=owned.get('score') if complete else None,
                geometry_score=owned.get('geometry_score') if verified else None,
                force_score=owned.get('force_score') if verified else None,
                weakest_breakout_score=owned.get('weakest_breakout_score') if verified else None,
                unknown_components=[] if complete else [reason], reason=reason,
                source_binding_state=owned.get('source_binding_state') if verified else 'unverified_native_event',
                phase_id=event.get('phase_id'), boundary_pair_id=event.get('boundary_pair_id'),
                source_id=event.get('source_id'), source_identity=deepcopy(event.get('source_identity')),
                timeframe=event.get('timeframe'), as_of_utc=event.get('as_of_utc'),
                scope='current_native_book_event_descriptive_measurement',
                semantics='existing_same_native_pair_force_and_weakest_break_minimum; no_chart_maxima',
                entry_permission=False, automatic_trade_permission=False)


def event_components(event):
    """Expose the existing stage-specific family composite, without refitting."""
    event = event or {}
    composite = event.get('composite') or {}
    stage = composite.get('active_stage', 'breakout_observation')
    reading = (composite.get('stages') or {}).get(stage) or {}
    groups = reading.get('groups') or {}
    bound = event.get('state') == 'bound_measurements'
    components = [dict(key=k, value=v['score']/100 if bound and v.get('score') is not None else None,
                       weight=100*reading['weights'][k], state='observed' if bound and v.get('score') is not None else 'unknown',
                       source_ids=[event['source_id']] if event.get('source_id') else [],
                       reason=v.get('reason') if bound else event.get('reason'), phase_id=event.get('phase_id'),
                       boundary_pair_id=event.get('boundary_pair_id'), formula=reading.get('formula'))
                  for k, v in groups.items()]
    coverage = reading.get('coverage') or {}
    fraction = coverage.get('measured', 0)/coverage['required'] if bound and coverage.get('required') else 0.0
    return components, reading.get('score') if bound else None, round(fraction, 4)
