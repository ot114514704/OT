"""Chapter 5 direction/B protection, separate from a retest or an order.

Source PDF 103-104,108-109,114-115,120. Closed-candle observation and the
upstream radius-2 A candidate are engineering conventions, not book axioms.
"""
from hashlib import sha256
from math import isfinite
from .book_first_response_leg import clock, close_time


def setup_state(bars, timeframe, cutoff, line, outer, turning, stop, change):
    rows = [r for r in bars if clock(close_time(r, timeframe)) <= clock(cutoff)]
    base = dict(schema='book_setup_state_v1', timeframe=timeframe, as_of_utc=cutoff,
                source_pdf_pages=[103,104,108,109,114,115,120],
                trade_permission=False, entry_permission=False,
                risk_budget_status='not_evaluated', target_status='not_evaluated',
                engineering_conventions=['closed_bar_observation', 'upstream_A_pivot_radius_2',
                                         'B_from_bound_pre_break_segment'],
                author_wave_membership_verified=False, known_at_utc=cutoff)
    def result(status, action, **kwargs):
        return dict(base, status=status, action=action, **kwargs)
    if not rows or not line.get('qualified') or line.get('direction') not in ('up','down'):
        return result('unknown', '等待有效趋势线与拐点线')
    side = 'down' if line['direction']=='up' else 'up'
    base['direction_candidate'] = side
    base['source_ruler_id'] = sha256(str((timeframe, line.get('start_index'),
        line.get('end_index'), line.get('start_price'), line.get('end_price'),
        rows[0]['timestamp_utc'])).encode()).hexdigest()[:24]
    def event(fact):
        i = fact.get('break_index')
        if fact.get('status')!='observed_candidate': return None
        if (isinstance(i,bool) or not isinstance(i,int) or not 0<=i<len(rows)
                or fact.get('break_side')!=side): return None
        if fact.get('timeframe',timeframe)!=timeframe: return None
        if fact.get('break_utc')!=rows[i]['timestamp_utc']: return None
        known = fact.get('known_at_utc')
        try:
            if not known or not clock(close_time(rows[i],timeframe))<=clock(known)<=clock(cutoff):
                return None
        except (ValueError,TypeError):
            return None
        return i
    oi, ti = event(outer), event(turning)
    base['conditions'] = dict(trendline_broken=oi is not None,
                              turning_line_broken=ti is not None,
                              boundary_A_broken=False, B_protected=None)
    base['both_boundaries_broken'] = oi is not None and ti is not None
    def partial():
        state, action = ('turning_only','等待趋势线突破') if ti is not None else (
            ('trendline_only','等待拐点线突破') if oi is not None else ('no_break','等待双线突破'))
        return result(state, action)
    if oi is None and ti is None:return partial()
    if base['both_boundaries_broken']:
        second=max(oi,ti)
        established=max([outer['known_at_utc'],turning['known_at_utc'],close_time(rows[second],timeframe)],key=clock)
        base.update(dual_break_utc=rows[second]['timestamp_utc'], dual_known_at_utc=established,
                    break_order='simultaneous' if oi==ti else 'outer_first' if oi<ti else 'turning_first')
    try:
        b=float(stop['reference_price']); bk=stop['known_at_utc']
        valid=(stop.get('status')=='observed_candidate' and isfinite(b) and b>0
               and not isinstance(stop['reference_price'],bool)
               and stop.get('timeframe',timeframe)==timeframe and clock(bk)<=clock(cutoff))
    except (KeyError,ValueError,TypeError): valid=False
    if not valid:
        return result('stop_unknown','双线已破，等待 B 点依据') if base['both_boundaries_broken'] else partial()
    base['stop_reference']=b
    # Do not require a close beyond B: a closed candle's wick establishes that
    # price crossed B. No intrabar fill, execution time or slippage is inferred.
    adverse='low' if side=='up' else 'high'
    # Either boundary may break first. A B breach between turning-first and
    # the later outer break must remain invalid after the second break.
    first=min(i for i in (oi,ti) if i is not None)
    # The first boundary bar can also pierce the frozen protective B.  Start
    # at ``first`` so a same-bar boundary/B conflict retires the setup instead
    # of being mislabelled as a direction confirmation.
    first_breach=next((i for i in range(first,len(rows)) if
        (float(rows[i][adverse])<b if side=='up' else float(rows[i][adverse])>b)),None)
    base['conditions']['B_protected']=first_breach is None
    if first_breach is not None:
        return result('stop_breached','B 点已越界，等待新结构',
                      invalidated_at_utc=close_time(rows[first_breach],timeframe),
                      invalidation_basis='closed_candle_extreme_crossed_frozen_B')
    if not base['both_boundaries_broken']:return partial()
    from .book_boundary_freeze import validate_boundary_freeze
    frozen=validate_boundary_freeze(rows,timeframe,cutoff,line,change,first)
    base['boundary_A_freeze']=frozen
    if frozen['status']!='frozen_before_first_boundary':
        return result('boundary_a_unknown','双线已破，等待首次突破前 A 点依据',
                      boundary_a_unknown_reason=frozen['reason'])
    a=frozen['point']['price']
    base['boundary_a_price']=a
    crossed=next((i for i in range(second,len(rows)) if
        (float(rows[i]['close'])>a if side=='up' else float(rows[i]['close'])<a)),None)
    base['conditions']['boundary_A_broken']=crossed is not None
    base['author_boundary_verified']=change.get('author_boundary_verified') is True
    if not base['author_boundary_verified']:
        return result('boundary_a_unverified','双线已破，候选 A 待作者结构核对',
                      boundary_a_source=change.get('boundary_a_source','unknown'))
    if crossed is None:
        return result('range_or_transition','双线已破，A 点待突破')
    action='向上条件成立，核对风险与目标' if side=='up' else '向下条件成立，核对风险与目标'
    return result('direction_confirmed',action,
                  A_cross_utc=rows[crossed]['timestamp_utc'],
                  direction_confirmed_at_utc=max(established,change['known_at_utc'],close_time(rows[crossed],timeframe),key=clock))
