"""Translate original ICT records into shared scene objects without a second strategy."""
from datetime import datetime, timedelta, timezone
from hashlib import sha256
from .ict_archive_detail import native

def epoch(value):
    if isinstance(value,(float,int)):return value/1000 if value>10**11 else value
    return datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()

def iso(value):return datetime.fromtimestamp(epoch(value),timezone.utc).isoformat()

def flatten(scene, native_period_bars=None):
    ctx=scene['ict_context'];tf=scene['timeframe'];end=epoch(scene['cutoff_utc'])
    minutes={'M1':'5','M5':'5','M15':'15','M30':'15','H1':'60','H4':'60','D1':'60','W1':'60'}[tf]
    def emit(group,kind,key,a,pa,b,pb,known,label,evidence,status='observed_candidate',native_timeframe=None):
        if known is None or epoch(known)>end:return
        a,b=epoch(a),min(epoch(b),end)
        if b<a or pa is None or pb is None:return
        identity=f"HistData:XAUUSD:{tf}:ict:{group}:{key}"
        scene['objects'].append(dict(id=sha256(identity.encode()).hexdigest()[:24],layer='ict',group=group,
            kind=kind,timeframe=tf,points=[[a,pa],[b,pb]],known_at_utc=iso(known),status=status,
            label=label,owner_id='',source_id=identity,evidence=evidence,
            native_timeframe=native_timeframe or evidence.get('source_timeframe'),
            rule_version='mt5_ict_layers_source_timeframe_v1'))
    def levels(record,scope):
        mapping=record.get('liquidity',{})
        for level in mapping.get('pools',[])+record.get('regular_liquidity',{}).get('levels',[])+record.get('weekly_stage_liquidity',{}).get('levels',[]):
            known=level.get('available_at')
            if not known:continue
            swept=level.get('sweep_known_at') or level.get('reclaim_known_at')
            swept=swept if swept and epoch(swept)<=end else None
            group=level.get('classification') or 'regular'
            group=group.lower() if group in ('ERL','IRL') else 'regular'
            side='BSL 买方' if level.get('side')=='buy_side_proxy' else 'SSL 卖方'
            label=(level.get('classification')+' ' if level.get('classification') else '')+side+(' · 已清扫' if swept else '')
            finish=swept or end
            if group=='regular' and not swept:
                anchor=level.get('first_anchor_time') or level.get('anchor_time') or known
                finish=min(end,max(epoch(known)+900,epoch(anchor)+3600))
            # A range can be classified after its internal pool was swept.
            # Keep that observed history; classification never becomes known
            # before its own available_at, nor erase it via a reversed interval.
            anchor=level.get('level_available_at') or known
            observed=max(epoch(known),epoch(swept)) if swept else epoch(known)
            emit(group,'line',scope+':'+level['id'],min(epoch(anchor),epoch(known)),level['price'],finish,level['price'],observed,label,level,
                 'swept_observation' if swept else 'observed_candidate')
        for arr in mapping.get('arrays',[]):
            known=arr.get('available_at')
            if known:
                finish=min([end]+[epoch(arr[k]) for k in ('full_mitigation_known_at','invalidation_known_at') if arr.get(k)])
                emit('irl','box',scope+':'+str(arr.get('id',known)),known,arr.get('lower'),finish,arr.get('upper'),known,'IRL FVG',arr)
    for d in ctx['days']:
        scope=d['date'];levels(d,scope)
        for f in d['charts'][minutes]['fvgs']:
            known=f['available_at'];a=epoch(known)
            from .ict_formation_provenance import bind_fvg_formation
            native_tf={'5':'M5','15':'M15','60':'H1'}[minutes]
            provenance=bind_fvg_formation(f,(native_period_bars or {}).get(int(minutes),[]),native_tf,
                scene['cutoff_utc'],scene.get('provider','HistData'),scene.get('instrument','XAUUSD'))
            f=dict(f,formation_provenance=provenance)
            emit('fvg','box',f"{minutes}:{known}:{f['lower']}:{f['upper']}",a,f['lower'],a+int(minutes)*360,f['upper'],known,
                f"M{minutes} {'看涨' if f['direction']=='bullish' else '看跌'} FVG",f,'geometric_fvg_candidate',
                native_timeframe={'5':'M5','15':'M15','60':'H1'}[minutes])
        for group,events in [('amd',d['amd_events']),('po3',d.get('po3',{}).get('zones',[]))]:
            for e in events:
                phase={'A':'收敛整理' if e.get('shape')=='contracting' else '积累整理','M':'越界收回','D':'直接扩张' if e.get('route')=='AD_no_M' else '派发扩张'}.get(e['phase'],e['phase'])
                emit(group,'box',f"{e.get('id',scope)}:{e['phase']}:{e['start']}:{e['available_at']}",e['start'],e['lower'],e['end'],e['upper'],e['available_at'],f"{group.upper()} {e['phase']} {phase}?",e)
        for name,s in d['sessions'].items():
            if not s.get('start') or not s.get('end'):continue
            if epoch(s['start'])>=end:continue
            if name not in ('asia','london','new_york'):continue
            session_name={'asia':'亚洲','london':'伦敦','new_york':'纽约'}[name]
            emit('sessions','band',scope+name,s['start'],0,s['end'],0,s['start'],session_name,dict(s,time_only=True),'scheduled_time')
            if s.get('complete'):
                for side in ('high','low'):
                    emit('levels','line',scope+name+side,s['end'],s[side],min(end,epoch(s['end'])+43200),s[side],s['end'],session_name+('高点' if side=='high' else '低点'),s)
        for w in d.get('silver_windows',[]):
            if epoch(w['start_ms'])<end:
                emit('silver','band',scope+w['id'],w['start_ms'],0,w['end_ms'],0,w['start_ms'],w.get('label','银弹')+' '+w.get('ny_time',''),w,'scheduled_time')
        midnight=next((m['time_ms']/1000 for m in d.get('midnights',[]) if m['date']==scope),None)
        if midnight and d.get('daily_open') is not None:
            opening=next((b for b in d['charts']['5']['bars'] if b[0]/1000>=midnight),None)
            if opening:
                next_midnight=(datetime.combine(datetime.fromisoformat(scope).date(),datetime.min.time(),native.NY)+timedelta(days=1)).timestamp()
                emit('levels','line',scope+'ny_open',opening[0],opening[1],min(end,next_midnight),opening[1],opening[0]/1000+300,'纽约零点开盘',dict(date=scope,source='first observed closed M5 at/after NY midnight'))
    for w in ctx['weeks']:
        scope=str(w.get('days',w.get('date','week')));levels(w,scope)
        pts=w.get('weekly_path',{}).get('points',[])
        for a,b in zip(pts,pts[1:]):
            known=max(a['available_at'],b['available_at'])
            emit('weekly','line',f"{a['time_ms']}:{b['time_ms']}",a['time_ms'],a['price'],b['time_ms'],b['price'],known,'周内 '+a['kind']+'→'+b['kind'],dict(a=a,b=b),
                 'developing_path' if a.get('provisional') or b.get('provisional') else 'observed_path')
        for day in w.get('weekly_path',{}).get('daily',[]):
            start=datetime.combine(datetime.fromisoformat(day['date']).date(),datetime.min.time(),native.NY)
            finish=(start+timedelta(days=1)).timestamp();known=min(end,finish)
            if start.timestamp()>=end:continue
            mid=(start.timestamp()+known)/2
            emit('daily','line',day['date']+'wick',mid,day['low'],mid,day['high'],known,'纽约日线 高/低',day,'observed_daily_ohlc')
            emit('daily','box',day['date']+'body',start.timestamp(),day['open'],known,day['close'],known,'纽约日线 '+('阳' if day['close']>=day['open'] else '阴'),day,'observed_daily_ohlc')
    for level in ctx.get('month',{}).get('prior_month_levels',[]):
        known=level.get('available_at')
        if known:
            emit('levels','line',level['id'],known,level['price'],end,level['price'],known,
                 '前月'+('高点' if level['side']=='buy_side_proxy' else '低点'),level,'observed_extreme_coverage_unverified')
    unique={}
    for obj in scene['objects']:
        old=unique.get(obj['id'])
        if old and old!=obj:raise ValueError('ICT identity reused with different evidence')
        unique[obj['id']]=obj
    scene['objects']=list(unique.values())
