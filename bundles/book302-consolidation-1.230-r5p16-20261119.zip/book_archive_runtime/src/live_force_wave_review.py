"""Whole native force observations, not an urgency/FVG or trade classifier.

Source: Feb2 first opposite delivery (7676543164736527516/3496751127699),
June8 sustained delivery vs sweep (7723164824425335636/5215224712777),
June9 first bull NOT force (7649471573649787459). No author numerical
speed/efficiency/bar-count threshold is supplied by those records.

Native close delivery and complete A→B geometry are required alongside a
predeparture-normalized force coverage of at least80% of native intervals.
The old aggregate momentum profile remains diagnostic evidence. The
preceding WHOLE remains the comparison/reference, even if not broken.
Every complete first opposite excursion is examined. Internal overlap and
pullbacks remain possible within the uncovered share of the whole wave.
"""
from collections import Counter
from hashlib import sha256
import json
import statistics

from .live_nested_stage_review import _native, _leg, _time
from .live_regime_one_to_one import _NativeWindow
from .live_source_wave_scope import source_wave_scope
from .live_wave_structure_context import WaveStructureIndex
from .live_one_to_one_source_selection import _close_delivery
from .native_market_sessions import research_calendar
from .native_timeframe_state import resolve_native_timeframe_state
from .live_force_coverage import delivery_coverage
from .first_response_evidence import channel_facts

METHOD = 'native_whole_force_coverage_v3'
MOMENTUM_METHOD = 'native_complete_wave_momentum_delivery_v1'
# Provisional evidence screens, not an asserted Alexander formula.
MIN_BODY_SHARE = 0.50
MIN_DIRECTIONAL_BODY_SHARE = 0.55
MIN_AMPLITUDE_OVER_TYPICAL_RANGE = 4.0
MIN_IMPULSE_RANGE_EXPANSION = 2.5
MIN_IMPULSE_BODY_EXPANSION = 2.0
MIN_SUSTAINED_BODY_EXPANSION = 1.5
MIN_DIRECTIONAL_CLOSE_RATIO = 0.50
MIN_RATE_OVER_TYPICAL_RANGE = 0.55
# A body-dominant path is not automatically force when it takes a long time
# to cover its envelope. Keep the balanced fallback for broad, orderly
# delivery, but reject low-liquidity drift below this provisional floor.
MIN_BALANCED_RATE_OVER_TYPICAL = 0.35
# A sweep/climax can still span a complete native envelope while most of its
# realised range arrives in one short burst.  Source notes distinguish that
# from same-speed real delivery; keep it in the rejected ledger instead of
# drawing it as force.  These are operational screens, not author formulas.
MIN_ACTIVITY_BARS = 8
BURST_WINDOW_BARS = 3
MAX_BURST_RANGE_SHARE = 0.60
MIN_ACTIVE_BLOCKS = 2
MIN_ACTIVE_BLOCK_RANGE_SHARE = 0.16
MIN_BURST_BODY_SHARE = 0.60
# A complete envelope can contain pullbacks and overlap, but a single
# active third followed by quiet drift is not a whole-period force delivery.
# This is deliberately lenient: two of three native thirds may carry the
# delivery; it is not a bar-count/straight-line requirement.
MIN_DELIVERY_BLOCK_BODY_SHARE = 0.30
MIN_DELIVERY_BLOCK_DIRECTIONAL_SHARE = 0.52
SOURCE_IDS = ['7676543164736527516', '7676543496751127699',
              '7723164824425335636', '7723165215224712777', '7649471573649787459']


def _expanded_same_period_channel_path(native, prior, direction):
    """Measure the preceding *whole native wave*, without expanding it.

    Earlier versions searched backwards for the largest qualified fit.  That
    made one M15 wave absorb unrelated pullbacks and older waves, producing a
    giant two-rail channel.  The preceding wave already is the background
    unit we need: keep its exact native bars and use one outer trendline in
    the display layer.
    """
    origin = _time(prior['origin']['pivot_timestamp_utc'])
    terminal = _time(prior['terminal']['pivot_timestamp_utc'])
    lo, hi = native.bounds(origin, terminal)
    if hi <= lo:
        return None
    bars = native.bars[lo:hi]
    if len(bars) < 32 or bars[-1].get('timestamp_utc') != prior['terminal']['pivot_timestamp_utc']:
        return None
    facts = channel_facts(bars, direction)
    if not facts.get('qualified'):
        return None
    return dict(bars=bars, facts=facts, start_index=lo, end_index=hi - 1)


def classify_cross_timeframe_force_priority(candidate, background, origin_background=None):
    """Describe a lower-period force against the nearest known parent process.

    This is a review priority, never an automatic trend/reversal verdict.
    A child period may oppose its parent while the parent is still active.
    The high-priority state binds the immediately preceding complete child
    wave and the nearest parent's closed process at A and B. An unrelated
    old force candidate cannot establish the current child's prior direction.
    """
    direction = candidate.get('direction')
    if direction not in {'up', 'down'}:
        return dict(status='unknown_child_direction', parent_timeframe=None,
                    parent_direction=None, prior_opposite_child=False,
                    structural_reversal_adjudicated=False)
    from .live_native_structure_sequence import ORDER
    tf=candidate.get('timeframe')
    parent_tf=ORDER[ORDER.index(tf)-1] if tf in ORDER and ORDER.index(tf)>0 else None
    active_states={'close_through_with_follow','return_held_node'}
    def nearest(context):
        row=next((r for r in (context or {}).get('higher_relations',[])
                  if parent_tf and r.get('timeframe')==parent_tf),None)
        return row if row and row.get('node_direction') in {'up','down'} and row.get('process_state') in active_states else None
    parent=nearest(background)
    before=nearest(origin_background)
    prior_opposite=candidate.get('preceding_whole_direction') in {'up','down'} and candidate['preceding_whole_direction']!=direction
    retained_parent_direction=bool(parent and before and parent['node_direction']==before['node_direction'])
    if not parent:
        status = 'parent_process_unknown'
    elif parent['node_direction'] == direction and prior_opposite and retained_parent_direction:
        status = 'higher_timeframe_aligned_reversal_priority'
    elif parent['node_direction'] != direction:
        status = 'countertrend_child_force_observation'
    else:
        status = 'higher_timeframe_aligned_force_observation'
    return dict(status=status, parent_timeframe=parent.get('timeframe') if parent else None,
        parent_direction=parent.get('node_direction') if parent else None,
        parent_process_state=parent.get('process_state') if parent else None,
        prior_opposite_child=prior_opposite,
        preceding_whole_wave_id=candidate.get('preceding_whole_wave_id'),
        preceding_whole_direction=candidate.get('preceding_whole_direction'),
        parent_direction_observed_at_origin_and_terminal=retained_parent_direction,
        same_parent_attempt=bool(parent and before and parent.get('attempt_id') and parent.get('attempt_id')==before.get('attempt_id')),
        parent_direction_is_node_process_observation=True,
        structural_reversal_adjudicated=False)


def attach_cross_timeframe_force_context(snapshot, timeframe, review, *, background_reader=None):
    """Attach source-time parent context without changing force admission."""
    from .live_regime_background_context import RegimeBackgroundIndex
    index = RegimeBackgroundIndex(snapshot, timeframe)
    if background_reader is not None:
        index.reader=background_reader
    candidates = sorted(review.get('force_wave_candidates', []),
                        key=lambda row: _time(row['origin_utc']))
    for candidate in candidates:
        family = dict(direction_observation=candidate['direction'],
            source_leg_id=candidate['force_leg_id'],
            source_origin=dict(pivot_timestamp_utc=candidate['origin_utc'],
                confirmed_at_utc=candidate['origin_confirmed_at_utc'], price=candidate['origin_price']),
            source_terminal=dict(pivot_timestamp_utc=candidate['terminal_utc'],
                confirmed_at_utc=candidate['terminal_confirmed_at_utc'], price=candidate['terminal_price']))
        point = dict(pivot_timestamp_utc=candidate['terminal_utc'],
            confirmed_at_utc=candidate['terminal_confirmed_at_utc'], price=candidate['terminal_price'])
        origin_context=index.at(family,candidate['origin_confirmed_at_utc'],family['source_origin'],'source_origin')
        context = index.at(family, candidate['known_at_utc'], point, 'source_terminal')
        priority = classify_cross_timeframe_force_priority(candidate, context, origin_context)
        candidate['cross_timeframe_context'] = dict(
            method='native_parent_process_force_priority_v1',
            working_timeframe=timeframe, known_at_utc=candidate['known_at_utc'],
            higher_relations=context.get('higher_relations', []),
            origin_known_at_utc=candidate['origin_confirmed_at_utc'],
            origin_higher_relations=origin_context.get('higher_relations', []),
            missing_or_invalid_periods=context.get('missing_or_invalid_periods', []),
            priority=priority, parent_task_adjudicated=False,
            structural_degree_adjudicated=False, trade_permission=False)
    review['cross_timeframe_force_context_method'] = 'native_parent_process_force_priority_v1'
    return review


def _legacy_momentum_profile(path, upward, amplitude):
    """Require body/rate/impulse evidence on the complete native wave.

    A complete A→B envelope is necessary but not sufficient: the source
    distinguishes rate-K/real-money delivery from wick-only or unusually
    regular low-liquidity movement.  Keep this profile on every candidate so
    later calibration can review rejected history instead of erasing it.
    """
    bars = path.get('bars') or []
    ranges = [max(0.0, float(b.get('high', 0.0)) - float(b.get('low', 0.0))) for b in bars]
    bodies = [abs(float(b.get('close', 0.0)) - float(b.get('open', 0.0))) for b in bars]
    typical = statistics.median(r for r in ranges if r > 0) if any(r > 0 for r in ranges) else 0.0
    if len(bars) < 3 or typical <= 0:
        return dict(method=MOMENTUM_METHOD, qualified=False,
                    reason='native_range_or_body_unavailable', bar_count=max(0, len(bars) - 1))
    directional = []
    opposite = []
    for bar in bars:
        delta = float(bar.get('close', 0.0)) - float(bar.get('open', 0.0))
        directed = delta if upward else -delta
        directional.append(max(0.0, directed))
        opposite.append(max(0.0, -directed))
    directional_total = sum(directional)
    opposite_total = sum(opposite)
    directional_body_share = directional_total / (directional_total + opposite_total) if directional_total + opposite_total else 0.0
    close_ratio = sum(
        (right['close'] > left['close'] if upward else right['close'] < left['close'])
        for left, right in zip(bars, bars[1:])
    ) / max(1, len(bars) - 1)
    body_share = sum(bodies) / max(1e-12, sum(ranges))
    range_expansion = max(ranges) / typical
    body_expansion = max(bodies) / typical
    amplitude_over_typical = abs(float(amplitude)) / typical
    rate_over_typical = abs(float(amplitude)) / max(1, len(bars) - 1) / typical
    # A complete envelope is not enough when the excursion is mostly a wick
    # or a slow, low-liquidity drift.  The strong delivery path must either
    # show both range *and* body expansion, or show sustained native pace
    # together with a meaningful body expansion.  The prior OR gate admitted
    # a large-range/low-body segment merely because its closes drifted in one
    # direction; retain that segment as rejected evidence instead.
    impulse_delivery = (
        range_expansion >= MIN_IMPULSE_RANGE_EXPANSION and
        body_expansion >= MIN_IMPULSE_BODY_EXPANSION
    )
    sustained_delivery = (
        rate_over_typical >= MIN_RATE_OVER_TYPICAL_RANGE and
        close_ratio >= MIN_DIRECTIONAL_CLOSE_RATIO and
        body_expansion >= MIN_SUSTAINED_BODY_EXPANSION
    )
    # A long, time-for-space wave may not print a single outsized body.  It
    # can still be genuine delivery when the whole path is body-dominant,
    # directionally balanced and closes continue to progress.  This narrow
    # fallback preserves that source-described case without admitting a
    # wick-led drift (which fails the body-share and close tests).
    balanced_delivery = (
        body_share >= 0.60 and
        directional_body_share >= 0.57 and
        close_ratio >= 0.55 and
        rate_over_typical >= MIN_BALANCED_RATE_OVER_TYPICAL
    )
    # Only candidates that already pass the base delivery screen need the
    # more expensive burst concentration check.  Rejected low-body paths are
    # still retained by the caller, but do not trigger a second full scan.
    # A single impulse-sized bar is evidence, not a whole-period delivery
    # mode.  It may support a candidate only when the complete native wave
    # still clears the same provisional pace floor used by the balanced path.
    # This prevents a slow, low-liquidity envelope from being painted as
    # force merely because one bar has an outsized body/range.
    whole_period_delivery = (
        sustained_delivery or
        balanced_delivery or
        (impulse_delivery and rate_over_typical >= MIN_BALANCED_RATE_OVER_TYPICAL)
    )
    base_qualified = (
        body_share >= MIN_BODY_SHARE and
        directional_body_share >= MIN_DIRECTIONAL_BODY_SHARE and
        amplitude_over_typical >= MIN_AMPLITUDE_OVER_TYPICAL_RANGE and
        whole_period_delivery
    )
    total_range = sum(ranges)
    if base_qualified and len(bars) >= MIN_ACTIVITY_BARS and total_range > 0:
        # Prefix sums keep this per-candidate screen linear without creating
        # a temporary slice for every possible burst window.
        prefix = [0.0]
        for value in ranges:
            prefix.append(prefix[-1] + value)
        burst_window_share = max(
            (prefix[i + BURST_WINDOW_BARS] - prefix[i]) / total_range
            for i in range(len(ranges) - BURST_WINDOW_BARS + 1)
        )
        block_count = 3
        block_size = max(1, (len(ranges) + block_count - 1) // block_count)
        block_shares = [
            (prefix[min(len(ranges), i + block_size)] - prefix[i]) / total_range
            for i in range(0, len(ranges), block_size)
        ]
        active_block_count = sum(share >= MIN_ACTIVE_BLOCK_RANGE_SHARE for share in block_shares)
        # Measure delivery in each native third, not just realised range.
        # This prevents a large first burst plus low-liquidity drift from
        # passing on global body_share while preserving genuine overlap.
        delivery_block_count = 0
        delivery_block_body_shares = []
        delivery_block_directional_shares = []
        for start in range(0, len(bars), block_size):
            stop = min(len(bars), start + block_size)
            block_ranges = ranges[start:stop]
            block_bodies = bodies[start:stop]
            block_directional = sum(directional[start:stop])
            block_opposite = sum(opposite[start:stop])
            block_range = sum(block_ranges)
            block_body = sum(block_bodies)
            body_ratio = block_body / block_range if block_range else 0.0
            directional_ratio = (block_directional / (block_directional + block_opposite)
                                 if block_directional + block_opposite else 0.0)
            delivery_block_body_shares.append(body_ratio)
            delivery_block_directional_shares.append(directional_ratio)
            if (body_ratio >= MIN_DELIVERY_BLOCK_BODY_SHARE and
                    directional_ratio >= MIN_DELIVERY_BLOCK_DIRECTIONAL_SHARE):
                delivery_block_count += 1
    else:
        burst_window_share = None
        active_block_count = None
        delivery_block_count = None
        delivery_block_body_shares = None
        delivery_block_directional_shares = None
    # A low-body wave whose range is concentrated in one short window is the
    # sweep/climax shape described in the source material, not a same-speed
    # force delivery.  A body-dominant wave may still qualify when it has a
    # genuine close path and complete native envelope.
    sweep_like_burst = bool(
        base_qualified and burst_window_share is not None and (
            (burst_window_share >= MAX_BURST_RANGE_SHARE and body_share < MIN_BURST_BODY_SHARE) or
            (active_block_count is not None and active_block_count < MIN_ACTIVE_BLOCKS and
             body_share < MIN_BURST_BODY_SHARE) or
            (delivery_block_count is not None and delivery_block_count < MIN_ACTIVE_BLOCKS and
             body_share < MIN_BURST_BODY_SHARE)
        )
    )
    qualified = (
        body_share >= MIN_BODY_SHARE and
        directional_body_share >= MIN_DIRECTIONAL_BODY_SHARE and
        amplitude_over_typical >= MIN_AMPLITUDE_OVER_TYPICAL_RANGE and
        not sweep_like_burst and
        whole_period_delivery
    )
    reason = 'momentum_body_rate_and_impulse' if qualified else 'low_liquidity_or_wick_drift'
    return dict(method=MOMENTUM_METHOD, qualified=qualified, reason=reason,
        bar_count=max(0, len(bars) - 1), body_share=body_share,
        directional_body_share=directional_body_share, directional_close_ratio=close_ratio,
        range_expansion=range_expansion, body_expansion=body_expansion,
        amplitude_over_typical_range=amplitude_over_typical,
        rate_over_typical_range=rate_over_typical,
        impulse_delivery=impulse_delivery,
        sustained_delivery=sustained_delivery,
        balanced_delivery=balanced_delivery,
        whole_period_delivery=whole_period_delivery,
        burst_window_range_share=burst_window_share,
        active_block_count=active_block_count,
        delivery_block_count=delivery_block_count,
        delivery_block_body_shares=delivery_block_body_shares,
        delivery_block_directional_shares=delivery_block_directional_shares,
        sweep_like_burst=sweep_like_burst,
        thresholds=dict(min_body_share=MIN_BODY_SHARE,
            min_directional_body_share=MIN_DIRECTIONAL_BODY_SHARE,
            min_amplitude_over_typical_range=MIN_AMPLITUDE_OVER_TYPICAL_RANGE,
            min_impulse_range_expansion=MIN_IMPULSE_RANGE_EXPANSION,
            min_impulse_body_expansion=MIN_IMPULSE_BODY_EXPANSION,
            min_sustained_body_expansion=MIN_SUSTAINED_BODY_EXPANSION,
            min_directional_close_ratio=MIN_DIRECTIONAL_CLOSE_RATIO,
            min_rate_over_typical_range=MIN_RATE_OVER_TYPICAL_RANGE,
            min_balanced_rate_over_typical=MIN_BALANCED_RATE_OVER_TYPICAL,
            min_impulse_delivery_rate_over_typical=MIN_BALANCED_RATE_OVER_TYPICAL,
            min_activity_bars=MIN_ACTIVITY_BARS,
            burst_window_bars=BURST_WINDOW_BARS,
            max_burst_window_range_share=MAX_BURST_RANGE_SHARE,
            min_active_blocks=MIN_ACTIVE_BLOCKS,
            min_active_block_range_share=MIN_ACTIVE_BLOCK_RANGE_SHARE,
            min_burst_body_share=MIN_BURST_BODY_SHARE,
            min_delivery_block_body_share=MIN_DELIVERY_BLOCK_BODY_SHARE,
            min_delivery_block_directional_share=MIN_DELIVERY_BLOCK_DIRECTIONAL_SHARE))


def _momentum_profile(path, upward, amplitude):
    legacy = _legacy_momentum_profile(path, upward, amplitude)
    coverage = delivery_coverage(path, upward, amplitude)
    # Coverage answers whether the native path kept delivering force across
    # its intervals.  The whole-wave profile answers whether the same A→B
    # envelope has enough body, amplitude and native pace to be called force
    # at all.  Either one alone is insufficient: coverage-only admitted the
    # short 3–4 bar impulse-like paths that the source distinguishes from a
    # complete force wave, while legacy-only could reject a broad wave merely
    # because its local delivery was uneven.  The main chart requires both;
    # both diagnostics remain visible for later fixed-case calibration.
    qualified = bool(legacy['qualified'] and coverage['qualified'])
    reason = 'momentum_body_rate_and_impulse' if qualified else (
        coverage['reason'] if not coverage['qualified'] else 'low_liquidity_or_wick_drift')
    return {**legacy, 'legacy_qualified':legacy['qualified'],
        'qualified':qualified, 'reason':reason,
        'delivery_coverage':coverage}


def _classify(context, departure, momentum, progress_nodes=(), terminal_close_progress=False):
    """Do not turn first-wave status, a wick, FVG or speed alone into force."""
    if context.get('status') != 'preceding_wave_and_local_structure_bound':
        return 'reference_unresolved'
    if not departure['sustained_source_close']:
        return 'departure_not_held_by_native_closes'
    if not momentum['qualified']:
        return 'low_liquidity_or_wick_drift_not_force'
    if any(node['sustained_source_close'] for node in context['nodes']):
        return 'held_preceding_structure_delivery'
    # June8's progressive recovery can still be INSIDE the prior whole fall.
    # Its own first push must have been genuinely extended and held; simply
    # accumulating overlapping pivots or touching the prior high is not enough.
    if any(node['sustained_source_close'] for node in progress_nodes):
        return 'held_whole_wave_progression_inside_prior_wave'
    c = context['comparison']
    pace, preceding = c['source_points_per_native_interval'], c['preceding_last_push_points_per_native_interval']
    if (terminal_close_progress and pace is not None and preceding is not None and pace >= preceding and
            c['source_amplitude'] >= c['preceding_last_push_amplitude']):
        return 'relative_whole_wave_departure'
    return 'first_opposite_wave_without_observed_force_delivery'


def _force_admission(reason, context, departure, momentum):
    """Separate own-period force from reference/degree adjudication.

    The source review uses the preceding whole wave and local nodes to explain
    *what the force is doing*, but those references are not a prerequisite for
    the observed A→B delivery itself.  The old caller used ``_classify`` as a
    hard gate, which made a fully delivered native wave disappear whenever its
    preceding structure was unresolved.  Keep that unresolved fact in the
    decision ledger, while admitting only a complete same-period wave that
    still passes the departure and delivery screens.
    """
    if not departure.get('sustained_source_close'):
        return False, 'departure_not_held_by_native_closes'
    if not momentum.get('qualified'):
        return False, 'low_liquidity_or_wick_drift_not_force'
    if context.get('status') == 'preceding_wave_and_local_structure_bound':
        if reason in ('held_preceding_structure_delivery',
                      'relative_whole_wave_departure',
                      'held_whole_wave_progression_inside_prior_wave'):
            return True, reason
        # A valid complete wave can be force even when its local reference
        # has no observed close-through yet.  Its structure relation remains
        # unresolved, but that must not erase the own-period observation.
        return True, 'whole_period_force_delivery_reference_pending'
    return True, 'whole_period_force_delivery_reference_unresolved'


def build_force_wave_review(snapshot, timeframe, *, include_response_evidence=False):
    result = dict(method_version=METHOD, timeframe=timeframe,
        snapshot_id=snapshot.get('snapshot_id'), as_of_utc=snapshot.get('as_of_utc'),
        status='native_force_wave_review_unavailable', force_wave_candidates=[],
        first_wave_review_counts={}, rejected_geometry_counts={},
        theory_source_message_ids=SOURCE_IDS, semantic_force_adjudicated=False,
        structural_degree_adjudicated=False, parent_reversal_adjudicated=False,
        trade_permission=False, admission_is_operational_hypothesis=True,
        legacy_short_force_and_ob_evidence_preserved=True)
    try:
        cutoff = _time(snapshot['as_of_utc'])
        state = resolve_native_timeframe_state(snapshot, timeframe)
        if not state:
            raise ValueError('own_native_timeframe_state_unresolved')
        snapshot = {**snapshot, 'timeframe_states':{**snapshot.get('timeframe_states', {}), timeframe:state}}
        _, raw, legs = _native(snapshot, timeframe, cutoff)
        native = _NativeWindow(raw, timeframe, cutoff, research_calendar(snapshot, timeframe))
        # Retain original order/ordinals including unordered outside-bar bounds;
        # filtering them out before extending can manufacture a connected chain.
        valid = [leg for leg in legs if _leg(leg, timeframe, raw, cutoff)]
        structure = WaveStructureIndex(legs, native)
        ordinals = {leg['leg_id']: i for i, leg in enumerate(legs)}
        if len(ordinals) != len(legs):
            raise ValueError('ambiguous_native_component_ids')
        seen, rejected, reviews, candidates, decisions = set(), Counter(), Counter(), [], []
        reversal_observations = []
        response_observations = []
        for leg in valid:
            a, b = leg['origin'], leg['terminal']
            known = max(a['confirmed_at_utc'], b['confirmed_at_utc'], key=_time)
            scope = source_wave_scope(legs, raw, timeframe, a, b, known,
                                      _window_index=native.envelope)
            if scope.get('status') != 'observed_same_period_zigzag_envelope':
                rejected['full_native_envelope_unresolved'] += 1
                continue
            source_id = scope['source_leg_id']
            if source_id in seen:
                continue
            seen.add(source_id)
            a, b = scope['origin'], scope['terminal']
            ta, tb = _time(a['pivot_timestamp_utc']), _time(b['pivot_timestamp_utc'])
            if not native.complete(ta, tb) or not native.envelope.contains(raw, timeframe,
                    ta, tb, *sorted((a['price'], b['price']))):
                rejected['native_history_gap_or_incomplete_extrema'] += 1
                continue
            context = structure.review(a, b, known)
            path = structure._path(a, b)
            lo, hi = native.bounds(ta, tb)
            start = max(0,lo-20)
            while start < lo and not native.complete(native.times[start],ta):
                start += 1
            path['baseline_bars'] = native.bars[start:lo]
            upward = b['price'] > a['price']
            # The origin candle's relevant edge is known only at its close;
            # this tests sustained departure, not an intrabar ordering guess.
            edge = raw[ta]['high'] if upward else raw[ta]['low']
            reference = dict(price=edge,
                confirmed_at_utc=(ta+native.duration).isoformat().replace('+00:00', 'Z'))
            departure = _close_delivery(path, reference, upward, compact_witnesses=True)
            ids = scope['component_source_leg_ids']
            progress_nodes = []
            for component_id in ids[:-1:2]:
                point = legs[ordinals[component_id]]['terminal']
                progress_nodes.append({**_close_delivery(path, point, upward, compact_witnesses=True),
                                       'price':point['price']})
            last_closes = [bar['close'] for bar in path['bars'][-3:]]
            terminal_progress = len(last_closes)==3 and all(
                (right>left if upward else right<left) for left,right in zip(last_closes,last_closes[1:]))
            momentum = _momentum_profile(path, upward, abs(b['price'] - a['price']))
            reason = _classify(context, departure, momentum, progress_nodes, terminal_progress)
            admitted, admission_reason = _force_admission(reason, context, departure, momentum)
            reviews[reason] += 1
            decisions.append(dict(force_leg_id=source_id,
                origin_group=f'{timeframe}:{a["pivot_timestamp_utc"]}:{a["kind"]}',
                timeframe=timeframe, origin_utc=a['pivot_timestamp_utc'], terminal_utc=b['pivot_timestamp_utc'],
                origin_price=a['price'],terminal_price=b['price'],known_at_utc=known,
                direction='up' if upward else 'down',admitted=admitted,reason=reason,
                admission_reason=admission_reason if admitted else reason,
                context_status=context.get('status'),
                departure_held=bool(departure.get('sustained_source_close')),
                momentum_qualified=bool(momentum.get('qualified')),
                legacy_momentum_qualified=bool(momentum.get('legacy_qualified')),
                bar_count=hi-lo, component_count=len(ids),
                coverage=momentum['delivery_coverage']['coverage']))
            prior = context.get('retraced_wave')
            nodes = [n for n in context['nodes'] if n['sustained_source_close']]
            # A same-period force can be observed before the preceding whole
            # reference is bound.  Keep the own-wave measurements and mark
            # the comparison side explicitly unknown instead of fabricating a
            # prior high/low or dropping the force from the main chart.
            c = dict(context.get('comparison') or {})
            c.setdefault('source_amplitude', abs(b['price'] - a['price']))
            c.setdefault('source_points_per_native_interval',
                          abs(b['price'] - a['price']) / max(1, hi - lo - 1))
            c.setdefault('preceding_whole_wave_amplitude', None)
            c.setdefault('preceding_whole_wave_points_per_native_interval', None)
            c.setdefault('preceding_last_push_amplitude', None)
            c.setdefault('preceding_last_push_points_per_native_interval', None)
            lo, hi = native.bounds(ta, tb)
            close_steps = [r['close']-l['close'] for l, r in zip(path['bars'], path['bars'][1:])]
            travel = sum(abs(d) for d in close_steps)
            candidate = dict(force_leg_id=source_id, timeframe=timeframe,
                origin_utc=a['pivot_timestamp_utc'], terminal_utc=b['pivot_timestamp_utc'],
                origin_price=a['price'], terminal_price=b['price'],
                origin_confirmed_at_utc=a['confirmed_at_utc'], terminal_confirmed_at_utc=b['confirmed_at_utc'],
                known_at_utc=known, direction='up' if upward else 'down',
                bar_count=hi-lo, component_count=len(ids),
                component_from_ordinal=ordinals[ids[0]], component_through_ordinal=ordinals[ids[-1]],
                component_chain_sha256=sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest(),
                origin_group=f'{timeframe}:{a["pivot_timestamp_utc"]}:{a["kind"]}',
                preceding_whole_wave_id=prior.get('source_leg_id') if prior else None,
                preceding_whole_origin_price=prior['origin']['price'] if prior else None,
                preceding_whole_terminal_price=prior['terminal']['price'] if prior else None,
                preceding_whole_direction=('up' if prior['terminal']['price']>prior['origin']['price'] else 'down') if prior else None,
                role='first_opposite_whole_wave_observation',
                admission_reason=admission_reason, classification_reason=reason,
                comparison=c,
                held_node_prices=[n['pivot']['price'] for n in nodes],
                held_progress_node_prices=[n['price'] for n in progress_nodes if n['sustained_source_close']],
                outer_origin_held=any(n['role']=='preceding_wave_origin' for n in nodes),
                close_path_efficiency=abs(sum(close_steps))/travel if travel else 0,
                internal_return_count=(len(ids)-1)//2,
                momentum_profile=momentum,
                strength_observation='whole_wave_delivery_candidate',
                semantic_force_adjudicated=False, parent_reversal_adjudicated=False,
                trade_permission=False)
            if admitted:
                candidates.append(candidate)
            if include_response_evidence and prior:
                from .first_response_evidence import first_response_record
                prior_path = structure._path(prior['origin'], prior['terminal'])
                prior_momentum = _legacy_momentum_profile(
                    prior_path, not upward,
                    abs(prior['terminal']['price'] - prior['origin']['price']))
                expanded_channel = _expanded_same_period_channel_path(
                    native, prior, not upward)
                channel_path = (dict(prior_path, bars=expanded_channel['bars'])
                                if expanded_channel else None)
                response = first_response_record(candidate, context, departure, path,
                    prior_path, prior_momentum, channel_path=channel_path)
                if response:
                    if expanded_channel:
                        response['preceding_channel_facts']['window_bars'] = len(expanded_channel['bars'])
                        response['preceding_channel_facts']['window_start_index'] = expanded_channel['start_index']
                        response['preceding_channel_facts']['window_end_index'] = expanded_channel['end_index']
                    response_observations.append(response)
            # Structural first response is observable independently of the
            # provisional momentum score. Never relabel all fast legs as
            # first reversals, and never require a later measuring C to exist.
            held = [n for n in nodes if _time(n['pivot']['pivot_timestamp_utc']) < ta]
            if prior and held and departure.get('sustained_source_close'):
                reversal_observations.append({**candidate,
                    'role':'first_opposite_structure_break_observation',
                    'status':'first_reverse_break_candidate',
                    'strength_qualified':admitted,
                    'return_completion_adjudicated':False,
                    'broken_reference_nodes':held,
                    'label':'首段反向突破 · 力度待核' if not admitted else '首段反向突破 · 力度候选'})
        return {**result, 'status':'native_whole_force_waves_reviewed',
            'native_bar_count':len(raw), 'native_ledger_leg_count':len(legs),
            'window_from_utc':native.times[0].isoformat().replace('+00:00', 'Z'),
            'window_through_utc':native.times[-1].isoformat().replace('+00:00', 'Z'),
            'force_wave_candidates':candidates, 'first_reversal_candidates':reversal_observations,
            **({'first_response_candidates':response_observations} if include_response_evidence else {}),
            'first_wave_review_counts':dict(reviews),
            'wave_decisions':decisions,
            'rejected_geometry_counts':dict(rejected), 'complete_wave_review_count':sum(reviews.values())}
    except (ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
        return {**result, 'error':str(error)}


def visible_force_waves(review, through_utc):
    """Latest KNOWABLE extension; hide only same-direction component subsets.

    A later extended envelope with low coverage does not erase a previously
    confirmed complete force wave. Both judgments stay in the causal ledger.
    An opposite first wave is never swallowed by a containing trend wave.
    """
    cutoff = _time(through_utc)
    rows = [r for r in review.get('force_wave_candidates', []) if _time(r['known_at_utc']) <= cutoff]
    groups = {}
    for row in rows:
        key = row['origin_group'], row['direction']
        if key not in groups or _time(row['terminal_utc']) > _time(groups[key]['terminal_utc']):
            groups[key] = row
    rows = list(groups.values())
    return [r for r in rows if not any(r is not other and r['direction']==other['direction'] and
        other['component_from_ordinal'] <= r['component_from_ordinal'] and
        other['component_through_ordinal'] >= r['component_through_ordinal'] and
        (other['component_from_ordinal'], other['component_through_ordinal']) !=
        (r['component_from_ordinal'], r['component_through_ordinal']) for other in rows)]
