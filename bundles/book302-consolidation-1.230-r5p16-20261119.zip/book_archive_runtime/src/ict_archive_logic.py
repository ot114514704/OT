"""Source-bound ICT observations for HistData archive windows.

The bundled ICT panel remains the source of the rules.  This adapter only
converts the archive's closed OHLC bars into that package's pure geometry
functions; it never emits an order or a production signal.
"""
from __future__ import annotations

import hashlib
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path


_PROJECT = Path(__file__).resolve().parents[1]
_ICT_PROJECT = (_PROJECT / "03_work_queue/ICT_Gold_Panel_FULL_20261017/"
                "ICT_Gold_Panel_FULL_20261017/project").resolve()


def _sources():
    if str(_ICT_PROJECT) not in sys.path:
        sys.path.insert(0, str(_ICT_PROJECT))
    from brooks_ai.types import Bar
    from ict_ai.features import geometric_fvgs
    from ict_ai.amd import amd_events
    return Bar, geometric_fvgs, amd_events


def calculate_ict_archive_logic(bars, timeframe: str, as_of_utc: str) -> dict:
    """Calculate closed-bar ICT geometry for one archive window.

    ``bars`` are live_xauusd_multitimeframe.OHLCBar objects.  The cutoff is
    deliberately passed to the package functions, so formation bars after the
    requested as-of cannot leak into the returned events.
    """
    if not bars:
        return _empty(timeframe, as_of_utc)
    from .live_xauusd_multitimeframe import TIMEFRAME_MINUTES
    minutes = TIMEFRAME_MINUTES.get(timeframe)
    if not minutes:
        raise ValueError(f"unsupported ICT timeframe: {timeframe}")
    cutoff = datetime.fromisoformat(as_of_utc.replace("Z", "+00:00"))
    if cutoff.tzinfo is None:
        raise ValueError("as_of_utc must include timezone")
    Bar, geometric_fvgs, amd_events = _sources()
    period = timedelta(minutes=minutes)
    package_bars = [Bar(b.timestamp_utc, float(b.open), float(b.high), float(b.low),
                         float(b.close), 0.1) for b in bars
                    if b.timestamp_utc + period <= cutoff]
    fvg = geometric_fvgs(package_bars, period, cutoff)
    amd = amd_events(package_bars, period, cutoff)
    # The archive package already contains the complete session/PO3 adapter.
    # Reuse it when the native display period supports the package's bounded
    # window (M5/M15/H1); its NY/DST basis is explicit and never copies MT5's
    # inferred broker offset.  Older or unsupported periods remain unknown.
    window = None
    if timeframe in {"M5", "M15", "H1"}:
        try:
            from .ict_archive_window import build_window
            start = max(package_bars[0].time, cutoff - timedelta(days=8))
            window = build_window(start.isoformat(), cutoff.isoformat(), timeframe)
        except (ValueError, KeyError, IndexError):
            window = None
    # Ensure JSON serialization is stable and expose the rule provenance.
    for row in fvg + amd:
        row["trade_signal"] = False
        row["automatic_trade_permission"] = False
        row["source_provider"] = "HistData"
        row["source_timeframe"] = timeframe
    from .ict_formation_provenance import bind_fvg_formation
    for row in fvg:
        row['formation_provenance'] = bind_fvg_formation(row, package_bars, timeframe, cutoff, 'HistData', 'XAUUSD')
    files = [_ICT_PROJECT / "ict_ai/features.py", _ICT_PROJECT / "ict_ai/amd.py"]
    hashes = {str(p.relative_to(_ICT_PROJECT)).replace("\\", "/"):
              hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    return {
        "schema": "ict_archive_logic_v1",
        "provider": "HistData",
        "timeframe": timeframe,
        "as_of_utc": cutoff.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        "bar_time_basis": "archive_export_UTC",
        "fvg": fvg,
        "amd": amd,
        "po3": ({"status": "archive_window_bound", "days": [d.get("po3", {}) for d in window.get("days", [])],
                 "clock_basis": window.get("clock")}
                if window else {"status": "not_run", "reason": "native archive window unavailable for this timeframe"}),
        "sessions": ([{"date": d.get("date"), "sessions": d.get("sessions", {})} for d in window.get("days", [])]
                     if window else []),
        "silver_bullet": ([{"date": d.get("date"), "windows": d.get("silver", [])} for d in window.get("days", [])]
                          if window else []),
        "smt": {"status": "not_run", "reason": "matched XAG archive is not bound to this packet"},
        "source_logic_files": hashes,
        "future_data_safe": True,
        "automatic_trade_permission": False,
        "order_api_called": False,
    }


def _empty(timeframe, as_of_utc):
    return {"schema": "ict_archive_logic_v1", "provider": "HistData",
            "timeframe": timeframe, "as_of_utc": as_of_utc, "fvg": [], "amd": [],
            "po3": {"status": "not_run"}, "smt": {"status": "not_run"},
            "future_data_safe": True, "automatic_trade_permission": False,
            "order_api_called": False}
