"""Prepare, but never silently apply, a Book revision rebuild proposal."""
from __future__ import annotations

from datetime import datetime


def _clock(value):
    return datetime.fromisoformat(str(value).replace("Z", "+00:00"))


def propose_book_revision_rebuild(book_candidate, unified_packet, *, timeframe, cutoff,
                                  phase_id=None):
    book = book_candidate if isinstance(book_candidate, dict) else {}
    unified = unified_packet if isinstance(unified_packet, dict) else {}
    old = list(book.get("pivot_times") or [])
    new = list(unified.get("confirmed_pivot_times") or unified.get("pivot_times") or [])
    lineage = book.get("wave_lineage_id")
    unified_lineage = unified.get("wave_lineage_id") or unified.get("canonical_wave_lineage_id")
    common = 0
    for a, b in zip(old, new):
        if a != b:
            break
        common += 1
    result = dict(
        schema="book_revision_rebuild_proposal_v1",
        timeframe=timeframe,
        cutoff_utc=cutoff,
        status="unknown",
        reason=None,
        old_book_wave_id=book.get("wave_id"),
        old_book_lineage_id=lineage,
        unified_wave_id=unified.get("canonical_wave_id") or unified.get("wave_id"),
        unified_lineage_id=unified_lineage,
        old_book_pivot_times=old,
        proposed_book_pivot_times=new,
        common_confirmed_pivot_count=common,
        old_book_known_at_utc=book.get("known_at_utc"),
        proposed_revision_known_at_utc=unified.get("known_at_utc"),
        phase_id=phase_id,
        author_wave_degree="unknown",
        author_membership_verified=False,
        score_admission=False,
        automatic_trade_permission=False,
    )
    if not old or not new:
        result.update(reason="pivot_sequence_missing")
        return result
    if lineage != unified_lineage:
        result.update(reason="different_wave_lineage")
        return result
    if common < 3:
        result.update(reason="insufficient_common_confirmed_pivots")
        return result
    try:
        if unified.get("known_at_utc") and _clock(unified["known_at_utc"]) > _clock(cutoff):
            result.update(reason="proposed_revision_known_after_cutoff")
            return result
    except (TypeError, ValueError):
        result.update(reason="revision_clock_invalid")
        return result
    if old == new:
        result.update(status="no_rebuild_needed",
                      score_admission=bool(phase_id),
                      reason=None if phase_id else "book_phase_unbound")
        return result
    result.update(status="pending_rebuild", reason="pivot_revision_mismatch",
                  next_action="recompute_book_geometry_and_phase_from_proposed_pivots",
                  requires_phase_rebind=not bool(phase_id))
    return result

