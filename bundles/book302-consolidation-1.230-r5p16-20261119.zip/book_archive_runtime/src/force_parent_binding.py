"""Bind a force to its direct, SAME-FEED native parent at explicit clocks.

Native pivot sequences are observations, not protected SNR/task ownership.
Historical formation context requires a separately captured original prefix.
"""
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path

from .force_strength_model import epoch,iso
from .mt5_structure_logic import PARENTS,parent_read
from .build_archive_window_snapshot import TIMEFRAME_MINUTES
from .force_parent_prefix_registry import lookup as prefix_lookup

ROOT=Path(__file__).resolve().parents[1]


@lru_cache(maxsize=2)
def _manifest_market(path,mtime):
    raw=Path(path).read_bytes();d=json.loads(raw);s=d.get('snapshot') or {}
    return dict(provider=s.get('provider'),instrument=s.get('instrument'),
                manifest_sha256=sha256(raw).hexdigest(),manifest=str(Path(path).relative_to(ROOT)))


def legacy_background_market(scene):
    if not scene.get('foundation_ladder_context'):return dict(status='not_present')
    # This is the actual producer manifest used by _foundation_ladder_context,
    # not an inferred market copied from the consuming HistData scene.
    from .foundation_review import DEFAULT_SHARD_MANIFEST
    try:
        p=DEFAULT_SHARD_MANIFEST
        market=_manifest_market(str(p),p.stat().st_mtime_ns)
    except (OSError,ValueError,KeyError):return dict(status='unverified_provenance')
    match=market['provider']==scene.get('provider') and market['instrument']==scene.get('instrument')
    return dict(market,status='same_market_not_automatically_bound' if match else 'different_market_not_borrowed')


def native_parent(force,scene):
    tf=force['timeframe'];parent=PARENTS.get(tf);now=scene['cutoff_utc'];cutoff=epoch(now)
    base=dict(schema='force_native_parent_prefix_v1',provider=scene.get('provider'),instrument=scene.get('instrument'),
        timeframe=tf,parent_timeframe=parent,owner_id=force.get('id'),source_id=force.get('source_id'),
        source_points=force['points'],source_known_at_utc=force['known_at_utc'],as_of_utc=now,
        known_at_utc=None,status='unknown',sequence=None,sequence_direction=None,
        source_direction_relation='unknown',witnesses=[],reference_node=None,
        native_evidence_sha256=None,latest_visible_leg=None,
        parent_task=dict(status='not_bound',owner_id=None,source_id=None,target=None),
        author_parent_reversal='not_adjudicated',automatic_trade_permission=False)
    if scene.get('timeframe')!=tf or epoch(force['known_at_utc'])>cutoff:
        return dict(base,status='force_scene_clock_or_period_mismatch')
    if not parent:return dict(base,status='top_period_no_direct_parent')
    ctx=scene.get('execution_context') or {}
    if ctx.get('parent_timeframe')!=parent:return dict(base,status='direct_parent_missing_or_mismatched')
    structure=ctx.get('parent_structure') or {}
    if structure.get('timeframe')!=parent or structure.get('as_of_utc')!=now:
        return dict(base,status='parent_structure_clock_or_period_mismatch')
    seconds=TIMEFRAME_MINUTES[parent]*60
    try:rows=[b for b in ctx.get('parent_bars',[]) if epoch(b['timestamp_utc'])+seconds<=cutoff]
    except (KeyError,ValueError,TypeError):return dict(base,status='native_parent_bar_clock_missing')
    if not rows:return dict(base,status='native_parent_bars_missing')
    for b in rows:
        if any(b.get(k)!=v for k,v in dict(provider=scene.get('provider'),symbol=scene.get('instrument'),timeframe=parent).items()):
            return dict(base,status='native_parent_market_mismatch')
    indexed={b['timestamp_utc']:b for b in rows}
    visible=[]
    for p in structure.get('points',[]):
        try:
            if epoch(p['known_at_utc'])>cutoff:continue
            b=indexed.get(p['timestamp_utc']);opened=epoch(p['timestamp_utc']);known=epoch(p['known_at_utc'])
            if not b or not opened+seconds<=known<=cutoff or p['kind'] not in ('high','low') or b[p['kind']]!=p['price']:
                return dict(base,status='parent_pivot_not_verified_in_native_bar')
            visible.append(p)
        except (KeyError,ValueError,TypeError):return dict(base,status='parent_pivot_clock_or_identity_missing')
    clean=dict(scene,execution_context=dict(ctx,parent_structure=dict(structure,points=visible),
        parent_bars=list(indexed.values())))
    observed=parent_read(clean)
    if observed.get('direction') not in (-1,0,1):
        return dict(base,status='insufficient_confirmed_parent_sequence')
    direction=observed['direction'];sign=1 if force['points'][1][1]>force['points'][0][1] else -1
    witnesses=observed['highs']+observed['lows']
    legs=[]
    for leg in structure.get('legs',[]):
        try:
            if epoch(leg['known_at_utc'])>cutoff or leg.get('geometry_unresolved') or leg.get('native_bar_envelope_status')!='verified':continue
            if not all(p in visible for p in (leg['origin'],leg['terminal'])):continue
            legs.append(leg)
        except (KeyError,ValueError,TypeError):continue
    latest=max(legs,key=lambda r:epoch(r['terminal']['timestamp_utc']),default=None)
    digest=sha256(json.dumps(dict(provider=scene.get('provider'),instrument=scene.get('instrument'),parent=parent,
        as_of_utc=now,bars=rows,points=visible),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    return dict(base,status='verified_same_feed_sequence_not_parent_task',sequence=observed['state'],
        sequence_direction='up' if direction==1 else 'down' if direction==-1 else 'mixed',
        source_direction_relation=('same_direction' if direction==sign else 'opposite_direction' if direction else 'mixed'),
        known_at_utc=observed.get('known_at_utc'),witnesses=witnesses,
        native_evidence_sha256=digest,
        latest_visible_leg=({k:latest[k] for k in ('id','timeframe','origin','terminal','direction','known_at_utc')} if latest else None),
        reference_node=observed.get('reference_node'),boundary_break_close=observed.get('first_break_close'),
        boundary_scope='sequence_reference_not_author_protected_SNR')


def bind_parent(force,scene,formation=None,legacy_market=None):
    review=native_parent(force,scene)
    registry=dict(status='not_consulted',record_id=None,registry_sha256=None)
    origin='explicit_input' if formation else 'unknown'
    if formation is None and epoch(scene['cutoff_utc'])>epoch(force['known_at_utc']):
        registered=prefix_lookup(force,scene)
        registry={k:registered[k] for k in ('status','record_id','registry_sha256')}
        if registered['status']=='matched':formation=registered['context'];origin='verified_registry'
    missing=dict(status='original_prefix_not_supplied',as_of_utc=force['known_at_utc'],
                 timeframe=force['timeframe'],parent_timeframe=PARENTS.get(force['timeframe']),
                 provider=scene.get('provider'),instrument=scene.get('instrument'),
                 owner_id=force.get('id'),source_id=force.get('source_id'),known_at_utc=None)
    if epoch(scene['cutoff_utc'])==epoch(force['known_at_utc']):
        birth=review;origin='current_original_prefix'
    elif formation:
        expected={k:review[k] for k in ('provider','instrument','timeframe','parent_timeframe','owner_id','source_id',
                                      'source_points','source_known_at_utc')}
        if (not isinstance(formation,dict) or any(formation.get(k)!=v for k,v in expected.items()) or
            formation.get('schema')!='force_native_parent_prefix_v1' or
            formation.get('as_of_utc')!=force['known_at_utc'] or
            (formation.get('known_at_utc') and epoch(formation['known_at_utc'])>epoch(force['known_at_utc']))):
            birth=dict(missing,status='foreign_or_future_formation_prefix_rejected')
            origin='rejected_input'
        else:birth=formation
    else:birth=missing
    parent=PARENTS.get(force['timeframe']);direction=review.get('sequence_direction')
    label=({'up':'上行序列','down':'下行序列','mixed':'混合'}[direction] if direction else '未知')
    birth_label={'up':'上行','down':'下行','mixed':'混合'}.get(birth.get('sequence_direction'),'未知')
    if review.get('sequence')=='sequence_boundary_broken':label+='·边界受挑战'
    relation={'same_direction':'同序','opposite_direction':'逆序'}.get(review.get('source_direction_relation'),'')
    return dict(schema='force_parent_binding_v1',owner_id=force.get('id'),source_id=force.get('source_id'),
        timeframe=force['timeframe'],provider=scene.get('provider'),instrument=scene.get('instrument'),
        as_of_utc=scene['cutoff_utc'],source_known_at_utc=force['known_at_utc'],
        direct_parent_timeframe=parent,formation_parent=birth,review_parent=review,
        formation_origin=origin,formation_registry=registry,
        legacy_background_market=legacy_market if legacy_market is not None else legacy_background_market(scene),
        caption=f"{force['timeframe']}→{parent or '无父'} 形成{birth_label}/复盘{scene['cutoff_utc'][5:16].replace('T',' ')} {label}"+(f"·{relation}" if relation else ''),
        parent_task_status='not_bound',automatic_trade_permission=False)
