"""Persistent, native-source entry observation, independent of chart selection.

PDF103/104/108/109 allow either boundary first and retain original B until
failure. Chart ranking alone neither cancels that source nor establishes a
new author wave. Observe every source that the real builder actually showed;
do not add unseen historical inventory as if it had been watched live.
"""
from copy import deepcopy
from .book_first_response_leg import clock,close_time,first_response_leg
from .book_boundary_freeze import ruler_identity,validate_boundary_freeze
from .book_breakout_assessment import assess_breakouts,digest,native_turning_source_proof
from .book_realtime_decision import observe_entry


LINE_FIELDS=('qualified','direction','start_index','start_price','end_index','end_price','slope',
    'wave_id','known_at_utc','wave_membership_state','phase_id','previous_phase_id',
    'parent_scope_id','root_phase_id','phase_relation','owned_scope','successor_admission')
TURN_FIELDS=('qualified','method','direction','start_index','start_price','slope','first_observable_index',
    'extension_start_index','extension_end_index','extension_start_price','extension_end_price',
    'parent_wave_id','known_at_utc','intelligence','established_wave_end_index','shift_anchor_index','construction_audit',
    'parent_wave_start_index','owned_scope_binding')


def pack_native(rows,fact,fields):
    data={k:deepcopy(fact[k]) for k in fields if k in fact}
    if 'successor_admission' in data:
        def native_only(value):
            if isinstance(value,dict):
                return {k:native_only(v) for k,v in value.items() if k not in ('index','first_recovery_index')}
            if isinstance(value,list):return [native_only(v) for v in value]
            return value
        data['successor_admission']=native_only(data['successor_admission'])
    indices={}
    for k in list(data):
        if k.endswith('_index'):
            i=data.pop(k)
            if isinstance(i,bool) or not isinstance(i,int) or not 0<=i<len(rows):
                raise ValueError('native construction index unavailable')
            indices[k]=rows[i]['timestamp_utc']
    return dict(facts=data,native_index_utc=indices,
        index_spans={k:fact[k]-fact['start_index'] for k in indices if 'start_index' in fact})


def restore_native(rows,packed):
    indices={r['timestamp_utc']:i for i,r in enumerate(rows)}
    fact=deepcopy(packed['facts'])
    fact.update({k:indices[t] for k,t in packed['native_index_utc'].items()})
    if any(fact[k]-fact['start_index']!=span for k,span in packed['index_spans'].items()):
        raise ValueError('native construction span changed')
    return fact


def turning_key(rows,phase,turn):
    native=lambda k:[rows[turn[k+'_index']]['timestamp_utc'],turn[k+'_price']]
    return phase+':turning:'+digest([native('extension_start'),native('extension_end'),native('start')])


def capture_selected_source(rows,timeframe,cutoff,observed,book,registry,snapshot):
    line=book.get('turning_point_line') or {}
    source_identity=ruler_identity(rows,line,timeframe)
    if (not line.get('qualified') or line.get('direction') not in ('up','down')
            or not source_identity or not line.get('wave_id')):return None
    market={k:rows[-1].get(k) for k in ('provider','symbol')}
    identity=dict(ruler=source_identity,**market);phase='book_break_phase:'+digest(identity)
    # Qualification is supplied by the builder. Native endpoint validation
    # prevents a custom/cached selected source silently changing its prices.
    field='high' if line['direction']=='down' else 'low'
    if any(float(rows[line[k+'_index']][field])!=float(line[k+'_price']) for k in ('start','end')):
        return None
    known=max((line.get('known_at_utc') or observed,observed),key=clock)
    if clock(known)>clock(observed):return None
    if phase not in registry:
        packed=pack_native(rows,dict(line,known_at_utc=known),LINE_FIELDS)
        registry[phase]=dict(schema='book_entry_source_watch_v1',phase_id=phase,source_identity=identity,
            first_observed_at_utc=observed,first_snapshot_id=snapshot,line=packed,turnings={},
            selected_observations=0,terminal_pairs={},known_events={},known_scores={},known_terminals={},
            unknown_turning_state=dict(frozen_A=None))
        context=source_identity.get('scope_context')
        if context is not None:
            registry[phase]['scope_context']=deepcopy(context)
            geometry={k:v for k,v in source_identity.items() if k!='scope_context'}
            registry[phase]['geometry_id']='book_geometry:'+digest(dict(ruler=geometry,**market))
            registry[phase]['scope_context_id']='book_scope_context:'+digest(context)
            registry[phase]['scope_use']=('geometry_review_only' if context['membership_state']=='declared_geometry_range_not_author_degree'
                else 'native_event_phase_observation_not_author_degree')
        if line.get('successor_admission') and registry[phase].get('scope_use')!='geometry_review_only':
            # Store native identities, not mutable viewport-relative indices.
            def native_receipt(value):
                if isinstance(value,dict):return {k:native_receipt(v) for k,v in value.items() if k not in ('index','first_recovery_index')}
                if isinstance(value,list):return [native_receipt(v) for v in value]
                return deepcopy(value)
            registry[phase]['native_successor_admission']=native_receipt(line['successor_admission'])
            predecessor=line['successor_admission'].get('predecessor_ruler_identity')
            registry[phase]['predecessor_source_phase_id']=next((pid for pid,record in registry.items()
                if pid!=phase and record['source_identity']==dict(ruler=predecessor,**market)),None)
    record=registry[phase]
    record.update(last_selected_at_utc=observed,last_selected_snapshot_id=snapshot,
        selected_observations=record['selected_observations']+1)
    change=deepcopy(book.get('trend_change') or {})
    if (not any((book.get(k) or {}).get('status')=='observed_candidate' for k in ('first_closed_break','parallel_break'))
            and change.get('boundary_a_utc') and change.get('boundary_ruler_identity')==source_identity
            and change.get('boundary_source_wave_id')==line['wave_id']):
        change.pop('boundary_a_index',None)
        record['prebreak_A_proposal']=dict(change=change,observed_at_utc=observed,prefix_snapshot_id=snapshot)
    capture_turning(rows,observed,record,book.get('turning_boundary') or {},snapshot)
    return phase


def capture_turning(rows,observed,record,turn,snapshot):
    def rejected(reason,proof=None):
        # Preserve the observed failed construction, without admitting it as
        # a ruler or borrowing the prior pair's clock. Otherwise the live
        # watchlist erases the selector's reason and reports only "unknown".
        record.setdefault('unknown_turning_state',dict(frozen_A=None))['diagnostic']=dict(
            qualified=False,status='unknown',reason=reason,known_at_utc=observed,
            diagnostic_observed_at_utc=observed,diagnostic_prefix_snapshot_id=snapshot,
            diagnostic_phase_id=record['phase_id'],rule_id=turn.get('rule_id'),
            source_rule_pages=deepcopy(turn.get('source_rule_pages') or []),
            construction_audit=deepcopy(turn.get('construction_audit') or {}),
            native_construction_validation=deepcopy(proof or {}),
            automatic_trade_permission=False,diagnostic_only=True)
        return None
    if not (turn.get('qualified') and turn.get('method')=='opposite_extension_shift'
            and turn.get('parent_wave_id')==record['line']['facts'].get('wave_id')):
        reason=(turn.get('reason') or turn.get('unknown_reason') or 'turning_source_absent') if not turn.get('qualified') else (
            'turning_method_not_supported' if turn.get('method')!='opposite_extension_shift' else 'turning_not_bound_to_outer_wave')
        return rejected(reason)
    try:
        if clock(turn.get('known_at_utc') or observed)>clock(observed):return rejected('turning_source_not_yet_known')
        proof=native_turning_source_proof(rows,restore_native(rows,record['line']),turn)
        if not proof['qualified']:return rejected('turning_native_construction_invalid',proof)
        key=turning_key(rows,record['phase_id'],turn)
        if key not in record['turnings']:
            # New geometry is a distinct construction. Keep all prior ones;
            # never transfer their first-observation clocks to this one.
            source=pack_native(rows,dict(turn,known_at_utc=observed),TURN_FIELDS)
            record['turnings'][key]=dict(source=source,first_observed_at_utc=observed,
                first_snapshot_id=snapshot,frozen_A=None)
        return key
    except (KeyError,IndexError,ValueError,TypeError):return rejected('turning_native_source_incomplete')


def frozen_change(rows,timeframe,cutoff,line,outer,second,selected,pair):
    from .trend_trade_method_full_pipeline import classify_trend_change
    from .trend_trade_method_patterns import detect_wave_adjustment
    events=[e for e in (outer,second) if e.get('status')=='observed_candidate']
    if not events:return {}
    first=min(e['break_index'] for e in events)
    if pair.get('frozen_A') is None:
        change=deepcopy(selected or {})
        if validate_boundary_freeze(rows,timeframe,cutoff,line,change,first)['status']!='frozen_before_first_boundary':
            boundary_cutoff=rows[first]['timestamp_utc']
            adjustment=detect_wave_adjustment(rows,timeframe,boundary_cutoff,line['direction'])
            change=classify_trend_change(rows,line,outer,timeframe,cutoff,second,adjustment)
        if 'boundary_a_index' in change:
            change['boundary_a_native_utc']=rows[change.pop('boundary_a_index')]['timestamp_utc']
        # Freeze absence too. Later pivots may never repair this phase's A.
        pair['frozen_A']=dict(change=change,first_boundary_utc=rows[first]['timestamp_utc'])
    frozen=pair['frozen_A'];change=deepcopy(frozen['change'])
    if frozen['first_boundary_utc']!=rows[first]['timestamp_utc']:
        return dict(reason='first_boundary_changed_after_A_freeze')
    if change.get('boundary_a_native_utc'):
        change['boundary_a_index']=next(i for i,r in enumerate(rows) if r['timestamp_utc']==change['boundary_a_native_utc'])
    return change


def observe_sources(rows,timeframe,cutoff,observed,selected_book,registry,snapshot,policy,context_factors,
                    *,native_one_to_one_scene=None,one_to_one_observations=None):
    """Return independent decisions; use current selected source only as input."""
    from .trend_trade_method_full_pipeline import detect_first_closed_break,detect_parallel_break
    from .trend_trade_method_patterns import build_stop_reference
    from .pdf_trendline_block import select_pdf_turning_boundary
    from .book_setup_state import setup_state
    selected_phase=capture_selected_source(rows,timeframe,cutoff,observed,selected_book,registry,snapshot)
    results=[]
    for phase,record in registry.items():
        base=dict(phase_id=phase,source_identity=record['source_identity'],
            current_selected=phase==selected_phase,first_observed_at_utc=record['first_observed_at_utc'])
        if record.get('scope_context') is not None:
            base.update(scope_context=deepcopy(record['scope_context']),scope_use=record['scope_use'],
                        geometry_id=record['geometry_id'],scope_context_id=record['scope_context_id'])
        try:
            line=restore_native(rows,record['line'])
            if ruler_identity(rows,line,timeframe)!=record['source_identity']['ruler']:
                raise ValueError('source ruler identity changed')
            outer=detect_first_closed_break(rows,line,timeframe,cutoff)
            # CDE may first become constructible after this ruler ceased to
            # rank first. Reuse the original builder's actual selector on the
            # same frozen native wave, cut BEFORE its first outer break.
            if phase!=selected_phase:
                formation=dict(line,first_break_index=outer.get('break_index'))
                turn=select_pdf_turning_boundary(rows,formation)
                turn['parent_wave_id']=line['wave_id']
                capture_turning(rows,observed,record,turn,snapshot)
            pairs=list(record['turnings'].items()) or [(phase+':turning_unknown',record['unknown_turning_state'])]
            for key,pair in pairs:
                if key in record['terminal_pairs']:
                    terminal=deepcopy(record['terminal_pairs'][key]);terminal.update(base)
                    terminal['decision']['as_of_utc']=cutoff
                    results.append(terminal);continue
                turn=restore_native(rows,pair['source']) if pair.get('source') else deepcopy(pair.get('diagnostic') or {})
                second=detect_parallel_break(rows,line,{'projection':turn},timeframe,cutoff)
                outer_owned=deepcopy(outer)
                for name,event in (('outer',outer_owned),('turning',second)):
                    if event.get('status')=='observed_candidate':
                        ekey=(phase if name=='outer' else key)+':'+event['break_utc']
                        known=record['known_events'].setdefault(ekey,observed)
                        event['known_at_utc']=max((event['known_at_utc'],known),key=clock)
                scores=assess_breakouts(rows,timeframe,cutoff,line,turn,outer_owned,second)
                for name,score in scores.get('boundaries',{}).items():
                    if score.get('status')=='scored':
                        skey=(phase if name=='outer' else key)+':'+score['break_utc']
                        known=record['known_scores'].setdefault(skey,observed)
                        score['known_at_utc']=max((score['known_at_utc'],known),key=clock)
                response=first_response_leg(rows,line,outer_owned,timeframe,cutoff)
                if response.get('source_complete'):
                    terminal_key=response['source_id']+':'+digest(response['terminal_C']['point'])
                    known=record['known_terminals'].setdefault(terminal_key,observed)
                    response['known_at_utc']=max((response['known_at_utc'],known),key=clock)
                    response['terminal_C']['known_at_utc']=response['known_at_utc']
                stop=build_stop_reference(rows,timeframe,cutoff,{},line,outer_owned)
                selected_change=selected_book.get('trend_change') if phase==selected_phase else None
                proposal=record.get('prebreak_A_proposal')
                events=[e for e in (outer_owned,second) if e.get('status')=='observed_candidate']
                if proposal and events:
                    first=min(e['break_index'] for e in events)
                    if clock(proposal['observed_at_utc'])<=clock(rows[first]['timestamp_utc']):
                        selected_change=deepcopy(proposal['change'])
                        selected_change['boundary_a_index']=next(i for i,r in enumerate(rows)
                            if r['timestamp_utc']==selected_change['boundary_a_utc'])
                frozen_unknown=record['unknown_turning_state'].get('frozen_A')
                if pair.get('frozen_A') is None and frozen_unknown and outer_owned.get('status')=='observed_candidate':
                    events=[e for e in (outer_owned,second) if e.get('status')=='observed_candidate']
                    first=min(e['break_utc'] for e in events)
                    if first==frozen_unknown['first_boundary_utc']:
                        pair['frozen_A']=deepcopy(frozen_unknown)
                change=frozen_change(rows,timeframe,cutoff,line,outer_owned,second,selected_change,pair)
                from .book_first_response_leg import backtrack_first_wave
                response['prior_B_A_backtrack']=backtrack_first_wave(
                    rows,timeframe,cutoff,response,change,outer_owned,second)
                setup=setup_state(rows,timeframe,cutoff,line,outer_owned,second,stop,change)
                book=dict(timeframe=timeframe,as_of_utc=cutoff,turning_point_line=line,turning_boundary=turn,
                    first_closed_break=outer_owned,parallel_break=second,first_response_leg=response,
                    stop_reference=stop,trend_change=change,setup_qualification=setup,
                    boundary_breakout_assessment=scores,execution_context_factors=deepcopy(context_factors or {}))
                if native_one_to_one_scene is not None and 'one_to_one_second_leg' not in (context_factors or {}):
                    from .one_to_one_native_observation import bind_native_book_context
                    from .book_one_to_one_observation import observe_context
                    bridge=bind_native_book_context(native_one_to_one_scene,book)
                    book['one_to_one_book_context']=bridge
                    if isinstance(bridge.get('execution_context_factor'),dict):
                        fact=observe_context(bridge['execution_context_factor'],
                            one_to_one_observations if one_to_one_observations is not None else {},cutoff,observed,snapshot)
                        book['execution_context_factors']['one_to_one_second_leg']=fact
                    book['one_to_one_native_observation']=deepcopy(selected_book.get('one_to_one_native_observation') or {})
                decision=observe_entry(rows,timeframe,cutoff,book,policy)
                book['author_review_context']=deepcopy(decision['author_review_context'])
                result=dict(base,pair_key=key,status='observing',decision=decision,book_logic=book)
                if decision['status'] in ('invalidated','completed','expired','ambiguous'):
                    result.update(status='retired',retired_at_utc=observed)
                    record['terminal_pairs'][key]=deepcopy(result)
                results.append(result)
        except (KeyError,ValueError,IndexError,TypeError,StopIteration) as exc:
            results.append(dict(base,status='source_history_unavailable',reason=str(exc),decision=dict(
                status='wait_source_history',paper_candidate=False,phase_id=phase,as_of_utc=cutoff,signal=None)))
    return dict(schema='book_entry_watchlist_v1',as_of_utc=cutoff,observed_at_utc=observed,
        selected_phase_id=selected_phase,source_count=len(registry),observations=results,
        automatic_trade_permission=False,order_api_called=False)


def select_entry_decision(watchlist,selected_decision):
    candidates=[r['decision'] for r in watchlist['observations'] if r['decision'].get('paper_candidate')]
    cycles={}
    for decision in candidates:
        signal=decision['signal'];signature=(signal['id'],signal['direction'],signal['stop'],signal['target'],signal['known_at_utc'])
        cycles.setdefault((signal['entry_cycle_id'],signature),[]).append(decision)
    if len(cycles)==1:
        equivalent=next(iter(cycles.values()))
        result=deepcopy(min(equivalent,key=lambda d:d.get('boundary_pair_id') or ''))
        result['source_selection']=dict(basis='unique_owned_entry_cycle',equivalent_boundary_pairs=len(equivalent),
            current_selected_phase_id=watchlist['selected_phase_id'])
        return result
    if not cycles:
        owned=[r['decision'] for r in watchlist['observations'] if r.get('current_selected')]
        if owned:
            matched=[d for d in owned if d.get('boundary_pair_id')==selected_decision.get('boundary_pair_id')]
            return deepcopy((matched or owned)[-1])
        if len(watchlist['observations'])==1:
            return deepcopy(watchlist['observations'][0]['decision'])
        if selected_decision.get('paper_candidate'):
            return dict(selected_decision,status='wait_source_provenance',paper_candidate=False,signal=None,
                reason='selected_source_not_registered_with_native_history')
        return selected_decision
    return dict(schema='book_realtime_entry_v1',as_of_utc=watchlist['as_of_utc'],status='wait_source_conflict',
        reason='multiple_owned_entry_cycles_require_explicit_adjudication',paper_candidate=False,signal=None,
        candidate_cycle_ids=sorted({d['signal']['entry_cycle_id'] for d in candidates}),
        automatic_trade_permission=False,live_order_permission=False,order_api_called=False)
