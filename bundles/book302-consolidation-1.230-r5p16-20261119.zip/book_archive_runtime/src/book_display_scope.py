"""Book presentation boundary; Machine1 ruler calculations remain independent."""
from hashlib import sha256
import json
import re

MACHINE1_LAYERS=frozenset({'one_to_one','three_push'})

def separate_nonforce_ruler(source):
    """Correct an explicitly identified outer ruler, never guess from colour.

    Retain its geometry and source observations. Old misattached force
    profiles remain audit evidence but may not be consumed as a force grade.
    """
    e=source.get('evidence') or {}
    status=(e.get('realtime_display') or {}).get('source_status',source.get('status'))
    if (source.get('layer')!='force' or source.get('kind')!='line'
            or status!='channel_observation' or e.get('display_role')!='single_outer_trendline'
            or e.get('channel_component') not in ('upper','lower')):return source
    evidence=dict(e);removed={}
    obj=dict(source,evidence=evidence,layer='trend')
    for field in ('strength_profile','wave_strength_profile'):
        if field in obj:removed[field]=obj.pop(field)
        if field in evidence:removed['evidence.'+field]=evidence.pop(field)
    evidence['Book_nonforce_display_repair']=dict(from_layer='force',to_layer='trend',
        reason='explicit_preceding_wave_outer_ruler_not_force_leg',original_label=source.get('label'),
        removed_misattached_profiles=removed,geometry_changed=False,force_admission=False)
    obj['label']='趋势外沿 · 几何参考，非力度段'
    return obj

def book_plan_lines(lines):
    """Hide Machine1 display counters/commentary, retain the research data."""
    result=[]
    for line in lines:
        value=re.sub(r'\s*(?:三推|1:1)\d+(?=\s|$)', '', line)
        parts=[s for s in value.split(' · ') if not any(k in s for k in ('三推','1:1','1：1'))]
        result.append(' · '.join(parts))
    return result


def book_object_caption(source):
    """Keep Machine1-only commentary out of Book's object captions too."""
    original=source.get('label')
    if not isinstance(original,str):return source
    parts=original.split('|')
    kept=[p.strip() for p in parts if not any(k in p for k in ('1:1','1：1','三推'))]
    if len(kept)==len(parts):return source
    evidence=dict(source.get('evidence') or {})
    evidence['Book_caption_filter']=dict(original_label=original,
        reason='Machine1_ruler_or_three_push_commentary_excluded',geometry_or_score_changed=False)
    return dict(source,label=' | '.join(kept),evidence=evidence)

def book_display_scene(source):
    """Detached top-level projection; never alter shared or immutable evidence."""
    objects=[book_object_caption(separate_nonforce_ruler(o)) for o in source['objects'] if o.get('layer') not in MACHINE1_LAYERS]
    result=dict(source,objects=objects)
    ids={o['id'] for o in objects}
    if 'active_object_ids' in source:
        result['active_object_ids']=[oid for oid in source['active_object_ids'] if oid in ids]
    if source.get('book_logic',{}).get('display_plan'):
        book=source['book_logic'];plan=book['display_plan']
        result['book_logic']=dict(book,display_plan=dict(plan,lines=book_plan_lines(plan.get('lines',[]))))
    result['book_presentation_scope']=dict(schema='book_luxiwu_display_v1',
        source_scene_id=source.get('scene_id'),excluded_layers=sorted(MACHINE1_LAYERS),
        source_objects=len(source['objects']),display_objects=len(objects),
        calculation_changed=False,read_only=True)
    body={k:v for k,v in result.items() if k!='scene_id'}
    result['scene_id']=sha256(json.dumps(body,sort_keys=True,separators=(',',':'),
        ensure_ascii=False,allow_nan=False).encode('utf-8')).hexdigest()
    return result
