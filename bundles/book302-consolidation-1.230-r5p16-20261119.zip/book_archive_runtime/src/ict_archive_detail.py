"""Full original ICT analysis and renderer, applied to bounded archive dates.

Price inputs are HistData UTC. Original broker quotes, journal, SMT and calendars
are never copied onto a different historical price series.
"""
from copy import deepcopy
from datetime import date, datetime, timedelta, timezone
from functools import lru_cache
from html.parser import HTMLParser
from pathlib import Path
import json

from src.ict_archive_window import PACKAGE, periods as archive_periods, read_bars
from scripts import prepare_ict_week as native

PROJECT = PACKAGE / 'project'


class EmbeddedPayload(HTMLParser):
    def __init__(self):
        super().__init__()
        self.frames, self.payloads, self.current = [], [], None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'iframe':
            self.frames.extend(attrs[k] for k in ('srcdoc', 'data-srcdoc') if k in attrs)
        if tag == 'script' and 'data-payload' in attrs:
            self.current = ''

    def handle_data(self, data):
        if self.current is not None:
            self.current += data

    def handle_endtag(self, tag):
        if tag == 'script' and self.current is not None:
            self.payloads.append(json.loads(self.current))
            self.current = None


@lru_cache(maxsize=1)
def source_metadata():
    pending = [(PROJECT / 'output/chart-preview/index.html').read_text(encoding='utf-8')]
    while pending:
        parsed = EmbeddedPayload()
        parsed.feed(pending.pop())
        if parsed.payloads:
            original = parsed.payloads[0]
            keys = ('profile_catalog', 'price_video_basis', 'po3_gate_policy',
                    'ict_liquidity_amd_basis', 'po3_basis', 'weekly_additional_source',
                    'silver_source', 'weekly_path_basis', 'liquidity_basis',
                    'source_slides_path', 'classification_basis')
            return {k: original[k] for k in keys if k in original}
        pending.extend(parsed.frames)
    raise ValueError('Original ICT source metadata is missing')


def archive_bounds():
    p = archive_periods()['M5']
    return (datetime.fromtimestamp(p['start'], timezone.utc).astimezone(native.NY).date(),
            datetime.fromtimestamp(p['end'] + 300, timezone.utc).astimezone(native.NY).date())


@lru_cache(maxsize=18)
def chart_page(scope, day_iso, direction=0):
    """Independent bounded pages; every page uses its own historical cutoff.

    Month pages overlap by a month. Week/day pages retain their original ICT
    semantics rather than relabelling a giant collection as one session.
    """
    if scope not in ('month', 'week', 'day') or direction not in (-1, 0, 1):
        raise ValueError('Invalid chart navigation')
    first, last = archive_bounds()
    target = date.fromisoformat(day_iso)
    if direction and scope == 'month':
        if direction < 0:
            target = target.replace(day=1) - timedelta(days=1)
        else:
            target = (target.replace(day=28) + timedelta(days=4)).replace(day=1)
            target = (target.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)
    elif direction:
        target += timedelta(days=direction * (7 if scope == 'week' else 1))
    target = min(last, max(first, target))
    # A weekend has no daily record. Navigate in the requested direction,
    # falling back inside the archive at the two physical boundaries.
    step = 1 if direction > 0 or target == first else -1
    for _ in range(15):
        if target.weekday() < 5:
            payload = detail_payload(str(target))
            scenario = payload['scenarios'][0]
            day = next((d for d in scenario['days'] if d['date'] == str(target)
                        and d['charts']['5']['bars']), None)
            if day:
                record = (scenario['month'] if scope == 'month' else
                          scenario['weeks'][1] if scope == 'week' else day)
                return dict(scope=scope, date=str(target), record=record,
                            context_day=day if scope == 'month' else None,
                            week_group=payload['week_groups'][1] if scope == 'week' else None,
                            as_of=payload['snapshot_read_at'], earliest=str(first), latest=str(last))
        candidate = target + timedelta(days=step)
        if not first <= candidate <= last:
            step *= -1
            candidate = target + timedelta(days=step)
        target = candidate
    raise ValueError('此区间缺少可用历史报价；上一张图已保留')


@lru_cache(maxsize=6)
def detail_payload(day_iso):
    today = date.fromisoformat(day_iso)
    earliest, latest = archive_bounds()
    if not earliest <= today <= latest:
        raise ValueError(f'历史日期范围：{earliest}—{latest}')
    as_of = min(datetime.combine(today + timedelta(days=1), datetime.min.time(), native.NY).astimezone(timezone.utc),
                datetime.fromtimestamp(archive_periods()['M5']['end'] + 300, timezone.utc))
    prior_month_start = (today.replace(day=1) - timedelta(days=1)).replace(day=1)
    history_floor = datetime.combine(prior_month_start, datetime.min.time(), native.NY).astimezone(timezone.utc)
    m5 = read_bars('M5', history_floor, as_of)
    periods = {n: native.aggregate_bars(m5, 5, n, as_of) for n in (5, 15, 60)}
    week = native.previous_week(today)
    current = [d + timedelta(days=7) for d in week]
    all_days = week + current
    days, weeks = assemble_records(periods, all_days, week, current, as_of)
    if not days:
        raise ValueError('此日期附近没有完整历史K线，请选择下一个交易日')
    amd = native.amd_events(periods[15], timedelta(minutes=15), as_of)
    payload = deepcopy(source_metadata())
    payload.update(symbol='XAUUSD', broker='HistData', provider='HistData', synthetic=False,
        source_period_minutes=5, display_period_minutes=[5, 15, 60], analysis_period_minutes=15,
        snapshot_read_at=as_of.isoformat(), history_used_from_ny=prior_month_start.isoformat(),
        clock_verified=False, historical_clock_alignment='archive UTC; America/New_York DST mapping',
        current_clock_measured_offset_hours=0, orders_sent=0, execution_allowed=False,
        aggregation='M15 and H1 from complete contiguous archive M5; no interpolation',
        week=[str(d) for d in all_days],
        week_groups=[{'label': f'{dates[0]}—{dates[-1]}', 'days': [str(d) for d in dates]} for dates in (week, current)],
        scenarios=[dict(id='archive-utc', label='HistData UTC → 纽约时间（自动夏令时）', offset_hours=0,
                        verified=False, days=days, weeks=weeks,
                        month=native.month_overview(periods, today, as_of, {}, amd))],
        initial_view={'week': '1', 'day': days[-1]['date']}, calendar_today_ny=str(today),
        calendar={'status': 'unavailable', 'events': [], 'reason': '该历史日期没有绑定已核实新闻日历'},
        unavailable={'smt': 'HistData黄金历史未绑定同源白银，保留SMT入口但不伪造背离',
                     'calendar': '没有该历史日期的已核实新闻数据'},
        archive={'selected_date': str(today), 'earliest': str(earliest), 'latest': str(latest),
                 'm5_total': archive_periods()['M5']['rows'], 'boundary': 'only closed prices through selected NY date'})
    return payload


def detail_fragment(day_iso):
    payload = detail_payload(day_iso)
    text = (PROJECT / 'scripts/ict_week_fragment.html').read_text(encoding='utf-8')
    text = text.replace('TMGM / XAUUSD', 'HistData / XAUUSD')
    text = text.replace('离线快照 · 持续更新请查看右侧本地页面', '历史复盘 · 截止所选纽约日期 · SMT与新闻缺失项单独标注')
    text = text.replace('左右拖动 · 滚轮 / 双指缩放', '左右拖动 · 滚轮小步缩放 · Shift＋滚轮左右移动')
    text = text.replace('d3.zoom().scaleExtent', 'd3.zoom().wheelDelta(event=>-Math.sign(event.deltaY)*0.035).scaleExtent')
    text = text.replace(".filter(event=>event.type==='wheel'||event.type==='dblclick')", ".filter(event=>!event.shiftKey&&(event.type==='wheel'||event.type==='dblclick'))")
    text = text.replace('window.addEventListener(', 'onWindow(')
    text = text.replace("const root=document.getElementById('ict-week-review');", """const life=new AbortController();
function onWindow(name,handler){window.addEventListener(name,handler,{signal:life.signal});}
let resizeObserver;
window.addEventListener('ict:dispose',()=>{life.abort();resizeObserver?.disconnect();},{once:true});
const root=document.getElementById('ict-week-review');""")
    text = text.replace('new ResizeObserver(()=>', '(resizeObserver=new ResizeObserver(()=>')
    text = text.replace('}}).observe(plot);draw();', '}})).observe(plot);draw();')
    # Native zoom uses each chart's own D3 transform; Shift-wheel never changes k.
    text = text.replace('function installVerticalNavigation(svg,hit,axisY,y,key,left,top,bottom,direct=false,onPanX=null){',
        "function installVerticalNavigation(svg,hit,zoom,axisY,y,key,left,top,bottom,direct=false,onPanX=null){\n"
        " hit.on('wheel.archive-pan',event=>{if(!event.shiftKey)return;event.preventDefault();event.stopImmediatePropagation();"
        "const t=d3.zoomTransform(hit.node());zoom.translateBy(hit,Math.sign(event.deltaY||event.deltaX)*60/Math.max(1,t.k),0);},{passive:false});")
    text = text.replace('installVerticalNavigation(svg,hit,null,', 'installVerticalNavigation(svg,hit,zoom,null,')
    text = text.replace('installVerticalNavigation(svg,hit,axisY,', 'installVerticalNavigation(svg,hit,zoom,axisY,')
    # Keep the original detailed renderer. Only its data source and navigation
    # are extended; no price-only substitute or reduction of ICT annotations.
    text = text.replace("const selected=()=>scenario().days.find(d=>d.date===daySelect.value);",
                        "const selected=()=>archiveDay||scenario().days.find(d=>d.date===daySelect.value);")
    text = text.replace("const week=scenario().weeks[Number(weekSelect.value)],day=selected();",
                        "const week=archiveWeek||scenario().weeks[Number(weekSelect.value)],day=selected();")
    text = text.replace("data.week_groups[Number(weekSelect.value)].label+' · '",
                        "(archiveWeekGroup||data.week_groups[Number(weekSelect.value)]).label+' · '")
    text = text.replace("daySelect.value+' · '+(day?", "(day?.date||daySelect.value)+' · '+(day?")
    text = text.replace("daySelect.value=item.date;draw();persist();", "loadArchivePage('day',item.date);persist();")
    text = text.replace("daySelect.addEventListener('change',()=>{draw();persist();});",
                        "daySelect.addEventListener('change',()=>{loadArchivePage('day',daySelect.value);persist();});")
    text = text.replace("weekSelect.addEventListener('change',()=>{populateDays();draw();persist();});",
                        "weekSelect.addEventListener('change',()=>{loadArchivePage('week',data.week_groups[Number(weekSelect.value)].days.at(-1));persist();});")
    text = text.replace("liveHere?data.live.read_at:data.snapshot_read_at", "liveHere?data.live.read_at:(record._archive_asof||data.snapshot_read_at)")
    text = text.replace("const key=clockSelect.value+':'+(weekly?'week-'+weekSelect.value:daySelect.value);",
                        "const key=clockSelect.value+':'+(weekly?'week-'+record.days[0]:record.date);")
    text = text.replace("const day=selected(),dayBars=", "const day=archiveMonthDay||selected(),dayBars=")
    text = text.replace("九月起至今 · H1", "当前历史窗口 · H1")
    text = text.replace("installVerticalNavigation(svg,hit,zoom,null,y,key,margin.left,margin.top,bottom);",
                        "installVerticalNavigation(svg,hit,zoom,null,y,key,margin.left,margin.top,bottom);\n installArchiveNavigation(svg,hit,zoom,baseX,key,weekly?'week':'day');")
    text = text.replace("views.set(key,domain.map(v=>v-shift));});",
                        "views.set(key,domain.map(v=>v-shift));});\n installArchiveNavigation(svg,hit,zoom,baseX,key,'month');")
    # Display dense bars by their full high/low range, not by their bodies.
    text = text.replace("groups.select('rect').attr('x',b=>x(b.t)-bw/2).attr('width',bw);",
                        "groups.select('rect').attr('x',b=>x(b.t)-bw/2).attr('width',bw).attr('display',Math.abs(x(candles[0].t+Number(period)*60000)-x(candles[0].t))<2?'none':null);")
    text = text.replace("candles.select('rect').attr('x',b=>x(b.t)-bw/2).attr('width',bw);",
                        "candles.select('rect').attr('x',b=>x(b.t)-bw/2).attr('width',bw).attr('display',Math.abs(x(bars[0].t+3600000)-x(bars[0].t))<2?'none':null);")
    navigation = Path(__file__).with_name('ict_archive_navigation.js').read_text(encoding='utf-8')
    text = text.replace('function drawChart(container,record,weekly){',
                        "function drawChart(container,record,weekly){\n if(archiveDrawingScope&&archiveDrawingScope!==(weekly?'week':'day'))return;")
    text = text.replace('function drawMonth(){',
                        "function drawMonth(){\n if(archiveDrawingScope&&archiveDrawingScope!=='month')return;")
    text = text.replace("views.set(key,domain.map(v=>v-shift));",
                        "const bounds=baseX.domain().map(Number),span=domain[1]-domain[0],start=Math.max(bounds[0],Math.min(bounds[1]-span,domain[0]-shift));views.set(key,[start,start+span]);")
    text = text.replace("let period='15',lastWidth=0,liveConnected=false;",
                        "let period='15',lastWidth=0,liveConnected=false;\n" + navigation)
    text = text.replace("(resizeObserver=new ResizeObserver", "setupArchiveNavigation();\n(resizeObserver=new ResizeObserver")
    return text.replace('__ICT_WEEK_DATA__', json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(',', ':')).replace('</', '<\\/'))


# assemble_records below deliberately uses the original full record schema.
# Native detection and source-grounded lifecycle functions are called unchanged.


def assemble_records(periods, all_days, week, current, as_of):
    smts = {n: [] for n in periods}
    amd = native.amd_events(periods[15], timedelta(minutes=15), as_of)
    daily_profile_lifecycle = native.daily_profile_lifecycle
    review_day = native.review_day
    profile_annotation = native.profile_annotation
    silver_bullet_windows = native.silver_bullet_windows
    session_windows = native.session_windows
    NY = native.NY
    chart_payload = native.chart_payload
    utc_time = native.utc_time
    po3_zones = native.po3_zones
    po3_research_gate = native.po3_research_gate
    range_liquidity_map = native.range_liquidity_map
    regular_liquidity = native.regular_liquidity
    review_week = native.review_week
    weekly_path = native.weekly_path
    weekly_profile_lifecycle = native.weekly_profile_lifecycle
    weekly_stage_liquidity = native.weekly_stage_liquidity
    daily_analysis = native.daily_analysis
    days=[]
    for day in all_days:
        lifecycle=daily_profile_lifecycle(periods[15],day,as_of,reference_m5=periods[5])
        record=review_day(periods[15],day,timedelta(minutes=15),as_of,lifecycle.get('daily_price_basis'))
        if not record: continue
        record.update(profile_annotation(record))
        record['silver_windows']=silver_bullet_windows(day)
        record['reference_levels']=[{'label':label,'price':s[field]} for key,field,label in [('asia','high','亚洲高点'),('asia','low','亚洲低点'),('london','high','伦敦高点'),('london','low','伦敦低点')] if (s:=record['sessions'][key]).get('complete')]
        start=session_windows(day)['asia'][0]
        finish=(datetime.combine(day,datetime.min.time(),NY)+timedelta(hours=17 if day.weekday()==4 else 24)).astimezone(timezone.utc)
        record['charts']={str(n):chart_payload(values,n,start,finish,as_of) for n,values in periods.items()}
        for n,chart in record['charts'].items():
            chart['smt']=[e for e in smts[int(n)] if start.timestamp()*1000<=e['primary'][0]['time_ms']<e['primary'][1]['time_ms']<finish.timestamp()*1000 and utc_time(e['available_at'])<=min(finish,as_of)]
        record['po3']=po3_zones(periods[15],start,session_windows(day)['asia'][1],finish,as_of)
        po3_gate=po3_research_gate(record['po3'],{},as_of)
        record['po3_research_gate']={'status':po3_gate['status'],'missing':po3_gate['missing'],
                                     'contradictions':po3_gate['contradictions'],
                                     'execution_allowed':False,'orders_sent':0}
        record['amd_events']=[e for e in amd if start<=utc_time(e['available_at'])<=min(finish,as_of)]
        record['profile_lifecycle']=lifecycle
        record['liquidity']=range_liquidity_map(periods[15],[day],as_of,reference_bars=periods[5])
        record['regular_liquidity']=regular_liquidity(periods[15],periods[5],day,as_of,record['liquidity'])
        record.update({k:record['profile_lifecycle'][k] for k in ('profile_label','profile_status','profile_reason')})
        days.append(record)
    weeks=[]
    for dates in [week,current]:
        record=review_week(periods[15],dates,as_of)
        record['weekly_path']=weekly_path(periods[5],dates,as_of)
        record['profile_lifecycle']=weekly_profile_lifecycle(periods[15],dates,as_of,record['weekly_path'])
        record['profile_reason']=record['profile_lifecycle']['profile_reason']
        record['liquidity']=range_liquidity_map(periods[15],dates,as_of,reference_bars=periods[5])
        record['weekly_stage_liquidity']=weekly_stage_liquidity(periods[5],dates,as_of)
        record['candidates']=record['weekly_path']['candidates']
        # Keep the lifecycle result as the display authority for both
        # ongoing and closed weeks.  A closed week may now carry an
        # explicit partial-path label (for example, a midweek break that
        # never reclaimed); falling back to the raw path would hide that
        # explanation from the chart.
        record['profile_label']=record['profile_lifecycle'].get('profile_label') or record['weekly_path']['profile_label']
        for candidate in record['candidates']:
            candidate['free_guide_pages']=[7] if '周三' in candidate['profile'] else [2] if '周二' in candidate['profile'] else [2,3,4,5,6,7]
        start=datetime.combine(dates[0],datetime.min.time(),NY).astimezone(timezone.utc)
        finish=(datetime.combine(dates[-1],datetime.min.time(),NY)+timedelta(hours=17)).astimezone(timezone.utc)
        record['charts']={str(n):chart_payload(values,n,start,finish,as_of,False) for n,values in periods.items()}
        for n,chart in record['charts'].items():
            chart['smt']=[e for e in smts[int(n)] if start.timestamp()*1000<=e['primary'][0]['time_ms']<e['primary'][1]['time_ms']<finish.timestamp()*1000 and utc_time(e['available_at'])<=min(finish,as_of)]
        for item in record['daily']:
            daily=next((d for d in days if d['date']==item['date']),None)
            item.update({k:daily[k] for k in ('profile_label','profile_status','profile_reason')} if daily else profile_annotation(None))
            reference=next((d for d in record['weekly_path']['daily'] if d['date']==item['date']),None)
            if reference:
                item.update({k:reference.get(k) for k in ('open','high','low','close')})
        record['session_bands']=[[key,s] for d in days if d['date'] in record['days'] for key,s in d['sessions'].items() if key in ('asia','london','new_york') and s.get('start')]
        record['po3_zones']=[z for d in days if d['date'] in record['days'] for z in d['po3']['zones']]
        record['amd_events']=[e for e in amd if start<=utc_time(e['available_at'])<=min(finish,as_of)]
        weeks.append(record)
    for day in days:
        previous=next((d for w in weeks for d in w['daily'] if d['date']==(date.fromisoformat(day['date'])-timedelta(days=1)).isoformat() and d.get('status')=='completed'),None)
        peerclosed=None
        day['analysis']=daily_analysis(day,as_of,previous,peerclosed)
    return days, weeks
