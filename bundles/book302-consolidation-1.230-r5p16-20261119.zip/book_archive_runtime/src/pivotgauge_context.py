"""Versioned price map, not a reproduction of the unpublished probability report.

Native D1/W1 anchors stay native. MN1/Q1 are explicitly derived from observed
D1 bars only on an explicit UTC calendar; their completeness is not asserted.
No current-period final high/low or future reaction labels enter this map.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import math

VERSION = 'pivotgauge_location_context_v1'
FORMULA_SOURCE = 'https://www.tradingview.com/support/solutions/43000521824-pivot-points-standard/'
TOOL_SOURCE = 'https://www.forexfactory.com/thread/post/15010960'
PERIODS = ('D1', 'W1', 'MN1', 'Q1')


def time(value):
    result = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    if result.tzinfo is None:
        raise ValueError('pivot_naive_clock')
    return result.astimezone(timezone.utc)


def iso(value):
    return value.isoformat().replace('+00:00', 'Z')


def formulas(bar):
    """Names identify explicit formula variants; no tzamo binary parity claim."""
    h, l, c = (Decimal(str(bar[k])) for k in ('high', 'low', 'close'))
    p, span = (h+l+c)/3, h-l
    common = dict(PP=p, R1=2*p-l, S1=2*p-h, R2=p+span, S2=p-span)
    families = {
        'classic': dict(common, R3=p+2*span, S3=p-2*span),
        'traditional': dict(common, R3=h+2*(p-l), S3=l-2*(h-p)),
        'camarilla': {f'{side}{n}': c+sign*Decimal('1.1')*span/div
                      for side, sign in [('H', 1), ('L', -1)]
                      for n, div in [(1,12), (2,6), (3,4), (4,2)]},
        'prior_range': dict(HIGH=h, LOW=l, CLOSE=c,
                            **{f'RANGE_{n}': l+span*Decimal(n)/100 for n in ('25','50','75')})}
    # These are named arithmetic subdivisions, not a claim about the EX4 UI.
    ordered = ['S3','S2','S1','PP','R1','R2','R3']
    for a, b in zip(ordered, ordered[1:]):
        x, y = families['classic'][a], families['classic'][b]
        for numerator in (1,2,3):
            families.setdefault('classic_subdivision', {})[f'{a}_{b}_{numerator}of4'] = x+(y-x)*numerator/4
    return {family: {name: float(price) for name, price in values.items()} for family, values in families.items()}


def bounds(at, tf, calendar, weekly_rows):
    utc = calendar.get('timezone')=='UTC' and calendar.get('day_boundary')=='00:00'
    offset = 0 if utc else calendar.get('server_offset_seconds')
    if not utc and (calendar.get('timezone')!='measured_server_offset' or not isinstance(offset,int)
                    or abs(offset)>50400 or offset%60):
        raise ValueError('calendar_unresolved')
    local = at+timedelta(seconds=offset)
    day = local.replace(hour=0,minute=0,second=0,microsecond=0)
    if tf=='D1':
        start, end = day, day+timedelta(days=1)
    elif tf=='W1':
        week = calendar.get('week_start')
        if utc:
            if week not in ('sunday','monday'): raise ValueError('week_boundary_unresolved')
            weekday = 6 if week=='sunday' else 0
        else:
            if not weekly_rows: raise ValueError('native_week_boundary_missing')
            source = time(weekly_rows[-1]['timestamp_utc'])+timedelta(seconds=offset)
            if source.time()!=day.time(): raise ValueError('native_week_boundary_unresolved')
            weekday = source.weekday()
        start = day-timedelta(days=(day.weekday()-weekday)%7)
        end = start+timedelta(days=7)
    else:
        if not utc: raise ValueError('historical_calendar_unverified_for_derived_period')
        month = local.month if tf=='MN1' else (local.month-1)//3*3+1
        start = day.replace(month=month,day=1)
        n = month+(1 if tf=='MN1' else 3)
        end = start.replace(year=start.year+(n-1)//12,month=(n-1)%12+1)
    return start-timedelta(seconds=offset), end-timedelta(seconds=offset)


def anchor(rows, tf, start):
    if tf in ('D1','W1'):
        eligible = [b for b in rows if time(b['closed_at_utc'])<=start]
        if not eligible: raise ValueError('previous_closed_native_period_missing')
        b = eligible[-1]
        # Do not reuse an old level across a missing period. Weekend handling
        # requires a session calendar; until then a missing preceding day is explicit.
        if time(b['closed_at_utc'])!=start:
            raise ValueError('previous_calendar_period_missing_or_market_closed')
        return dict(ohlc={k:b[k] for k in ('open','high','low','close')},
                    source_timeframe=tf, construction='supplied_native_period_bar',
                    start_utc=b['timestamp_utc'], end_utc=b['closed_at_utc'],
                    known_at_utc=b['known_at_utc'], source_bars=[deepcopy(b)],
                    source_completeness='as_supplied_not_tick_audited')
    step = 1 if tf=='MN1' else 3
    n = start.month-step
    previous = start.replace(year=start.year+(n-1)//12,month=(n-1)%12+1)
    selected = [b for b in rows if previous<=time(b['timestamp_utc'])<start and time(b['closed_at_utc'])<=start]
    if not selected or not any(time(b['timestamp_utc'])<previous for b in rows):
        raise ValueError('derived_period_history_left_truncated')
    return dict(ohlc=dict(open=selected[0]['open'],high=max(b['high'] for b in selected),
                         low=min(b['low'] for b in selected),close=selected[-1]['close']),
                source_timeframe='D1',construction='calendar_aggregate_of_observed_D1_not_native_'+tf,
                start_utc=iso(previous),end_utc=iso(start),known_at_utc=max([iso(start)]+[b['known_at_utc'] for b in selected],key=time),
                source_bars=deepcopy(selected),source_completeness='observed_days_only_session_calendar_unverified')


def build(periods, *, provider, instrument, source_id, cutoff_utc, chart_timeframe, calendar):
    at = time(cutoff_utc)
    inputs = {tf:deepcopy(periods.get(tf, [])[-400:]) for tf in ('D1','W1')}
    chart = deepcopy(periods.get(chart_timeframe, [])[-96:])
    opening_rows = deepcopy(periods.get('M1', [])[-2048:])
    return _calculate(inputs,chart,opening_rows,provider,instrument,source_id,at,chart_timeframe,calendar)


def _calculate(inputs, chart, opening_rows, provider, instrument, source_id, at, chart_tf, calendar):
    result = dict(schema=VERSION, provider=provider,instrument=instrument,source_id=source_id,
        as_of_utc=iso(at),chart_timeframe=chart_tf,calendar=deepcopy(calendar),
        source_inputs=deepcopy(inputs),chart_input_bars=deepcopy(chart),opening_input_bars=deepcopy(opening_rows),
        periods={},levels=[],geometric_neighbours=dict(above=[],below=[],at=[]),
        formula_source=FORMULA_SOURCE,tool_lineage_source=TOOL_SOURCE,
        author_binary_parity='unverified',probability_status='screenshot_only_not_consumed',
        selected_formula_family=None,owner_id=None,entry_permission=False,
        read_only=True,automatic_trade_permission=False,future_bars_used=False)
    from .gobi_digger_indicators import level_process
    for tf in PERIODS:
        try:
            start,end = bounds(at,tf,calendar,inputs['W1'])
            a = anchor(inputs[tf if tf in inputs else 'D1'],tf,start)
            known = max(start,time(a['known_at_utc']))
            if known>at: raise ValueError('anchor_not_yet_available')
        except ValueError as error:
            result['periods'][tf]=dict(status='unavailable',reason=str(error))
            continue
        result['periods'][tf] = dict(status='observed_location_map',valid_from_utc=iso(start),
                                    valid_until_utc=iso(end),anchor=a)
        values = formulas(a['ohlc'])
        opening = next((r for r in opening_rows if time(r['timestamp_utc'])==start),None)
        if opening:
            values['current_period']={'OPEN':opening['open']}
        else:
            result['periods'][tf]['current_open_status']='exact_boundary_M1_missing'
        for family, names in values.items():
            for name, price in names.items():
                available = max(known,time(opening['known_at_utc'])) if family=='current_period' else known
                identity = f'{provider}:{instrument}:{tf}:{iso(start)}:{family}:{name}'
                level = dict(object_id=identity,native_timeframe=tf,price=price,level_name=name,
                    formula_family=family,known_at_utc=iso(available),valid_from_utc=iso(start),valid_until_utc=iso(end),
                    source_id=source_id,source_timeframe='M1' if family=='current_period' else a['source_timeframe'],
                    source_construction='exact_boundary_M1_open' if family=='current_period' else a['construction'],
                    owner_equivalence=False)
                eligible = [b for b in chart if start<=time(b['timestamp_utc']) and time(b['closed_at_utc'])<=end]
                level['process']=level_process(level,eligible)
                result['levels'].append(level)
    if chart:
        last = chart[-1]
        for level in result['levels']:
            if time(level['known_at_utc'])>time(last['timestamp_utc']):continue
            delta = level['price']-last['close']
            side = 'above' if delta>0 else 'below' if delta<0 else 'at'
            result['geometric_neighbours'][side].append(dict(object_id=level['object_id'],
                price=level['price'],distance_price=abs(delta),period=level['native_timeframe'],
                formula_family=level['formula_family']))
        for side, rows in result['geometric_neighbours'].items():
            rows.sort(key=lambda r:(r['distance_price'],r['object_id']))
            result['geometric_neighbours'][side]=[r for r in rows if r['distance_price']==rows[0]['distance_price']]
    result['known_at_utc']=max([b['known_at_utc'] for b in chart]+[l['known_at_utc'] for l in result['levels']],key=time,default=None)
    return result


def verify(packet, minutes):
    raw = packet.get('pivotgauge_context')
    if raw is None:return []  # Historical receipts predate this explicitly optional layer.
    try:
        at = time(packet['as_of_utc'])
        groups = list(raw['source_inputs'].items())+[(packet['chart_timeframe'],raw['chart_input_bars']),('M1',raw['opening_input_bars'])]
        for tf, rows in groups:
            if tf not in minutes or len(rows)>2048:raise ValueError('period_or_window')
            previous = None
            for b in rows:
                start,closed,known = (time(b[k]) for k in ('timestamp_utc','closed_at_utc','known_at_utc'))
                if closed!=start+timedelta(minutes=minutes[tf]) or not closed<=known<=at:raise ValueError('clock')
                if previous is not None and start<=previous:raise ValueError('order')
                if 'native_epoch' in b:
                    offset=packet['calendar'].get('server_offset_seconds',0)
                    if b['native_epoch']!=int(start.timestamp())+offset:raise ValueError('native_clock')
                o,h,l,c = (b[k] for k in ('open','high','low','close'))
                if not all(math.isfinite(v) for v in (o,h,l,c)) or not l<=min(o,c)<=max(o,c)<=h:raise ValueError('price')
                previous=start
            existing=(packet.get('process_indicators',{}).get('gobi',{}).get(tf) or {}).get('input_bars',[])
            overlap={b['timestamp_utc']:b for b in existing}
            if any(overlap[b['timestamp_utc']]!=b for b in rows if b['timestamp_utc'] in overlap):raise ValueError('source_overlap')
        expected = _calculate(raw['source_inputs'],raw['chart_input_bars'],raw['opening_input_bars'],
            packet['provider'],packet['instrument'],packet['source_id'],at,packet['chart_timeframe'],packet['calendar'])
        if raw!=expected:raise ValueError('recomputation')
    except (ValueError,TypeError,KeyError,IndexError,OverflowError):
        return ['pivotgauge_source_or_recomputation_invalid']
    return []
