"""Causal, identity-bound research receipts for cross-framework observations.

These receipts expose context to the native task reducer. They do not score,
select, grant entry, infer owners by proximity, or alter source geometry.
"""
from datetime import datetime, timezone
from collections import Counter

from .ict_formation_owner_candidates import build_formation_owner_candidates

VERSION = 'structure_reference_context_v3'
PERIODS = {'M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D1', 'W1'}


def _identity(value):
    return isinstance(value, str) and value.strip().lower() not in {'', 'unknown', 'pending', 'none', 'null', 'unbound'}


def _time(value):
    try:
        result = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return result.astimezone(timezone.utc) if result.tzinfo is not None else None
    except (ValueError, TypeError):
        return None


def build_reference_context(scene):
    cutoff = _time(scene.get('cutoff_utc'))
    tasks = (scene.get('structure_logic') or {}).get('tasks', [])
    tasks = [t for t in tasks if not (cutoff and _time(t.get('known_at_utc'))
                                      and _time(t['known_at_utc']) > cutoff)]
    task_identities = {}
    for task in tasks:
        task_identities.setdefault(task.get('task_id'), []).append(task)
    rows = [o for o in scene.get('objects', []) if o.get('layer') == 'ict']
    # Gobi/Digger inputs must arrive as separately source-bound observations,
    # not direction inferred from a distance threshold or a drawing label.
    rows += [dict(o, layer=o.get('framework')) for o in scene.get('cross_framework_observations', [])
             if o.get('framework') in {'gobi', 'digger'}]
    receipts = []
    visible = []
    for obj in rows:
        known = _time(obj.get('known_at_utc'))
        if known and cutoff and known > cutoff:
            continue  # Do not even expose the existence of future evidence.
        visible.append(obj)
    identities = {}
    for obj in visible:
        key = obj.get('id')
        identities.setdefault(key, []).append(obj)
    seen = set()
    for obj in visible:
        if obj.get('id') in seen:
            continue
        seen.add(obj.get('id'))
        evidence = obj.get('evidence') or {}
        source_id = obj.get('source_id')
        prefix = str(source_id or '').split(':ict:', 1)[0] if ':ict:' in str(source_id or '') else ''
        source_parts = prefix.rsplit(':', 2)
        # Broker providers can themselves contain colons (MT5:server).
        encoded_market = source_parts[:2] if len(source_parts) == 3 else None
        provider = obj.get('provider') or evidence.get('source_provider') or (encoded_market[0] if encoded_market else None)
        instrument = obj.get('instrument') or evidence.get('instrument') or (encoded_market[1] if encoded_market else None)
        native = obj.get('native_timeframe') or evidence.get('source_timeframe')
        owner = obj.get('owner_id')
        known = _time(obj.get('known_at_utc'))
        reasons = []
        if cutoff is None:
            reasons.append('scene_cutoff_missing_or_naive')
        if known is None:
            reasons.append('observation_known_at_missing_or_naive')
        if not _identity(obj.get('id')) or not _identity(source_id):
            reasons.append('observation_identity_missing')
        if any(other != obj for other in identities[obj.get('id')]):
            reasons.append('conflicting_observation_identity')
        if not _identity(provider) or not _identity(instrument):
            reasons.append('source_market_identity_unknown')
        elif provider != scene.get('provider') or instrument != scene.get('instrument'):
            reasons.append('source_market_mismatch')
        if encoded_market and [provider, instrument] != encoded_market:
            reasons.append('encoded_and_explicit_market_conflict')
        if native not in PERIODS:
            reasons.append('native_timeframe_unknown')
        if obj.get('native_timeframe') and evidence.get('source_timeframe') and obj['native_timeframe'] != evidence['source_timeframe']:
            reasons.append('native_timeframe_conflict')
        if not _identity(owner):
            reasons.append('native_owner_unknown')
        if not _identity(obj.get('rule_version')):
            reasons.append('rule_version_unknown')
        bound, rejected = [], []
        for task in tasks:
            # A shared owner may have several distinct source/return tasks.
            # Require the producer's explicit exact task id as well.
            if task.get('task_id') not in (obj.get('structure_task_ids') or []):
                continue
            task_known = _time(task.get('known_at_utc'))
            task_asof = _time(task.get('as_of_utc'))
            checks = []
            if any(other != task for other in task_identities[task.get('task_id')]):
                checks.append('conflicting_native_task_identity')
            if not owner or owner != task.get('owner_id'):
                checks.append('task_owner_mismatch')
            if native != task.get('timeframe'):
                checks.append('task_native_timeframe_mismatch')
            if task.get('provider', scene.get('provider')) != provider or task.get('instrument', scene.get('instrument')) != instrument:
                checks.append('task_market_mismatch')
            if not task_known or not cutoff or task_known > cutoff or task_asof != cutoff:
                checks.append('task_clock_mismatch')
            if reasons or checks:
                rejected.append({'task_id': task.get('task_id'), 'reasons': sorted(set(reasons + checks))})
            else:
                bound.append(task['task_id'])
        if not bound and not rejected:
            reasons.append('explicit_native_task_binding_missing')
        # Only lifecycle facts whose own clocks are visible are carried.
        lifecycle = {key: value for key, value in evidence.items()
                     if key in {'sweep_known_at', 'reclaim_known_at', 'invalidation_known_at', 'full_mitigation_known_at'}
                     and _time(value) and cutoff and _time(value) <= cutoff}
        formation = evidence.get('formation_provenance') or {}
        candles = formation.get('candles') or []
        formation_visible = (
            formation.get('state') == 'three_candle_geometry_verified'
            and formation.get('provider') == provider and formation.get('instrument') == instrument
            and formation.get('native_timeframe') == native and len(candles) == 3
            and cutoff and _time(formation.get('known_at_utc'))
            and _time(formation['known_at_utc']) <= cutoff
            and all(_time(c.get('closed_at_utc')) and _time(c['closed_at_utc']) <= _time(formation['known_at_utc'])
                    for c in candles))
        formation_event = dict(evidence)
        formation_event['formation_provenance'] = formation
        owner_candidates = (build_formation_owner_candidates(
            formation_event, tasks, scene.get('cutoff_utc'), provider, instrument)
            if formation else [])
        owner_candidate_counts = Counter(row.get('candidate_status') for row in owner_candidates)
        receipts.append({
            'object_id': obj.get('id'), 'source_id': source_id, 'owner_id': owner or None,
            'framework': obj.get('layer'), 'display_timeframe': obj.get('timeframe'),
            'native_timeframe': native if native in PERIODS else None,
            'provider': provider, 'instrument': instrument,
            'known_at_utc': obj.get('known_at_utc'), 'as_of_utc': scene.get('cutoff_utc'),
            'observed_at_utc': (obj.get('observed_at_utc') if _time(obj.get('observed_at_utc')) and cutoff
                                and _time(obj['observed_at_utc']) <= cutoff else None),
            'observed_at_policy': 'explicit_only_never_inferred_from_known_at',
            'rule_version': obj.get('rule_version'),
            'causal_cluster_id': evidence.get('causal_cluster_id') or source_id,
            'state': 'task_bound_context_only' if bound else 'unbound_context',
            'task_ids': sorted(set(bound)), 'blockers': sorted(set(reasons)),
            'rejected_task_bindings': rejected, 'lifecycle_visible_at_cutoff': lifecycle,
            'formation_source': ({'formation_id': formation.get('formation_id'),
                                  'candle_ids': [c.get('candle_id') for c in candles],
                                  'candle_window': [{'open_at_utc': c.get('open_at_utc'), 'closed_at_utc': c.get('closed_at_utc')} for c in candles],
                                  'known_at_utc': formation.get('known_at_utc'),
                                  'state': 'three_candle_geometry_only_owner_unverified'} if formation_visible else None),
            'owner_candidate_state': ('candidate_review_only' if owner_candidates else 'not_available'),
            'owner_candidate_counts': dict(owner_candidate_counts),
            'owner_candidates': owner_candidates,
            'entry_permission': False, 'automatic_trade_permission': False,
        })
    receipts.sort(key=lambda r: (str(r['framework']), str(r['object_id'])))
    return {'schema': VERSION, 'as_of_utc': scene.get('cutoff_utc'),
            'receipts': receipts, 'bound_count': sum(bool(r['task_ids']) for r in receipts),
            'unbound_count': sum(not r['task_ids'] for r in receipts),
            'score_effect': 'none', 'parent_direction_effect': 'none',
            'entry_permission': False, 'automatic_trade_permission': False,
            'future_bars_used': False, 'read_only': True}
