"""Independent trendline/pivot block derived from the user's scanned PDF.

This module deliberately owns only the outer-line geometry.  It does not
classify order-book liquidity, assign an author wave degree, or grant a trade.
The PDF rule is stricter than a regression channel: the line must span the
major native wave, use the correct outer side, and remain clear of every bar
after the first anchor until the first opposite break.
"""
from __future__ import annotations

import math
import statistics
from fractions import Fraction
from functools import lru_cache


PDF_RULE_ID = "trend_trade_method_pdf_ch3_ch4_outer_wave_v1"
PDF_SOURCE_SHA256 = "e2a064c01b97d5098b5ecff968f67062220f663306fdcb2042e269c180577dfc"
PDF_SOURCE_PAGES = (48, 49, 58, 59, 80, 81, 82, 83, 84)
PDF_TRENDLINE_RULE_PAGES = (48, 49, 58, 59, 63, 64)
PDF_TURNING_POINT_RULE_PAGES = (80, 81, 82, 83, 84, 87, 88, 89)


def scene_block(scene, foundation_context=None):
    """Build the independent read-only chart block from visible objects."""
    context = foundation_context or {}
    objects = scene.get("objects", []) if isinstance(scene, dict) else []
    lines = [o for o in objects if o.get("kind") == "line"
             and o.get("evidence", {}).get("display_role") == "single_outer_trendline"]
    parallels = [o for o in objects if o.get("kind") == "line"
                 and o.get("evidence", {}).get("display_role") == "parallel_outer_extension"]
    boxes = [o for o in objects if o.get("layer") in {"force", "turning_point"} and o.get("kind") == "box"
             and o.get("evidence", {}).get("display_role") in {
                 "first_break_response_range", "primary_reverse_response_range"
             }]
    return {
        "schema": "xauusd_pdf_trendline_live_block_v1",
        "rule_id": PDF_RULE_ID,
        "source_pages": list(PDF_SOURCE_PAGES),
        "source_pdf_sha256": PDF_SOURCE_SHA256,
        "timeframe": scene.get("timeframe"),
        "as_of_utc": scene.get("cutoff_utc"),
        "foundation_context_as_of_utc": context.get("as_of_utc"),
        "policy": "one_major_same_period_outer_wave_line; broad_anchor_pair; no_internal_crossing; first_opposite_close_break; parallel_projection_evidence",
        "source_rule_pages": {"trendline": list(PDF_TRENDLINE_RULE_PAGES),
                               "turning_point": list(PDF_TURNING_POINT_RULE_PAGES)},
        "outer_line_object_ids": [o.get("id") for o in lines],
        "parallel_line_object_ids": [o.get("id") for o in parallels],
        "response_box_object_ids": [o.get("id") for o in boxes],
        "outer_line_count": len(lines),
        "parallel_line_count": len(parallels),
        "response_box_count": len(boxes),
        "unknown_reason": None if lines else "no_broad_clear_outer_pair_at_cutoff",
        "read_only": True,
        "trade_permission": False,
        "author_accuracy_verified": False,
    }


def _number(value):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def _valid_bar(row):
    if not isinstance(row, dict):
        return False
    try:
        values=(float(row.get('open')),float(row.get('high')),
                float(row.get('low')),float(row.get('close')))
    except (TypeError,ValueError):
        return False
    return _valid_ohlc(*values)


@lru_cache(maxsize=32768)
def _valid_ohlc(open_, high, low, close):
    # Exact finite values are the key. Mutating/revising a source dictionary
    # always rechecks its new OHLC; no trusted-row flag skips validation.
    return (math.isfinite(open_) and math.isfinite(high) and math.isfinite(low)
            and math.isfinite(close) and low <= min(open_, close) <= max(open_, close) <= high)


def _local_extrema(values, upward, radius):
    out = []
    for i in range(radius, len(values) - radius):
        left, right = values[i - radius:i], values[i + 1:i + radius + 1]
        if upward and values[i] <= min(left) and values[i] <= min(right):
            out.append(i)
        if not upward and values[i] >= max(left) and values[i] >= max(right):
            out.append(i)
    return out


def _axis_alignment_diagnostic(bars, start, anchor, terminal, slope, upward, *, reference_start=None):
    """Measure whether an otherwise valid outer ruler follows the wave axis.

    The book's ``中轴`` is a relationship between the two outer sides of the
    same movement; it is not a screen angle and it must not be used to relax
    the no-candle-contact rule.  We therefore build a provisional opposite
    rail from the *same native wave* (start through its observed terminal),
    compare candle body midpoints with that rail's midpoint, and return only
    an auditable ranking diagnostic.  The source line remains valid only when
    the strict clearance checks have already passed.
    """
    if not bars or not (0 <= int(start) < len(bars)):
        return {"score": 0.0, "reason": "invalid_axis_window"}
    start = int(start)
    terminal = max(start + 1, min(int(terminal), len(bars) - 1))
    from .book_calculation_scope import independent_axis_enabled,measure_axis
    if independent_axis_enabled():
        return measure_axis(bars,start,anchor,terminal,slope,reference_start=reference_start)
    base_values = []
    ranges = []
    displacements = []
    for k in range(start, terminal + 1):
        base = float(bars[start]["low" if upward else "high"]) + float(slope) * (k - start)
        opposite = float(bars[k]["high" if upward else "low"])
        displacements.append(opposite - base if upward else base - opposite)
        ranges.append(max(0.0, float(bars[k]["high"]) - float(bars[k]["low"])))
        base_values.append(base)
    positive = [value for value in ranges if value > 0]
    typical = statistics.median(positive) if positive else 0.0
    # Both directions use the farthest signed displacement.  Using ``min``
    # for a down wave selects the nearest low and collapses the provisional
    # channel, making every body midpoint look off-axis and reducing the
    # R05 tie-break to zero.
    offset = max(displacements)
    width = max(abs(offset), typical, 1e-9)
    # A non-positive offset means the proposed rail does not enclose the
    # observed movement.  Keep it as a diagnostic failure, never a rejection
    # reason (the strict outer-side test owns rejection).
    if offset <= 0:
        return {"score": 0.0, "reason": "opposite_rail_not_established", "offset": offset}
    # ``offset`` above is an unsigned outward distance in both directions.
    # A down-wave ruler is the upper rail, so its centre lies BELOW it.
    signed_offset = offset if upward else -offset
    residuals = []
    for k, base in zip(range(start, terminal + 1), base_values):
        body_mid = (float(bars[k].get("open", bars[k]["low"])) +
                    float(bars[k].get("close", bars[k]["high"]))) / 2.0
        residuals.append(abs(body_mid - (base + signed_offset / 2.0)) / width)
    residual = statistics.median(residuals) if residuals else 1.0
    fit = max(0.0, min(1.0, 1.0 - residual))
    span = max(1, terminal - start)
    coverage = max(0.0, min(1.0, (int(anchor) - start) / span))
    return {
        "score": round(fit * 100.0, 2),
        "reason": "body_midpoint_near_wave_axis" if fit >= 0.5 else "body_midpoint_axis_deviation",
        "body_mid_residual_median_normalized": round(residual, 6),
        "axis_fit": round(fit, 6),
        "opposite_rail_offset": round(offset, 8),
        "opposite_rail_signed_offset": round(signed_offset, 8),
        "score_version": "native_wave_axis_directional_midpoint_v2",
        "typical_native_range": round(typical, 8),
        "terminal_index": terminal,
        "coverage_to_terminal": round(coverage, 6),
        "future_bars_used": False,
        "research_only": True,
    }


def _parallel_intelligence(bars, line, opposite_idx, offset, upward, end):
    """Return a causal quality audit for a parallel projection.

    ``_parallel_projection`` must still enclose every candle before the first
    opposite close.  This second layer asks whether that enclosing edge is
    repeatedly witnessed or is merely one isolated wick.  It never uses bars
    after ``end`` and never labels direction or an entry.
    """
    start = int(line.get("start_index", 0))
    if end < start:
        return {"quality": "unknown", "reason": "empty_formation", "research_only": True,
                "semantic_state": "geometry_only",
                "author_state": "unknown_until_prefix_event"}
    ranges = [max(0.0, float(b["high"]) - float(b["low"]))
              for b in bars[start:end + 1]]
    typical = statistics.median([r for r in ranges if r > 0]) if any(r > 0 for r in ranges) else 0.0
    tol = max(typical * .20, abs(offset) * .025, 1e-9)
    lower_touches = upper_touches = 0
    body_fit = wick_excursions = 0
    for i in range(start, end + 1):
        base = float(line["start_price"]) + float(line["slope"]) * (i - start)
        lo, hi = (base, base + offset) if upward else (base + offset, base)
        if lo > hi:
            lo, hi = hi, lo
        if "open" in bars[i] and "close" in bars[i]:
            body_lo = min(float(bars[i]["open"]), float(bars[i]["close"]))
            body_hi = max(float(bars[i]["open"]), float(bars[i]["close"]))
            body_fit += int(body_lo >= lo - 1e-12 and body_hi <= hi + 1e-12)
        wick_excursions += int(float(bars[i]["low"]) < lo - tol or float(bars[i]["high"]) > hi + tol)
        lower_touches += int(abs(float(bars[i]["low"]) - lo) <= tol)
        upper_touches += int(abs(float(bars[i]["high"]) - hi) <= tol)
    count = max(1, end - start + 1)
    width_atr = abs(offset) / max(typical, 1e-9)
    width_fit = 1.0 if 1.0 <= width_atr <= 8.0 else max(0.0, 1.0 - abs(width_atr - 4.0) / 8.0)
    formation_span = max(1, end - start + 1)
    formation_fit = max(0.0, min(1.0, (formation_span - 4.0) / 20.0))
    touch_count = min(lower_touches, upper_touches)
    body_ratio = body_fit / count
    touch_ratio = min(1.0, touch_count / 2.0)
    clean_ratio = max(0.0, 1.0 - wick_excursions / count)
    # Initial geometry weights are deliberately exposed.  They are a
    # reproducible research score until a prefix-only channel outcome model
    # exists; they must never be presented as a hit rate.
    components = [
        {"key": "body_fit", "weight": 28.0, "value": round(body_ratio, 4)},
        {"key": "edge_touch", "weight": 25.0, "value": round(touch_ratio, 4)},
        {"key": "width_fit", "weight": 17.0, "value": round(width_fit, 4)},
        {"key": "wick_clean", "weight": 12.0, "value": round(clean_ratio, 4)},
        {"key": "formation_span", "weight": 18.0, "value": round(formation_fit, 4)},
    ]
    base_score = sum(c["weight"] * c["value"] for c in components)

    # Geometry quality is more than fitting an envelope.  Measure whether
    # native pivots actually alternate between rails, whether bodies sit near
    # the channel centre, and whether the slope is meaningful relative to the
    # channel width.  These diagnostics are prefix-only and descriptive; they
    # do not change the PDF drawing rule or grant an entry.
    centre_residuals = []
    touch_sequence = []
    touch_events = []
    ambiguous_touches = 0
    for i in range(start, end + 1):
        base = float(line["start_price"]) + float(line["slope"]) * (i - start)
        lo, hi = (base, base + offset) if upward else (base + offset, base)
        if lo > hi:
            lo, hi = hi, lo
        open_price = bars[i].get("open", bars[i].get("low"))
        close_price = bars[i].get("close", bars[i].get("high"))
        body_mid = (float(open_price) + float(close_price)) / 2.0
        centre_residuals.append(abs(body_mid - (lo + hi) / 2.0) /
                               max(abs(offset), typical, 1e-9))
        lower_hit=abs(float(bars[i]["low"]) - lo)<=tol
        upper_hit=abs(float(bars[i]["high"]) - hi)<=tol
        if lower_hit and upper_hit:
            ambiguous_touches+=1
            touch_events.append(None)
            continue  # OHLC cannot tell which rail was visited first.
        if lower_hit:
            rail = "lower"
        elif upper_hit:
            rail = "upper"
        else:
            continue
        touch_events.append(rail)
        if not touch_sequence or touch_sequence[-1] != rail:
            touch_sequence.append(rail)
    residual_median = statistics.median(centre_residuals) if centre_residuals else 1.0
    residual_fit = max(0.0, min(1.0, 1.0 - residual_median))
    alternations = sum(a is not None and b is not None and a != b
                       for a,b in zip(touch_events,touch_events[1:]))
    alternation_ratio = alternations / max(1, len(touch_events) - 1) if touch_events else 0.0
    rail_change = abs(float(line["slope"]) * max(1, end - start))
    slope_width_ratio = rail_change / max(abs(offset), typical, 1e-9)
    range_like = bool(slope_width_ratio < 0.20 and alternations >= 2)
    slope_quality = max(0.0, min(1.0, slope_width_ratio))
    if range_like:
        slope_quality *= 0.35
    advanced_quality = (0.40 * alternation_ratio +
                        0.35 * residual_fit + 0.25 * slope_quality)
    adjustment = (advanced_quality - 0.5) * 12.0
    if range_like:
        adjustment -= 8.0
    score = round(max(0.0, min(100.0, base_score + adjustment)), 1)
    grade = "strong" if score >= 70 else "medium" if score >= 50 else "weak"
    if touch_count >= 2 and score >= 70:
        quality, reason = "confirmed", "repeated_opposite_edge_touches"
    elif touch_count >= 1 and score >= 50:
        quality, reason = "candidate", "single_edge_touch_or_partial_distribution"
    else:
        quality, reason = "unknown", "enclosing_edge_not_repeatedly_witnessed"
    return {
        "quality": quality, "reason": reason, "score": score,
        # Geometry quality is intentionally separate from the author's
        # turning/trend state.  A fitted rail has no author confirmation by
        # itself; the latter requires the chapter-4 event sequence.
        "semantic_state": "geometry_only",
        "author_state": "unknown_until_prefix_event",
        "grade": grade,
        "base_score": round(base_score, 1),
        "advanced_adjustment": round(adjustment, 1),
        "score_version": "parallel_geometry_components_v3",
        "score_basis": "engineering_initial_components",
        "calibration_status": "not_calibrated_to_channel_outcomes",
        "grade_thresholds": {"weak_lt": 50.0, "medium_gte": 50.0, "strong_gte": 70.0},
        "components": components,
        "typical_native_range": typical, "width_atr_ratio": round(width_atr, 4),
        "formation_span_bars": formation_span,
        "formation_span_fit": round(formation_fit, 4),
        "body_fit_ratio": round(body_fit / count, 4),
        "wick_contamination_ratio": round(wick_excursions / count, 4),
        "lower_touch_count": lower_touches, "upper_touch_count": upper_touches,
        "advanced_diagnostics": {
            "touch_event_count": len(touch_events),
            "ambiguous_same_bar_touches": ambiguous_touches,
            "touch_sequence": touch_sequence,
            "touch_sequence_count": len(touch_sequence),
            "rail_alternation_count": alternations,
            "rail_alternation_ratio": round(alternation_ratio, 4),
            "body_mid_residual_median_normalized": round(residual_median, 4),
            "body_mid_residual_fit": round(residual_fit, 4),
            "slope_width_ratio": round(slope_width_ratio, 4),
            "range_like_balance_candidate": range_like,
            "evaluation_end_index": end,
            "evaluation_clock_role": "pre_break_formation_prefix",
            "future_bars_used": False,
        },
        "tolerance": tol, "as_of_index": end,
        "future_bars_used": False, "research_only": True,
    }


def _parallel_projection(bars, line, upward):
    """Return the PDF-style opposite-side parallel line and pivot level."""
    opposite_key = "high" if upward else "low"
    lo = max(0, int(line.get("start_index", 0)))
    first_break=line.get("first_break_index")
    hi = min(len(bars)-1, int(first_break)-1 if first_break is not None else len(bars)-1)
    candidate_indices = range(lo, hi + 1)
    def displacement(i):
        return float(bars[i][opposite_key])-(line['start_price']+line['slope']*(i-line['start_index']))
    # A parallel shift is set by distance from the ruler, not the largest
    # absolute price. The latter can leave another candle outside the channel.
    opposite_idx = (max(candidate_indices, key=displacement) if upward else
                    min(candidate_indices, key=displacement))
    base = line["start_price"] + line["slope"] * (opposite_idx - line["start_index"])
    offset = float(bars[opposite_idx][opposite_key]) - base
    projected_start = line["start_price"] + offset
    projected_end = line["end_price"] + offset
    return {
        "method": "parallel_outer_extension",
        "reference_side": "upper" if upward else "lower",
        "reference_index": opposite_idx,
        "reference_utc": bars[opposite_idx].get("timestamp_utc"),
        "reference_price": float(bars[opposite_idx][opposite_key]),
        "reference_window": {"start_index": lo, "end_index": hi,
                              "selection": "whole_established_wave_before_first_break"},
        "reference_selection": "outermost_signed_displacement_from_parallel_ruler",
        "encloses_established_wave": True,
        "offset": offset,
        "slope": line["slope"],
        "start_price": projected_start,
        "end_price": projected_end,
        "pivot_level_at_reference": float(bars[opposite_idx][opposite_key]),
        "turning_point_rule": "find_opposite_outer_extension_then_parallel_shift",
        "source_rule_pages": list(PDF_TURNING_POINT_RULE_PAGES),
        "intelligence": _parallel_intelligence(bars, line, opposite_idx, offset, upward, hi),
    }


def _double_extreme_neckline_ranges(bars, upward, extreme_index, radius, typical_range):
    """Allow the chapter-3 post-extreme neckline exception only for a clear
    double top/bottom.

    The normal rule is deliberately strict: an up-line's second low must be
    before the highest high, and a down-line's second high must be before the
    lowest low.  Pages 39/49 allow a later neckline only after a genuine
    double top/bottom.  A pair of nearby prices alone is insufficient; both
    pivots must be separated and locally confirmed.
    """
    key = "high" if upward else "low"
    pivots = _local_extrema([float(b[key]) for b in bars], not upward, radius)
    if len(pivots) < 2:
        return []
    tolerance = max(float(typical_range) * 1.5, 1e-9)
    ranges = []
    for a_pos, left in enumerate(pivots[:-1]):
        for right in pivots[a_pos + 1:]:
            if left >= extreme_index or right <= extreme_index:
                continue
            if right - left < max(2 * radius, 6):
                continue
            if abs(float(bars[left][key]) - float(bars[right][key])) > tolerance:
                continue
            # The supplied extreme must belong to this pair, otherwise a
            # remote equal high/low would incorrectly legalise a later point.
            if abs(left - extreme_index) <= radius or abs(right - extreme_index) <= radius:
                ranges.append((left, right))
    return ranges


def _double_extreme_exception(bars, upward, extreme_index, radius, typical_range):
    """Compatibility predicate for callers that only need the exception."""
    return bool(_double_extreme_neckline_ranges(
        bars, upward, extreme_index, radius, typical_range))


def _outer_hull_vertices(values, upward):
    """Native upper/lower envelope vertices, independent of the trend origin.

    This supplies supporting-point candidates missed by a pivot radius. It
    neither assigns a wave degree nor relaxes the full-wave clearance test.
    """
    sign = 1 if upward else -1
    hull = []
    for k, value in enumerate(values):
        while len(hull) >= 2:
            a, b = hull[-2:]
            cross = ((b-a)*sign*(value-values[a])
                     - sign*(values[b]-values[a])*(k-a))
            if cross < 0:
                break
            hull.pop()
        hull.append(k)
    return hull


def _native_axis_slope(rows):
    """Robust native price/bar diagnostic; never a screen-angle constraint."""
    half = len(rows)//2
    left, right = rows[:half], rows[-half:]
    mid = lambda r: (float(r['open']) + float(r['close']))/2
    return ((statistics.median(map(mid, right))-statistics.median(map(mid, left)))
            / (len(rows)-half))


def select_pdf_turning_boundary(bars, trendline, *, owned_scope=None):
    """Chapter 4 reversal target: opposite outer extension shifted to D.

    This is independent of the chapter-3 trendline and its same-slope channel.
    The established wave is frozen before its first opposite close break; no
    response candle may move the extension/shift anchor retroactively.
    """
    base={'qualified':False,'status':'unknown','source_rule_pages':list(PDF_TURNING_POINT_RULE_PAGES),
          'rule_id':'trend_trade_method_pdf_ch4_opposite_extension_shift_v1',
          'source_pdf_sha256':PDF_SOURCE_SHA256,'future_bars_used':False,
          'read_only':True,'trade_permission':False,
          'semantic_state':'chapter4_projection',
          'author_state':'unknown_until_price_contact_or_closed_confirmation'}
    if not trendline.get('qualified') or not bars:
        return dict(base,reason='trendline_unknown')
    stop=trendline.get('first_break_index')
    stop=int(stop) if stop is not None else len(bars)
    if not 0<stop<=len(bars):return dict(base,reason='invalid_wave_span')
    from .book_owned_scope import resolve_owned_scope
    try:
        scope=resolve_owned_scope(bars[:stop],trendline,owned_scope)
        start=scope['start_index']
        if type(start) is not int:return dict(base,reason='invalid_wave_span')
    except (KeyError,ValueError,TypeError,IndexError) as error:
        return dict(base,reason='owned_scope_unavailable',owned_scope_error=str(error))
    if scope['binding'] is not None:
        base['owned_scope_binding']=scope['binding']
        base['known_at_utc']=max([scope['binding']['known_at_utc']]+([trendline['known_at_utc']] if trendline.get('known_at_utc') else []))
    up=trendline.get('direction')=='up'
    if not 0<=start<stop<=len(bars):return dict(base,reason='invalid_wave_span')
    extreme=max(range(start,stop),key=lambda k:float(bars[k]['high'])) if up else min(range(start,stop),key=lambda k:float(bars[k]['low']))
    rows=bars[start:extreme+1];n=len(rows)
    if n<12:return dict(base,reason='insufficient_established_wave')
    side='high' if up else 'low';values=[float(row[side]) for row in rows]
    radius=max(1,min(6,n//20))
    pivots=set(_local_extrema(values,not up,radius))
    # C/E belong to this wave's opposite envelope, not to its trendline's
    # origin. Interior hull vertices also admit outer shoulders that a fixed
    # local-pivot radius can miss. The original wave origin is not invented
    # as a C pivot.
    hull=_outer_hull_vertices(values,up)
    pivots.update(k for k in hull if k>0)
    pivots.add(n-1)  # observed terminal extreme, not an invented window-edge origin
    axis_slope=_native_axis_slope(rows)
    axis_scale=max(abs(axis_slope), statistics.median(
        float(r['high'])-float(r['low']) for r in rows)/max(1,n-1), 1e-9)
    audit=dict(schema='book_CDE_construction_audit_v1',diagnostic_only=True,
        wave_start_utc=rows[0].get('timestamp_utc'),wave_end_utc=rows[-1].get('timestamp_utc'),
        wave_bars=n,extension_pivot_radius=radius,D_confirmation_radius=2,
        late_C_policy='every_C_requires_full_parent_wave_envelope',
        envelope_candidate_policy='native_pivots_plus_interior_outer_hull_vertices',
        opposite_envelope_vertices=hull,axis_slope_per_native_bar=axis_slope,
        engineering_span_filters=dict(minimum=max(6,int(n*.22)),E_minimum=int(n*.45)),
        counts={},rejected_candidates=[],rejected_receipt_limit=64,rejected_receipts_truncated=False,
        source_rule_pages=[81,82,83],author_wave_degree_verified=False)
    base['construction_audit']=audit
    if scope['binding'] is not None:
        audit.update(owned_scope_binding=scope['binding'],
            range_policy=scope['policy'],source_first_contact_index=trendline['start_index'])
    def note(reason,i,j,**details):
        audit['counts'][reason]=audit['counts'].get(reason,0)+1
        if len(audit['rejected_candidates'])<audit['rejected_receipt_limit']:
            audit['rejected_candidates'].append(dict(reason=reason,
                C=dict(utc=rows[i].get('timestamp_utc'),price=values[i],offset_from_wave_start=i),
                E=dict(utc=rows[j].get('timestamp_utc'),price=values[j],offset_from_wave_start=j),**details))
        else:audit['rejected_receipts_truncated']=True
    extensions=[]
    from .book_calculation_scope import independent_axis_enabled
    from .book_outer_scan import clearance
    fast_rejections=independent_axis_enabled() and all(math.isfinite(v) for v in values)
    for i in sorted(pivots):
        for j in sorted(pivots):
            if j-i<max(6,int(n*.22)) or j<int(n*.45):continue
            slope=(values[j]-values[i])/(j-i)
            if (up and slope<=0) or (not up and slope>=0):
                note('extension_slope_not_in_parent_direction',i,j);continue
            full_receipts=len(audit['rejected_candidates'])>=audit['rejected_receipt_limit']
            gaps=(clearance(values,i,j,slope,1 if up else -1,i+1,n)
                  if fast_rejections and full_receipts else
                  [(values[i]+slope*(k-i)-values[k])*(1 if up else -1)
                   for k in range(i+1,n) if k!=j])
            if not gaps or min(gaps)<=1e-9:
                note('extension_crosses_or_touches_internal_bar',i,j,
                    minimum_clearance=min(gaps) if gaps else None);continue
            # The entire OWNED wave must be enclosed regardless of C's
            # position. The old first-35% exception let a line cut through
            # early candles while claiming to describe the whole movement.
            earlier=(clearance(values,i,j,slope,1 if up else -1,0,i)
                     if fast_rejections and full_receipts else
                     [(values[i]+slope*(k-i)-values[k])*(1 if up else -1) for k in range(i)])
            if earlier and min(earlier)<=1e-9:
                note('earlier_parent_wave_outside_C_E_extension',i,j,
                    earlier_min_clearance=min(earlier));continue
            # Only hard-valid supporting pairs enter this engineering tie
            # break. Prefer the same wave's native body-axis slope, then
            # breadth/coverage. No line is rotated to obtain a visual fit.
            mismatch=abs(slope-axis_slope)/axis_scale
            rank=(-mismatch,j-i,n-i,min(gaps))
            extensions.append((rank,i,j,slope,min(gaps)))
    audit['eligible_extension_pairs']=len(extensions)
    if not extensions:return dict(base,reason='no_broad_opposite_outer_extension')
    destination='low' if up else 'high'
    candidates=_local_extrema([float(row[destination]) for row in rows],up,2)
    # Chapter 4's C--D--E construction: D belongs to the adjustment
    # BETWEEN the selected extension anchors. A later low/high after E
    # belongs to another leg and cannot retroactively relocate this line.
    d=None
    # A C--E pair without its own eligible D is not a complete chapter-4
    # construction. Try the next enclosing pair instead of suppressing the
    # whole wave. Ranking is an engineering tie-break, not a book rule.
    rejected_extensions=0
    for _,i,j,slope,gap in sorted(extensions,reverse=True):
        # D is the adjustment extreme of this C--E interval (figure 4-4),
        # not whichever later micro pivot happens to clear the shifted ray.
        candidate=(min if up else max)(range(i+1,j),key=lambda k:float(rows[k][destination]))
        detail=dict(D=dict(utc=rows[candidate].get('timestamp_utc'),price=float(rows[candidate][destination]),
            offset_from_wave_start=candidate),D_is_confirmed_local_extreme=candidate in candidates,
            D_confirmation_inside_C_E=candidate+2<=j)
        rejection='D_local_extreme_unconfirmed'
        if candidate not in candidates:
            # An outside C candle can contain both the extension high/low
            # and a deeper opposite extreme. OHLC cannot order those events.
            c_opposite=float(rows[i][destination]);d_opposite=float(rows[candidate][destination])
            if (d_opposite-c_opposite)*(1 if up else -1)>=0 and candidate-i<=2:
                rejection='C_candle_opposite_extreme_order_unknown'
        elif candidate+2>j:rejection='D_confirmation_not_inside_C_E'
        if candidate in candidates and candidate+2<=j:
            candidate_price=float(rows[candidate][destination])
            gaps=[(float(rows[k][destination])-(candidate_price+slope*(k-candidate)))*(1 if up else -1)
                  for k in range(candidate+1,j+1)]
            if gaps and min(gaps)>1e-9:d=candidate
            else:
                rejection='shifted_D_line_crosses_C_E_leg'
                detail['shifted_min_clearance']=min(gaps) if gaps else None
                # Explain the actual failure without replacing the fixed D
                # with a more convenient channel contact. Decimal-native
                # arithmetic keeps mirror/scale witnesses reproducible.
                m=(Fraction(str(values[j]))-Fraction(str(values[i])))/(j-i)
                price=Fraction(str(rows[candidate][destination]))
                sign=1 if up else -1
                # Reuse the already calculated clearance vector for witness
                # locations. Exact decimal arithmetic is needed only for the
                # selected receipts, not another rational scan of every bar.
                residuals=dict(enumerate(gaps,candidate+1))
                failed=[k for k,v in residuals.items() if v<=1e-9]
                worst=min(residuals,key=residuals.get)
                def witness(k):
                    value=sign*(Fraction(str(rows[k][destination]))-(price+m*(k-candidate)))
                    return dict(index=start+k,offset_from_wave_start=k,
                        utc=rows[k].get('timestamp_utc'),signed_clearance=float(value),
                        exact_clearance=dict(numerator=value.numerator,denominator=value.denominator))
                # Q is an explanatory parallel-envelope contact only. It is
                # never substituted into this C/D/E construction or score.
                q=(min if up else max)(range(i,j+1),key=lambda k:
                    float(rows[k][destination])-slope*(k-i))
                detail.update(CE_source_envelope='valid_for_declared_geometry_scope',
                    D_role='confirmed_under_radius2_engineering_policy',
                    shifted_boundary_formation='invalid_under_current_clearance_policy',
                    shift_failure=dict(first=witness(failed[0]) if failed else None,
                        worst=witness(worst),formation_end_index=start+j,
                        formation_end_utc=rows[j].get('timestamp_utc'),
                        historical_contact_before_E_known=bool(failed and failed[0]<j)),
                    parallel_envelope_reference=dict(index=start+q,utc=rows[q].get('timestamp_utc'),
                        price=float(rows[q][destination]),role='Q_diagnostic_not_replacement_D',
                        substituted_for_D=False))
        if d is not None:break
        note(rejection,i,j,**detail)
        rejected_extensions+=1
    if d is None:
        # A confirmed D whose shifted line fails formation clearance is an
        # invalid construction, not an unobserved adjustment pivot.
        confirmed_shift_failures=audit['counts'].get('shifted_D_line_crosses_C_E_leg',0)
        reason=('confirmed_D_shifted_boundary_invalid' if confirmed_shift_failures==len(extensions)
                else 'clear_confirmed_adjustment_D_between_C_E_unknown')
        audit['construction_state']=reason
        return dict(base,reason=reason)
    audit['selected']=dict(C=dict(utc=rows[i].get('timestamp_utc'),price=values[i],offset_from_wave_start=i),
        D=dict(utc=rows[d].get('timestamp_utc'),price=float(rows[d][destination]),offset_from_wave_start=d),
        E=dict(utc=rows[j].get('timestamp_utc'),price=values[j],offset_from_wave_start=j),
        late_C=i>int(n*.35),D_confirmation_bar_utc=rows[d+2].get('timestamp_utc'),
        shifted_min_clearance=min(gaps))
    audit['ranked_pairs_not_evaluated']=len(extensions)-rejected_extensions-1
    price=float(rows[d][destination])
    typical_range=statistics.median(
        max(0.0, float(r['high'])-float(r['low'])) for r in rows if _valid_bar(r)) or 0.0
    span=max(1, j-i)
    counter_move=abs(values[j]-values[i])
    # The shifted line is only a useful turning-boundary candidate when the
    # opposite extension is a real counter-leg, not a two-bar noise diagonal.
    # Keep the line as a candidate for visual review, but expose the evidence
    # so the panel can refuse to call it a confirmed reversal boundary.
    d_position=(d-i)/span
    extension_strength=counter_move/max(typical_range*span, 1e-9)
    clearance_strength=gap/max(typical_range, 1e-9)
    if span >= max(8, int(n*.22)) and d_position >= .20 and d_position <= .90 and clearance_strength >= .15:
        boundary_quality='confirmed'
        boundary_reason='broad_counter_extension_with_confirmed_D_and_clearance'
    elif span >= 6 and d_position > .10:
        boundary_quality='candidate'
        boundary_reason='D_exists_but_extension_or_clearance_is_not_broad_enough'
    else:
        boundary_quality='unknown'
        boundary_reason='short_or_weak_counter_extension'
    span_fit = max(0.0, min(1.0, span / max(8.0, n * .22)))
    position_fit = max(0.0, 1.0 - abs(d_position - .55) / .55)
    strength_fit = max(0.0, min(1.0, extension_strength / .75))
    clearance_fit = max(0.0, min(1.0, clearance_strength / .50))
    boundary_components = [
        {'key': 'extension_span', 'weight': 35.0, 'value': round(span_fit, 4)},
        {'key': 'D_position', 'weight': 25.0, 'value': round(position_fit, 4)},
        {'key': 'counter_move_strength', 'weight': 20.0, 'value': round(strength_fit, 4)},
        {'key': 'clearance', 'weight': 20.0, 'value': round(clearance_fit, 4)},
    ]
    boundary_score = round(max(0.0, min(100.0,
        sum(c['weight'] * c['value'] for c in boundary_components))), 1)
    boundary_grade = 'strong' if boundary_score >= 70 else 'medium' if boundary_score >= 50 else 'weak'
    return dict(base,qualified=True,status='observed_candidate',method='opposite_extension_shift',
        direction='up' if up else 'down',start_index=start+d,start_price=price,slope=slope,
        extension_start_index=start+i,extension_end_index=start+j,
        extension_start_price=values[i],extension_end_price=values[j],
        extension_side='upper' if up else 'lower',extension_min_clearance=gap,
        shift_anchor_index=start+d,shift_anchor_utc=rows[d].get('timestamp_utc'),
        shift_anchor_price=price,established_wave_end_index=extreme,
        parent_wave_start_index=start,
        full_parent_envelope_verified=True,
        axis_slope_per_native_bar=axis_slope,
        axis_slope_mismatch_normalized=abs(slope-axis_slope)/axis_scale,
        first_observable_index=max(extreme,start+d+2),
        selection='confirmed_adjustment_extreme_between_selected_C_E',
        shift_anchor_between_extension_anchors=True,
        construction_selection='rank_complete_C_D_E_candidates',
        rejected_extension_pairs_without_D=rejected_extensions,
        extension_rank_policy='engineering_native_axis_then_span_coverage_clearance_after_full_envelope',
        intelligence={
            'quality': boundary_quality,
            'semantic_state': 'geometry_only',
            'author_state': 'unknown_until_price_contact_or_closed_confirmation',
            'reason': boundary_reason,
            'grade': boundary_grade,
            'score': boundary_score,
            'score_version': 'turning_boundary_components_v1',
            'score_basis': 'engineering_initial_components',
            'calibration_status': 'not_calibrated_to_turning_outcomes',
            'grade_thresholds': {'weak_lt': 50.0, 'medium_gte': 50.0, 'strong_gte': 70.0},
            'components': boundary_components,
            'extension_span_bars': span,
            'D_position_ratio': round(d_position, 4),
            'counter_move_price': round(counter_move, 8),
            'counter_move_per_bar': round(counter_move/span, 8),
            'typical_native_range': round(typical_range, 8),
            'extension_strength_ratio': round(extension_strength, 4),
            'clearance_strength_ratio': round(clearance_strength, 4),
            'D_confirmed_before_as_of': True,
            'uses_future_response': False,
            'research_only': True,
        },
        theoretical_projection=True,source_pdf_sha256=PDF_SOURCE_SHA256,
        future_bars_used=False,read_only=True,trade_permission=False)


def select_pdf_wave_relative_outer(bars, upward, lookback=256, *, _validated_rows=False):
    """Supplement the legacy scan with an extreme-to-pre-extreme tangent.

    Chapter 3 specifies an origin low/high and a second point BEFORE the
    opposite extreme, not the strongest radius-8 pivot in a fixed window.
    The supporting slope considers EVERY native candle. Search size and the
    minimum broad span remain engineering choices, not author wave degrees.
    No borrowed-period anchors, window-edge origins or post-extreme anchors.
    """
    offset=max(0,len(bars)-lookback)
    rows=bars[offset:];n=len(rows)
    fail=lambda reason:dict(qualified=False,unknown_reason=reason,
                            source_pdf_sha256=PDF_SOURCE_SHA256,
                            future_bars_used=False,read_only=True,trade_permission=False)
    # ``historical_book_objects`` validates one immutable native prefix once
    # and passes this private flag for every overlapping window. Direct
    # callers keep the original validation path.
    if n<12 or (not _validated_rows and not all(_valid_bar(b) for b in rows)):
        return fail('invalid_native_wave')
    values=[float(b['low' if upward else 'high']) for b in rows]
    i=(min if upward else max)(range(n),key=values.__getitem__)
    if i==0 or i>=n-2:return fail('origin_not_confirmed_inside_context')
    opposite=[float(b['high' if upward else 'low']) for b in rows]
    extreme=(max if upward else min)(range(i+1,n),key=opposite.__getitem__)
    if extreme-i<12:return fail('wave_too_short')
    slopes={k:(values[k]-values[i])/(k-i) for k in range(i+1,extreme+1)}
    j=(min if upward else max)(slopes,key=slopes.__getitem__)
    slope=slopes[j]
    if (upward and slope<=0) or (not upward and slope>=0):return fail('wrong_direction')
    if j>=extreme:return fail('second_anchor_not_before_extreme')
    if j-i<max(6,math.ceil((extreme-i)*.22)):return fail('startup_pair_not_broad')
    if j not in _local_extrema(values,upward,1):return fail('second_anchor_not_local_pivot')
    clearances=[];first_break=None
    for k in range(i+1,n):
        if k==j:continue
        level=values[i]+slope*(k-i)
        gap=(values[k]-level) if upward else (level-values[k])
        if gap<=1e-9:
            # The established wave must survive all the way to its extreme.
            # Only subsequent price action may terminate this frozen ruler.
            if k<=extreme:return fail('established_wave_contact')
            close=float(rows[k]['close'])
            if not (close<level if upward else close>level):return fail('later_wick_contact')
            first_break=k;break
        clearances.append(gap)
    typical=statistics.median(float(b['high'])-float(b['low']) for b in rows)
    required=max(typical*.005,1e-9)
    if not clearances or min(clearances)<required:return fail('insufficient_clearance')
    axis=_axis_alignment_diagnostic(rows,i,j,extreme,slope,upward)
    line=dict(qualified=True,status='observed_pdf_outer_wave_line',rule_id=PDF_RULE_ID,
        source_pdf_sha256=PDF_SOURCE_SHA256,future_bars_used=False,
        read_only=True,trade_permission=False,
        start_index=i,end_index=j,start_price=values[i],end_price=values[j],slope=slope,
        min_clearance=min(clearances),mean_clearance=sum(clearances)/len(clearances),
        clearance_required=required,anchor_count=2,anchor_span_bars=j-i,
        wave_coverage_ratio=(j-i)/(extreme-i),start_utc=rows[i].get('timestamp_utc'),
        end_utc=rows[j].get('timestamp_utc'),first_break_index=first_break,
        direction='up' if upward else 'down',anchor_selection='native_extreme_supporting_tangent',
        anchor_order_rule='second_pivot_before_opposite_extreme',double_extreme_exception=False,
        axis_alignment_score=axis['score'],axis_alignment=axis,
        axis_rank_policy='same_native_wave_axis_after_outer_clearance',
        source_rule_pages=list(PDF_TRENDLINE_RULE_PAGES),no_internal_candle_crossing=True,
        wave_relative_supplement=True,established_extreme_index=extreme+offset,
        opposite_extreme_index=extreme+offset,second_anchor_index=j+offset,
        anchor_order_proof={
            'rule':'second_pivot_before_opposite_extreme',
            'second_anchor_index':j+offset,
            'opposite_extreme_index':extreme+offset,
            'valid':j < extreme,
            'double_extreme_exception':False,
        })
    line['parallel_projection']=_parallel_projection(rows,line,upward)
    for field in ('start_index','end_index','first_break_index'):
        if line[field] is not None:line[field]+=offset
    projection=line['parallel_projection'];projection['reference_index']+=offset
    for field in ('start_index','end_index'):projection['reference_window'][field]+=offset
    return line


def select_pdf_outer_trendline(bars, upward, lookback=256, *, _validated_rows=False):
    """Select two broad outer pivots for one complete native wave.

    The first anchor is drawn from the early part of the wave and the second
    from its later middle, with a terminal guard.  This prevents two nearby
    startup/end pivots from masquerading as the line for the whole movement.
    Every candle from the first anchor through the terminal is checked; only
    the two anchors may touch the line.
    """
    source_offset = max(0, len(bars) - max(lookback, 12))
    if source_offset:
        bars = bars[source_offset:]
    n = len(bars)
    if n < 12 or (not _validated_rows and not all(_valid_bar(b) for b in bars)):
        return {"qualified": False, "status": "unknown", "unknown_reason": "insufficient_or_invalid_native_bars", "rule_id": PDF_RULE_ID,
                "source_pdf_sha256": PDF_SOURCE_SHA256, "future_bars_used": False,
                "read_only": True, "trade_permission": False}
    values = [float(b["low"] if upward else b["high"]) for b in bars]
    opposite_key = "high" if upward else "low"
    opposite_values = [float(b[opposite_key]) for b in bars]
    opposite_extreme_index = (max(range(n), key=lambda i: opposite_values[i]) if upward
                              else min(range(n), key=lambda i: opposite_values[i]))
    ranges = [max(0.0, float(b["high"]) - float(b["low"])) for b in bars]
    positive = [r for r in ranges if r > 0]
    typical = statistics.median(positive) if positive else 0.0
    radius = max(1, min(8, n // 14))
    extrema = set(_local_extrema(values, upward, radius))
    # Monotone shoulders still need a usable outer candidate.
    first_end = max(2, int(math.floor(n * 0.45)))
    second_start = min(n - 2, int(math.ceil(n * 0.45)))
    key = (lambda i: values[i]) if not upward else (lambda i: -values[i])
    candidates = set(extrema)
    # A chart-window edge is not a pivot.  Using it as an anchor makes a
    # partially visible move look like the book's complete wave and was a
    # common source of long lines starting at the left border.  Real local
    # extrema, plus broad interior quartile candidates below, are admissible.
    candidates.add(max(range(radius, first_end), key=key))
    candidates.add(max(range(second_start, max(second_start + 1, n - 1)), key=key))
    candidates = sorted(candidates)
    min_sep = max(6, int(math.ceil(n * 0.22)))
    # The PDF examples leave room after the second outer pivot for the trend
    # to develop and then reach the pivot/break.  A late terminal spike is a
    # response/ending phase, not a second anchor for the preceding wave.
    terminal_guard = max(2, int(math.ceil(n * 0.18)))
    origin_limit = max(2, int(math.floor(n * 0.35)))
    terminal_limit = n - 1 - terminal_guard
    double_ranges = _double_extreme_neckline_ranges(
        bars, upward, opposite_extreme_index, radius, typical)
    best = None
    for i in candidates:
        if i > origin_limit:
            continue
        for j in candidates:
            if j <= i or j - i < min_sep or j < second_start or j > terminal_limit:
                continue
            # Book chapter 3: the second point is on the pre-extreme side of
            # the wave.  A point after the highest/lowest price is accepted
            # only when the surrounding movement is a confirmed double
            # top/bottom neckline case.
            double_exception_for_pair = any(
                left < j < right and j > opposite_extreme_index
                for left, right in double_ranges)
            if j >= opposite_extreme_index and not double_exception_for_pair:
                continue
            slope = (values[j] - values[i]) / (j - i)
            if (upward and slope <= 0) or (not upward and slope >= 0):
                continue
            clearances = []
            valid = True
            first_break_index = None
            for k in range(i + 1, n):
                if k == j:
                    continue
                line_value = values[i] + slope * (k - i)
                clearance = (values[k] - line_value) if upward else (line_value - values[k])
                if clearance <= 0:
                    # The line is required to remain outside the complete
                    # wave up to the second anchor.  Once the later price
                    # action closes through it, that first opposite break is
                    # the intended display endpoint; a wick-only contact
                    # before a close break still violates the no-touch rule.
                    if k < j:
                        valid = False
                    else:
                        close = float(bars[k]["close"])
                        close_break = (upward and close < line_value) or (not upward and close > line_value)
                        if not close_break:
                            valid = False
                            break
                        # Geometry ends at the observed break. Missing later
                        # force confirmation must not erase a valid wave.
                        first_break_index = k
                    break
                clearances.append(clearance)
            if not valid or not clearances:
                continue
            required = max(typical * 0.005, 1e-9)
            if min(clearances) < required:
                continue
            # R05: after the strict outer-side test, prefer the candidate
            # whose two rails describe the same wave axis.  This is a
            # deterministic tie-break only; it cannot rescue a line that
            # touches/crosses an interior candle or crosses a wave boundary.
            from .book_calculation_scope import independent_axis_enabled
            axis = (_axis_alignment_diagnostic(
                bars, i, j, opposite_extreme_index, slope, upward,reference_start=0)
                if independent_axis_enabled() else _axis_alignment_diagnostic(
                    bars, i, j, opposite_extreme_index, slope, upward))
            # After the PDF's hard outer-side/no-contact gates, prefer the
            # candidate whose body axis belongs to the same native movement.
            # Span and coverage remain deterministic tie-breakers; they must
            # not allow a long but off-axis tangent to outrank a shorter,
            # structurally central line.  This is a ranking rule only: it
            # cannot rescue a candidate that failed a hard geometry gate.
            coverage = (j - i) / max(1, opposite_extreme_index - i)
            score = (axis.get("ranking_value",axis["score"]), j - i, round(coverage, 8), n - i,
                     min(clearances), int(i in extrema), int(j in extrema))
            if best is None or score > best["_rank"]:
                best = {
                    "qualified": True,
                    "status": "observed_pdf_outer_wave_line",
                    "rule_id": PDF_RULE_ID,
                    "source_pdf_sha256": PDF_SOURCE_SHA256,
                    "start_index": i,
                    "end_index": j,
                    "start_price": values[i],
                    "end_price": values[j],
                    "slope": slope,
                    "min_clearance": min(clearances),
                    "mean_clearance": sum(clearances) / len(clearances),
                    "clearance_required": required,
                    "anchor_count": 2,
                    "anchor_span_bars": j - i,
                    "wave_coverage_ratio": (j - i) / max(1, n - 1),
                    "axis_alignment_score": axis["score"],
                    "axis_alignment": axis,
                    "axis_rank_policy": axis.get("rank_policy","axis_consistency_then_span_after_outer_clearance"),
                    "start_utc": bars[i].get("timestamp_utc"),
                    "end_utc": bars[j].get("timestamp_utc"),
                    "first_break_index": first_break_index,
                    "direction": "up" if upward else "down",
                    "anchor_selection": "broad_outer_pivots;startup_and_terminal_short_pairs_rejected",
                    "anchor_order_rule": ("double_top_neckline_exception" if double_exception_for_pair
                                           else "second_pivot_before_opposite_extreme"),
                    "double_extreme_exception": bool(double_exception_for_pair),
                    "opposite_extreme_index": opposite_extreme_index,
                    "second_anchor_index": j,
                    "anchor_order_proof": {
                        "rule": ("double_top_neckline_exception" if double_exception_for_pair
                                 else "second_pivot_before_opposite_extreme"),
                        "second_anchor_index": j,
                        "opposite_extreme_index": opposite_extreme_index,
                        "valid": bool(j < opposite_extreme_index or double_exception_for_pair),
                        "double_extreme_exception": bool(double_exception_for_pair),
                    },
                    "source_rule_pages": list(PDF_TRENDLINE_RULE_PAGES),
                    "no_internal_candle_crossing": True,
                    "future_bars_used": False,
                    "read_only": True,
                    "trade_permission": False,
                    "_rank": score,
                }
    if best is None:
        return {"qualified": False, "status": "unknown", "unknown_reason": "no_broad_clear_outer_pair",
                "rule_id": PDF_RULE_ID, "source_rule_pages": list(PDF_TRENDLINE_RULE_PAGES),
                "source_pdf_sha256": PDF_SOURCE_SHA256, "no_internal_candle_crossing": False,
                "future_bars_used": False, "read_only": True, "trade_permission": False}
    best["parallel_projection"] = _parallel_projection(bars, best, upward)
    if source_offset:
        for key in ("start_index", "end_index", "first_break_index"):
            if best.get(key) is not None:
                best[key] += source_offset
        projection = best.get("parallel_projection") or {}
        if projection.get("reference_index") is not None:
            projection["reference_index"] += source_offset
        window = projection.get("reference_window") or {}
        for key in ("start_index", "end_index"):
            if window.get(key) is not None:
                window[key] += source_offset
    best.pop("_rank", None)
    return best
