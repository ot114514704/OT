"""Observe frozen Book rulers after their clean drawing segment has ended.

These are boundary facts, not force scores or completed reversal signals.
No source object/anchor/force model is changed by this display supplement.
"""
from datetime import datetime
from decimal import Decimal
from hashlib import sha256
from .trend_trade_method_full_pipeline import _closed, _closed_at

ROLES={'historical_book_outer','single_outer_trendline','structural_wave_outer',
       'book_shifted_turning_boundary',
       # The owned-axis selector is an additive producer.  Its lines are
       # built after the legacy scene's first boundary pass, so they must be
       # admitted here as the same frozen OUTER/RETURN source families.
       'owned_wave_primary','owned_wave_turning'}

def boundary_event_objects(bars,timeframe,cutoff,existing):
    rows=_closed(bars,timeframe,cutoff)
    if any(r.get('timeframe',timeframe)!=timeframe for r in rows):
        return [],dict(status='CROSS_TIMEFRAME')
    epochs={datetime.fromisoformat(r['timestamp_utc'].replace('Z','+00:00')).timestamp():i for i,r in enumerate(rows)}
    closes=[_closed_at(r,timeframe) for r in rows]
    out=[];seen=set();skipped={};audited=0
    def skip(reason):skipped[reason]=skipped.get(reason,0)+1
    for source in existing:
        ev=source.get('evidence',{});role=ev.get('display_role')
        if role not in ROLES or source.get('timeframe')!=timeframe:continue
        identity=ev.get('ruler_identity') or ev.get('book_wave_ruler_identity')
        if not identity or len(identity) not in (2,3):continue
        if any(float(point[0]) not in epochs for point in identity):skip('ANCHOR_OUTSIDE_CONTEXT');continue
        # The object clock may already include a later display/event end.
        # Boundary observation must begin at the immutable construction clock,
        # otherwise a line is incorrectly treated as broken at birth.
        construction_known=ev.get('construction_known_at_utc') or source.get('known_at_utc')
        if construction_known is None:skip('UNKNOWN_CONSTRUCTION_CLOCK');continue
        known=construction_known
        if known>cutoff:continue
        (ta,pa),(tb,pb)=identity[:2];i,j=epochs[float(ta)],epochs[float(tb)]
        if j<=i:skip('INVALID_ANCHOR_ORDER');continue
        start,price=(epochs[float(identity[2][0])],identity[2][1]) if len(identity)==3 else (i,pa)
        price=Decimal(str(price));delta=Decimal(str(pb))-Decimal(str(pa));span=j-i
        up=ev.get('direction')=='up'
        is_turning=role in ('book_shifted_turning_boundary','owned_wave_turning')
        key=(tuple(tuple(v) for v in identity),known,up,is_turning)
        if key in seen:continue
        seen.add(key)
        observed=[k for k in range(start,len(rows)) if closes[k]<=known]
        if not observed:skip('CONSTRUCTION_OUTSIDE_CONTEXT');continue
        born=observed[-1]
        def numerator(k):return price*span+delta*(k-start)
        def gap(k,field):
            value=Decimal(str(rows[k][field]))*span
            return value-numerator(k) if up else numerator(k)-value
        if gap(born,'close')<0:
            skip('ALREADY_BROKEN_WHEN_CONSTRUCTION_KNOWN');continue
        contact=None;broken=None
        for k in range(born+1,len(rows)):
            if contact is None and gap(k,'low' if up else 'high')<=0:contact=k
            if gap(k,'close')<0:
                broken=k;break
        audited+=1
        for event,k in [('wick_contact',contact),('first_close_break',broken)]:
            if k is None or event=='wick_contact' and k==broken:continue
            label=('拐点线' if is_turning else '趋势线')
            label+=('影线触及·未收破' if event=='wick_contact' else ('触线并收破' if contact==broken else '触线后首次收破'))
            at=float(datetime.fromisoformat(rows[k]['timestamp_utc'].replace('Z','+00:00')).timestamp())
            oid='b'+sha256(f'{timeframe}|boundary_event|{key}|{event}|{at}'.encode()).hexdigest()[:23]
            # Bind the existing Book first-response pipeline to the frozen
            # ruler event.  The event clock remains the close of this bar;
            # follow-through, retest and invalidation clocks are separate.
            force=dict(status='unknown', reason='no_closed_break')
            pullback=dict(status='unknown', reason='break_unknown')
            invalidation=dict(status='unknown', reason='break_unknown')
            stop_reference=dict(status='unknown', reason='no_closed_break_for_B')
            stop_adjustment=dict(status='unknown', reason='stop_reference_unknown')
            if event=='first_close_break':
                # ``identity`` is [A,B] for an outer ruler and [A,B,D] for
                # a C-E line translated to D.  The event geometry above is
                # already evaluated from D when the third point exists, so
                # the first-response pipeline must receive the same native
                # line.  Passing C as the start index with D's price makes
                # ``pre_break_origin`` search the wrong segment and can
                # attach B/stop-reference evidence to a different wave.
                line_start = start
                line_end = start + span
                line_model=dict(qualified=True, start_index=line_start,
                    end_index=line_end, start_price=float(price),
                    end_price=float(price+delta), slope=float(delta/span),
                    direction='up' if up else 'down', known_at_utc=known,
                    source_geometry='RETURN_CE_D' if len(identity)==3 else 'OUTER')
                break_event=dict(status='observed_candidate',break_index=k,
                    break_utc=rows[k]['timestamp_utc'],break_price=float(rows[k]['close']),
                    break_level=float(numerator(k)/span),
                    break_side='down' if up else 'up',line_direction='up' if up else 'down')
                from .trend_trade_method_full_pipeline import (
                    evaluate_break_force, classify_pullback_and_retest,
                    invalidate_structure)
                from .trend_trade_method_patterns import (
                    build_stop_reference, build_stop_adjustment_candidates)
                force=evaluate_break_force(rows,break_event,timeframe,cutoff)
                stop_reference=build_stop_reference(
                    rows,timeframe,cutoff,{},line_model,break_event)
                pullback=classify_pullback_and_retest(
                    rows,break_event,timeframe,cutoff,stop_reference)
                invalidation=invalidate_structure(
                    rows,break_event,timeframe,cutoff,stop_reference)
                stop_adjustment=build_stop_adjustment_candidates(
                    rows,timeframe,cutoff,stop_reference,break_event)
            out.append(dict(id=oid,layer='breakout',kind='line',timeframe=timeframe,
                points=[[at,float(rows[k]['low'])],[at,float(rows[k]['high'])]],
                known_at_utc=closes[k],status=event,owner_id=source['id'],
                source_id='book_frozen_boundary_event_v1',evidence_ids=[source['id']],unknown=False,
                label=f'{label} | {timeframe} | '+rows[k]['timestamp_utc']+' | 单线事实，非反转确认',
                evidence=dict(display_role='book_boundary_event',event_kind=event,
                    source_line_id=source['id'],source_line_role=role,
                    source_line_known_at=known,source_object_known_at=source.get('known_at_utc'),
                    frozen_ruler_identity=identity,source_timeframe=timeframe,
                    event_bar_utc=rows[k]['timestamp_utc'],event_known_at_utc=closes[k],
                    line_price=float(numerator(k)/span),close=float(rows[k]['close']),
                    break_force=force,pullback_retest=pullback,
                    invalidation=invalidation,stop_reference=stop_reference,
                    stop_adjustment=stop_adjustment,
                    force_known_at_utc=force.get('known_at_utc'),
                    pullback_known_at_utc=pullback.get('known_at_utc'),
                    invalidation_known_at_utc=invalidation.get('known_at_utc'),
                    force_binding='frozen_native_ruler_first_response_pipeline',
                    first_contact_utc=rows[contact]['timestamp_utc'] if contact is not None else None,
                    first_close_break_utc=rows[broken]['timestamp_utc'] if broken is not None and k>=broken else None,
                    same_bar_touch_and_close_break=contact==broken,
                    state_as_of_utc=closes[k],intrabar_order='unknown',
                    trend_reversal_confirmed=False,force_score=None,
                    construction_geometry_unchanged=True,read_only=True,trade_permission=False)))
    ids={o['id'] for o in existing}
    return [o for o in out if o['id'] not in ids],dict(status='EVALUATED',rulers_observed=audited,
        events=len(out),skipped=skipped,source_objects_modified=0,
        force_calibration_unchanged=True)
