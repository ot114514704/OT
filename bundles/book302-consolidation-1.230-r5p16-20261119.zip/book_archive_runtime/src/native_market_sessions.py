"""Coarse XAUUSD bar coverage on the feed's verified broker clock.

TMGM publishes weekday gold sessions starting after 01:00 server time,
ending shortly before midnight; Saturday/Sunday are closed. The hour-grid
policy below only explains whole closed H1-or-larger buckets. It cannot
excuse a missing quote during an open session, a holiday, or an M1 gap.
"""
from datetime import timedelta
from functools import lru_cache

SOURCE_URL = 'https://www.tmgm.com/en/trading/trading-hours'
METHOD = 'tmgm_xauusd_coarse_session_coverage_v1'
DAILY_LABEL_CALENDAR = 'tmgm_native_daily_weekend_labels_v1'


def research_calendar(snapshot, timeframe):
    """Resolve coverage separately from the quote's wall-clock offset.

    Native D1 responses also use unshifted midnight broker-date labels. A
    verified zero-offset tick does not turn Saturday/Sunday date labels into
    missing daily bars. This opt-in explains only a Friday-to-Monday D1 pair;
    it neither certifies historical UTC/DST nor supplies an intraday schedule.
    Each pair must still have the exact date-label shape below. No later bar,
    target outcome, or inferred holiday participates in this decision.
    """
    offset = session_offset(snapshot)
    if offset is not None:
        return offset
    clock = snapshot.get('source_clock_alignment') or {}
    history = (snapshot.get('chart_history') or {}).get(timeframe) or {}
    provider = snapshot.get('provider') or ''
    if (timeframe == 'D1' and snapshot.get('instrument') == 'XAUUSD'
            and provider.casefold().startswith('trademaxglobal')
            and history.get('source_mode') == 'native_period_bars'
            and clock.get('provider_server') == provider
            and clock.get('status') == 'verified_against_host_clock'
            and type(clock.get('bar_timestamp_offset_seconds')) is int
            and clock['bar_timestamp_offset_seconds'] == 0
            and clock.get('normalization_applied_to_bars') is False
            and clock.get('bar_time_basis') == 'utc_datetime_query'):
        return DAILY_LABEL_CALENDAR
    return None


def daily_label_weekend(left, right, minutes):
    return (minutes == 1440 and right-left == timedelta(days=3)
            and left.weekday() == 4 and right.weekday() == 0
            and all(not (t.hour or t.minute or t.second or t.microsecond) for t in (left,right)))


def session_offset(snapshot):
    alignment = snapshot.get('source_clock_alignment') or {}
    provider = snapshot.get('provider') or ''
    offset = alignment.get('bar_timestamp_offset_seconds')
    if (not provider.casefold().startswith('trademaxglobal')
            or snapshot.get('instrument') != 'XAUUSD'
            or alignment.get('provider_server') != provider
            or alignment.get('status') != 'verified_against_host_clock'
            or alignment.get('normalization_applied_to_bars') is not True
            or isinstance(offset, bool) or offset not in (7200, 10800)):
        return None
    return offset


@lru_cache(maxsize=65536)
def bucket_has_trading(stamp, minutes, offset):
    """Whether any source hour in this nominal interval has a weekday session.

    Offset is the clock normalization used for THESE bars. This does not
    infer historical DST offsets from today's clock or repair old timestamps.
    """
    if (offset not in (7200,10800) or minutes < 60 or minutes % 60
            or stamp.minute or stamp.second or stamp.microsecond):
        raise ValueError('coarse session policy requires aligned hourly buckets')
    local = stamp + timedelta(seconds=offset)
    return any((local+timedelta(hours=i)).weekday() < 5
               and (local+timedelta(hours=i)).hour >= 1
               for i in range(minutes//60))


@lru_cache(maxsize=65536)
def adjacent_native_bars(left, right, minutes, offset=None):
    duration = timedelta(minutes=minutes)
    distance = right-left
    if distance == duration:
        return True
    if offset == DAILY_LABEL_CALENDAR:
        return daily_label_weekend(left, right, minutes)
    if (offset is None or minutes < 60 or minutes % 60 or distance <= duration
            or distance % duration or distance > timedelta(days=14)):
        return False
    missing = left+duration
    while missing < right:
        try:
            if bucket_has_trading(missing,minutes,offset):
                return False
        except ValueError:
            return False
        missing += duration
    return True


@lru_cache(maxsize=65536)
def adjacent_research_bars(left, right, minutes, offset=None):
    """Opt-in subhour *research* coverage using the published gold schedule.

    Rechecked 2026-10-07 at SOURCE_URL: weekday open 01:01 server clock;
    Mon-Thu end 23:59, Fri 23:55. End minutes remain conservatively open.
    Only missing wholly closed buckets are explained. Open-session missing
    quotes, exceptional holidays and historical clock provenance stay unknown.
    This does not change the legacy execution/source-admission policy above.
    """
    if adjacent_native_bars(left,right,minutes,offset):
        return True
    duration=timedelta(minutes=minutes)
    distance=right-left
    if (offset not in (7200,10800) or minutes not in (1,5,15,30)
            or distance<=duration or distance%duration or distance>timedelta(days=4)
            or left.second or left.microsecond or right.second or right.microsecond
            or left.minute%minutes or right.minute%minutes):
        return False
    missing=left+duration
    while missing<right:
        for minute in range(minutes):
            local=missing+timedelta(seconds=offset,minutes=minute)
            minute_of_day=local.hour*60+local.minute
            end=23*60+(55 if local.weekday()==4 else 59)
            if local.weekday()<5 and 61<=minute_of_day<=end:
                return False
        missing+=duration
    return True
