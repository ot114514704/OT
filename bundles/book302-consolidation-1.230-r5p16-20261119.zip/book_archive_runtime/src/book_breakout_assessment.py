"""Same-ruler geometry and two independent, causal boundary-break scores.

The seven force weights are the existing engineering score, applied to a
new, explicitly UNFITTED two-candle boundary domain. No book win rate or
old B-C calibration is borrowed. Full B-C force remains a separate fact.
"""
from fractions import Fraction
from copy import deepcopy
from hashlib import sha256
import json
from statistics import mean
from math import isfinite
from .book_first_response_leg import clock,close_time,MINUTES
from .book_boundary_freeze import ruler_identity
from .force_strength_model import score,grade
from .pdf_trendline_block import _parallel_projection


def digest(value):
    return sha256(json.dumps(value,sort_keys=True,allow_nan=False).encode()).hexdigest()[:24]


def _native_CDE_proof(rows,turning,origin_index,direction,line=None):
    """Recheck the chapter-4 construction at the consumer, not just its IDs.

    PDF81/83: D is the corresponding C--E adjustment extreme. A different
    native candle is not an interchangeable shift anchor. Radius2 and the
    first-equal-extreme tie policy mirror the existing producer; neither is
    an author wave degree. Only the construction prefix may supply proof.
    """
    base=dict(schema='book_native_CDE_consumer_proof_v1',qualified=False,
        source_pdf_pages=[81,83,87],author_wave_degree_verified=False,
        engineering_policy=dict(D_confirmation_radius=2,equal_D_tie='first_chronological'),
        automatic_trade_permission=False)
    def fail(reason):return dict(base,reason=reason)
    try:
        if (line is not None and not line.get('qualified')) or not turning.get('qualified'):return fail('CDE_construction_not_qualified')
        if turning.get('method')!='opposite_extension_shift':return fail('CDE_method_not_supported')
        if line is not None and (not line.get('wave_id') or turning.get('parent_wave_id')!=line['wave_id']):return fail('CDE_parent_wave_mismatch')
        keys=('extension_start','start','extension_end')
        indices=[turning[k+'_index'] for k in keys];observable=turning['first_observable_index']
        if any(isinstance(i,bool) or not isinstance(i,int) for i in [*indices,observable,origin_index]):return fail('CDE_native_indices_invalid')
        if not 0<=origin_index<=indices[0]<indices[1]<indices[2]<=observable<len(rows):return fail('CDE_native_order_invalid')
        if turning.get('direction')!=direction or direction not in ('up','down'):return fail('CDE_parent_direction_mismatch')
        extension='high' if direction=='up' else 'low';shift='low' if extension=='high' else 'high'
        up=direction=='up';c,d,e=indices
        for key,index,field in zip(keys,indices,(extension,shift,extension)):
            price=turning[key+'_price']
            if isinstance(price,bool) or not isfinite(float(price)) or price<=0 or float(price)!=float(rows[index][field]):return fail('CDE_anchor_price_not_native')
        from .book_calculation_scope import independent_axis_enabled
        if independent_axis_enabled():
            from .book_exact_envelope import decimal
            prices={field:[decimal(r[field]) for r in rows[:observable+1]] for field in (extension,shift)}
        else:
            prices={field:[Fraction(str(r[field])) for r in rows[:observable+1]] for field in (extension,shift)}
        if any(not isfinite(float(v)) or v<=0 for values in prices.values() for v in values):return fail('CDE_native_prices_invalid')
        slope=(prices[extension][e]-prices[extension][c])/(e-c)
        if (not isfinite(float(turning['slope'])) or isinstance(turning['slope'],bool)
                or abs(float(turning['slope'])-float(slope))>1e-10*max(1,abs(float(slope)))):return fail('CDE_slope_mismatch')
        sign=1 if up else -1
        if sign*slope<=0:return fail('CDE_extension_not_advancing_in_parent_direction')
        actual=(min if up else max)(range(c+1,e),key=lambda k:prices[shift][k])
        base.update(anchors=dict(C=c,D=d,E=e),actual_adjustment_extreme_index=actual,
            construction_through_index=observable,D_confirmation_through_index=d+2)
        if d!=actual:return fail('D_not_C_E_adjustment_extreme')
        if d-2<origin_index or d+2>e:return fail('D_confirmation_not_inside_C_E')
        if any(sign*(prices[shift][d]-prices[shift][k])>0 for k in range(d-2,d+3)):
            return fail('D_local_extreme_unconfirmed')
        from .book_exact_envelope import crosses
        if crosses(prices[extension],slope,c,(k for k in range(c+1,observable+1) if k!=e),sign):
            return fail('C_E_extension_crosses_or_touches_native_bar')
        # A cached early-C construction must not bypass the producer's
        # whole-wave envelope test. Scores and entry share this proof.
        if line is not None or turning.get('parent_wave_start_index') is not None:
            if (turning.get('parent_wave_start_index') is not None
                    and turning['parent_wave_start_index'] != origin_index):
                return fail('CDE_parent_wave_start_mismatch')
            if crosses(prices[extension],slope,c,range(origin_index,c),sign):
                return fail('earlier_parent_wave_outside_C_E_extension')
        if crosses(prices[shift],slope,d,range(d+1,e+1),-sign):
            return fail('shifted_D_line_crosses_C_E_leg')
        if ('shift_anchor_index' in turning and (type(turning['shift_anchor_index']) is not int or turning['shift_anchor_index']!=d)
                or 'shift_anchor_price' in turning and turning['shift_anchor_price']!=turning['start_price']):
            return fail('CDE_shift_anchor_alias_mismatch')
        return dict(base,qualified=True,reason=None,
            checks=['native_C_D_E_order_and_prices','advancing_C_E','own_interval_D_extreme',
                    'D_radius2_known_by_E','clear_C_E_extension','clear_shifted_D_through_E'],
            proof_scope='native_construction_geometry_not_author_degree_or_entry')
    except (KeyError,IndexError,TypeError,ValueError,ArithmeticError):return fail('CDE_native_source_incomplete')


def native_turning_source_proof(rows,line,turning):
    from .book_owned_scope import resolve_owned_scope
    try:
        scope=resolve_owned_scope(rows,line)
        if scope['binding'] is not None and turning.get('owned_scope_binding')!=scope['binding']:
            return dict(qualified=False,reason='CDE_owned_scope_binding_mismatch',automatic_trade_permission=False)
    except (KeyError,ValueError,TypeError,IndexError) as error:
        return dict(qualified=False,reason='CDE_owned_scope_unavailable',diagnostic=str(error),automatic_trade_permission=False)
    proof=_native_CDE_proof(rows,turning,scope['start_index'],line.get('direction'),line)
    if scope['binding'] is not None:
        proof.update(owned_scope_binding=scope['binding'],range_policy=scope['policy'])
    return proof


def native_turning_geometry_proof(rows,turning):
    """Standalone CDE geometry; does not manufacture a parent outer ruler."""
    proof=_native_CDE_proof(rows,turning,turning.get('parent_wave_start_index',0),turning.get('direction'))
    return dict(proof,parent_outer_binding='not_supplied_geometry_only')


def native_turning_source_valid(rows,line,turning):
    return native_turning_source_proof(rows,line,turning)['qualified']


def assess_breakouts(bars,timeframe,cutoff,line,turning,outer_event,turning_event):
    rows=[r for r in bars if clock(close_time(r,timeframe))<=clock(cutoff)]
    base=dict(schema='book_boundary_breakout_assessment_v1',timeframe=timeframe,as_of_utc=cutoff,
        automatic_trade_permission=False,source_pdf_pages=[131,132,133,135,136,137,279,280],
        score_semantics='engineering_geometry_and_boundary_response_not_probability',
        calibration_status='unfitted_boundary_two_candle_domain',author_wave_degree_verified=False,
        boundaries={},joint=dict(state='unknown',weakest_breakout_score=None))
    def fail(reason):return dict(base,status='unknown',reason=reason)
    identity=ruler_identity(rows,line,timeframe)
    if not identity or not line.get('qualified') or line.get('direction') not in ('up','down'):
        return fail('native_outer_source_unavailable')
    field='high' if line['direction']=='down' else 'low'
    if any(isinstance(line[k+'_price'],bool) or not isfinite(float(line[k+'_price']))
            or float(line[k+'_price'])!=float(rows[line[k+'_index']][field]) for k in ('start','end')):
        return fail('outer_anchor_price_not_native')
    if any(r.get('timeframe',timeframe)!=timeframe for r in rows):return fail('foreign_native_timeframe')
    for field in ('provider','symbol'):
        values={r.get(field) for r in rows if r.get(field) is not None}
        if len(values)>1:return fail('mixed_native_'+field)
        base[field]=next(iter(values),None)
    source=dict(ruler=identity,provider=base.get('provider'),symbol=base.get('symbol'))
    phase_id='book_break_phase:'+digest(source)
    base.update(phase_id=phase_id,source_identity=source,direction='up' if line['direction']=='down' else 'down')
    sign=1 if base['direction']=='up' else -1
    events={'outer':outer_event,'turning':turning_event}
    first=min((e['break_index'] for e in events.values() if e.get('status')=='observed_candidate'
        and isinstance(e.get('break_index'),int) and not isinstance(e['break_index'],bool)
        and 0<=e['break_index']<len(rows)),default=len(rows))
    # Recompute existing channel geometry strictly BEFORE the first boundary
    # event. The later response must not improve its own source's score.
    geometry=None
    if line['end_index']<first and line['start_index']<first-1:
        frozen=dict(line,first_break_index=None)
        geometry=_parallel_projection(rows[:first],frozen,line['direction']=='up')['intelligence']
    turning_proof=native_turning_source_proof(rows,line,turning)
    turning_native=turning_proof['qualified']
    turning_bound=(turning.get('qualified') and turning.get('method')=='opposite_extension_shift'
        and turning.get('parent_wave_id')==line.get('wave_id') and bool(line.get('wave_id')) and turning_native)
    models={'outer':(line['start_index'],line['start_price'],line['slope'],line['end_index'],line.get('known_at_utc'))}
    if turning_bound:
        models['turning']=(turning['start_index'],turning['start_price'],turning['slope'],
            turning['first_observable_index'],turning.get('known_at_utc'))
        native=lambda index,price:[rows[index]['timestamp_utc'],price] if isinstance(index,int) and 0<=index<len(rows) else [None,price]
        turning_identity=[native(turning.get('extension_start_index'),turning.get('extension_start_price')),
            native(turning.get('extension_end_index'),turning.get('extension_end_price')),
            native(turning['start_index'],turning['start_price'])]
        base['boundary_pair_id']='book_break_pair:'+digest([phase_id,turning_identity])
    assessments={}
    for name,event in events.items():
        result=dict(boundary=name,phase_id=phase_id,status='waiting_boundary',breakout_score=None,
            geometry_score=None,automatic_trade_permission=False,geometry=None)
        if name=='turning':
            result['native_construction_validation']=turning_proof
            if turning.get('diagnostic_phase_id')==phase_id:
                result['rejected_native_construction_validation']=deepcopy(turning.get('native_construction_validation') or {})
        if name not in models:
            reason=('turning_construction_not_qualified' if not turning.get('qualified') else
                'turning_method_not_supported' if turning.get('method')!='opposite_extension_shift' else
                'turning_not_bound_to_outer_wave' if turning.get('parent_wave_id')!=line.get('wave_id') or not line.get('wave_id') else
                'turning_native_construction_invalid')
            result.update(status='unknown',reason=reason,construction_reason=turning.get('reason'),
                construction_audit=deepcopy(turning.get('construction_audit') or {}))
            assessments[name]=result;continue
        start,price,slope,observable,construction=models[name]
        geometry_fact=geometry if name=='outer' else turning.get('intelligence')
        own_break=event.get('break_index') if event.get('status')=='observed_candidate' else len(rows)
        result['native_boundary_identity']=identity['anchors'] if name=='outer' else turning_identity
        result['boundary_id']=name+':'+digest([phase_id,result['native_boundary_identity']])
        if geometry_fact and (name=='outer' or isinstance(own_break,int) and turning['first_observable_index']<own_break):
            result.update(geometry_score=geometry_fact.get('score'),geometry=geometry_fact,
                geometry_evaluation_end_utc=rows[first-1]['timestamp_utc'] if name=='outer' else rows[turning['first_observable_index']]['timestamp_utc'])
        if name=='outer':slope=(Fraction(str(line['end_price']))-Fraction(str(line['start_price'])))/(line['end_index']-start)
        elif all(turning.get(k) is not None for k in ('extension_start_price','extension_end_price','extension_start_index','extension_end_index')):
            slope=(Fraction(str(turning['extension_end_price']))-Fraction(str(turning['extension_start_price'])))/(turning['extension_end_index']-turning['extension_start_index'])
        else:slope=Fraction(str(slope))
        level=lambda i:Fraction(str(price))+slope*(i-start)
        if event.get('status')!='observed_candidate':
            assessments[name]=result;continue
        i=event.get('break_index')
        if (isinstance(i,bool) or not isinstance(i,int) or not 0<=observable<i<len(rows)
                or event.get('break_utc')!=rows[i]['timestamp_utc'] or event.get('break_side')!=base['direction']
                or sign*(Fraction(str(rows[i]['close']))-level(i))<=0):
            result.update(status='unknown',reason='event_does_not_match_native_boundary');assessments[name]=result;continue
        if any(sign*(Fraction(str(rows[k]['close']))-level(k))>0 for k in range(observable+1,i)):
            result.update(status='unknown',reason='event_not_first_native_closed_break');assessments[name]=result;continue
        event_close=close_time(rows[i],timeframe)
        try:
            known=max((construction,event.get('known_at_utc') or event_close,event_close),key=clock)
            if clock(known)>clock(cutoff):raise ValueError('future clock')
        except (ValueError,TypeError):
            result.update(status='unknown',reason='source_knowledge_unavailable');assessments[name]=result;continue
        result.update(break_index=i,break_utc=rows[i]['timestamp_utc'],event_closed_at_utc=event_close,
            construction_known_at_utc=construction,event_known_at_utc=known,
            source_timing='known_before_break' if clock(construction)<=clock(rows[i]['timestamp_utc']) else 'historical_reconstruction')
        if i+1>=len(rows):
            result.update(status='pending_follow_close',known_at_utc=known);assessments[name]=result;continue
        if (clock(rows[i+1]['timestamp_utc'])-clock(rows[i]['timestamp_utc'])).total_seconds()!=MINUTES[timeframe]*60:
            result.update(status='unknown',reason='follow_native_continuity_unknown');assessments[name]=result;continue
        if i<15:
            result.update(status='unknown',reason='insufficient_pre_break_normalisation');assessments[name]=result;continue
        prior=rows[i-15:i]
        atr=mean(max(float(b['high'])-float(b['low']),abs(float(b['high'])-float(a['close'])),
            abs(float(b['low'])-float(a['close']))) for a,b in zip(prior,prior[1:]))
        if atr<=0:
            result.update(status='unknown',reason='zero_pre_break_range');assessments[name]=result;continue
        a,b=rows[i:i+2];move=sign*(float(b['close'])-float(a['close']))
        ranges=[float(r['high'])-float(r['low']) for r in (a,b)]
        overlap=max(0,min(float(a['high']),float(b['high']))-max(float(a['low']),float(b['low'])))
        features=dict(height_atr=max(0,move)/atr,speed_atr=max(0,move)/atr,
            efficiency=1. if move>0 else 0.,directional_close=1. if move>0 else 0.,
            body=sum(max(0,sign*(float(r['close'])-float(r['open']))) for r in (a,b))/max(sum(ranges),1e-12),
            close_location=mean(((float(r['close'])-float(r['low'])) if sign>0 else
                (float(r['high'])-float(r['close'])))/max(span,1e-12) for r,span in zip((a,b),ranges)),
            overlap=overlap/max(min(ranges),1e-12))
        value,components=score(features)
        closed=close_time(b,timeframe);score_known=max((known,closed),key=clock)
        result.update(status='scored',breakout_score=value,grade=grade(value),features=features,components=components,
            normalisation_through_utc=close_time(rows[i-1],timeframe),normalisation_atr=atr,
            score_event_closed_at_utc=closed,known_at_utc=score_known,
            follow_directional=move>0,follow_holds_boundary=sign*(Fraction(str(b['close']))-level(i+1))>0,
            observed_points=[[rows[i]['timestamp_utc'],float(a['close'])],[b['timestamp_utc'],float(b['close'])]],
            model_id=None,threshold_basis='existing_engineering_45_70_not_author_or_new_domain_calibration')
        from .book_boundary_dynamics import observe_boundary_dynamics
        result['dynamic_observation']=observe_boundary_dynamics(
            rows,timeframe,cutoff,i,level,sign,atr,result['boundary_id'],score_known)
        assessments[name]=result
    values=[r['breakout_score'] for r in assessments.values() if r.get('status')=='scored']
    both=len(values)==2
    base.update(status='evaluated',boundaries=assessments,
        joint=dict(state='dual_scored' if both else 'waiting_two_source_bound_scores',
            weakest_breakout_score=min(values) if both else None,
            both_follow_directional=both and all(r['follow_directional'] for r in assessments.values()),
            both_hold_boundaries=both and all(r['follow_holds_boundary'] for r in assessments.values()),
            prospective_sources=both and all(r['source_timing']=='known_before_break' for r in assessments.values()),
            averaging_unrelated_owners=False))
    return base
