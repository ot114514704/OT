"""Chapter8 candidate protection chronology, not an adopted/executed stop.

PDF264-268: E must be eligible before an E->G path can exist. Pivots use
the existing engineering radius2. The source B plan remains independent.
"""
from .book_first_response_leg import clock,close_time
from .book_stop_recovery_route import observe_owned_recovery
from decimal import Decimal


def observe_adjustment_path(rows,timeframe,cutoff,stop,raw):
    if any(raw.get(k) is None for k in ('b_price','c_index','c_price','e_index','e_price')):return raw
    sign=1 if raw['side']=='long' else -1;adverse='low' if sign>0 else 'high';favourable='high' if sign>0 else 'low'
    ci,ei=raw['c_index'],raw['e_index'];ep,cp,bp=raw['e_price'],raw['c_price'],raw['b_price']
    if sign*(cp-bp)<=0 or sign*(cp-ep)<=0:return raw
    result=dict(raw,status='pending',basis='await_C_break_or_strict_half_BC_after_E',adjustment_label='E',adjusted_reference=ep,
        reason='E_eligibility_not_observed_after_E',
        g_status='unknown_E_path_not_eligible',automatic_trade_permission=False,
        G_alternative_route_status='unknown_30pct_EF_requires_independent_same_source_dual_boundary_events',
        author_setup_verified=False,adoption_context='hypothetical_conditional_on_valid_setup_and_user_adoption',
        source_pdf_pages=[264,265,266,268,269],candidate_path=[],adopted_by_user=False,
        reference_is_executable_stop=False,stop_fill_confirmed=False,original_B_replaced=False,
        engineering_conventions=['radius2_confirmed_pivots','closed_C_and_F_cross','wick_recovery_and_protection_observation'])
    threshold=abs(Decimal(str(cp))-Decimal(str(bp)))*Decimal('0.5')
    trigger=next((i for i in range(ei+1,len(rows)) if sign*(float(rows[i]['close'])-cp)>0
        or sign*(Decimal(str(rows[i][favourable]))-Decimal(str(ep)))>threshold),None)
    result.update(recovery_threshold=float(threshold),recovery_threshold_comparison='strict_greater_than',
                  comparison_arithmetic='decimal_native_quote_values',
                  recovery_observation_start_utc=rows[ei+1]['timestamp_utc'] if ei+1<len(rows) else None)
    if trigger is None:return result
    e_ready=max(ci+2,ei+2,trigger)
    if e_ready>=len(rows):return result
    before=next((i for i in range(ei+1,e_ready+1) if sign*(float(rows[i][adverse])-ep)<0),None)
    if before is not None:
        return dict(result,reason='E_revisited_before_eligibility',g_status='unknown_E_path_not_eligible')
    basis='closed_C_break' if sign*(float(rows[trigger]['close'])-cp)>0 else 'recovery_0.5_BC'
    def stage(role,index,price,trigger_index,ready_index,basis):
        observed=close_time(rows[ready_index],timeframe)
        known=max((observed,stop.get('known_at_utc') or observed),key=clock)
        return dict(role=role,index=index,utc=rows[index]['timestamp_utc'],price=price,
            trigger_utc=rows[trigger_index]['timestamp_utc'],event_closed_at_utc=close_time(rows[trigger_index],timeframe),
            construction_known_at_utc=close_time(rows[index+2],timeframe),known_at_utc=known,basis=basis,
            timing='historical_reconstruction' if clock(known)>clock(close_time(rows[trigger_index],timeframe)) else 'observed_with_known_reference',
            status='hypothetical_reference_available',adopted_by_user=False)
    e_stage=stage('E',ei,ep,trigger,e_ready,basis);path=[e_stage]
    result.update(status='adjustment_candidate',reason=None,basis=basis,candidate_path=path,
        reference_eligible_known_at_utc=e_stage['known_at_utc'],g_status='unknown_without_confirmed_F_wave')
    fi,gi=raw.get('f_index'),raw.get('g_index');g_ready=None;g_stage=None
    if fi is not None and gi is not None:
        fp,gp=raw['f_price'],raw['g_price']
        if sign*(fp-cp)<=0 or sign*(gp-ep)<=0:
            result['g_status']='F_or_G_not_advancing_native_candidate'
        else:
            recovery=observe_owned_recovery(rows,timeframe,raw)
            result.update(G_alternative_route_status=recovery['status'],G_alternative_route=recovery)
            routes=[]
            f_trigger=next((i for i in range(gi+1,len(rows)) if sign*(float(rows[i]['close'])-fp)>0),None)
            if f_trigger is not None:
                routes.append((max(fi+2,gi+2,f_trigger,e_ready),f_trigger,'closed_F_break_after_C'))
            if recovery['status']=='observed_candidate':
                routes.append((max(recovery['ready_index'],e_ready),recovery['trigger_index'],recovery['basis']))
            if not routes:result['g_status']='pending_F_break_or_owned_30pct_recovery'
            else:
                # Preserve the first eligible route. A later F break must
                # not rewrite an already established 30%-EF chronology.
                g_ready,g_trigger,g_basis=min(routes)
                if any(sign*(float(rows[i][adverse])-gp)<0 for i in range(gi+1,min(g_ready+1,len(rows)))):
                    result['g_status']='G_revisited_before_eligibility';g_ready=None
                elif g_ready<len(rows):
                    g_stage=stage('G',gi,gp,g_trigger,g_ready,g_basis)
                    if g_basis==recovery['basis']:
                        g_stage['route_evidence']=recovery
                    result['g_status']='candidate_waiting_E_path'
                else:g_ready=None
    active=e_stage
    if g_stage and g_ready==e_ready:
        e_stage.update(status='historical_predecessor',superseded_known_at_utc=g_stage['known_at_utc'])
        path.append(g_stage);active=g_stage
    terminal=None
    for i in range(e_ready+1,len(rows)):
        if sign*(float(rows[i][adverse])-active['price'])<0:
            terminal=i
            active.update(status='hypothetical_reference_breached',breach_utc=rows[i]['timestamp_utc'],
                breach_closed_at_utc=close_time(rows[i],timeframe),
                breach_known_at_utc=max((active['known_at_utc'],close_time(rows[i],timeframe)),key=clock))
            if g_stage and i<=g_ready:
                result['g_status']='not_applied_prior_E_path_breached'
                if i==g_ready:result['event_order']='unknown_E_breach_and_G_eligibility_same_bar'
            break
        if g_stage and i==g_ready:
            active.update(status='historical_predecessor',superseded_known_at_utc=g_stage['known_at_utc'])
            path.append(g_stage);active=g_stage
    result.update(adjusted_reference=active['price'],adjustment_label=active['role'],basis=active['basis'],
        reference_eligible_known_at_utc=active['known_at_utc'],
        known_at_utc=max((active['known_at_utc'],close_time(rows[terminal if terminal is not None else -1],timeframe)),key=clock))
    if active['role']=='G':result['g_status']='adjustment_candidate' if terminal is None else 'hypothetical_reference_breached'
    if terminal is not None:
        result.update(status='adjusted_reference_breached',reason='hypothetical_adjusted_protection_crossed',
            display_end_index=terminal-1,adjusted_breach_index=terminal,
            adjusted_breach_utc=rows[terminal]['timestamp_utc'],original_B_plan_invalidated=False)
    return result
