"""Recompute same-native-source Book force; no chart maxima or order API."""
from copy import deepcopy
from math import isfinite
from .book_first_response_leg import first_response_leg,clock,close_time,MINUTES
from .book_breakout_assessment import assess_breakouts
from .force_strength_model import evaluate_strength


def owned_force_confluence(bars,timeframe,cutoff,book):
    base=dict(schema='book_owned_force_confluence_v1',as_of_utc=cutoff,timeframe=timeframe,
        state='unknown',score=None,source_binding_state='unverified',
        automatic_trade_permission=False,entry_permission=False,
        semantics='unfitted_engineering_minimum_not_author_rule_or_probability')
    def fail(reason,**facts):return dict(base,reason=reason,**facts)
    try:
        line=book.get('turning_point_line') or {};outer=book.get('first_closed_break') or {}
        response=book.get('first_response_leg') or {}
        if not response.get('source_complete') or response.get('status')!='confirmed_source':
            return fail('completed_valid_same_source_response_required')
        rows=[r for r in bars if clock(close_time(r,timeframe))<=clock(cutoff)]
        expected=first_response_leg(rows,line,outer,timeframe,cutoff,
            radius=response['terminal_confirmation_radius'])
        fields=('source_id','owner_id','source_wave_id','timeframe','direction','points','ruler_anchors')
        if any(response.get(k)!=expected.get(k) for k in fields):
            return fail('response_native_identity_mismatch')
        if expected.get('status')!='confirmed_source':return fail('response_not_valid_on_native_prefix')
        known=response['source_confirmation_utc']
        if not clock(expected['known_at_utc'])<=clock(known)<=clock(response['known_at_utc'])<=clock(cutoff):
            return fail('response_confirmation_clock_unbound')
        turning=book.get('turning_boundary') or {};second=book.get('parallel_break') or {}
        actual=assess_breakouts(rows,timeframe,cutoff,line,turning,outer,second)
        supplied=book.get('boundary_breakout_assessment') or {}
        if any(actual.get(k)!=supplied.get(k) for k in ('phase_id','boundary_pair_id','source_identity','direction')):
            return fail('boundary_pair_identity_mismatch')
        if not actual.get('boundary_pair_id'):return fail('native_boundary_pair_unavailable')
        boundary=[]
        for name in ('outer','turning'):
            a=(actual.get('boundaries') or {}).get(name,{})
            b=(supplied.get('boundaries') or {}).get(name,{})
            if a.get('status')!='scored' or b.get('status')!='scored':
                return fail('both_native_closed_breakout_scores_required')
            if any(a.get(k)!=b.get(k) for k in ('boundary_id','break_utc','breakout_score','geometry_score')):
                return fail('boundary_score_or_geometry_mismatch')
            if not clock(a['known_at_utc'])<=clock(b['known_at_utc'])<=clock(cutoff):
                return fail('boundary_score_clock_unbound')
            for value in (a['geometry_score'],a['breakout_score']):
                if isinstance(value,bool) or not isfinite(float(value)) or not 0<=float(value)<=100:
                    return fail('boundary_score_invalid')
            boundary.append(deepcopy(b))
        seconds=MINUTES[timeframe]*60
        # Source scoring stops at its first actual confirmation. Later price
        # bars can neither repair old gaps nor improve frozen force features.
        native=[r for r in rows if clock(close_time(r,timeframe))<=clock(known)]
        for r in native:
            if any(r.get(k)!=actual.get(k) for k in ('provider','symbol')) or r.get('timeframe')!=timeframe:
                return fail('source_native_market_or_period_mismatch')
            prices=[r[k] for k in ('open','high','low','close')]
            if any(isinstance(p,bool) or not isfinite(float(p)) or float(p)<=0 for p in prices):
                return fail('invalid_source_native_prices')
            if not r['low']<=min(r['open'],r['close'])<=max(r['open'],r['close'])<=r['high']:
                return fail('invalid_source_native_OHLC')
        points=response['points'];start,end=points
        part=[r for r in native if start[0]<=clock(r['timestamp_utc']).timestamp()<=end[0]]
        prior=[r for r in native if clock(r['timestamp_utc']).timestamp()<start[0]][-21:]
        used=prior+part
        if any((clock(b['timestamp_utc'])-clock(a['timestamp_utc'])).total_seconds()!=seconds for a,b in zip(used,used[1:])):
            return fail('normalisation_or_source_history_gap')
        source=dict(points=points,known_at_utc=known,source_id=response['source_id'],owner_id=response['owner_id'])
        raw=[[clock(r['timestamp_utc']).timestamp(),r['open'],r['high'],r['low'],r['close']] for r in used]
        profile=evaluate_strength(raw,source,timeframe,seconds,model={},
            provider=actual.get('provider'),domain='book_same_source_unfitted_engineering')
        if profile['score'] is None:return fail(profile['features']['status'],force_profile=profile)
        from .live_force_wave_review import _momentum_profile
        delivery=_momentum_profile(dict(bars=part,baseline_bars=prior[-20:]),
            response['direction']=='up',abs(end[1]-start[1]))
        geometry=min(float(b['geometry_score']) for b in boundary)
        weakest=min(float(b['breakout_score']) for b in boundary)
        return dict(base,state='complete' if delivery['qualified'] else 'measurement_only',
            reason=None if delivery['qualified'] else 'whole_wave_delivery_not_qualified',
            score=min(geometry,profile['score'],weakest) if delivery['qualified'] else None,
            geometry_score=geometry,force_score=profile['score'],weakest_breakout_score=weakest,
            source_binding_state='same_native_boundary_pair_and_force_verified',
            source_id=response['source_id'],owner_id=response['owner_id'],source_wave_id=line['wave_id'],
            source_identity=deepcopy(actual['source_identity']),phase_id=actual['phase_id'],
            boundary_pair_id=actual['boundary_pair_id'],force_known_at_utc=known,
            force_profile=profile,whole_wave_delivery=delivery,boundaries=boundary)
    except (KeyError,ValueError,TypeError,IndexError,ArithmeticError):
        return fail('source_identity_clock_or_history_incomplete')
