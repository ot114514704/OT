"""Keep an arithmetic ruler separate from a direction-owned 1:1 forecast.

Alexander's order is parent objective -> working-period background -> trend
position -> entry -> measurement. Native pivots, force speed, and a close over
the nearest fractal do not adjudicate those first three steps. This consumer
validates a separate, source-bound background decision; it does not manufacture
one and never reads user annotations as decisions.
"""
from datetime import datetime, timedelta
from math import isfinite
from .live_projection_lifecycle import NativeProjectionLifecycle


MINUTES = {"W1": 10080, "D1": 1440, "H4": 240, "H1": 60,
           "M30": 30, "M15": 15, "M5": 5, "M1": 1}
SOURCE_IDS = ["7674595968585551109", "7674515864606966022",
              "7685764459885286786", "7685764796256176487"]


def _time(value):
    parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("explicit timezone required")
    return parsed


def _identity(value):
    return isinstance(value, str) and value.strip() not in {"", "unknown", "unbound"}


def apply_one_to_one_admission(review, snapshot):
    """Attach the same decision to fresh analysis and old research responses.

    Caller owns this decoded response. Do not rewrite the historical evidence
    file or claim this today's policy existed at the market cutoff.
    """
    review["projection_admission"] = build_one_to_one_admission(review, snapshot)
    lifecycle = NativeProjectionLifecycle(snapshot)
    review["current_projection_lifecycle"] = lifecycle.review(review)
    ledger = review.get("measurement_lifecycle_ledger") or {}
    records = ledger.get("records") or []
    for record in records:
        record["projection_admission"] = build_one_to_one_admission(record, snapshot)
        record['historical_chart_admission'] = build_historical_chart_admission(record, snapshot)
        record['historical_source_chart_admission'] = build_historical_source_chart_admission(record, snapshot)
        record['current_projection_lifecycle'] = lifecycle.review(record)
    source_only_records = ledger.get('source_only_records') or []
    for record in source_only_records:
        record['projection_admission'] = build_one_to_one_admission(record, snapshot, source_only=True)
        record['historical_source_chart_admission'] = build_historical_source_chart_admission(record, snapshot)
    candidates = [record for record in records
                  if record["projection_admission"]["eligible_for_projection"]
                  and record['current_projection_lifecycle']['eligible_for_pending_target']]
    ledger['owned_geometry_count'] = sum(r['projection_admission']['eligible_for_projection'] for r in records)
    ledger["admitted_projection_count"] = len(candidates)
    ledger['historical_chart_count'] = sum(r['historical_chart_admission']['eligible_for_chart'] for r in records)
    ledger['historical_source_chart_count'] = sum(r['historical_source_chart_admission']['eligible_for_chart'] for r in [*records, *source_only_records])
    ledger['later_return_candidates'] = historical_later_return_candidates(ledger, snapshot)
    for candidate in ledger['later_return_candidates']:
        candidate['subsequent_path'] = review_later_return_path(candidate, snapshot)
    ledger['later_return_candidate_count'] = len(ledger['later_return_candidates'])
    review["analysis_projection_candidates"] = candidates
    forming = review.get("forming_pullback_one_to_one")
    if isinstance(forming, dict):
        forming["projection_admission"] = build_one_to_one_admission(forming, snapshot)
    return review


def review_later_return_path(candidate, snapshot):
    """Describe the subsequent historical path separately from C-time evidence.

    An unreviewed later C is not a completed second leg. Preserve the candidate
    in the ledger, but display an observed historical pair only when its own
    reference was reached before that anchor failed. End at the actual candle,
    never at C plus the old source's duration.
    """
    result = dict(status='second_leg_unresolved', display_as_second_leg=False,
                  ended_at_utc=None, evaluated_as_of_utc=snapshot.get('as_of_utc'),
                  historical_observation_only=True, trade_permission=False)
    tf = candidate.get('timeframe')
    if tf not in MINUTES or candidate.get('snapshot_id') != snapshot.get('snapshot_id'):
        return result
    c = candidate['projection_anchor']['price']
    target = candidate['projected_level']
    up = target > c
    known, cutoff = _time(candidate['known_at_utc']), _time(snapshot['as_of_utc'])
    duration = timedelta(minutes=MINUTES[tf])
    for bar in ((snapshot.get('chart_history') or {}).get(tf) or {}).get('bars') or []:
        opened = _time(bar['timestamp_utc'])
        if opened < known or opened + duration > cutoff:
            continue
        failed = bar['close'] < c if up else bar['close'] > c
        reached = bar['high'] >= target if up else bar['low'] <= target
        if failed or reached:
            # OHLC cannot order both events inside one candle.
            status = ('anchor_and_reference_same_bar_ambiguous' if failed and reached else
                      'anchor_failed_before_reference' if failed else 'reference_reached_before_anchor_failure')
            return {**result, 'status': status, 'display_as_second_leg': reached and not failed,
                    'ended_at_utc': bar['timestamp_utc']}
    return result


def historical_later_return_candidates(ledger, snapshot):
    """Record a deeper later C without promoting it to a visible second leg.

    A confirmed source can have several internal return pivots.  The first
    adjacent C is not necessarily the deepest return before the next push.
    This read uses only native pivots and bars known by C confirmation; later
    target contact never selects or validates the ruler.  It is historical
    geometry, deliberately separate from admitted projections. Its subsequent
    path must be reviewed before any completed historical second leg is drawn.
    """
    timeframe = ledger.get('timeframe')
    if timeframe not in MINUTES or ledger.get('snapshot_id') != snapshot.get('snapshot_id') or ledger.get('as_of_utc') != snapshot.get('as_of_utc'):
        return []
    states = snapshot.get('timeframe_states') or {
        row['timeframe']: row for row in (snapshot.get('analysis_report') or {}).get('timeframes') or []
        if isinstance(row, dict) and row.get('timeframe') in MINUTES}
    legs = ((states.get(timeframe) or {}).get('candidate_wave_ledger') or {}).get('legs') or []
    bars = ((snapshot.get('chart_history') or {}).get(timeframe) or {}).get('bars') or []
    if not legs or not bars:
        return []
    try:
        cutoff = _time(snapshot['as_of_utc'])
        native = {bar['timestamp_utc']: bar for bar in bars}
        if len(native) != len(bars):
            return []
        timeline = [(_time(bar['timestamp_utc']), bar) for bar in bars]
    except (KeyError, TypeError, ValueError):
        return []
    groups = {}
    for record in [*(ledger.get('records') or []), *(ledger.get('source_only_records') or [])]:
        admitted = record.get('historical_source_chart_admission') or {}
        if (admitted.get('status') != 'historical_source_owned_one_to_one' or
                admitted.get('eligible_for_chart') is not True or
                admitted.get('eligible_for_source_chart') is not True or
                admitted.get('eligible_for_projection') is not False or
                admitted.get('trade_permission') is not False or
                any(admitted.get(key) != value for key, value in (
                    ('timeframe', timeframe), ('snapshot_id', snapshot['snapshot_id']),
                    ('as_of_utc', snapshot['as_of_utc']),
                    ('measurement_id', record.get('measurement_id')),
                    ('source_leg_id', record.get('source_leg_id'))))):
            continue
        a, b = record.get('source_origin') or {}, record.get('source_terminal') or {}
        if not a.get('pivot_timestamp_utc') or not b.get('pivot_timestamp_utc'):
            continue
        key = (record.get('source_leg_id'), a['pivot_timestamp_utc'], b['pivot_timestamp_utc'])
        item = groups.setdefault(key, {'source': record, 'existing_anchors': []})
        if record.get('projection_anchor'):
            item['existing_anchors'].append(record['projection_anchor'])
    candidates = []
    for group in groups.values():
        source = group['source']
        a, b = source['source_origin'], source['source_terminal']
        up = b['price'] > a['price']
        baseline = (min if up else max)((point['price'] for point in group['existing_anchors']), default=b['price'])
        try:
            b_known = _time(b['confirmed_at_utc'])
            if b_known > cutoff:
                continue
            component_ids = source.get('component_source_leg_ids') or [source.get('source_leg_id')]
            source_end = next((i for i, leg in enumerate(legs) if
                leg.get('leg_id') == component_ids[-1] and leg.get('terminal') == b), None)
            if source_end is None:
                continue
            prior = []
            for leg_index in range(source_end + 1, len(legs)):
                leg = legs[leg_index]
                c = leg.get('terminal') or {}
                if (c.get('kind') != a.get('kind') or c.get('timeframe', timeframe) != timeframe
                        or not b['pivot_timestamp_utc'] < c.get('pivot_timestamp_utc', '')
                        or not min(a['price'], b['price']) < c.get('price', float('nan')) < max(a['price'], b['price'])
                        or not (c['price'] < baseline if up else c['price'] > baseline)):
                    continue
                c_known = _time(c['confirmed_at_utc'])
                chain = legs[source_end:leg_index + 1]
                if any(left.get('terminal') != right.get('origin') for left, right in zip(chain, chain[1:])) or any(
                        _time(part['terminal']['confirmed_at_utc']) > c_known for part in chain):
                    continue
                field = 'low' if up else 'high'
                if c_known > cutoff or native.get(c['pivot_timestamp_utc'], {}).get(field) != c['price']:
                    continue
                duration = timedelta(minutes=MINUTES[timeframe])
                interval = [bar for opened, bar in timeline if b_known <= opened and opened + duration <= c_known]
                if not interval or any(bar.get('timeframe', timeframe) != timeframe or
                    not isinstance(bar.get('close'), (int, float)) or not isfinite(bar['close']) for bar in interval):
                    continue
                if any((bar['close'] < a['price'] if up else bar['close'] > a['price']) or
                       (bar.get('high', float('-inf')) >= 2*b['price']-a['price'] if up else
                        bar.get('low', float('inf')) <= 2*b['price']-a['price']) for bar in interval):
                    continue
                prior.append((c, interval))
            if not prior:
                continue
            c, interval = (min if up else max)(prior, key=lambda item: item[0]['price'])
            target = round(c['price'] + b['price'] - a['price'], 6)
            candidates.append({
                'timeframe': timeframe, 'snapshot_id': snapshot['snapshot_id'],
                'as_of_utc': snapshot['as_of_utc'], 'source_leg_id': source['source_leg_id'],
                'source_measurement_id': source['measurement_id'],
                'source_origin': a, 'source_terminal': b, 'projection_anchor': c,
                'projected_level': target, 'source_height': round(abs(b['price']-a['price']), 6),
                'known_at_utc': c['confirmed_at_utc'],
                'source_terminal_exceeded_before_anchor': any(
                    bar['high'] > b['price'] if up else bar['low'] < b['price'] for bar in interval),
                'status': 'later_native_return_equal_height_candidate_parent_task_unreviewed',
                'historical_only': True, 'eligible_for_projection': False,
                'parent_target_rechecked_at_anchor': False, 'trade_permission': False,
            })
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
    return sorted(candidates, key=lambda row: row['known_at_utc'])


def build_historical_chart_admission(record, snapshot):
    """Retain a qualified historical ruler after its continuation failed.

    The source is judged at B; the parent reference must still have remained
    available when C was known. Later failure stays in the record and blocks
    current analysis, but does not erase what could be measured at that time.
    """
    empty={key:record.get(key) for key in ('timeframe','measurement_id','source_leg_id')}
    empty.update(snapshot_id=snapshot.get('snapshot_id'),as_of_utc=snapshot.get('as_of_utc'),
                 status='historical_source_unresolved',eligible_for_chart=False,
                 eligible_for_projection=False,trade_permission=False,blockers=[])
    selection=record.get('source_selection_review') or {}
    if not selection.get('source_background_ready_at_confirmation'):
        return empty
    if not record.get('projection_anchor'):
        return {**empty,'blockers':['retracement_anchor_not_confirmed']}
    candidate={key:value for key,value in record.items() if key not in ('continuation_requires_review','anchor_review')}
    candidate['source_selection_review']={**selection,'eligible_source_for_owned_task':True}
    decision=build_one_to_one_admission(candidate,snapshot)
    if not decision['eligible_for_projection']:
        return {**empty,'blockers':decision['blockers']}
    automatic=selection.get('automatic_background_review') or {}
    if automatic.get('context'):
        try:
            from .live_parent_objective_context import build_parent_objective_review
            states=snapshot.get('timeframe_states') or {
                row['timeframe']:row for row in (snapshot.get('analysis_report') or {}).get('timeframes',[])}
            anchor_known=record['projection_anchor']['confirmed_at_utc']
            objective_state=states[record['timeframe']]
            if record.get('source_geometry')=='enclosing_native_wave':
                from .live_one_to_one_source_selection import _verified_enclosing_source
                from .live_nested_stage_review import _native
                _,raw,legs=_native({**snapshot,'timeframe_states':states},record['timeframe'],
                                   _time(snapshot['as_of_utc']))
                source,_=_verified_enclosing_source(record['timeframe'],record,raw,legs,
                    _time(record['source_terminal']['confirmed_at_utc']))
                wave=objective_state.get('candidate_wave_ledger') or {}
                objective_state={**objective_state,'candidate_wave_ledger':{
                    **wave,'legs':[*legs,source]}}
            objective=build_parent_objective_review(automatic['parent_task'],automatic['target_graph'],
                objective_state,timeframe=record['timeframe'],as_of_utc=anchor_known,
                chart_history=snapshot.get('chart_history'),provider=snapshot.get('provider'),
                instrument=snapshot.get('instrument'))
            if objective['status']!='validated_parent_objective_context':
                return {**empty,'blockers':['parent_reference_no_longer_available_at_anchor_confirmation']}
        except (KeyError,TypeError,ValueError,AttributeError):
            return {**empty,'blockers':['parent_reference_at_anchor_unavailable']}
    return {**decision,'status':'historical_direction_owned_one_to_one',
            'eligible_for_chart':True,'eligible_for_projection':False,
            'readout':'保留当时合格的等高测量；后来失效状态仍在记录中，不能沿用为当前计划。'}


def build_historical_source_chart_admission(record, snapshot):
    """Keep the confirmed A→B ruler even when C never becomes valid.

    A source leg is a completed, direction-owned measurement in its own right.
    The later return leg is a separate lifecycle: an invalid/failed C may block
    the third pullback box, but it must not erase the source box. No B-based
    extension is generated when C is missing.
    """
    empty = {key: record.get(key) for key in ('timeframe', 'measurement_id', 'source_leg_id')}
    empty.update(snapshot_id=snapshot.get('snapshot_id'), as_of_utc=snapshot.get('as_of_utc'),
                status='historical_source_unresolved', eligible_for_chart=False,
                eligible_for_projection=False, eligible_for_source_chart=False,
                trade_permission=False, blockers=[])
    selection = record.get('source_selection_review') or {}
    if not selection.get('source_background_ready_at_confirmation'):
        return empty
    candidate = {key: value for key, value in record.items()
                 if key not in ('continuation_requires_review', 'anchor_review',
                                'projection_anchor', 'projected_level',
                                'paired_projection_review', 'signed_source_length')}
    candidate['source_selection_review'] = {**selection, 'eligible_source_for_owned_task': True}
    decision = build_one_to_one_admission(candidate, snapshot, source_only=True)
    if not decision.get('eligible_for_source_chart'):
        return {**empty, 'blockers': decision.get('blockers', [])}
    return {**decision, 'status': 'historical_source_owned_one_to_one',
            'eligible_for_chart': True, 'eligible_for_projection': False,
            'eligible_for_source_chart': True,
            'readout': '保留已确认的来源段；自身回调 C 另行确认，不会伪补第二框。'}


def _snapshot_bar_matches(snapshot):
    """Index exact timestamps for one admission call, retaining duplicate rows.

    This index never survives its call or binds a mutable snapshot to a global
    cache. Invalid/unhashable clocks retain the old equality-scan behavior.
    """
    indexes = {}
    def matches(timeframe, timestamp):
        bars = (snapshot.get("chart_history", {}).get(timeframe) or {}).get("bars") or []
        if timeframe not in indexes:
            index = {}
            try:
                for bar in bars:
                    index.setdefault(bar.get("timestamp_utc"), []).append(bar)
            except TypeError:
                index = None
            indexes[timeframe] = index
        index = indexes[timeframe]
        if index is not None:
            try:
                return index.get(timestamp, [])
            except TypeError:
                pass
        return [bar for bar in bars if bar.get("timestamp_utc") == timestamp]
    return matches


def build_one_to_one_admission(review, snapshot, *, source_only=False):
    """Admission to chart/analysis, NOT permission to trade or proof C is final.

    background_direction_review belongs to the system's independent background
    analysis, with named structure, current task role and native-bar witnesses.
    Until that analysis exists, the fail-closed result is deliberately explicit.
    Equal distance arithmetic stays in the diagnostic ledger only.
    """
    result = {"status": "background_or_source_unresolved", "eligible_for_projection": False,
              "timeframe": review.get("timeframe"), "snapshot_id": snapshot.get("snapshot_id"),
              "as_of_utc": snapshot.get("as_of_utc"), "measurement_id": review.get("measurement_id"),
              "source_leg_id": review.get("source_leg_id"), "direction_task_id": None,
              "blockers": [], "source_message_ids": SOURCE_IDS,
              "pullback_completed": False, "trade_permission": False,
              "eligible_for_source_chart": False,
              "readout": "背景方向、趋势位置和来源段尚未裁定；不输出本级 1:1 目标。"}
    native_matches = _snapshot_bar_matches(snapshot)
    context = review.get("background_direction_review") or {}
    issues = result["blockers"]
    selection = review.get("source_selection_review")
    if isinstance(selection,dict):
        if (selection.get("method_version") != "source_only_force_structure_task_join_v2"
                or selection.get("eligible_source_for_owned_task") is not True
                or any(selection.get(key) != result.get(key) for key in
                       ("timeframe","snapshot_id","as_of_utc","source_leg_id","measurement_id"))
                or selection.get("trade_permission") is not False):
            issues.append("joint_source_force_structure_task_not_ready")
    if not context:
        issues.extend(["background_direction_not_adjudicated", "trend_not_established",
                       "source_leg_not_adjudicated"])
        return result
    try:
        cutoff = _time(snapshot["as_of_utc"])
        if any(context.get(key) != result[key] for key in
               ("timeframe", "snapshot_id", "as_of_utc", "measurement_id", "source_leg_id")):
            issues.append("background_measurement_binding_mismatch")
        if review.get("timeframe") not in MINUTES or not _identity(snapshot.get("snapshot_id")):
            issues.append("snapshot_or_period_invalid")
        if (context.get("background_state") != "resolved"
                or context.get("trend_established") is not True
                or context.get("direction_task_confirmed") is not True):
            issues.append("background_direction_or_trend_unresolved")
        if context.get("source_leg_eligible") is not True:
            issues.append("source_leg_not_adjudicated")
        if not all(_identity(context.get(key)) for key in
                   ("background_context_id", "direction_task_id", "named_structure_node_id")):
            issues.append("named_background_task_or_structure_missing")
        role = context.get("current_task_role")
        if role not in {"trend_delivery", "bounded_pullback", "bounded_counter_task"}:
            issues.append("current_leg_role_unresolved")
        if role != "trend_delivery" and not _identity(context.get("counter_task_boundary_id")):
            issues.append("opposing_task_boundary_unbound")
        direction = review.get("direction_observation")
        if direction not in {"up", "down"} or context.get("direction_observation") != direction:
            issues.append("source_direction_not_owned_by_task")
        points = [review["source_origin"], review["source_terminal"]]
        if not source_only and review.get("projection_anchor"):
            points.append(review["projection_anchor"])
        for point in points:
            tf = review["timeframe"]
            bars = (snapshot.get("chart_history", {}).get(tf) or {}).get("bars") or []
            matches = native_matches(tf, point.get("pivot_timestamp_utc"))
            price = point.get("price")
            field = {"confirmed_swing_low_candidate": "low", "confirmed_swing_high_candidate": "high"}.get(point.get("kind"))
            if (not field or len(matches) != 1 or isinstance(price, bool)
                    or not isinstance(price, (int, float)) or not isfinite(price)
                    or matches[0].get(field) != price or point.get("timeframe", tf) != tf
                    or not _time(point["pivot_timestamp_utc"]) <= _time(point["confirmed_at_utc"]) <= cutoff):
                issues.append("measurement_anchor_not_native_or_not_known")
        a, b = points[:2]
        if (not _time(a["pivot_timestamp_utc"]) < _time(b["pivot_timestamp_utc"])
                or a["price"] == b["price"] or (b["price"] > a["price"]) != (direction == "up")):
            issues.append("source_leg_geometry_invalid")
        if len(points) == 3:
            c = points[2]
            target = review.get("projected_level")
            if (not _time(b["pivot_timestamp_utc"]) < _time(c["pivot_timestamp_utc"])
                    or not min(a["price"], b["price"]) < c["price"] < max(a["price"], b["price"])
                    or isinstance(target, bool) or not isinstance(target, (int, float)) or not isfinite(target)
                    or abs(target - (c["price"] + b["price"] - a["price"])) > 1e-6):
                issues.append("retracement_projection_geometry_invalid")
            # Losing the source BEFORE C became observable is not a later
            # failure that may be stripped to retain historical geometry.
            # Check native closes, never timestamps stored in lifecycle flags.
            c_known = _time(c['confirmed_at_utc'])
            b_known = _time(b['confirmed_at_utc'])
            c_open = _time(c['pivot_timestamp_utc'])
            sign = 1 if direction == 'up' else -1
            for bar in (snapshot.get('chart_history', {}).get(review['timeframe']) or {}).get('bars') or []:
                opened = _time(bar['timestamp_utc'])
                closed = opened + timedelta(minutes=MINUTES[review['timeframe']])
                if not b_known < closed <= c_known:
                    continue
                if (isinstance(bar.get('close'), bool) or not isinstance(bar.get('close'), (int,float))
                        or not isfinite(bar['close'])):
                    issues.append('measurement_lifecycle_close_unavailable')
                    continue
                if sign*(bar['close']-a['price']) < 0:
                    issues.append('source_origin_failed_before_anchor_confirmation')
                if opened >= c_open and sign*(bar['close']-c['price']) < 0:
                    issues.append('anchor_failed_before_its_confirmation')
        # First-leg eligibility cannot be supplied by what happened after that
        # leg was confirmed. Later theory may explain it, not backdate facts.
        known = _time(context.get("known_at_utc"))
        terminal_known = _time(review["source_terminal"]["confirmed_at_utc"])
        if not known <= terminal_known <= cutoff:
            issues.append("background_decision_not_known_at_source_confirmation")
        if role == 'bounded_pullback':
            from .live_parent_objective_context import counter_task_boundary_review
            boundary=context.get('counter_task_boundary') or {}
            parent_direction=context.get('parent_direction')
            bounds=counter_task_boundary_review(snapshot.get('chart_history'),context.get('parent_timeframe'),
                review['timeframe'],boundary,review['source_origin'],parent_direction,known,
                provider=snapshot.get('provider'),instrument=snapshot.get('instrument'))
            if (not bounds['valid'] or parent_direction == direction
                    or boundary.get('boundary_id') != context.get('counter_task_boundary_id')):
                issues.append('opposing_task_native_boundary_not_bound')
        if context.get("trade_permission") is not False:
            issues.append("analysis_is_not_trading_permission")
        witnesses = context.get("market_evidence") or []
        refs = context.get("source_refs") or []
        if not isinstance(witnesses, list) or not witnesses or not isinstance(refs, list) or not refs:
            issues.append("background_market_evidence_missing")
        else:
            identities = set()
            for witness in witnesses:
                tf = witness.get("timeframe")
                utc = witness.get("bar_open_utc")
                bars = (snapshot.get("chart_history", {}).get(tf) or {}).get("bars") or []
                matches = native_matches(tf, utc)
                price = witness.get("close")
                if (tf not in MINUTES or not _identity(witness.get("evidence_id")) or len(matches) != 1
                        or isinstance(price, bool) or not isinstance(price, (int, float)) or not isfinite(price)
                        or matches[0].get("close") != price
                        or matches[0].get("timeframe", tf) != tf
                        or _time(utc) + timedelta(minutes=MINUTES[tf]) > known):
                    issues.append("background_witness_not_native_or_not_known")
                identities.add(witness.get("evidence_id"))
            if any(not _identity(ref) or ref not in identities for ref in refs):
                issues.append("background_reference_not_market_witness")
        if review.get("continuation_requires_review") or (review.get("anchor_review") or {}).get("requires_anchor_review"):
            issues.append("origin_or_anchor_requires_review")
    except (KeyError, TypeError, ValueError, AttributeError, OverflowError):
        issues.append("background_evidence_invalid")
    result["blockers"] = list(dict.fromkeys(issues))
    if not issues:
        result.update(status="direction_owned_one_to_one_source" if source_only else "direction_owned_one_to_one",
                      eligible_for_projection=not source_only,
                      eligible_for_source_chart=source_only,
                      direction_task_id=context["direction_task_id"],
                      readout=("按已裁定的本级背景与来源段保留 A→B；自身回调 C 尚未确认，不补第二框。"
                               if source_only else
                               "按已裁定的本级背景、趋势位置与来源段画 1:1；不等于回调已结束或可进场。"))
    return result
