"""Chapter6 pullback-reversal branch, explicitly selected for paper research.

This is one implemented entry branch, not a claim to complete all book
methods. Scores filter a named policy; they never replace A, B, a location,
a reversal or the ordered stop/entry/target/risk calculation (PDF133-137/279).
"""
from decimal import Decimal
from .book_author_review import author_review_context,author_review_gate
from .book_first_response_leg import clock,close_time,MINUTES
from .book_breakout_assessment import digest,native_turning_source_proof
from .book_one_to_one_context import evaluate_one_to_one_context,requirement as one_to_one_requirement


def observe_entry(bars,timeframe,cutoff,book,policy=None,unified_geometry=None):
    rows=[r for r in bars if clock(close_time(r,timeframe))<=clock(cutoff)]
    scores=book.get('boundary_breakout_assessment') or {}
    setup=book.get('setup_qualification') or {};response=book.get('first_response_leg') or {}
    phase=scores.get('phase_id')
    from .book_owned_force import owned_force_confluence
    breakout_confluence=owned_force_confluence(rows,timeframe,cutoff,book)
    confirmation_mode=(policy or {}).get('boundary_confirmation_mode','initial_follow')
    dynamics={k:r.get('dynamic_observation') or {} for k,r in (scores.get('boundaries') or {}).items()}
    base=dict(schema='book_realtime_entry_v1',timeframe=timeframe,as_of_utc=cutoff,
        phase_id=phase,boundary_pair_id=scores.get('boundary_pair_id'),
        branch='chapter6_40_80_reversal',source_pdf_pages=[133,135,136,137,279,280],
        automatic_trade_permission=False,live_order_permission=False,order_api_called=False,
        breakout_confluence=breakout_confluence,
        boundary_confirmation_mode=confirmation_mode,current_boundary_observations=dynamics,
        breakout_confluence_required=(policy or {}).get('require_breakout_confluence') is True,
        progressive_period_context=book.get('progressive_period_context') or {},
        author_review_context=author_review_context(book,timeframe,cutoff,rows),
        paper_candidate=False,signal=None,policy_id=(policy or {}).get('id'),
        source_basis='engineering_native_BC_pending_author_wave_review')
    base['author_review_gate']=author_review_gate(base['author_review_context'])
    # The direct route is a separate research contract.  Consume it only when
    # explicitly selected with a packet bound to this exact Book source; do
    # not run it through the Chapter-6 pullback branch or silently treat a
    # generic integrated snapshot as an entry signal.
    if (policy or {}).get('branch') == 'direct_pre_adjudicated_location':
        from .book_direct_entry_contract import validate_direct_entry_contract
        direct = validate_direct_entry_contract(
            book, (policy or {}).get('direct_route_packet'), timeframe, cutoff)
        return dict(base, branch='direct_pre_adjudicated_location',
            status=direct['state'], reason=direct.get('reason'),
            direct_route_contract=direct, paper_candidate=False, signal=None,
            entry_permission=False, live_order_permission=False,
            automatic_trade_permission=False, order_api_called=False)
    one_to_one_review=dict(schema='book_one_to_one_context_receipt_v1',state='not_evaluated',
        reason='Book_response_identity_not_yet_verified',execution_admission='blocked_research_only',
        automatic_trade_permission=False,live_order_permission=False,order_api_called=False)
    def finish(status,reason,**facts):
        from .book_position_scorecard import position_scorecard,check_position_score_requirements
        facts['position_scorecard']=position_scorecard(rows,timeframe,cutoff,book,breakout_confluence,one_to_one_review,unified_geometry)
        score_gate=check_position_score_requirements(facts['position_scorecard'],(policy or {}).get('position_score_requirements'))
        facts['position_score_gate']=score_gate
        if status=='entry_candidate' and score_gate['state'] in ('wait','invalid_policy'):
            status='wait_position_scores' if score_gate['state']=='wait' else 'blocked'
            reason='position_score_requirements_not_satisfied' if score_gate['state']=='wait' else 'invalid_position_score_requirements'
            facts.update(paper_candidate=False,signal=None)
        from .book_composite_assessment import composite_assessment,composite_requirement,contextual_requirement
        combined=composite_assessment(facts['position_scorecard'],status,reason,setup)
        combined_gate=composite_requirement(combined,(policy or {}).get('composite_score_requirement'))
        facts.update(composite_assessment=combined,composite_score_gate=combined_gate)
        if status=='entry_candidate' and combined_gate['state'] in ('wait','invalid_policy'):
            status='wait_composite_score' if combined_gate['state']=='wait' else 'blocked'
            reason=combined_gate['reason'];facts.update(paper_candidate=False,signal=None)
            combined['admission']='waiting_composite_requirement'
        context_gate=contextual_requirement(facts['position_scorecard'],
            (policy or {}).get('contextual_score_requirement'),
            one_to_one_mode=one_to_one_requirement(policy))
        facts['contextual_score_gate']=context_gate
        if status=='entry_candidate' and context_gate['state'] in ('wait','invalid_policy'):
            status='wait_contextual_score' if context_gate['state']=='wait' else 'blocked'
            reason=context_gate['reason'];facts.update(paper_candidate=False,signal=None)
            combined['admission']='waiting_contextual_requirement'
        facts.setdefault('one_to_one_second_leg_review',one_to_one_review)
        return dict(base,status=status,reason=reason,**facts)
    if setup.get('status')=='stop_breached':return finish('invalidated','original_B_breached')
    scope=(book.get('turning_point_line') or {}).get('owned_scope') or {}
    if scope.get('membership_state')=='declared_geometry_range_not_author_degree':
        return finish('wait_native_ownership','declared_scope_is_geometry_review_only')
    if not rows or scores.get('joint',{}).get('state')!='dual_scored':
        return finish('wait_dual_scores','both_owned_boundary_breaks_need_follow_close')
    ruler_proof=base['author_review_context']['r01_same_degree']['native_ruler_review']['native_source_proof']
    base['outer_native_ruler_validation']=ruler_proof
    if not ruler_proof['qualified']:
        return finish('wait_native_construction','native_outer_ruler_not_reproduced')
    try:
        event=book['first_closed_break'];i=event['break_index']
        if (type(i) is not int or not 0<=i<len(rows) or
                clock(event['break_utc'])!=clock(rows[i]['timestamp_utc']) or
                not clock(close_time(rows[i],timeframe))<=clock(event['known_at_utc'])<=clock(cutoff)):
            raise ValueError('outer event clock')
        if clock(ruler_proof['known_at_utc'])>clock(event['break_utc']):
            base['outer_native_ruler_validation']=dict(ruler_proof,source_known_before_own_break=False)
            return finish('historical_only','native_outer_ruler_not_known_before_break')
        base['outer_native_ruler_validation']=dict(ruler_proof,source_known_before_own_break=True)
    except (KeyError,TypeError,ValueError,IndexError):
        return finish('wait_native_construction','native_outer_break_clock_not_bound')
    # A legacy/cached dual-score receipt cannot substitute a native point
    # for the corresponding C--E adjustment extreme. This is a construction
    # prerequisite, independent of optional numeric score thresholds.
    proof=native_turning_source_proof(rows,book.get('turning_point_line') or {},book.get('turning_boundary') or {})
    if proof['qualified']:
        try:
            line=book['turning_point_line'];turn=book['turning_boundary']
            dependencies=[('outer',line,line['end_index']),('turning',turn,turn['first_observable_index'])]
            valid=(book.get('timeframe')==timeframe and book.get('as_of_utc')==cutoff
                and scores.get('timeframe')==timeframe and scores.get('as_of_utc')==cutoff
                and all(type(i) is int and 0<=i<len(rows) and
                    clock(close_time(rows[i],timeframe))<=clock(fact['known_at_utc'])<=clock(cutoff)
                    for _,fact,i in dependencies))
            if not valid:raise ValueError('unbound construction clock')
            proof=dict(proof,construction_dependency_clocks={name:fact['known_at_utc'] for name,fact,_ in dependencies})
        except (KeyError,TypeError,ValueError,IndexError):
            proof=dict(proof,qualified=False,reason='CDE_dependency_clock_not_bound_to_current_prefix')
    base['turning_construction_validation']=dict(proof,phase_id=phase,timeframe=timeframe,as_of_utc=cutoff)
    if not proof['qualified']:return finish('wait_native_construction','same_wave_native_CDE_not_reproduced')
    try:
        event=book['parallel_break'];i=event['break_index']
        if (type(i) is not int or not 0<=i<len(rows) or
                clock(event['break_utc'])!=clock(rows[i]['timestamp_utc']) or
                not clock(close_time(rows[i],timeframe))<=clock(event['known_at_utc'])<=clock(cutoff)):
            raise ValueError('turning event clock')
        prospective=clock(book['turning_boundary']['known_at_utc'])<=clock(event['break_utc'])
        base['turning_construction_validation']['source_known_before_own_break']=prospective
        if not prospective:return finish('historical_only','native_turning_not_known_before_break')
    except (KeyError,TypeError,ValueError,IndexError):
        return finish('wait_native_construction','native_turning_break_clock_not_bound')
    # PDF202 explicitly assigns this backtrack to chapter7 target measurement.
    # It cannot supply a chapter7 target, but is not evidence of a veto on
    # this independently selected chapter6 engineering source-C paper branch.
    # Its existing source, target, pattern, policy and risk checks still apply.
    joint=scores['joint']
    if not joint['prospective_sources']:
        return finish('historical_only','boundary_geometry_not_known_before_break')
    if confirmation_mode not in ('initial_follow','current_closed_hold'):
        return finish('blocked','unknown_boundary_confirmation_mode')
    if confirmation_mode=='initial_follow' and (not joint['both_follow_directional'] or not joint['both_hold_boundaries']):
        return finish('wait_follow','boundary_follow_or_boundary_hold_not_confirmed')
    if not setup.get('both_boundaries_broken'):
        return finish('wait_dual_setup','setup_not_bound_to_both_boundaries')
    if (setup.get('boundary_A_freeze') or {}).get('status')!='frozen_before_first_boundary':
        return finish('wait_A_source','prebreak_A_freeze_not_established')
    if not (setup.get('conditions') or {}).get('boundary_A_broken'):
        return finish('wait_A_cross','closed_A_cross_not_observed')
    if not policy:return finish('wait_policy','named_execution_policy_and_risk_limits_not_configured')
    if policy.get('mode')!='paper':return finish('blocked','this_implementation_supports_paper_only')
    current_hold_since=None
    if policy.get('require_current_boundary_hold') is True or confirmation_mode=='current_closed_hold':
        try:
            valid=set(dynamics)=={'outer','turning'} and all(
                d.get('as_of_utc')==cutoff and d.get('timeframe')==timeframe and
                d.get('boundary_id')==scores['boundaries'][k].get('boundary_id') and bool(d.get('boundary_id')) and
                d.get('current_close_utc')==rows[-1]['timestamp_utc'] and
                d.get('current_close')==float(rows[-1]['close']) and
                isinstance((d.get('features') or {}).get('current_hold_run'),int) and
                not isinstance(d['features']['current_hold_run'],bool) and
                1<=d['features']['current_hold_run']<=len(rows) and
                clock(d['known_at_utc'])<=clock(cutoff) and
                d.get('state') in ('holding_outside','reclaimed_after_return')
                for k,d in dynamics.items())
        except (KeyError,ValueError,TypeError):valid=False
        if not valid:
            return finish('wait_current_boundary_hold','current_owned_boundary_state_not_outside_both_lines')
        # A reclaimed boundary starts a new uninterrupted hold interval.
        # An older reversal from before that interval cannot be recycled.
        # Same-close reversal + reclaim is observable after that bar closes.
        current_hold_since=max((close_time(rows[-d['features']['current_hold_run']],timeframe)
            for d in dynamics.values()),key=clock)
        base['current_boundary_hold_since_utc']=current_hold_since
    if policy.get('require_breakout_confluence') is True:
        if (breakout_confluence.get('state') != 'complete' or
                breakout_confluence.get('source_binding_state') != 'same_native_boundary_pair_and_force_verified'):
            return finish('wait_breakout_confluence','same_clock_geometry_force_and_weakest_breakout_required')
        minimum=policy.get('min_breakout_confluence')
        if isinstance(minimum,bool) or not isinstance(minimum,(int,float)) or not 0<=minimum<=100:
            return finish('blocked','explicit_breakout_confluence_threshold_required')
        if breakout_confluence.get('score') < minimum:
            return finish('wait_breakout_confluence','breakout_confluence_below_selected_policy')
    if not policy.get('id') or policy.get('branch')!=base['branch']:
        return finish('blocked','named_entry_branch_not_selected')
    if not setup.get('author_boundary_verified') and policy.get('allow_engineering_sources') is not True:
        return finish('wait_author_source','author_A_not_verified_and_engineering_not_selected')
    rules=policy.get('context_rules')
    if not isinstance(rules,dict):return finish('blocked','explicit_context_requirements_needed')
    if 'one_to_one_second_leg' in rules:
        return finish('blocked','one_to_one_requires_dedicated_policy_requirement')
    contexts=book.get('execution_context_factors') or {}
    for name,allowed in rules.items():
        fact=contexts.get(name) or {}
        if not isinstance(allowed,list) or not allowed:return finish('blocked','invalid_context_rule_'+name)
        try:
            valid=(fact.get('phase_id')==phase and fact.get('working_timeframe')==timeframe
                and fact.get('provider')==scores.get('provider') and fact.get('symbol')==scores.get('symbol')
                and clock(fact['known_at_utc'])<=clock(cutoff) and fact.get('source_id'))
        except (KeyError,TypeError,ValueError):valid=False
        if not valid:return finish('wait_context','same_source_current_'+name+'_required')
        if fact.get('state') not in allowed:return finish('wait_context',name+'_does_not_satisfy_selected_policy')
    for name,r in scores['boundaries'].items():
        for field,limit in (('geometry_score','min_geometry_score'),('breakout_score','min_boundary_score')):
            threshold=policy.get(limit)
            if isinstance(threshold,bool) or not isinstance(threshold,(int,float)) or not 0<=threshold<=100:
                return finish('blocked','explicit_score_thresholds_required')
            if r.get(field) is None or r[field]<threshold:
                return finish('wait_score',name+'_'+field+'_below_selected_policy')
    if not response.get('source_complete') or response.get('status')=='source_invalidated':
        return finish('wait_response','completed_same_source_BC_unavailable')
    line=book.get('turning_point_line') or {};stop=book.get('stop_reference') or {}
    expected=[[(clock(t).timestamp()),p] for t,p in scores['source_identity']['ruler']['anchors']]
    if (response.get('ruler_anchors')!=expected or response.get('source_wave_id')!=line.get('wave_id')
            or response.get('timeframe')!=timeframe or response.get('direction')!=scores['direction']):
        return finish('blocked','response_belongs_to_another_ruler_or_wave')
    try:
        origin=response['origin_B']['point'];terminal=response['terminal_C']['point']
        if origin[1]!=stop['reference_price'] or stop.get('status')!='observed_candidate':
            return finish('blocked','protective_B_does_not_match_entry_source')
        sign=1 if scores['direction']=='up' else -1
        bp,cp=Decimal(str(origin[1])),Decimal(str(terminal[1]));height=sign*(cp-bp)
        if height<=0:return finish('blocked','response_direction_invalid')
        a=Decimal(str(setup['boundary_A_freeze']['point']['price']))
        second=max(r['break_index'] for r in scores['boundaries'].values())
        a_cross=next((r for r in rows[second:] if sign*(Decimal(str(r['close']))-a)>0),None)
        if a_cross is None:return finish('wait_A_cross','A_cross_condition_not_reproduced_from_native_bars')
        dependencies=[response['known_at_utc'],setup['dual_known_at_utc'],close_time(a_cross,timeframe)]
        dependencies += [r['known_at_utc'] for r in scores['boundaries'].values()]
        ready=max(dependencies,key=clock)
        if clock(ready)>clock(cutoff):return finish('wait_response','entry_dependencies_after_cutoff')
    except (KeyError,ValueError,TypeError):return finish('blocked','entry_source_or_clock_incomplete')
    lo,hi=sorted((cp-sign*Decimal('.4')*height,cp-sign*Decimal('.8')*height))
    zone=dict(lower=float(lo),upper=float(hi),source_id=response.get('source_id'),known_at_utc=ready)
    if policy.get('target_mode')!='source_C':
        return finish('blocked','initial_paper_branch_requires_explicit_source_C_target',zone=zone)
    # This initial branch targets the first revisit of the completed C.
    # A later pattern/context cannot revive that opportunity after C was
    # already revisited, even if no eligible reversal existed at the time.
    target_visit=next((r for r in rows if clock(r['timestamp_utc'])>=clock(ready)
        and sign*(Decimal(str(r['high' if sign>0 else 'low']))-cp)>=0),None)
    if target_visit is not None:
        return finish('completed','source_C_reached_before_or_after_initial_signal',zone=zone,
            target_revisit_known_at_utc=close_time(target_visit,timeframe))
    one_to_one_review=evaluate_one_to_one_context(contexts,policy,scores,response,timeframe,cutoff)
    if one_to_one_review['state']=='policy_invalid':
        return finish('blocked',one_to_one_review['reason'])
    if (one_to_one_requirement(policy)!='not_required'
            and one_to_one_review['state']!=one_to_one_requirement(policy)):
        return finish('wait_one_to_one_review',one_to_one_review['reason'],zone=zone)
    if one_to_one_requirement(policy)=='same_phase_research_ready':
        return finish('wait_one_to_one_review','accepted_own_terminal_is_later_than_initial_source_C_entry',zone=zone)
    if one_to_one_requirement(policy)=='same_source_developing_reference':
        ready=max((ready,one_to_one_review['known_at_utc']),key=clock)
        if clock(ready)>clock(cutoff):return finish('wait_one_to_one_review','reference_not_observed_by_cutoff',zone=zone)
        zone['known_at_utc']=ready
    kinds=({'hammer','bullish_engulfing','morning_star_candidate','piercing_line_candidate'} if sign>0 else
        {'shooting_star','bearish_engulfing','evening_star_candidate','dark_cloud_cover_candidate'})
    # Reproduce patterns over the complete retained source prefix. The
    # display's 64-candle list can otherwise forget an old first attempt.
    from .trend_trade_method_patterns import detect_candlestick_patterns
    patterns=detect_candlestick_patterns(rows,timeframe,cutoff,lookback=len(rows))['patterns']
    candidates=[]
    for p in patterns:
        r=next((r for r in rows if r['timestamp_utc']==p.get('timestamp_utc')),None)
        pattern_direction={'bullish':'up','bearish':'down'}.get(p.get('direction'),p.get('direction'))
        if r is None or p.get('kind') not in kinds or pattern_direction!=scores['direction']:continue
        # The whole signal candle must begin after all its dependencies were
        # known. A later completed source cannot supply an earlier reversal.
        if clock(r['timestamp_utc'])<clock(ready):continue
        extreme=Decimal(str(r['low' if sign>0 else 'high']))
        if not lo<=extreme<=hi:continue
        if sign*(Decimal(str(r['close']))-Decimal(str(r['open'])))<=0:continue
        if p.get('known_at_utc')!=close_time(r,timeframe):continue
        if current_hold_since and clock(p['known_at_utc'])<clock(current_hold_since):continue
        candidates.append((clock(r['timestamp_utc']),p,r))
    if not candidates:return finish('wait_reversal','wait_40_80_zone_and_directional_reversal',zone=zone)
    _,pattern,signal_row=min(candidates,key=lambda v:v[0])
    signal_close=close_time(signal_row,timeframe)
    if sign*(Decimal(str(signal_row['close']))-cp)>=0:
        return finish('completed','selected_source_C_already_passed_on_signal',zone=zone)
    for r in rows:
        if clock(r['timestamp_utc'])<clock(signal_close):continue
        failed=sign*(Decimal(str(r['low' if sign>0 else 'high']))-bp)<0
        reached=sign*(Decimal(str(r['high' if sign>0 else 'low']))-cp)>=0
        if failed or reached:
            return finish('ambiguous' if failed and reached else 'invalidated' if failed else 'completed',
                'B_and_target_order_unknown' if failed and reached else 'B_breached_after_signal' if failed else 'source_C_reached_after_signal',zone=zone)
    # Max age is selected explicitly; an old historical pattern is not a new
    # order simply because the source still exists in a refreshed snapshot.
    age=policy.get('max_signal_age_seconds')
    if isinstance(age,bool) or not isinstance(age,(int,float)) or age<=0:
        return finish('blocked','positive_signal_lifetime_required',zone=zone)
    if (clock(cutoff)-clock(signal_close)).total_seconds()>age:
        return finish('expired','first_entry_signal_expired',zone=zone)
    mode=policy.get('protection_mode','original_B_only')
    if mode not in ('original_B_only','chapter8_EG'):
        return finish('blocked','unknown_protection_policy',zone=zone)
    from .book_paper_protection import freeze_protection_source
    protection=freeze_protection_source(rows,timeframe,line,book['first_closed_break'],response,scores)
    signal=dict(id='book_signal:'+digest([phase,response['source_id'],signal_close,policy['id']]),
        entry_cycle_id='book_entry_cycle:'+digest([phase,response['source_id'],policy['id']]),
        phase_id=phase,source_id=response['source_id'],timeframe=timeframe,
        boundary_pair_id=scores.get('boundary_pair_id'),
        provider=scores.get('provider'),symbol=scores.get('symbol'),
        direction=scores['direction'],known_at_utc=signal_close,price=float(signal_row['close']),
        stop=float(bp),target=float(cp),target_basis='explicit_source_C_resistance_target',
        pattern=pattern['kind'],zone=zone,max_age_seconds=age,protection_source=protection,
        protection_mode=mode,allow_unquantified_rapid_recovery=policy.get('allow_unquantified_rapid_recovery') is True)
    signal['one_to_one_second_leg_review']=one_to_one_review
    result=finish('entry_candidate','paper_price_pattern_ready_risk_and_quote_check_next',
        signal=signal,paper_candidate=True,zone=zone,
        context_evaluations=dict({k:contexts[k] for k in rules},one_to_one_second_leg=one_to_one_review),
        protection_policy=mode,
        score_pair={k:dict(geometry=v['geometry_score'],breakout=v['breakout_score']) for k,v in scores['boundaries'].items()})
    from .book_execution_evidence import freeze_execution_evidence
    if not result['paper_candidate']:return result
    result['execution_evidence']=freeze_execution_evidence(book,result,policy)
    return result
