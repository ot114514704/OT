"""Owner-bound 1:1 delivery AND current native structure, without an entry gate.

An equal-length target is geometry, not a structural breakout. The delivery
score is reused unchanged; structural acceptance is a separate, explicitly
unfitted engineering scale. Missing context does not become zero or a bullish
vote. No stored outcome or later C version is used by this evaluator.
"""
from bisect import bisect_left, bisect_right
from datetime import datetime, timezone
from math import isclose, isfinite

from .one_to_one_second_leg_score import MINUTES, epoch, score_second_leg
from .one_to_one_second_leg_embedding import embed_second_leg_current_structure
from .native_market_sessions import adjacent_research_bars
from .live_regime_one_to_one import _RegimeIndex
from .live_push_balance_evidence import amplitude_profile

VERSION = 'owned_one_to_one_current_structure_v1'
SOURCE_MESSAGES = ['7676649229776707833', '7685764459885286786',
                   '7685764649186122721', '7685764796256176487']
KINDS = {'low': 'confirmed_swing_low_candidate',
         'high': 'confirmed_swing_high_candidate'}


def utc(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat()


def canonical_point(point):
    return dict(point, kind=KINDS.get(point.get('kind'), point.get('kind')),
                pivot_timestamp_utc=point.get('pivot_timestamp_utc') or point['timestamp_utc'],
                confirmed_at_utc=point.get('confirmed_at_utc') or point['known_at_utc'])


class NativeScoreContext:
    """One shared native input index; validate only data visible at the query.

    Full-ledger pivots are filtered by both pivot and confirmation clocks.
    Their labels remain geometric candidates, not author protected nodes.
    """
    def __init__(self, bars, timeframe, provider, symbol, *, points=(), calendar=None):
        self.bars = bars
        self.tf, self.provider, self.symbol = timeframe, provider, symbol
        self.seconds = MINUTES[timeframe] * 60
        self.calendar = calendar
        self.times = [epoch(b['timestamp_utc']) for b in bars]
        if any(a >= b for a, b in zip(self.times, self.times[1:])):
            raise ValueError('unordered_or_duplicate_native_bars')
        self.points = [canonical_point(p) for p in points]
        self.stage = _RegimeIndex(self.points)

    def _bar(self, i):
        row = self.bars[i]
        if row.get('timeframe', self.tf) != self.tf:
            raise ValueError('foreign_native_timeframe')
        if row.get('provider', self.provider) != self.provider:
            raise ValueError('foreign_provider')
        if (row.get('symbol', self.symbol) != self.symbol or
                row.get('instrument', self.symbol) != self.symbol):
            raise ValueError('foreign_symbol')
        o, h, l, c = (float(row[k]) for k in ('open', 'high', 'low', 'close'))
        if not all(map(isfinite, (o, h, l, c))) or not l <= min(o, c) <= max(o, c) <= h:
            raise ValueError('invalid_native_OHLC')
        return row

    def point_index(self, point, cutoff):
        point = canonical_point(point)
        t, k = epoch(point['pivot_timestamp_utc']), epoch(point['confirmed_at_utc'])
        i = bisect_left(self.times, t)
        if not t + self.seconds <= k <= cutoff:
            raise ValueError('point_not_confirmed_at_cutoff')
        if i >= len(self.times) or self.times[i] != t:
            raise ValueError('native_point_outside_loaded_history')
        field = {'confirmed_swing_low_candidate': 'low', 'confirmed_swing_high_candidate': 'high'}.get(point['kind'])
        if not field or not isclose(float(self._bar(i)[field]), float(point['price']), rel_tol=0, abs_tol=1e-8):
            raise ValueError('point_not_native_extreme')
        return i

    def continuous(self, lo, hi):
        for i in range(lo, hi + 1):
            self._bar(i)
            if i > lo and not adjacent_research_bars(
                    datetime.fromtimestamp(self.times[i-1], timezone.utc),
                    datetime.fromtimestamp(self.times[i], timezone.utc),
                    MINUTES[self.tf], self.calendar):
                return False
        return True

    def current_stage(self, cutoff):
        end = bisect_right(self.times, cutoff - self.seconds)
        if not end:
            return dict(state='unknown', reason='no_closed_native_bar')
        stage = self.stage.at(datetime.fromtimestamp(cutoff, timezone.utc),
                              {'pivot_timestamp_utc': utc(self.times[end-1])})
        for p in stage.get('witnesses', []):
            self.point_index(p, cutoff)
        return stage


def node_response(context, rows, point, direction, anchor, target):
    """Close-through, independent later extension, reclaim, and new attempts.

    Acceptance requires a later close past the crossing candle's directional
    extreme. A later reclaim interrupts that attempt. Wick touch is separate.
    These are engineering observations, never author wave adjudication.
    """
    price = float(point['price'])
    span = abs(target-anchor)
    distance = direction*(price-anchor)
    relation = ('behind_anchor' if distance < 0 else 'at_anchor' if distance == 0 else
                'on_projected_leg' if distance < span else 'at_target' if distance == span else 'beyond_target')
    attempt = None
    attempts = 0
    state = 'untested'
    touched_at = None
    last_failed = None
    for row in rows:
        t = epoch(row['timestamp_utc']) + context.seconds
        if t < epoch(point['confirmed_at_utc']):
            continue
        beyond = direction*(row['close']-price) > 0
        touch = row['high'] >= price if direction > 0 else row['low'] <= price
        if touch and touched_at is None:
            touched_at = utc(t)
        if attempt is not None and not beyond:
            last_failed = dict(attempt, reclaimed_at_utc=utc(t))
            attempt = None
            state = 'reclaimed_after_cross'
        elif beyond and attempt is None:
            attempts += 1
            attempt = dict(crossed_at_utc=utc(t), crossing_extreme=row['high'] if direction > 0 else row['low'],
                           accepted_at_utc=None, attempt=attempts)
            state = 'closed_through'
        elif beyond and attempt['accepted_at_utc'] is None and direction*(row['close']-attempt['crossing_extreme']) > 0:
            attempt['accepted_at_utc'] = utc(t)
            state = 'accepted_with_follow'
    if state == 'untested' and touched_at:
        state = 'wick_touch_only'
    return dict(price=price, point=point, target_relation=relation, state=state,
                attempts=attempts, active_attempt=attempt, last_failed_attempt=last_failed,
                first_touched_at_utc=touched_at, semantic_control_node=False)


def reference_node_inventory(context, opposing, source_known, direction, anchor, target,
                             frozen_rows, current_rows, current_continuous):
    """Finite declared predecessor nodes, all checked, never count as author degree."""
    result=dict(status='unavailable',nodes=[],author_control_nodes_adjudicated=False,
                coverage_scope='declared_preceding_native_wave_not_all_market_or_author_nodes')
    try:
        if (opposing.get('status')!='preceding_wave_and_local_structure_bound' or
                opposing.get('native_timeframe')!=context.tf or epoch(opposing['known_at_utc'])!=source_known):
            return dict(result,reason='source_time_predecessor_context_unbound')
        declared=opposing.get('nodes');count=opposing.get('node_count')
        if not isinstance(declared,list) or not declared:
            return dict(result,reason='node_list_not_transported',declared_count=count)
        if count is not None and count!=len(declared):
            return dict(result,reason='node_count_conflicts_with_transported_inventory',declared_count=count)
        seen=set();nodes=[];origins=0
        for n in declared:
            p=canonical_point(n['pivot']);identity=n['node_id'];role=n['role']
            if not isinstance(identity,str) or not identity or identity in seen:
                raise ValueError('ambiguous_preceding_node_identity')
            seen.add(identity)
            if role not in ('preceding_wave_origin','preceding_wave_internal_turn'):
                raise ValueError('foreign_preceding_node_role')
            if p['kind']!=('confirmed_swing_high_candidate' if direction>0 else 'confirmed_swing_low_candidate'):
                raise ValueError('reference_not_own_directional_native_boundary')
            context.point_index(p,source_known)
            start=epoch(opposing['retraced_wave']['origin']['pivot_timestamp_utc'])
            end=epoch(opposing['retraced_wave']['terminal']['pivot_timestamp_utc'])
            if not start<=epoch(p['pivot_timestamp_utc'])<end:
                raise ValueError('reference_node_outside_its_named_preceding_wave')
            if role=='preceding_wave_origin':
                original=canonical_point(opposing['retraced_wave']['origin'])
                if any(p[k]!=original[k] for k in ('pivot_timestamp_utc','price','kind')):
                    raise ValueError('whole_origin_node_does_not_match_named_wave')
                origins+=1
            frozen=node_response(context,frozen_rows,p,direction,anchor,target)
            current=node_response(context,current_rows,p,direction,anchor,target) if current_continuous else None
            nodes.append(dict(node_id=identity,role=role,pivot=p,leg_observation=frozen,
                              current_observation=current,author_control_node=False))
        if origins!=1:raise ValueError('named_whole_origin_missing_or_ambiguous')
        nodes.sort(key=lambda n:direction*(n['pivot']['price']-anchor))
        ahead=[n for n in nodes if n['leg_observation']['target_relation']!='behind_anchor']
        pending=[n for n in ahead if not n['current_observation'] or n['current_observation']['state']!='accepted_with_follow']
        return dict(result,status='all_declared_native_nodes_verified',nodes=nodes,declared_count=len(nodes),
            verified_count=len(nodes),ahead_of_anchor_count=len(ahead),
            current_ahead_nodes_all_accepted=(not pending if ahead and current_continuous else None),
            nearest_unaccepted_node_id=pending[0]['node_id'] if pending else None,
            missing_internal_nodes=False,current_history_verified=current_continuous)
    except (KeyError,TypeError,ValueError) as exc:
        return dict(result,reason=str(exc))


def source_three_push_context(family, context, cutoff):
    """Verify preceding native geometry; never reuse its target as future C.

    The source producer freezes this chain at original B. Its third push
    is already over then. Current 1:1 C is later and has its own target.
    """
    result=dict(schema='source_three_push_context_v1',state='unknown',
        source_leg_id=family.get('source_leg_id'),automatic_trade_permission=False,
        order_api_called=False,used_as_admission_gate=False,
        prospective_target=False,author_wave_degree_adjudicated=False)
    balance=family.get('same_direction_push_balance') or {}
    if balance.get('status')!='three_connected_same_direction_pushes_observed':
        return dict(result,reason='three_connected_source_pushes_unavailable')
    try:
        known=epoch(balance['known_at_utc'])
        if not known<=epoch(family['known_at_utc'])<=cutoff or balance['native_timeframe']!=context.tf:
            raise ValueError('source_three_push_clock_or_timeframe_mismatch')
        pushes,returns=balance['pushes'],balance['returns']
        if len(pushes)!=3 or len(returns)!=2:raise ValueError('source_three_push_chain_incomplete')
        chain=[pushes[0],returns[0],pushes[1],returns[1],pushes[2]]
        sign=1 if balance['direction']=='up' else -1 if balance['direction']=='down' else 0
        if not sign:raise ValueError('source_three_push_direction_unknown')
        previous=None;ids=set();checked=[]
        def identity(p):return tuple(p[k] for k in ('kind','pivot_timestamp_utc','price','confirmed_at_utc'))
        for number,leg in enumerate(chain):
            a,b=[canonical_point(leg[k]) for k in ('origin','terminal')]
            ai,bi=[context.point_index(p,known) for p in (a,b)]
            expected=sign if number%2==0 else -sign
            if not ai<bi or expected*(b['price']-a['price'])<=0 or a['kind']==b['kind']:
                raise ValueError('source_three_push_native_order_or_direction_invalid')
            if previous is not None and identity(previous)!=identity(a):
                raise ValueError('source_three_push_disconnected')
            if not context.continuous(ai,bi):raise ValueError('source_three_push_history_gap')
            length=abs(float(b['price'])-float(a['price']))
            if not isclose(float(leg['length']),length,rel_tol=0,abs_tol=1e-8):
                raise ValueError('source_three_push_length_conflict')
            if not leg.get('source_leg_id') or leg['source_leg_id'] in ids:
                raise ValueError('source_three_push_identity_ambiguous')
            ids.add(leg['source_leg_id']);previous=b
            checked.append(dict(source_leg_id=leg['source_leg_id'],origin=a,terminal=b,length=length))
        if identity(previous)!=identity(canonical_point(family['source_terminal'])):
            raise ValueError('source_three_push_does_not_end_at_original_B')
        source_sign=1 if family['source_terminal']['price']>family['source_origin']['price'] else -1
        if sign!=source_sign:raise ValueError('source_three_push_source_direction_mismatch')
        profile=amplitude_profile(checked[::2],checked[1::2],balance['direction'],balance['known_at_utc'])
        return dict(result,state='verified_source_time_background',known_at_utc=balance['known_at_utc'],
            native_timeframe=context.tf,profile=profile,
            source_push_ids=[p['source_leg_id'] for p in checked[::2]],
            current_projection_target_binding='not_claimed_preceding_third_push_already_observed')
    except (KeyError,TypeError,ValueError,OverflowError) as exc:
        return dict(result,reason=str(exc))


def evaluate_structure_score(family, projection, context, as_of):
    """Score the exact AB / retraced native leg / C, not a nearby target."""
    result = dict(schema=VERSION, measurement_id=family.get('measurement_id'),
                  source_leg_id=family.get('source_leg_id'), projection_id=projection.get('projection_id'),
                  timeframe=context.tf, provider=context.provider, symbol=context.symbol, as_of_utc=as_of,
                  status='unavailable', delivery_score=None, structure_score=None, embedded_score=None,
                  score_is_probability=False, author_formula=False, author_degree_adjudicated=False,
                  calibration_status='unvalidated_engineering_weights', automatic_trade_permission=False,
                  order_api_called=False, theory_source_message_ids=SOURCE_MESSAGES)
    try:
        cutoff = epoch(as_of)
        if (family.get('timeframe') != context.tf or not family.get('measurement_id') or
                not family.get('source_leg_id') or not projection.get('projection_id') or
                projection.get('anchor_native_timeframe') != context.tf or
                projection.get('measurement_source_leg_id') != family['source_leg_id']):
            raise ValueError('measurement_projection_identity_mismatch')
        for key, expected in (('provider', context.provider), ('symbol', context.symbol), ('instrument', context.symbol)):
            if key in family and family[key] != expected:
                raise ValueError('foreign_family_' + key)
        a, b, c = [canonical_point(p) for p in (family['source_origin'], family['source_terminal'], projection['anchor'])]
        known = max(epoch(family['known_at_utc']), epoch(projection['known_at_utc']),
                    *(epoch(p['confirmed_at_utc']) for p in (a, b, c)))
        if known > cutoff:
            return dict(result, status='not_yet_known')
        ai, bi, ci = [context.point_index(p, cutoff) for p in (a, b, c)]
        if not ai < bi < ci:
            raise ValueError('nonsequential_AB_C')
        height = abs(float(b['price'])-float(a['price']))
        target = float(projection['target'])
        if not isfinite(target) or height <= 0 or not isclose(abs(target-c['price']), height, rel_tol=1e-10, abs_tol=1e-8):
            raise ValueError('target_not_original_AB_height')
        direction = 1 if target > c['price'] else -1
        ownership = (family.get('return_ownership_by_projection_id') or {}).get(projection['projection_id']) or {}
        if (ownership.get('native_timeframe') != context.tf or
                ownership.get('measurement_source_leg_id') != family['source_leg_id'] or
                ownership.get('retraces_source_leg_id') != projection.get('retraces_source_leg_id') or
                not projection.get('retraces_source_leg_id') or epoch(ownership['known_at_utc']) > known):
            raise ValueError('return_owner_identity_or_clock_mismatch')
        ra, rb = [canonical_point(ownership[k]) for k in ('retraced_wave_origin', 'retraced_wave_terminal')]
        rai, rbi = [context.point_index(p, known) for p in (ra, rb)]
        ordinal = projection.get('ordinal')
        inside_retraced = min(ra['price'], rb['price']) < c['price'] < max(ra['price'], rb['price'])
        if not rai < rbi < ci or direction*(rb['price']-c['price']) <= 0:
            raise ValueError('C_not_a_later_return_of_own_native_leg')
        if ordinal == 2 and not inside_retraced:
            raise ValueError('second_leg_C_not_inside_original_AB')
        range_context = projection.get('range_context_at_anchor') or {}
        if ordinal != 2 and (not isinstance(ordinal,int) or ordinal < 3 or
                family.get('mode') != 'range' or range_context.get('native_timeframe') != context.tf or
                epoch(range_context['known_at_utc']) > known):
            raise ValueError('later_leg_named_range_context_unbound')
        if direction*(rb['price']-ra['price']) <= 0:
            raise ValueError('projection_direction_differs_from_own_retraced_leg')
        if projection.get('ordinal') == 2 and (ra != a or rb != b or projection['retraces_source_leg_id'] != family['source_leg_id']):
            raise ValueError('second_leg_does_not_retrace_original_AB')
        end = bisect_right(context.times, cutoff-context.seconds)
        # Existing delivery evaluator freezes at first target/C-close failure.
        f = dict(family, provider=context.provider)
        q = dict(projection, anchor=c)
        delivery = score_second_leg(f, q, context.bars[ci:end], as_of)
        result.update(delivery=delivery, delivery_score=delivery['score'], ordinal=projection.get('ordinal'),
                      projection_role='second_leg' if projection.get('ordinal') == 2 else 'later_range_leg',
                      known_at_utc=utc(known), target=target, direction=direction)
        # Continuity only through the scoring terminal; post-terminal movement
        # cannot repair or erase a finished second-leg observation.
        frozen_end = (bisect_right(context.times, delivery['last_bar_open_epoch']) if 'last_bar_open_epoch' in delivery else
                      bisect_right(context.times, epoch(delivery['terminal_bar_open_utc'])) if 'terminal_bar_open_utc' in delivery else end)
        if not context.continuous(min(ai, rai), max(ci, frozen_end-1)):
            return dict(result, status='native_history_gap_unknown', delivery_score=None)
        if delivery['score'] is None:
            return dict(result, status=delivery['status'])
        rows = context.bars[ci+1:frozen_end]
        own = node_response(context, rows, rb, direction, c['price'], target)
        nodes = dict(own_retraced_terminal=own)
        unknowns = ['author_wave_degree_unresolved', 'direct_parent_not_bound_to_this_measurement']
        opposing = family.get('source_opposing_wave_context') or {}
        prior = (opposing.get('retraced_wave') or {}).get('origin')
        opposing_terminal = (opposing.get('retraced_wave') or {}).get('terminal')
        opposing_bound = (opposing_terminal and
            canonical_point(opposing_terminal)['pivot_timestamp_utc'] == a['pivot_timestamp_utc'] and
            isclose(float(opposing_terminal['price']), float(a['price']), rel_tol=0, abs_tol=1e-8))
        if (opposing.get('status') == 'preceding_wave_and_local_structure_bound' and opposing_bound and
                opposing.get('native_timeframe') == context.tf and
                epoch(opposing['known_at_utc']) == epoch(family['known_at_utc']) <= known and prior):
            prior = canonical_point(prior)
            context.point_index(prior, known)
            nodes['preceding_whole_origin'] = node_response(context, rows, prior, direction, c['price'], target)
            if opposing.get('node_count', len(opposing.get('nodes', []))) > 1 and not opposing.get('nodes'):
                unknowns.append('compact_packet_omits_internal_preceding_nodes')
        else:
            unknowns.append('preceding_whole_origin_unbound')
        # Structural acceptance uses a fixed own-boundary denominator; a
        # missing larger origin prevents a joint structural score altogether.
        scale = dict(untested=0, wick_touch_only=0, reclaimed_after_cross=0,
                     closed_through=50, accepted_with_follow=100)
        structural = None
        if 'preceding_whole_origin' in nodes:
            structural = min(scale[n['state']] for n in nodes.values())
        observed_until = context.times[frozen_end-1] + context.seconds
        stage = context.current_stage(observed_until)
        aligned = (stage.get('direction') == ('up' if direction > 0 else 'down')) if stage.get('state') == 'trend' else None
        # Current market view is deliberately separate from the frozen leg.
        current = context.current_stage(cutoff)
        current_rows = context.bars[ci+1:end]
        current_continuous = context.continuous(ci, end-1)
        current_nodes = ({name: node_response(context, current_rows, n['point'], direction, c['price'], target)
                          for name, n in nodes.items()} if current_continuous else {})
        inventory=reference_node_inventory(context,opposing if 'preceding_whole_origin' in nodes else {},epoch(family['known_at_utc']),direction,
            c['price'],target,rows,current_rows,current_continuous)
        progress = delivery['features']['signed_target_progress']
        larger = nodes.get('preceding_whole_origin') or {}
        state = ('completed_measurement_only' if delivery.get('terminal_event') == 'target_touched' else
                 'second_leg_anchor_failed' if delivery.get('terminal_event') == 'anchor_failed' else
                 'same_bar_order_unknown' if delivery.get('terminal_event') else
                 'target_inside_larger_structure' if larger.get('target_relation') == 'beyond_target' else
                 'larger_structure_not_accepted' if structural is not None and structural < 100 else
                 'structure_context_unknown' if structural is None else 'bound_nodes_accepted')
        first_bars = bi-ai
        second_bars = max(1, frozen_end-ci-1)
        features = dict(delivery['features'], retracement_depth=abs(rb['price']-c['price'])/abs(rb['price']-ra['price']),
                        own_boundary_acceptance=scale[own['state']]/100,
                        larger_boundary_acceptance=None if not larger else scale[larger['state']]/100,
                        target_before_larger_origin=None if not larger else float(larger['target_relation'] == 'beyond_target'),
                        current_native_sequence_alignment=None if aligned is None else float(aligned),
                        velocity_relative_original_AB=max(0, progress)*first_bars/second_bars,
                        observed_second_leg_bars=second_bars)
        # Weakest-link engineering score: force cannot compensate for an
        # unaccepted boundary. This is NOT an estimated success probability.
        embedded = min(delivery['score'], structural) if structural is not None else None
        range_retired = ordinal != 2 and range_context.get('state') == 'range_boundary_accepted_exit'
        if range_retired:
            state = 'named_range_accepted_exit_before_this_C'
        alignment = ('aligned_native_sequence' if aligned is True else 'counter_native_sequence' if aligned is False else
                     'range_or_transition_sequence')
        current_embedding = embed_second_leg_current_structure(
            delivery=delivery, structure_score=structural, embedded_score=embedded,
            current_structure=dict(as_of_utc=as_of, stage=current, nodes=current_nodes,
                                   continuity='verified_research_calendar' if current_continuous else 'history_gap_unknown'),
            direction=direction, range_retired=range_retired,
            forecast_eligible=delivery['status']=='developing_observation' and not range_retired,
            three_push_context=source_three_push_context(family,context,known),
            native_source_verified=True,source_clock_verified=True)
        return dict(result, status='scored', state=state, structure_score=structural, embedded_score=embedded,
                    embedded_score_scope='breakout_evidence_only_not_local_target_completion_quality',
                    structure_embedding=dict(delivery_state=delivery['status'], boundary_state=state,
                        sequence_alignment=alignment, local_target_validity_not_determined_by_breakout_score=True,
                        retracement_scope='inside_own_retraced_leg' if inside_retraced else 'beyond_previous_leg_origin',
                        named_range_state=range_context.get('state') if ordinal!=2 else None),
                    structure_nodes=nodes,source_reference_inventory=inventory,
                    leg_stage=stage, leg_structure_as_of_utc=utc(observed_until),
                    current_structure=dict(as_of_utc=as_of, stage=current, nodes=current_nodes,
                        continuity='verified_research_calendar' if current_continuous else 'history_gap_unknown'),
                    second_leg_current_structure_embedding=current_embedding,
                    features=features, unknowns=unknowns,
                    forecast_eligible=delivery['status']=='developing_observation' and not range_retired,
                    structure_formula='minimum(own_terminal_acceptance,preceding_whole_origin_acceptance); states=0/50/100',
                    embedded_formula='minimum(delivery_score,structure_score); missing stays unknown')
    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return dict(result, status='invalid_or_unbound', reason=str(exc))


def attach_scene_scores(scene):
    """Actual MT5 scene consumer: one score per existing owned projection.

    Uses existing native ZigZag witnesses, never builds another pivot engine.
    Incomplete legacy packets remain explicit unknowns and keep their geometry.
    """
    tf, cutoff = scene['timeframe'], scene['cutoff_utc']
    rows = scene.get('execution_context', {}).get('bars', [])
    provider = scene.get('provider')
    symbol = scene.get('symbol') or scene.get('instrument')
    points = []
    for obj in scene.get('objects', []):
        if obj.get('layer') == 'zigzag':
            points.extend(p for p in obj.get('evidence', {}).values() if isinstance(p, dict) and 'price' in p)
    scored = []
    context = None
    try:
        if not provider or not symbol:
            raise ValueError('scene_market_identity_missing')
        context = NativeScoreContext(rows, tf, provider, symbol, points=points)
    except (KeyError, ValueError, TypeError) as exc:
        context_error = str(exc)
    for obj in scene.get('objects', []):
        evidence = obj.get('evidence') or {}
        if obj.get('layer') != 'one_to_one' or 'projection' not in evidence:
            continue
        if context is None:
            reading = dict(schema=VERSION, status='invalid_or_unbound', reason=context_error,
                           delivery_score=None, structure_score=None, embedded_score=None,
                           as_of_utc=cutoff, automatic_trade_permission=False)
        else:
            family = dict(evidence.get('record') or {})
            reading = evaluate_structure_score(family, evidence['projection'], context, cutoff)
        reading['object_id'] = obj['id']
        evidence['second_leg_structure_score'] = reading
        scored.append(reading)
        label = str(obj.get('label', '')).split(' | leg2_delivery=')[0]
        show = lambda v: '?' if v is None else f'{v:.1f}'
        obj['label'] = label + f" | leg2_delivery={show(reading.get('delivery_score'))} leg2_structure={show(reading.get('structure_score'))} leg2_state={reading.get('state', reading['status'])}"
    by_object = {r['object_id']: r for r in scored}
    for task in scene.get('structure_logic', {}).get('tasks', []):
        if task.get('task_id') in by_object:
            task['second_leg_structure_score'] = by_object[task['task_id']]
    scene['one_to_one_structure_scores'] = dict(schema=VERSION, as_of_utc=cutoff, readings=scored,
        scored_count=sum(r['status']=='scored' for r in scored), automatic_trade_permission=False,
        score_is_probability=False)
    return scene
