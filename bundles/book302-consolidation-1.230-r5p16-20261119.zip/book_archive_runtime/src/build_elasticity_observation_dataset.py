"""Build closed-bar, outcome-free XAUUSD elasticity observation snapshots.

This is deliberately a research extractor, not a signal generator.  Every row
is timestamped at the close of an M5 decision bar and can only consume bars
whose close is at or before that timestamp.  It keeps the Boxing / Spud
observations separate and writes no trade direction, target, stop, or outcome.
"""
import argparse
import bisect
import csv
import json
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path


FRAMES = {"M5": 5, "M15": 15, "M30": 30, "H1": 60, "H4": 240}
LOWER, UPPER = 23.6, 76.4


def parse_timestamp(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def iso(value):
    return value.isoformat().replace("+00:00", "Z")


def bucket(timestamp, minutes):
    epoch = int(timestamp.timestamp())
    return datetime.fromtimestamp(epoch - (epoch % (minutes * 60)), timezone.utc)


def load_m1(path):
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for raw in csv.DictReader(handle):
            rows.append({
                "start": parse_timestamp(raw["timestamp_utc"]),
                "open": float(raw["open"]), "high": float(raw["high"]),
                "low": float(raw["low"]), "close": float(raw["close"]),
                "provider": raw.get("provider", "unknown"),
                "symbol": raw.get("symbol", "XAUUSD"),
            })
    return sorted(rows, key=lambda row: row["start"])


def aggregate_complete(m1_rows, minutes):
    """Return only bars with every expected constituent M1 timestamp present."""
    groups = defaultdict(list)
    for row in m1_rows:
        groups[bucket(row["start"], minutes)].append(row)
    output = []
    expected_step = timedelta(minutes=1)
    for start, rows in sorted(groups.items()):
        rows.sort(key=lambda row: row["start"])
        complete = len(rows) == minutes and all(
            row["start"] == start + expected_step * index for index, row in enumerate(rows)
        )
        if not complete:
            continue
        output.append({
            "start": start,
            "end": start + timedelta(minutes=minutes),
            "open": rows[0]["open"],
            "high": max(row["high"] for row in rows),
            "low": min(row["low"] for row in rows),
            "close": rows[-1]["close"],
        })
    return output


def sma(values, index, width):
    if index < width - 1:
        return None
    window = values[index - width + 1:index + 1]
    if any(value is None for value in window):
        return None
    return sum(window) / width


def stochastic_series(bars, k_period, slowing, d_period):
    """Classic %K range, then SMA slowing and SMA D; no incomplete bar used."""
    raw_k = []
    for index, bar in enumerate(bars):
        if index < k_period - 1:
            raw_k.append(None)
            continue
        window = bars[index - k_period + 1:index + 1]
        high, low = max(item["high"] for item in window), min(item["low"] for item in window)
        raw_k.append(50.0 if high == low else 100.0 * (bar["close"] - low) / (high - low))
    slow_k = [sma(raw_k, index, slowing) for index in range(len(raw_k))]
    d_line = [sma(slow_k, index, d_period) for index in range(len(slow_k))]
    return [{"k": k, "d": d} for k, d in zip(slow_k, d_line)]


def latest_at(bars, values, decision_time):
    ends = [bar["end"] for bar in bars]
    index = bisect.bisect_right(ends, decision_time) - 1
    return (values[index], index) if index >= 0 else ({"k": None, "d": None}, None)


def finite(values):
    return [value for value in values if value is not None]


def spud_state(current, previous):
    """A documented phase descriptor, not an entry rule or historical claim."""
    lower_now = current["M5"]["k"]
    higher = finite([current[frame]["k"] for frame in ("M15", "M30", "H1")])
    if lower_now is None or not higher:
        return "unknown"
    higher_mean = sum(higher) / len(higher)
    lower_before = previous["M5"]["k"]
    if higher_mean >= UPPER and lower_now <= LOWER:
        return "lower_tf_stretching_down_against_bullish_higher_context"
    if higher_mean <= LOWER and lower_now >= UPPER:
        return "lower_tf_stretching_up_against_bearish_higher_context"
    if lower_before is not None and lower_before <= LOWER < lower_now and higher_mean >= UPPER:
        return "lower_tf_snap_back_up_confirmed"
    if lower_before is not None and lower_before >= UPPER > lower_now and higher_mean <= LOWER:
        return "lower_tf_snap_back_down_confirmed"
    if higher_mean >= UPPER and lower_now >= 50:
        return "bullish_phase_alignment_candidate"
    if higher_mean <= LOWER and lower_now <= 50:
        return "bearish_phase_alignment_candidate"
    return "mixed_or_unclassified"


def boxing_state(current, previous):
    """Keep historical 5/20/50 visual vocabulary separate from Spud MTF state."""
    fast, slow20, slow50 = current["fast_5_3_3"], current["slow_20_10_20"], current["slow_50_10_20"]
    previous_fast = previous["fast_5_3_3"]
    if any(item["k"] is None for item in (fast, slow20, slow50)):
        return "unknown"
    up = slow20["k"] > slow20["d"] and slow50["k"] > slow50["d"] if slow20["d"] is not None and slow50["d"] is not None else False
    down = slow20["k"] < slow20["d"] and slow50["k"] < slow50["d"] if slow20["d"] is not None and slow50["d"] is not None else False
    cross_up = previous_fast["k"] is not None and previous_fast["d"] is not None and previous_fast["k"] <= previous_fast["d"] and fast["k"] > fast["d"] if fast["d"] is not None else False
    cross_down = previous_fast["k"] is not None and previous_fast["d"] is not None and previous_fast["k"] >= previous_fast["d"] and fast["k"] < fast["d"] if fast["d"] is not None else False
    if up and fast["k"] <= LOWER:
        return "up_context_fast_pullback_candidate"
    if down and fast["k"] >= UPPER:
        return "down_context_fast_pullback_candidate"
    if up and cross_up:
        return "up_context_fast_recovery_candidate"
    if down and cross_down:
        return "down_context_fast_recovery_candidate"
    if up:
        return "up_context_candidate"
    if down:
        return "down_context_candidate"
    return "mixed_or_unclassified"


def build_records(m1_rows):
    frame_bars = {name: aggregate_complete(m1_rows, minutes) for name, minutes in FRAMES.items()}
    frame_stoch = {name: stochastic_series(bars, 14, 3, 3) for name, bars in frame_bars.items()}
    boxing_bars = frame_bars["M15"]
    boxing_fast = stochastic_series(boxing_bars, 5, 3, 3)
    boxing_20 = stochastic_series(boxing_bars, 20, 10, 20)
    boxing_50 = stochastic_series(boxing_bars, 50, 10, 20)
    previous_spud = {name: {"k": None, "d": None} for name in FRAMES}
    previous_boxing = {"fast_5_3_3": {"k": None, "d": None}}
    records = []
    for m5_index, m5_bar in enumerate(frame_bars["M5"]):
        decision_time = m5_bar["end"]
        spud_values = {}
        for name in FRAMES:
            value, _ = latest_at(frame_bars[name], frame_stoch[name], decision_time)
            spud_values[name] = value
        boxing_values = {}
        for name, values in (("fast_5_3_3", boxing_fast), ("slow_20_10_20", boxing_20), ("slow_50_10_20", boxing_50)):
            value, _ = latest_at(boxing_bars, values, decision_time)
            boxing_values[name] = value
        spud_phase = spud_state(spud_values, previous_spud)
        boxing_phase = boxing_state(boxing_values, previous_boxing)
        records.append({
            "snapshot_id": f"XAUUSD_ELASTICITY_{decision_time.strftime('%Y%m%dT%H%M%SZ')}",
            "instrument": "XAUUSD",
            "as_of_closed_bar_time_utc": iso(decision_time),
            "feature_only": True,
            "outcome_label": None,
            "feed": {"provider": m1_rows[0]["provider"], "source_timeframe": "M1", "aggregation_boundary": "UTC", "complete_constituent_bars_required": True},
            "spud_mtf_research": {"parameter_spec": "classic_stochastic_14_3_3_on_each_frame", "values": spud_values, "phase_state": spud_phase, "higher_timeframes": ["M15", "M30", "H1"], "interpretation": "contextual_observation_only"},
            "boxing_multispeed_research": {"chart_timeframe": "M15", "parameter_spec": ["5,3,3", "20,10,20", "50,10,20"], "values": boxing_values, "phase_state": boxing_phase, "slow_line_k_separation": None if boxing_values["slow_20_10_20"]["k"] is None or boxing_values["slow_50_10_20"]["k"] is None else abs(boxing_values["slow_20_10_20"]["k"] - boxing_values["slow_50_10_20"]["k"]), "interpretation": "contextual_observation_only"},
            "required_upstream_fields_not_available_here": ["DOL", "PD_array", "weekly_profile_as_of", "liquidity_object", "sweep", "displacement", "close_acceptance", "MSS", "spread_at_execution", "slippage_at_execution"],
            "admission": "diagnostic_only"
        })
        previous_spud = spud_values
        previous_boxing = boxing_values
    return records, {name: len(bars) for name, bars in frame_bars.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_m1_csv", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    rows = load_m1(args.input_m1_csv)
    if not rows:
        raise SystemExit("input_has_no_rows")
    records, bar_counts = build_records(rows)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
    report = {"status": "diagnostic_only", "input_rows": len(rows), "output_snapshots": len(records), "complete_bars_by_timeframe": bar_counts, "no_future_outcomes_written": True, "warning": "No DOL/PD Array/Weekly Profile/price-action gate is present; these rows are forbidden as standalone signals."}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
