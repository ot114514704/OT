"""Cooperative cancellation of superseded Book viewport work only.

No timeout or candle limit changes a valid calculation. A caller explicitly
abandons its old window; confirmed/live producers without this scope keep
their original behavior. A cancelled calculation must never be published.
"""
from contextlib import contextmanager
from contextvars import ContextVar

_CANCEL=ContextVar('book_viewport_cancel_event',default=None)


class BookCalculationSuperseded(RuntimeError):
    pass


def check_current():
    event=_CANCEL.get()
    if event is not None and event.is_set():
        raise BookCalculationSuperseded('Book_viewport_superseded')


def cancellable():
    return _CANCEL.get() is not None


@contextmanager
def viewport_scope(event):
    token=_CANCEL.set(event)
    try:
        check_current()
        yield
        check_current()
    finally:
        _CANCEL.reset(token)
