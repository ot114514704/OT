"""Closed-prefix boundary evolution, separate from frozen breakout quality.

PDF136/137 permits a pullback before reversal. Returning inside a line does
not prove original B failure, author reversal or a trade. No fitted weights.
"""
from math import isfinite
from .book_first_response_leg import close_time,clock,MINUTES


def _motion_decomposition(rows, timeframe, first, last, level, sign, atr, boundary_id, known, basis):
    """Explain an already validated frozen boundary, without adding a vote.

    Native decimal arithmetic separates price movement from the moving line.
    Both terms share one frozen ATR; no current-volatility denominator is
    substituted. A single-line observation cannot infer a revision effect.
    """
    from fractions import Fraction
    price0=Fraction(str(rows[first]['close']));price1=Fraction(str(rows[last]['close']))
    line0=Fraction(str(level(first)));line1=Fraction(str(level(last)))
    old=sign*(price0-line0);new=sign*(price1-line1)
    price=sign*(price1-price0);extension=-sign*(line1-line0)
    delta=new-old
    normalised=({k:float(v)/atr for k,v in (
        ('price_movement',price),('line_extension',extension),('distance_change',delta))}
        if atr is not None and isfinite(atr) and atr>0 else None)
    return dict(schema='frozen_boundary_motion_decomposition_v1',state='measured',
        boundary_id=boundary_id,native_timeframe=timeframe,measurement_basis=basis,
        from_bar_open_utc=rows[first]['timestamp_utc'],through_bar_open_utc=rows[last]['timestamp_utc'],
        known_at_utc=max((known,close_time(rows[last],timeframe)),key=clock),
        adverse_sign=sign,price_from=float(price0),price_through=float(price1),
        boundary_from=float(line0),boundary_through=float(line1),
        adverse_distance_from=float(old),adverse_distance_through=float(new),
        price_movement_contribution=float(price),line_extension_contribution=float(extension),
        adverse_distance_change=float(delta),exact_additive_residual=float(delta-price-extension),
        normalised_by_frozen_atr=normalised,frozen_normalisation_atr=atr,
        line_revision_contribution=None,line_revision_state='not_comparable_from_one_frozen_boundary',
        interpretation='signed_distance_change_equals_price_movement_plus_line_extension',
        source_qualification='inherited_from_validating_caller_not_proved_by_this_identity',
        adds_independent_score_vote=False,is_probability=False,automatic_trade_permission=False)


def _revision_observation(rows, timeframe, cutoff, previous, current, previous_cutoff,
                          *,observed_at_utc=None,previous_observed_at_utc=None):
    """Compare already bound outer geometries; never infer phase membership.

    The binding session validates native history and both source receipts.
    A source switch has a geometric effect even if the price does not move.
    No common frozen ATR is supplied here, so normalization stays unknown.
    """
    from fractions import Fraction
    observed_at_utc=observed_at_utc or cutoff
    base=dict(schema='book_boundary_revision_observation_v1',state='unknown',
        as_of_utc=cutoff,previous_as_of_utc=previous_cutoff,native_timeframe=timeframe,
        observed_at_utc=observed_at_utc,previous_observed_at_utc=previous_observed_at_utc,
        data_known_at_utc=cutoff,known_at_utc=max((cutoff,observed_at_utc),key=clock),
        previous_phase_id=previous.get('phase_id'),current_phase_id=current.get('phase_id'),
        previous_binding_version_id=previous.get('binding_version_id'),
        current_binding_version_id=current.get('binding_version_id'),
        previous_owner_id=previous.get('owner_id'),current_owner_id=current.get('owner_id'),
        decision_role='geometry_comparison_only_not_force_or_admission',
        lifecycle='frozen_source_switch_receipt',
        source_membership_inferred=False,normalised_by_frozen_atr=None,
        adds_independent_score_vote=False,is_probability=False,
        previous_source_events_reclassified=False,automatic_trade_permission=False)
    try:
        if previous['market']!=current['market']:
            raise ValueError('different_native_markets')
        if previous['native_timeframe']!=timeframe or current['native_timeframe']!=timeframe:
            raise ValueError('different_native_timeframes')
        old,new=previous['Book_ruler_geometry'],current['Book_ruler_geometry']
        if old['direction']!=new['direction']:
            raise ValueError('different_adverse_directions_not_comparable')
        if clock(previous_cutoff)>clock(cutoff):raise ValueError('previous_observation_is_future')
        if clock(observed_at_utc)<clock(cutoff):raise ValueError('observation_precedes_data_cutoff')
        first=max(i for i,r in enumerate(rows) if clock(close_time(r,timeframe))<=clock(previous_cutoff))
        last=len(rows)-1
        if any((clock(b['timestamp_utc'])-clock(a['timestamp_utc'])).total_seconds()!=MINUTES[timeframe]*60
               for a,b in zip(rows[first:last],rows[first+1:last+1])):
            raise ValueError('native_comparison_history_gap')
        sign=-1 if new['direction']=='up' else 1

        def geometry(model,source):
            a,b=model['start_index'],model['end_index']
            side='low' if model['direction']=='up' else 'high'
            if any(type(i) is not int for i in (a,b)) or not 0<=a<b<=last:
                raise ValueError('native_geometry_indices_unavailable')
            if any(model[k+'_price']!=rows[i][side] for k,i in (('start',a),('end',b))):
                raise ValueError('native_geometry_anchors_changed')
            if not clock(close_time(rows[b],timeframe))<=clock(model['known_at_utc'])<=clock(cutoff):
                raise ValueError('geometry_clock_invalid')
            # Reconstruct the frozen ruler from the transport model itself.
            # ``Book_ruler_geometry`` is a reduced receipt and may not carry
            # every field expected by the full boundary-freeze helper.
            identity=dict(timeframe=timeframe,direction=model['direction'],anchors=[
                [rows[a]['timestamp_utc'],model['start_price']],
                [rows[b]['timestamp_utc'],model['end_price']]])
            if model.get('owned_scope'):
                scope=model['owned_scope']
                identity['scope_context']={k:scope[k] for k in (
                    'schema','scope_id','parent_scope_id','phase_id','provider',
                    'symbol','timeframe','direction','start_price',
                    'membership_state','relation_evidence_id','start_utc')
                    if k in scope}
            supplied=source['source_identity']['ruler']
            # A later prefix may discover an owned scope for an older line.
            # That enrichment must not rewrite the older source identity.
            # Core native geometry (period, direction, two timestamp/price
            # anchors) is the invariant; an explicitly persisted scope is
            # checked only when that source actually declared one.
            core=('timeframe','direction','anchors')
            if any(supplied.get(k)!=identity.get(k) for k in core):
                raise ValueError('geometry_source_identity_changed')
            if supplied.get('scope_context') is not None and supplied.get('scope_context')!=identity.get('scope_context'):
                raise ValueError('geometry_scope_context_changed')
            slope=(Fraction(str(model['end_price']))-Fraction(str(model['start_price'])))/(b-a)
            return lambda i:Fraction(str(model['start_price']))+slope*(i-a)

        old_level,new_level=geometry(old,previous),geometry(new,current)
        if clock(old['known_at_utc'])>clock(previous_cutoff):raise ValueError('previous_geometry_not_yet_known')
        p0,p1=Fraction(str(rows[first]['close'])),Fraction(str(rows[last]['close']))
        price=sign*(p1-p0);extension=-sign*(old_level(last)-old_level(first))
        raw_revision=new_level(last)-old_level(last);revision=-sign*raw_revision
        distance0=sign*(p0-old_level(first));distance1=sign*(p1-new_level(last))
        change=distance1-distance0
        return dict(base,state='measured',reason=None,market=dict(current['market']),
            from_bar_open_utc=rows[first]['timestamp_utc'],through_bar_open_utc=rows[last]['timestamp_utc'],
            data_known_at_utc=max((cutoff,old['known_at_utc'],new['known_at_utc']),key=clock),
            known_at_utc=max((cutoff,old['known_at_utc'],new['known_at_utc'],observed_at_utc),key=clock),
            previous_construction_known_at_utc=old['known_at_utc'],
            current_construction_known_at_utc=new['known_at_utc'],adverse_sign=sign,
            old_boundary_at_previous_close=float(old_level(first)),
            old_boundary_at_current_close=float(old_level(last)),
            new_boundary_at_current_close=float(new_level(last)),
            previous_signed_distance=float(distance0),current_signed_distance=float(distance1),
            signed_distance_change=float(change),price_movement_contribution=float(price),
            previous_line_extension_contribution=float(extension),line_revision_effect=float(raw_revision),
            line_revision_contribution=float(revision),exact_additive_residual=float(change-price-extension-revision),
            interpretation='distance_change_equals_price_plus_old_line_extension_plus_same_clock_revision',
            same_clock_price_change=0.,scale_policy='raw_price_units_no_common_frozen_ATR_supplied')
    except (KeyError,TypeError,ValueError,IndexError,ArithmeticError) as error:
        return dict(base,reason=str(error))


def observe_boundary_dynamics(rows,timeframe,cutoff,index,level,sign,atr,boundary_id,known):
    base=dict(schema='book_boundary_dynamics_v1',boundary_id=boundary_id,
        timeframe=timeframe,as_of_utc=cutoff,state='unknown',
        source_pdf_pages=[136,137],automatic_trade_permission=False,
        author_reversal_confirmed=False,original_B_invalidated=False,
        score_semantics='observed_boundary_path_not_probability_or_B_stop')
    def fail(reason):return dict(base,reason=reason)
    try:
        rows=[r for r in rows if clock(close_time(r,timeframe))<=clock(cutoff)]
        if isinstance(index,bool) or not isinstance(index,int) or not 0<=index<len(rows):
            return fail('invalid_break_index')
        if sign not in (-1,1) or isinstance(sign,bool):return fail('invalid_direction')
        if not isfinite(atr) or atr<=0:return fail('invalid_frozen_normalisation')
        if clock(known)>clock(cutoff):return fail('boundary_not_known_at_cutoff')
        part=rows[index:]
        if len(part)<2:return fail('follow_close_unavailable')
        # The normalization prefix and whole observed path must be valid;
        # missing bars cannot turn an unobserved crossing into a clean hold.
        checked=rows[max(0,index-15):]
        for row in checked:
            values=[row[k] for k in ('open','high','low','close')]
            if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not isfinite(v) or v<=0 for v in values):
                return fail('invalid_native_OHLC')
            if not row['low']<=min(row['open'],row['close'])<=max(row['open'],row['close'])<=row['high']:
                return fail('invalid_native_OHLC')
        if any((clock(b['timestamp_utc'])-clock(a['timestamp_utc'])).total_seconds()!=MINUTES[timeframe]*60
               for a,b in zip(checked,checked[1:])):return fail('native_history_gap')
        from fractions import Fraction
        distances=[sign*(Fraction(str(row['close']))-level(index+j)) for j,row in enumerate(part)]
        outside=[d>0 for d in distances]
        returns=[j for j in range(1,len(part)) if distances[j]<=0 and distances[j-1]>0]
        reclaims=[j for j in range(1,len(part)) if distances[j]>0 and distances[j-1]<=0]
        last=distances[-1]
        state=('on_boundary' if last==0 else 'returned_inside' if last<0 else
               'reclaimed_after_return' if returns else 'holding_outside')
        run=0
        for holding in reversed(outside):
            if not holding:break
            run+=1
        prices=[float(r['close']) for r in part]
        excursion=[sign*(p-prices[0]) for p in prices]
        peak=max(0.,max(excursion));current=excursion[-1]
        features=dict(age_bars=len(part)-1,current_distance_atr=float(last)/atr,
            progress_atr=current/atr,maximum_progress_atr=peak/atr,
            giveback_atr=(peak-current)/atr,outside_close_fraction=sum(outside)/len(part),
            current_hold_run=run,reentry_count=len(returns),reclaim_count=len(reclaims))
        return dict(base,state=state,reason=None,features=features,
            known_at_utc=max((known,close_time(part[-1],timeframe)),key=clock),
            current_close_utc=part[-1]['timestamp_utc'],current_close=prices[-1],
            current_boundary_price=float(level(len(rows)-1)),
            first_return_known_at_utc=close_time(part[returns[0]],timeframe) if returns else None,
            latest_reclaim_known_at_utc=close_time(part[reclaims[-1]],timeframe) if reclaims else None,
            motion_from_first_break_close=_motion_decomposition(rows,timeframe,index,len(rows)-1,level,sign,atr,
                boundary_id,known,'first_break_close_to_current_close'),
            motion_last_bar=_motion_decomposition(rows,timeframe,len(rows)-2,len(rows)-1,level,sign,atr,
                boundary_id,known,'previous_closed_bar_to_current_close'),
            construction_price_basis='same_frozen_native_line',calibration_status='unfitted_dynamic_features')
    except (KeyError,TypeError,ValueError,IndexError,ArithmeticError):return fail('incomplete_native_path')
