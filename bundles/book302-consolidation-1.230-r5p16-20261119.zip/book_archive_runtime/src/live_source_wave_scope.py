"""Causal, same-period Zigzag envelope ownership for a measuring source.

An unbroken outer origin followed by another directional extreme is one
observed excursion, not a new source starting at its internal lower high (or
higher low). This is geometry only; force and task admission remain separate.
"""
from copy import deepcopy
from bisect import bisect_left, bisect_right
from datetime import timedelta
import hashlib
import json

try:
    from .live_nested_stage_review import MINUTES, _leg, _same, _time, _number
except ImportError:
    from live_nested_stage_review import MINUTES, _leg, _same, _time, _number

METHOD = 'same_period_unbroken_zigzag_envelope_v2'


class _EnvelopeWindowIndex:
    """Exact native OHLC interval bounds for one immutable inventory call.

    This indexes observations, not decisions: bad bars affect only intervals
    containing them. No future C, outcome, other period or cross-snapshot
    cache participates. Every leg's own confirmation checks still run.
    """
    def __init__(self, raw, timeframe):
        self.raw, self.timeframe = raw, timeframe
        self._components = {}
        self._terminals = {}
        self.times = sorted(raw)
        self.invalid = [0]
        size = 1
        while size < len(self.times):
            size *= 2
        self.size = size
        self.lows = [float('inf')] * (2 * size)
        self.highs = [float('-inf')] * (2 * size)
        for i, stamp in enumerate(self.times):
            bar = raw[stamp]
            valid = (isinstance(bar, dict) and bar.get('timeframe', timeframe) == timeframe
                and all(_number(bar.get(key)) for key in ('open','high','low','close'))
                and bar['low'] <= min(bar['open'],bar['close']) <= max(bar['open'],bar['close']) <= bar['high'])
            self.invalid.append(self.invalid[-1] + (not valid))
            if valid:
                self.lows[size+i], self.highs[size+i] = bar['low'], bar['high']
        for i in range(size-1, 0, -1):
            self.lows[i] = min(self.lows[2*i], self.lows[2*i+1])
            self.highs[i] = max(self.highs[2*i], self.highs[2*i+1])

    def terminal_matches(self, legs, point):
        """Exact four-field lookup inside this immutable inventory only.

        Preserve duplicate matches and original ordering. Exotic/malformed
        points retain the original equality scan, including its exceptions.
        The leg list is retained, so object-ID reuse cannot alias inventories.
        """
        if not legs:return []
        def key(p):
            values=tuple(p.get(k) for k in ('kind','price','pivot_timestamp_utc','confirmed_at_utc'))
            if any(type(v) not in (str,int,float,bool,type(None)) or
                   (type(v) is float and v!=v) for v in values):return None
            return values
        identity=id(legs)
        if identity not in self._terminals:
            index={}
            for i,leg in enumerate(legs):
                value=key(leg['terminal'])
                if value is None:
                    index=None;break
                index.setdefault(value,[]).append(i)
            self._terminals[identity]=(legs,index)
        _,index=self._terminals[identity]
        value=key(point)
        if index is None or value is None:
            return [i for i,leg in enumerate(legs) if _same(leg['terminal'],point)]
        return index.get(value,[])

    def component(self, leg, known):
        """Reuse immutable source validation, retaining each query's clock gate."""
        key=id(leg)
        if key not in self._components:
            try:
                available=max(_time(leg[p]['confirmed_at_utc']) for p in ('origin','terminal'))
                valid=known_envelope_component(leg,self.timeframe,self.raw,available)
            except (KeyError,TypeError,ValueError,AttributeError):
                return known_envelope_component(leg,self.timeframe,self.raw,known)
            # Keep the referenced leg alive for the index's immutable lifetime.
            self._components[key]=(leg,available,valid)
        _,available,valid=self._components[key]
        return valid and available<=known

    def contains(self, raw, timeframe, start, end, low, high):
        if raw is not self.raw or timeframe != self.timeframe:
            raise ValueError('envelope index belongs to another native mapping or period')
        left, right = bisect_left(self.times, start), bisect_right(self.times, end)
        if left >= right:
            return False
        if self.invalid[right] != self.invalid[left]:
            # Invalid/untyped evidence retains the direct scanner's precise
            # short-circuit and exception behavior, not a cached new policy.
            return all(bar.get('timeframe',timeframe) == timeframe and
                all(_number(bar.get(key)) for key in ('open','high','low','close')) and
                low <= bar['low'] <= min(bar['open'],bar['close']) <=
                max(bar['open'],bar['close']) <= bar['high'] <= high
                for stamp,bar in raw.items() if start <= stamp <= end)
        left, right = left+self.size, right+self.size
        minimum, maximum = float('inf'), float('-inf')
        while left < right:
            if left & 1:
                minimum, maximum = min(minimum,self.lows[left]), max(maximum,self.highs[left])
                left += 1
            if right & 1:
                right -= 1
                minimum, maximum = min(minimum,self.lows[right]), max(maximum,self.highs[right])
            left //= 2
            right //= 2
        return low <= minimum and maximum <= high


def known_envelope_component(leg, timeframe, raw, known):
    """Validate an interior OHLC observation without inventing intrabar order.

    An outside bar may contain both a confirmed high and a confirmed low.
    It cannot be a sequential source leg, but both extremes are known bounds
    inside an A/B span whose endpoints are on distinct earlier/later bars.
    """
    if _leg(leg, timeframe, raw, known):
        return True
    try:
        if (leg.get('timeframe') != timeframe or not leg.get('leg_id') or
                leg.get('temporal_order') != 'same_bar_unresolved'):
            return False
        a,b=leg['origin'],leg['terminal']
        stamp=_time(a['pivot_timestamp_utc'])
        bar=raw.get(stamp) or {}
        if (stamp != _time(b['pivot_timestamp_utc']) or
                bar.get('timeframe',timeframe) != timeframe or
                not all(_number(bar.get(k)) for k in ('open','high','low','close')) or
                not bar['low'] <= min(bar['open'],bar['close']) <= max(bar['open'],bar['close']) <= bar['high'] or
                {a['kind'],b['kind']} != {'confirmed_swing_high_candidate','confirmed_swing_low_candidate'}):
            return False
        for point in (a,b):
            key='high' if point['kind']=='confirmed_swing_high_candidate' else 'low'
            if (not _number(point['price']) or point['price'] != bar[key] or
                    not stamp+timedelta(minutes=MINUTES[timeframe]) <= _time(point['confirmed_at_utc']) <= known):
                return False
        signed=b['price']-a['price']
        # Intrabar order is unknown, so the outside-bar leg is accepted only
        # as an unordered bound. Its price sign is not promoted to a wave
        # direction; sequential legs are validated by pivot kinds in _leg.
        return bool(signed)
    except (KeyError,TypeError,ValueError):
        return False


def source_wave_scope(legs, raw, timeframe, a, b, known, *, _window_index=None):
    result = dict(method=METHOD, timeframe=timeframe, known_at_utc=str(known),
                  status='unavailable', internal_origin=False, trade_permission=False)
    try:
        known = _time(known)
        ends = (_window_index.terminal_matches(legs,b) if _window_index is not None else
                [i for i, leg in enumerate(legs) if _same(leg['terminal'], b)])
        if len(ends) != 1:
            return result
        end = ends[0]
        last = legs[end]
        # One immutable scope call has one native mapping and knowledge clock.
        # Adjacent push/return/push windows share a leg; validate it once here,
        # without carrying decisions into another prefix or source call.
        component_checks = {}

        def component_ok(part):
            key = id(part)
            if key not in component_checks:
                component_checks[key] = (_window_index.component(part,known) if _window_index is not None
                    else known_envelope_component(part, timeframe, raw, known))
            return component_checks[key]

        if not component_ok(last):
            return result
        direction = last['direction_observation']
        upward = direction == 'up'
        start = end
        cursor = end

        def envelope_ok(origin):
            """Check one proposed outer A against the fixed terminal B."""
            low, high = sorted((origin['price'], b['price']))
            path_start = _time(origin['pivot_timestamp_utc'])
            path_end = _time(b['pivot_timestamp_utc'])
            if path_start >= path_end:
                return False
            if _window_index is not None:
                return _window_index.contains(raw, timeframe, path_start, path_end, low, high)
            path = [bar for stamp, bar in raw.items() if path_start <= stamp <= path_end]
            return bool(path) and all(
                bar.get('timeframe', timeframe) == timeframe and
                all(_number(bar.get(key)) for key in ('open', 'high', 'low', 'close')) and
                low <= bar['low'] <= min(bar['open'], bar['close']) <=
                max(bar['open'], bar['close']) <= bar['high'] <= high
                for bar in path)

        # Extend only through a connected push/return/push chain. A low
        # above the preceding high is not a downward price excursion: the
        # fractal inventory may have missed an intervening extreme. Do not
        # bridge that contradiction by treating the global enclosing range
        # as one named wave or by changing the direction label alone.
        while cursor >= 2:
            previous, retrace, current = legs[cursor-2:cursor+1]
            if (not all(component_ok(part) for part in (previous, retrace, current))
                    or not _same(previous['terminal'], retrace['origin'])
                    or not _same(retrace['terminal'], current['origin'])
                    or previous['direction_observation'] != direction
                    or current['direction_observation'] != direction
                    or retrace['direction_observation'] == direction):
                break
            origin = previous['origin']
            origin_extends = (origin['price'] < legs[start]['origin']['price'] if upward
                              else origin['price'] > legs[start]['origin']['price'])
            terminal_extends = (b['price'] >= previous['terminal']['price'] if upward
                                else b['price'] <= previous['terminal']['price'])
            if not terminal_extends:
                break
            if origin_extends and envelope_ok(origin):
                start = cursor - 2
            cursor -= 2
        components = legs[start:end+1]
        origin = components[0]['origin']
        if _time(origin['pivot_timestamp_utc']) >= _time(b['pivot_timestamp_utc']):
            return result  # A single outside bar has no knowable A/B order.
        ids = [part['leg_id'] for part in components]
        digest = hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()[:24]
        source_id = f'{timeframe}:enclosing:{digest}' if len(ids)>1 else ids[0]
        result.update(status='observed_same_period_zigzag_envelope',
            internal_origin=not _same(a,origin), origin=deepcopy(origin), terminal=deepcopy(b),
            source_leg_id=source_id, component_source_leg_ids=ids,
            signed_source_length=b['price']-origin['price'],
            interior_unordered_bar_times=sorted({part['origin']['pivot_timestamp_utc']
                for part in components if part.get('temporal_order')=='same_bar_unresolved'}),
            intrabar_order_inferred=False,
            known_at_utc=known.isoformat().replace('+00:00','Z'),
            boundary='Observed connected excursion only; not a global chart extreme, author wave label or inferred lower-period ownership.')
    except (KeyError,TypeError,ValueError,AttributeError):
        return result
    return result


def dominant_source_candidates(snapshot, timeframe, legs):
    """Inventory full envelopes at B confirmation, without using C/outcomes."""
    history = ((snapshot.get('chart_history') or {}).get(timeframe) or {}).get('bars') or []
    try:
        raw = {_time(bar['timestamp_utc']):bar for bar in history}
        if len(raw) != len(history):
            return []
        cutoff = _time(snapshot['as_of_utc'])
        window_index = _EnvelopeWindowIndex(raw,timeframe)
    except (KeyError,TypeError,ValueError):
        return []
    candidates, seen = [], set()
    for leg in legs:
        try:
            a,b = leg['origin'],leg['terminal']
            if _time(b['confirmed_at_utc']) > cutoff:
                continue
            scope = source_wave_scope(legs,raw,timeframe,a,b,b['confirmed_at_utc'],_window_index=window_index)
            if not scope.get('internal_origin') or scope['source_leg_id'] in seen:
                continue
            seen.add(scope['source_leg_id'])
            candidates.append(dict(leg_id=scope['source_leg_id'],timeframe=timeframe,
                origin=scope['origin'],terminal=scope['terminal'],
                direction_observation=leg['direction_observation'],temporal_order='sequential_confirmed_extrema',
                component_source_leg_ids=scope['component_source_leg_ids'], source_wave_scope=scope))
        except (KeyError,TypeError,ValueError):
            continue
    return candidates
