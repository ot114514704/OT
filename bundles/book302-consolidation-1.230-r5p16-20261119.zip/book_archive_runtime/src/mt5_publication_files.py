"""Immutable scene-addressed transport; the ready marker is the final commit."""
import re


def write_publication_files(directory, token, scene_id, files, atomic, *, record_history=True):
    if not scene_id:
        return  # Legacy exporters without a committed scene cannot be applied as v3.
    if not re.fullmatch(r'[0-9a-f]{64}',scene_id) or not re.fullmatch(r'[0-9_]+',token):
        raise ValueError('invalid publication identity')
    prepared=None
    if record_history and 'json' in files:
        from .digger_inventory_history import prepare
        prepared=prepare(files['json'],token,scene_id)
    for suffix,data in files.items():
        path=directory/f'{token}.{scene_id}.{suffix}'
        if path.exists():
            if path.read_bytes()!=data:
                raise ValueError('immutable publication changed: '+str(path))
        else:
            atomic(path,data)
    if prepared is not None:
        from .digger_inventory_history import index_prepared
        index_prepared(directory,prepared)
