"""Check archive delivery identity and closed-bar clocks before chart admission.

This gate checks provenance, not the accuracy of the pattern classification.
It deliberately rejects production-provider candles inside an archive packet.
"""
import math
from datetime import datetime

PERIOD_MINUTES = dict(W1=10080, D1=1440, H4=240, H1=60, M30=30, M15=15, M5=5, M1=1)


def utc_epoch(value):
    try:
        instant = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if instant.tzinfo is None:
            return None
        result = instant.timestamp()
        return result if math.isfinite(result) else None
    except (AttributeError, TypeError, ValueError, OverflowError):
        return None


def packet_binding_errors(payload, timeframe):
    errors = set()
    snapshot = payload.get('snapshot') or {}
    provenance = snapshot.get('archive_window_provenance') or {}
    review = (payload.get('reviews') or {}).get(timeframe) or {}
    regime = review.get('regime_measurement_review') or {}
    cutoff = utc_epoch(snapshot.get('as_of_utc'))
    if timeframe not in PERIOD_MINUTES or snapshot.get('selected_trading_timeframe') != timeframe:
        errors.add('selected_timeframe_mismatch')
    if cutoff is None or utc_epoch(provenance.get('cutoff_utc')) != cutoff:
        errors.add('cutoff_not_bound')
    if not str(snapshot.get('snapshot_id', '')).startswith('HistData_archive_'):
        errors.add('archive_snapshot_identity_missing')
    if snapshot.get('provider') != 'HistData' or provenance.get('provider') != 'HistData':
        errors.add('archive_provider_mismatch')
    if provenance.get('production_geometry_reused') is not False or provenance.get('windowed_analysis') is not True:
        errors.add('archive_provenance_not_explicit')
    if any(row.get('automatic_trade_permission') is not False for row in (payload, snapshot, provenance, regime)):
        errors.add('archive_trade_permission_not_closed')
    for label, row in [('review', review), ('regime', regime)]:
        if any(row.get(key) != snapshot.get(key) for key in ('snapshot_id', 'as_of_utc')):
            errors.add(label + '_identity_mismatch')
        if row.get('timeframe') != timeframe:
            errors.add(label + '_timeframe_mismatch')
    if review.get('provider') != 'HistData':
        errors.add('review_provider_mismatch')
    history = snapshot.get('chart_history') or {}
    if not history.get(timeframe, {}).get('bars'):
        errors.add('selected_period_candles_missing')
    for tf, entry in history.items():
        minutes = PERIOD_MINUTES.get(tf)
        if not minutes:
            errors.add('unknown_history_period')
            continue
        if utc_epoch(entry.get('cutoff_utc')) != cutoff:
            errors.add(tf + ':history_cutoff_mismatch')
        previous = None
        bars = entry.get('bars') or []
        coverage = (provenance.get('coverage') or {}).get(tf) or {}
        if coverage.get('bars') != len(bars):
            errors.add(tf + ':coverage_count_mismatch')
        for bar in bars:
            if bar.get('provider') != 'HistData' or bar.get('timeframe') != tf or bar.get('symbol') != snapshot.get('instrument'):
                errors.add(tf + ':candle_identity_mismatch')
            time = utc_epoch(bar.get('timestamp_utc'))
            if time is None or previous is not None and time <= previous:
                errors.add(tf + ':candle_clock_not_ordered')
            if time is None or cutoff is None or time + minutes * 60 > cutoff:
                errors.add(tf + ':unclosed_or_future_candle')
            previous = time
            prices = [bar.get(k) for k in ('open', 'high', 'low', 'close')]
            if not all(isinstance(p, (int, float)) and not isinstance(p, bool) and math.isfinite(p) for p in prices):
                errors.add(tf + ':nonfinite_ohlc')
            elif not bar['low'] <= min(bar['open'], bar['close']) <= max(bar['open'], bar['close']) <= bar['high']:
                errors.add(tf + ':invalid_ohlc_envelope')
        if bars and previous is not None and coverage.get('latest_closed_end_epoch') != previous + minutes * 60:
            errors.add(tf + ':coverage_clock_mismatch')
    return sorted(errors)
