"""Bind existing FVG geometry to three exact, closed source candles.

This is provenance for the bundled geometric rule, not proof of an author
setup, displacement ownership, protected swing, or order permission.
"""
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from hashlib import sha256
import json

VERSION = 'ict_fvg_three_candle_provenance_v1'
MINUTES = {'M1': 1, 'M5': 5, 'M15': 15, 'M30': 30, 'H1': 60, 'H4': 240, 'D1': 1440, 'W1': 10080}


def _time(value):
    try:
        dt = value if isinstance(value, datetime) else datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return dt.astimezone(timezone.utc) if dt.tzinfo is not None else None
    except (TypeError, ValueError):
        return None


def _iso(value):
    return value.isoformat().replace('+00:00', 'Z')


def _number(value):
    number = Decimal(str(value))
    if not number.is_finite():
        raise ValueError('non-finite OHLC')
    return number


def bind_fvg_formation(event, bars, timeframe, cutoff, provider, instrument):
    result = dict(schema=VERSION, state='unknown', blockers=[], native_timeframe=timeframe,
                  provider=provider, instrument=instrument, candles=[],
                  owner_id=None, author_setup_verified=False, automatic_trade_permission=False)
    end, available = _time(cutoff), _time(event.get('available_at'))
    minutes = MINUTES.get(timeframe)
    if not end or not available or not minutes:
        result['blockers'] = ['native_period_or_clock_unknown']
        return result
    if available > end:
        result['blockers'] = ['formation_not_yet_available']
        return result
    if not provider or not instrument or provider in {'unknown', 'pending'} or instrument in {'unknown', 'pending'}:
        result['blockers'] = ['source_market_unknown']
        return result
    period = timedelta(minutes=minutes)
    third = available - period
    claimed_open = event.get('formation_bar_open')
    if claimed_open is not None and _time(claimed_open) != third:
        result['blockers'] = ['formation_open_close_clock_mismatch']
        return result
    wanted = [third - 2 * period, third - period, third]
    matches = {t: [] for t in wanted}
    for bar in bars or []:
        stamp = _time(getattr(bar, 'time', None))
        if stamp in matches:
            matches[stamp].append(bar)
    if any(len(matches[t]) != 1 for t in wanted):
        result['blockers'] = ['three_unique_contiguous_native_candles_missing']
        return result
    values = []
    try:
        for stamp in wanted:
            bar = matches[stamp][0]
            o, h, l, c = [_number(getattr(bar, key)) for key in ('open', 'high', 'low', 'close')]
            if l > min(o, c) or h < max(o, c) or l > h:
                raise ValueError('invalid OHLC')
            values.append((o, h, l, c))
        a, b, c = values
        if c[2] > a[1]:
            direction, lower, upper = 'bullish', a[1], c[2]
        elif c[1] < a[2]:
            direction, lower, upper = 'bearish', c[1], a[2]
        else:
            raise ValueError('not a geometric gap')
        if not b[2] <= lower < upper <= b[1]:
            raise ValueError('middle candle does not span gap')
        if (direction != event.get('direction') or lower != _number(event.get('lower'))
                or upper != _number(event.get('upper'))):
            raise ValueError('event does not match source geometry')
    except (ValueError, TypeError, InvalidOperation, AttributeError):
        result['blockers'] = ['event_or_native_ohlc_geometry_mismatch']
        return result
    candles = []
    for stamp, values in zip(wanted, values):
        row = dict(provider=provider, instrument=instrument, native_timeframe=timeframe,
                   open_at_utc=_iso(stamp), closed_at_utc=_iso(stamp + period),
                   ohlc=[str(v.normalize()) for v in values])
        row['candle_id'] = sha256(json.dumps(row, sort_keys=True).encode()).hexdigest()
        candles.append(row)
    result.update(state='three_candle_geometry_verified', candles=candles,
                  known_at_utc=_iso(available), observed_at_utc=_iso(available),
                  formation_time_basis='explicit_open_verified' if claimed_open else 'available_at_minus_native_period_verified_against_bars',
                  source_rule='bundled ict_ai.features.geometric_fvgs; author semantics unverified')
    result['formation_id'] = sha256(json.dumps([VERSION, [c['candle_id'] for c in candles], direction], sort_keys=True).encode()).hexdigest()
    return result
