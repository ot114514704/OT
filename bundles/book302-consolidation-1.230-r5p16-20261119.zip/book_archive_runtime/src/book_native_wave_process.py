"""Closed-bar whole-move hypotheses and internal excursions, before display.

PDF48-49 separates the source extreme from subsequent adjustment anchors;
PDF81-83 requires C/E/D from that same move. A confirmed local pivot is an
engineering origin hypothesis, never an author degree or completed trend.
Each prefix redetects raw pivots; no final reduced ZigZag is filtered back.
"""
from copy import deepcopy
from hashlib import sha256
import json
from math import isfinite
from .book_first_response_leg import clock,close_time,MINUTES
from .live_xauusd_multitimeframe import OHLCBar,_confirmed_fractal_candidates
from .force_strength_model import features,score,grade,measurement_receipt

VERSION='native_wave_process_v1'
FACTORS=('native_source_wave_force','native_parent_wave_force','native_scope_bottleneck')

def digest(value):
    return sha256(json.dumps(value,sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest()

def _rows(bars,tf,cutoff):
    try:
        cutoff_clock=clock(cutoff)
    except (TypeError,ValueError,OverflowError):
        raise ValueError('native_scope_clock_or_period')
    if tf not in MINUTES or cutoff_clock.utcoffset() is None:raise ValueError('native_scope_clock_or_period')
    rows=[]
    for row in bars:
        try:
            if clock(close_time(row,tf))<=cutoff_clock:
                rows.append(row)
        except (KeyError,TypeError,ValueError,OverflowError):
            raise ValueError('native_scope_prefix_clock_invalid')
    if not rows:raise ValueError('native_scope_bars_missing')
    market={k:rows[0].get(k) for k in ('provider','symbol')}
    if not all(market.values()):raise ValueError('native_scope_market_missing')
    last=None
    for r in rows:
        t=clock(r['timestamp_utc'])
        if t.utcoffset() is None or t.utcoffset().total_seconds()!=0 or (last is not None and t<=last):raise ValueError('native_scope_bar_order')
        if any(r.get(k)!=v for k,v in market.items()) or r.get('timeframe')!=tf:raise ValueError('native_scope_market_or_period_mismatch')
        values=[r[k] for k in ('open','high','low','close')]
        if (any(isinstance(v,bool) or not isinstance(v,(int,float)) or not isfinite(v) or v<=0 for v in values)
                or not r['low']<=min(r['open'],r['close'])<=max(r['open'],r['close'])<=r['high']):raise ValueError('native_scope_OHLC')
        last=t
    return rows,market


def review_outer_successors(bars,timeframe,cutoff,seed):
    """Replay chapter-3 phase events from a declared native outer source.

    This extends the native process, not the containment parent-score gate.
    Radius2 pivots and strict closed recovery are explicit engineering
    policies. Original source/ancestor identity and historical phases remain
    distinct from each successor construction; no author degree is inferred.
    """
    version='native_outer_successor_closed_recovery_v1'
    base=dict(schema=version,selection=None,admissions=[],candidates=[],
        author_degree_verified=False,eligible_for_parent_score_gate=False,
        automatic_trade_permission=False,source_pdf_pages=[67,68],
        crossing_policy='strict_native_close_beyond_prior_extreme',
        pivot_policy='existing_radius2_closed_confirmation')
    try:
        rows,market=_rows(bars,timeframe,cutoff)
        direction=seed.get('direction');up=direction=='up';sign=1 if up else -1
        if direction not in ('up','down') or not seed.get('qualified'):
            return dict(base,reason='qualified_native_seed_unavailable')
        a,d=seed['start_index'],seed['end_index'];side='low' if up else 'high';other='high' if up else 'low'
        if any(type(i) is not int for i in (a,d)) or not 0<=a<d<len(rows):
            return dict(base,reason='seed_native_anchors_unavailable')
        pa,pd=rows[a][side],rows[d][side];slope=(pd-pa)/(d-a)
        if pa!=seed['start_price'] or pd!=seed['end_price'] or sign*slope<=0 or abs(seed['slope']-slope)>1e-10:
            return dict(base,reason='seed_native_geometry_mismatch')
        if any(sign*(rows[k][side]-(pa+slope*(k-a)))<=0 for k in range(a+1,d)):
            return dict(base,reason='seed_native_outer_cross_or_contact')
        native=[OHLCBar(clock(r['timestamp_utc']),r['open'],r['high'],r['low'],r['close'],
                       provider=market['provider'],symbol=market['symbol'],timeframe=timeframe) for r in rows]
        points=_confirmed_fractal_candidates(native)
        pos={clock(r['timestamp_utc']).timestamp():i for i,r in enumerate(rows)}
        points=[dict(p,index=pos[clock(p['pivot_timestamp_utc']).timestamp()]) for p in points]
        wanted='confirmed_swing_low_candidate' if up else 'confirmed_swing_high_candidate'
        adverse={p['index']:p for p in points if p['kind']==wanted}
        favorable={p['index']:p for p in points if p['kind']!=wanted}
        if a not in adverse or d not in adverse:
            return dict(base,reason='seed_native_origins_not_confirmed')
        c=(max if up else min)(range(a+1,d),key=lambda k:rows[k][other])
        if c not in favorable:return dict(base,reason='seed_prior_extreme_not_confirmed')
        seconds=MINUTES[timeframe]*60
        root_scope='native_scope:'+digest([market,timeframe,clock(rows[a]['timestamp_utc']).timestamp(),side,pa])[:24]
        def phase(i,j):return 'native_outer_phase:'+digest([market,timeframe,rows[i]['timestamp_utc'],rows[i][side],rows[j]['timestamp_utc'],rows[j][side]])[:24]
        def point(k,kind):
            p=(adverse if kind==side else favorable)[k]
            return dict(index=k,bar_open_utc=rows[k]['timestamp_utc'],price=rows[k][kind],confirmed_at_utc=p['confirmed_at_utc'])
        base.update(parent_scope_id=root_scope,root_phase_id=phase(a,d),ancestor_origin=point(a,side),
                    reconstruction_basis='loaded_closed_prefix_first_calculable_not_actual_first_observation')
        previous=phase(a,d);previous_known=max(adverse[a]['confirmed_at_utc'],adverse[d]['confirmed_at_utc'],favorable[c]['confirmed_at_utc'],key=clock)
        original=deepcopy(seed);preceding=deepcopy(seed);last_admission_index=d;phase_start=a
        while True:
            admitted=None
            for f,fp in adverse.items():
                if f<=d:continue
                possible=[k for k in favorable if d<k<f]
                if not possible:continue
                e=(max if up else min)(possible,key=lambda k:rows[k][other])
                if e<=last_admission_index:continue
                if sign*(rows[e][other]-rows[c][other])<=0:continue
                # E is the actual running extreme, F its subsequent deepest
                # return. Equal or competing terminal pivots stay explicit.
                if any(sign*(rows[k][other]-rows[e][other])>0 for k in range(d+1,f)):
                    continue
                from .book_boundary_freeze import ruler_identity
                event=dict(parent_scope_id=root_scope,previous_phase_id=previous,candidate_phase_id=phase(d,f),
                    predecessor_ruler_identity=ruler_identity(rows,preceding,timeframe),
                    successor_ruler_identity=dict(timeframe=timeframe,direction=direction,
                        anchors=[[rows[k]['timestamp_utc'],rows[k][side]] for k in (d,f)]),
                    D=point(d,side),E=point(e,other),F=point(f,side),
                    F_occurrence_at=rows[f]['timestamp_utc'],F_confirmation_at=fp['confirmed_at_utc'],
                    F_confirmed=True,
                    geometry_available=False,admitted=False,failure_reasons=[],
                    verification_rule_version=version,author_degree_verified=False,
                    eligible_for_parent_score_gate=False,automatic_trade_permission=False)
                recovery=next((k for k in range(f+1,len(rows)) if sign*(rows[k]['close']-rows[e][other])>0),None)
                event['first_recovery_index']=recovery
                event['first_recovery_known_at_utc']=close_time(rows[recovery],timeframe) if recovery is not None else None
                end=recovery if recovery is not None else len(rows)-1
                if any(sign*(rows[k][side]-rows[f][side])<0 for k in range(e+1,end+1)):
                    continue  # this F has already been superseded by a deeper return
                m=(rows[f][side]-rows[d][side])/(f-d)
                gaps=[k for k in range(a+1,end+1) if (clock(rows[k]['timestamp_utc'])-clock(rows[k-1]['timestamp_utc'])).total_seconds()!=seconds]
                clear=[sign*(rows[k][side]-(rows[d][side]+m*(k-d))) for k in range(d+1,end+1) if k!=f]
                ambiguous=any(k in favorable for k in (d,f))
                if ambiguous:event['failure_reasons'].append('same_native_bar_opposing_extremes_unknown')
                if gaps:event['failure_reasons'].append('native_phase_history_gap')
                if sign*m<=0 or not clear or min(clear)<=1e-9:event['failure_reasons'].append('successor_outer_cross_contact_or_wrong_direction')
                else:event['geometry_available']=True
                if any(sign*(rows[k][side]-pa)<0 for k in range(a+1,end+1)):
                    event['failure_reasons'].append('ancestor_origin_broken_before_admission')
                if any(sign*(rows[k]['close']-(original['start_price']+original['slope']*(k-a)))<0 for k in range(original['end_index']+1,end+1)):
                    event['failure_reasons'].append('ancestor_outer_closed_break_requires_separate_state')
                if any(sign*(rows[k]['close']-(preceding['start_price']+preceding['slope']*(k-preceding['start_index'])))<0
                       for k in range(preceding['end_index']+1,end+1)):
                    event['failure_reasons'].append('predecessor_outer_closed_break_requires_separate_state')
                if recovery is None:event['failure_reasons'].append('closed_recovery_beyond_E_unobserved')
                elif clock(fp['confirmed_at_utc'])>clock(close_time(rows[recovery],timeframe)):
                    event['failure_reasons'].append('recovery_before_F_confirmation')
                known=max([previous_known,fp['confirmed_at_utc'],favorable[e]['confirmed_at_utc']]+([close_time(rows[recovery],timeframe)] if recovery is not None else []),key=clock)
                event.update(admission_known_at_utc=known if not event['failure_reasons'] else None,
                    recovery_event_id=('native_recovery:'+digest([market,timeframe,rows[e]['timestamp_utc'],rows[e][other],favorable[e]['confirmed_at_utc'],rows[recovery]['timestamp_utc'],rows[recovery]['close'],version])[:24]) if recovery is not None else None)
                native_point=lambda p:{k:v for k,v in p.items() if k!='index'}
                event['event_chain_id']='native_phase_chain:'+digest([market,timeframe,previous,event['candidate_phase_id'],
                    *[native_point(event[k]) for k in ('D','E','F')],event['recovery_event_id'],known,version])[:24]
                if event['failure_reasons']:
                    base['candidates'].append(event);continue
                event['admitted']=True
                event['geometry_receipt_id']='native_phase_geometry:'+digest([market,timeframe,rows[d]['timestamp_utc'],rows[f]['timestamp_utc'],rows[d][side],rows[f][side],m,known])[:24]
                from .pdf_trendline_block import _parallel_projection,_axis_alignment_diagnostic,PDF_RULE_ID,PDF_SOURCE_SHA256
                first_break=next((k for k in range(recovery+1,len(rows)) if sign*(rows[k]['close']-(rows[d][side]+m*(k-d)))<0),None)
                selected=dict(qualified=True,status='observed_native_successor_outer',direction=direction,
                    start_index=d,end_index=f,start_price=rows[d][side],end_price=rows[f][side],slope=m,
                    start_utc=rows[d]['timestamp_utc'],end_utc=rows[f]['timestamp_utc'],
                    first_break_index=first_break,anchor_span_bars=f-d,anchor_count=2,
                    opposite_extreme_index=recovery,second_anchor_index=f,
                    min_clearance=min(clear),mean_clearance=sum(clear)/len(clear),
                    known_at_utc=known,timeframe=timeframe,rule_id=PDF_RULE_ID,source_pdf_sha256=PDF_SOURCE_SHA256,
                    source_rule_pages=[48,49,67,68],no_internal_candle_crossing=True,future_bars_used=False,
                    anchor_selection='event_admitted_successor_DF_not_window_ratio',
                    anchor_order_rule='F_confirmed_then_closed_recovery_beyond_E',
                    anchor_order_proof=dict(second_anchor_index=f,opposite_extreme_index=recovery,valid=True),
                    phase_id=event['candidate_phase_id'],previous_phase_id=previous,parent_scope_id=root_scope,
                    ancestor_origin=base['ancestor_origin'],root_phase_id=base['root_phase_id'],
                    phase_relation='successor_phase',successor_admission=deepcopy(event),
                    selection_prefix_end_index=recovery,selection_prefix_end_utc=rows[recovery]['timestamp_utc'],
                    context_selection_basis='event_admitted_native_successor',
                    read_only=True,trade_permission=False,author_wave_degree='unknown',automatic_trade_permission=False)
                selected['parallel_projection']=_parallel_projection(rows[:recovery+1],selected,up)
                selected['axis_alignment']=_axis_alignment_diagnostic(rows,d,f,recovery,m,up)
                selected['axis_alignment_score']=selected['axis_alignment']['score']
                # The phase origin D is a range role, separate from whatever
                # legal outer contacts a later geometry selection may use.
                # Reuse this native event lineage; do not invent a parent
                # from price containment or infer an author wave degree.
                from .book_owned_scope import SCHEMA as OWNED_SCOPE_SCHEMA
                selected['owned_scope']=dict(schema=OWNED_SCOPE_SCHEMA,
                    scope_id='native_scope:'+digest([market,timeframe,clock(rows[d]['timestamp_utc']).timestamp(),side,rows[d][side]])[:24],
                    parent_scope_id=root_scope,phase_id=selected['phase_id'],
                    provider=market['provider'],symbol=market['symbol'],timeframe=timeframe,
                    direction=direction,start_utc=rows[d]['timestamp_utc'],start_price=rows[d][side],
                    known_at_utc=known,relation_evidence_id=event['event_chain_id'],
                    membership_state='native_event_admitted_not_author_degree')
                admitted=(f,e,known,selected,event);break
            if admitted is None:
                # The observed return extreme exists before radius2 can
                # confirm it. Preserve that developing state without granting
                # a construction, stage transition, or parent-score vote.
                later=[k for k in favorable if k>d and k>last_admission_index and k<len(rows)-1]
                if later:
                    e=(max if up else min)(later,key=lambda k:rows[k][other])
                    if sign*(rows[e][other]-rows[c][other])>0:
                        f=(min if up else max)(range(e+1,len(rows)),key=lambda k:rows[k][side])
                        if f not in adverse:
                            base['candidates'].append(dict(parent_scope_id=root_scope,
                                previous_phase_id=previous,candidate_phase_id=phase(d,f),
                                D=point(d,side),E=point(e,other),
                                F=dict(index=f,bar_open_utc=rows[f]['timestamp_utc'],price=rows[f][side],confirmed_at_utc=None),
                                F_occurrence_at=rows[f]['timestamp_utc'],F_occurrence_known_at=close_time(rows[f],timeframe),
                                F_confirmation_at=None,F_confirmed=False,state='developing_return_extreme',
                                known_at_utc=cutoff,admitted=False,admission_known_at_utc=None,
                                failure_reasons=['F_unconfirmed'],verification_rule_version=version,
                                author_degree_verified=False,eligible_for_parent_score_gate=False,
                                automatic_trade_permission=False))
                break
            f,e,known,selected,event=admitted
            base['admissions'].append(event);base['selection']=selected
            preceding=selected
            phase_start,d,c,previous,previous_known=d,f,e,event['candidate_phase_id'],known
            last_admission_index=event['first_recovery_index']
        return dict(base,reason=None if base['selection'] else 'successor_event_dependencies_incomplete')
    except (KeyError,ValueError,TypeError,IndexError,ArithmeticError) as error:
        return dict(base,reason='native_successor_identity_clock_or_geometry_unavailable',diagnostic=type(error).__name__)

from .book_calculation_scope import reuse_native_wave_process

@reuse_native_wave_process
def recognize_wave_process(bars,timeframe,cutoff,*,bound_origin=None):
    """Rebuild open native excursions. A local return never erases its parent.

    A scope survives while its origin is unbroken; this means a hypothesis
    remains possible, NOT that the old trend or its Book entry remains valid.
    Parentage is an observed same-period OHLC path relationship. Post-extreme
    returns have a separate role and never extend the parent's frozen A-B.
    """
    rows,market=_rows(bars,timeframe,cutoff);seconds=MINUTES[timeframe]*60
    times=[clock(r['timestamp_utc']).timestamp() for r in rows];pos={t:i for i,t in enumerate(times)}
    native=[OHLCBar(clock(r['timestamp_utc']),r['open'],r['high'],r['low'],r['close'],
                    provider=market['provider'],symbol=market['symbol'],timeframe=timeframe) for r in rows]
    points=_confirmed_fractal_candidates(native)
    if bound_origin is not None:
        p=deepcopy(bound_origin);i=pos.get(p['point'][0]);side='low' if p['direction']=='up' else 'high'
        if (p['direction'] not in ('up','down') or isinstance(p['point'][1],bool)
                or i is None or p['point'][1]!=rows[i][side] or clock(p['known_at_utc'])>clock(cutoff)
                or clock(p['known_at_utc'])<clock(close_time(rows[i],timeframe))):raise ValueError('native_scope_bound_origin_invalid')
        if not any(clock(q['pivot_timestamp_utc']).timestamp()==times[i] and q['price']==p['point'][1]
                   and q['kind']==('confirmed_swing_low_candidate' if side=='low' else 'confirmed_swing_high_candidate') for q in points):
            points.append(dict(pivot_timestamp_utc=rows[i]['timestamp_utc'],price=p['point'][1],
                kind='confirmed_swing_low_candidate' if side=='low' else 'confirmed_swing_high_candidate',
                confirmed_at_utc=p['known_at_utc'],source='existing_qualified_book_native_origin'))
    # First future strict crossing of each origin, in linear time. No future
    # bar is in rows, including when the caller supplied a full poisoned file.
    crossings={}
    for side,compare in [('high',lambda a,b:a>b),('low',lambda a,b:a<b)]:
        stack=[];next_cross=[None]*len(rows)
        for i,r in enumerate(rows):
            while stack and compare(r[side],rows[stack[-1]][side]):next_cross[stack.pop()]=i
            stack.append(i)
        crossings[side]=next_cross
    raw=[[t,r['open'],r['high'],r['low'],r['close']] for t,r in zip(times,rows)]
    active=[];retired=[];by_id={}
    for p in points:
        i=pos[clock(p['pivot_timestamp_utc']).timestamp()];up=p['kind']=='confirmed_swing_low_candidate'
        side='low' if up else 'high';direction='up' if up else 'down'
        sid='native_scope:'+digest([market,timeframe,times[i],side,p['price']])[:24]
        if sid in by_id:continue
        record=dict(scope_id=sid,timeframe=timeframe,direction=direction,origin=[times[i],p['price']],
            origin_known_at_utc=p['confirmed_at_utc'],origin_seed=p.get('source','existing_radius_2_raw_confirmed_pivot'),
            author_degree_verified=False,automatic_trade_permission=False)
        broken=crossings[side][i]
        if broken is not None:
            record.update(state='origin_broken',broken_at_utc=close_time(rows[broken],timeframe),
                break_observed_before_origin_confirmation=clock(close_time(rows[broken],timeframe))<clock(p['confirmed_at_utc']))
        stop=broken if broken is not None else len(rows)
        if i+1>=stop:
            record.update(state='origin_broken' if broken is not None else 'awaiting_post_origin_bar')
            by_id[sid]=record
            (retired if broken is not None else active).append(record)
            continue
        favorable='high' if up else 'low'
        # Earliest equal extreme is retained; no unnoticed terminal rewrite.
        j=(max if up else min)(range(i+1,stop),key=lambda k:rows[k][favorable])
        b=[times[j],rows[j][favorable]];lo,hi=sorted([p['price'],b[1]])
        envelope=all(lo<=r['low'] and r['high']<=hi for r in rows[i:j+1])
        known=max(clock(p['confirmed_at_utc']),clock(close_time(rows[j],timeframe))).isoformat().replace('+00:00','Z')
        # The unchanged force formula consumes A..B and at most21 candles
        # immediately before A. Repeatedly filtering the entire chart for
        # every origin added two whole-chart scans per native scope. Later
        # adjustment candles have no part in this frozen force measurement.
        measured=raw[max(0,i-21):j+1]
        f=features(measured,dict(points=[record['origin'],b],known_at_utc=known),seconds,observed_bars_only=True)
        value,components=score(f)
        if not envelope:value=None
        profile=dict(score=value,quality=grade(value),features=f,components=components,
            scope_id=sid,range_version='native_range:'+digest([sid,b])[:24],points=[record['origin'],b],
            known_at_utc=known,as_of_utc=cutoff,model_status='unfitted_existing_engineering_formula',
            score_is_probability=False,continuity_verified=not f.get('gaps') and f.get('status')=='observed',
            eligible_for_score_gate=broken is None and envelope and value is not None and not f.get('gaps'))
        profile['measurement_receipt']=measurement_receipt(measured,dict(points=[record['origin'],b],known_at_utc=known),
            seconds,provider=market['provider'],symbol=market['symbol'],timeframe=timeframe,
            domain='native_scope_excursion_description')
        record.update(terminal=b,terminal_close_utc=close_time(rows[j],timeframe),
            observed_through_utc=close_time(rows[stop-1],timeframe),known_at_utc=known,
            formation_envelope_verified=envelope,confirmation_state='developing_extreme_not_completed_author_wave',
            state='origin_broken' if broken is not None else 'extending' if j==len(rows)-1 else 'return_after_observed_extreme',
            current_retention_fraction=(rows[stop-1]['close']-p['price'])/(b[1]-p['price']) if b[1]!=p['price'] else None,
            force_profile=profile,parent_scope_id=None,parent_relation=None,ancestor_scope_ids=[])
        if broken is not None:
            simultaneous=rows[broken][favorable]>b[1] if up else rows[broken][favorable]<b[1]
            record.update(confirmation_state='historical_excursion_origin_broken_not_author_wave',
                historical_range_state='pre_break_range_only_same_bar_order_unknown' if simultaneous else 'completed_excursion_before_origin_breach',
                break_bar_both_extremes=simultaneous)
            # Historical child ranges remain usable as evidence of the parent
            # path. Keep a compact frozen profile, never an eligible live vote.
            record['force_profile']={k:v for k,v in profile.items() if k not in ('features','components')}
            record['force_profile']['feature_status']=f.get('status')
            retired.append(record)
        else:active.append(record)
        by_id[sid]=record
    scopes=active+retired
    for child in scopes:
        if not child.get('formation_envelope_verified'):continue
        candidates=[]
        ca,cb=child['origin'],child['terminal']
        for parent in scopes:
            if not parent.get('formation_envelope_verified') or parent['origin'][0]>=ca[0]:continue
            pa,pb=parent['origin'],parent['terminal'];low,high=sorted([pa[1],pb[1]])
            if cb[0]+seconds>clock(parent['observed_through_utc']).timestamp():continue
            if low<=min(ca[1],cb[1]) and max(ca[1],cb[1])<=high:
                relation=('internal_forward_stage' if parent['direction']==child['direction'] else 'internal_return_stage') if cb[0]<=pb[0] else 'post_extreme_return_candidate'
                candidates.append((pb[0]-pa[0],abs(pb[1]-pa[1]),parent['scope_id'],relation))
        if candidates:
            candidates.sort()
            if len(candidates)>1 and candidates[0][:2]==candidates[1][:2]:
                child['ambiguous_parent_scope_ids']=[c[2] for c in candidates if c[:2]==candidates[0][:2]]
                continue
            _,_,pid,relation=candidates[0]
            child.update(parent_scope_id=pid,parent_relation=relation,
                membership_known_at_utc=max(clock(child['known_at_utc']),clock(by_id[pid]['known_at_utc'])).isoformat().replace('+00:00','Z'),
                candidate_parent_scope_ids=[c[2] for c in candidates],
                membership_basis='confirmed_native_origins_and_verified_closed_OHLC_path_not_author_degree')
    for child in scopes:
        ancestors=[];pid=child.get('parent_scope_id')
        while pid:
            ancestors.append(pid);pid=by_id[pid].get('parent_scope_id')
        child['ancestor_scope_ids']=ancestors
        parent=by_id.get(child.get('parent_scope_id')) or {}
        profile=child.get('force_profile') or {};parent_profile=parent.get('force_profile') or {}
        topology=dict(parent_scope_id=child.get('parent_scope_id'),parent_relation=child.get('parent_relation'),
                      ancestor_scope_ids=ancestors,ambiguous_parent_scope_ids=child.get('ambiguous_parent_scope_ids') or [])
        membership_known=max([child.get('known_at_utc') or child['origin_known_at_utc']]+
            [by_id[pid].get('known_at_utc') or by_id[pid]['origin_known_at_utc'] for pid in ancestors],key=clock)
        child['membership_known_at_utc']=membership_known
        child['membership_id']='native_membership:'+digest([child['scope_id'],topology])[:24]
        child['membership_receipt']=dict(topology,scope_id=child['scope_id'],membership_id=child['membership_id'],
            child_range_version=profile.get('range_version'),parent_range_version=parent_profile.get('range_version'),
            known_at_utc=membership_known,
            basis='current_prefix_native_path_not_author_degree',
            relation_state='containment_candidate',event_chain_verified=False,
            eligible_for_parent_score_gate=False)
        child['membership_receipt']['evidence_id']='native_membership_evidence:'+digest(child['membership_receipt'])[:24]
    # A graph is not a global directional vote. Keep both directions and the
    # original identities; the caller must explicitly bind a named source.
    return dict(schema=VERSION,timeframe=timeframe,as_of_utc=cutoff,market=market,
        native_input_sha256=digest(rows),active=sorted(active,key=lambda r:r['scope_id']),
        retired=sorted(retired,key=lambda r:r['scope_id']),
        author_wave_degree='unknown',entry_permission=False,
        automatic_trade_permission=False,source_pdf_pages=[48,49,81,83],
        method='existing_radius_2_raw_pivots_plus_qualified_Book_origin; surviving_excursions_are_hypotheses',
        future_bars_used=False)

def score_book_wave_process(bars,timeframe,cutoff,book,card):
    """Attach actual source/parent readings; never transfer a child's score."""
    base=dict(schema='book_native_scope_score_v1',state='unknown',reason=None,source_scope_id=None,
        parent_scope_id=None,source_profile=None,parent_profile=None,bottleneck_score=None,
        eligible_for_score_gate=False,is_probability=False,entry_permission=False,automatic_trade_permission=False)
    try:
        rows,_=_rows(bars,timeframe,cutoff);line=book.get('turning_point_line') or {};origin=None
        if (not card.get('reason') and card.get('phase_id') and line.get('qualified')
                and line.get('direction') in ('up','down') and line.get('known_at_utc')):
            from .book_owned_scope import resolve_owned_scope
            scope=resolve_owned_scope(rows,line);i=scope['start_index']
            side='low' if line['direction']=='up' else 'high'
            origin=dict(point=[clock(rows[i]['timestamp_utc']).timestamp(),rows[i][side]],
                direction=line['direction'],known_at_utc=line['known_at_utc'])
            if scope['binding'] is not None:
                base['owned_scope_binding']=scope['binding']
                origin['known_at_utc']=max((line['known_at_utc'],scope['binding']['known_at_utc']),key=clock)
        process=recognize_wave_process(rows,timeframe,cutoff,bound_origin=origin)
        # The full detector remains reproducible from OHLC. Keep the runtime
        # card compact: historical child measurements/edges survive without
        # repeating every force component and every competing parent list.
        def compact(s):
            keep=('scope_id','timeframe','direction','origin','terminal','origin_known_at_utc','known_at_utc',
                  'state','confirmation_state','broken_at_utc','historical_range_state','break_bar_both_extremes',
                  'formation_envelope_verified','parent_scope_id','parent_relation','ancestor_scope_ids',
                  'membership_known_at_utc','ambiguous_parent_scope_ids','membership_id','membership_receipt')
            item={k:deepcopy(s[k]) for k in keep if k in s}
            profile=s.get('force_profile')
            if profile:item['force_profile']={k:deepcopy(profile[k]) for k in ('score','scope_id','range_version',
                'points','known_at_utc','as_of_utc','eligible_for_score_gate','continuity_verified','measurement_receipt') if k in profile}
            return item
        base['recognition']={k:v for k,v in process.items() if k not in ('active','retired')}
        base['recognition'].update(active=[compact(s) for s in process['active']],retired=[compact(s) for s in process['retired']],
                                  profile_detail='Bound source/parent retain full readings below; other ranges are reproducible from native OHLC.')
        if card.get('reason') or not card.get('phase_id') or origin is None:
            return dict(base,reason=card.get('reason') or 'same_native_Book_source_unavailable')
        from .book_boundary_freeze import ruler_identity
        from .book_breakout_assessment import digest as boundary_digest
        expected=dict(ruler=ruler_identity(rows,line,timeframe),provider=process['market']['provider'],symbol=process['market']['symbol'])
        if (not expected['ruler'] or card.get('source_identity')!=expected
                or card['phase_id']!='book_break_phase:'+boundary_digest(expected)):
            return dict(base,reason='native_scope_Book_source_identity_mismatch')
        current_records={r['scope_id']:r for r in process['active']+process['retired']}
        matching=[r for r in current_records.values() if r['origin']==origin['point'] and r['direction']==origin['direction']]
        sid=matching[0]['scope_id'] if len(matching)==1 else None
        if (origin is not None and line.get('owned_scope',{}).get('membership_state')=='native_event_admitted_not_author_degree'
                and sid!=line['owned_scope']['scope_id']):
            return dict(base,reason='native_scope_event_source_identity_mismatch')
        source=current_records.get(sid) or {}
        base.update(source_scope_id=sid,source_state=source.get('state'),phase_id=card['phase_id'],source_id=card.get('source_id'),
                    source_identity=deepcopy(card.get('source_identity')),source_origin_known_at_utc=origin['known_at_utc'],
                    current_membership_receipt=deepcopy(source.get('membership_receipt')),
                    known_at_utc=origin['known_at_utc'],as_of_utc=cutoff)
        # After a first boundary break, the old formation's measuring range
        # stops BEFORE that break. Subsequent extensions belong to the current
        # process packet but cannot improve the frozen old trend measurement.
        breaks=[e['break_index'] for e in (book.get('first_closed_break') or {},book.get('parallel_break') or {})
                if e.get('status')=='observed_candidate' and type(e.get('break_index')) is int]
        formation=min(breaks,default=len(rows))
        if not 0<formation<=len(rows):return dict(base,reason='native_scope_formation_clock_invalid')
        formation_rows=rows[:formation];formation_cutoff=close_time(formation_rows[-1],timeframe)
        if formation<len(rows):
            frozen=recognize_wave_process(formation_rows,timeframe,formation_cutoff,bound_origin=origin)
            records={r['scope_id']:r for r in frozen['active']+frozen['retired']}
            measured=records.get(sid) or {}
        else:records=current_records;measured=source
        base.update(formation_through_utc=formation_cutoff,range_frozen_before_first_break=bool(breaks))
        source=measured
        profile=source.get('force_profile');base['source_profile']=deepcopy(profile)
        parent=records.get(source.get('parent_scope_id')) or {};base.update(parent_scope_id=parent.get('scope_id'),
            parent_relation=source.get('parent_relation'),parent_profile=deepcopy(parent.get('force_profile')),
            ancestor_scope_ids=source.get('ancestor_scope_ids') or [],membership_receipt=deepcopy(source.get('membership_receipt')))
        # The origin being known does not make a later terminal's numerical
        # reading known. Each factor and the joined membership keep their own
        # dependencies, including when an older Book ruler stays selected.
        parent_profile=base['parent_profile'] or {};membership=base['membership_receipt'] or {}
        own_known=max((origin['known_at_utc'],(profile or {}).get('known_at_utc') or origin['known_at_utc']),key=clock)
        parent_known=max((parent_profile['known_at_utc'],origin['known_at_utc']),key=clock) if parent_profile.get('known_at_utc') else None
        joined_known=max([own_known]+[t for t in (parent_known,membership.get('known_at_utc')) if t],key=clock)
        if clock(joined_known)>clock(cutoff):return dict(base,reason='native_scope_measurement_not_yet_known')
        base.update(source_measurement_known_at_utc=own_known,parent_measurement_known_at_utc=parent_known,
            scoring_membership_reference='frozen_before_first_boundary' if breaks else 'current_formation',
            membership_changed_since_scoring=(base.get('current_membership_receipt') or {}).get('membership_id')!=membership.get('membership_id'),
            known_at_utc=joined_known,measurement_receipt=dict(source_range_version=(profile or {}).get('range_version'),
                parent_range_version=parent_profile.get('range_version'),membership_evidence_id=membership.get('evidence_id'),
                formation_through_utc=formation_cutoff,source_known_at_utc=own_known,
                parent_known_at_utc=parent_known,joined_known_at_utc=joined_known))
        base['usage_receipt']=dict(source_scope_id=sid,phase_id=card['phase_id'],source_id=card.get('source_id'),
            timeframe=timeframe,market=process['market'],source_identity=deepcopy(card['source_identity']),
            membership_evidence_id=membership.get('evidence_id'),
            measurement_id=((profile or {}).get('measurement_receipt') or {}).get('measurement_id'),
            known_at_utc=joined_known,as_of_utc=cutoff,
            role='descriptive_measurement_not_parent_membership_confirmation')
        base['usage_receipt']['usage_id']='native_force_use:'+digest({k:v for k,v in base['usage_receipt'].items() if k!='as_of_utc'})[:24]
        if not profile or profile['score'] is None:return dict(base,reason='native_source_range_or_normalisation_unavailable')
        if base['source_state']=='origin_broken':return dict(base,state='historical_source_measurement',reason='bound_native_origin_broken')
        parent_profile=base['parent_profile']
        if not parent_profile or parent_profile['score'] is None:return dict(base,state='source_measured_parent_unknown',reason='native_parent_scope_unavailable')
        if base['parent_relation']!='internal_forward_stage':
            return dict(base,state='internal_return_measurements',reason='parent_and_child_do_not_form_one_continuation')
        # OHLC containment proposes a relationship; it cannot manufacture the
        # phase/event chain required to use a parent score as a decision gate.
        # Preserve both measured values as descriptions instead of replacing
        # the missing relation with zero or the stronger child's score.
        if not membership.get('event_chain_verified'):
            return dict(base,state='source_and_candidate_parent_measured',reason='parent_membership_event_chain_unverified')
        eligible=profile['eligible_for_score_gate'] and parent_profile['eligible_for_score_gate']
        return dict(base,state='same_native_source_and_parent_measured',reason=None if eligible else 'native_continuity_unverified',
            eligible_for_score_gate=eligible,bottleneck_score=min(profile['score'],parent_profile['score']) if eligible else None,
            formula='minimum(own_native_wave_force,parent_native_wave_force); no independent votes or child substitution')
    except (KeyError,ValueError,TypeError,IndexError,ArithmeticError,AttributeError):
        return dict(base,reason='native_scope_identity_clock_or_source_unavailable')

def observe_native_scopes(recognition,previous,observed_at_utc):
    """Caller-owned checkpoint of actual sightings, not a backdated detector.

    Keep first readings unchanged when a developing terminal extends. The
    exact old Book A-B receipts remain in their original source checkpoints;
    this compact registry records origin continuity, not a replacement ruler.
    """
    registry=deepcopy(previous or {})
    if not recognition:return registry,dict(state='not_observed',observations=[])
    cutoff=recognition['as_of_utc']
    if clock(observed_at_utc)<clock(cutoff):raise ValueError('native_scope_observation_clock')
    present=[];transitions=[]
    for scope in recognition['active']+recognition['retired']:
        key=scope['scope_id'];identity={k:deepcopy(scope[k]) for k in ('origin','direction','timeframe')}
        identity['market']=recognition['market'];profile=scope.get('force_profile') or {}
        if key not in registry:
            registry[key]=dict(identity=identity,first_observed_at_utc=observed_at_utc,first_as_of_utc=cutoff,
                first_calculable_known_at_utc=scope['origin_known_at_utc'],
                first_terminal=deepcopy(scope.get('terminal')),first_force_score=profile.get('score'),
                first_range_version=profile.get('range_version'),first_seen_as_retired=scope['state']=='origin_broken',
                range_versions_seen=0)
        r=registry[key]
        if r['identity']!=identity:raise ValueError('native_scope_origin_identity_changed')
        if r.get('last_observed_at_utc') and clock(observed_at_utc)<clock(r['last_observed_at_utc']):raise ValueError('native_scope_observation_rewind')
        if r.get('last_as_of_utc') and clock(cutoff)<clock(r['last_as_of_utc']):raise ValueError('native_scope_prefix_rewind')
        measurement=profile.get('measurement_receipt') or {}
        mid=measurement.get('measurement_id')
        if mid:
            evidence=r.setdefault('measurement_evidence',{})
            frozen=dict(receipt=deepcopy(measurement),score=profile.get('score'),
                first_observed_at_utc=observed_at_utc,first_as_of_utc=cutoff)
            if mid in evidence and evidence[mid]['score']!=profile.get('score'):
                raise ValueError('same_native_measurement_changed_score')
            evidence.setdefault(mid,frozen)
            previous_mid=r.get('current_measurement_id')
            if previous_mid!=mid:
                r.setdefault('measurement_transition_history',[]).append(dict(
                    from_measurement_id=previous_mid,to_measurement_id=mid,
                    observed_at_utc=observed_at_utc,as_of_utc=cutoff,
                    reason='first_measurement' if previous_mid is None else 'native_measurement_inputs_or_rule_changed'))
            r['current_measurement_id']=mid
        membership=deepcopy(scope.get('membership_receipt'))
        if membership is not None:
            if clock(membership['known_at_utc'])>clock(cutoff):raise ValueError('native_membership_not_yet_known')
            if 'first_membership' not in r:
                r.update(first_membership=deepcopy(membership),first_membership_observed_at_utc=observed_at_utc,
                    first_membership_as_of_utc=cutoff,current_membership=deepcopy(membership),
                    membership_transition_count=0,last_membership_transition=None,
                    membership_transition_history=[],membership_transition_evidence={},
                    membership_history_basis='actual_observation_from_this_checkpoint_not_backfilled')
            old_membership=r['current_membership']
            if old_membership['membership_id']!=membership['membership_id']:
                transition=dict(scope_id=key,from_membership=deepcopy(old_membership),to_membership=deepcopy(membership),
                    observed_at_utc=observed_at_utc,as_of_utc=cutoff,
                    known_at_utc=max((observed_at_utc,membership['known_at_utc']),key=clock),
                    reason='new_prefix_changes_native_containment_not_historical_rewrite')
                transition['event_id']='native_membership_transition:'+digest(transition)[:24]
                r['membership_transition_count']+=1;r['last_membership_transition']=transition
                evidence=r.setdefault('membership_transition_evidence',{})
                for receipt in (old_membership,membership):
                    evidence.setdefault(receipt['evidence_id'],deepcopy(receipt))
                r.setdefault('membership_transition_history',[]).append(dict(
                    event_id=transition['event_id'],from_evidence_id=old_membership['evidence_id'],
                    to_evidence_id=membership['evidence_id'],observed_at_utc=observed_at_utc,
                    as_of_utc=cutoff,known_at_utc=transition['known_at_utc']))
            r['current_membership']=membership
            latest=r.get('last_membership_transition')
            if latest and latest['as_of_utc']==cutoff:transitions.append(deepcopy(latest))
        if r.get('last_range_version')!=profile.get('range_version') and profile.get('range_version'):r['range_versions_seen']+=1
        r.update(last_observed_at_utc=observed_at_utc,last_as_of_utc=cutoff,last_state=scope['state'],
            last_range_version=profile.get('range_version'),last_terminal=deepcopy(scope.get('terminal')),
            last_force_score=profile.get('score'),parent_scope_id=scope.get('parent_scope_id'),
            parent_relation=scope.get('parent_relation'))
        # Persist complete transition evidence once in the checkpoint; the
        # per-prefix view carries first/current/last plus a count, not another
        # copy of the whole growing journal on every chart publication.
        public={k:deepcopy(v) for k,v in r.items() if k not in ('membership_transition_history','membership_transition_evidence','measurement_evidence','measurement_transition_history')}
        present.append(dict(scope_id=key,**public,membership_history_event_count=len(r.get('membership_transition_history') or [])))
    return registry,dict(state='actual_native_scope_observations',as_of_utc=cutoff,observed_at_utc=observed_at_utc,
        retained_origin_count=len(registry),observations=sorted(present,key=lambda r:r['scope_id']),
        membership_transitions=sorted(transitions,key=lambda r:r['event_id']),
        automatic_trade_permission=False,selection_policy='none_no_global_direction_vote')
