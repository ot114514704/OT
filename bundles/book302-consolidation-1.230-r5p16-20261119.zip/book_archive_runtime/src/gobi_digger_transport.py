"""Immutable indicator payload shared by archive and broker publishers.

UTC availability and native chart epochs are separate columns. The MQ5 client
draws these supplied calculations; it does not recalculate a second strategy.
"""
import re
import math
from .gobi_digger_context import consume_context, MINUTES
from .gobi_digger_task_review import build_review, time
from .digger_inventory_context import display_events


def epoch(value):
    stamp=time(value)
    if stamp is None:raise ValueError('indicator_clock_missing')
    return int(stamp.timestamp())


def clean(value):
    return str(value).replace('\t',' ').replace('\n',' ').replace('\r',' ')


def packet(scene,token,display_symbol=None):
    if not re.fullmatch('[0-9_]+',token):raise ValueError('indicator_token_invalid')
    for key in ('scene_id','engine_revision'):
        if not re.fullmatch('[0-9a-f]{64}',scene.get(key,'')):raise ValueError('indicator_publication_identity_missing')
    context=consume_context(scene)
    saved=(scene.get('integrated_market_logic') or {}).get('gobi_digger_context')
    if context!=saved:raise ValueError('indicator_consumer_stale_or_modified')
    review=build_review(scene,context,MINUTES)
    if review!=(scene.get('integrated_market_logic') or {}).get('gobi_digger_review'):
        raise ValueError('indicator_task_review_stale_or_modified')
    rows=[];ind=context.get('process_indicators') or {}
    offset=(context.get('calendar') or {}).get('server_offset_seconds',0)
    if not isinstance(offset,int) or abs(offset)>14*3600 or offset%60:raise ValueError('indicator_offset_invalid')
    for tf,frame in ind.get('gobi',{}).items():
        for bar,point in zip(frame['input_bars'],frame['series']):
            utc=epoch(bar['timestamp_utc']);native=bar.get('native_epoch',utc)
            if native!=utc+offset:raise ValueError('indicator_native_epoch_mismatch')
            value=lambda k:'?' if point[k] is None else format(point[k],'.17g')
            rows.append(['K',tf,utc,native,epoch(bar['closed_at_utc']),epoch(point['known_at_utc']),
                value('fast_k'),value('slow_k'),value('signed_gap'),value('fast_d'),value('slow_d')])
        # Bounded display tail only; JSON retains the complete source window.
        for variant in frame.get('fractal_variant_observations',{}).values():
            for r in variant['records'][-24:]:
                pivot=epoch(r['pivot_bar_utc']);e=r['event_log'][-1];event=epoch(e['event_bar_utc'])
                rows.append(['F',r['object_id'],tf,r['requested_period'],r['effective_period'],r['kind'],
                    format(r['price'],'.17g'),pivot,pivot+offset,epoch(r['candidate_known_at_utc']),r['state'],
                    epoch(r['known_at_utc']),event,event+offset,epoch(e['known_at_utc']),r['continuity'],
                    'ghbdr_2018' if variant['schema']=='jrcmod_ghbdr_2018_closed_bar_observation_v1' else 'reversal_candle_2022'])
    digger=ind.get('digger') or {};bars=digger.get('input_bars') or []
    nearest={l['object_id'] for ls in digger.get('geometric_neighbours',{}).values() for l in ls}
    byid={l['object_id']:l for l in (context.get('digger_context') or {}).get('mapped_objects',[])}
    for line in digger.get('level_processes',[]):
        source=byid[line['object_id']];start=max(epoch(source['known_at_utc']),epoch(bars[0]['timestamp_utc'])) if bars else None
        end=epoch(bars[-1]['closed_at_utc']) if bars else None
        if start is None or start>=end:continue
        rows.append(['L',line['object_id'],line['native_timeframe'],format(line['price'],'.17g'),
            epoch(line['line_known_at_utc']),start+offset,end+offset,
            '?' if line['current_close_side'] is None else line['current_close_side'],
            line['consecutive_closes_on_current_side'],int(line['object_id'] in nearest)])
        for event in line['events']:
            opened=epoch(event['bar_open_utc'])
            rows.append(['E',line['object_id'],event['kind'],opened,opened+offset,
                epoch(event['closed_at_utc']),epoch(event['known_at_utc']),event['close_side'],format(line['price'],'.17g')])
    for task in review['tasks']:
        rows.append(['T',task['task_id'],task['task_owner_id'],task['native_timeframe'],task['state'],
            task['binding'],epoch(task['known_at_utc']) if task['known_at_utc'] else 0])
    for obj in (context.get('digger_sequence_observations') or {}).get('objects',[]):
        for event in obj['events'][-24:]:
            opened=epoch(event['bar_open_utc'])
            rows.append(['Q',event['event_id'],obj['object_id'],event['native_timeframe'],event['kind'],
                format(obj['price'],'.17g'),opened,opened+offset,epoch(event['known_at_utc']),
                '?' if event['contact_cluster_number'] is None else event['contact_cluster_number'],
                int(event['first_visible_contact']),int(event['first_contact_proven_in_closed_prefix']),
                int(obj['left_censored']),event['close_side'],event['continuity'],event['intrabar_order']])
    inventory=context.get('digger_event_time_inventory')
    if inventory is not None:
        events=display_events(inventory);sources={s['source_version_id']:s for s in inventory['source_versions']}
        needed={e['inventory_version_id'] for e in events}|{inventory['current_inventory_version_id']}
        for version in inventory['inventory_versions']:
            if version['inventory_version_id'] not in needed:continue
            counts=version['coverage']['closed_period_counts']
            rows.append(['I',version['inventory_version_id'],version['feed_id'],epoch(version['known_at_utc']) if version['known_at_utc'] else 0,
                len(version['member_source_version_ids']),counts['D1'],counts['W1'],version['coverage']['current_day_open']])
        for e in events:
            opened=epoch(e['bar_open_utc'])
            rows.append(['R',e['event_id'],e['source_version_id'],e['position_object_id'],e['native_timeframe'],e['kind'],
                format(e['price'],'.17g'),opened,opened+offset,epoch(e['known_at_utc']),e['inventory_version_id'],e['feed_id'],
                '?' if e['contact_cluster_number'] is None else e['contact_cluster_number'],int(e['first_visible_contact']),
                int(e['first_contact_proven_in_closed_prefix']),int(e['left_censored']),e['close_side'],e['continuity'],
                e['intrabar_order'],epoch(sources[e['source_version_id']]['known_at_utc'])])
    pivot=context.get('pivotgauge_context') or {}
    reference=(pivot.get('chart_input_bars') or [])
    for level in pivot.get('levels',[]):
        if not reference:continue
        start=max(epoch(level['known_at_utc']),epoch(level['valid_from_utc']),epoch(reference[0]['timestamp_utc']))
        end=min(epoch(reference[-1]['closed_at_utc']),epoch(level['valid_until_utc']))
        if start>=end:continue
        delta=level['price']-reference[-1]['close']
        siblings=[l['price']-reference[-1]['close'] for l in pivot['levels']
            if l['native_timeframe']==level['native_timeframe'] and l['formula_family']==level['formula_family']
            and epoch(l['known_at_utc'])<=epoch(reference[-1]['timestamp_utc'])]
        near=(epoch(level['known_at_utc'])<=epoch(reference[-1]['timestamp_utc']) and
            not any((delta>0 and 0<=d<delta) or (delta<0 and delta<d<=0) for d in siblings))
        rows.append(['P',level['object_id'],level['native_timeframe'],level['formula_family'],level['level_name'],
            format(level['price'],'.17g'),epoch(level['known_at_utc']),start+offset,end+offset,
            epoch(level['valid_until_utc']),level['source_timeframe'],level['source_construction'],int(near)])
    rows.append(['S',len(review['review_queue']),sum(t['binding']=='explicit_task_C_native_bar_verified' for t in review['tasks']),
                 sum(t['state'].startswith('wait_') for t in review['tasks'])])
    header=['M1GOBIDIGGER',1,token,scene['scene_id'],scene['engine_revision'],display_symbol or scene['instrument'],
        scene['timeframe'],epoch(scene['cutoff_utc']),offset,len(rows),scene['provider'],scene['instrument'],1,0,0]
    text=['\t'.join(map(clean,header))]+['\t'.join(map(clean,r)) for r in rows]
    text.append('\t'.join(map(str,['END',token,scene['scene_id'],len(rows)])))
    raw=('\n'.join(text)+'\n').encode('utf8')
    validate_packet(raw,token,scene['scene_id'],scene['engine_revision'],display_symbol or scene['instrument'],scene['timeframe'])
    return raw


def validate_packet(raw,token,scene_id,engine,symbol,tf):
    """Strict independent client-format contract; rejects partial or mixed packets."""
    records=[s.split('\t') for s in raw.decode('utf8').splitlines()]
    h=records[0]
    if (len(h)!=15 or h[:7]!=['M1GOBIDIGGER','1',token,scene_id,engine,symbol,tf]
            or h[12:]!=['1','0','0']):raise ValueError('indicator_header_mismatch')
    cutoff,offset,count=map(int,h[7:10])
    if abs(offset)>14*3600 or offset%60 or not 0<count<=10000:raise ValueError('indicator_header_bounds')
    if len(records)!=count+2 or records[-1]!=['END',token,scene_id,str(count)]:raise ValueError('indicator_footer_mismatch')
    previous={};seen=set();inventories={};inventory_events=[]
    for r in records[1:-1]:
        if r[0]=='K':
            if len(r)!=11 or r[1] not in MINUTES:raise ValueError('indicator_K_shape')
            opened,native,closed,known=map(int,r[2:6]);period=r[1]
            if (native!=opened+offset or closed!=opened+MINUTES[period]*60 or not closed<=known<=cutoff
                    or opened<=previous.get(period,-1)):raise ValueError('indicator_K_clock')
            previous[period]=opened
            for i in range(6,11):
                if r[i]=='?':continue
                v=float(r[i]);lower=-100 if i==8 else 0
                if not math.isfinite(v) or not lower<=v<=100:raise ValueError('indicator_K_value')
        elif r[0]=='F':
            if len(r) not in (16,17) or r[1] in seen or r[2] not in MINUTES:raise ValueError('indicator_F_identity')
            if len(r)==17 and r[16] not in ('ghbdr_2018','reversal_candle_2022'):raise ValueError('indicator_F_source')
            source=r[16] if len(r)==17 else 'reversal_candle_2022'
            if not r[1].startswith('jrcmod_ghbdr_2018_' if source=='ghbdr_2018' else 'jrcmod_reversal_candle_'):
                raise ValueError('indicator_F_source_identity')
            seen.add(r[1]);requested,effective=map(int,r[3:5]);price=float(r[6])
            pivot,native,born=map(int,r[7:10]);known,event,event_native,event_known=map(int,r[11:15])
            if (requested not in (8,25) or effective!=requested+(requested%2==0) or r[5] not in ('high','low')
                    or not math.isfinite(price)):raise ValueError('indicator_F_value')
            if (native!=pivot+offset or event_native!=event+offset or not pivot+MINUTES[r[2]]*60<=born<=event_known<=known<=cutoff
                    or event<pivot or event+MINUTES[r[2]]*60>event_known):raise ValueError('indicator_F_clock')
            if r[10] not in ('candidate','invalidated','confirmed_window') or r[15] not in ('contiguous_native_bars','gap_or_calendar_unresolved'):
                raise ValueError('indicator_F_state')
        elif r[0]=='Q':
            if (len(r)!=16 or r[1] in seen or r[3]!=tf
                    or not r[1].startswith('digger_closed_position_sequence_v1:')):raise ValueError('indicator_Q_identity')
            seen.add(r[1]);price=float(r[5]);opened,native,known=map(int,r[6:9])
            if not math.isfinite(price) or r[4] not in {'close_cross','close_return_after_cross','touch_close_on_level',
                'probe_closed_on_prior_side','touch_without_known_approach'}:raise ValueError('indicator_Q_value')
            if native!=opened+offset or not opened+MINUTES[tf]*60<=known<=cutoff:raise ValueError('indicator_Q_clock')
            if (r[9]!='?' and not 1<=int(r[9])<=10000 or any(v not in ('0','1') for v in r[10:13])
                    or r[13] not in ('-1','0','1') or r[14] not in ('gap_or_calendar_unresolved','contiguous_observed_native_bars')
                    or r[15]!='unknown'):raise ValueError('indicator_Q_state')
            if r[11]=='1' and (r[10]!='1' or r[12]!='0' or r[14]!='contiguous_observed_native_bars'):
                raise ValueError('indicator_Q_first_contact')
        elif r[0]=='I':
            if len(r)!=8 or r[1] in seen or any(not re.fullmatch('[0-9a-f]{64}',v) for v in r[1:3]):
                raise ValueError('indicator_I_identity')
            seen.add(r[1]);known,n,d,w=map(int,r[3:7])
            observed=r[7]=='exact_boundary_M1_observed'
            if (not 0<=known<=cutoff or not 0<=d<=3 or not 0<=w<=3 or n!=d+w+int(observed)
                    or r[7] not in {'exact_boundary_M1_observed','boundary_not_observed_at_event_time','calendar_boundary_unverified'}):
                raise ValueError('indicator_I_coverage_or_clock')
            inventories[r[1]]=r
        elif r[0]=='R':
            if (len(r)!=20 or r[1] in seen or not re.fullmatch('digger_event_time_inventory_v1:[0-9a-f]{64}',r[1])
                    or any(not re.fullmatch('[0-9a-f]{64}',r[i]) for i in (2,10,11)) or r[4]!=tf or not r[3]):
                raise ValueError('indicator_R_identity')
            seen.add(r[1]);price=float(r[6]);opened,native,known=map(int,r[7:10]);source_known=int(r[19])
            if not math.isfinite(price) or r[5] not in {'close_cross','close_return_after_cross','touch_close_on_level',
                    'probe_closed_on_prior_side','touch_without_known_approach'}:raise ValueError('indicator_R_value')
            if native!=opened+offset or not source_known<=opened<opened+MINUTES[tf]*60<=known<=cutoff:
                raise ValueError('indicator_R_clock')
            if (r[12]!='?' and not 1<=int(r[12])<=10000 or any(v not in ('0','1') for v in r[13:16])
                    or r[16] not in ('-1','0','1') or r[17] not in ('gap_or_calendar_unresolved','contiguous_observed_native_bars')
                    or r[18]!='unknown'):raise ValueError('indicator_R_state')
            if r[14]=='1' and (r[13]!='1' or r[15]!='0' or r[17]!='contiguous_observed_native_bars'):
                raise ValueError('indicator_R_first_contact')
            inventory_events.append(r)
        elif r[0]=='L':
            if len(r)!=10 or r[1] in seen or r[2] not in {'D1','W1'}:raise ValueError('indicator_L_identity')
            seen.add(r[1]);price=float(r[3]);known,start,end=map(int,r[4:7])
            if not math.isfinite(price) or not known<=start-offset<end-offset<=cutoff:raise ValueError('indicator_L_clock')
            if r[7] not in {'?','-1','0','1'} or int(r[8])<0 or r[9] not in {'0','1'}:raise ValueError('indicator_L_state')
        elif r[0]=='E':
            if len(r)!=9 or r[1] not in seen:raise ValueError('indicator_E_identity')
            opened,native,closed,known=map(int,r[3:7])
            if native!=opened+offset or not opened<closed<=known<=cutoff:raise ValueError('indicator_E_clock')
        elif r[0]=='P':
            if len(r)!=13 or r[1] in seen or r[2] not in {'D1','W1','MN1','Q1'}:raise ValueError('indicator_P_identity')
            seen.add(r[1]);price=float(r[5]);known,start,end,expires=map(int,r[6:10])
            if (not math.isfinite(price) or not known<=start-offset<end-offset<=cutoff
                    or end-offset>expires):raise ValueError('indicator_P_clock_or_price')
            if r[3] not in {'classic','traditional','camarilla','prior_range','classic_subdivision','current_period'}:
                raise ValueError('indicator_P_formula')
            if r[10] not in {'M1','D1','W1'}:raise ValueError('indicator_P_source')
            if r[12] not in {'0','1'}:raise ValueError('indicator_P_neighbour')
        elif r[0]=='T':
            if len(r)!=7 or not 0<=int(r[6])<=cutoff:raise ValueError('indicator_T_clock')
        elif r[0]=='S':
            if len(r)!=4 or any(int(v)<0 for v in r[1:]):raise ValueError('indicator_S_shape')
        else:raise ValueError('indicator_row_unknown')
    for r in inventory_events:
        version=inventories.get(r[10])
        if version is None or version[2]!=r[11] or int(version[3])>int(r[7]):raise ValueError('indicator_R_map_binding')
    return records
