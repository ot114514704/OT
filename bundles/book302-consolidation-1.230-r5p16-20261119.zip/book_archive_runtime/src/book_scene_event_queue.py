"""Native Book event observations carried by the existing broker checkpoint.

Printed103-104/PDF114-115 preserve each source's B and pre-break A while
either boundary may break first. A chart selection change is not B failure.
No file, terminal, quote, account or order API is used in this adapter.
"""
from copy import deepcopy
from collections import Counter
from hashlib import sha256
import json
from math import isfinite
from .book_first_response_leg import clock, close_time, MINUTES
from .book_entry_watchlist import observe_sources
from .scene_event_confluence import scene_event_context, event_breakout_confluence


def digest(value):
    return sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,
                             separators=(',',':')).encode('utf-8')).hexdigest()


def native_book_rows(rows,timeframe,cutoff,provider,symbol,offset):
    """Bind absent metadata from the explicit broker request, reject conflicts."""
    if timeframe not in MINUTES or not provider or not symbol:
        raise ValueError('Book event market identity missing')
    end=clock(cutoff)
    if end.utcoffset() is None:raise ValueError('Book event cutoff timezone missing')
    result=[]
    for raw in rows:
        stamp=clock(raw['timestamp_utc'])
        if stamp.utcoffset() is None or stamp.utcoffset().total_seconds()!=0:
            raise ValueError('Book native UTC clock invalid')
        if clock(close_time(raw,timeframe))>end:continue
        if any(key in raw and raw[key]!=value for key,value in
               [('timeframe',timeframe),('provider',provider),('symbol',symbol)]):
            raise ValueError('Book native market or period mismatch')
        prices=[raw[k] for k in ('open','high','low','close')]
        if (any(isinstance(p,bool) or not isinstance(p,(int,float)) or not isfinite(p) or p<=0 for p in prices)
                or not raw['low']<=min(raw['open'],raw['close'])<=max(raw['open'],raw['close'])<=raw['high']):
            raise ValueError('Book native OHLC invalid')
        expected=stamp.timestamp()+offset
        if expected!=int(expected) or ('native_epoch' in raw and raw['native_epoch']!=expected):
            raise ValueError('Book native coordinate clock mismatch')
        result.append(dict(raw,timeframe=timeframe,provider=provider,symbol=symbol,native_epoch=int(expected)))
    if not result or any(clock(b['timestamp_utc'])<=clock(a['timestamp_utc']) for a,b in zip(result,result[1:])):
        raise ValueError('Book native prefix empty or unordered')
    return result


def _verify_state(state):
    if state.get('schema')!='book_scene_event_queue_state_v1' or state.get('sha256')!=digest(
            {k:v for k,v in state.items() if k!='sha256'}):
        raise ValueError('Book event checkpoint checksum or schema mismatch')


def attach_scene_event_queue(scene,bars,previous=None,previous_bars=None,*,observed_at_utc=None,
                             observation_basis='native_close_replay',reset_reason=None):
    """Observe only the current physical prefix, then atomically attach results.

    The caller owns the durable checkpoint. Same input reuses the first actual
    observation; a partial broker publication must never invoke this function.
    """
    tf=scene['timeframe'];cutoff=scene['cutoff_utc'];provider=scene['provider'];symbol=scene['instrument']
    offset=scene['observed_server_utc_offset_seconds']
    rows=native_book_rows(bars,tf,cutoff,provider,symbol,offset)
    if observation_basis not in ('native_close_replay','broker_processing_wall_clock'):
        raise ValueError('Book observation clock basis unknown')
    if observation_basis=='broker_processing_wall_clock' and not observed_at_utc:
        raise ValueError('Book actual observation clock missing')
    observed=observed_at_utc or cutoff
    if clock(observed).utcoffset() is None or clock(observed)<clock(cutoff):
        raise ValueError('Book observation precedes native data availability')
    identity=dict(provider=provider,symbol=symbol,timeframe=tf,offset=offset,
                  engine_revision=scene['engine_revision'],observation_basis=observation_basis)
    old=(previous or {}).get('book_event_queue_state')
    if old:_verify_state(old)
    if old and old['identity']!=identity:reset_reason=reset_reason or 'event_stream_identity_changed'
    if old and clock(cutoff)<clock(old['as_of_utc']):reset_reason=reset_reason or 'event_cutoff_rewind'
    if old and not reset_reason and clock(observed)<clock(old['observed_at_utc']):
        raise ValueError('Book observation clock moved backwards')
    book=scene.get('book_logic') or {}
    if book.get('timeframe')!=tf or book.get('as_of_utc')!=cutoff:
        raise ValueError('Book event source scene clock or period mismatch')
    native_source={k:book.get(k) for k in ('turning_point_line','turning_boundary','first_closed_break',
                                         'parallel_break','trend_change')}
    input_id=digest([identity,cutoff,rows,native_source])
    if old and not reset_reason and old['input_id']==input_id:
        packet=deepcopy((previous or {}).get('book_event_queue') or {})
        if digest(packet)!=old['packet_sha256']:raise ValueError('Book event cached packet mismatch')
        scene['book_event_queue_state']=deepcopy(old);scene['book_event_queue']=packet
        scene['book_logic']['entry_watchlist']=deepcopy((previous or {})['book_logic']['entry_watchlist'])
        return scene
    if old and not reset_reason and previous_bars:
        prior=native_book_rows(previous_bars,tf,previous['cutoff_utc'],provider,symbol,offset)
        before={r['timestamp_utc']:r for r in prior};present={r['timestamp_utc']:r for r in rows}
        if any(before[t]!=present[t] for t in before.keys()&present.keys()):
            raise ValueError('Book observed native history changed')
        if any(rows[0]['timestamp_utc']<=t<=rows[-1]['timestamp_utc'] and t not in present for t in before):
            raise ValueError('Book observed native history omitted')
    registry=deepcopy(old['registry']) if old and not reset_reason else {}
    terminals=deepcopy(old.get('terminal_contexts') or {}) if old and not reset_reason else {}
    watch=observe_sources(rows,tf,cutoff,observed,book,registry,'broker-event:'+input_id,None,{})
    observations=[]
    for reading in watch['observations']:
        item={k:deepcopy(reading.get(k)) for k in
              ('phase_id','pair_key','source_identity','current_selected','first_observed_at_utc','status','retired_at_utc','reason')}
        item['decision_status']=(reading.get('decision') or {}).get('status')
        key=reading['phase_id']+'|'+str(reading.get('pair_key'))
        if reading['status']=='retired' and key in terminals:
            item['event']=deepcopy(terminals[key])
        elif reading.get('book_logic'):
            native_book=reading['book_logic']
            own_scene=dict(timeframe=tf,cutoff_utc=native_book['as_of_utc'],provider=provider,instrument=symbol,
                           execution_context=dict(bars=rows),book_logic=native_book)
            item['event']=scene_event_context(own_scene)
            if reading['status']=='retired':terminals[key]=deepcopy(item['event'])
        else:
            item['event']=dict(state='unknown',reason='source_native_history_unavailable',scorecard=None,
                               composite=None,timeframe=tf,as_of_utc=cutoff,automatic_trade_permission=False)
        item['view_as_of_utc']=cutoff
        item['breakout_confluence']=event_breakout_confluence(item['event'])
        item['automatic_trade_permission']=False;item['entry_permission']=False
        observations.append(item)
    # The checkpoint writer sorts mapping keys. Registry insertion order is
    # therefore not durable; never let it change the published event array.
    observations.sort(key=lambda o:(o['phase_id'],o.get('pair_key') or ''))
    from .book_native_wave_process import observe_native_scopes
    recognition=(((book.get('realtime_entry_decision') or {}).get('position_scorecard') or {})
                 .get('native_wave_process') or {}).get('recognition')
    native_registry,native_observations=observe_native_scopes(recognition,
        old.get('native_wave_origins') if old and not reset_reason else None,observed)
    packet=dict(schema='book_scene_event_queue_v1',as_of_utc=cutoff,observed_at_utc=observed,
                identity=identity,selected_phase_id=watch['selected_phase_id'],source_count=len(registry),
                observations=observations,observation_basis=observation_basis,
                native_wave_observations=native_observations,
                observation_states=dict(Counter(o['status'] for o in observations)),
                event_states=dict(Counter(o['event']['state'] for o in observations)),
                nonselected_observations=sum(not o['current_selected'] for o in observations),
                reset_reason=reset_reason,automatic_trade_permission=False,order_api_called=False,
                selection_policy='none_keep_each_owner_and_terminal_separate',
                source_pdf_pages=[114,115],source_printed_pages=[103,104])
    state=dict(schema='book_scene_event_queue_state_v1',identity=identity,as_of_utc=cutoff,
               observed_at_utc=observed,input_id=input_id,registry=registry,terminal_contexts=terminals,
               packet_sha256=digest(packet))
    state['native_wave_origins']=native_registry
    state['sha256']=digest(state)
    compact_watch={k:deepcopy(watch[k]) for k in
                   ('schema','as_of_utc','observed_at_utc','selected_phase_id','source_count','automatic_trade_permission','order_api_called')}
    compact_watch['observations']=[{k:deepcopy(o.get(k)) for k in
                                  ('phase_id','pair_key','status','current_selected','decision')} for o in watch['observations']]
    compact_watch['observations'].sort(key=lambda o:(o['phase_id'],o.get('pair_key') or ''))
    # The original selected Book decision remains its own decision. There is
    # no scene-side arbitration, policy injection, risk preparation or order.
    scene['book_logic']['entry_watchlist']=compact_watch
    scene['book_event_queue_state']=state;scene['book_event_queue']=packet
    return scene


def scene_event_candidates(scene):
    """Expose only this scene's checkpoint-linked event packet, never a vote."""
    state=scene.get('book_event_queue_state');packet=scene.get('book_event_queue')
    if state is None and packet is None:return dict(state='not_observed',observations=[])
    try:
        _verify_state(state)
        if (state['packet_sha256']!=digest(packet) or packet['as_of_utc']!=scene['cutoff_utc']
                or state['as_of_utc']!=packet['as_of_utc'] or state['observed_at_utc']!=packet['observed_at_utc']):
            raise ValueError('Book event packet scene clock mismatch')
        identity=packet['identity']
        if identity!=state['identity'] or any(identity[k]!=scene[name] for k,name in
                [('provider','provider'),('symbol','instrument'),('timeframe','timeframe'),
                 ('offset','observed_server_utc_offset_seconds'),('engine_revision','engine_revision')]):
            raise ValueError('Book event packet scene market mismatch')
        for item in packet['observations']:
            event=item['event']
            if (clock(event['as_of_utc'])>clock(packet['as_of_utc']) or event.get('timeframe')!=identity['timeframe']
                    or item['status']=='observing' and event['as_of_utc']!=packet['as_of_utc']
                    or event.get('phase_id') is not None and event['phase_id']!=item['phase_id']):
                raise ValueError('Book candidate owner or event clock mismatch')
        return dict(state='verified_observation_packet',as_of_utc=packet['as_of_utc'],
                    observed_at_utc=packet['observed_at_utc'],source_count=packet['source_count'],
                    selected_phase_id=packet['selected_phase_id'],observations=deepcopy(packet['observations']),
                    automatic_trade_permission=False,selection_policy='none_independent_owner_contexts',
                    may_replace_current_event_score=False)
    except (KeyError,ValueError,TypeError,AttributeError):
        return dict(state='unverified_event_packet',observations=[],automatic_trade_permission=False)
