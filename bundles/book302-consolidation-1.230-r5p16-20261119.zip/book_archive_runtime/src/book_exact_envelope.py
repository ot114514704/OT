"""Exact rational line-side checks without per-candle Fraction temporaries.

Only Book's opt-in calculation uses this fast path. No rounding, tolerance,
omitted candles or change of contact admissibility. The bounded conversion
cache contains decimal strings and immutable numbers, never market state.
"""
from fractions import Fraction
from functools import lru_cache


@lru_cache(maxsize=16384)
def _decimal(text):
    return Fraction(text)


def decimal(value):
    text=str(value)
    # Keep the exact old conversion for unusually large strings without
    # admitting them into the bounded small-number cache. Errors stay errors.
    return _decimal(text) if len(text)<=128 else Fraction(text)


def crosses(values,slope,anchor,indices,sign):
    """Same predicate as sign * (line - price) <= 0, in the same order."""
    from .book_calculation_scope import independent_axis_enabled
    if not independent_axis_enabled():
        return any(sign*(values[anchor]+slope*(k-anchor)-values[k])<=0 for k in indices)
    price=values[anchor]
    base=price.numerator*slope.denominator
    step=slope.numerator*price.denominator
    denominator=price.denominator*slope.denominator
    for k in indices:
        value=values[k]
        numerator=(base+step*(k-anchor))*value.denominator-value.numerator*denominator
        if sign*numerator<=0:return True
    return False
