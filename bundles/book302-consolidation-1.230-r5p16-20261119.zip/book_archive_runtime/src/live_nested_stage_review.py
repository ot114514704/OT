"""Map native child stages to one native higher-timeframe segment.

Shared extrema are physical geometry, not two independent confirmations and
not proof of an Alexander first-force leg. No ratio tolerance or timeframe
conversion table is introduced as a trading rule.
"""
from datetime import datetime, timedelta, timezone
import hashlib
import json
from math import isfinite
from functools import lru_cache


MINUTES = {"M1": 1, "M5": 5, "M15": 15, "M30": 30, "H1": 60, "H4": 240, "D1": 1440, "W1": 10080}
SOURCE_REFS = ["msg-7676888339290328968", "msg-7602778785363485338", "msg-7602779106884338737", "msg-7602779373639413212"]


def _time(value):
    return _parse_time(str(value))


@lru_cache(maxsize=32768)
def _parse_time(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("explicit timezone required")
    return parsed.astimezone(timezone.utc)


def _number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and isfinite(value)


def geometric_direction(origin, terminal):
    """Return the direction of an alternating pivot leg, not its net price sign.

    A high→low leg remains a downward leg even when a gap leaves the later
    low above the earlier high.  Net price relation is a separate observation
    and must not change which same-period pullback owns the next ruler.
    """
    kinds = (origin.get("kind"), terminal.get("kind")) if isinstance(origin, dict) and isinstance(terminal, dict) else (None, None)
    if kinds == ("confirmed_swing_low_candidate", "confirmed_swing_high_candidate"):
        return "up"
    if kinds == ("confirmed_swing_high_candidate", "confirmed_swing_low_candidate"):
        return "down"
    return None


def _native(snapshot, tf, cutoff):
    state = (snapshot.get("timeframe_states") or {}).get(tf) or {}
    bars = ((snapshot.get("chart_history") or {}).get(tf) or {}).get("bars") or []
    latest = state.get("latest_closed_bar") or {}
    wave = state.get("candidate_wave_ledger") or {}
    if not isinstance(latest, dict) or not isinstance(wave, dict):
        raise ValueError("native latest bar and ledger must be records")
    if (wave.get("timeframe") != tf or wave.get("window_through_utc") != latest.get("timestamp_utc")
            or not _time(latest["timestamp_utc"]) + timedelta(minutes=MINUTES[tf]) == _time(state["latest_closed_bar_end_utc"]) <= cutoff):
        raise ValueError("native state identity or close missing")
    latest_stamp = _time(latest["timestamp_utc"])
    raw = {}
    for bar in bars:
        if not isinstance(bar, dict):
            raise ValueError("invalid native bar")
        stamp = _time(bar["timestamp_utc"])
        # Later appended market bars must not change a frozen interpretation.
        if stamp > latest_stamp:
            continue
        if (stamp in raw or bar.get("timeframe", tf) != tf
                or bar.get("provider", snapshot["provider"]) != snapshot["provider"]
                or bar.get("symbol", snapshot["instrument"]) != snapshot["instrument"]
                or bar.get("instrument", snapshot["instrument"]) != snapshot["instrument"]
                or not all(_number(bar.get(k)) for k in ("open", "high", "low", "close"))
                or not bar["low"] <= min(bar["open"], bar["close"]) <= max(bar["open"], bar["close"]) <= bar["high"]):
            raise ValueError("conflicting or impossible native bar")
        raw[stamp] = bar
    last_raw = raw.get(latest_stamp) or {}
    if (any(last_raw.get(key) != latest.get(key) for key in ("open", "high", "low", "close"))
            or latest.get("provider", snapshot["provider"]) != snapshot["provider"]
            or latest.get("symbol", snapshot["instrument"]) != snapshot["instrument"]
            or latest.get("instrument", snapshot["instrument"]) != snapshot["instrument"]
            or latest.get("timeframe", tf) != tf):
        raise ValueError("latest native OHLC differs")
    legs = wave.get("legs") or []
    ids = [leg.get("leg_id") for leg in legs if isinstance(leg, dict)]
    if not isinstance(legs, list) or len(ids) != len(legs) or any(not isinstance(identity, str) for identity in ids) or len(set(ids)) != len(ids):
        raise ValueError("ambiguous native leg identities")
    return state, raw, legs


def _leg(leg, tf, raw, cutoff):
    if not isinstance(leg, dict) or leg.get("timeframe") != tf or leg.get("temporal_order") != "sequential_confirmed_extrema":
        return False
    if not isinstance(leg.get("leg_id"), str) or not leg["leg_id"]:
        return False
    try:
        a, b = leg["origin"], leg["terminal"]
        for pivot in (a, b):
            key = {"confirmed_swing_high_candidate": "high", "confirmed_swing_low_candidate": "low"}.get(pivot["kind"])
            stamp, known = _time(pivot["pivot_timestamp_utc"]), _time(pivot["confirmed_at_utc"])
            if not (key and _number(pivot["price"]) and stamp + timedelta(minutes=MINUTES[tf]) <= known <= cutoff and raw.get(stamp, {}).get(key) == pivot["price"]):
                return False
        signed = b["price"] - a["price"]
        direction = geometric_direction(a, b)
        return bool(isfinite(signed) and signed and direction
                    and _time(a["pivot_timestamp_utc"]) < _time(b["pivot_timestamp_utc"])
                    and leg.get("direction_observation") == direction)
    except (KeyError, TypeError, ValueError):
        return False


def _same(left, right):
    return all(left.get(key) == right.get(key) for key in ("kind", "price", "pivot_timestamp_utc", "confirmed_at_utc"))


def _shared_extremum(child, parent, parent_tf):
    # A calendar bucket is geometry only, never parent-close acceptance.
    # Use the declared native timeframe duration, not a guessed TF multiplier.
    start = _time(parent["pivot_timestamp_utc"])
    return (child["kind"] == parent["kind"] and child["price"] == parent["price"]
            and start <= _time(child["pivot_timestamp_utc"]) < start + timedelta(minutes=MINUTES[parent_tf]))


def _paths(snapshot, timeframe, legs, raw, parents, cutoff):
    """Keep every child stage, including parents made of more than two pushes."""
    valid = [_leg(leg, timeframe, raw, cutoff) for leg in legs]
    starts = {}
    for i, leg in enumerate(legs):
        if valid[i]:
            starts.setdefault((leg["origin"]["kind"], leg["origin"]["price"]), []).append(i)
    paths = []
    for parent_tf, index, latest_id in parents:
        for parent in (leg for bucket in index.values() for leg in bucket):
            a, d = parent["origin"], parent["terminal"]
            for begin in starts.get((a["kind"], a["price"]), []):
                if not _shared_extremum(legs[begin]["origin"], a, parent_tf):
                    continue
                chain = []
                for position in range(begin, len(legs)):
                    leg = legs[position]
                    if not valid[position] or (chain and not _same(chain[-1]["terminal"], leg["origin"])):
                        break
                    if _time(leg["terminal"]["pivot_timestamp_utc"]) >= _time(d["pivot_timestamp_utc"]) + timedelta(minutes=MINUTES[parent_tf]):
                        break
                    chain.append(leg)
                    if not _shared_extremum(leg["terminal"], d, parent_tf):
                        continue
                    # A one-leg match is still one move, not a two-stage model.
                    points = [chain[0]["origin"]] + [stage["terminal"] for stage in chain]
                    known = max(_time(pivot["confirmed_at_utc"]) for pivot in points + [a,d])
                    identity = [snapshot["instrument"], snapshot["provider"], timeframe, parent_tf,
                                parent["leg_id"], [stage["leg_id"] for stage in chain]]
                    pushes = sum(stage["direction_observation"] == parent["direction_observation"] for stage in chain)
                    path = {"composition_id": hashlib.sha256(json.dumps(identity,separators=(",", ":")).encode()).hexdigest()[:24],
                            "child_timeframe": timeframe, "parent_timeframe": parent_tf,
                            "child_leg_ids": [stage["leg_id"] for stage in chain],
                            "parent_candidate_leg_id": parent["leg_id"],
                            "parent_is_latest_confirmed_leg": parent["leg_id"] == latest_id,
                            "stage_count": len(chain), "same_direction_push_count": pushes,
                            "opposing_return_count": len(chain)-pushes, "points": points,
                            "parent_origin": a, "parent_terminal": d,
                            "composition_known_at_utc": known.isoformat().replace("+00:00", "Z"),
                            "status": "native_child_path_shares_parent_extrema_not_task_membership",
                            "independent_direction_confirmation_count": 0,
                            "parent_task_transform_adjudicated": False, "trade_permission": False}
                    sequence = "→".join(f"{pivot['price']:.2f}" for pivot in points)
                    prefix = "最近已确认的一段" if path["parent_is_latest_confirmed_leg"] else "历史已确认段"
                    path["readout"] = (f"{parent_tf} {prefix} {a['price']:.2f}→{d['price']:.2f}，在 {timeframe} 展开为 {sequence}；"
                        f"包含 {pushes} 次同向推动、{len(chain)-pushes} 次反向回走。"
                        "两级共享实际端点，是同一走势的分层读法，不重复算方向证据；目标归属和第一力度仍须结构裁决。")
                    path["summary_readout"] = (f"{parent_tf} {prefix} {a['price']:.2f}→{d['price']:.2f}，"
                        f"在 {timeframe} 分成 {pushes} 段同向推动、{len(chain)-pushes} 段反向回走。"
                        "这是同一段行情的大小两种看法，不是额外的方向信号，也还不能据此认定趋势反转。")
                    paths.append(path)
                    break
    paths.sort(key=lambda row: (_time(row["composition_known_at_utc"]), row["composition_id"]), reverse=True)
    representatives = []
    for parent_tf, _, _ in parents:
        options = [row for row in paths if row["parent_timeframe"] == parent_tf]
        if options:
            representatives.append(next((row for row in options if row["parent_is_latest_confirmed_leg"]), options[0]))
    return paths, representatives


def build_nested_stage_review(snapshot, timeframe):
    result = {"status": "unavailable", "timeframe": timeframe,
              "snapshot_id": snapshot.get("snapshot_id"), "as_of_utc": snapshot.get("as_of_utc"),
              "records": [], "representatives": [], "record_count": 0,
              "child_paths": [], "path_representatives": [], "child_path_count": 0, "unavailable_parent_timeframes": [],
              "condition_source_refs": SOURCE_REFS,
              "first_force_leg_adjudicated": False, "parent_task_transform_adjudicated": False,
              "direction_ranked": False, "trade_permission": False,
              "readout": "暂时还不能把本周期的各段走势与上级波段两端完整对上。",
              "boundary": "同端点只证明两级可能描述同一走势；不证明两段都是有效1:1、上级第一力度或趋势已确立。"}
    if timeframe not in MINUTES or not snapshot.get("provider") or not snapshot.get("instrument"):
        return result
    try:
        cutoff = _time(snapshot["as_of_utc"])
        _, raw, legs = _native(snapshot, timeframe, cutoff)
    except (KeyError, TypeError, ValueError):
        return result
    parents = []
    for tf, minutes in MINUTES.items():
        if minutes <= MINUTES[timeframe]:
            continue
        try:
            state, parent_raw, parent_legs = _native(snapshot, tf, cutoff)
        except (KeyError, TypeError, ValueError):
            result["unavailable_parent_timeframes"].append(tf)
            continue
        index = {}
        for leg in parent_legs:
            if _leg(leg, tf, parent_raw, cutoff):
                index.setdefault((leg["origin"]["price"], leg["terminal"]["price"]), []).append(leg)
        parents.append((tf, index, parent_legs[-1].get("leg_id") if parent_legs else None))
    records = []
    for ab, bc, cd in zip(legs, legs[1:], legs[2:]):
        if not all(_leg(leg, timeframe, raw, cutoff) for leg in (ab, bc, cd)):
            continue
        if (len({leg["leg_id"] for leg in (ab, bc, cd)}) != 3
                or not _same(ab["terminal"], bc["origin"]) or not _same(bc["terminal"], cd["origin"])):
            continue
        a, b, c, d = ab["origin"], ab["terminal"], bc["terminal"], cd["terminal"]
        first, second, retracement = b["price"]-a["price"], d["price"]-c["price"], c["price"]-b["price"]
        if first * second <= 0 or first * retracement >= 0:
            continue
        projected = c["price"] + first
        if not _number(projected):
            continue
        ruler_known = max(_time(pivot["confirmed_at_utc"]) for pivot in (a, b, c))
        second_end = _time(d["pivot_timestamp_utc"])
        touch = next((bar for stamp, bar in sorted(raw.items())
                      if ruler_known <= stamp <= second_end and bar["low"] <= projected <= bar["high"]), None)
        for parent_tf, index, latest_parent_leg_id in parents:
            for parent in index.get((a["price"], d["price"]), []):
                if not (_shared_extremum(a, parent["origin"], parent_tf) and _shared_extremum(d, parent["terminal"], parent_tf)):
                    continue
                identity = [snapshot["instrument"], snapshot["provider"], timeframe, parent_tf,
                            ab["leg_id"], bc["leg_id"], cd["leg_id"], parent["leg_id"]]
                row = {"composition_id": hashlib.sha256(json.dumps(identity, separators=(",", ":")).encode()).hexdigest()[:24],
                       "child_timeframe": timeframe, "parent_timeframe": parent_tf,
                       "child_leg_ids": [ab["leg_id"], bc["leg_id"], cd["leg_id"]],
                       "parent_candidate_leg_id": parent["leg_id"],
                       "parent_is_latest_confirmed_leg": parent["leg_id"] == latest_parent_leg_id,
                       "anchors": {"A": a, "B": b, "C": c, "D": d},
                       "parent_origin": parent["origin"], "parent_terminal": parent["terminal"],
                       "direction_observation": ab["direction_observation"],
                       "first_push_length": abs(first), "second_push_length": abs(second),
                       "second_to_first_height_ratio": round(abs(second / first), 6),
                       "equal_distance_reference": projected,
                       "second_terminal_minus_reference": round(d["price"] - projected, 6),
                       "ruler_known_at_utc": ruler_known.isoformat().replace("+00:00", "Z"),
                       "ruler_known_before_second_terminal": ruler_known <= second_end,
                       "reference_touch_after_ruler_known_bar_open_utc": touch["timestamp_utc"] if touch else None,
                       "composition_known_at_utc": max(_time(pivot["confirmed_at_utc"]) for pivot in (a,b,c,d,parent["origin"],parent["terminal"])).isoformat().replace("+00:00", "Z"),
                       "independent_direction_confirmation_count": 0,
                       "status": "shared_native_extrema_two_push_composition_not_task_transform",
                       "first_force_leg_adjudicated": False, "parent_task_transform_adjudicated": False,
                       "trade_permission": False}
                row["readout"] = (f"{timeframe} {'该已确认波段' if row['parent_is_latest_confirmed_leg'] else '历史波段'}：先走 {a['price']:.2f}→{b['price']:.2f}，回到 {c['price']:.2f}，"
                    f"再走至 {d['price']:.2f}；两次推动合起来，共享 {parent_tf} 的 {a['price']:.2f}→{d['price']:.2f} 波段两端。"
                    f"从 {c['price']:.2f} 按首段高度量，等距参考是 {projected:.2f}。"
                    "这是同一走势的分层读法，不多算一份方向证据；是否形成上级第一力度，还要看关键结构、拒绝与接受。")
                records.append(row)
    records.sort(key=lambda row: (_time(row["composition_known_at_utc"]), row["composition_id"]), reverse=True)
    representatives = []
    for parent_tf, _, _ in parents:
        options = [row for row in records if row["parent_timeframe"] == parent_tf]
        # Display current parent segment before historical compositions; no
        # claim that absence of a two-push match makes that parent invalid.
        if options:
            representatives.append(next((row for row in options if row["parent_is_latest_confirmed_leg"]), options[0]))
    result.update(status="native_two_push_compositions_reviewed" if records else "no_shared_two_push_extrema_in_loaded_history",
                  records=records, representatives=representatives, record_count=len(records))
    if representatives:
        result["readout"] = representatives[0]["readout"]
    paths, path_representatives = _paths(snapshot, timeframe, legs, raw, parents, cutoff)
    result.update(child_paths=paths, path_representatives=path_representatives, child_path_count=len(paths))
    if path_representatives:
        result["status"] = "native_child_paths_and_two_push_compositions_reviewed"
        current = next((row for row in path_representatives if row["parent_is_latest_confirmed_leg"]), path_representatives[0])
        result["readout"] = current["summary_readout"]
    return result
