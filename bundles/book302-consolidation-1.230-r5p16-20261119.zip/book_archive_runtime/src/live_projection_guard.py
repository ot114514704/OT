"""Check that a live 1:1 number really belongs to a confirmed A-B-C geometry.

This only validates the measurement, not the market meaning of A, B or C.
In particular, a valid projection is neither an active DOL nor a trade target.
"""

from __future__ import annotations

from datetime import datetime, timezone
import math
from typing import Any


def _finite_price(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    number = float(value)
    return number if math.isfinite(number) else None


def _utc(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed.astimezone(timezone.utc) if parsed.tzinfo else None


def anchored_one_to_one_value(measurement: Any) -> float | None:
    """Return the C-anchored A-B equal-distance candidate, or reject it.

    Accept both the raw measurement (which nests ``one_to_one_source_leg``)
    and the flattened target-graph row. Persisted terminal doubles, missing
    pivot order and numerically inconsistent targets remain unbound.
    """
    if not isinstance(measurement, dict) or measurement.get("projection_family") != "retracement_anchored_geometric_candidate":
        return None
    source = measurement.get("one_to_one_source_leg") or measurement
    anchor = measurement.get("projection_anchor")
    if not isinstance(source, dict) or not isinstance(anchor, dict):
        return None
    origin, terminal = source.get("origin"), source.get("terminal")
    if not isinstance(origin, dict) or not isinstance(terminal, dict):
        return None
    a, b, c, target = (
        _finite_price(origin.get("price")),
        _finite_price(terminal.get("price")),
        _finite_price(anchor.get("price")),
        _finite_price(measurement.get("one_to_one_target_candidate")),
    )
    if any(value is None for value in (a, b, c, target)):
        return None
    a_time, b_time, c_time = (
        _utc(origin.get("pivot_timestamp_utc")),
        _utc(terminal.get("pivot_timestamp_utc")),
        _utc(anchor.get("pivot_timestamp_utc")),
    )
    b_confirm, c_confirm = _utc(terminal.get("confirmed_at_utc")), _utc(anchor.get("confirmed_at_utc"))
    if any(value is None for value in (a_time, b_time, c_time, b_confirm, c_confirm)):
        return None
    if not (a_time < b_time < c_time <= c_confirm and b_time <= b_confirm <= c_confirm):
        return None
    direction = source.get("direction_observation")
    if direction not in {"up", "down"} or (b > a) != (direction == "up") or a == b:
        return None
    if not min(a, b) < c < max(a, b):
        return None
    expected = c + (b - a)
    if not math.isclose(target, expected, rel_tol=0, abs_tol=0.00001):
        return None
    return target


def safe_measurement_candidate(measurement: Any) -> dict[str, Any]:
    """Keep raw geometry provenance, but withhold unverified target/touch claims."""
    if not isinstance(measurement, dict):
        return {}
    safe = dict(measurement)
    target = anchored_one_to_one_value(measurement)
    safe["one_to_one_target_candidate"] = target
    if target is None:
        safe["candidate_target_touch_observation"] = {"status": "candidate_or_confirmation_unavailable"}
        safe["source_leg_origin_side_close_observation"] = None
    return safe


def safe_context_candidate(context: Any) -> dict[str, Any]:
    if not isinstance(context, dict):
        return {}
    safe = dict(context)
    safe["one_to_one_target_candidate"] = anchored_one_to_one_value(context)
    nested = context.get("separate_retracement_anchored_measurement")
    if isinstance(nested, dict):
        candidate = {
            "projection_family": "retracement_anchored_geometric_candidate",
            "one_to_one_source_leg": nested.get("source_leg"),
            "projection_anchor": nested.get("projection_anchor"),
            "one_to_one_target_candidate": nested.get("target_candidate"),
        }
        nested_target = anchored_one_to_one_value(candidate)
        safe_nested = dict(nested)
        safe_nested["target_candidate"] = nested_target
        if nested_target is None:
            safe_nested["target_touch_observation"] = None
            safe_nested["source_origin_side_close_observation"] = None
        safe["separate_retracement_anchored_measurement"] = safe_nested
    return safe


def safe_structure_projection(projection: Any) -> dict[str, Any]:
    """Sanitize persisted projection rows before explaining or gating them."""
    if not isinstance(projection, dict):
        return {}
    safe = dict(projection)
    for key in ("higher_context_candidates", "parent_task_candidates"):
        safe[key] = [safe_context_candidate(item) for item in projection.get(key) or [] if isinstance(item, dict)]
    graph = projection.get("target_graph")
    if isinstance(graph, dict):
        safe_graph = dict(graph)
        safe_graph["candidate_measurements"] = [safe_measurement_candidate(item)
                                                for item in graph.get("candidate_measurements") or []
                                                if isinstance(item, dict)]
        safe["target_graph"] = safe_graph
    return safe
