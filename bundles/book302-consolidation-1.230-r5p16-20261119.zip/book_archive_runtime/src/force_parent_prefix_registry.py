"""Read stable, verified original-prefix facts; never store scene/engine hashes here.

Evidence publication is separate. This avoids engine->registry->scene cycles.
No nearest-wave fallback or inference from a later parent summary.
"""
from copy import deepcopy
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path

from .force_strength_model import epoch
from .mt5_structure_logic import PARENTS

ROOT=Path(__file__).resolve().parents[1]
REGISTRY=ROOT/'04_wells4_support/force_formation_parent_registry.json'


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def key_for(force,provider,instrument):
    identity=dict(provider=provider,instrument=instrument,timeframe=force['timeframe'],
        owner_id=force.get('id'),source_id=force.get('source_id'),
        source_points=[[float(t),float(p)] for t,p in force['points']],source_known_at_utc=force['known_at_utc'])
    return sha256(canonical(identity)).hexdigest()


@lru_cache(maxsize=4)
def _load(path,mtime,size):
    raw=Path(path).read_bytes();data=json.loads(raw)
    if data.get('schema')!='force_formation_parent_registry_v1' or not isinstance(data.get('entries'),dict):
        raise ValueError('Invalid formation prefix registry')
    return data,sha256(raw).hexdigest()


def lookup(force,scene,path=None):
    path=Path(path or REGISTRY)
    result=dict(status='not_found',record_id=None,registry_sha256=None,context=None)
    try:
        if epoch(force['known_at_utc'])>epoch(scene['cutoff_utc']):return dict(result,status='source_not_yet_known')
        stat=path.stat();data,digest=_load(str(path),stat.st_mtime_ns,stat.st_size)
        key=key_for(force,scene.get('provider'),scene.get('instrument'));entry=data['entries'].get(key)
        result.update(record_id=key,registry_sha256=digest)
        if not entry:return result
        context=entry['context']
        expected=dict(provider=scene.get('provider'),instrument=scene.get('instrument'),timeframe=force['timeframe'],
            parent_timeframe=PARENTS.get(force['timeframe']),owner_id=force.get('id'),source_id=force.get('source_id'),
            source_points=force['points'],source_known_at_utc=force['known_at_utc'],as_of_utc=force['known_at_utc'])
        if (any(context.get(k)!=v for k,v in expected.items()) or
            context.get('schema')!='force_native_parent_prefix_v1' or
            context.get('status')!='verified_same_feed_sequence_not_parent_task' or
            context.get('automatic_trade_permission') is not False or
            not context.get('native_evidence_sha256') or
            not context.get('known_at_utc') or epoch(context['known_at_utc'])>epoch(force['known_at_utc']) or
            entry.get('context_sha256')!=sha256(canonical(context)).hexdigest()):
            return dict(result,status='rejected_identity_clock_or_digest')
        return dict(result,status='matched',context=deepcopy(context))
    except FileNotFoundError:return dict(result,status='registry_not_present')
    except (OSError,ValueError,TypeError,KeyError,AttributeError):return dict(result,status='invalid_registry_or_record')
