"""Persistent paper observation of a particular 1:1 source/anchor/state.

An earlier calculable clock is not an earlier actual observation. Keep the
first runtime witness separate for developing and fully accepted contexts.
No later score change creates a new projection or resets its first witness.
"""
from copy import deepcopy
from .book_first_response_leg import clock
from .book_breakout_assessment import digest


def observe_context(fact, registry, cutoff, observed, snapshot):
    if not isinstance(fact,dict):return fact
    result=deepcopy(fact)
    try:
        if (fact.get('schema')!='book_one_to_one_execution_context_v2' or
                fact.get('automatic_trade_permission') is not False or fact.get('order_api_called') is not False or
                fact.get('state') not in ('same_phase_research_ready','same_source_developing_reference')):
            return result
        if fact.get('as_of_utc')!=cutoff or clock(fact['known_at_utc'])>clock(cutoff):return result
        if clock(observed)<clock(cutoff):return result
        fields=('schema','phase_id','book_source_id','source_identity','working_timeframe',
                'provider','symbol','one_to_one_object_id','one_to_one_source_leg_id','measurement_id','projection_id')
        identity={k:deepcopy(fact[k]) for k in fields}
        binding=fact['binding_receipt']
        identity['native_AB_map']=deepcopy(binding['native_AB_map'])
        # A changed anchor under the same projection identity is corruption,
        # rather than permission to make a second opportunity.
        key='one_to_one_observed:'+digest([identity[k] for k in fields])
        record=registry.setdefault(key,dict(identity=identity,states={}))
        if record['identity']!=identity:
            result['state']='source_identity_changed';return result
        state=fact['state']
        witness=record['states'].setdefault(state,dict(first_observed_at_utc=observed,
            native_cutoff_utc=cutoff,prefix_snapshot_id=snapshot))
        result['known_at_utc']=max((fact['known_at_utc'],witness['first_observed_at_utc']),key=clock)
        result['runtime_observation_witness']=deepcopy(witness)
        return result
    except (KeyError,TypeError,ValueError):
        return result
