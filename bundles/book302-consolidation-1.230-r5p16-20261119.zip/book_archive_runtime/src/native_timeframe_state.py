"""Resolve compact native state without laundering an invalid present ledger.

Chart packets may omit a ledger already carried in the same report. Omission
is not corruption, and corruption is not permission to borrow another row.
No market, timeframe or snapshot identities are inferred or rewritten here.
"""


def _identity(record, snapshot, timeframe, label):
    if not isinstance(record,dict):
        raise ValueError(f'{label} must be a record')
    expected=dict(timeframe=timeframe,snapshot_id=snapshot.get('snapshot_id'),
        as_of_utc=snapshot.get('as_of_utc'),provider=snapshot.get('provider'),
        instrument=snapshot.get('instrument'),symbol=snapshot.get('instrument'))
    for key,value in expected.items():
        if key in record and record[key]!=value:
            raise ValueError(f'{label} {key} conflicts with native snapshot')


def resolve_native_timeframe_state(snapshot,timeframe):
    root=snapshot.get('timeframe_states',{})
    if not isinstance(root,dict):
        raise ValueError('native root states must be a mapping')
    compact=root.get(timeframe,{})
    _identity(compact,snapshot,timeframe,'native root state')
    if 'candidate_wave_ledger' in compact:
        selected=compact
    else:
        report=snapshot.get('analysis_report',{})
        _identity(report,snapshot,timeframe,'native report')
        rows=report.get('timeframes',[])
        if not isinstance(rows,list):
            raise ValueError('native report timeframes must be a list')
        matches=[row for row in rows if isinstance(row,dict) and row.get('timeframe')==timeframe]
        if len(matches)!=1:
            raise ValueError('native report must have exactly one matching timeframe')
        full=matches[0]
        _identity(full,snapshot,timeframe,'native report state')
        # Already supplied compact facts are constraints, not fields that a
        # convenient complete report row may replace.
        for key in ('latest_closed_bar_open_utc','latest_closed_bar_end_utc','source_mode','source_status'):
            if key in compact and (key not in full or compact[key]!=full[key]):
                raise ValueError(f'compact {key} conflicts with report state')
        if 'latest_closed_bar' in compact:
            a,b=compact['latest_closed_bar'],full.get('latest_closed_bar')
            _identity(a,snapshot,timeframe,'compact latest bar')
            _identity(b,snapshot,timeframe,'report latest bar')
            for key in ('timestamp_utc','open','high','low','close'):
                if key not in a or key not in b or a[key]!=b[key]:
                    raise ValueError(f'compact latest bar {key} conflicts with report')
        selected={**full,**compact,'candidate_wave_ledger':full.get('candidate_wave_ledger')}
    ledger=selected.get('candidate_wave_ledger')
    _identity(ledger,snapshot,timeframe,'native ledger')
    if ledger.get('timeframe')!=timeframe or not isinstance(ledger.get('legs'),list):
        raise ValueError('native ledger requires its own timeframe and leg list')
    return selected
