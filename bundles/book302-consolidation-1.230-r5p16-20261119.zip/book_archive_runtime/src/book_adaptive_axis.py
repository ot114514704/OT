"""One declared diagnostic range for Book's finite recovery candidates.

Search windows generate legal contacts under their own original geometry
rules. Their raw axis readings have different ranges and cannot be ranked
against each other. This engineering display choice establishes no author
source, phase, wave degree or score eligibility.
"""
from copy import deepcopy
from math import isfinite
from .book_complete_wave_channels import owned_axis_measurement
from .book_calculation_cancel import check_current


def select(rows,candidates,timeframe,known_at):
    check_current()
    width=max(int(c['selection_lookback_bars']) for c in candidates)
    reference=rows[-width:]
    groups={}
    for candidate in candidates:
        key=(candidate.get('direction'),candidate['start_utc'],candidate['start_price'],
             candidate['end_utc'],candidate['end_price'])
        groups.setdefault(key,[]).append(candidate)
    readings=[];representatives=[]
    for geometry,witnesses in groups.items():
        # Earliest generated witness represents identical physical geometry;
        # the alternative windows remain diagnostic provenance, never votes.
        candidate=witnesses[0]
        measurement=owned_axis_measurement(reference,float(candidate['slope']),known_at=known_at)
        value=measurement.get('alignment_measure')
        value=value if isinstance(value,(int,float)) and isfinite(value) else None
        readings.append(dict(direction=geometry[0],source_contacts=[[geometry[1],geometry[2]],[geometry[3],geometry[4]]],
            generation_windows=[w['selection_lookback_bars'] for w in witnesses],
            generation_diagnostics=[dict(lookback_bars=w['selection_lookback_bars'],
                axis_alignment=deepcopy(w.get('axis_alignment') or {})) for w in witnesses],
            common_axis=measurement,source_membership='unknown',author_degree_verified=False,
            geometry_admission='original_generation_scope_only_not_promoted_by_common_measurement'))
        representatives.append((candidate,value))
    selected,_=max(representatives,key=lambda item:(
        item[1] is not None,-item[1] if item[1] is not None else float('-inf'),
        int(item[0].get('anchor_span_bars') or 0),float(item[0].get('min_clearance') or 0.0)))
    result=dict(selected)
    selected_reading=next(r for r in readings if r['source_contacts']==[
        [selected['start_utc'],selected['start_price']],[selected['end_utc'],selected['end_price']]])
    common=deepcopy(selected_reading['common_axis']);drift=common.get('alignment_measure')
    common.update(score=None,ranking_value=-drift if drift is not None else -1e300,
        score_version='Book_adaptive_common_diagnostic_axis_v1',
        scope_role='fixed_selection_prefix_not_author_wave_membership',
        reference_start_index=max(0,len(rows)-width),source_contact_index=selected['start_index'],
        second_contact_index=selected['end_index'],terminal_index=len(rows)-1,
        rank_policy='same_closed_recovery_search_range_engineering_display_only',author_degree_verified=False)
    result.update(axis_alignment=common,axis_alignment_score=None,axis_rank_policy=common['rank_policy'])
    result['adaptive_axis_comparison']=dict(schema='Book_adaptive_common_diagnostic_axis_v1',
        policy='same_closed_recovery_search_range_engineering_display_only',timeframe=timeframe,
        known_at_utc=known_at,reference_start_utc=reference[0]['timestamp_utc'],
        reference_end_utc=reference[-1]['timestamp_utc'],reference_bars=len(reference),
        candidate_window_count=len(candidates),distinct_geometry_count=len(groups),
        candidates=readings,selected_contacts=[[selected['start_utc'],selected['start_price']],
            [selected['end_utc'],selected['end_price']]],
        raw_cross_window_readings_ranked=False,source_membership='unknown',phase_relation='unknown',
        author_degree_verified=False,author_calibrated=False,score_admission=False,
        geometry_revalidated_on_common_scope=False,reference_role='search_range_not_declared_author_wave',
        automatic_trade_permission=False)
    return result
