"""Book rejection scans once the original detailed audit limit is reached.

Every candidate is still checked. A non-positive clearance already determines
rejection, so only successful candidates need the full minimum. Callers must
use this only for finite native values and after detailed receipts are full;
otherwise the exact rejected minimum is part of the original output contract.
"""


def clearance(values,i,j,slope,sign,start,stop):
    minimum=None
    for k in range(start,stop):
        if k==j:continue
        gap=(values[i]+slope*(k-i)-values[k])*sign
        if gap<=1e-9:return [gap]
        if minimum is None or gap<minimum:minimum=gap
    return [] if minimum is None else [minimum]
