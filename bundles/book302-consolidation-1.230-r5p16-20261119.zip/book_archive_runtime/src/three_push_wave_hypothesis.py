"""Research-only quantitative reading of three same-direction pushes.

The source book's wave examples are conditional proportions, not a detector
that can assign author wave degree from three arbitrary pivots.  This module
keeps the measurements separate and returns bounded engineering scores for
comparison.  It never selects a target, opens an entry, or grants permission.
"""

from __future__ import annotations

from math import isfinite


def _clip(value: float) -> float:
    return max(0.0, min(100.0, float(value)))


def _fit(value: float, target: float, scale: float) -> float:
    if not isfinite(value) or not isfinite(target) or scale <= 0:
        return 0.0
    return _clip(100.0 * (1.0 - abs(value - target) / scale))


def _band(value: float, lower: float, upper: float) -> float:
    if not isfinite(value):
        return 0.0
    if lower <= value <= upper:
        return 100.0
    # A continuous falloff makes the research ranking inspectable without
    # pretending that 1.618 or 2.618 is a calibrated hard boundary.
    distance = lower - value if value < lower else value - upper
    return _clip(100.0 * (1.0 - distance / max(upper - lower, 1e-12)))


def quantify_three_pushes(push_lengths, return_lengths=(), push_seconds=(),
                          return_prior_ratios=()):
    """Return equal-unit, extended-middle, and correction-depth readings.

    ``push_lengths`` is [P1, P2, P3].  ``return_lengths`` contains the two
    connectors (P1->P2 and P2->P3).  Scores are descriptive and deliberately
    independent: a deep return does not turn a geometric ratio into a valid
    entry.  The 1.618-2.618 band is explicitly marked as a user research
    hypothesis; the book-backed conditional comparison remains 1/1.618 for
    the middle wave and 1/.618 for the later wave when the middle extends.
    """
    lengths = [float(v) for v in push_lengths]
    if len(lengths) != 3 or any(not isfinite(v) or v <= 0 for v in lengths):
        return {"status": "invalid_push_lengths", "scores": {},
                "automatic_trade_permission": False}
    unit = lengths[0]
    ratios = [v / unit for v in lengths]
    equal_score = _clip(100.0 * (1.0 - sum(abs(v - 1.0) for v in ratios) / 3.0))
    outer_symmetry = _fit(ratios[2] / ratios[0], 1.0, 1.0)
    middle_book_1 = _fit(ratios[1], 1.0, 1.0)
    middle_book_1618 = _fit(ratios[1], 1.618, 1.618)
    middle_user_band = _band(ratios[1], 1.618, 2.618)
    extended_score = _clip(0.55 * middle_user_band + 0.45 * outer_symmetry)
    later_book_one = _fit(ratios[2], 1.0, 1.0)
    later_book_point618 = _fit(ratios[2], 0.618, 0.618)
    if ratios[1] >= 1.0:
        later_extended_score = _clip(0.6 * max(later_book_one, later_book_point618)
                                     + 0.4 * middle_book_1618)
    else:
        later_extended_score = 0.0

    returns = [float(v) for v in return_lengths]
    return_ratios = [float(v) for v in return_prior_ratios]
    deepest_index = None
    deepest_ratio = None
    if returns:
        deepest_index = max(range(len(returns)), key=lambda i: returns[i])
        if deepest_index < len(return_ratios):
            deepest_ratio = return_ratios[deepest_index]
    # This is the requested C-D callback/deepest-return evidence.  It is
    # measured relative to its immediately preceding push, never substituted
    # for the correction terminal or used as a prospective anchor.
    depth_observation = {
        "status": "observed" if returns else "missing",
        "deepest_index": deepest_index,
        "deepest_return_length": returns[deepest_index] if deepest_index is not None else None,
        "deepest_return_to_prior_push": deepest_ratio,
        "anchor_role": "deepest_interval_excursion_only",
        "terminal_substitution_forbidden": True,
    }
    speed = []
    if push_seconds and len(push_seconds) == 3:
        speed = [lengths[i] / float(push_seconds[i]) if float(push_seconds[i]) > 0 else None
                 for i in range(3)]
    scores = {
        "equal_unit_1_1_1": round(equal_score, 6),
        "book_middle_1_or_1_618": round(max(middle_book_1, middle_book_1618), 6),
        "user_middle_1_618_to_2_618": round(extended_score, 6),
        "book_later_1_or_0_618_after_extension": round(later_extended_score, 6),
    }
    # Exact equality at 1:1:1 is a true tie with the book's allowed
    # middle=1 reference.  Prefer the more specific complete equal-unit
    # description in that tie; it does not make a trading selection.
    tie_priority = {
        "equal_unit_1_1_1": 0,
        "user_middle_1_618_to_2_618": 1,
        "book_middle_1_or_1_618": 2,
        "book_later_1_or_0_618_after_extension": 3,
    }
    ordered = sorted(scores.items(), key=lambda item: (-item[1], tie_priority[item[0]]))
    overall_score = ordered[0][1] if ordered else None
    return {
        "schema": "three_push_wave_hypothesis_v1",
        "status": "descriptive_research_measurement",
        "push_lengths": lengths,
        "ratios_to_first_push": ratios,
        "scores": scores,
        "overall_score": round(overall_score, 6) if overall_score is not None else None,
        "overall_score_basis": "highest descriptive ratio-family fit; return depth remains a separate observation",
        "ranking": [name for name, _ in ordered],
        "preferred_reading": ordered[0][0] if ordered else None,
        "return_depth": depth_observation,
        "push_speed_per_second": speed,
        "rules": {
            "equal_unit": "P1,P2,P3 each compared with AB-sized first unit",
            "extended_trend": "conditional middle 1/1.618; later 1/.618 or 1 when middle extends",
            "user_research_band": "middle 1.618..2.618, not a book frequency claim",
            "deep_callback": "deepest C-D style interval return is evidence only; correction terminal is separate",
        },
        "calibration_status": "unvalidated_engineering_scores",
        "author_wave_degree_adjudicated": False,
        "selected_for_execution": False,
        "automatic_trade_permission": False,
    }
