"""Derived publication index; immutable original receipts remain authoritative.

Ingestion is a normal publisher write. Discovery/restore never write, create an
index, infer a missing map or select a later receipt. All clocks here describe
closed-bar replay, not historical live arrival or native chart application.
"""
from copy import deepcopy
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
import json,re,sqlite3

VERSION='digger_inventory_history_v1'
INDEX='digger_inventory_history.sqlite3'
HEX=re.compile(r'[0-9a-f]{64}')
TOKEN=re.compile(r'[0-9_]+')


def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf8')


def epoch(value):
    t=datetime.fromisoformat(value.replace('Z','+00:00'))
    if t.tzinfo is None:raise ValueError('history_aware_clock_required')
    return t.timestamp()


def _hash(value):return sha256(canonical(value)).hexdigest()


def _identity(token,scene_id):
    if not isinstance(token,str) or not TOKEN.fullmatch(token) or not isinstance(scene_id,str) or not HEX.fullmatch(scene_id):
        raise ValueError('history_publication_identity_invalid')


def _artifact(directory,token,scene_id):
    _identity(token,scene_id);root=Path(directory).resolve()
    path=(root/f'{token}.{scene_id}.json').resolve()
    if path.parent!=root:raise ValueError('history_publication_path_outside_directory')
    return path


def _validated(raw,scene_id):
    from .gobi_digger_context import consume_context
    from .gobi_digger_task_review import build_review
    from .gobi_digger_context import MINUTES
    scene=json.loads(raw)
    if scene.get('scene_id')!=scene_id or _hash({k:v for k,v in scene.items() if k!='scene_id'})!=scene_id:
        raise ValueError('history_scene_content_identity_mismatch')
    context=consume_context(scene)
    if context.get('status')!='consumed_native_observations' or context!=(scene.get('integrated_market_logic') or {}).get('gobi_digger_context'):
        raise ValueError('history_main_consumer_not_verified')
    if build_review(scene,context,MINUTES)!=(scene.get('integrated_market_logic') or {}).get('gobi_digger_review'):
        raise ValueError('history_task_review_not_verified')
    inventory=context.get('digger_event_time_inventory')
    if inventory is None:raise ValueError('history_inventory_not_produced')
    if scene.get('automatic_trade_permission',False) is not False:raise ValueError('history_permission_upgrade')
    return scene,context,inventory


def prepare(raw,token,scene_id):
    """Validate before either immutable files or index metadata are changed."""
    _identity(token,scene_id)
    decoded=json.loads(raw)
    if not isinstance(decoded,dict):raise ValueError('history_scene_object_required')
    if 'digger_event_time_inventory' not in (decoded.get('gobi_digger_producer') or {}):return None
    scene,context,inventory=_validated(raw,scene_id)
    receipt=scene['gobi_digger_producer']['receipt_id']
    body=dict(publication_token=token,scene_id=scene_id,producer_receipt_id=receipt,
        publication_json_sha256=sha256(raw).hexdigest(),provider=scene['provider'],instrument=scene['instrument'],
        chart_timeframe=scene['timeframe'],feed_id=inventory['feed_identity']['feed_id'],
        scene_as_of_utc=scene['cutoff_utc'],producer_known_at_utc=context['known_at_utc'])
    return dict(publication_id=_hash(body),**body,inventory=inventory)


def _connect_writer(directory):
    root=Path(directory);root.mkdir(parents=True,exist_ok=True)
    if (root/INDEX).resolve().parent!=root.resolve():raise ValueError('history_index_path_outside_directory')
    db=sqlite3.connect(root/INDEX,timeout=30)
    # A closed writer leaves a standalone DB. Read-only recovery needs no WAL
    # side files and never invokes this connection helper.
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('CREATE TABLE IF NOT EXISTS history_schema (version TEXT PRIMARY KEY)')
    versions=[r[0] for r in db.execute('SELECT version FROM history_schema')]
    if versions and versions!=[VERSION]:db.close();raise ValueError('history_index_schema_unknown')
    db.execute('INSERT OR IGNORE INTO history_schema VALUES (?)',(VERSION,))
    db.execute('CREATE TABLE IF NOT EXISTS publications (id TEXT PRIMARY KEY, token TEXT, scene_id TEXT, receipt_id TEXT, json_sha TEXT, provider TEXT, instrument TEXT, timeframe TEXT, feed_id TEXT, asof REAL, known REAL, indexed_at_utc TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS inventories (id TEXT PRIMARY KEY, feed_id TEXT, known REAL, body_sha TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS publication_maps (publication_id TEXT, map_id TEXT, PRIMARY KEY(publication_id,map_id), FOREIGN KEY(publication_id) REFERENCES publications(id), FOREIGN KEY(map_id) REFERENCES inventories(id))')
    db.execute('CREATE TABLE IF NOT EXISTS map_sources (map_id TEXT, source_id TEXT, PRIMARY KEY(map_id,source_id), FOREIGN KEY(map_id) REFERENCES inventories(id))')
    return db


def index_prepared(directory,prepared):
    if prepared is None:return None
    p=prepared;path=_artifact(directory,p['publication_token'],p['scene_id'])
    if sha256(path.read_bytes()).hexdigest()!=p['publication_json_sha256']:raise ValueError('history_original_artifact_changed')
    db=_connect_writer(directory)
    try:
        with db:
            values=(p['publication_id'],p['publication_token'],p['scene_id'],p['producer_receipt_id'],p['publication_json_sha256'],
                p['provider'],p['instrument'],p['chart_timeframe'],p['feed_id'],epoch(p['scene_as_of_utc']),epoch(p['producer_known_at_utc']))
            old=db.execute('SELECT id,token,scene_id,receipt_id,json_sha,provider,instrument,timeframe,feed_id,asof,known FROM publications WHERE id=?',(p['publication_id'],)).fetchone()
            if old is not None and old!=values:raise ValueError('history_publication_index_conflict')
            db.execute('INSERT OR IGNORE INTO publications VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',values+(datetime.now(timezone.utc).isoformat(),))
            for m in p['inventory']['inventory_versions']:
                entry=(m['inventory_version_id'],m['feed_id'],epoch(m['known_at_utc']) if m['known_at_utc'] else None,_hash(m))
                old=db.execute('SELECT id,feed_id,known,body_sha FROM inventories WHERE id=?',(entry[0],)).fetchone()
                if old is not None and old!=entry:raise ValueError('history_map_identity_conflict')
                db.execute('INSERT OR IGNORE INTO inventories VALUES (?,?,?,?)',entry)
                db.execute('INSERT OR IGNORE INTO publication_maps VALUES (?,?)',(p['publication_id'],entry[0]))
                for sid in m['member_source_version_ids']:
                    db.execute('INSERT OR IGNORE INTO map_sources VALUES (?,?)',(entry[0],sid))
    finally:db.close()
    return dict(schema=VERSION,publication_id=p['publication_id'],inventory_versions=len(p['inventory']['inventory_versions']),
        original_scene_id=p['scene_id'],read_only=True,automatic_trade_permission=False,future_bars_used=False)


def backfill(directory,token,scene_id):
    """Explicit index repair/import from one exact original, never a glob scan."""
    path=_artifact(directory,token,scene_id)
    return index_prepared(directory,prepare(path.read_bytes(),token,scene_id))


def reference(prepared,inventory_version_id):
    m=next((m for m in prepared['inventory']['inventory_versions'] if m['inventory_version_id']==inventory_version_id),None)
    if m is None:raise ValueError('history_map_not_in_original_receipt')
    keys=('publication_token','scene_id','producer_receipt_id','publication_json_sha256','provider','instrument',
        'chart_timeframe','feed_id','scene_as_of_utc','producer_known_at_utc')
    return dict(schema=VERSION,**{k:prepared[k] for k in keys},inventory_version_id=inventory_version_id,
        inventory_known_at_utc=m['known_at_utc'])


def _base(status):
    return dict(schema=VERSION,status=status,read_only=True,automatic_trade_permission=False,future_bars_used=False,
        entry_permission=False,owner_equivalence=False,score_effect='none',direction_effect='none',
        availability_scope='saved_closed_bar_replay_receipt_not_historical_live_arrival',live_first_seen_verified=False)


def restore(directory,ref,*,as_of_utc,provider,instrument,chart_timeframe,feed_id,require_ready=False):
    """Exact original receipt lookup; index absence cannot create/fabricate data."""
    result=_base('rejected')
    try:
        if type(require_ready) is not bool:raise ValueError('history_ready_requirement_invalid')
        if not isinstance(ref,dict) or ref.get('schema')!=VERSION:raise ValueError('history_reference_schema')
        now=epoch(as_of_utc)
        for key,value in (('provider',provider),('instrument',instrument),('chart_timeframe',chart_timeframe),('feed_id',feed_id)):
            if ref.get(key)!=value:raise ValueError('history_reference_'+key+'_mismatch')
        if epoch(ref['scene_as_of_utc'])>now or epoch(ref['producer_known_at_utc'])>now:
            raise ValueError('history_original_receipt_after_requested_asof')
        path=_artifact(directory,ref['publication_token'],ref['scene_id']);raw=path.read_bytes()
        if sha256(raw).hexdigest()!=ref['publication_json_sha256']:raise ValueError('history_original_bytes_mismatch')
        p=prepare(raw,ref['publication_token'],ref['scene_id'])
        if p is None:raise ValueError('history_original_inventory_absent')
        expected=reference(p,ref['inventory_version_id'])
        if ref!=expected:raise ValueError('history_reference_does_not_match_original')
        if expected['inventory_known_at_utc'] is not None and epoch(expected['inventory_known_at_utc'])>now:
            raise ValueError('history_map_after_requested_asof')
        scene=json.loads(raw);ready=Path(directory)/f'{ref["publication_token"]}.ready';marker=None
        if ready.is_file():
            parts=ready.read_text(encoding='utf8').strip().split('\t')
            marker=len(parts)>=3 and parts[:3]==[ref['scene_id'],'1',scene['engine_revision']]
        if require_ready and marker is not True:raise ValueError('history_ready_not_verified_for_original')
        inventory=deepcopy(p['inventory']);m=next(m for m in inventory['inventory_versions'] if m['inventory_version_id']==ref['inventory_version_id'])
        members=set(m['member_source_version_ids'])
        result.update(status='restored_original_observation',reference=deepcopy(ref),requested_as_of_utc=as_of_utc,
            original_inventory=inventory,requested_map=m,
            requested_member_sources=[s for s in inventory['source_versions'] if s['source_version_id'] in members],
            events_in_requested_map=[e for e in inventory['events'] if e['inventory_version_id']==ref['inventory_version_id']],
            original_publication_path=str(path),ready_marker_matches_now=marker is True,
            native_application_verified=False,index_required_for_exact_reference_restore=False)
    except (ValueError,TypeError,KeyError,OSError,OverflowError,AttributeError) as error:
        result['reason']=str(error)
    return result


def discover(directory,*,as_of_utc,provider,instrument,chart_timeframe,feed_id,inventory_version_id=None,source_version_id=None,limit=50):
    """Return verified candidates; never choose the most recent receipt for caller."""
    result=_base('not_indexed');path=Path(directory)/INDEX
    if not path.is_file():return result
    db=None
    try:
        if isinstance(limit,bool) or not isinstance(limit,int) or not 1<=limit<=100:raise ValueError('history_discovery_limit')
        now=epoch(as_of_utc)
        if path.resolve().parent!=Path(directory).resolve():raise ValueError('history_index_path_outside_directory')
        for value in (feed_id,inventory_version_id,source_version_id):
            if value is not None and (not isinstance(value,str) or not HEX.fullmatch(value)):raise ValueError('history_discovery_identity')
        db=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True,timeout=10)
        db.execute('PRAGMA query_only=ON')
        if db.execute('SELECT version FROM history_schema').fetchall()!=[(VERSION,)]:raise ValueError('history_index_schema_unknown')
        sql='SELECT p.token,p.scene_id,p.receipt_id,p.json_sha,p.provider,p.instrument,p.timeframe,p.feed_id,p.asof,p.known,m.id,m.known FROM publications p JOIN publication_maps pm ON pm.publication_id=p.id JOIN inventories m ON m.id=pm.map_id WHERE p.provider=? AND p.instrument=? AND p.timeframe=? AND p.feed_id=? AND m.feed_id=? AND p.asof<=? AND p.known<=? AND (m.known IS NULL OR m.known<=?)'
        args=[provider,instrument,chart_timeframe,feed_id,feed_id,now,now,now]
        if inventory_version_id:sql+=' AND m.id=?';args.append(inventory_version_id)
        if source_version_id:sql+=' AND EXISTS(SELECT 1 FROM map_sources ms WHERE ms.map_id=m.id AND ms.source_id=?)';args.append(source_version_id)
        sql+=' ORDER BY p.asof,p.scene_id,m.id LIMIT ?';args.append(limit)
        rows=db.execute(sql,args).fetchall();candidates=[]
        for row in rows:
            token,sid,receipt,json_sha,_,_,_,_,asof,known,mid,mapknown=row
            raw=_artifact(directory,token,sid).read_bytes();p=prepare(raw,token,sid)
            if p is None or (p['producer_receipt_id'],p['publication_json_sha256'],epoch(p['scene_as_of_utc']),epoch(p['producer_known_at_utc']))!=(receipt,json_sha,asof,known):
                raise ValueError('history_cached_publication_mismatch')
            ref=reference(p,mid)
            if (epoch(ref['inventory_known_at_utc']) if ref['inventory_known_at_utc'] else None)!=mapknown:raise ValueError('history_cached_map_clock_mismatch')
            restored=restore(directory,ref,as_of_utc=as_of_utc,provider=provider,instrument=instrument,chart_timeframe=chart_timeframe,feed_id=feed_id)
            if restored['status']!='restored_original_observation':raise ValueError('history_discovery_original_rejected')
            if source_version_id and source_version_id not in restored['requested_map']['member_source_version_ids']:
                raise ValueError('history_cached_source_membership_mismatch')
            candidates.append(ref)
        result.update(status='verified_candidates',candidates=candidates,selection_required=len(candidates)>1,
            selected_reference=None,limit=limit,search_scope='indexed_exact_publications_only_not_complete_source_history')
    except (ValueError,TypeError,KeyError,OSError,sqlite3.Error,AttributeError) as error:
        result.update(status='rejected',reason=str(error))
    finally:
        if db is not None:db.close()
    return result


def load_original(directory,token,scene_id):
    """Read one sealed original for the main history consumer, without aliasing."""
    return _validated(_artifact(directory,token,scene_id).read_bytes(),scene_id)[0]
