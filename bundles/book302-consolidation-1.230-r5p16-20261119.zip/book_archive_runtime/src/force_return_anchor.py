"""Source-owned return-C candidates and their 1:1, not entry permission.

Radius-two is an explicit engineering observation, not author wave degree or
proof that the complete correction ended. A larger return extreme retires the
old current ruler; previous facts and target events are retained with clocks.
"""
from hashlib import sha256

from .force_strength_model import epoch,iso
from .build_archive_window_snapshot import TIMEFRAME_MINUTES
from .mt5_structure_logic import PARENTS

RADIUS=2


def ratio_zone(ratio):
    if .5<=ratio<=.618:return '50_61.8'
    if .77<=ratio<=.88:return '77_88'
    if .618<ratio<.77:return 'between_61.8_and_77'
    if .88<ratio<1:return 'between_88_and_source_origin'
    return 'shallower_than_50' if ratio<.5 else 'outside_ordinary_source'


def return_anchors(force,bars,as_of_utc,review_end_utc=None,parent=None,market=None):
    cutoff=epoch(as_of_utc);end=epoch(review_end_utc or as_of_utc);available=epoch(force['known_at_utc'])
    if end>cutoff:raise ValueError('Return review cannot exceed visible cutoff')
    a,b=force['points'];tf=force['timeframe'];seconds=TIMEFRAME_MINUTES[tf]*60
    sign=1 if b[1]>a[1] else -1;height=abs(b[1]-a[1]);kind='low' if sign>0 else 'high'
    market=market or {}
    base=dict(schema='force_own_return_anchor_v1',owner_id=force['id'],source_id=force['source_id'],timeframe=tf,
        provider=market.get('provider'),instrument=market.get('instrument'),
        source_points=force['points'],source_known_at_utc=force['known_at_utc'],as_of_utc=as_of_utc,
        review_end_utc=iso(end),historical_review=end<cutoff,known_at_utc=iso(min(end,cutoff)),
        status='observation',current_anchor=None,developing_return_extreme=None,anchors=[],
        parent_reference_comparison=None,full_return_completion='not_adjudicated',
        automatic_trade_permission=False,entry_permission=False,
        method=dict(radius=RADIUS,basis='engineering_local_pivot_not_author_degree',
            equal_extreme='latest_equal_touch_requires_two_strictly_smaller_return_extremes',
            source_terminal_bar='excluded_no_intrabar_order_inferred'))
    if available>end or not height:return dict(base,status='source_not_available')
    rows=sorted((r for r in bars if r['closed']<=end),key=lambda r:r['t'])
    if len({r['t'] for r in rows})!=len(rows):raise ValueError('Duplicate native candle')
    if any(r['closed']!=r['t']+seconds for r in rows):raise ValueError('Foreign timeframe candle')
    indexed={r['t']:r for r in rows}
    if (a[0] not in indexed or b[0] not in indexed or
        indexed[a[0]]['low' if sign>0 else 'high']!=a[1] or
        indexed[b[0]]['high' if sign>0 else 'low']!=b[1]):
        return dict(base,status='source_extrema_not_verified')
    post=[r for r in rows if r['t']>=b[0]+seconds]
    if not post:return base
    crossed=next((r for r in post if -sign*(r[kind]-a[1])>=0),None)
    extreme=None;record=b[1];candidates=[]
    for i,r in enumerate(rows):
        if r['t']<b[0]+seconds or -sign*(r[kind]-record)<0:continue
        record=r[kind];extreme=r
        if -sign*(record-b[1])<=0 or -sign*(record-a[1])>=0:continue
        # A point needs its own native neighbours, not child tips promoted to
        # this period. Equal right extremes delay confirmation to the last tip.
        if i<RADIUS or i+RADIUS>=len(rows):continue
        if not (all(-sign*(record-v[kind])>=0 for v in rows[i-RADIUS:i]) and
                all(-sign*(record-v[kind])>0 for v in rows[i+1:i+RADIUS+1])):continue
        known=max(available,rows[i+RADIUS]['closed']);target=record+b[1]-a[1]
        identifier=sha256(f"{force['id']}|own-return-C|{r['t']}|{record}|{known}".encode()).hexdigest()[:24]
        origin=dict(pivot_timestamp_utc=iso(r['t']),price=record,confirmed_at_utc=iso(known),
                    native_timeframe=tf,kind=kind)
        later=[v for v in post if v['t']>r['t']]
        refresh=next((v for v in later if -sign*(v[kind]-record)>=0),None)
        touch=next((v for v in later if sign*(v['high' if sign>0 else 'low']-target)>=0),None)
        events=[(v['closed'],k) for k,v in [('refresh',refresh),('target',touch),('source',crossed)] if v and v['t']>r['t']]
        first=min((v[0] for v in events),default=None);same=[k for t,k in events if t==first]
        state='candidate'
        if sign*(r['high' if sign>0 else 'low']-target)>=0:state='ambiguous_anchor_bar'
        elif len(same)>1:state='ambiguous_same_bar'
        elif same==['refresh']:state='superseded_by_larger_return' if -sign*(refresh[kind]-record)>0 else 'superseded_by_equal_return_retest'
        elif same==['source']:state='ordinary_source_crossed'
        elif same==['target']:state='target_already_observed_at_confirmation' if touch['closed']<=known else 'target_observed_after_confirmation'
        candidates.append(dict(anchor_id=identifier,owner_id=force['id'],source_id=force['source_id'],timeframe=tf,
            C=origin,known_at_utc=iso(known),retracement_ratio=abs(record-b[1])/height,
            retracement_zone=ratio_zone(abs(record-b[1])/height),
            target=target,target_formula='C+B-A',target_role='own_source_1_to_1_candidate_not_selected_entry_target',
            projection_state=state,larger_return_at_utc=iso(refresh['closed']) if refresh else None,
            target_observed_at_utc=iso(touch['closed']) if touch else None,
            state_known_at_utc=iso(max(known,first or known)),
            completion_status='local_pivot_only_full_return_not_adjudicated',automatic_trade_permission=False))
    if extreme:
        base['developing_return_extreme']=dict(pivot_timestamp_utc=iso(extreme['t']),price=extreme[kind],
            observed_at_utc=iso(extreme['closed']),retracement_ratio=abs(extreme[kind]-b[1])/height)
    latest=next((c for c in reversed(candidates) if extreme and epoch(c['C']['pivot_timestamp_utc'])==extreme['t']
                  and c['C']['price']==extreme[kind]),None)
    current=latest if latest and latest['projection_state']=='candidate' else None
    base.update(anchors=candidates,current_anchor=current,status='local_C_candidate' if current else
        'developing_return_extreme' if extreme else 'observation')
    if latest and not current:
        base['status']='projection_completed' if latest['projection_state'].startswith('target_') else 'projection_order_ambiguous'
    if crossed:base.update(status='ordinary_source_crossed_requires_separate_setup',current_anchor=None,
        source_origin_breach_at_utc=iso(crossed['closed']))
    # Parent sequence reference is a separately-owned observation, not a DOL
    # selected by proximity to our projection. Compare numbers without tolerance.
    if current and not crossed and parent and market.get('provider') and market.get('instrument'):
        ref=parent.get('reference_node')
        if (parent.get('owner_id')==force['id'] and parent.get('source_id')==force['source_id'] and
            parent.get('provider')==market['provider'] and parent.get('instrument')==market['instrument'] and
            parent.get('source_known_at_utc')==force['known_at_utc'] and
            parent.get('source_points')==force['points'] and parent.get('timeframe')==tf and
            parent.get('parent_timeframe')==PARENTS.get(tf) and epoch(parent['as_of_utc'])==end and ref and
            ref.get('kind')==('high' if sign>0 else 'low') and epoch(ref['known_at_utc'])<=end):
            base['parent_reference_comparison']=dict(parent_timeframe=parent['parent_timeframe'],reference=ref,
                parent_scope='confirmed_sequence_reference_not_protected_SNR_or_parent_DOL',
                own_anchor_id=current['anchor_id'],own_target=current['target'],
                absolute_distance=abs(current['target']-ref['price']),
                distance_source_span=abs(current['target']-ref['price'])/height,
                exact_price_match=current['target']==ref['price'],
                target_beyond_reference_in_source_direction=sign*(current['target']-ref['price'])>0,
                parent_transition_if_visited='review_parent_native_closes_acceptance_and_retest_not_child_target_hit',
                known_at_utc=iso(max(epoch(current['known_at_utc']),epoch(ref['known_at_utc']))),
                confluence_threshold=None,automatic_trade_permission=False)
    return base


def caption(result):
    c=result['current_anchor']
    if c:return f"本级C候选{c['C']['price']:.3f}({c['retracement_ratio']:.1%})→1:1 {c['target']:.3f}·回调结束未定"
    if result['status']=='ordinary_source_crossed_requires_separate_setup':return '原来源已越界·自身C量尺不续用'
    if result['status']=='projection_completed':return '自身1:1已见目标·不作当前新目标'
    if result['status']=='projection_order_ambiguous':return '自身C与目标顺序未知·不作当前确认'
    if result['developing_return_extreme']:return '自身回调C发展中·旧尺不作当前目标'
    return '自身回调C待形成'
