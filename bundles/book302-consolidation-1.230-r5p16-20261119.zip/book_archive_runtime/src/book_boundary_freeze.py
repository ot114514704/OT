"""Chapter5 pre-break boundary provenance, separate from author adjudication."""
from math import isfinite
from .book_first_response_leg import clock,close_time


def ruler_identity(rows,line,timeframe):
    try:
        i,j=line['start_index'],line['end_index']
        if any(isinstance(k,bool) or not isinstance(k,int) for k in (i,j)) or not 0<=i<j<len(rows):return None
        identity=dict(timeframe=timeframe,direction=line['direction'],anchors=[
            [rows[i]['timestamp_utc'],line['start_price']],[rows[j]['timestamp_utc'],line['end_price']]])
        # Legacy sources retain their exact key. Explicit owned contexts add
        # a semantic namespace while the same native contacts remain reusable
        # as geometry. Assessment/observation clocks never split this key.
        from .book_owned_scope import scope_context_identity
        context=scope_context_identity(rows,line)
        if context is not None:identity['scope_context']=context
        return identity
    except (KeyError,TypeError,ValueError,IndexError):return None


def validate_boundary_freeze(rows,timeframe,cutoff,line,change,first_break):
    base=dict(status='unknown',author_membership_established=False,
        policy='native_A_and_source_known_before_first_boundary_bar_open')
    def fail(reason):return dict(base,reason=reason)
    try:
        ai=change['boundary_a_index'];price=change['boundary_a_price']
        if (isinstance(ai,bool) or not isinstance(ai,int) or not 0<=ai<first_break
                or isinstance(price,bool) or not isfinite(float(price)) or price<=0):return fail('A_point_unbound')
        if change.get('timeframe')!=timeframe:return fail('A_timeframe_mismatch')
        field='high' if line['direction']=='down' else 'low'
        if change['boundary_a_utc']!=rows[ai]['timestamp_utc'] or price!=float(rows[ai][field]):
            return fail('A_point_not_native')
        expected=ruler_identity(rows,line,timeframe)
        if expected is None or change.get('boundary_ruler_identity')!=expected:
            return fail('A_parent_ruler_mismatch_or_missing')
        if ai<line['start_index']:return fail('A_precedes_parent_native_interval')
        if change.get('boundary_source_wave_id')!=line.get('wave_id'):
            return fail('A_parent_wave_mismatch')
        freeze=rows[first_break]['timestamp_utc'];known=change['boundary_a_known_at_utc']
        if clock(change['boundary_a_freeze_cutoff_utc'])!=clock(freeze):return fail('A_freeze_boundary_mismatch')
        if not clock(close_time(rows[ai],timeframe))<=clock(known)<=clock(freeze):
            return fail('A_not_known_before_first_boundary')
        if not clock(known)<=clock(change['known_at_utc'])<=clock(cutoff):return fail('A_fact_clock_unbound')
        return dict(base,status='frozen_before_first_boundary',reason=None,
            point=dict(index=ai,utc=rows[ai]['timestamp_utc'],price=price),
            source_known_at_utc=known,freeze_cutoff_utc=freeze,ruler_identity=expected,
            source_wave_id=line.get('wave_id'))
    except (KeyError,TypeError,ValueError,IndexError):return fail('A_freeze_evidence_missing_or_invalid')
