"""Compact chapter-9 facts for MT5; no recommendations from missing evidence."""
from math import isfinite
from datetime import datetime
from .book_execution_evidence import validate_execution_evidence,validate_request_evidence

DYNAMIC_NAMES={'holding_outside':'线外保持','returned_inside':'回到线内',
    'on_boundary':'触线','reclaimed_after_return':'重新收回','unknown':'待核'}


def execution_plan(book, timeframe, cutoff):
    """Actual arbitrated source, independent of the chart-selected plan."""
    decision=book.get('realtime_entry_decision') or {}
    base=dict(schema='book_paper_candidate_plan_v1',state='unavailable',
        timeframe=timeframe,as_of_utc=cutoff,automatic_trade_permission=False)
    if decision.get('status')!='entry_candidate':return dict(base,reason='no_current_candidate')
    reason=validate_execution_evidence(decision)
    if reason:return dict(base,reason=reason)
    if decision.get('timeframe')!=timeframe or decision.get('as_of_utc')!=cutoff:
        return dict(base,reason='candidate_clock_or_timeframe_mismatch')
    evidence=decision['execution_evidence'];signal=decision['signal']
    result=dict(base,state='bound_paper_candidate',reason=None,evidence_id=evidence['evidence_id'],
        phase_id=signal['phase_id'],source_id=signal['source_id'],
        boundary_pair_id=signal['boundary_pair_id'],stop=signal['stop'],target=signal['target'],
        signal_close=signal['price'],entry=None,volume=None,risk_cash=None,net_rr=None,
        boundary_confirmation_mode=decision.get('boundary_confirmation_mode','initial_follow'),
        current_boundary_observations=decision.get('current_boundary_observations') or {},
        position_scorecard=decision.get('position_scorecard') or {},
        composite_assessment=decision.get('composite_assessment') or {},quote_composite=None,
        contextual_score_gate=decision.get('contextual_score_gate') or {},
        score_pair=decision['score_pair'],quote_state='waiting_quote_and_risk')
    execution=book.get('paper_execution') or {};request=execution.get('request') or {}
    try:
        if (execution.get('mode')=='paper' and execution.get('status')=='prepared' and
                request.get('execution_evidence')==evidence and
                validate_request_evidence(request) is None and
                request.get('signal_id')==signal['id'] and request.get('entry_cycle_id')==signal['entry_cycle_id'] and
                request.get('phase_id')==signal['phase_id'] and request.get('stop')==signal['stop'] and
                request.get('target')==signal['target'] and
                request.get('decision_as_of_utc')==cutoff and
                datetime.fromisoformat(cutoff.replace('Z','+00:00'))<=
                datetime.fromisoformat(request['quote_timestamp_utc'].replace('Z','+00:00'))<=
                datetime.fromisoformat(execution['as_of_utc'].replace('Z','+00:00'))<=
                datetime.fromisoformat(cutoff.replace('Z','+00:00'))):
            values={k:request[k] for k in ('entry','volume','risk_cash','net_rr')}
            if all(not isinstance(v,bool) and isfinite(v) and v>0 for v in values.values()):
                result.update(values,quote_state=execution.get('ledger_result') or 'prepared_paper_intent')
                result['quote_composite']=execution.get('quote_composite')
    except (KeyError,ValueError,TypeError):pass
    return result


def chapter7_details(plan,timeframe,cutoff):
    fact=plan.get('third_wave_targets') or {}
    if fact.get('status')!='theoretical_candidates' or fact.get('timeframe')!=timeframe:return ''
    try:
        if datetime.fromisoformat(fact['known_at_utc'].replace('Z','+00:00'))>datetime.fromisoformat(cutoff.replace('Z','+00:00')):return ''
    except (KeyError,TypeError,ValueError):return ''
    details=[]
    for item in fact.get('candidates',[]):
        space=item.get('space') or {}
        try:
            if (space.get('status')!='descriptive_price_space' or space.get('timeframe')!=timeframe
                    or datetime.fromisoformat(space['known_at_utc'].replace('Z','+00:00'))>datetime.fromisoformat(cutoff.replace('Z','+00:00'))):continue
            if (item['source_id']!=fact['source_id'] or item['owner_id']!=fact['owner_id']
                    or space.get('source_id')!=fact['source_id'] or space.get('owner_id')!=fact['owner_id']
                    or space.get('target_price')!=item['target_price']):continue
            details.append(f"{item['ratio']:g}倍={item['target_price']:.3f} {space['reference_status']}")
        except (KeyError,TypeError,ValueError):continue
    if not details:return ''
    terminal_text=''
    target=plan.get('first_wave_theoretical_target') or {}
    binding=target.get('correction_terminal_binding') or {}
    try:
        if (target.get('source_id')==fact['source_id'] and target.get('owner_id')==fact['owner_id']
                and binding.get('status')=='same_named_terminal'
                and datetime.fromisoformat(binding['known_at_utc'].replace('Z','+00:00'))<=datetime.fromisoformat(cutoff.replace('Z','+00:00'))):
            terminal=binding['terminal'];extreme=binding.get('adverse_extreme') or {}
            if isfinite(terminal['price']):
                terminal_text=f"; 调整末端候选={terminal['price']:.3f}@{terminal['utc']}"
                if isfinite(extreme.get('price',float('nan'))):
                    terminal_text+=f"; 区间最深回撤={extreme['price']:.3f}@{extreme.get('utc','?')}"
    except (KeyError,TypeError,ValueError):pass
    return ('; '.join(details)+f"; 来源={fact['source_id']}; owner={fact['owner_id']}; "
            f"来源可知={fact['known_at_utc']}; 本次截止={cutoff}"+terminal_text+"; 作者归属待核")


def chapter7_caption(plan,timeframe,cutoff):
    target=plan.get('first_wave_theoretical_target') or {}
    if (target.get('status')=='unknown' and target.get('reason') in ('correction_terminal_unresolved','correction_terminal_binding_mismatch')
            and target.get('timeframe')==timeframe):
        try:
            if datetime.fromisoformat(target['known_at_utc'].replace('Z','+00:00'))<=datetime.fromisoformat(cutoff.replace('Z','+00:00')):
                return '第二浪终点待核'
        except (KeyError,TypeError,ValueError):pass
    alternatives=plan.get('third_wave_targets') or {}
    if alternatives.get('status')=='theoretical_candidates' and alternatives.get('timeframe')==timeframe:
        labels=[]
        for candidate in alternatives.get('candidates',[]):
            space=candidate.get('space') or {}
            try:
                valid=(space.get('status')=='descriptive_price_space' and space.get('timeframe')==timeframe
                    and datetime.fromisoformat(space['known_at_utc'].replace('Z','+00:00'))<=datetime.fromisoformat(cutoff.replace('Z','+00:00')))
            except (KeyError,TypeError,ValueError):valid=False
            if not valid:continue
            state={'target_already_reached':'已达','target_touch_order_unknown':'触达待核',
                'waiting_A_cross':'待越A','invalid_current_price_geometry':'无空间',
                'historical_source_reference':'历史','author_source_and_entry_unverified':'待核'}.get(space.get('reference_status'),'未知')
            labels.append(f'{candidate["ratio"]:g}倍{state}')
        if labels:return '候选 '+ ' / '.join(labels)
    fact=plan.get('first_wave_target_space') or {}
    if fact.get('status')!='descriptive_price_space' or fact.get('timeframe')!=timeframe:return ''
    try:
        if datetime.fromisoformat(fact['known_at_utc'].replace('Z','+00:00'))>datetime.fromisoformat(cutoff.replace('Z','+00:00')):return ''
    except (KeyError,TypeError,ValueError):return ''
    return {'target_already_reached':'候选量尺已达',
            'target_touch_order_unknown':'量尺触达顺序待核',
            'waiting_A_cross':'候选量尺待越A',
            'invalid_current_price_geometry':'候选空间失效',
            'historical_source_reference':'量尺仅历史重建',
            'author_source_and_entry_unverified':'量尺作者归属待核'}.get(fact.get('reference_status'),'')


def plan_summary(scene):
    tf=scene.get('timeframe','?'); cutoff=scene.get('cutoff_utc','')
    book=scene.get('book_logic') or {}
    aligned=book.get('timeframe')==tf and book.get('as_of_utc')==cutoff
    plan=book.get('trade_plan_facts') or {} if aligned else {}
    setup=book.get('setup_qualification') or {} if aligned else {}
    setup_aligned=(setup.get('timeframe')==tf and setup.get('as_of_utc')==cutoff)
    try: setup_aligned=setup_aligned and datetime.fromisoformat(setup['known_at_utc'].replace('Z','+00:00'))<=datetime.fromisoformat(cutoff.replace('Z','+00:00'))
    except (KeyError,TypeError,ValueError):setup_aligned=False
    components=plan.get('components') or {}
    def available(name):
        item=components.get(name) or {}
        try:
            value=float(item.get('price'))
            known=plan.get('known_at_utc')
            if known and datetime.fromisoformat(known.replace('Z','+00:00'))>datetime.fromisoformat(cutoff.replace('Z','+00:00')):return None
            return value if item.get('status')=='observed_candidate' and isfinite(value) and value>0 and not isinstance(item.get('price'),bool) else None
        except (TypeError,ValueError):return None
    stop=available('stop');entry=available('entry') if stop is not None else None
    target=available('target') if entry is not None else None
    setup_direction=(book.get('first_closed_break') or {}).get('break_side') if aligned else None
    invalidated=setup_aligned and setup.get('status')=='stop_breached'
    inconsistent=entry is not None and (setup_direction not in ('up','down') or
        (setup_direction=='up' and stop>=entry) or (setup_direction=='down' and stop<=entry))
    if inconsistent:entry=None;target=None
    if invalidated:stop=None;entry=None;target=None
    # Older cached scenes cannot bypass the new chapter-5 setup evaluation.
    if not setup_aligned or not setup.get('both_boundaries_broken'):
        entry=None;target=None
    prices=dict(stop=stop,entry=entry,target=target)
    missing=[name for name,value in prices.items() if value is None]
    next_required=missing[0] if missing else 'risk_review'
    direction=(book.get('trend') or {}).get('direction') if aligned else None
    background={'up':'背景上升','down':'背景下降'}.get(direction,'背景待确认')
    trigger='触发方向待确认'
    action=(setup.get('action') if setup_aligned else '等待本周期双线与 B 点核对')
    condition=setup.get('conditions',{}) if setup_aligned else {}
    if setup_aligned:
        trigger=('双线已破' if setup.get('both_boundaries_broken') else
                 '仅趋势线突破' if condition.get('trendline_broken') else
                 '仅拐点线突破' if condition.get('turning_line_broken') else '双线待突破')
        if setup.get('both_boundaries_broken') and setup.get('direction_candidate') in ('up','down'):
            trigger='双线向上破' if setup['direction_candidate']=='up' else '双线向下破'
    stage=('B 已越界' if invalidated else 'A 冻结依据待核' if setup.get('status')=='boundary_a_unknown' else '候选 A 待核' if setup.get('status')=='boundary_a_unverified' else 'A 已越界' if condition.get('boundary_A_broken') else
           'A 待越界' if setup.get('both_boundaries_broken') else '方向待确认')
    if inconsistent:action='核对入场与止损方向'
    display=lambda v:'—' if v is None else f'{v:.3f}'
    target_note=chapter7_caption(plan,tf,cutoff) if not invalidated else ''
    target_details=chapter7_details(plan,tf,cutoff) if not invalidated else ''
    target_text=display(target)+(f'/{target_note}' if target_note else '')
    # The integrated packet is the single as-of join of parent context,
    # geometry, force, three-push and owned 1:1 evidence.  Keep it compact on
    # the four-line card; the full packet remains in scene JSON/tooltips.
    integrated=scene.get('integrated_market_logic') or {}
    phase=integrated.get('phase','unknown')
    fused_score=integrated.get('score')
    coverage=integrated.get('coverage')
    score_text='?' if fused_score is None else f'{float(fused_score):.1f}'
    coverage_text='?' if coverage is None else f'{float(coverage):.0%}'
    parent=integrated.get('direct_parent') or {}
    parent_tf=parent.get('direct_parent') or '父级?'
    alignment=parent.get('alignment','unknown')
    routes=integrated.get('routes') or []
    route_a=any(r.get('route_A')=='candidate' for r in routes)
    route_b=any(r.get('route_B')=='candidate' for r in routes)
    route_text=f'A:{"候选" if route_a else "等待"} B:{"候选" if route_b else "等待"}'
    blockers=integrated.get('blockers') or []
    evidence=(f"父级{parent_tf}/{alignment} · 几何{len(integrated.get('geometry_candidates') or [])}"
              f" 力度{len(integrated.get('force_candidates') or [])}"
              f" 三推{(integrated.get('measurements') or {}).get('linked_three_push_count',0)}"
              f" 1:1{(integrated.get('measurements') or {}).get('valid_C_count',0)}")
    weekly=integrated.get('weekly') or {}
    weekly_events=weekly.get('events') or []
    weekly_text=(f"weekly_status={weekly.get('status','unknown')} "
                  f"weekly_events={len(weekly_events)} "
                  f"weekly_macro={sum(e.get('priority')=='macro_window_candidate' for e in weekly_events)}")
    ladder=integrated.get('period_ladder') or {}
    direction_text=','.join(f"{row.get('timeframe')}:{row.get('direction') or 'unknown'}"
                            for row in ladder.get('periods') or [])
    breakout=book.get('boundary_breakout_assessment') or {} if aligned else {}
    entry_decision=book.get('realtime_entry_decision') or {} if aligned else {}
    author=entry_decision.get('author_review_context') or book.get('author_review_context') or {} if aligned else {}
    author_text=''
    if author.get('as_of_utc')==cutoff and author.get('timeframe')==tf:
        r01=(author.get('r01_same_degree') or {}).get('state','unknown')
        r01={'native_ruler_ready_for_author_review':'端点时钟已核/作者浪级待核',
             'review_not_bound_to_current_ruler':'旧复核未绑定当前量尺'}.get(r01,r01)
        r14=author.get('r14_prior_B_A') or {}
        freeze=(author.get('boundary_A_freeze') or {}).get('status','unknown')
        author_text=(f" · R01={r01} R14={r14.get('reason') or r14.get('status','unknown')}"
                     f" A_freeze={freeze} 作者归属待核")
        from .book_author_review import author_review_gate
        review_gate=author_review_gate(author)
        if review_gate['r14_target_state']=='source_invalidated' or entry_decision.get('status')=='invalidated':
            author_text+=' R14_target_gate=原来源已失效'
        elif review_gate['r14_review_required']:
            author_text+=f" R14_target_gate=等待作者回溯[{review_gate['r14_state']}]"
    boundary_text=''
    turning_construction={}
    if (breakout.get('as_of_utc')==cutoff and breakout.get('phase_id')
            and breakout.get('phase_id')==entry_decision.get('phase_id')):
        turning_construction=((breakout.get('boundaries') or {}).get('turning') or {}).get('construction_audit') or {}
        counts=turning_construction.get('counts') or {}
        if turning_construction.get('construction_state')=='confirmed_D_shifted_boundary_invalid':
            boundary_text+=' · D已确认，平移形成期穿价'
            failures=[r.get('shift_failure') for r in turning_construction.get('rejected_candidates',[])
                      if r.get('reason')=='shifted_D_line_crosses_C_E_leg' and r.get('shift_failure')]
            if failures:
                first=failures[0].get('first') or {};worst=failures[0].get('worst') or {}
                boundary_text+=f" 首穿K{first.get('index','?')} 最差净空{worst.get('signed_clearance',0):.4f}"
        for reason,label in (
                ('C_candle_opposite_extreme_order_unknown','C同根高低顺序待核'),
                ('D_local_extreme_unconfirmed','D局部极值未确认'),
                ('D_confirmation_not_inside_C_E','D确认未落在C-E内'),
                ('shifted_D_line_crosses_C_E_leg','D平移线穿越区间'),
                ('earlier_parent_wave_outside_late_C_extension','晚C只覆盖内部波段'),
                ('earlier_parent_wave_outside_C_E_extension','C-E未包住所属整段外沿')):
            if counts.get(reason):
                boundary_text+=f' · 拐点构造={label}';break
        turning_reading=(breakout.get('boundaries') or {}).get('turning') or {}
        consumer_proof=turning_reading.get('rejected_native_construction_validation') or turning_reading.get('native_construction_validation') or {}
        consumer_label={'D_not_C_E_adjustment_extreme':'D不是本段C-E调整极值',
                        'earlier_parent_wave_outside_C_E_extension':'C-E穿过所属波段早期K线',
                        'CDE_parent_wave_start_mismatch':'C-E构造所属波段起点不一致',
                        'C_E_extension_crosses_or_touches_native_bar':'C-E外延线穿价',
                        'CDE_extension_not_advancing_in_parent_direction':'C-E未沿原段推进'}.get(consumer_proof.get('reason'))
        if consumer_label:boundary_text+=f' · 拐点消费校验={consumer_label}'
    composite=entry_decision.get('composite_assessment') or {}
    if composite.get('as_of_utc')==cutoff and composite.get('timeframe')==tf:
        v=composite.get('active_score');label='待核' if v is None else f'{v:.1f}'
        boundary_text+=f" · 阶段复合={label}/{composite.get('active_stage','unknown')}（非概率）"
        context_gate=entry_decision.get('contextual_score_gate') or {}
        if context_gate.get('state')!='not_requested' and context_gate:
            context=context_gate.get('reading') or {};score=context.get('score')
            value='待核' if score is None else f'{score:.1f}'
            state={'satisfied':'通过','wait':'等待','invalid_policy':'配置无效'}.get(context_gate.get('state'),'待核')
            boundary_text+=f' · 上下文门={state}/{value}（非概率）'
            missing=context.get('missing') or []
            if missing:
                names={'one_to_one':'同源1:1结构','one_to_one_delivery':'局部1:1推进',
                       'native_scope_bottleneck':'父级归属/力度'}
                boundary_text+=' 缺='+','.join(names.get(n,n) for n in missing)
    position_scores=entry_decision.get('position_scorecard') or {}
    native_membership_observation={}
    native_one=book.get('one_to_one_native_observation') or {}
    if native_one.get('as_of_utc')==cutoff and native_one.get('timeframe')==tf:
        boundary_text+=f" · 原生1:1已观察源/版本={native_one.get('source_count',0)}/{native_one.get('observed_projection_count',0)}"
    if position_scores.get('as_of_utc')==cutoff and position_scores.get('timeframe')==tf:
        f=position_scores.get('factors') or {};coverage=position_scores.get('coverage') or {}
        def display_factor(key):
            v=(f.get(key) or {}).get('score');return '?' if v is None else f'{v:.0f}'
        boundary_text+=(' · 位置分 动能/回调/空间='+ '/'.join(display_factor(k) for k in
            ('directional_efficiency_8','pullback_zone','gross_target_space'))+
            f" 覆盖={coverage.get('measured',0)}/{coverage.get('total',0)} 融合待校准")
        one=f.get('one_to_one') or {}
        if one.get('state')=='measured':
            boundary_text+=f" · 同源1:1接纳={display_factor('one_to_one')}（非目标概率）"
        scope=position_scores.get('native_wave_process') or {}
        if scope.get('source_scope_id'):
            relation={'internal_forward_stage':'内部同向','internal_return_stage':'内部回调',
                      'post_extreme_return_candidate':'极值后调整'}.get(scope.get('parent_relation'),'归属待核')
            boundary_text+=(' · 波段自身/外层力度='+ '/'.join(display_factor(k) for k in
                ('native_source_wave_force','native_parent_wave_force'))+' '+relation+
                ('（历史已结束）' if scope.get('source_state')=='origin_broken' else '（形成中假设）'))
            if scope.get('range_frozen_before_first_break'):
                boundary_text+=' 评分沿用突破前冻结归属'
            queue=scene.get('book_event_queue') or {}
            observed=queue.get('native_wave_observations') or {}
            if queue.get('as_of_utc')==cutoff and observed.get('as_of_utc')==cutoff:
                native_membership_observation=next((r for r in observed.get('observations') or []
                    if r.get('scope_id')==scope['source_scope_id']),{})
                if native_membership_observation:
                    boundary_text+=f" 归属链变更={native_membership_observation.get('membership_transition_count',0)}"
        local=f.get('one_to_one_delivery') or {}
        if local.get('state')=='measured':
            boundary_text+=f" · 局部1:1运行={display_factor('one_to_one_delivery')}（与大结构接纳分开）"
    own_force=entry_decision.get('breakout_confluence') or {}
    if own_force.get('schema')=='book_owned_force_confluence_v1' and own_force.get('as_of_utc')==cutoff:
        force_value=own_force.get('force_score')
        force_label='?' if force_value is None else f'{force_value:.2f}'
        boundary_text+=f" · 本源力度={force_label}/{own_force.get('state','unknown')}"
    if breakout.get('as_of_utc')==cutoff:
        readings=breakout.get('boundaries') or {}
        boundary_text+=' · 双线力度 '+ '/'.join('?' if (readings.get(k) or {}).get('breakout_score') is None
            else f"{readings[k]['breakout_score']:.0f}" for k in ('outer','turning'))
        boundary_text+=' · entry_state='+entry_decision.get('status','unknown')
        direct_contract=entry_decision.get('direct_route_contract') or {}
        if direct_contract:
            direct_label={'research_candidate_ready':'已绑定·研究候选','wait_direct_route_evidence':'等待证据'}.get(
                direct_contract.get('state'),'待核')
            boundary_text+=f' · 直入研究={direct_label}（无入场许可）'
        boundary_text+=' · 边界动态='+ '/'.join(DYNAMIC_NAMES.get(
            ((readings.get(k) or {}).get('dynamic_observation') or {}).get('state','unknown'),'待核')
            for k in ('outer','turning'))
    watchlist=book.get('entry_watchlist') or {} if aligned else {}
    if watchlist.get('as_of_utc')==cutoff:
        observations=watchlist.get('observations') or []
        count=sum(o.get('status')!='retired' for o in observations)
        ready=sum(bool(o.get('decision',{}).get('paper_candidate')) for o in observations)
        boundary_text+=f' · 独立来源{watchlist.get("source_count",0)}/观察{count}/候选{ready}'
        retained_count=sum(o.get('status')=='observing' and not o.get('current_selected') for o in observations)
        if retained_count:boundary_text+=f' · 延续观察{retained_count}'
        if entry_decision.get('signal'):
            boundary_text+=' · entry_phase='+entry_decision['signal']['phase_id']
        if not breakout.get('phase_id'):
            boundary_text+=' · entry_state='+entry_decision.get('status','unknown')
    execution=book.get('paper_execution') or {} if aligned else {}
    try:
        if (execution.get('mode')=='paper' and execution.get('as_of_utc')
                and datetime.fromisoformat(execution['as_of_utc'].replace('Z','+00:00'))<=datetime.fromisoformat(cutoff.replace('Z','+00:00'))):
            boundary_text+=' · 模拟执行='+execution.get('status','unknown')
            if execution.get('reason'):boundary_text+='/'+execution['reason']
    except (TypeError,ValueError):pass
    management=book.get('paper_position_management') or {} if aligned else {}
    progressive=book.get('progressive_period_context') or {} if aligned else {}
    progressive_text=''
    if progressive.get('as_of_utc')==cutoff and progressive.get('entry_timeframe')==tf:
        progressive_text=(f" · 渐进管理={'→'.join(progressive.get('chain_timeframes') or [])} "
                          f"{progressive.get('management_state','unknown')}"
                          f"/{progressive.get('management_action','unknown')}")
    else:progressive={}
    candidate_plan=execution_plan(book,tf,cutoff) if aligned else dict(state='unavailable')
    candidate_text=''
    if candidate_plan['state']=='bound_paper_candidate':
        p=candidate_plan
        candidate_text=(f" · 模拟来源B={p['stop']:.3f} 目标={p['target']:.3f}"
            f" 报价入场={display(p['entry'])} {p['quote_state']} source={p['source_id']}")
        if p['volume'] is not None:
            candidate_text+=f" 手数={p['volume']:g} 风险={p['risk_cash']:.2f} 净RR={p['net_rr']:.2f}"
        pairs=p['score_pair']
        candidate_text+=' 源双线='+ '/'.join(f"{pairs[k]['breakout']:.0f}" for k in ('outer','turning'))
        candidate_text+=' 源当前='+ '/'.join(DYNAMIC_NAMES.get(
            (p['current_boundary_observations'].get(k) or {}).get('state'),'待核') for k in ('outer','turning'))
    position_text=''
    if management.get('mode')=='paper' and management.get('as_of_utc')==cutoff:
        positions=management.get('positions') or []
        # Each position keeps its OWN phase. The current chart's selected
        # B/phase cannot relabel an older open position's adopted protection.
        active=[p for p in positions if p.get('status')=='open']
        if management.get('status')=='unknown_ledger_ahead_of_requested_clock':
            position_text=' · 模拟持仓时间待核'
        elif active:
            position_text=' · 模拟持仓 '+ '; '.join(
                f"{p['side']} B={p['original_B']:.3f} 当前{p['adopted_role']}={p['current_stop']:.3f} "
                f"待报价={p.get('pending_role') or '无'} 管理={p.get('management_timeframe') or tf} "
                f"目标={p.get('current_target',p.get('target'))} source={p.get('source_key')}" for p in active)
        elif positions:
            last=positions[-1]
            position_text=f" · 模拟已平 {last.get('exit_reason')}={last.get('exit_price')} source={last.get('source_key')}"
    gd=book.get('gobi_digger_review') or {}
    gd_text=''
    if gd.get('status')=='task_measurements_evaluated' and gd.get('as_of_utc')==cutoff and gd.get('timeframe')==tf:
        states=gd.get('state_counts') or {}
        gd_text=(' · GD 待复核='+str(len(gd.get('review_queue',[])))+
            ' / C源待补='+str(states.get('wait_native_anchor',0))+
            ' / 冲突='+str(states.get('review_conflicting_geometry',0)))
    return dict(status='incomplete' if missing else 'review_required',next_required=next_required,
                prices=prices,source_rule_pages=[103,104,109,115,120,278,279,280],trade_permission=False,
                setup_status=setup.get('status') if setup_aligned else 'unknown',
                price_scope='chart_selected_source',paper_candidate_plan=candidate_plan,
                position_scorecard=position_scores,turning_construction_audit=turning_construction,
                native_scope_membership_observation=native_membership_observation,
                progressive_period_context=progressive,
                composite_assessment=composite,composite_chain=(book.get('composite_chain') or {})
                    if aligned and (book.get('composite_chain') or {}).get('as_of_utc')==cutoff else {},
                conditions=condition,action=action,chapter7_observation=target_note,gobi_digger_review=gd,
                lines=[f"{tf} {background} · {cutoff[5:16].replace('T',' ')} UTC · {weekly_text}",
                       f"{trigger} · {stage} · 融合{phase} {score_text}/100 覆盖{coverage_text}"+boundary_text,
                       f"主图B {display(stop)} | 入场 {display(entry)} | 目标 {target_text} · {route_text}"+(f" · 量尺详情={target_details}" if target_details else '')+candidate_text,
                       f"{action} · {evidence} · ladder={direction_text}" + (f" · 阻断{len(blockers)}" if blockers else "")+author_text+position_text+progressive_text+gd_text])


def plan_packet(scene, token):
    clean=lambda value:str(value).replace('\t',' ').replace('\r',' ').replace('\n',' ')
    lines=['\t'.join(('M1BOOKPLAN','1',token,scene['timeframe'],scene.get('scene_id','')))]
    summary=plan_summary(scene)['lines']
    parent=(scene.get('realtime_display') or {}).get('Book_parent_preview')
    if parent is not None:
        # Parent's nominal horizon is explicitly provisional; keep the
        # primary plan's real confirmed conditions and prices unchanged.
        label=str(parent.get('parent_timeframe','?'))
        if parent.get('state')=='provisional_native_parent_Book_scenario':
            parent_lines=plan_summary(parent['scene'])['lines']
            summary=list(summary)
            summary[0]+=' · 父'+label+'未收盘独立计算'
            summary[-1]+=' · 父周期候选：'+parent_lines[1]
        else:
            summary=list(summary);summary[0]+=' · 父'+label+'原生历史不足'
    if scene.get('book_presentation_scope'):
        from .book_display_scope import book_plan_lines
        summary=book_plan_lines(summary)
    lines.extend(clean(line) for line in summary)
    lines.append('END\t'+token)
    return ('\n'.join(lines)+'\n').encode('utf-8')
