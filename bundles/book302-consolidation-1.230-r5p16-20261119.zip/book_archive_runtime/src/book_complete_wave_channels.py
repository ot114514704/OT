"""Whole native-wave display, downstream of (never input to) Book decisions.

PDF64/65: the outer ruler uses broad supporting native points BEFORE
the opposite extreme and follows its owned movement's axis. The first
price extreme is not a mandatory anchor for every boundary. PDF81/83 C-E/D remains a
separate construction, never renamed from the parallel channel.

Wave scope is the causally confirmed Arrow3 inventory, an explicit engineering
scope, not adjudication of the author's degree. Internal source objects and
all decision evidence survive in the audit; only their main-chart display
is replaced, after the complete wave becomes known.
"""
from .book_evidence_copy import copy_evidence as deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import math
import statistics
import json

RULE='completed_native_wave_channel_v2'

def owned_axis_measurement(rows, slope, *, owner_id=None, known_at=None):
    """Measure a fixed native scope independently of the candidate's rails.

    Both estimates use body midpoints and native row ordinals. The scale is
    the median positive candle range, never a candidate-dependent envelope.
    This is descriptive geometry, not an author threshold or a 0..100 score.
    """
    base=dict(schema='book_independent_owned_axis_v1',owner_id=owner_id,
        axis_method='split_half_native_body_medians_with_independent_ols',
        x_coordinate='observed_native_bar_ordinal',candidate_slope_per_native_bar=slope,
        axis_as_of=known_at,author_calibrated=False,automatic_trade_permission=False,
        score=None,score_is_probability=False)
    if len(rows)<2:return dict(base,alignment_quality_state='unknown_insufficient_scope')
    values=[];ranges=[];source=[]
    for row in rows:
        o,h,l,c=[float(row[k]) for k in ('open','high','low','close')]
        if not all(math.isfinite(v) for v in (o,h,l,c)) or not l<=min(o,c)<=max(o,c)<=h:
            return dict(base,alignment_quality_state='unknown_invalid_native_ohlc')
        values.append((o+c)/2);ranges.append(h-l)
        source.append([row['timestamp_utc'],o,h,l,c,row.get('provider'),row.get('symbol'),row.get('timeframe')])
    times=[epoch(r['timestamp_utc']) for r in rows]
    if any(b<=a for a,b in zip(times,times[1:])):
        return dict(base,alignment_quality_state='unknown_native_order')
    from .pdf_trendline_block import _native_axis_slope
    axis=_native_axis_slope(rows);n=len(rows);xm=(n-1)/2;ym=statistics.fmean(values)
    ols=sum((i-xm)*(y-ym) for i,y in enumerate(values))/sum((i-xm)**2 for i in range(n))
    positive=[v for v in ranges if v>0];scale=statistics.median(positive) if positive else None
    reference=dict(scope_source_sha256=sha256(json.dumps(source,separators=(',',':'),allow_nan=False).encode()).hexdigest(),
        owner_id=owner_id,axis_method=base['axis_method'],x_coordinate=base['x_coordinate'],known_at=known_at)
    base.update(axis_scope=dict(start_utc=rows[0]['timestamp_utc'],end_utc=rows[-1]['timestamp_utc']),
        axis_scope_identity=sha256(json.dumps(reference,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
        scope_source_sha256=reference['scope_source_sha256'],axis_slope_per_native_bar=axis,
        ols_slope_per_native_bar=ols,estimator_difference_per_native_bar=abs(ols-axis),
        independent_price_scale=scale,normalization='median_positive_native_candle_range',native_bar_count=n)
    if not scale:return dict(base,alignment_quality_state='unknown_zero_native_price_scale',alignment_measure=None)
    flat=abs(axis)*(n-1)<=math.ulp(scale)*16
    return dict(base,alignment_measure=abs(slope-axis)*(n-1)/scale,
        ols_alignment_measure=abs(slope-ols)*(n-1)/scale,
        relative_slope_difference=None if flat else abs(slope-axis)/abs(axis),
        axis_flat_at_numeric_resolution=flat,
        alignment_quality_state=('flat_axis_descriptive_only' if flat else
            'estimator_direction_disagreement' if axis*ols<0 else 'independent_engineering_reading_not_author_threshold'))

def epoch(t):
    return datetime.fromisoformat(t.replace('Z','+00:00')).timestamp()

def iso(t):
    return datetime.fromtimestamp(t,timezone.utc).isoformat().replace('+00:00','Z')

def owned_outer_pair(bars, start, terminal, upward):
    """Choose a full-scope supporting edge, then rank axis fit and breadth.

    Hull points are geometric contacts, not author-confirmed phase pivots.
    No arbitrary angle threshold or rotated prices; no later bars in ranking.
    """
    from .pdf_trendline_block import _outer_hull_vertices, _native_axis_slope
    rows=bars[start:terminal+1];span=terminal-start;sign=1 if upward else -1
    side='low' if upward else 'high';values=[float(r[side]) for r in rows]
    hull=_outer_hull_vertices(values,not upward)
    axis=_native_axis_slope(rows)
    measurement=owned_axis_measurement(rows,axis)
    typical=measurement.get('independent_price_scale')
    if typical is None:return None,measurement
    scale=typical/max(1,span)
    candidates=[];rejected=[]
    for a,b in zip(hull,hull[1:]):
        slope=(values[b]-values[a])/(b-a)
        gaps=[sign*(v-(values[a]+slope*(k-a))) for k,v in enumerate(values) if k not in (a,b)]
        reasons=[]
        # Full-owned support precedes engineering placement/ranking. Requiring
        # the first contact in the first 35% silently excluded broad pairs
        # straddling the middle, then admitted them on unrelated later bars.
        # Keep span, middle coverage and terminal guards, and expose every
        # rejection. This downstream geometry never admits an author phase.
        # Three real contacts on the same supporting edge are valid. The old
        # strict-positive clearance rejected every collinear third touch and
        # could leave an otherwise well-defined whole wave without a channel.
        # Only a candle crossing outside the support invalidates this edge.
        if not gaps or min(gaps)<-1e-9:reasons.append('crosses_full_owned_support')
        if sign*slope<=0:reasons.append('slope_not_in_owned_direction')
        if b>=span:reasons.append('second_contact_not_before_terminal')
        if b-a<max(2,math.ceil(span*.22)):reasons.append('engineering_minimum_span_22pct')
        if not 2*a<=span<=2*b:reasons.append('contacts_do_not_straddle_owned_midpoint')
        fact=dict(start_index=start+a,end_index=start+b,slope=slope,
            axis_mismatch_normalized=abs(slope-axis)/scale,
            min_clearance=min(gaps) if gaps else None,span=b-a,
            additional_native_contacts=[start+k for k,v in enumerate(values)
                if k not in (a,b) and abs(v-(values[a]+slope*(k-a)))<=1e-9],
            legacy_first_35pct_rejected=a>span*.35)
        if reasons:rejected.append(dict(fact,rejection_reasons=reasons))
        else:candidates.append(fact)
    candidates.sort(key=lambda c:(c['axis_mismatch_normalized'],-c['span'],c['start_index']))
    audit=dict(measurement,axis_scope=dict(start_utc=rows[0]['timestamp_utc'],end_utc=rows[-1]['timestamp_utc']),
        axis_method='split_half_native_body_medians',axis_slope_per_native_bar=axis,
        axis_as_of=rows[-1]['timestamp_utc'],alignment_quality_state='engineering_relative_rank_not_author_validated',
        candidate_count=len(candidates),rank_policy='full_owned_envelope_then_axis_then_span',
        candidate_policy=RULE,legacy_first_35pct_hard_gate=False,
        engineering_placement=dict(minimum_span_fraction=.22,must_straddle_owned_midpoint=True,
            second_contact_before_terminal=True,author_rule_calibrated=False),
        eligible_candidates=candidates,rejected_candidates=rejected,
        original_wave_origin_required=False,author_degree_verified=False,
        semantic_or_scoring_admission_changed=False)
    return (candidates[0] if candidates else None),audit

def build_pair(wave, bars, tf, cutoff, seconds, provider, symbol):
    """Freeze geometry to A..B; subsequent bars only stop its display."""
    ev=wave.get('evidence',{})
    native_interval=ev.get('native_boundary_scope') and ev.get('scope_source_schema')=='book_native_boundary_scope_history_v1'
    if ((ev.get('descriptive_wave_scope')!='coarse' and not native_interval) or wave.get('timeframe')!=tf
            or ev.get('data_provider')!=provider or epoch(wave['known_at_utc'])>epoch(cutoff)):
        return [],{'reason':'scope_identity_or_clock'}
    a,b=wave['points'];times=[epoch(r['timestamp_utc']) for r in bars];pos={t:i for i,t in enumerate(times)}
    if a[0] not in pos or b[0] not in pos:return [],{'reason':'source_outside_native_context'}
    i,z=pos[a[0]],pos[b[0]];up=b[1]>a[1];side='low' if up else 'high';other='high' if up else 'low'
    if z-i<3 or bars[i][side]!=a[1] or bars[z][other]!=b[1]:return [],{'reason':'source_extrema_mismatch'}
    if any(r.get('timeframe')!=tf or r.get('provider')!=provider for r in bars[i:z+1]):
        return [],{'reason':'mixed_native_context'}
    low,high=sorted([a[1],b[1]])
    if any(r['low']<low-1e-8 or r['high']>high+1e-8 for r in bars[i:z+1]):
        return [],{'reason':'source_not_complete_envelope'}
    pair,axis=owned_outer_pair(bars,i,z,up)
    if pair is None:return [],dict(reason='no_broad_balanced_outer_pair',axis=axis)
    anchor,j=pair['start_index'],pair['end_index'];slope=pair['slope']
    axis.update(owned_axis_measurement(bars[i:z+1],slope,owner_id=wave['owner_id'],known_at=wave['known_at_utc']))
    level=lambda k:bars[anchor][side]+slope*(k-anchor)
    reference=(max if up else min)(range(i,z+1),key=lambda k:bars[k][other]-level(k))
    offset=bars[reference][other]-level(reference)
    if not math.isfinite(offset) or offset*(1 if up else -1)<=0:return [],{'reason':'invalid_parallel_offset'}
    owner=wave['owner_id'];identity=[[times[anchor],bars[anchor][side]],[times[j],bars[j][side]]]
    common=dict(rule_id=RULE,wave_id=owner,whole_wave_identity=deepcopy(wave['points']),
        whole_wave_known_at_utc=wave['known_at_utc'],author_wave_degree='unknown',
        wave_membership_policy='native_interval_geometry_not_author_or_force_admission' if native_interval else 'confirmed_native_coarse_scope_not_author_degree',
        boundary_scope_state='native_envelope_only' if native_interval else 'completed_native_descriptive_scope',
        source_native_leg_id=ev.get('source_native_leg_id'),
        interior_order_unknown=ev.get('interior_order_unknown') if native_interval else False,
        force_admission=False,native_scope_confirmation_clock=wave['known_at_utc'],
        data_provider=provider,native_timeframe=tf,direction='up' if up else 'down',
        ruler_identity=identity,source_rule_pages=[48,49,58,59,81,83],
        slope_per_native_bar=slope,anchor_order_proof=dict(second_anchor=times[j],terminal=b[0],valid=True),
        axis_reference=dict(axis,alignment_measure=pair['axis_mismatch_normalized'],
            axis_known_at_utc=wave['known_at_utc']),
        geometry_scope='whole_wave_A_to_B',display_only_geometry=True,
        construction_known_at_utc=wave['known_at_utc'],
        broker_book_native_projection=True,read_only=True,trade_permission=False,
        automatic_trade_permission=False,future_bars_used=False)
    out=[]
    from .pdf_trendline_block import _parallel_intelligence
    quality_line=dict(start_index=i,start_price=level(i),end_index=j,end_price=level(j),slope=slope)
    channel_quality=_parallel_intelligence(bars,quality_line,reference,offset,up,z)
    channel_quality.update(measurement_scope='full_owned_native_interval',
        known_at_utc=wave['known_at_utc'],force_admission=False)
    for family,layer,shift,lower in [('OUTER','trend',0,up),('CHANNEL','channel',offset,not up)]:
        # The overview belongs to A..B, not the subsequent overlapping
        # correction. Later boundary observations remain evidence only.
        end=z;contact=None
        for k in range(z+1,len(bars)):
            gap=(bars[k]['low']-level(k)-shift) if lower else (level(k)+shift-bars[k]['high'])
            if gap<=1e-9:contact=k;break
        facts=dict(common,coefficient_family=family,display_role='completed_wave_'+family.lower(),
            parallel_reference=[times[reference],bars[reference][other]] if shift else None,
            parallel_offset=shift,terminal_utc=iso(b[0]),
            first_contact_utc=iso(times[contact]) if contact is not None else None,
            display_state_known_at_utc=iso(times[end]+seconds),
            event_known_at_utc=iso(times[contact]+seconds) if contact is not None else None,
            display_end_reason='owned_wave_terminal_subsequent_adjustment_separate',
            retrospective_at_construction=bool(contact is not None and times[contact]+seconds<epoch(wave['known_at_utc'])))
        if family=='CHANNEL':facts['parallel_intelligence']=deepcopy(channel_quality)
        # Piecewise native-bar slope; never span a broker session gap with a
        # wall-clock chord. A single channel can have multiple finite pieces.
        # A parallel offset at A is a coefficient origin, not a price touch.
        # Chapter-3 channel starts at its OWN farthest native contact. Its
        # following clean extension is distinct from the A..B force measure.
        start_index=reference if family=='CHANNEL' else anchor
        if family=='CHANNEL':
            end=(contact-1) if contact is not None else len(bars)-1
            end=max(z,end)
            facts.update(display_anchor=[times[reference],bars[reference][other]],
                display_end_reason='native_channel_contact_to_first_subsequent_touch',
                display_state_known_at_utc=iso(times[end]+seconds))
        starts=[start_index]+[k+1 for k in range(start_index,end) if times[k+1]-times[k]!=seconds]
        stops=[k for k in range(start_index,end) if times[k+1]-times[k]!=seconds]+[end]
        for start,stop in zip(starts,stops):
            if start>=stop:continue
            oid='b'+sha256(f'{provider}|{symbol}|{RULE}|{owner}|{family}|{times[start]}'.encode()).hexdigest()[:23]
            caption=(('原生区间外沿' if family=='OUTER' else '原生区间通道') if native_interval else
                     ('整段趋势' if family=='OUTER' else '整段通道'))+' | '+tf+' | '+('上涨' if up else '下跌')
            if family=='CHANNEL':
                from .trend_trade_method_full_pipeline import _geometry_label_suffix
                caption+=_geometry_label_suffix(channel_quality)
            out.append(dict(id=oid,kind='line',layer=layer,timeframe=tf,owner_id=owner,source_id=RULE,
                points=[[times[k],level(k)+shift] for k in (start,stop)],
                known_at_utc=iso(max(epoch(wave['known_at_utc']),epoch(facts['display_state_known_at_utc']),
                    epoch(facts['event_known_at_utc']) if facts['event_known_at_utc'] else 0)),
                status='native_interval_boundary_candidate' if native_interval else 'whole_wave_boundary',
                label=caption,
                evidence=deepcopy(facts)))
    # Evaluate the original C/E and D logic on THIS whole wave only. Failure
    # is explicit; a child-wave target must not masquerade as its parent.
    from .pdf_trendline_block import select_pdf_turning_boundary
    turning=select_pdf_turning_boundary(bars[:z+1],dict(qualified=True,direction='up' if up else 'down',start_index=i))
    turning.update(known_at_utc=wave['known_at_utc'],parent_wave_id=owner)
    if turning.get('qualified'):
        from .trend_trade_method_full_pipeline import scene_objects
        targets=scene_objects(dict(as_of_utc=cutoff,turning_boundary=turning,
            recovery_target={'qualified':False}),bars,tf)
        for o in targets:
            o['evidence'].update(common,coefficient_family='RETURN_CE_D',
                display_role='completed_wave_return',ruler_identity=o['evidence']['ruler_identity'],
                slope_per_native_bar=turning['slope'],geometry_scope='owned_C_E_shifted_to_D',
                axis_reference=dict(owned_axis_measurement(bars[i:z+1],turning['slope'],
                    owner_id=owner,known_at=wave['known_at_utc']),
                    axis_known_at_utc=wave['known_at_utc']))
            o['owner_id']=owner
            o['id']='b'+sha256(f'{provider}|{symbol}|{RULE}|{owner}|{o["id"]}'.encode()).hexdigest()[:23]
            from .broker_live_engine import _finite_segments
            split,_=_finite_segments([o],bars,seconds);out.extend(split)
    return out,dict(owner_id=owner,source_points=wave['points'],known_at_utc=wave['known_at_utc'],
        ruler_identity=identity,parallel_reference=[times[reference],bars[reference][other]],
        slope_per_native_bar=slope,parallel_offset=offset,
        axis_reference=dict(axis,alignment_measure=pair['axis_mismatch_normalized']),
        turning_qualified=bool(turning.get('qualified')),turning_reason=turning.get('reason'),
        boundary_scope_state='native_envelope_only' if native_interval else 'completed_native_descriptive_scope',
        interior_order_unknown=ev.get('interior_order_unknown') if native_interval else False,
        author_degree_verified=False,display_only=True)

def restore_display_inventory(scene, *, _owned=False):
    """A repeated semantic merge receives the original research inventory."""
    # The public path owns one detached graph. The merge path can hand over
    # its already detached graph; copying the many-megabyte evidence twice
    # added seconds without changing a single decision or display point.
    result=scene if _owned else deepcopy(scene)
    current={o['id']:o for o in result['objects'] if not o.get('evidence',{}).get('display_only_geometry')}
    active=set(result.get('active_object_ids',current))&current.keys()
    old=result.pop('whole_wave_channel_display',{})
    for source in old.get('internal_source_objects',[]):
        obj=source;meta=obj.pop('display_suppression',{})
        current.setdefault(obj['id'],obj)
        if meta.get('was_active'):active.add(obj['id'])
    order={oid:i for i,oid in enumerate(old.get('original_object_order',[]))}
    result['objects']=sorted(current.values(),key=lambda o:order.get(o['id'],len(order)))
    result['active_object_ids']=sorted(active)
    return result

def _same_turning_construction(source,replacement,provider,timeframe):
    """A containing overview is not a replacement for an independent C-E/D.

    Deduplicate only an identical native construction and finite segment.
    Equal screen location, parent time enclosure or outer/channel slope
    cannot establish source ownership or replace RETURN with RESUME.
    """
    a=source.get('evidence') or {};b=replacement.get('evidence') or {}
    family=a.get('coefficient_family') or a.get('family')
    if (family not in ('RETURN_CE_D','RESUME_DF_C')
            or (b.get('coefficient_family') or b.get('family'))!=family
            or source.get('timeframe')!=timeframe or replacement.get('timeframe')!=timeframe
            or a.get('data_provider')!=provider or b.get('data_provider')!=provider
            or not a.get('direction') or a.get('direction')!=b.get('direction')
            or len(a.get('ruler_identity') or [])!=3
            or a.get('ruler_identity')!=b.get('ruler_identity')
            or len(source.get('points') or [])!=2
            or source.get('points')!=replacement.get('points')):
        return False
    return True


def _compatible_overview_boundary(source,replacement,wave,provider,timeframe):
    """Necessary construction compatibility, never author ownership proof.

    Enclosure by an up-wave cannot replace a down-wave's outer/channel.
    Nor can an outer rail stand in for a missing parallel channel. Source
    phase/degree adjudication remains separate from this minimum safeguard.
    """
    a=source.get('evidence') or {};b=replacement.get('evidence') or {}
    family=a.get('coefficient_family') or a.get('family')
    layer={'OUTER':'trend','CHANNEL':'channel'}.get(family)
    points=wave.get('points') or []
    if len(points)!=2:return False
    direction=('up' if points[1][1]>points[0][1] else
               'down' if points[1][1]<points[0][1] else None)
    return bool(direction and layer and source.get('layer')==replacement.get('layer')==layer
        and (b.get('coefficient_family') or b.get('family'))==family
        and source.get('timeframe')==replacement.get('timeframe')==timeframe
        and a.get('data_provider')==b.get('data_provider')==provider
        and a.get('direction')==b.get('direction')==direction)


def apply_complete_wave_channels(scene, *, _owned=False):
    """Must run after semantic reducers. No mutation of input or entry logic."""
    scene=restore_display_inventory(scene,_owned=_owned)
    result=dict(scene);tf=scene['timeframe'];cutoff=scene['cutoff_utc']
    from .broker_live_engine import SECONDS
    seconds=SECONDS[tf];clock=epoch(cutoff)
    bars=[r for r in scene.get('execution_context',{}).get('bars',[]) if epoch(r['timestamp_utc'])+seconds<=clock]
    candidates=[o for o in scene['objects'] if o.get('evidence',{}).get('descriptive_wave_scope')=='coarse']
    from .book_boundary_scopes import boundary_scopes
    native_intervals,native_scope_audit=boundary_scopes(scene,bars,seconds)
    candidates+=native_intervals
    bundles=[];audits=[]
    for wave in candidates:
        if wave['evidence'].get('native_boundary_scope') and any(
                parent['points'][0][0]<=wave['points'][0][0]<wave['points'][1][0]<=parent['points'][1][0]
                and min(parent['points'][0][1],parent['points'][1][1])<=min(wave['points'][0][1],wave['points'][1][1])
                and max(wave['points'][0][1],wave['points'][1][1])<=max(parent['points'][0][1],parent['points'][1][1])
                for parent,_ in bundles):
            audits.append(dict(owner_id=wave['owner_id'],reason='native_interval_inside_completed_overview'))
            continue
        objects,audit=build_pair(wave,bars,tf,cutoff,seconds,scene['provider'],scene['instrument'])
        audits.append(audit)
        if objects:bundles.append((wave,objects))
    # Only a successfully reconstructed native binding can reserve the current
    # ruler. Do not trust a cached high score or a loose time/price enclosure.
    binding=scene.get('book_trend_binding') or {}
    protected=set()
    if (binding.get('state')=='bound' and binding.get('native_timeframe')==tf
            and binding.get('as_of_utc')==cutoff
            and binding.get('market')==dict(provider=scene['provider'],symbol=scene['instrument'])):
        # Source identity uses the production ruler contract, whose price
        # points are also carried by each original Book display object.
        line=binding.get('Book_ruler_geometry') or {}
        try:
            pair=tuple((epoch(bars[line[k+'_index']]['timestamp_utc']),line[k+'_price']) for k in ('start','end'))
            for obj in scene['objects']:
                ev=obj.get('evidence',{})
                own=ev.get('book_wave_ruler_identity') or ev.get('ruler_identity') or []
                if obj.get('timeframe')==tf and tuple(map(tuple,own))==pair:protected.add(obj['id'])
                if line.get('wave_id') and ev.get('parent_wave_id')==line['wave_id']:protected.add(obj['id'])
        except (KeyError,TypeError,IndexError,ValueError):pass
    suppressed=[];kept=[];independent_turning=[];turning_duplicates=[];incompatible_boundaries=[]
    for obj in scene['objects']:
        ev=obj.get('evidence',{});identity=ev.get('ruler_identity')
        container=None;turning_enclosed=False;boundary_incompatible=False
        if obj['id'] not in protected and obj.get('timeframe')==tf and obj.get('layer') in ('trend','channel','turning_point') and identity:
            # Actual native source points, not projected display endpoints.
            # Never hide a cross-period ruler or one that began before A.
            for wave,replacements in bundles:
                a,b=wave['points']
                if all(a[0]<=p[0]<=b[0] and min(a[1],b[1])-1e-8<=p[1]<=max(a[1],b[1])+1e-8 for p in identity):
                    if obj.get('layer') in ('trend','channel') and not any(
                            _compatible_overview_boundary(obj,new,wave,scene['provider'],tf) for new in replacements):
                        boundary_incompatible=True
                        continue
                    family=ev.get('coefficient_family') or ev.get('family')
                    if family in ('RETURN_CE_D','RESUME_DF_C'):
                        if not any(_same_turning_construction(obj,new,scene['provider'],tf) for new in replacements):
                            # Price/time enclosure gives no parent-child
                            # construction proof. In particular, an overview
                            # with no qualified C-E/D must not erase a valid
                            # independent historical or selected turning line.
                            turning_enclosed=True
                            continue
                        turning_duplicates.append(obj['id'])
                    container=wave['owner_id'];break
        if container:
            reason=('identical_native_turning_segment_already_displayed' if obj['id'] in turning_duplicates
                    else 'internal_candidate_of_completed_native_wave')
            record=obj;record['display_suppression']=dict(reason=reason,display_owner=container,
                was_active=obj['id'] in scene.get('active_object_ids',[]))
            suppressed.append(record)
        elif not ev.get('display_only_geometry'):
            kept.append(obj)
            if turning_enclosed:independent_turning.append(obj['id'])
            if boundary_incompatible:incompatible_boundaries.append(obj['id'])
    new=[o for _,items in bundles for o in items]
    offset=scene['observed_server_utc_offset_seconds']
    for o in new:o['native_points']=[[int(t+offset),p] for t,p in o['points']]
    result['objects']=kept+new
    existing={o['id'] for o in kept};result['active_object_ids']=sorted((set(scene.get('active_object_ids',existing))&existing)|{o['id'] for o in new})
    result['whole_wave_channel_display']=dict(rule=RULE,scopes=audits,
        native_interval_source_audit=native_scope_audit,
        original_object_order=[o['id'] for o in scene['objects']],
        internal_source_objects=suppressed,internal_source_count=len(suppressed),
        visible_boundary_segments=len(new),protected_selected_source_ids=sorted(protected),semantic_decisions_changed=False,
        independent_turning_sources_retained=sorted(set(independent_turning)),
        identical_turning_segments_deduplicated=sorted(set(turning_duplicates)),
        turning_replacement_policy='same_family_native_contacts_and_segment_not_containment',
        incompatible_overview_boundary_sources_retained=sorted(set(incompatible_boundaries)),
        boundary_replacement_minimum='same_native_direction_family_layer_and_provider_required',
        boundary_source_phase_ownership_verified=False,
        author_degree_verified=False,automatic_trade_permission=False)
    return result
