"""Contract for the second, direct-entry research route.

The direct route is an exception to the pullback/right-side sequence.  It is
therefore admitted only when an external route packet is bound to the exact
Book phase and native source at the same closed cutoff.  This module does not
create a price signal, risk plan, order, or author confirmation.
"""
from copy import deepcopy
from .book_first_response_leg import clock


REQUIRED = (
    'parent_task_id', 'direction_task_id', 'upstream_parent_target_id',
    'downstream_measurement_target_id', 'parent_direction_basis_ids',
    'parent_unfinished_delivery_ids', 'measurement_ledger_ids',
    'retracement_amplitude_ledger_ids', 'liquidity_object_ids',
    'liquidity_clearance_evidence_ids', 'force_progression_evidence_ids',
    'invalidation_node_id', 'first_target_id', 'prior_adjudication_evidence_ids',
)


def validate_direct_entry_contract(book, route, timeframe, cutoff):
    """Bind a research route packet to one current Book scene."""
    base = dict(schema='book_direct_entry_contract_v1', state='unknown',
        timeframe=timeframe, as_of_utc=cutoff, entry_permission=False,
        paper_candidate=False, automatic_trade_permission=False,
        order_api_called=False, score_is_probability=False)
    def wait(reason, **facts):
        return dict(base, state='wait_direct_route_evidence', reason=reason, **facts)
    if not isinstance(route, dict):
        return wait('direct_route_packet_missing')
    if route.get('entry_route') != 'direct_pre_adjudicated_location':
        return wait('direct_route_name_mismatch')
    if route.get('route_is_not_direction_engine') is not True:
        return wait('direct_route_claims_direction')
    if route.get('direct_exception_pre_adjudicated') is not True:
        return wait('direct_exception_not_pre_adjudicated')
    missing = [key for key in REQUIRED if not route.get(key)]
    if missing:
        return wait('direct_route_required_evidence_missing', missing=missing)
    for key in ('parent_task_id','direction_task_id','upstream_parent_target_id',
            'downstream_measurement_target_id','invalidation_node_id','first_target_id',
            'phase_id'):
        if not isinstance(route.get(key), str) or not route[key].strip():
            return wait('direct_route_identifier_invalid', field=key)
    if route.get('right_side_state') != 'not_required_by_audited_exception':
        return wait('direct_exception_right_side_rule_unbound')
    if route.get('direction_side') not in ('long', 'short'):
        return wait('direct_route_direction_missing')
    evidence_clocks = route.get('evidence_clocks')
    if not isinstance(evidence_clocks, dict):
        return wait('direct_route_evidence_clocks_missing')
    evidence_ids=[]
    for key in ('parent_direction_basis_ids','parent_unfinished_delivery_ids',
            'measurement_ledger_ids','retracement_amplitude_ledger_ids',
            'liquidity_object_ids','liquidity_clearance_evidence_ids',
            'force_progression_evidence_ids','prior_adjudication_evidence_ids',
            'route_selection_basis_ids'):
        values=route.get(key)
        if (not isinstance(values,list) or not values or
                any(not isinstance(value,str) or not value.strip() for value in values)):
            return wait('direct_route_evidence_list_invalid', field=key)
        evidence_ids.extend(values)
    for evidence_id in evidence_ids:
        try:
            if evidence_id not in evidence_clocks:
                return wait('direct_route_evidence_clock_missing', evidence_id=evidence_id)
            if clock(evidence_clocks[evidence_id]) > clock(cutoff):
                return wait('direct_route_evidence_after_cutoff', evidence_id=evidence_id)
        except (TypeError, ValueError):
            return wait('direct_route_evidence_clock_invalid', evidence_id=evidence_id)
    try:
        packet_known=clock(route['known_at_utc'])
        latest_evidence=max((clock(evidence_clocks[evidence_id]) for evidence_id in evidence_ids))
        if latest_evidence > packet_known:
            return wait('direct_route_packet_clock_before_evidence', evidence_id=max(
                evidence_ids, key=lambda value: clock(evidence_clocks[value])))
    except (KeyError, TypeError, ValueError):
        return wait('direct_route_packet_clock_invalid')
    if route.get('background_state') != 'resolved' or route.get('force_progression_state') not in ('current_tf_confirmed', 'parent_acceptance_pending'):
        return wait('direct_route_background_or_force_unresolved')
    if route.get('parent_target_state') not in ('active', 'approaching', 'touched_under_review'):
        return wait('direct_route_parent_target_not_active')
    if route.get('small_tf_background_state') in (None, 'unknown') or route.get('trend_position') in (None, 'unknown'):
        return wait('direct_route_working_context_missing')
    if route.get('pullback_completion_state') not in ('candidate', 'current_tf_confirmed'):
        return wait('direct_route_pullback_completion_missing')
    if route.get('liquidity_clearance_assessment') not in ('processed_under_review', 'processed_with_current_tf_confirmation'):
        return wait('direct_route_liquidity_unresolved')
    try:
        if route.get('working_timeframe') != timeframe:
            return wait('direct_route_timeframe_mismatch')
        if clock(route['known_at_utc']) > clock(cutoff):
            return wait('direct_route_known_after_cutoff')
    except (KeyError, TypeError, ValueError):
        return wait('direct_route_clock_invalid')
    scores = book.get('boundary_breakout_assessment') or {}
    line = book.get('turning_point_line') or {}
    identity = scores.get('source_identity') or {}
    # The packet is bound to the Book scene, not only to a nested score
    # receipt.  A stale top-level scene timeframe must never be masked by a
    # copied nested assessment that happens to carry the requested timeframe.
    if book.get('timeframe') != timeframe:
        return wait('direct_route_book_timeframe_mismatch')
    try:
        if not book.get('as_of_utc') or clock(book['as_of_utc']) != clock(cutoff):
            return wait('direct_route_book_clock_mismatch')
    except (TypeError, ValueError):
        return wait('direct_route_book_clock_mismatch')
    if not isinstance(route.get('source_identity'), dict) or not route.get('source_identity'):
        return wait('direct_route_source_identity_invalid')
    if not isinstance(route.get('source_wave_id'), str) or not route.get('source_wave_id'):
        return wait('direct_route_source_wave_invalid')
    setup = book.get('setup_qualification') or {}
    try:
        if not setup.get('known_at_utc') or clock(setup['known_at_utc']) > clock(cutoff):
            return wait('direct_route_setup_clock_invalid')
    except (TypeError, ValueError):
        return wait('direct_route_setup_clock_invalid')
    if (scores.get('joint') or {}).get('state') != 'dual_scored':
        return wait('direct_route_dual_break_not_scored')
    if setup.get('both_boundaries_broken') is not True:
        return wait('direct_route_dual_setup_not_confirmed')
    if (setup.get('boundary_A_freeze') or {}).get('status') != 'frozen_before_first_boundary':
        return wait('direct_route_A_freeze_not_established')
    if scores.get('phase_id') != route.get('phase_id'):
        return wait('direct_route_phase_mismatch')
    expected_side={'up':'long','down':'short'}.get(scores.get('direction'))
    if expected_side is None or route.get('direction_side') != expected_side:
        return wait('direct_route_direction_mismatch')
    if route.get('phase_id') is None or route.get('source_identity') != identity:
        return wait('direct_route_native_source_identity_mismatch')
    if line.get('wave_id') != route.get('source_wave_id'):
        return wait('direct_route_wave_identity_mismatch')
    if scores.get('timeframe') != timeframe or scores.get('as_of_utc') != cutoff:
        return wait('direct_route_score_clock_mismatch')
    route_fingerprint = dict(
        parent_task_id=route['parent_task_id'], direction_task_id=route['direction_task_id'],
        upstream_parent_target_id=route['upstream_parent_target_id'],
        downstream_measurement_target_id=route['downstream_measurement_target_id'],
        phase_id=route['phase_id'], source_wave_id=route['source_wave_id'],
        known_at_utc=route['known_at_utc'])
    return dict(base, state='research_candidate_ready', reason=None,
        route=deepcopy(route), route_fingerprint=route_fingerprint,
        native_source_identity=deepcopy(identity),
        next_required='separate_quote_risk_and_paper_execution_review',
        author_wave_degree_verified=False, entry_permission=False,
        paper_candidate=False, automatic_trade_permission=False)

