"""Chapter-4 constructions that become available AFTER their parent ruler.

This drawing-only supplement preserves the force detector's frozen population.
Book PDF p81 describes C -> E development before C/E is shifted to D. Parent
trend qualification is not the same event as completion of this construction.
"""
from datetime import datetime
from .pdf_trendline_block import select_pdf_turning_boundary
from .book_wave_inventory import first_ruler_contact
from .trend_trade_method_full_pipeline import _closed, _closed_at, scene_objects
from .book_recovery_projection import recovery_projection


def first_late_turning(rows, line, observed_end, timeframe):
    """Only fill an absent construction, inside the still-clear parent phase.

    The selector freezes at the directional record extreme. Its inputs cannot
    change between record extremes, so there is no need to rescan every bar.
    Original geometric and D-confirmation rules are deliberately unchanged.
    """
    start=int(line['start_index'])
    stop=min(len(rows), first_ruler_contact(rows,line))
    if not start < observed_end <= stop:return None
    initial=select_pdf_turning_boundary(rows[:observed_end],dict(line,first_break_index=observed_end))
    if initial.get('qualified'):return None
    up=line['direction']=='up';side='high' if up else 'low'
    extreme=(max if up else min)(float(r[side]) for r in rows[start:observed_end])
    for k in range(observed_end,stop):
        value=float(rows[k][side])
        if not (value>extreme if up else value<extreme):continue
        extreme=value
        candidate=select_pdf_turning_boundary(rows[:k+1],dict(line,first_break_index=k+1))
        if candidate.get('qualified'):
            # The selector certifies D..E, but E may precede the latest extreme.
            # Do not discover an already-expired projection retrospectively.
            d=candidate['shift_anchor_index'];price=candidate['start_price']
            slope=candidate['slope'];destination='low' if up else 'high'
            if any((float(rows[q][destination])-(price+slope*(q-d)))*(1 if up else -1)<=1e-9
                   for q in range(d+1,k+1)):
                continue
            return dict(candidate,timeframe=timeframe,known_at_utc=_closed_at(rows[k],timeframe),
                        late_formation=True,parent_first_known_utc=_closed_at(rows[observed_end-1],timeframe),
                        formation_policy='first_complete_CDE_before_parent_first_contact')
    return None


def late_turning_objects(bars,timeframe,cutoff,existing):
    rows=_closed(bars,timeframe,cutoff)
    epoch=lambda s:datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
    positions={epoch(r['timestamp_utc']):i for i,r in enumerate(rows)}
    closes=[_closed_at(r,timeframe) for r in rows]
    ids={o['id'] for o in existing};out=[];considered=0;formed=0
    for obj in existing:
        e=obj.get('evidence',{})
        if e.get('display_role')!='historical_book_outer' or obj.get('timeframe')!=timeframe:continue
        anchors=e.get('book_wave_ruler_identity') or e.get('ruler_identity')
        if not anchors or any(a[0] not in positions for a in anchors):continue
        i,j=(positions[a[0]] for a in anchors)
        if j<=i:continue
        known=obj.get('known_at_utc')
        observed_end=next((k+1 for k,c in enumerate(closes) if c>=known),len(rows)+1) if known else len(rows)+1
        if observed_end>len(rows):continue
        line=dict(qualified=True,start_index=i,end_index=j,direction=e['direction'],
                  start_price=anchors[0][1],end_price=anchors[1][1],
                  slope=(anchors[1][1]-anchors[0][1])/(j-i))
        parent_wave_id = 'book_wave_parent:' + __import__('hashlib').sha256(
            f"{timeframe}|{anchors}".encode()).hexdigest()[:24]
        line.update(wave_id=parent_wave_id,known_at_utc=known)
        considered+=1
        turning=first_late_turning(rows,line,observed_end,timeframe)
        if not turning:continue
        turning['parent_wave_id']=parent_wave_id
        formed+=1
        recovery=recovery_projection(rows,turning,timeframe,cutoff,source_line=line)
        batch=scene_objects(dict(as_of_utc=cutoff,turning_boundary=turning,recovery_target=recovery),rows,timeframe)
        for added in batch:
            if added['id'] in ids:continue
            added['evidence'].update(late_formation=True,parent_ruler_identity=anchors,
                                    parent_wave_id=parent_wave_id,
                                    parent_first_known_utc=known,author_wave_degree='unknown',
                                    independent_drawing_supplement=True)
            ids.add(added['id']);out.append(added)
    return out,dict(parent_rulers_checked=considered,late_complete_constructions=formed,
                    additional_objects=len(out),force_detector_unchanged=True,
                    policy='fill_absent_CDE_before_parent_first_contact')
