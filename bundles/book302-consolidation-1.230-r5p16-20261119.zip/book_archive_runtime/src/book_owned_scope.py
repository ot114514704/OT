"""Native phase range is distinct from its ruler's first geometric contact.

This validates an explicitly supplied source range. It does not discover a
parent, promote containment to ownership, or establish the author's degree.
Legacy callers without a range retain their original geometry-only policy.
"""
from copy import deepcopy
from datetime import datetime, timedelta
from math import isfinite

SCHEMA = 'book_explicit_owned_scope_v1'
MINUTES = dict(M1=1, M5=5, M15=15, M30=30, H1=60, H4=240, D1=1440, W1=10080)


def clock(value):
    if not isinstance(value, str):
        raise ValueError('OWNED_SCOPE_CLOCK_MISSING')
    t = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if t.utcoffset() is None or t.utcoffset().total_seconds() != 0:
        raise ValueError('OWNED_SCOPE_NON_UTC_CLOCK')
    return t


def resolve_owned_scope(rows, line, explicit=None):
    """Return an input-bound start without substituting the source contact.

    The caller still owns construction/outer-envelope validation. A declared
    range is not proof of author membership or parent-score eligibility.
    """
    scope = explicit if explicit is not None else line.get('owned_scope')
    if scope is None:
        return dict(start_index=line.get('start_index'), binding=None,
                    policy='legacy_source_contact_range_no_independent_ownership')
    if not isinstance(scope, dict) or scope.get('schema') != SCHEMA:
        raise ValueError('OWNED_SCOPE_SCHEMA')
    tf = scope.get('timeframe')
    if tf not in MINUTES or not rows:
        raise ValueError('OWNED_SCOPE_NATIVE_PERIOD')
    if any(not scope.get(k) for k in ('scope_id', 'phase_id', 'provider', 'symbol',
                                     'start_utc', 'known_at_utc', 'membership_state')):
        raise ValueError('OWNED_SCOPE_IDENTITY_MISSING')
    if scope.get('direction') != line.get('direction') or scope['direction'] not in ('up', 'down'):
        raise ValueError('OWNED_SCOPE_DIRECTION')
    if line.get('timeframe', tf) != tf:
        raise ValueError('OWNED_SCOPE_NATIVE_PERIOD')
    if any(r.get('provider') != scope['provider'] or r.get('symbol') != scope['symbol']
           or r.get('timeframe') != tf for r in rows):
        raise ValueError('OWNED_SCOPE_MARKET_OR_PERIOD')
    times = [clock(r['timestamp_utc']) for r in rows]
    if any(a >= b for a, b in zip(times, times[1:])):
        raise ValueError('OWNED_SCOPE_NATIVE_ORDER')
    origin = clock(scope['start_utc'])
    if origin not in times:
        raise ValueError('OWNED_SCOPE_START_OUTSIDE_NATIVE_INPUT')
    start = times.index(origin)
    contact = line.get('start_index')
    if type(contact) is not int or not 0 <= start <= contact < len(rows):
        raise ValueError('OWNED_SCOPE_CONTACT_ORDER')
    price = scope.get('start_price')
    side = 'low' if scope['direction'] == 'up' else 'high'
    if isinstance(price, bool) or not isinstance(price, (int, float)) or not isfinite(price) or price != rows[start][side]:
        raise ValueError('OWNED_SCOPE_START_NOT_NATIVE')
    known = clock(scope['known_at_utc'])
    step = timedelta(minutes=MINUTES[tf])
    if not times[start] + step <= known <= times[-1] + step:
        raise ValueError('OWNED_SCOPE_NOT_KNOWN_IN_PREFIX')
    if scope['membership_state'] == 'native_event_admitted_not_author_degree':
        from .book_native_wave_process import digest
        expected_source='native_scope:'+digest([
            dict(provider=scope['provider'],symbol=scope['symbol']),tf,origin.timestamp(),side,price])[:24]
        admission = line.get('successor_admission') or {}
        d = admission.get('D') or {}
        if (not admission.get('admitted') or admission.get('failure_reasons')
            or scope.get('relation_evidence_id') != admission.get('event_chain_id')
            or scope['scope_id'] != expected_source
            or scope.get('parent_scope_id') != line.get('parent_scope_id')
            or scope['phase_id'] != line.get('phase_id')
            or scope['phase_id'] != admission.get('candidate_phase_id')
            or d.get('bar_open_utc') != scope['start_utc'] or d.get('price') != price
            or admission.get('admission_known_at_utc') != scope['known_at_utc']):
            raise ValueError('OWNED_SCOPE_NATIVE_PHASE_BINDING')
    elif scope['membership_state'] != 'declared_geometry_range_not_author_degree':
        raise ValueError('OWNED_SCOPE_MEMBERSHIP_NOT_SUPPORTED')
    binding = deepcopy(scope)
    binding.update(author_degree_verified=False, eligible_for_parent_score_gate=False,
                   scope_validation='native_range_and_source_lineage_not_author_membership')
    return dict(start_index=start, binding=binding,
                policy='explicit_owned_range_independent_of_first_ruler_contact')


def scope_context_identity(rows, line):
    """Stable semantic context, separate from contacts and current assessment.

    No cutoff, axis reading, terminal, or per-bar observation clock enters
    the source key. Distinct declared/event uses cannot silently collide.
    The declaration remains geometry-only; hashing it never admits a phase.
    """
    binding=resolve_owned_scope(rows,line)['binding']
    if binding is None:return None
    keys=('schema','scope_id','parent_scope_id','phase_id','provider','symbol',
          'timeframe','direction','start_price','membership_state','relation_evidence_id')
    context={k:deepcopy(binding.get(k)) for k in keys}
    context['start_utc']=clock(binding['start_utc']).isoformat().replace('+00:00','Z')
    context['start_price']=float(context['start_price'])
    return context
