"""Detach Book evidence without generic dispatch for every numeric leaf.

Book packets contain many repeated OHLC/receipt dictionaries. Plain dict/list
graphs need only one memoized traversal; every other type keeps Python's
deepcopy protocol. No serialization, pruning, normalization or cached clocks.
"""
from copy import deepcopy as _deepcopy

_ATOMIC=frozenset((str,int,float,bool,bytes,complex,type(None)))


def copy_evidence(value,memo=None):
    kind=type(value)
    if kind in _ATOMIC:return value
    if memo is None:memo={}
    identity=id(value)
    if identity in memo:return memo[identity]
    if kind is dict:
        result={};memo[identity]=result
        for key,item in value.items():
            result[key if type(key) in _ATOMIC else copy_evidence(key,memo)]=copy_evidence(item,memo)
        return result
    if kind is list:
        result=[];memo[identity]=result
        result.extend(copy_evidence(item,memo) for item in value)
        return result
    return _deepcopy(value,memo)
