"""Broker-neutral first slice of the XAUUSD live analysis loop.

This module intentionally stops before trading permission.  It turns a stream
of M1 OHLC bars into *closed-bar* M1/M5/M15/M30/H1/H4 observations and a
top-down snapshot that the existing theory engine can consume.  The numeric
measurements are observations (range, wick, location and candidate sweeps),
not fixed thresholds or entry signals.
"""

from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import statistics
import hashlib
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable, Sequence

try:
    from .live_projection_guard import anchored_one_to_one_value
    from .live_force_ob_review import review_force_ob_candidates
    from .live_parallel_channel_review import review_parallel_channels
    from .live_native_structure_sequence import review_native_structure
    from .three_push_wave_hypothesis import quantify_three_pushes
except ImportError:  # Direct module execution.
    from live_projection_guard import anchored_one_to_one_value
    from live_force_ob_review import review_force_ob_candidates
    from live_parallel_channel_review import review_parallel_channels
    from live_native_structure_sequence import review_native_structure
    from three_push_wave_hypothesis import quantify_three_pushes


TIMEFRAME_MINUTES: dict[str, int] = {
    "W1": 10080,
    "D1": 1440,
    "M1": 1,
    "M5": 5,
    "M15": 15,
    "M30": 30,
    "H1": 60,
    "H4": 240,
}
NATIVE_HIGHER_TIMEFRAMES: tuple[str, ...] = ("W1", "D1")
TOP_DOWN_ORDER: tuple[str, ...] = ("W1", "D1", "H4", "H1", "M30", "M15", "M5", "M1")


def parse_utc(value: str | datetime) -> datetime:
    """Parse an ISO UTC value and normalize it to an aware UTC datetime."""

    if isinstance(value, datetime):
        parsed = value
    else:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def iso_utc(value: datetime) -> str:
    return parse_utc(value).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True)
class OHLCBar:
    timestamp_utc: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float | None = None
    provider: str | None = None
    symbol: str = "XAUUSD"
    timeframe: str = "M1"

    @property
    def range(self) -> float:
        return max(0.0, self.high - self.low)

    @property
    def body(self) -> float:
        return abs(self.close - self.open)

    @property
    def upper_wick(self) -> float:
        return max(0.0, self.high - max(self.open, self.close))

    @property
    def lower_wick(self) -> float:
        return max(0.0, min(self.open, self.close) - self.low)

    def as_dict(self) -> dict[str, object]:
        return {
            "timestamp_utc": iso_utc(self.timestamp_utc),
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "volume": self.volume,
            "provider": self.provider,
            "symbol": self.symbol,
            "timeframe": self.timeframe,
        }


def _number(row: dict[str, str], field: str) -> float:
    value = row.get(field)
    if value in (None, ""):
        raise ValueError(f"missing numeric field: {field}")
    return float(value)


def load_m1_csv(path: str | Path, *, expected_symbol: str = "XAUUSD") -> list[OHLCBar]:
    """Load M1 bars without assuming a broker-specific live API."""

    bars: list[OHLCBar] = []
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        for line_number, row in enumerate(csv.DictReader(handle), start=2):
            symbol = row.get("symbol") or expected_symbol
            timeframe = row.get("timeframe") or "M1"
            if symbol != expected_symbol or timeframe != "M1":
                continue
            try:
                bars.append(
                    OHLCBar(
                        timestamp_utc=parse_utc(row["timestamp_utc"]),
                        open=_number(row, "open"),
                        high=_number(row, "high"),
                        low=_number(row, "low"),
                        close=_number(row, "close"),
                        volume=float(row["volume"]) if row.get("volume") else None,
                        provider=row.get("provider") or None,
                        symbol=symbol,
                        timeframe="M1",
                    )
                )
            except (KeyError, ValueError) as error:
                raise ValueError(f"invalid M1 row {line_number}: {error}") from error
    return sorted(bars, key=lambda item: item.timestamp_utc)


def _bucket_start(timestamp: datetime, timeframe_minutes: int) -> datetime:
    epoch_minutes = int(parse_utc(timestamp).timestamp() // 60)
    bucket_minutes = epoch_minutes - (epoch_minutes % timeframe_minutes)
    return datetime.fromtimestamp(bucket_minutes * 60, tz=timezone.utc)


def aggregate_bars(
    bars: Sequence[OHLCBar],
    timeframe: str,
    *,
    as_of_utc: str | datetime | None = None,
) -> list[OHLCBar]:
    """Aggregate M1 bars and retain only bars fully closed by ``as_of_utc``."""

    if timeframe not in TIMEFRAME_MINUTES:
        raise ValueError(f"unsupported timeframe: {timeframe}")
    if timeframe in NATIVE_HIGHER_TIMEFRAMES:
        raise ValueError(f"{timeframe} requires native broker bars; do not synthesize it from M1")
    minutes = TIMEFRAME_MINUTES[timeframe]
    cutoff = parse_utc(as_of_utc) if as_of_utc is not None else None
    buckets: dict[datetime, list[OHLCBar]] = {}
    for bar in bars:
        start = _bucket_start(bar.timestamp_utc, minutes)
        end = start + timedelta(minutes=minutes)
        if cutoff is not None and end > cutoff:
            continue
        buckets.setdefault(start, []).append(bar)

    result: list[OHLCBar] = []
    for start in sorted(buckets):
        members = sorted(buckets[start], key=lambda item: item.timestamp_utc)
        result.append(
            OHLCBar(
                timestamp_utc=start,
                open=members[0].open,
                high=max(item.high for item in members),
                low=min(item.low for item in members),
                close=members[-1].close,
                volume=(
                    sum(item.volume for item in members if item.volume is not None)
                    if any(item.volume is not None for item in members)
                    else None
                ),
                provider=members[-1].provider,
                symbol=members[-1].symbol,
                timeframe=timeframe,
            )
        )
    return result


def _safe_ratio(numerator: float, denominator: float) -> float | None:
    return round(numerator / denominator, 6) if denominator > 0 else None


def _reconstructed_indicator_context(
    bars: Sequence[OHLCBar], *, as_of_utc: str | datetime, bin_size: float = 0.1,
    days_to_draw: int = 20, price_steps: int = 800, value_area_ratio: float = 0.618,
    smooth: int = 2, provider_day_offset_seconds: int = 0,
) -> dict[str, object]:
    """Rebuild a small, auditable subset of the user's MT5 overlays.

    This is deliberately an observation layer: it uses only closed bars and
    broker tick-volume as a within-feed weighting proxy.  It does not copy an
    opaque EX5 calculation and it never produces an order side or price.
    """
    cutoff = parse_utc(as_of_utc)
    closed = [bar for bar in bars if parse_utc(bar.timestamp_utc) + timedelta(minutes=1) <= cutoff]
    if not closed:
        return {"status": "no_closed_bars", "vwap": None, "value_area": None, "session": None}
    def provider_day(bar: OHLCBar):
        return (parse_utc(bar.timestamp_utc) + timedelta(seconds=provider_day_offset_seconds)).date()

    latest = closed[-1]
    day = provider_day(latest)
    day_bars = [bar for bar in closed if provider_day(bar) == day]
    weighted = [(bar, float(bar.volume)) for bar in day_bars if bar.volume is not None and bar.volume > 0]
    vwap = None
    vwap_status = "unavailable_no_tick_volume"
    if weighted:
        denominator = sum(volume for _, volume in weighted)
        vwap = round(sum(((bar.high + bar.low + bar.close) / 3.0) * volume for bar, volume in weighted) / denominator, 6)
        vwap_status = "reconstructed_from_closed_bars"

    value_area: dict[str, object] = {"status": "unavailable_no_tick_volume"}
    if weighted and bin_size > 0:
        bins: dict[float, float] = {}
        for bar, volume in weighted:
            typical = (bar.high + bar.low + bar.close) / 3.0
            level = round(round(typical / bin_size) * bin_size, 6)
            bins[level] = bins.get(level, 0.0) + volume
        total = sum(bins.values())
        poc = max(bins, key=lambda level: (bins[level], -level))
        selected = {poc}
        covered = bins[poc]
        # Expand by the strongest adjacent bins until the user-confirmed 61.8%
        # coverage is reached; this is not a trading threshold or signal.
        while covered < total * value_area_ratio and len(selected) < len(bins):
            candidates = [level for level in bins if level not in selected]
            level = max(candidates, key=lambda item: (bins[item], -item))
            selected.add(level)
            covered += bins[level]
        value_area = {
            "status": "reconstructed_candidate",
            "bin_size": bin_size,
            "poc": poc,
            "value_area_low": min(selected),
            "value_area_high": max(selected),
            "coverage_ratio": round(covered / total, 6) if total else None,
            "source_bar_count": len(weighted),
            "weighting": "MT5_tick_volume_within_same_provider_day",
        }

    # This follows the supplied VP62_Daily_M1_Correct.mq5 semantics rather
    # than the generic histogram above: each day gets its own high/low range,
    # 800 bins, range-overlap tick-volume allocation, two smoothing passes,
    # and a 61.8% POC-centred value area.  Missing days remain missing rather
    # than being forward-filled.
    daily_profiles: list[dict[str, object]] = []
    by_day: dict[object, list[OHLCBar]] = {}
    for bar in closed:
        by_day.setdefault(provider_day(bar), []).append(bar)
    server_cutoff_day = (cutoff + timedelta(seconds=provider_day_offset_seconds)).date()
    calendar_days = [server_cutoff_day - timedelta(days=index) for index in range(max(1, days_to_draw))]
    for profile_day in calendar_days:
        if profile_day not in by_day:
            continue
        # MQ5 determines the range from every included M1, even a zero-weight
        # wick. Only the allocation uses tick volume; it must not narrow the
        # statistical range by discarding those bars.
        day_rows = list(by_day[profile_day])
        if not any(bar.volume is not None and bar.volume > 0 for bar in day_rows):
            daily_profiles.append({"date_server": str(profile_day), "status": "unavailable_no_tick_volume"})
            continue
        day_low = min(bar.low for bar in day_rows)
        day_high = max(bar.high for bar in day_rows)
        step = (day_high - day_low) / float(price_steps) if day_high > day_low else 0.0
        if step <= 0:
            daily_profiles.append({"date_server": str(profile_day), "status": "flat_price_range"})
            continue
        profile = [0.0] * price_steps
        for bar in day_rows:
            if bar.volume is None or bar.volume <= 0:
                continue
            low_bin = max(0, int((bar.low - day_low) / step))
            high_bin = min(price_steps - 1, int((bar.high - day_low) / step))
            share = float(bar.volume) / float(max(1, high_bin - low_bin + 1))
            for index in range(low_bin, high_bin + 1):
                profile[index] += share
        for _ in range(max(0, smooth)):
            smoothed = profile.copy()
            for index in range(1, price_steps - 1):
                smoothed[index] = (profile[index - 1] + profile[index] + profile[index + 1]) / 3.0
            profile = smoothed
        total = sum(profile)
        poc_index = max(range(price_steps), key=lambda index: profile[index]) if total else 0
        low_index = high_index = poc_index
        covered = profile[poc_index] if total else 0.0
        while covered < total * value_area_ratio and (low_index > 0 or high_index < price_steps - 1):
            up = profile[high_index + 1] if high_index + 1 < price_steps else -1.0
            down = profile[low_index - 1] if low_index > 0 else -1.0
            if up >= down and up >= 0:
                high_index += 1; covered += profile[high_index]
            elif down >= 0:
                low_index -= 1; covered += profile[low_index]
            else:
                break
        daily_profiles.append({
            "date_server": str(profile_day),
            "status": "reconstructed_candidate",
            "source_bar_count": len(day_rows),
            "price_steps": price_steps,
            "range_low": round(day_low, 6),
            "range_high": round(day_high, 6),
            "poc": round(day_low + (poc_index + 0.5) * step, 6),
            "value_area_low": round(day_low + low_index * step, 6),
            "value_area_high": round(day_low + (high_index + 1) * step, 6),
            "coverage_ratio": round(covered / total, 6) if total else None,
            "profile_width_bars": 80,
        })

    hour = parse_utc(latest.timestamp_utc).hour
    session = (
        "asia_candidate" if 0 <= hour < 8 else
        "london_candidate" if 8 <= hour < 13 else
        "new_york_candidate" if 13 <= hour < 21 else
        "rollover_or_off_session"
    )
    return {
        "status": "diagnostic_only",
        "as_of_utc": iso_utc(cutoff),
        "vwap": {"status": vwap_status, "value": vwap, "anchor": "provider_server_calendar_day", "provider_day_offset_seconds": provider_day_offset_seconds},
        "value_area": value_area,
        "daily_price_distribution": {
            "indicator_family": "VP62_Daily_M1_Correct",
            "status": "diagnostic_only",
            "days_requested": days_to_draw,
            "days_available": len(daily_profiles),
            "calendar_window_start_server": str(calendar_days[-1]),
            "calendar_window_end_server": str(calendar_days[0]),
            "calendar_days_without_closed_bars": [str(day) for day in calendar_days if day not in by_day],
            "price_steps": price_steps,
            "value_area_ratio": value_area_ratio,
            "smooth_passes": smooth,
            "day_boundary": "provider_server_midnight" if provider_day_offset_seconds else "UTC_midnight_unless_provider_offset_verified",
            "provider_day_offset_seconds": provider_day_offset_seconds,
            "profiles": daily_profiles,
            "partial_history_boundary": min(by_day) > calendar_days[-1],
        },
        "session": {"label": session, "basis": "UTC_hour_candidate_window", "validated_against_broker_session": False},
        "boundary": "VWAP/Value Area/Session 是位置与背景候选，不替代父级结构、目标、收盘接受或风险裁决。",
    }


def _coarse_closed_bar_view(bars: Sequence[OHLCBar], *, window: int = 16) -> dict[str, object]:
    """Show the whole recent path before inspecting standout candles.

    Tick volume is only a within-provider activity proxy, never market depth
    or proof of liquidity. All members have already closed at the caller's
    snapshot cutoff; a standout candle's follow-through uses only later bars
    present in that same cutoff.
    """

    recent = list(bars[-window:])
    if not recent:
        return {"status": "no_closed_bars", "close_path": [], "range_leaders": [],
                "lower_tick_activity_bars": [], "activity_caveat": "无可比较已收盘 K 线"}
    first, last = recent[0], recent[-1]
    close_path = [
        {"timestamp_utc": iso_utc(bar.timestamp_utc), "close": bar.close}
        for bar in recent
    ]
    candle_path = [
        {
            "timestamp_utc": iso_utc(bar.timestamp_utc),
            "open": bar.open,
            "high": bar.high,
            "low": bar.low,
            "close": bar.close,
        }
        for bar in recent
    ]

    def candle_fact(index: int) -> dict[str, object]:
        bar = recent[index]
        following = recent[index + 1] if index + 1 < len(recent) else None
        direction = "up" if bar.close > bar.open else "down" if bar.close < bar.open else "flat"
        if following is None:
            next_close_read = "pending_next_close"
        elif direction == "up":
            if following.close > bar.high:
                next_close_read = "up_extension_beyond_high"
            elif following.close < bar.open:
                next_close_read = "up_body_retraced_through_open"
            elif following.close > bar.close:
                next_close_read = "up_follow_on_within_range"
            else:
                next_close_read = "up_paused_or_partly_retraced"
        elif direction == "down":
            if following.close < bar.low:
                next_close_read = "down_extension_beyond_low"
            elif following.close > bar.open:
                next_close_read = "down_body_retraced_through_open"
            elif following.close < bar.close:
                next_close_read = "down_follow_on_within_range"
            else:
                next_close_read = "down_paused_or_partly_retraced"
        elif following.close > bar.high:
            next_close_read = "flat_bar_followed_by_close_above_high"
        elif following.close < bar.low:
            next_close_read = "flat_bar_followed_by_close_below_low"
        else:
            next_close_read = "flat_bar_followed_by_close_inside_range"
        previous = recent[index - 1] if index > 0 else None
        previous_range_relation = (
            "close_above_previous_high" if previous and bar.close > previous.high else
            "close_below_previous_low" if previous and bar.close < previous.low else
            "close_inside_or_at_previous_range" if previous else "no_previous_bar_in_window"
        )
        return {
            "timestamp_utc": iso_utc(bar.timestamp_utc),
            "open": bar.open, "high": bar.high, "low": bar.low, "close": bar.close,
            "range": round(bar.range, 6),
            "body_share": _safe_ratio(bar.body, bar.range),
            "upper_wick_share": _safe_ratio(bar.upper_wick, bar.range),
            "lower_wick_share": _safe_ratio(bar.lower_wick, bar.range),
            "close_location": _safe_ratio(bar.close - bar.low, bar.range),
            "tick_volume": bar.volume,
            "direction": direction,
            "next_close_read": next_close_read,
            "previous_range_relation": previous_range_relation,
            "next_closed_bar_utc": iso_utc(following.timestamp_utc) if following else None,
            "next_closed_close": following.close if following else None,
        }

    largest = sorted(range(len(recent)), key=lambda index: (-recent[index].range, index))[:2]
    volume_complete = all(bar.volume is not None for bar in recent)
    volume_has_order = volume_complete and len({bar.volume for bar in recent}) > 1
    lower_activity = (
        sorted(range(len(recent)), key=lambda index: (recent[index].volume, index))[:2]
        if volume_has_order and len(recent) >= 3 else []
    )
    low_activity_facts = []
    for rank, index in enumerate(lower_activity, start=1):
        fact = candle_fact(index)
        fact["activity_rank_low_to_high"] = rank
        low_activity_facts.append(fact)
    adjacent_pairs = list(zip(recent, recent[1:]))
    overlapping_pairs = sum(
        min(previous.high, current.high) > max(previous.low, current.low)
        for previous, current in adjacent_pairs
    )
    closes_above_previous_high = sum(
        current.close > previous.high for previous, current in adjacent_pairs
    )
    closes_below_previous_low = sum(
        current.close < previous.low for previous, current in adjacent_pairs
    )
    close_travel = sum(
        abs(current.close - previous.close) for previous, current in adjacent_pairs
    )
    # Preserve these as raw process facts.  No fixed overlap/travel threshold
    # can identify Alexander's low-liquidity movement or a parent trend.
    whole_path_process = {
        "adjacent_pairs": len(adjacent_pairs),
        "overlapping_ranges": overlapping_pairs,
        "nonoverlapping_ranges": len(adjacent_pairs) - overlapping_pairs,
        "closes_above_previous_high": closes_above_previous_high,
        "closes_below_previous_low": closes_below_previous_low,
        "close_path_travel": round(close_travel, 6),
        "net_close_distance": round(abs(last.close - first.close), 6),
        "interpretation_status": "descriptive_process_only",
        "boundary": "整段重叠与收盘路径用于对照推动/回吐，不按计数阈值宣告低流动性、趋势、父任务或交易方向。",
    }
    return {
        "status": "descriptive_only",
        "timeframe": last.timeframe,
        "window_count": len(recent),
        "from_utc": iso_utc(first.timestamp_utc),
        "through_utc": iso_utc(last.timestamp_utc),
        "first_close": first.close,
        "last_close": last.close,
        "net_close_change": round(last.close - first.close, 6),
        "window_high": max(bar.high for bar in recent),
        "window_low": min(bar.low for bar in recent),
        "close_path": close_path,
        "candle_path": candle_path,
        "whole_path_process": whole_path_process,
        "range_leaders": [candle_fact(index) for index in largest],
        "lower_tick_activity_bars": low_activity_facts,
        "activity_caveat": (
            "仅是同一经纪商、同一周期内 tick 计数的相对低位；不等于真实市场流动性或订单簿深度。"
            if lower_activity else
            "该窗口缺少完整可比 tick 计数，或各根计数相同；不能据此判断相对低活动，更不能判断低流动性。"
        ),
        "boundary": "折线只显示收盘轨迹；大 K 线、影线和低活动都只是观察，须结合位置、后续收盘与父级任务解释。",
    }


def _confirmed_fractal_candidates(
    bars: Sequence[OHLCBar],
    *,
    radius: int = 2,
) -> list[dict[str, object]]:
    """Return swings visible only after their right-side bars have closed.

    These are structural measurement candidates, not protected nodes, MSS,
    trend labels or targets.  A small radius keeps the live view responsive;
    it is not a universal theory threshold and must remain reviewable.
    """

    if radius < 1 or len(bars) < radius * 2 + 1:
        return []
    output: list[dict[str, object]] = []
    for pivot in range(radius, len(bars) - radius):
        left = bars[pivot - radius:pivot]
        right = bars[pivot + 1:pivot + radius + 1]
        confirmation_bar = bars[pivot + radius]
        confirmation_minutes = TIMEFRAME_MINUTES.get(confirmation_bar.timeframe)
        if confirmation_minutes is None:
            raise ValueError(f"unsupported fractal confirmation timeframe: {confirmation_bar.timeframe}")
        confirmed_at_utc = iso_utc(
            parse_utc(confirmation_bar.timestamp_utc) + timedelta(minutes=confirmation_minutes)
        )
        high = bars[pivot].high
        low = bars[pivot].low
        if high > max(item.high for item in left + right):
            output.append({
                "kind": "confirmed_swing_high_candidate",
                "pivot_timestamp_utc": iso_utc(bars[pivot].timestamp_utc),
                "confirmed_at_utc": confirmed_at_utc,
                "price": high,
                "radius": radius,
                "status": "confirmed_observation_not_protected_node",
            })
        if low < min(item.low for item in left + right):
            output.append({
                "kind": "confirmed_swing_low_candidate",
                "pivot_timestamp_utc": iso_utc(bars[pivot].timestamp_utc),
                "confirmed_at_utc": confirmed_at_utc,
                "price": low,
                "radius": radius,
                "status": "confirmed_observation_not_protected_node",
            })
    return output


def _geometric_step_chain(
    swings: Sequence[dict[str, object]], *, timeframe: str,
) -> dict[str, object]:
    """Compare successive same-cycle return attempts without naming SNR.

    Alexander's staircase requires a *named* structure node and an account
    of force at that node. These confirmed OHLC pivots only identify which
    highs/lows a later attempt did or did not reach; they are the places to
    inspect the actual candle force and source drawing next.
    """
    high_kind = "confirmed_swing_high_candidate"
    low_kind = "confirmed_swing_low_candidate"

    def steps(kind: str, opposite_kind: str) -> list[dict[str, object]]:
        same = [item for item in swings if item.get("kind") == kind and isinstance(item.get("price"), (int, float))]
        opposite = [item for item in swings if item.get("kind") == opposite_kind and isinstance(item.get("price"), (int, float))]
        output: list[dict[str, object]] = []
        selected = same[-7:]
        for previous, current in zip(selected, selected[1:]):
            prior_price = float(previous["price"])
            price = float(current["price"])
            between = [item for item in opposite
                       if str(previous.get("pivot_timestamp_utc") or "") < str(item.get("pivot_timestamp_utc") or "")
                       < str(current.get("pivot_timestamp_utc") or "")]
            counter_pivot = (min(between, key=lambda item: float(item["price"])) if kind == high_kind else
                             max(between, key=lambda item: float(item["price"]))) if between else None
            output.append({
                "timeframe": timeframe,
                "side": "return_high" if kind == high_kind else "return_low",
                "previous_price": prior_price,
                "previous_pivot_utc": previous.get("pivot_timestamp_utc"),
                "current_price": price,
                "current_pivot_utc": current.get("pivot_timestamp_utc"),
                "current_confirmed_at_utc": current.get("confirmed_at_utc"),
                "relative_to_previous": "higher" if price > prior_price else "lower" if price < prior_price else "equal",
                "intervening_opposite_pivot": {
                    "price": counter_pivot["price"],
                    "pivot_timestamp_utc": counter_pivot.get("pivot_timestamp_utc"),
                } if counter_pivot else None,
                "status": "complete_geometric_return_attempt" if counter_pivot else "same_side_pivots_without_bound_return_leg",
            })
        return output

    high_steps = steps(high_kind, low_kind)
    low_steps = steps(low_kind, high_kind)
    return {
        "status": "same_timeframe_geometric_step_observation" if high_steps or low_steps else "insufficient_confirmed_pivots",
        "timeframe": timeframe,
        "high_steps": high_steps,
        "low_steps": low_steps,
        "source": "confirmed_closed_bar_fractal_pivots",
        "theory_condition_source_ref": "msg-7719597270944042673",
        "theory_condition_application": "analogue_to_force_failing_at_named_snr_not_yet_source_bound",
        "boundary": (
            "高点逐级降低只是反抽高度的几何观察；低点逐级抬高也一样。"
            "必须核对真实 SNR 所属周期、两次尝试之间的大 K/重叠、目标和后续收盘；"
            "不能把几何高低点直接叫 Alexander 的 SNR 阶梯或趋势结论。"
        ),
    }


def _candidate_node_test_observations(
    bars: Sequence[OHLCBar], swings: Sequence[dict[str, object]],
) -> list[dict[str, object]]:
    """Record how closed bars test confirmed swing prices on their own timeframe.

    A swing is only a geometric candidate. A wick, close through, or later
    return is a source-bar fact, not SNR conversion, acceptance, a protected
    node, or a parent-task replacement.
    """

    output: list[dict[str, object]] = []
    for swing in swings:
        price = swing.get("price")
        confirmed_at = swing.get("confirmed_at_utc")
        kind = swing.get("kind")
        if not isinstance(price, (int, float)) or isinstance(price, bool) or not confirmed_at or kind not in {
            "confirmed_swing_high_candidate", "confirmed_swing_low_candidate",
        }:
            continue
        eligible = [bar for bar in bars if parse_utc(bar.timestamp_utc) >= parse_utc(str(confirmed_at))]
        is_high = kind == "confirmed_swing_high_candidate"
        through_wick = [bar for bar in eligible if bar.high > price] if is_high else [bar for bar in eligible if bar.low < price]
        through_close = [bar for bar in eligible if bar.close > price] if is_high else [bar for bar in eligible if bar.close < price]
        first_close = through_close[0] if through_close else None
        after_first = eligible[eligible.index(first_close) + 1:] if first_close else []
        immediate_next = after_first[0] if after_first else None
        close_back = next(
            (bar for bar in after_first if bar.close < price), None
        ) if is_high else next(
            (bar for bar in after_first if bar.close > price), None
        )
        latest = eligible[-1] if eligible else None
        latest_side = (
            "new_side" if (latest.close > price if is_high else latest.close < price)
            else "old_side" if latest.close != price else "at_candidate_price"
        ) if latest else "no_post_confirmation_close"
        body_crosses_from_old_side = (
            first_close.open < price if is_high else first_close.open > price
        ) if first_close else None
        immediate_next_side = (
            "new_side" if (immediate_next.close > price if is_high else immediate_next.close < price)
            else "old_side" if immediate_next.close != price else "at_candidate_price"
        ) if immediate_next else "pending_next_closed_bar"
        output.append({
            "kind": kind,
            "pivot_timestamp_utc": swing.get("pivot_timestamp_utc"),
            "candidate_price": price,
            "confirmed_at_utc": confirmed_at,
            "source_bar_timeframe": bars[-1].timeframe if bars else None,
            "observed_bar_count_after_confirmation": len(eligible),
            "first_wick_through_bar_utc": iso_utc(through_wick[0].timestamp_utc) if through_wick else None,
            "first_close_through_bar_utc": iso_utc(first_close.timestamp_utc) if first_close else None,
            "first_close_through_bar": {
                "timestamp_utc": iso_utc(first_close.timestamp_utc),
                "open": first_close.open, "high": first_close.high,
                "low": first_close.low, "close": first_close.close,
                "body_crosses_node_from_old_side": body_crosses_from_old_side,
                "reading": (
                    "body_crossed_candidate_level_from_old_side"
                    if body_crosses_from_old_side else "close_beyond_level_without_body_cross_from_old_side"
                ),
            } if first_close else None,
            "immediate_following_close": {
                "timestamp_utc": iso_utc(immediate_next.timestamp_utc),
                "close": immediate_next.close,
                "side_vs_candidate": immediate_next_side,
                "closed_beyond_first_crossing_bar_extreme": (
                    immediate_next.close > first_close.high if is_high
                    else immediate_next.close < first_close.low
                ),
            } if immediate_next and first_close else None,
            "immediate_following_close_state": immediate_next_side,
            "first_close_back_old_side_bar_utc": iso_utc(close_back.timestamp_utc) if close_back else None,
            "latest_closed_bar_utc": iso_utc(latest.timestamp_utc) if latest else None,
            "latest_closed_price": latest.close if latest else None,
            "latest_close_side": latest_side,
            "status": (
                "no_closed_bars_after_confirmation" if not eligible
                else "close_through_back_and_recrossed_new_side_observed" if close_back and latest_side == "new_side"
                else "close_through_then_close_back_old_side_observed" if close_back
                else "close_through_observed_no_close_back_in_loaded_bars" if first_close
                else "wick_through_only_in_loaded_bars" if through_wick
                else "no_through_test_in_loaded_bars"
            ),
            "boundary": "确认后的同周期已收盘 K 线几何测试；不据此命名颈线/SNR、保护节点、接受转换、父任务或交易方向。",
        })
    return output


def _alternating_swings(swings: Sequence[dict[str, object]]) -> list[dict[str, object]]:
    """Keep a time-ordered alternating swing sequence for measurement only."""

    output: list[dict[str, object]] = []
    for swing in sorted(swings, key=lambda item: (str(item.get("pivot_timestamp_utc")), str(item.get("kind")))):
        if not output or output[-1].get("kind") != swing.get("kind"):
            output.append(dict(swing))
            continue
        if swing.get("kind") == "confirmed_swing_high_candidate" and float(swing.get("price", 0)) >= float(output[-1].get("price", 0)):
            output[-1] = dict(swing)
        elif swing.get("kind") == "confirmed_swing_low_candidate" and float(swing.get("price", 0)) <= float(output[-1].get("price", 0)):
            output[-1] = dict(swing)
    return output


def _pivot_direction(origin: dict[str, object], terminal: dict[str, object]) -> str | None:
    """Direction is the ordered high/low transition, not endpoint arithmetic."""
    kinds = (origin.get("kind"), terminal.get("kind"))
    if kinds == ("confirmed_swing_low_candidate", "confirmed_swing_high_candidate"):
        return "up"
    if kinds == ("confirmed_swing_high_candidate", "confirmed_swing_low_candidate"):
        return "down"
    return None


def _measurement_candidates(
    swings: Sequence[dict[str, object]],
    current_close: float,
) -> dict[str, object]:
    """Expose leg geometry; only a later distinct retracement pivot may start 1:1."""

    alternating = _alternating_swings(swings)
    kinds_by_time: dict[str, set[str]] = {}
    for swing in swings:
        kinds_by_time.setdefault(str(swing.get("pivot_timestamp_utc")), set()).add(str(swing.get("kind")))
    ambiguous_times = {time for time, kinds in kinds_by_time.items() if len(kinds) > 1}
    if len(alternating) < 2:
        return {
            "method": "confirmed_live_fractal_radius_2",
            "visible_swing_count": len(alternating),
            "latest_leg": None,
            "one_to_one_target_candidate": None,
            "one_to_one_source_leg": None,
            "projection_anchor": None,
            "projection_family": "none_missing_retracement_anchor",
            "retracement_observation": None,
            "status": "insufficient_confirmed_swings",
        }
    origin, terminal = alternating[-2], alternating[-1]
    if (str(origin.get("pivot_timestamp_utc")) >= str(terminal.get("pivot_timestamp_utc"))
            or str(origin.get("pivot_timestamp_utc")) in ambiguous_times
            or str(terminal.get("pivot_timestamp_utc")) in ambiguous_times):
        return {
            "method": "confirmed_live_fractal_radius_2",
            "visible_swing_count": len(alternating),
            "latest_leg": None,
            "one_to_one_target_candidate": None,
            "one_to_one_source_leg": None,
            "projection_anchor": None,
            "projection_family": "none_ambiguous_same_bar_pivot_order",
            "retracement_observation": None,
            "status": "ambiguous_same_bar_pivot_order",
        }
    origin_price = float(origin["price"])
    terminal_price = float(terminal["price"])
    direction = _pivot_direction(origin, terminal)
    if direction is None:
        return {
            "method": "confirmed_live_fractal_radius_2",
            "visible_swing_count": len(alternating),
            "latest_leg": None,
            "one_to_one_target_candidate": None,
            "one_to_one_source_leg": None,
            "projection_anchor": None,
            "projection_family": "none_ambiguous_pivot_roles",
            "retracement_observation": None,
            "status": "ambiguous_pivot_roles",
        }
    length = abs(terminal_price - origin_price)
    source_leg = None
    projection_anchor = None
    one_to_one = None
    projection_status = "awaiting_retracement_anchor"
    if len(alternating) >= 3:
        source_origin, source_terminal, retrace = alternating[-3:]
        source_direction = _pivot_direction(source_origin, source_terminal)
        ordered = (str(source_origin.get("pivot_timestamp_utc"))
                   < str(source_terminal.get("pivot_timestamp_utc"))
                   < str(retrace.get("pivot_timestamp_utc")))
        roles_match = (
            (source_origin.get("kind"), source_terminal.get("kind"), retrace.get("kind"))
            == ("confirmed_swing_low_candidate", "confirmed_swing_high_candidate", "confirmed_swing_low_candidate")
            if source_direction == "up" else
            (source_origin.get("kind"), source_terminal.get("kind"), retrace.get("kind"))
            == ("confirmed_swing_high_candidate", "confirmed_swing_low_candidate", "confirmed_swing_high_candidate"))
        lower, upper = sorted((float(source_origin["price"]), float(source_terminal["price"])))
        inside = lower < float(retrace["price"]) < upper
        if (not ordered or any(str(item.get("pivot_timestamp_utc")) in ambiguous_times
                               for item in (source_origin, source_terminal, retrace))):
            projection_status = "ambiguous_same_bar_pivot_order"
        elif not roles_match:
            projection_status = "source_or_retracement_role_unresolved"
        elif not inside:
            projection_status = "retracement_outside_source_anchors_review_required"
        else:
            source_length = upper - lower
            one_to_one = (float(retrace["price"]) + source_length if source_direction == "up"
                          else float(retrace["price"]) - source_length)
            source_leg = {
                "origin": source_origin, "terminal": source_terminal,
                "direction_observation": source_direction, "range_points": round(source_length, 6),
            }
            projection_anchor = retrace
            projection_status = "retracement_anchored_geometric_candidate"
    retracement = (
        (terminal_price - current_close) / length
        if direction == "up" and length
        else (current_close - terminal_price) / length
        if direction == "down" and length
        else None
    )
    return {
        "method": "confirmed_live_fractal_radius_2",
        "visible_swing_count": len(alternating),
        "latest_leg": {
            "origin": origin,
            "terminal": terminal,
            "direction_observation": direction,
            "range_points": round(length, 6),
        },
        "one_to_one_target_candidate": round(one_to_one, 6) if one_to_one is not None else None,
        "one_to_one_source_leg": source_leg,
        "projection_family": ("retracement_anchored_geometric_candidate" if one_to_one is not None
                              else "none_missing_valid_retracement_anchor"),
        "projection_anchor": projection_anchor,
        "terminal_extension_reference": round(terminal_price + length if direction == "up" else terminal_price - length, 6),
        "retracement_observation": round(retracement, 6) if retracement is not None else None,
        "status": projection_status,
    }


def _candidate_wave_ledger(
    bars: Sequence[OHLCBar], *, max_bars: int = 128,
) -> dict[str, object]:
    """List every mechanically confirmed leg in the displayed closed-bar window.

    The ledger makes origins and terminals inspectable.  Radius-two pivots are
    only one geometric reading of the bars: they do not name Alexander's wave,
    a protected node, an SNR, the parent task, or an active target.
    """

    visible = list(bars[-max_bars:])
    if not visible:
        return {"status": "no_closed_bars", "bars_in_window": 0, "legs": [], "unfinished_tail": None}
    swings = _alternating_swings(_confirmed_fractal_candidates(visible))
    timeframe = visible[-1].timeframe
    legs: list[dict[str, object]] = []
    for origin, terminal in zip(swings, swings[1:]):
        origin_time = str(origin["pivot_timestamp_utc"])
        terminal_time = str(terminal["pivot_timestamp_utc"])
        origin_price = float(origin["price"])
        terminal_price = float(terminal["price"])
        legs.append({
            "leg_id": f"{timeframe}:geometric_leg:{origin_time}->{terminal_time}",
            "timeframe": timeframe,
            "origin": origin,
            "terminal": terminal,
            "direction_observation": _pivot_direction(origin, terminal) or "flat",
            "price_change_direction": "up" if terminal_price > origin_price else "down" if terminal_price < origin_price else "flat",
            "range_points": round(abs(terminal_price - origin_price), 6),
            "terminal_confirmed_at_utc": terminal["confirmed_at_utc"],
            "temporal_order": "same_bar_unresolved" if origin_time == terminal_time else "sequential_confirmed_extrema",
            "status": "geometric_candidate_not_author_named_wave",
        })
    # The first confirmed swing starts the first leg, so retain it as the
    # comparison reference even though it is not a leg terminal itself.
    prior_terminal_by_kind: dict[str, dict[str, object]] = (
        {str(swings[0]["kind"]): swings[0]} if swings else {}
    )
    structural_step_comparisons: list[dict[str, object]] = []
    for leg in legs:
        terminal = leg["terminal"]
        kind = str(terminal.get("kind") or "")
        earlier = prior_terminal_by_kind.get(kind)
        if earlier is not None and kind in {"confirmed_swing_high_candidate", "confirmed_swing_low_candidate"}:
            earlier_price = float(earlier["price"])
            present_price = float(terminal["price"])
            if kind == "confirmed_swing_high_candidate":
                comparison = "higher_high" if present_price > earlier_price else "lower_high" if present_price < earlier_price else "equal_high"
            else:
                comparison = "lower_low" if present_price < earlier_price else "higher_low" if present_price > earlier_price else "equal_low"
            structural_step_comparisons.append({
                "challenger_leg_id": leg["leg_id"],
                "timeframe": timeframe,
                "prior_same_kind_extreme": {
                    "kind": kind,
                    "pivot_timestamp_utc": earlier["pivot_timestamp_utc"],
                    "price": earlier_price,
                },
                "current_terminal": {
                    "kind": kind,
                    "pivot_timestamp_utc": terminal["pivot_timestamp_utc"],
                    "price": present_price,
                    "confirmed_at_utc": terminal["confirmed_at_utc"],
                },
                "comparison": comparison,
                "status": "same_timeframe_extreme_comparison_not_named_snr_test",
            })
        prior_terminal_by_kind[kind] = terminal
    ladder_candidates: list[dict[str, object]] = []
    for kind, relationship_names in (
        ("confirmed_swing_high_candidate", {"lower_high": "descending_highs", "higher_high": "ascending_highs"}),
        ("confirmed_swing_low_candidate", {"higher_low": "ascending_lows", "lower_low": "descending_lows"}),
    ):
        same_kind = [item for item in structural_step_comparisons
                     if item["current_terminal"]["kind"] == kind]
        if not same_kind:
            continue
        latest_relationship = str(same_kind[-1]["comparison"])
        ladder_type = relationship_names.get(latest_relationship)
        if ladder_type is None:
            continue
        run: list[dict[str, object]] = []
        for item in reversed(same_kind):
            if item["comparison"] != latest_relationship:
                break
            run.append(item)
        if len(run) < 2:
            continue
        run.reverse()
        ladder_candidates.append({
            "timeframe": timeframe,
            "kind": ladder_type,
            "source_comparison_count": len(run),
            "step_prices": [run[0]["prior_same_kind_extreme"]["price"]]
                           + [item["current_terminal"]["price"] for item in run],
            "from_utc": run[0]["prior_same_kind_extreme"]["pivot_timestamp_utc"],
            "through_utc": run[-1]["current_terminal"]["pivot_timestamp_utc"],
            "last_step_confirmed_at_utc": run[-1]["current_terminal"]["confirmed_at_utc"],
            "status": "same_timeframe_geometric_extreme_ladder_not_source_named_snr",
        })
    latest = visible[-1]
    last_swing = swings[-1] if swings else None
    return {
        "status": "confirmed_geometric_extrema_only" if legs else "insufficient_confirmed_extrema",
        "method": "radius_2_fractal_with_alternating_extrema",
        "timeframe": timeframe,
        "window_from_utc": iso_utc(visible[0].timestamp_utc),
        "window_through_utc": iso_utc(latest.timestamp_utc),
        "bars_in_window": len(visible),
        "window_left_edge_may_truncate_prior_leg": len(bars) > len(visible),
        "legs": legs,
        "structural_step_comparisons": structural_step_comparisons[-8:],
        "ladder_candidates": ladder_candidates,
        "unfinished_tail": {
            "from_confirmed_extremum": last_swing,
            "to_latest_closed_bar_utc": iso_utc(latest.timestamp_utc),
            "to_latest_close": latest.close,
            "status": "not_a_confirmed_terminal_or_named_wave",
        } if last_swing else None,
        "boundary": "每段仅为同周期已收盘 K 线的几何端点，不能据此自动命名 SNR、父任务、有效 1:1、活跃 DOL 或交易方案。",
    }


def _piecewise_close_turns(closes: Sequence[float], max_turns: int) -> list[int]:
    """Return display-scale close-path turns, not confirmed market pivots."""

    if len(closes) < 2:
        return list(range(len(closes)))
    turns = [0, len(closes) - 1]
    while len(turns) < max_turns:
        best: tuple[float, int] | None = None
        for left, right in zip(turns, turns[1:]):
            for index in range(left + 1, right):
                straight = closes[left] + (closes[right] - closes[left]) * (index - left) / (right - left)
                error = abs(closes[index] - straight)
                if best is None or error > best[0]:
                    best = (error, index)
        if best is None or best[0] <= 0:
            break
        turns.append(best[1])
        turns.sort()
    # Sampling points that continue in the same direction are not turns.
    alternating_turns = [turns[0]]
    for position in range(1, len(turns) - 1):
        previous = alternating_turns[-1]
        current = turns[position]
        following = turns[position + 1]
        before = closes[current] - closes[previous]
        after = closes[following] - closes[current]
        if before and after and before * after < 0:
            alternating_turns.append(current)
    alternating_turns.append(turns[-1])
    return alternating_turns


def _coarse_structure_context(
    bars: Sequence[OHLCBar], *, max_bars: int = 512, max_turns: int = 24,
) -> dict[str, object]:
    """Sketch the long close path before examining local candles.

    Turns and boxes are display/interpretation candidates.  A sideways box
    does not establish Wyckoff accumulation, inventory, SNR, or a target.
    The relative-price tests only select a region worth inspecting; they are
    never a trade permission threshold.
    """

    visible = list(bars[-max_bars:])
    if len(visible) < 2:
        return {"status": "insufficient_closed_history", "bars_in_window": len(visible),
                "major_turns": [], "balance_box_candidate": None,
                "balance_box_candidates": []}
    closes = [bar.close for bar in visible]
    size = len(visible)
    # On a short, choppy window, 24 turns is not a broad read at all. Grow
    # the display budget only as the visible history grows; the full-span
    # working path below remains available for every intervening excursion.
    # A D1/H4 bar spans far more market process than a minute bar. Preserve
    # the parent chart's larger set of turns even when it has fewer bars;
    # otherwise a recent high can vanish from the parent context entirely.
    coarse_turn_limit = (
        max_turns if visible[-1].timeframe in {"W1", "D1", "H4", "H1"}
        else min(max_turns, max(8, (size + 31) // 32))
    )
    turns = _piecewise_close_turns(closes, coarse_turn_limit)
    major_turns = [
        {"index": index, "timestamp_utc": iso_utc(visible[index].timestamp_utc),
         "close": visible[index].close}
        for index in turns
    ]
    major_segments = [
        {
            "start_index": origin["index"],
            "end_index": terminal["index"],
            "from_utc": origin["timestamp_utc"],
            "through_utc": terminal["timestamp_utc"],
            "origin_close": origin["close"],
            "terminal_close": terminal["close"],
            "bar_count": terminal["index"] - origin["index"],
            "price_change": round(terminal["close"] - origin["close"], 5),
            "range_points": round(abs(terminal["close"] - origin["close"]), 5),
            "direction_observation": "up" if terminal["close"] > origin["close"] else "down" if terminal["close"] < origin["close"] else "flat",
            "status": "coarse_close_path_segment_not_source_named_wave",
        }
        for origin, terminal in zip(major_turns, major_turns[1:])
    ]
    previous_same_direction: dict[str, dict[str, object]] = {}
    for segment in major_segments:
        direction = str(segment["direction_observation"])
        prior = previous_same_direction.get(direction)
        if prior is not None and direction in {"up", "down"}:
            current_range = float(segment["range_points"])
            prior_range = float(prior["range_points"])
            segment["same_direction_prior_range_points"] = prior_range
            segment["range_vs_prior_same_direction"] = (
                "larger" if current_range > prior_range else
                "smaller" if current_range < prior_range else "equal"
            )
        else:
            segment["same_direction_prior_range_points"] = None
            segment["range_vs_prior_same_direction"] = "no_prior_same_direction_segment"
        previous_same_direction[direction] = segment
    # The broad display budget deliberately favors the largest deviations.
    # Read every part of a long chart at a second, fixed-width scale so the
    # middle of a multiweek history is not silently skipped. Adjacent chunks
    # share one boundary bar, yielding a continuous path without inventing an
    # extra price move at a chunk seam.
    working_chunk_width = 256
    working_indices: list[int] = []
    for chunk_start in range(0, size - 1, working_chunk_width):
        chunk_end = min(size - 1, chunk_start + working_chunk_width)
        for local_index in _piecewise_close_turns(closes[chunk_start:chunk_end + 1], 12):
            index = chunk_start + local_index
            if not working_indices or working_indices[-1] != index:
                working_indices.append(index)
    working_turns = [
        {"index": index, "timestamp_utc": iso_utc(visible[index].timestamp_utc),
         "close": closes[index]}
        for index in working_indices
    ]
    working_segments = [
        {
            "start_index": origin["index"],
            "end_index": terminal["index"],
            "from_utc": origin["timestamp_utc"],
            "through_utc": terminal["timestamp_utc"],
            "origin_close": origin["close"],
            "terminal_close": terminal["close"],
            "bar_count": terminal["index"] - origin["index"],
            "range_points": round(abs(terminal["close"] - origin["close"]), 5),
            "direction_observation": "up" if terminal["close"] > origin["close"] else "down" if terminal["close"] < origin["close"] else "flat",
            "status": "full_span_working_close_path_not_source_named_wave",
        }
        for origin, terminal in zip(working_turns, working_turns[1:])
    ]
    # A broad line alone hides the effort and failed recoveries inside it.
    # Keep every broad leg's own closed-bar process and its nested working
    # excursions.  These are inspection facts, not an SNR/force verdict.
    for segment in major_segments:
        start, end = int(segment["start_index"]), int(segment["end_index"])
        section = visible[start:end + 1]
        pairs = list(zip(section, section[1:]))
        largest_range = max(section, key=lambda bar: bar.high - bar.low)
        largest_body = max(section, key=lambda bar: abs(bar.close - bar.open))
        direction = segment["direction_observation"]
        nested = [
            item for item in working_segments
            if start <= int(item["start_index"]) and int(item["end_index"]) <= end
        ]
        counter = [item for item in nested if item["direction_observation"] not in {direction, "flat"}]
        segment["process_evidence"] = {
            "status": "closed_bar_process_not_named_force_or_snr",
            "bars_examined": len(section),
            "highest_wick": max(bar.high for bar in section),
            "lowest_wick": min(bar.low for bar in section),
            "total_close_path_travel": round(sum(abs(right.close - left.close) for left, right in pairs), 5),
            "overlapping_adjacent_ranges": sum(
                min(left.high, right.high) > max(left.low, right.low) for left, right in pairs
            ),
            "adjacent_pairs": len(pairs),
            "closes_through_previous_extreme_in_leg_direction": sum(
                (right.close > left.high if direction == "up" else right.close < left.low)
                for left, right in pairs
            ) if direction in {"up", "down"} else 0,
            "closes_through_previous_extreme_against_leg_direction": sum(
                (right.close < left.low if direction == "up" else right.close > left.high)
                for left, right in pairs
            ) if direction in {"up", "down"} else 0,
            "largest_range_bar": {
                "timestamp_utc": iso_utc(largest_range.timestamp_utc),
                "open": largest_range.open, "high": largest_range.high,
                "low": largest_range.low, "close": largest_range.close,
                "range_points": round(largest_range.high - largest_range.low, 5),
            },
            "largest_body_bar": {
                "timestamp_utc": iso_utc(largest_body.timestamp_utc),
                "open": largest_body.open, "high": largest_body.high,
                "low": largest_body.low, "close": largest_body.close,
                "body_points": round(abs(largest_body.close - largest_body.open), 5),
            },
            "nested_working_legs": nested,
            "counter_legs": counter,
            "boundary": "区间、重叠、最大单根与内部反向腿须结合所到结构/目标和随后收盘解读；计数不能直接命名力度、低流动性、SNR 或趋势。",
        }
    # A full multi-week compression can legitimately devote most of its
    # points to older large swings.  Preserve a separate right-edge read so
    # the currently contested area is not flattened into one long line.
    detail_window = min(384, len(visible))
    detail_offset = len(visible) - detail_window
    detail_indices = _piecewise_close_turns(closes[detail_offset:], 18)
    recent_detail_turns = [
        {
            "index": detail_offset + index,
            "timestamp_utc": iso_utc(visible[detail_offset + index].timestamp_utc),
            "close": closes[detail_offset + index],
        }
        for index in detail_indices
    ]
    recent_detail_segments = [
        {
            "from_utc": origin["timestamp_utc"],
            "through_utc": terminal["timestamp_utc"],
            "origin_close": origin["close"],
            "terminal_close": terminal["close"],
            "bar_count": terminal["index"] - origin["index"],
            "direction_observation": "up" if terminal["close"] > origin["close"] else "down" if terminal["close"] < origin["close"] else "flat",
            "status": "recent_close_path_detail_not_source_named_wave",
        }
        for origin, terminal in zip(recent_detail_turns, recent_detail_turns[1:])
    ]
    scale_views: list[dict[str, object]] = []
    for label, scale_turn_limit in (("broad", 4), ("working", max_turns), ("fine", 48)):
        scale_turns = _piecewise_close_turns(closes, scale_turn_limit)
        origin_index = scale_turns[-2]
        terminal_index = scale_turns[-1]
        change = closes[terminal_index] - closes[origin_index]
        scale_views.append({
            "scale": label,
            "max_sample_points": scale_turn_limit,
            "turn_count": len(scale_turns),
            "last_segment_origin_index": origin_index,
            "last_segment_origin_utc": iso_utc(visible[origin_index].timestamp_utc),
            "last_segment_origin_close": closes[origin_index],
            "last_segment_terminal_utc": iso_utc(visible[terminal_index].timestamp_utc),
            "last_segment_terminal_close": closes[terminal_index],
            "last_segment_direction": "up" if change > 0 else "down" if change < 0 else "flat",
            "status": "compression_scale_candidate_not_named_wave",
        })
    scale_directions = {view["last_segment_direction"] for view in scale_views if view["last_segment_direction"] != "flat"}
    scale_relation = "opposed_or_nested_last_segments" if len(scale_directions) > 1 else "same_direction_at_tested_scales"

    candidates: list[tuple[float, int, int, dict[str, object]]] = []
    for length in (32, 64, 128, 256):
        if length > size:
            continue
        # Inspect the whole visible path, not only three windows near its
        # right edge: a prior range can explain a later departure/retest.
        scan_ends = set(range(length, size + 1, max(8, length // 4))) | {size}
        for end in sorted(scan_ends):
            start = end - length
            if start < 0 or end <= 0:
                continue
            section = visible[start:end]
            path = closes[start:end]
            close_low, close_high = min(path), max(path)
            span = close_high - close_low
            if span <= 0:
                continue
            centre = (close_low + close_high) / 2
            crossings = sum((a < centre <= b) or (b < centre <= a) for a, b in zip(path, path[1:]))
            lower_visits = sum(value <= close_low + span / 4 for value in path)
            upper_visits = sum(value >= close_high - span / 4 for value in path)
            edge_sequence: list[str] = []
            for value in path:
                edge = "lower" if value <= close_low + span / 4 else "upper" if value >= close_high - span / 4 else None
                if edge and (not edge_sequence or edge != edge_sequence[-1]):
                    edge_sequence.append(edge)
            edge_traversals = max(0, len(edge_sequence) - 1)
            travelled = sum(abs(b - a) for a, b in zip(path, path[1:]))
            efficiency = abs(path[-1] - path[0]) / travelled if travelled else 1.0
            if (crossings < 3 or lower_visits < 2 or upper_visits < 2
                    or efficiency > 0.4 or (length >= 64 and edge_traversals < 2)):
                continue
            box = {
                "start_index": start, "end_index": end - 1,
                "bars_since_box_end": size - end,
                "window_role": "includes_latest_closed_bar" if end == size else "historical_window",
                "from_utc": iso_utc(section[0].timestamp_utc),
                "through_utc": iso_utc(section[-1].timestamp_utc),
                "price_low": min(bar.low for bar in section),
                "price_high": max(bar.high for bar in section),
                "close_low": close_low, "close_high": close_high,
                "centre_crossings": crossings,
                "edge_traversals": edge_traversals,
                "lower_side_closes": lower_visits, "upper_side_closes": upper_visits,
                "path_efficiency": round(efficiency, 4),
                "latest_close_relation": (
                    "above" if closes[-1] > max(bar.high for bar in section)
                    else "below" if closes[-1] < min(bar.low for bar in section)
                    else "inside"
                ),
                "status": "geometric_balance_candidate_not_accumulation",
            }
            score = crossings * (1 - efficiency) / (length ** 0.5)
            candidates.append((score, end, length, box))
    # A visually stronger old range must not hide a weaker but still valid
    # present-window candidate.  If none includes the latest closed bar,
    # retain the old region explicitly as historical context.
    current_candidates = [item for item in candidates if item[1] == size]
    pool = current_candidates or candidates
    chosen = max(pool, key=lambda item: (item[0], item[1], item[2]))[3] if pool else None
    distinct_boxes: list[dict[str, object]] = []
    if chosen is not None:
        distinct_boxes.append(chosen)
    for _, _, _, box in sorted(candidates, key=lambda item: (item[0], item[1], item[2]), reverse=True):
        if len(distinct_boxes) >= 6:
            break
        start, end = int(box["start_index"]), int(box["end_index"])
        if any(
            max(0, min(end, int(prior["end_index"])) - max(start, int(prior["start_index"])) + 1)
            / min(end - start + 1, int(prior["end_index"]) - int(prior["start_index"]) + 1) > 0.25
            for prior in distinct_boxes
        ):
            continue
        distinct_boxes.append(box)
    def inspection_region(purpose: str, centre: int, before: int, after: int) -> dict[str, object]:
        first = max(0, centre - before)
        last = min(size - 1, centre + after)
        return {
            "purpose": purpose,
            "representation": "closed_ohlc_candles",
            "start_index": first,
            "end_index": last,
            "from_utc": iso_utc(visible[first].timestamp_utc),
            "through_utc": iso_utc(visible[last].timestamp_utc),
            "bar_count": last - first + 1,
        }

    # Choose where the *next inspection* should zoom. This is deliberately
    # separate from the market verdict: a geometric turn or box can direct
    # attention, but cannot itself establish a wave, SNR, or accumulation.
    focal_regions: list[dict[str, object]] = []
    if len(turns) >= 2:
        focal_regions.append(inspection_region("latest_coarse_leg_origin_candidate", turns[-2], 8, 12))
    if chosen is not None:
        box_start = int(chosen["start_index"])
        box_end = int(chosen["end_index"])
        if chosen["window_role"] == "includes_latest_closed_bar":
            box_closes = closes[box_start:box_end + 1]
            band = (float(chosen["close_high"]) - float(chosen["close_low"])) / 4
            for edge, matches in (
                ("lower", [box_start + i for i, value in enumerate(box_closes)
                           if value <= float(chosen["close_low"]) + band]),
                ("upper", [box_start + i for i, value in enumerate(box_closes)
                           if value >= float(chosen["close_high"]) - band]),
            ):
                if matches:
                    focal_regions.append(inspection_region(f"current_box_last_{edge}_edge_visit", matches[-1], 4, 4))
        else:
            focal_regions.append(inspection_region("historical_box_departure_candidate", box_end, 4, 12))
    for box in distinct_boxes[1:]:
        # Keep other separated regions available for source/structure review.
        # They must not replace the current box or appear as live accumulation.
        focal_regions.append(inspection_region(
            "other_historical_box_departure_candidate", int(box["end_index"]), 4, 12,
        ))
    focal_regions.append(inspection_region("latest_closed_candles_for_force_and_acceptance", size - 1, 23, 0))
    # Keep the visual decision explicit and machine-readable.  The engine is
    # allowed to choose the representation; the user is not required to draw
    # boxes before the system can inspect a chart.  Each later step narrows
    # the field of view, but never upgrades a geometric candidate into a
    # source-bound SNR, named wave, or trading permission.
    visual_read_method = {
        "status": "self_selected_coarse_to_fine",
        "ordered_steps": [
            {
                "step": 1,
                "name": "远景折线",
                "representation": "complete_closed_close_path",
                "bars": size,
                "purpose": "先看整段背景、主要转折和走势是否处于扩张或横向反复",
            },
            {
                "step": 2,
                "name": "波段与区间框",
                "representation": "piecewise_turns_and_separated_balance_boxes",
                "segment_count": len(major_segments),
                "box_count": len(distinct_boxes),
                "purpose": "把可能的每一段起止及互不重叠的反复区分开，不把所有方框合并成一个积累",
            },
            {
                "step": 3,
                "name": "局部 K 线复核",
                "representation": "closed_ohlc_candles",
                "region_count": len(focal_regions),
                "purpose": "只在关键端点、框边和最新收盘处检查力度、扫荡、收盘接受与后续跟随",
            },
            {
                "step": 4,
                "name": "来源对象绑定",
                "representation": "source_chart_object_or_user_annotation",
                "purpose": "最后才把真实浅绿 SNR、OB/FVG、目标与所属结构周期绑定；没有来源证据就保留未知",
            },
        ],
        "current_focus": focal_regions[0]["purpose"] if focal_regions else "等待足够的已收盘历史",
        "granularity_policy": "先粗后细；只在结构端点和最新反应处放大，不用整段细 K 线噪声替代背景",
        # Keep the result of the visual selection next to the recipe.  This is
        # deliberately a geometry readout (not a trend, accumulation, SNR or
        # trade verdict) so the UI can tell the operator what the system chose
        # to look at before exposing the detailed candle evidence.
        "selection": {
            "background_read": (
                "长、中、短三种压缩尺度的最近段方向不同，先检查嵌套回调、再定价或结构替换"
                if scale_relation == "opposed_or_nested_last_segments"
                else "长、中、短三种压缩尺度的最近段暂时同向，但这里只是整段几何观察"
            ),
            "latest_coarse_leg": major_segments[-1] if major_segments else None,
            "selected_range": chosen,
            "first_zoom": focal_regions[0] if focal_regions else None,
            "readout_boundary": "这些是系统选择的观察对象；波段、积累、SNR 和目标仍须按来源与收盘证据分别命名。",
        },
        "boundary": "折线、波段和方框是系统选择的观察工具，不是趋势、积累、SNR 或下单许可本身。",
    }
    return {
        "status": "coarse_close_path_only",
        "timeframe": visible[-1].timeframe,
        "window_from_utc": iso_utc(visible[0].timestamp_utc),
        "window_through_utc": iso_utc(visible[-1].timestamp_utc),
        "bars_in_window": size,
        "coarse_turn_display_budget": coarse_turn_limit,
        "window_left_edge_may_truncate_prior_structure": len(bars) > size,
        "major_turns": major_turns,
        "major_segments": major_segments,
        "full_span_detail": {
            "status": "full_span_working_close_path_not_source_named_wave",
            "window_from_utc": iso_utc(visible[0].timestamp_utc),
            "window_through_utc": iso_utc(visible[-1].timestamp_utc),
            "bars_in_window": size,
            "chunk_width_bars": working_chunk_width,
            "turns": working_turns,
            "segments": working_segments,
            "boundary": "中景分段覆盖整段历史，只是逐处放大入口；不能单凭折线命名结构波浪、SNR、积累或目标。",
        },
        "recent_detail": {
            "status": "right_edge_close_path_detail_not_source_named_wave",
            "window_from_utc": iso_utc(visible[detail_offset].timestamp_utc),
            "window_through_utc": iso_utc(visible[-1].timestamp_utc),
            "bars_in_window": detail_window,
            "turns": recent_detail_turns,
            "segments": recent_detail_segments,
            "boundary": "右侧细分只解释近期内部往返；不覆盖全图粗波段，也不把每一小段自动当作结构转变。",
        },
        "scale_comparison": {
            "status": "geometric_scale_sensitivity_not_trend_vote",
            "views": scale_views,
            "relation": scale_relation,
            "boundary": "长中短压缩尺度若指向不同方向，只说明波段划法依赖观察尺度；不能按多数票选市场趋势，也不能由此确认父任务、SNR 或反转。",
        },
        "balance_box_candidate": chosen,
        "balance_box_candidates": distinct_boxes,
        "inspection_plan": {
            "status": "view_selection_candidate_not_market_verdict",
            "broad_view": {
                "representation": "complete_closed_close_path",
                "from_utc": iso_utc(visible[0].timestamp_utc),
                "through_utc": iso_utc(visible[-1].timestamp_utc),
                "bars_in_window": size,
            },
            "focal_regions": focal_regions,
            "boundary": "系统自行选长段与局部复核位置；粗折线只定位波段/区间候选，细 K 还需核对力度、扫荡、收盘、跟进及所属周期，不自动命名 SNR/目标或准许交易。",
        },
        "visual_read_method": visual_read_method,
        "boundary": "折线大波段和横向反复框只提示先看哪里；积累/派发要回到父级目标、位置、扫荡、离开力度与后续接受，不能由盒子形状断言。",
    }


def _candidate_target_touch_observation(
    bars: Sequence[OHLCBar], measurement: dict[str, object],
) -> dict[str, object]:
    """Observe a measured level only after its leg became knowable.

    A touched 1:1 *candidate* is not an active DOL or a completed parent task.
    The observation is bounded to loaded, closed bars and does not imply that
    missing broker history was checked.
    """

    leg = measurement.get("one_to_one_source_leg") or {}
    anchor = measurement.get("projection_anchor") or {}
    confirmed_at = anchor.get("confirmed_at_utc")
    target = measurement.get("one_to_one_target_candidate")
    direction = leg.get("direction_observation")
    if (measurement.get("projection_family") != "retracement_anchored_geometric_candidate"
            or not confirmed_at or not isinstance(target, (int, float))
            or direction not in {"up", "down"}):
        return {"status": "candidate_or_confirmation_unavailable", "first_touch_bar_utc": None}
    visible_from = parse_utc(str(confirmed_at))
    eligible = [bar for bar in bars if parse_utc(bar.timestamp_utc) >= visible_from]
    first_touch = next(
        (bar for bar in eligible if bar.high >= target), None
    ) if direction == "up" else next(
        (bar for bar in eligible if bar.low <= target), None
    )
    return {
        "status": (
            "touched_in_loaded_closed_bars" if first_touch
            else "not_touched_in_loaded_closed_bars" if eligible
            else "no_closed_bars_after_confirmation"
        ),
        "candidate_level": target,
        "candidate_direction": direction,
        "projection_anchor_confirmed_at_utc": iso_utc(visible_from),
        "observed_bar_count_after_confirmation": len(eligible),
        "first_touch_bar_utc": iso_utc(first_touch.timestamp_utc) if first_touch else None,
        "last_observed_bar_utc": iso_utc(eligible[-1].timestamp_utc) if eligible else None,
        "boundary": "仅核对已载入且在回调锚点确认后收盘的同周期 K 线；触价不等于 active DOL、父任务完成或交易许可。",
    }


def _candidate_origin_side_close_observation(
    bars: Sequence[OHLCBar], measurement: dict[str, object], *, leg_key: str = "latest_leg",
) -> dict[str, object]:
    """Track own-timeframe closes across a measured leg's old origin.

    This questions whether an old measurement can still describe current
    delivery.  It does not identify a protected node, parent task, structural
    reversal, or a new direction.
    """

    leg = measurement.get(leg_key) or {}
    origin = leg.get("origin") or {}
    terminal = leg.get("terminal") or {}
    origin_price = origin.get("price")
    confirmed_at = terminal.get("confirmed_at_utc")
    direction = leg.get("direction_observation")
    if (
        not isinstance(origin_price, (int, float)) or isinstance(origin_price, bool)
        or not confirmed_at or direction not in {"up", "down"}
    ):
        return {"status": "candidate_or_confirmation_unavailable", "first_beyond_origin_bar_utc": None}
    visible_from = parse_utc(str(confirmed_at))
    eligible = [bar for bar in bars if parse_utc(bar.timestamp_utc) >= visible_from]
    beyond = [
        bar for bar in eligible
        if (bar.close < origin_price if direction == "up" else bar.close > origin_price)
    ]
    latest = eligible[-1] if eligible else None
    latest_beyond = latest in beyond if latest is not None else False
    return {
        "status": (
            "no_closed_bars_after_confirmation" if latest is None
            else "latest_same_timeframe_close_beyond_old_origin" if latest_beyond
            else "earlier_close_beyond_origin_later_back_on_leg_side" if beyond
            else "no_close_beyond_origin_in_loaded_closed_bars"
        ),
        "origin_price": origin_price,
        "candidate_direction": direction,
        "leg_confirmed_at_utc": iso_utc(visible_from),
        "observed_bar_count_after_confirmation": len(eligible),
        "first_beyond_origin_bar_utc": iso_utc(beyond[0].timestamp_utc) if beyond else None,
        "latest_closed_bar_utc": iso_utc(latest.timestamp_utc) if latest else None,
        "latest_closed_price": latest.close if latest else None,
        "boundary": "只记录旧测量腿确认后、同一周期的收盘与起点位置；不自动宣告父任务失效、结构反转、DOL 完成或交易方向。",
    }


def _three_push_candidate_quality(
    bars: Sequence[OHLCBar], sequence: Sequence[dict], first_base: dict,
    *, _bar_index: dict[str, int] | None = None,
) -> dict | None:
    """Screen the user's overlapping, balanced three-push (not harmonic).

    Numeric cutoffs are provisional implementation tolerances, not Alexander
    quotations or calibrated probabilities. OHLC overlap/urgency is only a
    price-behaviour proxy; neither volume nor candles establish liquidity depth.
    Baselines use bars before each push, never bars after the third pivot.
    """
    if len(sequence) != 5 or not bars:
        return None
    points = [first_base, *sequence]
    kinds = [p.get("kind") for p in points]
    low, high = "confirmed_swing_low_candidate", "confirmed_swing_high_candidate"
    if kinds not in ([low, high]*3, [high, low]*3):
        return None
    index = (_bar_index if _bar_index is not None else
             {iso_utc(b.timestamp_utc): i for i, b in enumerate(bars)})
    positions = [index.get(str(p.get("pivot_timestamp_utc"))) for p in points]
    if any(i is None for i in positions) or any(a >= b for a, b in zip(positions, positions[1:])):
        return None
    prices = [float(p["price"]) for p in points]
    if not all(math.isfinite(p) for p in prices):
        return None
    used = bars[positions[0]:positions[-1]+1]
    if len({b.timeframe for b in used}) != 1 or any(
        not all(math.isfinite(v) for v in (b.open, b.high, b.low, b.close))
        or b.high < max(b.open, b.close) or b.low > min(b.open, b.close) for b in used
    ):
        return None
    for p, i, kind in zip(prices, positions, kinds):
        if not math.isclose(p, bars[i].low if kind == low else bars[i].high, abs_tol=1e-7):
            return None
    sign = 1 if kinds[0] == low else -1
    amplitudes = [sign*(prices[i+1]-prices[i]) for i in (0, 2, 4)]
    if min(amplitudes) <= 0 or max(amplitudes)/min(amplitudes) > 2.0 + 1e-9:
        return None
    typical_push = statistics.median(amplitudes)
    bases = prices[::2]
    tips = prices[1::2]
    centres = [(a+b)/2 for a, b in zip(bases, tips)]
    centre_advances = [sign*(b-a)/typical_push for a, b in zip(centres, centres[1:])]
    tip_advances = [sign*(b-a)/typical_push for a, b in zip(tips, tips[1:])]
    base_advances = [sign*(b-a)/typical_push for a, b in zip(bases, bases[1:])]
    # Overlap alone also describes a horizontal range. All three push zones
    # must migrate in their push direction, not just make tiny new extremes.
    # Measure in native price/push units, not screen angle or chart zoom.
    if (min(centre_advances) < .12 or sum(centre_advances) < .45
            or min(tip_advances) < .08 or sum(tip_advances) < .45
            or min(base_advances) < -.15):
        return None
    ranges = [sorted(prices[i:i+2]) for i in (0, 2, 4)]
    overlaps = [(min(a[1], b[1])-max(a[0], b[0])) / min(a[1]-a[0], b[1]-b[0])
                for a, b in zip(ranges, ranges[1:])]
    # One small miss is tolerated; three disconnected drives are not a cluster.
    if min(overlaps) < -.12 or max(overlaps) < .50 or statistics.mean(overlaps) < .35-1e-9:
        return None
    observations = []
    for j in (0, 2, 4):
        start, end = positions[j:j+2]
        prior = [b.range for b in bars[max(0, start-20):start] if b.range > 0]
        if len(prior) < 5:
            return None
        baseline = statistics.median(prior)
        segment = bars[start:end+1]
        # A sharp bar is allowed, but the declared leg must contain its own
        # native highs/lows. Do not hide an earlier extreme behind false tips.
        lo, hi = ranges[j//2]
        if any(b.low < lo-1e-7 or b.high > hi+1e-7 for b in segment):
            return None
        steps = [b.close-a.close for a, b in zip(segment, segment[1:])]
        travel = sum(abs(s) for s in steps)
        efficiency = abs(segment[-1].close-segment[0].close)/travel if travel else 0
        speed = amplitudes[j//2]/(end-start)/baseline
        dominant = sum(sign*(b.close-b.open) > 0 and b.body >= .5*b.range for b in segment[1:])
        force = (speed >= .70 and efficiency >= .68
                 and sum(sign*s > 0 for s in steps)/len(steps) >= .65 and dominant >= 2)
        spike = any(b.range >= 2*baseline and b.body >= .65*b.range for b in segment)
        local_overlap = statistics.mean(
            max(0, min(a.high, b.high)-max(a.low, b.low))/max(min(a.range, b.range), 1e-9)
            for a, b in zip(segment, segment[1:]))
        observations.append({"origin_utc": iso_utc(segment[0].timestamp_utc),
            "terminal_utc": iso_utc(segment[-1].timestamp_utc), "bar_count": end-start,
            "speed_to_prior_range": round(speed, 4), "bar_overlap": round(local_overlap, 4),
            "urgent_drive_observed": force, "large_body_bar_observed": spike})

    # The three internal 1:1 readings are competing location hypotheses.  They
    # are deliberately calculated from the three closed legs only; no later
    # candle is allowed to choose a route or turn a location into an entry.
    # This is the same distinction used by Wells4/W5: a ratio is a place to
    # watch, while own-C, parent-window completion, protected-liquidity sweep,
    # reclaim, retest and follow-through are separate gates.
    third_origin = ranges[2][1] if sign == -1 else ranges[2][0]
    third_terminal = prices[5]
    route_sizes = {
        "equal_each": statistics.median(amplitudes[:2]),
        "first_two_to_third": amplitudes[0] + amplitudes[1],
        "first_to_last_two": amplitudes[0] - amplitudes[1],
    }
    route_labels = {
        "equal_each": "等腿 P1≈P2≈P3",
        "first_two_to_third": "前两腿合计≈第三腿",
        "first_to_last_two": "第一腿≈后两腿",
    }
    expected_direct_parent_timeframe = {
        'M1': 'M5', 'M5': 'M15', 'M15': 'M30', 'M30': 'H1',
        'H1': 'H4', 'H4': 'D1', 'D1': 'W1', 'W1': None,
    }.get(used[0].timeframe)
    ratio_locations = []
    for route_id, expected_size in route_sizes.items():
        usable = bool(math.isfinite(expected_size) and expected_size > 0)
        projected = third_origin + sign * expected_size if usable else None
        residual = abs(amplitudes[2] - expected_size) if usable else None
        residual_ratio = residual / expected_size if usable else None
        if not usable:
            phase = "not_usable"
        elif sign == -1:
            phase = ("pending" if projected < third_terminal - 1e-9 else
                     "at_current_terminal" if math.isclose(projected, third_terminal, abs_tol=1e-9)
                     else "already_reached_or_passed")
        else:
            phase = ("pending" if projected > third_terminal + 1e-9 else
                     "at_current_terminal" if math.isclose(projected, third_terminal, abs_tol=1e-9)
                     else "already_reached_or_passed")
        ratio_locations.append({
            "route_id": route_id,
            "label": route_labels[route_id],
            "expected_third_amplitude": round(expected_size, 8) if usable else None,
            "projected_price": round(projected, 8) if usable else None,
            "actual_third_amplitude": round(amplitudes[2], 8),
            "residual": round(residual, 8) if residual is not None else None,
            "residual_ratio": round(residual_ratio, 8) if residual_ratio is not None else None,
            "projection_phase": phase,
            "status": "location_candidate" if usable else "not_usable",
        })
    connecting_returns = [
        {
            "from_utc": iso_utc(bars[positions[j + 1]].timestamp_utc),
            "to_utc": iso_utc(bars[positions[j + 2]].timestamp_utc),
            "bar_count": max(0, positions[j + 2] - positions[j + 1]),
            "status": "observed_native_connector",
        }
        for j in (0, 2)
    ]
    return_lengths = [abs(prices[j + 2] - prices[j + 1]) for j in (0, 2)]
    return_prior_ratios = [return_lengths[i] / amplitudes[i + 0]
                           for i in range(2)]
    push_seconds = [
        max(1.0, (positions[j + 1] - positions[j]) *
            TIMEFRAME_MINUTES[used[0].timeframe] * 60.0)
        for j in (0, 2, 4)
    ]
    wave_ratio_observation = quantify_three_pushes(
        amplitudes, return_lengths, push_seconds, return_prior_ratios)
    future_locations = [row for row in ratio_locations if row["projection_phase"] in {"pending", "at_current_terminal"}]
    if future_locations:
        ratio_lifecycle = "future_location_available"
    elif any(row["projection_phase"] == "at_current_terminal" for row in ratio_locations):
        ratio_lifecycle = "at_current_terminal"
    elif any(row["projection_phase"] == "already_reached_or_passed" for row in ratio_locations):
        ratio_lifecycle = "all_feasible_locations_reached_or_passed"
    else:
        ratio_lifecycle = "no_usable_ratio_location"
    return {"pattern_status": "balanced_overlapping_directional_candidate",
            "classification": "three_push_candidate",
            "three_wave_status": "not_evaluated",
            "method_version": "nested_balanced_three_push_v4", "timeframe": used[0].timeframe,
            "push_count": 3, "push_amplitudes": amplitudes, "push_ranges": ranges,
            "amplitude_ratio": max(amplitudes)/min(amplitudes),
            "maximum_amplitude_ratio": 2.0,
            "balance_score": min(amplitudes)/max(amplitudes),
            "adjacent_overlap_ratios": overlaps, "overlap_pair_count": sum(v > 0 for v in overlaps),
            "directional_progression": {"centre_advances_to_typical_push": centre_advances,
                "tip_advances_to_typical_push": tip_advances,
                "base_advances_to_typical_push": base_advances,
                "total_centre_advance_to_typical_push": sum(centre_advances),
                "total_tip_advance_to_typical_push": sum(tip_advances),
                "horizontal_oscillation_excluded": True},
            "push_observations": observations, "local_urgency_is_veto": False,
            "local_urgent_push_count": sum(o["urgent_drive_observed"] or o["large_body_bar_observed"] for o in observations),
            "liquidity_measured": False, "liquidity_evidence": "overlap_and_urgency_proxy_only",
            "threshold_status": "provisional_visual_filter_not_calibrated",
            "geometry_status": "valid_ordered_three_push",
            "push_connection": {
                "status": "three_connected_native_legs_candidate",
                "native_timeframe": used[0].timeframe,
                "pushes_are_connected": True,
                "connecting_returns": connecting_returns,
                "structural_degree_adjudicated": False,
                "used_as_admission_gate": False,
            },
            "ratio_projection": {
                "locations": ratio_locations,
                "lifecycle": ratio_lifecycle,
                "selected_hypothesis": None,
                "selection_status": "not_selected",
                "future_entry_zone_candidates": future_locations,
            },
            "wave_ratio_observation": wave_ratio_observation,
            "context_gates": {
                "parent_window": "unknown_not_bound_in_native_candidate",
                "expected_direct_parent_timeframe": expected_direct_parent_timeframe,
                "own_c": "unknown",
                "protected_liquidity": "not_measured",
                "p3_exhaustion": "unknown",
                "entity_reclaim": "unknown",
                "retest_hold": "unknown",
                "follow_through": "unknown",
            },
            "third_push_response": {
                "pierce_reference_bar_id": None,
                "pierce_status": "unknown",
                "same_period_close_acceptance": "unknown",
                "reclaim_state": "unknown",
                "retest_hold": "unknown",
                "new_force_after_reclaim": "unknown",
            },
            "state_trace": [
                {"gate": "geometry", "status": "confirmed"},
                {"gate": "balance_and_overlap", "status": "observed_proxy"},
                {"gate": "parent_window", "status": "unknown"},
                {"gate": "own_c", "status": "unknown"},
                {"gate": "protected_liquidity_sweep", "status": "unknown"},
                {"gate": "p3_exhaustion_and_reclaim", "status": "unknown"},
                {"gate": "retest_hold_and_follow_through", "status": "unknown"},
                {"gate": "entry_route", "status": "not_selected"},
            ],
            "state": "candidate",
            "trade_permission": False,
            "entry_permission": False,
            "direct_flip_forbidden": True}


def _multiscale_three_push_candidates(bars: Sequence[OHLCBar]) -> list[dict]:
    """Keep nested native patterns; a coarse swing never replaces a local one.

    Radius controls pivot confirmation scale, not candle timeframe. Every
    scale is checked against the same native OHLC and the same quality rule.
    Identical six-anchor patterns are deduplicated at their earliest scale.
    """
    if not bars:
        return []
    direct_parent_timeframe = {
        'M1': 'M5', 'M5': 'M15', 'M15': 'M30', 'M30': 'H1',
        'H1': 'H4', 'H4': 'D1', 'D1': 'W1', 'W1': None,
    }.get(bars[-1].timeframe)
    bar_index = {iso_utc(bar.timestamp_utc): i for i, bar in enumerate(bars)}
    candidates = {}
    for radius in (2, 4, 8, 16, 32):
        ordered = _alternating_swings(_confirmed_fractal_candidates(bars, radius=radius))
        for start in range(len(ordered)-5):
            anchors = ordered[start:start+6]
            key = tuple((p.get('pivot_timestamp_utc'), p.get('kind'), p.get('price')) for p in anchors)
            if key in candidates:
                candidates[key]['pivot_radii'].append(radius)
                continue
            quality = _three_push_candidate_quality(bars, anchors[1:], anchors[0], _bar_index=bar_index)
            if quality is None:
                continue
            direction = 'up' if anchors[0]['kind'] == 'confirmed_swing_low_candidate' else 'down'
            tips = anchors[1::2]
            identity = hashlib.sha256(json.dumps([bars[-1].timeframe, key], separators=(',', ':')).encode()).hexdigest()[:20]
            candidates[key] = dict(
                pattern_id=f'{bars[-1].timeframe}:three-push:{identity}',
                kind=f'three_push_{direction}_candidate', timeframe=bars[-1].timeframe,
                quality=quality, push_prices=[p['price'] for p in tips],
                pivot_timestamps_utc=[p['pivot_timestamp_utc'] for p in tips],
                anchors=anchors, from_utc=anchors[0]['pivot_timestamp_utc'],
                through_utc=anchors[-1]['pivot_timestamp_utc'],
                known_at_utc=max((p.get('confirmed_at_utc') or p['pivot_timestamp_utc']) for p in anchors),
                pivot_radii=[radius], parent_pattern_id=None, child_pattern_ids=[],
                status='candidate_not_terminal_pattern',
                required_context=['regime', 'location', 'parent_task', 'post_third_response'])
    rows = sorted(candidates.values(), key=lambda row: (row['through_utc'], row['from_utc']))
    for child in rows:
        enclosing = [parent for parent in rows if parent is not child
            and parent['kind'] == child['kind']
            and parent['from_utc'] <= child['from_utc'] and parent['through_utc'] >= child['through_utc']
            and (parent['from_utc'], parent['through_utc']) != (child['from_utc'], child['through_utc'])
            and statistics.median(parent['quality']['push_amplitudes']) > statistics.median(child['quality']['push_amplitudes'])]
        if enclosing:
            parent = min(enclosing, key=lambda row: bar_index[row['through_utc']]-bar_index[row['from_utc']])
            child['parent_pattern_id'] = parent['pattern_id']
            parent['child_pattern_ids'].append(child['pattern_id'])
    for row in rows:
        row['scale_role'] = ('middle' if row['parent_pattern_id'] and row['child_pattern_ids'] else
                             'inner' if row['parent_pattern_id'] else 'outer' if row['child_pattern_ids'] else 'standalone')
        # A same-period nested parent is a scale relation, not the direct
        # higher-timeframe pullback task required by Wells4/W5.  Keep that
        # distinction explicit so the renderer cannot mistake an outer M5
        # candidate for an M15 parent window.
        row['nested_scope'] = {
            'same_period_parent_id': row['parent_pattern_id'],
            'same_period_child_ids': list(row['child_pattern_ids']),
            'same_period_role': row['scale_role'],
            'expected_direct_parent_timeframe': direct_parent_timeframe,
            'direct_parent_timeframe': None,
            'direct_parent_binding': 'not_bound_in_native_candidate',
        }
    return rows


def _candidate_price_action_objects(
    bars: Sequence[OHLCBar],
    *,
    lookback: int = 20,
) -> dict[str, object]:
    """Extract closed-bar price-action objects without naming their meaning.

    These are deliberately mechanical *candidates*: a three-bar imbalance is
    not automatically an ICT FVG, a body-dominant bar is not automatically a
    displacement leg, and a close outside the previous bar is not automatic
    acceptance.  The objects carry timestamps and a cutoff so the theory
    layer can compare them with parent tasks, targets and competing paths.
    """

    if not bars:
        return {
            "imbalance_candidates": [],
            "displacement_candidates": [],
            "close_acceptance_candidates": [],
            "status": "no_closed_bars",
        }
    source = list(bars[-max(lookback + 2, 3):])
    imbalance_candidates: list[dict[str, object]] = []
    for left, _middle, right in zip(source, source[1:], source[2:]):
        if right.low > left.high:
            imbalance_candidates.append({
                "kind": "bullish_imbalance_candidate",
                "lower": left.high,
                "upper": right.low,
                "origin_left_timestamp_utc": iso_utc(left.timestamp_utc),
                "origin_right_timestamp_utc": iso_utc(right.timestamp_utc),
                "status": "candidate_not_named_fvg",
                "fill_state": "unknown",
            })
        elif right.high < left.low:
            imbalance_candidates.append({
                "kind": "bearish_imbalance_candidate",
                "lower": right.high,
                "upper": left.low,
                "origin_left_timestamp_utc": iso_utc(left.timestamp_utc),
                "origin_right_timestamp_utc": iso_utc(right.timestamp_utc),
                "status": "candidate_not_named_fvg",
                "fill_state": "unknown",
            })

    baseline = [bar.range for bar in source[:-1] if bar.range > 0]
    median_range = statistics.median(baseline) if baseline else None
    latest = source[-1]
    displacement_candidates: list[dict[str, object]] = []
    # Qualitative body-dominance avoids a hard ATR/percentage threshold.
    if latest.range > 0 and latest.body > (latest.upper_wick + latest.lower_wick):
        displacement_candidates.append({
            "kind": "body_dominant_force_candidate",
            "direction_observation": "up" if latest.close > latest.open else "down" if latest.close < latest.open else "flat",
            "timestamp_utc": iso_utc(latest.timestamp_utc),
            "range": latest.range,
            "body": latest.body,
            "range_vs_recent_median": _safe_ratio(latest.range, median_range or 0.0),
            "status": "candidate_not_confirmed_displacement",
            "required_follow_through": True,
        })

    close_acceptance_candidates: list[dict[str, object]] = []
    if len(source) >= 2:
        previous = source[-2]
        if latest.close > previous.high:
            close_acceptance_candidates.append({
                "kind": "close_outside_previous_high_candidate",
                "direction_observation": "up",
                "timestamp_utc": iso_utc(latest.timestamp_utc),
                "reference": previous.high,
                "status": "candidate_acceptance_needs_follow_through",
            })
        elif latest.close < previous.low:
            close_acceptance_candidates.append({
                "kind": "close_outside_previous_low_candidate",
                "direction_observation": "down",
                "timestamp_utc": iso_utc(latest.timestamp_utc),
                "reference": previous.low,
                "status": "candidate_acceptance_needs_follow_through",
            })
    three_push_candidates = _multiscale_three_push_candidates(bars)
    return {
        "imbalance_candidates": imbalance_candidates[-6:],
        "displacement_candidates": displacement_candidates,
        "close_acceptance_candidates": close_acceptance_candidates,
        "three_push_candidates": three_push_candidates,
        "status": "candidate_price_action_objects",
        "provenance": "closed_bars_only",
    }


def _build_live_structure_projection(
    states: dict[str, object],
    *,
    as_of_utc: str,
    provider: str | None,
) -> dict[str, object]:
    """Create a source-bar-bound candidate spine/target graph for live use.

    The projection gives downstream explanation code stable object IDs and
    provenance without silently promoting a fractal into a protected node or
    a measured leg into DOL.  Semantic acceptance stays explicitly unknown.
    """

    nodes: list[dict[str, object]] = []
    target_candidates: list[dict[str, object]] = []
    location_candidates: list[dict[str, object]] = []
    protected_node_candidates: list[dict[str, object]] = []
    higher_context_candidates: list[dict[str, object]] = []
    parent_task_candidates: list[dict[str, object]] = []
    for timeframe in TOP_DOWN_ORDER:
        state = states.get(timeframe) or {}
        if not isinstance(state, dict):
            continue
        node_tests = {
            (item.get("kind"), item.get("pivot_timestamp_utc")): item
            for item in state.get("candidate_node_test_observations") or []
            if isinstance(item, dict)
        }
        for swing in state.get("confirmed_swing_candidates") or []:
            if not isinstance(swing, dict):
                continue
            timestamp = str(swing.get("pivot_timestamp_utc") or "unknown")
            kind = str(swing.get("kind") or "unknown")
            nodes.append({
                "node_id": f"{timeframe}:{kind}:{timestamp}",
                "timeframe": timeframe,
                "kind": kind,
                "price": swing.get("price"),
                "pivot_timestamp_utc": timestamp,
                "confirmed_at_utc": swing.get("confirmed_at_utc"),
                "post_confirmation_test": node_tests.get((kind, timestamp), {}),
                "status": "candidate_not_protected_node",
                "source_bar_timeframe": timeframe,
                "as_of_utc": as_of_utc,
            })
            protected_node_candidates.append({
                "object_id": f"{timeframe}:protected_candidate:{kind}:{timestamp}",
                "role": "protected_node_candidate",
                "timeframe": timeframe,
                "price": swing.get("price"),
                "pivot_timestamp_utc": timestamp,
                "post_confirmation_test": node_tests.get((kind, timestamp), {}),
                "status": "candidate_not_protected_node",
                "required_evidence": [
                    "source_bound_structure_role",
                    "parent_close_acceptance",
                    "invalidation_or_delivery_context",
                ],
                "as_of_utc": as_of_utc,
            })
        raw_metrics = state.get("raw_metrics") or {}
        for role, key in (
            ("recent_window_high", "recent_window_high"),
            ("recent_window_low", "recent_window_low"),
        ):
            price = raw_metrics.get(key) if isinstance(raw_metrics, dict) else None
            if isinstance(price, (int, float)):
                location_candidates.append({
                    "object_id": f"{timeframe}:{role}:{as_of_utc}",
                    "role": role,
                    "timeframe": timeframe,
                    "price": price,
                    "status": "candidate_range_boundary_not_named_snr",
                    "snr_or_pd_array": "unknown",
                    "source_bar_timeframe": timeframe,
                    "as_of_utc": as_of_utc,
                })
        measurement = state.get("measurement_candidates") or {}
        price_action = state.get("price_action_objects") or {}
        for imbalance in price_action.get("imbalance_candidates") or []:
            if isinstance(imbalance, dict):
                location_candidates.append({
                    "object_id": f"{timeframe}:imbalance:{imbalance.get('origin_right_timestamp_utc', 'unknown')}",
                    "role": "imbalance_candidate",
                    "timeframe": timeframe,
                    "lower": imbalance.get("lower"),
                    "upper": imbalance.get("upper"),
                    "status": imbalance.get("status", "candidate_not_named_fvg"),
                    "source_bar_timeframe": timeframe,
                    "as_of_utc": as_of_utc,
                })
        latest_leg = measurement.get("latest_leg")
        if isinstance(latest_leg, dict):
            valid_target = anchored_one_to_one_value(measurement)
            target_source_leg = measurement.get("one_to_one_source_leg") if valid_target is not None else None
            target_anchor = measurement.get("projection_anchor") if valid_target is not None else None
            target_touch = measurement.get("candidate_target_touch_observation") if valid_target is not None else None
            source_origin_close = measurement.get("source_leg_origin_side_close_observation") if valid_target is not None else None
            origin_time = latest_leg.get("origin", {}).get("pivot_timestamp_utc", "unknown")
            terminal_time = latest_leg.get("terminal", {}).get("pivot_timestamp_utc", "unknown")
            stable_leg_id = f"{timeframe}:leg:{origin_time}->{terminal_time}"
            parent_timeframes = {"W1", "D1", "H4", "H1"}
            if timeframe in parent_timeframes | {"M30"}:
                context_status = "candidate_parent_context" if timeframe in parent_timeframes else "intermediate_context_only"
                candidate_id = f"{timeframe}:parent_candidate:{origin_time}->{terminal_time}"
                higher_context_candidates.append({
                    "timeframe": timeframe,
                    "direction_observation": latest_leg.get("direction_observation"),
                    "origin": latest_leg.get("origin"),
                    "terminal": latest_leg.get("terminal"),
                    "one_to_one_target_candidate": None,
                    "projection_family": "not_bound_to_latest_leg",
                    "projection_anchor": None,
                    "separate_retracement_anchored_measurement": {
                        "source_leg": target_source_leg,
                        "projection_anchor": target_anchor,
                        "target_candidate": valid_target,
                        "target_touch_observation": target_touch,
                        "source_origin_side_close_observation": source_origin_close,
                    },
                    "candidate_target_touch_observation": None,
                    "candidate_origin_side_close_observation": measurement.get("candidate_origin_side_close_observation"),
                    "status": context_status,
                    "parent_task_candidate_id": candidate_id if timeframe in parent_timeframes else None,
                    "as_of_utc": as_of_utc,
                })
                if timeframe in parent_timeframes:
                    parent_task_candidates.append({
                        "parent_task_candidate_id": candidate_id,
                        "timeframe": timeframe,
                        "direction_observation": latest_leg.get("direction_observation"),
                        "origin": latest_leg.get("origin"),
                        "terminal": latest_leg.get("terminal"),
                        "one_to_one_target_candidate": None,
                        "projection_family": "not_bound_to_latest_leg",
                        "projection_anchor": None,
                        "separate_retracement_anchored_measurement": {
                            "source_leg": target_source_leg,
                            "projection_anchor": target_anchor,
                            "target_candidate": valid_target,
                            "target_touch_observation": target_touch,
                            "source_origin_side_close_observation": source_origin_close,
                        },
                        "candidate_target_touch_observation": None,
                        "candidate_origin_side_close_observation": measurement.get("candidate_origin_side_close_observation"),
                        "status": "candidate_not_parent_task",
                        "required_confirmation": [
                            "name_parent_task_and_structure_role",
                            "bind_protected_node_or_named_snr",
                            "observe_parent_close_acceptance_and_follow_through",
                            "bind_dol_or_target_lifecycle",
                        ],
                        "as_of_utc": as_of_utc,
                    })
            measured_leg = target_source_leg or latest_leg
            measured_origin_time = measured_leg.get("origin", {}).get("pivot_timestamp_utc", "unknown")
            measured_terminal_time = measured_leg.get("terminal", {}).get("pivot_timestamp_utc", "unknown")
            retrace_time = (target_anchor or {}).get("pivot_timestamp_utc")
            target_id = (f"{timeframe}:retracement_anchored_1to1:{measured_origin_time}->{measured_terminal_time}@{retrace_time}"
                         if retrace_time else stable_leg_id)
            target_candidates.append({
                "target_candidate_id": target_id,
                "timeframe": timeframe,
                "origin": measured_leg.get("origin"),
                "terminal": measured_leg.get("terminal"),
                "direction_observation": measured_leg.get("direction_observation"),
                "range_points": measured_leg.get("range_points"),
                "one_to_one_target_candidate": valid_target,
                "projection_family": (measurement.get("projection_family") if valid_target is not None else "unbound_geometry"),
                "projection_anchor": target_anchor,
                "candidate_target_touch_observation": target_touch,
                "candidate_origin_side_close_observation": (
                    source_origin_close
                    if target_source_leg
                    else measurement.get("candidate_origin_side_close_observation")
                ),
                "status": "candidate_measurement_not_DOL",
                "as_of_utc": as_of_utc,
            })
    return {
        "status": "candidate_spine_and_target_graph",
        "provider": provider,
        "as_of_utc": as_of_utc,
        "parent_task": {
            "state": "unknown",
            "parent_task_id": None,
            "required_before_direction": True,
        },
        "higher_context_candidates": higher_context_candidates,
        "parent_task_candidates": parent_task_candidates,
        "structure_spine": {
            "candidate_nodes": nodes,
            "protected_node_candidates": protected_node_candidates,
            "protected_node_state": "unbound",
            "neckline_snr_state": "unbound",
            "parent_close_acceptance": "unknown",
        },
        "target_graph": {
            "candidate_measurements": target_candidates,
            "dol_state": "unbound",
            "pd_array_state": "unbound",
            "target_completion_state": "unknown",
        },
        "location_objects": {
            "candidate_boundaries": location_candidates,
            "named_snr_state": "unbound",
            "pd_array_state": "unbound",
            "ob_fvg_state": "unbound",
            "imbalance_candidates_present": bool(location_candidates),
        },
        "liquidity_and_acceptance": {
            "named_object_state": "unbound",
            "sweep_state": "candidate_only",
            "displacement_state": "unknown",
            "close_acceptance_state": "unknown",
            "follow_through_state": "unknown",
        },
        "provenance_policy": "Every candidate carries its timeframe, pivot/confirmation time and snapshot cutoff; no later bar is used to promote semantic status.",
    }


def analyze_closed_bars(bars: Sequence[OHLCBar], *, lookback: int = 20) -> dict[str, object]:
    """Describe the latest closed bar without promoting it to a trade signal."""

    if not bars:
        return {
            "state": "unknown",
            "latest_closed_bar": None,
            "observations": [],
            "unknowns": ["no_closed_bars"],
            "entry_permission": "blocked",
            "automatic_trade_permission": False,
        }

    latest = bars[-1]
    prior = list(bars[max(0, len(bars) - lookback - 1) : -1])
    observations: list[str] = []
    structure_observations: list[str] = []
    force_observations: list[str] = []
    location_observations: list[str] = []
    swing_candidates: list[dict[str, object]] = []
    unknowns: list[str] = []
    prior_high = max((item.high for item in prior), default=None)
    prior_low = min((item.low for item in prior), default=None)
    if prior_high is not None and latest.high > prior_high:
        observations.append("high_reaches_above_recent_window")
        if latest.close <= prior_high:
            observations.append("high_sweep_candidate_close_back_at_or_below_window")
    if prior_low is not None and latest.low < prior_low:
        observations.append("low_reaches_below_recent_window")
        if latest.close >= prior_low:
            observations.append("low_sweep_candidate_close_back_at_or_above_window")
    if len(prior) < 3:
        unknowns.append("short_history_for_structure_context")
    recent_ranges = [item.range for item in prior if item.range > 0]
    median_range = statistics.median(recent_ranges) if recent_ranges else None
    if median_range is None:
        unknowns.append("recent_range_baseline_missing")
    direction = "up" if latest.close > latest.open else "down" if latest.close < latest.open else "flat"
    close_location = (
        _safe_ratio(latest.close - latest.low, latest.range)
        if latest.range > 0
        else None
    )
    if prior_high is None or prior_low is None:
        unknowns.append("recent_window_bounds_missing")
    if len(bars) >= 3:
        before_previous = bars[-3]
        previous = bars[-2]
        close_directions = [
            "up" if item.close > item.open else "down" if item.close < item.open else "flat"
            for item in bars[-3:]
        ]
        nonflat = [item for item in close_directions if item != "flat"]
        if nonflat and len(set(nonflat)) == 1:
            structure_observations.append(f"recent_closed_sequence_{nonflat[0]}")
        elif nonflat:
            structure_observations.append("recent_closed_sequence_mixed")
        if previous.high > before_previous.high and previous.high >= latest.high:
            swing_candidates.append({
                "kind": "swing_high_candidate",
                "timestamp_utc": iso_utc(previous.timestamp_utc),
                "price": previous.high,
                "status": "candidate_not_accepted",
            })
        if previous.low < before_previous.low and previous.low <= latest.low:
            swing_candidates.append({
                "kind": "swing_low_candidate",
                "timestamp_utc": iso_utc(previous.timestamp_utc),
                "price": previous.low,
                "status": "candidate_not_accepted",
            })
    if median_range is not None:
        if latest.range > median_range:
            force_observations.append("latest_range_larger_than_recent_median")
        elif latest.range < median_range:
            force_observations.append("latest_range_smaller_than_recent_median")
        else:
            force_observations.append("latest_range_near_recent_median")
    if close_location is not None:
        if close_location > 0.5:
            location_observations.append("latest_close_above_own_bar_midpoint")
        elif close_location < 0.5:
            location_observations.append("latest_close_below_own_bar_midpoint")
        else:
            location_observations.append("latest_close_at_own_bar_midpoint")
    confirmed_swing_candidates = _confirmed_fractal_candidates(bars, radius=2)
    geometric_step_chain = _geometric_step_chain(confirmed_swing_candidates, timeframe=bars[-1].timeframe)
    node_test_observations = _candidate_node_test_observations(bars, confirmed_swing_candidates[-8:])
    measurement_candidates = _measurement_candidates(confirmed_swing_candidates, latest.close)
    # Keep the broad read on the actual available history.  M15 must cover
    # the multi-week chart the user is comparing against, while M1's fine
    # view stays bounded so the per-close audit remains responsive.
    frame = bars[-1].timeframe
    visual_horizon = {
        "M1": 512, "M5": 2048, "M15": 2048, "M30": 1536,
        "H1": 1024, "H4": 512, "D1": 512, "W1": 512,
    }.get(frame, 512)
    # A visual overview budget must not silently discard older source legs.
    # Keep the native inventory coextensive with the 8192-bar chart archive;
    # this only inventories geometry, not automatic 1:1 admission.
    source_history = bars[-8192:]
    candidate_wave_ledger = _candidate_wave_ledger(bars, max_bars=8192)
    # The current channel/structure scan has a separate, bounded working
    # window. Expanding source inventory must not turn its pairwise channel
    # search into a full-archive operation on every closed candle.
    working_wave_ledger = _candidate_wave_ledger(bars, max_bars=min(512, visual_horizon))
    coarse_structure_context = _coarse_structure_context(bars, max_bars=visual_horizon)
    measurement_candidates["candidate_target_touch_observation"] = _candidate_target_touch_observation(bars, measurement_candidates)
    measurement_candidates["candidate_origin_side_close_observation"] = _candidate_origin_side_close_observation(bars, measurement_candidates)
    measurement_candidates["source_leg_origin_side_close_observation"] = (
        _candidate_origin_side_close_observation(bars, measurement_candidates, leg_key="one_to_one_source_leg")
        if measurement_candidates.get("one_to_one_source_leg") else None
    )
    price_action_objects = _candidate_price_action_objects(bars, lookback=lookback)
    # Chart history must retain old observations even after forty newer ones.
    # Source-admission callers keep their existing bounded default separately.
    force_ob = review_force_ob_candidates(source_history, candidate_wave_ledger, max_candidates=None)
    price_action_objects["force_leg_candidates"] = force_ob["force_leg_candidates"]
    price_action_objects["order_block_candidates"] = force_ob["order_block_candidates"]
    price_action_objects["force_ob_review_boundary"] = force_ob.get("boundary")
    price_action_objects["parallel_channel_review"] = review_parallel_channels(bars[-visual_horizon:], working_wave_ledger)
    price_action_objects["native_structure_sequence"] = review_native_structure(
        bars[-visual_horizon:], working_wave_ledger, timeframe=latest.timeframe,
        as_of_utc=iso_utc(latest.timestamp_utc+timedelta(minutes=TIMEFRAME_MINUTES[latest.timeframe])))
    return {
        "state": "observed_closed_bar",
        "bar_count": len(bars),
        "latest_closed_bar": latest.as_dict(),
        "coarse_closed_bar_view": _coarse_closed_bar_view(bars),
        "direction_observation": direction,
        "raw_metrics": {
            "range": latest.range,
            "body": latest.body,
            "upper_wick": latest.upper_wick,
            "lower_wick": latest.lower_wick,
            "body_to_range": _safe_ratio(latest.body, latest.range),
            "close_location_in_bar": close_location,
            "range_to_recent_median": _safe_ratio(latest.range, median_range or 0.0),
            "recent_window_high": prior_high,
            "recent_window_low": prior_low,
        },
        "observations": observations,
        "structure_observations": structure_observations,
        "force_observations": force_observations,
        "location_observations": location_observations,
        "swing_candidates": swing_candidates,
        "structure_observation_status": "candidate_only" if structure_observations or swing_candidates else "not_recorded",
        "confirmed_swing_candidates": confirmed_swing_candidates[-8:],
        "geometric_step_chain": geometric_step_chain,
        "candidate_node_test_observations": node_test_observations,
        "measurement_candidates": measurement_candidates,
        "candidate_wave_ledger": candidate_wave_ledger,
        "coarse_structure_context": coarse_structure_context,
        "price_action_objects": price_action_objects,
        "unknowns": unknowns,
        "target_status": "unknown",
        "close_acceptance": "unknown",
        "structure_transition": "unknown",
        "competing_paths": [
            "continuation_requires_parent_task_and_follow_through",
            "pullback_or_resweep_remains_possible_until_close_acceptance_is_known",
        ],
        "entry_permission": "blocked",
        "automatic_trade_permission": False,
    }


def build_snapshot(
    m1_bars: Sequence[OHLCBar],
    *,
    as_of_utc: str | datetime,
    provider: str | None = None,
    instrument: str = "XAUUSD",
    selected_trading_timeframe: str = "M5",
    native_higher_timeframe_bars: dict[str, Sequence[OHLCBar]] | None = None,
    native_higher_timeframe_sources: dict[str, dict[str, object]] | None = None,
    native_analysis_period_bars: dict[str, Sequence[OHLCBar]] | None = None,
    display_period_bars: dict[str, Sequence[OHLCBar]] | None = None,
    provider_day_offset_seconds: int = 0,
    forming_period_bars: dict[str, Sequence[OHLCBar]] | None = None,
    _period_analyzer=None,
) -> dict[str, object]:
    """Build a conservative top-down snapshot for one closed-bar moment."""

    as_of = parse_utc(as_of_utc)
    native_higher_timeframe_bars = native_higher_timeframe_bars or {}
    native_higher_timeframe_sources = native_higher_timeframe_sources or {}
    native_analysis_period_bars = native_analysis_period_bars or {}
    display_period_bars = display_period_bars or {}
    forming_period_bars = forming_period_bars or {}
    display_provider = provider or next((bar.provider for bar in m1_bars if bar.provider), None)
    states: dict[str, object] = {}
    chart_history: dict[str, dict[str, object]] = {}
    forming_candidates: dict[str, dict[str, object]] = {}
    snapshot_higher_timeframe_sources: dict[str, dict[str, object]] = {}
    for timeframe in TOP_DOWN_ORDER:
        has_native_analysis = timeframe in native_analysis_period_bars
        if has_native_analysis:
            supplied_analysis = list(native_analysis_period_bars.get(timeframe) or [])
            invalid_analysis = [
                bar for bar in supplied_analysis
                if bar.timeframe != timeframe or bar.symbol != instrument
            ]
            if invalid_analysis:
                raise ValueError(f"native analysis {timeframe} bars must match timeframe and instrument")
            period = timedelta(minutes=TIMEFRAME_MINUTES[timeframe])
            analysis_times: set[datetime] = set()
            aggregated = []
            for bar in supplied_analysis:
                prices = (bar.open, bar.high, bar.low, bar.close)
                if (any(isinstance(value, bool) or not isinstance(value, (int, float))
                        or not math.isfinite(value) for value in prices)
                        or bar.high < max(bar.open, bar.close, bar.low)
                        or bar.low > min(bar.open, bar.close, bar.high)):
                    raise ValueError(f"native analysis {timeframe} invalid OHLC")
                opened = parse_utc(bar.timestamp_utc)
                if opened in analysis_times:
                    raise ValueError(f"native analysis {timeframe} duplicate timestamp")
                analysis_times.add(opened)
                if opened + period <= as_of:
                    aggregated.append(bar)
            aggregated.sort(key=lambda bar: parse_utc(bar.timestamp_utc))
            source_mode = "native_period_bars"
        elif timeframe in NATIVE_HIGHER_TIMEFRAMES:
            supplied = list(native_higher_timeframe_bars.get(timeframe) or [])
            invalid = [
                bar for bar in supplied
                if bar.timeframe != timeframe or bar.symbol != instrument
            ]
            if invalid:
                raise ValueError(f"native {timeframe} bars must match timeframe and instrument")
            period = timedelta(minutes=TIMEFRAME_MINUTES[timeframe])
            aggregated = sorted(
                (bar for bar in supplied if parse_utc(bar.timestamp_utc) + period <= as_of),
                key=lambda bar: parse_utc(bar.timestamp_utc),
            )
            source_mode = "native_timeframe_bars"
        else:
            aggregated = aggregate_bars(m1_bars, timeframe, as_of_utc=as_of)
            source_mode = "aggregated_from_closed_m1"
        state = (_period_analyzer or analyze_closed_bars)(aggregated)
        # Local timeframe state above still uses `aggregated`. The drawing
        # workbench and downstream source/background/lifecycle reviews also
        # consume chart_history, so its larger window must be validated and
        # clipped at the receiving snapshot's cutoff, not just at poll time.
        chart_horizon = 8192
        # Display history may come from a broker-native query for every
        # timeframe. Keep the local state input above unchanged until its
        # per-period computation is separately budgeted; never label an M1
        # aggregate as native merely because it is drawn on an H1/H4 card.
        display_supplied = list(display_period_bars.get(timeframe) or [])
        has_native_display = timeframe in display_period_bars
        if has_native_display:
            period = timedelta(minutes=TIMEFRAME_MINUTES[timeframe])
            seen_display_times = set()
            closed_display = []
            for bar in display_supplied:
                if (bar.timeframe != timeframe or bar.symbol != instrument
                        or (display_provider is not None and bar.provider != display_provider)):
                    raise ValueError(f"native display {timeframe} identity mismatch")
                prices = (bar.open, bar.high, bar.low, bar.close)
                if (any(isinstance(value, bool) or not isinstance(value, (int, float))
                        or not math.isfinite(value) for value in prices)
                        or bar.high < max(bar.open, bar.close, bar.low)
                        or bar.low > min(bar.open, bar.close, bar.high)):
                    raise ValueError(f"native display {timeframe} invalid OHLC")
                opened = parse_utc(bar.timestamp_utc)
                if opened in seen_display_times:
                    raise ValueError(f"native display {timeframe} duplicate timestamp")
                seen_display_times.add(opened)
                if opened + period <= as_of:
                    closed_display.append(bar)
            closed_display.sort(key=lambda bar: parse_utc(bar.timestamp_utc))
            visible_bars = closed_display[-chart_horizon:]
        else:
            visible_bars = aggregated[-chart_horizon:]
        display_source_mode = (
            "native_period_bars" if has_native_display else source_mode
        )
        chart_history[timeframe] = {
            "source_mode": display_source_mode,
            "cutoff_utc": iso_utc(as_of),
            "bars": [
                {
                    "timestamp_utc": iso_utc(bar.timestamp_utc),
                    "open": bar.open, "high": bar.high,
                    "low": bar.low, "close": bar.close,
                    "volume": bar.volume, "volume_type": "tick_volume",
                    "provider": bar.provider, "symbol": bar.symbol,
                    "timeframe": timeframe,
                }
                for bar in visible_bars
            ],
        }
        state["timeframe"] = timeframe
        state["source_bar_count"] = len(aggregated)
        state["source_mode"] = source_mode
        if has_native_analysis:
            state["source_status"] = "available" if aggregated else "unavailable"
            if not aggregated:
                state.setdefault("unknowns", []).append(
                    f"native_{timeframe}_analysis_history_unavailable"
                )
        latest_closed_bar = aggregated[-1] if aggregated else None
        state["latest_closed_bar_open_utc"] = (
            iso_utc(parse_utc(latest_closed_bar.timestamp_utc)) if latest_closed_bar else None
        )
        state["latest_closed_bar_end_utc"] = (
            iso_utc(parse_utc(latest_closed_bar.timestamp_utc) + timedelta(minutes=TIMEFRAME_MINUTES[timeframe]))
            if latest_closed_bar else None
        )
        if timeframe in NATIVE_HIGHER_TIMEFRAMES:
            fetched_source = native_higher_timeframe_sources.get(timeframe) or {}
            source_rows = (
                supplied_analysis if has_native_analysis
                else list(native_higher_timeframe_bars.get(timeframe) or [])
            )
            source_status = (
                "available" if has_native_analysis and aggregated
                else "no_closed_history" if has_native_analysis
                else str(fetched_source.get("status", "not_requested"))
            )
            state["source_status"] = (
                "available" if aggregated else
                source_status if source_status == "unavailable" else "no_closed_history"
            )
            latest_native_bar = aggregated[-1] if aggregated else None
            # Rebuild these fields at the snapshot's own cutoff. A poll can
            # fetch history once and emit several older M1 snapshots; exposing
            # the poll's later cutoff/bar count would leak later-known context.
            snapshot_higher_timeframe_sources[timeframe] = {
                "status": state["source_status"],
                "bar_time_basis": "provider_native",
                "snapshot_cutoff_utc": iso_utc(as_of),
                "bar_count": len(aggregated),
                "latest_closed_bar_utc": (
                    iso_utc(parse_utc(latest_native_bar.timestamp_utc)) if latest_native_bar else None
                ),
                "latest_closed_bar_open_utc": state["latest_closed_bar_open_utc"],
                "latest_closed_bar_end_utc": state["latest_closed_bar_end_utc"],
                "excluded_after_snapshot_cutoff": len(source_rows) - len(aggregated),
            }
            if not aggregated:
                state.setdefault("unknowns", []).append(f"native_{timeframe}_closed_history_unavailable")
        states[timeframe] = state
        if timeframe in forming_period_bars:
            forming_candidates[timeframe] = build_forming_candidate(
                forming_period_bars[timeframe],
                as_of_utc=as_of,
                provider=display_provider,
                instrument=instrument,
                timeframe=timeframe,
            )
    structure_projection = _build_live_structure_projection(
        states,
        as_of_utc=iso_utc(as_of),
        provider=provider or next((bar.provider for bar in m1_bars if bar.provider), None),
    )
    reconstructed_indicators = _reconstructed_indicator_context(
        m1_bars, as_of_utc=as_of, provider_day_offset_seconds=provider_day_offset_seconds,
    )
    daily_distribution = reconstructed_indicators.get("daily_price_distribution") or {}
    distribution_profiles = (
        daily_distribution.get("profiles") or []
        if isinstance(daily_distribution, dict)
        else []
    )
    latest_distribution = distribution_profiles[0] if distribution_profiles else {}
    if isinstance(structure_projection, dict):
        location_objects = structure_projection.setdefault("location_objects", {})
        if isinstance(location_objects, dict) and latest_distribution.get("status") == "reconstructed_candidate":
            location_objects["price_distribution_candidates"] = [
                {
                    "kind": "vp62_daily_poc_candidate",
                    "price": latest_distribution.get("poc"),
                    "timeframe": "M1_source_distribution",
                    "date_server": latest_distribution.get("date_server"),
                    "role": "candidate_location_only",
                    "source": "VP62_Daily_M1_Correct_reconstruction",
                },
                {
                    "kind": "vp62_daily_value_area_candidate",
                    "low": latest_distribution.get("value_area_low"),
                    "high": latest_distribution.get("value_area_high"),
                    "timeframe": "M1_source_distribution",
                    "date_server": latest_distribution.get("date_server"),
                    "role": "candidate_location_only",
                    "source": "VP62_Daily_M1_Correct_reconstruction",
                },
            ]
    return {
        "snapshot_id": f"{instrument}_{iso_utc(as_of)}",
        "chart_history": chart_history,
        "instrument": instrument,
        "provider": provider or next((bar.provider for bar in m1_bars if bar.provider), None),
        "as_of_utc": iso_utc(as_of),
        "data_integrity": {
            "same_source": "unknown",
            "gaps": "not_audited",
            "future_information": "cutoff_applied_to_closed_bars",
            "news_data": "not_joined",
            "spread_slippage": "not_joined",
            "admission": "diagnostic_only",
            "higher_timeframe_sources": snapshot_higher_timeframe_sources,
        },
        "timeframe_states": states,
        "forming_candidates": forming_candidates,
        "live_structure_projection": structure_projection,
        "analysis_order": list(TOP_DOWN_ORDER),
        "higher_timeframe_background": {
            "bias": "unknown",
            "parent_task": "unknown",
            "target_status": "unknown",
            "entry_permission": "wait",
        },
        "weekly_profile": {
            "hypothesis": "unknown",
            "status": "unknown",
            "economic_program_joined": False,
            "actual_reaction_required": True,
        },
        "indicator_context": {
            "source_inventory": "03_work_queue/wells3_mt5_indicator_inventory_20260930/inventory.json",
            "reconstruction": reconstructed_indicators,
            "admission": "diagnostic_only",
            "opaque_mt5_outputs_used_as_truth": False,
        },
        "price_action_chain": {
            "location": "unknown",
            "sweep": "candidate_only",
            "displacement": "candidate_only",
            "close_acceptance": "unknown",
            "structure_change": "unknown",
            "pullback": "unknown",
            "follow_through": "unknown",
        },
        "selected_trading_timeframe": selected_trading_timeframe,
        "decision": {
            "state": "WAIT_DATA",
            "allowed_direction": "unknown",
            "trigger_requirements": [
                "name_parent_task_and_current_object",
                "review_closed_bar_and_follow_through_in_selected_timeframe",
                "check_higher_timeframe_target_and_competing_paths",
            ],
            "invalidation": [],
            "target_stack": [],
            "risk_plan": "unknown",
            "explanation_chain": [],
            "confidence": "not_calibrated",
        },
        "automatic_trade_permission": False,
    }


def build_forming_candidate(
    bars: Sequence[OHLCBar],
    *,
    as_of_utc: str | datetime,
    provider: str | None = None,
    instrument: str = "XAUUSD",
    timeframe: str = "M5",
    source_id: str | None = None,
    lineage_id: str | None = None,
) -> dict[str, object]:
    """Score only the currently forming bar without mutating closed structure.

    The input must contain a raw same-timeframe series.  The last bar is
    considered forming only while ``as_of_utc`` is inside its interval; every
    baseline and anchor is taken from bars whose interval has already closed.
    The returned identity stays attached to the confirmed anchor, so a quote
    update changes the candidate score while the confirmed producer remains
    unchanged.  This is a display observation, never an entry permission.
    """

    as_of = parse_utc(as_of_utc)
    base = {
        "ready": False,
        "status": "unknown",
        "reason": "unknown",
        "timeframe": timeframe,
        "observed_through_utc": iso_utc(as_of),
        "source_id": source_id or "",
        "lineage_id": lineage_id or "",
        "trade_permission": False,
    }
    if timeframe not in TIMEFRAME_MINUTES or not bars:
        base["reason"] = "invalid_timeframe_or_empty_series"
        return base
    period = timedelta(minutes=TIMEFRAME_MINUTES[timeframe])
    rows = sorted(bars, key=lambda item: parse_utc(item.timestamp_utc))
    if any(item.timeframe != timeframe or item.symbol != instrument
           or (provider is not None and item.provider != provider)
           for item in rows):
        base["reason"] = "identity_mismatch"
        return base
    timestamps = [parse_utc(item.timestamp_utc) for item in rows]
    if len(set(timestamps)) != len(timestamps):
        base["reason"] = "duplicate_timestamp"
        return base
    forming = [
        item for item in rows
        if parse_utc(item.timestamp_utc) <= as_of
        and parse_utc(item.timestamp_utc) + period > as_of
    ]
    if len(forming) != 1:
        base["reason"] = "no_unique_forming_bar" if not forming else "ambiguous_forming_bar"
        return base
    current = forming[0]
    closed = [
        item for item in rows
        if parse_utc(item.timestamp_utc) + period <= as_of
        and parse_utc(item.timestamp_utc) < parse_utc(current.timestamp_utc)
    ]
    if len(closed) < 5:
        base["reason"] = "insufficient_closed_baseline"
        return base
    anchors = _confirmed_fractal_candidates(closed, radius=2)
    if not anchors:
        base["reason"] = "no_confirmed_anchor"
        return base
    anchor = anchors[-1]
    explicit_source = str(source_id or "").strip()
    if not explicit_source:
        explicit_source = f"web:{provider or 'unknown'}:{instrument}:{timeframe}"
    if not str(lineage_id or "").strip():
        identity = "|".join([
            explicit_source,
            str(anchor.get("kind", "")),
            str(anchor.get("pivot_timestamp_utc", "")),
            str(anchor.get("price", "")),
        ])
        lineage_id = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:24]
    else:
        lineage_id = str(lineage_id)
    base.update({"source_id": explicit_source, "lineage_id": lineage_id})
    if current.range <= 0 or current.body <= 0:
        base["reason"] = "forming_range_or_body_zero"
        return base
    upward = anchor.get("kind") == "confirmed_swing_low_candidate"
    direction = current.close - current.open if upward else current.open - current.close
    baseline_ranges = [item.range for item in closed[-9:] if item.range > 0]
    if not baseline_ranges:
        base["reason"] = "closed_range_baseline_missing"
        return base
    baseline = statistics.median(baseline_ranges)
    if baseline <= 0:
        base["reason"] = "closed_range_baseline_zero"
        return base
    body_share = min(1.0, current.body / current.range)
    directional_body = max(0.0, direction) / current.body
    close_position = (
        (current.close - current.low) / current.range
        if upward else (current.high - current.close) / current.range
    )
    range_expansion = current.range / baseline
    progress_distance = (
        current.close - float(anchor["price"])
        if upward else float(anchor["price"]) - current.close
    )
    progress = max(0.0, progress_distance / baseline)
    score = 100.0 * (
        0.25 * body_share
        + 0.25 * min(1.0, directional_body)
        + 0.20 * min(1.0, range_expansion / 2.0)
        + 0.20 * max(0.0, min(1.0, close_position))
        + 0.10 * min(1.0, progress / 4.0)
    )
    base.update({
        "ready": True,
        "status": "forming_candidate",
        "reason": "ok",
        "upward": upward,
        "bar_open_utc": iso_utc(current.timestamp_utc),
        "known_at_utc": iso_utc(as_of),
        "open": current.open,
        "high": current.high,
        "low": current.low,
        "close": current.close,
        "baseline_bars": len(baseline_ranges),
        "anchor": dict(anchor),
        "body_share": body_share,
        "directional_body": directional_body,
        "close_position": close_position,
        "range_expansion": range_expansion,
        "progress": progress,
        "score": score,
        "confirmed_structure_unchanged": True,
        "confirmation_state": "developing",
    })
    return base


def _projection_node_id(node: object) -> str | None:
    if not isinstance(node, dict):
        return None
    value = node.get("node_id")
    return str(value) if value is not None else None


def _projection_target_id(target: object) -> str | None:
    """Return a time-stable target identity, excluding the changing cutoff."""

    if not isinstance(target, dict):
        return None
    timeframe = target.get("timeframe")
    origin = target.get("origin") if isinstance(target.get("origin"), dict) else {}
    terminal = target.get("terminal") if isinstance(target.get("terminal"), dict) else {}
    origin_time = origin.get("pivot_timestamp_utc") or origin.get("timestamp_utc")
    terminal_time = terminal.get("pivot_timestamp_utc") or terminal.get("timestamp_utc")
    if timeframe is None or origin_time is None or terminal_time is None:
        return None
    return f"{timeframe}:leg:{origin_time}->{terminal_time}"


def summarize_snapshot_delta(
    previous: dict[str, object] | None,
    current: dict[str, object],
) -> dict[str, object]:
    """Describe only the consecutive closed-bar changes visible at emission time.

    This is deliberately a delta of observations, not a hindsight label.  A
    newly appearing swing/measurement is reported as a candidate addition and
    never promoted to a protected node, DOL, direction or order instruction.
    """

    as_of = current.get("as_of_utc")
    if previous is None:
        return {
            "status": "initial",
            "previous_as_of_utc": None,
            "as_of_utc": as_of,
            "as_of_changed": False,
            "timeframes_changed": [],
            "added_candidate_node_ids": [],
            "removed_candidate_node_ids": [],
            "added_target_candidate_ids": [],
            "removed_target_candidate_ids": [],
            "higher_context_changed": False,
            "note": "这是第一条可比较快照，尚无上一根收盘 K 线。",
        }

    previous_states = previous.get("timeframe_states") or {}
    current_states = current.get("timeframe_states") or {}
    timeframe_changes: list[dict[str, object]] = []
    for timeframe in TOP_DOWN_ORDER:
        before = previous_states.get(timeframe) or {}
        after = current_states.get(timeframe) or {}
        if not isinstance(before, dict) or not isinstance(after, dict):
            continue
        changed_fields: list[str] = []
        if before.get("direction_observation") != after.get("direction_observation"):
            changed_fields.append("direction_observation")
        if before.get("structure_observations") != after.get("structure_observations"):
            changed_fields.append("structure_observations")
        if before.get("observations") != after.get("observations"):
            changed_fields.append("window_or_sweep_observations")
        if before.get("measurement_candidates") != after.get("measurement_candidates"):
            changed_fields.append("measurement_candidates")
        before_bar = before.get("latest_closed_bar") or {}
        after_bar = after.get("latest_closed_bar") or {}
        if isinstance(before_bar, dict) and isinstance(after_bar, dict):
            if before_bar.get("timestamp_utc") != after_bar.get("timestamp_utc"):
                changed_fields.append("latest_closed_bar")
        if changed_fields:
            timeframe_changes.append({
                "timeframe": timeframe,
                "changed_fields": changed_fields,
                "before_direction": before.get("direction_observation"),
                "after_direction": after.get("direction_observation"),
                "after_measurement_status": (after.get("measurement_candidates") or {}).get("status")
                if isinstance(after.get("measurement_candidates"), dict) else None,
            })

    def projection_items(snapshot: dict[str, object], section: str, key: str) -> list[object]:
        projection = snapshot.get("live_structure_projection") or {}
        container = projection.get(section) if isinstance(projection, dict) else {}
        values = container.get(key) if isinstance(container, dict) else []
        return list(values or [])

    before_nodes = {_projection_node_id(item) for item in projection_items(previous, "structure_spine", "candidate_nodes")}
    after_nodes = {_projection_node_id(item) for item in projection_items(current, "structure_spine", "candidate_nodes")}
    before_targets = {_projection_target_id(item) for item in projection_items(previous, "target_graph", "candidate_measurements")}
    after_targets = {_projection_target_id(item) for item in projection_items(current, "target_graph", "candidate_measurements")}
    before_nodes.discard(None)
    after_nodes.discard(None)
    before_targets.discard(None)
    after_targets.discard(None)
    def context_without_cutoff(snapshot: dict[str, object]) -> list[dict[str, object]]:
        candidates = (snapshot.get("live_structure_projection") or {}).get("higher_context_candidates") or []
        return [
            {key: value for key, value in candidate.items() if key != "as_of_utc"}
            for candidate in candidates
            if isinstance(candidate, dict)
        ]

    # Candidate provenance is retained in each snapshot, but a new as-of
    # stamp alone is not a change in the underlying higher-timeframe reading.
    higher_context_changed = context_without_cutoff(previous) != context_without_cutoff(current)
    changed = bool(timeframe_changes or before_nodes != after_nodes or before_targets != after_targets or higher_context_changed)
    return {
        "status": "changed" if changed else "unchanged",
        "previous_as_of_utc": previous.get("as_of_utc"),
        "as_of_utc": as_of,
        "as_of_changed": previous.get("as_of_utc") != as_of,
        "timeframes_changed": timeframe_changes,
        "added_candidate_node_ids": sorted(after_nodes - before_nodes),
        "removed_candidate_node_ids": sorted(before_nodes - after_nodes),
        "added_target_candidate_ids": sorted(after_targets - before_targets),
        "removed_target_candidate_ids": sorted(before_targets - after_targets),
        "higher_context_changed": higher_context_changed,
        "note": "仅比较相邻收盘快照；候选变化不等于方向、保护节点、DOL 或下单许可。",
    }


def _delta_checkpoint(snapshot: dict[str, object]) -> dict[str, object]:
    """Detach only fields read by summarize_snapshot_delta, not chart history.

    Keeping a second deep copy of thousands of native candles and all source
    ledgers is unnecessary for this comparison and magnifies live memory use.
    This projection preserves the exact compared values and target identities.
    """
    states = snapshot.get("timeframe_states") or {}
    projection = snapshot.get("live_structure_projection") or {}
    minimal = {"as_of_utc": snapshot.get("as_of_utc"),
        "timeframe_states": {}, "live_structure_projection": {
            "structure_spine": {"candidate_nodes": []},
            "target_graph": {"candidate_measurements": []},
            "higher_context_candidates": projection.get("higher_context_candidates") or []}}
    for timeframe, row in states.items():
        if isinstance(row, dict):
            minimal["timeframe_states"][timeframe] = {
                field: row.get(field) for field in ("direction_observation",
                    "structure_observations", "observations", "measurement_candidates",
                    "latest_closed_bar")}
    for node in (projection.get("structure_spine") or {}).get("candidate_nodes") or []:
        minimal["live_structure_projection"]["structure_spine"]["candidate_nodes"].append(
            {"node_id": _projection_node_id(node)})
    for target in (projection.get("target_graph") or {}).get("candidate_measurements") or []:
        if isinstance(target, dict):
            minimal["live_structure_projection"]["target_graph"]["candidate_measurements"].append(
                {field: target.get(field) for field in ("timeframe", "origin", "terminal")})
    return copy.deepcopy(minimal)


class ClosedBarScheduler:
    """Incremental replay/live boundary for a monotonic M1 bar stream.

    A broker adapter can call :meth:`ingest` for each completed M1 bar.  The
    scheduler emits one cutoff-safe snapshot per new bar; it deliberately does
    not decide direction or place orders.  Out-of-order data is rejected so a
    reconnect cannot silently rewrite an already emitted state.
    """

    def __init__(
        self,
        *,
        provider: str | None = None,
        instrument: str = "XAUUSD",
        selected_trading_timeframe: str = "M5",
        max_bars: int = 20_000,
        expected_interval_minutes: int = 1,
    ) -> None:
        self.provider = provider
        self.instrument = instrument
        self.selected_trading_timeframe = selected_trading_timeframe
        self.max_bars = max_bars
        self.expected_interval_minutes = expected_interval_minutes
        self._bars: list[OHLCBar] = []
        self._last_timestamp: datetime | None = None
        self._last_emitted_snapshot: dict[str, object] | None = None

    @property
    def bars_seen(self) -> int:
        return len(self._bars)

    @property
    def last_timestamp(self) -> datetime | None:
        return self._last_timestamp

    def _capture_state(self) -> tuple:
        # OHLCBar values are frozen; the list and delta checkpoint are replaced,
        # never modified by ingest. No full-snapshot copy is needed for retry.
        return self._bars, self._last_timestamp, self._last_emitted_snapshot

    def _restore_state(self, state: tuple) -> None:
        self._bars, self._last_timestamp, self._last_emitted_snapshot = state

    def seed_history(self, bars: Sequence[OHLCBar]) -> None:
        """Seed closed history without emitting incomplete warm-up snapshots.

        A live connector can fetch a lookback window on startup.  Those bars
        establish H4/H1 context, while only the newest bar should be emitted
        as a new live observation.  Seeding is still strict about instrument,
        timeframe and chronological order.
        """

        ordered = list(bars)
        previous: datetime | None = None
        for bar in ordered:
            if bar.symbol != self.instrument or bar.timeframe != "M1":
                raise ValueError("scheduler accepts only the configured instrument's M1 bars")
            timestamp = parse_utc(bar.timestamp_utc)
            if previous is not None and timestamp <= previous:
                raise ValueError("history contains out-of-order or duplicate M1 bars")
            previous = timestamp
        self._bars = ordered[-self.max_bars :]
        self._last_timestamp = parse_utc(self._bars[-1].timestamp_utc) if self._bars else None
        self._last_emitted_snapshot = None

    def ingest(
        self,
        bar: OHLCBar,
        *,
        native_higher_timeframe_bars: dict[str, Sequence[OHLCBar]] | None = None,
        native_higher_timeframe_sources: dict[str, dict[str, object]] | None = None,
        native_analysis_period_bars: dict[str, Sequence[OHLCBar]] | None = None,
        display_period_bars: dict[str, Sequence[OHLCBar]] | None = None,
        provider_day_offset_seconds: int = 0,
    ) -> dict[str, object]:
        if bar.symbol != self.instrument or bar.timeframe != "M1":
            raise ValueError("scheduler accepts only the configured instrument's M1 bars")
        timestamp = parse_utc(bar.timestamp_utc)
        if self._last_timestamp is not None and timestamp <= self._last_timestamp:
            raise ValueError("out-of-order or duplicate M1 bar")
        missing_minutes = 0
        if self._last_timestamp is not None:
            elapsed_minutes = int((timestamp - self._last_timestamp).total_seconds() // 60)
            missing_minutes = max(0, elapsed_minutes - self.expected_interval_minutes)
        pending_bars = (self._bars + [bar])[-self.max_bars:]
        close_time = timestamp + timedelta(minutes=1)
        snapshot = build_snapshot(
            pending_bars,
            as_of_utc=close_time,
            provider=self.provider or bar.provider,
            instrument=self.instrument,
            selected_trading_timeframe=self.selected_trading_timeframe,
            native_higher_timeframe_bars=native_higher_timeframe_bars,
            native_higher_timeframe_sources=native_higher_timeframe_sources,
            native_analysis_period_bars=native_analysis_period_bars,
            display_period_bars=display_period_bars,
            provider_day_offset_seconds=provider_day_offset_seconds,
        )
        snapshot["stream_integrity"] = {
            "bar_timestamp_utc": iso_utc(timestamp),
            "bar_close_utc": iso_utc(close_time),
            "status": "gap_detected" if missing_minutes else "contiguous_since_previous_bar",
            "missing_minutes": missing_minutes,
        }
        if missing_minutes:
            snapshot["data_integrity"]["gaps"] = "detected"
            snapshot["decision"]["state"] = "WAIT_DATA"
            snapshot["decision"]["trigger_requirements"].append("resolve_stream_gap_before_live_use")
            snapshot["decision"]["confidence"] = "not_calibrated"
        else:
            snapshot["data_integrity"]["gaps"] = "contiguous_since_previous_bar"
        snapshot["live_change"] = summarize_snapshot_delta(self._last_emitted_snapshot, snapshot)
        checkpoint = _delta_checkpoint(snapshot)
        # Commit only after construction/checkpoint succeeds. A failed bar
        # remains eligible on retry rather than silently advancing the cursor.
        self._bars = pending_bars
        self._last_timestamp = timestamp
        self._last_emitted_snapshot = checkpoint
        return snapshot

    def health(
        self,
        *,
        now_utc: str | datetime | None = None,
        max_delay_minutes: int = 3,
    ) -> dict[str, object]:
        """Return a deterministic stream-health record for a watchdog."""

        if self._last_timestamp is None:
            return {"status": "no_data", "last_bar_timestamp_utc": None, "delay_minutes": None}
        now = parse_utc(now_utc) if now_utc is not None else datetime.now(timezone.utc)
        expected_close = self._last_timestamp + timedelta(minutes=self.expected_interval_minutes)
        delay_minutes = max(0.0, (now - expected_close).total_seconds() / 60.0)
        status = "stale" if delay_minutes > max_delay_minutes else "healthy"
        return {
            "status": status,
            "last_bar_timestamp_utc": iso_utc(self._last_timestamp),
            "expected_last_close_utc": iso_utc(expected_close),
            "delay_minutes": round(delay_minutes, 3),
            "max_delay_minutes": max_delay_minutes,
        }

    def replay(self, bars: Iterable[OHLCBar]) -> Iterable[dict[str, object]]:
        for bar in bars:
            yield self.ingest(bar)


def _cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", required=True, type=Path)
    parser.add_argument("--as-of-utc", required=True)
    parser.add_argument("--provider")
    parser.add_argument("--selected-timeframe", default="M5")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    bars = load_m1_csv(args.csv)
    snapshot = build_snapshot(
        bars,
        as_of_utc=args.as_of_utc,
        provider=args.provider,
        selected_trading_timeframe=args.selected_timeframe,
    )
    rendered = json.dumps(snapshot, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    else:
        print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
