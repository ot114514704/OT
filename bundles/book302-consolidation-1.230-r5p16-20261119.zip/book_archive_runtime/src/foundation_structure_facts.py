"""Read-only foundation facts projected from :mod:`live_structure_graph`.

This module is deliberately a *projection*, not a second structure detector.
The native graph remains the sole source of A->B observations and causal
cross-period paths.  The projection removes measurement/entry concerns so the
structure phase can be inspected, replayed and validated independently of the
production chart.
"""

from __future__ import annotations

import argparse
import copy
import gzip
import json
from datetime import datetime, timezone, timedelta
from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping

try:  # package execution: python -m src.foundation_structure_facts
    from .live_structure_graph import NativeStructureGraph, PERIODS, SOURCE_REFS
    from .live_nested_stage_review import MINUTES, _time
except ImportError:  # direct execution during local inspection
    from live_structure_graph import NativeStructureGraph, PERIODS, SOURCE_REFS
    from live_nested_stage_review import MINUTES, _time


SCHEMA = "xauusd_foundation_structure_facts_v1"
FOUNDATION_PERIODS = tuple(PERIODS)
DIRECT_PARENT = {
    tf: FOUNDATION_PERIODS[i - 1] if i else None
    for i, tf in enumerate(FOUNDATION_PERIODS)
}


def _json(value: Any) -> Any:
    """Return a detached JSON-compatible value for a projection field."""
    return copy.deepcopy(value)


def _evidence_ids(node: Mapping[str, Any]) -> list[str]:
    source = node.get("source_leg_id")
    components = node.get("component_leg_ids") or []
    ids = [f"native:{node.get('timeframe')}:{source}"] if source else []
    ids.extend(f"native_component:{node.get('timeframe')}:{part}" for part in components)
    return ids


def _compact_context(value: Any) -> Any:
    """Keep observed context, excluding downstream measurement semantics."""
    if not isinstance(value, Mapping):
        if isinstance(value, list):
            return [_compact_context(item) for item in value]
        return _json(value)
    allowed = {
        "status", "basis", "state", "direction", "reason", "known_at_utc",
        "timeframe", "node_id", "origin", "terminal", "direction",
        "relation_type", "role", "process_id", "parent_regime_state",
        "parent_regime_direction", "expected_direct_parent_timeframe",
        "direct_parent_status", "bound_direct_parent", "outer_contexts",
        "selected", "immediate", "outer", "available_parent_timeframes",
        "competing_parent_processes", "parent_wave_ownership_proven",
        "working", "direct_parent", "owner", "outer_owner", "candidate_count",
        "component_count", "kind", "witnesses", "native_closed_through_utc",
        "range_exit", "alignment", "local_direction", "net_displacement_direction",
        "endpoint_direction_agrees", "parent_direction", "parent_relation_role",
        "ruler_bias", "measurement_role", "role_basis", "working_structure_direction",
    }
    result = {}
    for key, val in value.items():
        if key not in allowed:
            continue
        if key in {"origin", "terminal"} and isinstance(val, Mapping):
            result[key] = {
                field: _json(val[field])
                for field in ("kind", "price", "pivot_timestamp_utc", "confirmed_at_utc")
                if field in val
            }
        elif key == "witnesses" and isinstance(val, list):
            result[key] = [
                {
                    field: _json(point[field])
                    for field in ("kind", "price", "pivot_timestamp_utc", "confirmed_at_utc")
                    if field in point
                }
                for point in val if isinstance(point, Mapping)
            ]
        else:
            result[key] = _compact_context(val)
    return result


def _foundation_node(node: Mapping[str, Any]) -> dict[str, Any]:
    """Project one native node without importing downstream trade concepts."""
    return {
        "node_id": node["node_id"],
        "timeframe": node["timeframe"],
        "source_leg_id": node["source_leg_id"],
        "component_leg_ids": _json(node.get("component_leg_ids") or []),
        "origin": _json(node["origin"]),
        "terminal": _json(node["terminal"]),
        "known_at_utc": node["known_at_utc"],
        # A source exists before its parent may be known. Later ownership is
        # queried from relation events; never rewrite this initial observation.
        "owner_id": None,
        "owner_status": "unknown_at_initial_observation_query_relation_events",
        "scope_id": node["node_id"],
        "observed_at_utc": node["terminal"]["pivot_timestamp_utc"],
        "rule_id": "native_structure_graph_exact_endpoints_and_components",
        "rule_version": "foundation_projection_r2",
        "status": "observed_native_source_candidate",
        "unknown_reason": "author_wave_degree_unreviewed; parent queried at independent event time",
        "direction_observation": node.get("direction"),
        "local_regime": _compact_context(node.get("local_regime")),
        "structure_scope": _compact_context(node.get("structure_scope")),
        "range_container": _compact_context(node.get("range_container")),
        "accumulation_context": _compact_context(node.get("accumulation_context")),
        "observed_same_period_context": _compact_context(node.get("observed_same_period_context")),
        "observed_background_context": _compact_context(node.get("observed_background_context")),
        "observed_pullback_context": _compact_context(node.get("observed_pullback_context")),
        "current_structure_context": _compact_context(node.get("current_structure_context")),
        "direction_context": _compact_context(node.get("direction_context")),
        "evidence_ids": _evidence_ids(node),
        "unknown_fields": {
            "author_wave_degree": "unknown",
            "institutional_accumulation": "unknown",
            "entry": "unknown",
            "target": "unknown",
            "outcome": "unknown",
        },
        "author_wave_degree_adjudicated": False,
        "trade_permission": False,
    }


def _causal_relations(graph: NativeStructureGraph) -> list[dict[str, Any]]:
    """Preserve adjacent-parent events at their own clocks, up to the snapshot.

    A child may be confirmed before its parent. Comparing a relation's clock
    to the child's first clock permanently discarded legitimate later links.
    Consumers must query relation events at their requested cutoff instead.
    """
    output: list[dict[str, Any]] = []
    for relation in graph.links:
        child = graph.nodes.get(relation.get("child_node_id"))
        if not child:
            continue
        # The foundation ledger intentionally keeps the configured adjacent
        # parent only.  Farther ancestors remain available in the native graph
        # for later adapters, but they must not masquerade as the direct
        # parent in this first structure layer.
        if relation.get("parent_timeframe") != DIRECT_PARENT.get(relation.get("child_timeframe")):
            continue
        if _time(relation["known_at_utc"]) > _time(graph.snapshot["as_of_utc"]):
            continue
        row = {
            key: _json(relation[key])
            for key in (
                "relation_id", "child_node_id", "parent_node_id", "child_timeframe",
                "parent_timeframe", "relation_type", "role", "process_id",
                "path_origin_node_id", "path_terminal_node_id", "known_at_utc",
            )
            if key in relation
        }
        row.update(owner_id=relation["parent_node_id"],
                   evidence_ids=list(dict.fromkeys(relation[key] for key in (
                       "child_node_id", "parent_node_id", "path_origin_node_id",
                       "path_terminal_node_id") if relation.get(key))),
                   status="observed_native_path_relation_candidate",
                   trade_permission=False)
        output.append(row)
    output.sort(key=lambda row: (row.get("known_at_utc", ""), row.get("relation_id", "")))
    return output


def _attach_snapshot_owners(period_rows: Mapping[str, Any],
                            relations: list[Mapping[str, Any]]) -> None:
    """Attach a non-destructive latest owner view to each source object.

    ``owner_id`` on a node remains null because the source is an immutable
    observation made before a parent relation necessarily existed.  The
    additional fields answer the practical review question "who owns this at
    the packet cutoff?" without rewriting the original observation or hiding
    competing parent events.
    """
    by_child: dict[str, list[Mapping[str, Any]]] = {}
    for relation in relations:
        by_child.setdefault(relation.get("child_node_id"), []).append(relation)
    for row in period_rows.values():
        for node in row.get("nodes", []):
            links = by_child.get(node.get("node_id"), [])
            owners = sorted({link.get("parent_node_id") for link in links if link.get("parent_node_id")})
            if len(owners) == 1:
                node["owner_at_snapshot_id"] = owners[0]
                node["owner_at_snapshot_status"] = "observed_direct_parent_candidate"
            elif owners:
                node["owner_at_snapshot_id"] = None
                node["owner_at_snapshot_status"] = "competing_direct_parent_candidates"
            else:
                node["owner_at_snapshot_id"] = None
                node["owner_at_snapshot_status"] = (
                    "root_timeframe" if DIRECT_PARENT.get(node.get("timeframe")) is None
                    else "direct_parent_unknown")


def _event_ledger(period_rows: Mapping[str, Any],
                  relations: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Create a small, causal event ledger for source/return review.

    The native graph already provides the authoritative A→B nodes and direct
    parent links.  This ledger makes their lifecycle explicit: source
    observation, same-period component scope, and return/decomposition
    relation.  It intentionally records C/D/B-recovery as unknown when no
    explicit event exists; it never invents a later endpoint from a target or
    a result.
    """
    events: list[dict[str, Any]] = []
    for row in period_rows.values():
        for node in row.get("nodes", []):
            node_id = node["node_id"]
            events.append({
                "event_id": f"{node_id}:source_observed",
                "event_type": "source_observed",
                "object_id": node_id,
                "timeframe": node["timeframe"],
                "scope_id": node["scope_id"],
                "owner_id": node.get("owner_at_snapshot_id"),
                "observed_at_utc": node["observed_at_utc"],
                "known_at_utc": node["known_at_utc"],
                "status": node["status"],
                "evidence_ids": list(node.get("evidence_ids") or []),
                "unknown_reason": node.get("unknown_reason"),
                "c_versions": [],
                "d_event": {"status": "unknown", "unknown_reason": "no_explicit_D_event_in_native_graph"},
                "b_recovery_event": {"status": "unknown", "unknown_reason": "no_explicit_B_recovery_event_in_native_graph"},
            })
            components = list(node.get("component_leg_ids") or [])
            if len(components) > 1:
                events.append({
                    "event_id": f"{node_id}:components",
                    "event_type": "same_period_component_scope",
                    "object_id": node_id,
                    "timeframe": node["timeframe"],
                    "scope_id": node["scope_id"],
                    "owner_id": node_id,
                    "observed_at_utc": node["observed_at_utc"],
                    "known_at_utc": node["known_at_utc"],
                    "status": "observed_native_components",
                    "evidence_ids": list(node.get("evidence_ids") or []),
                    "component_leg_ids": components,
                    "unknown_reason": "component_degree_and_author_wave_label_unadjudicated",
                })
    for relation in relations:
        kind = "return_relation_observed" if relation.get("relation_type") == "return" else "decomposition_relation_observed"
        events.append({
            "event_id": f"{relation['relation_id']}:event",
            "event_type": kind,
            "object_id": relation["child_node_id"],
            "timeframe": relation["child_timeframe"],
            "scope_id": relation["process_id"],
            "owner_id": relation.get("parent_node_id"),
            "observed_at_utc": relation["known_at_utc"],
            "known_at_utc": relation["known_at_utc"],
            "status": relation.get("status", "observed_native_path_relation_candidate"),
            "evidence_ids": list(relation.get("evidence_ids") or []),
            "relation_id": relation["relation_id"],
            "relation_type": relation.get("relation_type"),
            "role": relation.get("role"),
            "unknown_reason": "C/D/B-recovery semantics remain separate from this native parent relation",
        })
    events.sort(key=lambda row: (row.get("known_at_utc", ""), row.get("event_id", "")))
    return events


def _background_judgment(timeframe: str, nodes: list[Mapping[str, Any]],
                         relations: list[Mapping[str, Any]],
                         as_of_utc: str) -> dict[str, Any]:
    """Produce the current read-only background from this period's own nodes.

    This is an explicit structure observation, not a strategy signal.  It
    uses only nodes whose ``known_at_utc`` is inside the snapshot and keeps the
    latest direct-parent relation separate from the local judgment.  The
    thresholds are deliberately exposed so a reviewer can challenge them
    against manual cases instead of mistaking a score for author truth.
    """
    visible = [node for node in nodes
               if _time(node.get("known_at_utc")) <= _time(as_of_utc)]
    visible.sort(key=lambda node: (
        node.get("terminal", {}).get("pivot_timestamp_utc", ""),
        node.get("known_at_utc", ""), node.get("node_id", "")))
    if not visible:
        return {
            "timeframe": timeframe, "as_of_utc": as_of_utc,
            "state": "unknown", "direction": None,
            "status": "no_known_native_structure", "confidence": "unknown",
            "current_node_id": None, "owner_id": None,
            "evidence_ids": [], "recent_node_ids": [],
            "candidate_roles": {
                "overall": {"status": "unknown", "state": "unknown", "direction": None},
                "trend": {"status": "unknown", "direction": None},
                "pullback": {"status": "unknown", "direction": None},
                "range": {"status": "unknown", "direction": None},
                "transition": {"status": "unknown", "direction": None},
            },
            "complete_wave": {"status": "unknown", "source_leg_id": None,
                              "origin": None, "terminal": None,
                              "author_wave_degree": "unknown", "evidence_ids": []},
            "same_period_context": {"timeframe": timeframe, "status": "unknown",
                                     "scope": "same_native_timeframe", "node_id": None,
                                     "hierarchy_status": "unknown",
                                     "component_count": None,
                                     "immediate": None, "outer": None,
                                     "candidate_count": 0,
                                     "author_wave_degree": "unknown"},
            "unknown_reason": "no native node known at cutoff",
            "rule_id": "foundation_background_v1", "rule_version": "1",
            "trade_permission": False,
        }
    recent = visible[-12:]
    signed = {"up": 0.0, "down": 0.0}
    counts = {"up": 0, "down": 0}
    regimes = {"trend": 0, "range": 0, "transition": 0, "unknown": 0}
    evidence_ids: list[str] = []
    for node in recent:
        direction = node.get("direction_observation")
        displacement = abs(float(node["terminal"]["price"]) - float(node["origin"]["price"]))
        if direction in signed:
            signed[direction] += displacement
            counts[direction] += 1
        state = (node.get("local_regime") or {}).get("state")
        regimes[state if state in regimes else "unknown"] += 1
        evidence_ids.extend(node.get("evidence_ids") or [])
    total = signed["up"] + signed["down"]
    dominant = "up" if signed["up"] > signed["down"] else "down" if signed["down"] > signed["up"] else None
    dominance = (max(signed.values()) / total) if total else 0.0
    direction_balance = (max(counts.values()) / max(1, sum(counts.values())))
    latest = recent[-1]
    latest_state = (latest.get("local_regime") or {}).get("state")
    observed_same = latest.get("observed_same_period_context") or {}
    structure_scope = latest.get("structure_scope") or {}
    immediate = observed_same.get("immediate")
    outer = observed_same.get("outer")
    if immediate or outer:
        hierarchy_status = "nested_same_period_candidate"
    elif int(structure_scope.get("component_count") or 0) > 1:
        hierarchy_status = "compound_same_period_span"
    else:
        hierarchy_status = "unbound_same_period_level"
    if latest_state == "transition":
        state, status = "transition", "latest_native_context_transition"
    elif dominant and dominance >= 0.60 and direction_balance >= 0.55:
        state, status = "trend", "recent_native_displacement_dominant"
    elif latest_state == "range" or (counts["up"] and counts["down"] and dominance < 0.60):
        state, status = "range", "mixed_native_swings_or_range_context"
    else:
        state, status = "unknown", "insufficient_directional_agreement"
    parent_rows = [row for row in relations
                   if row.get("child_node_id") == latest.get("node_id")
                   and _time(row.get("known_at_utc")) <= _time(as_of_utc)]
    parent_ids = sorted({row.get("parent_node_id") for row in parent_rows if row.get("parent_node_id")})
    parent_status = ("observed_direct_parent_candidate" if len(parent_ids) == 1
                     else "competing_direct_parent_candidates" if parent_ids
                     else "root_timeframe" if DIRECT_PARENT.get(timeframe) is None
                     else "direct_parent_unknown")
    latest_direction = latest.get("direction_observation")
    pullback_candidate = bool(
        dominant and state == "trend" and
        (latest_direction != dominant or latest_state in {"range", "transition"})
    )
    candidate_roles = {
        "overall": {"status": "candidate", "state": state,
                     "direction": dominant if state == "trend" else None,
                     "node_id": latest.get("node_id"),
                     "evidence_ids": list(dict.fromkeys(evidence_ids))},
        "trend": {"status": "candidate" if state == "trend" else "not_observed",
                   "direction": dominant if state == "trend" else None},
        "pullback": {"status": "candidate" if pullback_candidate else "not_observed",
                      "direction": latest_direction if pullback_candidate else None,
                      "basis": "latest_native_direction_or_local_regime_against_recent_dominance"
                      if pullback_candidate else None},
        "range": {"status": "candidate" if state == "range" else "not_observed",
                   "direction": None},
        "transition": {"status": "candidate" if state == "transition" else "not_observed",
                        "direction": None},
    }
    return {
        "timeframe": timeframe, "as_of_utc": as_of_utc,
        "state": state, "direction": dominant if state == "trend" else None,
        "status": status, "confidence": "candidate",
        "current_node_id": latest.get("node_id"),
        "current_source_leg_id": latest.get("source_leg_id"),
        "current_range": {"origin": latest.get("origin"), "terminal": latest.get("terminal")},
        "owner_id": parent_ids[0] if len(parent_ids) == 1 else None,
        "owner_status": parent_status,
        "parent_timeframe": DIRECT_PARENT.get(timeframe),
        "evidence_ids": list(dict.fromkeys(evidence_ids)),
        "recent_node_ids": [node.get("node_id") for node in recent],
        "candidate_roles": candidate_roles,
        "complete_wave": {
            "status": "observed_native_span_not_author_degree",
            "timeframe": timeframe,
            "source_leg_id": latest.get("source_leg_id"),
            "node_id": latest.get("node_id"),
            "origin": latest.get("origin"), "terminal": latest.get("terminal"),
            "known_at_utc": latest.get("known_at_utc"),
            "author_wave_degree": "unknown",
            "evidence_ids": list(dict.fromkeys(evidence_ids)),
        },
        "same_period_context": {
            "timeframe": timeframe, "status": "observed_native_context",
            "scope": "same_native_timeframe", "node_id": latest.get("node_id"),
            "recent_node_ids": [node.get("node_id") for node in recent],
            "hierarchy_status": hierarchy_status,
            "component_count": structure_scope.get("component_count"),
            "immediate": immediate,
            "outer": outer,
            "candidate_count": observed_same.get("candidate_count", 0),
            "author_wave_degree": "unknown",
        },
        "counts": {"recent_nodes": len(recent), "directions": counts, "regimes": regimes},
        "features": {"signed_displacement": signed, "dominance": dominance,
                      "direction_balance": direction_balance,
                      "latest_local_regime": latest_state},
        "thresholds": {"trend_dominance": 0.60, "trend_direction_balance": 0.55,
                       "recent_node_limit": 12},
        "unknown_reason": None if state != "unknown" else status,
        "rule_id": "foundation_background_v1", "rule_version": "1",
        "trade_permission": False,
    }


def _attach_background_parent_context(period_rows: Mapping[str, Any]) -> None:
    """Add the configured adjacent parent's observed context and joint view.

    ``parent_context`` is the observed owner node.  ``joint_context`` is a
    separate, same-cutoff comparison of the two period background judgments.
    It never promotes a local range/transition to a confirmed pullback and it
    never walks past the configured direct parent.
    """
    by_id = {
        node.get("node_id"): node
        for row in period_rows.values()
        for node in row.get("nodes", [])
    }
    for tf, row in period_rows.items():
        background = row.get("background_judgment") or {}
        owner_id = background.get("owner_id")
        parent_tf = DIRECT_PARENT.get(tf)
        owner = by_id.get(owner_id) if owner_id else None
        if parent_tf is None:
            background["parent_context"] = {
                "timeframe": None, "status": "root_timeframe",
                "node_id": None, "state": None, "direction": None,
                "unknown_reason": None,
            }
        elif owner and owner.get("timeframe") == parent_tf:
            local = owner.get("local_regime") or {}
            background["parent_context"] = {
                "timeframe": parent_tf, "status": "observed_direct_parent_context",
                "node_id": owner.get("node_id"),
                "state": local.get("state"),
                "direction": owner.get("direction"),
                "known_at_utc": owner.get("known_at_utc"),
                "evidence_ids": list(owner.get("evidence_ids") or []),
                "unknown_reason": None,
            }
        else:
            background["parent_context"] = {
                "timeframe": parent_tf,
                "status": ("competing_or_unresolved_owner" if background.get("owner_status")
                           == "competing_direct_parent_candidates"
                           else "direct_parent_unknown"),
                "node_id": None, "state": None, "direction": None,
                "unknown_reason": "no single direct parent is knowable at cutoff",
            }

        parent_row = period_rows.get(parent_tf) if parent_tf else None
        parent_background = (parent_row or {}).get("background_judgment") or {}
        local_state = background.get("state")
        local_direction = background.get("direction")
        parent_state = parent_background.get("state")
        parent_direction = parent_background.get("direction")
        local_node_id = background.get("current_node_id")
        parent_node_id = parent_background.get("current_node_id")
        local_evidence = list(background.get("evidence_ids") or [])
        parent_evidence = list(parent_background.get("evidence_ids") or [])
        joint_evidence = list(dict.fromkeys(local_evidence + parent_evidence))

        if parent_tf is None:
            joint_status = "root_timeframe"
            alignment = "root"
            candidate_role = "overall_only"
            unknown_reason = None
        elif parent_state == "unknown":
            joint_status = "parent_background_unknown"
            alignment = "unknown"
            candidate_role = "unknown_parent_context"
            unknown_reason = "direct_parent_background_unknown_at_same_cutoff"
        elif local_state == "unknown":
            joint_status = "local_background_unknown"
            alignment = "unknown"
            candidate_role = "unknown_local_context"
            unknown_reason = "local_background_unknown_at_same_cutoff"
        elif local_state == "trend" and parent_state == "trend":
            if local_direction and parent_direction and local_direction == parent_direction:
                joint_status = "trend_aligned_with_direct_parent"
                alignment = "aligned"
                candidate_role = "trend_continuation_candidate"
                unknown_reason = None
            elif local_direction and parent_direction:
                joint_status = "trend_opposes_direct_parent"
                alignment = "opposed"
                candidate_role = "counter_parent_trend_candidate"
                unknown_reason = None
            else:
                joint_status = "trend_direction_unresolved"
                alignment = "unknown"
                candidate_role = "unknown_trend_alignment"
                unknown_reason = "one_or_both_trend_directions_missing"
        elif parent_state == "trend" and local_state == "transition":
            joint_status = "local_transition_under_parent_trend"
            alignment = "nontrend_under_parent_trend"
            candidate_role = "pullback_or_transition_candidate"
            unknown_reason = "transition_not_adjudicated_as_pullback"
        elif parent_state == "trend" and local_state == "range":
            joint_status = "local_range_under_parent_trend"
            alignment = "nontrend_under_parent_trend"
            candidate_role = "range_or_pullback_candidate"
            unknown_reason = "range_not_adjudicated_as_pullback"
        elif local_state == "trend" and parent_state in {"range", "transition"}:
            joint_status = "local_trend_under_nontrend_parent"
            alignment = "local_trend_parent_nontrend"
            candidate_role = "local_trend_candidate_parent_context_nontrend"
            unknown_reason = "parent_nontrend_context_does_not_confirm_local_structure"
        else:
            joint_status = "nontrend_local_parent_context"
            alignment = "nontrend_or_mixed"
            candidate_role = "range_or_transition_candidate"
            unknown_reason = "neither_period_has_aligned_trend_context"

        background["joint_context"] = {
            "timeframe": tf,
            "parent_timeframe": parent_tf,
            "as_of_utc": background.get("as_of_utc"),
            "status": joint_status,
            "alignment": alignment,
            "candidate_role": candidate_role,
            "basis": "same_cutoff_direct_parent_background_only",
            "local": {
                "state": local_state,
                "direction": local_direction,
                "node_id": local_node_id,
                "evidence_ids": local_evidence,
            },
            "parent": {
                "timeframe": parent_tf,
                "state": parent_state if parent_tf else None,
                "direction": parent_direction if parent_tf else None,
                "node_id": parent_node_id if parent_tf else None,
                "evidence_ids": parent_evidence if parent_tf else [],
                "status": parent_background.get("status") if parent_tf else "root_timeframe",
            },
            "evidence_ids": joint_evidence,
            "unknown_reason": unknown_reason,
            "rule_id": "foundation_joint_background_v1",
            "rule_version": "1",
            "trade_permission": False,
        }


def parent_relations_at(packet: Mapping[str, Any], node_id: str,
                        as_of_utc: str) -> dict[str, Any]:
    """Query parent evidence without changing a source or borrowing a C.

    This queries recorded events, not a fresh causal rebuild of the detector.
    It does not return contexts from a later snapshot as if they were earlier.
    """
    cutoff = _time(as_of_utc)
    if cutoff > _time(packet["snapshot"]["as_of_utc"]):
        raise ValueError("relation query exceeds frozen snapshot")
    nodes = {n["node_id"]: n for row in packet["periods"].values()
             for n in row["nodes"]}
    if node_id not in nodes:
        raise KeyError(node_id)
    node = nodes[node_id]
    result = dict(node_id=node_id, timeframe=node["timeframe"],
                  as_of_utc=as_of_utc, owner_id=None, relations=[],
                  status="source_not_yet_known", trade_permission=False)
    if _time(node["known_at_utc"]) > cutoff:
        return result
    result["status"] = ("root_timeframe" if DIRECT_PARENT[node["timeframe"]] is None
                        else "direct_parent_unknown")
    rows = []
    for row in packet["relations"]:
        if row["child_node_id"] != node_id or _time(row["known_at_utc"]) > cutoff:
            continue
        parent = nodes.get(row["parent_node_id"])
        if (not parent or parent["timeframe"] != DIRECT_PARENT[node["timeframe"]]
                or _time(parent["known_at_utc"]) > cutoff):
            raise ValueError("invalid parent event; validate foundation packet")
        rows.append(_json(row))
    result["relations"] = rows
    owners = {row["parent_node_id"] for row in rows}
    if len(owners) == 1:
        result.update(owner_id=next(iter(owners)), status="observed_direct_parent_candidate")
    elif owners:
        result["status"] = "competing_direct_parent_candidates"
    return result


def _native_evidence(graph: NativeStructureGraph) -> tuple[dict, dict]:
    """Store each native OHLC once; source evidence references a bounded span.

    Compound source IDs may not be original ledger leg IDs. They resolve to
    the exact graph node and its same-period component IDs, not a fabricated
    raw-leg record. Provider and instrument are inherited only from the
    already validated native snapshot.
    """
    bars_by_period, evidence = {}, {}
    node_by_source = {(n["timeframe"], n["source_leg_id"]): n for n in graph.nodes.values()}
    positions = {}
    for tf in FOUNDATION_PERIODS:
        raw = graph.periods.get(tf, {}).get("raw", {})
        ordered = sorted(raw)
        bars_by_period[tf] = [{k: _json(raw[t][k]) for k in
                              ("timestamp_utc", "open", "high", "low", "close")}
                             for t in ordered]
        positions[tf] = {t: i for i, t in enumerate(ordered)}
    for node in graph.nodes.values():
        tf = node["timeframe"]
        references = [(f"native:{tf}:{node['source_leg_id']}", node)]
        for part in node.get("component_leg_ids", []):
            component = node_by_source.get((tf, part))
            if component is None:
                references.append((f"native_component:{tf}:{part}", None))
            else:
                references.append((f"native_component:{tf}:{part}", component))
        for identity, source in references:
            if source is None:
                evidence[identity] = dict(
                    evidence_id=identity, kind="native_component_reference",
                    timeframe=tf, node_id=node["node_id"],
                    source_leg_id=identity.split(":", 2)[-1], component_leg_ids=[],
                    known_at_utc=node["known_at_utc"], resolution_status="unknown",
                    unknown_reason="component_leg_not_present_in_native_node_index",
                    provider=graph.snapshot["provider"], instrument=graph.snapshot["instrument"])
                continue
            record = dict(evidence_id=identity, kind="native_source_path", timeframe=tf,
                          node_id=source["node_id"], source_leg_id=source["source_leg_id"],
                          component_leg_ids=_json(source["component_leg_ids"]),
                          known_at_utc=source["known_at_utc"],
                          origin=_json(source["origin"]), terminal=_json(source["terminal"]),
                          bar_start=positions[tf][_time(source["origin"]["pivot_timestamp_utc"])],
                          bar_end=positions[tf][_time(source["terminal"]["pivot_timestamp_utc"])],
                          provider=graph.snapshot["provider"], instrument=graph.snapshot["instrument"])
            if identity in evidence and evidence[identity] != record:
                raise ValueError(f"conflicting evidence identity: {identity}")
            evidence[identity] = record
    return bars_by_period, evidence


def project_graph(graph: NativeStructureGraph) -> dict[str, Any]:
    """Create the foundation-only packet from an already-built native graph."""
    period_rows: dict[str, dict[str, Any]] = {}
    for tf in FOUNDATION_PERIODS:
        period = graph.periods.get(tf, {})
        nodes = [
            _foundation_node(node)
            for node in graph.nodes.values()
            if node.get("timeframe") == tf
        ]
        nodes.sort(key=lambda row: (row["known_at_utc"], row["node_id"]))
        period_rows[tf] = {
            "timeframe": tf,
            "status": period.get("status", "unavailable"),
            "native_bar_count": period.get("native_bar_count", 0),
            "native_closed_through_utc": period.get("native_closed_through_utc"),
            "rejected_leg_count": period.get("rejected_leg_count", 0),
            "node_ids": [row["node_id"] for row in nodes],
            "nodes": nodes,
        }

    native_bars, evidence = _native_evidence(graph)
    relations = _causal_relations(graph)
    for tf, row in period_rows.items():
        row["background_judgment"] = _background_judgment(
            tf, row["nodes"], relations, graph.snapshot["as_of_utc"])
    _attach_snapshot_owners(period_rows, relations)
    _attach_background_parent_context(period_rows)
    event_ledger = _event_ledger(period_rows, relations)
    payload: dict[str, Any] = {
        "schema": SCHEMA,
        "projection_revision": 3,
        "snapshot": {
            "snapshot_id": graph.snapshot["snapshot_id"],
            "as_of_utc": graph.snapshot["as_of_utc"],
            "instrument": graph.snapshot.get("instrument"),
            "provider": graph.snapshot.get("provider"),
        },
        "timeframe_ladder": list(FOUNDATION_PERIODS),
        "direct_parent_map": DIRECT_PARENT,
        "periods": period_rows,
        "native_bars": native_bars,
        "evidence": evidence,
        "relations": relations,
        "event_ledger": event_ledger,
        "relation_clock_policy": "event_known_at_not_child_first_known_at",
        "condition_source_refs": list(SOURCE_REFS),
        "boundary": (
            "Observed native bars, same-period A->B nodes, same-period context, "
            "and directly adjacent parent relations only."
        ),
        "forbidden_downstream": [
            "direct_flip", "entry", "target", "stop", "three_push_decision",
            "ict_label", "wave_degree_label", "trade_permission",
        ],
        "automatic_trade_permission": False,
        "author_accuracy_verified": False,
    }
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    payload["content_sha256"] = sha256(canonical.encode("utf-8")).hexdigest()
    return payload


def project_snapshot(snapshot: Mapping[str, Any]) -> dict[str, Any]:
    """Build and project one immutable snapshot."""
    return project_graph(NativeStructureGraph(snapshot))


def validate_foundation_facts(packet: Mapping[str, Any]) -> list[str]:
    """Check transport/clock invariants, not semantic segmentation accuracy."""
    errors: list[str] = []
    if packet.get("schema") != SCHEMA:
        errors.append("schema")
    if tuple(packet.get("timeframe_ladder", ())) != FOUNDATION_PERIODS:
        errors.append("timeframe_ladder")
    if packet.get("direct_parent_map") != DIRECT_PARENT:
        errors.append("direct_parent_map")
    if packet.get("automatic_trade_permission") is not False:
        errors.append("automatic_trade_permission")
    if packet.get("author_accuracy_verified") is not False:
        errors.append("author_accuracy_verified")
    snapshot_clock = packet.get("snapshot", {}).get("as_of_utc")
    try:
        snapshot_time = _time(snapshot_clock)
    except Exception:
        errors.append("snapshot_clock")
        snapshot_time = None

    node_by_id: dict[str, Mapping[str, Any]] = {}
    periods = packet.get("periods", {})
    if set(periods) != set(FOUNDATION_PERIODS):
        errors.append("periods")
    for tf in FOUNDATION_PERIODS:
        background = periods.get(tf, {}).get("background_judgment")
        if not isinstance(background, Mapping):
            errors.append(f"background_missing:{tf}")
        else:
            if background.get("timeframe") != tf:
                errors.append(f"background_timeframe:{tf}")
            if background.get("trade_permission") is not False:
                errors.append(f"background_trade:{tf}")
            if background.get("state") not in {"trend", "range", "transition", "unknown"}:
                errors.append(f"background_state:{tf}")
            if not background.get("evidence_ids") and background.get("state") != "unknown":
                errors.append(f"background_evidence:{tf}")
            parent_context = background.get("parent_context")
            if not isinstance(parent_context, Mapping):
                errors.append(f"background_parent_context:{tf}")
            elif parent_context.get("timeframe") != DIRECT_PARENT.get(tf):
                errors.append(f"background_parent_timeframe:{tf}")
            joint_context = background.get("joint_context")
            if not isinstance(joint_context, Mapping):
                errors.append(f"background_joint_context:{tf}")
            else:
                if joint_context.get("timeframe") != tf:
                    errors.append(f"background_joint_timeframe:{tf}")
                if joint_context.get("parent_timeframe") != DIRECT_PARENT.get(tf):
                    errors.append(f"background_joint_parent_timeframe:{tf}")
                if joint_context.get("trade_permission") is not False:
                    errors.append(f"background_joint_trade:{tf}")
                if not joint_context.get("evidence_ids") and background.get("state") != "unknown":
                    errors.append(f"background_joint_evidence:{tf}")
        for node in periods.get(tf, {}).get("nodes", []):
            if node.get("node_id") in node_by_id:
                errors.append(f"duplicate_node:{node.get('node_id')}")
            node_by_id[node.get("node_id")] = node
            if node.get("timeframe") != tf:
                errors.append(f"node_timeframe:{node.get('node_id')}")
            if not node.get("source_leg_id") or not node.get("evidence_ids"):
                errors.append(f"node_evidence:{node.get('node_id')}")
            if "owner_id" not in node or node.get("owner_id") is not None:
                errors.append(f"initial_owner:{node.get('node_id')}")
            if "owner_at_snapshot_id" not in node or "owner_at_snapshot_status" not in node:
                errors.append(f"snapshot_owner_fields:{node.get('node_id')}")
            if node.get("author_wave_degree_adjudicated") is not False:
                errors.append(f"node_degree:{node.get('node_id')}")
            if node.get("trade_permission") is not False:
                errors.append(f"node_trade:{node.get('node_id')}")
            try:
                known = _time(node["known_at_utc"])
                if snapshot_time is not None and known > snapshot_time:
                    errors.append(f"future_node:{node.get('node_id')}")
            except Exception:
                errors.append(f"node_clock:{node.get('node_id')}")

    evidence = packet.get("evidence", {})
    for node in node_by_id.values():
        for identity in node.get("evidence_ids", []):
            record = evidence.get(identity)
            if not record:
                errors.append(f"unresolved_node_evidence:{node['node_id']}:{identity}")
                continue
            try:
                if record["timeframe"] != node["timeframe"]:
                    errors.append(f"evidence_timeframe:{identity}")
                if record.get("resolution_status") == "unknown":
                    if not record.get("unknown_reason"):
                        errors.append(f"unknown_evidence_reason:{identity}")
                    continue
                if _time(record["known_at_utc"]) > _time(node["known_at_utc"]):
                    errors.append(f"future_evidence:{identity}")
            except (KeyError, TypeError, ValueError):
                errors.append(f"evidence_clock:{identity}")
    for identity, record in evidence.items():
        try:
            tf = record["timeframe"]
            source = node_by_id[record["node_id"]]
            if record.get("resolution_status") == "unknown":
                if (record.get("provider") != packet["snapshot"]["provider"] or
                        record.get("instrument") != packet["snapshot"]["instrument"]):
                    errors.append(f"evidence_feed:{identity}")
                continue
            bars = packet["native_bars"][tf]
            lo, hi = record["bar_start"], record["bar_end"]
            if not (isinstance(lo, int) and isinstance(hi, int) and 0 <= lo <= hi < len(bars)):
                raise ValueError("invalid native span")
            if (record["provider"] != packet["snapshot"]["provider"] or
                    record["instrument"] != packet["snapshot"]["instrument"]):
                errors.append(f"evidence_feed:{identity}")
            for key in ("timeframe", "source_leg_id", "known_at_utc", "origin", "terminal", "component_leg_ids"):
                if record[key] != source[key]:
                    errors.append(f"evidence_source_mismatch:{identity}:{key}")
            for endpoint, index in (("origin", lo), ("terminal", hi)):
                point = record[endpoint]
                bar = bars[index]
                field = {"confirmed_swing_high_candidate": "high",
                         "confirmed_swing_low_candidate": "low"}[point["kind"]]
                if bar["timestamp_utc"] != point["pivot_timestamp_utc"] or bar[field] != point["price"]:
                    errors.append(f"evidence_endpoint:{identity}:{endpoint}")
                if not (_time(bar["timestamp_utc"]) + timedelta(minutes=MINUTES[tf]) <=
                        _time(point["confirmed_at_utc"]) <= _time(record["known_at_utc"])):
                    errors.append(f"evidence_endpoint_clock:{identity}:{endpoint}")
        except (KeyError, IndexError, TypeError, ValueError):
            errors.append(f"invalid_evidence:{identity}")

    relation_ids = set()
    for relation in packet.get("relations", []):
        identity = relation.get("relation_id")
        if identity in relation_ids:
            errors.append(f"duplicate_relation:{identity}")
        relation_ids.add(identity)
        child = node_by_id.get(relation.get("child_node_id"))
        if not child:
            errors.append(f"orphan_relation:{relation.get('relation_id')}")
            continue
        if relation.get("parent_timeframe") != DIRECT_PARENT.get(relation.get("child_timeframe")):
            errors.append(f"non_adjacent_parent:{relation.get('relation_id')}")
        parent = node_by_id.get(relation.get("parent_node_id"))
        if not parent:
            errors.append(f"orphan_parent:{identity}")
        if relation.get("child_timeframe") != child.get("timeframe"):
            errors.append(f"child_timeframe_mismatch:{identity}")
        if parent and relation.get("parent_timeframe") != parent.get("timeframe"):
            errors.append(f"parent_timeframe_mismatch:{identity}")
        if relation.get("owner_id") != relation.get("parent_node_id"):
            errors.append(f"relation_owner:{identity}")
        expected_evidence = {relation.get(key) for key in (
            "child_node_id", "parent_node_id", "path_origin_node_id", "path_terminal_node_id")}
        if None in expected_evidence or set(relation.get("evidence_ids", [])) != expected_evidence:
            errors.append(f"relation_evidence:{identity}")
        witnesses = [node_by_id.get(key) for key in expected_evidence if key is not None]
        if any(w is None for w in witnesses):
            errors.append(f"unresolved_relation_evidence:{identity}")
        for key in ("path_origin_node_id", "path_terminal_node_id"):
            witness = node_by_id.get(relation.get(key))
            if witness and witness["timeframe"] != child["timeframe"]:
                errors.append(f"path_timeframe_mismatch:{identity}")
        try:
            known = _time(relation["known_at_utc"])
            if snapshot_time is not None and known > snapshot_time:
                errors.append(f"future_relation:{relation.get('relation_id')}")
            if any(w and _time(w["known_at_utc"]) > known for w in witnesses):
                errors.append(f"premature_relation:{identity}")
        except Exception:
            errors.append(f"relation_clock:{relation.get('relation_id')}")
    event_ids = set()
    for event in packet.get("event_ledger", []):
        event_id = event.get("event_id")
        if event_id in event_ids:
            errors.append(f"duplicate_event:{event_id}")
        event_ids.add(event_id)
        if event.get("object_id") not in node_by_id:
            errors.append(f"orphan_event:{event_id}")
        if event.get("timeframe") not in FOUNDATION_PERIODS:
            errors.append(f"event_timeframe:{event_id}")
        try:
            if snapshot_time is not None and _time(event["known_at_utc"]) > snapshot_time:
                errors.append(f"future_event:{event_id}")
            if _time(event["observed_at_utc"]) > _time(event["known_at_utc"]):
                errors.append(f"event_clock:{event_id}")
        except (KeyError, TypeError, ValueError):
            errors.append(f"invalid_event_clock:{event_id}")
        if not event.get("evidence_ids"):
            errors.append(f"event_evidence:{event_id}")
    return errors


def _load(path: Path) -> Mapping[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build the read-only XAUUSD foundation structure facts packet")
    parser.add_argument("snapshot", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    packet = project_snapshot(_load(args.snapshot))
    errors = validate_foundation_facts(packet)
    if errors:
        raise SystemExit("foundation validation failed: " + ", ".join(errors[:20]))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # Keep the sidecar cheap to load over the local dashboard.  The packet is
    # still deterministic and readable through the JSON viewer; pretty
    # printing a multi-period history needlessly multiplies its size.
    encoded = json.dumps(packet, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if args.output.suffix == ".gz":
        with gzip.open(args.output, "wb", compresslevel=6) as handle:
            handle.write(encoded)
    else:
        args.output.write_bytes(encoded)
    print(json.dumps({"schema": packet["schema"], "output": str(args.output),
                      "nodes": sum(len(row["nodes"]) for row in packet["periods"].values()),
                      "relations": len(packet["relations"]),
                      "content_sha256": packet["content_sha256"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
