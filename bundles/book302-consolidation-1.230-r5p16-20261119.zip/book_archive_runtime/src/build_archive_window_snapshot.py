"""Recompute an archive window with the existing indicator engine.

This creates a separate source-bound artifact. It never relabels production
geometry as HistData geometry or overwrites the active production snapshot.
"""
import argparse
import gzip
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from .live_xauusd_multitimeframe import OHLCBar, build_snapshot, TIMEFRAME_MINUTES
from .live_retracement_measurement_review import build_retracement_measurement_review
from .ict_archive_logic import calculate_ict_archive_logic

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / '03_work_queue/wells3_live_multitimeframe_vertical_slice_20260928/dashboard/long-history'


def closed_prefix(rows, cutoff, minutes, count):
    """Filter before selecting the tail: incomplete candles never enter analysis."""
    if count < 1 or minutes <= 0:
        raise ValueError('positive window count and period required')
    rows = np.asarray(rows, dtype=float).reshape(-1, 6)
    if len(rows) and (not np.isfinite(rows[:, :5]).all() or
                     np.any(np.diff(rows[:, 0]) <= 0)):
        raise ValueError('archive timestamps/OHLC must be finite and strictly ordered')
    return rows[rows[:, 0] + minutes * 60 <= cutoff][-count:]


def load_prefix(period, cutoff, count, directory=ARCHIVE):
    parts, available = [], 0
    for chunk in reversed(period['chunks']):
        if chunk['start'] >= cutoff:
            continue
        raw = gzip.decompress((directory / chunk['file']).read_bytes())
        rows = np.frombuffer(raw, dtype='<f8').reshape(-1, 6)
        rows = closed_prefix(rows, cutoff, period['minutes'], count)
        parts.insert(0, rows)
        available += len(rows)
        if available >= count:
            break
    return np.concatenate(parts)[-count:] if parts else np.empty((0, 6))


def mt5_weekly_prefix(dataset, cutoff, count, directory=ARCHIVE):
    """MT5 custom symbols label weekly candles at Sunday 00:00 UTC.

    Derive OHLC from the same archived daily prices. This explicit alternate
    calendar is used only by the custom-symbol consumer; web Monday bars stay
    unchanged. Missing trading days are never interpolated.
    """
    daily = load_prefix(dataset['periods']['D1'], cutoff, count*7+14, directory)
    groups = {}
    for row in daily:
        start = ((int(row[0])-259200)//604800)*604800+259200
        if start+604800>cutoff:
            continue
        if start not in groups:
            groups[start]=[start,*map(float,row[1:5]),float(row[5])]
        else:
            g=groups[start];g[2]=max(g[2],float(row[2]));g[3]=min(g[3],float(row[3]));g[4]=float(row[4]);g[5]+=float(row[5])
    return np.asarray(list(groups.values())[-count:],dtype=float).reshape(-1,6)


def build_archive_window(cutoff, timeframe, count=1024, directory=ARCHIVE, *, week_start='monday'):
    if count < 16 or count > 32768:
        raise ValueError('window count must be between 16 and 32768; archive itself is not truncated')
    catalog = json.loads((directory / 'catalog.json').read_text(encoding='utf-8'))
    dataset = next(item for item in catalog['datasets'] if item['id'] == 'HistData')
    instant = datetime.fromisoformat(cutoff.replace('Z', '+00:00'))
    if instant.tzinfo is None:
        raise ValueError('cutoff must include an explicit timezone')
    epoch = instant.timestamp()
    inputs, coverage = {}, {}
    for tf, minutes in TIMEFRAME_MINUTES.items():
        period = dataset['periods'].get(tf)
        if period is None:
            continue
        rows = (mt5_weekly_prefix(dataset, epoch, count, directory) if tf=='W1' and week_start=='sunday'
                else load_prefix(period, epoch, count, directory))
        inputs[tf] = [OHLCBar(datetime.fromtimestamp(row[0], timezone.utc),
            *map(float, row[1:5]), volume=None, provider='HistData', timeframe=tf)
            for row in rows]
        coverage[tf] = dict(bars=len(rows), archive_bars=period['rows'],
            archive_start_epoch=period['start'], archive_end_epoch=period['end'],
            latest_closed_end_epoch=float(rows[-1, 0] + minutes * 60) if len(rows) else None)
    snapshot = build_snapshot(inputs.get('M1', []), as_of_utc=cutoff,
        provider='HistData', selected_trading_timeframe=timeframe,
        native_analysis_period_bars=inputs, display_period_bars=inputs)
    snapshot['snapshot_id'] = 'HistData_archive_' + snapshot['snapshot_id']
    snapshot['archive_window_provenance'] = dict(provider='HistData',
        week_start=week_start,
        bar_time_basis='archive_export_UTC_aggregation_not_broker_native',
        cutoff_utc=cutoff, coverage=coverage, production_geometry_reused=False,
        windowed_analysis=True, automatic_trade_permission=False)
    snapshot['ict_archive_logic'] = calculate_ict_archive_logic(
        inputs.get(timeframe, []), timeframe, cutoff)
    # Main-chart measuring families (including complete enclosing waves) are
    # a separate engine branch. Omitting it silently leaves only legacy pairs.
    review = build_retracement_measurement_review(snapshot, timeframe,
        include_regime_research=True)
    return dict(snapshot=snapshot, reviews={timeframe: review},
        stage='source_bound_archive_window_not_yet_main_chart',
        automatic_trade_permission=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cutoff', required=True)
    parser.add_argument('--timeframe', default='M5', choices=sorted(TIMEFRAME_MINUTES))
    parser.add_argument('--count', type=int, default=1024)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = build_archive_window(args.cutoff, args.timeframe, args.count)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(args.output, 'wt', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, allow_nan=False)
    print(json.dumps(dict(output=str(args.output),
        snapshot_id=result['snapshot']['snapshot_id'],
        coverage=result['snapshot']['archive_window_provenance']['coverage'])))


if __name__ == '__main__':
    main()
