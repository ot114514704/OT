"""Native ruler inputs for R01; exact geometry does not decide author degree."""
from copy import deepcopy
from hashlib import sha256
import json
from math import isfinite,isclose
from datetime import timezone
from .book_first_response_leg import clock,close_time


def _digest(value):
    return sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()[:24]


def native_ruler_source_proof(bars,line,timeframe,cutoff):
    base=dict(schema='R01_native_ruler_source_proof_v1',qualified=False,
        timeframe=timeframe,as_of_utc=cutoff,author_degree_verified=False,
        entry_permission=False,automatic_trade_permission=False)
    def fail(reason):return dict(base,reason=reason)
    if bars is None:return fail('native_rows_not_supplied')
    try:
        cutoff_clock=clock(cutoff)
        rows=[]
        for row in bars:
            try:
                if clock(close_time(row,timeframe))<=cutoff_clock:
                    rows.append(row)
            except (KeyError,TypeError,ValueError,OverflowError):
                return fail('native_prefix_clock_invalid')
        if not line.get('qualified'):return fail('native_ruler_not_qualified')
        if line.get('timeframe',timeframe)!=timeframe:return fail('native_ruler_timeframe_mismatch')
        if any(r.get('timeframe',timeframe)!=timeframe for r in rows):return fail('native_row_timeframe_mismatch')
        if any(clock(rows[k]['timestamp_utc'])>=clock(rows[k+1]['timestamp_utc']) for k in range(len(rows)-1)):
            return fail('native_row_order_or_duplicate_time')
        market={}
        for field in ('provider','symbol'):
            values={r.get(field) for r in rows if r.get(field) is not None}
            if len(values)>1:return fail('native_row_'+field+'_conflict')
            market[field]=next(iter(values),None)
        i,j=line['start_index'],line['end_index'];dependency=line.get('first_observable_index',j)
        if any(type(k) is not int for k in (i,j,dependency)) or not 0<=i<j<=dependency<len(rows):
            return fail('native_ruler_indices_unbound')
        direction=line['direction']
        if direction not in ('up','down'):return fail('native_ruler_direction_unknown')
        field='low' if direction=='up' else 'high'
        a,b,slope=line['start_price'],line['end_price'],line['slope']
        if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not isfinite(v) for v in (a,b,slope)) or min(a,b)<=0:
            return fail('native_ruler_coefficients_invalid')
        if a!=rows[i][field] or b!=rows[j][field]:return fail('native_ruler_anchor_not_candle_extreme')
        if not isclose(slope,(b-a)/(j-i),rel_tol=1e-12,abs_tol=1e-10):return fail('native_ruler_slope_mismatch')
        known=line['known_at_utc']
        if not clock(close_time(rows[dependency],timeframe))<=clock(known)<=clock(cutoff):
            return fail('native_ruler_construction_clock_unbound')
        utc=lambda t:clock(t).astimezone(timezone.utc).isoformat().replace('+00:00','Z')
        facts=dict(start_utc=utc(rows[i]['timestamp_utc']),end_utc=utc(rows[j]['timestamp_utc']),
            start_price=float(a),end_price=float(b),direction=direction,timeframe=timeframe,
            exact_native_identity=True)
        identity=dict(market=market,timeframe=timeframe,direction=direction,
            anchors=[[facts['start_utc'],facts['start_price']],[facts['end_utc'],facts['end_price']]])
        native_id='R01_native_ruler:'+_digest(identity)
        return dict(base,qualified=True,reason=None,native_ruler_id=native_id,
            source_wave_id=line.get('wave_id'),native_ruler_facts=facts,native_identity=identity,
            known_at_utc=utc(known),dependency_index=dependency,
            dependency_closed_at_utc=close_time(rows[dependency],timeframe),
            evidence_id='R01_native_ruler_evidence:'+_digest([native_id,utc(known),dependency]),
            market_binding_state='native_labels_complete' if all(market.values()) and
                all(r.get('provider')==market['provider'] and r.get('symbol')==market['symbol'] for r in rows)
                else 'partial_or_missing_native_labels',
            proof_scope='native_anchor_extremes_coefficients_and_clock; not full author anchor selection')
    except (KeyError,TypeError,ValueError,IndexError,ArithmeticError):return fail('native_ruler_source_incomplete')


def native_ruler_review(bars,line,timeframe,cutoff):
    proof=native_ruler_source_proof(bars,line,timeframe,cutoff)
    ready=proof['qualified'] and bool(line.get('wave_id'))
    # PDF pp.27-28 lets the trader choose an operating period from trader
    # type/capital/instrument. Keep that engineering context separate from
    # author-selected wave degree and never use it as a score vote.
    try:
        from .trend_trade_method_full_pipeline import period_profile_contract
        period=period_profile_contract(timeframe)
        period['timeframe']=timeframe
        period_state='operating_period_profile_available'
    except (KeyError,TypeError,ValueError):
        period=dict(name='unknown',timeframe=timeframe,periods=[timeframe]*3,
                    roles=[dict(role=r,timeframe=timeframe) for r in ('long','medium','short')])
        period_state='operating_period_profile_unknown'
    operating=dict(schema='R01_operating_period_context_v1',state=period_state,
        source_pdf_pages=[27,28],timeframe=timeframe,profile=deepcopy(period),
        trader_type=None,capital_class=None,instrument=None,
        selected_by_author=False,author_wave_degree='unknown',
        engineering_context_only=True,entry_permission=False,
        automatic_trade_permission=False)
    return dict(schema='R01_selected_Book_native_review_v1',source_pdf_pages=[27,28,49],
        state='native_ruler_ready_for_author_review' if ready else 'native_ruler_unbound',
        native_wave_group_id=line.get('wave_id'),native_timeframe=timeframe,
        native_ruler_id=proof.get('native_ruler_id'),evidence_id=proof.get('evidence_id'),
        known_at_utc=proof.get('known_at_utc'),as_of_utc=cutoff,
        native_ruler_facts=deepcopy(proof.get('native_ruler_facts') or {}),native_source_proof=proof,
        operating_period_context=operating,
        required_author_inputs=['author_wave_degree_or_period_role',
            'same_author_wave_or_parent_child_relation','selected_author_parent_wave_id_when_applicable',
            'manual_page_and_rationale'],
        author_wave_degree='unknown',author_parent_wave_id=None,author_same_degree_adjudicated=False,
        engineering_lookback_is_not_author_degree=True,entry_permission=False,automatic_trade_permission=False)


def validate_attached_review(review,current,timeframe,cutoff):
    proof=current['native_source_proof']
    if not proof['qualified']:return False,proof['reason']
    if (not current.get('native_wave_group_id') or review.get('native_wave_group_id')!=current['native_wave_group_id']
            or review.get('native_timeframe')!=timeframe):return False,'review_wave_or_timeframe_mismatch'
    if review.get('native_ruler_id')!=current['native_ruler_id'] or review.get('evidence_id')!=current['evidence_id']:
        return False,'review_native_identity_or_construction_changed'
    if review.get('native_ruler_facts')!=current['native_ruler_facts']:return False,'review_native_anchors_changed'
    if review.get('operating_period_context')!=current.get('operating_period_context'):
        return False,'review_operating_period_context_changed'
    try:
        if clock(review['as_of_utc'])!=clock(cutoff):return False,'review_as_of_not_current'
        if not clock(current['known_at_utc'])<=clock(review['known_at_utc'])<=clock(cutoff):
            return False,'review_clock_unbound'
    except (KeyError,TypeError,ValueError):return False,'review_clock_unbound'
    pending={'native_ruler_ready_for_author_review','requires_author_same_degree_adjudication',
        'author_input_bound_pending_confirmation',
        'same_native_ruler_deduplicated_not_author_degree','no_geometric_same_period_relation_to_adjudicate'}
    if review.get('author_same_degree_adjudicated') is True or review.get('state') not in pending:
        return False,'unsupported_author_adjudication_claim'
    return True,None


def bind_author_review_input(current, author_input):
    """Bind human review fields to the exact ruler without granting permission."""
    required=('author_wave_degree_or_period_role',
        'same_author_wave_or_parent_child_relation',
        'selected_author_parent_wave_id_when_applicable',
        'manual_page_and_rationale')
    if not isinstance(author_input,dict):
        return dict(schema='R01_author_review_input_v1',state='invalid',
            reason='author_review_input_not_object',author_same_degree_adjudicated=False,
            entry_permission=False,automatic_trade_permission=False)
    missing=[k for k in required if not author_input.get(k)]
    if missing:
        return dict(schema='R01_author_review_input_v1',state='invalid',
            reason='author_review_input_missing_fields',missing=missing,
            author_same_degree_adjudicated=False,entry_permission=False,
            automatic_trade_permission=False)
    if not current.get('native_source_proof',{}).get('qualified'):
        return dict(schema='R01_author_review_input_v1',state='invalid',
            reason='native_ruler_source_not_qualified',author_same_degree_adjudicated=False,
            entry_permission=False,automatic_trade_permission=False)
    return dict(schema='R01_author_review_input_v1',state='author_input_bound_pending_confirmation',
        source_pdf_pages=[27,28,49],native_wave_group_id=current.get('native_wave_group_id'),
        native_timeframe=current.get('native_timeframe'),native_ruler_id=current.get('native_ruler_id'),
        evidence_id=current.get('evidence_id'),as_of_utc=current.get('as_of_utc'),
        native_ruler_facts=deepcopy(current.get('native_ruler_facts') or {}),
        operating_period_context=deepcopy(current.get('operating_period_context') or {}),
        author_wave_degree_or_period_role=author_input['author_wave_degree_or_period_role'],
        same_author_wave_or_parent_child_relation=author_input['same_author_wave_or_parent_child_relation'],
        selected_author_parent_wave_id_when_applicable=author_input['selected_author_parent_wave_id_when_applicable'],
        manual_page_and_rationale=author_input['manual_page_and_rationale'],
        author_wave_degree='unknown',author_same_degree_adjudicated=False,
        author_confirmation_state='not_confirmed_by_governed_author_review',
        entry_permission=False,automatic_trade_permission=False)
