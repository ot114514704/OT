"""Selected native-wave rulers; book geometry + explicit engineering selection.

PDF63-65 requires ownership/order, clearance, span and axis separately.
The monotonic confirmed-pivot run and midpoint proxy below are engineering
definitions, not a claim to recover all of the author's wave degrees.
Existing source/force objects are not removed, moved or re-owned.
"""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
from statistics import median
from .book_structural_anchors import integer_prices, confirmed_sequences, clear, lifecycle, _epoch
from .trend_trade_method_full_pipeline import _closed, _closed_at

RULE='book_owned_axis_v1'
SCALES=(2,6,18,54)
# A pair of immediately adjacent pivots is not a book-style ruler.  The
# minimum is deliberately independent of the wave span so a short local pair
# cannot win merely because the surrounding run is short.
MIN_ANCHOR_SPAN_BARS=9
# The second anchor belongs in the latter half of the wave but should leave
# visible breathing room before the wave's terminal extreme. This is a
# preference gate; if no candidate satisfies it, the broad legal candidate is
# retained and the unresolved condition is recorded.
MIN_SECOND_ANCHOR_END_MARGIN_BARS=2
# The PDF asks for a line parallel to the movement's centre axis, but gives
# screen-angle examples that are not portable between symbols/timeframes.
# This ratio is therefore only an audit classification, never a selection
# gate.  It is deliberately expressed against the native pivot slopes.
AXIS_PHASE_EARLY_MAX=Fraction(3,4)
AXIS_PHASE_LATE_MIN=Fraction(5,4)
# Two legal lines whose normalized axis errors are this close are an
# unresolved tie.  We retain the deterministic first line and expose the
# tie instead of silently pretending that the book selected one uniquely.
AXIS_AMBIGUITY_RATIO=Fraction(1,10)
# Once a pair is close enough to the current ZigZag-owned wave's centre axis,
# prefer the widest/outermost valid contacts. A tiny inner pair must not win
# merely because its two-point slope is a few decimals closer.
OUTERMOST_AXIS_TOLERANCE=Fraction(3,2)


def owned_runs(prices,radius):
    """Causal snapshots of adjacent, same-scale HH/HL or LL/LH chains.

    A changed intervening pivot starts a different run; no nearest-anchor
    substitution. Same-side extension of the latest extreme stays in-run.
    Invalid four-point steps reset that directional run, never erase history.
    """
    active={}
    for seq,known in confirmed_sequences(prices,radius):
        if len(seq)!=4:continue
        up=seq[0][1]=='low';sign=1 if up else -1
        valid=sign*(seq[2][2]-seq[0][2])>0 and sign*(seq[3][2]-seq[1][2])>0
        if not valid:
            if active.pop(up,None):yield (),known,up
            continue
        previous=active.get(up,())
        if previous and previous[-2:]==seq[:2]:chain=previous+seq[2:]
        elif previous and previous[-4:-1]==seq[:3] and sign*(seq[3][2]-previous[-1][2])>0:
            chain=previous[:-1]+seq[3:]
        else:chain=seq
        active[up]=chain
        yield chain,known,up


def axis_profile(chain):
    """Return the native centre-axis measurements for one owned run.

    The book's "parallel to the centre axis" rule is implemented from the
    alternating swing midpoints.  All values stay in integer quote units and
    native bars, so a screen resize or a different symbol price scale cannot
    change the chosen candidate.  ``phase`` is an engineering description of
    the run's relative speed; it is not claimed to be the author's wave degree.
    """
    centers=[(Fraction(a[0]+b[0],2),Fraction(a[2]+b[2],2)) for a,b in zip(chain,chain[1:])]
    slopes=[(b[1]-a[1])/(b[0]-a[0]) for i,a in enumerate(centers) for b in centers[i+1:] if b[0]>a[0]]
    axis=median(slopes) if slopes else Fraction(0)
    legs=[abs((b[2]-a[2])/(b[0]-a[0])) for a,b in zip(chain,chain[1:]) if b[0]>a[0]]
    median_leg=median(legs) if legs else Fraction(0)
    ratio=abs(axis)/median_leg if median_leg else Fraction(0)
    if ratio and ratio < AXIS_PHASE_EARLY_MAX: phase='EARLY_SLOW'
    elif ratio and ratio >= AXIS_PHASE_LATE_MIN: phase='LATE_FAST'
    elif ratio: phase='MID_CENTRE'
    else: phase='UNKNOWN'
    return dict(axis=axis,center_points=centers,pairwise_slopes=slopes,
                median_leg_slope=median_leg,axis_to_leg_ratio=ratio,phase=phase)


def axis_of(chain):
    return axis_profile(chain)['axis']


def _freeze_geometry(value):
    """Make JSON-like identity/point data comparable without rounding prices."""
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_geometry(v) for v in value)
    if isinstance(value, dict):
        return tuple(sorted((k, _freeze_geometry(v)) for k, v in value.items()))
    return value


def _merge_exact_new_geometry_duplicates(objects, counts):
    """Merge only newly generated, visually identical degree candidates.

    Several engineering radii can describe the same native ruler.  Rendering
    that exact ruler once keeps the chart legible while preserving the lower
    degree as auditable support.  This function sees only ``objects`` created
    by this engine; legacy scene objects are merged later by the delivery layer
    and are never removed here.
    """
    kept = {}
    duplicate_ids = []
    for oid, obj in objects.items():
        ev = obj.get('evidence', {})
        key = (ev.get('coefficient_family'),
               _freeze_geometry(ev.get('ruler_identity', [])),
               _freeze_geometry(obj.get('points', [])))
        prior = kept.get(key)
        if prior is None:
            kept[key] = oid
            ev.setdefault('supporting_engineering_scales',
                          [ev.get('engineering_scale_radius')])
            ev.setdefault('supporting_wave_ids', [obj.get('owner_id')])
            ev.setdefault('exact_geometry_equivalent_count', 1)
            continue
        representative = objects[prior]
        rep_ev = representative['evidence']
        scales = set(rep_ev.get('supporting_engineering_scales', []))
        scales.add(ev.get('engineering_scale_radius'))
        rep_ev['supporting_engineering_scales'] = sorted(scales)
        owners = list(rep_ev.get('supporting_wave_ids', [representative.get('owner_id')]))
        if obj.get('owner_id') not in owners:
            owners.append(obj.get('owner_id'))
        rep_ev['supporting_wave_ids'] = owners
        rep_ev['exact_geometry_equivalent_count'] = int(rep_ev.get('exact_geometry_equivalent_count', 1)) + 1
        duplicate_ids.append(oid)
    for oid in duplicate_ids:
        del objects[oid]
    if duplicate_ids:
        counts['EXACT_NEW_GEOMETRY_DUPLICATE_SUPPRESSED'] = counts.get(
            'EXACT_NEW_GEOMETRY_DUPLICATE_SUPPRESSED', 0) + len(duplicate_ids)
    return objects


def _same_wave_geometry_key(obj):
    """Identity for one native ruler inside one complete wave.

    The endpoint is intentionally excluded: endpoint is a lifecycle/display
    fact, while the book's line identity is the same native wave, side and
    two (or three for CE/D) source anchors.
    """
    ev = obj.get('evidence', {})
    return (ev.get('coefficient_family'),
            _freeze_geometry(ev.get('ruler_identity', [])),
            _freeze_geometry(ev.get('integer_line', [])),
            ev.get('direction'), ev.get('geometry_side'),
            ev.get('wave_start_utc'), ev.get('wave_extreme_utc'))


def _merge_same_wave_geometry_duplicates(objects, counts, prices=None,
                                         rows=None, unit=None):
    """Merge lifecycle variants only after an earliest-clock clearance proof.

    Adjacent engineering radii can confirm the same native wave at different
    clocks.  We may keep the longest visible endpoint only when the line is
    clear from the earliest construction clock through that endpoint.  This
    prevents a later-radius candidate from hiding an earlier wick contact.
    Legacy scene objects are never passed here.
    """
    groups = {}
    for oid, obj in objects.items():
        groups.setdefault(_same_wave_geometry_key(obj), []).append(oid)
    duplicate_ids = []
    for key, ids in groups.items():
        if len(ids) < 2:
            continue
        # Prefer the longest proven native segment; ties prefer the earliest
        # construction clock and then the richer wave membership evidence.
        ordered = sorted(ids, key=lambda oid: (
            -int(objects[oid].get('evidence', {}).get('end_index', -1)),
            objects[oid].get('evidence', {}).get('construction_known_at_utc', ''),
            -len(objects[oid].get('evidence', {}).get('wave_pivot_times', [])),
            oid))
        representative = objects[ordered[0]]
        rep_ev = representative['evidence']
        if prices is not None and rows is not None and unit:
            lower = rep_ev.get('geometry_side') == 'lower'
            line = tuple(rep_ev.get('integer_line', ()))
            if len(line) != 4:
                counts['SAME_WAVE_GEOMETRY_MERGE_REJECTED_IDENTITY'] = counts.get(
                    'SAME_WAVE_GEOMETRY_MERGE_REJECTED_IDENTITY', 0) + 1
                continue
            stamp_to_index = {r['timestamp_utc']: i for i, r in enumerate(rows)}
            # ruler_identity stores native epochs for MT5 transport, while
            # wave clocks store ISO UTC strings.  Keep both representations
            # in one lookup so CE/D and OUTER use the same causal proof.
            stamp_to_index.update({_epoch(r['timestamp_utc']): i
                                   for i, r in enumerate(rows)})
            try:
                start = stamp_to_index[rep_ev['wave_start_utc']]
                end = int(rep_ev['end_index'])
                construction_indices = []
                for oid in ids:
                    source = objects[oid]
                    # The three-clock evidence fields are finalized below
                    # this merge.  At this point object.known_at_utc is the
                    # immutable construction clock, so use it as the causal
                    # fallback rather than rejecting every same-wave group.
                    construction = source['evidence'].get(
                        'construction_known_at_utc', source.get('known_at_utc'))
                    construction_indices.append(stamp_to_index[construction])
                earliest = min(construction_indices)
                if rep_ev.get('coefficient_family') == 'OUTER':
                    allowed = (line[0], line[2])
                else:
                    ident = rep_ev.get('ruler_identity', [])
                    allowed = tuple(stamp_to_index[t] for t, _ in ident[2:])
                proof = clear(prices, line, start, end, lower, allowed)
            except (KeyError, TypeError, ValueError):
                proof = {'ok': False, 'reason': 'IDENTITY_CLOCK_UNRESOLVED'}
            if not proof.get('ok'):
                counts['SAME_WAVE_GEOMETRY_MERGE_REJECTED_CLEARANCE'] = counts.get(
                    'SAME_WAVE_GEOMETRY_MERGE_REJECTED_CLEARANCE', 0) + 1
                continue
        # Preserve every source lifecycle in evidence while exposing one line.
        memberships = []
        scales = set()
        owners = []
        earliest_construction = None
        for oid in ordered:
            obj = objects[oid]
            ev = obj['evidence']
            scales.add(ev.get('engineering_scale_radius'))
            if obj.get('owner_id') not in owners:
                owners.append(obj.get('owner_id'))
            construction = ev.get('construction_known_at_utc', obj.get('known_at_utc'))
            if construction and (earliest_construction is None or construction < earliest_construction):
                earliest_construction = construction
            memberships.append({
                'owner_id': obj.get('owner_id'),
                'engineering_scale_radius': ev.get('engineering_scale_radius'),
                'construction_known_at_utc': construction,
                'display_end_index': ev.get('end_index'),
                'known_at_utc': obj.get('known_at_utc'),
                'wave_pivot_times': list(ev.get('wave_pivot_times', [])),
            })
        rep_ev['supporting_engineering_scales'] = sorted(x for x in scales if x is not None)
        rep_ev['supporting_wave_ids'] = owners
        rep_ev['same_wave_geometry_equivalent_count'] = len(ordered)
        rep_ev['same_wave_geometry_merge'] = 'earliest_clock_clearance_verified'
        rep_ev['equivalent_wave_memberships'] = memberships
        if earliest_construction is not None:
            # Keep the earliest member clock for audit, but the visible
            # representative cannot claim construction before all of its own
            # named wave pivots were confirmed.  The two clocks are distinct:
            # membership evidence may begin earlier than the composite line's
            # complete construction clock.
            rep_ev['earliest_equivalent_construction_known_at_utc'] = earliest_construction
            confirmations = rep_ev.get('wave_pivot_confirmation_times', [])
            rep_ev['construction_known_at_utc'] = max(
                [earliest_construction, *confirmations])
        for oid in ordered[1:]:
            duplicate_ids.append(oid)
    for oid in duplicate_ids:
        del objects[oid]
    if duplicate_ids:
        counts['SAME_WAVE_GEOMETRY_DUPLICATE_SUPPRESSED'] = counts.get(
            'SAME_WAVE_GEOMETRY_DUPLICATE_SUPPRESSED', 0) + len(duplicate_ids)
    return objects


def select_pair(prices,chain,known,lower,axis,extension=False):
    """Compare only candidates of one run, one snapshot and one family.

    Explicit engineering coverage: cross the run's time midpoint, span at
    least one third of the run, and start in its first third. If unavailable,
    report no broad selection; do NOT fall back to a tiny end/start pair.
    """
    first,last=chain[0][0],chain[-1][0];span=last-first
    candidates=[];reasons=Counter()
    pivots=[p for p in chain if p[1]==('low' if lower else 'high')]
    first,last=chain[0][0],chain[-1][0];span=last-first
    movement=max((abs(p[2]-chain[0][2]) for p in chain),default=Fraction(1))
    movement=max(Fraction(1),movement)
    for a_pos,a in enumerate(pivots):
        for b in pivots[a_pos+1:]:
            i,pi,j,pj=a[0],a[2],b[0],b[2]
            if (pj-pi)*(1 if chain[0][1]=='low' else -1)<=0:continue
            if not extension and j>=last:continue
            balanced=not (3*(j-i)<span or 3*(i-first)>span or not 2*i<=first+last<=2*j)
            if not balanced:
                reasons['COVERAGE_NOT_BALANCED']+=1
            minimum_span=max(MIN_ANCHOR_SPAN_BARS,(span+2)//3)
            if j-i<minimum_span:
                reasons['ANCHOR_SPAN_TOO_SHORT']+=1;continue
            if not balanced:
                continue
            line=(i,pi,j,pj)
            # Check the complete owned formation range, including before I.
            proof=clear(prices,line,first,known,lower,(i,j))
            if not proof['ok']:
                reasons[proof['reason']]+=1;continue
            slope=Fraction(pj-pi,j-i)
            # The book's centre-axis choice is a geometric relation inside
            # the owned wave, so the error must be normalized by that wave's
            # movement/span before comparing candidates.  Raw quote error is
            # retained as a deterministic tie-breaker and for the audit.
            normalized_axis_distance=abs(slope-axis)*span/movement
            candidates.append(dict(line=line,a=a,b=b,axis_distance=abs(slope-axis),
                                   normalized_axis_distance=normalized_axis_distance,
                                   span=j-i,left_margin=i-first,right_margin=last-j,
                                   end_margin=last-j,
                                   # The PDF end-margin rule is for the
                                   # original OUTER ruler. CE/D is a shifted
                                   # return boundary and has its own C<D<E
                                   # ordering/adjustment-extreme gates.
                                   end_margin_ok=(extension or
                                                  (last-j)>=MIN_SECOND_ANCHOR_END_MARGIN_BARS)))
    if not candidates:return None,dict(reasons)
    # Geometry + coverage are gates; normalized centre-axis error selects
    # within this one owned wave.  This prevents a large-price or long-leg
    # candidate from winning solely because its raw quote error is smaller.
    margin_candidates=[c for c in candidates if c['end_margin_ok']]
    if margin_candidates:
        candidates=margin_candidates
    best_axis=min(c['normalized_axis_distance'] for c in candidates)
    axis_floor=Fraction(1,max(1,span))
    axis_limit=max(best_axis*OUTERMOST_AXIS_TOLERANCE,axis_floor*2)
    outer_candidates=[c for c in candidates if c['normalized_axis_distance']<=axis_limit]
    # Outermost/widest contact is primary inside the same-wave axis envelope;
    # slope alignment remains the deterministic tie-breaker.
    candidates=outer_candidates or candidates
    candidates.sort(key=lambda c:(-c['span'],c['normalized_axis_distance'],c['axis_distance'],
                                  max(c['left_margin'],c['right_margin']),c['line'][0]))
    best=candidates[0]
    if len(candidates)>1:
        second=candidates[1]
        # Relative tie, with a one-native-unit floor to avoid noise from
        # exact integer arithmetic.  Keep the best line but make ambiguity
        # visible to the audit and to the MT5 evidence payload.
        floor=Fraction(1, max(1, span))
        threshold=max(best['normalized_axis_distance']*AXIS_AMBIGUITY_RATIO, floor)
        best['axis_selection_ambiguous']=second['normalized_axis_distance']-best['normalized_axis_distance'] <= threshold
        best['axis_candidate_count']=len(candidates)
        best['second_normalized_axis_distance']=second['normalized_axis_distance']
        if best['axis_selection_ambiguous']:reasons['AXIS_AMBIGUOUS']+=1
    else:
        best['axis_selection_ambiguous']=False
        best['axis_candidate_count']=1
        best['second_normalized_axis_distance']=None
    best['end_margin_required_bars']=(0 if extension else MIN_SECOND_ANCHOR_END_MARGIN_BARS)
    best['end_margin_unresolved']=not best['end_margin_ok']
    if best['end_margin_unresolved']:
        reasons['END_MARGIN_UNRESOLVED']+=1
    return best,dict(reasons)


def owned_axis_objects(bars,timeframe,cutoff,scales=SCALES):
    rows=_closed(bars,timeframe,cutoff)
    if any(r.get('timeframe',timeframe)!=timeframe for r in rows):
        return [],dict(status='CROSS_TIMEFRAME',added=0)
    if not rows:return [],dict(status='DATA_PENDING',added=0)
    prices,unit=integer_prices(rows);objects={};versions={};counts=Counter();live_owner={}
    def stop_owner(owner,known):
        for family in ('OUTER','RETURN_CE_D'):
            oid=versions.get((owner,family))
            if not oid:continue
            obj=objects[oid];ev=obj['evidence']
            if ev['end_index']<=known:continue
            i,pi,j,pj=ev['integer_line']
            # Stop only on confirmed structural failure, never retrospectively
            # at an unconfirmed swing time.
            obj['points'][-1]=[_epoch(rows[known]['timestamp_utc']),float((Fraction(pi)+Fraction(pj-pi,j-i)*(known-i))/unit)]
            ev['end_index']=known;ev['membership_ended_known_at_utc']=_closed_at(rows[known],timeframe)
            obj['status']='owned_wave_membership_ended'
    def emit(chain,known,up,radius,owner,family,pair,line,identity,lower,axis,shift=None):
        key=f'{timeframe}|{owner}|{family}|{identity}'
        oid='b'+sha256(key.encode()).hexdigest()[:23]
        if oid in objects:
            if versions.get((owner,family))==oid:return
            oid='b'+sha256((key+'|reselected|'+rows[known]['timestamp_utc']).encode()).hexdigest()[:23]
        i,pi,j,pj=line;life=lifecycle(prices,line,known,lower);end=life['display_end_index']
        if end<=i:return
        stamps=[rows[p[0]]['timestamp_utc'] for p in chain]
        group=(owner,family);previous=versions.get(group)
        if previous:
            old=objects[previous];ev=old['evidence'];old_end=ev['end_index']
            if old_end>known:
                oi,opi,oj,opj=ev['integer_line'];endprice=Fraction(opi)+Fraction(opj-opi,oj-oi)*(known-oi)
                old['points'][-1]=[_epoch(rows[known]['timestamp_utc']),float(endprice/unit)]
                ev['end_index']=known;ev['superseded_by']=oid
                ev['superseded_known_at_utc']=_closed_at(rows[known],timeframe)
                old['status']='owned_wave_historical_revision'
        profile=axis_profile(chain)
        evidence=dict(display_role='owned_wave_primary' if family=='OUTER' else 'owned_wave_turning',
            direction='up' if up else 'down',geometry_side='lower' if lower else 'upper',
            native_timeframe=timeframe,engineering_scale_radius=radius,wave_id=owner,
            wave_membership_policy='adjacent_confirmed_monotonic_pivot_run',
            author_wave_degree='unknown',source_rule_pages=[63,64,65,81,83],
            wave_pivot_times=stamps,wave_pivot_roles=[p[1] for p in chain],
            wave_pivot_prices=[p[2]/unit for p in chain],
            wave_pivot_confirmation_times=[_closed_at(rows[p[3]],timeframe) for p in chain],
            wave_start_utc=stamps[0],wave_extreme_utc=stamps[-1],
            ruler_identity=identity,coefficient_family=family,
            geometry_checked_through_utc=_closed_at(rows[known],timeframe),
            axis_method='median_pairwise_slopes_of_alternating_swing_midpoints',
            axis_slope_per_native_bar=float(axis/unit),
            selected_axis_distance=float(pair['axis_distance']/unit),
            selected_normalized_axis_distance=float(pair['normalized_axis_distance']),
            axis_selection_ambiguous=bool(pair.get('axis_selection_ambiguous',False)),
            axis_candidate_count=pair.get('axis_candidate_count',1),
            second_normalized_axis_distance=(float(pair['second_normalized_axis_distance'])
                                             if pair.get('second_normalized_axis_distance') is not None else None),
            axis_median_leg_slope=float(profile['median_leg_slope']/unit),
            axis_to_leg_ratio=float(profile['axis_to_leg_ratio']) if profile['axis_to_leg_ratio'] else 0.0,
            axis_phase=profile['phase'],axis_phase_is_engineering=True,
            anchor_span_bars=pair['span'],wave_span_bars=chain[-1][0]-chain[0][0],
            outermost_contact_pair=True,
            outermost_contact_span_bars=pair['span'],
            outermost_contact_left_margin_bars=pair['left_margin'],
            outermost_contact_right_margin_bars=pair['right_margin'],
            axis_tolerance_multiplier=float(OUTERMOST_AXIS_TOLERANCE),
            selection_policy='zigzag_owned_wave_outermost_pair_within_axis_tolerance_native_axis',
            minimum_anchor_span_bars=MIN_ANCHOR_SPAN_BARS,
            second_anchor_end_margin_bars=pair.get('end_margin', 0),
            second_anchor_end_margin_required_bars=pair.get('end_margin_required_bars', MIN_SECOND_ANCHOR_END_MARGIN_BARS),
            second_anchor_end_margin_unresolved=bool(pair.get('end_margin_unresolved', False)),
            selection_numbers_are_engineering=True,
            integer_line=list(line),price_unit=unit,end_index=end,formation_index=known,
            first_contact_utc=rows[life['contact_index']]['timestamp_utc'] if life['contact_index'] is not None else None,
            first_close_break_utc=rows[life['close_break_index']]['timestamp_utc'] if life['close_break_index'] is not None else None,
            no_internal_candle_crossing=True,read_only=True,trade_permission=False)
        if shift is not None:evidence['shift_pivot_utc']=rows[shift[0]]['timestamp_utc']
        label=('同波段主趋势' if family=='OUTER' else '同波段主拐点')
        objects[oid]=dict(id=oid,layer='trend' if family=='OUTER' else 'turning_point',kind='line',
            timeframe=timeframe,points=[[_epoch(rows[i]['timestamp_utc']),pi/unit],
            [_epoch(rows[end]['timestamp_utc']),float((Fraction(pi)+Fraction(pj-pi,j-i)*(end-i))/unit)]],
            known_at_utc=_closed_at(rows[known],timeframe),status='owned_wave_selected',
            owner_id=owner,source_id=RULE,evidence_ids=[RULE],unknown=False,
            group='book_owned_axis',label=f'{label} | {timeframe} S{radius} | 跨度{pair["span"]}/{chain[-1][0]-chain[0][0]} | 中轴选点·工程确认',evidence=evidence)
        versions[group]=oid
    for radius in scales:
        for chain,known,up in owned_runs(prices,radius):
            previous_owner=live_owner.get((radius,up))
            if not chain:
                if previous_owner:stop_owner(previous_owner,known)
                live_owner.pop((radius,up),None)
                continue
            owner='ow'+sha256(f'{timeframe}|{radius}|{up}|{rows[chain[0][0]]["timestamp_utc"]}'.encode()).hexdigest()[:18]
            if previous_owner and previous_owner!=owner:stop_owner(previous_owner,known)
            live_owner[(radius,up)]=owner
            # A confirmed two-leg, four-pivot formation already supplies two
            # same-side outer anchors.  PDF63-65 requires sufficient span,
            # coverage and clearance; it does not require a third full swing
            # before a ruler may exist.  Requiring six pivots hid valid early
            # and historical waves.  The gates in select_pair still reject
            # short, end-biased or candle-crossing pairs.
            if len(chain)<4:continue
            counts['OWNED_RUN_SNAPSHOTS']+=1
            axis=axis_of(chain)
            if axis*(1 if up else -1)<=0:
                counts['AXIS_DIRECTION_DISAGREEMENT']+=1;continue
            point=lambda p:[_epoch(rows[p[0]]['timestamp_utc']),p[2]/unit]
            pair,rejected=select_pair(prices,chain,known,up,axis)
            counts.update(rejected)
            if pair:
                emit(chain,known,up,radius,owner,'OUTER',pair,pair['line'],[point(pair['a']),point(pair['b'])],up,axis)
            else:counts['NO_BROAD_TREND_PAIR']+=1
            pair,rejected=select_pair(prices,chain,known,not up,axis,extension=True)
            counts.update(rejected)
            if not pair:
                counts['NO_BROAD_EXTENSION_PAIR']+=1;continue
            a,b=pair['a'],pair['b']
            adjustments=[p for p in chain if a[0]<p[0]<b[0] and p[1]==('low' if up else 'high')]
            if not adjustments:continue
            d=(min if up else max)(adjustments,key=lambda p:p[2])
            actual=(min if up else max)(prices[k]['low' if up else 'high'] for k in range(a[0]+1,b[0]))
            if d[2]!=actual:
                counts['SHIFT_NOT_ACTUAL_ADJUSTMENT_EXTREME']+=1;continue
            shifted=(d[0],d[2],d[0]+b[0]-a[0],d[2]+b[2]-a[2])
            if not clear(prices,shifted,d[0],known,up,(d[0],))['ok']:
                counts['SHIFT_ALREADY_CONTACTED_AT_FORMATION']+=1;continue
            emit(chain,known,up,radius,owner,'RETURN_CE_D',pair,shifted,[point(a),point(b),point(d)],up,axis,d)
    # The same native ruler may be selected at adjacent engineering radii.
    # Collapse only exact new geometry; historical/legacy objects are outside
    # this map and are never removed.
    _merge_exact_new_geometry_duplicates(objects, counts)
    _merge_same_wave_geometry_duplicates(objects, counts, prices=prices,
                                         rows=rows, unit=unit)
    # Source birth and later display/event facts have separate clocks.
    for obj in objects.values():
        ev=obj['evidence']
        # A same-wave merge may have proved that an earlier engineering
        # radius established the identical ruler before the representative's
        # current lifecycle clock.  Preserve that earliest construction clock
        # instead of overwriting it with the representative endpoint clock.
        # Display/contact/break clocks are allowed to move later below.
        construction=ev.get('construction_known_at_utc') or obj['known_at_utc']
        confirmations=ev.get('wave_pivot_confirmation_times', [])
        if confirmations:
            construction=max([construction, *confirmations])
        ev['construction_known_at_utc']=construction
        clocks=[construction,_closed_at(rows[ev['end_index']],timeframe)]
        for field in ('first_contact_utc','first_close_break_utc'):
            if ev.get(field):
                at=next(k for k,r in enumerate(rows) if r['timestamp_utc']==ev[field])
                clocks.append(_closed_at(rows[at],timeframe))
        clocks.extend(ev[k] for k in ('superseded_known_at_utc','membership_ended_known_at_utc') if ev.get(k))
        ev['display_state_known_at_utc']=max(clocks);obj['known_at_utc']=max(clocks)
    # IDs/formation facts are frozen. Later revisions retain historical parts.
    return list(objects.values()),dict(status='EVALUATED',added=len(objects),counts=dict(counts),
        owners=len({o['owner_id'] for o in objects.values()}),
        old_objects_removed=0,force_modified=0,author_wave_degrees='unknown',
        selection_is_engineering_implementation_of_book_constraints=True)
