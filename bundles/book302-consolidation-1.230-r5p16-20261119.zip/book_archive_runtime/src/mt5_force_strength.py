"""Native MT5 labels and click-owned retracement geometry for force objects."""
from hashlib import sha256
from functools import lru_cache
from copy import deepcopy
from math import ceil
import json
from .force_strength_model import evaluate_strength, BANDS, epoch, iso,band_paths
from .mt5_structure_logic import closed_bars, force_retests
from .build_archive_window_snapshot import TIMEFRAME_MINUTES
from .book_force_calibration_contract import BOOK_DOMAIN,load_book_model
from .force_return_decision import return_decision
from .force_node_route import context_plan
from .force_entry_space import entry_space_plan
from .force_post_trigger import follow_plan,LABELS as FOLLOW_LABELS
from .force_path_decision import path_decision,LABELS as PATH_LABELS
from .force_parent_binding import bind_parent,legacy_background_market
from .force_case_components import lookup as case_lookup,projected_children
from .force_return_anchor import return_anchors,caption as return_anchor_caption
from .force_weekly_context import weekly_context,bind_force as bind_weekly,caption as weekly_caption

LABELS={'50_61.8':'50–61.8%','77_88':'77–88%','127.2':'127.2% 二次扫荡'}
STATES={'waiting':'观察','touched':'触及待收回','close_recovered':'已收回待触发',
        'invalidated':'普通回踩失效','separate_sweep_setup_required':'独立扫荡待确认',
        'path_trigger_observed':'历史同口径触发已出现·非下单',
        'response_target_reached':'触发后已到来源终点','response_failed':'触发后保护位失效',
        'response_ambiguous':'同根触及目标与保护·顺序未知','target_already_passed':'触发时目标已过'}


def _preserve_unified_label(obj,label):
    """Keep adapter and explicit unfitted-domain tokens across annotations."""
    old=str(obj.get('label') or '')
    marker=' | unified_projection_schema='
    if marker in old and marker not in str(label):
        label=str(label)+old[old.index(marker):]
    # Owned boundary response scores are a different, unfitted domain from
    # full-wave strength. scene_objects declares that domain structurally;
    # response-box annotation must not drop it from the final TSV label.
    # Do not inherit a free-text flag from an unrelated or legacy object.
    domain=obj.get('calibration_status')
    role=obj.get('display_role')
    if domain=='unfitted_boundary_two_candle_domain' and role=='owned_boundary_breakout_score' and 'unfitted_boundary_domain=true' not in str(label):
        label=str(label)+' | unfitted_boundary_domain=true'
    return label


def panel_response_state(retest,path,ordinary):
    """Use the SAME causal response label as calibration, without an order.

    Observation/acceptance and realized target response are separate axes.
    Do not claim that a statistical preference supplies a missing route trigger.
    """
    state=path['state']
    if ordinary and state=='source_crossed':return 'invalidated'
    if state in ('success','failed','ambiguous'):
        return {'success':'response_target_reached','failed':'response_failed','ambiguous':'response_ambiguous'}[state]
    if state=='target_already_passed':return state
    if path.get('signal_at_utc'):return 'path_trigger_observed'
    return retest['state']


@lru_cache(maxsize=256)
def archived_force_rows(tf, start, end, known):
    """Fetch this leg's original bars when a wide historical overlay outlives
    the current viewport context. No later candle is used to fill the source.
    """
    from .build_archive_window_snapshot import ARCHIVE,load_prefix
    dataset=next(d for d in json.loads((ARCHIVE/'catalog.json').read_text(encoding='utf-8'))['datasets'] if d['id']=='HistData')
    count=ceil((known-start)/(TIMEFRAME_MINUTES[tf]*60))+32
    return load_prefix(dataset['periods'][tf],known,count).tolist()


def is_force_leg(obj):
    if obj.get('layer')!='force' or obj.get('group')=='force_retracement':return False
    if obj.get('kind')!='line':return False
    e=obj.get('evidence',{})
    # A rectangle's high/low corners are NOT ordered directional endpoints.
    # Neither score nor retracement arithmetic may infer direction from them.
    if e.get('response_range') or (e.get('rule_id','').endswith(':force') and obj.get('kind')=='box'):
        return False
    if e.get('book_first_response'):
        return e.get('source_completion')=='confirmed'
    # Outer channel boundaries share the force display switch, but their
    # endpoints are a trendline ruler, not an impulse A/B.
    source=str(obj.get('source_id',''))
    return bool(e.get('force_leg_id') or ':geometric_leg:' in source or ':enclosing:' in source
                or e.get('rule_id','').endswith(':force')) and ':channel:' not in source


def merge_book_first_sources(objects):
    """One exact native source geometry may break several outer rulers.

    Keep the earliest known reading and every context, not several supposedly
    independent impulses/scores for the same candles. Different endpoints or
    periods remain competitors, never proximity-merged.
    """
    groups={};other=[]
    for o in objects:
        r=o.get('evidence',{}).get('book_first_response')
        if not r:other.append(o);continue
        key=(o.get('timeframe'),tuple(map(tuple,o['points'])),r['source_complete'])
        groups.setdefault(key,[]).append(o)
    for group in groups.values():
        group.sort(key=lambda o:(epoch(o['evidence']['book_first_response']['known_at_utc']),o['id']))
        representative=group[0]
        contexts=[]
        for o in group:
            r=o['evidence']['book_first_response']
            contexts.extend(o['evidence'].get('merged_response_contexts') or [dict(
                object_id=o['id'],source_id=o['source_id'],owner_id=o['owner_id'],
                source_confirmation_utc=r.get('source_confirmation_utc'),
                response_known_at_utc=r.get('state_known_at_utc') or r.get('known_at_utc'),
                break_known_at_utc=r.get('break_known_at_utc'),ruler_anchors=r.get('ruler_anchors'),
                prior_B_A_backtrack=deepcopy(r.get('prior_B_A_backtrack')),
                source_wave_id=r.get('source_wave_id'),
                wave_membership_state=r.get('wave_membership_state','unknown'),
                ruler_known_at_utc=r.get('ruler_known_at_utc'),
                book_direction_state=o['evidence'].get('book_direction_state','unknown'))])
        # Repeated independent review of the same packet stays idempotent.
        contexts=list({c['object_id']:c for c in contexts}.values())
        representative['evidence']['merged_response_contexts']=sorted(contexts,key=lambda c:c['object_id'])
        representative['evidence']['source_geometry_context_count']=len(contexts)
        # The score still uses the earliest source-confirmation clock. The
        # composite object also exposes later contexts, so its publication
        # knowledge cannot predate any of those contexts.
        clocks=[representative['known_at_utc']]
        for context in contexts:
            clocks.extend(context.get(k) for k in ('response_known_at_utc','ruler_known_at_utc') if context.get(k))
            binding=context.get('prior_B_A_backtrack') or {}
            if binding.get('known_at_utc'):clocks.append(binding['known_at_utc'])
        representative['known_at_utc']=max(clocks,key=epoch)
        other.append(representative)
    return other


def first_wave_binding_caption(obj):
    """Explain retained owner contexts without promoting their representative."""
    evidence=obj.get('evidence') or {}
    response=evidence.get('book_first_response') or {}
    if not response:return ''
    contexts=evidence.get('merged_response_contexts') or [dict(
        prior_B_A_backtrack=response.get('prior_B_A_backtrack'))]
    bindings=[c.get('prior_B_A_backtrack') or {} for c in contexts]
    candidates=[b for b in bindings if b.get('status')=='candidate_bound_to_prior_B_A']
    late=sum(b.get('ruler_timing')=='historical_reconstruction' for b in candidates)
    timing=f'·其中{late}来源为历史重建' if late else ''
    reviews=[b.get('author_backtrack_review') or {} for b in bindings]
    review_sources=sum(r.get('status','').startswith('review_required') for r in reviews)
    review_candidates=sum(r.get('candidate_count',0) for r in reviews)
    review=(f'·PDF201回溯待审{review_sources}源/{review_candidates}候选'
            if review_sources else '')
    return f'BA回溯候选{len(candidates)}/{len(contexts)}来源·作者浪级待核{timing}{review}'


def attach_mt5_force_strength(scene, native_bars):
    from .book_calculation_scope import independent_axis_enabled
    book_origin_check={'require_origin_envelope':True} if independent_axis_enabled() else {}
    tf=scene['timeframe'];seconds=TIMEFRAME_MINUTES[tf]*60;cutoff=epoch(scene['cutoff_utc'])
    bars=closed_bars(native_bars,tf,cutoff)
    rows=[[b['t'],b['open'],b['high'],b['low'],b['close']] for b in bars]
    # Idempotence matters when a frozen scene is independently recomputed.
    scene['objects']=merge_book_first_sources([o for o in scene['objects'] if o.get('group') not in ('force_retracement','case_child_three_push')])
    additions=[];child_additions=[];scored=unknown=0
    suppressed=set();scope_audit=[]
    background_market=legacy_background_market(scene)
    scene['force_background_market_provenance']=background_market
    weekly=weekly_context(scene)
    scene['force_weekly_context']=weekly
    for obj in scene['objects']:
        e=obj.get('evidence',{})
        response_box=obj.get('kind')=='box' and obj.get('layer')=='force'
        if response_box:
            # Also repair derived readings of pre-fix immutable packets:
            # stale profiles must not survive merely because scoring skips it.
            obj.pop('strength_profile',None);e.pop('strength_profile',None)
            obj['label']=_preserve_unified_label(obj,'突破响应范围·非完整力度段 | '+{'up':'向上突破','down':'向下突破'}.get(e.get('break_side'),'方向未绑定'))
            continue
        if obj.get('layer')=='force' and ':channel:' in str(obj.get('source_id','')):
            # Legacy structure packets can already contain an old force
            # profile. Skipping a fresh calculation does not remove it:
            # the panel would still choose that stale, non-impulse reading.
            had_profile=bool(obj.get('strength_profile') or e.get('strength_profile'))
            obj.pop('strength_profile',None);e.pop('strength_profile',None)
            obj.pop('wave_strength_profile',None);e.pop('wave_strength_profile',None)
            if had_profile:
                obj['label']=_preserve_unified_label(obj,'波段通道边界 · 几何参考，非完整力度段')
            continue
        if not is_force_leg(obj) or epoch(obj['known_at_utc'])>cutoff:continue
        scope=e.get('descriptive_wave_scope')
        if scope:
            q=evaluate_strength(rows,obj,tf,seconds,model={},provider=scene.get('provider',''),domain='native_completed_wave_description')
            obj.pop('strength_profile',None);e.pop('strength_profile',None)
            obj['wave_strength_profile']=q;e['wave_strength_profile']=q
            label='大波段' if scope=='coarse' else '小波段'
            if q['score'] is None:
                suppressed.add(obj['id']);scope_audit.append(dict(id=obj['id'],reason=q['features']['status']));continue
            obj['label']=_preserve_unified_label(obj,f"{label} · {q['label']}力度 {q['score']}/100 | 已观测K线的描述评分 · 非入场许可")
            if q['features'].get('gaps'):obj['label']+=' | 含行情时段缺口，非连续样本校准'
            scored+=1
            # A descriptive wave grade must not fabricate a first-break
            # admission, entry route, retracement preference or probability.
            continue
        is_full_book=bool(obj.get('evidence',{}).get('book_first_response'))
        is_book=is_full_book or bool(obj.get('evidence',{}).get('rule_id','').endswith(':force'))
        # Lifecycle failure may advance state_known_at, not source features.
        source_clock=obj.get('evidence',{}).get('book_first_response',{}).get('source_confirmation_utc')
        score_source=dict(obj,known_at_utc=source_clock) if source_clock else obj
        model_options=({'model':load_book_model(),'domain':BOOK_DOMAIN} if is_full_book else
                       {'model':{}} if is_book else {})
        q=evaluate_strength(rows,score_source,tf,seconds,provider=scene.get('provider',''),**model_options,**book_origin_check)
        if is_full_book and q['score'] is None and str(scene.get('provider','')).startswith('MT5:'):
            suppressed.add(obj['id']);scope_audit.append(dict(id=obj['id'],reason=q['features']['status'],source=obj))
            continue
        if q['score'] is None and scene.get('provider')=='HistData':
            exact=archived_force_rows(tf,obj['points'][0][0],obj['points'][1][0],epoch(score_source['known_at_utc']))
            q=evaluate_strength(exact,score_source,tf,seconds,provider='HistData',**model_options,**book_origin_check)
            q['source_window']='exact_archived_source_prefix'
        if is_full_book and q['score'] is not None:
            # Book B-C rulers previously bypassed the original whole-wave
            # delivery screen. A long overlapping drift then received a
            # force label and retracement bands just because it had endpoints.
            from .live_force_wave_review import _momentum_profile
            source_rows=exact if q.get('source_window')=='exact_archived_source_prefix' else rows
            a,b=score_source['points'];known=epoch(score_source['known_at_utc'])
            available=[r for r in source_rows if float(r[0])+seconds<=known]
            convert=lambda r:dict(open=float(r[1]),high=float(r[2]),low=float(r[3]),close=float(r[4]))
            path=dict(bars=[convert(r) for r in available if a[0]<=float(r[0])<=b[0]],
                      baseline_bars=[convert(r) for r in available if float(r[0])<a[0]][-20:])
            delivery=_momentum_profile(path,b[1]>a[1],abs(b[1]-a[1]))
            e['whole_wave_delivery_review']=delivery
            if not delivery['qualified']:
                e['unqualified_descriptive_strength_profile']=q
                obj.pop('strength_profile',None);e.pop('strength_profile',None)
                obj['label']=_preserve_unified_label(obj,'推进资格未通过 · 整理/漂移待分段 | '+delivery['reason']+' | 不生成力度回调档')
                unknown+=1
                if str(scene.get('provider','')).startswith('MT5:'):
                    suppressed.add(obj['id']);scope_audit.append(dict(id=obj['id'],reason=delivery['reason'],source=obj))
                continue
        fitted=model_options.get('model',{})
        fitted_version=next((v for v in fitted.get('periods',{}).get(tf,[]) if v['model_id']==q['model_id']),{})
        q['calibration_revision']=fitted.get('calibration_revision') if fitted_version else None
        q['training_month_n']=fitted_version.get('training_month_n')
        q['calibration_domain']=(BOOK_DOMAIN if is_full_book else
                                 'book_response_range_initial_only' if is_book else 'native_first_response_candidate')
        obj['strength_profile']=q
        value=q['score'];s=q['band_selection'];f=q['features']
        prefix=f"{q['label']}力度 {value if value is not None else '?'} /100"
        if is_full_book and obj['status']=='source_invalidated':prefix='来源已失效·'+prefix
        if value is None:
            label=prefix+' | '+f.get('status','分项不足')
            unknown+=1
        else:
            stats=s.get('statistics',{})
            counts=' '.join(f"{name}{stats[key]['success_n']}/{stats[key]['n']}" for key,name in
                             [('50_61.8','浅'),('77_88','深'),('127.2','再扫')] if key in stats)
            names={'50_61.8':'50–61.8','77_88':'77–88','127.2':'127.2'}
            order='>'.join(names[k] for k in s.get('ranked_bands',[]) if k in names)
            choice=(f"历史优先观察 {LABELS[s['preferred_band']]}" if s['preferred_band'] else
                    f'响应排序 {order}·未分出唯一档' if s['status']=='competing_bands' else
                    '浅回/深回/再扫竞争·样本不足')
            months=f"/{q['training_month_n']}月" if q['training_month_n'] is not None else ''
            label=(prefix+f" | 幅{f['height_atr']:.2f}ATR 速{f['speed_atr']:.2f}ATR/根"
                   +f" | 效{f['efficiency']:.0%} 实{f['body']:.0%} 同向收{f['directional_close']:.0%} 收位{f['close_location']:.0%} 重叠{f['overlap']:.0%}"
                   +f" | {choice}"
                   +f" | 历史响应 {counts or '暂无同域样本'}·非胜率"
                   +f" | 训练{q['training_n']}条{months} 分界{q['thresholds']['low']:.1f}/{q['thresholds']['high']:.1f} 截止{(q['trained_through_utc'] or '初始工程评分')[:10]}")
            scored+=1
        domain_label=(('B→C工程候选·历史分位校准·作者第一浪待核' if q['model_id'] else 'B→C工程候选·初始评分·作者第一浪待核') if is_full_book else
                      '书本响应范围·初始工程评分' if is_book else '完整首段力度·前缀校准')
        obj['label']=_preserve_unified_label(obj,label+f" | 源确认 {q['known_at_utc']}·{domain_label}")
        binding_caption=first_wave_binding_caption(obj)
        if binding_caption:obj['label']+='·'+binding_caption
        obj.setdefault('evidence',{})['strength_profile']=q
        a,b=obj['points'];height=abs(b[1]-a[1])
        if value is None or not height:continue
        sign=1 if b[1]>a[1] else -1
        path_end=min(cutoff,epoch(score_source['known_at_utc'])+86400)
        # Historical objects may originate long before the visible window.
        # Evaluate their response in the original 24h path, not in whichever
        # much later candles happen to be on screen now.
        path_bars=bars
        if scene.get('provider')=='HistData':
            path_rows=archived_force_rows(tf,a[0],b[0],path_end)
            path_bars=[dict(t=r[0],closed=r[0]+seconds,open=r[1],high=r[2],low=r[3],close=r[4])
                       for r in path_rows]
        path_bars=[r for r in path_bars if r['closed']<=path_end]
        retests=force_retests(path_bars,score_source,sign)
        future=[[r['t'],r['open'],r['high'],r['low'],r['close']] for r in path_bars
                if r['t']>=epoch(score_source['known_at_utc'])]
        responses=band_paths(future,score_source,seconds,path_end)
        early_failure=obj.get('evidence',{}).get('book_first_response',{}).get('invalidated_at_utc')
        if early_failure and epoch(early_failure)<=epoch(score_source['known_at_utc']):
            for retest in retests:
                if retest['route_family']=='ordinary_retest':
                    retest.update(state='invalidated',accepted_close_utc=None,invalidated_at_utc=early_failure)
        decision=return_decision(score_source,retests,responses,as_of_utc=scene['cutoff_utc'],
                                 review_end_utc=iso(path_end),selection=s,bars=path_bars)
        obj['force_return_decision']=decision
        obj['evidence']['force_return_decision']=decision
        # Reconstruct the SOURCE'S own past context, not today's latest pivots.
        # This is a separate qualitative route, never a secretly refitted score.
        context_bars=bars
        if scene.get('provider')=='HistData':
            context_rows=archived_force_rows(tf,a[0]-128*seconds*3,b[0],path_end)
            context_bars=[dict(t=r[0],closed=r[0]+seconds,open=r[1],high=r[2],low=r[3],close=r[4])
                          for r in context_rows if r[0]+seconds<=path_end]
        plan=context_plan(score_source,context_bars,q['quality'],decision)
        obj['force_context_plan']=plan
        obj['evidence']['force_context_plan']=plan
        policies=scene.get('force_execution_policies') or {}
        if not isinstance(policies,dict):policies={}
        space=entry_space_plan(score_source,decision,plan,path_bars,policy=policies.get(obj['id']))
        obj['force_entry_space_plan']=space
        obj['evidence']['force_entry_space_plan']=space
        following=follow_plan(score_source,space,path_bars)
        obj['force_post_trigger_plan']=following
        obj['evidence']['force_post_trigger_plan']=following
        paths=path_decision(score_source,q,decision,plan,space,following)
        obj['force_path_decision']=paths
        obj['evidence']['force_path_decision']=paths
        formations=scene.get('force_formation_parent_contexts') or {}
        formation=formations.get(obj['id']) if isinstance(formations,dict) else None
        parent_binding=bind_parent(score_source,scene,formation,background_market)
        obj['force_parent_binding']=parent_binding
        obj['evidence']['force_parent_binding']=parent_binding
        weekly_binding=bind_weekly(score_source,scene,weekly,parent_binding)
        obj['force_weekly_binding']=weekly_binding
        obj['evidence']['force_weekly_binding']=weekly_binding
        own_return=return_anchors(score_source,path_bars,scene['cutoff_utc'],iso(path_end),parent_binding['review_parent'],
                                 market=dict(provider=scene.get('provider'),instrument=scene.get('instrument')))
        obj['force_own_return_anchor']=own_return
        obj['evidence']['force_own_return_anchor']=own_return
        case=case_lookup(score_source,scene)
        obj['force_case_components']=case
        obj['evidence']['force_case_components']=case
        if case['status']=='matched':child_additions.extend(projected_children(score_source,scene,case['context']))
        # Preserve the fitted statistics, but don't present an invalid/archived
        # band as a live preferred entry. Seven native detail rows stay stable.
        parts=obj['label'].split('|')
        historical_pref=LABELS.get(s.get('preferred_band'),'未分出')
        ranking='>'.join(LABELS[k].replace('% 二次扫荡','').replace('%','') for k in s.get('ranked_bands',[]) if k in LABELS)
        comparison=('统计偏好'+historical_pref if s.get('preferred_band') else
                    '统计排序'+ranking+'·未唯一' if ranking else '统计不足·三档竞争')
        # "比例" is the calibrated whole-band route; a node inside that band
        # has its own earlier/later trigger. Don't merge their confirmations.
        parts[3]=paths['caption']+' · '+plan['caption']+' · '+comparison
        if plan['statistics_context_relation']=='conflict_requires_context_resolution':parts[3]+='·局部条件冲突'
        parts[6]+='·'+parent_binding['caption']
        if weekly_caption(weekly_binding):parts[6]+='·'+weekly_caption(weekly_binding)
        if background_market['status']=='different_market_not_borrowed':parts[6]+='·背景跨源不借'
        if case['status']=='matched':
            c=case['context'];n=len(c['child_patterns'])
            failed=sum(p['post_third_response']['state']=='reclaim_failed' for p in c['child_patterns'])
            parts[5]+=f"·子{c['child_timeframe']}三推{n}组/收回失守{failed}·既有尺同源匹配{len(c['exact_force_source_ruler_candidates'])}"
        parts[5]+='·'+return_anchor_caption(own_return)
        shown_space_key=None
        current_refs=[(key,b['trigger_geometry']) for key,b in decision['bands'].items() if b['current_conditional_reference']]
        if current_refs:
            selected=next((v for v in current_refs if v[0]==s.get('preferred_band')),None)
            if selected is None and len(current_refs)==1:selected=current_refs[0]
            if selected:
                key,g=selected
                shown_space_key='ratio:'+key
                parts[4]=(f"{LABELS[key]} 比例收回 收盘参考{g['trigger_close_reference']:.2f} 保护{g['protection_price']:.2f}"
                          +f" 回补{g['response_target_price']:.2f} RR{g['reward_risk']:.2f}·非成交")
                node=plan['node_routes'][key]
                if node['current_reference']:
                    parts[4]+=f"·节点回接#{node['current_attempt']['ordinal']}"
                elif node['price_pattern_confirmed'] and node['pattern_state']=='confirmed':
                    parts[4]+='·节点回接中断'
            else:parts[4]='多个价格触发并存，未替用户选择入口；统计不等于执行'
        else:
            node_refs=[(key,v) for key,v in plan['node_routes'].items() if v['current_reference']]
            if len(node_refs)==1:
                key,v=node_refs[0]
                attempt=v['current_attempt']
                shown_space_key='node:'+key
                parts[4]=(f"{LABELS[key]} 节点第{attempt['ordinal']}次收回{attempt['closed_reference']:.2f} 保护{v['protection_price']:.2f}"
                          +f" 回补{v['response_target_price']:.2f} RR{attempt['reward_risk']:.2f}·非成交")
            elif any(v['node_acceptance_state'] in ('not_held_on_close','retest_wait_directional_close')
                     and v['price_pattern_confirmed'] and v['pattern_state']=='confirmed'
                     and not v['historical_only']
                     for v in plan['node_routes'].values()):
                parts[4]='节点旧回接已中断；等待新的触及收回，不沿用旧收盘价'
        if shown_space_key:
            assessment=space['routes'][shown_space_key]
            current_rr=assessment['current_closed_geometry'].get('reward_risk')
            if current_rr is not None:
                signal_rr=assessment['signal_geometry'].get('reward_risk')
                if signal_rr is not None:
                    parts[4]=parts[4].replace(f" RR{signal_rr:.2f}",f" R{signal_rr:.2f}→末收{current_rr:.2f}")
                if assessment['current_closed_geometry']['space_relation']=='reward_less_than_risk':parts[4]+='·酬<险'
            if assessment['current_scenario']['status'].startswith('below_minimum'):parts[4]+='·未达配置门槛'
            progress=following['routes'][shown_space_key]
            parts[4]+='·'+FOLLOW_LABELS[progress['state']]
        obj['label']=_preserve_unified_label(obj,'|'.join(parts))
        for (key,(r1,r2)),retest in zip(BANDS.items(),retests):
            low,high=sorted(b[1]-sign*height*r for r in (r1,r2))
            identifier=sha256(f"{obj['id']}|force_band|{key}".encode()).hexdigest()[:24]
            start=epoch(score_source['known_at_utc']);end=min(cutoff,start+86400)
            response=responses[key]
            state=panel_response_state(retest,response,r1<1)
            if early_failure and epoch(early_failure)<=epoch(score_source['known_at_utc']) and r1<1:
                state='invalidated'
            band_decision=decision['bands'][key]
            priority=band_decision['current_observation_priority']
            stat=s.get('statistics',{}).get(key)
            history=''
            if stat:
                ci=stat['interval95']
                unit='月份' if stat.get('cluster_unit')=='source_confirmation_calendar_month' else '窗口'
                history=f" · 响应{stat['success_n']}/{stat['n']} 95%[{ci[0]:.0%},{ci[1]:.0%}] {unit}{stat.get('independent_window_n','?')}"
            g=band_decision['trigger_geometry'];reference=''
            if g.get('status')=='observed':
                reference=(f" | {'当前条件' if band_decision['current_conditional_reference'] else '历史'}收盘参考{g['trigger_close_reference']:.2f}"
                           +f" 保护{g['protection_price']:.2f} 回补{g['response_target_price']:.2f}·非成交")
            node_route=plan['node_routes'][key]
            path=paths['paths'][key]
            ratio_follow=following['routes']['ratio:'+key]
            node_follow=following['routes']['node:'+key]
            node_detail=''
            if node_route.get('node_price') is not None:
                node_state={'observation':'观察','candidate':'触及候选','confirmed':'价格触发确认',
                            'completed':'已结束','invalidated':'失效','ambiguous':'顺序未知',
                            'not_applicable':'不适用'}[node_route['pattern_state']]
                node_detail=f" | 节点回接{node_route['node_price']:.2f}·{node_state}"
                if node_route['trigger_at_utc']:
                    node_detail+=f" 首次收盘{node_route['closed_reference']:.2f}·非成交"
                    acceptance={'not_held_on_close':'旧回接中断','retest_wait_directional_close':'再触及待收回',
                                'reclaimed_close':'收回保持','source_task_terminal':'来源任务结束'}
                    node_detail+='·'+acceptance.get(node_route['node_acceptance_state'],node_route['node_acceptance_state'])
                    if node_route.get('current_attempt'):
                        attempt=node_route['current_attempt']
                        node_detail+=f" 第{attempt['ordinal']}次参考{attempt['closed_reference']:.2f}"
            follow_detail=''
            path_detail=' | 路径'+PATH_LABELS[path['stage']]
            if path['source_prior_supported']:path_detail+='·原力度/节点条件支持'
            if path['competing_watch_reopened']:path_detail+='·浅回吐后竞争观察，未确认'
            for name,progress in (('比例',ratio_follow),('节点',node_follow)):
                if progress['current_observation']:
                    follow_detail+=f" | {name}后续{FOLLOW_LABELS[progress['state']]}"
                    if progress['net_close_progress_in_original_R'] is not None:
                        follow_detail+=f" 净收盘{progress['net_close_progress_in_original_R']:+.2f}R"
            additions.append(dict(id=identifier,layer='force',kind='line' if r1==r2 else 'box',
                points=[[start,low],[end,high]],status=state,owner_id=obj['id'],
                source_id=f"{obj.get('source_id',obj['id'])}:retest:{key}",timeframe=tf,
                known_at_utc=scene['cutoff_utc'],group='force_retracement',
                label=f"{LABELS[key]} {low:.2f}—{high:.2f} | {STATES[state]} | {priority}{history}{reference}{node_detail}{follow_detail}{path_detail} | 源确认{q['known_at_utc']} · 响应窗≤24h",
                evidence=dict(force_object_id=obj['id'],force_source_id=q['source_id'],
                    force_owner_id=q['owner_id'],ratio=[r1,r2],first_touch_utc=retest['first_touch_utc'],
                    accepted_close_utc=retest['accepted_close_utc'],invalidated_at_utc=retest['invalidated_at_utc'],
                    original_known_at_utc=q['known_at_utc'],state_known_at_utc=scene['cutoff_utc'],
                    response_review_through_utc=iso(path_end),
                    observation_state=retest['state'],response_state=response['state'],
                    response_signal_at_utc=response['signal_at_utc'],
                    response_semantics='same_as_calibration_not_route_or_order_permission',
                    return_decision=band_decision,
                    node_retest_route=node_route,
                    entry_space={name:space['routes'][name+':'+key] for name in ('ratio','node')},
                    post_trigger={name:following['routes'][name+':'+key] for name in ('ratio','node')},
                    path_decision=path,
                    band_selection=s,as_of_utc=scene['cutoff_utc'],automatic_trade_permission=False)))
    scene['objects']=[o for o in scene['objects'] if o['id'] not in suppressed]
    if 'active_object_ids' in scene:scene['active_object_ids']=[i for i in scene['active_object_ids'] if i not in suppressed]
    scene['force_scope_display_audit']=dict(suppressed=scope_audit,reason='invalid_or_unqualified_response_is_not_a_complete_force_wave',research_sources_preserved=True)
    scene['objects'].extend(additions)
    scene['objects'].extend(child_additions)
    scene['force_strength_delivery']=dict(version='mt5_force_strength_v1',timeframe=tf,
        as_of_utc=scene['cutoff_utc'],scored=scored,unknown=unknown,retest_objects=len(additions),
        interaction='click_force_to_reveal_its_three_bands',automatic_trade_permission=False)
    return scene
