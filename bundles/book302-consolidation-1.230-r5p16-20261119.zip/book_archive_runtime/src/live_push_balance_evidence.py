"""Compare three connected same-direction pushes, not three adjacent swings.

User's amplitude preference is an observation only, not Alexander's classifier.
The caller supplies OHLC-validated native legs. Same native timeframe does not
prove equal structural degree, a wedge, a range, or completion of a pullback.
"""
from .live_nested_stage_review import _time
from .three_push_wave_hypothesis import quantify_three_pushes


def _hypothesis(ratios):
    """Continuous facts, without inventing an approximately-equal tolerance."""
    _, middle, last = ratios
    return dict(equal_unit_absolute_deviations=[abs(v-1) for v in ratios],
        middle_minus_user_lower=middle-1.618, middle_minus_user_upper=middle-2.618,
        middle_in_user_research_band=1.618 <= middle <= 2.618,
        last_minus_first_unit=last-1,
        last_minus_book_conditional_point618=last-.618,
        classification='unadjudicated', tolerance_selected=False)


def amplitude_profile(pushes, returns, direction, known):
    """Three observed pushes, normalized to the FIRST, without wave labels.

    PDF207/223 describe wave1/3/5 hypotheses, not a universal classifier of
    every five-leg native chain. Relative amplitude, elapsed speed and regime
    must remain separate. Ratios are observations; no fitted tolerance or
    probability is introduced here.
    """
    lengths=[p['length'] for p in pushes];unit=lengths[0]
    ratios=[v/unit for v in lengths]
    seconds=[(_time(p['terminal']['pivot_timestamp_utc'])-
              _time(p['origin']['pivot_timestamp_utc'])).total_seconds() for p in pushes]
    sign=1 if direction=='up' else -1
    anchor=returns[-1]['terminal']
    return_depths=[r['length']/p['length'] for p,r in zip(pushes[:2],returns)]
    deepest_index=max(range(len(returns)),key=lambda i:returns[i]['length']) if returns else None
    return dict(schema='three_push_first_unit_profile_v3',known_at_utc=known,
        first_push_unit=unit,ratios_to_first=ratios,
        equal_length_deviation_to_first=[abs(v-1) for v in ratios],
        middle_extension_ratio=ratios[1],last_to_first_ratio=ratios[2],
        inter_push_return_lengths=[r['length'] for r in returns],
        inter_push_return_ratios_to_prior_push=return_depths,
        deepest_inter_push_return=dict(
            index=deepest_index,
            length=returns[deepest_index]['length'] if deepest_index is not None else None,
            ratio_to_prior_push=return_depths[deepest_index] if deepest_index is not None else None,
            terminal=dict(returns[deepest_index]['terminal']) if deepest_index is not None else None),
        push_elapsed_seconds=seconds,
        push_price_per_elapsed_second=[length/elapsed for length,elapsed in zip(lengths,seconds)],
        third_push_one_unit_projection=dict(anchor=dict(anchor),
            anchor_role='observed_second_return_terminal_not_author_correction_end',
            target=anchor['price']+sign*unit,measurement_unit_source_leg_id=pushes[0]['source_leg_id'],
            retroactive_observation_only=True,prospective_anchor_freeze_verified=False),
        reference_hypotheses=dict(
            equal_pushes=dict(ratios=[1,1,1],basis='user_research_hypothesis'),
            middle_extended=dict(middle_reference_multipliers=[1,1.618],
                last_reference_multipliers_if_middle_extended=[.618,1],
                basis='PDF207_and_223_conditional_author_wave1_3_5_not_native_degree_assignment'),
            user_extended_band=dict(lower=1.618,upper=2.618,
                basis='user_requested_research_band_not_book_frequency_claim')),
        hypothesis_comparison=_hypothesis(ratios),
        wave_ratio_observation=quantify_three_pushes(
            lengths, [r['length'] for r in returns], seconds, return_depths),
        hypothesis_basis='amplitude_only; callback_depth_and_speed_are_separate_observations',
        pattern_classification='unadjudicated',market_regime='unbound',
        equal_length_implies_slow=False,equal_length_implies_range=False,
        author_wave_degree_adjudicated=False,used_as_admission_gate=False,
        automatic_trade_permission=False)


def key(point):
    return tuple(point[k] for k in ('kind','pivot_timestamp_utc','price','confirmed_at_utc'))


class PushBalanceIndex:
    def __init__(self, legs, timeframe):
        self.timeframe=timeframe
        self.by_terminal={}
        for leg in legs:
            if leg.get('timeframe')==timeframe:
                self.by_terminal.setdefault(key(leg['terminal']),[]).append(leg)

    def at(self, terminal, known):
        cutoff=_time(known)
        result=dict(status='insufficient_connected_pushes',native_timeframe=self.timeframe,
            known_at_utc=known,pushes=[],returns=[],push_lengths=[],
            longest_to_shortest_ratio=None,within_user_two_to_one_preference=None,
            structural_degree_adjudicated=False,pattern_confirmed=False,
            used_as_admission_gate=False,trade_permission=False,
            interpretation='Three native-ledger pushes; equal structural degree and trend/range remain unresolved.')
        tail=terminal;chain=[]
        for _ in range(5):
            choices=[leg for leg in self.by_terminal.get(key(tail),[]) if
                all(_time(p['confirmed_at_utc'])<=cutoff for p in (leg['origin'],leg['terminal']))]
            if len(choices)!=1:
                return {**result,'status':'ambiguous_connected_path' if choices else 'insufficient_connected_pushes'}
            leg=choices[0];a,b=leg['origin'],leg['terminal']
            delta=b['price']-a['price']
            if (leg.get('temporal_order')!='sequential_confirmed_extrema' or
                    _time(a['pivot_timestamp_utc'])>=_time(b['pivot_timestamp_utc']) or not delta or
                    a['kind']==b['kind'] or
                    leg.get('direction_observation')!=('up' if delta>0 else 'down')):
                return {**result,'status':'invalid_or_unordered_path'}
            chain.append(leg);tail=a
        chain.reverse()
        directions=[leg['direction_observation'] for leg in chain]
        if any(a==b for a,b in zip(directions,directions[1:])):
            return {**result,'status':'nonalternating_path'}
        def witness(leg):
            return dict(source_leg_id=leg['leg_id'],origin=dict(leg['origin']),
                terminal=dict(leg['terminal']),length=abs(leg['terminal']['price']-leg['origin']['price']))
        pushes=[witness(leg) for leg in chain[::2]]
        lengths=[p['length'] for p in pushes]
        returns=[witness(leg) for leg in chain[1::2]]
        return {**result,'status':'three_connected_same_direction_pushes_observed',
            'direction':directions[0],'pushes':pushes,'returns':returns,
            'push_lengths':lengths,'longest_to_shortest_ratio':max(lengths)/min(lengths),
            'first_unit_amplitude_profile':amplitude_profile(pushes,returns,directions[0],known),
            'within_user_two_to_one_preference':max(lengths)<=2*min(lengths)}
