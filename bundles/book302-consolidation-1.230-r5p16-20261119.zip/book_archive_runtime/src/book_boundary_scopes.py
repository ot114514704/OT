"""Validate Book's native ZigZag intervals independently of force admission.

An ordered pair of native endpoint candles and a full OHLC envelope can own
geometry even when intrabar order within its interior remains unknown. This
adapter never changes Book decisions, original force scopes or their scores.
"""
from datetime import datetime
from hashlib import sha256
from math import isfinite
import json

SCHEMA='book_native_boundary_scope_history_v1'


def epoch(value):return datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()


def boundary_scopes(scene,bars,seconds):
    tf=scene['timeframe'];cutoff=scene['cutoff_utc'];end=epoch(cutoff)
    history=scene.get('execution_context',{}).get('force_scope_paths',{}).get('boundary_history') or {}
    market=(scene['provider'],scene['instrument'])
    if (history.get('schema')!=SCHEMA or history.get('timeframe')!=tf
            or (history.get('provider'),history.get('instrument'))!=market
            or history.get('as_of_utc')!=cutoff):
        return [],dict(reason='native_boundary_history_identity_or_clock_unavailable',accepted=0)
    positions={epoch(r['timestamp_utc']):i for i,r in enumerate(bars)}
    scopes=[];rejected=[];seen=set()
    for leg in history.get('legs',[]):
        try:
            if (leg.get('timeframe')!=tf or leg.get('geometry_unresolved')
                    or leg.get('native_bar_envelope_status')!='verified'):
                raise ValueError('native_interval_unverified')
            a,b=leg['origin'],leg['terminal'];known=leg['known_at_utc'];k=epoch(known)
            points=[[epoch(p['timestamp_utc']),p['price']] for p in (a,b)]
            if any(isinstance(p[1],bool) or not isinstance(p[1],(float,int)) or not isfinite(p[1]) for p in points):
                raise ValueError('native_interval_nonfinite_or_boolean_price')
            if not points[0][0]<points[1][0] or points[1][0]+seconds>k or k>end:
                raise ValueError('native_interval_endpoint_or_knowledge_clock')
            i,z=(positions[p[0]] for p in points);up=points[1][1]>points[0][1]
            if i>=z or leg.get('direction')!=('up' if up else 'down'):
                raise ValueError('native_interval_direction_or_order')
            if (bars[i]['low' if up else 'high']!=points[0][1]
                    or bars[z]['high' if up else 'low']!=points[1][1]):
                raise ValueError('native_interval_endpoint_not_native_extreme')
            low,high=sorted(p[1] for p in points)
            section=bars[i:z+1]
            if any((r.get('provider'),r.get('symbol'))!=market or r.get('timeframe')!=tf for r in section):
                raise ValueError('native_interval_foreign_market_or_period')
            if any(r['low']<low-1e-8 or r['high']>high+1e-8 for r in section):
                raise ValueError('native_interval_incomplete_envelope')
            identity=json.dumps([market,tf,points,known],sort_keys=True,separators=(',',':'))
            if identity in seen:continue
            seen.add(identity);owner='book_native_interval:'+sha256(identity.encode()).hexdigest()[:24]
            scopes.append(dict(id=owner,source_id=SCHEMA,owner_id=owner,kind='line',layer='wave',
                timeframe=tf,points=points,known_at_utc=known,
                evidence=dict(data_provider=market[0],native_boundary_scope=True,
                    boundary_scope_state='native_envelope_only',native_envelope_verified=True,
                    interior_order_unknown=bool(leg.get('interior_order_unknown')),
                    source_native_leg_id=leg.get('id'),scope_source_schema=SCHEMA,
                    native_scope_confirmation_clock=known,
                    author_wave_degree='unknown',structural_degree_adjudicated=False,
                    force_admission=False,automatic_trade_permission=False)))
        except (KeyError,TypeError,ValueError,IndexError,OverflowError) as error:
            rejected.append(dict(source_native_leg_id=leg.get('id'),reason=str(error)))
    return scopes,dict(schema=SCHEMA,accepted=len(scopes),rejected=rejected,
        role='native_geometry_ownership_only',force_admission_changed=False,
        author_degree_verified=False,automatic_trade_permission=False)
