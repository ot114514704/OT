"""Book B->C first response, distinct from the two-bar breakout rectangle.

PDF pp.104,135-137 use B as the pre-break extreme, C as the first response
terminal, D as its return, and A as a different structural boundary. The
radius below is an explicit causal engineering approximation, not book text.
"""
from datetime import datetime, timedelta
from functools import lru_cache
from hashlib import sha256

MINUTES={'M1':1,'M5':5,'M15':15,'M30':30,'H1':60,'H4':240,'D1':1440,'W1':10080}


def backtrack_first_wave(bars, timeframe, cutoff, response, change, outer, turning):
    """Compatibility entry for chapter7; chapter5 ``change`` is not its A.

    The chapter7 source is selected independently from original B and native
    rebound structure. Keep the old call signature while callers migrate.
    """
    from .book_chapter7_first_wave import bind_chapter7_first_wave
    return bind_chapter7_first_wave(bars,timeframe,cutoff,response,outer,turning)


def clock(t):
    return _clock_text(str(t))


@lru_cache(maxsize=32768)
def _clock_text(text):
    # Parsed datetimes are immutable; the key retains the entire timestamp
    # including its offset. This cache contains no bars, prices or decisions.
    return datetime.fromisoformat(text.replace('Z','+00:00'))


@lru_cache(maxsize=32768)
def _close_text(timestamp, tf, minutes):
    return (clock(timestamp)+timedelta(minutes=minutes)).isoformat().replace('+00:00','Z')


def close_time(row, tf):
    return _close_text(row['timestamp_utc'],tf,MINUTES[tf])


def pre_break_origin(rows,line,break_event):
    """Book B, frozen in the final old-trend segment BEFORE the break.

    Shared by the source ruler and protective B reference, so the latter
    cannot silently move to a later, adverse post-break extreme.
    """
    i=break_event.get('break_index',-1);j=line.get('end_index',-1)
    side=break_event.get('break_side')
    if side not in ('up','down') or not 0<=j<i<len(rows):return None
    sign=1 if side=='up' else -1
    adverse='low' if sign>0 else 'high'
    origin=min(range(j+1,i+1),key=lambda k:sign*float(rows[k][adverse]))
    prior=None;start=line.get('start_index')
    if isinstance(start,int) and not isinstance(start,bool) and 0<=start<=j:
        k=min(range(start,i+1),key=lambda k:sign*float(rows[k][adverse]))
        prior=dict(index=k,utc=rows[k]['timestamp_utc'],price=float(rows[k][adverse]),
            known_at_utc=break_event.get('known_at_utc'),
            basis='native_outer_start_through_first_close_break_not_author_wave_degree')
    return dict(index=origin,price=float(rows[origin][adverse]),side=side,
        prior_phase_extreme=prior,backtrack_review_required=bool(prior and prior['price']!=float(rows[origin][adverse])))


def first_response_leg(bars, line, break_event, timeframe, cutoff, radius=2):
    """Freeze the FIRST confirmed terminal, never the later largest rebound.

    OHLC extremes describe a candidate B/C; they do not prove intrabar order,
    author wave degree, institutional activity, dual-line completion or entry.
    """
    rows=[r for r in bars if clock(close_time(r,timeframe))<=clock(cutoff)]
    base=dict(schema='book_first_response_leg_v1',timeframe=timeframe,
              as_of_utc=cutoff,source_pdf_pages=[104,135,136,137],
              terminal_confirmation_radius=radius,parameter_basis='engineering_not_author_threshold',
              author_wave_degree='unknown',automatic_trade_permission=False)
    side=break_event.get('break_side')
    i=break_event.get('break_index',-1);j=line.get('end_index',-1)
    if (not line.get('qualified') or side not in ('up','down') or
            break_event.get('status')!='observed_candidate' or not 0<=j<i<len(rows)):
        return dict(base,status='unknown',reason='unbound_break_direction_or_ruler')
    break_known=break_event.get('known_at_utc') or close_time(rows[i],timeframe)
    ruler_known=line.get('known_at_utc')
    dependency=max((t for t in (break_known,ruler_known) if t),key=clock)
    if clock(dependency)>clock(cutoff):
        return dict(base,status='unknown',reason='break_dependency_not_yet_known')
    sign=1 if side=='up' else -1
    adverse='low' if sign>0 else 'high';favourable='high' if sign>0 else 'low'
    # The old trend's final extreme is AFTER its second trendline anchor.
    origin_ref=pre_break_origin(rows,line,break_event)
    origin=origin_ref['index'];price=origin_ref['price']
    origin_point=[clock(rows[origin]['timestamp_utc']).timestamp(),price]
    identity=f"{timeframe}|{line.get('start_price')}|{line.get('end_price')}|{rows[j]['timestamp_utc']}|{rows[i]['timestamp_utc']}|{origin_point}"
    owner='book_first_response:'+sha256(identity.encode()).hexdigest()[:24]
    terminal=None;confirmed=None
    for k in range(max(i,origin+1),len(rows)-radius):
        if k-radius<origin:continue
        v=sign*float(rows[k][favourable])
        # Right-strict selects the end of a flat top/bottom, not its start.
        if (all(v>=sign*float(rows[z][favourable]) for z in range(k-radius,k)) and
                all(v>sign*float(rows[z][favourable]) for z in range(k+1,k+radius+1))):
            terminal=k;confirmed=k+radius;break
    end=terminal if terminal is not None else max(range(max(i,origin+1),len(rows)),
                                                 key=lambda k:sign*float(rows[k][favourable]),default=None)
    if end is None or sign*(float(rows[end][favourable])-price)<=0:
        return dict(base,status='unknown',reason='directional_response_missing')
    end_point=[clock(rows[end]['timestamp_utc']).timestamp(),float(rows[end][favourable])]
    known=max(dependency,close_time(rows[confirmed if confirmed is not None else len(rows)-1],timeframe))
    # Separate the visible post-break response from the complete first-wave
    # source.  A later higher-low/lower-high may be where the final response
    # actually starts, while the source still belongs to frozen B->C.
    response_start = origin
    for k in range(max(origin + radius, i + radius), end - radius + 1):
        value = float(rows[k][adverse])
        left = [float(rows[z][adverse]) for z in range(k-radius, k)]
        right = [float(rows[z][adverse]) for z in range(k+1, k+radius+1)]
        if not left or not right:
            continue
        local = (value <= min(left) and value < min(right)) if sign > 0 else (value >= max(left) and value > max(right))
        higher_or_lower = value > price if sign > 0 else value < price
        if local and higher_or_lower:
            response_start = k
    response_identity = f"{owner}|response|{response_start}|{end}"
    break_response_leg_id = 'book_break_response:' + sha256(response_identity.encode()).hexdigest()[:24]
    # Origin failure is sticky and cannot be rescued by a later, bigger leg.
    failure=next((k for k in range(origin+1,len(rows))
                  if sign*(float(rows[k][adverse])-price)<0),None)
    failure_at=close_time(rows[failure],timeframe) if failure is not None else None
    state='confirmed_source' if confirmed is not None else 'developing_source'
    if failure is not None:state='source_invalidated'
    result=dict(base,status=state,owner_id=owner,source_id=owner,direction=side,
                source_wave_id=line.get('wave_id'),
                wave_membership_state=line.get('wave_membership_state','unknown'),
                ruler_known_at_utc=ruler_known,
                chapter7_B_scope_review=dict(required=origin_ref['backtrack_review_required'],
                    local_B_index=origin,local_B_price=price,prior_phase_extreme=origin_ref['prior_phase_extreme'],
                    author_wave_degree='unknown',protective_B_replaced=False),
                # Compatibility ID for the engineering B->C ruler. PDF201-202
                # can require tracing the first wave back to prior B->A;
                # a local C confirmation cannot establish that author source.
                wave1_source_id=owner, break_response_leg_id=break_response_leg_id,
                wave1_source_basis='engineering_BC_not_pdf201_backtrack',
                author_wave1_source_id=None, author_wave1_state='unverified',
                wave1_source=dict(start_index=origin,end_index=end,
                                  start_utc=rows[origin]['timestamp_utc'],end_utc=rows[end]['timestamp_utc'],
                                  start_price=price,end_price=float(rows[end][favourable]),
                                  status='local_terminal_confirmed' if terminal is not None else 'developing',
                                  author_wave_degree='unknown',
                                  basis='engineering_BC_not_pdf201_backtrack',
                                  source_id=owner),
                break_response_leg=dict(start_index=response_start,end_index=end,
                                        start_utc=rows[response_start]['timestamp_utc'],end_utc=rows[end]['timestamp_utc'],
                                        start_price=float(rows[response_start][adverse]),
                                        end_price=float(rows[end][favourable]),
                                        source_id=break_response_leg_id),
                ruler_span_bars=j-int(line['start_index']),
                break_utc=rows[i]['timestamp_utc'],prior_direction=line.get('direction'),
                ruler_anchors=[[clock(rows[line['start_index']]['timestamp_utc']).timestamp(),float(line['start_price'])],
                               [clock(rows[j]['timestamp_utc']).timestamp(),float(line['end_price'])]],
                origin_B=dict(point=origin_point,known_at_utc=close_time(rows[origin],timeframe),
                              basis='native_extreme_after_second_anchor_before_closed_break'),
                terminal_C=dict(point=end_point,known_at_utc=known,
                                status='confirmed' if terminal is not None else 'developing'),
                break_known_at_utc=break_known,known_at_utc=known,
                source_confirmation_utc=known if terminal is not None else None,
                state_known_at_utc=max(known,failure_at or known),
                invalidated_at_utc=failure_at,points=[origin_point,end_point],
                letters=dict(A='book_structural_boundary_not_source_origin',B='source_origin',
                             C='source_terminal',D='later_return_not_yet_adjudicated'),
                source_complete=terminal is not None,
                book_direction_permission='not_granted_by_force',entry_permission=False)
    return result
