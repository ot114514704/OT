"""Source-owned chapter8 protection for paper positions, independent of selection.

PDF266/268/269: breaking the new two lines alone does not close a position
or relax E. E/G eligibility comes from the existing native stop producer.
This adapter freezes entry provenance and proposes changes; only a later
usable quote can adopt one. Nothing in this module sends an order.
"""
from copy import deepcopy
from decimal import Decimal
from .book_first_response_leg import clock,close_time
from .book_breakout_assessment import digest
from .book_boundary_freeze import ruler_identity


def freeze_protection_source(rows,timeframe,line,event,response,scores):
    identity=deepcopy(scores['source_identity'])
    return dict(schema='book_paper_protection_source_v1',phase_id=scores['phase_id'],
        source_key='book_position_source:'+digest([identity,event['break_utc'],response['origin_B']['point']]),
        source_id=response['source_id'],identity=identity,timeframe=timeframe,
        ruler_span_bars=line['end_index']-line['start_index'],source_wave_id=line.get('wave_id'),
        ruler_known_at_utc=line['known_at_utc'],break_utc=event['break_utc'],
        break_known_at_utc=event['known_at_utc'],origin_B=deepcopy(response['origin_B']['point']),
        terminal_C=deepcopy(response['terminal_C']['point']))


def observe_position_protection(bars,timeframe,cutoff,request,snapshot_id,*,observed_at_utc=None):
    """Rebuild the position's original native ruler, never today's selected one."""
    source=request.get('protection_source') or {}
    base=dict(schema='book_paper_protection_update_v1',intent_id=request['intent_id'],
        source_key=source.get('source_key'),phase_id=source.get('phase_id'),
        observed_at_utc=observed_at_utc or cutoff,native_cutoff_utc=cutoff,prefix_snapshot_id=snapshot_id,candidate=None,
        source_pdf_pages=[264,265,266,268,269],automatic_trade_permission=False,
        order_api_called=False,actual_fill_confirmed=False)
    def wait(reason,**facts):return dict(base,status='waiting',reason=reason,**facts)
    try:
        if clock(base['observed_at_utc'])<clock(cutoff):return wait('observation_precedes_native_cutoff')
    except (TypeError,ValueError,OverflowError):
        return wait('position_native_prefix_clock_invalid')
    if request.get('protection_mode','original_B_only')!='chapter8_EG':
        return wait('selected_policy_retains_original_B')
    try:
        if source.get('schema')!='book_paper_protection_source_v1':return wait('entry_protection_provenance_missing')
        if source['timeframe']!=timeframe:return wait('position_native_timeframe_not_loaded')
        identity=source['identity'];native=identity['ruler'];old_direction=native['direction']
        if source['phase_id']!='book_break_phase:'+digest(identity):return wait('position_phase_identity_mismatch')
        if source['source_key']!='book_position_source:'+digest([identity,source['break_utc'],source['origin_B']]):
            return wait('position_source_key_mismatch')
        if request['phase_id']!=source['phase_id']:return wait('request_phase_mismatch')
        if any(identity[k]!=request[k] for k in ('provider','symbol')):return wait('position_market_mismatch')
        if request['side']!=('buy' if old_direction=='down' else 'sell') or old_direction not in ('up','down'):
            return wait('position_direction_mismatch')
        cutoff_clock=clock(cutoff)
        rows=[]
        for row in bars:
            try:
                if clock(close_time(row,timeframe))<=cutoff_clock:
                    rows.append(row)
            except (KeyError,TypeError,ValueError,OverflowError):
                return wait('position_native_prefix_clock_invalid')
        if any(r.get('timeframe',timeframe)!=timeframe or any(r.get(k,identity[k])!=identity[k]
                for k in ('provider','symbol')) for r in rows):return wait('foreign_position_native_bars')
        indices={clock(r['timestamp_utc']).timestamp():i for i,r in enumerate(rows)}
        if len(indices)!=len(rows) or any(clock(b['timestamp_utc'])<=clock(a['timestamp_utc']) for a,b in zip(rows,rows[1:])):
            return wait('position_native_bar_order_invalid')
        anchors=native['anchors'];i,j=[indices[clock(p[0]).timestamp()] for p in anchors]
        bi=indices[source['origin_B'][0]];ci=indices[source['terminal_C'][0]]
        event_index=indices[clock(source['break_utc']).timestamp()]
        if not 0<=i<j<=bi<=event_index<=ci<len(rows) or j-i!=source['ruler_span_bars']:
            return wait('position_native_ruler_span_or_point_order_changed')
        field='high' if old_direction=='down' else 'low';adverse='low' if field=='high' else 'high'
        if any(Decimal(str(rows[k][field]))!=Decimal(str(p[1])) for k,p in zip((i,j),anchors)):
            return wait('position_ruler_points_not_native')
        if (Decimal(str(rows[bi][adverse]))!=Decimal(str(source['origin_B'][1]))
                or Decimal(str(request['stop']))!=Decimal(str(source['origin_B'][1]))
                or Decimal(str(rows[ci][field]))!=Decimal(str(source['terminal_C'][1]))):
            return wait('position_B_or_C_not_native')
        if clock(source['ruler_known_at_utc'])>clock(source['break_utc']):return wait('position_ruler_was_not_prospective')
        if clock(source['break_known_at_utc'])>clock(cutoff):return wait('position_break_not_known')
        line=dict(qualified=True,direction=old_direction,start_index=i,end_index=j,
            start_price=anchors[0][1],end_price=anchors[1][1],
            slope=float((Decimal(str(anchors[1][1]))-Decimal(str(anchors[0][1])))/(j-i)),
            wave_id=source.get('source_wave_id'),known_at_utc=source['ruler_known_at_utc'])
        if ruler_identity(rows,line,timeframe)!=native:return wait('position_native_ruler_identity_changed')
        from .trend_trade_method_full_pipeline import detect_first_closed_break
        from .trend_trade_method_patterns import build_stop_reference,build_stop_adjustment_candidates
        event=detect_first_closed_break(rows,line,timeframe,cutoff)
        if event.get('break_utc')!=source['break_utc']:return wait('original_position_break_not_reproduced')
        event['known_at_utc']=source['break_known_at_utc']
        stop=build_stop_reference(rows,timeframe,cutoff,{},line,event)
        if (stop.get('reference_index')!=bi or stop.get('reference_price')!=source['origin_B'][1]):
            return wait('position_B_changed_in_reconstruction')
        adjustment=build_stop_adjustment_candidates(rows,timeframe,cutoff,stop,event)
        base.update(adjustment=adjustment,stop_reference=stop)
        if adjustment.get('status')!='adjustment_candidate':return wait('no_current_eligible_unbreached_EG')
        if adjustment.get('c_utc')!=rows[ci]['timestamp_utc'] or adjustment.get('c_price')!=source['terminal_C'][1]:
            return wait('adjustment_C_differs_from_position_first_response')
        active=deepcopy((adjustment.get('candidate_path') or [{}])[-1])
        if active.get('status')!='hypothetical_reference_available':return wait('EG_path_already_ended')
        first_eligibility_basis=active['basis'];first_eligibility_known=active['known_at_utc']
        if (active['basis']=='recovery_strict_0.3_EF_after_owned_dual_break'
                and request.get('allow_unquantified_rapid_recovery') is not True):
            # Do not invent a speed threshold. A later independently observed
            # F close can qualify the ordinary route without rewriting which
            # geometric route first made G a hypothetical candidate.
            direction=1 if request['side']=='buy' else -1
            f_cross=next((r for r in rows[adjustment['g_index']+1:]
                if direction*(Decimal(str(r['close']))-Decimal(str(adjustment['f_price'])))>0),None)
            if f_cross is None:return wait('author_rapid_recovery_speed_not_quantified')
            active['basis']='closed_F_break_after_C'
            active['known_at_utc']=max((active['known_at_utc'],close_time(f_cross,timeframe)),key=clock)
        if clock(active['known_at_utc'])>clock(cutoff):return wait('EG_eligibility_after_cutoff')
        sign=1 if request['side']=='buy' else -1
        if sign*(Decimal(str(active['price']))-Decimal(str(request['stop'])))<=0:
            return wait('EG_does_not_tighten_original_B')
        candidate=dict(id='paper_protection:'+digest([source['source_key'],active['role'],active['utc'],active['price'],active['basis']]),
            role=active['role'],price=active['price'],point_utc=active['utc'],basis=active['basis'],
            eligible_known_at_utc=active['known_at_utc'],source_key=source['source_key'],
            first_geometric_eligibility_basis=first_eligibility_basis,
            first_geometric_eligibility_known_at_utc=first_eligibility_known,
            phase_id=source['phase_id'],source_pdf_pages=base['source_pdf_pages'],
            author_setup_verified=False,reference_is_real_broker_stop=False)
        return dict(base,status='candidate',reason=None,candidate=candidate)
    except KeyError:return wait('original_position_native_history_or_provenance_missing')
    except (ValueError,TypeError,IndexError,ArithmeticError):return wait('position_protection_evidence_invalid')
