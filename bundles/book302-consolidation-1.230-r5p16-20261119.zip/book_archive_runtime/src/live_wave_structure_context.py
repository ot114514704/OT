"""Bind what a first opposite wave retraces, without grading it by speed.

Alexander 7676543496751127699 / 7676550586231557407: compare the first
wave's delivery and the preceding structure; a weak first wave still has
competing retracement routes. 7605363360134535055: name the whole wave
being retraced, not just its last internal push. These objects are geometric
evidence, not automatic author wave names, protected nodes or degree labels.
"""
from bisect import bisect_left, bisect_right
from math import isfinite, isclose

from .live_nested_stage_review import _same, _time
from .live_source_wave_scope import source_wave_scope, known_envelope_component
from .live_one_to_one_source_selection import _close_delivery
from .live_return_wave_scope import projection_owner


def projection_structure_relation(family, projection):
    """Compare a conditional target path to B-known reference nodes.

    Feb3 (7676649229776707833) names a local 1:1 before the prior high is
    broken; Feb27 (7685764459885286786..7685764796256176487) says neither
    force nor 1:1 proves breakout. This is prospective geometry, not a new
    admission gate or an assertion that our geometric nodes are those author
    wave2/wave4 highs. No outcome or post-anchor candles are consulted.
    """
    result = dict(status='reference_unresolved',
        known_at_utc=projection['known_at_utc'],
        native_timeframe=family['timeframe'],
        measurement_source_leg_id=family['source_leg_id'],
        retraces_source_leg_id=projection.get('retraces_source_leg_id'),
        source_context_known_at_utc=family['known_at_utc'],
        reference_scope='preceding_geometric_wave_at_source_confirmation',
        nodes=[], observation_time='source_confirmation_not_current_market',
        target_is_observed_breakout=False, structural_degree_adjudicated=False,
        admission_changed=False, trade_permission=False,
        theory_source_message_ids=['7676649229776707833','7685764459885286786',
                                  '7685764649186122721','7685764796256176487'])
    context=family.get('source_opposing_wave_context') or {}
    if context.get('status')!='preceding_wave_and_local_structure_bound':
        return {**result,'reason':'no_bound_preceding_reference'}
    known=_time(projection['known_at_utc'])
    source_known=_time(family['known_at_utc'])
    if (context.get('native_timeframe')!=family['timeframe'] or
            projection.get('anchor_native_timeframe')!=family['timeframe'] or
            projection.get('measurement_source_leg_id')!=family['source_leg_id'] or
            _time(context['known_at_utc'])!=source_known or source_known>known):
        return {**result,'reason':'reference_identity_or_time_mismatch'}
    anchor,target=projection['anchor']['price'],projection['target']
    signed=family['source_terminal']['price']-family['source_origin']['price']
    if (not all(isfinite(v) for v in (anchor,target,signed)) or not signed or
            not isclose(target-anchor,signed,rel_tol=1e-10,abs_tol=1e-8)):
        return {**result,'reason':'projection_not_same_signed_source_height'}
    direction=1 if signed>0 else -1
    nodes=[]
    for node in context['nodes']:
        point=node['pivot']
        if _time(point['confirmed_at_utc'])>source_known or not isfinite(point['price']):
            return {**result,'reason':'reference_not_known_at_source'}
        distance=direction*(point['price']-anchor)
        length=abs(signed)
        relation=('behind_anchor' if distance<0 else 'at_anchor' if distance==0
                  else 'on_projected_leg' if distance<length else
                  'at_target' if distance==length else 'beyond_target')
        nodes.append(dict(node_id=node['node_id'],price=point['price'],role=node['role'],
            pivot_timestamp_utc=point['pivot_timestamp_utc'],
            relation_to_projected_leg=relation,
            source_terminal_closed_beyond=node['terminal_close_beyond'],
            any_source_close_beyond=node['any_source_close_beyond'],
            semantic_control_node=False))
    nodes.sort(key=lambda n:direction*(n['price']-anchor))
    return {**result,'status':'conditional_target_related_to_source_nodes',
        'anchor_price':anchor,'target_price':target,'nodes':nodes,
        'interpretation':'目标与来源确认时已知节点的几何关系；不说明C时或现在已突破，也不单独决定量尺准入。'}


def _key(point):
    return tuple(point[k] for k in ('kind','pivot_timestamp_utc','price','confirmed_at_utc'))


def first_outer_structure_reclaim(context, prior_families):
    """Independent first-source route, NOT evidence a smaller ruler finished.

    Feb2's handled-structure context and Feb10's whole-wave ownership motivate
    this conservative research interpretation. It is not an author-defined
    sufficient trading rule or a proof of degree. Only a *new* terminal close
    beyond the connected preceding WHOLE origin qualifies here; touching an
    internal node, or repeating an already measured reclaim, does not.
    No projection outcome (past or future) is inspected.
    """
    result = dict(status='no_new_outer_structure_delivery',
        known_at_utc=context['known_at_utc'],
        outcomes_used_for_admission=False, structural_degree_adjudicated=False,
        trade_permission=False)
    reference = context.get('retraced_wave')
    node = next((n for n in context.get('nodes', []) if n['role']=='preceding_wave_origin'), None)
    if not prior_families or not reference or not node or not node['terminal_close_beyond']:
        return {**result, 'reason':'new_terminal_close_beyond_connected_whole_origin_not_observed'}
    receipts=[]
    for family in prior_families:
        previous=family.get('source_opposing_wave_context') or {}
        previous_wave=previous.get('retraced_wave')
        previous_node=next((n for n in previous.get('nodes', []) if n['role']=='preceding_wave_origin'), None)
        if (not previous_wave or not previous_node or
                previous_wave['source_leg_id']!=reference['source_leg_id'] or
                not _same(previous_wave['origin'],reference['origin']) or
                not _same(previous_wave['terminal'],reference['terminal'])):
            return {**result, 'reason':'prior_source_structure_reference_unresolved_or_changed'}
        if previous_node['any_source_close_beyond']:
            return {**result, 'reason':'whole_origin_already_delivered_by_prior_measurement',
                    'prior_measurement_id':family['measurement_id']}
        receipts.append(family['measurement_id'])
    return {**result, 'status':'first_delivery_beyond_preceding_whole_origin',
        'reference_wave_id':reference['source_leg_id'], 'reference_node':node['pivot'],
        'first_source_close_through_bar_open_utc':node['first_source_close_through_bar_open_utc'],
        'terminal_close_beyond':True, 'coexisting_measurement_ids':receipts,
        'interpretation':'独立整段首次收过前一整段起点；不是小量尺到位升级，不保证本级趋势或回调级别已成立。'}


class WaveStructureIndex:
    """Call-local, already native-validated ledger; no cross-snapshot cache."""
    def __init__(self, legs, native):
        self.legs, self.native = legs, native
        self.by_terminal, self.by_id = {}, {}
        self.component_counts = {}
        for leg in legs:
            self.by_terminal.setdefault(_key(leg['terminal']), []).append(leg)
            self.by_id[leg['leg_id']] = leg
            self.component_counts[leg['leg_id']] = self.component_counts.get(leg['leg_id'], 0) + 1

    def owner_reference_components(self, owner, context):
        """Distinguish a complete suffix from a merely shared price/terminal.

        Feb10's blue whole wave may contain smaller named pushes. Compare
        the entire known native component chain, not price containment alone.
        This is an observed nesting relation, not wave-degree adjudication,
        a reason to move A/C, or proof that either return has finished.
        """
        reference = context.get('retraced_wave') or {}
        result = dict(status='component_relation_unresolved',
            known_at_utc=context['known_at_utc'], native_timeframe=self.native.timeframe,
            named_owner_id=owner['id'], reference_wave_id=reference.get('source_leg_id'),
            structural_degree_adjudicated=False, return_completion_adjudicated=False,
            admission_changed=False, trade_permission=False)
        if (context.get('status') != 'preceding_wave_and_local_structure_bound' or
                context.get('native_timeframe') != self.native.timeframe or
                reference.get('native_timeframe') != self.native.timeframe):
            return {**result, 'reason':'reference_identity_unresolved'}
        try:
            known = _time(context['known_at_utc'])
            if _time(owner['known']) > known:
                return {**result, 'reason':'owner_not_known_at_reference_observation'}
            def chain(ids, a, b):
                if not ids or len(set(ids)) != len(ids) or any(self.component_counts.get(i) != 1 for i in ids):
                    return None
                parts = [self.by_id[i] for i in ids]
                if (not all(known_envelope_component(l,self.native.timeframe,self.native.raw,known) for l in parts) or
                        not _same(parts[0]['origin'],a) or not _same(parts[-1]['terminal'],b) or
                        any(not _same(l['terminal'],r['origin']) for l,r in zip(parts,parts[1:]))):
                    return None
                return parts
            owner_ids,ref_ids = owner['components'],reference['component_source_leg_ids']
            own_parts = chain(owner_ids,owner['origin'],owner['terminal'])
            ref_parts = chain(ref_ids,reference['origin'],reference['terminal'])
            if own_parts is None or ref_parts is None:
                return {**result, 'reason':'missing_ambiguous_disconnected_future_or_wrong_native_components'}
            terminal_shared = _same(owner['terminal'],reference['terminal'])
            owner_suffix = terminal_shared and len(owner_ids)<len(ref_ids) and ref_ids[-len(owner_ids):]==owner_ids
            ref_suffix = terminal_shared and len(ref_ids)<len(owner_ids) and owner_ids[-len(ref_ids):]==ref_ids
            if owner_ids==ref_ids and _same(owner['origin'],reference['origin']) and terminal_shared:
                relation,extra = 'same_native_components',[]
            elif owner_suffix:
                relation,extra = 'owner_is_component_suffix_of_reference',ref_ids[:-len(owner_ids)]
            elif ref_suffix:
                relation,extra = 'reference_is_component_suffix_of_owner',owner_ids[:-len(ref_ids)]
            else:
                relation,extra = ('shared_terminal_without_complete_suffix' if terminal_shared else
                                  'different_terminal_no_suffix_relation'),[]
            unordered = sorted({l['origin']['pivot_timestamp_utc'] for l in own_parts+ref_parts
                                if l.get('temporal_order')=='same_bar_unresolved'})
            return {**result, 'status':'native_component_relation_recorded', 'relation':relation,
                'shared_terminal':terminal_shared, 'owner_component_count':len(owner_ids),
                'reference_component_count':len(ref_ids), 'additional_prefix_component_ids':list(extra),
                'owner_component_ids':list(owner_ids), 'reference_component_ids':list(ref_ids),
                'unordered_component_bar_times':unordered, 'intrabar_order_inferred':False,
                'interpretation':'完整组成链的相等／末端包含关系；共享终点或价格包住不足以证明包含，也不因此把几何参考升级为更高结构级别。'}
        except (KeyError,TypeError,ValueError):
            return {**result, 'reason':'malformed_native_component_identity'}

    def return_review(self, family, projection):
        """Read first opposite departure separately from accumulated B-to-C.

        Feb2: first-wave force and the structure it handles inform the return
        location. Feb10: the return must refer to the complete named source,
        not its terminal internal push. Record those exact relationships; do
        not call a connected C a completed same-degree return.
        """
        path=projection.get('return_wave_scope') or {}
        result=dict(status='return_structure_unresolved',
            retraces_source_leg_id=projection.get('retraces_source_leg_id'),
            known_at_utc=projection['known_at_utc'],native_timeframe=self.native.timeframe,
            structural_degree_adjudicated=False,return_completion_adjudicated=False,
            admission_changed=False,trade_permission=False)
        owner=projection_owner(family,projection,self.native.timeframe)
        if not owner:
            return {**result,'reason':'named_return_owner_not_bound'}
        ids=path.get('component_leg_ids') or []
        first=self.by_id.get(ids[0]) if ids else None
        if (path.get('status')!='connected_native_return_candidate' or
                path.get('native_timeframe')!=self.native.timeframe or
                family['timeframe']!=self.native.timeframe or
                projection.get('anchor_native_timeframe')!=self.native.timeframe or
                path.get('retraces_source_leg_id')!=owner['id'] or
                result['retraces_source_leg_id']!=owner['id'] or
                not path.get('return_origin') or not path.get('endpoint_candidate') or
                not _same(path['return_origin'],owner['terminal']) or
                not _same(path['endpoint_candidate'],projection['anchor']) or
                _time(path['known_at_utc'])>_time(projection['known_at_utc']) or
                not first or not _same(first['origin'],owner['terminal'])):
            return {**result,'reason':'return_path_or_source_identity_unresolved'}
        first_known=max(_time(owner['known']),
                        *(_time(p['confirmed_at_utc']) for p in (first['origin'],first['terminal'])))
        if first_known>_time(projection['known_at_utc']):
            return {**result,'reason':'first_return_leg_not_yet_known'}
        first_context=self.review(first['origin'],first['terminal'],first_known.isoformat().replace('+00:00','Z'))
        whole_context=self.review(owner['terminal'],projection['anchor'],projection['known_at_utc'])
        first_components=self.owner_reference_components(owner,first_context)
        whole_components=self.owner_reference_components(owner,whole_context)
        def relation(context):
            wave=context.get('retraced_wave')
            if not wave:return 'reference_unresolved'
            # The actual second span has its own ID, distinct from an index's
            # geometric-leg ID. Match complete native components and bounds;
            # keep any larger competing preceding envelope rather than crop it.
            identity=(wave['source_leg_id']==owner['id'] if owner['original_AB'] else
                      wave['component_source_leg_ids']==owner['components'])
            if (identity and _same(wave['origin'],owner['origin']) and
                    _same(wave['terminal'],owner['terminal'])):
                return 'same_named_source'
            return 'different_preceding_envelope_not_substituted'
        return {**result,'status':'first_and_accumulated_return_structure_recorded',
            'first_return_leg_id':first['leg_id'],
            'first_return_terminal':first['terminal'],
            'first_return_known_at_utc':first_context['known_at_utc'],
            'first_return_source_relation':relation(first_context),
            'accumulated_return_source_relation':relation(whole_context),
            'first_return_source_component_relation':first_components,
            'accumulated_return_source_component_relation':whole_components,
            'first_return_node_ownership':self.return_node_ownership(owner,first_context,
                first['origin'],first['terminal'],first_components),
            'accumulated_return_node_ownership':self.return_node_ownership(owner,whole_context,
                owner['terminal'],projection['anchor'],whole_components),
            'first_return_context':first_context,'accumulated_return_context':whole_context,
            'internal_rebounds_are_new_first_departures':False,
            'interpretation':'首段反向推动与累积回调分开比较原整段及其内部结构；后来的反弹不重置首段，穿越事实不自动裁定同级回调结束。'}

    def return_node_ownership(self, owner, context, a, b, components):
        """Relate observed delivery to the named whole, not an enclosing alias.

        Feb2's handled-structure comparison does not make every native pivot
        an author fourth-wave high. Keep node ownership and close facts apart
        from that semantic adjudication, and from completion of the return.
        Reuse the exact context observations without duplicating its complete
        close-witness arrays. First departure and accumulated return are read
        independently at their own known cutoffs.
        """
        result=dict(status='return_node_ownership_unresolved',
            known_at_utc=context['known_at_utc'],native_timeframe=self.native.timeframe,
            named_owner_id=owner['id'],reference_wave_id=components.get('reference_wave_id'),
            nodes=[],structural_degree_adjudicated=False,return_completion_adjudicated=False,
            semantic_control_node_adjudicated=False,admission_changed=False,trade_permission=False)
        if (components.get('status')!='native_component_relation_recorded' or
                components.get('relation') not in ('same_native_components','owner_is_component_suffix_of_reference') or
                components.get('native_timeframe')!=self.native.timeframe or
                components.get('named_owner_id')!=owner['id'] or
                components.get('known_at_utc')!=context['known_at_utc']):
            return {**result,'reason':'complete_named_owner_reference_relation_unresolved'}
        try:
            known=_time(context['known_at_utc'])
            if (not _same(a,owner['terminal']) or
                    max(_time(p['confirmed_at_utc']) for p in (a,b))>known or
                    self._path(a,b)['coverage_gap']):
                return {**result,'reason':'return_path_identity_time_or_coverage_unresolved'}
            own_points={_key(p) for i in components['owner_component_ids']
                for p in (self.by_id[i]['origin'],self.by_id[i]['terminal'])}
            ref_point_map={_key(p):p for i in components['reference_component_ids']
                for p in (self.by_id[i]['origin'],self.by_id[i]['terminal'])}
            expected={key for key,p in ref_point_map.items() if p['kind']==b['kind'] and
                _time(p['pivot_timestamp_utc'])<_time(a['pivot_timestamp_utc']) and _time(p['confirmed_at_utc'])<=known}
            nodes=[]
            seen=set()
            for node in context['nodes']:
                point=node['pivot'];key=_key(point)
                if (key not in expected or key in seen or _time(point['confirmed_at_utc'])>known or
                        node['node_id']!=f"{self.native.timeframe}:{point['pivot_timestamp_utc']}:{point['kind']}"):
                    return {**result,'reason':'node_not_uniquely_bound_to_known_reference_components'}
                for field in ('first_range_reach_bar_open_utc','first_source_close_through_bar_open_utc',
                              'latest_source_close_through_bar_open_utc'):
                    if node[field] is not None:
                        stamp=_time(node[field])
                        if (stamp not in self.native.raw or not
                            max(_time(a['pivot_timestamp_utc']),_time(point['confirmed_at_utc']))<=stamp<=_time(b['pivot_timestamp_utc'])):
                            return {**result,'reason':'node_delivery_witness_outside_known_native_return'}
                seen.add(key)
                role=('named_owner_origin' if _same(point,owner['origin']) else
                      'named_owner_internal_turn' if key in own_points else 'preceding_reference_only')
                response=('sustained_close_beyond' if node['sustained_source_close'] else
                    'terminal_close_beyond_without_observed_follow' if node['terminal_close_beyond'] else
                    'closed_beyond_then_returned' if node['any_source_close_beyond'] else
                    'range_reached_no_close_beyond' if node['first_range_reach_bar_open_utc'] else 'not_reached')
                nodes.append(dict(node_id=node['node_id'],pivot=point,ownership_role=role,
                    reference_role=node['role'],response=response,
                    any_close_beyond=node['any_source_close_beyond'],
                    terminal_close_beyond=node['terminal_close_beyond'],
                    observed_follow_while_terminal_beyond=node['sustained_source_close'],
                    first_range_reach_bar_open_utc=node['first_range_reach_bar_open_utc'],
                    first_close_through_bar_open_utc=node['first_source_close_through_bar_open_utc'],
                    latest_close_through_bar_open_utc=node['latest_source_close_through_bar_open_utc']))
            if seen!=expected:
                return {**result,'reason':'known_reference_nodes_missing_not_zero'}
            origin=next((n for n in nodes if n['ownership_role']=='named_owner_origin'),None)
            if origin is None:
                return {**result,'reason':'named_owner_origin_not_available_as_ordered_node'}
            return {**result,'status':'named_owner_and_reference_node_delivery_recorded',
                'nodes':nodes,'named_owner_origin_node_id':origin['node_id'],
                'return_origin':a,'return_terminal':b,
                'witness_time_semantics':'native_bar_open_labels_not_close_or_action_times',
                'interpretation':'本命名整段起点／内部节点与更大参考独有节点分别记录触及、收过与返回；节点穿越不单独裁定同级回调完成或趋势反转。'}
        except (KeyError,TypeError,ValueError):
            return {**result,'reason':'malformed_node_or_native_component_binding'}

    def _path(self, a, b):
        native = self.native
        ta,tb = _time(a['pivot_timestamp_utc']),_time(b['pivot_timestamp_utc'])
        lo,hi = bisect_left(native.times,ta),bisect_right(native.times,tb)
        rows = native.bars[lo:hi]
        complete = native.complete(ta,tb)
        preceding = native.bars[lo-1] if lo and native.complete(native.times[lo-1],ta) else None
        intervals = hi-lo-1
        return dict(bars=rows, preceding_bar=preceding, coverage_gap=not complete,
            amplitude=abs(b['price']-a['price']),
            points_per_native_interval=abs(b['price']-a['price'])/intervals if complete and intervals>0 else None)

    def review(self, a, b, known_at_utc):
        """All evidence ends at B; later C/outcomes cannot select a parent.

        Reference set is the connected preceding envelope, not arbitrary
        chart-wide old extrema. A preceding opposite wave may itself contain
        several pushes. Keep the last push as a separate comparison.
        """
        known = _time(known_at_utc)
        result = dict(status='preceding_wave_unresolved', known_at_utc=known_at_utc,
            native_timeframe=self.native.timeframe, retraced_wave=None, nodes=[],
            semantic_force_adjudicated=False, structural_degree_adjudicated=False,
            parent_task_adjudicated=False, speed_used_as_admission_gate=False,
            trade_permission=False,
            theory_source_message_ids=['7676543496751127699','7676550586231557407','7605363360134535055'])
        previous = [leg for leg in self.by_terminal.get(_key(a),[]) if
            max(_time(p['confirmed_at_utc']) for p in (leg['origin'],leg['terminal']))<=known]
        if len(previous)!=1:
            return {**result, 'reason':'missing_or_ambiguous_connected_preceding_wave'}
        previous = previous[0]
        scope = source_wave_scope(self.legs,self.native.raw,self.native.timeframe,
            previous['origin'],a,known_at_utc,_window_index=self.native.envelope)
        if scope.get('status')!='observed_same_period_zigzag_envelope' or not _same(scope['terminal'],a):
            return {**result, 'reason':'preceding_envelope_unresolved'}
        pa,pb = scope['origin'],scope['terminal']
        opposing = self._path(pa,pb)
        if opposing['coverage_gap'] or not self.native.envelope.contains(self.native.raw,
                self.native.timeframe,_time(pa['pivot_timestamp_utc']),_time(pb['pivot_timestamp_utc']),
                *sorted((pa['price'],pb['price']))):
            return {**result, 'reason':'preceding_wave_native_envelope_or_coverage_unresolved'}
        path = self._path(a,b)
        adjacent = self._path(previous['origin'],previous['terminal'])
        refs = {}
        for leg_id in scope['component_source_leg_ids']:
            for point in (self.by_id[leg_id]['origin'], self.by_id[leg_id]['terminal']):
                if (point['kind']==b['kind'] and _time(point['pivot_timestamp_utc'])<_time(a['pivot_timestamp_utc'])
                        and _time(point['confirmed_at_utc'])<=known):
                    refs[_key(point)] = point
        up = b['price']>a['price']
        nodes=[]
        for point in sorted(refs.values(),key=lambda p:p['pivot_timestamp_utc']):
            delivery=_close_delivery(path,point,up,compact_witnesses=True)
            nodes.append(dict(node_id=f"{self.native.timeframe}:{point['pivot_timestamp_utc']}:{point['kind']}",
                pivot=point, role='preceding_wave_origin' if _same(point,pa) else 'preceding_wave_internal_turn',
                **{k:v for k,v in delivery.items() if k!='reference'}, semantic_control_node=False))
        outer = next((node for node in nodes if node['role']=='preceding_wave_origin'),None)
        if outer and outer['terminal_close_beyond']:
            location='closed_beyond_preceding_wave_origin_not_parent_reversal_confirmation'
        elif outer and outer['first_range_reach_bar_open_utc']:
            location='preceding_wave_origin_touched_or_swept_not_held_beyond'
        elif any(node['any_source_close_beyond'] for node in nodes):
            location='internal_structure_reached_outer_origin_not_crossed'
        else:
            location='within_preceding_wave_no_observed_node_close_through'
        result.update(status='preceding_wave_and_local_structure_bound',
            retraced_wave=dict(source_leg_id=scope['source_leg_id'],origin=pa,terminal=pb,
                component_source_leg_ids=scope['component_source_leg_ids'],
                interior_unordered_bar_times=scope['interior_unordered_bar_times'],
                intrabar_order_inferred=False,
                native_timeframe=self.native.timeframe,structural_degree_adjudicated=False),
            preceding_adjacent_leg_id=previous['leg_id'],
            comparison=dict(source_amplitude=path['amplitude'],
                source_points_per_native_interval=path['points_per_native_interval'],
                preceding_whole_wave_amplitude=opposing['amplitude'],
                preceding_whole_wave_points_per_native_interval=opposing['points_per_native_interval'],
                preceding_last_push_amplitude=adjacent['amplitude'],
                preceding_last_push_points_per_native_interval=adjacent['points_per_native_interval']),
            nodes=nodes, location_observation=location,
            competing_paths=['return_inside_preceding_wave','first_opposite_wave_starting_larger_adjustment'],
            interpretation='先比较所回调整段、内部节点和外侧起点；速率不单独确认或否决首浪，也不证明级别。')
        return result
