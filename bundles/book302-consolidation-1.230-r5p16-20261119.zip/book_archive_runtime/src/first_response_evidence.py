"""Read-only first opposite-wave evidence; not force or entry confirmation.

Alexander 7602322931794615203/7602323140890502153 distinguishes first
delivery from clearing the preceding high. OHLC comparisons do not observe
order-book liquidity. No new numerical admission threshold is introduced.
"""
from math import isfinite
import statistics

MIN_LOW_LIQUIDITY_WAVE_BARS = 20


def path_facts(bars, upward):
    if len(bars) < 2:
        return None
    rows = [[float(b[k]) for k in ('open', 'high', 'low', 'close')] for b in bars]
    if any(not all(isfinite(v) for v in r) or not r[2] <= min(r[0], r[3]) <= max(r[0], r[3]) <= r[1] for r in rows):
        return None
    sign = 1 if upward else -1
    moves = [sign*(b[3]-a[3]) for a,b in zip(rows,rows[1:])]
    # Turning candle may belong to the prior direction; score after its close.
    bodies = [sign*(r[3]-r[0]) for r in rows[1:]]
    spans = [r[1]-r[2] for r in rows[1:]]
    travel, body, span = sum(abs(v) for v in moves), sum(abs(v) for v in bodies), sum(spans)
    overlaps = [max(0., min(a[1],b[1])-max(a[2],b[2])) /
                max(1e-12, max(a[1],b[1])-min(a[2],b[2])) for a,b in zip(rows,rows[1:])]
    close_follow_ratio = sum(v > 0 for v in moves) / max(1, len(moves))
    return dict(native_intervals=len(moves), net_close_points=sum(moves),
        close_points_per_interval=sum(moves)/len(moves),
        close_follow_ratio=close_follow_ratio,
        path_efficiency=sum(moves)/travel if travel else 0.,
        body_share=body/span if span else 0.,
        directional_body_share=sum(max(0.,v) for v in bodies)/body if body else 0.,
        mean_range_overlap=sum(overlaps)/len(overlaps))


def _legacy_outer_turning_trendline(bars, upward):
    """Find an outer two-pivot line that stays clear of the wave candles.

    The line is deliberately different from a regression channel rail.  It
    joins two well-separated local outer pivots, then requires the interior
    highs (down wave) or lows (up wave) to remain on the inside with a visible
    clearance.  That is the user's ``拐点线``: it may touch its two anchors,
    but it must not run through the low-liquidity candles.
    """
    n = len(bars)
    if n < 12:
        return None
    values = [float(b['low'] if upward else b['high']) for b in bars]
    ranges = [max(0.0, float(b['high']) - float(b['low'])) for b in bars]
    typical = statistics.median(r for r in ranges if r > 0) if any(ranges) else 0.0
    radius = max(2, min(8, n // 12))
    extrema = []
    for i in range(radius, n - radius):
        left = values[i-radius:i]
        right = values[i+1:i+radius+1]
        if (upward and values[i] <= min(left) and values[i] <= min(right)) or (
                not upward and values[i] >= max(left) and values[i] >= max(right)):
            extrema.append(i)
    # Keep the wave origin available.  The old implementation discarded the
    # first/last radius bars and then pooled almost every interior candle;
    # that selected short, lower-period-looking lines inside the real wave.
    # A boundary is a valid pivot when the movement starts at that candle.
    candidates = set(extrema)
    candidates.update((0, n - 1))
    # A monotone shoulder may not be a strict local extremum.  Add only the
    # strongest outer pivot from each broad portion, rather than every bar.
    first_pool = range(0, max(2, int(n * 0.40)))
    second_pool = range(max(1, int(n * 0.40)), n)
    key = (lambda i: values[i]) if not upward else (lambda i: -values[i])
    candidates.add(max(first_pool, key=key))
    candidates.add(max(second_pool, key=key))
    candidates = sorted(candidates)
    min_sep = max(6, n // 6)
    best = None
    for i in candidates:
        for j in candidates:
            if j <= i or j - i < min_sep or j >= n - 1:
                continue
            # Down wave: descending highs. Up wave: ascending lows.
            slope = (values[j] - values[i]) / (j - i)
            if (not upward and slope >= -1e-12) or (upward and slope <= 1e-12):
                continue
            # Validate the complete movement from the first anchor through
            # the wave terminal.  The line may touch only its two anchors;
            # checking only i..j was the source of the visible false lines
            # whose later candles crossed the second pivot's extension.
            interior = []
            for k in range(i + 1, n):
                if k == j:
                    continue
                line = values[i] + slope * (k - i)
                interior.append((line - values[k]) if not upward else (values[k] - line))
            if not interior:
                continue
            clearance = min(interior)
            required = max(typical * 0.005, 1e-9)
            if clearance < required:
                continue
            # Prefer the earliest valid origin and the furthest second pivot;
            # this keeps one line for the whole same-period pullback instead
            # of choosing a visually cleaner fragment in its middle.
            score = (n - i, j - i, clearance,
                     1 if i in extrema else 0, 1 if j in extrema else 0)
            if best is None or score > best['_rank']:
                best = dict(start_index=i, end_index=j,
                            start_price=values[i], end_price=values[j],
                            slope=slope, min_clearance=clearance,
                            mean_clearance=sum(interior) / len(interior),
                            score=float(clearance), _rank=score,
                            anchor_count=2)
    if best is None:
        return None
    best['start_utc'] = bars[best['start_index']].get('timestamp_utc')
    best['end_utc'] = bars[best['end_index']].get('timestamp_utc')
    best['direction'] = 'up' if upward else 'down'
    best['clearance_required'] = max(typical * 0.005, 1e-9)
    best.pop('_rank', None)
    return best


def _outer_turning_trendline(bars, upward):
    """Use the independent PDF outer-wave selector for chart geometry."""
    from .pdf_trendline_block import select_pdf_outer_trendline
    return select_pdf_outer_trendline(bars, upward)


def _burst_facts(bars, upward):
    """Score the actual breakout candles, including the first candle.

    ``path_facts`` intentionally ignores the turning candle for wave-path
    diagnostics.  That convention is wrong for a first-break force burst:
    the candle that closes through the trendline is the primary evidence.
    """
    if not bars:
        return None
    rows = [[float(b[k]) for k in ('open', 'high', 'low', 'close')] for b in bars]
    if any(not all(isfinite(v) for v in r) or
           not r[2] <= min(r[0], r[3]) <= max(r[0], r[3]) <= r[1]
           for r in rows):
        return None
    sign = 1 if upward else -1
    bodies = [sign * (r[3] - r[0]) for r in rows]
    spans = [max(0.0, r[1] - r[2]) for r in rows]
    closes = [sign * (r[3] - a[3]) for a, r in zip(rows, rows[1:])]
    travel = sum(abs(v) for v in closes)
    body = sum(abs(v) for v in bodies)
    span = sum(spans)
    first = rows[0]
    first_body = abs(first[3] - first[0])
    first_span = max(spans[0], 1e-12)
    first_directional_body = max(0.0, bodies[0])
    return dict(native_intervals=max(0, len(rows) - 1),
                close_follow_ratio=(sum(v > 0 for v in closes) /
                                    max(1, len(closes))) if closes else
                                   (1.0 if bodies[0] > 0 else 0.0),
                path_efficiency=(sum(closes) / travel if travel else
                                 (1.0 if bodies[0] > 0 else 0.0)),
                body_share=body / span if span else 0.0,
                directional_body_share=sum(max(0.0, v) for v in bodies) /
                body if body else 0.0,
                burst_range=max(spans), bar_count=len(rows),
                first_body=first_body,
                first_body_share=first_body / first_span,
                first_directional_body=first_directional_body,
                first_directional_body_share=first_directional_body / first_span)


def _trendline_force_decision(burst_facts, first_facts, baseline_range,
                              hold_count, tolerance):
    """Admit only a forceful first trendline break.

    The book's sequence is: a closed candle breaks the outer line, the break
    has visible directional body/range, and the next price action holds the
    new side.  A wick or an ordinary close is still a geometric break, but it
    is not a displayed force event.  A single exceptional first candle is
    allowed when its body and excursion are both large enough; this covers
    the book examples where the turn is delivered in one decisive bar.
    """
    if not burst_facts or not first_facts:
        return False, "missing_break_candle_facts"
    typical = max(float(baseline_range or 0.0), 1e-12)
    first_range = max(float(first_facts.get("burst_range") or 0.0), 0.0)
    first_body = max(float(first_facts.get("first_directional_body") or 0.0), 0.0)
    first_body_share = float(first_facts.get("first_body_share") or 0.0)
    first_excursion = max(0.0, first_body - float(tolerance or 0.0))
    decisive_first = bool(
        first_body >= typical * 0.55 and
        first_body_share >= 0.50 and
        first_excursion >= typical * 0.35 and
        first_range >= typical * 1.20
    )
    held_follow = bool(
        int(hold_count or 0) >= 2 and
        float(burst_facts.get("close_follow_ratio") or 0.0) >= 0.50 and
        float(burst_facts.get("directional_body_share") or 0.0) >= 0.65 and
        float(burst_facts.get("path_efficiency") or 0.0) >= 0.45 and
        float(burst_facts.get("body_share") or 0.0) >= 0.28 and
        float(burst_facts.get("burst_range") or 0.0) >= typical * 1.15
    )
    if decisive_first:
        return True, "decisive_first_break_candle"
    if held_follow:
        return True, "break_and_two_bar_follow_through"
    return False, "ordinary_close_break_or_wick"


def channel_facts(bars, upward):
    """Find a provisional low-liquidity trend channel from closed OHLC only.

    A channel here is an observed geometry, not a claim about order-book
    liquidity.  The fit uses the complete preceding path available at the
    current cutoff; it never reaches into the later response bars.
    """
    if len(bars) < 6:
        return dict(method='native_ohlc_channel_v1', qualified=False,
                    status='insufficient_native_bars', bar_count=len(bars))
    closes = [float(b['close']) for b in bars]
    ranges = [max(0.0, float(b['high']) - float(b['low'])) for b in bars]
    typical = statistics.median(v for v in ranges if v > 0) if any(ranges) else 0.0
    n = len(closes)
    mean_x = (n - 1) / 2.0
    mean_y = sum(closes) / n
    denom = sum((i - mean_x) ** 2 for i in range(n))
    slope = sum((i - mean_x) * (v - mean_y) for i, v in enumerate(closes)) / max(1e-12, denom)
    intercept = mean_y - slope * mean_x
    fitted = [intercept + slope * i for i in range(n)]
    residuals = [v - fitted[i] for i, v in enumerate(closes)]
    upper_residuals = [float(b['high']) - fitted[i] for i, b in enumerate(bars)]
    lower_residuals = [float(b['low']) - fitted[i] for i, b in enumerate(bars)]
    # Use a robust envelope so one news wick cannot stretch the channel over
    # the later reversal. Small native paths keep their exact extrema;
    # longer windows use the 85/15 residual quantiles.
    if n >= 10:
        upper = statistics.quantiles(upper_residuals, n=20,
                                     method='inclusive')[16]
        lower = statistics.quantiles(lower_residuals, n=20,
                                     method='inclusive')[2]
    else:
        upper = max(upper_residuals)
        lower = min(lower_residuals)
    width = max(0.0, upper - lower)
    sse = sum((v - fitted[i]) ** 2 for i, v in enumerate(closes))
    sst = sum((v - mean_y) ** 2 for v in closes)
    r_squared = 1.0 - sse / sst if sst else 0.0
    sign = 1.0 if upward else -1.0
    directional_slope = sign * slope
    width_per_bar = width / max(1, n - 1)
    normalized_slope = directional_slope / max(1e-12, typical)
    tolerance = max(typical * 0.75, width * 0.18)
    upper_touches = sum(v >= upper - tolerance for v in upper_residuals)
    lower_touches = sum(v <= lower + tolerance for v in lower_residuals)
    path = path_facts(bars, upward)
    outer_line = _outer_turning_trendline(bars, upward)
    # These are price-shape clues only.  They are intentionally kept out of
    # the generic channel geometry test so historical channel unit tests and
    # the review ledger remain backwards compatible.
    low_liquidity_shape = bool(
        path.get('mean_range_overlap', 0.0) >= 0.12 and
        path.get('body_share', 1.0) <= 0.65 and
        path.get('path_efficiency', 1.0) <= 0.92
    )
    # The source examples are orderly drift with overlap, then a separate
    # opposite response.  Require direction and two-sided channel contact,
    # while keeping the threshold deliberately provisional.
    qualified = bool(
        directional_slope > 0 and normalized_slope >= 0.015 and
        r_squared >= 0.12 and width > 0 and
        upper_touches >= 2 and lower_touches >= 2 and
        path['close_follow_ratio'] >= 0.42 and path['directional_body_share'] >= 0.45
    )
    return dict(method='native_ohlc_channel_v1', envelope_method='residual_quantile_85_15',
        upward=bool(upward), qualified=qualified,
        status='observed_low_liquidity_channel_candidate' if qualified else 'channel_not_admitted',
        bar_count=n, slope=slope, directional_slope=directional_slope,
        normalized_slope=normalized_slope, intercept=intercept,
        upper_offset=upper, lower_offset=lower, width=width,
        width_per_bar=width_per_bar, r_squared=r_squared,
        typical_range=typical,
        upper_touches=upper_touches, lower_touches=lower_touches,
        upper_start_price=intercept + upper,
        upper_end_price=intercept + slope * (n - 1) + upper,
        lower_start_price=intercept + lower,
        lower_end_price=intercept + slope * (n - 1) + lower,
        close_follow_ratio=path['close_follow_ratio'],
        directional_body_share=path['directional_body_share'],
        mean_range_overlap=path['mean_range_overlap'], body_share=path['body_share'],
        path_efficiency=path['path_efficiency'], low_liquidity_shape=low_liquidity_shape,
        outer_trendline=outer_line,
        pdf_trendline_rule_id=(outer_line or {}).get('rule_id', 'trend_trade_method_pdf_ch3_ch4_outer_wave_v1'),
        pdf_trendline_source_pages=[48, 49, 58, 59, 80, 81, 82, 83, 84],
        pdf_parallel_projection=(outer_line or {}).get('parallel_projection'),
        origin_utc=bars[0].get('timestamp_utc'),
        terminal_utc=bars[-1].get('timestamp_utc'),
        thresholds=dict(min_bars=32, min_normalized_slope=0.015,
                        min_r_squared=0.12, min_upper_touches=2,
                        min_lower_touches=2, min_close_follow_ratio=0.42,
                        min_directional_body_share=0.45))


def channel_break_facts(channel, bars, upward):
    """Measure the first closed-bar break of a preceding channel.

    This is deliberately a price-only observation.  It identifies the first
    close that leaves the extrapolated opposite channel boundary and counts
    the immediately held closes.  It does not infer order-book liquidity or
    grant trade permission.
    """
    if not channel or not channel.get('qualified') or not bars:
        return dict(status='channel_break_unavailable', observed=False,
                    breakout_index=None, hold_count=0)
    preceding_up = bool(channel.get('upward'))
    if preceding_up == bool(upward):
        return dict(status='same_direction_as_channel', observed=False,
                    breakout_index=None, hold_count=0)
    n = max(1, int(channel.get('bar_count') or 1))
    slope = float(channel.get('slope') or 0.0)
    end_fit = float(channel.get('intercept') or 0.0) + slope * (n - 1)
    upper_end = float(channel.get('upper_end_price') or end_fit)
    lower_end = float(channel.get('lower_end_price') or end_fit)
    width = abs(float(channel.get('width') or 0.0))
    # The response itself may contain the news candle that is being measured;
    # using its range for the crossing tolerance made the result future-sized.
    tolerance = max(width * 0.03,
                    float(channel.get('typical_range') or 0.0) * 0.08,
                    1e-12)
    break_index = None
    break_close = None
    boundary = None
    for i, bar in enumerate(bars):
        # The first response bar follows the channel terminal.  If a path
        # includes the shared terminal candle, the i==0 boundary is still the
        # correct no-future extrapolation point.
        upper = upper_end + slope * i
        lower = lower_end + slope * i
        close = float(bar['close'])
        crossed = close > upper + tolerance if upward else close < lower - tolerance
        if crossed:
            break_index, break_close, boundary = i, close, upper if upward else lower
            break
    if break_index is None:
        return dict(status='no_closed_close_through_channel', observed=False,
                    breakout_index=None, hold_count=0,
                    tolerance=tolerance, boundary_side='upper' if upward else 'lower')
    hold = 0
    for j in range(break_index, len(bars)):
        upper = upper_end + slope * j
        lower = lower_end + slope * j
        close = float(bars[j]['close'])
        held = close > upper + tolerance if upward else close < lower - tolerance
        if not held:
            break
        hold += 1
    return dict(status='channel_break_observed', observed=True,
                breakout_index=break_index,
                breakout_utc=bars[break_index].get('timestamp_utc'),
                breakout_close=break_close, breakout_boundary=boundary,
                hold_count=hold, hold_confirmed=hold >= 1,
                tolerance=tolerance,
                boundary_side='upper' if upward else 'lower')


def trendline_break_facts(channel, bars, upward):
    """Measure a break of the one outer trendline shown on the chart.

    A downward low-liquidity wave is represented by its descending upper
    trendline (the sequence of highs); an upward wave is represented by its
    ascending lower trendline (the sequence of lows).  This is intentionally
    separate from :func:`channel_break_facts`, which retains the historical
    two-boundary channel observation for review compatibility.
    """
    if not channel or not channel.get('qualified') or not bars:
        return dict(status='trendline_break_unavailable', observed=False,
                    breakout_index=None, hold_count=0)
    preceding_up = bool(channel.get('upward'))
    if preceding_up == bool(upward):
        return dict(status='same_direction_as_trendline', observed=False,
                    breakout_index=None, hold_count=0)
    outer = channel.get('outer_trendline') or {}
    if not outer:
        return dict(status='outer_trendline_unavailable', observed=False,
                    breakout_index=None, hold_count=0)
    n = max(1, int(channel.get('bar_count') or 1))
    anchor_slope = float(outer.get('slope') or 0.0)
    anchor_end_index = int(outer.get('end_index') or 0)
    # Project the outer line from its second pivot to the terminal candle,
    # then continue that same line through the response bars.
    boundary_end = float(outer.get('end_price') or 0.0) + anchor_slope * (n - 1 - anchor_end_index)
    slope = anchor_slope
    side = 'lower' if preceding_up else 'upper'
    width = abs(float(channel.get('width') or 0.0))
    # Keep the crossing threshold anchored to the preceding wave.  Response
    # ranges are evidence, never a look-ahead input to the line geometry.
    tolerance = max(width * 0.03,
                    float(channel.get('typical_range') or 0.0) * 0.08,
                    1e-12)
    break_index = None
    break_close = None
    boundary = None
    for i, bar in enumerate(bars):
        level = boundary_end + slope * i
        close = float(bar['close'])
        crossed = close < level - tolerance if preceding_up else close > level + tolerance
        if crossed:
            break_index, break_close, boundary = i, close, level
            break
    if break_index is None:
        return dict(status='no_closed_close_through_trendline', observed=False,
                    breakout_index=None, hold_count=0, tolerance=tolerance,
                    boundary_side=side)
    hold = 0
    for j in range(break_index, len(bars)):
        level = boundary_end + slope * j
        close = float(bars[j]['close'])
        held = close < level - tolerance if preceding_up else close > level + tolerance
        if not held:
            break
        hold += 1
    # A close through the line is only a geometric event.  Call it a
    # displayed ``力度`` only when the first one to three response candles
    # carry directional bodies/closures, or when one candle is an obvious
    # range expansion.  This prevents an ordinary wick/one-bar bounce from
    # being promoted to force.
    burst = bars[break_index:min(len(bars), break_index + 3)]
    burst_facts = _burst_facts(burst, upward) if burst else None
    first_burst = _burst_facts(burst[:1], upward) if burst else None
    baseline_range = float(channel.get('typical_range') or 0.0)
    burst_force, force_reason = _trendline_force_decision(
        burst_facts, first_burst, baseline_range, hold, tolerance)
    return dict(status='trendline_break_observed', observed=True,
                breakout_index=break_index,
                breakout_utc=bars[break_index].get('timestamp_utc'),
                breakout_close=break_close, breakout_boundary=boundary,
                hold_count=hold, hold_confirmed=hold >= 1,
                break_force_observed=burst_force, break_force_facts=burst_facts,
                first_break_candle_facts=first_burst,
                break_force_reason=force_reason,
                tolerance=tolerance, boundary_side=side)


def first_response_record(candidate, context, departure, path, prior_path,
                          prior_momentum=None, channel_path=None):
    prior = context.get('retraced_wave')
    if not prior or not departure.get('sustained_source_close'):
        return None
    up = candidate['direction']=='up'
    if ((prior['terminal']['price']>prior['origin']['price']) == up or
        prior['native_timeframe'] != candidate['timeframe'] or
        prior['terminal']['pivot_timestamp_utc'] != candidate['origin_utc'] or
        prior['terminal']['price'] != candidate['origin_price']):
        return None
    current, previous = path_facts(path['bars'], up), path_facts(prior_path['bars'], not up)
    held = [n for n in context['nodes'] if n['sustained_source_close']]
    evidence_ids = list(dict.fromkeys([candidate['force_leg_id'], prior['source_leg_id'],
        *prior['component_source_leg_ids'], *(n['node_id'] for n in context['nodes'])]))
    prior_quality = ('possible_low_liquidity_or_wick_drift' if
                     prior_momentum is not None and not prior_momentum.get('qualified')
                     else 'directional_delivery_observed' if prior_momentum is not None
                     else 'unknown')
    # This is the specific case that was disappearing from the chart: a
    # first opposite response after a preceding wave that only looked like
    # trend because of slow/wick-led delivery.  OHLC cannot prove actual
    # order-book liquidity, so the pattern is named as an observation and
    # remains pending regardless of the current segment's provisional screen.
    channel_source = channel_path or prior_path
    preceding_channel = channel_facts(channel_source['bars'], not up)
    if channel_path is not None:
        preceding_channel['window_role'] = 'expanded_same_timeframe_preceding_channel'
    preceding_channel.setdefault('window_bars', preceding_channel.get('bar_count', 0))
    low_liquidity_reverse = bool(
        preceding_channel.get('qualified') and
        preceding_channel.get('bar_count', 0) >= MIN_LOW_LIQUIDITY_WAVE_BARS and
        preceding_channel.get('low_liquidity_shape') and
        preceding_channel.get('outer_trendline') and
        prior_momentum is not None and not prior_momentum.get('qualified')
    )
    break_facts = channel_break_facts(preceding_channel, path['bars'], up)
    trendline_facts = trendline_break_facts(preceding_channel, path['bars'], up)
    label = ('低流动性波段趋势线突破 · 首段反向力度'
             if low_liquidity_reverse and trendline_facts.get('observed') and
                trendline_facts.get('break_force_observed')
             else '首段反向响应 · 低流动性前段 · 力度待核'
             if low_liquidity_reverse else '首段反向响应 · 力度待核')
    return dict(candidate, role='first_opposite_structure_break_observation',
        label=label, observation_pattern=('counter_low_liquidity_trend_reverse'
             if low_liquidity_reverse else 'first_opposite_response'),
        owner_id=prior['source_leg_id'],
        preceding_whole_wave_id=prior['source_leg_id'], evidence_ids=evidence_ids,
        scope_id=candidate['force_leg_id'], rule_id='first_opposite_response_evidence_v1',
        status='first_opposite_response_observed',
        node_break_status='held_close_through' if held else 'not_held_through_reference',
        broken_reference_nodes=held, reference_nodes=context['nodes'],
        force_quality_status='provisional_screen_pass' if candidate['momentum_profile']['qualified'] else 'not_qualified_by_provisional_screen',
        current_path_facts=current, preceding_path_facts=previous,
        preceding_channel_facts=preceding_channel,
        channel_break_facts=break_facts,
        trendline_break_facts=trendline_facts,
        reverse_force_facts={
            'directional_body_share': current.get('directional_body_share'),
            'close_follow_ratio': current.get('close_follow_ratio'),
            'speed_ratio_vs_preceding': (
                current.get('close_points_per_interval', 0.0) /
                max(1e-12, previous.get('close_points_per_interval', 0.0))
                if previous.get('close_points_per_interval', 0.0) else None),
            'current_path_is_directional': bool(
                current.get('directional_body_share', 0.0) >= 0.55 and
                current.get('close_follow_ratio', 0.0) >= 0.45),
        },
        preceding_delivery_quality=prior_quality,
        preceding_momentum_profile=prior_momentum,
        liquidity_status='unknown_no_orderbook_evidence',
        low_liquidity_trend_observed=low_liquidity_reverse,
        low_liquidity_trend_adjudicated=False, return_completion_adjudicated=False,
        unknown_reason='OHLC contrast alone does not establish low liquidity, channel reversal, return completion or entry.',
        theory_source_message_ids=['7602322931794615203','7602323140890502153','7676550586231557407'],
        production_admission_changed=False, trade_permission=False)
