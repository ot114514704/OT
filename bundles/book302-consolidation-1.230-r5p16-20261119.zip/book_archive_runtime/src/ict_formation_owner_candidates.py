"""Research-only candidates between an ICT formation and native structure tasks.

The module compares explicit identity and clocks. Time overlap is a candidate
relation, never ownership. It never chooses the nearest task, direction, score,
or first row and never changes a scene.
"""
from datetime import datetime, timezone

VERSION = 'ict_formation_owner_candidates_v2'
PERIODS = {'M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D1', 'W1'}


def _time(value):
    try:
        dt = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return dt.astimezone(timezone.utc) if dt.tzinfo else None
    except (TypeError, ValueError):
        return None


def _identity(value):
    return isinstance(value, str) and value.strip().lower() not in {'', 'unknown', 'pending', 'none', 'null', 'unbound'}


def _task_points(task):
    source = task.get('source') or {}
    points = []
    for role in ('A', 'B', 'C'):
        point = source.get(role)
        if not isinstance(point, dict):
            continue
        stamp = _time(point.get('pivot_timestamp_utc') or point.get('timestamp_utc'))
        if stamp:
            points.append((role, stamp, point.get('price')))
    return points


def _task_points_json(task):
    """Return the comparison points in the scene-safe wire representation.

    `_task_points` deliberately keeps timezone-aware datetimes for interval
    comparisons.  Candidate rows are persisted inside the integrated scene,
    so their public copy must use the same canonical UTC string format as the
    rest of the scene payload.
    """
    return [
        (role, stamp.isoformat().replace('+00:00', 'Z'), price)
        for role, stamp, price in _task_points(task)
    ]


def build_formation_owner_candidates(event, tasks, scene_cutoff, provider, instrument):
    """Return every explicit candidate and rejection reason for one formation."""
    cutoff = _time(scene_cutoff)
    provenance = event.get('formation_provenance') or {}
    candles = provenance.get('candles') or []
    known = _time(provenance.get('known_at_utc') or event.get('available_at'))
    first = _time(candles[0].get('open_at_utc')) if candles else None
    last = _time(candles[-1].get('closed_at_utc')) if candles else None
    base = {
        'schema': VERSION, 'rule_version': VERSION,
        'formation_id': provenance.get('formation_id'),
        'formation_native_timeframe': provenance.get('native_timeframe') or event.get('source_timeframe'),
        'formation_provider': provenance.get('provider') or provider,
        'formation_instrument': provenance.get('instrument') or instrument,
        'formation_known_at_utc': (known.isoformat().replace('+00:00', 'Z') if known else None),
        'formation_window': {
            'first_candle_open_utc': first.isoformat().replace('+00:00', 'Z') if first else None,
            'last_candle_closed_utc': last.isoformat().replace('+00:00', 'Z') if last else None,
        },
        'owner_id': None, 'selected': False, 'automatic_trade_permission': False,
    }
    if not cutoff or not first or not last or last < first:
        return [dict(base, candidate_status='rejected', blockers=['formation_window_clock_missing_or_invalid'])]
    if not known:
        return [dict(base, candidate_status='rejected', blockers=['formation_known_at_missing_or_invalid'])]
    if known and known > cutoff:
        return [dict(base, candidate_status='rejected', blockers=['formation_known_after_scene_cutoff'])]
    if last > known:
        return [dict(base, candidate_status='rejected', blockers=['formation_known_before_last_candle_close'])]
    if not _identity(base['formation_id']):
        return [dict(base, candidate_status='rejected', blockers=['formation_id_missing'])]
    if base['formation_native_timeframe'] not in PERIODS:
        return [dict(base, candidate_status='rejected', blockers=['formation_native_timeframe_unknown'])]
    rows = []
    for task in tasks or []:
        row = dict(base, task_id=task.get('task_id'), task_owner_id=task.get('owner_id'),
                   task_timeframe=task.get('timeframe'), task_provider=task.get('provider', provider),
                   task_instrument=task.get('instrument', instrument), task_source_points=_task_points_json(task),
                   relation='unknown', diagnostics={})
        blockers = []
        points = _task_points(task)
        task_times = [stamp for _, stamp, _ in points]
        task_known = _time(task.get('known_at_utc'))
        task_asof = _time(task.get('as_of_utc'))
        if not _identity(task.get('task_id')):
            blockers.append('task_id_missing')
        if not _identity(task.get('owner_id')):
            blockers.append('task_owner_missing')
        if task.get('timeframe') != base['formation_native_timeframe']:
            blockers.append('native_timeframe_mismatch')
        if task.get('provider', provider) != provider:
            blockers.append('provider_mismatch')
        if task.get('instrument', instrument) != instrument:
            blockers.append('instrument_mismatch')
        if len(points) < 2:
            blockers.append('task_source_points_incomplete')
        if not task_known or task_known > cutoff:
            blockers.append('task_known_at_missing_or_after_cutoff')
        if task_known and any(stamp > task_known for stamp in task_times):
            blockers.append('task_source_point_after_known_at')
        if not task_asof or task_asof != cutoff:
            blockers.append('task_as_of_missing_or_not_scene_cutoff')
        if task_times and max(task_times) < first:
            blockers.append('formation_after_task_source_interval')
        elif task_times and min(task_times) > last:
            blockers.append('formation_before_task_source_interval')
        elif task_times:
            row['relation'] = 'formation_window_overlaps_task_source_interval'
        else:
            row['relation'] = 'unknown'
        direction = event.get('direction')
        task_direction = task.get('direction')
        row['diagnostics']['direction_relation'] = (
            'same' if direction and task_direction and direction == task_direction else
            'different' if direction and task_direction else 'unknown')
        row['diagnostics']['selection_policy'] = 'retain_all_candidates_no_owner_promotion'
        row['candidate_status'] = 'requires_owner_review' if not blockers and row['relation'] != 'unknown' else 'rejected'
        row['blockers'] = sorted(set(blockers))
        rows.append(row)
    if not rows:
        rows.append(dict(base, candidate_status='rejected', relation='unknown',
                         blockers=['no_native_structure_tasks_available']))
    return rows
