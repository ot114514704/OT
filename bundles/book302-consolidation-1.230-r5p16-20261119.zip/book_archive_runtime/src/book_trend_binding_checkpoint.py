"""Replay-verified persistence for Book source-binding observations.

The checkpoint records the caller's observation ledger, never historical live
selection. Restore re-runs the binding against the supplied native scene before
accepting the checkpoint, so a resigned checksum cannot bless altered data.
"""

from copy import deepcopy
from hashlib import sha256
import json
import os
from pathlib import Path
import tempfile
from datetime import datetime, timezone

from .book_trend_wave_binding import BookTrendBindingSession, rule_sources

VERSION = 'book_trend_binding_checkpoint_v1'


def digest(value):
    return sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                             allow_nan=False, separators=(',', ':')).encode('utf-8')).hexdigest()


def checkpoint_body(session, *, shared_consumer_source_sha256=None, scene_metadata=None):
    state=session.checkpoint_state()
    return dict(schema=VERSION, rule_version='book_trend_wave_binding_v1',
        rule_sources=rule_sources(),
        shared_consumer_source_sha256=shared_consumer_source_sha256,
        scene_metadata=deepcopy(scene_metadata) if scene_metadata is not None else None,
        session=state, session_binding_count=len(state['bindings']),
        read_only=True, automatic_trade_permission=False,
        future_bars_used=False)


def checkpoint(session, *, shared_consumer_source_sha256=None, scene_metadata=None):
    body=checkpoint_body(session, shared_consumer_source_sha256=shared_consumer_source_sha256,
                         scene_metadata=scene_metadata)
    return dict(body, checksum=digest(body))


def save_checkpoint(session, path, *, shared_consumer_source_sha256=None, scene_metadata=None):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    data=(json.dumps(checkpoint(session,shared_consumer_source_sha256=shared_consumer_source_sha256,
                                scene_metadata=scene_metadata),
                     ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,prefix=path.name+'.',suffix='.tmp',delete=False) as handle:
            temporary=Path(handle.name);handle.write(data);handle.flush();os.fsync(handle.fileno())
        os.replace(temporary,path)
    finally:
        if temporary is not None:temporary.unlink(missing_ok=True)
    return sha256(data).hexdigest()


def restore_checkpoint(path, scene, *, observed_at_utc, shared_consumer_source_sha256=None):
    payload=json.loads(Path(path).read_text(encoding='utf-8'))
    body={key:value for key,value in payload.items() if key!='checksum'}
    if payload.get('schema')!=VERSION or digest(body)!=payload.get('checksum'):
        raise ValueError('Book_binding_checkpoint_checksum_or_schema_invalid')
    if body.get('rule_sources')!=rule_sources():
        raise ValueError('Book_binding_checkpoint_rules_changed_replay_required')
    if body.get('shared_consumer_source_sha256') != shared_consumer_source_sha256:
        raise ValueError('Book_binding_checkpoint_shared_consumer_changed_replay_required')
    metadata=body.get('scene_metadata')
    if metadata is not None:
        expected={'provider':scene.get('provider'),'instrument':scene.get('instrument'),
                  'timeframe':scene.get('timeframe'),'cutoff_utc':scene.get('cutoff_utc')}
        if metadata != expected:
            raise ValueError('Book_binding_checkpoint_scene_identity_mismatch')
    stored=body.get('session') or {}
    if body.get('session_binding_count') != len(stored.get('bindings') or {}):
        raise ValueError('Book_binding_checkpoint_binding_count_mismatch')
    session=BookTrendBindingSession()
    session._bindings=deepcopy(stored.get('bindings') or {})
    session._history=deepcopy(stored.get('history'))
    session._last_observed_at=stored.get('last_observed_at')
    before=session.checkpoint_state()
    result=session.observe(scene,observed_at_utc=observed_at_utc)
    if result.get('state')!='observed':
        raise ValueError('Book_binding_checkpoint_native_replay_failed:'+str(result.get('reason')))
    history=before.get('history') or {}
    if (history.get('cutoff')==scene.get('cutoff_utc') and
            history.get('selected_binding_version_id')!=result['current_evaluation']['binding_version_id']):
        raise ValueError('Book_binding_checkpoint_last_selection_mismatch')
    revision=history.get('boundary_revision_observation')
    if revision is not None:
        from .book_boundary_dynamics import _revision_observation
        from .book_trend_wave_binding import Book_native_rows
        prior=before['bindings'].get(revision.get('previous_binding_version_id'))
        selected=before['bindings'].get(history.get('selected_binding_version_id'))
        if not prior or not selected:
            raise ValueError('Book_binding_checkpoint_revision_source_unavailable')
        native=Book_native_rows((scene.get('execution_context') or {}).get('bars') or [],scene['timeframe'],history['cutoff'])
        expected=_revision_observation(native,scene['timeframe'],history['cutoff'],
            prior['selected_source'],selected['selected_source'],revision['previous_as_of_utc'],
            observed_at_utc=revision['observed_at_utc'],previous_observed_at_utc=revision.get('previous_observed_at_utc'))
        if expected!=revision:
            raise ValueError('Book_binding_checkpoint_revision_native_replay_failed')
    # The old ledger is immutable; a later scene may append a new observation,
    # but it cannot rewrite any previous binding receipt.
    if not before.get('bindings'):
        raise ValueError('Book_binding_checkpoint_has_no_prior_receipt')
    for key,value in before.get('bindings',{}).items():
        if session.snapshot().get(key)!=value:
            raise ValueError('Book_binding_checkpoint_prior_receipt_changed')
    return session,result


def checkpoint_path_for_scene(scene, directory):
    """Use one immutable receipt per market, native period and scene as-of."""
    provider=str(scene.get('provider','unknown')).replace(':','_').replace('/','_')
    symbol=str(scene.get('instrument','unknown')).replace(':','_').replace('/','_')
    timeframe=str(scene.get('timeframe','unknown'))
    cutoff=str(scene.get('cutoff_utc','unknown')).replace(':','').replace('+','p').replace('Z','z')
    return Path(directory) / f'book-binding-checkpoint-{provider}-{symbol}-{timeframe}-{cutoff}.json'


def persist_published_binding(scene, directory, *, observed_at_utc=None, shared_consumer_source_sha256=None):
    """Persist a binding only at the shared publisher's actual observation clock."""
    if not scene.get('book_trend_binding'):
        return None
    observed_at_utc=observed_at_utc or datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
    path=checkpoint_path_for_scene(scene,directory)
    if path.exists():
        session,result=restore_checkpoint(path,scene,observed_at_utc=observed_at_utc,
            shared_consumer_source_sha256=shared_consumer_source_sha256)
    else:
        session=BookTrendBindingSession();result=session.observe(scene,observed_at_utc=observed_at_utc)
        if result.get('state')!='observed':
            raise ValueError('Book_binding_publish_observation_failed:'+str(result.get('reason')))
    save_checkpoint(session,path,shared_consumer_source_sha256=shared_consumer_source_sha256,
                    scene_metadata={'provider':scene.get('provider'),'instrument':scene.get('instrument'),
                                    'timeframe':scene.get('timeframe'),'cutoff_utc':scene.get('cutoff_utc')})
    return dict(path=str(path),observed_at_utc=observed_at_utc,state=result.get('state'),
                first_observed_at_utc=(result.get('first_binding') or {}).get('first_observed_at_utc'),
                read_only=True,automatic_trade_permission=False,future_bars_used=False)


def checkpoint_inventory(directory):
    """Read checkpoint metadata; invalid files remain visible and protected."""
    directory=Path(directory);items=[]
    for path in sorted(directory.glob('book-binding-checkpoint-*.json')):
        item={'path':str(path),'name':path.name,'valid':False,'reason':None}
        try:
            payload=json.loads(path.read_text(encoding='utf-8'))
            body={key:value for key,value in payload.items() if key!='checksum'}
            if payload.get('schema')!=VERSION or digest(body)!=payload.get('checksum'):
                raise ValueError('checksum_or_schema_invalid')
            metadata=body.get('scene_metadata') or {}
            item.update(valid=True,provider=metadata.get('provider'),instrument=metadata.get('instrument'),
                        timeframe=metadata.get('timeframe'),cutoff_utc=metadata.get('cutoff_utc'),
                        observed_at_utc=(body.get('session') or {}).get('last_observed_at'),
                        checksum=payload.get('checksum'),size=path.stat().st_size)
        except (OSError,TypeError,ValueError,json.JSONDecodeError) as error:
            item['reason']=str(error)
        items.append(item)
    return items


def plan_checkpoint_cleanup(directory, *, keep_latest_per_group=8, referenced_paths=()):
    """Return a dry-run plan. No file is deleted by this function."""
    if isinstance(keep_latest_per_group,bool) or not isinstance(keep_latest_per_group,int) or keep_latest_per_group<1:
        raise ValueError('checkpoint_retention_count_invalid')
    referenced={str(Path(p)) for p in referenced_paths}
    inventory=checkpoint_inventory(directory);groups={};protected=[];invalid=[]
    for item in inventory:
        if not item['valid']:
            invalid.append(item);continue
        if item['path'] in referenced:
            protected.append(item);continue
        key=(item.get('provider'),item.get('instrument'),item.get('timeframe'))
        groups.setdefault(key,[]).append(item)
    candidates=[];kept=[]
    for key,items in groups.items():
        ordered=sorted(items,key=lambda x:(x.get('cutoff_utc') or '',x.get('observed_at_utc') or '',x['name']),reverse=True)
        kept.extend(ordered[:keep_latest_per_group]);candidates.extend(ordered[keep_latest_per_group:])
    return dict(schema='book_trend_binding_cleanup_plan_v1',directory=str(Path(directory)),
                keep_latest_per_group=keep_latest_per_group,groups={str(k):len(v) for k,v in groups.items()},
                kept=kept,protected=protected,candidates=candidates,invalid=invalid,
                destructive_action_required=True,automatic_trade_permission=False,read_only=True,
                future_bars_used=False)


def apply_checkpoint_cleanup(plan, *, confirm=False):
    """Apply only a previously generated plan after explicit confirmation."""
    if confirm is not True:
        raise ValueError('checkpoint_cleanup_confirmation_required')
    allowed={item.get('path') for item in plan.get('candidates',[])};removed=[]
    for raw_path in sorted(allowed):
        path=Path(raw_path)
        if path.exists():
            path.unlink();removed.append(str(path))
    return dict(schema='book_trend_binding_cleanup_result_v1',removed=removed,
                automatic_trade_permission=False,read_only=True,future_bars_used=False)
