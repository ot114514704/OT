"""Bind the selected Book source without replacing it with a raw pivot scope.

Book may admit a native origin that is not a radius-two pivot. Reconstruct that
explicit origin in its own observation lane. Never insert it retrospectively
into the pure-pivot discovery history, or substitute a different fitted ruler.
"""

from copy import deepcopy
from hashlib import sha256
from math import isclose, isfinite
from pathlib import Path

from .book_first_response_leg import close_time
from .book_boundary_freeze import ruler_identity
from .book_boundary_dynamics import _revision_observation
from .book_breakout_assessment import digest as book_digest, native_turning_source_proof
from .book_native_wave_process import recognize_wave_process, score_book_wave_process
from .trend_trade_method_full_pipeline import detect_first_closed_break, detect_parallel_break
from .trend_wave_state_adjudication import _closed, _time, fit_native_wave_scope, adjudicate_trend_wave_state
from .trend_wave_discovery import digest, iso, compact_fit, source_version, scope_receipt

VERSION = 'book_trend_wave_binding_v1'
SOURCE_FILES = ('book_trend_wave_binding.py', 'book_boundary_freeze.py',
    'book_breakout_assessment.py', 'book_native_wave_process.py', 'book_owned_scope.py',
    'book_first_response_leg.py', 'live_xauusd_multitimeframe.py', 'force_strength_model.py',
    'pdf_trendline_block.py', 'trend_trade_method_full_pipeline.py',
    'trend_wave_state_adjudication.py', 'trend_wave_discovery.py',
    'trend_boundary_damage.py', 'book_boundary_dynamics.py', 'book_trend_structure_judgement.py',
    'book_trend_binding_checkpoint.py')


def rule_sources():
    parent = Path(__file__).resolve().parent
    return {name: sha256((parent / name).read_bytes()).hexdigest() for name in SOURCE_FILES}


IMPORTED_SOURCES = rule_sources()


def _event_identity(event):
    return {key: event.get(key) for key in
            ('status', 'break_index', 'break_utc', 'break_price', 'break_level', 'break_side')}


def Book_native_rows(bars, timeframe, cutoff):
    # Archive/Book calculation uses floating OHLC. A JS/JSON round trip may
    # serialize 4768.0 as 4768; hashing the unnormalized value then changes a
    # range ID despite equal native prices. Reconstruct the producer's float
    # representation before deriving IDs; never ignore a mismatched ID.
    rows = _closed(bars, timeframe, cutoff)
    return [dict(row, **{key: float(row[key]) for key in ('open', 'high', 'low', 'close')}) for row in rows]


def resolve_book_trend_binding(scene):
    """Reconstruct the selected source, measured range and original boundaries.

    Numeric scores are never an owner selector. Source/data calculability and
    observation of a supplied Book scene remain separate clocks.
    """
    cutoff, tf = scene.get('cutoff_utc'), scene.get('timeframe')
    base = dict(schema=VERSION, state='unknown', as_of_utc=cutoff, native_timeframe=tf,
                read_only=True, entry_permission=False, automatic_trade_permission=False,
                future_bars_used=False, author_wave_degree='unknown')
    try:
        if rule_sources() != IMPORTED_SOURCES:
            raise ValueError('binding_rules_changed_restart_required')
        rows = Book_native_rows((scene.get('execution_context') or {}).get('bars') or [], tf, cutoff)
        market = {key: rows[0][key] for key in ('provider', 'symbol')}
        if scene.get('provider') != market['provider'] or scene.get('instrument') != market['symbol']:
            raise ValueError('Book_scene_market_identity_mismatch')
        book = scene['book_logic'];decision = book['realtime_entry_decision'];card = decision['position_scorecard']
        for packet in (book, decision, card):
            if packet.get('timeframe') != tf or packet.get('as_of_utc') != cutoff:
                raise ValueError('Book_source_clock_or_period_mismatch')
        if card.get('reason'):
            raise ValueError('Book_selected_card_source_unavailable')
        line = book['turning_point_line'];i, j = line['start_index'], line['end_index']
        if (not line.get('qualified') or line.get('direction') not in ('up', 'down') or
                any(type(k) is not int for k in (i, j)) or not 0 <= i < j < len(rows)):
            raise ValueError('Book_native_ruler_identity_invalid')
        side = 'low' if line['direction'] == 'up' else 'high'
        for key, index in (('start_price', i), ('end_price', j)):
            value = line[key]
            if isinstance(value, bool) or not isfinite(value) or value != rows[index][side]:
                raise ValueError('Book_ruler_anchor_not_native')
        slope = (line['end_price'] - line['start_price']) / (j - i)
        if (isinstance(line['slope'], bool) or not isfinite(line['slope']) or
                not isclose(slope, line['slope'], rel_tol=1e-12, abs_tol=1e-9) or
                slope * (1 if side == 'low' else -1) <= 0):
            raise ValueError('Book_ruler_coefficients_invalid')
        if not _time(close_time(rows[j], tf)) <= _time(line['known_at_utc']) <= _time(cutoff):
            raise ValueError('Book_ruler_clock_invalid')
        line = dict(line, start_price=float(line['start_price']), end_price=float(line['end_price']),
                    slope=float(line['slope']))
        sign = 1 if side == 'low' else -1
        if any((rows[k][side] - line['start_price'] - slope * (k - i)) * sign <= 1e-9
               for k in range(i + 1, j)):
            raise ValueError('Book_ruler_cuts_or_contacts_native_interior')
        identity = dict(ruler=ruler_identity(rows, line, tf), **market)
        phase = 'book_break_phase:' + book_digest(identity)
        cached = card['native_wave_process']
        if cached.get('schema') != 'book_native_scope_score_v1' or cached.get('as_of_utc') != cutoff:
            raise ValueError('Book_native_measurement_schema_or_asof_mismatch')
        for value in (cached.get('known_at_utc'), card.get('position_close_utc')):
            if not value or _time(value) > _time(cutoff):
                raise ValueError('Book_cached_dependency_clock_invalid')
        if (card.get('source_identity') != identity or cached.get('source_identity') != identity or
                any(p.get('phase_id') != phase for p in (decision, card, cached)) or
                card.get('direction') != ('down' if line['direction'] == 'up' else 'up')):
            raise ValueError('Book_selected_phase_identity_mismatch')
        turning = book.get('turning_boundary') or {}
        if turning.get('qualified'):
            proof = native_turning_source_proof(rows, line, turning)
            if not proof['qualified']:
                raise ValueError('Book_CDE_source_unreproduced:' + str(proof.get('reason')))
            if not _time(close_time(rows[turning['first_observable_index']], tf)) <= _time(turning['known_at_utc']) <= _time(cutoff):
                raise ValueError('Book_CDE_clock_invalid')
            turning = dict(turning, **{key: float(turning[key]) for key in
                ('start_price', 'extension_start_price', 'extension_end_price', 'slope')})
        pair_points = ([[rows[turning[k + '_index']]['timestamp_utc'], turning[k + '_price']]
                        for k in ('extension_start', 'extension_end', 'start')]
                       if turning.get('qualified') else None)
        pair_id = 'book_break_pair:' + book_digest([phase, pair_points]) if pair_points else None
        if any(p.get('boundary_pair_id') != pair_id for p in (decision, card)):
            raise ValueError('Book_selected_boundary_pair_mismatch')
        outer_event = detect_first_closed_break(rows, line, tf, cutoff)
        turning_event = detect_parallel_break(rows, line,
            {'projection': turning} if turning.get('qualified') else {}, tf, cutoff)
        if (_event_identity(book.get('first_closed_break') or {}) != _event_identity(outer_event) or
                _event_identity(book.get('parallel_break') or {}) != _event_identity(turning_event)):
            raise ValueError('Book_boundary_events_unreproduced')
        own_book = deepcopy(book)
        own_book.update(turning_point_line=line, first_closed_break=outer_event, parallel_break=turning_event)
        actual = score_book_wave_process(rows, tf, cutoff, own_book,
                                        dict(phase_id=phase, source_identity=identity, reason=None))
        profile = actual.get('source_profile') or {}
        if not actual.get('source_scope_id') or not profile.get('points'):
            raise ValueError('Book_native_measured_source_unavailable')
        cached_profile = cached.get('source_profile') or {}
        fields = ('scope_id', 'range_version', 'points', 'known_at_utc')
        if (cached.get('source_scope_id') != actual['source_scope_id'] or
                any(cached_profile.get(k) != profile.get(k) for k in fields) or
                any(cached.get(k) != actual.get(k) for k in
                    ('formation_through_utc', 'range_frozen_before_first_break', 'source_measurement_known_at_utc'))):
            raise ValueError('Book_measured_range_identity_or_clock_mismatch')
        for value in (actual['known_at_utc'], profile['known_at_utc'], actual['formation_through_utc']):
            if _time(value) > _time(cutoff):
                raise ValueError('Book_measured_source_not_known_at_cutoff')
        from .book_owned_scope import resolve_owned_scope
        owned_scope=resolve_owned_scope(rows,line);origin_index=owned_scope['start_index']
        origin = dict(point=[_time(rows[origin_index]['timestamp_utc']).timestamp(), rows[origin_index][side]],
                      direction=line['direction'], known_at_utc=line['known_at_utc'])
        native = recognize_wave_process(rows, tf, cutoff, bound_origin=origin)
        source = next(s for s in native['active'] + native['retired'] if s['scope_id'] == actual['source_scope_id'])
        raw = recognize_wave_process(rows, tf, cutoff)
        in_raw = any(s['scope_id'] == source['scope_id'] for s in raw['active'] + raw['retired'])
        points = profile['points']
        fit = compact_fit(fit_native_wave_scope(rows, tf, cutoff,
            [iso(points[0][0]), points[0][1]], [iso(points[1][0]), points[1][1]], profile['known_at_utc']))
        fitted = fit.get('outer_line') or {}
        same_ruler = bool(fit.get('qualified') and all(fitted.get(k) == line.get(k)
                          for k in ('start_index', 'end_index', 'start_price', 'end_price', 'slope')))
        # The Book-selected coefficients remain primary even if another
        # valid A-B fit would choose a different anchor. A is not invented.
        state = adjudicate_trend_wave_state(rows, tf, cutoff, line,
            turning if turning.get('qualified') else None, wave_record=source)
        turning_identity = ([[rows[turning[k + '_index']]['timestamp_utc'], turning[k + '_price']]
                             for k in ('extension_start', 'start', 'extension_end')]
                            if turning.get('qualified') else None)
        geometry_known = max((line['known_at_utc'], profile['known_at_utc'],
                              turning.get('known_at_utc') or line['known_at_utc']), key=_time)
        geometry_rows = [r for r in rows if _time(close_time(r, tf)) <= _time(geometry_known)]
        geometry_hash = digest([{key:r[key] for key in
            ('timestamp_utc', 'provider', 'symbol', 'timeframe', 'open', 'high', 'low', 'close')}
            for r in geometry_rows])
        key = [market, tf, phase, profile['range_version'], identity['ruler'],
               line['known_at_utc'], turning_identity, turning.get('known_at_utc'), geometry_hash]
        return dict(base, state='bound', binding_version_id='book_geometry_binding:' + digest(key)[:24],
            market=market, owner_id=source['scope_id'], phase_id=phase, source_identity=identity,
            owned_scope_binding=owned_scope['binding'],
            boundary_pair_id=pair_id,
            Book_ruler_geometry={k:deepcopy(line.get(k)) for k in ('qualified', 'direction', 'start_index',
                'end_index', 'start_price', 'end_price', 'slope', 'known_at_utc', 'wave_id', 'owned_scope')},
            Book_turning_native_points=turning_identity,
            Book_turning_geometry={k:deepcopy(turning.get(k)) for k in ('qualified', 'direction', 'method',
                'start_index', 'start_price', 'slope', 'extension_start_index', 'extension_start_price',
                'extension_end_index', 'extension_end_price', 'first_observable_index', 'known_at_utc',
                'parent_wave_id', 'shift_anchor_index', 'shift_anchor_price', 'source_pdf_sha256', 'rule_id', 'owned_scope_binding')},
            measured_source_range_version=profile['range_version'], measured_source_points=deepcopy(points),
            native_current_version_id=source_version(source, market, tf),
            source_admission=('existing_raw_native_origin' if in_raw else 'explicit_Book_native_origin'),
            native_source_known_at_utc=profile['known_at_utc'], Book_line_known_at_utc=line['known_at_utc'],
            source_geometry_known_at_utc=geometry_known, source_geometry_prefix_sha256=geometry_hash,
            source_data_known_at_utc=max((line['known_at_utc'], actual['known_at_utc'],
                                          turning.get('known_at_utc') or line['known_at_utc']), key=_time),
            formation_through_utc=actual['formation_through_utc'],
            range_frozen_before_first_break=actual['range_frozen_before_first_break'],
            current_native_scope=scope_receipt(source), Book_boundary_state=state,
            native_wave_fit=fit, fitted_outer_matches_Book_ruler=same_ruler,
            native_fit_substitution_allowed=False,
            numeric_identity_policy='Book_float_OHLC_reconstruction_before_version_hashing',
            pure_pivot_registry_modified=False, historical_Book_selection_proven=False,
            source_scope='selected_supplied_Book_scene_reconstructed_from_native_OHLC')
    except (KeyError, TypeError, ValueError, IndexError, StopIteration) as error:
        return dict(base, reason=str(error))


class BookTrendBindingSession:
    """Actual sightings of supplied Book scenes, separate from data clocks."""
    def __init__(self):
        self._bindings = {}
        self._history = None
        self._last_observed_at = None

    def snapshot(self):
        return deepcopy(self._bindings)

    def checkpoint_state(self):
        """Return durable observation state without exposing mutable internals."""
        return dict(bindings=deepcopy(self._bindings), history=deepcopy(self._history),
                    last_observed_at=self._last_observed_at)

    def observe(self, scene, *, observed_at_utc):
        cutoff, tf = scene.get('cutoff_utc'), scene.get('timeframe')
        base = dict(schema='Book_binding_observation_v1', state='unknown', as_of_utc=cutoff,
            observed_at_utc=observed_at_utc, read_only=True, entry_permission=False,
            automatic_trade_permission=False, future_bars_used=False,
            boundary_revision_observation=None)
        try:
            if _time(observed_at_utc) < _time(cutoff) or (self._last_observed_at and _time(observed_at_utc) < _time(self._last_observed_at)):
                raise ValueError('Book_binding_observation_clock_invalid')
            rows = Book_native_rows((scene.get('execution_context') or {}).get('bars') or [], tf, cutoff)
            market = {key: rows[0][key] for key in ('provider', 'symbol')}
            old = self._history
            if old and (old['market'] != market or old['timeframe'] != tf or _time(cutoff) < _time(old['cutoff'])):
                raise ValueError('Book_binding_context_changed_replay_required')
            if old and (len(rows) < old['count'] or digest(rows[:old['count']]) != old['sha256']):
                raise ValueError('Book_binding_history_changed_replay_required')
            if old and len(rows) > old['count'] and _time(close_time(rows[old['count']], tf)) <= _time(old['cutoff']):
                raise ValueError('Book_binding_late_history_append_replay_required')
            if old and old.get('selected_binding_version_id') not in self._bindings:
                raise ValueError('Book_binding_previous_selection_receipt_unavailable')
            actual = resolve_book_trend_binding(scene)
            if actual['state'] != 'bound':
                return dict(base, reason=actual.get('reason'), current_evaluation=actual)
            key = actual['binding_version_id']
            first = self._bindings.get(key)
            revision = None
            prior = self._bindings.get((old or {}).get('selected_binding_version_id'))
            if prior and prior['selected_source']['source_identity'] != actual['source_identity']:
                revision = _revision_observation(rows,tf,cutoff,prior['selected_source'],actual,old['cutoff'],
                    observed_at_utc=observed_at_utc,previous_observed_at_utc=self._last_observed_at)
            elif old and old['cutoff']==cutoff and old.get('selected_binding_version_id')==key:
                # Replay the current sighting, rather than the first time this
                # binding ever existed. A later return to it is a new switch.
                revision=deepcopy(old.get('boundary_revision_observation'))
            if first is None:
                first = dict(binding_version_id=key, owner_id=actual['owner_id'],
                    first_scene_as_of_utc=cutoff, first_observed_at_utc=observed_at_utc,
                    source_data_known_at_utc=actual['source_data_known_at_utc'],
                    source_admission=actual['source_admission'],
                    native_input_sha256=digest(rows), selected_source=deepcopy(actual),
                    clock_basis='caller_reported_observation_of_supplied_scene_not_historical_live_selection',
                    read_only=True, automatic_trade_permission=False, future_bars_used=False)
                if revision is not None:first['boundary_revision_observation']=deepcopy(revision)
            self._bindings.setdefault(key, first)
            self._history = dict(market=market, timeframe=tf, count=len(rows), sha256=digest(rows), cutoff=cutoff,
                                 selected_binding_version_id=key,boundary_revision_observation=deepcopy(revision))
            self._last_observed_at = observed_at_utc
            return dict(base, state='observed', first_binding=deepcopy(first), current_evaluation=actual,
                        boundary_revision_observation=deepcopy(revision))
        except (KeyError, TypeError, ValueError, IndexError) as error:
            return dict(base, reason=str(error))


def attach_book_trend_binding(scene, session, *, observed_at_utc):
    result = deepcopy(scene)
    result['book_trend_binding'] = session.observe(scene, observed_at_utc=observed_at_utc)
    result['book_trend_binding_attachment'] = dict(source=VERSION, score_effect='none',
        direction_effect='none', entry_permission=False, automatic_trade_permission=False)
    return result
