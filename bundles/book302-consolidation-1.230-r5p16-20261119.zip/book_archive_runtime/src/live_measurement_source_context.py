"""Compare a local measuring leg with still-exposed, earlier native rulers.

This is a same-period price/time relation, not semantic parenthood or a first
force classifier. It prevents a new short ruler from becoming the entire read.
"""
from __future__ import annotations

from datetime import datetime
from math import isfinite


def _time(value):
    result = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise ValueError("timezone required")
    return result


def _number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and isfinite(value)


def build_measurement_source_context(snapshot, timeframe, review):
    """Relate the newest native leg to earlier, unbroken/unreached rulers.

    Admission uses independently verified ledger records. A qualifying earlier
    source must have closed beyond its prior geometric extreme before B, and
    its C and reference must still require observation. This qualification is
    a review hypothesis, not proof that the geometric node controls a trend.
    We retain all matches; newest-by-known-time per direction is only a display
    choice. Neither width, touch count nor the latest leg decides task priority.
    """
    result = {
        "status": "unavailable", "timeframe": timeframe,
        "snapshot_id": snapshot.get("snapshot_id"), "as_of_utc": snapshot.get("as_of_utc"),
        "candidates": [], "representatives": [],
        "first_force_leg_adjudicated": False, "parent_task_bound": False,
        "direction_task_confirmed": False, "trade_permission": False,
        "selection_policy": "latest_known_example_per_direction_not_task_priority",
        "source_refs": ["7676543496751127699", "7676550586231557407", "7676888339290328968"],
        "interpretation_status": "mainline_geometric_context_hypothesis_not_source_named_current_task",
        "readout": "来源段和旧量尺还不能在同周期行情中对齐。",
    }
    ledger = review.get("measurement_lifecycle_ledger") or {}
    state = (snapshot.get("timeframe_states") or {}).get(timeframe) or {}
    wave = state.get("candidate_wave_ledger") or {}
    legs = wave.get("legs") or []
    latest = state.get("latest_closed_bar") or {}
    history = ((snapshot.get("chart_history") or {}).get(timeframe) or {}).get("bars") or []
    try:
        cutoff = _time(snapshot["as_of_utc"])
        end = _time(state["latest_closed_bar_end_utc"])
        if (not legs or ledger.get("status") != "native_adjacent_rulers_reviewed" or
                ledger.get("timeframe") != timeframe or ledger.get("snapshot_id") != snapshot.get("snapshot_id") or
                ledger.get("as_of_utc") != snapshot.get("as_of_utc") or wave.get("timeframe") != timeframe or
                wave.get("window_through_utc") != latest.get("timestamp_utc") or
                not _time(latest["timestamp_utc"]) < end <= cutoff):
            return result
        raw = {bar["timestamp_utc"]: bar for bar in history}
        if len(raw) != len(history) or raw.get(latest["timestamp_utc"], {}).get("close") != latest.get("close"):
            return result
        local = legs[-1]
        a, b = local["origin"], local["terminal"]
        if local.get("timeframe") != timeframe or local.get("temporal_order") != "sequential_confirmed_extrema":
            return result
        for pivot in (a, b):
            key = {"confirmed_swing_low_candidate": "low", "confirmed_swing_high_candidate": "high"}.get(pivot.get("kind"))
            bar = raw.get(pivot["pivot_timestamp_utc"], {})
            if (not key or not _number(pivot.get("price")) or bar.get(key) != pivot["price"] or
                    bar.get("timeframe", timeframe) != timeframe or
                    not _time(pivot["pivot_timestamp_utc"]) <= _time(pivot["confirmed_at_utc"]) <= end):
                return result
        if not _time(a["pivot_timestamp_utc"]) < _time(b["pivot_timestamp_utc"]) <= _time(latest["timestamp_utc"]):
            return result
        local_direction = "up" if b["price"] > a["price"] else "down" if b["price"] < a["price"] else "unknown"
        if local_direction == "unknown" or local.get("direction_observation") != local_direction or not _number(latest.get("close")):
            return result
        local_prices = [float(a["price"]), float(b["price"]), float(latest["close"])]
        tail_direction = "up" if latest["close"] > b["price"] else "down" if latest["close"] < b["price"] else "flat"
        matches = []
        for row in ledger.get("records") or []:
            structure = row.get("source_structure_review") or {}
            if (row.get("timeframe") != timeframe or row.get("source_leg_id") == local.get("leg_id") or
                    row.get("lifecycle") not in {"reference_not_reached_geometry_only", "origin_or_anchor_review_required"} or
                    (row.get("continuation_requires_review") and
                     structure.get("phase") not in {"source_departure_latest_returned", "source_departure_latest_reclaimed"}) or
                    (row.get("anchor_review") or {}).get("first_close_through_bar_open_utc") or
                    row.get("phase") in {"retracement_anchor_beyond_source_origin",
                                         "close_beyond_source_origin", "source_origin_crossed_then_reclaimed"} or
                    row.get("reference_reached_after_confirmation") or
                    structure.get("status") != "native_source_leg_prior_extreme_process" or
                    structure.get("source_terminal_bar_close_beyond") is not True or
                    structure.get("first_source_close_beyond_bar_open_utc") is None):
                continue
            # An earlier reference known only after this local leg started may
            # explain today, but cannot be called its already-known corridor.
            if not _time(row["anchors_known_at_utc"]) <= _time(a["pivot_timestamp_utc"]):
                continue
            if row.get("latest_closed_end_utc") != state.get("latest_closed_bar_end_utc") or row.get("latest_closed_price") != latest["close"]:
                continue
            origin, terminal, anchor = row["source_origin"], row["source_terminal"], row["projection_anchor"]
            target = row["projected_level"]
            if not all(_number(value) for value in [origin.get("price"), terminal.get("price"), anchor.get("price"), target]):
                continue
            direction = row.get("direction_observation")
            signed = terminal["price"] - origin["price"]
            if (direction not in {"up", "down"} or (signed > 0) != (direction == "up") or not signed or
                    abs((anchor["price"] + signed) - target) > 1e-6):
                continue
            low, high = sorted([float(anchor["price"]), float(target)])
            if not low <= min(local_prices) <= max(local_prices) <= high:
                continue
            relation = "same_direction_local_progress" if direction == local_direction else "opposing_local_return"
            relation_read = "局部同向推进" if relation == "same_direction_local_progress" else "局部反向回走"
            tail_relation = ("no_net_tail_move" if tail_direction == "flat" else
                             "same_direction_tail_progress" if tail_direction == direction else "opposing_tail_return")
            tail_read = ("还停在该段终点附近" if tail_relation == "no_net_tail_move" else
                         "又朝旧量尺方向走" if tail_relation == "same_direction_tail_progress" else "正在朝旧量尺的反向回走")
            node = structure["reference"]["price"]
            structure_recheck = structure.get("phase") in {
                "source_departure_latest_returned", "source_departure_latest_reclaimed"}
            structure_readout = structure.get("readout", "")
            readout = (f"旧段 {origin['price']:.2f}→{terminal['price']:.2f}，从 {anchor['price']:.2f} 量到 {target:.2f}；"
                       f"来源段末曾收过前一{'高' if direction == 'up' else '低'}点 {node:.2f}。"
                       f"现在小段两端 {a['price']:.2f}→{b['price']:.2f} 和最新收盘仍处于这条路径内，是{relation_read}的几何候选；"
                       f"这段之后最新收盘 {latest['close']:.2f} {tail_read}。"
                       + (f"旧参考虽未到、投射起点虽未收穿，但突破位置 {node:.2f} 的保持已经变化："
                          + structure_readout + "先重审旧测量的延续依据，不能只因价格仍在框内就沿用。"
                          if structure_recheck else
                          "旧参考尚未到、起点尚未收穿，不能只拿最新小段重新定义整段方向。"))
            matches.append({
                "measurement_id": row["measurement_id"], "source_leg_id": row["source_leg_id"],
                "direction_observation": direction, "source_origin": origin, "source_terminal": terminal,
                "projection_anchor": anchor, "projected_level": target, "anchors_known_at_utc": row["anchors_known_at_utc"],
                "prior_extreme": structure["reference"], "source_structure_phase": structure["phase"],
                "source_structure_requires_review": structure_recheck,
                "relation_to_local_leg": relation, "measured_path_area": {"price_low": low, "price_high": high},
                "latest_tail_direction_observation": tail_direction, "relation_to_latest_tail": tail_relation,
                "readout": readout, "semantic_parenthood_proven": False, "trade_permission": False,
                "next_observation": ((f"先核突破位置 {node:.2f} 的重新站回和后续保持；" if structure_recheck else "") +
                                     f"先看沿途本周期 SNR 的返回反应；若本周期收过 {anchor['price']:.2f} 起点的反侧，旧量尺须重审，"
                                     f"若先到 {target:.2f} 参考，先看能否继续而不是直接反手。"
                                     "本级到位后再重评，不直接取消上级任务。"),
            })
        matches.sort(key=lambda row: (_time(row["anchors_known_at_utc"]), row["measurement_id"]), reverse=True)
        representatives = []
        for direction in ("up", "down"):
            candidate = next((row for row in matches if row["direction_observation"] == direction
                              and not row["source_structure_requires_review"]), None)
            if candidate:
                representatives.append(candidate)
        result.update(
            status=("local_leg_inside_earlier_measured_paths" if representatives else
                    "only_contested_earlier_measured_paths" if matches else
                    "no_qualified_containing_measured_path"),
            local_leg_id=local.get("leg_id"), local_source_origin=a, local_source_terminal=b,
            local_direction_observation=local_direction, latest_closed_price=latest["close"],
            candidates=matches, representatives=representatives,
            opposing_measured_paths_coexist=len(representatives) > 1,
            readout=(" ".join(row["readout"] for row in representatives) if representatives else
                     "旧量尺位置仍可核对，但来源段已退回旧结构一侧，不能把它列为当前仍可沿用的测量。" if matches else
                     f"最新局部段 {a['price']:.2f}→{b['price']:.2f}；已载旧量尺中尚未找到仍未到、起点未收穿且包住这段的结构跨越路径，不能因此把小段认作第一力度。"),
            boundary="这里是同周期旧测量与当前小段的位置关系，不是已确定的父子任务；真正第一力度、方向及上级目标仍需背景裁决。",
        )
    except (KeyError, TypeError, ValueError):
        return result
    return result
