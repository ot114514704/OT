"""Date-precision US program + same-feed native weekly observations.

Plan, price observations and unverified research are separate. No event-name
direction/point-size mapping; no forced profile or entry permission.
"""
from copy import deepcopy
from datetime import datetime,timedelta,timezone
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
from zoneinfo import ZoneInfo

from .force_parent_prefix_registry import ROOT
from .force_strength_model import epoch,iso

REGISTRY=ROOT/'04_wells4_support/force_weekly_programs.json'
NY=ZoneInfo('America/New_York')


def week_monday(asof):
    t=datetime.fromtimestamp(epoch(asof),timezone.utc).astimezone(NY)
    day=t.date()
    if day.weekday()==6 and t.hour>=17:return (day+timedelta(days=1)).isoformat()
    return (day-timedelta(days=day.weekday())).isoformat()


def native_week_facts(rows,asof,monday):
    """Daily archive UTC calendar, explicitly not inferred broker/guide rollover."""
    now=epoch(asof);start=epoch(monday+'T00:00:00Z');native_start=start-86400
    visible=sorted((list(map(float,r[:5])) for r in rows if r[0]+86400<=now),key=lambda r:r[0])
    if len({r[0] for r in visible})!=len(visible):raise ValueError('Duplicate daily bar')
    prior=[r for r in visible if native_start-7*86400<=r[0]<native_start]
    week=[r for r in visible if start<=r[0]<start+5*86400]
    daily=[dict(timestamp_utc=iso(r[0]),known_at_utc=iso(r[0]+86400),open=r[1],high=r[2],low=r[3],close=r[4]) for r in week]
    base=dict(provider='HistData',instrument='XAUUSD',timeframe='D1',as_of_utc=asof,
        calendar='archive_daily_UTC_and_MT5_Sunday_week_not_inferred_from_guide',
        native_week_start_utc=iso(native_start),closed_days=daily,prior_week_range=None,
        mon_wed_inside_prior_week_range=None,thursday_close_beyond_mon_wed=None,
        chosen_weekly_container='not_adjudicated',weekly_DOL='not_bound',automatic_trade_permission=False)
    if not prior:return base
    high=max(r[2] for r in prior);low=min(r[3] for r in prior)
    base['prior_week_range']=dict(high=high,low=low,known_at_utc=iso(max(r[0]+86400 for r in prior)),
        role='explicit_native_prior_week_baseline_not_selected_profile_container')
    early=[r for r in week if r[0]<start+3*86400]
    if len(early)==3:
        base['mon_wed_inside_prior_week_range']=all(low<=r[3] and r[2]<=high for r in early)
        thu=next((r for r in week if r[0]==start+3*86400),None)
        if thu:
            base['thursday_close_beyond_mon_wed']=dict(direction='up' if thu[4]>max(r[2] for r in early) else
                'down' if thu[4]<min(r[3] for r in early) else 'inside',close=thu[4],
                early_high=max(r[2] for r in early),early_low=min(r[3] for r in early),
                known_at_utc=iso(thu[0]+86400),event_causation='not_inferred_from_daily_bar')
    return base


@lru_cache(maxsize=4)
def _load(path,mtime,size):return json.loads(Path(path).read_bytes())


def read_program(asof,path=None,root=ROOT):
    path=Path(path or REGISTRY)
    if not path.exists():return None
    stat=path.stat();data=_load(str(path),stat.st_mtime_ns,stat.st_size)
    if data.get('schema')!='force_weekly_program_registry_v1':raise ValueError('Foreign weekly registry')
    p=deepcopy(data['programs'].get(week_monday(asof)))
    if not p:return None
    sources={s['source_id']:s for s in p['sources']}
    visible_sources={k:s for k,s in sources.items() if epoch(s['known_at_utc'])<=epoch(asof)}
    for s in visible_sources.values():
        proof=(Path(root)/s['proof_path']).resolve()
        if not proof.is_relative_to(Path(root).resolve()) or sha256(proof.read_bytes()).hexdigest()!=s['proof_sha256']:
            raise ValueError('Weekly proof mismatch')
    events=[]
    for e in p['events']:
        s=sources[e['source_id']]
        if e['source_id'] not in visible_sources:continue
        date=e['scheduled_date_us']
        if not p['week_start']<=date<(datetime.fromisoformat(p['week_start'])+timedelta(days=7)).date().isoformat():
            raise ValueError('Foreign calendar week')
        if e['country']!='US' or e['precision']!='date_only_runtime':raise ValueError('Unreviewed calendar precision')
        # Only reviewed schedule fields: actual/forecast/revisions are never copied.
        event={k:e[k] for k in ('event_id','name','country','event_class','scheduled_date_us','precision','source_id')}
        left=datetime.fromisoformat(date).replace(tzinfo=NY);right=left+timedelta(days=1)
        event.update(known_at_utc=s['known_at_utc'],source_url=s['url'],
            timing_state='before_scheduled_day' if epoch(asof)<left.timestamp() else
            'scheduled_day_elapsed_no_outcome_imported' if epoch(asof)>=right.timestamp() else 'within_day_exact_time_unverified',
            actual_values_joined=False)
        events.append(event)
    p['events']=events
    p['sources']=list(visible_sources.values())
    # Research-only post-case-modified documents do not become a calendar row.
    p.pop('research_only_not_runtime_events',None)
    return p


def weekly_context(scene,*,program_path=None,root=ROOT,daily_rows=None):
    asof=scene['cutoff_utc'];monday=week_monday(asof)
    base=dict(schema='force_weekly_context_v1',provider=scene.get('provider'),instrument=scene.get('instrument'),
        as_of_utc=asof,week_start=monday,status='no_verified_program_for_week',events=[],market_facts=None,
        selected_profile=None,weekly_direction=None,weekly_DOL=None,actual_values_joined=False,
        automatic_trade_permission=False)
    try:p=read_program(asof,program_path,root)
    except (ValueError,KeyError,TypeError,OSError):return dict(base,status='program_proof_invalid')
    if not p or not p['events']:return base
    if scene.get('provider')!='HistData' or scene.get('instrument')!='XAUUSD':return dict(base,status='market_not_joined')
    if daily_rows is None:
        from .build_archive_window_snapshot import load_prefix,ARCHIVE
        catalog=json.loads((ARCHIVE/'catalog.json').read_text(encoding='utf-8'))
        d=next(d for d in catalog['datasets'] if d['id']=='HistData')
        daily_rows=load_prefix(d['periods']['D1'],epoch(asof),25)
    facts=native_week_facts(daily_rows,asof,monday)
    known=max((e['known_at_utc'] for e in p['events']),key=epoch)
    macro_dates=sorted({e['scheduled_date_us'] for e in p['events'] if e['event_class'] in ('national_GDP_update','national_income_spending_prices')})
    labels={'national_GDP_update':'GDP','national_income_spending_prices':'PCE/收支','regional_GDP_income':'州GDP'}
    schedule_summary=[]
    for day in sorted({e['scheduled_date_us'] for e in p['events']}):
        names=list(dict.fromkeys(labels.get(e['event_class'],'其他已核数据') for e in p['events'] if e['scheduled_date_us']==day))
        schedule_summary.append('周'+'一二三四五六日'[datetime.fromisoformat(day).weekday()]+','.join(names))
    hypotheses=[
        dict(family='classic_expansion',status='unselected',needs=['early_week_HTF_PDA_and_manipulation','parent_DOL','own_period_acceptance'],source_pages=[10,13]),
        dict(family='midweek_reversal',status='unselected',needs=['Wednesday_relevant_event_and_PDA','H1_H4_reversal_acceptance'],source_pages=[50,51]),
        dict(family='consolidation_reversal_prior_week_container',status='not_supported_for_this_container' if facts['mon_wed_inside_prior_week_range'] is False else 'unselected',
             needs=['selected_external_container','Mon_Wed_internal_range','Thursday_external_manipulation_and_acceptance'],source_pages=[31]),
        dict(family='Friday_continuation',status='conditional',needs=['prior_expansion_accepted','parent_DOL_still_open','Friday_follow'],source_pages=[31,50]),
        dict(family='Friday_TGIF',status='conditional',needs=['named_weekly_or_daily_expansion_objective_completed','opposing_price_response'],source_pages=[17]),
        dict(family='neutral_Friday_release_prior_week_container',status='not_supported_for_this_container' if facts['mon_wed_inside_prior_week_range'] is False else 'unselected',
            needs=['Mon_Thu_consolidation_in_named_container','verified_Friday_major_window','price_acceptance'],
            source_document='weekly_profiles_smc_ict_free_guide.pdf',source_pages=[6]),
        dict(family='no_profile',status='open_competitor',needs=[],source_pages=[])]
    return dict(base,status='partial_verified_US_date_program_and_native_context',program_id=p['program_id'],
        program_known_at_utc=known,program_coverage=p['coverage'],source_provenance=p['sources'],events=p['events'],
        market_facts=facts,profile_candidates=hypotheses,schedule_summary=';'.join(schedule_summary),
        planned_day_roles=[
            dict(before_dates=macro_dates[:1],role='pre_macro_window_preparation_or_independent_local_sweep',
                state='research_hypothesis_not_guaranteed_accumulation',liquidity_scale='requires_named_session_daily_or_weekly_objects'),
            dict(dates=macro_dates,role='verified_subset_macro_window_candidate',state='not_proven_dominant_in_full_US_calendar',
                liquidity_scale='not_measured_from_event_names',events=[e['event_id'] for e in p['events'] if e['scheduled_date_us'] in macro_dates]),
            dict(days=['Friday'],role='continuation_vs_objective_completion_return_vs_other_unverified_events',
                state='conditional_not_friday_reversal',liquidity_scale='requires_parent_target_and_acceptance')],
        planned_role_vs_realized_reaction='separate_no_causation_from_daily_range',
        guide_day_ratings_are_probabilities=False)


def bind_force(force,scene,weekly,parent_binding):
    base=dict(schema='force_weekly_binding_v1',provider=scene.get('provider'),instrument=scene.get('instrument'),
        owner_id=force['id'],source_id=force['source_id'],timeframe=force['timeframe'],source_points=force['points'],
        source_known_at_utc=force['known_at_utc'],as_of_utc=scene['cutoff_utc'],
        scope='review_week_context_not_formation_or_entry_confirmation',status=weekly['status'],
        week_start=weekly['week_start'],program_id=weekly.get('program_id'),
        source_grade_overridden=False,selected_profile=None,selected_entry_route=None,automatic_trade_permission=False)
    if weekly.get('program_id') is None:return base
    if (weekly['provider']!=scene.get('provider') or weekly['instrument']!=scene.get('instrument') or
        weekly['as_of_utc']!=scene['cutoff_utc'] or epoch(force['known_at_utc'])>epoch(scene['cutoff_utc'])):
        return dict(base,status='foreign_or_future_context')
    if any(parent_binding.get(k)!=v for k,v in dict(owner_id=force['id'],source_id=force['source_id'],
        timeframe=force['timeframe'],as_of_utc=scene['cutoff_utc'],provider=scene.get('provider'),instrument=scene.get('instrument')).items()):
        return dict(base,status='foreign_parent_binding')
    parent=parent_binding['review_parent']
    relation=parent.get('source_direction_relation')
    base.update(program_known_at_utc=weekly['program_known_at_utc'],calendar_complete=False,
        schedule_summary=weekly['schedule_summary'],
        parent_sequence_relation=relation,parent_task_target='not_bound',
        cadence_interpretation='local_counter_sequence_response_not_weekly_reversal' if relation=='opposite_direction' else
            'same_sequence_continuation_still_needs_parent_objective' if relation=='same_direction' else 'competing_directions',
        Friday_action='continuation_if_DOL_open_or_return_if_named_objective_completed_neither_selected')
    return base


def caption(binding):
    if not binding.get('program_id'):return ''
    return '周历已核子集·'+binding['schedule_summary']+'·续接/回归待择'
