"""Whole-wave delivery coverage against the native market BEFORE departure.

User correction (2026-10-09): roughly 80–90% of a full own-period wave must
carry force. Coverage below is over short native intervals, not a claim that
80% same-colour candles is Alexander's formula or observed market liquidity.
All numerical screens are provisional. No future return or outcome is used.
"""
import math
import statistics

METHOD = 'native_predeparture_force_coverage_v1'
MIN_COVERAGE = .80
STRONG_COVERAGE = .90
LOCAL_INTERVALS = 3
MIN_BASELINE_BARS = 5
MIN_SPEED = .70
MIN_EFFICIENCY = .68
MIN_CLOSE_SHARE = .65
MIN_BODY_SHARE = .50
MIN_DIRECTIONAL_BODY_SHARE = .65


def _valid(bar):
    try:
        o,h,l,c = [float(bar[k]) for k in ('open','high','low','close')]
        return all(math.isfinite(v) for v in (o,h,l,c)) and l <= min(o,c) <= max(o,c) <= h
    except (KeyError, TypeError, ValueError):
        return False


def delivery_coverage(path, upward, amplitude):
    bars = path.get('bars') or []
    prior = path.get('baseline_bars') or []
    result = dict(method=METHOD, qualified=False, coverage=None, strong_coverage=False,
        baseline_bar_count=len(prior), coverage_unit='trailing_native_intervals',
        local_intervals=LOCAL_INTERVALS, threshold=MIN_COVERAGE,
        liquidity_observed=False, rule_is_provisional=True)
    if len(bars) < 3 or not all(_valid(b) for b in bars + prior):
        return {**result, 'reason':'invalid_or_insufficient_native_ohlc'}
    ranges = [float(b['high'])-float(b['low']) for b in prior]
    if len(prior) < MIN_BASELINE_BARS or not ranges or statistics.median(ranges) <= 0:
        return {**result, 'reason':'predeparture_native_baseline_unavailable'}
    baseline = statistics.median(ranges)
    sign = 1 if upward else -1
    steps = [sign*(float(r['close'])-float(l['close'])) for l,r in zip(bars,bars[1:])]
    # A is the turning candle; its full body can belong to the old wave.
    # Keep A's exact high/low as geometry, but score delivery from A close on.
    moves = bars[1:]
    def facts(start, stop):
        ds = steps[start:stop]
        rows = moves[start:stop]
        net,travel = sum(ds),sum(abs(v) for v in ds)
        bodies = [sign*(float(b['close'])-float(b['open'])) for b in rows]
        body = sum(abs(v) for v in bodies)
        span = sum(float(b['high'])-float(b['low']) for b in rows)
        return dict(speed=net/len(ds)/baseline,
            efficiency=net/travel if travel else 0.,
            directional_closes=sum(v>0 for v in ds)/len(ds),
            body_share=body/span if span else 0.,
            directional_body_share=sum(max(0.,v) for v in bodies)/body if body else 0.,
            body_to_displacement=body/net if net>0 else 0.)
    def carries_force(f):
        return (f['speed'] >= MIN_SPEED and f['efficiency'] >= MIN_EFFICIENCY and
            f['directional_closes'] >= MIN_CLOSE_SHARE and f['body_share'] >= MIN_BODY_SHARE and
            f['directional_body_share'] >= MIN_DIRECTIONAL_BODY_SHARE and
            f['body_to_displacement'] >= .60)
    intervals = []
    for i in range(len(steps)):
        # The initial interval has one observation; it is not duplicated or
        # blessed by a later burst. Later windows never extend beyond B.
        start = max(0,i+1-LOCAL_INTERVALS)
        intervals.append(carries_force(facts(start,i+1)))
    coverage = sum(intervals)/len(intervals)
    whole = facts(0,len(steps))
    qualified = coverage >= MIN_COVERAGE and carries_force(whole) and abs(amplitude) >= 2*baseline
    return {**result, 'qualified':qualified, 'coverage':coverage,
        'strong_coverage':qualified and coverage>=STRONG_COVERAGE,
        'reason':'sustained_whole_wave_delivery' if qualified else 'insufficient_whole_wave_force_coverage',
        'baseline_median_range':baseline, 'whole':whole,
        'force_interval_count':sum(intervals), 'interval_count':len(intervals),
        'interval_force_mask':''.join('1' if v else '0' for v in intervals)}
