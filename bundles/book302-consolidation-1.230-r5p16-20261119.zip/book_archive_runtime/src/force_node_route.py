"""Causal local-node/sweep context and a concrete broken-node return route.

Local radius2 pivots are observable engineering references, NOT author's
fourth-wave nodes, institutional inventory or parent trend adjudication.
Context is frozen at source confirmation. Later route state is independent.
"""
from .force_strength_model import BANDS, epoch, iso

LEFT_BARS = 128
RADIUS = 2


def source_context(force, bars):
    a, b = force['points']; known = epoch(force['known_at_utc'])
    sign = 1 if b[1] > a[1] else -1
    rows = sorted((r for r in bars if r['closed'] <= known), key=lambda r:r['t'])
    # Selection cannot use C or the future success of a particular node. Lock
    # the latest fully known pivot BEFORE source B, of each kind.
    left = [r for r in rows if r['t'] < a[0]][-LEFT_BARS:]
    refs = {}
    for kind in ('high', 'low'):
        for i in range(RADIUS, len(left)-RADIUS):
            value = left[i][kind]; direction = 1 if kind=='high' else -1
            if (all(direction*value >= direction*left[j][kind] for j in range(i-RADIUS,i)) and
                all(direction*value > direction*left[j][kind] for j in range(i+1,i+RADIUS+1)) and
                left[i+RADIUS]['closed'] <= a[0]):
                refs[kind] = dict(kind=kind,price=value,pivot_at_utc=iso(left[i]['t']),
                    known_at_utc=iso(left[i+RADIUS]['closed']),timeframe=force['timeframe'],
                    basis='local_radius2_pivot_not_author_wave_degree')
    part = [r for r in rows if a[0] <= r['t'] <= b[0]]
    node = refs.get('high' if sign>0 else 'low')
    liquidity = refs.get('low' if sign>0 else 'high')
    broken = dict(status='missing_preexisting_node',reference=node,close_break_at_utc=None)
    if node:
        # A node already behind B was not newly broken by this source.
        ahead = sign*(node['price']-a[1]) > 0
        crossing = next((r for r in part if sign*(r['close']-node['price'])>0),None) if ahead else None
        wick = any(sign*((r['high'] if sign>0 else r['low'])-node['price'])>0 for r in part) if ahead else False
        broken.update(status='closed_break' if crossing else 'wick_only' if wick else 'not_broken' if ahead else 'already_beyond_at_origin',
            close_break_at_utc=iso(crossing['closed']) if crossing else None)
    sweep = dict(status='missing_preexisting_reference',reference=liquidity,
                 sweep_at_utc=None,reclaim_at_utc=None,intrabar_order='not_inferred')
    if liquidity and part:
        adverse = 'low' if sign>0 else 'high'
        # The origin wick is a left-liquidity observation, not a claim that all
        # liquidity was exhausted. No post-C candle can repair this context.
        crossed = next((r for r in part if sign*(r[adverse]-liquidity['price'])<0),None)
        reclaimed = next((r for r in part if crossed and r['t']>=crossed['t'] and
                          sign*(r['close']-liquidity['price'])>0),None)
        sweep.update(status='swept_and_closed_back' if reclaimed else 'swept_not_reclaimed' if crossed else 'no_observed_breach',
            sweep_at_utc=iso(crossed['closed']) if crossed else None,
            reclaim_at_utc=iso(reclaimed['closed']) if reclaimed else None)
    return dict(schema='force_local_node_context_v1',owner_id=force.get('id'),source_id=force.get('source_id'),
        timeframe=force['timeframe'],source_known_at_utc=force['known_at_utc'],known_at_utc=force['known_at_utc'],
        source_points=[list(p) for p in force['points']],local_break=broken,left_liquidity=sweep,
        parameters=dict(left_closed_bars=LEFT_BARS,pivot_radius=RADIUS),
        author_fourth_wave_node='unknown',parent_transition='not_adjudicated',
        chip_inventory='not_observable_from_ohlc',automatic_trade_permission=False)


def node_retest(force, context, bars, band, as_of_utc):
    """One chosen source/ordinary-band's alternative price-trigger route.

    In contrast to whole-band reclaim, a preexisting broken node inside the
    band may be reclaimed before its upper/lower edge. Neither route requires
    a later follow candle or a second retest to confirm this close pattern.
    """
    a,b=force['points'];sign=1 if b[1]>a[1] else -1
    end=epoch(as_of_utc);known=epoch(force['known_at_utc']);height=abs(b[1]-a[1])
    if end<known:raise ValueError('Node route predates source confirmation')
    if (context.get('owner_id')!=force.get('id') or context.get('source_id')!=force.get('source_id') or
        context.get('timeframe')!=force.get('timeframe') or context.get('source_points')!=force['points'] or
        context.get('source_known_at_utc')!=force['known_at_utc'] or epoch(context['known_at_utc'])>known):
        raise ValueError('Foreign or future node context')
    base=dict(route='broken_local_node_retest',owner_id=force.get('id'),source_id=force.get('source_id'),
        timeframe=force['timeframe'],band=band,as_of_utc=as_of_utc,pattern_state='observation',
        first_touch_at_utc=None,trigger_at_utc=None,closed_reference=None,protection_price=a[1],
        response_target_price=b[1],response_target_scope='source_terminal_not_parent_DOL',
        reward_risk=None,price_pattern_confirmed=False,current_reference=False,
        node_acceptance_state='not_evaluated',acceptance_known_at_utc=force['known_at_utc'],
        attempts=[],current_attempt=None,
        entry_route_permission=False,automatic_trade_permission=False,fill_price=None)
    if band=='127.2':
        return dict(base,pattern_state='not_applicable',reason='independent_sweep_not_ordinary_node_retest')
    failed=force.get('evidence',{}).get('book_first_response',{}).get('invalidated_at_utc')
    if failed and epoch(failed)<=known:
        return dict(base,pattern_state='invalidated',reason='source_failed_before_confirmation',state_known_at_utc=failed)
    node=context['local_break']['reference']
    if context['local_break']['status']!='closed_break':
        return dict(base,pattern_state='not_applicable',reason='no_source_body_break_of_preexisting_node')
    lo,hi=sorted(b[1]-sign*height*r for r in BANDS[band])
    if not lo<=node['price']<=hi:
        return dict(base,pattern_state='not_applicable',reason='broken_node_outside_this_band',node_price=node['price'])
    base.update(node_price=node['price'],node_known_at_utc=node['known_at_utc'],
        node_acceptance_state='waiting_touch',
        source_break_known_at_utc=context['local_break']['close_break_at_utc'],reason='await_node_touch_and_directional_reclaim_close')
    later=sorted((r for r in bars if r['t']>=known and r['closed']<=end),key=lambda r:r['t'])
    touched=None;signal=None;active=None
    for row in later:
        # A source-origin cross defeats the ordinary route even if that same
        # candle also closes back above the node. Do not infer tick order.
        breach=sign*((row['low'] if sign>0 else row['high'])-a[1])<=0
        if signal:
            target=sign*((row['high'] if sign>0 else row['low'])-b[1])>=0
            if breach or target:
                state='ambiguous' if breach and target else 'invalidated' if breach else 'completed'
                if active:
                    active.update(status=state,ended_at_utc=iso(row['closed']))
                return dict(base,pattern_state=state,reason='later_protection_target_or_ambiguous',
                    node_acceptance_state='source_task_terminal',acceptance_known_at_utc=iso(row['closed']),
                    state_known_at_utc=iso(row['closed']))
            if active:
                # This ends THIS node-entry attempt, not the frozen B stop or
                # the source direction. A wick through the node is not a loss
                # on close. Equality is boundary/undecided, not accepted side.
                if sign*(row['close']-node['price'])<=0:
                    active.update(status='interrupted_at_node_close',ended_at_utc=iso(row['closed']))
                    active=None
                    base.update(node_acceptance_state='not_held_on_close',
                        acceptance_known_at_utc=iso(row['closed']),
                        reason='node_attempt_interrupted_not_source_stop')
                continue
        if breach and not signal:
            return dict(base,pattern_state='invalidated',reason='source_origin_breached_before_route_trigger',state_known_at_utc=iso(row['closed']))
        if not signal and sign*((row['high'] if sign>0 else row['low'])-b[1])>=0:
            # This specific route targets the original C. Once it has already
            # been delivered, a later node touch is a different task/target,
            # not a fresh entry using the retired source-terminal objective.
            return dict(base,pattern_state='completed',reason='source_target_delivered_before_node_trigger',
                        target_reached_at_utc=iso(row['closed']),state_known_at_utc=iso(row['closed']))
        if row['low']<=node['price']<=row['high']:
            touched=touched or iso(row['closed'])
            base.update(pattern_state='confirmed' if signal else 'candidate',first_touch_at_utc=touched,
                node_acceptance_state='retest_wait_directional_close',acceptance_known_at_utc=iso(row['closed']),
                reason='node_touched_wait_directional_close_back')
            if sign*(row['close']-node['price'])>0 and sign*(row['close']-row['open'])>0:
                entry=row['close'];risk=sign*(entry-a[1]);reward=sign*(b[1]-entry)
                if risk<=0 or reward<=0:
                    return dict(base,pattern_state='completed',reason='source_target_already_traversed_at_trigger_not_fresh_reference')
                active=dict(attempt_id=f"{force.get('id')}:{band}:node:{int(row['closed'])}",
                    ordinal=len(base['attempts'])+1,trigger_at_utc=iso(row['closed']),closed_reference=entry,
                    protection_price=a[1],response_target_price=b[1],reward_risk=reward/risk,
                    status='price_trigger_confirmed',ended_at_utc=None)
                base['attempts'].append(active)
                if not signal:
                    # Keep first trigger immutable. New attempts have their
                    # own clock/price; never silently resurrect the old one.
                    signal=row
                    base.update(trigger_at_utc=active['trigger_at_utc'],closed_reference=entry,
                        price_pattern_confirmed=True,reward_risk=reward/risk)
                base.update(pattern_state='confirmed',node_acceptance_state='reclaimed_close',
                    acceptance_known_at_utc=iso(row['closed']),reason='node_inside_band_touched_and_directionally_closed_back')
    return dict(base,current_reference=bool(active),current_attempt=active,
        state_known_at_utc=base['acceptance_known_at_utc'])


def context_plan(force, bars, quality, return_observation):
    context=source_context(force,bars)
    node=context['local_break'];sweep=context['left_liquidity']
    strong=quality=='strong' and node['status']=='closed_break' and sweep['status']=='swept_and_closed_back'
    weak=quality=='weak' and node['status'] in ('not_broken','wick_only')
    inclination='shallow_confluence' if strong else 'deep_and_sweep_compete' if weak else 'no_forced_band_mapping'
    preferred=next((k for k,v in return_observation.get('bands',{}).items() if v.get('statistical_preference')),None)
    prior_bands={'50_61.8'} if strong else {'77_88','127.2'} if weak else set()
    relation=('conflict_requires_context_resolution' if preferred and prior_bands and preferred not in prior_bands else
              'aligned' if preferred and preferred in prior_bands else 'undecided')
    routes={band:node_retest(force,context,bars,band,return_observation['review_end_utc']) for band in BANDS}
    # Keep the 24h response review boundary explicit. This is not a general
    # expiry rule. The same frozen context can be reused by another policy.
    for route in routes.values():
        route['historical_only']=return_observation['historical_only']
        if route['historical_only']:route['current_reference']=False
    node_label={'closed_break':'近侧节点已收破','wick_only':'节点仅影破','not_broken':'节点未破',
                'missing_preexisting_node':'近侧节点未知','already_beyond_at_origin':'节点非本段新破'}[node['status']]
    sweep_label={'swept_and_closed_back':'左侧已扫回','swept_not_reclaimed':'左侧扫后未回',
                 'no_observed_breach':'未见左扫','missing_preexisting_reference':'左扫未知'}[sweep['status']]
    return dict(schema='force_context_route_plan_v1',context=context,contextual_inclination=inclination,
        inclination_basis='qualitative_author_prior_not_statistically_calibrated_or_required_gate',
        statistics_context_relation=relation,statistical_preferred_band=preferred,
        node_routes=routes,caption=node_label+'/'+sweep_label,
        selected_entry_band=None,automatic_trade_permission=False)
