"""Observe the frozen C/E source rail independently of its D-shift target.

PDF83-84 describe distinct construction and theoretical targets. Reassessment
after source contact is an explicit engineering review flag, not an author
trend reversal, target fill, or permission to replace C/D/E.
"""
from math import isfinite
from .book_first_response_leg import clock,close_time


def observe_return_source(bars,turning,timeframe,cutoff):
    base=dict(status='unknown',timeframe=timeframe,source_pdf_pages=[83,84],
              review_rule_basis='engineering_source_contact_review_not_author_invalidation',
              author_invalidation_confirmed=False,automatic_trade_permission=False,
              first_contact=None,first_closed_break=None)
    try:
        rows=[r for r in bars if clock(close_time(r,timeframe))<=clock(cutoff)]
        c,e=turning['extension_start_index'],turning['extension_end_index']
        if any(isinstance(i,bool) or not isinstance(i,int) for i in (c,e)) or not 0<=c<e<len(rows):
            return dict(base,reason='source_indices_unbound')
        sign=1 if turning['direction']=='up' else -1 if turning['direction']=='down' else 0
        if not sign:return dict(base,reason='source_direction_unknown')
        pc,pe=turning['extension_start_price'],turning['extension_end_price']
        if any(isinstance(p,bool) or not isfinite(p) or p<=0 for p in (pc,pe)):
            return dict(base,reason='source_prices_invalid')
        side='high' if sign>0 else 'low'
        if rows[c][side]!=pc or rows[e][side]!=pe:return dict(base,reason='source_points_not_native')
        slope=(pe-pc)/(e-c);known=turning['known_at_utc']
        if clock(known)>clock(cutoff):return dict(base,reason='source_not_yet_known')
        contact=broken=None
        for i in range(e+1,len(rows)):
            level=pc+slope*(i-c);row=rows[i]
            event=dict(utc=row['timestamp_utc'],level=level,event_closed_at_utc=close_time(row,timeframe),
                known_at_utc=max((known,close_time(row,timeframe)),key=clock),
                timing='historical_reconstruction' if clock(known)>clock(close_time(row,timeframe)) else 'observed_after_construction')
            if contact is None and sign*(float(row[side])-level)>=0:contact=dict(event,extreme_price=row[side])
            if broken is None and sign*(float(row['close'])-level)>0:broken=dict(event,close_price=row['close'])
        state='closed_break_observed' if broken else 'price_contact_observed' if contact else 'not_contacted_in_observed_prefix'
        clocks=[known]+[event['known_at_utc'] for event in (contact,broken) if event]
        return dict(base,status=state,source_points=[[rows[c]['timestamp_utc'],pc],[rows[e]['timestamp_utc'],pe]],
            first_contact=contact,first_closed_break=broken,source_reassessment_required=bool(contact or broken),
            known_at_utc=max(clocks,key=clock),observed_through_utc=close_time(rows[-1],timeframe))
    except (KeyError,TypeError,ValueError):return dict(base,reason='source_identity_or_clock_missing')
