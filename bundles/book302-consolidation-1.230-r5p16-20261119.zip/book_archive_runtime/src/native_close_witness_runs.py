"""Lossless timestamp evidence encoding, never a market/acceptance threshold.

Each run names its first native bar-open UTC, exact second interval and count.
Session breaks start separate runs. No witness is discarded, sampled or capped.
Legacy lists remain accepted; decode only on explicit evidence inspection.
"""
from datetime import datetime, timedelta, timezone

ENCODING = "native_utc_arithmetic_runs_v1"


def _parse(utc):
    if not isinstance(utc, str):
        raise ValueError("witness UTC must be a string")
    value = datetime.fromisoformat(utc.replace("Z", "+00:00"))
    if value.tzinfo is None or value.utcoffset() != timedelta(0) or value.microsecond:
        raise ValueError("witness UTC must name an exact UTC second")
    if value.isoformat().replace("+00:00", "Z") != utc:
        raise ValueError("noncanonical UTC representation")
    return value


def encode_close_witnesses(witnesses):
    """Return exact runs when smaller, otherwise retain the original list."""
    return _encode(witnesses, _parse)


def source_close_witness_encoder():
    """Memoize pure canonical UTC parsing inside ONE synchronous source scope.

    Each node can name many of the same native timestamps. Values are still
    validated by the original parser; no price, node, acceptance decision or
    encoded output is cached. The closure is discarded with its source scope.
    """
    times = {}

    def parse(utc):
        if utc not in times:
            times[utc] = _parse(utc)
        return times[utc]

    def encode(witnesses):
        return _encode(witnesses, parse)

    return encode


def _encode(witnesses, parse):
    if not isinstance(witnesses, list):
        raise ValueError("expected a timestamp list")
    if len(witnesses) < 8:
        return witnesses
    try:
        times = [parse(utc) for utc in witnesses]
    except (ValueError, TypeError, OverflowError):
        return witnesses
    if any(b <= a for a, b in zip(times, times[1:])):
        return witnesses
    runs, index = [], 0
    while index < len(times):
        end = index + 1
        step = int((times[end] - times[index]).total_seconds()) if end < len(times) else 0
        if step:
            end += 1
            while end < len(times) and (times[end] - times[end - 1]).total_seconds() == step:
                end += 1
        runs.append([witnesses[index], step, end - index])
        index = end
    # Canonical timestamps cost 23 JSON bytes each; each run costs at least
    # 32. This conservative bound avoids encoding irregular short sequences.
    if len(runs) * 48 + 100 >= len(witnesses) * 23:
        return witnesses
    return {"encoding": ENCODING, "count": len(witnesses), "runs": runs}


def decode_close_witnesses(value, *, max_count=1_000_000):
    """Explicitly reconstruct every UTC witness, with bounded input validation."""
    if isinstance(value, list):
        if len(value) > max_count:
            raise ValueError("witness count exceeds inspection bound")
        return list(value)
    if not isinstance(value, dict) or value.get("encoding") != ENCODING:
        raise ValueError("unknown witness encoding")
    count, runs = value.get("count"), value.get("runs")
    if type(count) is not int or not 0 <= count <= max_count or not isinstance(runs, list):
        raise ValueError("invalid witness count/runs")
    output, previous = [], None
    for run in runs:
        if not isinstance(run, list) or len(run) != 3:
            raise ValueError("invalid witness run")
        utc, step, size = run
        if type(step) is not int or type(size) is not int or size < 1 or step < 0 or (size > 1 and not step):
            raise ValueError("invalid witness interval/count")
        if len(output) + size > count:
            raise ValueError("witness runs exceed declared count")
        start = _parse(utc)
        if previous is not None and start <= previous:
            raise ValueError("unordered witness runs")
        try:
            for index in range(size):
                current = start + timedelta(seconds=step * index)
                output.append(current.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"))
            previous = current
        except OverflowError as exc:
            raise ValueError("witness UTC overflow") from exc
    if len(output) != count:
        raise ValueError("witness runs do not cover declared count")
    return output
