"""Construct a conditional background from native prices, before copying a ruler.

The interpretation is an engineering hypothesis grounded in Alexander's
top-down/source-position conditions. It is not an author label or a calibrated
trading model. No C, equal-distance outcome, or user drawing selects the source.
"""
from copy import deepcopy
import hashlib
from datetime import timedelta

from .live_nested_stage_review import MINUTES, _time, _same
from .live_native_structure_sequence import ORDER, source_time_background
from .live_parent_objective_context import later_parent_target_contact, counter_task_boundary_review

METHOD = 'automatic_native_parent_source_background_v1'
SOURCE_IDS = ['7674514871451136703', '7674515091465949482',
              '7674515523879872601', '7674515864606966022',
              '7676550586231557407', '7608052678914466373', '7685764649186122721']


def build_automatic_background(snapshot, timeframe, record, source_facts):
    result = dict(status='unresolved', producer_method=METHOD, context=None,
                  parent_task=None, target_graph=None, blockers=[], trade_permission=False)
    try:
        if not source_facts.get('source_delivery_evidence_ready'):
            result['blockers'].append('source_force_and_delivery_not_ready')
            return result
        state = snapshot['timeframe_states'][timeframe]
        counter = next((leg for leg in state['candidate_wave_ledger']['legs']
                        if leg['leg_id']==source_facts['relative_effort']['prior_opposing_leg_id']), None)
        # Select the position the immediately preceding opposing leg came from,
        # not whichever of many older fractals happens to make the ruler pass.
        node = counter['origin'] if counter else None
        handled = next((item for item in source_facts['source_node_scope']['nodes']
                        if node and _same(item['pivot'],node)
                        and item['response']=='sustained_close_through'), None)
        if not handled:
            result['blockers'].append('preceding_opposing_origin_not_delivered_through')
            return result
        background=source_facts.get('native_background_at_source') or source_time_background(
            snapshot,timeframe,source_facts['source_known_at_utc'])
        frames=background.get('frames') or []
        active={'close_through_with_follow','return_held_node'}
        # The closest observed higher directional task owns this comparison.
        # A farther surviving task cannot silently replace an opposing nearer
        # active task. Other higher observations remain in the reading context.
        parents=[frame for frame in frames if frame['timeframe']!=timeframe
                 and (frame.get('selected') or {}).get('state') in active]
        parent=max(parents,key=lambda frame:ORDER.index(frame['timeframe'])) if parents else None
        direction=record['direction_observation']
        if not parent:
            result['blockers'].append('higher_same_direction_task_not_established')
            return result
        event=parent['selected']
        parent_direction=event['direction']
        role='trend_delivery' if parent_direction==direction else 'bounded_pullback'
        boundary=None
        known=source_facts['source_known_at_utc']
        if role=='bounded_pullback':
            point=event['origin_boundary']
            boundary=dict(boundary_id=f"{parent['timeframe']}:origin_boundary:{point['pivot_timestamp_utc']}",
                          timeframe=parent['timeframe'],pivot=deepcopy(point),
                          role='native_parent_origin_not_author_adjudicated_protected_node')
            bounds=counter_task_boundary_review(snapshot.get('chart_history'),parent['timeframe'],timeframe,
                boundary,record['source_origin'],parent_direction,_time(known),
                provider=snapshot.get('provider'),instrument=snapshot.get('instrument'))
            if not bounds['valid'] or (1 if parent_direction=='up' else -1)*(
                    record['source_terminal']['price']-point['price']) <= 0:
                result['blockers'].append('counter_task_boundary_unavailable_or_breached')
                result['counter_task_boundary_review']=bounds
                return result
        sign=1 if direction=='up' else -1
        # A nearer parent barrier constrains the child measurement; it does not
        # erase its source or justify skipping to a convenient farther target.
        targets=event.get('target_candidates') or []
        if not targets:
            result['blockers'].append('parent_unreached_reference_unavailable')
            return result
        parent_sign=1 if parent_direction=='up' else -1
        target=min(targets,key=lambda p:parent_sign*p['price'])
        contact=later_parent_target_contact(snapshot.get('chart_history'),parent['timeframe'],
            dict(as_of_utc=parent['latest_closed_end_utc'],price_low=target['price'],price_high=target['price']),
            _time(known),provider=snapshot.get('provider'),instrument=snapshot.get('instrument'))
        if contact:
            # Do not silently skip this nearer obstacle to manufacture a
            # convenient farther "untouched" parent task.
            result['blockers'].append('parent_reference_contact_known_before_source_confirmation')
            result['parent_reference_contact']=contact
            return result
        witnesses={w['evidence_id']:deepcopy(w) for w in source_facts['market_evidence']}
        parent_bars={b['timestamp_utc']:b for b in snapshot['chart_history'][parent['timeframe']]['bars']}
        for witness in event['witnesses']:
            utc=witness['bar_open_utc']; bar=parent_bars[utc]
            if (_time(utc)+timedelta(minutes=MINUTES[parent['timeframe']])>_time(known)
                    or bar['close']!=witness['close']):
                raise ValueError('unknown parent witness')
            identity=f"{parent['timeframe']}:background:{utc}"
            witnesses[identity]=dict(evidence_id=identity,timeframe=parent['timeframe'],
                                     bar_open_utc=utc,close=bar['close'])
        target_id=f"{parent['timeframe']}:prior_extreme:{target['pivot_timestamp_utc']}:{target['kind']}"
        parent_id=f"{parent['timeframe']}:native_task:{event['attempt_id']}"
        task_id=f"{timeframe}:source_task:{record['source_leg_id']}:{handled['node_id']}"
        identity=hashlib.sha256(f'{task_id}|{parent_id}|{target_id}'.encode()).hexdigest()[:24]
        context={key:record[key] for key in ('timeframe','snapshot_id','as_of_utc','measurement_id','source_leg_id')}
        context.update(producer_method=METHOD,interpretation_status='automatic_conditional_analysis',
            background_state='resolved',resolution_scope='local_source_with_higher_direction_and_remaining_native_target',
            trend_established=True,direction_task_confirmed=True,source_leg_eligible=True,
            background_context_id=f'automatic:{identity}',direction_task_id=task_id,
            current_task_role=role,direction_observation=direction,known_at_utc=known,
            parent_direction=parent_direction,counter_task_boundary=boundary,
            counter_task_boundary_id=boundary['boundary_id'] if boundary else None,
            named_structure_node_id=handled['node_id'],
            named_structure_node=dict(node_id=handled['node_id'],timeframe=timeframe,pivot=deepcopy(node),
                                      role='origin_of_preceding_opposing_leg'),
            parent_timeframe=parent['timeframe'],parent_task_id=parent_id,
            parent_target=dict(target_id=target_id,timeframe=parent['timeframe'],price=target['price'],
                               pivot=deepcopy(target),role='unreached_prior_extreme_not_author_named_dol'),
            parent_measurement_relation=dict(
                relation=role,
                permission_to_ignore_parent_reference=False,
                interpretation='source and parent barrier remain separate; no B-based copy is generated'),
            higher_observations=[dict(timeframe=f['timeframe'],name=f.get('name'),
                                      direction=(f.get('selected') or {}).get('direction'),
                                      state=(f.get('selected') or {}).get('state')) for f in frames if f['timeframe']!=timeframe],
            source_refs=list(witnesses),market_evidence=list(witnesses.values()),
            theory_source_message_ids=SOURCE_IDS+(['7685103353552794027'] if boundary else []),trade_permission=False)
        refs=list(witnesses)
        parent_task=dict(parent_task_id=parent_id,timeframe=parent['timeframe'],direction_observation=parent_direction,
                         state='active',as_of_utc=known,source_refs=refs,interpretation_status='automatic_conditional_analysis')
        target_record=dict(target_id=target_id,parent_task_id=parent_id,timeframe=parent['timeframe'],
            direction_observation=parent_direction,state='active',as_of_utc=known,source_refs=refs,
            supports_source_task_role=role,supports_source_direction=direction,counter_task_boundary=boundary,
            supports_source_leg_id=record['source_leg_id'],price_low=target['price'],price_high=target['price'])
        graph=dict(dol_state='bound',target_completion_state='active',as_of_utc=known,source_refs=refs,
                   active_targets=[target_record],binding_scope='automatic_unreached_native_extreme_hypothesis')
        result.update(status='automatic_conditional_background',context=context,parent_task=parent_task,target_graph=graph)
    except (KeyError,TypeError,ValueError,AttributeError,OverflowError):
        result['blockers'].append('automatic_background_native_evidence_unavailable')
    return result
