"""Bounded HistData adapter for the shipped ICT logic. No broker clock shift."""
from datetime import datetime, timedelta, timezone
from functools import lru_cache
import gzip
import json
import sys

import numpy as np
from src.ict_archive_price_probe import PACKAGE, ARCHIVE

sys.path.insert(0, str(PACKAGE / 'project'))
from brooks_ai.types import Bar
from ict_ai.features import geometric_fvgs
from ict_ai.amd import amd_events
from ict_ai.po3 import po3_zones
from ict_ai.timebase import NY, session_windows
from ict_ai.silver_bullet import silver_bullet_windows
from ict_ai.range_liquidity import range_liquidity_map
from ict_ai.regular_liquidity import regular_liquidity
from ict_ai.profile_lifecycle import daily_profile_lifecycle


@lru_cache(maxsize=1)
def periods():
    catalog = json.loads((ARCHIVE / 'catalog.json').read_text(encoding='utf-8'))
    return next(d for d in catalog['datasets'] if d['id'] == 'HistData')['periods']


@lru_cache(maxsize=12)
def chunk_rows(filename):
    path = (ARCHIVE / filename).resolve()
    if not path.is_relative_to(ARCHIVE.resolve()):
        raise ValueError('Invalid archive path')
    rows = np.frombuffer(gzip.decompress(path.read_bytes()), dtype='<f8').reshape(-1, 6)
    if len(rows) > 1 and np.any(np.diff(rows[:, 0]) <= 0):
        raise ValueError('Archive timestamps are not strictly ordered')
    return rows


def read_bars(tf, start, cutoff):
    """Only closed bars; binary search within cached immutable archive chunks."""
    period = periods()[tf]
    step = period['minutes'] * 60
    result = []
    for chunk in period['chunks']:
        if chunk['end'] < start.timestamp() or chunk['start'] > cutoff.timestamp() - step:
            continue
        values = chunk_rows(chunk['file'])
        lo = np.searchsorted(values[:, 0], start.timestamp())
        hi = np.searchsorted(values[:, 0], cutoff.timestamp() - step, side='right')
        result.extend(Bar(datetime.fromtimestamp(r[0], timezone.utc),
                          *map(float, r[1:5]), spread=0) for r in values[lo:hi])
    if any(a.time >= b.time for a, b in zip(result, result[1:])):
        raise ValueError('Overlapping archive chunks')
    return result


def price_window(start_iso, end_iso, tf='M15', pixels=1600):
    """Viewport OHLC: every closed input candle contributes, never stride sampling."""
    start = datetime.fromisoformat(start_iso.replace('Z', '+00:00'))
    end = datetime.fromisoformat(end_iso.replace('Z', '+00:00'))
    if start.tzinfo is None or end.tzinfo is None or end <= start:
        raise ValueError('A positive timezone-aware range is required')
    if tf not in ('M5', 'M15', 'H1'):
        raise ValueError('Unsupported ICT period')
    pixels = max(64, min(4096, int(pixels)))
    period = periods()[tf]
    first, last = start.timestamp(), end.timestamp()
    step = period['minutes'] * 60
    parts = []
    for chunk in period['chunks']:
        if chunk['end'] < first or chunk['start'] > last - step:
            continue
        values = chunk_rows(chunk['file'])
        lo = np.searchsorted(values[:, 0], first)
        hi = np.searchsorted(values[:, 0], last-step, side='right')
        if hi > lo:
            parts.append(values[lo:hi, :5])
    if not parts:
        return dict(bars=[], source_rows=0, aggregated=False, timeframe=tf)
    rows = np.concatenate(parts)
    count = len(rows)
    if count > pixels * 2:
        columns = np.floor((rows[:, 0]-first) / (last-first) * pixels).astype(np.int64)
        indices = np.r_[0, np.flatnonzero(np.diff(columns)) + 1]
        ends = np.r_[indices[1:]-1, count-1]
        rows = np.column_stack((rows[indices, 0], rows[indices, 1],
                                np.maximum.reduceat(rows[:, 2], indices),
                                np.minimum.reduceat(rows[:, 3], indices), rows[ends, 4]))
    rows[:, 0] *= 1000
    return dict(bars=rows.tolist(), source_rows=count, aggregated=count > pixels*2,
                timeframe=tf, cutoff=end.isoformat(), total_history_bars=period['rows'])


def build_window(start_iso, end_iso, tf='M15'):
    start = datetime.fromisoformat(start_iso.replace('Z', '+00:00'))
    end = datetime.fromisoformat(end_iso.replace('Z', '+00:00'))
    if start.tzinfo is None or end.tzinfo is None or not timedelta(0) < end-start <= timedelta(days=8):
        raise ValueError('Request an aware, positive window of at most eight days')
    if tf not in ('M5', 'M15', 'H1'):
        raise ValueError('ICT native display periods: M5, M15, H1')
    # Calendar context includes the entire preceding month for prior-month
    # liquidity. It is calculation context, not thousands of visible SVG nodes.
    local = start.astimezone(NY)
    floor = (local.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
             - timedelta(days=1)).replace(day=1).astimezone(timezone.utc)
    m5 = read_bars('M5', floor, end)
    m15 = read_bars('M15', floor, end)
    native = m5 if tf == 'M5' else m15 if tf == 'M15' else read_bars(tf, floor, end)
    step = timedelta(minutes=periods()[tf]['minutes'])
    visible = [b for b in native if b.time >= start]
    all_fvg = geometric_fvgs(native, step, end)
    all_amd = amd_events(native, step, end)
    days = []
    day = start.astimezone(NY).date()
    while day <= end.astimezone(NY).date():
        windows = session_windows(day)
        finish = datetime.combine(day + timedelta(days=1), datetime.min.time(), NY).astimezone(timezone.utc)
        through = min(finish, end)
        if day.weekday() < 5 and through > windows['asia'][0]:
            liquidity = range_liquidity_map(m15, [day], through, reference_bars=m5)
            days.append(dict(date=str(day), as_of=through.isoformat(),
                sessions={k: [a.isoformat(), b.isoformat()] for k, (a,b) in windows.items()},
                silver=silver_bullet_windows(day),
                po3=po3_zones(m15, *windows['asia'], finish, through),
                liquidity=liquidity,
                regular=regular_liquidity(m15, m5, day, through, liquidity),
                profile=daily_profile_lifecycle(m15, day, through, reference_m5=m5)))
        day += timedelta(days=1)
    return dict(schema='ict_archive_window_v1', provider='HistData', clock='UTC; sessions America/New_York',
        timeframe=tf, start=start.isoformat(), cutoff=end.isoformat(),
        bars=[[b.time.timestamp()*1000,b.open,b.high,b.low,b.close] for b in visible],
        fvgs=[e for e in all_fvg if datetime.fromisoformat(e['available_at']) >= start],
        amd=[e for e in all_amd if datetime.fromisoformat(e['end']) >= start], days=days,
        context_start=floor.isoformat(), total_history_bars=periods()[tf]['rows'],
        unavailable={'smt':'No matched historical peer series bound', 'news':'No historical calendar bound'},
        context_boundary='Patterns originating before context_start are not inferred',
        execution_allowed=False, spread_observed=False)
