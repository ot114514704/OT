"""A range fact names an own-period container, not a lifetime touch counter.

Four known nonexpanding swings are a geometric working hypothesis, NOT an
Alexander major-degree label. Keep the actual boundaries and their own native
close/follow exit. A wick sweep alone is not an accepted exit.
"""
from .live_nested_stage_review import _time

METHOD = 'native_named_range_boundary_tests_v1'
TRAVERSE_METHOD = 'native_named_opposite_boundary_full_test_v1'


def effective_responses(node, cutoff=None):
    """Keep old accepted tests untouched; add separately witnessed range tests."""
    extra = node.get('range_response_receipts', []) if node.get('range_response_method') == TRAVERSE_METHOD else []
    rows = {r[1]:r for r in node.get('response_receipts', []) if cutoff is None or _time(r[0]) <= _time(cutoff)}
    rows.update({r[1]:r for r in extra if cutoff is None or _time(r[0]) <= _time(cutoff)})
    return sorted(rows.values(), key=lambda r:(r[1],r[0]))


def opposite_boundary_origin(proof, origin, context):
    """A full incoming A must actually reach this container's opposite body.

    No percentage-of-old-trend size threshold: a range traversal is judged
    against its own two named boundaries. An inner wiggle cannot substitute.
    This is an operational relation, not an author-labelled major degree.
    """
    bars, positions, _, _, _ = context
    opposite = proof['range_low' if proof['boundary_role'] == 'range_high' else 'range_high']
    i, j = positions.get(origin), positions.get(opposite['pivot_timestamp_utc'])
    if i is None or j is None or origin < proof['from_utc']:
        return False
    a, boundary = bars[i], bars[j]
    return (proof['range_low']['price'] <= a['close'] <= proof['range_high']['price'] and
            a['low'] <= boundary['close'] <= a['high'])


def traverse_proofs(node, receipt, context, *, validated=None):
    """Bind a test/its own follow to ONE live container, at its known time."""
    proofs = validated if validated is not None else [p for p in node.get('range_boundary_reviews', [])
        if valid_range_review(node, p, context)]
    matches = []
    for p in proofs:
        known = max(receipt[0], p['known_at_utc'], key=_time)
        candidate = [known] + receipt[1:]
        if owns_range_test(node, p, candidate, context) and opposite_boundary_origin(p, receipt[5], context):
            matches.append((known, p['range_id']))
    return matches


def boundary_end(proof, context):
    bars, positions, duration, gaps, _ = context
    start = positions.get(proof['last_pivot_utc'])
    if start is None:
        return None
    pending = None
    iso = lambda t:t.isoformat().replace('+00:00', 'Z')
    low, high = proof['range_low']['price'], proof['range_high']['price']
    for i in range(start + 1, len(bars)):
        b = bars[i]
        if i in gaps:
            return dict(state='coverage_lost', bar_open_utc=b['timestamp_utc'],
                        known_at_utc=iso(_time(b['timestamp_utc']) + duration))
        side = 'above' if b['close'] > high else 'below' if b['close'] < low else None
        if side is None:
            pending = None
        elif pending is not None and pending[0] == side:
            cross = bars[pending[1]]
            if b['close'] > cross['high'] if side == 'above' else b['close'] < cross['low']:
                return dict(state='range_boundary_accepted_exit', side=side,
                    crossing_bar_open_utc=cross['timestamp_utc'], bar_open_utc=b['timestamp_utc'],
                    known_at_utc=iso(_time(b['timestamp_utc']) + duration))
        else:
            pending = side, i
    return None


def make_range_review(regime, scope, context, timeframe):
    high, low = regime['range_high'], regime['range_low']
    witnesses = regime['witnesses']
    proof = dict(method=METHOD, timeframe=timeframe,
        range_id=f"{timeframe}:range:{high['pivot_timestamp_utc']}:{low['pivot_timestamp_utc']}",
        range_high=high, range_low=low, witnesses=witnesses,
        from_utc=min(p['pivot_timestamp_utc'] for p in witnesses),
        last_pivot_utc=max(p['pivot_timestamp_utc'] for p in witnesses),
        known_at_utc=max([scope['known_at_utc']] + [p['confirmed_at_utc'] for p in witnesses], key=_time),
        source_wave_id=scope['source_leg_id'], ended_by=None,
        structural_degree_adjudicated=False, author_formula_verified=False)
    proof['ended_by'] = boundary_end(proof, context)
    return proof


def valid_range_review(node, proof, context):
    """Validate serialized boundaries against the available native prefix."""
    bars, positions, duration, gaps, cutoff = context
    try:
        if proof['method'] != METHOD or proof['timeframe'] != node['timeframe'] or _time(proof['known_at_utc']) > cutoff:
            return False
        high, low = proof['range_high'], proof['range_low']
        role = proof['boundary_role']
        point = high if role == 'range_high' else low if role == 'range_low' else None
        if point is None or point['pivot_timestamp_utc'] != node['origin_bar_open_utc'] or point['price'] != node['source_origin_extreme']:
            return False
        ws = proof['witnesses']
        highs = sorted((p for p in ws if p['kind'] == 'confirmed_swing_high_candidate'), key=lambda p:p['pivot_timestamp_utc'])
        lows = sorted((p for p in ws if p['kind'] == 'confirmed_swing_low_candidate'), key=lambda p:p['pivot_timestamp_utc'])
        if len(ws) != 4 or len(highs) != 2 or len(lows) != 2 or highs[0] != high or lows[0] != low:
            return False
        if not low['price'] < high['price'] or highs[1]['price'] > high['price'] or lows[1]['price'] < low['price']:
            return False
        if proof['from_utc'] != min(p['pivot_timestamp_utc'] for p in ws) or proof['last_pivot_utc'] != max(p['pivot_timestamp_utc'] for p in ws):
            return False
        for p in ws:
            i = positions.get(p['pivot_timestamp_utc'])
            if i is None or bars[i]['timeframe'] != node['timeframe']:
                return False
            extreme = bars[i]['high' if p['kind'] == 'confirmed_swing_high_candidate' else 'low']
            if p['price'] != extreme or _time(p['confirmed_at_utc']) > _time(proof['known_at_utc']) or _time(p['confirmed_at_utc']) < _time(p['pivot_timestamp_utc']) + duration:
                return False
        first, last = positions[proof['from_utc']], positions[proof['last_pivot_utc']]
        if any(first < i <= last for i in gaps):
            return False
        stored = proof['ended_by']
        visible = stored if stored and _time(stored['known_at_utc']) <= cutoff else None
        return visible == boundary_end(proof, context)
    except (KeyError, TypeError, ValueError):
        return False


def owns_range_test(node, proof, receipt, context):
    bars, positions, duration, _, cutoff = context
    side = 'below' if proof['boundary_role'] == 'range_high' else 'above'
    if receipt[3] != side or receipt[5] < proof['from_utc']:
        return False
    origin = positions.get(receipt[5])
    follow = positions.get(receipt[2])
    if origin is None or follow is None or not proof['range_low']['price'] <= bars[origin]['close'] <= proof['range_high']['price']:
        return False
    known = max(proof['known_at_utc'], receipt[0], key=_time)
    if _time(known) > cutoff or _time(receipt[2]) + duration > _time(receipt[0]):
        return False
    end = proof['ended_by']
    # This uses the exit only when it happened, never to erase an earlier
    # valid qualification. Confirmation after exit cannot be backdated.
    return not end or _time(known) < _time(end['known_at_utc'])
