"""Causal numerical indicators, not author adjudications or trading signals.

MetaQuotes' ratio-of-sums slowing is deliberately separate from the legacy
SMA-of-ratios extractor. Strict neighbouring turns are an explicit engineering
measurement, NOT jrcMOD Fractals (8/25). All dependencies retain their clocks.
"""
from copy import deepcopy
from datetime import datetime, timedelta
import math

from .build_elasticity_observation_dataset import stochastic_series

VERSION = 'gobi_digger_process_indicators_v4'
WINDOW = 96  # bounded diagnostic history, not an author lookback or entry rule
TASK_WINDOW = 2048  # independent native task-anchor calculation budget
SOURCES = {
    'metaquotes_stoch': 'https://www.mql5.com/en/code/7792',
    'ghbdr_closed_k_and_h4': 'https://www.forexfactory.com/thread/973872-d1-elasticity-pullback-trading?page=3',
    'digger_close_location_path': 'https://www.metalsmine.com/thread/930946-aussi-my-thread-and-anything-i-want-to?page=980',
    'digger_hold_next': 'https://www.metalsmine.com/thread/930946-aussi-my-thread-and-anything-i-want-to?page=1613',
}


def _time(value):
    t = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if t.tzinfo is None:
        raise ValueError('aware_clock_required')
    return t


def _known(rows):
    return max((r['known_at_utc'] for r in rows), key=_time) if rows else None


def metaquotes_stochastic(rows, width, slowing=3, d_period=3):
    """Official low/high ratio-of-sums formula; warmup is None, never fake zero."""
    numerators, denominators, k = [], [], []
    for i, row in enumerate(rows):
        if i < width - 1:
            numerators.append(None); denominators.append(None); k.append(None)
            continue
        window = rows[i-width+1:i+1]
        low = min(r['low'] for r in window); high = max(r['high'] for r in window)
        numerators.append(row['close']-low); denominators.append(high-low)
        if i < width+slowing-2:
            k.append(None)
        else:
            denominator = sum(denominators[i-slowing+1:i+1])
            k.append(100.0 if denominator == 0 else 100*sum(numerators[i-slowing+1:i+1])/denominator)
    output = []
    for i, value in enumerate(k):
        values = k[max(0, i-d_period+1):i+1]
        d = sum(values)/d_period if len(values)==d_period and all(v is not None for v in values) else None
        output.append(dict(k=value, d=d))
    return output


def _sign(value):
    return 1 if value > 0 else -1 if value < 0 else 0


def _turns(rows, values, kind):
    turns = [];availability=[];known=None
    for row in rows:
        known=max([known,row['known_at_utc']],key=_time) if known else row['known_at_utc']
        availability.append(known)
    for i in range(1, len(rows)-1):
        a, b, c = values[i-1:i+2]
        if any(v is None for v in (a,b,c)):
            continue
        if (b < a and b < c) if kind=='low' else (b > a and b > c):
            turns.append(dict(index=i, value=b, pivot_bar_utc=rows[i]['timestamp_utc'],
                confirmation_bar_utc=rows[i+1]['timestamp_utc'], known_at_utc=availability[i+1]))
    return turns


def _last_pair(turns):
    pair = turns[-2:]
    return dict(points=pair, delta=pair[1]['value']-pair[0]['value'] if len(pair)==2 else None,
                relation=('higher' if pair[1]['value']>pair[0]['value'] else 'lower'
                          if pair[1]['value']<pair[0]['value'] else 'equal') if len(pair)==2 else 'unknown')


def gobi_frame(rows, tf, minutes, history_limit=WINDOW):
    from .gobi_fractal_observations import build as build_fractal_observations
    fast = metaquotes_stochastic(rows, 5); slow = metaquotes_stochastic(rows, 14)
    legacy_fast = stochastic_series(rows, 5, 3, 3); legacy_slow = stochastic_series(rows, 14, 3, 3)
    series = [];known=None
    for i, row in enumerate(rows):
        f, s = fast[i]['k'], slow[i]['k']
        previous = series[-1] if series else None
        gap = f-s if f is not None and s is not None else None
        old_gap = previous['signed_gap'] if previous else None
        gap_delta = abs(gap)-abs(old_gap) if gap is not None and old_gap is not None else None
        known=max([known,row['known_at_utc']],key=_time) if known else row['known_at_utc']
        series.append(dict(bar_open_utc=row['timestamp_utc'], closed_at_utc=row['closed_at_utc'],
            # Conservative prefix availability includes all historical dependencies.
            known_at_utc=known, fast_k=f, slow_k=s,
            fast_d=fast[i]['d'], slow_d=slow[i]['d'], signed_gap=gap,
            absolute_gap=abs(gap) if gap is not None else None,
            absolute_gap_change=gap_delta,
            separation_change='unknown' if gap_delta is None else 'widening' if gap_delta>0 else
                              'narrowing' if gap_delta<0 else 'unchanged',
            fast_k_change=f-previous['fast_k'] if previous and f is not None and previous['fast_k'] is not None else None,
            slow_k_change=s-previous['slow_k'] if previous and s is not None and previous['slow_k'] is not None else None,
            side_changed=(_sign(gap)!=_sign(old_gap)) if gap is not None and old_gap is not None else None,
            legacy_fast_k_difference=f-legacy_fast[i]['k'] if f is not None else None,
            legacy_slow_k_difference=s-legacy_slow[i]['k'] if s is not None else None))
    price_lows = _turns(rows, [r['low'] for r in rows], 'low')
    price_highs = _turns(rows, [r['high'] for r in rows], 'high')
    pairs = dict(price_lows=_last_pair(price_lows), price_highs=_last_pair(price_highs),
        fast_lows=_last_pair(_turns(rows, [r['k'] for r in fast], 'low')),
        slow_lows=_last_pair(_turns(rows, [r['k'] for r in slow], 'low')))
    divergences = []
    # Oscillator measured at the SAME price pivots; no nearest-time substitution.
    for kind, turns in [('low',price_lows), ('high',price_highs)]:
        for a,b in zip(turns, turns[1:]):
            for name,values in [('fast_5_3_3',fast), ('slow_14_3_3',slow)]:
                ka,kb = values[a['index']]['k'],values[b['index']]['k']
                if ka is None or kb is None:
                    continue
                dp, dk = b['value']-a['value'], kb-ka
                if dp*dk < 0:
                    label = ('regular_bullish' if dp<0 else 'hidden_bullish') if kind=='low' else (
                        'regular_bearish' if dp>0 else 'hidden_bearish')
                    divergences.append(dict(kind=label, oscillator=name, price_pivots=[a,b],
                        oscillator_values_at_price_pivots=[ka,kb], known_at_utc=b['known_at_utc'],
                        confirmation='strict_one_closed_neighbour_engineering_not_author_fractal'))
    latest = series[-1] if series else None
    h4 = dict(source='ghbdr_closed_k_and_h4', source_post=52, scope='H4_bullish_preference_only',
              threshold=23.6, short_mirror_inferred=False, status='not_applicable')
    if tf=='H4':
        checks = {name: None if pairs[name]['relation']=='unknown' else pairs[name]['relation']=='higher'
                  for name in ('price_lows','fast_lows','slow_lows')}
        checks['both_k_above_23_6'] = (latest['fast_k']>23.6 and latest['slow_k']>23.6
            if latest and latest['fast_k'] is not None and latest['slow_k'] is not None else None)
        h4.update(checks=checks, status='insufficient_history' if None in checks.values() else
                  'numerical_preference_observed' if all(checks.values()) else 'numerical_preference_not_met',
                  pivot_alignment='independent_latest_pairs_not_shared_structure_owner',
                  known_at_utc=_known(rows))
    gaps = [dict(left=left['timestamp_utc'],right=right['timestamp_utc']) for left,right in zip(rows, rows[1:])
            if _time(right['timestamp_utc'])-_time(left['timestamp_utc']) != timedelta(minutes=minutes)]
    return dict(native_timeframe=tf, calculation='metaquotes_low_high_ratio_of_sums_slowing_sma_d',
        source='metaquotes_stoch', author_attachment_parity='unverified',
        warmup_policy='unknown_until_complete_support', zero_denominator_policy='100_as_official_source',
        history_limit=history_limit, input_bars=deepcopy(rows), series=series, latest=latest,
        turn_definition='strict_one_left_one_right_closed_bar_project_measurement',
        turning_pairs=pairs, divergence_observations=divergences, h4_source_preference=h4,
        timestamp_discontinuities=gaps, gap_interpretation='calendar_or_missing_data_unresolved',
        author_elasticity_sufficiency='unknown', author_fractal_8_25='unknown',
        fractal_variant_observations=build_fractal_observations(rows,tf,minutes),
        parent_acceptance='unknown', entry_permission=False)


def level_process(level, rows):
    eligible = [r for r in rows if _time(r['timestamp_utc'])>=_time(level['known_at_utc'])]
    events, sides, last_cross, first_touch = [], [], None, None
    for i,row in enumerate(eligible):
        side = _sign(row['close']-level['price']); previous = sides[-1] if sides else None
        touch = row['low']<=level['price']<=row['high']
        cross = previous not in (None,0) and side not in (0,previous)
        kind = None
        if cross:
            kind = 'close_cross'
            if last_cross is not None and side==last_cross['from_side']:
                kind = 'close_return_after_cross'
            last_cross = dict(from_side=previous,to_side=side)
        elif touch:
            kind = 'touch_close_on_level' if side==0 else 'probe_closed_on_prior_side' if side==previous else 'touch'
        if touch and first_touch is None:
            first_touch=i
        if kind:
            events.append(dict(kind=kind,bar_open_utc=row['timestamp_utc'],closed_at_utc=row['closed_at_utc'],
                known_at_utc=max([level['known_at_utc'],_known(eligible[:i+1])],key=_time),
                close_side=side,previous_close_side=previous,touches=touch,
                source_ohlc={k:row[k] for k in ('open','high','low','close')},
                intrabar_order='unknown', author_hold_fold='unknown'))
        sides.append(side)
    streak=0
    for side in reversed(sides):
        if side==0 or side!=sides[-1]:break
        streak+=1
    return dict(object_id=level['object_id'],native_timeframe=level['native_timeframe'],price=level['price'],
        line_known_at_utc=level['known_at_utc'],events=events,
        current_close_side=sides[-1] if sides else None,consecutive_closes_on_current_side=streak,
        first_observed_touch_utc=eligible[first_touch]['timestamp_utc'] if first_touch is not None else None,
        closed_bars_after_first_observed_touch=len(eligible)-1-first_touch if first_touch is not None else None,
        window_start_utc=eligible[0]['timestamp_utc'] if eligible else None,
        observation_left_censored=True,author_first_attempt_identified=False,
        author_hold_state='unknown',author_fold_state='unknown',entry_permission=False)


def digger_map(levels, rows, tf, minutes):
    processes = [level_process(l,rows) for l in levels]
    latest = rows[-1] if rows else None
    neighbours = dict(above=[],below=[],at=[])
    tr = [max(b['high']-b['low'],abs(b['high']-a['close']),abs(b['low']-a['close']))
          for a,b in zip(rows,rows[1:])]
    scale = sum(tr[-14:])/14 if len(tr)>=14 else None
    if latest:
        # Only objects available before this last bar opened may join its map.
        for level in levels:
            if _time(level['known_at_utc'])>_time(latest['timestamp_utc']):continue
            delta=level['price']-latest['close']
            name='above' if delta>0 else 'below' if delta<0 else 'at'
            neighbours[name].append(dict(object_id=level['object_id'],native_timeframe=level['native_timeframe'],
                source_id=level['source_id'],source_claim_ids=deepcopy(level['source_claim_ids']),
                price=level['price'],distance_price=abs(delta),
                distance_mean_true_range_14=abs(delta)/scale if scale else None,
                known_at_utc=level['known_at_utc']))
    for side in neighbours:
        neighbours[side].sort(key=lambda x:(x['distance_price'],x['object_id']))
    nearest = {side:[x for x in items if x['distance_price']==items[0]['distance_price']] if items else []
               for side,items in neighbours.items()}
    velocity=None
    if latest:
        baseline=sum(tr[-15:-1])/14 if len(tr)>=15 else None
        velocity=dict(bar_open_utc=latest['timestamp_utc'],known_at_utc=_known(rows),
            body_price_per_minute=abs(latest['close']-latest['open'])/minutes,
            range_price_per_minute=(latest['high']-latest['low'])/minutes,
            true_range_vs_prior_14=tr[-1]/baseline if baseline else None,
            prior_mean_true_range_14=baseline,session_regime='unknown',indicator_lag_risk='unknown')
    return dict(interaction_timeframe=tf,input_bars=deepcopy(rows),level_processes=processes,
        geometric_neighbours=nearest,reference_close=latest['close'] if latest else None,
        reference_bar_utc=latest['timestamp_utc'] if latest else None,mean_true_range_14=scale,
        velocity=velocity,author_next_in_line_object_id=None,
        map_scope='mapped_period_opens_only_not_complete_author_map',
        neighbours_role='geometric_candidates_not_ranked_targets',entry_permission=False)


def build_indicators(periods, levels, chart_timeframe, minutes):
    frames={tf:gobi_frame(rows[-WINDOW:],tf,minutes[tf]) for tf,rows in periods.items() if rows and tf in minutes}
    chart_rows=periods.get(chart_timeframe,[])[-WINDOW:]
    return dict(schema=VERSION,source_claims=deepcopy(SOURCES),gobi=frames,
        task_frame=(gobi_frame(periods[chart_timeframe][-TASK_WINDOW:],chart_timeframe,minutes[chart_timeframe],TASK_WINDOW)
                    if periods.get(chart_timeframe) else None),
        digger=digger_map(levels,chart_rows,chart_timeframe,minutes[chart_timeframe]),
        author_semantics_complete=False,read_only=True,automatic_trade_permission=False,future_bars_used=False)


def verify_indicators(packet, native_minutes):
    """Recompute all derived fields; a re-signed hash cannot authenticate numbers."""
    raw=packet.get('process_indicators')
    if raw is None:
        return []  # historical v1 receipts remain readable and explicitly lack this layer
    try:
        cutoff=_time(packet['as_of_utc']); periods={}
        for tf,frame in raw['gobi'].items():
            rows=frame['input_bars'];previous=None
            if tf not in native_minutes or len(rows)>WINDOW or not rows:raise ValueError('frame')
            for row in rows:
                start,end,known=(_time(row[k]) for k in ('timestamp_utc','closed_at_utc','known_at_utc'))
                if not (end==start+timedelta(minutes=native_minutes[tf]) and end<=known<=cutoff):raise ValueError('clock')
                if previous is not None and start<=previous:raise ValueError('order')
                prices=[row[k] for k in ('low','open','close','high')]
                if not all(math.isfinite(v) for v in prices) or not prices[0]<=min(prices[1:3])<=max(prices[1:3])<=prices[3]:
                    raise ValueError('ohlc')
                previous=start
            if rows[-19:]!=packet['gobi_observations'][tf]['input_bars']:raise ValueError('tail_identity')
            periods[tf]=rows
        if set(periods)!=set(packet['gobi_observations']):raise ValueError('period_identity')
        task_frame=raw.get('task_frame')
        if task_frame:
            tf=task_frame['native_timeframe'];rows=task_frame['input_bars']
            if tf!=packet['chart_timeframe'] or len(rows)>TASK_WINDOW or rows[-WINDOW:]!=periods.get(tf):raise ValueError('task_frame_tail')
            previous=None
            for row in rows:
                start,end,known=(_time(row[k]) for k in ('timestamp_utc','closed_at_utc','known_at_utc'))
                if not end==start+timedelta(minutes=native_minutes[tf]) or not end<=known<=cutoff:raise ValueError('task_clock')
                if previous is not None and start<=previous:raise ValueError('task_order')
                values=[row[k] for k in ('low','open','close','high')]
                if not all(math.isfinite(v) for v in values) or not values[0]<=min(values[1:3])<=max(values[1:3])<=values[3]:raise ValueError('task_prices')
                previous=start
            periods[tf]=rows
        expected=build_indicators(periods,packet['digger_context']['mapped_objects'],packet['chart_timeframe'],native_minutes)
        if raw.get('schema')=='gobi_digger_process_indicators_v3':
            for f in list(expected['gobi'].values())+([expected['task_frame']] if expected.get('task_frame') else []):
                f['fractal_variant_observations']={k:v for k,v in f['fractal_variant_observations'].items() if not k.startswith('ghbdr_2018:')}
            expected['schema']=raw['schema']
        if raw.get('schema') in ('gobi_digger_process_indicators_v1','gobi_digger_process_indicators_v2'):
            for f in expected['gobi'].values():f.pop('fractal_variant_observations',None)
            if expected.get('task_frame'):expected['task_frame'].pop('fractal_variant_observations',None)
            if raw['schema']=='gobi_digger_process_indicators_v1':expected.pop('task_frame',None)
            expected['schema']=raw['schema']
        if expected!=raw:raise ValueError('derived_value')
    except (ValueError,TypeError,KeyError,IndexError,OverflowError):
        return ['process_indicators_source_or_recomputation_invalid']
    return []
