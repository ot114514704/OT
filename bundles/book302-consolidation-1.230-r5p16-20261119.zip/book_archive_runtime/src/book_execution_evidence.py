"""Freeze the actual candidate's evidence across arbitration, risk and paper ledger.

This is an engineering provenance contract, not author wave adjudication or
a trading permission. Its digest detects content drift, not authenticity.
"""
from copy import deepcopy
from hashlib import sha256
import json
from .book_first_response_leg import clock


BOOK_FIELDS = ('turning_point_line', 'turning_boundary', 'first_closed_break',
    'parallel_break', 'first_response_leg', 'stop_reference', 'trend_change',
    'setup_qualification', 'boundary_breakout_assessment', 'execution_context_factors',
    'progressive_period_context','one_to_one_native_observation')


def _decision_body(decision):
    # Arbitration may identify the current chart without changing the native
    # candidate. Every other decision field is part of the frozen contract.
    return {k: v for k, v in decision.items() if k not in ('execution_evidence', 'source_selection')}


def _digest(body):
    return sha256(json.dumps(body, sort_keys=True, separators=(',', ':'),
                             ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()


def freeze_execution_evidence(book, decision, policy):
    body = dict(schema='book_execution_evidence_v1', state='bound_paper_candidate',
        timeframe=decision['timeframe'], as_of_utc=decision['as_of_utc'],
        phase_id=decision['phase_id'], boundary_pair_id=decision['boundary_pair_id'],
        source_id=decision['signal']['source_id'],
        decision=deepcopy(_decision_body(decision)), policy=deepcopy(policy),
        native_book={k: deepcopy(book.get(k) or {}) for k in BOOK_FIELDS},
        automatic_trade_permission=False, order_api_called=False,
        author_membership_verified=False)
    return dict(body, evidence_id='book_execution_evidence:'+_digest(body))


def validate_execution_evidence(decision):
    """Return a stable reason on drift/mismatch; never borrow chart evidence."""
    evidence = decision.get('execution_evidence')
    if not isinstance(evidence, dict):return 'execution_evidence_missing'
    try:
        if (evidence.get('schema') != 'book_execution_evidence_v1' or
                evidence.get('state') != 'bound_paper_candidate'):
            return 'execution_evidence_schema_invalid'
        body = {k: v for k, v in evidence.items() if k != 'evidence_id'}
        if evidence.get('evidence_id') != 'book_execution_evidence:'+_digest(body):
            return 'execution_evidence_content_changed'
        if evidence['decision'] != _decision_body(decision):
            return 'execution_decision_changed_after_evidence_freeze'
        if (evidence.get('automatic_trade_permission') is not False or
                evidence.get('order_api_called') is not False or
                decision.get('automatic_trade_permission') is not False or
                decision.get('live_order_permission') is not False):
            return 'execution_evidence_permission_mismatch'
        signal=decision['signal'];book=evidence['native_book'];policy=evidence['policy']
        scores=book['boundary_breakout_assessment'];response=book['first_response_leg']
        setup=book['setup_qualification'];freeze=setup['boundary_A_freeze']
        if (policy.get('mode')!='paper' or policy.get('id')!=decision.get('policy_id') or
                policy.get('branch')!=decision.get('branch')):
            return 'execution_policy_binding_mismatch'
        if not decision.get('paper_candidate') or decision.get('status')!='entry_candidate':
            return 'execution_evidence_requires_candidate'
        if policy.get('contextual_score_requirement') is not None:
            from .book_composite_assessment import contextual_requirement
            from .book_one_to_one_context import requirement as one_to_one_requirement
            card=decision.get('position_scorecard') or {}
            if (card.get('phase_id')!=decision.get('phase_id') or
                    card.get('source_id')!=signal.get('source_id') or
                    card.get('timeframe')!=decision.get('timeframe') or
                    card.get('as_of_utc')!=decision.get('as_of_utc')):
                return 'execution_contextual_scorecard_identity_mismatch'
            gate=contextual_requirement(card,policy['contextual_score_requirement'],
                one_to_one_mode=one_to_one_requirement(policy))
            if gate['state']!='satisfied' or decision.get('contextual_score_gate')!=gate:
                return 'execution_contextual_requirement_not_reproduced'
        for key in ('phase_id','boundary_pair_id'):
            if not evidence.get(key) or any(x.get(key)!=evidence[key] for x in (decision,signal,scores)):
                return 'execution_'+key+'_mismatch'
        if (evidence['source_id']!=signal['source_id'] or response['source_id']!=signal['source_id'] or
                response['source_wave_id']!=book['turning_point_line'].get('wave_id')):
            return 'execution_response_identity_mismatch'
        if (signal['stop']!=response['origin_B']['point'][1] or
                signal['stop']!=book['stop_reference'].get('reference_price') or
                signal['target']!=response['terminal_C']['point'][1] or
                policy.get('target_mode')!='source_C'):
            return 'execution_B_C_price_mismatch'
        if (freeze.get('status')!='frozen_before_first_boundary' or
                not setup.get('both_boundaries_broken') or
                not setup.get('conditions',{}).get('boundary_A_broken')):
            return 'execution_A_or_dual_setup_mismatch'
        for key in ('provider','symbol'):
            if signal.get(key)!=scores.get(key):return 'execution_market_mismatch'
        if (evidence['timeframe']!=decision['timeframe'] or signal['timeframe']!=decision['timeframe'] or
                response['timeframe']!=decision['timeframe'] or evidence['as_of_utc']!=decision['as_of_utc']):
            return 'execution_timeframe_or_cutoff_mismatch'
        if any(clock(t)>clock(decision['as_of_utc']) for t in
               [response['known_at_utc'],signal['known_at_utc'],setup['dual_known_at_utc'],
                *(v['known_at_utc'] for v in scores['boundaries'].values())]):
            return 'execution_dependency_after_cutoff'
    except (KeyError,TypeError,ValueError,OverflowError):
        return 'execution_evidence_incomplete'
    return None


def validate_request_evidence(request):
    evidence=request.get('execution_evidence')
    if not isinstance(evidence,dict):return 'execution_evidence_missing'
    decision=dict(evidence.get('decision') or {},execution_evidence=evidence)
    reason=validate_execution_evidence(decision)
    if reason:return reason
    signal=decision['signal']
    mapping=dict(signal_id='id',entry_cycle_id='entry_cycle_id',phase_id='phase_id',
                 provider='provider',symbol='symbol',stop='stop',target='target',
                 protection_source='protection_source',protection_mode='protection_mode')
    if any(request.get(k)!=signal.get(v) for k,v in mapping.items()):
        return 'request_differs_from_frozen_execution_source'
    if (request.get('side')!=('buy' if signal['direction']=='up' else 'sell') or
            request.get('decision_as_of_utc')!=decision['as_of_utc']):
        return 'request_direction_or_decision_clock_mismatch'
    return None
