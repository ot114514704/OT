"""Stage-specific, source-bound composite measurements and execution readout.

Equal-family harmonic aggregation is an explicit engineering baseline. It
is neither a fitted probability nor permission to bypass the Book/risk gates.
Correlated body/momentum and pullback/gross-space do not get duplicate votes.
"""
from math import isfinite
from copy import deepcopy
from .book_first_response_leg import clock

FAMILIES={
    'geometry':['outer_geometry','turning_geometry'],
    'initial_break':['outer_breakout','turning_breakout'],
    'current_boundary':['outer_hold','turning_hold'],
    'directional_motion':['directional_efficiency_8'],
    'pullback_location':['pullback_zone'],
    'source_force':['source_BC_force']}
STAGES={
    'breakout_observation':['geometry','initial_break','current_boundary','directional_motion'],
    'pullback_observation':['geometry','current_boundary','pullback_location','source_force'],
    'entry_review':['geometry','current_boundary','pullback_location','source_force','directional_motion']}


def numeric(v):return not isinstance(v,bool) and isinstance(v,(int,float)) and isfinite(v) and 0<=v<=100


def harmonic(values):
    if not values:return None
    return 0. if any(v==0 for v in values) else len(values)/sum(1/v for v in values)


def combine_groups(groups,required):
    available={k:groups[k]['score'] for k in required if numeric(groups[k].get('score'))}
    missing=[k for k in required if k not in available]
    scores=list(available.values())
    return dict(state='complete_measurement' if not missing else 'incomplete',
        score=round(harmonic(scores),6) if not missing else None,
        missing=missing,coverage=dict(measured=len(scores),required=len(required)),
        bounds=dict(lower=0. if missing else round(harmonic(scores),6),
            upper=round(harmonic(scores+[100.]*len(missing)),6)),
        groups=deepcopy({k:groups[k] for k in required}),
        formula='equal_family_harmonic_mean; min_inside_same_family',
        weights={k:1/len(required) for k in required},calibration='unfitted_engineering_baseline',
        is_probability=False,entry_permission=False)


CONTEXT_MEMBERS=('one_to_one','one_to_one_delivery','native_scope_bottleneck')


def contextual_fusion(card,members=CONTEXT_MEMBERS):
    """One causal structure reading; dependent measurements never add votes.

    Local 1:1 delivery is selectable separately from larger-node acceptance.
    A numeric parent measurement whose membership is not admitted remains
    unavailable, just as in check_position_score_requirements.
    """
    measured=[];missing=[];failures={}
    for name in members:
        factor=(card.get('factors') or {}).get(name) or {}
        reason=None
        try:
            valid=(not card.get('reason') and not card.get('vetoes') and
                bool(card.get('phase_id')) and bool(card.get('source_id')) and
                factor.get('state')=='measured' and numeric(factor.get('score')) and
                factor.get('phase_id')==card['phase_id'] and
                factor.get('source_id')==card['source_id'] and
                clock(factor['known_at_utc'])<=clock(card['as_of_utc']))
            if name=='native_scope_bottleneck' and (factor.get('raw') or {}).get('eligible_for_score_gate') is not True:
                valid=False;reason='native_scope_not_eligible'
        except (KeyError,TypeError,ValueError,OverflowError):
            valid=False
        if valid:
            measured.append(dict(name=name,score=float(factor['score']),
                known_at_utc=factor['known_at_utc']))
        else:
            missing.append(name);failures[name]=reason or 'missing_or_unbound_measurement'
    return dict(schema='book_contextual_structure_fusion_v1',
        state='measured' if not missing else 'unknown',
        score=round(min(row['score'] for row in measured),6) if not missing else None,
        phase_id=card.get('phase_id'),source_id=card.get('source_id'),
        timeframe=card.get('timeframe'),as_of_utc=card.get('as_of_utc'),
        known_at_utc=max((row['known_at_utc'] for row in measured),key=clock) if not missing else None,
        required=list(members),members=measured,missing=missing,failures=failures,
        formula='minimum_of_explicit_same_source_context_members; missing stays unknown',
        score_is_probability=False,independent_vote=False,
        affects_directional_active_score=False,automatic_trade_permission=False,
        policy_gate='contextual_score_requirement')


def contextual_requirement(card,requirement,*,one_to_one_mode=None):
    """Explicit paper-policy AND gate; no implicit threshold or parent vote."""
    base=dict(schema='book_contextual_gate_v1',automatic_trade_permission=False,
        may_override_other_entry_gates=False,threshold_basis='explicit_unfitted_paper_research')
    def result(state,reason,**facts):return dict(base,state=state,reason=reason,**facts)
    if requirement is None:return result('not_requested',None)
    if not isinstance(requirement,dict) or set(requirement)!={'members','minimum'}:
        return result('invalid_policy','explicit_context_members_and_minimum_required')
    names=requirement['members'];minimum=requirement['minimum']
    if (not isinstance(names,list) or not names or
            any(not isinstance(n,str) or n not in CONTEXT_MEMBERS for n in names) or
            len(set(names))!=len(names) or not numeric(minimum)):
        return result('invalid_policy','invalid_context_members_or_minimum')
    if any(n.startswith('one_to_one') for n in names) and one_to_one_mode!='same_source_developing_reference':
        return result('invalid_policy','explicit_developing_one_to_one_binding_required')
    reading=contextual_fusion(card,tuple(names))
    facts=dict(requirement=deepcopy(requirement),reading=reading)
    if card.get('reason') or card.get('vetoes'):
        return result('wait','context_source_or_upstream_veto',**facts)
    if reading['state']!='measured':return result('wait','required_context_members_incomplete',**facts)
    if reading['score']<minimum:return result('wait','below_explicit_contextual_minimum',**facts)
    return result('satisfied',None,**facts)


def composite_assessment(card,decision_status,decision_reason,setup=None):
    base=dict(schema='book_composite_assessment_v1',timeframe=card.get('timeframe'),as_of_utc=card.get('as_of_utc'),
        phase_id=card.get('phase_id'),boundary_pair_id=card.get('boundary_pair_id'),source_id=card.get('source_id'),
        source_identity=deepcopy(card.get('source_identity')),position_price=card.get('position_price'),
        position_stage=card.get('stage'),upstream_decision_status=decision_status,
        upstream_decision_reason=decision_reason,automatic_trade_permission=False,entry_permission=False,
        calibrated_probability=None,model_status='no_accepted_joint_probability_model',
        conflicts=deepcopy(card.get('conflicts') or []),vetoes=deepcopy(card.get('vetoes') or []),
        excluded_duplicate_votes=['directional_body_8','gross_target_space'],
        context_only=['path_cleanliness_8','range_stability_8','one_to_one','one_to_one_delivery','parent_alignment','quote_risk',
                      'native_source_wave_force','native_parent_wave_force','native_scope_bottleneck'],
        native_wave_scope={k:deepcopy(v) for k,v in (card.get('native_wave_process') or {}).items() if k!='recognition'},
        stages={},groups={})
    factors=card.get('factors') or {};groups={}
    for family,names in FAMILIES.items():
        values=[];missing=[]
        for name in names:
            f=factors.get(name) or {}
            try:
                valid=(not card.get('reason') and f.get('state')=='measured' and numeric(f.get('score')) and
                    f.get('phase_id')==card.get('phase_id') and bool(card.get('phase_id')) and
                    f.get('source_id')==card.get('source_id') and clock(f['known_at_utc'])<=clock(card['as_of_utc']))
            except (KeyError,ValueError,TypeError):valid=False
            if valid:values.append(float(f['score']))
            else:missing.append(name)
        groups[family]=dict(score=min(values) if not missing else None,members=names,missing=missing,
            formula='minimum_of_source_bound_members',reason='missing_or_unbound_members' if missing else None)
    base['groups']=groups;base['stages']={stage:combine_groups(groups,names) for stage,names in STAGES.items()}
    # Contextual structure is a separate weakest-link reading.  It is
    # deliberately excluded from the directional entry score because 1:1,
    # parent scope and three-push observations share the same structural
    # task and are not independent votes.  Keeping the fusion here makes the
    # measured context consumable by an explicit policy without silently
    # treating a missing context as zero or changing the main score.
    base['contextual_fusion']=contextual_fusion(card)
    position=card.get('stage')
    stage=('entry_review' if decision_status=='entry_candidate' else 'pullback_observation'
        if position in ('pullback_in_book_zone','outside_book_pullback_zone') else 'breakout_observation')
    terminal=decision_status in ('invalidated','completed','expired','ambiguous') or bool(base['vetoes'])
    if terminal:base['vetoes'].append('upstream_terminal_or_source_veto')
    if (setup or {}).get('status')=='stop_breached':base['vetoes'].append('original_B_breached')
    base.update(active_stage=stage,active_score=base['stages'][stage]['score'],
        measurement_state=base['stages'][stage]['state'],
        admission='terminal' if terminal else 'pending_quote_and_risk' if decision_status=='entry_candidate' else 'waiting_upstream_conditions',
        all_scores_are_descriptive=True)
    return base


def composite_requirement(assessment,requirement):
    result=dict(schema='book_composite_gate_v1',automatic_trade_permission=False)
    if requirement is None:return dict(result,state='not_requested',reason=None)
    if not isinstance(requirement,dict) or set(requirement)!={'stage','minimum'}:
        return dict(result,state='invalid_policy',reason='explicit_stage_and_minimum_required')
    stage= requirement['stage'];minimum=requirement['minimum']
    if stage!='entry_review' or not numeric(minimum):
        return dict(result,state='invalid_policy',reason='entry_review_and_valid_minimum_required')
    reading=assessment['stages'][stage]
    if assessment['vetoes']:return dict(result,state='wait',reason='source_or_upstream_veto')
    if reading['state']!='complete_measurement':return dict(result,state='wait',reason='required_stage_groups_incomplete')
    if reading['score']<minimum:return dict(result,state='wait',reason='below_explicit_composite_minimum')
    return dict(result,state='satisfied',reason=None,minimum=minimum,score=reading['score'],
        threshold_basis='explicit_unfitted_paper_research_not_learned_cutoff')


def quote_composite(decision,request,quote,limits,now):
    """Called ONLY after prepare_intent passed its native quote/risk checks.

    Post-quote evidence stays separate from the frozen closed-bar evidence.
    No price measurement changes the stop, volume, target or ledger policy.
    """
    source=decision.get('composite_assessment') or {}
    base=dict(schema='book_quote_composite_v1',as_of_utc=now,closed_as_of_utc=decision.get('as_of_utc'),
        phase_id=decision.get('phase_id'),boundary_pair_id=decision.get('boundary_pair_id'),
        source_id=(decision.get('signal') or {}).get('source_id'),
        evidence_id=(decision.get('execution_evidence') or {}).get('evidence_id'),
        quote_id=quote.get('id'),quote_timestamp_utc=quote.get('timestamp_utc'),
        account_id=quote.get('account_id'),automatic_trade_permission=False,entry_permission=False,
        closed_composite=deepcopy(source),order_state='risk_prepared_pending_ledger',probability=None)
    try:
        risk=request['risk_cash']/request['volume'];costs=request['commission_cash_per_lot']+request['slippage_ticks']*request['tick_value_loss']
        spread=(quote['ask']-quote['bid'])/request['tick_size']*request['tick_value_loss']
        age=(clock(now)-clock(quote['timestamp_utc'])).total_seconds()
        rr=request['net_rr'];clamp=lambda v:max(0.,min(100.,v))
        factors=dict(net_reward_share=100*rr/(1+rr),cost_retention=clamp(100*(1-costs/risk)),
            spread_retention=clamp(100*(1-spread/risk)),freshness=clamp(100*(1-age/limits['max_quote_age_seconds'])))
        groups=dict(closed_entry=dict(score=(source.get('stages') or {}).get('entry_review',{}).get('score')),
            economics=dict(score=min(factors[k] for k in ('net_reward_share','cost_retention','spread_retention'))),
            freshness=dict(score=factors['freshness']))
        return dict(base,state='observed',factors=factors,composite=combine_groups(groups,list(groups)),
            raw=dict(net_rr=rr,cost_cash_per_lot=costs,spread_cash_per_lot=spread,quote_age_seconds=age,
                risk_cash=request['risk_cash'],volume=request['volume'],risk_budget=limits['risk_cash']),
            formula_basis='descriptive_policy_headroom_not_fill_probability; economics_family_not_three_votes')
    except (KeyError,ValueError,TypeError,ZeroDivisionError):return dict(base,state='unknown',reason='incomplete_prepared_request')


def chain_observation(decision,execution,position_view,previous=None):
    composite=decision.get('composite_assessment') or {};positions=(position_view or {}).get('positions') or []
    status=execution.get('ledger_result') or execution.get('status')
    active=[p for p in positions if p.get('status')=='open']
    closed=execution.get('positions_closed') or []
    state=('position_management' if active else 'position_closed' if closed else 'risk_prepared' if execution.get('status')=='prepared'
        else 'execution_blocked' if execution.get('status')=='blocked' else decision.get('status','unknown'))
    if (position_view or {}).get('status')=='unknown_ledger_ahead_of_requested_clock':state='position_state_unknown'
    same=bool(previous and all(previous.get(k)==decision.get(k) for k in ('phase_id','boundary_pair_id')) and
        previous.get('source_id')==composite.get('source_id') and previous.get('active_stage')==composite.get('active_stage'))
    prior=previous.get('active_score') if same else None;score=composite.get('active_score')
    return dict(schema='book_composite_chain_v1',as_of_utc=execution.get('as_of_utc') or decision.get('as_of_utc'),
        closed_as_of_utc=decision.get('as_of_utc'),phase_id=decision.get('phase_id'),boundary_pair_id=decision.get('boundary_pair_id'),
        source_id=composite.get('source_id'),active_stage=composite.get('active_stage'),active_score=score,
        score_delta=score-prior if numeric(score) and numeric(prior) else None,
        comparison='same_source_same_stage' if same else 'new_source_or_stage',state=state,
        previous_state=previous.get('state') if previous else None,decision_status=decision.get('status'),
        execution_status=status,quote_composite=deepcopy(execution.get('quote_composite')),
        open_positions=len(active),positions_closed_this_event=deepcopy(closed),
        position_readings=deepcopy(positions),management_order_ids=[p.get('intent_id') for p in active],
        management_sources=[dict(intent_id=p.get('intent_id'),phase_id=p.get('phase_id'),source_key=p.get('source_key')) for p in active],
        selected_score_applies_to_all_positions=False,
        automatic_trade_permission=False,stop_or_order_changed_by_score=False)
