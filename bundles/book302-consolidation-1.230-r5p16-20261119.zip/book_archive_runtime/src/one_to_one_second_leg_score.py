"""Causal experimental delivery score, never a target-hit probability.

Measures only the second leg from its fixed C. No source reselection, no
extension after the first target/anchor-failure bar, no use of stored outcomes.
Weights are explicit engineering hypotheses pending out-of-time calibration.
"""
from datetime import datetime,timezone
from math import isfinite

MINUTES={'M1':1,'M5':5,'M15':15,'M30':30,'H1':60,'H4':240,'D1':1440,'W1':10080}

def epoch(value):
    dt=datetime.fromisoformat(value.replace('Z','+00:00'))
    if dt.tzinfo is None:raise ValueError('timezone required')
    return dt.timestamp()

def score_second_leg(family,projection,bars,as_of):
    tf=family['timeframe'];seconds=MINUTES[tf]*60;cutoff=epoch(as_of)
    result=dict(schema='one_to_one_second_leg_delivery_v1',measurement_id=family['measurement_id'],
        projection_id=projection['projection_id'],timeframe=tf,as_of_utc=as_of,
        score=None,status='unavailable',score_is_probability=False,author_formula=False,
        calibration_status='unvalidated_engineering_weights',trade_permission=False,
        order_api_called=False)
    anchor=projection['anchor'];start=epoch(anchor['pivot_timestamp_utc'])
    known=max(epoch(projection['known_at_utc']),epoch(anchor['confirmed_at_utc']),epoch(family['known_at_utc']))
    if known>cutoff:return dict(result,status='anchor_not_yet_known')
    c=float(anchor['price']);target=float(projection['target']);span=abs(target-c)
    if not isfinite(span) or span<=0:return dict(result,status='invalid_target')
    direction=1 if target>c else -1
    selected=[];last=None;event=None
    for row in bars:
        opened=epoch(row['timestamp_utc'])
        if last is not None and opened<=last:raise ValueError('unordered native bars')
        last=opened
        if opened<start or opened+seconds>cutoff:continue
        if row.get('timeframe',tf)!=tf:raise ValueError('foreign native timeframe')
        if row.get('provider',family.get('provider'))!=family.get('provider',row.get('provider')):raise ValueError('foreign provider')
        values=[float(row[k]) for k in ('open','high','low','close')]
        o,h,l,close=values
        if not all(map(isfinite,values)) or l>min(o,close) or h<max(o,close) or h<l:raise ValueError('invalid OHLC')
        selected.append((opened,o,h,l,close))
        # C's own candle cannot establish intrabar order relative to C.
        if opened==start:
            if not l<=c<=h:return dict(result,status='anchor_price_outside_native_bar')
            touched=h>=target if direction>0 else l<=target
            if touched:return dict(result,status='anchor_bar_target_order_unknown')
            continue
        reached=h>=target if direction>0 else l<=target
        failed=close<c if direction>0 else close>c
        if reached or failed:
            event='same_bar_ambiguous' if reached and failed else 'target_touched' if reached else 'anchor_failed'
            if opened+seconds<=known:
                return dict(result,status='terminal_event_before_anchor_confirmation',terminal_event=event,
                            terminal_bar_open_utc=row['timestamp_utc'],score=None)
            break
    if not selected or selected[0][0]!=start:return dict(result,status='anchor_bar_outside_loaded_history')
    # Two closes after C are a minimum observation, never a confirmed wave.
    path=selected[1:]
    if len(path)<2:return dict(result,status='insufficient_second_leg_bars',observed_bars=len(path))
    closes=[c]+[r[4] for r in path]
    travel=sum(abs(b-a) for a,b in zip(closes,closes[1:]));net=direction*(closes[-1]-c)
    efficiency=max(0,net)/travel if travel else 0
    body=sum(abs(r[4]-r[1]) for r in path)
    directed=sum(max(0,direction*(r[4]-r[1])) for r in path)/body if body else 0
    overlaps=[]
    for a,b in zip(path,path[1:]):
        union=max(a[2],b[2])-min(a[3],b[3]);overlap=max(0,min(a[2],b[2])-max(a[3],b[3]))
        overlaps.append(overlap/union if union else 1)
    overlap=sum(overlaps)/len(overlaps) if overlaps else 1
    # Fixed recent window exposes flattening rather than averaging it away
    # inside an old impulse. It does not move C or select a later best peak.
    n=min(5,len(path));tail_start=closes[-n-1];tail_net=max(0,direction*(closes[-1]-tail_start))
    tail_rate=tail_net/n;whole_rate=max(0,net)/len(path)
    sustained=min(1,tail_rate/whole_rate) if whole_rate else 0
    score=100*(.4*efficiency+.3*directed+.3*(1-overlap))*sustained
    return dict(result,score=round(score,2),status='terminal_observation' if event else 'developing_observation',
        terminal_event=event,observed_bars=len(path),last_bar_open_epoch=path[-1][0],
        known_at_utc=datetime.fromtimestamp(max(known,path[-1][0]+seconds),timezone.utc).isoformat(),
        features=dict(close_path_efficiency=efficiency,directional_body_share=directed,
                      adjacent_overlap=overlap,recent_delivery_ratio=sustained,
                      signed_target_progress=net/span),
        formula='100*(0.4*efficiency+0.3*directional_body+0.3*(1-overlap))*recent_delivery_ratio')
