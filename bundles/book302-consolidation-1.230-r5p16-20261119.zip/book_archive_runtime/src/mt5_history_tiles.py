"""Persistent fixed historical display tiles; exact-prefix replay stays separate.

The MT5 chart is a static history browser. Each tile retains its own evaluation
clock and scene identity. A historical overview must never be traded/replayed as
if all of its objects had been available at the left edge of the viewport.
"""
import gzip
import json
import time
from collections import OrderedDict, Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
from .build_archive_window_snapshot import ARCHIVE, TIMEFRAME_MINUTES, mt5_weekly_prefix

TILE = 512
# A tile contains 512 archive bars.  Keeping the worker's causal context at
# the tile width prevents a cold historical tile from retaining a second full
# context window for every projection while preserving the complete archive
# index and the closed-bar evidence clock.
WORKER_CONTEXT_BARS = TILE
MEMORY_TILES = 96  # bounded hot cache; the immutable ledger retains all tiles

def request_affected_by_failure(fields, keys, task_key, task_mode, task_exact):
    """A failed exact request belongs to one clock/period/mode, not every tab."""
    if len(fields) not in (6, 7) or fields[5] != 'END':
        return False
    mode = fields[6] if len(fields) == 7 else 'all'
    if mode != task_mode:
        return False
    if task_exact:
        try:
            return (fields[2], utc(float(fields[3])), mode) == tuple(task_exact)
        except (TypeError, ValueError, OverflowError):
            return False
    return task_key in keys


def clear_recovered_error(directory, token, has_exact, errors):
    """Do not leave a prior failure on a successfully recovered static view."""
    import re
    if has_exact and errors == 0 and re.fullmatch(r'[0-9_]+', token):
        try:
            (directory / f'{token}.error').unlink(missing_ok=True)
        except OSError:
            pass  # MT5 may briefly hold this one file; retry next loop.


def runtime_receipt_complete(receipt_fields, request_fields, revision):
    """Whether a frontend receipt proves the current EX5 runtime identity."""
    return bool(len(receipt_fields)>=7 and receipt_fields[:3]==request_fields[:3]
                and receipt_fields[4]=='APPLIED' and receipt_fields[5]
                and receipt_fields[5]==revision and receipt_fields[6]==revision)


def publication_inputs(directory, token):
    """Read the small ready marker and TSV header, never the full JSON scene."""
    try:
        ready=(directory/f'{token}.ready').read_text(encoding='utf8').strip().split('\t')
        packet=directory/f'{token}.{ready[0]}.tsv' if ready and len(ready[0])==64 else directory/f'{token}.tsv'
        with packet.open(encoding='utf8') as stream:
            header=stream.readline().strip().split('\t')
        return ready,header
    except OSError:
        return [],[]


def runtime_publication_complete(receipt, request, revision, ready, header):
    """Bind an applied runtime to this exact scene, including equal-size edits."""
    return bool(runtime_receipt_complete(receipt,request,revision)
                and len(receipt)>=8 and len(ready)>=3 and ready[0]
                and ready[2]==revision and receipt[7]==ready[0]
                and len(header)==6 and header[:2]==['M1SCENE','2']
                and header[2:5]==request[:3] and header[5].isdigit()
                and receipt[3]==header[5])


def stale_receipt_pairs(directory, revision, symbol):
    """List request/receipt pairs that still need a current-runtime publish."""
    pairs=[]
    for path in directory.glob('request_*.tsv'):
        try:
            fields=path.read_text(encoding='utf8').strip().split('\t')
            if (len(fields) not in (6,7) or fields[1] != symbol or fields[5] != 'END'
                    or not fields[0].replace('_','').isdigit()):
                continue
            receipt_path=directory/(path.stem.replace('request_','display_',1)+'.txt')
            if not receipt_path.exists():
                pairs.append({'request':path.name,'receipt':receipt_path.name,
                              'request_token':fields[0],'receipt_token':None,
                              'reasons':['missing_receipt']})
                continue
            receipt=receipt_path.read_text(encoding='utf8').strip().split('\t')
            ready,header=publication_inputs(directory,fields[0])
            if not runtime_publication_complete(receipt,fields,revision,ready,header):
                reasons=[]
                if not receipt or receipt[0] != fields[0]: reasons.append('token_mismatch')
                if len(receipt)<7: reasons.append('legacy_receipt_schema')
                elif receipt[5] != revision or receipt[6] != revision: reasons.append('engine_revision_mismatch')
                if len(receipt)>4 and receipt[4] != 'APPLIED': reasons.append('not_applied')
                if len(receipt)<8 or not ready or receipt[7]!=ready[0]:
                    reasons.append('publication_identity_missing_or_mismatched')
                if len(receipt)>3 and len(header)==6 and receipt[3]!=header[5]:
                    reasons.append('object_count_mismatch')
                pairs.append({'request':path.name,'receipt':receipt_path.name,
                              'request_token':fields[0],
                              'receipt_token':receipt[0] if receipt else None,
                              'reasons':reasons or ['runtime_receipt_incomplete']})
        except (OSError,IndexError):
            continue
    return pairs


def schedulable_requests(directory, revision, symbol, now=None):
    """Age only completed idle views; a slow first paint must never expire.

    Static charts do not rewrite an unchanged viewport request. Completion
    therefore requires the same token, period, current engine and an applied
    complete viewport, rather than assuming an old file belongs to a closed tab.
    """
    import re
    now = time.time() if now is None else now
    candidates = []
    for path in directory.glob('request_*.tsv'):
        try:
            fields = path.read_text(encoding='utf8').strip().split('\t')
            if (len(fields) not in (6,7) or fields[1] != symbol or fields[5] != 'END'
                    or not re.fullmatch(r'[0-9_]+', fields[0])):
                continue
            if len(fields) == 7 and fields[6] not in ('all','structure','ict'):
                continue
            candidates.append((path.stat().st_mtime, path, fields))
        except OSError:
            continue
    candidates.sort(key=lambda x:x[0], reverse=True)
    selected = []
    for i, (modified, path, fields) in enumerate(candidates):
        complete = False
        try:
            ready,header=publication_inputs(directory,fields[0])
            receipt = (directory / (path.stem.replace('request_', 'display_', 1)+'.txt')).read_text(encoding='utf8').strip().split('\t')
            # A transport receipt is only complete for the current frontend
            # after it carries the runtime identity written by the new EX5.
            # Legacy five-field receipts remain schedulable so the worker can
            # republish them, instead of treating an old terminal view as
            # finished forever.
            complete = (len(ready)>=3 and ready[1]=='1' and ready[2]==revision
                        and runtime_publication_complete(receipt, fields, revision, ready, header))
        except OSError:
            pass
        if i==0 or now-modified<180 or not complete:
            selected.append(path)
    return selected

def publish_view(scene, token, mode, destination):
    """Keep full evidence in the ledger/JSON; send only requested display layers."""
    from .mt5_unified_backend import atomic, publish, validate, COMMON, OUTPUT
    if mode == 'all':
        publish(scene, token, destination)
        return len(scene['objects'])
    import re
    if not re.fullmatch(r'[0-9_]+',token) or scene['provider']!='HistData':
        raise ValueError('invalid display request')
    validate(scene)
    objects = [o for o in scene['objects'] if (o['layer']=='ict') == (mode=='ict')]
    lines=[f"M1SCENE\t2\t{token}\tMachine1.HistData.XAUUSD\t{scene['timeframe']}\t{len(objects)}"]
    for o in objects:
        a,b=o['points']
        fields=[o['id'],o['layer'],o['kind'],int(a[0]),a[1],int(b[0]),b[1],o['status'],o.get('owner_id',''),o.get('group',''),o.get('label','')]
        lines.append('\t'.join(str(v).replace('\t',' ').replace('\n',' ').replace('\r',' ') for v in fields))
    lines.append(f"END\t{token}\t{len(objects)}")
    raw=json.dumps(scene,ensure_ascii=False,allow_nan=False).encode('utf8')
    from .book_plan_summary import plan_packet
    plan=plan_packet(scene,token)
    tsv=('\n'.join(lines)+'\n').encode('utf8')
    from .mt5_publication_files import write_publication_files
    write_publication_files(destination,token,scene.get('scene_id'),
                            {'json':raw,'tsv':tsv,'bookplan.tsv':plan},atomic)
    atomic(destination/f'{token}.bookplan.tsv',plan)
    atomic(destination/f'{token}.json',raw)
    atomic(destination/f'{token}.tsv',tsv)
    if Path(destination)==COMMON:atomic(OUTPUT/'latest-scene.json',raw)
    return len(objects)

def utc(epoch):
    return datetime.fromtimestamp(float(epoch), timezone.utc).isoformat().replace('+00:00','Z')


def _compact_force_channels(objects):
    """Remove duplicate channel fits introduced when history tiles overlap.

    Each tile deliberately keeps its own evidence clock, so the same broad
    movement can arrive twice at a tile boundary.  The chart needs one red
    outer trendline and one response marker for that movement; the source
    scenes and review ledger remain untouched.  A confirmed trendline break
    wins over an unconfirmed fit, then the longer same-direction fit wins.
    """
    groups = {}
    for obj in objects:
        if obj.get('layer') != 'force' or obj.get('kind') != 'line':
            continue
        source = str(obj.get('source_id') or '')
        side = (':channel:upper' if ':channel:upper' in source else
                ':channel:lower' if ':channel:lower' in source else None)
        if side is None:
            continue
        base = source.rsplit(side, 1)[0]
        points = obj.get('points') or []
        if len(points) != 2:
            continue
        a, b = points
        try:
            start, end = float(a[0]), float(b[0])
            slope = float(b[1]) - float(a[1])
        except (TypeError, ValueError):
            continue
        paired = [o for o in objects if o.get('layer') == 'force' and
                  (str(o.get('source_id') or '') == base or
                   str(o.get('source_id') or '').startswith(base + ':'))]
        groups[base] = dict(base=base, start=start, end=end,
                            direction=1 if slope >= 0 else -1,
                            span=max(0.0, end - start),
                            confirmed=any(('低流动性波段趋势线突破' in str(o.get('label') or '') or
                                           '低流动性通道突破' in str(o.get('label') or ''))
                                          for o in paired))
    if len(groups) < 2:
        return objects
    chosen = []
    removed = set()
    # Confirmed break evidence has priority; within an episode retain the
    # widest representative so a short tile fragment cannot replace it.
    ordered = sorted(groups.values(), key=lambda g: (g['confirmed'], g['span']), reverse=True)
    for current in ordered:
        if current['base'] in removed:
            continue
        chosen.append(current)
        for other in ordered:
            if other['base'] in removed or other is current:
                continue
            overlap = max(0.0, min(current['end'], other['end']) -
                          max(current['start'], other['start']))
            shorter = min(current['span'], other['span'])
            if shorter > 0 and overlap / shorter >= 0.65:
                removed.add(other['base'])
    if not removed:
        return objects
    kept=[]
    for obj in objects:
        source = str(obj.get('source_id') or '')
        if any(source == base or source.startswith(base + ':') for base in removed):
            continue
        kept.append(obj)
    return kept

def _merge_owned_boundary_events(objects, events):
    """Merge owned-source boundary facts without duplicating chart markers.

    A legacy line and a newly selected owned ruler can share the same native
    geometry.  They must render one marker, while the new source still needs
    its own provenance and force/retest evidence.
    """
    by_id={o.get('id'):o for o in objects}
    added=0;merged=0
    for event in events:
        prior=by_id.get(event.get('id'))
        if prior is None:
            objects.append(event);by_id[event.get('id')]=event;added+=1;continue
        pe=prior.setdefault('evidence',{});ee=event.get('evidence',{})
        refs=set(pe.get('supporting_source_line_ids',[]))
        if event.get('owner_id'):refs.add(event['owner_id'])
        if ee.get('supporting_source_line_ids'):refs.update(ee['supporting_source_line_ids'])
        pe['supporting_source_line_ids']=sorted(refs)
        pe['owned_boundary_source']=True
        # Cached legacy packets may predate force binding.  Refresh only the
        # derived evidence, preserving the original event owner and geometry.
        for field in ('break_force','pullback_retest','invalidation',
                      'force_known_at_utc','pullback_known_at_utc',
                      'invalidation_known_at_utc','force_binding'):
            if field in ee:pe[field]=ee[field]
        merged+=1
    return objects,dict(added=added,merged=merged,total_events=len(events))


class HistoryTiles:
    def __init__(self, full_history=False):
        self.full_history = bool(full_history)
        # Revision checks are immutable for one worker run.  Recomputing the
        # source-tree digest for every one of the 767 historical tiles made a
        # fresh chart appear stalled even though the worker was only doing
        # redundant cache-key work.
        self.engine_revision_value = None
        self.archive_revision_cache = {}
        self.times = {}
        self.scenes = OrderedDict()
        self.missing = set()
        self.views = OrderedDict()
        self.prepared = set()
        self.exact_scenes = OrderedDict()
        self.inventory_cursor = {}

    def exact(self, tf, cutoff, mode):
        """Disk-only lookup: the request loop must never calculate synchronously."""
        from .mt5_scene_store import cached, scene_request_key
        at=utc(float(cutoff)); identity=(tf,at,mode)
        if identity in self.exact_scenes:
            return self.exact_scenes[identity]
        scene=cached(scene_request_key(tf,at,WORKER_CONTEXT_BARS,mode,
            revision=self.engine_revision_value))
        if scene and scene.get('provider')=='HistData' and scene.get('timeframe')==tf and scene.get('cutoff_utc')==at:
            self.exact_scenes[identity]=scene
            while len(self.exact_scenes)>12:self.exact_scenes.popitem(last=False)
            return scene
        return None

    def index(self, tf):
        if tf not in self.times:
            catalog=json.loads((ARCHIVE/'catalog.json').read_text(encoding='utf8'))
            data=next(d for d in catalog['datasets'] if d['id']=='HistData')
            if tf=='W1':
                rows=mt5_weekly_prefix(data, data['periods']['D1']['end']+86400,100000)
                stamps=rows[:,0].copy()
            else:
                stamps=np.concatenate([np.frombuffer(gzip.decompress((ARCHIVE/c['file']).read_bytes()),dtype='<f8').reshape(-1,6)[:,0].copy() for c in data['periods'][tf]['chunks']])
            if len(stamps)==0 or np.any(np.diff(stamps)<=0):raise ValueError('invalid history index')
            self.times[tf]=stamps
        return self.times[tf]

    def keys(self, tf, cutoff, count):
        stamps=self.index(tf)
        end=max(1,int(np.searchsorted(stamps+TIMEFRAME_MINUTES[tf]*60,float(cutoff),side='right')))
        # Production requests index the entire imported period.  The worker
        # still calculates the rightmost/visible tile first, then warms older
        # tiles in the background, so the chart remains responsive while no
        # artificial 8,100/32,768-bar ceiling is applied.
        window = len(stamps) if self.full_history else min(32768,max(1,int(count)))
        first=max(0,end-window)
        # These are absolute archive bar tiles, independent of the scroll step.
        return [(tf,n) for n in range(first//TILE,(end-1)//TILE+1)]

    def viewport_keys(self,tf,cutoff,count):
        stamps=self.index(tf)
        end=max(1,int(np.searchsorted(stamps+TIMEFRAME_MINUTES[tf]*60,float(cutoff),side='right')))
        first=max(0,end-max(TILE,int(count)))
        return [(tf,n) for n in range(first//TILE,(end-1)//TILE+1)]

    def scan_inventory(self,keys,mode,budget=16):
        """Bound disk checks per tick; no full archive scan before first paint."""
        if not keys:return
        identity=(keys[0][0],mode)
        cursor=self.inventory_cursor.get(identity,len(keys)-1)
        for _ in range(min(budget,len(keys))):
            self.get(keys[cursor%len(keys)],mode=mode)
            cursor-=1
        self.inventory_cursor[identity]=cursor%len(keys)

    def completed_count(self,keys,mode):
        return sum((key,mode) in self.prepared for key in keys)

    def endpoint(self,key):
        tf,n=key;stamps=self.index(tf)
        return utc(stamps[min(len(stamps),(n+1)*TILE)-1]+TIMEFRAME_MINUTES[tf]*60)

    def get(self,key,calculate=False,mode='all'):
        from .mt5_unified_backend import build_scene
        from .mt5_scene_store import cached,engine_revision,archive_revision,scene_request_key
        cache_key=(key,mode)
        if cache_key in self.scenes:
            result=self.scenes.pop(cache_key);self.scenes[cache_key]=result;return result
        if not calculate and cache_key in self.missing:return None
        tf,_=key;at=self.endpoint(key)
        if calculate:result=build_scene(tf,at,WORKER_CONTEXT_BARS,mode)
        else:
            revision=self.engine_revision_value or engine_revision()
            archive_key=(at,WORKER_CONTEXT_BARS)
            if archive_key not in self.archive_revision_cache:
                self.archive_revision_cache[archive_key]=archive_revision(at,WORKER_CONTEXT_BARS)
            result=cached(scene_request_key(tf,at,WORKER_CONTEXT_BARS,mode,
                revision=revision,data_revision=self.archive_revision_cache[archive_key]))
        # A cache key is necessary but not sufficient evidence: an interrupted
        # migration or a copied cache file can carry a different clock or
        # duplicate objects under the same filename.  Reject it before it can
        # enter a composed historical view.
        if result:
            ids=[obj.get('id') for obj in result.get('objects', [])
                 if isinstance(obj, dict)]
            if (result.get('provider') != 'HistData' or
                    result.get('timeframe') != tf or
                    result.get('cutoff_utc') != at or
                    len(ids) != len(set(ids))):
                result=None
        if result:
            self.prepared.add((key,mode))
            self.missing.discard(cache_key)
            self.scenes[cache_key]=result
            while len(self.scenes)>MEMORY_TILES:self.scenes.popitem(last=False)
        else:self.missing.add(cache_key)
        return result

    def neighbors(self, keys):
        if not keys:return []
        tf,left=keys[0];right=keys[-1][1];total=(len(self.index(tf))+TILE-1)//TILE
        return [(tf,n) for n in (left-1,right+1) if 0<=n<total]

    def warm_order(self,keys):
        """Continue toward the start of the selected period while idle."""
        tf,left=keys[0];right=keys[-1][1];total=(len(self.index(tf))+TILE-1)//TILE
        yield from self.neighbors(keys)
        yield from ((tf,n) for n in range(left-2,-1,-1))
        yield from ((tf,n) for n in range(right+2,total))

    def compose(self, keys, scenes, requested_cutoff=None, mode='all', exact_scene=None):
        from .mt5_scene_store import save
        from .mt5_unified_backend import validate
        requested_utc = utc(float(requested_cutoff)) if requested_cutoff is not None else None
        if requested_utc is not None:
            # The rightmost absolute tile can end after the requested chart
            # clock.  Never let that future endpoint become the scene's
            # top-level cutoff.  Build one exact current scene and retain only
            # completed historical components at or before the request.
            from .mt5_unified_backend import build_scene
            eligible = [s for s in scenes if s.get('cutoff_utc', '') <= requested_utc]
            exact = exact_scene or build_scene(keys[0][0], requested_utc, WORKER_CONTEXT_BARS, mode)
            if exact.get('timeframe')!=keys[0][0] or exact.get('cutoff_utc')!=requested_utc:
                raise ValueError('exact scene clock does not match request')
            components = [s for s in eligible if s.get('scene_id') != exact.get('scene_id')]
            components.append(exact)
        else:
            components=sorted(scenes,key=lambda s:s['cutoff_utc'])
        cache_key=(tuple(keys),tuple(s['scene_id'] for s in components))
        if cache_key in self.views:return self.views[cache_key]
        latest=components[-1]
        result=dict(latest);result.pop('scene_id',None)
        result['component_scene_ids']=[s['scene_id'] for s in components]
        merged={}
        for component in components:
            for obj in component['objects']:
                merged[obj['id']]=dict(obj,evaluated_at_utc=component['cutoff_utc'],component_scene_id=component['scene_id'])
        # Keep the uncompressed anchor inventory for analysis-window loading.
        # Display compaction may remove a duplicate/legacy object while its
        # native timestamp is still needed to reconstruct an earlier owned
        # wave.  The display set and the calculation context have different
        # responsibilities.
        raw_merged_objects=list(merged.values())
        from .book_wave_inventory import compact_historical_book_objects
        merged_objects = compact_historical_book_objects(_compact_force_channels(raw_merged_objects))
        from .book_projection_display import revise_projection_display
        merged_objects, revision_audit = revise_projection_display(
            merged_objects, latest['timeframe'], latest['cutoff_utc'],
            self.index(latest['timeframe']), TIMEFRAME_MINUTES[latest['timeframe']] * 60)
        result['book_projection_display_audit'] = revision_audit
        from .book_line_delivery import deliver_book_lines, native_delivery_context
        delivery_bars = native_delivery_context(raw_merged_objects, latest['timeframe'],
                                               latest['cutoff_utc'], self.index(latest['timeframe']))
        merged_objects, delivery_audit = deliver_book_lines(
            merged_objects, delivery_bars, latest['timeframe'], latest['cutoff_utc'],
            TIMEFRAME_MINUTES[latest['timeframe']] * 60)
        result['book_line_delivery_audit'] = delivery_audit
        from .book_line_delivery import route_book_line_roles
        merged_objects, role_audit = route_book_line_roles(merged_objects)
        result['book_line_role_audit'] = role_audit
        # Broad lines are selected from confirmed native runs, not from a
        # union of arbitrary sliding windows. Keep all pre-existing geometry
        # and force owners intact; the terminal gives selected lines priority.
        from .book_owned_axis import owned_axis_objects
        selected, owned_audit = owned_axis_objects(
            delivery_bars, latest['timeframe'], latest['cutoff_utc'])
        # Publish the selected geometry through the native-source projection
        # contract before it reaches the chart packet.  This is deliberately
        # additive: a failed projection keeps its source line, and legacy
        # objects are never filtered or reselected on the display timeframe.
        from .book_projection_contract import (annotate_native_identity,
                                                deliver_owned_native_segments)
        selected = [annotate_native_identity(obj) for obj in selected]
        selected, owned_projection_audit = deliver_owned_native_segments(
            selected, delivery_bars, latest['timeframe'], latest['cutoff_utc'],
            timestamp_format='epoch')
        existing_ids = {obj['id'] for obj in merged_objects}
        merged_objects.extend(obj for obj in selected if obj['id'] not in existing_ids)
        # The owned-axis selector runs after the legacy scene boundary pass.
        # Generate matching frozen contact/close-break facts for these new
        # sources before publication; otherwise a newly drawn Book ruler has
        # no breakout evidence attached to it.  Existing sources are passed
        # through for deterministic ID de-duplication, but are never changed.
        from .book_boundary_events import boundary_event_objects
        owned_boundary_events, owned_boundary_audit = boundary_event_objects(
            delivery_bars, latest['timeframe'], latest['cutoff_utc'],
            selected)
        if owned_boundary_events:
            from .book_projection_display import revise_projection_display
            owned_boundary_events, owned_boundary_display_audit = revise_projection_display(
                owned_boundary_events, latest['timeframe'], latest['cutoff_utc'],
                self.index(latest['timeframe']),
                TIMEFRAME_MINUTES[latest['timeframe']] * 60)
            merged_objects, owned_boundary_merge_audit = _merge_owned_boundary_events(
                merged_objects, owned_boundary_events)
        else:
            owned_boundary_display_audit = dict(policy='projection_revision_display_v1',
                                                revised_projections=0,
                                                boundary_level_markers=0,
                                                removed_objects=0,
                                                force_objects_modified=0,
                                                changes=[])
            owned_boundary_merge_audit = dict(added=0,merged=0,total_events=0)
        result['book_owned_axis_audit'] = owned_audit
        result['book_owned_axis_projection_audit'] = owned_projection_audit
        result['book_owned_axis_boundary_audit'] = owned_boundary_audit
        result['book_owned_axis_boundary_display_audit'] = owned_boundary_display_audit
        result['book_owned_axis_boundary_merge_audit'] = owned_boundary_merge_audit
        merged_objects = [annotate_native_identity(obj) for obj in merged_objects]
        result['book_projection_contract'] = dict(
            native_identity_annotated=sum(1 for obj in merged_objects if obj.get('evidence',{}).get('native_source_identity')),
            cross_period_projection='fail_closed_identity_only',
            target_period_reselects_points=False,
            target_period_confirms_native_events=False)
        # A historical overview is composed from independently validated
        # tiles.  Keep the display fail-closed for an individual malformed
        # geometry record: reject only that record and retain a reviewable
        # receipt instead of making the whole composed view undisplayable.
        display_rejections = []
        clean_objects = []
        for obj in merged_objects:
            points = obj.get('points') if isinstance(obj, dict) else None
            valid_geometry = (isinstance(points, list) and len(points) == 2 and
                              all(isinstance(p, (list, tuple)) and len(p) == 2 for p in points))
            if valid_geometry:
                try:
                    valid_geometry = (all(np.isfinite(float(v)) for p in points for v in p) and
                                      float(points[1][0]) >= float(points[0][0]))
                except (TypeError, ValueError):
                    valid_geometry = False
            if valid_geometry:
                clean_objects.append(obj)
            else:
                display_rejections.append({
                    'id': obj.get('id') if isinstance(obj, dict) else None,
                    'layer': obj.get('layer') if isinstance(obj, dict) else None,
                    'reason': 'invalid_composed_geometry',
                    'read_only': True,
                    'trade_permission': False,
                })
        result['objects'] = clean_objects
        result['display_rejections'] = display_rejections
        if latest.get('ict_context'):
            days={d['date']:d for s in components for d in s.get('ict_context',{}).get('days',[])}
            result['ict_context']=dict(latest['ict_context'],days=[days[d] for d in sorted(days)],
                group_counts=dict(Counter(o['group'] for o in result['objects'] if o['layer']=='ict')))
        tf=keys[0][0];stamps=self.index(tf)
        start=max(0,keys[0][1]*TILE-512)
        if requested_cutoff is not None:
            end=max(start+1, min(len(stamps), int(np.searchsorted(
                stamps + TIMEFRAME_MINUTES[tf] * 60, float(requested_cutoff), side='right'))))
        else:
            end=min(len(stamps),(keys[-1][1]+1)*TILE)
        result['coverage']=dict(latest['coverage'],bars=end-start,from_epoch=float(stamps[start]),
            historical_tiles=len(components),requested_tiles=len(keys),
            **{'from':utc(stamps[start]),'through':utc(stamps[end-1])})
        result['display_policy']={'mode':'fixed_historical_tiles','tile_bars':TILE,
            'is_asof_replay':False,'complete':len(components)==len(keys),
            'note':'Historical observations retain component clocks; use the original component scene for causal replay.'}
        validate(result);save(result)
        self.views[cache_key]=result
        while len(self.views)>12:self.views.popitem(last=False)
        return result

def bootstrap_prior_packet(token, tf, cutoff, mode, directory=None):
    """Publish one validated same-clock packet while a cold tile warms.

    A terminal reload otherwise has no scene until the first expensive tile
    finishes and therefore looks empty.  This is display-only evidence: the
    packet is marked incomplete and is replaced as soon as a current-revision
    tile is available.  We never accept a different symbol/timeframe/clock,
    future coordinates, duplicate IDs, or ICT data for the structure view.
    """
    from .mt5_unified_backend import COMMON, SYMBOL, atomic
    if directory is not None:
        COMMON = Path(directory)
    if mode != 'structure':
        return False
    try:
        requested = utc(float(cutoff))
    except (TypeError, ValueError):
        return False
    candidates=[]
    # Prefer the packet named by the chart's last applied receipt.  This
    # is O(1) and is the common terminal-reload path; only fall back to a
    # small newest-first window when no receipt is available.
    preferred=[]
    for receipt in COMMON.glob('display_*.txt'):
        try:
            fields=receipt.read_text(encoding='utf8').strip().split('\t')
            if len(fields)>=4 and fields[1]==SYMBOL and fields[2]==tf:
                preferred.append(COMMON/f'{fields[0]}.json')
        except (OSError, ValueError):
            continue
    metas=[p for p in preferred if p.exists()]
    if not metas:
        metas=sorted(COMMON.glob('*.json'), key=lambda p:p.stat().st_mtime, reverse=True)[:32]
    for meta in metas:
        if meta.name in {'history-status.json'} or meta.name.endswith('.json.gz'):
            continue
        try:
            payload=json.loads(meta.read_text(encoding='utf8'))
            if (payload.get('provider') != 'HistData' or
                    payload.get('timeframe') != tf or
                    payload.get('cutoff_utc') != requested):
                continue
            stem=meta.with_suffix('.tsv')
            if stem.exists():
                candidates.append((meta.stat().st_mtime, stem, payload))
        except (OSError, ValueError, TypeError):
            continue
    for _, source, payload in sorted(candidates, key=lambda item:item[0], reverse=True):
        try:
            rows=source.read_text(encoding='utf8').splitlines()
            if not rows: continue
            head=rows[0].split('\t')
            if len(head)!=6 or head[:5] != ['M1SCENE','2',head[2],SYMBOL,tf]:
                continue
            count=int(head[5])
            if count < 0 or len(rows) != count + 2: continue
            seen=set(); out=[f'M1SCENE\t2\t{token}\t{SYMBOL}\t{tf}\t{count}']
            valid=True
            for row in rows[1:-1]:
                fields=row.split('\t')
                if len(fields)!=11 or fields[1]=='ict' or fields[0] in seen:
                    valid=False; break
                seen.add(fields[0])
                try:
                    a=int(fields[3]); b=int(fields[5])
                    if a<=0 or b<a or float(fields[4]) != float(fields[4]) or float(fields[6]) != float(fields[6]):
                        valid=False; break
                    if b > float(cutoff):
                        valid=False; break
                except (TypeError, ValueError):
                    valid=False; break
                out.append(row)
            end=rows[-1].split('\t')
            if not valid or len(end)!=3 or end[0]!='END' or int(end[2])!=count:
                continue
            out.append(f'END\t{token}\t{count}')
            # A bootstrap is the original packet, never evidence of newly
            # loaded code. Keep its JSON, scene identity and actual engine
            # together; the current engine will replace it after calculation.
            source_revision=payload.get('engine_revision')
            source_scene=payload.get('scene_id')
            if not source_revision or not source_scene:
                continue
            source_objects=[obj for obj in payload.get('objects',[]) if obj.get('layer')!='ict']
            if len(source_objects)!=count or {obj.get('id') for obj in source_objects}!=seen:
                continue
            if any(float(point[0])>float(cutoff)
                   for obj in source_objects for point in obj.get('points',[])):
                continue
            publish_view(payload,token,mode,COMMON)
            atomic(COMMON/f'{token}.ready', (f'{source_scene}\t0\t{source_revision}').encode('utf8'))
            return True
        except (OSError, ValueError, TypeError):
            continue
    return False

def run_worker(lock, loaded_revision):
    """Serve warm tiles while one cold tile computes; prioritize current charts.

    Only one calculator runs, so rapid scrolls do not multiply CPU/memory load.
    Old queued requests are replaced, but completed tiles remain reusable.
    """
    from .mt5_unified_backend import COMMON, atomic, publish, SYMBOL, build_scene
    from .mt5_scene_store import engine_revision
    import os,sys,threading
    atlas=HistoryTiles(full_history=True);atlas.engine_revision_value=loaded_revision
    pool=ThreadPoolExecutor(max_workers=1)
    task=None;task_key=None;task_mode='all';task_exact=None;task_revision=None;served={};active={};checked_revision=0;failed={};last_status=0
    print('Machine1 fixed-history tile worker ready',flush=True)
    # A cold scene can block the main loop for longer than the audit timeout.
    # Keep the liveness heartbeat independent of that single calculator.
    heartbeat_state={'prepared':0,'calculating':None,'active':0,'republish_pending':[]}

    def heartbeat():
        while True:
            try:
                atomic(COMMON/'history-status.json',json.dumps(dict(
                    mode='fixed_history_tiles', prepared_this_run=heartbeat_state['prepared'],
                    calculating=heartbeat_state['calculating'], tile_bars=TILE,
                    automatic_trade_permission=False, worker_pid=os.getpid(),
                    loaded_engine_revision=loaded_revision,
                    republish_pending=heartbeat_state['republish_pending'],
                    active_requests=heartbeat_state['active'], heartbeat_utc=utc(time.time()),
                    note='Background builds the selected period toward earlier history; cached tiles survive restarts.'
                )).encode())
            except (OSError, PermissionError):
                # MT5 can hold the common status file briefly while reading
                # it.  A transient replace failure must not kill the
                # heartbeat thread and make a live worker look stale.
                pass
            time.sleep(2)
    threading.Thread(target=heartbeat,name='machine1-history-heartbeat',daemon=True).start()
    while True:
        now=time.monotonic()
        if now-checked_revision>5:
            checked_revision=now
            current_revision = engine_revision()
            if current_revision!=loaded_revision:
                # Updating a hash cannot reload already imported Python code.
                # Finish/cancel the one calculator, discard its result, then
                # let the owner release its PID guard and launch a fresh process.
                print('engine changed; restarting with a fresh interpreter',flush=True)
                pool.shutdown(wait=True,cancel_futures=True)
                return 'engine_changed'
        if task and task.done():
            try:
                scene=task.result()
                if task_revision != loaded_revision:
                    print('discarded completed scene from superseded engine revision',flush=True)
                elif task_exact:
                    atlas.exact_scenes[task_exact]=scene
                    while len(atlas.exact_scenes)>12:atlas.exact_scenes.popitem(last=False)
                    print(f'exact {task_exact} ready objects={len(scene["objects"])}',flush=True)
                else:
                    atlas.scenes[(task_key,task_mode)]=scene;atlas.missing.discard((task_key,task_mode));atlas.prepared.add((task_key,task_mode))
                    while len(atlas.scenes)>MEMORY_TILES:atlas.scenes.popitem(last=False)
                    print(f'tile {task_key} ready objects={len(scene["objects"])}',flush=True)
            except Exception as error:
                failed[(task_exact or task_key,task_mode)]=time.monotonic()+300
                print(f'tile {task_key}: {error}',flush=True)
                for request_path,(token,keys) in active.items():
                    try:
                        fields=request_path.read_text(encoding='utf8').strip().split('\t')
                        if fields[0]==token and request_affected_by_failure(fields,keys,task_key,task_mode,task_exact):
                            atomic(COMMON/f'{token}.error',str(error).encode('utf8'))
                    except (OSError,IndexError):
                        continue
            task=None;task_exact=None
            heartbeat_state['calculating']=None
        requests=schedulable_requests(COMMON,loaded_revision,SYMBOL)
        heartbeat_state['republish_pending']=stale_receipt_pairs(COMMON,loaded_revision,SYMBOL)
        viewport_work=[]
        for request in requests:
            try:
                raw=request.read_text(encoding='utf8').strip();fields=raw.split('\t')
                if len(fields) not in (6,7):continue
                token,symbol,tf,cutoff,count,complete=fields[:6]
                mode=fields[6] if len(fields)==7 else 'all'
                if mode not in ('all','structure','ict'):continue
                if complete!='END' or symbol!=SYMBOL:continue
                # Publication and acknowledgement are independent. A missing
                # or old receipt remains pending in the heartbeat, but must
                # not repeatedly rewrite the identical bootstrap/packet and
                # starve the one background calculator. A new worker starts
                # with an empty served map; changed scenes change signature.
                if request not in active or active[request][0]!=token:
                    keys=atlas.keys(tf,int(cutoff),int(count));active[request]=(token,keys)
                else:keys=active[request][1]
                # Bootstrap before walking the complete historical index.  A
                # full-history request can contain hundreds of tiles and the
                # cache validation pass itself is expensive; the chart must
                # not remain empty while that pass is running.
                if token not in served and bootstrap_prior_packet(token, tf, cutoff, mode):
                    served[token]=('__bootstrap__',)
                    print(f'{token}: validated bootstrap packet while tiles warm',flush=True)
                view_keys=atlas.viewport_keys(tf,int(cutoff),int(count))
                exact=atlas.exact(tf,cutoff,mode)
                # Current clock calculation has priority over any inventory
                # walk. Only one calculator runs and the request loop stays free.
                exact_identity=(tf,utc(float(cutoff)),mode)
                if task is None and exact is None and failed.get((exact_identity,mode),0)<=now:
                    task_key=None;task_mode=mode;task_exact=exact_identity;task_revision=loaded_revision
                    heartbeat_state['calculating']=list(task_exact)
                    task=pool.submit(build_scene,tf,task_exact[1],WORKER_CONTEXT_BARS,mode)
                available=[s for k in view_keys if (s:=atlas.get(k,mode=mode))]
                atlas.scan_inventory(keys,mode)
                signature=tuple(s['scene_id'] for s in available)+((exact['scene_id'],) if exact else ())
                # Progress is independent of scene availability and survives redraws.
                errors=sum(failed.get((k,mode),0)>now for k in keys)+int(failed.get((exact_identity,mode),0)>now)
                completed=atlas.completed_count(keys,mode)
                progress=f'{completed}\t{len(keys)}\t{errors}'
                progress_path=COMMON/f'{token}.progress'
                if not progress_path.exists() or progress_path.read_text(encoding='utf8')!=progress:
                    atomic(progress_path,progress.encode('utf8'))
                if exact and served.get(token)!=signature:
                    scene=dict(atlas.compose(view_keys,available,cutoff,mode,exact_scene=exact))
                    scene['historical_inventory']={'computed_tiles':completed,'requested_tiles':len(keys),
                        'complete':completed==len(keys),'scope':'full_imported_prefix',
                        'display_scope':'viewport_tiles_only; other tiles remain scroll_accessible'}
                    from .mt5_scene_store import save
                    save(scene)
                    if request.read_text(encoding='utf8').strip()==raw:
                        publish_view(scene,token,mode,COMMON)
                        atomic(COMMON/f'{token}.ready',(scene['scene_id']+'\t'+str(int(scene['display_policy']['complete']))+'\t'+loaded_revision).encode())
                        served[token]=signature
                        print(f'{token}: viewport {len(available)}/{len(view_keys)}, history {completed}/{len(keys)}',flush=True)
                clear_recovered_error(COMMON,token,served.get(token)==signature and exact is not None,errors)
                if task is None:
                    if exact is None:
                        if failed.get((exact_identity,mode),0)>now:continue
                        task_key=None;task_mode=mode;task_exact=(tf,utc(float(cutoff)),mode)
                        task_revision=loaded_revision
                        heartbeat_state['calculating']=list(task_exact)
                        task=pool.submit(build_scene,tf,task_exact[1],WORKER_CONTEXT_BARS,mode)
                        continue
                    # Rightmost requested tile first, then its visible history.
                    missing=next((k for k in reversed(view_keys) if failed.get((k,mode),0)<now and atlas.get(k,mode=mode) is None),None)
                    if missing:
                        # Let every pending view's first exact scene take
                        # precedence over filling another view's older tiles.
                        viewport_work.append((missing,mode))
            except (OSError,ValueError,KeyError) as error:
                print(f'viewport: {error}',flush=True)
        if task is None and viewport_work:
            task_key,task_mode=viewport_work[0];task_revision=loaded_revision
            heartbeat_state['calculating']=task_key
            task=pool.submit(build_scene,task_key[0],atlas.endpoint(task_key),WORKER_CONTEXT_BARS,task_mode)
        # A user scrolling should not repeatedly wait behind speculative work.
        if task is None and requests and requests[0] in active and time.time()-requests[0].stat().st_mtime>5:
            _,keys=active[requests[0]]
            newest=requests[0].read_text(encoding='utf8').strip().split('\t')
            mode=newest[6] if len(newest)==7 else 'all'
            for key in reversed(keys):
                if (key,mode) in atlas.prepared or failed.get((key,mode),0)>now:continue
                if atlas.get(key,mode=mode) is None:
                    task_key=key;task_mode=mode;task_revision=loaded_revision;heartbeat_state['calculating']=task_key;task=pool.submit(build_scene,key[0],atlas.endpoint(key),WORKER_CONTEXT_BARS,mode);break
        heartbeat_state['prepared']=len(atlas.prepared)
        heartbeat_state['active']=len(active)
        # Retain bounded metadata for the currently open request files.
        if len(served)>128:served={token:served[token] for token,_ in active.values() if token in served}
        time.sleep(.2)

