"""Causal working-period measuring families, NOT an execution admission.

Author Feb10: 7605363360134535045, 7679581626945303530,
7679581120807612849, 7679584484261708379. User Oct7 distinguishes
trend nesting from range reuse. The swing-order regime below is our explicit
research interpretation, not an author label or a proven trend classifier.

Every native turn is reviewed. An outer first wave that actually departs its
origin candle can be measured before an upper-period objective is adjudicated.
Internal subpivots cannot silently become new outer sources. A first complete
compound departure is distinct from upgrading an already measured pair. The
latter requires its earlier second leg to reach the reference; both use the
actual enclosing extreme, never the projected price as a synthetic pivot.
"""
from bisect import bisect_left, bisect_right
from datetime import timedelta
from hashlib import sha256
from math import isclose, isfinite

from .live_nested_stage_review import MINUTES, _native, _leg, _same, _time
from .live_nested_stage_review import geometric_direction
from .live_source_wave_scope import source_wave_scope, _EnvelopeWindowIndex, known_envelope_component
from .native_market_sessions import adjacent_research_bars, research_calendar, SOURCE_URL
from .live_return_wave_scope import ReturnWaveIndex, projection_owner
from .live_wave_structure_context import WaveStructureIndex, first_outer_structure_reclaim, projection_structure_relation
from .native_timeframe_state import resolve_native_timeframe_state
from .live_regime_background_context import RegimeBackgroundIndex
from .live_return_measurement_context import attach_return_measurements
from .live_push_balance_evidence import PushBalanceIndex
from .live_return_process_review import return_process_review
from .live_snr_range_ownership import boundary_end
from .native_medium_wave_boundary import derive_medium_terminal_components

METHOD = 'native_regime_measuring_families_v1'
HIGH = 'confirmed_swing_high_candidate'
LOW = 'confirmed_swing_low_candidate'


def _key(point):
    return point['kind'], point['pivot_timestamp_utc'], point['price'], point['confirmed_at_utc']


def _id(*parts):
    return sha256(repr(parts).encode()).hexdigest()[:24]


def _utc(value):
    return value.isoformat().replace('+00:00', 'Z')


class _NativeWindow:
    def __init__(self, raw, timeframe, cutoff, offset):
        self.raw, self.timeframe = raw, timeframe
        self.times = sorted(raw)
        self.bars = [raw[t] for t in self.times]
        self.duration = timedelta(minutes=MINUTES[timeframe])
        self.cutoff = cutoff
        self.envelope = _EnvelopeWindowIndex(raw, timeframe)
        self.gaps = [0]
        for i, stamp in enumerate(self.times):
            gap = i > 0 and not adjacent_research_bars(self.times[i-1], stamp, MINUTES[timeframe], offset)
            self.gaps.append(self.gaps[-1] + int(gap))
        self.range_context = (self.bars, {b['timestamp_utc']:i for i,b in enumerate(self.bars)},
            self.duration, {i for i in range(1,len(self.bars)) if self.gaps[i+1]!=self.gaps[i]}, cutoff)
        self.range_ends = {}

    def range_at(self, regime, known):
        """The SAME named container/exit as SNR, consumed only when known.

        A wick or two weakening outside closes cannot certify an exit. The
        shared operational screen needs an outside close plus a separate
        close past that crossing candle's extreme, with continuous native
        coverage. This is not an Alexander major-degree or reversal formula.
        """
        high,low=regime['range_high'],regime['range_low']
        witnesses=regime['witnesses']
        first=min(p['pivot_timestamp_utc'] for p in witnesses)
        last=max(p['pivot_timestamp_utc'] for p in witnesses)
        key=(first,last,low['price'],high['price'])
        if key not in self.range_ends:
            if not self.complete(_time(first),_time(last)):
                end=dict(state='coverage_lost',known_at_utc=regime['known_at_utc'])
            else:
                end=boundary_end(dict(last_pivot_utc=last,range_high=high,range_low=low),self.range_context)
            self.range_ends[key]=end
        end=self.range_ends[key]
        visible=end if end and _time(end['known_at_utc'])<=known else None
        i=bisect_right(self.times,known-self.duration)-1
        close=self.bars[i]['close'] if i>=0 else None
        result=dict(method='same_native_named_range_exit_v1',native_timeframe=self.timeframe,
            state=visible['state'] if visible else 'no_accepted_exit_observed',known_at_utc=_utc(known),
            inside_original_range=close is not None and low['price']<=close<=high['price'],
            author_major_degree_adjudicated=False,trade_permission=False)
        if visible:
            result['ended_by']=visible
        return result

    def bounds(self, a, b):
        return bisect_left(self.times, a), bisect_right(self.times, b)

    def complete(self, a, b):
        lo, hi = self.bounds(a, b)
        return lo < hi and self.gaps[hi] == self.gaps[lo+1]

    def return_envelope(self, terminal, anchor):
        """B's opposite wick may precede B; it is not a later C.

        Compare all *later* native candles through C. B's close is known to
        follow its extreme, so a close beyond C still rejects the anchor.
        Do not infer the intrabar order of the excluded opposite wick.
        """
        tb,tc=_time(terminal['pivot_timestamp_utc']),_time(anchor['pivot_timestamp_utc'])
        low,high=sorted((terminal['price'],anchor['price']))
        if not self.complete(tb,tc) or not low <= self.raw[tb]['close'] <= high:
            return False
        start=bisect_right(self.times,tb)
        if start>=len(self.times) or self.times[start]>tc:
            return False
        return self.envelope.contains(self.raw,self.timeframe,self.times[start],tc,low,high)

    def outcome(self, source, anchor, *, known_override=None, as_of=None, target_override=None):
        """First price event from C, distinguishing pre-confirmation contact.

        A failure is a close beyond C, not automatically a parent trend failure.
        A same-candle target/failure is ambiguous. Missing history is unknown.
        """
        signed = source['source_terminal']['price'] - source['source_origin']['price']
        target, up = anchor['price'] + signed, signed > 0
        if target_override is not None:
            if (isinstance(target_override,bool) or not isinstance(target_override,(int,float)) or
                    not isfinite(target_override) or (target_override-anchor['price'])*signed<=0):
                raise ValueError('Alternative target must be finite and in original source direction')
            target=target_override
        start = _time(anchor['pivot_timestamp_utc'])
        known = max(_time(source['known_at_utc']), _time(anchor['confirmed_at_utc']),
                    known_override or _time(source['known_at_utc']))
        cutoff=self.cutoff if as_of is None else _time(as_of)
        if cutoff>self.cutoff or cutoff<known:
            raise ValueError('Outcome observation must be after anchor knowledge and inside native cutoff')
        lo = bisect_right(self.times, start)
        result = dict(status='unreached', target=target, known_at_utc=_utc(known),
                      event_bar_utc=None, event_known_at_utc=None, preconfirmation=False,
                      trade_permission=False)
        for i in range(lo, len(self.bars)):
            stamp, bar = self.times[i], self.bars[i]
            if stamp+self.duration>cutoff:
                break
            if i > 0 and self.gaps[i+1] != self.gaps[i]:
                return {**result, 'status':'history_gap_unknown', 'event_bar_utc':_utc(stamp)}
            hit = bar['high'] >= target if up else bar['low'] <= target
            fail = bar['close'] < anchor['price'] if up else bar['close'] > anchor['price']
            if hit or fail:
                return {**result, 'status': 'same_bar_ambiguous' if hit and fail else
                        'reached' if hit else 'anchor_failed', 'event_bar_utc':bar['timestamp_utc'],
                        'event_known_at_utc':_utc(stamp+self.duration),
                        'preconfirmation': stamp+self.duration <= known}
        return result


def _regime(points, known, terminal):
    # Only confirmed points up to B; future C, successes, and today's bias do
    # not select the family. Keep the actual comparison witnesses.
    visible = [p for p in points if _time(p['confirmed_at_utc']) <= known and
               _time(p['pivot_timestamp_utc']) <= _time(terminal['pivot_timestamp_utc'])]
    highs = [p for p in visible if p['kind'] == HIGH][-2:]
    lows = [p for p in visible if p['kind'] == LOW][-2:]
    result = dict(state='transition', direction=None, known_at_utc=_utc(known),
                  basis='same_period_confirmed_swing_order_hypothesis',
                  witnesses=sorted(highs+lows, key=lambda p:p['pivot_timestamp_utc']),
                  author_adjudicated=False, trade_permission=False)
    if len(highs) < 2 or len(lows) < 2:
        return {**result, 'reason':'insufficient_prior_swing_context_first_wave_still_reviewed'}
    dh, dl = highs[1]['price']-highs[0]['price'], lows[1]['price']-lows[0]['price']
    if dh > 0 and dl > 0:
        return {**result, 'state':'trend', 'direction':'up', 'reason':'higher_high_and_higher_low'}
    if dh < 0 and dl < 0:
        return {**result, 'state':'trend', 'direction':'down', 'reason':'lower_high_and_lower_low'}
    if dh <= 0 and dl >= 0:
        witnesses = sorted(highs+lows, key=lambda p:(p['pivot_timestamp_utc'],p['kind']))
        spans = [abs(float(right['price'])-float(left['price']))
                 for left, right in zip(witnesses, witnesses[1:])
                 if float(right['price']) != float(left['price'])]
        longest = max(spans) if spans else None
        shortest = min(spans) if spans else None
        ratio = (longest / shortest) if longest is not None and shortest else None
        balance = dict(
            schema='same_period_range_leg_balance_v1',
            criterion='alternating_swing_span_observation_only',
            segment_count=len(spans), segment_lengths=spans,
            longest=longest, shortest=shortest, ratio=ratio,
            balanced=bool(ratio is not None and ratio <= 2.0),
            used_as_regime_gate=False,
            same_direction_three_pushes=False,
            author_adjudicated=False, trade_permission=False)
        # These are alternating swings including returns, not three pushes.
        # The user's three-push preference cannot veto a held range here.
        return {**result, 'state':'range', 'reason':'overlapping_nonexpanding_swing_boundaries',
                'range_balance':balance,
                'range_high':highs[0], 'range_low':lows[0]}
    return {**result, 'reason':'expanding_or_one_sided_swing_order_not_a_confirmed_range'}


def _source_extent_reason(native, raw, timeframe, origin, terminal):
    """Return a precise rejection reason for an outer A→B envelope.

    Continuity and price containment are independent observations.  Keeping
    them separate matters for long native periods where a broker calendar can
    leave a missing candle: a valid price envelope must not silently waive the
    gap, and a breached envelope must not be reported as a calendar problem.
    """
    ta, tb = _time(origin['pivot_timestamp_utc']), _time(terminal['pivot_timestamp_utc'])
    low, high = sorted((origin['price'], terminal['price']))
    continuous = native.complete(ta, tb)
    contained = native.envelope.contains(raw, timeframe, ta, tb, low, high)
    if continuous and contained:
        return None
    if not continuous and contained:
        return 'source_native_history_gap_unresolved'
    if continuous and not contained:
        return 'source_extreme_envelope_breached'
    return 'source_native_history_gap_and_extreme_envelope_unresolved'


def _whole_return_reconsideration(scope, regime, points, native, return_index, source_known):
    """Revisit a withheld envelope at C, not a completed-pair promotion at B.

    An aligned, complete source may be reconsidered at its own connected C.
    Keep a shallow C inside the final push separate from a return that closes
    through every internal origin. Both measure the full A→B height; neither
    proves structural degree or parent trend continuation. The first accepted
    C fixes admission time; later target outcomes are never consulted.
    """
    a, b = scope['origin'], scope['terminal']
    up = b['price'] > a['price']
    direction = 'up' if up else 'down'
    if regime['state'] != 'trend' or regime['direction'] != direction:
        return None
    family = dict(source_origin=a, source_terminal=b, timeframe=native.timeframe,
        source_leg_id=scope['source_leg_id'], known_at_utc=_utc(source_known),
        component_source_leg_ids=scope['component_source_leg_ids'], direction_observation=direction)
    for c in points:
        if c['pivot_timestamp_utc'] <= b['pivot_timestamp_utc'] or c['kind'] != a['kind']:
            continue
        # No retroactive reopening after the original excursion was crossed.
        if c['price'] <= a['price'] if up else c['price'] >= a['price']:
            break
        known = max(source_known, _time(c['confirmed_at_utc']))
        if known > native.cutoff or not native.return_envelope(b, c):
            continue
        path = return_index.bind_native_bounds(family['source_leg_id'], b, c, _utc(known), native)
        if path['status'] != 'connected_native_return_candidate':
            continue
        ownership = return_index.source_return_ownership(family, c, _utc(known), native)
        observations = ownership['internal_origin_observations']
        deep = (ownership['status'] == 'beyond_all_internal_push_origins' and observations and
                all(o['anchor_beyond_origin'] and o['first_later_close_beyond_origin_utc']
                    for o in observations))
        shallow = (ownership['status'] == 'inside_terminal_push_component' and observations and
                   ownership['terminal_component_relation'] == 'inside_terminal_push_component' and
                   all(not o['anchor_beyond_origin'] and not o['anchor_touches_origin']
                       for o in observations))
        if not (deep or shallow):
            continue
        return dict(schema='whole_return_source_reconsideration_v1',
            status='same_period_whole_excursion_measurement_candidate' if deep
                else 'same_period_shallow_return_measurement_candidate',
            known_at_utc=_utc(known), source_confirmed_at_utc=_utc(source_known),
            anchor=c, native_timeframe=native.timeframe,
            source_leg_id=family['source_leg_id'], return_path_id=path['return_path_id'],
            return_ownership_status=ownership['status'],
            return_component_leg_ids=path['component_leg_ids'],
            internal_origin_observations=observations,
            basis='aligned_source_connected_C_closes_through_all_internal_push_origins_with_A_held'
                if deep else 'aligned_complete_source_connected_same_period_shallow_C_inside_terminal_component',
            uses_later_target_outcome=False, source_admitted_at_B=False,
            structural_degree_adjudicated=False, trade_permission=False)
    return None


def _structure_observation(timeframe, source_leg_id, source_origin, source_terminal,
                           component_ids, *, local_leg_id=None, regime=None,
                           unordered_bar_times=None, intrabar_order_inferred=False):
    """Describe observable same-period nesting without assigning author degree.

    A connected envelope can contain several native pushes.  That fact is
    useful on the chart (it prevents a local pivot from looking like the
    outer source), but it is not enough to call the wave a confirmed author
    degree.  Keep the distinction explicit and source-time bounded.
    """
    component_ids = list(component_ids or [])
    component_count = len(component_ids)
    enclosing = component_count > 1 or source_leg_id != (local_leg_id or source_leg_id)
    return {
        'schema': 'same_period_structure_observation_v1',
        'native_timeframe': timeframe,
        'source_leg_id': source_leg_id,
        'local_leg_id': local_leg_id or source_leg_id,
        'source_origin': source_origin,
        'source_terminal': source_terminal,
        'component_leg_ids': component_ids,
        'component_count': component_count,
        'interior_unordered_bar_times': sorted(set(unordered_bar_times or [])),
        'intrabar_order_inferred': bool(intrabar_order_inferred),
        'scope': 'same_period_compound_envelope' if enclosing else 'same_period_single_swing',
        'nested_local_segment_present': enclosing,
        'regime_state_at_source': (regime or {}).get('state'),
        'structural_degree_adjudicated': False,
        'degree_status': 'unresolved_same_period_geometry_only',
        'evidence_basis': 'connected_native_extreme_envelope_and_component_chain',
        'lookahead_used': False,
        'trade_permission': False,
    }


def _first_unit_projection_receipt(family, projection, owner, native, envelope_verified):
    """Freeze reference availability at THIS anchor version's knowledge clock.

    Original AB supplies the length; the actual preceding wave supplies the
    return owner. A later deeper return cannot rewrite this version, and a
    target already visited before confirmation is historical evidence only.
    This is a reference receipt, never proof of author correction completion.
    """
    result=dict(schema='first_unit_projection_receipt_v1',projection_id=projection.get('projection_id'),
        measurement_source_leg_id=family['source_leg_id'],retraces_source_leg_id=owner['id'],
        native_timeframe=native.timeframe,known_at_utc=projection.get('known_at_utc'),
        original_unit_height=abs(family['source_terminal']['price']-family['source_origin']['price']),
        previous_wave_height=abs(owner['terminal']['price']-owner['origin']['price']),
        automatic_trade_permission=False,author_correction_end_adjudicated=False,
        execution_admission='blocked_research_only',reference_active_at_confirmation=False)
    try:
        anchor=projection['anchor'];known=_time(projection['known_at_utc'])
        dependencies=[family['known_at_utc'],owner['known'],anchor['confirmed_at_utc']]
        dependencies += [p['confirmed_at_utc'] for p in
            (family['source_origin'],family['source_terminal'],owner['origin'],owner['terminal'])]
        if known>native.cutoff or any(_time(t)>known for t in dependencies):
            return dict(result,state='unavailable',reason='source_or_anchor_dependency_after_version_clock')
        if not envelope_verified:
            return dict(result,state='unavailable',reason='native_return_extreme_not_verified')
        signed=family['source_terminal']['price']-family['source_origin']['price']
        target=anchor['price']+signed
        if not isclose(projection['target'],target,rel_tol=0,abs_tol=1e-8):
            return dict(result,state='unavailable',reason='target_does_not_reuse_original_AB')
        observation=native.outcome(family,anchor,known_override=known,as_of=projection['known_at_utc'])
        active=observation['status']=='unreached'
        return dict(result,state='reference_active_at_confirmation' if active else 'historical_or_unknown_at_confirmation',
            reason='original_AB_reused_with_actual_return_owner',target=target,
            observation_at_confirmation={k:observation[k] for k in
                ('status','event_bar_utc','event_known_at_utc','preconfirmation')},
            reference_active_at_confirmation=active)
    except (KeyError,TypeError,ValueError):
        return dict(result,state='unavailable',reason='incomplete_unit_or_anchor_clock')


def _continuation_unit_alternatives(family, projection, native):
    """Freeze conditional geometry at this return version's OWN clock.

    PDF207 and223 use author wave1/3/5. A native AB/C can only carry the
    corresponding hypotheses while wave degree/correction end stay unknown.
    No reached original 1:1 target automatically promotes the extension.
    """
    ordinal=projection.get('ordinal')
    if ordinal==2:
        references=[(1.,'book_wave3_if_AB_is_author_wave1',[207]),
                    (1.618,'book_wave3_if_AB_is_author_wave1',[207]),
                    (2.618,'user_research_extension_not_book_general_rule',[])]
    elif ordinal==3:
        references=[(.618,'book_wave5_if_middle_is_author_extended_wave3',[223]),
                    (1.,'book_wave5_if_middle_is_author_extended_wave3',[223])]
    else:
        references=[(1.,'user_range_reuses_original_unit',[])]
    anchor=projection['anchor'];known=projection['known_at_utc']
    signed=family['source_terminal']['price']-family['source_origin']['price']
    result=[]
    for ratio,basis,pages in references:
        target=anchor['price']+signed*ratio
        observation=native.outcome(family,anchor,known_override=_time(known),as_of=known,target_override=target)
        result.append(dict(ratio=ratio,target=target,basis=basis,source_pdf_pages=pages,
            known_at_utc=known,measurement_source_leg_id=family['source_leg_id'],
            retraces_source_leg_id=projection['retraces_source_leg_id'],
            anchor=dict(anchor),observation_at_confirmation=observation,
            geometry_available_at_confirmation=observation['status']=='unreached',
            original_unit_height=abs(signed),author_wave_mapping_adjudicated=False,
            author_correction_end_adjudicated=False,selected_for_execution=False,
            execution_admission='blocked_research_only',automatic_trade_permission=False))
    return dict(schema='original_unit_continuation_alternatives_v1',ordinal=ordinal,
        projection_id=projection['projection_id'],known_at_utc=known,
        anchor_basis='native_return_extreme_candidate_not_author_correction_terminal',
        selection_policy='preserve_all_conditional_hypotheses_without_ranking',
        options=result,automatic_trade_permission=False,order_api_called=False)


def _annotate_pullback_anchor_selection(family, native):
    """Record the deepest confirmed C for each same-period return episode.

    A family may legitimately contain several C versions: the first shallow
    pullback can be known before a later, deeper pullback is confirmed.  The
    archive must keep every version and its later outcome, while the current
    chart needs an explicit, causal choice instead of relying on list order.
    This helper only ranks already admitted native candidates; it does not
    admit a new C, infer intrabar order, or assign structural degree.
    """
    a, b = family.get('source_origin'), family.get('source_terminal')
    projections = family.get('projections') or []
    height = abs(float(b['price']) - float(a['price'])) if a and b else 0.0
    direction = family.get('direction_observation')
    episodes = {}
    for projection in projections:
        anchor = projection.get('anchor') or {}
        if not a or not b or not height or direction not in ('up', 'down'):
            continue
        owner = projection_owner(family, projection, family['timeframe'])
        if not owner:
            continue  # Never silently substitute original B for a third leg.
        origin, terminal = owner['origin'], owner['terminal']
        owner_height = abs(float(terminal['price']) - float(origin['price']))
        depth = (float(terminal['price']) - float(anchor['price'])) if direction == 'up' else \
            (float(anchor['price']) - float(terminal['price']))
        ratio = depth / owner_height if owner_height else None
        path = projection.get('return_wave_scope') or {}
        envelope_verified = (
            native.timeframe == family['timeframe']
            and path.get('native_timeframe') == family['timeframe']
            and path.get('status') in ('connected_native_return_candidate', 'native_return_bounds_candidate')
            and _same(path.get('return_origin') or {}, terminal)
            and _same(path.get('endpoint_candidate') or {}, anchor)
            and path.get('retraces_source_leg_id') == owner['id']
            and _time(path['known_at_utc']) <= _time(projection['known_at_utc'])
            and _time(projection['known_at_utc']) <= native.cutoff
            and native.return_envelope(terminal, anchor))
        evidence = dict(
            schema='same_period_deepest_pullback_anchor_v1',
            native_timeframe=family.get('timeframe'),
            source_leg_id=family.get('source_leg_id'),
            projection_id=projection.get('projection_id'),
            episode_id=projection.get('pullback_episode_id'),
            anchor=anchor,
            direction=direction,
            retraces_source_leg_id=owner['id'],
            retraced_wave_origin=origin,
            retraced_wave_terminal=terminal,
            retraced_wave_height=owner_height,
            depth_from_return_terminal=depth,
            retracement_ratio=ratio,
            external_native_extreme=envelope_verified,
            confirmed_at_utc=projection.get('known_at_utc'),
            source_origin_break_guard='C must remain strictly inside A-B; an origin break is reassessment, not ordinary pullback',
            structural_degree_adjudicated=False,
            trade_permission=False,
        )
        projection['pullback_anchor_evidence'] = evidence
        projection['first_unit_projection_receipt']=_first_unit_projection_receipt(
            family,projection,owner,native,envelope_verified)
        evidence['selected_at_confirmation']=False
        # Recording a failed envelope is not permission to select it as C.
        if (not envelope_verified or
                projection['first_unit_projection_receipt']['state']=='unavailable'):
            continue
        projection['first_unit_projection_receipt']['continuation_alternatives']=_continuation_unit_alternatives(
            family,projection,native)
        # Episode IDs are mutable observation revisions. Group by the stable
        # native return owner so a deeper later C replaces the earlier frame;
        # a real second/third segment has a different retraced A→B owner.
        owner_key = (owner.get('id'),
                     _key(origin), _key(terminal))
        key = ('owned-return', *owner_key) if owner else \
            (projection.get('ordinal'), projection.get('pullback_episode_id') or 'same-return')
        episodes.setdefault(key, []).append((projection, depth))

    selections = {}
    selected_ids = []
    for episode_key, rows in episodes.items():
        # Depth is primary.  Confirmation time is only a deterministic tie
        # breaker; later outcomes never influence this selection.
        selected, selected_depth = max(rows, key=lambda item: (
            item[1], _time(item[0].get('known_at_utc')), _time(item[0].get('anchor', {}).get('pivot_timestamp_utc'))))
        selected_ids.append(selected['projection_id'])
        key = '|'.join(map(str, episode_key))
        selections[key] = dict(
            ordinal=selected.get('ordinal'), episode_id=selected.get('pullback_episode_id'),
            selected_projection_id=selected['projection_id'],
            candidate_projection_ids=[row[0]['projection_id'] for row in rows],
            selected_anchor=selected['anchor'],
            retraces_source_leg_id=selected['retraces_source_leg_id'],
            depth_from_return_terminal=selected_depth,
            retracement_ratio=selected['pullback_anchor_evidence']['retracement_ratio'],
            selected_known_at_utc=selected.get('known_at_utc'),
            rule='deepest_confirmed_same_period_external_pullback_v1',
            structural_degree_adjudicated=False,
            trade_permission=False)
        for projection, depth in rows:
            # Immutable evidence at this version's OWN knowledge time. Do not
            # rewrite an early C as "superseded" using a later final low.
            then_known = [item for item in rows if
                          _time(item[0]['known_at_utc']) <= _time(projection['known_at_utc'])]
            then_selected = max(then_known, key=lambda item: (
                item[1], _time(item[0]['known_at_utc']),
                _time(item[0]['anchor']['pivot_timestamp_utc'])))[0]
            projection['pullback_anchor_evidence']['selected_at_confirmation'] = projection is then_selected

    family['pullback_anchor_selection'] = dict(
        schema='same_period_deepest_pullback_selection_v1',
        native_timeframe=family.get('timeframe'),
        source_leg_id=family.get('source_leg_id'),
        source_origin=a, source_terminal=b, direction=direction,
        source_height=height,
        selection_as_of_utc=family['as_of_utc'],
        episodes=selections,
        current_deepest_projection_ids=selected_ids,
        origin_break_guard='origin_break_is_reassessment_not_a_normal_C',
        structural_degree_adjudicated=False,
        trade_permission=False)


class _RegimeIndex:
    """The same swing-order hypothesis at each C, without scanning all history.

    A pivot before C can still be unconfirmed at C's knowledge time. Search
    backwards separately for the last two *known* highs/lows, not merely the
    last two pivots. No future outcome or present-day direction is consulted.
    """
    def __init__(self, points):
        self.points = {}
        self.times = {}
        for kind in (HIGH, LOW):
            rows = sorted((p for p in points if p['kind'] == kind),
                          key=lambda p:(p['pivot_timestamp_utc'], p['kind']))
            self.points[kind] = [(p, _time(p['confirmed_at_utc'])) for p in rows]
            self.times[kind] = [_time(p['pivot_timestamp_utc']) for p in rows]

    def at(self, known, terminal):
        cutoff = _time(terminal['pivot_timestamp_utc'])
        selected = []
        for kind in (HIGH, LOW):
            found = []
            end = bisect_right(self.times[kind], cutoff)
            for i in range(end-1, -1, -1):
                p, confirmed = self.points[kind][i]
                if confirmed <= known:
                    found.append(p)
                    if len(found) == 2:
                        break
            selected.extend(reversed(found))
        selected.sort(key=lambda p:(p['pivot_timestamp_utc'], p['kind']))
        return _regime(selected, known, terminal)


def build_regime_one_to_one(snapshot, timeframe, *, include_background=True,
                            review_completed_pair_in_transition=False,
                            review_medium_terminal_component=False,_background_reader=None):
    result = dict(method_version=METHOD, timeframe=timeframe,
                  snapshot_id=snapshot.get('snapshot_id'), as_of_utc=snapshot.get('as_of_utc'),
                  status='unavailable', families=[], turn_reviews=[], trade_permission=False,
                  execution_admission_changed=False, automatic_trade_permission=False,
                  session_policy=dict(scope='published_weekly_schedule_research_only',source_url=SOURCE_URL,
                      holidays_and_historical_dst_verified=False, missing_open_session_bars_excused=False),
                  interpretation='本级波段次序判断是研究解释；量尺不等于交易信号或必到目标。')
    try:
        if timeframe not in MINUTES or snapshot.get('automatic_trade_permission') is not False:
            raise ValueError('readonly native snapshot required')
        cutoff = _time(snapshot['as_of_utc'])
        # Compact chart packets keep the full native ledger in the report.
        state=resolve_native_timeframe_state(snapshot,timeframe)
        snapshot = {**snapshot, 'timeframe_states':{
            **(snapshot.get('timeframe_states') or {}), timeframe:state}}
        _, raw, legs = _native(snapshot, timeframe, cutoff)
        native = _NativeWindow(raw, timeframe, cutoff, research_calendar(snapshot, timeframe))
        if not native.times or any(a >= b for a,b in zip(raw, list(raw)[1:])):
            raise ValueError('ordered native bars required')
        valid = [leg for leg in legs if _leg(leg, timeframe, raw, cutoff)]
        push_balance=PushBalanceIndex(valid,timeframe)
        return_index=ReturnWaveIndex(valid,timeframe,source_bounds=legs)
        # Both source-time and return-time comparisons need the WHOLE known
        # predecessor, including verified unordered OHLC bounds. Omitting an
        # outside bar can shrink its origin to the last internal turn and
        # falsely report that the first opposite wave reclaimed the whole.
        # source_wave_scope revalidates those bounds at each observation's
        # own confirmation. Ordered sources/return edges still use `valid`;
        # a same-bar high/low never supplies an invented traversable edge.
        structure_index=WaveStructureIndex(legs,native)
        return_structure_index=structure_index
        background=RegimeBackgroundIndex(snapshot,timeframe,_reader=_background_reader) if include_background else None
        points_by_key = {_key(p):p for leg in valid for p in (leg['origin'],leg['terminal'])}
        points = sorted(points_by_key.values(), key=lambda p:(p['pivot_timestamp_utc'],p['kind']))
        # A confirmed low/high in an unordered outside bar is already a
        # known external C candidate. Do not wait for its NEXT sequential
        # leg to be confirmed, then backfill it into an earlier prefix.
        # Keep this bound inventory separate from directed source/stage legs.
        return_points_by_key={_key(p):p for leg in legs if
            known_envelope_component(leg,timeframe,raw,cutoff)
            for p in (leg['origin'],leg['terminal'])}
        return_points=sorted(return_points_by_key.values(),key=lambda p:(p['pivot_timestamp_utc'],p['kind']))
        stage_index = _RegimeIndex(points)
        families, deferred_families, root_by_leg, reviews_by_leg = [], [], {}, {}
        for leg in valid:
            a, b = leg['origin'], leg['terminal']
            known = max(_time(a['confirmed_at_utc']), _time(b['confirmed_at_utc']))
            review = dict(source_leg_id=leg['leg_id'], known_at_utc=_utc(known),
                          considered_as_first_wave=True, eligible_for_measurement=False, reasons=[])
            result['turn_reviews'].append(review)
            reviews_by_leg[leg['leg_id']] = review
            scope = source_wave_scope(legs, raw, timeframe, a, b, _utc(known),
                                      _window_index=native.envelope)
            if scope.get('status') != 'observed_same_period_zigzag_envelope':
                review['reasons'].append('native_outer_wave_unresolved')
                continue
            outer_a, outer_b = scope['origin'], scope['terminal']
            ta, tb = _time(outer_a['pivot_timestamp_utc']), _time(outer_b['pivot_timestamp_utc'])
            raw_signed = outer_b['price']-outer_a['price']
            direction = geometric_direction(outer_a, outer_b)
            if direction is None or not raw_signed:
                review['reasons'].append('ambiguous_outer_pivot_roles')
                continue
            up = direction == 'up'
            signed = abs(raw_signed) if up else -abs(raw_signed)
            low, high = sorted((outer_a['price'],outer_b['price']))
            extent_reason = _source_extent_reason(native, raw, timeframe, outer_a, outer_b)
            if extent_reason:
                review['reasons'].append(extent_reason)
                continue
            origin_bar, terminal_bar = raw[ta], raw[tb]
            lo, hi = native.bounds(ta, tb)
            departure = next((bar for bar in native.bars[lo+1:hi] if
                (bar['close'] > origin_bar['high'] if up else bar['close'] < origin_bar['low'])), None)
            if (not departure or (terminal_bar['close']-origin_bar['close'])*(1 if up else -1) <= 0):
                review['reasons'].append('no_directional_close_departure_from_origin_candle')
                continue
            regime = _regime(points, known, b)
            review['regime_at_source'] = regime
            # A weak first opposite wave still has a conditional measuring
            # interpretation. Speed alone cannot decide routine return vs a
            # larger adjustment. Bind its preceding WHOLE wave and actual
            # node observations; leave semantic role/degree competing.
            children = []
            first_compound = False
            structure_reclaim = None
            whole_return_reconsideration = None
            source_context = None
            component_ids = scope['component_source_leg_ids']
            if scope['internal_origin']:
                # A source admitted at its later C belongs to the historical
                # inventory from that C onward. It may support a later B only
                # when its own admission and target event were already known.
                # The event checks below keep the future outcome out of the
                # earlier source decision.
                available_families = families + deferred_families
                prior = [f for f in available_families if _same(f['source_origin'],outer_a)
                         and f['direction_observation']==('up' if up else 'down')
                         and _time(f['known_at_utc'])<=known
                         and _time(f['source_terminal']['pivot_timestamp_utc'])<tb]
                review['prior_same_origin_measurement_ids'] = [f['measurement_id'] for f in prior]
                seed = reviews_by_leg.get(component_ids[0])
                # A previously rejected short seed is not a forever-ban on A.
                # Current A/B has independently passed the complete native
                # envelope and close-departure checks above. With no earlier
                # measurement, this is its FIRST complete source, not proof
                # that a smaller 1:1 finished or wave degree increased.
                # Missing/unordered seed evidence remains unresolved.
                first_compound = bool(not prior and seed and
                    _time(seed['known_at_utc'])<=known and
                    seed['reasons'] in (['no_directional_close_departure_from_origin_candle'],
                                       ['source_not_complete_native_extreme_to_extreme'],
                                       ['source_native_history_gap_unresolved'],
                                       ['source_extreme_envelope_breached'],
                                       ['source_native_history_gap_and_extreme_envelope_unresolved']))
                if first_compound:
                    review['first_compound_seed_review'] = dict(source_leg_id=component_ids[0],
                        known_at_utc=seed['known_at_utc'],reasons=list(seed['reasons']))
                # A distinct first reclaim of the preceding whole structure
                # can coexist with an unfinished inner ruler. Its admission
                # has no dependency on that ruler's target or later outcome.
                # A first WHOLE structure reclaim is distinct from a
                # completed-pair trend promotion. Internal highs/lows may
                # still describe a transition when the native terminal close
                # first crosses the preceding complete wave's origin. Do not
                # suppress that independent first-source route while waiting
                # for a later swing-order trend label. The receipt below
                # still requires the same complete known predecessor and a
                # new terminal close; it does not confirm reversal/degree or
                # change the source-time regime label.
                if prior:
                    source_context=structure_index.review(outer_a,outer_b,_utc(known))
                    receipt=first_outer_structure_reclaim(source_context,prior)
                    review['outer_structure_reclaim_review']=receipt
                    if receipt['status']=='first_delivery_beyond_preceding_whole_origin':
                        structure_reclaim=receipt
                # Completed-pair promotion remains a separate route, using
                # only outcomes already observable at this source's B.
                for family in available_families:
                    if (_same(family['source_origin'],outer_a) and
                            family['direction_observation'] == ('up' if up else 'down') and
                            family['mode'] != 'range' and
                            _time(family['source_terminal']['pivot_timestamp_utc']) < tb and
                            any(p['outcome']['status']=='reached' and
                                _time(p['known_at_utc']) <= known and
                                _time(p['outcome']['event_known_at_utc']) <= known and
                                _time(p['outcome']['event_bar_utc']) <= tb
                                for p in family['projections'])):
                        children.append(family['measurement_id'])
                # Explicit research trial: a local four-pivot expansion can
                # coexist with an already completed same-origin pair. Keep
                # the transition label; test source coverage independently.
                transition_pair = bool(review_completed_pair_in_transition and children
                                       and regime['state'] == 'transition')
                if not first_compound and not structure_reclaim and not transition_pair and (not children or regime['state'] != 'trend' or regime['direction'] != ('up' if up else 'down')):
                    review['reasons'].append('internal_subpivot_requires_completed_trend_pair_not_arbitrary_restart')
                    # Keep the known geometry even when the outer extension is
                    # withheld.  Dropping this record made a later degree
                    # review unable to tell "candidate rejected by the current
                    # rule" from "no same-period wave was observed".  This is
                    # an evidence receipt only: it is not a chart family,
                    # projection, author node, or trade permission.
                    review['candidate_source'] = dict(
                        admission='withheld_unfinished_outer_extension',
                        native_timeframe=timeframe,
                        local_source_leg_id=leg['leg_id'],
                        outer_source_leg_id=scope['source_leg_id'],
                        local_origin=a,
                        local_terminal=b,
                        outer_origin=outer_a,
                        outer_terminal=outer_b,
                        component_source_leg_ids=list(component_ids),
                        signed_source_length=outer_b['price']-outer_a['price'],
                        known_at_utc=_utc(known),
                        structural_degree_adjudicated=False,
                        eligible_for_chart=False,
                        eligible_for_projection=False,
                        trade_permission=False,
                    )
                    # A new high/low that still sits inside an already named
                    # same-origin range is not a fresh trend whole source.
                    # Preserve its withheld geometry until the range boundary
                    # has its own exit evidence.
                    prior_range_contains_b = any(
                        f['mode'] == 'range' and
                        (f.get('regime_at_source') or {}).get('range_low') and
                        (f.get('regime_at_source') or {}).get('range_high') and
                        f['regime_at_source']['range_low']['price'] <= outer_b['price'] <=
                        f['regime_at_source']['range_high']['price']
                        for f in prior)
                    whole_return_reconsideration = None if prior_range_contains_b else _whole_return_reconsideration(
                        scope, regime, points, native, return_index, known)
                    if not whole_return_reconsideration:
                        continue
            elif leg['leg_id'] in root_by_leg:
                continue
            mode = ('range' if regime['state']=='range' else 'trend'
                    if regime['state']=='trend' and regime['direction']==('up' if up else 'down')
                    else 'turn_first_wave')
            identity = _id(snapshot['instrument'],snapshot['provider'],timeframe,
                           _key(outer_a),_key(outer_b),METHOD)
            family = dict(measurement_id=f'{timeframe}:regime:{identity}',
                source_leg_id=scope['source_leg_id'], timeframe=timeframe,
                snapshot_id=snapshot['snapshot_id'], as_of_utc=snapshot['as_of_utc'],
                source_origin=outer_a, source_terminal=outer_b, known_at_utc=_utc(known),
                direction_observation=direction, source_height=abs(signed),
                signed_source_length=signed, mode=mode, regime_at_source=regime,
                source_kind='completed_pair_outer_wave' if children and (mode=='trend' or review_completed_pair_in_transition and regime['state']=='transition') else 'structure_reclaim_outer_wave' if structure_reclaim else 'compound_first_wave' if first_compound else 'turn_first_wave',
                component_source_leg_ids=component_ids, nested_child_ids=children,
                interior_unordered_bar_times=sorted(set(scope.get('interior_unordered_bar_times') or [])),
                intrabar_order_inferred=False,
                departure_bar_utc=departure['timestamp_utc'], projections=[],
                eligible_for_chart=True, eligible_for_projection=False, trade_permission=False,
                parent_task_adjudicated=False,
                structural_degree_adjudicated=False,
                degree_boundary='Native-period extrema are not proof of structural wave degree; parent-return ownership remains under review.')
            if review_completed_pair_in_transition and children and regime['state']=='transition':
                family['source_admission_trial'] = {
                    'rule': 'completed_pair_independent_of_local_transition_label',
                    'known_at_utc': _utc(known), 'completed_child_ids': list(children),
                    'local_state_preserved': 'transition', 'production_default': False,
                    'structural_degree_adjudicated': False,
                }
            if whole_return_reconsideration:
                family.update(source_kind='whole_return_reconsidered_source',
                    source_confirmed_at_utc=_utc(known),
                    known_at_utc=whole_return_reconsideration['known_at_utc'],
                    whole_return_reconsideration=whole_return_reconsideration)
                review['candidate_source'].update(reconsidered_at_utc=family['known_at_utc'],
                    reconsidered_measurement_id=family['measurement_id'])
                review['measurement_known_at_utc']=family['known_at_utc']
            family['structure_observation'] = _structure_observation(
                timeframe, scope['source_leg_id'], outer_a, outer_b, component_ids,
                local_leg_id=leg['leg_id'], regime=regime,
                unordered_bar_times=scope.get('interior_unordered_bar_times'),
                intrabar_order_inferred=False)
            family['source_opposing_wave_context']=source_context or structure_index.review(outer_a,outer_b,_utc(known))
            family['same_direction_push_balance']=push_balance.at(outer_b,_utc(known))
            if mode=='range':
                family['range_boundary_exit_review']=native.range_at(regime,_time(family['known_at_utc']))
            if structure_reclaim:
                family['outer_structure_reclaim']=structure_reclaim
            # Keep successive deeper confirmed C versions. Reaching/failing
            # later must never decide whether an earlier version is retained.
            deepest = outer_b['price']
            for c in return_points:
                tc = _time(c['pivot_timestamp_utc'])
                kc = max(known, _time(c['confirmed_at_utc']))
                if tc <= tb or c['kind'] != outer_a['kind'] or kc > cutoff:
                    continue
                if kc < _time(family['known_at_utc']):
                    # The later whole-return receipt cannot admit an earlier
                    # internal C or backdate this family to source B.
                    continue
                if (c['price'] <= outer_a['price'] if up else c['price'] >= outer_a['price']):
                    family['source_origin_review'] = dict(status='ordinary_continuation_requires_reassessment',
                        point=c, known_at_utc=_utc(kc), sweep_recovery_path='not_adjudicated',
                        permanent_source_ban=False, trade_permission=False)
                    break
                if not (low < c['price'] < high) or not (c['price'] < deepest if up else c['price'] > deepest):
                    continue
                if not native.return_envelope(outer_b,c):
                    continue
                return_scope=return_index.bind_native_bounds(family['source_leg_id'],outer_b,c,_utc(kc),native)
                if return_scope['status'] not in ('connected_native_return_candidate','native_return_bounds_candidate'):
                    family.setdefault('unresolved_return_candidates',[]).append(return_scope)
                    continue
                # Stop reusing a finished old source as a fresh second leg.
                if any(p['outcome']['status']=='reached' and
                       _time(p['outcome']['event_known_at_utc']) <= kc for p in family['projections']):
                    break
                deepest = c['price']
                family['projections'].append(dict(
                    projection_id=f'{identity}:2:{_id(_key(c))}', ordinal=2,
                    pullback_episode_id=f'{identity}:return-after-source',
                    replaces_projection_id=family['projections'][-1]['projection_id'] if family['projections'] else None,
                    anchor=c, known_at_utc=_utc(kc), target=c['price']+signed,
                    anchor_scope='all_native_candles_after_B_through_C_plus_B_close',
                    B_opposite_wick_order_inferred=False,
                    anchor_native_timeframe=timeframe,
                    measurement_source_leg_id=family['source_leg_id'],
                    retraces_source_leg_id=family['source_leg_id'],
                    structural_degree_adjudicated=False,
                    return_wave_scope=return_scope,
                    outcome=native.outcome(family,c)))
                if mode=='range':
                    family['projections'][-1]['range_context_at_anchor']=native.range_at(regime,kc)
                family['projections'][-1]['return_structure_observation'] = {
                    'schema': 'same_period_return_structure_observation_v1',
                    'native_timeframe': timeframe,
                    'source_measurement_id': family['measurement_id'],
                    'return_source_leg_id': return_scope.get('retraces_source_leg_id'),
                    'return_origin': return_scope.get('return_origin'),
                    'return_terminal': return_scope.get('endpoint_candidate'),
                    'component_leg_ids': list(return_scope.get('component_leg_ids') or []),
                    'component_count': len(return_scope.get('component_leg_ids') or []),
                    'scope': 'same_period_return_chain',
                    'degree_status': 'unresolved_same_period_return_ownership',
                    'structural_degree_adjudicated': False,
                    'lookahead_used': False,
                    'trade_permission': False,
                }
            if mode == 'range':
                _append_range_sequence(family, points, native, return_index)
            # Keep all historical C versions, but publish an explicit
            # same-period deepest-anchor choice for the current view.  This
            # is intentionally after the range sequence has been built so
            # ordinal 3+ episodes are selected independently.
            # Keep degree observations separate from price outcomes. A C can
            # be on the right native timeframe yet still sit inside the last
            # smaller push. Do not label that as a proven whole-source return.
            family['return_ownership_by_projection_id']={
                p['projection_id']:return_index.projection_return_ownership(family,p,native)
                for p in family['projections']}
            _annotate_pullback_anchor_selection(family, native)
            for projection in family['projections']:
                projection['target_structure_relation']=projection_structure_relation(family,projection)
                projection['return_structure_review']=return_structure_index.return_review(family,projection)
                projection['return_process_review']=return_process_review(family,projection,
                    stage_index.at(_time(projection['known_at_utc']),projection['anchor']))
            if background:
                family['background_at_source_confirmation']=background.at(family,_utc(known),outer_b,'source_terminal')
                for projection in family['projections']:
                    projection['background_at_anchor_confirmation']=background.at(
                        family,projection['known_at_utc'],projection['anchor'],'return_anchor')
                    projection['background_at_anchor_confirmation']['source_node_continuity']=background.track_source_nodes(
                        family['background_at_source_confirmation'],projection['background_at_anchor_confirmation'])
            # Delayed candidates do not retroactively change B-time admission
            # of other sources, or serve as completed children in this pass.
            (deferred_families if whole_return_reconsideration else families).append(family)
            root_by_leg[leg['leg_id']] = family
            review.update(eligible_for_measurement=True, measurement_id=family['measurement_id'],
                          reasons=['whole_excursion_reconsidered_at_same_period_return' if whole_return_reconsideration else
                                   'completed_trend_pair_outer_source' if children else
                                   'first_delivery_beyond_preceding_whole_origin' if structure_reclaim else
                                   'first_complete_compound_outer_source' if first_compound else
                                   'native_outer_first_wave_with_close_departure'])
        families.extend(deferred_families)
        # Research-only native boundary review.  The ordinary family reader
        # retains the composite outer source; this optional layer exposes a
        # single last-component A→B candidate so the medium current-period
        # frame can be reviewed without admitting every internal turn.
        if review_medium_terminal_component:
            medium_rows = derive_medium_terminal_components(
                families, legs, timeframe, _utc(cutoff))
            for medium in medium_rows:
                medium['review_only'] = True
                medium['eligible_for_chart'] = False
                medium['eligible_for_projection'] = False
                families.append(medium)
        # Keep the relationship in both directions.  The outer family already
        # records ``nested_child_ids`` when a completed earlier 1:1 becomes
        # the first leg of this larger source.  Without the reverse link the
        # child looked unrelated in the compact packet and the chart could not
        # explain why two same-period measurements overlap.  This is only an
        # observed same-period relationship; it does not adjudicate author
        # wave degree or promote a parent target.
        by_measurement = {family['measurement_id']: family for family in families}
        for family in families:
            for child_id in family.get('nested_child_ids') or []:
                child = by_measurement.get(child_id)
                if child is None:
                    continue
                child.setdefault('nested_parent_measurement_ids', [])
                if family['measurement_id'] not in child['nested_parent_measurement_ids']:
                    child['nested_parent_measurement_ids'].append(family['measurement_id'])
                    # The reverse ID is an archive pointer, not an observation
                    # available at the child's earlier B. Consumers must use
                    # this relation's own knowledge time for causal replay.
                    child.setdefault('nested_parent_relations', []).append(dict(
                        measurement_id=family['measurement_id'],
                        native_timeframe=timeframe,
                        known_at_utc=family['known_at_utc'],
                        relation='completed_measurement_within_outer_source',
                        structural_degree_adjudicated=False,
                        trade_permission=False))
        attach_return_measurements(families,native)
        result.update(status='native_regime_measurements_reviewed', families=families,
                      reviewed_turn_count=len(result['turn_reviews']), family_count=len(families),
                      native_bar_count=len(raw), window_from_utc=_utc(native.times[0]),
                      window_through_utc=_utc(native.times[-1]))
    except (KeyError, ValueError, TypeError, OverflowError) as error:
        result['error'] = str(error)
    return result


def _append_range_sequence(family, points, native, return_index):
    """No arbitrary third-leg ceiling; each new C needs its actual prior wave.

    Termination is structural/data-dependent: no reached prior projection,
    no confirmed actual terminal, no bound return, or no admissible C. Every
    new episode advances beyond the preceding terminal in native time.
    """
    ordinal = 3
    while True:
        before = len(family['projections'])
        _append_range_leg(family, points, native, return_index, ordinal)
        if len(family['projections']) == before:
            return
        ordinal += 1


def _append_range_leg(family, points, native, return_index, ordinal):
    """Range: reuse the FIRST height, do not promote the completed pair.

    Every later leg is conditional, never an obligation to reverse at target.
    A sweep is reported only against a pre-existing named swing boundary.
    """
    second = next((p for p in family['projections'] if p['ordinal']==ordinal-1 and
                   p['outcome']['status']=='reached'),None)
    if second is None:
        return
    up = family['direction_observation']=='up'
    a, b = family['source_origin'], family['source_terminal']
    hit_known = _time(second['outcome']['event_known_at_utc'])
    end = next((p for p in points if p['kind']==b['kind'] and
                _time(p['pivot_timestamp_utc']) >= _time(second['outcome']['event_bar_utc']) and
                _time(p['confirmed_at_utc']) >= hit_known),None)
    if end is None:
        return
    second_known=max(_time(second['known_at_utc']),_time(end['confirmed_at_utc']),hit_known)
    second_path=return_index.bind(family['source_leg_id'],second['anchor'],end,_utc(second_known))
    second_start,second_end=_time(second['anchor']['pivot_timestamp_utc']),_time(end['pivot_timestamp_utc'])
    second_low,second_high=sorted((second['anchor']['price'],end['price']))
    second_envelope=(native.complete(second_start,second_end) and native.envelope.contains(
        native.raw,native.timeframe,second_start,second_end,second_low,second_high))
    if second_path['status']!='connected_native_return_candidate' or not second_envelope:
        unresolved=dict(origin=second['anchor'],terminal=end,
            known_at_utc=_utc(second_known),native_path=second_path,
            native_envelope_ok=second_envelope,reason='actual_second_wave_not_bound_no_third_anchor_owner'
                if ordinal==3 else 'actual_preceding_wave_not_bound_no_next_anchor_owner')
        if ordinal==3:
            family['unresolved_range_second_wave']=unresolved
        else:
            family.setdefault('unresolved_range_measured_waves',{})[str(ordinal-1)]=unresolved
        return
    # AB supplies the HEIGHT, but the next return retraces the actual second
    # C2->D2 wave. Its endpoint is the observed extreme, not the target price.
    span_role='second-span' if ordinal==3 else f'range-span:{ordinal-1}'
    second_span_id=f"{family['measurement_id']}:{span_role}:{_id(_key(second['anchor']),_key(end))}"
    second_span=dict(wave_id=second_span_id,origin=second['anchor'],terminal=end,
        measurement_projection_id=second['projection_id'],
        known_at_utc=_utc(second_known),component_source_leg_ids=second_path['component_leg_ids'],
        native_envelope_ok=True,native_timeframe=native.timeframe,structural_degree_adjudicated=False)
    if ordinal==3:
        family['range_second_wave']=second_span
    else:
        # Freeze the price event known by this actual terminal; later context
        # readers must not consult a subsequently edited/final outcome label.
        second_span['completion_observation']=native.outcome(family,second['anchor'],
            known_override=_time(second['known_at_utc']),as_of=_utc(second_known))
        family.setdefault('range_measured_waves',{})[str(ordinal-1)]=second_span
    boundary=family['regime_at_source'].get('range_high' if up else 'range_low')
    observation = dict(terminal=end, boundary=boundary,known_at_utc=_utc(second_known),
        boundary_excursion=bool(boundary and (end['price'] > boundary['price'] if up else end['price'] < boundary['price'])),
        reversal_confirmed=False)
    if ordinal==3:
        family['range_terminal_observation']=observation
    else:
        family.setdefault('range_sequence_reviews',{})[str(ordinal)]={'terminal_observation':observation}
    # Internal swing order does not retire the named outer range. SNR and
    # measuring families consume the same native cross/follow/gap evidence.
    # Later exits are rechecked at EACH C, not frozen at the prior terminal.
    range_read=native.range_at(family['regime_at_source'],second_known)
    family.setdefault('range_boundary_exit_review',range_read)
    after_b=_time(b['pivot_timestamp_utc'])
    beyond=lambda bar: bool(boundary and (bar['close']>boundary['price'] if up else bar['close']<boundary['price']))
    if range_read['state']=='range_boundary_accepted_exit':
        transition = dict(state='outer_range_close_break_with_follow',
            known_at_utc=range_read['ended_by']['known_at_utc'], boundary=boundary,
            exit_evidence=range_read['ended_by'],trade_permission=False)
        if ordinal==3:
            family['range_transition_review']=transition
        else:
            family['range_sequence_reviews'][str(ordinal)]['transition_review']=transition
    boundary_events=[]
    prior_state='inside_range'
    for stamp,bar in zip(native.times,native.bars):
        if stamp <= after_b:
            continue
        state='outside_reference' if beyond(bar) else 'inside_range'
        if state != prior_state:
            boundary_events.append(dict(state=state,bar_open_utc=_utc(stamp),
                known_at_utc=_utc(stamp+native.duration),close=bar['close']))
        prior_state=state
    family['range_boundary_events']=boundary_events
    family['current_boundary_read']=dict(state=prior_state,boundary=boundary,
        known_at_utc=_utc(native.times[-1]+native.duration),
        interpretation='外侧收盘与返回事实；突破延续和区间恢复仍须合看力度，非反转确认。',
        trade_permission=False)
    deepest=end['price']
    for c in points:
        if c['kind']!=a['kind'] or _time(c['pivot_timestamp_utc']) <= _time(end['pivot_timestamp_utc']):
            continue
        if (c['price'] <= a['price'] if up else c['price'] >= a['price']):
            break
        if not (c['price']<deepest if up else c['price']>deepest):
            continue
        start, finish = _time(end['pivot_timestamp_utc']),_time(c['pivot_timestamp_utc'])
        if not native.return_envelope(end,c):
            continue
        known=max(second_known,_time(c['confirmed_at_utc']))
        return_scope=return_index.bind(second_span_id,end,c,_utc(known))
        if return_scope['status']!='connected_native_return_candidate':
            family.setdefault('unresolved_return_candidates',[]).append(return_scope)
            continue
        range_at_c=native.range_at(family['regime_at_source'],known)
        broke=range_at_c['state']=='range_boundary_accepted_exit'
        if range_at_c['state']=='coverage_lost' or broke and not range_at_c['inside_original_range']:
            family.setdefault('withheld_range_returns',[]).append(dict(anchor=c,
                known_at_utc=_utc(known),ordinal=ordinal,range_context_at_anchor=range_at_c,
                reason='named_range_coverage_unknown' if range_at_c['state']=='coverage_lost'
                    else 'accepted_range_exit_without_observed_body_return'))
            continue
        if any(p['ordinal']==ordinal and p['outcome']['status']=='reached' and
               _time(p['outcome']['event_known_at_utc']) <= known for p in family['projections']):
            break
        deepest=c['price']
        episode='return-after-second-leg' if ordinal==3 else f'return-after-leg:{ordinal-1}'
        family['projections'].append(dict(projection_id=f"{family['measurement_id']}:{ordinal}:{_id(_key(c))}",
            ordinal=ordinal, pullback_episode_id=f"{family['measurement_id']}:{episode}",
            replaces_projection_id=next((p['projection_id'] for p in reversed(family['projections']) if p['ordinal']==ordinal),None),
            anchor=c, known_at_utc=_utc(known), target=c['price']+family['signed_source_length'],
            anchor_native_timeframe=native.timeframe,
            measurement_source_leg_id=family['source_leg_id'],
            retraces_source_leg_id=second_span_id,
            structural_degree_adjudicated=False,
            return_wave_scope=return_scope,
            range_context_at_anchor=range_at_c,
            boundary_interpretation='range_return_competing_with_breakout_retest' if broke else 'within_original_range_hypothesis',
            outcome=native.outcome(family,c,known_override=known)))
        family['projections'][-1]['return_structure_observation'] = {
            'schema': 'same_period_return_structure_observation_v1',
            'native_timeframe': native.timeframe,
            'source_measurement_id': family['measurement_id'],
            'return_source_leg_id': return_scope.get('retraces_source_leg_id'),
            'return_origin': return_scope.get('return_origin'),
            'return_terminal': return_scope.get('endpoint_candidate'),
            'component_leg_ids': list(return_scope.get('component_leg_ids') or []),
            'component_count': len(return_scope.get('component_leg_ids') or []),
            'scope': 'same_period_range_return_chain',
            'degree_status': 'unresolved_same_period_return_ownership',
            'structural_degree_adjudicated': False,
            'lookahead_used': False,
            'trade_permission': False,
        }
