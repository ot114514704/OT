"""Receipt-independent event-time observed inventory, not an author target map.

Closed D1/W1 opens enter only at their supplied known clock; last three
*available* native periods are retained at each bar open, not at scene cutoff.
UTC current-day opens need an exact M1 boundary witness and expire at midnight.
Missing input is unknown, never reconstructed from a later D1 open.
"""
from copy import deepcopy
from datetime import datetime, timedelta
from hashlib import sha256
import json

VERSION='digger_event_time_inventory_v1'


def digest(value):
    return sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def time(value):
    t=datetime.fromisoformat(value.replace('Z','+00:00'))
    if t.tzinfo is None:raise ValueError('inventory_aware_clock_required')
    return t


def iso(value):return value.isoformat().replace('+00:00','Z')


def _source(row,tf,kind,provider,instrument,feed):
    position=f'{provider}:{instrument}:{tf}:period_open:{row["timestamp_utc"]}'
    body=dict(feed_id=feed,position_object_id=position,native_timeframe=tf,
        source_timeframe='M1' if kind=='boundary_M1_open' else tf,
        source_kind=kind,price=row['open'],known_at_utc=row['known_at_utc'],source_bar=deepcopy(row))
    return dict(source_version_id=digest(body),**body)


def _neighbours(sources,own,close):
    result={'above':[],'below':[],'at':[]}
    for s in sources:
        if s['position_object_id']==own['position_object_id']:continue
        delta=s['price']-close;name='above' if delta>0 else 'below' if delta<0 else 'at'
        result[name].append(dict(position_object_id=s['position_object_id'],source_version_id=s['source_version_id'],
            native_timeframe=s['native_timeframe'],price=s['price'],known_at_utc=s['known_at_utc'],distance_price=abs(delta)))
    for name,values in result.items():
        nearest=min((v['distance_price'] for v in values),default=None)
        result[name]=sorted((v for v in values if v['distance_price']==nearest),key=lambda v:v['source_version_id'])
    return result


def display_events(inventory):
    """Native rendering only: JSON/main task consumption keep full history."""
    counts={};selected=[]
    for event in reversed(inventory.get('events',[])):
        sid=event['source_version_id']
        if counts.get(sid,0)>=24:continue
        selected.append(event);counts[sid]=counts.get(sid,0)+1
        if len(selected)>=256:break
    return list(reversed(selected))


def build(clean, *, provider,instrument,calendar,cutoff_utc,chart_timeframe,minutes):
    inputs={tf:deepcopy(clean.get(tf,[])) for tf in ('D1','W1','M1')}
    rows=clean.get(chart_timeframe,[]);cutoff=time(cutoff_utc)
    feed_body=dict(provider=provider,instrument=instrument,calendar=deepcopy(calendar),
        clock_model='supplied_native_closed_bar_known_at_not_live_arrival')
    feed=digest(feed_body)
    history={tf:[_source(b,tf,'closed_native_period_open',provider,instrument,feed) for b in inputs[tf]] for tf in ('D1','W1')}
    boundary_supported=calendar.get('timezone')=='UTC' and calendar.get('day_boundary')=='00:00'
    boundaries={b['timestamp_utc']:_source(b,'D1','boundary_M1_open',provider,instrument,feed)
        for b in inputs['M1'] if boundary_supported and time(b['timestamp_utc']).time().isoformat()=='00:00:00'}
    clocks={s['source_version_id']:time(s['known_at_utc']) for group in list(history.values())+[list(boundaries.values())] for s in group}
    maps={};used={}
    def at(instant):
        members=[];counts={}
        for tf,values in history.items():
            active=[s for s in values if clocks[s['source_version_id']]<=instant][-3:]
            members.extend(active);counts[tf]=len(active)
        midnight=instant.replace(hour=0,minute=0,second=0,microsecond=0)
        current=boundaries.get(iso(midnight))
        observed=bool(current and clocks[current['source_version_id']]<=instant)
        if observed:members.append(current)
        coverage=dict(closed_period_counts=counts,
            closed_history='observed_native_suffix_not_guaranteed_calendar_complete',
            current_day_open='exact_boundary_M1_observed' if observed else
                'boundary_not_observed_at_event_time' if boundary_supported else 'calendar_boundary_unverified',
            author_map_complete=False)
        known=max((s['known_at_utc'] for s in members),key=time,default=None)
        body=dict(feed_id=feed,member_source_version_ids=sorted(s['source_version_id'] for s in members),
            known_at_utc=known,coverage=coverage,retention_rule='last_three_known_native_closed_periods_per_D1_W1_plus_witnessed_current_UTC_day_open')
        map_id=digest(body);maps[map_id]=dict(inventory_version_id=map_id,**body)
        used.update({s['source_version_id']:s for s in members})
        return maps[map_id],members
    timeline=[];states={};events=[]
    for row in rows:
        opened=time(row['timestamp_utc']);inventory,members=at(opened)
        timeline.append(dict(bar_open_utc=row['timestamp_utc'],inventory_version_id=inventory['inventory_version_id']))
        for s in members:
            sid=s['source_version_id'];state=states.setdefault(sid,dict(previous=None,decisive=None,cross=None,
                touching=False,clusters=0,first=None,events=[],gapped=False,
                left_censored=opened!=clocks[sid]))
            prior=state['previous']
            if prior is not None and opened-time(prior['timestamp_utc'])!=timedelta(minutes=minutes[chart_timeframe]):
                state['gapped']=True;state['touching']=False
            side=(row['close']>s['price'])-(row['close']<s['price'])
            touch=row['low']<=s['price']<=row['high']
            if touch and not state['touching']:state['clusters']+=1
            cross=state['decisive'] is not None and side not in (0,state['decisive'])
            if touch and state['first'] is None:state['first']=row['timestamp_utc']
            if touch or cross:
                kind=('close_return_after_cross' if cross and state['cross'] and side==state['cross']['from_side'] else
                    'close_cross' if cross else 'touch_close_on_level' if side==0 else
                    'probe_closed_on_prior_side' if side==state['decisive'] else 'touch_without_known_approach')
                known=max(filter(None,(s['known_at_utc'],inventory['known_at_utc'],row['known_at_utc'],state.get('known_at_utc'))),key=time)
                body=dict(source_version_id=sid,position_object_id=s['position_object_id'],
                    inventory_version_id=inventory['inventory_version_id'],feed_id=feed,
                    native_timeframe=chart_timeframe,level_native_timeframe=s['native_timeframe'],price=s['price'],
                    bar_open_utc=row['timestamp_utc'],closed_at_utc=row['closed_at_utc'],known_at_utc=known,
                    source_ohlc={k:row[k] for k in ('open','high','low','close')},kind=kind,touches=touch,close_side=side,
                    prior_decisive_close_side=state['decisive'],crosses_after_on_level=bool(cross and prior and prior['close']==s['price']),
                    prior_cross_event_id=state['cross']['event_id'] if cross and state['cross'] else None,
                    contact_cluster_number=state['clusters'] if touch else None,
                    first_visible_contact=touch and state['first']==row['timestamp_utc'],left_censored=state['left_censored'],
                    first_contact_proven_in_closed_prefix=bool(touch and state['first']==row['timestamp_utc'] and not state['left_censored'] and not state['gapped']),
                    continuity='gap_or_calendar_unresolved' if state['gapped'] else 'contiguous_observed_native_bars',
                    available_neighbours=_neighbours(members,s,row['close']),intrabar_order='unknown',
                    level_price_traded_witness='bar_range_contains_level' if touch else 'not_observed_gap_cross_possible',
                    author_hold_fold='unknown',author_next_in_line_object_id=None,owner_equivalence=False,entry_permission=False)
                # Revision identity includes inventory/source/measurement clocks, never a scene id.
                event=dict(event_id=VERSION+':'+digest(body),**body)
                events.append(event);state['events'].append(event['event_id'])
                if cross:state['cross']=dict(event_id=event['event_id'],from_side=state['decisive'])
            state['known_at_utc']=max(filter(None,(row['known_at_utc'],state.get('known_at_utc'))),key=time)
            if side:state['decisive']=side
            state['previous']=row;state['touching']=touch
    current,members=at(cutoff);active={s['source_version_id'] for s in members}
    streams=[dict(source_version_id=sid,position_object_id=used[sid]['position_object_id'],
        native_timeframe=used[sid]['native_timeframe'],event_ids=state['events'],
        active_in_current_inventory=sid in active,left_censored=state['left_censored'],
        retirement_meaning='not_retained_in_current_observed_map_not_author_fold') for sid,state in sorted(states.items())]
    known=max((b['known_at_utc'] for group in inputs.values() for b in group),key=time,default=None)
    return dict(schema=VERSION,feed_identity=dict(feed_id=feed,**feed_body),source_inputs=inputs,
        source_inputs_sha256=digest(inputs),source_versions=[used[k] for k in sorted(used)],
        inventory_versions=[maps[k] for k in sorted(maps)],bar_inventory_refs=timeline,
        current_inventory_version_id=current['inventory_version_id'],source_streams=streams,events=events,
        chart_timeframe=chart_timeframe,as_of_utc=cutoff_utc,known_at_utc=known,
        source_window_start_utc=rows[0]['timestamp_utc'] if rows else None,
        source_window_end_utc=rows[-1]['closed_at_utc'] if rows else None,
        sequence_scope='observed_inventory_membership_only_including_retired_source_versions',
        current_day_source_switch='M1_boundary_and_closed_D1_are_distinct_source_versions_no_state_transfer',
        inventory_removal_meaning='retention_not_author_fold',neighbour_role='observed_geometric_candidates_not_author_target',
        read_only=True,automatic_trade_permission=False,future_bars_used=False,entry_permission=False)
