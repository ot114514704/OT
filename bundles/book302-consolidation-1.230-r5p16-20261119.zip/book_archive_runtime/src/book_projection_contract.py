"""Native-source identity and finite display projection for Book lines.

This is the production-side contract distilled from W4 r7. It never selects
anchors and never recalculates a slope on the display timeframe. Owned-axis
lines use finite segments at the production exit; older source objects are
retained. Cross-period publication still requires native chart validation.
"""
from copy import deepcopy
from hashlib import sha256
from datetime import datetime, timezone
from fractions import Fraction
from math import isfinite

SUPPORTED = {'M1','M5','M15','M30','H1','H4','D1','W1'}
PERIOD_SECONDS = dict(M1=60,M5=300,M15=900,M30=1800,H1=3600,
                      H4=14400,D1=86400,W1=604800)

def _epoch(value):
    if isinstance(value,(int,float)): return float(value)
    return datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()

def _iso(value):
    return datetime.fromtimestamp(float(value),timezone.utc).isoformat().replace('+00:00','Z')

def _timestamp_like(value, template):
    """Keep the source packet's timestamp representation at the display edge."""
    return _iso(value) if isinstance(template, str) else float(value)

def _digest(value):
    import json
    return sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def annotate_native_identity(obj, *, provider='HistData', instrument='Machine1.HistData.XAUUSD',
                             clock_id='UTC:HistData'):
    """Add immutable source identity without changing geometry or ownership."""
    out=deepcopy(obj); ev=out.setdefault('evidence',{})
    tf=ev.get('native_timeframe') or ev.get('source_timeframe') or out.get('timeframe')
    if tf not in SUPPORTED: return out
    previous=ev.get('native_source_identity') or {}
    source_line_id=(ev.get('projection_source_line_id') or
                    previous.get('source_line_id') or out.get('id',''))
    identity=dict(provider=provider,instrument=instrument,native_timeframe=tf,
                  wave_owner=out.get('owner_id',''),family=ev.get('coefficient_family') or ev.get('display_role',''),
                  source_line_id=source_line_id,source_points=deepcopy(ev.get('ruler_identity') or out.get('points') or []),
                  construction_known_at_utc=ev.get('construction_known_at_utc') or out.get('known_at_utc'),
                  clock_id=clock_id,policy_version=ev.get('policy_version') or out.get('source_id',''))
    identity['formation_hash']=_digest(identity)
    ev['native_source_identity']=identity
    ev['native_timeframe']=tf;ev['display_timeframe']=out.get('timeframe',tf)
    ev['display_projection']='native_same_period' if out.get('timeframe',tf)==tf else 'pending_verified_projection'
    ev['anchors_snapped']=False;ev['reaggregated']=False
    return out

def project_native_line(obj, native_bars, *, display_timeframe, provider='HistData',
                        instrument='Machine1.HistData.XAUUSD', source_clock_id='UTC:HistData',
                        chart_clock_id='UTC:HistData', cutoff_utc=None,
                        timestamp_format='native'):
    """Copy a native finite line into a display packet, splitting unknown gaps.

    ``native_bars`` are ordered source bars with timestamp_utc and optional
    closed_at_utc. The target chart supplies no prices and no confirmation.
    """
    ev=obj.get('evidence',{});src=ev.get('native_source_identity')
    if not src: raise ValueError('native_source_identity_required')
    frozen={k:v for k,v in src.items() if k!='formation_hash'}
    if src.get('formation_hash')!=_digest(frozen): raise ValueError('native_identity_hash_changed')
    if src.get('wave_owner')!=obj.get('owner_id',''): raise ValueError('native_owner_changed')
    if src.get('source_points')!=(ev.get('ruler_identity') or obj.get('points') or []):
        raise ValueError('native_source_points_changed')
    native_tf=src['native_timeframe']
    if native_tf not in SUPPORTED or display_timeframe not in SUPPORTED: raise ValueError('unsupported_period')
    if src['provider']!=provider or src['instrument']!=instrument: raise ValueError('foreign_feed_or_instrument')
    if source_clock_id!=chart_clock_id or src['clock_id']!=source_clock_id: raise ValueError('verified_identity_clock_required')
    if not native_bars: raise ValueError('native_data_pending')
    if any(r.get('timeframe',native_tf)!=native_tf for r in native_bars):
        raise ValueError('mixed_native_periods')
    times=[_epoch(r['timestamp_utc']) for r in native_bars]
    if any(not isfinite(t) for t in times) or any(b<=a for a,b in zip(times,times[1:])):
        raise ValueError('native_times_not_strictly_increasing')
    pos={t:i for i,t in enumerate(times)}
    points=obj.get('points') or []
    if len(points)!=2 or any(_epoch(p[0]) not in pos for p in points): raise ValueError('source_vertex_outside_native_context')
    left,right=pos[_epoch(points[0][0])],pos[_epoch(points[1][0])]
    if left>=right: raise ValueError('native_vertex_order')
    if any(not isfinite(float(p[1])) for p in points): raise ValueError('nonfinite_source_price')
    if cutoff_utc is not None:
        cutoff=_epoch(cutoff_utc)
        if (_epoch(obj['known_at_utc'])>cutoff or
                _epoch(src['construction_known_at_utc'])>cutoff or
                any(_epoch(native_bars[k].get('closed_at_utc',times[k]+PERIOD_SECONDS[native_tf]))>cutoff
                    for k in range(left,right+1))):
            raise ValueError('unclosed_or_future_native_line')
    # Reconstruct from the named native anchors, never from target OHLC.
    # This avoids accumulating the float rounding of an extended endpoint.
    named=ev.get('ruler_identity')
    family=ev.get('coefficient_family')
    if family in ('OUTER','RETURN_CE_D','RESUME_DF_C') and named:
        if len(named)!=(2 if family=='OUTER' else 3): raise ValueError('incomplete_native_coefficients')
        if any(_epoch(p[0]) not in pos for p in named): raise ValueError('native_coefficient_outside_context')
        a,b=named[:2];i,j=pos[_epoch(a[0])],pos[_epoch(b[0])]
        if i>=j: raise ValueError('native_coefficient_order')
        slope=(Fraction(str(b[1]))-Fraction(str(a[1])))/(j-i)
        # RETURN_CE_D uses C→E shifted through D; RESUME_DF_C uses D→F
        # shifted back through C.  In both cases the third native point is
        # the affine origin, never the already projected display endpoint.
        anchor=named[2] if family in ('RETURN_CE_D','RESUME_DF_C') else a
        origin=pos[_epoch(anchor[0])];price=Fraction(str(anchor[1]))
        level=lambda k:price+slope*(k-origin)
        if any(abs(float(level(pos[_epoch(t)]))-float(p))>1e-7 for t,p in points):
            raise ValueError('native_display_coefficient_mismatch')
    else:
        price=Fraction(str(points[0][1]));slope=(Fraction(str(points[1][1]))-price)/(right-left)
        level=lambda k:price+slope*(k-left)
    # The selected source has already passed the owned-axis wick test.  Repeat
    # the invariant at this production boundary so a malformed or stale source
    # cannot become a visible line that cuts through a native candle.
    side=ev.get('geometry_side')
    if side in ('lower','upper'):
        crossings=[]
        for k in range(left,right+1):
            row=native_bars[k]
            line=float(level(k))
            if side=='lower' and float(row['low']) < line-1e-9:
                crossings.append(_iso(times[k]))
            elif side=='upper' and float(row['high']) > line+1e-9:
                crossings.append(_iso(times[k]))
        if crossings:
            raise ValueError('native_price_crossing')
    # Do not invent continuity from the next open when closed_at is absent.
    # The declared native period supplies its nominal close. Explicit shortened
    # bars are allowed, but changes of time step need separate affine segments.
    ranges=[];isolated=[];gaps=[];changes=[];start=left;step=None
    def finish(a,b):
        if a<b:ranges.append((a,b))
        else:isolated.append(a)
    for k in range(left,right):
        close=_epoch(native_bars[k].get('closed_at_utc',times[k]+PERIOD_SECONDS[native_tf]))
        nxt=times[k+1]
        delta=nxt-times[k]
        if abs(close-nxt)>1e-6:
            finish(start,k);start=k+1;step=None;gaps.append(_iso(nxt))
        else:
            if step is not None and abs(step-delta)>1e-6:
                finish(start,k);start=k;changes.append(_iso(times[k]))
            step=delta
    finish(start,right)
    if not ranges: raise ValueError('no_finite_native_segment')
    result=[]
    for a,b in ranges:
        seg=deepcopy(obj)
        # Endpoint extension and display-period changes do not rename a source.
        # The first finite piece retains the source ID; subsequent pieces use
        # the immutable source ID and their native starting timestamp only.
        seg['id']=(obj['id'] if not result else
                   'p'+sha256(f"{obj['id']}|{times[a]}".encode()).hexdigest()[:23])
        # Projection packets follow the native bar feed's timestamp contract.
        # A split segment must therefore remain readable even when the source
        # object stored epoch seconds while the feed stores ISO UTC strings.
        timestamp_template=(0 if timestamp_format == 'epoch'
                            else native_bars[left].get('timestamp_utc'))
        if timestamp_format not in ('native','epoch'):
            raise ValueError('unsupported_timestamp_format')
        seg['points']=[[_timestamp_like(times[a],timestamp_template),float(level(a))],
                       [_timestamp_like(times[b],timestamp_template),float(level(b))]]
        if a==left and b==right:seg['points']=deepcopy(points)
        seg['timeframe']=display_timeframe
        se=seg.setdefault('evidence',{});se.update(source_line_id=obj['id'],
            projection_source_line_id=obj['id'],native_timeframe=native_tf,
            display_timeframe=display_timeframe,clock_id=source_clock_id,
            display_projection='native_vertices_only',anchors_snapped=False,reaggregated=False,
            source_gap_edges=gaps,native_step_change_vertices=changes,
            isolated_native_vertices=[[_iso(times[k]),float(level(k))] for k in isolated],
            original_display_points=deepcopy(points),
            native_segment_range=[_iso(times[a]),_iso(times[b])],
            native_segment_vertex_count=b-a+1,
            display_does_not_confirm_target_period=True)
        result.append(seg)
    return result


def deliver_owned_native_segments(objects, native_bars, timeframe, cutoff_utc,
                                  *, timestamp_format='native'):
    """Production exit for new owned-axis lines only; preserve legacy records.

    A failed new projection retains its full source in the audit and never
    falls back to a potentially crossing chord. No legacy line is filtered.
    """
    output=[];checks=[];pending=[]
    for obj in objects:
        if obj.get('group')!='book_owned_axis' or obj.get('kind')!='line':
            output.append(obj);continue
        try:
            pieces=project_native_line(obj,native_bars,display_timeframe=timeframe,
                                       cutoff_utc=cutoff_utc,
                                       timestamp_format=timestamp_format)
            output.extend(pieces)
            checks.append(dict(id=obj['id'],segment_ids=[p['id'] for p in pieces],
                source_gap_edges=pieces[0]['evidence']['source_gap_edges'],
                native_step_change_vertices=pieces[0]['evidence']['native_step_change_vertices'],
                isolated_native_vertices=pieces[0]['evidence']['isolated_native_vertices'],
                native_vertices=sum(p['evidence']['native_segment_vertex_count'] for p in pieces)))
        except (ValueError,KeyError,TypeError,IndexError,OverflowError) as exc:
            # Fail closed for the new projection, but never erase a source
            # line that was already selected by the native owned-axis engine.
            output.append(obj)
            pending.append(dict(id=obj.get('id'),reason=str(exc),source=deepcopy(obj)))
    return output,dict(projected_sources=len(checks),finite_segments=sum(len(c['segment_ids']) for c in checks),
        legacy_objects_changed=0,checks=checks,unrendered_sources=pending,
        native_api_verified=False,native_pixels_verified=False)

