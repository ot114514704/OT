"""Bounded, read-only review access to the foundation facts packet.

The packet is deliberately large because it keeps native bars and immutable
evidence.  This module is the small query surface used by a review page: it
never rebuilds a detector, assigns a parent after the requested clock, or
returns downstream trade decisions.  Every result is bounded and carries its
cutoff so a reviewer can tell what was visible at that point in history.
"""

from __future__ import annotations

import argparse
import gzip
import json
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any, Mapping

try:
    from .foundation_structure_facts import (
        DIRECT_PARENT,
        FOUNDATION_PERIODS,
        SCHEMA,
        _background_judgment,
        _attach_background_parent_context,
        _time,
        parent_relations_at,
        validate_foundation_facts,
    )
except ImportError:  # direct local inspection
    from foundation_structure_facts import (
        DIRECT_PARENT,
        FOUNDATION_PERIODS,
        SCHEMA,
        _background_judgment,
        _attach_background_parent_context,
        _time,
        parent_relations_at,
        validate_foundation_facts,
    )


DEFAULT_PACKET = Path(__file__).resolve().parents[1] / "03_work_queue" / "machine1_unified_mt5" / "foundation_r2" / "facts_r5_20261018.json.gz"
DEFAULT_SHARD_MANIFEST = DEFAULT_PACKET.with_name("shards_r5_20261018") / "manifest.json"
DEFAULT_LIMIT = 50
MAX_LIMIT = 250


def _iso(value: str | None) -> str:
    if value is None or not str(value).strip():
        return ""
    return _time(str(value)).isoformat().replace("+00:00", "Z")


def _bounded_limit(value: int | str | None) -> int:
    try:
        value = int(value if value is not None else DEFAULT_LIMIT)
    except (TypeError, ValueError):
        value = DEFAULT_LIMIT
    return max(1, min(value, MAX_LIMIT))


def load_packet(path: Path = DEFAULT_PACKET) -> Mapping[str, Any]:
    """Load one frozen packet.  This function has no write or refresh path."""
    path = Path(path)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        packet = json.load(handle)
    if packet.get("schema") != SCHEMA:
        raise ValueError("unsupported foundation facts schema")
    return _refresh_background_context(packet)


def _load_gzip_json(path: Path) -> Mapping[str, Any]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        return json.load(handle)


def _refresh_background_context(packet: Mapping[str, Any]) -> Mapping[str, Any]:
    """Refresh derived background/candidate views at the frozen packet clock."""
    snapshot = packet.get("snapshot", {}).get("as_of_utc")
    if not snapshot:
        return packet
    periods = packet.get("periods", {})
    relations = packet.get("relations", [])
    for tf in FOUNDATION_PERIODS:
        row = periods.get(tf)
        if not row:
            continue
        row["background_judgment"] = _background_judgment(
            tf, row.get("nodes", []), relations, snapshot)
    _attach_background_parent_context(periods)
    return packet


def load_sharded_packet(manifest_path: Path = DEFAULT_SHARD_MANIFEST) -> Mapping[str, Any]:
    """Reassemble the immutable per-timeframe review packet from shards.

    The source packet remains the canonical hash.  This path is used by the
    local review service so period data comes from the bounded shard set while
    preserving the exact packet shape and validation semantics.
    """
    manifest_path = Path(manifest_path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    root = manifest_path.parent
    periods = {}
    native_bars = {}
    evidence = {}
    relations = []
    events = []
    for tf in manifest.get("timeframe_ladder", []):
        tf_dir = root / tf
        node_payload = _load_gzip_json(tf_dir / manifest["shards"][tf]["files"]["nodes"]["path"])
        period = dict(node_payload.get("period") or {})
        period["nodes"] = node_payload.get("nodes", [])
        # The background field is retained in the period metadata for old
        # manifests and explicitly restored for clarity.
        period["background_judgment"] = node_payload.get("background_judgment")
        periods[tf] = period
        native_bars[tf] = node_payload.get("native_bars", [])
        for kind in ("relations", "events", "evidence"):
            payload = _load_gzip_json(tf_dir / manifest["shards"][tf]["files"][kind]["path"])
            if kind == "relations":
                relations.extend(payload.get("relations", []))
            elif kind == "events":
                events.extend(payload.get("events", []))
            else:
                evidence.update(payload.get("evidence", {}))
    packet = {
        "schema": "xauusd_foundation_structure_facts_v1",
        "projection_revision": manifest.get("projection_revision"),
        "snapshot": manifest.get("snapshot"),
        "timeframe_ladder": list(manifest.get("timeframe_ladder", [])),
        "direct_parent_map": manifest.get("direct_parent_map", {}),
        "periods": periods,
        "native_bars": native_bars,
        "evidence": evidence,
        "relations": relations,
        "event_ledger": events,
        "relation_clock_policy": manifest.get("relation_clock_policy"),
        "condition_source_refs": manifest.get("condition_source_refs", {}),
        "boundary": manifest.get("boundary"),
        "forbidden_downstream": manifest.get("forbidden_downstream", []),
        "automatic_trade_permission": False,
        "author_accuracy_verified": False,
        "content_sha256": manifest.get("source_content_sha256"),
        "loaded_from_shards": True,
    }
    return _refresh_background_context(packet)


def _node_index(packet: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    return {
        node["node_id"]: node
        for row in packet.get("periods", {}).values()
        for node in row.get("nodes", [])
    }


def _node_row(packet: Mapping[str, Any], node: Mapping[str, Any], *, cutoff: str) -> dict[str, Any]:
    evidence = packet.get("evidence", {})
    evidence_state = []
    for identity in node.get("evidence_ids", []):
        record = evidence.get(identity)
        evidence_state.append({
            "evidence_id": identity,
            "resolution_status": (record or {}).get("resolution_status", "missing"),
            "known_at_utc": (record or {}).get("known_at_utc"),
            "unknown_reason": (record or {}).get("unknown_reason"),
        })
    return {
        "node_id": node.get("node_id"),
        "timeframe": node.get("timeframe"),
        "source_leg_id": node.get("source_leg_id"),
        "component_leg_ids": list(node.get("component_leg_ids") or []),
        "origin": node.get("origin"),
        "terminal": node.get("terminal"),
        "known_at_utc": node.get("known_at_utc"),
        "owner_id": node.get("owner_id"),
        "owner_status": node.get("owner_status"),
        "owner_at_snapshot_id": node.get("owner_at_snapshot_id"),
        "owner_at_snapshot_status": node.get("owner_at_snapshot_status"),
        "scope_id": node.get("scope_id"),
        "status": node.get("status"),
        "unknown_reason": node.get("unknown_reason"),
        "direction_observation": node.get("direction_observation"),
        "structure_scope": node.get("structure_scope"),
        "observed_same_period_context": node.get("observed_same_period_context"),
        "current_structure_context": node.get("current_structure_context"),
        "evidence_ids": list(node.get("evidence_ids") or []),
        "evidence": evidence_state,
        "author_wave_degree_adjudicated": node.get("author_wave_degree_adjudicated"),
        "trade_permission": node.get("trade_permission"),
        "as_of_utc": cutoff,
    }


def packet_summary(packet: Mapping[str, Any], *, sample_limit: int = 3) -> dict[str, Any]:
    """Return a small dashboard-safe summary; no native bars are included."""
    sample_limit = _bounded_limit(sample_limit)
    periods = {}
    for tf in FOUNDATION_PERIODS:
        row = packet.get("periods", {}).get(tf, {})
        nodes = row.get("nodes", [])
        periods[tf] = {
            "timeframe": tf,
            "direct_parent": DIRECT_PARENT[tf],
            "status": row.get("status"),
            "native_bar_count": row.get("native_bar_count", 0),
            "native_closed_through_utc": row.get("native_closed_through_utc"),
            "node_count": len(nodes),
            "rejected_leg_count": row.get("rejected_leg_count", 0),
            "background_judgment": row.get("background_judgment"),
            "sample_nodes": [
                {"node_id": n.get("node_id"), "known_at_utc": n.get("known_at_utc"),
                 "status": n.get("status"), "direction": n.get("direction_observation")}
                for n in nodes[-sample_limit:]
            ],
        }
    relations = packet.get("relations", [])
    relation_counts = {tf: 0 for tf in FOUNDATION_PERIODS}
    for relation in relations:
        if relation.get("child_timeframe") in relation_counts:
            relation_counts[relation["child_timeframe"]] += 1
    return {
        "schema": packet.get("schema"),
        "projection_revision": packet.get("projection_revision"),
        "snapshot": packet.get("snapshot"),
        "timeframe_ladder": list(packet.get("timeframe_ladder", [])),
        "direct_parent_map": dict(packet.get("direct_parent_map", {})),
        "relation_clock_policy": packet.get("relation_clock_policy"),
        "automatic_trade_permission": packet.get("automatic_trade_permission"),
        "author_accuracy_verified": packet.get("author_accuracy_verified"),
        "content_sha256": packet.get("content_sha256"),
        "validation_error_count": len(validate_foundation_facts(packet)),
        "relation_count": len(relations),
        "relation_counts_by_child_timeframe": relation_counts,
        "event_ledger_count": len(packet.get("event_ledger", [])),
        "loaded_from_shards": bool(packet.get("loaded_from_shards", False)),
        "periods": periods,
        "read_only": True,
    }


def query_period(packet: Mapping[str, Any], timeframe: str, *, cutoff: str | None = None,
                 start: str | None = None, end: str | None = None,
                 limit: int = DEFAULT_LIMIT, offset: int = 0) -> dict[str, Any]:
    """List a bounded period prefix/window using only known-at clocks."""
    if timeframe not in FOUNDATION_PERIODS:
        raise ValueError(f"unsupported timeframe: {timeframe}")
    snapshot_cutoff = _iso(cutoff) if cutoff else packet["snapshot"]["as_of_utc"]
    if _time(snapshot_cutoff) > _time(packet["snapshot"]["as_of_utc"]):
        raise ValueError("cutoff exceeds frozen snapshot")
    start_clock = _time(start) if start else None
    end_clock = _time(end) if end else None
    if start_clock and end_clock and start_clock > end_clock:
        raise ValueError("start is after end")
    nodes = []
    for node in packet["periods"][timeframe].get("nodes", []):
        known = _time(node["known_at_utc"])
        if known > _time(snapshot_cutoff):
            continue
        if start_clock and known < start_clock:
            continue
        if end_clock and known > end_clock:
            continue
        nodes.append(node)
    limit = _bounded_limit(limit)
    offset = max(0, int(offset or 0))
    selected = nodes[offset:offset + limit]
    cutoff_relations = [relation for relation in packet.get("relations", [])
                        if _time(relation.get("known_at_utc")) <= _time(snapshot_cutoff)]
    background = _background_judgment(timeframe, nodes, cutoff_relations, snapshot_cutoff)
    parent_rows = {}
    for tf in FOUNDATION_PERIODS:
        period_nodes = [candidate for candidate in packet["periods"][tf].get("nodes", [])
                        if _time(candidate.get("known_at_utc")) <= _time(snapshot_cutoff)]
        parent_rows[tf] = {
            "nodes": period_nodes,
            "background_judgment": _background_judgment(
                tf, period_nodes, cutoff_relations, snapshot_cutoff),
        }
    _attach_background_parent_context(parent_rows)
    background = parent_rows[timeframe]["background_judgment"]
    return {
        "kind": "foundation_period_review",
        "timeframe": timeframe,
        "direct_parent": DIRECT_PARENT[timeframe],
        "as_of_utc": snapshot_cutoff,
        "start": _iso(start) if start else None,
        "end": _iso(end) if end else None,
        "total_visible": len(nodes),
        "offset": offset,
        "limit": limit,
        "background_judgment": background,
        "nodes": [_node_row(packet, node, cutoff=snapshot_cutoff) for node in selected],
        "read_only": True,
        "trade_permission": False,
    }


def query_node(packet: Mapping[str, Any], node_id: str, *, cutoff: str | None = None) -> dict[str, Any]:
    """Return one node and its direct-parent event ledger at the same cutoff."""
    index = _node_index(packet)
    node = index.get(node_id)
    if node is None:
        raise KeyError(node_id)
    snapshot_cutoff = _iso(cutoff) if cutoff else packet["snapshot"]["as_of_utc"]
    if _time(snapshot_cutoff) > _time(packet["snapshot"]["as_of_utc"]):
        raise ValueError("cutoff exceeds frozen snapshot")
    row = _node_row(packet, node, cutoff=snapshot_cutoff)
    row["parent_review"] = parent_relations_at(packet, node_id, snapshot_cutoff)
    # Keep the immutable source owner field intact while exposing the owner
    # that is actually knowable at the requested review clock.
    parent_review = row["parent_review"]
    row["effective_owner_id"] = parent_review.get("owner_id")
    row["effective_owner_status"] = parent_review.get("status")
    period_nodes = [candidate for candidate in packet["periods"][node["timeframe"]].get("nodes", [])
                    if _time(candidate.get("known_at_utc")) <= _time(snapshot_cutoff)]
    cutoff_relations = [relation for relation in packet.get("relations", [])
                        if _time(relation.get("known_at_utc")) <= _time(snapshot_cutoff)]
    row["background_judgment"] = _background_judgment(
        node["timeframe"], period_nodes, cutoff_relations, snapshot_cutoff)
    parent_rows = {}
    for tf in FOUNDATION_PERIODS:
        period_nodes = [candidate for candidate in packet["periods"][tf].get("nodes", [])
                        if _time(candidate.get("known_at_utc")) <= _time(snapshot_cutoff)]
        parent_rows[tf] = {
            "nodes": period_nodes,
            "background_judgment": _background_judgment(
                tf, period_nodes, cutoff_relations, snapshot_cutoff),
        }
    _attach_background_parent_context(parent_rows)
    row["background_judgment"] = parent_rows[node["timeframe"]]["background_judgment"]
    row["event_ledger"] = [
        event for event in packet.get("event_ledger", [])
        if event.get("object_id") == node_id and
        _time(event.get("known_at_utc")) <= _time(snapshot_cutoff)
    ]
    row["read_only"] = True
    row["trade_permission"] = False
    return {"kind": "foundation_node_review", "node": row, "read_only": True,
            "trade_permission": False}


def review_window(packet: Mapping[str, Any], timeframe: str, *, cutoff: str | None = None,
                  limit: int = DEFAULT_LIMIT) -> dict[str, Any]:
    """Return summary plus bounded nodes for the page's initial load."""
    result = query_period(packet, timeframe, cutoff=cutoff, limit=limit)
    result["packet_summary"] = packet_summary(packet, sample_limit=1)
    return result


def _main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Read-only foundation review query")
    parser.add_argument("--packet", type=Path, default=DEFAULT_PACKET)
    parser.add_argument("--summary", action="store_true")
    parser.add_argument("--timeframe", choices=FOUNDATION_PERIODS)
    parser.add_argument("--cutoff")
    parser.add_argument("--start")
    parser.add_argument("--end")
    parser.add_argument("--node-id")
    parser.add_argument("--limit", type=int, default=DEFAULT_LIMIT)
    parser.add_argument("--offset", type=int, default=0)
    args = parser.parse_args(argv)
    packet = load_packet(args.packet)
    if args.summary or not args.timeframe and not args.node_id:
        output = packet_summary(packet, sample_limit=args.limit)
    elif args.node_id:
        output = query_node(packet, args.node_id, cutoff=args.cutoff)
    else:
        output = query_period(packet, args.timeframe, cutoff=args.cutoff,
                              start=args.start, end=args.end,
                              limit=args.limit, offset=args.offset)
    print(json.dumps(output, ensure_ascii=False, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
