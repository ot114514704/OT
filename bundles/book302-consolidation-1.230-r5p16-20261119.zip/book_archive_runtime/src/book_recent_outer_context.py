"""Retain a causally discovered clean outer context across rolling windows.

The 96-bar scale matches the existing inventory's finest search, and the
96-prefix recall horizon is engineering policy, never author wave degree.
Only one surviving native anchor identity can fill a missing primary line.
"""
from copy import deepcopy
from .book_first_response_leg import clock,close_time
from .pdf_trendline_block import select_pdf_outer_trendline,select_pdf_turning_boundary


def successor_outer_context(bars,timeframe,cutoff,current):
    """Only native event-admitted successors may replace a window choice.

    Root tangents merely provide declared source hypotheses. Competing
    admitted roots stay unresolved; this does not prove author membership.
    """
    from .pdf_trendline_block import select_pdf_wave_relative_outer
    from .book_native_wave_process import review_outer_successors
    rows=[r for r in bars if clock(close_time(r,timeframe))<=clock(cutoff)]
    roots={}
    for seed in [current]+[select_pdf_wave_relative_outer(rows,up,lookback=len(rows)) for up in (True,False)]:
        if not seed.get('qualified'):continue
        key=(seed['direction'],seed['start_index'],seed['end_index'])
        roots.setdefault(key,seed)
    reviews=[review_outer_successors(rows,timeframe,cutoff,line) for line in roots.values()]
    selected={(r['selection']['parent_scope_id'],r['selection']['phase_id']):r['selection'] for r in reviews if r.get('selection')}
    result=dict(schema='book_native_successor_selection_v1',reviews=reviews,selection=None,
        status='candidate',reason='no_event_admitted_successor',
        author_degree_verified=False,automatic_trade_permission=False)
    if len(selected)>1:return dict(result,reason='multiple_successor_sources_need_adjudication')
    if not selected:return result
    line=next(iter(selected.values()))
    # A successor belonging to a different still-selected source cannot take
    # over merely because its geometry or force score happens to rank higher.
    root=next(r for r in reviews if r.get('selection') and (r['selection']['parent_scope_id'],r['selection']['phase_id'])==(line['parent_scope_id'],line['phase_id']))
    current_origin=current.get('start_utc')
    if current.get('qualified') and (current.get('direction')!=line['direction'] or
            current_origin and current_origin!=root['ancestor_origin']['bar_open_utc']):
        return dict(result,reason='selected_source_differs_from_successor_root')
    return dict(result,selection=line,status='native_event_admitted',reason=None)


def retained_outer_context(bars,timeframe,cutoff,direction=None):
    rows=[r for r in bars if clock(close_time(r,timeframe))<=clock(cutoff)]
    scale=horizon=96;identities={}
    for end in range(max(scale,len(rows)-horizon+1),len(rows)+1):
        for up in (True,False):
            line=select_pdf_outer_trendline(rows[:end],up,lookback=scale)
            if not line.get('qualified'):continue
            i,j=line['start_index'],line['end_index']
            key=(rows[i]['timestamp_utc'],line['start_price'],rows[j]['timestamp_utc'],line['end_price'])
            if key in identities:continue
            # A prior physical prefix must establish the construction. Later
            # clean extension preserves it; any wick contact excludes it as a
            # current fallback without deleting its historical inventory.
            sign=1 if up else -1;side='low' if up else 'high'
            if any(sign*(float(rows[k][side])-(line['start_price']+line['slope']*(k-i)))<=0
                   for k in range(j+1,len(rows))):continue
            selected=deepcopy(line)
            selected.update(timeframe=timeframe,known_at_utc=close_time(rows[end-1],timeframe),
                selection_prefix_end_index=end-1,selection_prefix_end_utc=rows[end-1]['timestamp_utc'],
                context_selection_basis='unique_uncontacted_recalled_native_outer',
                context_search_bars=scale,context_recall_prefixes=horizon,
                author_wave_degree='unknown',automatic_trade_permission=False)
            identities[key]=selected
    candidates=list(identities.values())
    # Compare only clean lines sharing the exact second native anchor and
    # direction. PDF49's first point is the movement's extreme; rolling
    # windows can otherwise replace it with a later interior low/high.
    groups={}
    for candidate in candidates:
        groups.setdefault((candidate['direction'],candidate['end_index'],candidate['end_price']),[]).append(candidate)
    survivors=[];comparisons=[]
    for group in groups.values():
        earliest=min(group,key=lambda line:line['start_index']);up=earliest['direction']=='up'
        start=earliest['start_index'];side='low' if up else 'high'
        extreme=(min if up else max)(float(r[side]) for r in rows[start:])
        if earliest['start_price']==extreme:
            survivors.append(earliest)
            comparisons.append(dict(basis='same_second_anchor_clean_phase_extreme_origin',
                kept_start_utc=rows[start]['timestamp_utc'],kept_start_price=extreme,
                retained_alternatives=len(group)-1,author_wave_degree='unknown'))
        else:survivors.extend(group)
    result=dict(status='unknown',reason='no_uncontacted_recalled_context',candidates=candidates,
                surviving_context_count=len(survivors),comparisons=comparisons,
                selection=None,search_bars=scale,recall_prefixes=horizon,automatic_trade_permission=False)
    if len(survivors)>1:return dict(result,reason='multiple_native_contexts_need_adjudication')
    if not survivors:return result
    line=survivors[0]
    if direction is not None and direction!=line['direction']:
        return dict(result,reason='recent_direction_conflicts_with_retained_context')
    return dict(result,status='engineering_context_retained',reason=None,selection=line)


def first_known_turning_for_context(rows,line,timeframe):
    """A later E/D confirmation may form after the outer line was known.

    Discover on physical prefixes and freeze the first qualified C/D/E,
    rather than freezing absence forever or selecting with later prices.
    """
    start=line['selection_prefix_end_index']+1
    last={}
    for end in range(start,len(rows)+1):
        formation=dict(line,first_break_index=end)
        last=select_pdf_turning_boundary(rows[:end],formation)
        if last.get('qualified'):
            return dict(last,known_at_utc=close_time(rows[end-1],timeframe),
                construction_prefix_end_index=end-1,
                construction_prefix_basis='first_qualified_CDE_after_retained_outer_known')
    return last
