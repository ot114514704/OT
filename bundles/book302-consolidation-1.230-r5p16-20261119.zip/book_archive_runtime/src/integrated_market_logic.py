"""Recompute the current native event; keep chart inventories separate.

This module is deliberately a reducer, not a strategy.  It does not replace
the source geometry, invent a wave degree, or grant an order.  It joins the
facts already produced by the scene:

* direct-parent background and same-period direction;
* native A->B/C ownership and the attached three-push candidates;
* force strength and its calibrated/initial band preference;
* channel/turning-line geometry quality.

Chart-wide parent, wave, force and geometry inventories remain review context.
The scalar and components reuse the existing Book event/family measurements,
never the chart's highest independent scores. Missing event evidence stays
unknown. Labels retain their own object scores, not an inherited event grade.
"""
from __future__ import annotations

from datetime import datetime
from copy import deepcopy
from math import isfinite
import re


VERSION = "integrated_market_logic_v1"
PARENTS = dict(M1="M5", M5="M15", M15="M30", M30="H1", H1="H4", H4="D1", D1="W1")


def _epoch(value):
    if not value:
        return float("inf")
    return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()


def _direction(value):
    if value in (1, "up", "bull", "long", "多头", "上升"):
        return "up"
    if value in (-1, "down", "bear", "short", "空头", "下降"):
        return "down"
    return None


def _quality_value(item):
    if not isinstance(item, dict):
        return None
    value = item.get("score")
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    return value if isfinite(value) and 0.0 <= value <= 100.0 else None


def _component(key, value, weight, source_ids, state="observed", reason=None):
    return {
        "key": key,
        "value": round(float(value), 4) if value is not None else None,
        "weight": float(weight),
        "source_ids": sorted({str(x) for x in source_ids if x}),
        "state": state,
        "reason": reason,
    }


def _geometry_evidence(scene, cutoff):
    rows = []
    for obj in scene.get("objects", []):
        if obj.get("layer") not in {"channel", "turning_point", "trend"}:
            continue
        evidence = obj.get("evidence") or {}
        intelligence = (evidence.get("parallel_intelligence")
                        or evidence.get("turning_intelligence")
                        or evidence.get("line_intelligence"))
        if not isinstance(intelligence, dict):
            continue
        known = obj.get("known_at_utc") or intelligence.get("known_at_utc")
        if known and _epoch(known) > _epoch(cutoff):
            continue
        score = _quality_value(intelligence)
        if score is None:
            continue
        rows.append({
            "object_id": obj.get("id"),
            "layer": obj.get("layer"),
            "source_id": obj.get("source_id"),
            "owner_id": obj.get("owner_id"),
            "timeframe": obj.get("timeframe"),
            "known_at_utc": known or cutoff,
            "as_of_utc": cutoff,
            "quality": intelligence.get("quality", "unknown"),
            "grade": intelligence.get("grade", "unknown"),
            "score": score,
            "score_version": intelligence.get("score_version"),
            "calibration_status": intelligence.get("calibration_status"),
        })
    rows.sort(key=lambda row: (row["score"], row.get("known_at_utc", "")), reverse=True)
    return rows


def _force_evidence(scene, cutoff, *, include_descriptive=False):
    rows = []
    for obj in scene.get("objects", []):
        if obj.get("layer") != "force" or obj.get("group") == "force_retracement":
            continue
        profile = obj.get("strength_profile") or (obj.get("evidence") or {}).get("strength_profile")
        if not isinstance(profile, dict):
            continue
        evidence = obj.get("evidence") or {}
        descriptive = bool(evidence.get('descriptive_wave_scope') or evidence.get('force_admission') is False
                           or profile.get('model_domain') == 'native_completed_wave_description')
        if descriptive and not include_descriptive:
            continue
        known = profile.get("known_at_utc") or obj.get("known_at_utc")
        if known and _epoch(known) > _epoch(cutoff):
            continue
        score = _quality_value(profile)
        if score is None:
            continue
        selection = profile.get("band_selection") or {}
        rows.append({
            "object_id": obj.get("id"),
            "source_id": profile.get("source_id") or obj.get("source_id"),
            "owner_id": profile.get("owner_id") or obj.get("owner_id"),
            "timeframe": obj.get("timeframe"),
            "known_at_utc": known or cutoff,
            "as_of_utc": cutoff,
            "quality": profile.get("quality", "unknown"),
            "score": score,
            "model_id": profile.get("model_id"),
            "model_validation_status": profile.get("model_validation_status"),
            "threshold_basis": profile.get("threshold_basis"),
            "preferred_band": selection.get("preferred_band"),
            "ranked_bands": selection.get("ranked_bands", []),
            "band_status": selection.get("status"),
            "source_window": profile.get("source_window"),
            "evidence_scope": "descriptive_wave_only" if descriptive else "force_profile_inventory",
            "used_as_event_vote": False,
        })
    rows.sort(key=lambda row: (row["score"], row.get("object_id", "")), reverse=True)
    return rows


def _parent_context(scene):
    tf = scene.get("timeframe")
    foundation = scene.get("foundation_context") or {}
    structure_parent = (scene.get("structure_logic") or {}).get("parent") or {}
    direct_parent = foundation.get("direct_parent") or PARENTS.get(tf)
    parent_direction = _direction(structure_parent.get("direction"))
    if parent_direction is None:
        parent_direction = _direction(foundation.get("parent_context", {}).get("direction"))
    parent_state = structure_parent.get("state") or foundation.get("parent_context", {}).get("state")
    current_direction = _direction(foundation.get("direction"))
    if current_direction is None:
        current_direction = _direction((scene.get("book_logic") or {}).get("trend", {}).get("direction"))
    if current_direction is None:
        current_row = (scene.get("foundation_ladder_context") or {}).get(tf, {})
        current_direction = _direction(current_row.get("direction"))
    if parent_direction and current_direction:
        alignment = "aligned" if parent_direction == current_direction else "countertrend"
    else:
        alignment = "unknown"
    return {
        "working_timeframe": tf,
        "direct_parent": direct_parent,
        "parent_state": parent_state or "unknown",
        "parent_direction": parent_direction,
        "current_direction": current_direction,
        "alignment": alignment,
        "known_at_utc": foundation.get("as_of_utc") or scene.get("cutoff_utc"),
        "as_of_utc": scene.get("cutoff_utc"),
        "source_id": (foundation.get("rule_id") or foundation.get("source_id")
                       or "foundation_ladder_context"),
        "timeframe": tf,
        "owner_id": f"parent:{direct_parent or 'unknown'}:{scene.get('cutoff_utc')}",
        "source_ids": list(structure_parent.get("evidence_ids", [])) + list(foundation.get("evidence_ids", [])),
        "unknown_reason": ("parent_or_current_direction_unavailable" if alignment == "unknown" else None),
    }


def _measurement_evidence(scene, cutoff):
    logic = scene.get("structure_logic") or {}
    tasks = [task for task in logic.get("tasks", [])
             if _epoch(task.get("evaluated_at_utc") or cutoff) <= _epoch(cutoff)]
    valid = [task for task in tasks if task.get("own_C_valid")]
    pending = [task for task in valid if task.get("target_state") == "pending"]
    linked = [task for task in valid if task.get("three_push_ids")]
    routes = []
    for task in valid:
        response = task.get("response") or {}
        force = task.get("first_force") or {}
        route_a = (response.get("state") in {"reclaimed", "reclaimed_with_follow"}
                   and task.get("target_state") == "pending")
        retests = force.get("retests") or []
        route_b = (force.get("state") == "first_complete_force_observed"
                   and any(row.get("state") == "close_recovered" for row in retests))
        preferred = ((force.get("strength_profile") or {}).get("band_selection") or {}).get("preferred_band")
        routes.append({
            "task_id": task.get("task_id"),
            "owner_id": task.get("owner_id"),
            "source_id": (task.get("source") or {}).get("source_leg_id") or task.get("owner_id"),
            "timeframe": task.get("timeframe") or scene.get("timeframe"),
            "known_at_utc": task.get("evaluated_at_utc") or cutoff,
            "as_of_utc": cutoff,
            "route_A": "candidate" if route_a else "waiting",
            "route_B": "candidate" if route_b else "waiting",
            "preferred_band": preferred,
            "three_push_ids": task.get("three_push_ids", []),
            "target_state": task.get("target_state"),
            "invalidated": task.get("target_state") in {"invalidated_source", "same_bar_target_and_invalidation_unknown"},
            "second_leg_structure_score": task.get("second_leg_structure_score"),
        })
    return {
        "task_count": len(tasks),
        "valid_C_count": len(valid),
        "pending_target_count": len(pending),
        "linked_three_push_count": len(linked),
        "invalidated_route_count": sum(bool(row.get("invalidated")) for row in routes),
        "active_route_count": sum(row.get("target_state") == "pending" or
                                   row.get("route_A") == "candidate" or
                                   row.get("route_B") == "candidate" for row in routes),
        "routes": routes,
        "source_ids": [task.get("owner_id") for task in valid],
    }


def _weekly_context(scene, cutoff):
    """Expose Weekly Profile scheduling as priority context, not direction.

    The registry is intentionally date precision only.  A large named event
    can mark a candidate release window, but it cannot itself assert a sweep,
    accumulation, or reversal.  Those remain price and acceptance facts.
    """
    weekly = scene.get("force_weekly_context") or {}
    events = []
    for event in weekly.get("events") or []:
        event_class = event.get("event_class")
        priority = ("macro_window_candidate" if event_class in {
            "national_GDP_update", "national_income_spending_prices"
        } else "scheduled_US_context")
        events.append({
            "event_id": event.get("event_id"),
            "name": event.get("name"),
            "event_class": event_class,
            "scheduled_date_us": event.get("scheduled_date_us"),
            "timing_state": event.get("timing_state"),
            "priority": priority,
            "liquidity_scale": "unknown_until_price_response_and_session_object_are_joined",
            "source_id": event.get("source_id"),
            "known_at_utc": event.get("known_at_utc"),
            "timeframe": "W1",
            "owner_id": event.get("source_id") or event.get("event_id"),
            "as_of_utc": cutoff,
        })
    roles = []
    for role in weekly.get("planned_day_roles") or []:
        roles.append({
            "role": role.get("role"),
            "dates": role.get("dates") or role.get("days") or role.get("before_dates", []),
            "state": role.get("state"),
            "liquidity_scale": role.get("liquidity_scale"),
            "event_ids": role.get("events", []),
            "source_id": weekly.get("program_id"),
            "owner_id": f"weekly:{weekly.get('week_start', 'unknown')}",
            "timeframe": "W1",
            "known_at_utc": weekly.get("program_known_at_utc") or cutoff,
            "as_of_utc": cutoff,
        })
    return {
        "status": weekly.get("status", "unknown"),
        "week_start": weekly.get("week_start"),
        "program_id": weekly.get("program_id"),
        "program_known_at_utc": weekly.get("program_known_at_utc"),
        "schedule_summary": weekly.get("schedule_summary"),
        "events": events,
        "planned_day_roles": roles,
        "market_facts": weekly.get("market_facts"),
        "profile_candidates": weekly.get("profile_candidates", []),
        "weekly_direction": weekly.get("weekly_direction"),
        "weekly_DOL": weekly.get("weekly_DOL"),
        "priority_semantics": "calendar_priority_only; event_name_does_not_define_direction_or_liquidity_size",
        "unknown_boundary": "date-only US schedule; exact release time, realized sweep size and selected profile remain unknown",
        "known_at_utc": weekly.get("program_known_at_utc") or cutoff,
        "as_of_utc": cutoff,
        "timeframe": "W1",
        "source_id": weekly.get("program_id") or "weekly_context_unverified",
        "owner_id": f"weekly:{weekly.get('week_start', 'unknown')}",
    }


def _period_ladder(scene, cutoff):
    ladder = scene.get("foundation_ladder_context") or {}
    periods = []
    order = ("W1", "D1", "H4", "H1", "M30", "M15", "M5", "M1")
    for tf in order:
        row = ladder.get(tf) or {}
        periods.append({
            "timeframe": tf,
            "direct_parent": row.get("direct_parent") or PARENTS.get(tf),
            "state": row.get("state", "unknown"),
            "direction": _direction(row.get("direction")),
            "status": row.get("status", "unknown"),
            "confidence": row.get("confidence", "unknown"),
            "candidate_roles": row.get("candidate_roles", {}),
            "known_at_utc": row.get("as_of_utc") or cutoff,
            "as_of_utc": cutoff,
            "source_ids": row.get("evidence_ids", []),
            "source_id": (row.get("evidence_ids") or ["foundation_ladder_context"])[0],
            "owner_id": f"structure:{tf}:{cutoff}",
            "unknown_reason": row.get("unknown_reason"),
        })
    return {
        "periods": periods,
        "as_of_utc": cutoff,
        "source_id": "foundation_ladder_context",
        "owner_id": f"ladder:{cutoff}",
        "timeframe": scene.get("timeframe"),
        "unknown_boundary": "author wave degree is not inferred from native sequence; direction remains unknown when the period context is mixed",
    }


def _book_breakout_evidence(scene, cutoff):
    """Read the native Book double-boundary assessment at one fixed clock.

    Geometry quality describes the line itself; ``breakout_score`` describes
    the closed follow-through after that line was crossed.  They are separate
    facts and must not be replaced by a direction or by the strongest one of
    the two boundaries.  This reader only exposes a same-clock receipt for
    the confluence calculation below.
    """
    book = scene.get("book_logic") or {}
    assessment = book.get("boundary_breakout_assessment") or scene.get("boundary_breakout_assessment") or {}
    if assessment.get("as_of_utc") not in (None, cutoff):
        return {"state": "unknown", "rows": [], "unknown_components": ["breakout_scene_clock_mismatch"]}
    rows = []
    for name, reading in (assessment.get("boundaries") or {}).items():
        if not isinstance(reading, dict):
            continue
        known = reading.get("known_at_utc") or reading.get("score_event_closed_at_utc")
        if known and _epoch(known) > _epoch(cutoff):
            continue
        geometry = reading.get("geometry_score")
        breakout = reading.get("breakout_score")
        try:
            geometry = float(geometry) if geometry is not None else None
            breakout = float(breakout) if breakout is not None else None
        except (TypeError, ValueError):
            geometry = breakout = None
        if geometry is not None and not (isfinite(geometry) and 0 <= geometry <= 100):
            geometry = None
        if breakout is not None and not (isfinite(breakout) and 0 <= breakout <= 100):
            breakout = None
        rows.append({
            "boundary": name,
            "geometry_score": geometry,
            "breakout_score": breakout,
            "status": reading.get("status"),
            "known_at_utc": known or cutoff,
            "as_of_utc": cutoff,
            "source_timing": reading.get("source_timing"),
            "follow_directional": reading.get("follow_directional"),
            "holds_boundary": reading.get("holds_boundary"),
            "phase_id": assessment.get("phase_id"),
        })
    rows.sort(key=lambda row: row["boundary"])
    joint = assessment.get("joint") or {}
    # Recompute from both named native boundaries.  A cached joint minimum
    # must not survive when one boundary was future, missing or malformed.
    named = {row["boundary"]: row for row in rows}
    if all(name in named and named[name].get("breakout_score") is not None
           for name in ("outer", "turning")):
        weakest = min(named["outer"]["breakout_score"], named["turning"]["breakout_score"])
    else:
        weakest = None
    return {
        "state": "observed" if rows else "unknown",
        "assessment_state": joint.get("state", "unknown"),
        "phase_id": assessment.get("phase_id"),
        "rows": rows,
        "weakest_breakout_score": weakest,
        "unknown_components": [],
    }


def _breakout_confluence(geometry, force, breakout, *, event=None):
    """Legacy arguments are inventory only; recomputed event evidence is required."""
    from .scene_event_confluence import event_breakout_confluence
    return event_breakout_confluence(event)


def _fuse_components(parent, geometry, force, measurements, *, event=None):
    """Never combine source-unbound chart inventories as a position score."""
    from .scene_event_confluence import event_components
    return event_components(event)


def _owner_task_context(reading, cutoff, tasks_by_id):
    """Return only the task that has the exact 1:1 owner identity.

    A scene-wide parent or a nearby three-push cannot be silently attached to
    a different AB/C measurement.  This helper therefore refuses substitutes:
    the task id, source owner, native timeframe and as-of clock must all
    match the reading.  Its result remains descriptive and does not change
    the second-leg research-ready predicate.
    """
    if tasks_by_id is None:
        return None
    task = tasks_by_id.get(reading.get("object_id"))
    if not isinstance(task, dict):
        return {"state": "owner_structure_task_missing", "context_bound": False,
                "reason": "no_task_with_same_one_to_one_object_id"}
    mismatches = []
    if task.get("owner_id") != reading.get("source_leg_id"):
        mismatches.append("source_owner_mismatch")
    if task.get("timeframe") != reading.get("timeframe"):
        mismatches.append("native_timeframe_mismatch")
    # Older frozen scene records predate the redundant ``as_of_utc`` field;
    # ``evaluated_at_utc`` is their authoritative task clock.  When the
    # newer field is present both must agree.  Do not treat an absent field as
    # a mismatch, and do not accept a differing field.
    if (task.get("evaluated_at_utc") != cutoff or
            task.get("as_of_utc") not in (None, cutoff)):
        mismatches.append("task_scene_clock_mismatch")
    if task.get("automatic_trade_permission") is not False:
        mismatches.append("task_permission_state_unbound")
    if mismatches:
        return {"state": "owner_structure_task_identity_unbound", "context_bound": False,
                "reason": mismatches, "task_id": task.get("task_id"),
                "task_owner_id": task.get("owner_id")}
    parent = task.get("parent") or {}
    three_push_ids = list(task.get("three_push_ids") or [])
    routes = task.get("routes") or {}
    return {
        "state": "same_owner_native_task_bound", "context_bound": True,
        "task_id": task.get("task_id"), "owner_id": task.get("owner_id"),
        "timeframe": task.get("timeframe"), "as_of_utc": cutoff,
        "own_C_valid": task.get("own_C_valid"), "target_state": task.get("target_state"),
        "three_push_ids": three_push_ids,
        "three_push_state": "owner_bound_native_pattern" if three_push_ids else "no_owner_bound_three_push",
        "native_parent": {key: parent.get(key) for key in
                          ("timeframe", "state", "direction", "known_at_utc",
                           "protected_node_status", "parent_reversal_confirmed")},
        "degree_status": task.get("degree_status") or "unknown",
        "author_wave_degree_adjudicated": False,
        "route_states": {name: {"state": value.get("state"),
                                 "blockers": list(value.get("blockers") or [])}
                         for name, value in routes.items() if isinstance(value, dict)},
        "automatic_trade_permission": False,
        "context_is_not_author_wave_degree_or_entry_permission": True,
    }


def _downstream_chart_context(parent, weekly):
    """Compact chart-level context without claiming it belongs to an owner."""
    if parent is None and weekly is None:
        return None
    direct_parent = parent or {}
    weekly = weekly or {}
    return {
        "direct_parent": {key: direct_parent.get(key) for key in
                          ("working_timeframe", "direct_parent", "parent_state", "parent_direction",
                           "current_direction", "alignment", "known_at_utc", "source_id", "unknown_reason")},
        "weekly": {key: weekly.get(key) for key in
                   ("status", "week_start", "program_id", "program_known_at_utc", "weekly_direction",
                    "weekly_DOL", "unknown_boundary")},
        "binding_state": "chart_level_context_only_not_same_owner_or_author_wave_degree",
        "may_not_change_second_leg_score_or_execution_admission": True,
    }


def one_to_one_downstream_review(readings, cutoff, *, tasks=None, parent_context=None, weekly_context=None):
    """Expose exact owned 1:1 review facts without selecting an entry.

    The second-leg receipt is meaningful only for its original owner and
    fixed scene clock.  This keeps ready and non-ready records separately so
    a later, independently validated policy has a traceable input rather than
    rediscovering a number from labels.  A ready record is deliberately not a
    route, a model score, or an execution request.
    """
    ready, withheld = [], []
    tasks_by_id = None if tasks is None else {
        task.get("task_id"): task for task in tasks if isinstance(task, dict) and task.get("task_id")
    }
    for reading in readings or []:
        embedding = reading.get("second_leg_current_structure_embedding") or {}
        if reading.get("status") != "scored":
            withheld.append(dict(object_id=reading.get("object_id"), reason="reading_not_scored",
                continuation_unit_context=deepcopy(reading.get('continuation_unit_context'))
                    if reading.get('as_of_utc')==cutoff else None))
            continue
        if reading.get("as_of_utc") != cutoff:
            withheld.append(dict(object_id=reading.get("object_id"), reason="reading_scene_clock_mismatch"))
            continue
        if embedding.get("entry_gate") != "closed_research_only":
            withheld.append(dict(object_id=reading.get("object_id"), reason="unrecognized_second_leg_gate"))
            continue
        item = dict(
            object_id=reading.get("object_id"), source_leg_id=reading.get("source_leg_id"),
            measurement_id=reading.get("measurement_id"), projection_id=reading.get("projection_id"),
            timeframe=reading.get("timeframe"), as_of_utc=cutoff,
            joint_score=embedding.get("joint_score"),
            joint_score_complete=embedding.get("joint_score_complete"),
            joint_unknown_components=embedding.get("joint_unknown_components"),
            delivery_score=embedding.get("delivery_score"),
            frozen_structure_score=embedding.get("structure_score"),
            current_structure_score=embedding.get("current_structure_score"),
            quantitative_score=embedding.get("quantitative_score"),
            quantitative_score_state=embedding.get("quantitative_score_state"),
            quantitative_score_receipt=deepcopy(embedding.get("quantitative_score_receipt")),
            three_push_ratio_observation=deepcopy(embedding.get("three_push_ratio_observation")),
            contextual_joint_score=embedding.get("contextual_joint_score"),
            contextual_joint_score_complete=embedding.get("contextual_joint_score_complete"),
            contextual_joint_score_unknown_components=embedding.get("contextual_joint_score_unknown_components"),
            current_sequence_alignment=embedding.get("current_sequence_alignment"),
            downstream_review_reason=embedding.get("downstream_review_reason"),
            source_three_push_context=deepcopy(embedding.get('three_push_context')),
            continuation_unit_context=deepcopy(reading.get('continuation_unit_context')),
        )
        task_context = _owner_task_context(reading, cutoff, tasks_by_id)
        if task_context is not None:
            item["owner_task_context"] = task_context
        if embedding.get("research_ready_for_downstream_review"):
            ready.append(item)
        else:
            withheld.append(dict(item, reason=embedding.get("downstream_review_reason") or
                                  "second_leg_review_requirements_not_met"))
    context_rows = [item for item in ready + withheld if isinstance(item.get("owner_task_context"), dict)]
    bound_scored = sum(bool(item["owner_task_context"].get("context_bound")) for item in context_rows)
    bound_candidates = sum(bool(item.get("owner_task_context", {}).get("context_bound")) for item in ready)
    return dict(
        schema="owned_one_to_one_downstream_review_v2", as_of_utc=cutoff,
        candidate_count=len(ready), candidates=ready,
        withheld_count=len(withheld), withheld=withheld,
        selection_policy="none_preserve_all_owner_bound_review_facts",
        owner_task_binding_policy=("exact object_id/source_leg_id/timeframe/as_of only; no nearby task substitution"
                                   if tasks_by_id is not None else "task context not supplied"),
        owner_task_context_scored_record_count=len(context_rows),
        owner_task_bound_scored_record_count=bound_scored,
        owner_task_unbound_scored_record_count=len(context_rows)-bound_scored,
        owner_task_bound_candidate_count=bound_candidates,
        owner_task_unbound_candidate_count=len(ready)-bound_candidates,
        chart_context=_downstream_chart_context(parent_context, weekly_context),
        execution_admission="blocked_research_only",
        automatic_trade_permission=False, order_api_called=False,
    )


def attach_integrated_logic(scene):
    """Attach one causal, read-only fusion packet and compact display tokens."""
    cutoff = scene.get("cutoff_utc")
    # Book/context adapters may append objects after the initial reducer or
    # retain only its per-task scores. Re-evaluate active native projections
    # at this final scene clock; never borrow another scene's score packet.
    from .one_to_one_scene_binding import attach_owned_scene_scores
    attach_owned_scene_scores(scene)
    parent = _parent_context(scene)
    geometry = _geometry_evidence(scene, cutoff)
    force = _force_evidence(scene, cutoff)
    measurements = _measurement_evidence(scene, cutoff)
    weekly = _weekly_context(scene, cutoff)
    ladder = _period_ladder(scene, cutoff)
    breakout = _book_breakout_evidence(scene, cutoff)
    from .scene_event_confluence import scene_event_context
    event = scene_event_context(scene)
    from .book_scene_event_queue import scene_event_candidates
    source_events = scene_event_candidates(scene)
    breakout_confluence = _breakout_confluence(geometry, force, breakout, event=event)
    components, score, coverage = _fuse_components(parent, geometry, force, measurements, event=event)
    # A historical owner can be invalidated while another source leg is still
    # pending at this same cutoff.  That does not invalidate the whole chart;
    # only an exhausted set of routes can move the aggregate to invalidated.
    candidate = bool(event.get('state') in {'bound_measurements', 'partial_native_event'} or geometry or force or measurements["task_count"])
    # Chart inventories remain visible but cannot establish an event phase.
    event_vetoes = (event.get('composite') or {}).get('vetoes') or []
    invalidated = bool(event_vetoes) if event.get('state') in {'bound_measurements', 'partial_native_event'} else False
    complete_gate = (breakout_confluence['state'] == 'complete' and score is not None and not event_vetoes)
    phase = "invalidated" if invalidated else "confirmed" if complete_gate else "candidate" if candidate else "observation"
    blockers = []
    if event.get('state') != 'bound_measurements':
        blockers.append(event.get('reason') or 'same_native_event_binding_required')
    if breakout_confluence['state'] != 'complete':
        blockers.append(breakout_confluence.get('reason') or 'same_native_event_confluence_incomplete')
    if parent["alignment"] == "unknown":
        blockers.append("direct_parent_direction_unknown")
    elif parent["alignment"] == "countertrend":
        blockers.append("current_direction_countertrend_to_direct_parent")
    if not measurements["valid_C_count"]:
        blockers.append("native_C_owner_missing")
    if not measurements["linked_three_push_count"]:
        blockers.append("owner_bound_three_push_missing")
    factors = (event.get('scorecard') or {}).get('factors') or {}
    owned_force = event.get('owned_force') or {}
    if any((factors.get(k) or {}).get('score') is None for k in ('outer_geometry', 'turning_geometry')):
        blockers.append("channel_or_turning_geometry_score_missing")
    if owned_force.get('force_score') is None:
        blockers.append("force_score_missing")
    if owned_force.get('force_score') is not None and (owned_force.get('force_profile') or {}).get('model_validation_status') != 'matched':
        blockers.append("force_band_model_not_matched")
    routes = measurements["routes"]
    entry_status = "blocked" if blockers or phase != "confirmed" else "research_ready_only"
    one_to_one_scores = scene.get("one_to_one_structure_scores") or {
        "status": "not_evaluated", "readings": [], "automatic_trade_permission": False}
    one_to_one_review = one_to_one_downstream_review(
        one_to_one_scores.get("readings"), cutoff,
        tasks=(scene.get("structure_logic") or {}).get("tasks", []),
        parent_context=parent, weekly_context=weekly)
    # A ready owner review still cannot join a Book B/C response on score,
    # direction or proximity.  The bridge records only a physical same-native
    # B/C proof; its factor stays research-only and is not an entry request.
    from .book_one_to_one_context import derive_one_to_one_book_context
    one_to_one_book_context = derive_one_to_one_book_context(scene, one_to_one_review)
    # Keep the non-authoritative research receipt next to Book logic so a
    # closed-prefix paper runner can consume it on a later explicit policy.
    # The runner still rejects it unless the dedicated policy is requested.
    book_logic = scene.get("book_logic")
    if isinstance(book_logic, dict):
        book_logic["one_to_one_book_context"] = one_to_one_book_context
    packet = {
        "schema": "integrated_market_logic_v1",
        "version": VERSION,
        "as_of_utc": cutoff,
        "timeframe": scene.get("timeframe"),
        "direct_parent": parent,
        "components": components,
        "score": score,
        "coverage": coverage,
        "phase": phase,
        "entry_status": entry_status,
        "entry_permission": False,
        "automatic_trade_permission": False,
        "routes": routes,
        "geometry_candidates": geometry[:8],
        "force_candidates": force[:8],
        "descriptive_force_measurements": [r for r in _force_evidence(scene, cutoff, include_descriptive=True)
                                            if r['evidence_scope'] == 'descriptive_wave_only'],
        "current_native_event": event,
        "source_event_observations": source_events,
        "native_wave_scope": {k:deepcopy(v) for k,v in ((event.get('scorecard') or {}).get('native_wave_process') or {}).items()
                              if k!='recognition'},
        "score_binding_version": "same_native_event_v2",
        "boundary_breakout_evidence": breakout,
        "breakout_confluence": breakout_confluence,
        "measurements": measurements,
        "one_to_one_structure_scores": one_to_one_scores,
        "one_to_one_downstream_review": one_to_one_review,
        "one_to_one_book_context": one_to_one_book_context,
        "weekly": weekly,
        "period_ladder": ladder,
        "blockers": blockers,
        "unknown_boundary": "score joins prefix evidence; missing direction, ownership or outcome is preserved as unknown",
        "score_semantics": "existing_stage_family_composite_of_recomputed_native_event_not_probability",
        "future_bars_used": False,
        "research_only": True,
    }
    # Keep the live Book decision card and the scene reducer on one immutable
    # receipt.  This only enriches diagnostics; it never changes the decision
    # status or turns the descriptive confluence into an entry permission.
    if isinstance(book_logic, dict) and isinstance(book_logic.get("realtime_entry_decision"), dict):
        decision = book_logic["realtime_entry_decision"]
        if decision.get("as_of_utc", cutoff) == cutoff:
            decision["chart_breakout_confluence"] = deepcopy(breakout_confluence)
            decision["chart_breakout_confluence_source"] = "integrated_market_logic_v1"
    from .structure_reference_context import build_reference_context
    packet["cross_framework_context"] = build_reference_context(scene)
    from .gobi_digger_context import consume_context, MINUTES
    packet["gobi_digger_context"] = consume_context(scene)
    from .gobi_digger_task_review import attach_review
    attach_review(scene, packet, packet['gobi_digger_context'], MINUTES)
    scene["integrated_market_logic"] = packet
    scene.setdefault("display_alignment", {})["integrated_market_logic"] = {
        "version": VERSION,
        "as_of_utc": cutoff,
        "phase": phase,
        "score": score,
        "coverage": coverage,
        "breakout_confluence": breakout_confluence,
        "entry_permission": False,
        "one_to_one_downstream_review_count": one_to_one_review["candidate_count"],
    }
    # A scene event score is not each drawn object's own grade. Remove old
    # aggregate tokens without changing the native label/profile/geometry.
    # Clicking an object may reference the scene, but must not inherit its score.
    for obj in scene.get("objects", []):
        if obj.get("layer") not in {"force", "channel", "turning_point", "trend", "three_push", "one_to_one"}:
            continue
        label = str(obj.get("label", ""))
        # A final reducer may revisit retained objects at a later scene clock.
        # Replace our prior tokens; presence is not proof that they are fresh.
        label = re.sub(r'(?:\s*\|\s*)?(?:fusion_phase=[^|]*|breakout_confluence=[^|]*)', '', label).strip()
        obj["label"] = label
        obj.setdefault("evidence", {})["integrated_market_logic_ref"] = {
            "version": VERSION,
            "as_of_utc": cutoff,
            "scope": "scene_event_context_only_not_this_object_grade",
            "object_source_id": obj.get('source_id'),
            "event_source_id": event.get('source_id'),
            "object_inherits_scene_score": False,
            "entry_permission": False,
        }
    return scene

