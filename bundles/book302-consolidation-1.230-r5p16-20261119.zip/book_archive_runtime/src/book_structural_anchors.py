"""Causal, native-period swing ownership for Book trend/turning constructions.

PDF63-65: order, exterior, coverage and axis are separate requirements.
PDF81/93-94: the shift anchor belongs to the corresponding adjustment.
The radii below are engineering scales, NOT the author's wave degrees.
Legacy accepted objects are retained. New objects need an actual alternating
sequence at one scale; geometric clearance alone never invents membership.
"""
from collections import Counter
from copy import deepcopy
from decimal import Decimal
from datetime import datetime
from hashlib import sha256
from statistics import median
from .trend_trade_method_full_pipeline import _closed, _closed_at
from .book_neckline_proof import neckline_proof

SCALES=(2,6,18,54)
RULE='trend_trade_method_pdf_structural_anchors_v2'


def _epoch(t):return datetime.fromisoformat(t.replace('Z','+00:00')).timestamp()


def integer_prices(rows):
    """Exact decimal quote units, not an invented trade tick or ATR allowance."""
    digits=max((max(0,-Decimal(str(r[s])).as_tuple().exponent)
                for r in rows for s in ('low','high','close')),default=0)
    unit=10**digits
    return [{s:int(Decimal(str(r[s]))*unit) for s in ('low','high','close')} for r in rows],unit


def confirmed_sequences(prices,radius):
    """Yield frozen four/five alternating pivots at their first knowledge time.

    Consecutive same-side extrema may update the current unfinished leg;
    already emitted tuples are immutable. Outside-bar order is unknown.
    """
    chain=[]
    for known in range(2*radius,len(prices)):
        i=known-radius
        high=all(prices[i]['high']>prices[j]['high'] for j in range(i-radius,known+1) if j!=i)
        low=all(prices[i]['low']<prices[j]['low'] for j in range(i-radius,known+1) if j!=i)
        if high==low:continue
        side='high' if high else 'low';p=(i,side,prices[i][side],known)
        if chain and chain[-1][1]==side:
            if (p[2]-chain[-1][2])*(1 if high else -1)<=0:continue
            chain[-1]=p
        else:chain.append(p)
        if len(chain)>=4:yield tuple(chain[-4:]),known
        if len(chain)>=5:yield tuple(chain[-5:]),known


def signed_gap(p,line,k,lower):
    i,pi,j,pj=line
    level_num=pi*(j-i)+(pj-pi)*(k-i)
    return p[k]['low']*(j-i)-level_num if lower else level_num-p[k]['high']*(j-i)


def clear(p,line,start,end,lower,anchors=()):
    for k in range(start,end+1):
        if k in anchors:continue
        g=signed_gap(p,line,k,lower)
        if g<=0:return {'ok':False,'index':k,'reason':'WICK_TOUCH' if g==0 else 'WICK_CROSS'}
    return {'ok':True}


def lifecycle(p,line,known,lower):
    contact=None;brk=None
    i,pi,j,pj=line
    for k in range(known+1,len(p)):
        if contact is None and signed_gap(p,line,k,lower)<=0:contact=k
        delta=p[k]['close']*(j-i)-(pi*(j-i)+(pj-pi)*(k-i))
        if brk is None and delta*(1 if lower else -1)<0:brk=k
    return dict(contact_index=contact,close_break_index=brk,
                display_end_index=contact-1 if contact is not None else len(p)-1)


def phase_contract(prices,seq,known,radius):
    """A four-pivot wave has TWO directional advances and its own adjustment.

    C-D-E are adjacent pivots at this scale; no scanning for a prettier D.
    The five-pivot form adds the FIRST corresponding post-E F for recovery.
    """
    if len(seq) not in (4,5):return {'ok':False,'reason':'PIVOT_COUNT'}
    up=seq[0][1]=='low';s=1 if up else -1
    expected=['low','high','low','high','low'] if up else ['high','low','high','low','high']
    if [x[1] for x in seq]!=expected[:len(seq)]:return {'ok':False,'reason':'NOT_ALTERNATING'}
    if any(a[0]>=b[0] for a,b in zip(seq,seq[1:])):return {'ok':False,'reason':'ANCHOR_ORDER'}
    if any(x[3]>known for x in seq):return {'ok':False,'reason':'ANCHOR_UNCONFIRMED'}
    o,c,d,e=seq[:4]
    if s*(d[2]-o[2])<=0:return {'ok':False,'reason':'DIRECTIONAL_STRUCTURE_BROKEN'}
    neckline=False;pair_proof=None
    if s*(e[2]-c[2])<=0:
        # PDF49/60/63: a confirmed second top/bottom can legalise the
        # intervening neckline AFTER the first (absolute) extreme. Keep
        # this a separate variant, not a relaxation of the ordinary rule.
        side='high' if up else 'low'
        typical=median(v['high']-v['low'] for v in prices[o[0]:known+1])
        pair_proof=neckline_proof(prices,seq,known,radius,typical*1.5)
        neckline=(len(seq)==4 and pair_proof['qualified']
                  and pair_proof['variant']=='post_extreme_neckline')
        if len(seq)==4 and not pair_proof['qualified']:
            return {'ok':False,'reason':pair_proof['reason']}
        if not neckline:return {'ok':False,'reason':'DIRECTIONAL_STRUCTURE_BROKEN'}
        # Preserve the native formation receipt needed by a downstream
        # Unified consumer. The boolean/price proof alone is insufficient:
        # a later consumer must recheck the four alternating pivots, the
        # absolute extreme, the intervening neckline and the first closed
        # confirmation boundary at this same prefix.
        pair_proof['native_receipt']=dict(
            schema='native_double_extreme_neckline_receipt_v1',
            pair=[dict(index=x[0],kind=x[1],price=x[2],known_index=x[3]) for x in seq[:4]],
            extreme_index=pair_proof['extreme_index'],
            neckline_index=pair_proof['neckline_index'],
            known_index=pair_proof['known_index'],
            radius=radius,source_rule_pages=[49,50,60,63],
            price_tolerance=typical*1.5,
            structural_degree_adjudicated=False,trade_permission=False)
    if d[0]-o[0]<6 or e[0]-c[0]<6:return {'ok':False,'reason':'ANCHOR_SPAN_TOO_SHORT'}
    # Geometric range includes the full phase, including confirmation bars.
    trend=(o[0],o[2],d[0],d[2])
    ce=(c[0],c[2],e[0],e[2])
    shifted=(d[0],d[2],d[0]+e[0]-c[0],d[2]+e[2]-c[2])
    return dict(ok=True,up=up,origin=o,c=c,d=d,e=e,trend=trend,extension=ce,shifted=shifted,
                known=known,radius=radius,neckline_exception=neckline,neckline_proof=pair_proof)


def structural_wave_objects(bars,timeframe,cutoff,existing=(),scales=SCALES):
    rows=_closed(bars,timeframe,cutoff)
    if not rows:return [],dict(status='DATA_PENDING',additional_objects=0)
    if any(r.get('timeframe',timeframe)!=timeframe for r in rows):
        return [],dict(status='CROSS_TIMEFRAME',additional_objects=0)
    p,unit=integer_prices(rows);counts=Counter();rejects=[];objects={};owners={}
    existing_ids={o['id'] for o in existing}
    def reject(reason,seq,radius,scope='',index=None):
        counts[reason]+=1
        # Keep representative actionable evidence without unbounded payloads.
        if sum(r['reason']==reason for r in rejects)<4:
            rejects.append(dict(reason=reason,scale_radius=radius,scope=scope,
                anchors=[rows[v[0]]['timestamp_utc'] for v in seq],
                first_failure_utc=rows[index]['timestamp_utc'] if index is not None else None))
    def emit(role,line,identity,lower,known,ctx,seq,radius,companion=None):
        life=lifecycle(p,line,known,lower);i,pi,j,pj=line;end=life['display_end_index']
        source_contact=None
        if companion is not None:
            source_contact=lifecycle(p,companion,known,not lower)['contact_index']
            if source_contact is not None:end=min(end,source_contact-1)
        if end<=i:return
        points=[[_epoch(rows[i]['timestamp_utc']),pi/unit],
                [_epoch(rows[end]['timestamp_utc']),(pi+(pj-pi)*(end-i)/(j-i))/unit]]
        variant='double_extreme_neckline' if ctx.get('neckline_exception') else 'ordinary'
        key=f'{timeframe}|turning_point|{role}|{identity}'
        if variant!='ordinary':key+='|'+variant
        oid='b'+sha256(key.encode()).hexdigest()[:23]
        stamps=[rows[v[0]]['timestamp_utc'] for v in seq]
        wave='bw'+sha256(f'{timeframe}|{radius}|{stamps[:4]}'.encode()).hexdigest()[:18]
        canonical_wave='native_wave:'+sha256(
            f"{timeframe}|{'up' if ctx['up'] else 'down'}|{','.join(stamps[:4])}".encode()
        ).hexdigest()[:24]
        canonical_lineage='native_wave_lineage:'+sha256(
            f"{timeframe}|{'up' if ctx['up'] else 'down'}|{','.join(stamps[:3])}".encode()
        ).hexdigest()[:24]
        known_utc=_closed_at(rows[known],timeframe)
        direction='up' if ctx['up'] else 'down'
        # Mid-axis agreement is measured, not presented as an author threshold.
        mids=[((a[0]+b[0])/2,(a[2]+b[2])/2) for a,b in zip(seq[:4],seq[1:4])]
        axis=median((b[1]-a[1])/(b[0]-a[0]) for a,b in zip(mids,mids[1:]))/unit
        name={'single_outer_trendline':'同段趋势','book_shifted_turning_boundary':'同段拐点','book_recovery_target':'同段恢复目标'}[role]
        if variant!='ordinary':name='双顶颈线趋势' if ctx['up'] else '双底颈线趋势'
        neckline_proof=ctx.get('neckline_proof')
        if neckline_proof and neckline_proof.get('native_receipt'):
            receipt=deepcopy(neckline_proof['native_receipt'])
            receipt.update(native_timeframe=timeframe,cutoff_utc=known_utc,
                pair=[dict(item,timestamp_utc=rows[item['index']]['timestamp_utc'],
                           known_at_utc=_closed_at(rows[item['known_index']],timeframe))
                      for item in receipt['pair']])
            neckline_proof=deepcopy(neckline_proof);neckline_proof['native_receipt']=receipt
        evidence=dict(rule_id=RULE,display_role='structural_wave_outer' if role=='single_outer_trendline' else role,
            direction=direction,structural_wave=True,wave_id=wave,canonical_wave_id=canonical_wave,
            canonical_wave_lineage_id=canonical_lineage,
            source_timeframe=timeframe,
            author_wave_degree='unknown',engineering_scale_radius=radius,
            membership_policy='adjacent_alternating_native_pivots',pivot_times=stamps,
            rule_variant=variant,neckline_similarity_policy='1.5_median_native_bar_range_engineering' if variant!='ordinary' else None,
            neckline_pair_proof=neckline_proof,
            pivot_roles=[v[1] for v in seq],pivot_confirmation_times=[_closed_at(rows[v[3]],timeframe) for v in seq],
            geometry_side='lower' if lower else 'upper',geometry_checked_through_utc=known_utc,
            owned_phase_start_utc=stamps[0],owned_phase_formation_end_utc=rows[known]['timestamp_utc'],
            ruler_identity=identity,anchor_start_index=i,anchor_end_index=j,
            source_rule_pages=[63,64,65,81,83,87,88,93,94],
            midaxis_slope=axis,midaxis_error=abs((pj-pi)/(j-i)/unit-axis),
            first_contact_utc=rows[life['contact_index']]['timestamp_utc'] if life['contact_index'] is not None else None,
            first_close_break_utc=rows[life['close_break_index']]['timestamp_utc'] if life['close_break_index'] is not None else None,
            source_extension_contact_utc=rows[source_contact]['timestamp_utc'] if source_contact is not None else None,
            read_only=True,trade_permission=False,no_internal_candle_crossing=True,
            author_membership_verified=False)
        status=('stopped_before_source_contact' if source_contact is not None and end==source_contact-1 else
                'stopped_before_price_contact' if life['contact_index'] is not None else 'projected_candidate')
        o=dict(id=oid,layer='turning_point',kind='line',timeframe=timeframe,points=points,
               known_at_utc=known_utc,status=status,owner_id=wave,source_id=RULE,evidence_ids=[RULE],unknown=False,
               label=f'{name} | {timeframe} {direction} | {wave} | S{radius} | '+('首次触价前停止' if status!='projected_candidate' else '有效候选'),evidence=evidence)
        owners.setdefault(oid,[]).append(wave)
        if oid in existing_ids:counts['MATCHES_EXISTING_GEOMETRY']+=1;return
        old=objects.get(oid)
        if old is None or known_utc<old['known_at_utc']:objects[oid]=o
    for radius in scales:
        for seq,known in confirmed_sequences(p,radius):
            counts['PIVOT_SEQUENCES']+=1
            ctx=phase_contract(p,seq,known,radius)
            if not ctx['ok']:reject(ctx['reason'],seq,radius);continue
            up=ctx['up'];o,c,d,e=seq[:4]
            point=lambda v:[_epoch(rows[v[0]]['timestamp_utc']),v[2]/unit]
            if len(seq)==4:
                counts['OWNED_CDE']+=1
                proof=clear(p,ctx['trend'],o[0],known,up,(o[0],d[0]))
                if proof['ok']:emit('single_outer_trendline',ctx['trend'],[point(o),point(d)],up,known,ctx,seq,radius)
                else:reject(proof['reason'],seq,radius,'trend',proof['index'])
                # A neckline exception does not create a directional CE/D
                # construction. Its high/low sequence has stopped advancing.
                if ctx.get('neckline_exception'):
                    counts['CONFIRMED_NECKLINE_PHASES']+=1
                    continue
                # C/E is the opposite outer edge of THIS declared phase.
                # Its backwards extension must also clear O..C, independently
                # of the D-shift target and the O/D trend boundary.
                proof=clear(p,ctx['extension'],o[0],known,not up,(c[0],e[0]))
                if not proof['ok']:reject(proof['reason'],seq,radius,'CE',proof['index']);continue
                proof=clear(p,ctx['shifted'],d[0],known,up,(d[0],))
                if not proof['ok']:reject(proof['reason'],seq,radius,'D_shift',proof['index']);continue
                emit('book_shifted_turning_boundary',ctx['shifted'],[point(c),point(e),point(d)],up,known,ctx,seq,radius)
            else:
                f=seq[4]
                # The same-scale first adjustment F must respect D. No later
                # micro-pivot substitution when this corresponding F fails.
                if (f[2]-d[2])*(1 if up else -1)<=0:reject('F_BREAKS_D',seq,radius);continue
                df=(d[0],d[2],f[0],f[2]);target=(c[0],c[2],c[0]+f[0]-d[0],c[2]+f[2]-d[2])
                for line,start,lower,anchors,scope in ((df,d[0],up,(d[0],f[0]),'DF'),(target,c[0],not up,(c[0],),'C_shift')):
                    proof=clear(p,line,start,known,lower,anchors)
                    if not proof['ok']:reject(proof['reason'],seq,radius,scope,proof['index']);break
                else:emit('book_recovery_target',target,[point(d),point(f),point(c)],not up,known,ctx,seq,radius,df)
    for oid,obj in objects.items():obj['evidence']['supporting_wave_ids']=sorted(set(owners[oid]))
    return list(objects.values()),dict(status='EVALUATED',context_bars=len(rows),scales=list(scales),
        scales_are_engineering_parameters=True,additional_objects=len(objects),counts=dict(counts),
        rejection_examples=rejects,retained_existing_objects=len(existing),legacy_removed=0,
        author_wave_degrees='unknown',force_detector_unchanged=True)
