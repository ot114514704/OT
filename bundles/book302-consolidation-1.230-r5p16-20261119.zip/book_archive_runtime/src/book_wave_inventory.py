"""Native-period historical outer candidates; search sizes are not book degrees."""
from datetime import datetime, timezone
import json
import hashlib
from .pdf_trendline_block import (select_pdf_outer_trendline, select_pdf_turning_boundary,
    select_pdf_wave_relative_outer, PDF_SOURCE_SHA256, PDF_TRENDLINE_RULE_PAGES,
    PDF_TURNING_POINT_RULE_PAGES)
from .trend_trade_method_full_pipeline import (_closed, _closed_at, scene_objects,
    detect_first_closed_break, detect_parallel_break, evaluate_break_force)
from .book_recovery_projection import recovery_projection

BOOK_CONTEXT_BARS = 2048


def first_ruler_contact(rows, line):
    """A shared origin does not merge phases separated by an observed contact."""
    i,j=line['start_index'],line['end_index']
    for k in range(j+1,len(rows)):
        level=line['start_price']+line['slope']*(k-i)
        gap=float(rows[k]['low'])-level if line['direction']=='up' else level-float(rows[k]['high'])
        if gap<=0:return k
    return len(rows)


def load_book_context(timeframe, cutoff, fallback):
    """Read only the selected period widely, without expanding all 8 engines."""
    if not cutoff:
        return fallback
    from .build_archive_window_snapshot import ARCHIVE, load_prefix, mt5_weekly_prefix
    dataset=next(d for d in json.loads((ARCHIVE/'catalog.json').read_text(encoding='utf-8'))['datasets'] if d['id']=='HistData')
    epoch=datetime.fromisoformat(cutoff.replace('Z','+00:00')).timestamp()
    rows=(mt5_weekly_prefix(dataset,epoch,BOOK_CONTEXT_BARS) if timeframe=='W1'
          else load_prefix(dataset['periods'][timeframe],epoch,BOOK_CONTEXT_BARS))
    return [dict(timestamp_utc=datetime.fromtimestamp(float(r[0]),timezone.utc).isoformat().replace('+00:00','Z'),
                 open=float(r[1]),high=float(r[2]),low=float(r[3]),close=float(r[4]),
                 provider='HistData',symbol='XAUUSD',timeframe=timeframe) for r in rows]


def historical_book_objects(bars, timeframe, cutoff, existing=()):
    rows=_closed(bars,timeframe,cutoff)
    n=len(rows); candidates={}; attempts=0
    # All overlapping selectors below read this same closed native prefix.
    # Validate it once; passing the private selector flag preserves exactly
    # the same rejection rule while removing repeated full-prefix validation
    # from the hot scan loop.
    from .pdf_trendline_block import _valid_bar
    validated_rows=all(_valid_bar(row) for row in rows)
    from .book_window_selector_cache import WINDOWS,row_fingerprints
    fingerprints=row_fingerprints(rows)
    # Sliding prefixes retain earlier waves and both directions. A currently
    # upward vote cannot suppress an earlier down wave. Every accepted ruler
    # still goes through the strict broad-anchor/wick selector.
    for width in (96,256,512,1024):
        if n<width:continue
        # Inspect every closed prefix at the finest existing search scale.
        # A 48-bar stride skipped complete fast waves between samples (the
        # Jan-30 M30 decline qualified only between the coarse endpoints).
        # Wider scans and all geometric/anchor acceptance rules are unchanged.
        step=1 if width==96 else max(32,width//2)
        ends=sorted(set(range(width,n+1,step))|{n})
        for end in ends:
            for upward in (True,False):
                attempts+=1
                line=WINDOWS.select(select_pdf_outer_trendline,rows,end,upward,width,
                                    validated_rows,fingerprints)
                if not line.get('qualified'):continue
                i,j=line['start_index'],line['end_index']
                key=(rows[i]['timestamp_utc'],line['start_price'],rows[j]['timestamp_utc'],line['end_price'])
                known=_closed_at(rows[end-1],timeframe)
                if key in candidates and candidates[key][1]<=known:continue
                candidates[key]=(line,known,width,end)
    # A wider later anchor pair may replace an overlapping candidate, but
    # cannot erase a phase which had ended before that pair's second anchor.
    origins={}
    for key,value in candidates.items():
        line=value[0];origin=(key[0],key[1],line['direction'])
        origins.setdefault(origin,[]).append((key,value))
    grouped={}
    for group in origins.values():
        selected=[]
        for key,value in sorted(group,key=lambda item:item[1][0]['anchor_span_bars'],reverse=True):
            line=value[0];contact=first_ruler_contact(rows,line)
            if any(contact>=other[0]['end_index'] for other in selected):continue
            selected.append(value);grouped[key]=value
    # Keep the legacy inventory intact. A separate supporting-tangent search
    # recovers broad native-wave anchors lost by fixed-window pivot radii and
    # terminal percentages; it may not delete an earlier accepted ruler.
    supplements={}
    for width in (256,512,1024):
        ends=range(12,n+1) if width==256 else sorted(set(range(width,n+1,width//2))|{n})
        for end in ends:
            for upward in (True,False):
                attempts+=1
                line=WINDOWS.select(select_pdf_wave_relative_outer,rows,end,upward,width,
                                    validated_rows,fingerprints)
                if not line.get('qualified'):continue
                i,j=line['start_index'],line['end_index']
                identity=(rows[i]['timestamp_utc'],line['start_price'],rows[j]['timestamp_utc'],line['end_price'])
                if identity in supplements:continue
                supplements[identity]=(line,_closed_at(rows[end-1],timeframe),width,end)
    objects=[]; rejected_contacts=0; found=0
    occupied={tuple(tuple(p) for p in (o.get('evidence',{}).get('ruler_identity') or o.get('ruler_identity') or []))
              for o in existing if o.get('evidence',{}).get('display_role') in
              {'single_outer_trendline','trend_outer_boundary','same_chart_wave_degree_outer_trendline'}}
    for line,known,width,observed_end in [*grouped.values(),*supplements.values()]:
        i,j=line['start_index'],line['end_index']
        identity=tuple((datetime.fromisoformat(rows[k]['timestamp_utc'].replace('Z','+00:00')).timestamp(),line[field])
                       for k,field in ((i,'start_price'),(j,'end_price')))
        if identity in occupied:continue
        occupied.add(identity)
        line=dict(line,timeframe=timeframe,known_at_utc=known)
        # A stable computational identity is required before chapter-4 lines
        # or later targets can claim membership in this native wave.  This is
        # a source identity, not an author degree assertion.
        wave_identity = f"{timeframe}|{line.get('direction')}|{rows[i]['timestamp_utc']}|{line.get('start_price')}|{rows[j]['timestamp_utc']}|{line.get('end_price')}"
        line['wave_id'] = 'book_wave:' + hashlib.sha256(wave_identity.encode()).hexdigest()[:24]
        line['parent_wave_id'] = None
        line['wave_membership_state'] = 'native_source_candidate_not_author_verified'
        end=n-1; contact=None
        # Freeze the ruler. A later wick-only breach ends its clean display,
        # rather than erasing the entire preceding qualified movement.
        for k in range(j+1,n):
            level=line['start_price']+line['slope']*(k-i)
            gap=float(rows[k]['low'])-level if line['direction']=='up' else level-float(rows[k]['high'])
            if gap<=0:
                close=float(rows[k]['close'])
                crossed=close<level if line['direction']=='up' else close>level
                end=k if crossed else k-1
                if crossed:line['first_break_index']=k
                else:contact=k;line['first_break_index']=None;rejected_contacts+=1
                break
        shown=rows[:end+1] if contact is not None else rows
        brk=detect_first_closed_break(shown,line,timeframe,cutoff)
        formation_line=dict(line, first_break_index=min(line.get("first_break_index") or observed_end, observed_end))
        turning=select_pdf_turning_boundary(rows[:observed_end],formation_line)
        turning.update(timeframe=timeframe,known_at_utc=known,
                       parent_wave_id=line.get('wave_id'),
                       wave_membership_state=line.get('wave_membership_state'))
        pbrk=detect_parallel_break(shown,line,{'projection':turning} if turning.get('qualified') else {},timeframe,cutoff)
        ev=dict(as_of_utc=cutoff,turning_point_line=line,turning_boundary=turning,
                first_closed_break=brk,parallel_break=pbrk,break_force=evaluate_break_force(shown,brk,timeframe,cutoff),
                recovery_target={'qualified':False,'reason':'separate_projection_lifecycle'})
        if ev['break_force'].get('known_at_utc'):
            ev['break_force']['known_at_utc']=max(known,ev['break_force']['known_at_utc'])
        batch=scene_objects(ev,shown,timeframe)
        # Both chapter-4 rulers have their own lifecycle. The parent outer
        # line's wick stop cannot leave a separately frozen return boundary
        # or recovery target falsely pending. Keep the original parent and
        # response observations, replacing only its truncated RETURN object.
        batch=[obj for obj in batch if obj.get('evidence',{}).get('family')!='RETURN_CE_D']
        return_break=detect_parallel_break(rows,line,{'projection':turning} if turning.get('qualified') else {},timeframe,cutoff)
        return_batch=scene_objects(dict(as_of_utc=cutoff,turning_boundary=turning,
            parallel_break=return_break,recovery_target={'qualified':False,'reason':'separate_projection_lifecycle'}),rows,timeframe)
        batch.extend(obj for obj in return_batch if obj.get('evidence',{}).get('family')=='RETURN_CE_D')
        recovery=recovery_projection(rows,turning,timeframe,cutoff,source_line=line)
        batch+=scene_objects(dict(as_of_utc=cutoff,recovery_target=recovery),rows,timeframe)
        for obj in batch:
            e=obj['evidence']
            e['book_wave_ruler_identity']=identity
            if e.get('display_role') not in {'single_outer_trendline','book_shifted_turning_boundary','book_recovery_target'}:
                obj['id']='b'+hashlib.sha256(f"{identity}|{obj['id']}".encode()).hexdigest()[:23]
            e.update(historical_wave_candidate=True,search_window_bars=width,
                     wave_relative_supplement=bool(line.get('wave_relative_supplement')),
                     author_wave_degree='unknown',
                     first_wick_contact_utc=rows[contact]['timestamp_utc'] if contact is not None else None,
                     source_pdf_sha256=PDF_SOURCE_SHA256,
                     future_bars_used=False,read_only=True,trade_permission=False)
            # Keep chapter-4 provenance on a C/D/E projection. The parent
            # chapter-3 trendline is context, not its construction source.
            e.setdefault('source_rule_pages',list(PDF_TRENDLINE_RULE_PAGES))
            if e.get('display_role') in {'book_shifted_turning_boundary','book_recovery_target','parallel_outer_extension'}:
                e.setdefault('turning_point_rule_pages',list(PDF_TURNING_POINT_RULE_PAGES))
            if e.get('display_role')=='single_outer_trendline':
                e['display_role']='historical_book_outer'
                e['trend_degree']='unknown';e['degree_role']='unassigned_native_wave'
                e['degree_lookback_bars']=width
                obj.update(display_role='historical_book_outer',trend_degree='unknown',degree_role='unassigned_native_wave',degree_lookback_bars=width)
                if contact is not None:
                    obj['status']='stopped_before_unconfirmed_wick_contact'
                    obj['label']+=' | wick contact: unconfirmed'
            objects.append(obj)
        found+=1
    unique={}
    for obj in objects:
        previous=unique.get(obj['id'])
        if previous and obj['evidence'].get('display_role') in {'book_shifted_turning_boundary','book_recovery_target'}:
            # One C/D/E construction can be discovered by several parent
            # candidates. Retain one independently validated geometry, not
            # one duplicate for every parent trendline.
            known=min(previous['known_at_utc'],obj['known_at_utc'])
            if previous['points'][-1][0]>obj['points'][-1][0]:obj=previous
            # Keep the earliest construction discovery without backdating
            # a later display extent or contact state of the chosen geometry.
            clocks=[obj.get('evidence',{}).get(k) for k in
                    ('construction_known_at_utc','display_known_at_utc','state_known_at_utc')]
            known=max([known]+[t for t in clocks if t],key=lambda t:datetime.fromisoformat(t.replace('Z','+00:00')))
            obj['known_at_utc']=known
        unique[obj['id']]=obj
    retained=compact_historical_book_objects(list(unique.values()))
    retained,display_compactions=_compact_duplicate_display_segments(retained,timeframe)
    return retained,dict(context_bars=n,attempted_windows=attempts,
        unique_rulers=len(candidates),origin_groups=len(origins),retained_ruler_phases=len(grouped),
        additional_rulers=found,wick_contact_stops=rejected_contacts,
        duplicate_display_segments_compacted=display_compactions,
        direction_search='both_independent_of_latest_vote',author_wave_degree='unknown',
        window_sizes_are_engineering_parameters=True,finest_scan_stride_bars=1,
        wave_relative_unique_pairs=len(supplements),
        read_only=True,trade_permission=False)


def compact_historical_book_objects(objects):
    """Overview-only compaction across tiles; original scene evidence survives."""
    groups={}
    for obj in objects:
        e=obj.get('evidence',{})
        if e.get('display_role')!='historical_book_outer':continue
        identity=e.get('book_wave_ruler_identity')
        if not identity:continue
        origin=(obj.get('timeframe'),tuple(identity[0]),e.get('direction'),bool(e.get('wave_relative_supplement')))
        groups.setdefault(origin,[]).append(obj)
    keep=set()
    # A wider later pair cannot erase an earlier ruler that had ALREADY
    # broken before that wider pair's second anchor. They are distinct
    # observed phases, even when their first extreme is the same.
    for group in groups.values():
        selected=[]
        for obj in sorted(group,key=lambda o:o['evidence']['book_wave_ruler_identity'][1][0],reverse=True):
            identity=obj['evidence']['book_wave_ruler_identity']
            # Missing lifecycle evidence cannot establish a distinct phase.
            end=float(obj['points'][-1][0]) if obj.get('points') else float('inf')
            if any(end>=float(other['evidence']['book_wave_ruler_identity'][1][0]) for other in selected):continue
            selected.append(obj);keep.add((obj.get('timeframe'),tuple(tuple(p) for p in identity)))
    return [obj for obj in objects if not obj.get('evidence',{}).get('historical_wave_candidate')
            or obj.get('evidence',{}).get('display_role') in {'book_shifted_turning_boundary','book_recovery_target'}
            or (obj.get('timeframe'),tuple(tuple(p) for p in obj['evidence'].get('book_wave_ruler_identity',[]))) in keep]


def _compact_duplicate_display_segments(objects, timeframe):
    """Collapse overlapping render copies of one frozen Book ruler.

    The inventory scans the same prefix at several widths.  A single ruler
    can therefore arrive as many objects with the same native identity and
    overlapping endpoints.  They are evidence copies, not separate waves.
    Keep non-overlapping native/session segments, but merge only overlapping
    copies whose rendered line has the same slope and intercept.  The dropped
    IDs and clocks remain on the retained object for auditability.
    """
    period={'M1':60,'M5':300,'M15':900,'M30':1800,'H1':3600,
            'H4':14400,'D1':86400,'W1':604800}.get(timeframe,0)
    roles={'historical_book_outer','parallel_outer_extension'}
    groups={}
    passthrough=[]
    for obj in objects:
        ev=obj.get('evidence',{})
        if (not ev.get('historical_wave_candidate') or
                ev.get('display_role') not in roles or
                not ev.get('book_wave_ruler_identity') or
                len(obj.get('points') or [])<2):
            passthrough.append(obj);continue
        ident=tuple(tuple(p) for p in ev['book_wave_ruler_identity'])
        groups.setdefault((obj.get('timeframe'),ev.get('display_role'),ident),[]).append(obj)
    compacted=0
    kept=[]
    for group in groups.values():
        if len(group)<2:
            kept.extend(group);continue
        def sig(obj):
            p=obj['points'];t0,y0=p[0];t1,y1=p[-1]
            if not isinstance(t0,(int,float)) or not isinstance(t1,(int,float)) or t1==t0:return None
            slope=(y1-y0)/(t1-t0)
            return slope,y0-slope*t0
        entries=[]
        for obj in group:
            p=obj['points'];start=float(p[0][0]);end=float(p[-1][0]);s=sig(obj)
            entries.append((start,end,s,obj))
        used=set()
        for i,(start,end,s,obj) in enumerate(entries):
            if i in used:continue
            component=[i];used.add(i);changed=True
            while changed:
                changed=False
                for j,(s2,e2,ss,obj2) in enumerate(entries):
                    if j in used:continue
                    if any(not (e2 < entries[k][0] or s2 > entries[k][1]) and
                           ss is not None and s is not None and
                           abs(ss[0]-s[0])<=1e-12 and abs(ss[1]-s[1])<=1e-7
                           for k in component):
                        component.append(j);used.add(j);changed=True
            if len(component)==1:
                kept.append(obj);continue
            # Preserve one exact line over the union of overlapping copies.
            members=[entries[k] for k in component]
            first=min(members,key=lambda x:x[0]);last=max(members,key=lambda x:x[1])
            chosen=max(members,key=lambda x:(x[1]-x[0],x[1],-x[0]))[3]
            left,right=first[0],last[1]
            slope,intercept=s
            chosen['points']=[[left,slope*left+intercept],[right,slope*right+intercept]]
            dropped=[m[3] for m in members if m[3] is not chosen]
            if dropped:
                ev=chosen.setdefault('evidence',{})
                prior=ev.setdefault('display_lifecycle_compacted',[])
                prior.extend(dict(id=x.get('id'),points=x.get('points'),status=x.get('status'),
                                  known_at_utc=x.get('known_at_utc')) for x in dropped)
                ev['display_lifecycle_compacted_count']=len(prior)
                compacted+=len(dropped)
            kept.append(chosen)
    return passthrough+kept,compacted
