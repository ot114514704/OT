"""Historical display lifetimes for revisions of one frozen C/E -> D ruler.

Engineering display policy, not a new book wave-degree classifier. Only an
identical native C, D, direction, method and scale can revise an earlier E.
Earlier geometry remains until the successor is knowable. Source scenes and
force calculations remain unchanged. Independent origins are never merged.
"""
from bisect import bisect_right
from copy import deepcopy
from datetime import datetime


def epoch(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()


def revise_projection_display(objects, timeframe, cutoff, stamps, seconds):
    cutoff_epoch = epoch(cutoff)
    stamps = [float(t) for t in stamps if float(t) + seconds <= cutoff_epoch]
    positions = {t: i for i, t in enumerate(stamps)}
    groups = {}
    for obj in objects:
        ev = obj.get('evidence', {})
        if ev.get('display_role') != 'book_shifted_turning_boundary':
            continue
        identity = ev.get('ruler_identity')
        if obj.get('timeframe') != timeframe or not identity or len(identity) != 3:
            continue
        c, e, d = identity
        known = obj.get('known_at_utc')
        if (not known or known > cutoff or not c[0] < d[0] < e[0] < epoch(known)
                or any(float(p[0]) not in positions for p in identity)):
            continue
        direction = ev.get('direction')
        if direction not in ('up', 'down'):
            continue
        # Deliberately do not combine structural and legacy interpretations,
        # or neighbouring radii. Shared screen positions do not prove a wave.
        key = (timeframe, tuple(c), tuple(d), direction, obj.get('source_id'),
               ev.get('engineering_scale_radius'), ev.get('rule_variant'))
        groups.setdefault(key, []).append(obj)

    changes = {}
    for group in groups.values():
        ordered = sorted(group, key=lambda o: (o['known_at_utc'], o['id']))
        for old in ordered:
            ev = old['evidence']; c, e, d = ev['ruler_identity']
            sign = 1 if ev['direction'] == 'up' else -1
            # Same-clock alternatives are ambiguous, not sequential revisions.
            successors = [new for new in ordered
                          if new['known_at_utc'] > old['known_at_utc']
                          and new['evidence']['ruler_identity'][1][0] > e[0]
                          and sign * (new['evidence']['ruler_identity'][1][1] - e[1]) > 0]
            if not successors:
                continue
            successor = successors[0]
            at = epoch(successor['known_at_utc'])
            end = bisect_right(stamps, at - seconds) - 1
            start = positions[float(d[0])]
            if end <= start or stamps[end] >= float(old['points'][-1][0]):
                continue  # Already ended phases keep their original geometry.
            slope = (e[1] - c[1]) / (positions[float(e[0])] - positions[float(c[0])])
            replacement = deepcopy(old)
            replacement['points'][-1] = [stamps[end], d[1] + slope * (end - start)]
            evidence = replacement['evidence']
            evidence['display_revision'] = dict(
                policy='same_C_D_native_method_scale_later_directional_E',
                successor_id=successor['id'], successor_known_at=successor['known_at_utc'],
                original_points=deepcopy(old['points']), original_status=old['status'],
                history_retained=True, source_geometry_changed=False,
                display_only=True, author_wave_degree_verified=False)
            replacement['status'] = 'historical_projection_revised'
            replacement['label'] += ' | 历史拐点版本·后续E确认后停止延伸'
            changes[old['id']] = replacement

    result = []
    markers = 0
    for obj in objects:
        shown = changes.get(obj['id'], obj)
        ev = shown.get('evidence', {})
        if (ev.get('display_role') == 'book_boundary_event'
                and shown.get('timeframe') == timeframe and 'line_price' in ev):
            # Mark the actual frozen ruler level, not the entire price candle.
            # Width is one native bar; no future candle value is consumed.
            shown = deepcopy(shown)
            start = epoch(ev['event_bar_utc'])
            if start + seconds <= epoch(shown['known_at_utc']) <= epoch(cutoff):
                shown['evidence']['display_original_points'] = deepcopy(shown['points'])
                shown['points'] = [[start, ev['line_price']], [start + seconds, ev['line_price']]]
                shown['evidence']['display_marker'] = 'one_native_bar_at_frozen_ruler_price'
                markers += 1
        result.append(shown)
    return result, dict(policy='projection_revision_display_v1',
                        revised_projections=len(changes), boundary_level_markers=markers,
                        removed_objects=0, force_objects_modified=0,
                        changes=[dict(id=o['id'], **o['evidence']['display_revision']) for o in changes.values()])
