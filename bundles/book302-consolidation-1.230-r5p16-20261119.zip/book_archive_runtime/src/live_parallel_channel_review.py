"""Native parallel-channel geometry independent of equal-distance rulers.

Two same-side confirmed extrema define the trend rail; an intervening
opposite extremum defines its parallel. Candle bodies must fit the formation.
Wick excursions are observations. The first subsequent outside close ends
the displayed channel, without asserting a trend reversal. Bar ordinal is
the horizontal coordinate, matching a chart with market closures compressed.
"""
from datetime import datetime, timedelta
from math import isfinite
from statistics import median

METHOD = "native_swing_parallel_channel_lifecycle_v1"
MINUTES = {"M1":1,"M5":5,"M15":15,"M30":30,"H1":60,"H4":240,"D1":1440,"W1":10080}


def _utc(value):
    return value.isoformat().replace("+00:00","Z") if isinstance(value,datetime) else value


def _time(value):
    value=datetime.fromisoformat(str(value).replace("Z","+00:00"))
    if value.tzinfo is None:
        raise ValueError("explicit UTC offset required")
    return value


def _channel_intelligence(bars, ordered, side_kind, ia, ic, end, low, high,
                          offset, typical_range):
    """Score channel *quality* without turning it into a trading signal.

    The old reviewer selected the largest opposite excursion.  That is
    geometrically enclosing, but a single news wick could therefore become a
    fake channel.  This audit keeps the enclosing geometry and adds causal,
    reproducible diagnostics: body fit, independent rail touches, touch
    distribution, width relative to native range and wick contamination.
    Nothing here uses bars after ``end`` or future outcome information.
    """
    count = max(1, end - ia + 1)
    tol = max(typical_range * 0.20, abs(offset) * 0.025, 1e-9)
    body_fit = 0
    wick_excursions = 0
    lower_touches = []
    upper_touches = []
    for i in range(ia, end + 1):
        lo, hi = low(i), high(i)
        body_lo = min(bars[i].open, bars[i].close)
        body_hi = max(bars[i].open, bars[i].close)
        if body_lo >= lo - 1e-12 and body_hi <= hi + 1e-12:
            body_fit += 1
        if bars[i].low < lo - tol or bars[i].high > hi + tol:
            wick_excursions += 1
        if abs(bars[i].low - lo) <= tol:
            lower_touches.append(i)
        if abs(bars[i].high - hi) <= tol:
            upper_touches.append(i)

    opposite = [p for p in ordered if ia <= p["index"] <= ic and
                p["kind"] != side_kind]
    opposite_touch_indices = []
    for p in opposite:
        rail = low(p["index"]) if side_kind == "confirmed_swing_high_candidate" else high(p["index"])
        if abs(p["price"] - rail) <= tol:
            opposite_touch_indices.append(p["index"])
    opposite_touch_indices = sorted(set(opposite_touch_indices))
    touch_indices = sorted(set(lower_touches + upper_touches + opposite_touch_indices))
    thirds = [set(range(ia, ia + max(1, (ic - ia + 1) // 3))),
              set(range(ia + max(1, (ic - ia + 1) // 3),
                       ia + max(1, 2 * (ic - ia + 1) // 3))),
              set(range(ia + max(1, 2 * (ic - ia + 1) // 3), ic + 1))]
    occupied = sum(bool(set(touch_indices) & bucket) for bucket in thirds)
    width_atr = abs(offset) / max(typical_range, 1e-9)
    # A useful channel need not have an arbitrary fixed pip width.  It should
    # be neither narrower than noise nor so wide that it is merely a box.
    width_fit = (1.0 if 1.0 <= width_atr <= 8.0 else
                 max(0.0, 1.0 - abs(width_atr - 4.0) / 8.0))
    formation_span = max(1, ic - ia + 1)
    # Very short rails can fit by construction.  Give the score credit only
    # when the two anchors have a meaningful native separation; this keeps a
    # compact two-touch spike from becoming a perfect channel.
    formation_fit = max(0.0, min(1.0, (formation_span - 4.0) / 20.0))
    body_ratio = body_fit / count
    touch_quality = min(1.0, len(opposite_touch_indices) / 2.0)
    distribution = occupied / 3.0
    contamination = wick_excursions / count
    clean_ratio = max(0.0, 1.0 - contamination)
    # These are explanatory weights, not fitted probabilities.  Keep each
    # component visible so a later prefix calibration can replace the cutoffs
    # without hiding which geometric fact changed the grade.
    components = [
        {"key": "body_fit", "weight": 20.0, "value": round(body_ratio, 4)},
        {"key": "opposite_touch", "weight": 22.0, "value": round(touch_quality, 4)},
        {"key": "touch_distribution", "weight": 18.0, "value": round(distribution, 4)},
        {"key": "width_fit", "weight": 15.0, "value": round(width_fit, 4)},
        {"key": "wick_clean", "weight": 10.0, "value": round(clean_ratio, 4)},
        {"key": "formation_span", "weight": 15.0, "value": round(formation_fit, 4)},
    ]
    base_score = sum(c["weight"] * c["value"] for c in components)

    # The six geometric components above answer "can an envelope be drawn?".
    # They do not answer whether the swings behave like a channel.  Keep that
    # distinction explicit and add a small, auditable adjustment for the
    # properties a discretionary chart reader actually uses: alternating rail
    # contact, stable residuals, slope relative to width, and the first closed
    # breakout.  This uses only bars through ``end``; it never looks past the
    # first outside close or the current prefix.
    centre = lambda i: (low(i) + high(i)) / 2.0
    residuals = []
    for i in range(ia, end + 1):
        body_mid = (float(bars[i].open) + float(bars[i].close)) / 2.0
        residuals.append(abs(body_mid - centre(i)) / max(abs(offset), typical_range, 1e-9))
    residual_median = median(residuals) if residuals else 1.0
    residual_fit = max(0.0, min(1.0, 1.0 - residual_median))

    touch_sequence = []
    touch_events = []
    rails_by_bar = {}
    for p in ordered:
        if not ia <= p["index"] <= end:
            continue
        i = p["index"]
        if abs(p["price"] - low(i)) <= tol:
            rail_name = "lower"
        elif abs(p["price"] - high(i)) <= tol:
            rail_name = "upper"
        else:
            continue
        rails_by_bar.setdefault(i,set()).add(rail_name)
    for i,rails in sorted(rails_by_bar.items()):
        if len(rails)!=1:
            touch_events.append(None)
            continue
        rail_name=next(iter(rails));touch_events.append(rail_name)
        if not touch_sequence or touch_sequence[-1]["rail"] != rail_name:
            touch_sequence.append({"rail": rail_name, "index": i,
                                   "timestamp_utc": _utc(bars[i].timestamp_utc)})
    alternations = sum(a is not None and b is not None and a!=b
                       for a,b in zip(touch_events,touch_events[1:]))
    alternation_ratio = (alternations / max(1, len(touch_events) - 1)
                         if touch_sequence else 0.0)
    rail_change = abs(float(low(ic) - low(ia)))
    slope_width_ratio = rail_change / max(abs(offset), typical_range, 1e-9)
    # A nearly horizontal envelope with frequent alternating touches is a
    # balance/range candidate. It can be useful context, but should not be
    # treated as directional channel evidence.
    range_like = bool(slope_width_ratio < 0.20 and alternations >= 2)
    slope_quality = max(0.0, min(1.0, slope_width_ratio / 1.0))
    if range_like:
        slope_quality *= 0.35

    break_extension = None
    if end > ic:
        close = float(bars[end].close)
        boundary = high(end) if close > high(end) else low(end)
        break_extension = abs(close - boundary) / max(typical_range, 1e-9)
    breakout_quality = (max(0.0, min(1.0, break_extension / 1.5))
                        if break_extension is not None else None)
    advanced_parts = [0.35 * alternation_ratio,
                      0.35 * residual_fit,
                      0.20 * slope_quality]
    if breakout_quality is not None:
        advanced_parts.append(0.10 * breakout_quality)
    advanced_quality = sum(advanced_parts) / max(1e-9, sum(
        [0.35, 0.35, 0.20] + ([0.10] if breakout_quality is not None else [])))
    adjustment = (advanced_quality - 0.5) * 12.0
    if range_like:
        adjustment -= 8.0
    score = round(max(0.0, min(100.0, base_score + adjustment)), 1)
    grade = "strong" if score >= 70 else "medium" if score >= 50 else "weak"
    if len(opposite_touch_indices) >= 2 and occupied >= 2 and score >= 70:
        quality = "confirmed"
        reason = "two_independent_opposite_touches_with_distributed_fit"
    elif len(opposite_touch_indices) >= 1 and score >= 50:
        quality = "candidate"
        reason = "single_opposite_touch_or_incomplete_distribution"
    else:
        quality = "unknown"
        reason = "channel_is_enclosing_geometry_without_repeated_rail_evidence"
    return {
        "score": score,
        "base_score": round(base_score, 1),
        "advanced_adjustment": round(adjustment, 1),
        "grade": grade,
        "score_version": "channel_geometry_components_v2",
        "score_basis": "engineering_initial_components",
        "calibration_status": "not_calibrated_to_channel_outcomes",
        "grade_thresholds": {"weak_lt": 50.0, "medium_gte": 50.0, "strong_gte": 70.0},
        "components": components,
        "quality": quality,
        "reason": reason,
        "typical_range": typical_range,
        "formation_span_bars": formation_span,
        "formation_span_fit": round(formation_fit, 4),
        "width_atr_ratio": round(width_atr, 4),
        "body_fit_ratio": round(body_ratio, 4),
        "wick_contamination_ratio": round(contamination, 4),
        "opposite_touch_count": len(opposite_touch_indices),
        "opposite_touch_indices": opposite_touch_indices,
        "lower_touch_count": len(lower_touches),
        "upper_touch_count": len(upper_touches),
        "touch_distribution_thirds": occupied,
        "advanced_diagnostics": {
            "touch_sequence": touch_sequence,
            "touch_sequence_count": len(touch_sequence),
            "rail_alternation_count": alternations,
            "rail_alternation_ratio": round(alternation_ratio, 4),
            "body_mid_residual_median_normalized": round(residual_median, 4),
            "body_mid_residual_fit": round(residual_fit, 4),
            "slope_width_ratio": round(slope_width_ratio, 4),
            "range_like_balance_candidate": range_like,
            "break_extension_atr": (round(break_extension, 4)
                                     if break_extension is not None else None),
            "breakout_quality": (round(breakout_quality, 4)
                                  if breakout_quality is not None else None),
            "evaluation_end_index": end,
            "evaluation_clock_role": "first_closed_break_or_current_prefix",
            "future_bars_used": False,
        },
        "tolerance": tol,
        "as_of_index": end,
        "future_bars_used": False,
        "research_only": True,
    }


def review_parallel_channels(bars, ledger):
    result=dict(method_version=METHOD,status="unavailable",timeframe=None,
        channels=[],selected_channel=None,candidate_count=0,trade_permission=False)
    if not bars:
        return result
    tf=bars[-1].timeframe
    if tf not in MINUTES:
        return result
    result["timeframe"]=tf
    duration=timedelta(minutes=MINUTES[tf])
    try:
        times=[_time(_utc(b.timestamp_utc)) for b in bars]
        if any(right<=left for left,right in zip(times,times[1:])):
            return result
        if any(b.timeframe!=tf or not all(isfinite(v) for v in (b.open,b.high,b.low,b.close))
               or not b.low<=min(b.open,b.close)<=max(b.open,b.close)<=b.high for b in bars):
            return result
        cutoff=times[-1]+duration
        result["through_utc"]=_utc(times[-1])
        index={stamp:i for i,stamp in enumerate(times)}
        points={}
        for leg in ledger.get("legs") or []:
            if leg.get("timeframe")!=tf:
                continue
            for point in (leg.get("origin"),leg.get("terminal")):
                if not isinstance(point,dict):
                    continue
                stamp,known=_time(point["pivot_timestamp_utc"]),_time(point["confirmed_at_utc"])
                i=index.get(stamp)
                field={"confirmed_swing_low_candidate":"low","confirmed_swing_high_candidate":"high"}.get(point["kind"])
                if i is None or not field or not stamp+duration<=known<=cutoff:
                    continue
                if not isinstance(point.get("price"),(int,float)) or isinstance(point["price"],bool) or getattr(bars[i],field)!=point["price"]:
                    return result
                item=dict(point,index=i)
                identity=(i,point["kind"])
                if identity in points and any(points[identity][key]!=item[key] for key in
                    ("kind","price","pivot_timestamp_utc","confirmed_at_utc")):
                    return result
                # An outside candle can be both a local high and a low. Keep
                # both facts without ordering them inside that candle; the
                # three selected anchors always use strictly distinct bars.
                points[identity]=item
        ordered=sorted(points.values(),key=lambda p:p["index"])
        candidates=[]
        for kind,up in (("confirmed_swing_low_candidate",True),("confirmed_swing_high_candidate",False)):
            side=[p for p in ordered if p["kind"]==kind]
            for pos,a in enumerate(side[:-1]):
                for c in side[pos+1:]:
                    ia,ic=a["index"],c["index"]
                    slope=(c["price"]-a["price"])/(ic-ia)
                    if (slope<=0 if up else slope>=0):
                        continue  # Horizontal ranges are a different object.
                    internal=[p for p in side if ia<p["index"]<ic]
                    if any((p["price"]>c["price"] if up else p["price"]<c["price"]) for p in internal):
                        continue  # Do not bridge a later reversal with a wide envelope.
                    opposite=[p for p in ordered if ia<p["index"]<ic and p["kind"]!=kind]
                    if not opposite:
                        continue
                    rail=lambda i:a["price"]+slope*(i-ia)
                    b=(max if up else min)(opposite,key=lambda p:p["price"]-rail(p["index"]))
                    offset=b["price"]-rail(b["index"])
                    if (offset<=0 if up else offset>=0):
                        continue
                    low=lambda i:rail(i)+min(0,offset)
                    high=lambda i:rail(i)+max(0,offset)
                    # Numerical roundoff only, not a market/ATR tolerance.
                    epsilon=max(abs(a["price"]),abs(b["price"]),abs(c["price"]),1)*1e-12
                    if any(min(bars[i].open,bars[i].close)<low(i)-epsilon
                           or max(bars[i].open,bars[i].close)>high(i)+epsilon for i in range(ia,ic+1)):
                        continue
                    known=max(_time(p["confirmed_at_utc"]) for p in (a,b,c))
                    exit_index=next((i for i in range(ic+1,len(bars))
                        if bars[i].close<low(i)-epsilon or bars[i].close>high(i)+epsilon),None)
                    if exit_index is not None and times[exit_index]+duration<=known:
                        continue  # Already outside before this channel was knowable.
                    end=exit_index if exit_index is not None else len(bars)-1
                    status="closed_outside" if exit_index is not None else "active_candidate"
                    direction="up" if up else "down"
                    exit_side=("upper" if bars[end].close>high(end) else "lower") if exit_index is not None else None
                    typical_range=median(max(0.0, float(row.high)-float(row.low))
                                         for row in bars[ia:end+1])
                    intelligence=_channel_intelligence(
                        bars, ordered, kind, ia, ic, end, low, high, offset,
                        typical_range)
                    candidates.append(dict(channel_id=f"{tf}:channel:{a['pivot_timestamp_utc']}:{c['pivot_timestamp_utc']}:{b['pivot_timestamp_utc']}",
                        timeframe=tf,direction=direction,status=status,known_at_utc=_utc(known),
                        trend_anchors=[a,c],parallel_anchor=b,slope_per_native_bar=slope,parallel_offset=offset,
                        from_utc=a["pivot_timestamp_utc"],through_utc=_utc(times[end]),
                        first_outside_close_utc=_utc(times[end]) if exit_index is not None else None,
                        first_outside_close_known_at_utc=_utc(times[end]+duration) if exit_index is not None else None,
                        outside_side=exit_side,formation_swing_count=len({p["index"] for p in ordered if ia<=p["index"]<=ic}),
                        formation_bar_count=ic-ia+1,display_bar_count=end-ia+1,
                        wick_excursion_count=sum(bars[i].low<low(i)-epsilon or bars[i].high>high(i)+epsilon
                            for i in range(ia,end+1)),
                        intelligence=intelligence,
                        smart_score=intelligence["score"],
                        smart_quality=intelligence["quality"],
                        smart_reason=intelligence["reason"],
                        lower_at_start=low(ia),upper_at_start=high(ia),lower_at_end=low(end),upper_at_end=high(end),
                        _from=ia,_end=end,trade_permission=False))
        active=[c for c in candidates if c["status"]=="active_candidate"]
        # Prefer a repeatedly witnessed channel over a single-spike envelope;
        # recency only breaks ties.  This is still a geometry selection, not
        # direction/entry authorization.
        def rank(c):
            return (c.get("smart_score", 0.0), c.get("known_at_utc", ""),
                    c.get("formation_swing_count", 0), -abs(c.get("parallel_offset", 0.0)))
        active_confirmed=[c for c in active if c.get("smart_quality")=="confirmed"]
        pool=active_confirmed or active
        selected=max(pool,key=rank) if pool else max(candidates,
            key=lambda c:(c.get("first_outside_close_utc") or "",*rank(c)),default=None)
        display=[selected] if selected else []
        if selected and active:
            older=[c for c in candidates if c["status"]=="closed_outside" and c["_end"]<selected["_from"]]
            if older:
                display.insert(0,max(older,key=lambda c:(c["first_outside_close_utc"],*rank(c))))
        for item in display:
            ia,end=item.pop("_from"),item.pop("_end")
            base=item["lower_at_start"]
            item["rail_samples"]=[dict(timestamp_utc=_utc(times[i]),
                low=base+item["slope_per_native_bar"]*(i-ia),
                high=base+item["slope_per_native_bar"]*(i-ia)+abs(item["parallel_offset"])) for i in range(ia,end+1)]
            item["readout"]=(f"{tf} {'上升' if item['direction']=='up' else '下降'}通道："
                +("已收出上沿，旧通道线止于首次越界收盘。" if item["outside_side"]=="upper" else
                  "已收出下沿，旧通道线止于首次越界收盘。" if item["outside_side"]=="lower" else
                  "当前收盘仍在两条平行边界内。"))
            item["readout"] += (f" 质量={item.get('smart_quality')} 等级={item.get('intelligence', {}).get('grade', 'unknown')}"
                                 f" 分={item.get('smart_score')}（{item.get('intelligence', {}).get('calibration_status', 'unknown')}，不是胜率）。")
        result.update(status="native_channel_review",channels=display,selected_channel=selected,
                      candidate_count=len(candidates),active_candidate_count=len(active))
    except (KeyError,TypeError,ValueError,OverflowError):
        pass
    return result
