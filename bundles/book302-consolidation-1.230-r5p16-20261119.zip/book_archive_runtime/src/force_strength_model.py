"""Prefix-only force strength and past-sample band preference.

Strength describes the observed leg; future retracement is a separate target.
Weights are transparent engineering choices. Quantile cutoffs describe relative
strength in the training population, never an author-labelled ground truth.
"""
from bisect import bisect_right
from datetime import datetime, timezone
from functools import lru_cache
from hashlib import sha256
import json
from math import sqrt, isfinite
from pathlib import Path
from statistics import median

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT/'04_wells4_support/W4-20261020-FORCE-CALIBRATION/model.json'
VERSION = 'force_strength_prefix_v1'
FEATURE_RULE_SHA256 = sha256(Path(__file__).read_bytes()).hexdigest()
BANDS = {'50_61.8': (.5, .618), '77_88': (.77, .88), '127.2': (1.272, 1.272)}
LABELS = {'strong': '强', 'medium': '中', 'weak': '弱', 'unknown': '未知'}


def epoch(value):
    if isinstance(value, (int, float)):
        return float(value)
    t = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if t.utcoffset() is None:
        raise ValueError('explicit timezone required')
    return t.timestamp()


def iso(t):
    return datetime.fromtimestamp(t, timezone.utc).isoformat().replace('+00:00', 'Z')


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and isfinite(value)


def features(rows, force, seconds, *, observed_bars_only=False,require_origin_envelope=False):
    """All leg features stop at B's candle; normalisation stops before A.

    rows are [open_epoch, O, H, L, C, ...]. The confirmation clock is supplied
    by the native detector, not inferred from the retrospectively final B.
    """
    a, b = force['points']
    available = epoch(force['known_at_utc'])
    if b[0] + seconds > available or a[0] >= b[0] or a[1] == b[1]:
        return {'status': 'endpoint_or_close_not_yet_known'}
    closed = [r for r in rows if float(r[0])+seconds <= available]
    part = [r for r in closed if a[0] <= float(r[0]) <= b[0]]
    if len(part)<2 or float(part[0][0]) != a[0] or float(part[-1][0]) != b[0]:
        return {'status': 'incomplete_source_window'}
    gaps=[dict(before=iso(float(x[0])),after=iso(float(y[0]))) for x,y in zip(part,part[1:]) if float(y[0])-float(x[0])!=seconds]
    if gaps and not observed_bars_only:
        return {'status':'unverified_source_continuity'}
    if not (float(part[0][3])-1e-7<=a[1]<=float(part[0][2])+1e-7
            and float(part[-1][3])-1e-7<=b[1]<=float(part[-1][2])+1e-7):
        return {'status':'endpoint_price_outside_native_bar'}
    # A lower high after a completed upward excursion (or a higher low
    # after a downward excursion) cannot be scored as the terminal of that
    # whole impulse. Preserve the supplied ruler for review; never silently
    # move its endpoint using a later, retrospective pivot.
    interior=part[1:-1]
    crossed=[r for r in interior if
             (float(r[2])>b[1]+1e-7 if b[1]>a[1] else float(r[3])<b[1]-1e-7)]
    if crossed:
        extreme=max(crossed,key=lambda r:float(r[2])) if b[1]>a[1] else min(crossed,key=lambda r:float(r[3]))
        return dict(status='source_terminal_preceded_by_further_extreme',
                    earlier_extreme_utc=iso(float(extreme[0])),
                    earlier_extreme_price=float(extreme[2] if b[1]>a[1] else extreme[3]),
                    endpoint_action='retain_ruler_pending_source_leg_review')
    if require_origin_envelope:
        # A deeper low inside an upward A-B (or a higher high inside a
        # downward A-B) starts a different native excursion. Its recovery
        # cannot be credited as delivery from the earlier, overtaken A.
        # Preserve the submitted ruler; source ownership must resolve it.
        adverse=[r for r in interior if
            (float(r[3])<a[1]-1e-7 if b[1]>a[1] else float(r[2])>a[1]+1e-7)]
        if adverse:
            extreme=min(adverse,key=lambda r:float(r[3])) if b[1]>a[1] else max(adverse,key=lambda r:float(r[2]))
            return dict(status='source_origin_overtaken_by_adverse_extreme',
                adverse_extreme_utc=iso(float(extreme[0])),
                adverse_extreme_price=float(extreme[3] if b[1]>a[1] else extreme[2]),
                endpoint_action='retain_ruler_pending_source_leg_review')
    prior = [r for r in closed if float(r[0]) < a[0]][-21:]
    if len(prior)<15:
        return {'status': 'insufficient_pre_source_normalisation'}
    tr=[max(float(y[2]-y[3]),abs(float(y[2]-x[4])),abs(float(y[3]-x[4])))
        for x,y in zip(prior,prior[1:])][-14:]
    atr=sum(tr)/len(tr)
    if atr<=0:
        return {'status': 'zero_pre_source_range'}
    sign=1 if b[1]>a[1] else -1
    height=abs(b[1]-a[1]); ranges=[float(r[2]-r[3]) for r in part]
    travel=sum(abs(float(y[4]-x[4])) for x,y in zip(part,part[1:]))
    overlaps=[max(0,min(float(x[2]),float(y[2]))-max(float(x[3]),float(y[3]))) /
              max(1e-12,min(float(x[2]-x[3]),float(y[2]-y[3]))) for x,y in zip(part,part[1:])]
    return dict(status='observed', net_points=height, bars=len(part),
        **(dict(observed_bars_only=True,gaps=gaps,continuity_verified=not gaps) if observed_bars_only else {}),
        height_atr=height/atr, speed_atr=height/max(1,len(part)-1)/atr,
        efficiency=abs(float(part[-1][4]-part[0][4]))/travel if travel else 0,
        directional_close=sum(sign*float(y[4]-x[4])>0 for x,y in zip(part,part[1:]))/(len(part)-1),
        body=sum(max(0,sign*float(r[4]-r[1])) for r in part)/sum(ranges) if sum(ranges) else 0,
        close_location=sum((float(r[4]-r[3]) if sign>0 else float(r[2]-r[4]))/max(1e-12,v)
                           for r,v in zip(part,ranges))/len(part),
        overlap=sum(overlaps)/len(overlaps), normalisation_atr=atr,
        normalisation_through_utc=iso(float(prior[-1][0])+seconds),
        known_at_utc=force['known_at_utc'], terminal_close_utc=iso(b[0]+seconds),
        quote_basis='OHLC_only_tick_and_DOM_unavailable')


def score_components(f):
    specs=(('height_atr','幅度/前期ATR',.15,lambda x:x/4),
           ('speed_atr','每根推进/前期ATR',.15,lambda x:x),
           ('efficiency','路径效率',.20,lambda x:x),
           ('directional_close','同向收盘',.10,lambda x:x),
           ('body','同向实体贡献',.15,lambda x:x),
           ('close_location','收盘靠近推进端',.10,lambda x:x),
           ('overlap','低重叠',.15,lambda x:1-x))
    components=[dict(key=k,name=n,weight=w,value=f[k],normalised=max(0,min(1,fn(f[k]))))
                for k,n,w,fn in specs if finite(f.get(k))]
    return components


def score(f):
    components=score_components(f)
    if len(components)!=7:
        return None,components
    return round(100*sum(c['weight']*c['normalised'] for c in components),2),components


def grade(value, low=45, high=70):
    return 'unknown' if value is None else 'weak' if value<low else 'strong' if value>=high else 'medium'


def measurement_receipt(rows, force, seconds, *, provider, symbol, timeframe, domain, model_id=None,
                        origin_envelope_required=False):
    """Identity of the measured candles, independent of later use/line choice.

    Range identity alone misses corrected interior OHLC and normalisation.
    Hash exactly the source and pre-A inputs consumed by features; a later
    adjustment or viewport extension cannot mutate this frozen measurement.
    """
    a,b=force['points'];known=epoch(force['known_at_utc'])
    closed=[r for r in rows if float(r[0])+seconds<=known]
    prior=[r[:5] for r in closed if float(r[0])<a[0]][-21:]
    source=[r[:5] for r in closed if a[0]<=float(r[0])<=b[0]]
    def hashed(value):
        return sha256(json.dumps(value,sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest()
    # Canonical numeric representation survives JSON float/int round trips.
    prior=[[float(v) for v in r] for r in prior];source=[[float(v) for v in r] for r in source]
    identity=dict(provider=provider,symbol=symbol,timeframe=timeframe,domain=domain,
        points=[[float(v) for v in p] for p in (a,b)],seconds=seconds,
        normalisation_sha256=hashed(prior),source_sha256=hashed(source),
        feature_rule=VERSION,feature_rule_sha256=FEATURE_RULE_SHA256,model_id=model_id)
    if origin_envelope_required:
        identity['source_range_validation']='native_AB_origin_envelope_v1'
    return dict(identity,measurement_id='force_measurement:'+hashed(identity),
        measured_from_utc=iso(a[0]),measured_through_utc=iso(b[0]+seconds),
        normalisation_through_utc=iso(prior[-1][0]+seconds) if prior else None,
        known_at_utc=force['known_at_utc'],source_bars=len(source),normalisation_bars=len(prior),
        score_is_probability=False,automatic_trade_permission=False)


def wilson(successes, n):
    if not n:
        return [0,1]
    z=1.96;p=successes/n;den=1+z*z/n
    center=(p+z*z/(2*n))/den
    half=z*sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [round(max(0,center-half),4),round(min(1,center+half),4)]


@lru_cache(maxsize=2)
def _load_model(path, mtime):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def load_model():
    try:
        return _load_model(str(MODEL_PATH),MODEL_PATH.stat().st_mtime_ns)
    except (OSError,ValueError):
        return {}


def model_at(model, timeframe, when):
    versions=model.get('periods',{}).get(timeframe,[])
    eligible=[v for v in versions if epoch(v['trained_through_utc']) < epoch(when)]
    return max(eligible,key=lambda v:epoch(v['trained_through_utc']),default=None)


def evaluate_strength(rows, force, timeframe, seconds, *, model=None, provider='HistData',
                      domain='native_first_response_candidate', symbol='XAUUSD',require_origin_envelope=False):
    descriptive=domain=='native_completed_wave_description'
    origin_required=require_origin_envelope or descriptive or domain.startswith('book_')
    f=features(rows,force,seconds,observed_bars_only=descriptive,
        require_origin_envelope=origin_required);value,components=score(f)
    fitted=load_model() if model is None else model
    domain_ok=fitted.get('calibration_domain','native_first_response_candidate')==domain
    signature_ok=True
    if domain.startswith('book_first_response'):
        from .book_force_calibration_contract import detector_signature
        signature_ok=fitted.get('detector_signature')==detector_signature()
        source=force.get('evidence',{}).get('book_first_response',{})
        span=source.get('ruler_span_bars')
        scope=fitted.get('scope',{})
        signature_ok=signature_ok and isinstance(span,(int,float)) and 0<span<=scope.get('max_ruler_span_bars',0)
        signature_ok=signature_ok and f.get('bars',float('inf'))<=scope.get('max_source_bars',0)
    version=(model_at(fitted,timeframe,force['known_at_utc'])
             if fitted.get('provider')==provider and domain_ok and signature_ok else None)
    if descriptive:version=None
    cuts=version['thresholds'] if version else {'low':45,'high':70}
    quality=grade(value,**cuts)
    selection=(version.get('quality',{}).get(quality,{}) if version else {})
    return dict(version=VERSION,score=value,quality=quality,label=LABELS[quality],
        measurement_receipt=measurement_receipt(rows,force,seconds,provider=provider,symbol=symbol,
            timeframe=timeframe,domain=domain,model_id=version.get('model_id') if version else None,
            origin_envelope_required=origin_required),
        model_domain=domain,model_validation_status='matched' if version else 'no_eligible_matching_model',
        features=f,components=components,thresholds=cuts,
        threshold_basis='past_training_score_terciles' if version else 'engineering_initial_45_70',
        model_id=version.get('model_id') if version else None,
        trained_through_utc=version.get('trained_through_utc') if version else None,
        training_n=version.get('training_n',0) if version else 0,
        band_selection=dict(status=selection.get('status','insufficient_history'),
            preferred_band=selection.get('preferred_band'),ranked_bands=selection.get('ranked_bands',[]),
            statistics=selection.get('statistics',{}),sample_n=selection.get('n',0),
            semantics='historical_path_priority_pending_touch_reclaim_and_route_trigger',
            second_sweep_is_separate_setup=True),
        known_at_utc=force['known_at_utc'],as_of_utc=force['known_at_utc'],
        source_id=force.get('source_id') or force.get('evidence',{}).get('force_leg_id') or force.get('id'),
        owner_id=force.get('owner_id') or force.get('source_id') or force.get('id'),
        timeframe=timeframe,automatic_trade_permission=False)


def band_paths(future, force, seconds, horizon_end):
    """Observe path after known_at, with native-close entry and fixed horizon.

    Ordinary bands require same-bar directional reclaim without crossing A;
    127.2 requires sweep -> close back over A -> later same-direction close.
    Target is B after signal, failure is signal setup's extreme (resweep) or A
    (ordinary). Simultaneous target/failure is ambiguous; no OHLC ordering guess.
    This studies geometric responses, with no spread/fill/PnL assumption.
    """
    a,b=force['points'];sign=1 if b[1]>a[1] else -1;height=abs(b[1]-a[1])
    start=epoch(force['known_at_utc'])
    rows=[r for r in future if float(r[0])>=start and float(r[0])+seconds<=horizon_end]
    complete=bool(rows and float(rows[-1][0])+seconds>=horizon_end)
    out={}
    for name,(r1,r2) in BANDS.items():
        lo,hi=sorted(b[1]-sign*height*r for r in (r1,r2))
        touched=None;signal=None;stop=a[1];state='no_touch';swept=False
        for i,r in enumerate(rows):
            o,h,l,c=map(float,r[1:5]); adverse=l if sign>0 else h
            intersects=l<=hi and h>=lo
            if touched is None and intersects:
                touched=i;state='no_reclaim'
            if name!='127.2' and sign*(adverse-a[1])<=0:
                state='source_crossed';break
            if touched is not None:
                if name=='127.2':
                    swept=True
                    stop=min(stop,l) if sign>0 else max(stop,h)
                    reclaimed=sign*(c-a[1])>0 and sign*(c-o)>0
                    if reclaimed and i+1<len(rows):
                        nxt=rows[i+1]
                        if sign*float(nxt[4]-c)>0 and (float(nxt[3])>stop if sign>0 else float(nxt[2])<stop):
                            signal=i+1;break
                elif intersects and sign*(c-(hi if sign>0 else lo))>0 and sign*(c-o)>0:
                    signal=i;break
        if signal is not None:
            state='expired'
            # If already beyond B, B cannot be counted as a future target.
            if sign*(float(rows[signal][4])-b[1])>=0:
                state='target_already_passed'
            else:
                for r in rows[signal+1:]:
                    target=sign*((float(r[2]) if sign>0 else float(r[3]))-b[1])>=0
                    fail=sign*((float(r[3]) if sign>0 else float(r[2]))-stop)<=0
                    if target and fail:state='ambiguous';break
                    if fail:state='failed';break
                    if target:state='success';break
        if not complete and state not in ('success','failed','ambiguous','source_crossed','target_already_passed'):
            state='censored'
        out[name]=dict(state=state,touched=touched is not None,
            signal_at_utc=iso(float(rows[signal][0])+seconds) if signal is not None else None,
            low=lo,high=hi,setup_family='second_sweep' if swept else 'ordinary_retest' if name!='127.2' else 'second_sweep',
            complete_horizon=complete)
    return out
