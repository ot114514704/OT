"""Immutable, content-addressed scenes shared by display, review and replay."""
import gzip
import hashlib
import json
import sqlite3
import ast
import re
import os
from importlib.util import resolve_name
from pathlib import Path
from datetime import datetime, timezone
from functools import lru_cache

ROOT = Path(__file__).resolve().parents[1]
STORE = ROOT/'03_work_queue/machine1_unified_mt5/ledger'

@lru_cache(maxsize=512)
def _local_python_dependencies(text, package):
    """Cache parsing of exact source text, never file contents or revisions.

    Each traversal still reads every file and revision hashing still consumes
    its bytes. Same-size edits with preserved mtimes therefore invalidate both
    imports and engine identity. Syntax failures are not cached.
    """
    modules=[]
    for node in ast.walk(ast.parse(text)):
        found=[]
        if isinstance(node,ast.Import):found=[n.name for n in node.names]
        elif isinstance(node,ast.ImportFrom):
            base=resolve_name('.'*node.level+(node.module or ''),package) if node.level else (node.module or '')
            found=[base]+[base+'.'+alias.name for alias in node.names]
        modules.extend(module for module in found if module.startswith('src.'))
    return tuple(modules)

def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf8')

def engine_source_files(project_root=ROOT,*,_directory_inventory=True):
    """Transitive calculation dependencies; unrelated chat work is not an engine edit."""
    root=Path(project_root)
    pending=[root/'src'/name for name in (
        'mt5_unified_backend.py','mt5_history_tiles.py','mt5_scene_store.py','mt5_scene_adapter.js')]
    files=set()
    directory_files={}
    def source_file(path):
        if not _directory_inventory:return path.is_file()
        parent=path.parent
        if parent not in directory_files:
            try:
                with os.scandir(parent) as entries:
                    directory_files[parent]={os.path.normcase(entry.name) for entry in entries if entry.is_file()}
            except (FileNotFoundError,NotADirectoryError):directory_files[parent]=set()
        return os.path.normcase(path.name) in directory_files[parent]
    while pending:
        path=pending.pop()
        if path in files or not source_file(path):continue
        files.add(path)
        text=path.read_text(encoding='utf-8-sig')
        if path.suffix=='.py':
            package='.'.join(path.relative_to(root).with_suffix('').parts[:-1])
            for module in _local_python_dependencies(text,package):
                pending.append(root.joinpath(*module.split('.')).with_suffix('.py'))
        elif path.suffix=='.js':
            for name in re.findall(r'require\([\"\'](\.[^\"\']+)[\"\']\)',text):
                pending.append((path.parent/name).resolve())
    template=root/'src/live_dashboard_template.html'
    if template.exists():files.add(template)
    # Fitted data affect scores and band preferences just as source code does.
    # Including the file prevents old scene cache keys surviving recalibration.
    force_model=root/'04_wells4_support/W4-20261020-FORCE-CALIBRATION/model.json'
    if force_model.exists():files.add(force_model)
    book_force_model=root/'04_wells4_support/W4-20261020-BOOK-FORCE-CALIBRATION/model.json'
    if book_force_model.exists():files.add(book_force_model)
    # Stable original-prefix parent facts affect displayed historical context.
    # Proof scene hashes stay outside this registry to avoid self-reference.
    parent_prefixes=root/'04_wells4_support/force_formation_parent_registry.json'
    if parent_prefixes.exists():files.add(parent_prefixes)
    case_components=root/'04_wells4_support/force_case_component_registry.json'
    if case_components.exists():files.add(case_components)
    weekly_programs=root/'04_wells4_support/force_weekly_programs.json'
    if weekly_programs.exists():
        files.add(weekly_programs)
        for p in json.loads(weekly_programs.read_bytes()).get('programs',{}).values():
            for source in p.get('sources',[]):
                proof=(root/source['proof_path']).resolve()
                if proof.is_relative_to(root.resolve()) and proof.exists():files.add(proof)
    # The original ICT implementation is loaded dynamically from its package.
    ict=root/'03_work_queue/ICT_Gold_Panel_FULL_20261017/ICT_Gold_Panel_FULL_20261017/project'
    for package in ('scripts','ict_ai','brooks_ai','vendor'):
        files.update((ict/package).rglob('*.py'))
    return sorted(files)


def engine_revision(project_root=ROOT):
    root=Path(project_root)
    files=engine_source_files(root)
    digest = hashlib.sha256()
    for path in files:
        digest.update(str(path.relative_to(root)).encode());digest.update(path.read_bytes())
    return digest.hexdigest()

def archive_revision(cutoff,count):
    from .build_archive_window_snapshot import ARCHIVE
    catalog=(ARCHIVE/'catalog.json').read_bytes()
    dataset=next(d for d in json.loads(catalog)['datasets'] if d['id']=='HistData')
    end=datetime.fromisoformat(cutoff.replace('Z','+00:00')).timestamp()
    digest=hashlib.sha256(catalog)
    # Book's native-only context reaches further than a 512-bar strategy tile.
    from .book_wave_inventory import BOOK_CONTEXT_BARS
    count=max(count,BOOK_CONTEXT_BARS)
    # Catch edited archive inputs even when filenames/catalog were retained.
    for tf,p in sorted(dataset['periods'].items()):
        required=count*7+14 if tf=='D1' else count
        used=0
        for chunk in reversed(p['chunks']):
            if chunk['start']>=end:continue
            path=ARCHIVE/chunk['file'];st=path.stat()
            digest.update(f'{chunk["file"]}:{st.st_size}:{st.st_mtime_ns}'.encode())
            # Count only fully earlier chunks; a cutoff inside a yearly
            # chunk may need another year for its warmup.
            if chunk['end']<end:used+=chunk['rows']
            if used>=required:break
    return digest.hexdigest()


def scene_request_key(tf, cutoff, count, mode, *, revision=None, data_revision=None):
    """One cache identity for producers and disk-only historical readers."""
    if not cutoff:
        return None
    foundation = 'foundation_unavailable'
    try:
        from .foundation_review import DEFAULT_SHARD_MANIFEST
        foundation = json.loads(DEFAULT_SHARD_MANIFEST.read_text(encoding='utf-8')).get('manifest_sha256', foundation)
    except (OSError, ValueError, TypeError):
        pass
    revision = revision or engine_revision()
    data_revision = data_revision or archive_revision(cutoff, count)
    return f'{revision}|{foundation}|{data_revision}|HistData|{tf}|{cutoff}|{count}|{mode}'

def connect(directory=STORE):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(directory/'index.sqlite',timeout=30)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('CREATE TABLE IF NOT EXISTS scenes (id TEXT PRIMARY KEY, provider TEXT, timeframe TEXT, cutoff TEXT, revision TEXT, bars INTEGER, created TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS requests (key TEXT PRIMARY KEY, scene_id TEXT NOT NULL)')
    db.execute('CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, scene_id TEXT, object_id TEXT, note TEXT, created TEXT)')
    return db

def save(scene, request_key=None, directory=STORE):
    # Derived identity is outside the hashed payload to avoid self-reference.
    payload={k:v for k,v in scene.items() if k!='scene_id'}
    data=canonical(payload);sid=hashlib.sha256(data).hexdigest()
    directory=Path(directory)
    with connect(directory) as db:
        path=directory/(sid+'.json.gz')
        if not path.exists():
            from .mt5_unified_backend import atomic
            atomic(path,gzip.compress(data,mtime=0))
        db.execute('INSERT OR IGNORE INTO scenes VALUES (?,?,?,?,?,?,?)',
            (sid,scene['provider'],scene['timeframe'],scene['cutoff_utc'],scene.get('engine_revision',''),scene['coverage']['bars'],datetime.now(timezone.utc).isoformat()))
        if request_key:
            old=db.execute('SELECT scene_id FROM requests WHERE key=?',(request_key,)).fetchone()
            if old and old[0]!=sid: raise ValueError('same engine/input produced a different scene')
            db.execute('INSERT OR IGNORE INTO requests VALUES (?,?)',(request_key,sid))
    scene['scene_id']=sid
    return sid

def read(sid,directory=STORE):
    if len(sid)!=64 or any(c not in '0123456789abcdef' for c in sid): raise ValueError('invalid scene id')
    data=gzip.decompress((Path(directory)/(sid+'.json.gz')).read_bytes())
    if hashlib.sha256(data).hexdigest()!=sid: raise ValueError('scene integrity check failed')
    return dict(json.loads(data),scene_id=sid)

def cached(key,directory=STORE):
    with connect(directory) as db:
        row=db.execute('SELECT scene_id FROM requests WHERE key=?',(key,)).fetchone()
    return read(row[0],directory) if row else None

def listing(directory=STORE):
    with connect(directory) as db:
        db.row_factory=sqlite3.Row
        return [dict(r) for r in db.execute('SELECT * FROM scenes ORDER BY created DESC LIMIT 500')]

def note(sid,oid,text,directory=STORE):
    scene=read(sid,directory)
    if oid not in {o['id'] for o in scene['objects']}:raise ValueError('object is not part of this scene')
    if not text.strip() or len(text)>4000:raise ValueError('note must be 1 to 4000 characters')
    with connect(directory) as db:
        db.execute('INSERT INTO notes (scene_id,object_id,note,created) VALUES (?,?,?,?)',(sid,oid,text.strip(),datetime.now(timezone.utc).isoformat()))

def notes(sid,directory=STORE):
    with connect(directory) as db:
        db.row_factory=sqlite3.Row
        return [dict(r) for r in db.execute('SELECT * FROM notes WHERE scene_id=? ORDER BY id',(sid,))]
