"""Strict transport boundary between a 1:1 research review and a Book source.

The 1:1 second-leg work and the Chapter 6 Book response deliberately use
different identifiers.  A similar direction, timestamp, or score is not
proof that they describe the same native source.  This module therefore
accepts only an explicit, clock-bound source-binding receipt.  It exposes a
research context to the paper branch; it does not create an entry, fit a
threshold, or grant an execution permission.
"""
from math import isclose
from copy import deepcopy
from .one_to_one_quantitative_score import score_one_to_one_quantitatively
from .book_first_response_leg import clock
from .one_to_one_structure_score import canonical_point, epoch


CONTEXT_SCHEMA = "book_one_to_one_execution_context_v2"
BINDING_SCHEMA = "one_to_one_to_book_response_binding_v2"
REQUIREMENT_FIELD = "one_to_one_second_leg_requirement"
REQUIRED_STATE = "same_phase_research_ready"
DEVELOPING_STATE = "same_source_developing_reference"


def requirement(policy):
    """Return the explicit 1:1 policy mode, without silently opting in."""
    value = (policy or {}).get(REQUIREMENT_FIELD, "not_required")
    return value if value in ("not_required", REQUIRED_STATE, DEVELOPING_STATE) else None


def _pair(point):
    """Use the physical native timestamp/price, never an object id or label."""
    p = canonical_point(point)
    return [float(epoch(p["pivot_timestamp_utc"])), float(p["price"])]


def _same_pair(left, right):
    try:
        return (isclose(float(left[0]), float(right[0]), rel_tol=0, abs_tol=1e-6)
                and isclose(float(left[1]), float(right[1]), rel_tol=0, abs_tol=1e-8))
    except (IndexError, TypeError, ValueError):
        return False


def derive_one_to_one_book_context(scene, downstream_review=None):
    """Derive at most one Book context from the same original impulsive leg.

    This is the only automatic bridge.  It refuses all semantic shortcuts:
    1:1 source A/B must equal Book response B/C at native time and price.
    The 1:1 C is the subsequent return, NOT the Book response terminal. A
    Book response can have many unrelated 1:1 readings; those remain in the
    audit, rather than being ranked.  The returned factor remains research
    only and may be supplied to ``BookPaperEngine`` only by a caller that
    intentionally enables the dedicated policy requirement.
    """
    book = scene.get("book_logic") or {}
    scores = book.get("boundary_breakout_assessment") or {}
    response = book.get("first_response_leg") or {}
    cutoff = scene.get("cutoff_utc") or book.get("as_of_utc")
    base = dict(
        schema="one_to_one_to_book_context_collection_v1", as_of_utc=cutoff,
        phase_id=scores.get("phase_id"), book_source_id=response.get("source_id"),
        automatic_trade_permission=False, live_order_permission=False,
        order_api_called=False, execution_admission="blocked_research_only",
        bindings=[], withheld=[])
    if not cutoff or not response.get("source_complete") or response.get("status") == "source_invalidated":
        return dict(base, state="book_response_unavailable",
                    reason=response.get("reason") or "completed_same_source_BC_unavailable",
                    execution_context_factor=None)
    try:
        book_b, book_c = response["origin_B"]["point"], response["terminal_C"]["point"]
        _ = scores["source_identity"]
    except (KeyError, TypeError):
        return dict(base, state="book_response_identity_incomplete",
                    reason="Book_response_BC_or_source_identity_missing", execution_context_factor=None)

    review = downstream_review or ((scene.get("integrated_market_logic") or {})
                                   .get("one_to_one_downstream_review") or {})
    owner_bound = {row.get("object_id"): row for row in
                   list(review.get("candidates", []))+list(review.get("withheld", []))
                   if isinstance(row, dict) and (row.get("owner_task_context") or {}).get("context_bound")}
    objects = {obj.get("id"): obj for obj in scene.get("objects", []) if isinstance(obj, dict)}
    for reading in (scene.get("one_to_one_structure_scores") or {}).get("readings", []):
        oid = reading.get("object_id")
        embedding = reading.get("second_leg_current_structure_embedding") or {}
        obj = objects.get(oid) or {}; evidence = obj.get("evidence") or {}
        family, projection = evidence.get("record"), evidence.get("projection")
        item = dict(object_id=oid, source_leg_id=reading.get("source_leg_id"),
                    measurement_id=reading.get("measurement_id"), projection_id=reading.get("projection_id"))
        if reading.get("status") != "scored":
            base["withheld"].append(dict(item, reason="one_to_one_reading_not_scored")); continue
        if (embedding.get('lifecycle')!='developing_second_leg' or
                embedding.get('entry_gate')!='closed_research_only' or
                embedding.get('range_context_retired') is not False):
            base['withheld'].append(dict(item,reason='one_to_one_not_developing_research_reference'));continue
        if oid not in owner_bound:
            base["withheld"].append(dict(item, reason="one_to_one_owner_task_not_exactly_bound")); continue
        task=owner_bound[oid]['owner_task_context']
        if (task.get('as_of_utc')!=cutoff or task.get('task_id')!=oid or
                task.get('owner_id')!=reading.get('source_leg_id') or task.get('timeframe')!=reading.get('timeframe')):
            base['withheld'].append(dict(item,reason='one_to_one_owner_task_identity_or_clock_mismatch'));continue
        try:
            one_a, one_b = _pair(family['source_origin']), _pair(family['source_terminal'])
            return_c = _pair(projection['anchor'])
        except (KeyError, TypeError, ValueError):
            base["withheld"].append(dict(item, reason="one_to_one_native_BC_points_unavailable")); continue
        mismatches = []
        if not _same_pair(one_a, book_b): mismatches.append('one_to_one_A_not_Book_origin_B')
        if not _same_pair(one_b, book_c): mismatches.append('one_to_one_B_not_Book_terminal_C')
        sign=1 if scores.get('direction')=='up' else -1
        if reading.get('direction')!=sign or sign*(one_b[1]-one_a[1])<=0:
            mismatches.append('one_to_one_direction_differs_from_Book_response')
        if not one_a[0]<one_b[0]<return_c[0]:mismatches.append('return_C_not_after_source_AB')
        if projection.get('ordinal')!=2:mismatches.append('initial_entry_requires_second_leg_not_later_range_leg')
        if (family.get('source_leg_id')!=reading.get('source_leg_id') or
                family.get('measurement_id')!=reading.get('measurement_id') or
                projection.get('projection_id')!=reading.get('projection_id') or
                projection.get('measurement_source_leg_id')!=reading.get('source_leg_id')):
            mismatches.append('original_measurement_projection_identity_mismatch')
        if reading.get("timeframe") != response.get("timeframe") or reading.get("timeframe") != scene.get("timeframe"):
            mismatches.append("native_timeframe_mismatch")
        if family.get("provider", scene.get("provider")) != scores.get("provider"):
            mismatches.append("provider_mismatch")
        if family.get("symbol", scene.get("symbol") or scene.get("instrument")) != scores.get("symbol"):
            mismatches.append("symbol_mismatch")
        if mismatches:
            base["withheld"].append(dict(item, reason="one_to_one_AB_not_exact_Book_BC", mismatch_fields=mismatches,
                                         one_to_one_A=one_a, one_to_one_B=one_b,one_to_one_return_C=return_c,
                                         book_origin_B=book_b, book_terminal_C=book_c)); continue
        try:
            known=max((reading['known_at_utc'],response['known_at_utc'],
                projection['known_at_utc'],projection['anchor']['confirmed_at_utc']),key=clock)
            if reading.get('as_of_utc')!=cutoff or clock(known)>clock(cutoff):
                raise ValueError('reading_clock')
            if reading.get('automatic_trade_permission') is not False or reading.get('order_api_called') is not False:
                raise ValueError('reading_permissions')
        except (KeyError,TypeError,ValueError):
            base['withheld'].append(dict(item,reason='one_to_one_reading_clock_or_permission_unbound'));continue
        state=REQUIRED_STATE if embedding.get('research_ready_for_downstream_review') is True else DEVELOPING_STATE
        binding = dict(schema=BINDING_SCHEMA, state="same_native_source_confirmed",
            phase_id=scores.get("phase_id"), book_source_id=response.get("source_id"),
            source_identity=scores.get("source_identity"), known_at_utc=known,
            native_AB_map=dict(one_to_one_A=one_a, one_to_one_B=one_b,one_to_one_return_C=return_c,
                               book_origin_B=book_b, book_terminal_C=book_c))
        fact = dict(schema=CONTEXT_SCHEMA, state=state, phase_id=scores.get("phase_id"),
            book_source_id=response.get("source_id"), source_identity=scores.get("source_identity"),
            working_timeframe=reading.get("timeframe"), provider=scores.get("provider"), symbol=scores.get("symbol"),
            as_of_utc=cutoff, known_at_utc=known, one_to_one_object_id=oid,
            one_to_one_source_leg_id=reading.get("source_leg_id"), measurement_id=reading.get("measurement_id"),
            projection_id=reading.get("projection_id"),
            direction=scores.get('direction'),second_leg_lifecycle='developing_second_leg',
            research_ready_for_downstream_review=embedding.get('research_ready_for_downstream_review') is True,
            owner_task_bound=True, execution_admission="blocked_research_only",
            automatic_trade_permission=False, order_api_called=False,
            joint_score=embedding.get("joint_score"), joint_score_is_probability=False,
            delivery_score=embedding.get('delivery_score'),frozen_structure_score=embedding.get('structure_score'),
            current_structure_score=embedding.get('current_structure_score'),
            current_sequence_alignment=embedding.get('current_sequence_alignment'),
            quantitative_score=embedding.get('quantitative_score'),
            quantitative_score_state=embedding.get('quantitative_score_state'),
            quantitative_score_receipt=deepcopy(embedding.get('quantitative_score_receipt')),
            score_roles=deepcopy(embedding.get('score_roles')),
            target_progress=deepcopy(embedding.get('target_progress')),
            return_depth=deepcopy(embedding.get('return_depth')),
            score_interpretation=embedding.get('score_interpretation'),
            context_known_at_utc=cutoff,
            binding_receipt=binding)
        base["bindings"].append(dict(item, execution_context_factor=fact))
    if len(base["bindings"]) != 1:
        return dict(base, state="multiple_exact_bindings_withheld" if base["bindings"] else "no_exact_owner_bound_BC_binding",
                    reason="exact_one_to_one_BC_binding_required_without_ranking", execution_context_factor=None)
    return dict(base, state=base['bindings'][0]['execution_context_factor']['state'],
                reason="one_exact_owner_bound_native_BC_binding", execution_context_factor=base["bindings"][0]["execution_context_factor"])


def evaluate_one_to_one_context(contexts, policy, scores, response, timeframe, cutoff):
    """Validate one externally supplied source binding at one closed prefix.

    ``one_to_one_downstream_review`` remains an owner-level research record.
    It cannot be used here by itself: a caller must also retain a concrete
    proof that names the exact Book phase, completed B/C response and native
    ruler.  Every useful outcome preserves the research-only permission.
    """
    selected = requirement(policy)
    base = dict(
        schema="book_one_to_one_context_receipt_v1",
        requirement=selected if selected is not None else "invalid",
        phase_id=scores.get("phase_id"),
        book_source_id=response.get("source_id"),
        working_timeframe=timeframe,
        as_of_utc=cutoff,
        execution_admission="blocked_research_only",
        automatic_trade_permission=False,
        live_order_permission=False,
        order_api_called=False,
    )
    if selected is None:
        return dict(base, state="policy_invalid", reason="invalid_one_to_one_second_leg_requirement")
    if selected == "not_required":
        return dict(base, state="not_requested", reason="policy_does_not_require_one_to_one_review")

    fact = (contexts or {}).get("one_to_one_second_leg")
    if not isinstance(fact, dict):
        return dict(base, state="withheld", reason="explicit_one_to_one_source_binding_required",
                    mismatch_fields=["one_to_one_second_leg"])

    binding = fact.get("binding_receipt")
    mismatches = []
    expected_identity = scores.get("source_identity")
    checks = (
        ("schema", fact.get("schema") == CONTEXT_SCHEMA),
        ("state", fact.get("state") == selected),
        ("phase_id", fact.get("phase_id") == scores.get("phase_id")),
        ("book_source_id", fact.get("book_source_id") == response.get("source_id")),
        ("source_identity", fact.get("source_identity") == expected_identity),
        ("working_timeframe", fact.get("working_timeframe") == timeframe),
        ("provider", fact.get("provider") == scores.get("provider")),
        ("symbol", fact.get("symbol") == scores.get("symbol")),
        ("as_of_utc", fact.get("as_of_utc") == cutoff),
        ('direction',fact.get('direction')==scores.get('direction')),
        ('second_leg_lifecycle',fact.get('second_leg_lifecycle')=='developing_second_leg'),
        ("owner_task_bound", fact.get("owner_task_bound") is True),
        ("execution_admission", fact.get("execution_admission") == "blocked_research_only"),
        ("automatic_trade_permission", fact.get("automatic_trade_permission") is False),
        ("order_api_called", fact.get("order_api_called") is False),
        ("joint_score_is_probability", fact.get("joint_score_is_probability") is False),
    )
    for field, matched in checks:
        if not matched:
            mismatches.append(field)
    if selected==REQUIRED_STATE and fact.get('research_ready_for_downstream_review') is not True:
        mismatches.append('research_ready_for_downstream_review')
    for field in ("one_to_one_object_id", "one_to_one_source_leg_id", "measurement_id", "projection_id"):
        if not isinstance(fact.get(field), str) or not fact[field]:
            mismatches.append(field)
    try:
        if clock(fact["known_at_utc"]) > clock(cutoff):
            mismatches.append("known_at_utc")
    except (KeyError, TypeError, ValueError):
        mismatches.append("known_at_utc")

    if not isinstance(binding, dict):
        mismatches.append("binding_receipt")
    else:
        binding_checks = (
            ("binding_receipt.schema", binding.get("schema") == BINDING_SCHEMA),
            ("binding_receipt.state", binding.get("state") == "same_native_source_confirmed"),
            ("binding_receipt.phase_id", binding.get("phase_id") == scores.get("phase_id")),
            ("binding_receipt.book_source_id", binding.get("book_source_id") == response.get("source_id")),
            ("binding_receipt.source_identity", binding.get("source_identity") == expected_identity),
        )
        for field, matched in binding_checks:
            if not matched:
                mismatches.append(field)
        try:
            if clock(binding["known_at_utc"]) > clock(cutoff):
                mismatches.append("binding_receipt.known_at_utc")
        except (KeyError, TypeError, ValueError):
            mismatches.append("binding_receipt.known_at_utc")
        native_map = binding.get("native_AB_map")
        if not isinstance(native_map, dict):
            mismatches.append("binding_receipt.native_AB_map")
        else:
            checks = (("binding_receipt.book_origin_B", _same_pair(native_map.get("book_origin_B"), response.get("origin_B", {}).get("point"))),
                      ("binding_receipt.book_terminal_C", _same_pair(native_map.get("book_terminal_C"), response.get("terminal_C", {}).get("point"))),
                      ("binding_receipt.same_native_A", _same_pair(native_map.get("one_to_one_A"), native_map.get("book_origin_B"))),
                      ("binding_receipt.same_native_B", _same_pair(native_map.get("one_to_one_B"), native_map.get("book_terminal_C"))))
            for field, matched in checks:
                if not matched:
                    mismatches.append(field)
            try:
                a,b,c=[native_map[k] for k in ('one_to_one_A','one_to_one_B','one_to_one_return_C')]
                sign=1 if scores.get('direction')=='up' else -1
                if not a[0]<b[0]<c[0]<=clock(cutoff).timestamp() or sign*(b[1]-a[1])<=0:
                    mismatches.append('binding_receipt.native_role_order_or_direction')
            except (KeyError,TypeError,ValueError,IndexError):
                mismatches.append('binding_receipt.return_C_missing')

    quantitative=fact.get('quantitative_score_receipt')
    if quantitative is None and (fact.get('quantitative_score') is not None or fact.get('quantitative_score_state') is not None):
        mismatches.append('quantitative_score_receipt')
    if quantitative is not None:
        expected=score_one_to_one_quantitatively(
            delivery_score=fact.get('delivery_score'),frozen_structure_score=fact.get('frozen_structure_score'),
            current_structure_score=fact.get('current_structure_score'),
            ratio_observation=(quantitative.get('input_profile') if isinstance(quantitative,dict) else None),
            current_sequence_alignment=fact.get('current_sequence_alignment'),
            native_source_verified=True,source_clock_verified=True,lifecycle='developing_second_leg')
        if (not isinstance(quantitative,dict) or quantitative!=expected or
                fact.get('quantitative_score')!=expected['score'] or fact.get('quantitative_score_state')!=expected['status']):
            mismatches.append('quantitative_score_receipt')
    # Newer producers may include the role ledger.  If present, bind its
    # numeric values to the already validated source fields so a stale panel
    # cannot relabel a local delivery score as structure acceptance (or as a
    # probability).  Older receipts without the optional ledger remain valid.
    roles=fact.get('score_roles')
    if roles is not None:
        if not isinstance(roles,dict) or fact.get('score_interpretation') != 'role_measurements_only; no_target_success_probability_or_order_vote':
            mismatches.append('score_roles_schema')
        else:
            expected_roles={
                'local_delivery':fact.get('delivery_score'),
                'frozen_structure_acceptance':fact.get('frozen_structure_score'),
                'current_structure_alignment':fact.get('current_structure_score'),
            }
            for name,value in expected_roles.items():
                row=roles.get(name)
                if not isinstance(row,dict) or row.get('score') != value or row.get('score_is_probability') is not False:
                    mismatches.append('score_roles.'+name)
            target=roles.get('target_success_probability')
            if not isinstance(target,dict) or target.get('score') is not None or target.get('score_is_probability') is not True:
                mismatches.append('score_roles.target_success_probability')
    if mismatches:
        return dict(base, state="withheld", reason="one_to_one_binding_identity_or_clock_mismatch",
                    mismatch_fields=mismatches)
    return dict(base, state=selected, reason="explicit_same_native_source_research_context_bound",
                one_to_one_object_id=fact["one_to_one_object_id"],
                one_to_one_source_leg_id=fact["one_to_one_source_leg_id"],
                measurement_id=fact["measurement_id"], projection_id=fact["projection_id"],
                joint_score=fact.get("joint_score"), joint_score_is_probability=False,
                known_at_utc=max((fact['known_at_utc'],binding['known_at_utc']),key=clock),
                context_known_at_utc=fact.get('context_known_at_utc',fact.get('known_at_utc')),
                runtime_observation_witness=fact.get('runtime_observation_witness'),
                delivery_score=fact.get('delivery_score'),frozen_structure_score=fact.get('frozen_structure_score'),
                current_structure_score=fact.get('current_structure_score'),
                quantitative_score=fact.get('quantitative_score'),
                quantitative_score_state=fact.get('quantitative_score_state'),
                quantitative_score_receipt=deepcopy(quantitative),
                score_roles=deepcopy(fact.get('score_roles')),
                target_progress=deepcopy(fact.get('target_progress')),
                return_depth=deepcopy(fact.get('return_depth')),
                score_interpretation=fact.get('score_interpretation'),
                binding_receipt=dict(binding))
