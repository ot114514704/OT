"""Join a frozen 1:1 second-leg observation to the current native structure.

This module deliberately does not choose an entry threshold.  It translates
the two already causal observations into one bounded, inspectable receipt:
delivery is the fixed C-to-target observation, while the current structure is
the native state visible at the query cutoff.  Unknown clocks and missing
reference nodes remain unknown; they are never converted to a weak score.
"""

from __future__ import annotations
from math import isfinite
from .one_to_one_quantitative_score import score_one_to_one_quantitatively



_STATE_SCORE = {
    "untested": 0,
    "wick_touch_only": 0,
    "reclaimed_after_cross": 0,
    "closed_through": 50,
    "accepted_with_follow": 100,
}


def _finite_number(value):
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and isfinite(value))


def _boundary_score(nodes):
    values = []
    for node in (nodes or {}).values():
        state = node.get("state") if isinstance(node, dict) else None
        if state not in _STATE_SCORE:
            return None
        values.append(_STATE_SCORE[state])
    return min(values) if values else None


def classify_current_structure(*, current_structure, direction, range_retired=False):
    """Return the current native state without consulting later outcomes."""
    current = current_structure if isinstance(current_structure, dict) else {}
    stage = current.get("stage") or {}
    continuity = current.get("continuity")
    if continuity != "verified_research_calendar":
        return dict(state="current_structure_unknown", score=None,
                    sequence_alignment="unknown_history_gap", reason=continuity or "missing_current_structure")
    if stage.get("state") == "unknown":
        return dict(state="current_structure_unknown", score=None,
                    sequence_alignment="unknown_stage", reason=stage.get("reason", "unknown_stage"))
    expected = "up" if direction > 0 else "down"
    if stage.get("state") == "trend":
        alignment = "aligned_native_sequence" if stage.get("direction") == expected else "counter_native_sequence"
    else:
        alignment = "range_or_transition_sequence"
    score = _boundary_score(current.get("nodes"))
    if score is None:
        state = "current_reference_context_unknown"
    elif range_retired:
        state = "named_range_already_retired"
    elif alignment == "counter_native_sequence":
        state = "current_structure_counter_sequence"
    elif score >= 100:
        state = "current_structure_aligned_and_accepted" if alignment == "aligned_native_sequence" else "current_structure_accepted_in_range"
    elif score >= 50:
        state = "current_structure_boundary_pending"
    else:
        state = "current_structure_boundary_not_accepted"
    return dict(state=state, score=score, sequence_alignment=alignment,
                stage_state=stage.get("state"), stage_direction=stage.get("direction"))


def embed_second_leg_current_structure(*, delivery, structure_score,
                                       embedded_score, current_structure,
                                       direction, range_retired=False,
                                       forecast_eligible=False,
                                       three_push_context=None,
                                       native_source_verified=False,
                                       source_clock_verified=False):
    """Create a research-only receipt for the two-score combination.

    ``embedded_score`` is the weakest-link engineering value already computed
    by the owner evaluator.  It is copied, never recalculated from a later
    target outcome.  ``entry_gate`` stays closed because this project has no
    live order permission in this path.
    """
    delivery = delivery if isinstance(delivery, dict) else {}
    current = classify_current_structure(current_structure=current_structure,
                                         direction=direction,
                                         range_retired=range_retired)
    delivery_score = delivery.get("score")
    delivery_state = delivery.get("status", "unknown")
    ratio_observation = None
    if isinstance(three_push_context, dict):
        profile = three_push_context.get("profile")
        if isinstance(profile, dict):
            ratio_observation = profile.get("wave_ratio_observation")
        if ratio_observation is None:
            ratio_observation = three_push_context.get("wave_ratio_observation")
    if delivery_state in {"terminal_observation", "target_touched", "anchor_failed"}:
        lifecycle = "frozen_terminal_observation"
    elif delivery_state == "developing_observation":
        lifecycle = "developing_second_leg"
    else:
        lifecycle = "second_leg_observation_unknown"
    # There are three separate pieces of evidence.  ``embedded_score`` is
    # the already frozen first two-way minimum (delivery x structure).  The
    # current reading must still be included before a consumer can describe
    # the entire 1:1 context as strong.  Do not substitute a zero for a
    # missing clock/node: zero means an observed rejection, while None means
    # the context is not known.
    joint_components = {
        "delivery": delivery_score,
        "frozen_structure": structure_score,
        "current_structure": current.get("score"),
    }
    joint_unknowns = [name for name, value in joint_components.items() if value is None]
    joint_score = (min(joint_components.values()) if not joint_unknowns else None)

    if lifecycle == "second_leg_observation_unknown" or current["state"] == "current_structure_unknown":
        disposition = "observe_unknown"
    elif range_retired:
        disposition = "range_context_retired"
    elif current["state"] == "current_structure_counter_sequence":
        disposition = "counter_sequence_hold"
    elif current["score"] is None:
        disposition = "structure_context_unknown"
    elif structure_score is None:
        disposition = "frozen_structure_context_unknown"
    elif min(structure_score, current["score"]) < 100:
        disposition = "boundary_acceptance_pending"
    else:
        disposition = "delivery_and_current_structure_observed"
    sequence = current.get("sequence_alignment")
    complete_aligned = (not joint_unknowns and sequence == "aligned_native_sequence")
    structural_context_accepted = (
        complete_aligned and structure_score == 100 and current.get("score") == 100
    )
    delivery_positive = delivery_score is not None and delivery_score > 0
    ratio_scores = (ratio_observation or {}).get("scores", {}) if isinstance(ratio_observation, dict) else {}
    ratio_score = (max(ratio_scores.values()) if ratio_scores and
                   all(isinstance(v, (int, float)) for v in ratio_scores.values()) else None)
    contextual_components = dict(joint_components, three_push_ratio=ratio_score)
    contextual_unknowns = [name for name, value in contextual_components.items() if value is None]
    contextual_joint_score = (min(contextual_components.values())
                              if not contextual_unknowns else None)
    quantitative = score_one_to_one_quantitatively(
        delivery_score=delivery_score, frozen_structure_score=structure_score,
        current_structure_score=current.get("score"), ratio_observation=ratio_observation,
        current_sequence_alignment=sequence, target_already_reached=range_retired,
        native_source_verified=native_source_verified,
        source_clock_verified=source_clock_verified,lifecycle=lifecycle)
    # Keep the evidence roles explicit at the point where the three clocks
    # meet.  A bounded score is a measurement of one role; it is not a
    # calibrated chance of reaching the target.  In particular, progress on
    # C->target and local delivery can be useful while the larger structure is
    # still pending, whereas current structure acceptance answers a different
    # question.  Copy only the causal delivery features observed at this
    # cutoff; never derive them from a later outcome.
    delivery_features = delivery.get('features') if isinstance(delivery.get('features'), dict) else {}
    signed_progress = delivery_features.get('signed_target_progress')
    retracement_depth = delivery_features.get('retracement_depth')
    score_roles = dict(
        local_delivery=dict(score=delivery_score,
            scope='C_to_original_AB_target_path_and_progress',
            answers='how_the_current_second_leg_is_delivering',
            score_is_probability=False),
        frozen_structure_acceptance=dict(score=structure_score,
            scope='frozen_original_breakout_boundary',
            answers='whether_the_original_boundary_was_accepted',
            score_is_probability=False),
        current_structure_alignment=dict(score=current.get('score'),
            scope='current_native_structure_at_same_cutoff',
            answers='whether_current_structure_still_supports_the_source_direction',
            score_is_probability=False),
        three_push_ratio=dict(
            score=ratio_score,
            scope='observed_three_push_shape_diagnostic',
            answers='whether_observed_push_lengths_resemble_a_candidate_profile',
            score_is_probability=False),
        target_success_probability=dict(score=None,
            scope='future_target_success',
            answers='requires_out_of_time_calibration_not_present',
            score_is_probability=True),
    )
    progress_role = dict(value=signed_progress,
        state='observed' if _finite_number(signed_progress) else 'unknown',
        scope='signed_C_to_original_AB_target_progress',
        score_is_probability=False)
    depth_role = dict(value=retracement_depth,
        state='observed' if _finite_number(retracement_depth) else 'unknown',
        scope='return_depth_relative_to_original_AB',
        score_is_probability=False)
    # This flag deliberately has no fitted numerical cutoff.  Both the
    # frozen and current boundaries must be observed accepted, the native
    # sequence must agree, and the developing delivery must at least move in
    # its stated direction.  The continuous joint score remains available to
    # a later calibrated consumer.  This is still not an order signal:
    # source admission, entry, risk, and authorization are separate.
    research_ready = bool(
        forecast_eligible and lifecycle == "developing_second_leg" and
        structural_context_accepted and delivery_positive and
        not range_retired
    )
    return dict(
        schema="owned_one_to_one_second_leg_current_structure_embedding_v1",
        delivery_score=delivery_score, structure_score=structure_score,
        current_structure_score=current.get("score"),
        effective_structure_score=(min(structure_score, current["score"])
                                   if structure_score is not None and current.get("score") is not None else None),
        embedded_score=embedded_score, embedded_score_is_probability=False,
        joint_score=joint_score, joint_score_formula=(
            "minimum(delivery_score,frozen_structure_score,current_structure_score); missing stays unknown"),
        joint_score_is_probability=False, joint_components=joint_components,
        joint_score_complete=not joint_unknowns, joint_unknown_components=joint_unknowns,
        three_push_ratio_observation=ratio_observation,
        contextual_joint_score=contextual_joint_score,
        contextual_joint_score_formula=(
            "minimum(delivery_score,frozen_structure_score,current_structure_score,max_three_push_ratio_score); missing stays unknown"),
        contextual_joint_score_complete=not contextual_unknowns,
        contextual_joint_score_unknown_components=contextual_unknowns,
        contextual_joint_score_is_probability=False,
        quantitative_score=quantitative.get('score'),
        quantitative_score_state=quantitative.get('status'),
        quantitative_score_receipt=quantitative,
        score_roles=score_roles,
        target_progress=progress_role,
        return_depth=depth_role,
        score_interpretation='role_measurements_only; no_target_success_probability_or_order_vote',
        delivery_status=delivery_state, lifecycle=lifecycle,
        current_structure=current, disposition=disposition,
        three_push_context=three_push_context,
        range_context_retired=bool(range_retired),
        forecast_eligible=bool(forecast_eligible),
        current_sequence_alignment=sequence,
        structural_context_accepted=structural_context_accepted,
        delivery_positive=delivery_positive,
        research_ready_for_downstream_review=research_ready,
        downstream_review_reason=("developing_positive_delivery_with_frozen_and_current_boundaries_accepted" if research_ready else
                                  "requires_developing_positive_delivery_and_aligned_accepted_boundaries"),
        entry_gate="closed_research_only",
        entry_gate_reason="automatic_trade_permission_false",
        automatic_trade_permission=False, order_api_called=False,
    )

