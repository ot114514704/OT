"""Fail-closed symbolic reasoning engine for the integrated XAUUSD framework.

The engine deliberately separates observation, parent authority, statistical
priors, and execution geometry. It is not a signal generator: even a complete
research chain returns a research candidate, never an order instruction.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List


# Source-guide confirmation scopes, not permission to replace a parent task.
# Physical pp. 13/53: CE/MR H1-H4; physical p. 33: CR M15-H1.
# M30 membership is our explicit interval interpretation, not a quoted M30 rule.
_WEEKLY_CE_MR_CLOSE_TFS = {"H1", "H4", "H1-H4"}
_WEEKLY_CR_CLOSE_TFS = {"M15", "M30", "H1", "M15-H1"}

# This is an execution-research descent, not a claim that every chart must
# have one universal hierarchy.  It records the analyst's chosen parent task
# and then requires each normally available lower timeframe to be inspected
# before an OB/FVG/SNR route is permitted.  W1 may be a context parent even
# though it is not itself an execution working timeframe.
_TIMEFRAME_DESCENT_ORDER = ("W1", "D1", "H4", "H1", "M30", "M15", "M5", "M1")
_TIMEFRAME_DESCENT_RANK = {timeframe: index for index, timeframe in enumerate(_TIMEFRAME_DESCENT_ORDER)}


@dataclass
class Decision:
    action: str
    permission: str
    blockers: List[str] = field(default_factory=list)
    next_evidence: List[str] = field(default_factory=list)
    state: Dict[str, Any] = field(default_factory=dict)


def _truthy(mapping: Dict[str, Any], key: str) -> bool:
    value = mapping.get(key)
    if value is True:
        return True
    if value is None or value == "" or value == [] or value is False:
        return False
    # Source-ledger placeholders are explicit absence, not evidence.  Keeping
    # them false here is critical because many gates use this helper for the
    # identity of a DOL, PDA, node, event, parent task, or execution field.
    # A string such as "unknown" must never satisfy a required-observation
    # check merely because it is non-empty.
    if isinstance(value, str) and value.strip().lower() in {
        "unknown", "not_recorded", "not applicable", "not_applicable", "n/a", "none", "pending",
    }:
        return False
    return True


def _all_true(mapping: Dict[str, Any], keys: Iterable[str]) -> bool:
    return all(mapping.get(key) is True for key in keys)


def _gobi_digger_adjudication(elasticity: Dict[str, Any], digger: Dict[str, Any]) -> str:
    """Return a non-directional, as-of integration state; never an entry."""
    if not elasticity or not digger:
        return "not_recorded"
    if digger.get("integration_status") == "conflicted":
        return "conflicted_wait"
    parent_state = elasticity.get("parent_elasticity_state")
    child_state = elasticity.get("child_elasticity_state")
    interaction = digger.get("interaction_state")
    path_state = digger.get("level_path_state")
    parent_structure = elasticity.get("parent_structure_state")
    if parent_state == "expanding" and child_state == "countermove":
        return "countermove_watch_only"
    if (
        digger.get("integration_status") == "mapped_crosscheck"
        and parent_state == "expanding"
        and child_state == "recovering_with_parent"
        and interaction in {"first_attempt_hold", "retest"}
        and path_state in {None, "holding_candidate", "progressing_next_in_line"}
    ):
        return "continuation_quality_supported"
    if interaction == "failure_to_hold" and parent_structure in {"pending_change", "accepted_change"}:
        return "parent_change_review"
    return "context_incomplete"


def _pattern_authority_gates(pattern: Dict[str, Any], force: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Check optional deep price-action annotations without inventing a trade.

    The annotations are optional because historical/source cases are often not
    yet fully mapped. Once an annotator claims this level of pattern authority,
    however, the parent task, named object and as-of time-state must be present.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []

    if pattern:
        if not _truthy(pattern, "parent_task_id"):
            blockers.append("pattern_authority_parent_task_unknown")
            next_evidence.append("name_parent_task_for_pattern_authority")
        if pattern.get("container_regime") in {None, "unknown"}:
            blockers.append("pattern_authority_container_unknown")
        status = pattern.get("observation_status")
        if status not in {"unclosed_observation", "closed_setup", "triggered", "held_or_failed"}:
            blockers.append("pattern_authority_time_state_invalid")
        if pattern.get("claimed_ratio_confluence_upgrade") is True:
            required = ("anchored_measurements", "closed_response", "parent_state_checked")
            if not _all_true(pattern, required):
                blockers.append("ratio_confluence_without_close_acceptance_parent_state")
                next_evidence.append("anchor_each_measurement_and_check_close_acceptance_parent_state")
        if pattern.get("claimed_false_breakout") is True:
            required = ("named_boundary", "reclaimed_inside_close", "opposite_follow_through")
            if not _all_true(pattern, required):
                blockers.append("false_breakout_without_boundary_reclaim_followthrough")
                next_evidence.append("record_boundary_outside_close_reclaim_and_follow_through")
        if pattern.get("reinforced_two_test_claimed") is True:
            required = ("magnet_id", "c1_recorded", "p1_recorded", "c2_recorded", "p2_recorded", "c2_same_magnet")
            if not _all_true(pattern, required):
                blockers.append("reinforced_two_test_chain_incomplete_or_different_magnet")
                next_evidence.append("record_C1_P1_C2_P2_against_same_named_magnet")
            if pattern.get("counterforce_conflict") is True and pattern.get("counterforce_resolved") is not True:
                blockers.append("reinforced_two_test_counterforce_unresolved")
                next_evidence.append("resolve_consecutive_opposite_body_and_close_dominance")

    if force:
        if not _truthy(force, "boundary_id"):
            blockers.append("breakout_force_boundary_unknown")
            next_evidence.append("name_boundary_for_breakout_force")
        follow_state = force.get("follow_through_state")
        if follow_state not in {"immediate", "delayed", "neutral", "rapid_reclaim", "unknown"}:
            blockers.append("breakout_force_follow_through_state_invalid")
        if follow_state == "delayed" and not _truthy(force, "follow_through_policy"):
            blockers.append("delayed_follow_through_without_policy_window")
            next_evidence.append("declare_relative_timeframe_follow_through_window")
        if force.get("institutional_build_claimed") is True:
            required = ("named_sweep_or_task", "creator_structure_identity", "subsequent_acceptance")
            if not _all_true(force, required):
                blockers.append("institutional_build_claim_without_observable_process_chain")
                next_evidence.append("record_sweep_task_creator_identity_and_acceptance")
        if force.get("leg_hypothesis") == "delivery_second_leg" and follow_state in {"neutral", "rapid_reclaim", "unknown"}:
            blockers.append("delivery_second_leg_without_held_follow_through")
            next_evidence.append("observe_follow_through_or_keep_trap_climax_competitors")

    return blockers, next_evidence


def _al10_setup_gates(setup: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Validate an optional Al10 evidence card without turning it into a signal."""
    if not setup:
        return [], []
    blockers: List[str] = []
    next_evidence: List[str] = []
    families = {
        "major_trend_reversal", "final_flag", "breakout", "h2_l2", "wedge_three_push",
        "channel", "measured_move", "range_reversal", "opening_reversal", "magnet", "none", "unknown",
    }
    family = setup.get("setup_family")
    if family not in families:
        blockers.append("al10_setup_family_invalid")
    if not _truthy(setup, "as_of_utc") or not _truthy(setup, "timeframe"):
        blockers.append("al10_setup_asof_or_timeframe_missing")
        next_evidence.append("bind_al10_setup_to_asof_and_timeframe")
    if not isinstance(setup.get("evidence_ids"), list) or not setup["evidence_ids"]:
        blockers.append("al10_setup_source_evidence_missing")
        next_evidence.append("bind_al10_setup_to_pdf_or_original_message_evidence")
    object_ids = setup.get("object_ids")
    if (
        not isinstance(object_ids, list)
        or not object_ids
        or not any(_truthy({"value": value}, "value") for value in object_ids)
    ):
        blockers.append("al10_setup_named_objects_missing")
        next_evidence.append("name_range_snr_magnet_or_target_object")
    if not isinstance(setup.get("attempt_chain"), list) or not setup["attempt_chain"]:
        blockers.append("al10_setup_attempt_chain_missing")
        next_evidence.append("record_first_attempt_recovery_second_attempt_and_result")
    if setup.get("bar_close_status") not in {"unclosed", "closed_inside", "closed_beyond", "reclaimed", "rejected", "unknown"}:
        blockers.append("al10_setup_bar_close_status_invalid")
    if setup.get("follow_through_status") not in {"pending", "present", "failed", "conflicted", "unknown"}:
        blockers.append("al10_setup_followthrough_status_invalid")

    evidence = setup.get("evidence") if isinstance(setup.get("evidence"), dict) else setup
    required_by_family = {
        "major_trend_reversal": ("defined_prior_trend", "trendline_break_pullback", "old_trend_recovery_attempt", "second_failure_or_new_structure"),
        "final_flag": ("late_trend_pause", "magnet_or_key_location", "continuation_and_reversal_branches_both_preserved"),
        "breakout": ("named_object", "closed_relation_to_object", "follow_through_status"),
        "h2_l2": ("trend_or_strong_range_leg", "two_failed_countertrend_attempts", "signal_close_and_stop_context"),
        "wedge_three_push": ("at_least_three_pushes", "regime_and_location", "post_third_push_response"),
        "channel": ("channel_context", "edge_or_breakout_failure_evidence"),
        "measured_move": ("anchor_a", "anchor_b", "timeframe", "target_status"),
        "range_reversal": ("range_regime_evidence", "outer_location", "failed_first_attempt_or_second_entry"),
        "opening_reversal": ("explicit_session_definition", "opening_test_object", "response_and_followthrough"),
        "magnet": ("magnet_type", "parent_timeframe", "reach_status", "post_reach_response"),
    }
    required = required_by_family.get(family, ())
    if family not in {None, "none", "unknown"} and not all(evidence.get(key) is True for key in required):
        blockers.append("al10_setup_family_evidence_incomplete")
        next_evidence.append("complete_al10_family_specific_attempt_close_and_followthrough_fields")
    if setup.get("autonomous_direction_claimed") is True:
        blockers.append("al10_setup_autonomous_direction_forbidden")
        next_evidence.append("replace_setup_direction_with_competing_paths_and_parent_relation")
    return blockers, next_evidence


def _weekly_profile_gates(weekly: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Validate a claimed Weekly Profile path at its source-specific evidence scale.

    CE/MR and CR deliberately have different object and close-timeframe
    obligations. A weekday/event label never supplies a missing obligation.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    profile = weekly.get("profile_candidate")
    if not profile:
        return blockers, next_evidence

    program = weekly.get("economic_program") or {}
    if not program:
        blockers.append("weekly_profile_without_us_economic_program")
        next_evidence.append("record_us_week_calendar_program_model_accumulation_release_scale_and_objects")
    else:
        if program.get("calendar_scope") != "US_weekly_macro":
            blockers.append("weekly_economic_program_calendar_scope_invalid")
        if program.get("calendar_known_as_of") is not True:
            blockers.append("weekly_economic_program_calendar_not_known_asof")
        source_refs = program.get("calendar_source_refs")
        if not isinstance(source_refs, list) or not any(isinstance(ref, str) and ref for ref in source_refs):
            blockers.append("weekly_economic_program_calendar_source_missing")
        for field in ("dominant_release_map", "profile_model_candidates", "predicted_accumulation_windows", "predicted_release_windows", "predicted_reversal_scales", "object_plan"):
            if not isinstance(program.get(field), list) or not program[field]:
                blockers.append(f"weekly_economic_program_{field}_missing")
        if program.get("event_name_direction") != "forbidden":
            blockers.append("weekly_economic_program_event_name_claims_direction")
        if program.get("execution_permission") not in {"observation_only", "blocked"}:
            blockers.append("weekly_economic_program_claims_execution_permission")
        if program.get("program_state") not in {"planned", "active", "reclassified", "invalidated", "unknown"}:
            blockers.append("weekly_economic_program_state_invalid")
        candidate_families = {
            item.get("family") for item in program.get("profile_model_candidates", [])
            if isinstance(item, dict)
        }
        canonical_profile = {"CE": "classic_expansion", "MR": "midweek_reversal", "CR": "consolidation_reversal"}.get(profile, profile)
        if canonical_profile not in candidate_families:
            blockers.append("weekly_profile_candidate_not_in_economic_program")
        allowed_roles = {
            "weekly_accumulation", "intraday_liquidity_clearance", "weekly_release_candidate",
            "continuation_or_reassessment", "low_liquidity_reassessment", "unknown",
        }
        for event in program.get("dominant_release_map", []):
            if not isinstance(event, dict) or not _truthy(event, "event_id"):
                blockers.append("weekly_economic_program_event_map_invalid")
                continue
            if event.get("planned_role") not in allowed_roles:
                blockers.append("weekly_economic_program_event_role_invalid")
            scales = event.get("candidate_timeframes")
            if not isinstance(scales, list) or not scales:
                blockers.append("weekly_economic_program_event_scale_missing")
        if profile in {"CE", "MR"}:
            planned_scales = {str(scale) for scale in program.get("predicted_reversal_scales", [])}
            if not any(scale in {"H1", "H4", "H1-H4"} or "H1-H4" in scale for scale in planned_scales):
                blockers.append("weekly_economic_program_missing_h1_h4_reversal_scale")
                next_evidence.append("state_whether_programmed_weekly_reversal_requires_H1_or_H4_acceptance")

    if weekly.get("event_direction_from_name") is True:
        blockers.append("weekly_event_name_claims_direction")
        next_evidence.append("replace_event_direction_with_object_response_and_close")

    state = weekly.get("profile_state")
    if state not in {"candidate", "confirmed", "void", "reclassified", "no_profile", "unknown"}:
        blockers.append("weekly_profile_state_invalid")

    if profile in {"CE", "MR"}:
        if not (
            weekly.get("preweek_dol_declared") is True
            and weekly.get("relevant_htf_pda_engaged") is True
            and _truthy(weekly, "manipulated_object_id")
        ):
            blockers.append("weekly_ce_mr_missing_dol_pda_or_manipulation")
            next_evidence.append("name_weekly_dol_htf_pda_and_manipulated_object")
        if weekly.get("required_close_timeframe") not in _WEEKLY_CE_MR_CLOSE_TFS:
            blockers.append("weekly_ce_mr_wrong_or_missing_close_timeframe")
            next_evidence.append("record_H1_H4_breaker_close_for_ce_or_mr")
        if profile == "MR":
            entry = weekly.get("mon_tue_entry_type")
            if entry not in {"accumulation", "retracement"}:
                blockers.append("midweek_reversal_without_accumulation_or_retracement_entry")
                next_evidence.append("classify_mon_tue_as_accumulation_or_retracement_or_void_mr")
        if profile == "CE" and weekly.get("directional_no_retrace_without_manipulation") is True:
            blockers.append("classic_expansion_low_quality_direct_extension_without_manipulation")

    if profile == "CR":
        if not (
            _truthy(weekly, "external_range_object_id")
            and weekly.get("external_range_engaged") is True
            and _truthy(weekly, "manipulated_object_id")
        ):
            blockers.append("consolidation_reversal_without_external_range_engagement")
            next_evidence.append("name_and_observe_external_consolidated_range_manipulation")
        if weekly.get("required_close_timeframe") not in _WEEKLY_CR_CLOSE_TFS:
            blockers.append("consolidation_reversal_wrong_or_missing_close_timeframe")
            next_evidence.append("record_M15_H1_breaker_close_for_consolidation_reversal")

    if state == "confirmed" and not _all_true(weekly, ("required_close_observed", "acceptance_confirmed", "follow_through_observed")):
        blockers.append("weekly_confirmed_without_close_acceptance_followthrough")
        next_evidence.append("downgrade_to_candidate_or_record_close_acceptance_and_delivery")
    if weekly.get("target_state") == "completed" and weekly.get("friday_default_continuation") is True:
        blockers.append("weekly_completed_target_still_claims_default_friday_continuation")
        next_evidence.append("rebuild_target_or_evaluate_tgif_consolidation_branch")

    return blockers, next_evidence


def _weekly_alexander_execution_context_gates(weekly: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Keep Alexander's observed weekly path states distinct from profile names.

    This is deliberately optional: a source case may have no usable weekly
    context. When it is recorded, an intraday sweep, a broken week-open
    continuity, or a target-completion reprice cannot silently become a
    confirmed CE/MR/CR narrative.
    """
    context = weekly.get("alexander_execution_context") or {}
    if not context:
        return [], []

    blockers: List[str] = []
    next_evidence: List[str] = []
    path = context.get("path_classification")
    valid_paths = {
        "early_week_accumulation_candidate", "intraday_sweep_only", "weekly_release_observation",
        "target_completion_reprice", "reaccumulation_or_no_profile", "unknown",
    }
    if path not in valid_paths:
        blockers.append("weekly_alexander_execution_context_path_invalid")
        return blockers, next_evidence
    if context.get("week_continuity_state") not in {
        "intact", "gap_filled_no_object", "high_open_prior_pool_interrupted",
        "target_not_reached_old_pool_active", "unknown",
    }:
        blockers.append("weekly_alexander_execution_context_continuity_invalid")
    if context.get("claim_scope") not in {"observation_only", "candidate_path", "confirmed_weekly_path", "unknown"}:
        blockers.append("weekly_alexander_execution_context_claim_scope_invalid")
    refs = context.get("source_refs")
    if not isinstance(refs, list) or not any(isinstance(ref, str) and ref for ref in refs):
        blockers.append("weekly_alexander_execution_context_source_missing")
    if not isinstance(context.get("named_object_ids"), list):
        blockers.append("weekly_alexander_execution_context_object_list_invalid")
    if not _truthy(context, "as_of_utc"):
        blockers.append("weekly_alexander_execution_context_asof_missing")

    profile_state = weekly.get("profile_state")
    resolution = weekly.get("family_resolution") or {}
    family_state = resolution.get("resolution_state")
    confirmed = profile_state == "confirmed" or family_state == "confirmed" or context.get("claim_scope") == "confirmed_weekly_path"
    if path == "intraday_sweep_only" and confirmed:
        blockers.append("weekly_intraday_sweep_only_claims_weekly_confirmation")
        next_evidence.append("require_htf_target_relation_and_family_specific_close_acceptance_before_weekly_upgrade")
    if path == "reaccumulation_or_no_profile" and confirmed and context.get("reclassification_recorded") is not True:
        blockers.append("weekly_reaccumulation_claims_confirmed_family_without_reclassification")
        next_evidence.append("record_new_object_task_and_accepted_reclassification_or_keep_no_profile")
    if path == "target_completion_reprice" and weekly.get("friday_default_continuation") is True:
        blockers.append("weekly_target_completion_reprice_claims_default_friday_continuation")
    if context.get("week_continuity_state") in {"gap_filled_no_object", "high_open_prior_pool_interrupted"}:
        if path not in {"reaccumulation_or_no_profile", "unknown"} and context.get("reclassification_recorded") is not True:
            blockers.append("weekly_continuity_break_replays_default_profile_without_new_object_review")
            next_evidence.append("review_old_liquidity_pool_gap_and_parent_target_before_reusing_weekly_story")
    return blockers, next_evidence


def _weekly_family_resolution_gates(weekly: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Fail closed when a standard Weekly Profile family is selected.

    The guide's weekday families are competing conditional templates.  This
    extra layer applies only when an annotator explicitly claims one; legacy
    source snapshots that merely carry a weekly program remain unaffected.
    """
    resolution = weekly.get("family_resolution") or {}
    if not resolution:
        return [], []

    blockers: List[str] = []
    next_evidence: List[str] = []
    family = resolution.get("standard_family")
    allowed_families = {
        "classic_tuesday_wednesday_extreme",
        "wednesday_weekly_reversal",
        "consolidation_thursday_reversal",
        "consolidation_midweek_continuation",
        "friday_delayed_release_or_reprice",
        "no_profile",
        "unknown",
    }
    if family not in allowed_families:
        blockers.append("weekly_family_resolution_standard_family_invalid")
        next_evidence.append("select_standard_weekly_family_or_no_profile")
        return blockers, next_evidence

    # Some guide labels intentionally have no canonical family until their
    # path is distinguished by structure and event evidence.  Do not let a
    # retrieval alias silently turn them into a confirmed standard family.
    unresolved_variant_labels = {
        "Wednesday Low of the Week",
        "Wednesday High of the Week",
        "Seek and Destroy Bullish Friday",
        "Neutral-Low Probability Profile",
    }
    if (resolution.get("source_guide_label") in unresolved_variant_labels
            and family != "unknown"
            and resolution.get("variant_resolution_evidence_bound") is not True):
        blockers.append("weekly_variant_alias_promoted_without_resolution_evidence")
        next_evidence.append("bind_structure_target_event_and_belonging_timeframe_acceptance_before_canonical_family_mapping")

    if family == "unknown":
        if (resolution.get("resolution_state") == "confirmed"
                or weekly.get("profile_state") == "confirmed"):
            blockers.append("weekly_unknown_family_cannot_claim_confirmation")
            next_evidence.append("resolve_competing_variant_paths_with_parent_structure_target_and_belonging_timeframe_acceptance")
        return blockers, next_evidence

    state = resolution.get("resolution_state")
    if state not in {"candidate", "confirmed", "reclassified", "no_profile", "unknown"}:
        blockers.append("weekly_family_resolution_state_invalid")
    if resolution.get("competition_state") not in {"unresolved", "resolved", "not_applicable"}:
        blockers.append("weekly_family_resolution_competition_state_invalid")
    # Legacy value describes event-window binding only. The full economic
    # program can also prioritize families, accumulation and release scales.
    if resolution.get("event_role_permission") not in {"window_selector_only", "upstream_weekly_program"}:
        blockers.append("weekly_family_resolution_event_role_claims_more_than_window")
        next_evidence.append("record_economic_program_as_conditional_planning_not_direction_or_execution")
    if not isinstance(resolution.get("competing_families"), list):
        blockers.append("weekly_family_resolution_competing_families_missing")

    program = weekly.get("economic_program") or {}
    if family != "no_profile":
        planned_events = {
            item.get("event_id")
            for item in program.get("dominant_release_map", [])
            if isinstance(item, dict) and _truthy(item, "event_id")
        }
        if resolution.get("event_window_id") not in planned_events:
            blockers.append("weekly_family_resolution_window_not_in_preweek_program")
            next_evidence.append("bind_selected_family_to_preweek_event_or_session_window")

        profile = weekly.get("profile_candidate")
        allowed_by_profile = {
            "CE": {"classic_tuesday_wednesday_extreme", "consolidation_midweek_continuation"},
            "MR": {"wednesday_weekly_reversal"},
            "CR": {"consolidation_thursday_reversal"},
        }
        if profile in allowed_by_profile and family not in allowed_by_profile[profile]:
            blockers.append("weekly_family_resolution_conflicts_with_profile_candidate")
        if family == "friday_delayed_release_or_reprice" and profile not in {None, "no_profile"}:
            blockers.append("weekly_family_resolution_friday_reprice_must_not_claim_directional_profile")

    if family == "no_profile":
        if state == "confirmed":
            blockers.append("weekly_no_profile_cannot_claim_confirmation")
        if weekly.get("profile_candidate") not in {None, "no_profile"}:
            blockers.append("weekly_no_profile_conflicts_with_directional_profile_claim")
        return blockers, next_evidence

    if state == "confirmed":
        if resolution.get("competition_state") == "unresolved":
            blockers.append("weekly_family_resolution_confirmed_while_competition_unresolved")
            next_evidence.append("resolve_competing_weekly_families_with_named_object_close_acceptance_evidence")
        required = ("early_week_container_id", "parent_task_id", "htf_context_id", "liquidity_object_id", "structure_node_id")
        if not all(_truthy(resolution, key) for key in required):
            blockers.append("weekly_family_resolution_confirmed_without_container_parent_context_object_and_node")
            next_evidence.append("name_early_container_parent_htf_context_liquidity_object_and_structure_node")
        if resolution.get("parent_task_relation") not in {"aligned", "reclassified"}:
            blockers.append("weekly_family_resolution_confirmed_without_parent_task_relation")
        if family == "consolidation_thursday_reversal":
            if resolution.get("close_timeframe") not in _WEEKLY_CR_CLOSE_TFS:
                blockers.append("weekly_family_resolution_cr_without_m15_h1_close")
        elif resolution.get("close_timeframe") not in _WEEKLY_CE_MR_CLOSE_TFS:
            blockers.append("weekly_family_resolution_confirmed_without_h1_h4_close")
        if resolution.get("close_state") not in {"body_close", "accepted"} or resolution.get("acceptance_state") != "held":
            blockers.append("weekly_family_resolution_confirmed_without_held_close_acceptance")

    if family == "consolidation_midweek_continuation" and state == "confirmed":
        if resolution.get("parent_task_relation") != "aligned":
            blockers.append("weekly_continuation_without_active_aligned_parent_task")
        if resolution.get("acceptance_state") != "held":
            blockers.append("weekly_continuation_without_held_breakout_or_retest")

    if family == "friday_delayed_release_or_reprice" and weekly.get("target_state") == "completed":
        if resolution.get("acceptance_state") == "held" and weekly.get("friday_default_continuation") is True:
            blockers.append("weekly_friday_reprice_claims_default_continuation_after_completed_target")

    return blockers, next_evidence


def _weekly_event_realization_gates(weekly: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Bind live event observation to the preweek economic program.

    The calendar program is allowed to select *when and at what scale* to
    investigate a Weekly Profile branch.  This function prevents an annotator
    from silently changing that program after a news candle, or from treating
    the first reaction as a confirmed weekly path.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    realization = weekly.get("event_realization") or {}
    if not realization:
        return blockers, next_evidence

    program = weekly.get("economic_program") or {}
    if not program:
        blockers.append("weekly_event_realization_without_preweek_program")
        next_evidence.append("bind_event_observation_to_source_bound_us_week_program")
        return blockers, next_evidence

    event_id = realization.get("event_id")
    planned_events = {
        item.get("event_id"): item
        for item in program.get("dominant_release_map", [])
        if isinstance(item, dict) and item.get("event_id")
    }
    if not event_id or event_id not in planned_events:
        blockers.append("weekly_event_realization_not_in_preweek_program")
        next_evidence.append("bind_observed_event_to_a_planned_event_or_explicitly_reclassify_program")

    if realization.get("state") not in {
        "active", "first_response", "acceptance_test", "reclassified", "invalidated", "unknown",
    }:
        blockers.append("weekly_event_realization_state_invalid")
    if realization.get("direction_from_event_name") != "forbidden":
        blockers.append("weekly_event_realization_claims_direction_from_event_name")
    refs = realization.get("source_refs")
    if not isinstance(refs, list) or not any(isinstance(ref, str) and ref for ref in refs):
        blockers.append("weekly_event_realization_source_missing")
    if not _truthy(realization, "observation_as_of_utc"):
        blockers.append("weekly_event_realization_asof_missing")
    if realization.get("actual_release_verified") not in {True, False}:
        blockers.append("weekly_event_realization_release_verification_invalid")

    response = realization.get("first_response")
    allowed_responses = {
        "single_sided_delivery", "sweep_reclaim", "double_sided",
        "range_contained", "data_unreconstructable", "unknown",
    }
    if response not in allowed_responses:
        blockers.append("weekly_event_realization_first_response_invalid")
    if realization.get("response_timeframe") not in {"M1", "M5", "M15", "M30", "H1", "H4", "unknown"}:
        blockers.append("weekly_event_realization_timeframe_invalid")
    if realization.get("close_state") not in {"wick_only", "body_close", "accepted", "reclaimed", "unknown"}:
        blockers.append("weekly_event_realization_close_state_invalid")
    object_ids = realization.get("named_object_ids")
    if not isinstance(object_ids, list):
        blockers.append("weekly_event_realization_object_list_invalid")

    claimed_confirmation = realization.get("weekly_confirmation_claimed") is True
    if response in {"double_sided", "sweep_reclaim", "data_unreconstructable", "unknown"} and claimed_confirmation:
        blockers.append("weekly_event_realization_unresolved_response_claims_confirmation")
        next_evidence.append("wait_for_post_event_normalization_and_named_object_acceptance")
    if response == "single_sided_delivery":
        if not object_ids:
            blockers.append("weekly_event_delivery_without_named_object")
        if realization.get("close_state") in {"wick_only", "reclaimed", "unknown"} and claimed_confirmation:
            blockers.append("weekly_event_delivery_without_accepted_close")
    if response == "data_unreconstructable" and realization.get("label_for_training") is True:
        blockers.append("weekly_event_unreconstructable_used_as_training_label")

    profile = weekly.get("profile_candidate")
    planned_event = planned_events.get(event_id, {})
    planned_role = planned_event.get("planned_role")
    if claimed_confirmation and profile in {"CE", "MR"}:
        if planned_role not in {"weekly_release_candidate", "continuation_or_reassessment"}:
            blockers.append("weekly_event_role_cannot_confirm_ce_mr")
        if realization.get("response_timeframe") not in {"H1", "H4"}:
            blockers.append("weekly_event_ce_mr_confirmation_below_h1_h4")
        if realization.get("close_state") != "accepted" or realization.get("follow_through_observed") is not True:
            blockers.append("weekly_event_ce_mr_without_acceptance_followthrough")
    if claimed_confirmation and profile == "CR":
        if realization.get("response_timeframe") not in _WEEKLY_CR_CLOSE_TFS - {"M15-H1"}:
            blockers.append("weekly_event_cr_confirmation_wrong_timeframe")
        if realization.get("close_state") != "accepted" or realization.get("follow_through_observed") is not True:
            blockers.append("weekly_event_cr_without_acceptance_followthrough")

    return blockers, next_evidence


def _amd_gates(amd: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Gate optional AMD annotations as observable task states, not intent claims."""
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not amd:
        return blockers, next_evidence

    if amd.get("phase") not in {"A", "M", "D", "transition", "unknown"}:
        blockers.append("amd_phase_invalid")
    if not _truthy(amd, "parent_task_id"):
        blockers.append("amd_parent_task_unknown")
        next_evidence.append("bind_amd_to_parent_creator_leg_and_dol")
    if amd.get("institutional_account_claimed") is True and amd.get("observable_process_hypothesis") is not True:
        blockers.append("amd_claims_unobservable_institutional_account_state")

    phase = amd.get("phase")
    if phase in {"A", "M", "D", "transition"}:
        if not _truthy(amd, "phase_task_id") or not _truthy(amd, "phase_timeframe"):
            blockers.append("amd_phase_not_bound_to_task_and_timeframe")
            next_evidence.append("name_the_task_and_timeframe_for_this_amd_phase")
        if amd.get("phase_parent_relation") not in {"same_task", "child_of_parent", "parent_transition"}:
            blockers.append("amd_phase_parent_relation_unknown")
            next_evidence.append("state_whether_the_phase_belongs_to_the_parent_child_or_transition_task")
    if phase == "A":
        if amd.get("accumulation_mode") not in {"time", "space", "insufficient"}:
            blockers.append("amd_accumulation_mode_unknown")
        if not _truthy(amd, "container_id"):
            blockers.append("amd_accumulation_container_unknown")
    if phase == "M":
        if not _truthy(amd, "manipulated_object_id"):
            blockers.append("amd_manipulated_object_unknown")
            next_evidence.append("name_object_processed_during_manipulation")
        if amd.get("manipulation_outcome") not in {"reclaim", "accepted_break", "double_sided", "unknown"}:
            blockers.append("amd_manipulation_outcome_invalid")
        if not _truthy(amd, "manipulated_object_timeframe"):
            blockers.append("amd_manipulated_object_timeframe_unknown")
    if phase == "D":
        required = ("creator_leg_id", "structure_identity", "target_relation")
        if not _all_true(amd, required):
            blockers.append("amd_distribution_without_creator_structure_and_task_relation")
            next_evidence.append("record_creator_leg_structure_identity_and_target_relation")
        if amd.get("distribution_after_accepted_opposite_break") is True:
            blockers.append("amd_distribution_conflicts_with_accepted_manipulation_break")
        target_state = amd.get("distribution_target_state")
        if target_state not in {"active", "approaching", "touched_under_review", "completed", "invalidated"}:
            blockers.append("amd_distribution_target_lifecycle_unknown")
        if amd.get("continuation_distribution_claimed") is True and target_state in {"completed", "invalidated"}:
            blockers.append("amd_continuation_claimed_after_distribution_target_ended")
            next_evidence.append("rebuild_the_task_or_classify_a_target_transition_before_continuation")

    if amd.get("poi_confirmation_claimed") is True:
        confirmation_route = amd.get("poi_confirmation_route")
        allowed_routes = {
            "corresponding_tf_structure_reversal",
            "poi_tf_signal_bar_high_low1",
            "secondary_divergence_signal_high_low1",
            "composite_same_event",
        }
        required = ("poi_id", "poi_source_timeframe", "confirmation_timeframe", "poi_confirmation_causal_cluster_id")
        observations = amd.get("poi_confirmation_closed_observation_ids")
        if not _all_true(amd, required) or not isinstance(observations, list) or not any(observations):
            blockers.append("amd_poi_confirmation_identity_or_closed_evidence_missing")
            next_evidence.append("bind_poi_confirmation_to_one_poi_timeframe_closed_event_and_causal_cluster")
        if confirmation_route not in allowed_routes:
            blockers.append("amd_poi_confirmation_route_invalid")
        if amd.get("poi_confirmation_counted_as_multiple_votes") is not False:
            blockers.append("amd_poi_confirmation_terms_counted_as_votes")
        route_requirements = {
            "corresponding_tf_structure_reversal": "poi_structure_event_id",
            "poi_tf_signal_bar_high_low1": "poi_signal_bar_id",
            "secondary_divergence_signal_high_low1": "poi_divergence_object_id",
        }
        route_field = route_requirements.get(confirmation_route)
        if route_field and not _truthy(amd, route_field):
            blockers.append("amd_poi_confirmation_route_evidence_missing")

    if amd.get("lower_tf_reverse_amd_claimed") is True:
        required = (
            "old_distribution_id", "old_distribution_target_id", "reverse_amd_timeframe",
            "reverse_manipulated_object_id", "reverse_creator_leg_id",
        )
        if not _all_true(amd, required) or amd.get("reverse_amd_is_lower_timeframe") is not True:
            blockers.append("amd_lower_tf_reverse_transition_chain_incomplete")
            next_evidence.append("bind_old_distribution_target_and_lower_timeframe_reverse_amd_process")
        old_target_state = amd.get("old_distribution_target_state")
        if old_target_state not in {"touched_under_review", "completed"}:
            blockers.append("amd_reverse_transition_claimed_before_old_target_engagement")
        if amd.get("old_distribution_end_claimed") is True:
            reverse_evidence = amd.get("reverse_close_acceptance_evidence_ids")
            if (
                amd.get("reverse_close_acceptance_state") != "accepted"
                or not isinstance(reverse_evidence, list)
                or not any(reverse_evidence)
                or amd.get("old_distribution_recovery_state") != "failed"
            ):
                blockers.append("amd_old_distribution_end_without_reverse_acceptance_and_failed_recovery")
                next_evidence.append("observe_reverse_close_acceptance_and_failure_of_old_distribution_recovery")

    if amd.get("manipulation_measurement_claimed") is True:
        required = (
            "manipulation_range_id",
            "measurement_definition",
            "measurement_timeframe",
            "measurement_family",
            "measurement_method_authority",
            "measurement_source_profile_id",
            "measurement_purpose",
            "manipulation_event_id",
        )
        if not all(_truthy(amd, key) for key in required):
            blockers.append("amd_measurement_without_range_definition_and_timeframe")
            next_evidence.append("bind_measurement_to_manipulation_range_definition_and_timeframe")
        measurement_family = amd.get("measurement_family")
        if measurement_family not in {"three_candle_manipulation_sd_projection", "source_bound_other_measurement"}:
            blockers.append("amd_measurement_family_invalid")

        if measurement_family == "three_candle_manipulation_sd_projection":
            required_sd = (
                "measurement_anchor_context_timeframe",
                "measurement_sample_bar_timeframe",
                "measurement_candle_selection_rule",
                "measurement_target_direction",
                "measurement_calculation_method",
            )
            sample_bar_ids = amd.get("measurement_sample_bar_ids")
            projection_levels = amd.get("measurement_projection_levels")
            if (
                not all(_truthy(amd, key) for key in required_sd)
                or not isinstance(sample_bar_ids, list)
                or len(sample_bar_ids) != 3
                or len(set(str(item) for item in sample_bar_ids)) != 3
            ):
                blockers.append("amd_three_candle_sd_sample_or_anchor_incomplete")
                next_evidence.append("lock_exactly_three_closed_source_profile_bars_and_anchor_context")
            if amd.get("measurement_sample_bars_closed_at_projection") is not True:
                blockers.append("amd_three_candle_sd_uses_unclosed_sample_bars")
            allowed_levels = {1.0, 2.0, 2.5, 3.5, 4.0, 4.5}
            if (
                not isinstance(projection_levels, list)
                or not projection_levels
                or any(not isinstance(level, (int, float)) or float(level) not in allowed_levels for level in projection_levels)
            ):
                blockers.append("amd_three_candle_sd_projection_ladder_invalid")
                next_evidence.append("use_source_ladder_1_2_2_5_3_5_4_4_5_without_invented_levels")

            if amd.get("measurement_method_authority") != "digital_time_theory":
                blockers.append("amd_three_candle_sd_method_authority_invalid")
                next_evidence.append("bind_three_candle_sd_method_to_digital_time_and_keep_alexander_as_application_evidence")
            application_evidence_ids = amd.get("measurement_application_evidence_ids")
            if not isinstance(application_evidence_ids, list) or not any(application_evidence_ids):
                blockers.append("amd_three_candle_sd_application_evidence_missing")

            source_profile = amd.get("measurement_source_profile_id")
            target_direction = amd.get("measurement_target_direction")
            selection_rule = amd.get("measurement_candle_selection_rule")
            if source_profile == "dtt_judas_3m_ob_m1_three_close":
                expected_rule = {
                    "buyside": "last_3_down_close",
                    "sellside": "last_3_up_close",
                }.get(target_direction)
                if (
                    amd.get("measurement_anchor_context_timeframe") != "M3"
                    or amd.get("measurement_sample_bar_timeframe") != "M1"
                    or expected_rule is None
                    or selection_rule != expected_rule
                ):
                    blockers.append("amd_digital_time_three_candle_profile_mismatch")
                    next_evidence.append("use_m3_orderblock_context_and_m1_directional_close_triplet_for_book_profile")
            elif source_profile == "dtt_intraday_m15_manipulation_triplet":
                allowed_rules = {
                    "last_3_closed_bars_of_named_manipulation_leg",
                    "last_3_candles_of_downward_manipulation",
                    "last_3_candles_of_upward_manipulation",
                }
                directional_mismatch = (
                    selection_rule == "last_3_candles_of_downward_manipulation" and target_direction != "buyside"
                ) or (
                    selection_rule == "last_3_candles_of_upward_manipulation" and target_direction != "sellside"
                )
                if (
                    amd.get("measurement_anchor_context_timeframe") != "M15"
                    or amd.get("measurement_sample_bar_timeframe") != "M15"
                    or selection_rule not in allowed_rules
                    or directional_mismatch
                ):
                    blockers.append("amd_dtt_intraday_m15_three_candle_profile_mismatch")
                    next_evidence.append("bind_three_closed_m15_bars_to_one_named_intraday_manipulation_leg")
            elif source_profile == "source_bound_custom_triplet":
                source_ids = amd.get("measurement_source_evidence_ids")
                if not isinstance(source_ids, list) or not any(source_ids):
                    blockers.append("amd_custom_three_candle_profile_without_source")
            else:
                blockers.append("amd_three_candle_sd_source_profile_invalid")

            calculation_method = amd.get("measurement_calculation_method")
            if calculation_method not in {"source_sd_projection_tool", "formula_verified"}:
                blockers.append("amd_three_candle_sd_calculation_method_invalid")
            if calculation_method == "formula_verified" and not _truthy(amd, "measurement_formula_evidence_id"):
                blockers.append("amd_three_candle_sd_formula_claimed_without_evidence")
            if amd.get("measurement_statistical_sigma_formula_claimed") is True and not _truthy(amd, "measurement_formula_evidence_id"):
                blockers.append("amd_three_candle_sd_statistical_sigma_unproven")
            if amd.get("measurement_anchor_locked_before_target_observed") is not True:
                blockers.append("amd_three_candle_sd_anchor_not_locked_asof")
            if amd.get("measurement_reanchored_after_outcome") is True:
                blockers.append("amd_three_candle_sd_hindsight_reanchor")
            if amd.get("measurement_claims_autonomous_direction") is not False:
                blockers.append("amd_three_candle_sd_claims_autonomous_direction")

            target_nodes = amd.get("measurement_target_nodes")
            allowed_tiers = {"near", "intermediate", "far", "terminal_review"}
            allowed_lifecycle = {"planned", "approached", "touched", "accepted", "rejected", "completed", "invalidated"}
            allowed_pda_states = {"absent", "before_target", "overlaps_target", "beyond_target", "unknown"}
            if not isinstance(target_nodes, list) or not target_nodes:
                blockers.append("amd_three_candle_sd_target_hierarchy_missing")
                next_evidence.append("create_target_nodes_with_tier_lifecycle_next_target_and_pda_relation")
            else:
                node_ids: set[str] = set()
                malformed_node = False
                for node in target_nodes:
                    if not isinstance(node, dict):
                        malformed_node = True
                        continue
                    target_id = node.get("target_id")
                    if not target_id or str(target_id) in node_ids:
                        malformed_node = True
                    else:
                        node_ids.add(str(target_id))
                    if node.get("target_tier") not in allowed_tiers:
                        malformed_node = True
                    if node.get("lifecycle_state") not in allowed_lifecycle:
                        malformed_node = True
                    if node.get("pda_in_path_state") not in allowed_pda_states:
                        malformed_node = True
                if malformed_node:
                    blockers.append("amd_three_candle_sd_target_hierarchy_invalid")

            continuation_permission = amd.get("measurement_continuation_permission")
            if continuation_permission not in {
                "continue_to_next_target", "hold_for_review", "terminal_candidate", "blocked",
            }:
                blockers.append("amd_three_candle_sd_continuation_permission_invalid")
            if continuation_permission == "continue_to_next_target":
                if (
                    amd.get("measurement_active_dol_state") != "incomplete"
                    or amd.get("measurement_current_level_acceptance") != "accepted_beyond"
                    or amd.get("measurement_creator_force_state") not in {"active", "resumed"}
                    or not _truthy(amd, "measurement_next_target_id")
                    or amd.get("measurement_blocking_htf_pda_state") not in {"absent", "beyond_next_target"}
                ):
                    blockers.append("amd_three_candle_sd_continuation_without_delivery_evidence")
                    next_evidence.append("confirm_unfinished_dol_close_acceptance_creator_force_next_target_and_no_blocking_htf_pda")

            terminal_candidate = amd.get("measurement_terminal_candidate") is True
            if terminal_candidate:
                if (
                    not _truthy(amd, "measurement_terminal_containing_pda_id")
                    or not _truthy(amd, "measurement_terminal_pda_timeframe")
                    or amd.get("measurement_active_dol_state") not in {"engaged", "completed"}
                ):
                    blockers.append("amd_three_candle_sd_terminal_candidate_without_htf_pda_or_dol_engagement")
            if amd.get("measurement_reversal_claimed") is True:
                if (
                    not terminal_candidate
                    or amd.get("measurement_terminal_object_response") not in {"swept_reclaimed", "rejected"}
                    or amd.get("measurement_opposite_displacement") is not True
                    or amd.get("measurement_belonging_timeframe_close_acceptance") is not True
                    or amd.get("measurement_old_direction_recovery_failed") is not True
                ):
                    blockers.append("amd_three_candle_sd_reversal_without_terminal_process")
                    next_evidence.append("require_htf_pda_terminal_candidate_object_response_opposite_displacement_close_acceptance_and_failed_recovery")
    if amd.get("digital_time_overlay_state") in {"candidate", "separately_validated"} and amd.get("digital_time_autonomous_direction") is not False:
        blockers.append("digital_time_overlay_claims_autonomous_direction")
    return blockers, next_evidence


def _high_probability_poi_gates(poi: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Require the ordered POI/IOFED chain when that high-probability label is claimed."""
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not poi:
        return blockers, next_evidence

    if not _truthy(poi, "parent_dol_id") or poi.get("parent_dol_state") not in {"active", "approaching_target"}:
        blockers.append("high_probability_poi_parent_dol_inactive_or_unknown")
        next_evidence.append("name_active_parent_dol_and_its_lifecycle")
    required = ("htf_sweep_object_id", "creator_leg_id", "creator_structure_identity")
    if not _all_true(poi, required):
        blockers.append("high_probability_poi_missing_sweep_or_creator_chain")
        next_evidence.append("record_htf_sweep_and_creator_structure_before_poi_claim")
    if poi.get("fvg_depth_state") not in {"shallow", "deep", "accepted_failure", "unknown"}:
        blockers.append("high_probability_poi_fvg_depth_state_invalid")
    if poi.get("confluence_claimed") is True and poi.get("roles_separately_verified") is not True:
        blockers.append("high_probability_poi_confluence_roles_unverified")
        next_evidence.append("separate_ob_ifvg_ote_roles_and_anchor_leg")
    if poi.get("local_secondary_sweep_claimed") is True and not _truthy(poi, "local_sweep_object_id"):
        blockers.append("high_probability_poi_local_sweep_unnamed")
    if poi.get("ny_post_window_claimed") is True and not _truthy(poi, "ny_post_window_policy"):
        blockers.append("ny_post_window_without_timezone_start_policy")
        next_evidence.append("declare_new_york_post_window_timezone_and_start_definition")
    if poi.get("old_target_completed") is True and poi.get("continuation_poi_claimed") is True:
        blockers.append("continuation_poi_claimed_after_old_target_completed")
        next_evidence.append("rebuild_parent_task_or_classify_target_transition_poi")
    if poi.get("institutional_accounts_proven") is True:
        blockers.append("poi_claims_unobservable_institutional_accounts")
    return blockers, next_evidence


def _institutional_origin_ob_lifecycle_gates(
    ob: Dict[str, Any], decision_cutoff_utc: Any = None
) -> tuple[List[str], List[str]]:
    """Keep origin quality, retest response, target expiry and breaker states ordered."""
    if not ob:
        return [], []
    blockers: List[str] = []
    next_evidence: List[str] = []
    base_required = (
        "ob_id", "source_timeframe", "task_id", "parent_task_id",
        "parent_dol_id", "as_of_utc", "source_evidence_ids",
    )
    if not all(_truthy(ob, field) for field in base_required):
        blockers.append("institutional_origin_ob_identity_or_source_missing")
        next_evidence.append("bind_ob_to_source_timeframe_task_parent_dol_and_asof")
    observed = _iso_time(ob.get("as_of_utc"))
    cutoff = _iso_time(decision_cutoff_utc)
    if observed is None:
        blockers.append("institutional_origin_ob_asof_time_invalid")
    elif cutoff is not None and observed > cutoff:
        blockers.append("institutional_origin_ob_future_evidence")

    lifecycle = ob.get("lifecycle_state")
    allowed_lifecycle = {
        "origin_candidate", "high_probability_candidate", "first_retest_pending",
        "defended", "deep_test_unresolved", "task_terminated", "breaker_candidate",
        "inactive", "unknown",
    }
    if lifecycle not in allowed_lifecycle:
        blockers.append("institutional_origin_ob_lifecycle_invalid")

    if ob.get("high_probability_claimed") is True:
        required = (
            "origin_candle_ids", "creator_leg_id", "structure_break_id",
            "pre_origin_liquidity_object_id", "fvg_id",
        )
        if not all(_truthy(ob, field) for field in required):
            blockers.append("high_probability_ob_missing_origin_structure_sweep_or_fvg")
            next_evidence.append("record_origin_cluster_structure_break_pre_origin_liquidity_and_adjacent_fvg")
        if ob.get("structure_break_close_state") not in {"closed_beyond", "accepted"}:
            blockers.append("high_probability_ob_without_closed_structure_break")
        if ob.get("pre_origin_liquidity_state") not in {"swept_reclaimed", "processed"}:
            blockers.append("high_probability_ob_without_pre_origin_liquidity_processing")
            next_evidence.append("keep_ob_low_resweep_path_open_until_pre_origin_liquidity_is_named_and_processed")
        if ob.get("fvg_adjacency") != "immediate_same_creator":
            blockers.append("high_probability_ob_fvg_not_adjacent_to_creator_origin")
        if ob.get("post_origin_efficiency") != "immediate_displacement":
            blockers.append("high_probability_ob_departure_efficiency_not_high")
            next_evidence.append("downgrade_to_low_quality_or_resweep_candidate_when_origin_dwells_or_overlaps")
        if ob.get("parent_dol_state") not in {"active", "approaching", "touched_under_review"}:
            blockers.append("high_probability_ob_parent_target_inactive_or_unknown")

    if (
        ob.get("parent_dol_state") in {"completed", "invalidated"}
        and lifecycle in {"high_probability_candidate", "first_retest_pending", "defended"}
    ):
        blockers.append("institutional_origin_ob_old_direction_used_after_parent_target_ended")
        next_evidence.append("terminate_the_old_ob_task_and_build_a_new_target_transition_chain")

    if lifecycle == "defended" and (
        ob.get("retest_close_state") != "reclaimed_or_accepted"
        or not _truthy(ob, "retest_response_evidence_ids")
    ):
        blockers.append("institutional_origin_ob_defended_without_retest_acceptance")

    if lifecycle == "breaker_candidate":
        breaker_required = (
            "old_task_failure_event_id", "opposite_structure_event_id",
            "opposite_close_acceptance_evidence_ids", "old_task_failed_recovery_evidence_ids",
        )
        if (
            ob.get("prior_lifecycle_state") != "task_terminated"
            or not all(_truthy(ob, field) for field in breaker_required)
            or ob.get("opposite_close_state") != "accepted"
        ):
            blockers.append("institutional_origin_ob_breaker_without_old_task_failure_chain")
            next_evidence.append("require_old_task_termination_opposite_acceptance_and_failed_recovery_before_breaker")
    if ob.get("institutional_accounts_proven") is True:
        blockers.append("institutional_origin_ob_claims_unobservable_account_truth")
    return blockers, next_evidence


def _integrated_adjudication_gates(adjudication: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Guard the synthesis layer against vote counting and unlabeled wave claims."""
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not adjudication:
        return blockers, next_evidence

    if adjudication.get("framework_vote_counting") is True:
        blockers.append("integrated_adjudication_uses_framework_vote_counting")
    if adjudication.get("lower_timeframe_overrides_parent") is True:
        blockers.append("integrated_adjudication_lower_timeframe_overrides_parent")
    if adjudication.get("wave_stage_claimed") is True:
        required = ("wave_origin_id", "wave_parent_task_id", "wave_delivery_stage", "wave_protected_object_id")
        if not _all_true(adjudication, required):
            blockers.append("wave_stage_without_origin_parent_stage_and_protected_object")
            next_evidence.append("bind_wave_label_to_origin_parent_stage_and_protected_object")
    conflicts = adjudication.get("unresolved_conflicts", [])
    if conflicts and adjudication.get("permission_requested") in {"research_candidate", "execute"}:
        blockers.append("integrated_adjudication_unresolved_conflicts_before_permission")
        next_evidence.append("retain_competing_paths_until_conflict_is_resolved_by_state_evidence")
    if adjudication.get("target_completed") is True and adjudication.get("immediate_reversal_claimed") is True:
        blockers.append("integrated_adjudication_completed_target_claims_immediate_reversal")
    return blockers, next_evidence


def _structural_transition_gates(transition: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Require a parent-aware chain for claimed MSS/CHOCH task replacement."""
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not transition:
        return blockers, next_evidence

    classification = transition.get("classification")
    if classification not in {"local_countermove", "parent_transition_candidate", "accepted_parent_replacement", "unknown"}:
        blockers.append("structural_transition_classification_invalid")
    if not _truthy(transition, "parent_task_id") or not _truthy(transition, "parent_protected_object_id"):
        blockers.append("structural_transition_parent_task_or_protected_object_unknown")
        next_evidence.append("name_parent_task_and_protected_object_for_mss_claim")
    if transition.get("mss_or_choch_claimed") is True:
        required = ("broken_object_id", "first_opposite_leg_force", "break_type")
        if not _all_true(transition, required):
            blockers.append("mss_choch_without_broken_object_or_opposite_force")
        if transition.get("break_type") not in {"wick", "body_close", "accepted"}:
            blockers.append("mss_choch_break_type_invalid")
    if transition.get("mss_plus_three_push_claimed") is True and transition.get("parent_background_resolved") is not True:
        blockers.append("mss_three_push_without_parent_background_resolution")
        next_evidence.append("resolve_active_parent_background_before_using_mss_three_push")
    if classification == "accepted_parent_replacement":
        required = ("break_type_accepted", "old_task_recovery_failed", "acceptance_follow_through")
        if not _all_true(transition, required):
            blockers.append("accepted_parent_replacement_without_acceptance_and_failed_recovery")
            next_evidence.append("record_parent_acceptance_and_failed_old_task_recovery")
    if transition.get("gap_overlap_claims_all_failure") is True:
        blockers.append("gap_overlap_claims_structure_ob_and_dol_failure")
    return blockers, next_evidence


def _vp_wyckoff_balance_gates(vp: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Keep VP/Wyckoff as a reproducible balance aid, never a direction vote.

    The generic VP fields remain enough for a simple location map. These gates
    activate only when a richer claim is made: acceptance, range projection or
    a direct entry after high-force balance.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not vp:
        return blockers, next_evidence

    if vp.get("order_book_or_account_truth_claimed") is True:
        blockers.append("vp_claims_unobservable_order_book_or_institutional_account_truth")

    if vp.get("balance_acceptance_claimed") is True:
        required = ("profile_id", "prior_value_boundary_id", "new_balance_id", "parent_task_id", "price_action_acceptance")
        if not _all_true(vp, required):
            blockers.append("vp_balance_acceptance_without_profile_boundary_new_balance_parent_and_price_action")
            next_evidence.append("record_profile_boundary_new_balance_parent_task_and_closed_price_action")
        if vp.get("retest_state") not in {"not_seen", "held", "failed", "accepted_back_inside", "unknown"}:
            blockers.append("vp_balance_retest_state_invalid")
        if vp.get("parent_target_state") == "completed" and vp.get("continuation_from_old_balance_claimed") is True:
            blockers.append("vp_old_balance_continuation_after_parent_target_completed")
            next_evidence.append("rebuild_parent_task_and_profile_after_completed_target")

    if vp.get("range_measurement_claimed") is True:
        required = ("profile_id", "profile_range_id", "range_start_end", "measurement_anchor_side", "target_id", "parent_task_id", "price_distribution_enabled")
        if not _all_true(vp, required):
            blockers.append("vp_range_measurement_without_reproducible_range_anchor_target_parent_and_distribution")
            next_evidence.append("record_profile_range_anchor_target_parent_and_distribution_settings")
        if vp.get("parent_target_state_at_measurement") == "completed":
            blockers.append("vp_range_measurement_extends_completed_parent_task")

    if vp.get("direct_high_force_balance_claimed") is True:
        required = (
            "parent_task_id", "creator_leg_id", "creator_structure_identity", "creator_closed_response",
            "new_balance_id", "local_sweep_object_id", "execution_chain_complete",
        )
        if not _all_true(vp, required) or vp.get("parent_dol_state") not in {"active", "approaching_target"}:
            blockers.append("vp_direct_high_force_balance_without_active_parent_creator_balance_sweep_and_execution_chain")
            next_evidence.append("bind_high_force_balance_to_active_parent_creator_close_local_sweep_and_execution_chain")
        if vp.get("retest_state") in {"failed", "accepted_back_inside"}:
            blockers.append("vp_direct_high_force_balance_failed_retest")

    return blockers, next_evidence


def _multitimeframe_background_gates(background: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Prevent nested measurements and Weekly timing from replacing parent authority."""
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not background:
        return blockers, next_evidence

    # Keep the missing object explicit.  A live candidate can have a valid
    # cutoff and current-task identity while still lacking a named parent;
    # collapsing all three into one blocker obscures the next useful action.
    if not _truthy(background, "as_of_utc"):
        blockers.append("multitimeframe_background_asof_missing")
    if not _truthy(background, "parent_task_id"):
        blockers.append("multitimeframe_background_parent_task_missing")
    if not _truthy(background, "current_task_id"):
        blockers.append("multitimeframe_background_current_task_missing")
    if background.get("child_overrides_parent") is True:
        blockers.append("multitimeframe_child_claims_direct_parent_override")
        next_evidence.append("use_parent_structure_transition_chain_before_replacing_parent_task")
    if background.get("delivery_stage_mapping_status") not in {"mapped", "competing", "unknown"}:
        blockers.append("multitimeframe_delivery_stage_mapping_invalid")
    if background.get("parent_dol_state") == "completed" and background.get("target_lifecycle_action") == "continue":
        blockers.append("multitimeframe_continues_completed_parent_task")
        next_evidence.append("retire_old_delivery_and_rebuild_parent_background")
    if background.get("weekly_role") in {"timing_candidate", "validated_path"}:
        required = ("candidate_release_window", "named_liquidity_object_id", "parent_background_checked")
        if not _all_true(background, required):
            blockers.append("weekly_binding_without_release_window_object_and_parent_background")
            next_evidence.append("bind_weekly_timing_to_named_object_and_checked_parent_background")
        if background.get("event_name_direction_claimed") is True:
            blockers.append("weekly_binding_event_name_claims_direction")
    for relation in background.get("measurement_relations", []):
        if not isinstance(relation, dict):
            blockers.append("multitimeframe_measurement_relation_invalid")
            continue
        if relation.get("relation_type") not in {"child_projection", "parent_pullback_map", "serial_relay", "spatial_coupling", "unknown"}:
            blockers.append("multitimeframe_measurement_relation_type_invalid")
        if not _all_true(relation, ("source_leg_ids", "parent_task_id", "origin_and_anchor_recorded")):
            blockers.append("multitimeframe_measurement_without_leg_parent_origin_and_anchor")
        if relation.get("relation_type") == "spatial_coupling" and relation.get("independent_measurement_roles_recorded") is not True:
            blockers.append("multitimeframe_spatial_coupling_without_separate_measurement_roles")
        if relation.get("target_state_at_claim") == "completed" and relation.get("permission") == "supports_existing_chain":
            blockers.append("multitimeframe_completed_measurement_extends_old_delivery")
    return blockers, next_evidence


def _kline86_permission_gates(context: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Apply Kline86 as closed-bar/market-state discipline, not a bar signal bot."""
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not context:
        return blockers, next_evidence
    if context.get("observed_on_closed_bar") != "yes":
        blockers.append("kline86_signal_not_observed_on_closed_bar")
        next_evidence.append("wait_for_closed_bar_before_kline86_permission")
    if context.get("autonomous_direction_forbidden") is not True:
        blockers.append("kline86_claims_autonomous_bar_direction")
    container = context.get("container")
    if container not in {"trend", "range", "barb_wire", "unknown"}:
        blockers.append("kline86_container_invalid")
    if context.get("location_in_container") not in {"edge", "middle", "outside", "unknown"}:
        blockers.append("kline86_location_invalid")
    if not _truthy(context, "named_boundary_id"):
        blockers.append("kline86_named_boundary_missing")
        next_evidence.append("name_range_edge_trendline_or_structure_boundary")
    bar_quality = context.get("bar_quality") or {}
    for key in ("body_direction", "close_location", "wick_asymmetry", "overlap_with_prior"):
        if key not in bar_quality:
            blockers.append(f"kline86_bar_quality_{key}_missing")
    if container in {"range", "barb_wire"} and context.get("location_in_container") == "middle" and context.get("direct_entry_claimed") is True:
        blockers.append("kline86_direct_entry_in_range_middle_or_barb_wire")
        next_evidence.append("wait_for_named_edge_failed_break_or_accepted_escape")
    if context.get("second_attempt_claimed") is True:
        if (
            not _truthy(context, "named_boundary_id")
            or context.get("first_attempt_outcome") not in {"failed", "held", "accepted"}
            or context.get("closed_response") is not True
        ):
            blockers.append("kline86_second_attempt_without_first_outcome_boundary_and_close")
        if context.get("opposite_follow_through") not in {"weak", "clear"}:
            blockers.append("kline86_second_attempt_without_followthrough")
    if context.get("strong_reversal_claimed") is True:
        required = ("trendline_or_structure_break_id", "first_opposite_leg_closed", "old_path_recovery_state", "opposite_follow_through")
        if not _all_true(context, required) or context.get("opposite_follow_through") not in {"weak", "clear"}:
            blockers.append("kline86_strong_reversal_without_break_closed_leg_recovery_test_and_followthrough")
            next_evidence.append("record_break_closed_first_leg_old_path_test_and_opposite_follow_through")
    if context.get("source_specific_parameter_promoted_to_global") is True:
        blockers.append("kline86_source_specific_parameter_promoted_to_global_threshold")
    if context.get("parent_override_claimed") is True and context.get("parent_acceptance_confirmed") is not True:
        blockers.append("kline86_parent_override_without_parent_acceptance")
        next_evidence.append("record_parent_scale_close_acceptance_before_override")
    return blockers, next_evidence


def _threepush_measurement_gates(measurement: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Keep three-push/three-wave geometry as a state map until its full chain exists."""
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not measurement:
        return blockers, next_evidence
    classification = measurement.get("classification")
    if classification not in {"three_push", "three_wave", "ambiguous", "unknown"}:
        blockers.append("threepush_threewave_classification_invalid")
    if not _all_true(measurement, ("container_id", "task_id", "timeframe")):
        blockers.append("threepush_measurement_missing_container_task_or_timeframe")
    if classification == "three_push" and not _all_true(measurement, ("p1_id", "p2_id", "p3_id")):
        blockers.append("threepush_claim_without_three_named_pushes")
    if classification == "three_wave" and measurement.get("fvg_role") != "required_for_three_wave":
        blockers.append("threewave_claim_without_required_impulsive_fvg_role")
    if measurement.get("measurement_model") in {"two_leg_1to1", "p1_plus_p2_equals_p3", "p1_equals_p2_plus_p3"} and measurement.get("anchors_locked_as_of") is not True:
        blockers.append("threepush_measurement_anchors_not_locked_asof")
    if measurement.get("autonomous_direction_forbidden") is not True:
        blockers.append("threepush_measurement_claims_autonomous_direction")
    if measurement.get("pierce_reversal_claimed") is True:
        required = ("pierce_reference_bar_id", "closed_response", "parent_task_relation")
        if not _all_true(measurement, required) or measurement.get("closed_response") not in {"reclaim", "accepted_break"}:
            blockers.append("threepush_pierce_without_named_bar_closed_response_and_parent_relation")
    if measurement.get("model4_ratio_selection_rule_known") is True:
        blockers.append("model4_ratio_selection_rule_prematurely_claimed_known")
    return blockers, next_evidence


def _same_leg_sweep_recovery_gates(
    measurements: List[Dict[str, Any]], task_as_of: Any,
) -> tuple[List[str], List[str]]:
    """Protect the user-supplied 127.2 -> 168/200 model from hindsight re-anchoring.

    This is not a fixed-ratio trading rule.  It applies only when a case
    explicitly instantiates that same-leg recovery family.  A wick, a close
    below, a reclaim and acceptance below must remain separate observations;
    a later swing cannot silently repair the ruler used before the sweep.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not isinstance(measurements, list):
        return blockers, next_evidence

    families = {
        "first_leg_extension_1272",
        "same_leg_post_sweep_redelivery_168",
        "same_leg_post_sweep_redelivery_200",
    }
    active_measurements = [
        item for item in measurements
        if isinstance(item, dict) and (
            item.get("projection_family") in families
            or item.get("measurement_mode") == "same_bull_leg_sweep_recovery"
        )
    ]
    if not active_measurements:
        return blockers, next_evidence

    cutoff = _iso_time(task_as_of)
    by_id = {
        item.get("measurement_id"): item
        for item in active_measurements
        if _truthy(item, "measurement_id")
    }
    sweep_states = {
        "unreached", "wick_or_intrabar_breach", "belonging_timeframe_close_below",
        "reclaimed_pending_retest", "accepted_below", "resumed_delivery", "unknown",
    }
    continuity_states = {
        "original_anchors_and_parent_task_intact", "pending_reacceptance",
        "retired_by_acceptance_or_parent_reset", "unknown",
    }
    redelivery_families = {
        "same_leg_post_sweep_redelivery_168",
        "same_leg_post_sweep_redelivery_200",
    }

    for measurement in active_measurements:
        required = (
            "same_leg_anchor_leg_id", "anchor_lock_state", "anchor_locked_at_utc",
            "sweep_object_id", "sweep_event_timeframe", "sweep_state",
            "same_leg_continuity_state",
        )
        if not all(_truthy(measurement, field) for field in required):
            blockers.append("same_leg_sweep_recovery_lifecycle_incomplete")
            next_evidence.append("record_original_leg_anchor_lock_sweep_object_timeframe_and_continuity")
            continue
        if measurement.get("same_leg_anchor_leg_id") != measurement.get("of_leg_id"):
            blockers.append("same_leg_sweep_recovery_anchor_leg_mismatch")
        if measurement.get("anchor_lock_state") != "locked_as_of":
            blockers.append("same_leg_sweep_recovery_anchor_not_locked_asof")
        locked_at = _iso_time(measurement.get("anchor_locked_at_utc"))
        if locked_at is None:
            blockers.append("same_leg_sweep_recovery_anchor_lock_time_invalid")
        elif cutoff is not None and locked_at > cutoff:
            blockers.append("same_leg_sweep_recovery_anchor_locked_after_task_asof")
        if measurement.get("sweep_event_timeframe") not in {"W1", "D1", "H4", "H1", "M30", "M15", "M5", "M1"}:
            blockers.append("same_leg_sweep_recovery_sweep_timeframe_invalid")
        if measurement.get("sweep_state") not in sweep_states:
            blockers.append("same_leg_sweep_recovery_sweep_state_invalid")
        if measurement.get("same_leg_continuity_state") not in continuity_states:
            blockers.append("same_leg_sweep_recovery_continuity_state_invalid")
        if (
            measurement.get("sweep_state") == "accepted_below"
            and measurement.get("same_leg_continuity_state") != "retired_by_acceptance_or_parent_reset"
        ):
            blockers.append("same_leg_sweep_recovery_accepted_below_without_leg_retirement")

        if measurement.get("projection_family") not in redelivery_families:
            continue
        origin_id = measurement.get("origin_sweep_measurement_id")
        origin = by_id.get(origin_id)
        if not isinstance(origin, dict) or origin.get("projection_family") != "first_leg_extension_1272":
            blockers.append("same_leg_redelivery_without_linked_1272_measurement")
            next_evidence.append("link_168_200_candidate_to_a_named_same_leg_1272_measurement")
            continue
        if origin.get("same_leg_anchor_leg_id") != measurement.get("same_leg_anchor_leg_id"):
            blockers.append("same_leg_redelivery_anchor_changed_after_sweep")
        if origin.get("sweep_state") == "accepted_below" or origin.get("same_leg_continuity_state") == "retired_by_acceptance_or_parent_reset":
            blockers.append("same_leg_redelivery_retains_retired_original_leg")
        authorization = measurement.get("redelivery_authorization_state")
        if authorization not in {"not_open", "candidate_after_reacceptance", "active_after_new_delivery", "retired", "unknown"}:
            blockers.append("same_leg_redelivery_authorization_invalid")
        requires_recovery = authorization in {"candidate_after_reacceptance", "active_after_new_delivery"} or measurement.get("target_state") in {"active", "approaching"}
        evidence = measurement.get("post_sweep_recovery_evidence_ids")
        if requires_recovery and (not isinstance(evidence, list) or not evidence):
            blockers.append("same_leg_redelivery_without_post_sweep_recovery_evidence")
            next_evidence.append("record_new_closed_reclaim_retest_or_delivery_evidence_before_168_200_authority")

    return blockers, next_evidence


def _nested_delivery_task_gates(task: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Audit a parent/child delivery task and its measurement coupling.

    The record represents the user-supplied M30/M15/M5 examples: a parent
    delivery task can meet a child 1:1, a third push and a named location in
    one band.  That overlap only creates a location for review.  It never
    lets a later-selected anchor, duplicated creator-leg evidence, or a child
    reclaim replace the parent task.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not task or task.get("recorded") is not True:
        return blockers, next_evidence

    identity_fields = (
        "task_id", "as_of_timestamp", "instrument_and_quote_source",
        "timeframe", "source_evidence_ids", "known_at_decision",
        "unknown_at_decision",
    )
    if not all(_truthy(task, field) for field in identity_fields):
        blockers.append("nested_delivery_task_identity_or_asof_boundary_missing")
        next_evidence.append("bind_task_timeframe_source_and_known_unknown_boundary")

    parent = task.get("parent_delivery_task") or {}
    if task.get("claims_parent_replacement") is True:
        if parent.get("parent_acceptance_state") != "accepted":
            blockers.append("nested_delivery_task_parent_replacement_without_parent_acceptance")
            next_evidence.append("record_parent_protected_node_failure_and_parent_timeframe_acceptance")

    measurements = task.get("measurements", [])
    if not isinstance(measurements, list):
        blockers.append("nested_delivery_task_measurement_ledger_invalid")
        measurements = []
    measurement_ids = set()
    causal_clusters: Dict[str, int] = {}
    for measurement in measurements:
        if not isinstance(measurement, dict):
            blockers.append("nested_delivery_task_measurement_invalid")
            continue
        required = (
            "measurement_id", "of_leg_id", "timeframe_scope", "start_anchor_id",
            "end_anchor_id", "anchor_convention", "ratio_or_projection",
            "projection_family", "anchor_known_at", "target_band", "causal_cluster_id",
            "target_state",
        )
        if not all(_truthy(measurement, field) for field in required):
            blockers.append("nested_delivery_task_measurement_anchor_or_asof_missing")
            continue
        measurement_ids.add(measurement["measurement_id"])
        cluster = measurement["causal_cluster_id"]
        causal_clusters[cluster] = causal_clusters.get(cluster, 0) + 1

    recovery_blockers, recovery_next_evidence = _same_leg_sweep_recovery_gates(
        measurements, task.get("as_of_timestamp"),
    )
    blockers.extend(recovery_blockers)
    next_evidence.extend(recovery_next_evidence)

    coupling = task.get("measurement_coupling") or {}
    if coupling.get("claimed") is True:
        coupled_ids = coupling.get("measurement_ids")
        if not isinstance(coupled_ids, list) or len(coupled_ids) < 2 or not all(mid in measurement_ids for mid in coupled_ids):
            blockers.append("nested_delivery_task_coupling_without_independent_named_measurements")
            next_evidence.append("record_two_or_more_independently_anchored_measurements_known_asof")
        if not _truthy(coupling, "overlap_band"):
            blockers.append("nested_delivery_task_coupling_without_price_band")
            next_evidence.append("record_overlap_as_price_band_not_exact_tick")
        if coupling.get("parent_task_compatibility") not in {
            "aligned", "local_counter_task_bounded", "parent_reprice_review",
        }:
            blockers.append("nested_delivery_task_coupling_parent_compatibility_unresolved")
        if coupling.get("deduplicated_causal_clusters") is not True:
            blockers.append("nested_delivery_task_coupling_same_source_not_deduplicated")
            next_evidence.append("collapse_measurements_from_same_creator_leg_leave_candle_or_gap_cluster")
        if coupling.get("claims_execution_candidate") is True:
            required_process = {"sweep_or_object_process", "belonging_timeframe_close", "retest_state", "creator_leg_state"}
            if not required_process.issubset(set(coupling.get("process_evidence", []))):
                blockers.append("nested_delivery_task_coupling_execution_without_process_chain")
                next_evidence.append("record_object_process_close_retest_and_aligned_creator_leg")

    if any(count > 1 for count in causal_clusters.values()) and coupling.get("deduplicated_causal_clusters") is not True:
        blockers.append("nested_delivery_task_duplicate_causal_cluster_counted_as_confluence")

    false_balance = task.get("false_balance") or {}
    if false_balance.get("claims_constructed_reclaim") is True:
        required = ("relevant_line_or_range_id", "outside_side", "bar_close_ids", "reclaim_state")
        if not all(_truthy(false_balance, field) for field in required) or false_balance.get("reclaim_state") not in {"B2", "B3", "B4"}:
            blockers.append("nested_delivery_task_constructed_reclaim_without_line_and_closed_process")
        if false_balance.get("reclaim_state") == "B4" and false_balance.get("creator_leg_state") != "aligned_present":
            blockers.append("nested_delivery_task_constructed_reclaim_without_aligned_creator_leg")
        if false_balance.get("claims_parent_replacement") is True and parent.get("parent_acceptance_state") != "accepted":
            blockers.append("nested_delivery_task_constructed_reclaim_claims_parent_replacement")

    if task.get("autonomous_direction_claimed") is True:
        blockers.append("nested_delivery_task_claims_autonomous_direction")
    return blockers, next_evidence


def _trade_construction_pipeline_gates(pipeline: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Enforce Alexander's task -> pullback -> entry-route order of work."""
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not pipeline or pipeline.get("recorded") is not True:
        return blockers, next_evidence

    if pipeline.get("working_timeframe") not in {"M1", "M5", "M15", "M30", "H1", "H4", "D1"}:
        blockers.append("trade_pipeline_working_timeframe_not_selected")
    if pipeline.get("holding_scope") not in {"child_delivery", "parent_aligned_swing", "bounded_countertask", "parent_replacement_review"}:
        blockers.append("trade_pipeline_holding_scope_not_selected")
    if not _truthy(pipeline, "parent_task_id") or not _truthy(pipeline, "direction_task_id"):
        blockers.append("trade_pipeline_parent_or_direction_task_missing")
        next_evidence.append("name_parent_task_and_the_delivery_direction_being_traded")
    if pipeline.get("direction_side") not in {None, "long", "short", "unknown"}:
        blockers.append("trade_pipeline_direction_side_invalid")
    if pipeline.get("background_state") not in {"resolved", "two_sided", "unknown"}:
        blockers.append("trade_pipeline_background_state_invalid")
    if pipeline.get("small_tf_background_state") not in {None, "trend", "range", "pullback", "terminal", "unknown"}:
        blockers.append("trade_pipeline_small_timeframe_background_invalid")
    if pipeline.get("trend_position") not in {None, "start", "continuation", "late_target_approach", "pullback", "reprice", "unknown"}:
        blockers.append("trade_pipeline_trend_position_invalid")
    if pipeline.get("pullback_state") not in {
        "P0_active_pullback", "P1_location_reached", "P2_liquidity_review", "P3_force_start",
        "P4_current_tf_confirmation", "P5_distribution_or_reentry_ready", "PX_continuation_or_reprice", "unknown",
    }:
        blockers.append("trade_pipeline_pullback_state_invalid")
    if pipeline.get("route_is_not_direction_engine") is not True:
        blockers.append("trade_pipeline_entry_route_claims_to_create_direction")

    route = pipeline.get("entry_route")
    valid_routes = {
        "snr_retest", "ob_or_fvg_revisit", "50_ote_location", "second_sweep_or_second_build",
        "direct_pre_adjudicated_location", "target_direct_reversal_candidate", "none", "unknown",
    }
    if route not in valid_routes:
        blockers.append("trade_pipeline_entry_route_invalid")
        return blockers, next_evidence
    # Management can be asserted for an already-held position even when no
    # fresh entry route is selected. Do not let that path bypass the guard.
    if pipeline.get("management_action_claimed") is True and pipeline.get("post_entry_progress_state") != "trend_established":
        blockers.append("trade_pipeline_management_change_without_established_post_entry_trend")
    if route in {"none", "unknown"}:
        return blockers, next_evidence

    if pipeline.get("background_state") != "resolved":
        blockers.append("trade_pipeline_entry_selected_before_background_resolved")
    if pipeline.get("direction_side") not in {"long", "short"}:
        blockers.append("trade_pipeline_entry_without_explicit_direction_side")
    parent_target_state = pipeline.get("parent_target_state")
    if route != "target_direct_reversal_candidate" and parent_target_state not in {"active", "approaching", "touched_under_review"}:
        blockers.append("trade_pipeline_entry_without_active_or_approaching_parent_target")
    if not _truthy(pipeline, "upstream_parent_target_id") or not _truthy(pipeline, "downstream_measurement_target_id"):
        blockers.append("trade_pipeline_entry_without_separate_parent_and_downstream_targets")
    if not _truthy(pipeline, "parent_direction_basis_ids") or not _truthy(pipeline, "parent_unfinished_delivery_ids"):
        blockers.append("trade_pipeline_entry_without_parent_direction_and_unfinished_delivery_evidence")
    if pipeline.get("small_tf_background_state") in {None, "unknown"} or pipeline.get("trend_position") in {None, "unknown"}:
        blockers.append("trade_pipeline_entry_without_small_timeframe_background_and_trend_position")
    if pipeline.get("pullback_completion_state") not in {"candidate", "current_tf_confirmed"}:
        blockers.append("trade_pipeline_entry_without_pullback_completion_state")
    if not _truthy(pipeline, "measurement_ledger_ids") or not _truthy(pipeline, "retracement_amplitude_ledger_ids") or not _truthy(pipeline, "liquidity_object_ids"):
        blockers.append("trade_pipeline_entry_without_measurement_and_liquidity_ledger")
    if pipeline.get("liquidity_clearance_assessment") not in {"insufficient_or_second_sweep_live", "processed_under_review", "processed_with_current_tf_confirmation"} or not _truthy(pipeline, "liquidity_clearance_evidence_ids"):
        blockers.append("trade_pipeline_entry_without_liquidity_clearance_assessment")
    if pipeline.get("liquidity_clearance_assessment") == "insufficient_or_second_sweep_live":
        blockers.append("trade_pipeline_entry_while_liquidity_or_second_sweep_unresolved")
        next_evidence.append("observe_named_second_sweep_or_reassessment_of_liquidity_clearance_before_entry_research")
    if pipeline.get("force_progression_state") not in {"current_tf_confirmed", "parent_acceptance_pending"}:
        blockers.append("trade_pipeline_entry_without_current_timeframe_force_progression")
        next_evidence.append("observe_child_to_current_timeframe_force_and_structure_progression")
    if not _truthy(pipeline, "force_progression_evidence_ids"):
        blockers.append("trade_pipeline_entry_without_force_progression_evidence")
    if not _truthy(pipeline, "invalidation_node_id") or not _truthy(pipeline, "first_target_id"):
        blockers.append("trade_pipeline_entry_without_invalidation_and_next_target")

    direct_exception = route == "direct_pre_adjudicated_location"
    if direct_exception:
        if pipeline.get("direct_exception_pre_adjudicated") is not True:
            blockers.append("trade_pipeline_direct_entry_without_pre_adjudicated_build_or_gap")
        if not _truthy(pipeline, "prior_adjudication_evidence_ids"):
            blockers.append("trade_pipeline_direct_entry_without_prior_adjudication_evidence")
        if pipeline.get("right_side_state") != "not_required_by_audited_exception":
            blockers.append("trade_pipeline_direct_entry_exception_not_audited")
    else:
        if pipeline.get("pullback_state") not in {"P4_current_tf_confirmation", "P5_distribution_or_reentry_ready"}:
            blockers.append("trade_pipeline_entry_before_pullback_confirmation")
        if pipeline.get("right_side_state") != "closed_and_held":
            blockers.append("trade_pipeline_non_direct_entry_without_closed_right_side")
        if not _truthy(pipeline, "route_selection_basis_ids"):
            blockers.append("trade_pipeline_non_direct_entry_without_route_selection_basis")

    if route == "second_sweep_or_second_build" and pipeline.get("pullback_state") not in {"P2_liquidity_review", "P3_force_start", "P4_current_tf_confirmation", "P5_distribution_or_reentry_ready"}:
        blockers.append("trade_pipeline_second_sweep_without_prior_liquidity_review")
    if route == "second_sweep_or_second_build" and pipeline.get("liquidity_clearance_assessment") != "processed_with_current_tf_confirmation":
        blockers.append("trade_pipeline_second_sweep_route_without_completed_processing_and_current_tf_confirmation")
        next_evidence.append("bind_second_sweep_object_reclaim_and_current_timeframe_force_close_before_second_sweep_entry_research")
    if route == "target_direct_reversal_candidate" and pipeline.get("parent_target_state") not in {"touched_under_review", "completed_with_acceptance"}:
        blockers.append("trade_pipeline_target_reversal_without_parent_target_review")
    pierce_branch = pipeline.get("pierce_branch")
    if pierce_branch not in {None, "continuation_break", "retest_second_event", "unknown"}:
        blockers.append("trade_pipeline_pierce_branch_invalid")
    if pierce_branch in {"continuation_break", "retest_second_event"} and not _truthy(pipeline, "pierce_anchor_bar_or_node_id"):
        blockers.append("trade_pipeline_pierce_branch_without_named_anchor")
    if pipeline.get("claims_parent_replacement") is True and pipeline.get("parent_acceptance_state") != "accepted":
        blockers.append("trade_pipeline_parent_replacement_without_parent_acceptance")
    return blockers, next_evidence


def _trade_route_reprioritization_gates(
    pipeline: Dict[str, Any], spine: Dict[str, Any], decision_cutoff_utc: Any,
    declared_source_refs: set[str],
) -> tuple[List[str], List[str]]:
    """Audit a source-time route-priority revision without creating a signal.

    A base or a weak first force can change which pullback path deserves the
    next observation. It cannot eliminate a second sweep or confirm a parent
    reversal. The record is optional; once asserted, its provenance and
    force-to-node relation must be explicit.
    """
    review = pipeline.get("route_reprioritization") if isinstance(pipeline, dict) else None
    if review is None:
        return [], []
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not isinstance(review, dict):
        return ["trade_route_reprioritization_record_invalid"], []
    if pipeline.get("recorded") is not True:
        blockers.append("trade_route_reprioritization_pipeline_not_recorded")
    if review.get("status") not in {"candidate", "revised", "invalidated", "unknown"}:
        blockers.append("trade_route_reprioritization_status_invalid")
    if review.get("parent_task_id") != pipeline.get("parent_task_id"):
        blockers.append("trade_route_reprioritization_parent_task_mismatch")
    if review.get("working_timeframe") != pipeline.get("working_timeframe"):
        blockers.append("trade_route_reprioritization_working_timeframe_mismatch")
    observed = _iso_time(review.get("observed_at_utc"))
    cutoff = _iso_time(decision_cutoff_utc)
    if observed is None or cutoff is None:
        blockers.append("trade_route_reprioritization_asof_missing_or_invalid")
    elif observed > cutoff:
        blockers.append("trade_route_reprioritization_after_decision_cutoff")
    refs = review.get("source_refs")
    if not isinstance(refs, list) or not refs or any(not isinstance(ref, str) or not ref for ref in refs):
        blockers.append("trade_route_reprioritization_source_missing")
    elif any(ref not in declared_source_refs for ref in refs):
        blockers.append("trade_route_reprioritization_source_unregistered")
    allowed_priority = {"live", "deprioritized", "reopened", "unknown"}
    if review.get("deep_revisit_priority") not in allowed_priority:
        blockers.append("trade_route_reprioritization_deep_revisit_priority_invalid")
    if review.get("second_sweep_priority") not in allowed_priority:
        blockers.append("trade_route_reprioritization_second_sweep_priority_invalid")
    if review.get("claims_deep_revisit_impossible") is True or review.get("claims_second_sweep_impossible") is True:
        blockers.append("trade_route_reprioritization_disfavored_path_claimed_impossible")
    if review.get("claims_parent_replacement") is True:
        blockers.append("trade_route_reprioritization_claims_parent_replacement")
    allowed_routes = {
        "snr_retest", "ob_or_fvg_revisit", "50_ote_location", "second_sweep_or_second_build",
        "direct_pre_adjudicated_location", "target_direct_reversal_candidate", "none", "unknown",
    }
    if review.get("favored_entry_route", "unknown") not in allowed_routes:
        blockers.append("trade_route_reprioritization_favored_route_invalid")
    if review.get("route_selected_from_revision") is True and review.get("status") != "revised":
        blockers.append("trade_route_reprioritization_candidate_claims_route_selection")
    if (review.get("status") != "revised"
            and (review.get("deep_revisit_priority") == "deprioritized"
                 or review.get("second_sweep_priority") == "deprioritized")):
        blockers.append("trade_route_reprioritization_candidate_cannot_deprioritize_path")

    history = review.get("priority_events")
    if review.get("status") in {"revised", "invalidated"} and (
            not isinstance(history, list) or len(history) < 2):
        blockers.append("trade_route_reprioritization_transition_history_missing")
    if isinstance(history, list):
        previous_time = None
        event_types = []
        for index, event in enumerate(history):
            if not isinstance(event, dict):
                blockers.append("trade_route_reprioritization_event_invalid")
                continue
            kind = event.get("event_type")
            event_types.append(kind)
            if kind not in {"initial_review", "base_support_revision", "base_failure_reopen"}:
                blockers.append("trade_route_reprioritization_event_type_invalid")
            event_time = _iso_time(event.get("observed_at_utc"))
            evidence_time = _iso_time(event.get("evidence_available_at_utc"))
            if event_time is None or evidence_time is None:
                blockers.append("trade_route_reprioritization_event_time_invalid")
            else:
                if (previous_time is not None and event_time <= previous_time) or (
                        cutoff is not None and event_time > cutoff) or (
                        observed is not None and event_time > observed) or evidence_time > event_time:
                    blockers.append("trade_route_reprioritization_event_time_order_or_cutoff_invalid")
                previous_time = event_time
            event_refs = event.get("source_refs")
            if (not isinstance(event_refs, list) or not event_refs
                    or any(not isinstance(ref, str) or ref not in declared_source_refs for ref in event_refs)):
                blockers.append("trade_route_reprioritization_event_source_unregistered")
            for field in ("deep_revisit_priority", "second_sweep_priority"):
                if event.get(field) not in allowed_priority:
                    blockers.append("trade_route_reprioritization_event_priority_invalid")
            if index == 0 and (kind != "initial_review" or any(
                    event.get(field) not in {"live", "unknown"}
                    for field in ("deep_revisit_priority", "second_sweep_priority"))):
                blockers.append("trade_route_reprioritization_initial_state_invalid")
            if index > 0 and isinstance(history[index - 1], dict):
                prior = history[index - 1]
                allowed_next = {
                    "initial_review": "base_support_revision",
                    "base_support_revision": "base_failure_reopen",
                    "base_failure_reopen": "base_support_revision",
                }
                if (kind != allowed_next.get(prior.get("event_type"))
                        or all(event.get(field) == prior.get(field)
                               for field in ("deep_revisit_priority", "second_sweep_priority"))):
                    blockers.append("trade_route_reprioritization_event_transition_invalid")
        if history and isinstance(history[-1], dict):
            last = history[-1]
            if any(last.get(field) != review.get(field)
                   for field in ("deep_revisit_priority", "second_sweep_priority")):
                blockers.append("trade_route_reprioritization_summary_not_latest_event")
            if review.get("status") == "revised" and last.get("event_type") != "base_support_revision":
                blockers.append("trade_route_reprioritization_revision_event_missing")
            if review.get("status") == "invalidated":
                if (last.get("event_type") != "base_failure_reopen"
                        or "base_support_revision" not in event_types[:-1]
                        or not any(last.get(field) == "reopened"
                                   for field in ("deep_revisit_priority", "second_sweep_priority"))
                        or any(last.get(field) not in {"live", "reopened"}
                               for field in ("deep_revisit_priority", "second_sweep_priority"))):
                    blockers.append("trade_route_reprioritization_reopen_transition_invalid")

    if review.get("status") == "invalidated":
        if (review.get("trigger") != "base_failure_after_prior_revision"
                or review.get("base_state") != "failed"):
            blockers.append("trade_route_reprioritization_reopen_without_failed_base")
        failure_refs = review.get("base_failure_evidence_ids")
        if (not isinstance(failure_refs, list) or not failure_refs
                or any(not isinstance(ref, str) or ref not in declared_source_refs for ref in failure_refs)):
            blockers.append("trade_route_reprioritization_reopen_without_failure_evidence")

    if review.get("status") == "revised":
        if review.get("trigger") != "base_support_after_force_to_node" or review.get("base_state") != "supported":
            blockers.append("trade_route_reprioritization_revised_without_supported_base_and_force")
        if review.get("parent_target_relation") not in {"active", "approaching", "under_review"}:
            blockers.append("trade_route_reprioritization_revised_without_parent_target_relation")
        target_id = review.get("parent_target_id")
        targets = [target for target in spine.get("active_target_graph", []) if isinstance(target, dict)
                   and target.get("measurement_id") == target_id]
        if (not target_id or target_id != pipeline.get("upstream_parent_target_id")
                or len(targets) != 1):
            blockers.append("trade_route_reprioritization_parent_target_not_bound")
        else:
            target_state = targets[0].get("state_record")
            expected_states = {
                "active": {"active"},
                "approaching": {"approaching"},
                "under_review": {"touched_under_review"},
            }
            if (not isinstance(target_state, dict)
                    or target_state.get("state") not in expected_states.get(review.get("parent_target_relation"), set())
                    or _iso_time(target_state.get("observed_at_utc")) is None
                    or cutoff is None
                    or _iso_time(target_state.get("observed_at_utc")) > cutoff
                    or not isinstance(target_state.get("source_refs"), list)
                    or not target_state["source_refs"]
                    or any(ref not in declared_source_refs for ref in target_state["source_refs"])):
                blockers.append("trade_route_reprioritization_parent_target_state_unverified")
        force_id = review.get("force_leg_id")
        node_id = review.get("structure_node_id")
        links = [link for link in spine.get("force_links", []) if isinstance(link, dict)
                 and link.get("force_leg_id") == force_id and link.get("node_attempted_id") == node_id]
        nodes = [node for node in spine.get("nodes", []) if isinstance(node, dict)
                 and node.get("node_id") == node_id]
        if not force_id or not node_id or len(links) != 1 or len(nodes) != 1:
            blockers.append("trade_route_reprioritization_force_node_not_bound")
            next_evidence.append("bind_asof_first_force_to_one_named_structure_node_and_parent_target")
        if (review.get("deep_revisit_priority") == "deprioritized"
                or review.get("second_sweep_priority") == "deprioritized"):
            base_refs = review.get("base_support_evidence_ids")
            if (not isinstance(base_refs, list) or not base_refs
                    or any(not isinstance(ref, str) or ref not in declared_source_refs for ref in base_refs)):
                blockers.append("trade_route_reprioritization_deprioritized_without_base_evidence")
        if (review.get("route_selected_from_revision") is True
                and review.get("favored_entry_route") != pipeline.get("entry_route")):
            blockers.append("trade_route_reprioritization_selected_route_mismatch")
    return blockers, next_evidence


def _trade_pipeline_timeframe_descent_gates(pipeline: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Require an explicit parent-to-working-timeframe path before entry research.

    Alexander's sequence is not "find an OB/FVG, then construct a bias."  The
    trader first selects the task timeframe, reads the larger task, then steps
    down through each available timeframe until the current task and its
    lower-timeframe force are understood.  This gate stores that descent as
    source-bound task records.  It does not manufacture any direction, target,
    or execution permission.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not pipeline or pipeline.get("recorded") is not True:
        return blockers, next_evidence
    if pipeline.get("entry_route") in {None, "none", "unknown"}:
        return blockers, next_evidence

    path = pipeline.get("timeframe_descent_path")
    if not isinstance(path, list) or len(path) < 2:
        blockers.append("trade_pipeline_entry_without_parent_to_working_timeframe_descent")
        next_evidence.append("record_selected_parent_to_working_timeframe_path_before_entry_route")
        return blockers, next_evidence

    seen_timeframes: set[str] = set()
    parent_task_id = pipeline.get("parent_task_id")
    direction_task_id = pipeline.get("direction_task_id")
    working_timeframe = pipeline.get("working_timeframe")
    previous_timeframe: str | None = None
    for index, record in enumerate(path):
        if not isinstance(record, dict):
            blockers.append(f"trade_pipeline_timeframe_descent_record_invalid_{index}")
            continue
        timeframe = record.get("timeframe")
        if timeframe not in _TIMEFRAME_DESCENT_RANK:
            blockers.append(f"trade_pipeline_timeframe_descent_timeframe_invalid_{index}")
            continue
        if timeframe in seen_timeframes:
            blockers.append("trade_pipeline_timeframe_descent_timeframe_duplicated")
        seen_timeframes.add(timeframe)

        if index == 0:
            if _truthy(record, "parent_timeframe"):
                blockers.append("trade_pipeline_timeframe_descent_root_has_unresolved_parent")
            if record.get("task_id") != parent_task_id:
                blockers.append("trade_pipeline_timeframe_descent_root_not_selected_parent_task")
        else:
            if record.get("parent_timeframe") != previous_timeframe:
                blockers.append(f"trade_pipeline_timeframe_descent_parent_link_missing_or_wrong_{index}")
            if previous_timeframe is not None:
                previous_rank = _TIMEFRAME_DESCENT_RANK[previous_timeframe]
                current_rank = _TIMEFRAME_DESCENT_RANK[timeframe]
                if current_rank != previous_rank + 1:
                    blockers.append("trade_pipeline_timeframe_descent_skips_intermediate_timeframe")

        if not _truthy(record, "task_id"):
            blockers.append(f"trade_pipeline_timeframe_descent_task_missing_{index}")
        if not _truthy(record, "structure_state"):
            blockers.append(f"trade_pipeline_timeframe_descent_structure_unknown_{index}")
        if not _truthy(record, "active_leg_or_structure_id"):
            blockers.append(f"trade_pipeline_timeframe_descent_active_leg_missing_{index}")
        if not _truthy(record, "protected_node_or_target_id"):
            blockers.append(f"trade_pipeline_timeframe_descent_protected_node_or_target_missing_{index}")
        evidence_ids = record.get("source_evidence_ids")
        if not isinstance(evidence_ids, list) or not evidence_ids or any(not isinstance(value, str) or not value for value in evidence_ids):
            blockers.append(f"trade_pipeline_timeframe_descent_source_evidence_missing_{index}")
        previous_timeframe = timeframe

    if path and isinstance(path[-1], dict):
        if path[-1].get("timeframe") != working_timeframe:
            blockers.append("trade_pipeline_timeframe_descent_does_not_end_at_working_timeframe")
        if path[-1].get("task_id") != direction_task_id:
            blockers.append("trade_pipeline_timeframe_descent_final_task_not_selected_direction_task")

    if blockers:
        next_evidence.append("retain_parent_task_and_each_intermediate_timeframe_state_before_selecting_OB_FVG_SNR_or_OTE_route")
    return blockers, next_evidence


def _pullback_completion_audit_gates(
    audit: Dict[str, Any],
    pipeline: Dict[str, Any],
    decision_cutoff_utc: Any = None,
    spine_asof_utc: Any = None,
    case_source_refs: set[str] | None = None,
) -> tuple[List[str], List[str]]:
    """Keep pullback termination causal instead of treating a ratio touch as completion.

    Alexander's cases separate five questions that are often collapsed into
    one label: did the measured ratio arrive, did the retracement amplitude
    finish, is liquidity sufficiently processed (or is a second sweep still
    live), did the creator force progress at the working timeframe, and did a
    belonging close/reclaim hold?  This optional ledger makes those dimensions
    independently auditable.  It deliberately contains no universal point,
    ATR, candle-count, or fixed liquidity threshold.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not audit or audit.get("recorded") is not True:
        return blockers, next_evidence

    required_identity = (
        "working_timeframe", "parent_task_id", "direction_task_id", "parent_target_or_leg_id",
    )
    for field in required_identity:
        value = audit.get(field)
        if not isinstance(value, str) or not _truthy({"value": value}, "value"):
            blockers.append(f"pullback_completion_audit_{field}_missing_or_invalid")
    audit_timeframe = audit.get("working_timeframe")
    if not isinstance(audit_timeframe, str) or audit_timeframe not in {"W1", "D1", "H4", "H1", "M30", "M15", "M5", "M1"}:
        blockers.append("pullback_completion_audit_working_timeframe_unsupported")

    for field in ("source_evidence_ids", "competing_paths"):
        value = audit.get(field)
        if not isinstance(value, list) or not value or any(
            not isinstance(item, str) or not _truthy({"value": item}, "value") for item in value
        ):
            blockers.append(f"pullback_completion_audit_{field}_missing_or_invalid")
    if case_source_refs is not None:
        refs = audit.get("source_evidence_ids")
        if isinstance(refs, list) and any(
            isinstance(ref, str) and ref not in case_source_refs for ref in refs
        ):
            blockers.append("pullback_completion_audit_source_evidence_unregistered")

    audit_time = _iso_time(audit.get("as_of_utc"))
    cutoff_time = _iso_time(decision_cutoff_utc)
    spine_time = _iso_time(spine_asof_utc)
    if audit_time is None:
        blockers.append("pullback_completion_audit_asof_invalid")
    if cutoff_time is None:
        blockers.append("pullback_completion_audit_decision_cutoff_missing_or_invalid")
    elif audit_time is not None and audit_time > cutoff_time:
        blockers.append("pullback_completion_audit_after_decision_cutoff")
    if spine_asof_utc is not None and spine_time is None:
        blockers.append("pullback_completion_audit_spine_asof_invalid")
    elif audit_time is not None and spine_time is not None and audit_time > spine_time:
        blockers.append("pullback_completion_audit_after_spine_asof")

    states = {
        "ratio_state": {"not_reached", "location_reached", "process_confirmed", "completed", "unknown"},
        "amplitude_state": {"pending", "incomplete", "completed", "unknown"},
        "liquidity_state": {
            "not_reviewed", "insufficient", "accumulation_pending", "cleared",
            "second_sweep_live", "second_sweep_complete", "unknown",
        },
        "force_state": {"none", "weak_creator", "decisive", "current_tf_confirmed", "unknown"},
        "acceptance_state": {"pending", "closed_reclaim", "held", "accepted", "failed", "unknown"},
        "termination_decision": {"pending", "candidate", "confirmed", "failed", "unknown"},
    }
    for field, allowed in states.items():
        value = audit.get(field)
        if not isinstance(value, str) or value not in allowed:
            blockers.append(f"pullback_completion_audit_{field}_invalid")

    termination_decision = audit.get("termination_decision")
    if isinstance(termination_decision, str) and termination_decision in {"candidate", "confirmed"}:
        for field in ("ratio_evidence_ids", "amplitude_evidence_ids", "liquidity_evidence_ids", "force_evidence_ids", "acceptance_evidence_ids"):
            value = audit.get(field)
            if not isinstance(value, list) or not value or any(
                not isinstance(item, str) or not _truthy({"value": item}, "value") for item in value
            ):
                blockers.append(f"pullback_completion_audit_{field}_missing_or_invalid")

    if termination_decision == "confirmed":
        ratio_state = audit.get("ratio_state")
        liquidity_state = audit.get("liquidity_state")
        force_state = audit.get("force_state")
        acceptance_state = audit.get("acceptance_state")
        if not isinstance(ratio_state, str) or ratio_state not in {"process_confirmed", "completed"}:
            blockers.append("pullback_completion_confirmed_without_ratio_process")
        if audit.get("amplitude_state") != "completed":
            blockers.append("pullback_completion_confirmed_without_amplitude_completion")
        if not isinstance(liquidity_state, str) or liquidity_state not in {"cleared", "second_sweep_complete"}:
            blockers.append("pullback_completion_confirmed_while_liquidity_remains_live")
        if not isinstance(force_state, str) or force_state not in {"decisive", "current_tf_confirmed"}:
            blockers.append("pullback_completion_confirmed_without_current_tf_force")
        if not isinstance(acceptance_state, str) or acceptance_state not in {"closed_reclaim", "held", "accepted"}:
            blockers.append("pullback_completion_confirmed_without_close_acceptance")
        if force_state == "weak_creator" or liquidity_state == "second_sweep_live":
            blockers.append("pullback_completion_weak_force_or_second_sweep_still_live")

    if audit.get("ratio_state") == "location_reached" and termination_decision == "confirmed":
        blockers.append("pullback_ratio_touch_cannot_confirm_completion")
    if pipeline.get("recorded") is True:
        if audit.get("working_timeframe") != pipeline.get("working_timeframe"):
            blockers.append("pullback_completion_audit_working_timeframe_mismatch")
        if audit.get("parent_task_id") != pipeline.get("parent_task_id"):
            blockers.append("pullback_completion_audit_parent_task_mismatch")
        if audit.get("direction_task_id") != pipeline.get("direction_task_id"):
            blockers.append("pullback_completion_audit_direction_task_mismatch")

        # These are two views of one evolving pullback, not independent votes.
        # If both ledgers are supplied, they must not claim incompatible states.
        expected_pipeline_completion = {
            "pending": "pending",
            "candidate": "candidate",
            "confirmed": "current_tf_confirmed",
            "failed": "failed",
            "unknown": "unknown",
        }.get(termination_decision) if isinstance(termination_decision, str) else None
        if (
            expected_pipeline_completion is not None
            and pipeline.get("pullback_completion_state") != expected_pipeline_completion
        ):
            blockers.append("pullback_completion_audit_pipeline_completion_state_mismatch")
        if termination_decision == "confirmed" and pipeline.get("pullback_state") not in {
            "P4_current_tf_confirmation", "P5_distribution_or_reentry_ready",
        }:
            blockers.append("pullback_completion_audit_confirmed_before_pipeline_P4")

        audit_liquidity = audit.get("liquidity_state")
        pipeline_liquidity = pipeline.get("liquidity_clearance_assessment")
        if isinstance(audit_liquidity, str) and audit_liquidity in {"not_reviewed", "unknown", "insufficient", "accumulation_pending", "second_sweep_live"} and isinstance(pipeline_liquidity, str) and pipeline_liquidity in {
            "processed_under_review", "processed_with_current_tf_confirmation",
        }:
            blockers.append("pullback_completion_audit_liquidity_state_conflicts_with_pipeline")
        if isinstance(audit_liquidity, str) and audit_liquidity in {"cleared", "second_sweep_complete"} and pipeline_liquidity == "insufficient_or_second_sweep_live":
            blockers.append("pullback_completion_audit_liquidity_state_conflicts_with_pipeline")

        audit_force = audit.get("force_state")
        pipeline_force = pipeline.get("force_progression_state")
        if isinstance(audit_force, str) and audit_force in {"none", "weak_creator", "unknown"} and isinstance(pipeline_force, str) and pipeline_force in {
            "current_tf_confirmed", "parent_acceptance_pending",
        }:
            blockers.append("pullback_completion_audit_force_state_conflicts_with_pipeline")
        if audit_force == "current_tf_confirmed" and isinstance(pipeline_force, str) and pipeline_force in {"none", "child_only", "unknown"}:
            blockers.append("pullback_completion_audit_force_state_conflicts_with_pipeline")

        audit_acceptance = audit.get("acceptance_state")
        pipeline_asserts_hold = (
            pipeline.get("right_side_state") == "closed_and_held"
            or pipeline.get("pullback_completion_state") == "current_tf_confirmed"
        )
        if isinstance(audit_acceptance, str) and audit_acceptance in {"pending", "failed", "unknown"} and pipeline_asserts_hold:
            blockers.append("pullback_completion_audit_acceptance_state_conflicts_with_pipeline")
        if isinstance(audit_acceptance, str) and audit_acceptance in {"closed_reclaim", "held", "accepted"} and pipeline.get("right_side_state") == "failed":
            blockers.append("pullback_completion_audit_acceptance_state_conflicts_with_pipeline")
    if isinstance(termination_decision, str) and termination_decision in {"pending", "candidate"}:
        next_evidence.append("separate_ratio_amplitude_liquidity_force_and_close_acceptance_before_marking_pullback_complete")
    return blockers, next_evidence


def _measurement_target_role_gates(
    spine: Dict[str, Any],
    pipeline: Dict[str, Any],
    decision_time_utc: Any,
    case_source_refs: set[str],
) -> tuple[List[str], List[str]]:
    """Bind selected entry research to explicit, as-of target roles.

    The same measured level may explicitly serve both the parent delivery and
    a downstream measurement role. Role membership is never inferred from a
    ratio name, timeframe, or what price did afterward. This gate validates
    the declared record and its cutoff; it does not verify the underlying
    chart/source content.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not pipeline or pipeline.get("recorded") is not True:
        return blockers, next_evidence

    route = pipeline.get("entry_route")
    if route in {None, "none", "unknown"}:
        return blockers, next_evidence

    graph = spine.get("active_target_graph") if isinstance(spine, dict) else None
    if not isinstance(graph, list) or not graph:
        blockers.append("trade_pipeline_entry_without_explicit_target_role_graph")
        next_evidence.append("record_parent_and_downstream_measurement_roles_with_asof_source_refs")
        return blockers, next_evidence

    allowed_roles = {
        "parent_task_delivery_target", "entry_geometry_candidate",
        "post_entry_measurement", "unknown",
    }
    targets_by_id: Dict[str, Dict[str, Any]] = {}
    for index, target in enumerate(graph):
        if not isinstance(target, dict):
            blockers.append("market_structure_spine_target_graph_entry_invalid")
            continue
        measurement_id = target.get("measurement_id")
        if not _truthy(target, "measurement_id"):
            blockers.append("market_structure_spine_target_graph_measurement_id_missing")
            continue
        if measurement_id in targets_by_id:
            blockers.append("market_structure_spine_target_graph_duplicate_measurement_id")
            continue
        targets_by_id[measurement_id] = target
        roles = target.get("roles")
        if not isinstance(roles, list) or not roles:
            roles = ["unknown"]
        if any(not isinstance(role, str) or role not in allowed_roles for role in roles):
            blockers.append(f"market_structure_spine_target_graph_roles_invalid_{index}")
            continue
        if len(set(roles)) != len(roles):
            blockers.append(f"market_structure_spine_target_graph_roles_duplicated_{index}")
        if "unknown" in roles and len(roles) > 1:
            blockers.append(f"market_structure_spine_target_graph_unknown_mixed_with_claimed_role_{index}")

    parent_id = pipeline.get("upstream_parent_target_id")
    downstream_id = pipeline.get("downstream_measurement_target_id")
    if not _truthy(pipeline, "upstream_parent_target_id"):
        blockers.append("trade_pipeline_target_role_parent_target_id_missing")
    if not _truthy(pipeline, "downstream_measurement_target_id"):
        blockers.append("trade_pipeline_target_role_downstream_measurement_id_missing")

    required_role_groups: Dict[str, List[set[str]]] = {}
    if _truthy(pipeline, "upstream_parent_target_id"):
        required_role_groups.setdefault(parent_id, []).append({"parent_task_delivery_target"})
    if _truthy(pipeline, "downstream_measurement_target_id"):
        required_role_groups.setdefault(downstream_id, []).append(
            {"entry_geometry_candidate", "post_entry_measurement"}
        )

    cutoff = _iso_time(decision_time_utc)
    spine_asof = _iso_time(spine.get("as_of_utc")) if isinstance(spine, dict) else None
    for measurement_id, required_groups in required_role_groups.items():
        target = targets_by_id.get(measurement_id)
        if target is None:
            blockers.append("trade_pipeline_target_role_id_unmapped_in_target_graph")
            next_evidence.append("map_selected_parent_and_downstream_ids_to_named_target_graph_items")
            continue
        if not _truthy(target, "timeframe"):
            blockers.append("trade_pipeline_selected_target_role_timeframe_missing")
        if measurement_id == parent_id:
            # The route's parent-target status is not a second source of
            # truth. It must agree with an explicitly sourced, as-of state
            # of that very measurement in the target graph.
            state_record = target.get("state_record")
            if not isinstance(state_record, dict):
                blockers.append("trade_pipeline_parent_target_state_record_missing")
                next_evidence.append("record_parent_target_state_in_target_graph_with_asof_source")
            else:
                target_state = state_record.get("state")
                if target_state not in {
                    "active", "approaching", "touched_under_review",
                    "completed_with_acceptance", "completed", "invalidated", "unknown",
                }:
                    blockers.append("trade_pipeline_parent_target_graph_state_invalid")
                elif target_state == "unknown" or target_state != pipeline.get("parent_target_state"):
                    blockers.append("trade_pipeline_parent_target_state_conflicts_with_graph")
                if measurement_id == downstream_id and target_state in {
                    "completed_with_acceptance", "completed", "invalidated", "unknown",
                }:
                    blockers.append("trade_pipeline_downstream_target_not_active_for_new_route")
                    next_evidence.append("select_new_downstream_measurement_after_completed_or_invalidated_child_target")
                state_refs = state_record.get("source_refs")
                if not isinstance(state_refs, list) or not state_refs or any(
                    not isinstance(ref, str) or not ref for ref in state_refs
                ):
                    blockers.append("trade_pipeline_parent_target_state_source_refs_missing")
                elif any(ref not in case_source_refs for ref in state_refs):
                    blockers.append("trade_pipeline_parent_target_state_source_ref_unresolved")
                state_at = _iso_time(state_record.get("observed_at_utc"))
                if state_at is None:
                    blockers.append("trade_pipeline_parent_target_state_asof_missing_or_invalid")
                else:
                    if cutoff is not None and state_at > cutoff:
                        blockers.append("trade_pipeline_parent_target_state_after_decision_cutoff")
                    if spine_asof is not None and state_at > spine_asof:
                        blockers.append("trade_pipeline_parent_target_state_after_spine_asof")
        if measurement_id == downstream_id and measurement_id != parent_id:
            # A fresh entry route cannot silently recycle a completed child
            # measurement as its next target. The state belongs to this named
            # graph item and must be known at the same decision cutoff.
            state_record = target.get("state_record")
            if not isinstance(state_record, dict):
                blockers.append("trade_pipeline_downstream_target_state_record_missing")
                next_evidence.append("record_new_downstream_target_lifecycle_after_child_measurement_completion")
            else:
                state = state_record.get("state")
                allowed_states = {
                    "active", "approaching", "touched_under_review",
                    "completed_with_acceptance", "completed", "invalidated", "unknown",
                }
                if not isinstance(state, str) or state not in allowed_states:
                    blockers.append("trade_pipeline_downstream_target_graph_state_invalid")
                elif state in {"completed_with_acceptance", "completed", "invalidated", "unknown"}:
                    blockers.append("trade_pipeline_downstream_target_not_active_for_new_route")
                    next_evidence.append("select_new_downstream_measurement_after_completed_or_invalidated_child_target")
                state_refs = state_record.get("source_refs")
                if not isinstance(state_refs, list) or not state_refs or any(
                    not isinstance(ref, str) or not _truthy({"value": ref}, "value") for ref in state_refs
                ):
                    blockers.append("trade_pipeline_downstream_target_state_source_refs_missing")
                elif any(ref not in case_source_refs for ref in state_refs):
                    blockers.append("trade_pipeline_downstream_target_state_source_ref_unresolved")
                state_at = _iso_time(state_record.get("observed_at_utc"))
                if state_at is None:
                    blockers.append("trade_pipeline_downstream_target_state_asof_missing_or_invalid")
                else:
                    if cutoff is not None and state_at > cutoff:
                        blockers.append("trade_pipeline_downstream_target_state_after_decision_cutoff")
                    if spine_asof is not None and state_at > spine_asof:
                        blockers.append("trade_pipeline_downstream_target_state_after_spine_asof")
        roles = target.get("roles")
        if (
            not isinstance(roles, list)
            or not roles
            or any(not isinstance(role, str) or role not in allowed_roles for role in roles)
        ):
            roles = ["unknown"]
        assigned_roles = set(roles)
        if "unknown" in assigned_roles or any(not (assigned_roles & group) for group in required_groups):
            blockers.append("trade_pipeline_selected_target_role_unknown_or_incompatible")
            next_evidence.append("assign_only_source-supported_parent_entry_or_post_entry_roles")
        role_records = target.get("role_assignment_records")
        if not isinstance(role_records, dict):
            role_records = {}
            blockers.append("trade_pipeline_selected_target_role_records_missing")
        declared_roles = assigned_roles - {"unknown"}
        if set(role_records) != declared_roles:
            blockers.append("trade_pipeline_selected_target_role_records_do_not_match_declared_roles")
        for role in declared_roles:
            role_record = role_records.get(role)
            if not isinstance(role_record, dict):
                blockers.append(f"trade_pipeline_target_role_source_record_missing_{role}")
                continue
            role_refs = role_record.get("source_refs")
            if not isinstance(role_refs, list) or not role_refs or any(
                not isinstance(ref, str) or not ref for ref in role_refs
            ):
                blockers.append(f"trade_pipeline_target_role_source_refs_missing_{role}")
            elif any(ref not in case_source_refs for ref in role_refs):
                blockers.append(f"trade_pipeline_target_role_source_ref_unresolved_{role}")
                next_evidence.append("resolve_each_role_source_ref_in_case_provenance")
            assigned_at = _iso_time(role_record.get("assigned_as_of_utc"))
            if assigned_at is None:
                blockers.append(f"trade_pipeline_target_role_assignment_asof_missing_or_invalid_{role}")
            elif cutoff is not None and assigned_at > cutoff:
                blockers.append(f"trade_pipeline_target_role_assignment_after_decision_cutoff_{role}")

    ledger_ids = pipeline.get("measurement_ledger_ids")
    if not isinstance(ledger_ids, list) or not _truthy(pipeline, "downstream_measurement_target_id"):
        blockers.append("trade_pipeline_downstream_target_ledger_reference_missing")
    elif downstream_id not in ledger_ids:
        blockers.append("trade_pipeline_downstream_target_not_in_measurement_ledger")
        next_evidence.append("bind_downstream_measurement_target_to_measurement_ledger_entry")

    return blockers, next_evidence


def _case_declared_source_refs(snapshot: Dict[str, Any], identity: Dict[str, Any]) -> set[str]:
    """Return source IDs explicitly declared for this decision snapshot."""
    refs: set[str] = set()
    for field in ("source_message_ids", "source_document_ids"):
        values = identity.get(field)
        if isinstance(values, list):
            refs.update(value for value in values if isinstance(value, str) and value)
    image_sha = identity.get("image_sha256")
    if isinstance(image_sha, str) and image_sha:
        refs.add(image_sha)
    for field in ("source_refs", "data_provenance"):
        values = snapshot.get(field)
        if isinstance(values, list):
            refs.update(value for value in values if isinstance(value, str) and value)
    boundary_refs = (snapshot.get("evidence_boundary") or {}).get("source_refs")
    if isinstance(boundary_refs, list):
        refs.update(value for value in boundary_refs if isinstance(value, str) and value)
    return refs


def _source_case_provenance_gates(
    source_case: Dict[str, Any],
    identity: Dict[str, Any],
    execution: Dict[str, Any],
    declared_source_refs: set[str],
) -> tuple[List[str], List[str]]:
    """Validate an explicitly submitted case ledger boundary.

    The raw chat/image binding is an input contract, not something the engine
    can infer from a later outcome.  This gate is optional for generic theory
    snapshots, but fail-closed once a caller supplies ``source_case``.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not source_case:
        return blockers, next_evidence
    if not _truthy(source_case, "case_id"):
        blockers.append("source_case_case_id_missing")
    if source_case.get("speech_role") not in {
        "plan", "observation", "explanation", "execution", "review", "conditional_management", "unknown",
    }:
        blockers.append("source_case_speech_role_invalid")
    source_refs = source_case.get("source_refs")
    if not isinstance(source_refs, list) or not any(isinstance(ref, str) and ref for ref in source_refs):
        blockers.append("source_case_raw_or_image_source_refs_missing")
        next_evidence.append("bind_case_to_original_message_document_or_image_reference")
    elif any(ref not in declared_source_refs for ref in source_refs if isinstance(ref, str) and ref):
        blockers.append("source_case_source_ref_unresolved_in_snapshot_provenance")
        next_evidence.append("register_case_message_document_or_image_ref_in_snapshot_provenance")
    if not _truthy(source_case, "as_of_utc"):
        blockers.append("source_case_asof_missing")
        next_evidence.append("record_case_asof_before_using_later_outcome")
    for field in ("known_before_event", "unknown_before_event", "later_only_information"):
        if not isinstance(source_case.get(field), list):
            blockers.append(f"source_case_{field}_boundary_missing")
    if source_case.get("label_permission") not in {
        "hard_annotation_gate", "candidate", "competing_path", "blocked", "unknown",
    }:
        blockers.append("source_case_label_permission_invalid")
    if source_case.get("later_only_information") and source_case.get("label_permission") == "hard_annotation_gate":
        blockers.append("source_case_later_only_information_claims_hard_label")
        next_evidence.append("keep_later_outcome_separate_from_asof_case_label")
    execution_claimed = isinstance(execution, dict) and any(
        _truthy(execution, field)
        for field in (
            "candidate_entry", "direction", "invalidation_object", "first_target",
            "entry_modality", "stop_location", "target_stack",
        )
    )
    if execution_claimed and source_case.get("speech_role") in {"review", "explanation"}:
        blockers.append("source_case_review_or_explanation_cannot_authorize_execution")
        next_evidence.append("separate_asof_plan_or_execution_record_from_later_review_explanation")
    decision_time = _iso_time(identity.get("decision_time_utc"))
    case_time = _iso_time(source_case.get("as_of_utc"))
    if decision_time is not None and case_time is not None and case_time > decision_time:
        blockers.append("source_case_asof_after_decision_cutoff")
    return blockers, next_evidence


def _nested_ratio_threepush_entry_gates(
    review: Dict[str, Any],
    spine: Dict[str, Any] | None = None,
    case_source_refs: set[str] | None = None,
    decision_cutoff_utc: Any = None,
) -> tuple[List[str], List[str]]:
    """Require the ratio stack and three-push process to agree before entry research."""
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not review or review.get("recorded") is not True:
        return blockers, next_evidence
    if review.get("working_timeframe") not in {"M1", "M5", "M15", "M30", "H1", "H4", "D1"}:
        blockers.append("nested_ratio_threepush_working_timeframe_missing")
    if not _truthy(review, "parent_task_id") or not _truthy(review, "current_task_id"):
        blockers.append("nested_ratio_threepush_parent_or_current_task_missing")
    ratios = review.get("ratio_stack")
    if not isinstance(ratios, list) or not ratios:
        blockers.append("nested_ratio_threepush_ratio_stack_missing")
    else:
        known_relations = {"child_projection", "parent_pullback_map", "serial_relay", "spatial_coupling"}
        seen_measurement_ids: set[str] = set()
        for index, ratio in enumerate(ratios):
            if not isinstance(ratio, dict) or not _truthy(ratio, "leg_id") or not _truthy(ratio, "timeframe") or not _truthy(ratio, "anchor_ids"):
                blockers.append(f"nested_ratio_threepush_ratio_{index}_not_source_bound")
            if isinstance(ratio, dict):
                relation = ratio.get("relation")
                if not isinstance(relation, str) or relation not in {
                    "child_projection", "parent_pullback_map", "serial_relay", "spatial_coupling", "unknown",
                }:
                    blockers.append(f"nested_ratio_threepush_ratio_{index}_relation_invalid")
    role = review.get("three_push_role", "not_claimed")
    if role not in {"not_claimed", "background_adjustment", "retest_candidate", "continuation_candidate", "conflicted", "unknown"}:
        blockers.append("nested_ratio_threepush_role_invalid")
    effect_scope = review.get("effect_scope", "unknown")
    if effect_scope not in {"local_pullback_completion_candidate", "parent_test_only", "parent_replacement_request", "unknown"}:
        blockers.append("nested_ratio_threepush_effect_scope_invalid")
    if effect_scope == "parent_replacement_request" and review.get("parent_acceptance_state") != "accepted":
        blockers.append("nested_ratio_threepush_parent_replacement_without_parent_acceptance")
    if review.get("entry_requested") is not True:
        return blockers, next_evidence

    # Entry research needs a concrete measurement-to-target relationship for
    # every ratio in the stack. A timeframe/anchor label alone is not enough:
    # otherwise a lower-timeframe ratio can be silently treated as the parent
    # target, or the same named target can be counted twice.
    if not isinstance(ratios, list) or not ratios:
        ratios = []
    graph = spine.get("active_target_graph") if isinstance(spine, dict) else None
    graph = graph if isinstance(graph, list) else []
    declared_refs = case_source_refs or set()
    supported_timeframes = {"W1", "D1", "H4", "H1", "M30", "M15", "M5", "M1"}
    valid_task_ids = {
        task_id for task_id in (review.get("parent_task_id"), review.get("current_task_id"))
        if isinstance(task_id, str) and _truthy({"value": task_id}, "value")
    }
    review_time = _iso_time(review.get("as_of_utc"))
    cutoff_time = _iso_time(decision_cutoff_utc)
    spine_time = _iso_time(spine.get("as_of_utc")) if isinstance(spine, dict) else None
    if review_time is None:
        blockers.append("nested_ratio_threepush_entry_asof_invalid")
    if cutoff_time is None:
        blockers.append("nested_ratio_threepush_decision_cutoff_missing_or_invalid")
    if spine_time is None:
        blockers.append("nested_ratio_threepush_spine_asof_missing_or_invalid")
    if review_time is not None and cutoff_time is not None and review_time > cutoff_time:
        blockers.append("nested_ratio_threepush_review_after_decision_cutoff")
    if review_time is not None and spine_time is not None and review_time > spine_time:
        blockers.append("nested_ratio_threepush_review_after_spine_asof")
    for index, ratio in enumerate(ratios):
        if not isinstance(ratio, dict):
            continue
        measurement_id = ratio.get("measurement_id")
        if not isinstance(measurement_id, str) or not _truthy({"value": measurement_id}, "value"):
            blockers.append(f"nested_ratio_threepush_ratio_{index}_measurement_id_missing")
        elif measurement_id in seen_measurement_ids:
            blockers.append("nested_ratio_threepush_ratio_measurement_id_duplicated")
        else:
            seen_measurement_ids.add(measurement_id)
        leg_id = ratio.get("leg_id")
        if not isinstance(leg_id, str) or not _truthy({"value": leg_id}, "value"):
            blockers.append(f"nested_ratio_threepush_ratio_{index}_leg_id_invalid")
        timeframe = ratio.get("timeframe")
        if not isinstance(timeframe, str) or timeframe not in supported_timeframes:
            blockers.append(f"nested_ratio_threepush_ratio_{index}_timeframe_unknown_or_unsupported")
        anchor_ids = ratio.get("anchor_ids")
        if (
            not isinstance(anchor_ids, list)
            or len(anchor_ids) < 2
            or any(not isinstance(anchor, str) or not _truthy({"value": anchor}, "value") for anchor in anchor_ids)
            or len(anchor_ids) != len(set(anchor_ids))
        ):
            blockers.append(f"nested_ratio_threepush_ratio_{index}_anchors_incomplete_or_duplicated")
        relation = ratio.get("relation")
        if not isinstance(relation, str) or relation not in known_relations:
            blockers.append(f"nested_ratio_threepush_ratio_{index}_task_relation_unknown")
        task_id = ratio.get("task_id")
        if not isinstance(task_id, str) or task_id not in valid_task_ids:
            blockers.append(f"nested_ratio_threepush_ratio_{index}_task_id_unbound")
        causal_cluster_id = ratio.get("causal_cluster_id")
        if not isinstance(causal_cluster_id, str) or not _truthy({"value": causal_cluster_id}, "value"):
            blockers.append(f"nested_ratio_threepush_ratio_{index}_causal_cluster_missing")
        refs = ratio.get("source_refs")
        if not isinstance(refs, list) or not refs or any(
            not isinstance(ref, str) or not _truthy({"value": ref}, "value") or ref not in declared_refs
            for ref in refs
        ):
            blockers.append(f"nested_ratio_threepush_ratio_{index}_source_refs_missing_or_unregistered")
        ratio_time = _iso_time(ratio.get("as_of_utc"))
        if ratio_time is None:
            blockers.append(f"nested_ratio_threepush_ratio_{index}_asof_missing_or_invalid")
        else:
            if review_time is not None and ratio_time > review_time:
                blockers.append(f"nested_ratio_threepush_ratio_{index}_after_review_asof")
            if cutoff_time is not None and ratio_time > cutoff_time:
                blockers.append(f"nested_ratio_threepush_ratio_{index}_after_decision_cutoff")
            if spine_time is not None and ratio_time > spine_time:
                blockers.append(f"nested_ratio_threepush_ratio_{index}_after_spine_asof")
        if isinstance(measurement_id, str) and _truthy({"value": measurement_id}, "value"):
            targets = [target for target in graph
                       if isinstance(target, dict) and target.get("measurement_id") == measurement_id]
            if len(targets) != 1:
                blockers.append(f"nested_ratio_threepush_ratio_{index}_target_unmapped_or_ambiguous")
            elif targets[0].get("timeframe") != timeframe:
                blockers.append(f"nested_ratio_threepush_ratio_{index}_target_timeframe_mismatch")
            else:
                roles = targets[0].get("roles")
                allowed_target_roles = {
                    "parent_task_delivery_target", "entry_geometry_candidate", "post_entry_measurement",
                }
                if (
                    not isinstance(roles, list)
                    or not roles
                    or any(not isinstance(role, str) or role not in allowed_target_roles for role in roles)
                ):
                    blockers.append(f"nested_ratio_threepush_ratio_{index}_target_role_unresolved")
    if not _truthy(review, "as_of_utc"):
        blockers.append("nested_ratio_threepush_entry_asof_missing")
    if review.get("ratio_state") in {"not_drawn", "location_reached", "conflicted", "unknown"}:
        blockers.append("nested_ratio_threepush_ratio_not_process_confirmed")
    if role in {"background_adjustment", "conflicted", "unknown"}:
        blockers.append("nested_ratio_threepush_three_push_not_entry_ready")
    if review.get("three_push_close_state") not in {"reclaimed", "accepted_break", "closed_and_held"}:
        blockers.append("nested_ratio_threepush_close_acceptance_missing")
    if not _truthy(review, "joint_process_evidence_ids"):
        blockers.append("nested_ratio_threepush_joint_process_evidence_missing")
    if not _truthy(review, "structure_acceptance_evidence_ids"):
        blockers.append("nested_ratio_threepush_structure_acceptance_missing")
    if not _truthy(review, "route_basis_ids"):
        blockers.append("nested_ratio_threepush_route_basis_missing")
    if review.get("admission_state") != "licensed_for_entry_research":
        blockers.append("nested_ratio_threepush_entry_not_jointly_licensed")
    if review.get("vetoes"):
        blockers.append("nested_ratio_threepush_explicit_veto_present")
    return blockers, next_evidence


def _market_structure_spine_gates(
    spine: Dict[str, Any], decision_cutoff_utc: Any = None
) -> tuple[List[str], List[str]]:
    """Make structure/force/target evidence precede every secondary framework.

    A structure node is a named neckline, SNR conversion, range edge or
    protected swing. A wick, a lower-timeframe CHOCH, reaching an H4 1:1, or a
    weekly label cannot silently replace it. This is deliberately an
    observation ledger rather than an automatic swing-labeling algorithm.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not spine:
        return blockers, next_evidence

    spine_time = _iso_time(spine.get("as_of_utc"))
    cutoff = _iso_time(decision_cutoff_utc)
    if spine_time is None:
        blockers.append("market_structure_spine_missing_asof")
    elif cutoff is not None and spine_time > cutoff:
        blockers.append("market_structure_spine_asof_after_decision_cutoff")
    if spine.get("weekly_cannot_override_spine") is not True:
        blockers.append("market_structure_spine_weekly_not_subordinate")

    nodes = spine.get("nodes")
    if not isinstance(nodes, list) or not nodes:
        blockers.append("market_structure_spine_nodes_missing")
        next_evidence.append("record_named_multitimeframe_neckline_snr_and_protected_nodes")
        nodes = []
    node_ids = set()
    node_id_counts: Dict[str, int] = {}
    valid_nodes: List[Dict[str, Any]] = []
    valid_roles = {"neckline", "snr_conversion", "range_edge", "protected_swing", "breakout_origin", "unknown"}
    valid_lifecycles = {"formed", "tested", "body_broken", "accepted_conversion", "reclaimed", "retired", "unknown"}
    for node in nodes:
        if not isinstance(node, dict):
            blockers.append("market_structure_spine_node_invalid")
            continue
        node_id = node.get("node_id")
        timeframe = node.get("timeframe")
        if (
            not isinstance(node_id, str)
            or not node_id.strip()
            or not isinstance(timeframe, str)
            or not timeframe.strip()
        ):
            blockers.append("market_structure_spine_node_identity_missing")
        else:
            node_ids.add(node_id)
            node_id_counts[node_id] = node_id_counts.get(node_id, 0) + 1
            valid_nodes.append(node)
        if node.get("role") not in valid_roles or node.get("lifecycle") not in valid_lifecycles:
            blockers.append("market_structure_spine_node_role_or_lifecycle_invalid")

    if any(count > 1 for count in node_id_counts.values()):
        blockers.append("market_structure_spine_node_id_duplicate")
    parent_node_by_id: Dict[str, str] = {}
    for node in valid_nodes:
        parent_node_id = node.get("parent_node_id")
        if not _truthy({"parent_node_id": parent_node_id}, "parent_node_id"):
            continue
        node_id = node.get("node_id")
        if not isinstance(parent_node_id, str) or not parent_node_id.strip():
            blockers.append("market_structure_spine_parent_node_id_invalid")
        elif parent_node_id == node_id:
            blockers.append("market_structure_spine_parent_node_self_reference")
        elif node_id_counts.get(parent_node_id, 0) == 0:
            blockers.append("market_structure_spine_parent_node_unmapped")
        elif node_id_counts[parent_node_id] > 1:
            blockers.append("market_structure_spine_parent_node_ambiguous")
        else:
            parent_node_by_id[node_id] = parent_node_id

    visited_parent_paths = set()
    parent_cycle_found = False
    for start_node_id in parent_node_by_id:
        path = set()
        current_node_id = start_node_id
        while current_node_id in parent_node_by_id:
            if current_node_id in path:
                parent_cycle_found = True
                break
            if current_node_id in visited_parent_paths:
                break
            path.add(current_node_id)
            current_node_id = parent_node_by_id[current_node_id]
        visited_parent_paths.update(path)
        if parent_cycle_found:
            break
    if parent_cycle_found:
        blockers.append("market_structure_spine_parent_node_cycle")

    force_links = spine.get("force_links", [])
    if not isinstance(force_links, list):
        blockers.append("market_structure_spine_force_links_invalid")
        force_links = []
    force_ids = set()
    valid_results = {"wick", "body_close", "accepted", "reclaimed", "failed_to_reach", "unknown"}
    for link in force_links:
        if not isinstance(link, dict):
            blockers.append("market_structure_spine_force_link_invalid")
            continue
        force_id = link.get("force_leg_id")
        node_id = link.get("node_attempted_id")
        if (
            not isinstance(force_id, str)
            or not force_id.strip()
            or not isinstance(link.get("timeframe"), str)
            or not link.get("timeframe", "").strip()
            or not isinstance(node_id, str)
            or not node_id.strip()
        ):
            blockers.append("market_structure_spine_force_link_identity_missing")
        else:
            force_ids.add(force_id)
            if node_id not in node_ids:
                blockers.append("market_structure_spine_force_link_node_unmapped")
        if link.get("node_result") not in valid_results:
            blockers.append("market_structure_spine_force_link_result_invalid")

    if spine.get("child_choch_replaces_parent") is True:
        blockers.append("market_structure_spine_child_choch_replaces_parent")
        next_evidence.append("record_progressive_child_to_parent_node_acceptance")
    child_event = spine.get("child_structure_event") or {}
    if child_event:
        valid_child_events = {"CHOCH", "BOS", "MSS", "none", "unknown"}
        valid_scopes = {"child_delivery", "parent_test", "range_rotation", "transition_candidate", "unknown"}
        if child_event.get("event_name") not in valid_child_events:
            blockers.append("market_structure_spine_child_event_invalid")
        if child_event.get("event_name") not in {"none", "unknown"}:
            if child_event.get("node_id") not in node_ids or not child_event.get("timeframe"):
                blockers.append("market_structure_spine_child_event_node_or_timeframe_unmapped")
            if child_event.get("claimed_scope") not in valid_scopes:
                blockers.append("market_structure_spine_child_event_scope_invalid")
        if child_event.get("parent_target_dismisses_event") is True:
            blockers.append("market_structure_spine_parent_target_dismisses_child_event")
            next_evidence.append("retain_child_event_and_classify_its_scope_against_parent_target")
    if spine.get("reached_h4_1to1_auto_reversal") is True:
        blockers.append("market_structure_spine_h4_1to1_claims_automatic_reversal")
        next_evidence.append("after_h4_target_record_small_to_large_force_node_and_acceptance_chain")
    if spine.get("snr_conversion_claimed") is True:
        conversion_node = spine.get("conversion_node_id")
        conversion_force = spine.get("conversion_force_leg_id")
        conversion_nodes = [
            node for node in nodes
            if isinstance(node, dict) and node.get("node_id") == conversion_node
        ]
        conversion_link = None
        if len(conversion_nodes) != 1 or conversion_force not in force_ids:
            blockers.append("market_structure_spine_snr_conversion_unmapped")
        else:
            # The force leg may be observed on a child timeframe, but an
            # accepted conversion of a named H1/H4/etc. node needs a close on
            # that node's belonging timeframe. A child close only records a
            # challenge/candidate; it cannot silently promote the parent node.
            node_timeframe = conversion_nodes[0].get("timeframe")
            close_timeframe = spine.get("conversion_close_timeframe")
            if not _truthy({"timeframe": node_timeframe}, "timeframe"):
                blockers.append("market_structure_spine_snr_conversion_node_timeframe_missing_or_unknown")
            elif node_timeframe not in _TIMEFRAME_DESCENT_RANK:
                blockers.append("market_structure_spine_snr_conversion_node_timeframe_invalid")
            if not _truthy({"timeframe": close_timeframe}, "timeframe"):
                blockers.append("market_structure_spine_snr_conversion_close_timeframe_missing")
                next_evidence.append("record_belonging_timeframe_close_for_named_snr_node")
            elif close_timeframe not in _TIMEFRAME_DESCENT_RANK:
                blockers.append("market_structure_spine_snr_conversion_close_timeframe_invalid")
            elif close_timeframe != node_timeframe:
                blockers.append("market_structure_spine_snr_conversion_close_timeframe_mismatch")
                next_evidence.append("wait_for_belonging_timeframe_close_before_claiming_snr_conversion")
            # A force leg elsewhere in the ledger cannot prove conversion of
            # this named SNR. Reused leg IDs are ambiguous even if one link
            # happens to point to the claimed node.
            matching_links = [
                link for link in force_links
                if isinstance(link, dict) and link.get("force_leg_id") == conversion_force
            ]
            if len(matching_links) != 1:
                blockers.append("market_structure_spine_snr_conversion_force_ambiguous")
            else:
                conversion_link = matching_links[0]
                if conversion_link.get("node_attempted_id") != conversion_node:
                    blockers.append("market_structure_spine_snr_conversion_force_node_mismatch")
                    next_evidence.append("bind_conversion_force_to_the_named_snr_node")
                result = conversion_link.get("node_result")
                retest = spine.get("conversion_retest_state")
                if result not in {"body_close", "accepted"} and not (
                    result == "reclaimed" and retest == "old_side_reclaim"
                ):
                    blockers.append("market_structure_spine_snr_conversion_force_result_insufficient")
                    next_evidence.append("observe_close_or_acceptance_at_the_named_snr_node")
        # A later close/retest cannot be copied back into the earlier
        # decision. Explicit event times are required for a claimed conversion,
        # independently of the spine's aggregate as-of label.
        event_times = {
            "force": _iso_time(conversion_link.get("observed_at_utc")) if conversion_link else None,
            "close": _iso_time(spine.get("conversion_close_observed_at_utc")),
            "retest": _iso_time(spine.get("conversion_retest_observed_at_utc")),
        }
        for event_name, event_time in event_times.items():
            if event_time is None:
                blockers.append(f"market_structure_spine_snr_conversion_{event_name}_time_missing")
            elif cutoff is not None and event_time > cutoff:
                blockers.append(f"market_structure_spine_snr_conversion_{event_name}_after_decision_cutoff")
            if event_time is not None and spine_time is not None and event_time > spine_time:
                blockers.append(f"market_structure_spine_snr_conversion_{event_name}_after_spine_asof")
        if event_times["force"] and event_times["close"] and event_times["force"] > event_times["close"]:
            blockers.append("market_structure_spine_snr_conversion_force_after_close")
        if event_times["close"] and event_times["retest"] and event_times["close"] > event_times["retest"]:
            blockers.append("market_structure_spine_snr_conversion_retest_before_close")
        if spine.get("conversion_close_observed") is not True:
            blockers.append("market_structure_spine_snr_conversion_without_body_close")
        if spine.get("conversion_retest_state") not in {"held", "old_side_reclaim"}:
            blockers.append("market_structure_spine_snr_conversion_without_hold_or_reclaim")
            next_evidence.append("observe_conversion_retest_hold_or_old_side_reclaim")
    if spine.get("liquidity_object_substitutes_structure") is True:
        blockers.append("market_structure_spine_liquidity_substitutes_named_structure")

    # A measured 1:1 or an energetic counter-leg can coexist with an intact
    # trend high (Alexander, 2026-02-27 14:11-14:12 UTC). Only inspect this
    # optional assertion when an annotator actually claims a breakout. The
    # declaration must bind the *same* key node, force and belonging-timeframe
    # close/acceptance; it does not derive any of those facts from a ratio.
    breakout = spine.get("breakout_assertion")
    if breakout and not isinstance(breakout, dict):
        blockers.append("market_structure_spine_breakout_assertion_invalid")
    if isinstance(breakout, dict) and breakout.get("claimed") is True:
        key_id = breakout.get("key_structure_node_id")
        leg_id = breakout.get("force_leg_id")
        timeframe = breakout.get("timeframe")
        key_matches = [node for node in nodes
                       if isinstance(node, dict) and node.get("node_id") == key_id]
        leg_matches = [link for link in force_links
                       if isinstance(link, dict) and link.get("force_leg_id") == leg_id]
        if len(key_matches) != 1 or not key_id or not timeframe:
            blockers.append("market_structure_spine_breakout_key_node_unmapped_or_ambiguous")
        else:
            key_node = key_matches[0]
            if key_node.get("timeframe") != timeframe or key_node.get("role") not in {
                "protected_swing", "neckline", "range_edge", "snr_conversion"
            }:
                blockers.append("market_structure_spine_breakout_key_node_scope_mismatch")
            if key_node.get("lifecycle") not in {"body_broken", "accepted_conversion"}:
                blockers.append("market_structure_spine_breakout_key_node_not_broken")
        if len(leg_matches) != 1 or not leg_id:
            blockers.append("market_structure_spine_breakout_force_unmapped_or_ambiguous")
        else:
            leg = leg_matches[0]
            if leg.get("node_attempted_id") != key_id or leg.get("timeframe") != timeframe:
                blockers.append("market_structure_spine_breakout_force_node_or_timeframe_mismatch")
            if leg.get("node_result") != "accepted":
                blockers.append("market_structure_spine_breakout_force_not_accepted_at_key_node")
        if breakout.get("proof_basis") != "structure_close_acceptance":
            blockers.append("market_structure_spine_breakout_claim_from_measurement_or_force_alone")
        if breakout.get("belonging_timeframe_close") is not True:
            blockers.append("market_structure_spine_breakout_belonging_close_missing")
        if breakout.get("boundary_accepted") is not True:
            blockers.append("market_structure_spine_breakout_boundary_acceptance_missing")
        close_time = _iso_time(breakout.get("close_observed_at_utc"))
        acceptance_time = _iso_time(breakout.get("acceptance_observed_at_utc"))
        force_time = _iso_time(leg_matches[0].get("observed_at_utc")) if len(leg_matches) == 1 else None
        if force_time is None:
            blockers.append("market_structure_spine_breakout_force_time_missing")
        elif (cutoff is not None and force_time > cutoff) or (
            spine_time is not None and force_time > spine_time
        ):
            blockers.append("market_structure_spine_breakout_force_after_cutoff")
        if close_time is None or acceptance_time is None:
            blockers.append("market_structure_spine_breakout_close_or_acceptance_time_missing")
        else:
            if force_time is not None and force_time > close_time:
                blockers.append("market_structure_spine_breakout_force_after_close")
            if close_time > acceptance_time:
                blockers.append("market_structure_spine_breakout_acceptance_before_close")
            if (cutoff is not None and (close_time > cutoff or acceptance_time > cutoff)) or (
                spine_time is not None and (close_time > spine_time or acceptance_time > spine_time)
            ):
                blockers.append("market_structure_spine_breakout_acceptance_after_cutoff")

    return blockers, next_evidence


def _structure_authority_presence_gate(
    spine: Dict[str, Any],
    pipeline: Dict[str, Any],
    nested_delivery: Dict[str, Any],
    nested_ratio_threepush: Dict[str, Any],
    execution: Dict[str, Any],
) -> tuple[List[str], List[str]]:
    """Require the primary structure spine before a secondary route can claim authority.

    Theory-only records may remain unstructured. Once a snapshot presents an
    entry route, nested delivery/ratio admission, or execution geometry,
    however, an absent spine is a missing prerequisite rather than a harmless
    unknown. This keeps Weekly, OB/FVG, ratios and liquidity from becoming an
    accidental direction engine.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    pipeline_claims_route = isinstance(pipeline, dict) and bool(pipeline.get("entry_route"))
    nested_claims_entry = (
        isinstance(nested_delivery, dict)
        and isinstance(nested_delivery.get("measurement_coupling"), dict)
        and nested_delivery["measurement_coupling"].get("claims_execution_candidate") is True
    )
    ratio_claims_entry = (
        isinstance(nested_ratio_threepush, dict)
        and nested_ratio_threepush.get("admission_state") in {"licensed_for_entry_research", "candidate"}
    )
    geometry_claims_entry = isinstance(execution, dict) and any(
        execution.get(key) not in (None, "", "unknown", "not_recorded")
        for key in ("candidate_entry", "invalidation_object", "first_target")
    )
    authority_claimed = pipeline_claims_route or nested_claims_entry or ratio_claims_entry or geometry_claims_entry
    if not authority_claimed:
        return blockers, next_evidence
    if not isinstance(spine, dict) or not spine:
        blockers.append("market_structure_spine_required_before_secondary_authority")
        next_evidence.append("record_multitimeframe_structure_nodes_before_weekly_ob_or_ratio_route")
        return blockers, next_evidence
    if spine.get("weekly_cannot_override_spine") is not True:
        blockers.append("market_structure_spine_authority_contract_missing")
    nodes = spine.get("nodes")
    if not isinstance(nodes, list) or not nodes:
        blockers.append("market_structure_spine_required_nodes_missing_before_secondary_authority")
        next_evidence.append("name_parent_current_and_child_neckline_snr_or_protected_nodes")
    elif not any(
        isinstance(node, dict)
        and node.get("node_id") not in {None, "", "unknown"}
        and node.get("timeframe") not in {None, "", "unknown"}
        and node.get("role") not in {None, "", "unknown"}
        for node in nodes
    ):
        blockers.append("market_structure_spine_nodes_unqualified_before_secondary_authority")
        next_evidence.append("bind_named_structure_node_to_its_timeframe_and_role_before_entry_route")
    target_graph = spine.get("active_target_graph")
    if not isinstance(target_graph, list) or not target_graph:
        blockers.append("market_structure_spine_target_graph_missing_before_secondary_authority")
        next_evidence.append("bind_parent_and_working_timeframe_dol_or_measurement_targets")
    force_links = spine.get("force_links")
    if not isinstance(force_links, list) or not force_links:
        blockers.append("market_structure_spine_force_to_node_link_missing_before_secondary_authority")
        next_evidence.append("bind_force_leg_to_named_node_and_record_belonging_timeframe_close")
    elif not any(
        isinstance(link, dict)
        and link.get("node_result") in {"body_close", "accepted", "reclaimed"}
        for link in force_links
    ):
        blockers.append("market_structure_spine_force_to_node_close_acceptance_missing_before_secondary_authority")
        next_evidence.append("record_force_to_node_body_close_and_followthrough_or_retest_hold")
    return blockers, next_evidence


def _selected_force_node_target_gates(
    spine: Dict[str, Any], pipeline: Dict[str, Any], decision_cutoff_utc: Any,
    case_source_refs: set[str],
) -> tuple[List[str], List[str]]:
    """Keep a selected route's force, structure node and target on one chain.

    Presence of an unrelated accepted force link or an unrelated target must
    not license the selected entry research route. This checks declared
    relations, not the chart-level truth of the annotations.
    """
    if not isinstance(pipeline, dict) or pipeline.get("recorded") is not True:
        return [], []
    if pipeline.get("entry_route") in {None, "none", "unknown"}:
        return [], []
    blockers: List[str] = []
    next_evidence: List[str] = []
    leg_id = pipeline.get("selected_force_leg_id")
    node_id = pipeline.get("selected_structure_node_id")
    if not _truthy(pipeline, "selected_force_leg_id") or not _truthy(pipeline, "selected_structure_node_id"):
        blockers.append("trade_pipeline_selected_force_or_node_missing")
        next_evidence.append("select_named_force_leg_and_structure_node_for_entry_route")
        return blockers, next_evidence
    links = spine.get("force_links") if isinstance(spine, dict) else None
    links = links if isinstance(links, list) else []
    selected = [link for link in links if isinstance(link, dict) and link.get("force_leg_id") == leg_id]
    if len(selected) != 1:
        blockers.append("trade_pipeline_selected_force_unmapped_or_ambiguous")
        return blockers, next_evidence
    link = selected[0]
    nodes = spine.get("nodes") if isinstance(spine, dict) else None
    nodes = nodes if isinstance(nodes, list) else []
    if len([node for node in nodes if isinstance(node, dict) and node.get("node_id") == node_id]) != 1:
        blockers.append("trade_pipeline_selected_node_unmapped_or_ambiguous")
    if link.get("node_attempted_id") != node_id:
        blockers.append("trade_pipeline_selected_force_node_mismatch")
    if link.get("node_result") not in {"body_close", "accepted", "reclaimed"}:
        blockers.append("trade_pipeline_selected_force_without_node_close_or_acceptance")
    graph = spine.get("active_target_graph") if isinstance(spine, dict) else None
    graph = graph if isinstance(graph, list) else []
    target_id = link.get("target_or_measurement_id")
    if not _truthy(link, "target_or_measurement_id") or len([
        target for target in graph
        if isinstance(target, dict) and target.get("measurement_id") == target_id
    ]) != 1:
        blockers.append("trade_pipeline_selected_force_target_unmapped_or_ambiguous")
    if link.get("target_relation") not in {"proves", "approaches", "fails"}:
        blockers.append("trade_pipeline_selected_force_target_relation_unknown")
    refs = link.get("source_refs")
    if not isinstance(refs, list) or not refs or any(not isinstance(ref, str) or not ref for ref in refs):
        blockers.append("trade_pipeline_selected_force_source_refs_missing")
    elif any(ref not in case_source_refs for ref in refs):
        blockers.append("trade_pipeline_selected_force_source_ref_unresolved")
    observed_at = _iso_time(link.get("observed_at_utc"))
    cutoff = _iso_time(decision_cutoff_utc)
    spine_asof = _iso_time(spine.get("as_of_utc")) if isinstance(spine, dict) else None
    if observed_at is None:
        blockers.append("trade_pipeline_selected_force_asof_missing_or_invalid")
    else:
        if cutoff is not None and observed_at > cutoff:
            blockers.append("trade_pipeline_selected_force_after_decision_cutoff")
        if spine_asof is not None and observed_at > spine_asof:
            blockers.append("trade_pipeline_selected_force_after_spine_asof")
    return blockers, next_evidence


def _force_sweep_interpretation_gates(event: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Keep same-timeframe force delivery distinct from a liquidity sweep.

    Alexander's distinction is qualitative and source-specific: sustained
    real-break delivery versus a spike only on reaching a liquidity object.
    The engine requires the observable object/path fields, but deliberately
    does not invent any point, ATR, duration or bar-count threshold.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not event:
        return blockers, next_evidence

    classification = event.get("classification")
    allowed = {"force_delivery", "liquidity_sweep", "ambiguous", "unknown"}
    if classification not in allowed:
        blockers.append("force_sweep_interpretation_classification_invalid")
        return blockers, next_evidence
    if classification == "unknown":
        return blockers, next_evidence

    if not _truthy(event, "same_timeframe") or not _truthy(event, "named_object_id"):
        blockers.append("force_sweep_interpretation_missing_timeframe_or_named_object")
        next_evidence.append("name_same_timeframe_and_object_before_force_or_sweep_label")
    if event.get("object_kind") not in {"structure_node", "liquidity_object", "mixed", "unknown"}:
        blockers.append("force_sweep_interpretation_object_kind_invalid")
    if event.get("approach_velocity_pattern") not in {"sustained_to_boundary", "near_boundary_spike", "mixed", "unknown"}:
        blockers.append("force_sweep_interpretation_velocity_pattern_invalid")
    if event.get("boundary_outcome") not in {"body_continuation", "wick_excursion", "reclaimed", "accepted", "unknown"}:
        blockers.append("force_sweep_interpretation_boundary_outcome_invalid")
    if event.get("opposite_response") not in {"none_yet", "clear_pullback", "clear_reclaim", "unknown"}:
        blockers.append("force_sweep_interpretation_opposite_response_invalid")
    if event.get("larger_context_force_comparison") not in {"same_direction_dominant", "countermove_recovered", "mixed", "unknown"}:
        blockers.append("force_sweep_interpretation_context_comparison_invalid")

    response_timing = event.get("opposite_response_timing", "unknown")
    if response_timing not in {"prompt", "delayed", "not_observed", "unknown"}:
        blockers.append("force_sweep_interpretation_response_timing_invalid")

    if classification == "force_delivery":
        required = ("structure_node_id", "target_relation_id")
        if not all(_truthy(event, key) for key in required):
            blockers.append("force_delivery_without_named_structure_node_and_target_relation")
            next_evidence.append("bind_force_to_named_structure_node_and_target_relation")
        if event.get("approach_velocity_pattern") == "near_boundary_spike":
            blockers.append("force_delivery_claimed_from_near_boundary_spike")
        if event.get("boundary_outcome") in {"wick_excursion", "reclaimed"}:
            blockers.append("force_delivery_claimed_despite_wick_or_reclaim")
        if event.get("opposite_response") in {"clear_pullback", "clear_reclaim"}:
            blockers.append("force_delivery_claimed_despite_clear_opposite_response")
        if event.get("claims_parent_replacement") is True:
            blockers.append("force_delivery_claims_parent_replacement_without_separate_acceptance_chain")

    if classification == "liquidity_sweep":
        if event.get("object_kind") not in {"liquidity_object", "mixed"}:
            blockers.append("liquidity_sweep_without_liquidity_object_role")
        if event.get("approach_velocity_pattern") not in {"near_boundary_spike", "mixed"}:
            blockers.append("liquidity_sweep_without_boundary_spike_or_mixed_path")
        if event.get("boundary_outcome") == "accepted" or event.get("post_boundary_balance_state") == "held_above_or_below_on_new_side":
            blockers.append("liquidity_sweep_claimed_despite_new_side_acceptance")
            next_evidence.append("reclassify_as_acceptance_or_ambiguous_after_belonging_timeframe_close_review")
        if event.get("opposite_response") not in {"clear_pullback", "clear_reclaim"}:
            blockers.append("liquidity_sweep_without_clear_opposite_response")
            next_evidence.append("observe_prompt_opposite_force_relative_to_the_chosen_timeframe")
        # Alexander's Feb 27 double-top/sweep-short path was conditional on
        # prompt same-timeframe bearish force after the high was swept. Keep
        # that response-quality test separate from merely naming a sweep:
        # delayed response may remain a later event observation, but cannot
        # satisfy the original prompt-response setup. No numeric latency
        # threshold is inferred from the source wording.
        if event.get("claims_prompt_response_setup") is True and response_timing != "prompt":
            blockers.append("prompt_response_setup_claimed_without_prompt_same_timeframe_response")
            next_evidence.append("bind_boundary_breach_and_first_opposite_force_on_the_same_timeframe; keep_original_setup_unconfirmed_if_delayed")
        if event.get("claims_immediate_reversal") is True:
            blockers.append("liquidity_sweep_claims_immediate_reversal")
        if event.get("claims_structure_replacement") is True:
            blockers.append("liquidity_sweep_claims_structure_replacement")

    if classification == "ambiguous" and event.get("classification_permission") not in {"observation_only", "unknown", None}:
        blockers.append("ambiguous_force_sweep_claims_permission")
        next_evidence.append("keep_ambiguous_event_observation_only_until_object_path_and_response_resolve")

    return blockers, next_evidence


def _force_delivery_spine_join_gates(
    event: Dict[str, Any], spine: Dict[str, Any], decision_cutoff_utc: Any,
    case_source_refs: set[str],
) -> tuple[List[str], List[str]]:
    """Resolve a delivery claim to one force leg, one structural node and one target.

    The event's free-text IDs are not evidence by themselves. An internal
    liquidity hit may coexist with structural delivery, but it cannot stand
    in for the named node or its target relation (Alexander, 2026-06-09).
    """
    if not isinstance(event, dict) or event.get("classification") != "force_delivery":
        return [], []
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not isinstance(spine, dict) or not spine:
        return ["force_delivery_spine_missing"], ["bind_delivery_event_to_market_structure_spine"]

    cutoff = _iso_time(decision_cutoff_utc)
    spine_asof = _iso_time(spine.get("as_of_utc"))

    def check_availability(refs: Any, records: Any, prefix: str) -> None:
        """Require one publication-time record for every supporting source."""
        if not isinstance(refs, list) or not refs or not isinstance(records, list):
            blockers.append(f"{prefix}_availability_unbound")
            return
        indexed: Dict[str, List[Any]] = {}
        for record in records:
            if isinstance(record, dict) and isinstance(record.get("source_ref"), str):
                indexed.setdefault(record["source_ref"], []).append(record.get("available_at_utc"))
        if (
            len(records) != len(refs)
            or len(set(refs)) != len(refs)
            or set(indexed) != set(refs)
            or any(len(indexed.get(ref, [])) != 1 for ref in refs)
        ):
            blockers.append(f"{prefix}_availability_source_mismatch")
            return
        for ref in refs:
            available = _iso_time(indexed[ref][0])
            if available is None:
                blockers.append(f"{prefix}_availability_time_invalid")
            elif (cutoff is not None and available > cutoff) or (spine_asof is not None and available > spine_asof):
                blockers.append(f"{prefix}_source_published_after_cutoff")

    node_id = event.get("structure_node_id")
    target_id = event.get("target_relation_id")
    leg_id = event.get("force_leg_id")
    if event.get("object_kind") not in {"structure_node", "mixed"}:
        blockers.append("force_delivery_object_lacks_structure_role")
    if event.get("object_kind") == "structure_node" and event.get("named_object_id") != node_id:
        blockers.append("force_delivery_named_object_node_mismatch")

    nodes = spine.get("nodes") if isinstance(spine.get("nodes"), list) else []
    node_matches = [item for item in nodes if isinstance(item, dict) and item.get("node_id") == node_id]
    if not isinstance(node_id, str) or not node_id.strip() or len(node_matches) != 1:
        blockers.append("force_delivery_structure_node_unmapped_or_ambiguous")
        next_evidence.append("identify_unique_structure_step_and_belonging_timeframe")
    elif _truthy(node_matches[0], "target_relation_id") and node_matches[0].get("target_relation_id") != target_id:
        blockers.append("force_delivery_node_target_relation_mismatch")

    targets = spine.get("active_target_graph") if isinstance(spine.get("active_target_graph"), list) else []
    target_matches = [item for item in targets if isinstance(item, dict) and item.get("measurement_id") == target_id]
    if not isinstance(target_id, str) or not target_id.strip() or len(target_matches) != 1:
        blockers.append("force_delivery_target_unmapped_or_ambiguous")
        next_evidence.append("bind_delivery_to_one_active_target_graph_object")

    links = spine.get("force_links") if isinstance(spine.get("force_links"), list) else []
    leg_matches = [item for item in links if isinstance(item, dict) and item.get("force_leg_id") == leg_id]
    if not isinstance(leg_id, str) or not leg_id.strip() or len(leg_matches) != 1:
        blockers.append("force_delivery_force_leg_unmapped_or_ambiguous")
        next_evidence.append("bind_observed_force_leg_to_named_node_and_target")
        return blockers, next_evidence
    link = leg_matches[0]
    if link.get("timeframe") != event.get("same_timeframe"):
        blockers.append("force_delivery_event_force_timeframe_mismatch")
    if link.get("node_attempted_id") != node_id or link.get("target_or_measurement_id") != target_id:
        blockers.append("force_delivery_leg_node_target_chain_mismatch")
    if link.get("node_result") not in {"body_close", "accepted"}:
        blockers.append("force_delivery_leg_has_no_structural_body_close_or_acceptance")
    if event.get("boundary_outcome") == "accepted" and link.get("node_result") != "accepted":
        blockers.append("force_delivery_event_acceptance_not_in_force_link")
    if len(node_matches) == 1 and link.get("timeframe") != node_matches[0].get("timeframe") and (
        event.get("boundary_outcome") == "accepted"
        or event.get("classification_permission") == "delivery_candidate"
    ):
        close_time = _iso_time(event.get("node_close_observed_at_utc"))
        close_refs = event.get("node_close_source_refs")
        if not (
            event.get("node_close_observed") is True
            and event.get("node_close_timeframe") == node_matches[0].get("timeframe")
            and close_time is not None
            and isinstance(close_refs, list) and close_refs
            and all(isinstance(ref, str) and ref in case_source_refs for ref in close_refs)
        ):
            blockers.append("force_delivery_parent_node_close_not_source_bound")
            next_evidence.append("observe_source_bound_close_on_structure_nodes_belonging_timeframe")
        else:
            check_availability(close_refs, event.get("node_close_source_availability"), "force_delivery_parent_node_close")
            force_time = _iso_time(link.get("observed_at_utc"))
            if force_time is not None and close_time < force_time:
                blockers.append("force_delivery_parent_node_close_before_force")
            if (cutoff is not None and close_time > cutoff) or (spine_asof is not None and close_time > spine_asof):
                blockers.append("force_delivery_parent_node_close_after_cutoff")
    refs = link.get("source_refs")
    if not isinstance(refs, list) or not refs or any(
        not isinstance(ref, str) or not ref or ref not in case_source_refs for ref in refs
    ):
        blockers.append("force_delivery_leg_source_refs_unresolved")
    else:
        check_availability(refs, link.get("source_availability"), "force_delivery_leg")
    observed_at = _iso_time(link.get("observed_at_utc"))
    cutoff = _iso_time(decision_cutoff_utc)
    spine_asof = _iso_time(spine.get("as_of_utc"))
    if observed_at is None:
        blockers.append("force_delivery_leg_observation_time_missing")
    elif (cutoff is not None and observed_at > cutoff) or (spine_asof is not None and observed_at > spine_asof):
        blockers.append("force_delivery_leg_observation_after_cutoff")
    return blockers, next_evidence


def _constructed_reclaim_gates(reclaim: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Gate the line-outside construction → reclaim → retest sequence.

    A double bottom/top, a false balance name, or a one-bar line reclaim is
    deliberately insufficient.  This captures Alexander's source mechanism
    without making an unobservable order-flow claim or replacing the parent.
    """
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not reclaim:
        return blockers, next_evidence

    classification = reclaim.get("classification")
    allowed = {
        "construction_candidate", "reclaim_attempt", "retest_pending",
        "local_constructed_reclaim_confirmed", "accepted_breakdown_continuation", "unknown",
    }
    if classification not in allowed:
        blockers.append("constructed_reclaim_classification_invalid")
        return blockers, next_evidence
    if classification == "unknown":
        return blockers, next_evidence
    if not _truthy(reclaim, "structure_line_id") or not _truthy(reclaim, "line_timeframe"):
        blockers.append("constructed_reclaim_missing_named_line_or_timeframe")
        next_evidence.append("name_structure_line_and_belonging_timeframe")
    if reclaim.get("line_break_state") not in {"wick", "body_close", "accepted_outside", "unknown"}:
        blockers.append("constructed_reclaim_line_break_state_invalid")
    if reclaim.get("outside_construction") not in {"none", "balance_candidate", "double_bottom_top_candidate", "confirmed_balance", "unknown"}:
        blockers.append("constructed_reclaim_outside_construction_invalid")
    if reclaim.get("reclaim_close_state") not in {"not_seen", "wick_only", "body_close", "accepted", "unknown"}:
        blockers.append("constructed_reclaim_close_state_invalid")
    if reclaim.get("retest_state") not in {"not_seen", "pending", "held", "failed", "accepted_back_outside", "unknown"}:
        blockers.append("constructed_reclaim_retest_state_invalid")
    if reclaim.get("post_retest_creator_leg") not in {"not_seen", "candidate", "clear", "unknown"}:
        blockers.append("constructed_reclaim_creator_leg_state_invalid")
    if reclaim.get("orderflow_mechanism_status") not in {"source_explanation_not_observable", "not_claimed", None}:
        blockers.append("constructed_reclaim_claims_unobservable_orderflow_truth")

    if classification in {"construction_candidate", "reclaim_attempt", "retest_pending", "local_constructed_reclaim_confirmed"}:
        if reclaim.get("outside_construction") not in {"balance_candidate", "double_bottom_top_candidate", "confirmed_balance"}:
            blockers.append("constructed_reclaim_without_line_outside_construction")
            next_evidence.append("record_line_outside_balance_or_double_bottom_top_candidate")
    if classification in {"reclaim_attempt", "retest_pending", "local_constructed_reclaim_confirmed"}:
        if reclaim.get("reclaim_close_state") not in {"body_close", "accepted"}:
            blockers.append("constructed_reclaim_without_body_close_or_acceptance")
            next_evidence.append("observe_closed_reclaim_of_named_line")
    if classification == "local_constructed_reclaim_confirmed":
        if reclaim.get("retest_state") != "held":
            blockers.append("constructed_reclaim_confirmed_without_held_retest")
            next_evidence.append("observe_retest_hold_on_reclaimed_side")
        if reclaim.get("post_retest_creator_leg") != "clear":
            blockers.append("constructed_reclaim_confirmed_without_creator_leg")
            next_evidence.append("observe_same_side_creator_leg_after_retest")
    if classification == "accepted_breakdown_continuation":
        continued = (
            reclaim.get("line_break_state") == "accepted_outside"
            and reclaim.get("retest_state") in {"failed", "accepted_back_outside"}
        )
        if not continued:
            blockers.append("accepted_breakdown_without_outside_acceptance_and_failed_reclaim")
            next_evidence.append("observe_outside_acceptance_and_failed_or_outside_retest")
    if reclaim.get("claims_parent_replacement") is True and reclaim.get("separate_parent_acceptance_chain") is not True:
        blockers.append("constructed_reclaim_claims_parent_replacement_without_separate_acceptance_chain")
        next_evidence.append("run_parent_structure_transition_acceptance_chain_separately")
    return blockers, next_evidence


def _delivery_quality_container_gates(quality: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Keep force quality container-aware and separate from parent reversal."""
    blockers: List[str] = []
    next_evidence: List[str] = []
    if not quality:
        return blockers, next_evidence
    classification = quality.get("classification")
    allowed = {
        "trend_delivery_candidate", "weakening_continuation", "range_or_complex_pullback",
        "climax_transition_candidate", "countertrend_failure", "unknown",
    }
    if classification not in allowed:
        blockers.append("delivery_quality_classification_invalid")
        return blockers, next_evidence
    if classification == "unknown":
        return blockers, next_evidence
    if not _truthy(quality, "named_boundary_or_target_id") or not _truthy(quality, "timeframe"):
        blockers.append("delivery_quality_missing_named_boundary_or_timeframe")
        next_evidence.append("name_delivery_boundary_target_and_belonging_timeframe")
    if quality.get("container") not in {"wide_overlapping_channel", "tight_continuation_channel", "narrow_range", "expanded_range", "climactic_channel", "unknown"}:
        blockers.append("delivery_quality_container_invalid")
    if quality.get("body_quality") not in {"dominant", "mixed", "weak", "unknown"}:
        blockers.append("delivery_quality_body_invalid")
    if quality.get("close_location") not in {"extreme", "favorable_not_extreme", "interior", "unknown"}:
        blockers.append("delivery_quality_close_invalid")
    if quality.get("separation") not in {"clear", "partial", "none", "unknown"}:
        blockers.append("delivery_quality_separation_invalid")
    if quality.get("overlap") not in {"low", "mixed", "high", "unknown"}:
        blockers.append("delivery_quality_overlap_invalid")
    follow = quality.get("follow_through_state")
    if follow not in {"immediate", "delayed_confirmed", "pending", "poor", "rapid_reclaim", "unknown"}:
        blockers.append("delivery_quality_follow_through_invalid")
    if follow == "delayed_confirmed" and quality.get("follow_through_window_policy") != "named_timeframe_relative_policy":
        blockers.append("delivery_quality_delayed_follow_without_policy")
    if classification == "trend_delivery_candidate":
        required_quality = (
            quality.get("body_quality") == "dominant"
            and quality.get("close_location") in {"extreme", "favorable_not_extreme"}
            and quality.get("separation") == "clear"
            and quality.get("overlap") != "high"
            and follow in {"immediate", "delayed_confirmed"}
        )
        if not required_quality:
            blockers.append("trend_delivery_without_body_close_separation_and_followthrough")
            next_evidence.append("record_body_close_separation_and_policy_bound_followthrough")
    if classification == "weakening_continuation" and quality.get("claims_parent_replacement") is True:
        blockers.append("weakening_delivery_claims_parent_replacement")
    if classification == "climax_transition_candidate" and quality.get("claims_immediate_reversal") is True:
        blockers.append("climax_claims_immediate_reversal")
        next_evidence.append("retain_TBTL_range_and_reversal_competing_paths")
    if classification == "countertrend_failure" and quality.get("claims_parent_replacement") is True:
        blockers.append("countertrend_failure_claims_parent_replacement")
    if quality.get("claims_parent_replacement") is True and quality.get("separate_parent_acceptance_chain") is not True:
        blockers.append("delivery_quality_claims_parent_replacement_without_acceptance_chain")
    return blockers, next_evidence


def _second_attempt_counterforce_gates(state: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Audit an optional second-attempt chain without erasing a later counterforce.

    The Notes2 case distinguishes a weak first attempt, a second closed signal,
    initial follow-through and a *later* opposite force at a named node.  This
    gate is deliberately observational: it rejects an asserted confirmation or
    resumption that lacks its own as-of evidence; it never creates an entry.
    """
    if not state:
        return [], []
    blockers: List[str] = []
    next_evidence: List[str] = []
    phases = {
        "first_attempt_weak", "second_signal_close", "initial_followthrough",
        "counterforce_test", "resolution_after_counterforce", "unknown",
    }
    if state.get("phase") not in phases:
        blockers.append("second_attempt_counterforce_phase_invalid")
    if not _truthy(state, "current_node_id") or not _truthy(state, "timeframe"):
        blockers.append("second_attempt_counterforce_node_or_timeframe_unknown")
        next_evidence.append("name_current_timeframe_node_for_second_attempt_chain")
    if state.get("first_attempt_overlap") not in {"low", "mixed", "high", "unknown"}:
        blockers.append("second_attempt_first_overlap_invalid")
    if state.get("second_signal_close") not in {"inside", "outside", "reclaimed", "unknown"}:
        blockers.append("second_attempt_signal_close_invalid")
    if state.get("initial_followthrough") not in {"absent", "weak", "clear", "unknown"}:
        blockers.append("second_attempt_initial_followthrough_invalid")
    if state.get("claims_initial_confirmation") is True:
        if state.get("second_signal_close") != "outside" or state.get("initial_followthrough") != "clear":
            blockers.append("second_attempt_confirmation_without_outside_close_and_clear_followthrough")
            next_evidence.append("record_second_close_relation_and_same_timeframe_followthrough")
    counterforce_visible = state.get("counterforce_close") in {"body_close", "accepted"}
    if state.get("counterforce_close") not in {"not_seen", "wick", "body_close", "accepted", "unknown"}:
        blockers.append("second_attempt_counterforce_close_invalid")
    if state.get("counterforce_followthrough") not in {"not_seen", "weak", "clear", "unknown"}:
        blockers.append("second_attempt_counterforce_followthrough_invalid")
    if counterforce_visible and not _truthy(state, "counterforce_node_id"):
        blockers.append("second_attempt_counterforce_without_named_node")
        next_evidence.append("name_counterforce_origin_node_and_close_relation")
    if state.get("claims_original_delivery_resumed") is True and counterforce_visible:
        if state.get("post_counterforce_resolution") != "same_side_resumed_with_close":
            blockers.append("second_attempt_original_delivery_resumed_without_post_counterforce_close")
            next_evidence.append("observe_same_timeframe_close_resolving_counterforce")
    if state.get("claims_parent_replacement") is True and state.get("separate_parent_acceptance_chain") is not True:
        blockers.append("second_attempt_parent_replacement_without_parent_acceptance_chain")
    if state.get("later_outcome_used") is True:
        blockers.append("second_attempt_later_outcome_contamination")
    return blockers, next_evidence


def _iso_time(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value or value.lower() == "unknown":
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    return parsed.astimezone(timezone.utc)


def _multitimeframe_reversal_management_gates(
    record: Dict[str, Any]
) -> tuple[List[str], List[str]]:
    """Keep child reversal discovery, parent replacement and management separate."""
    if not record or record.get("recorded") is not True:
        return [], []
    blockers: List[str] = []
    next_evidence: List[str] = []
    required_identity = (
        "source_evidence_ids", "as_of_utc", "parent_task_id",
        "parent_timeframe", "working_timeframe", "child_timeframe",
    )
    if not all(_truthy(record, field) for field in required_identity):
        blockers.append("multitimeframe_reversal_identity_or_source_missing")
        next_evidence.append("bind_source_asof_parent_working_and_child_timeframes")

    stages = {
        "MT0_parent_active", "MT1_child_weakness", "MT2_child_opposite_break",
        "MT3_current_tf_success", "MT4_parent_test", "MT5_parent_accepted_change", "unknown",
    }
    stage = record.get("transition_stage")
    if stage not in stages:
        blockers.append("multitimeframe_reversal_stage_invalid")
    if record.get("holding_scope") not in {
        "scalp", "working_tf_swing", "parent_aligned_position", "unknown",
    }:
        blockers.append("multitimeframe_reversal_holding_scope_invalid")
    if record.get("parent_trend_state") not in {
        "healthy", "weakening", "climax_candidate", "transition", "accepted_change", "unknown",
    }:
        blockers.append("multitimeframe_reversal_parent_state_invalid")

    if stage in {"MT2_child_opposite_break", "MT3_current_tf_success", "MT4_parent_test", "MT5_parent_accepted_change"}:
        if not _truthy(record, "trend_weakness_evidence_ids"):
            blockers.append("multitimeframe_reversal_without_old_trend_weakness_evidence")
        if not _truthy(record, "opposite_break_object_id") or not _truthy(record, "opposite_break_timeframe"):
            blockers.append("multitimeframe_reversal_without_named_opposite_break")
        if record.get("opposite_close_state") not in {"body_close", "accepted"}:
            blockers.append("multitimeframe_reversal_without_closed_opposite_break")
        if record.get("opposite_followthrough_state") not in {"pending", "held"}:
            blockers.append("multitimeframe_reversal_without_opposite_followthrough_state")
    if stage == "MT3_current_tf_success" and not _truthy(record, "current_tf_success_evidence_ids"):
        blockers.append("multitimeframe_reversal_current_tf_success_without_evidence")
    if stage in {"MT4_parent_test", "MT5_parent_accepted_change"}:
        if not _truthy(record, "parent_protected_node_id") or not _truthy(record, "parent_close_acceptance_evidence_ids"):
            blockers.append("multitimeframe_reversal_parent_test_without_parent_node_and_close")
        if stage == "MT5_parent_accepted_change" and not _truthy(record, "old_parent_task_recovery_failure_ids"):
            blockers.append("multitimeframe_reversal_parent_change_without_failed_old_task_recovery")

    if record.get("climax_exception_claimed") is True:
        required = (
            "climax_location_ids", "climax_overextension_evidence_ids",
            "opposite_response_evidence_ids",
        )
        if not all(_truthy(record, field) for field in required):
            blockers.append("multitimeframe_reversal_climax_exception_without_location_overextension_and_response")
            next_evidence.append("bind_climax_to_parent_location_overextension_and_closed_opposite_response")
    if record.get("source_multiplier_promoted_to_global") is True:
        blockers.append("multitimeframe_reversal_source_multiplier_promoted_to_global_mapping")

    management_states = {
        "M0_initial_risk", "M1_held_followthrough", "M2_first_target_reached",
        "M3_counterforce_review", "M4_new_child_protection",
        "MX_task_invalidated_or_repriced", "unknown",
    }
    management_actions = {
        "unchanged", "breakeven", "partial_or_scalp_exit",
        "protect_behind_child_swing", "exit_or_rebuild", "unknown",
    }
    if record.get("management_state") not in management_states:
        blockers.append("multitimeframe_reversal_management_state_invalid")
    action = record.get("management_action")
    if action not in management_actions:
        blockers.append("multitimeframe_reversal_management_action_invalid")
    if action != "unknown" and not _truthy(record, "initial_invalidation_node_id"):
        blockers.append("multitimeframe_reversal_management_without_initial_invalidation")
    if action in {"breakeven", "partial_or_scalp_exit", "protect_behind_child_swing", "exit_or_rebuild"} and not _truthy(record, "management_evidence_ids"):
        blockers.append("multitimeframe_reversal_management_action_without_evidence")
    progress = record.get("post_entry_progress_state")
    if action == "breakeven" and progress not in {"clear_followthrough", "target1_reached"}:
        blockers.append("multitimeframe_reversal_breakeven_without_held_followthrough")
    if action == "protect_behind_child_swing" and (
        progress != "target1_reached"
        or not _truthy(record, "target1_id")
        or not _truthy(record, "new_child_protection_node_id")
    ):
        blockers.append("multitimeframe_reversal_child_swing_protection_without_target_and_node")
    if action == "partial_or_scalp_exit" and (
        record.get("holding_scope") != "scalp"
        and progress not in {"target1_reached", "counterforce"}
    ):
        blockers.append("multitimeframe_reversal_partial_exit_without_scope_target_or_counterforce")
    if action == "exit_or_rebuild" and progress != "task_invalidated":
        blockers.append("multitimeframe_reversal_exit_without_task_invalidation")
    if record.get("no_arbitrary_stop_widening") is not True:
        blockers.append("multitimeframe_reversal_allows_arbitrary_stop_widening")
    if record.get("later_outcome_used_for_asof") is True:
        blockers.append("multitimeframe_reversal_later_outcome_contamination")
    return blockers, next_evidence


def _theory_lens_composition_gates(
    composition: Dict[str, Any], decision_cutoff_utc: Any = None
) -> tuple[List[str], List[str]]:
    """Keep multiple hard theories role-composed, not vote-combined.

    The project treats the sources as lenses on one market process.  When a
    snapshot claims an explicit composition, each lens must declare its role,
    timeframe and observed object; no collection of labels may replace the
    structure→target→force/acceptance→container spine.
    """
    if not composition:
        return [], []
    blockers: List[str] = []
    next_evidence: List[str] = []
    if composition.get("same_market_process_asserted") is not True:
        blockers.append("theory_lens_composition_missing_common_market_process")
    if composition.get("composition_mode") != "role_partition_not_vote":
        blockers.append("theory_lens_composition_not_role_partitioned")
    if composition.get("primary_spine") != "structure_target_force_acceptance_container":
        blockers.append("theory_lens_composition_primary_spine_invalid")
    if composition.get("coincidence_counts_as_multiple_votes") is not False:
        blockers.append("theory_lens_composition_double_counts_coincident_evidence")
    allowed_roles = {
        "structure", "target_location", "force_acceptance", "container",
        "temporal_liquidity", "pda_ob_fvg_location", "distribution_balance",
        "momentum_quality", "time_window", "execution_quality", "risk_environment",
    }
    common_process_slots = {
        "task_background", "target_location", "liquidity_engagement",
        "creator_delivery", "close_acceptance", "container_reprice",
        "execution_risk",
    }
    allowed_effects = {
        # These are bounded changes to an already-named task.  They are not
        # directional votes.
        "context", "target_map", "attention_window", "location_candidate",
        "quality_assessment", "risk_constraint", "competing_path",
        "acceptance_evidence", "execution_geometry_input", "audit_only",
        "replace_parent_task",
    }
    allowed_effects_by_role = {
        "structure": {"context", "competing_path", "acceptance_evidence", "audit_only", "replace_parent_task"},
        "target_location": {"context", "target_map", "location_candidate", "risk_constraint", "competing_path", "audit_only"},
        "force_acceptance": {"context", "quality_assessment", "competing_path", "acceptance_evidence", "audit_only", "replace_parent_task"},
        "container": {"context", "quality_assessment", "competing_path", "risk_constraint", "audit_only"},
        "temporal_liquidity": {"context", "attention_window", "competing_path", "risk_constraint", "audit_only"},
        "pda_ob_fvg_location": {"context", "target_map", "location_candidate", "competing_path", "risk_constraint", "audit_only"},
        "distribution_balance": {"context", "location_candidate", "quality_assessment", "competing_path", "acceptance_evidence", "audit_only"},
        "momentum_quality": {"context", "quality_assessment", "competing_path", "audit_only"},
        "time_window": {"context", "attention_window", "risk_constraint", "competing_path", "audit_only"},
        "execution_quality": {"quality_assessment", "risk_constraint", "execution_geometry_input", "audit_only"},
        "risk_environment": {"context", "risk_constraint", "audit_only"},
    }
    forbidden_temporal_effects = {
        "acceptance_evidence", "execution_geometry_input", "replace_parent_task",
    }
    parameter_statuses = {
        "not_quantified_or_not_applicable", "source_parameter_only",
        "conditional_learning_pending", "not_recorded", "unknown",
    }
    as_of_states = {"observed_closed", "hypothesis", "retrospective", "unknown"}
    cutoff = _iso_time(decision_cutoff_utc)
    parent_chain_records = composition.get("parent_acceptance_chains")
    evidence_registry = composition.get("evidence_registry")
    evidence_by_id: Dict[str, Dict[str, Any]] = {}
    if evidence_registry is not None:
        if not isinstance(evidence_registry, list):
            blockers.append("theory_lens_evidence_registry_invalid")
        else:
            for evidence_record in evidence_registry:
                if not isinstance(evidence_record, dict):
                    blockers.append("theory_lens_evidence_record_invalid")
                    continue
                required = (
                    "evidence_id", "evidence_type", "task_id", "timeframe",
                    "object_ids", "observed_at_utc", "available_at_utc", "source_ref",
                )
                if not all(_truthy(evidence_record, field) for field in required):
                    blockers.append("theory_lens_evidence_record_incomplete")
                    continue
                evidence_id = evidence_record["evidence_id"]
                if evidence_id in evidence_by_id:
                    blockers.append("theory_lens_duplicate_evidence_id")
                    continue
                observed = _iso_time(evidence_record.get("observed_at_utc"))
                available = _iso_time(evidence_record.get("available_at_utc"))
                if observed is None or available is None:
                    blockers.append("theory_lens_evidence_time_boundary_missing_or_invalid")
                    continue
                if observed > available:
                    blockers.append("theory_lens_evidence_observed_after_available")
                    continue
                if cutoff is not None and (observed > cutoff or available > cutoff):
                    blockers.append("theory_lens_evidence_available_after_decision_cutoff")
                    continue
                evidence_by_id[evidence_id] = evidence_record
    verified_parent_chains: Dict[str, Dict[str, Any]] = {}
    if parent_chain_records is not None:
        if not isinstance(parent_chain_records, list):
            blockers.append("theory_lens_parent_acceptance_chains_invalid")
        else:
            for chain in parent_chain_records:
                if not isinstance(chain, dict):
                    blockers.append("theory_lens_parent_acceptance_chain_invalid")
                    continue
                required = (
                    "chain_id", "parent_task_id", "timeframe", "protected_node_id",
                    "close_acceptance_evidence_ids", "old_task_recovery_failure_ids",
                    "requesting_task_ids", "parent_child_relation_ids",
                    "as_of_utc", "available_at_utc", "source_evidence_ids",
                )
                if not all(_truthy(chain, field) for field in required):
                    blockers.append("theory_lens_parent_acceptance_chain_incomplete")
                    continue
                observed = _iso_time(chain.get("as_of_utc"))
                available = _iso_time(chain.get("available_at_utc"))
                if observed is None or available is None:
                    blockers.append("theory_lens_parent_acceptance_chain_time_invalid")
                    continue
                if observed > available or (cutoff is not None and (observed > cutoff or available > cutoff)):
                    blockers.append("theory_lens_parent_acceptance_chain_future_or_reversed_time")
                    continue
                close_ids = chain.get("close_acceptance_evidence_ids") or []
                failure_ids = chain.get("old_task_recovery_failure_ids") or []
                close_records = [evidence_by_id.get(evidence_id) for evidence_id in close_ids]
                failure_records = [evidence_by_id.get(evidence_id) for evidence_id in failure_ids]
                evidence_scope_valid = (
                    bool(close_records)
                    and bool(failure_records)
                    and all(record is not None for record in close_records + failure_records)
                    and all(
                        record.get("evidence_type") == "close_acceptance"
                        and record.get("task_id") == chain.get("parent_task_id")
                        and record.get("timeframe") == chain.get("timeframe")
                        and chain.get("protected_node_id") in (record.get("object_ids") or [])
                        for record in close_records
                    )
                    and all(
                        record.get("evidence_type") == "old_task_recovery_failure"
                        and record.get("task_id") == chain.get("parent_task_id")
                        and record.get("timeframe") == chain.get("timeframe")
                        for record in failure_records
                    )
                )
                if not evidence_scope_valid:
                    blockers.append("theory_lens_parent_acceptance_chain_evidence_unresolved_or_scope_mismatched")
                    continue
                verified_parent_chains[chain["chain_id"]] = chain
    lenses = composition.get("lenses")
    if not isinstance(lenses, list) or not lenses:
        blockers.append("theory_lens_composition_lenses_missing")
        next_evidence.append("record_source_role_timeframe_object_and_asof_for_each_lens")
        return blockers, next_evidence
    for lens in lenses:
        if not isinstance(lens, dict):
            blockers.append("theory_lens_composition_lens_invalid")
            continue
        role = lens.get("role")
        if not _truthy(lens, "source_id") or role not in allowed_roles:
            blockers.append("theory_lens_composition_source_or_role_invalid")
        source_refs = lens.get("source_evidence_ids")
        if (
            not _truthy(lens, "lens_id")
            or not isinstance(source_refs, list)
            or not any(_truthy({"value": ref}, "value") for ref in source_refs)
        ):
            blockers.append("theory_lens_identity_or_source_evidence_missing")
            next_evidence.append("bind_each_lens_to_a_claim_id_and_source_evidence")
        object_ids = lens.get("object_ids")
        if (
            not _truthy(lens, "task_id")
            or not _truthy(lens, "timeframe")
            or not isinstance(object_ids, list)
            or not any(_truthy({"value": value}, "value") for value in object_ids)
        ):
            blockers.append("theory_lens_composition_timeframe_or_objects_missing")
        slots = lens.get("common_process_slots")
        if not isinstance(slots, list) or not slots or any(slot not in common_process_slots for slot in slots):
            blockers.append("theory_lens_common_process_translation_missing_or_invalid")
            next_evidence.append("translate_the_source_term_to_one_or_more_common_process_slots_without_erasing_it")
        if not _truthy(lens, "source_term") or not _truthy(lens, "translation_term"):
            blockers.append("theory_lens_source_or_translation_term_missing")
        if lens.get("independent_direction_allowed") is not False:
            blockers.append("theory_lens_composition_independent_direction_not_forbidden")
        effect = lens.get("claimed_effect")
        if effect not in allowed_effects:
            blockers.append("theory_lens_composition_claimed_effect_invalid")
            next_evidence.append("declare_the_lens_bounded_effect_without_direction_vote")
        elif role in allowed_effects_by_role and effect not in allowed_effects_by_role[role]:
            blockers.append("theory_lens_role_effect_overreach")
            next_evidence.append("map_the_claim_to_an_effect_allowed_for_its_observed_role")
        if lens.get("role") == "temporal_liquidity" and effect in forbidden_temporal_effects:
            blockers.append("theory_lens_temporal_liquidity_overreaches_structure_or_execution")
            next_evidence.append("use_temporal_liquidity_for_window_attention_or_competing_path_not_direction_or_execution")
        parameter_status = lens.get("source_parameter_status")
        if parameter_status is not None:
            if parameter_status == "global_threshold_promoted":
                blockers.append("theory_lens_source_parameter_promoted_to_global_threshold")
                next_evidence.append("keep_source_parameter_conditional_and_learn_xauusd_boundaries_by_state")
            elif parameter_status not in parameter_statuses:
                blockers.append("theory_lens_source_parameter_status_invalid")
        as_of_state = lens.get("as_of_state")
        if as_of_state is not None and as_of_state not in as_of_states:
            blockers.append("theory_lens_asof_state_invalid")
        if as_of_state == "retrospective" and effect in {"acceptance_evidence", "execution_geometry_input"}:
            blockers.append("theory_lens_retrospective_evidence_claims_earlier_permission")
            next_evidence.append("keep_retrospective_interpretation_outside_the_original_asof_permission")
        available_at = _iso_time(lens.get("available_at_utc"))
        observed_at = _iso_time(lens.get("as_of_utc"))
        if available_at is None or observed_at is None:
            blockers.append("theory_lens_time_boundary_missing_or_invalid")
            next_evidence.append("record_observed_and_available_times_for_each_lens")
        else:
            if observed_at > available_at:
                blockers.append("theory_lens_observed_after_available_time")
                next_evidence.append("record_observation_before_or_at_its_source_availability_time")
            if cutoff is not None and (observed_at > cutoff or available_at > cutoff):
                blockers.append("theory_lens_evidence_available_after_decision_cutoff")
                next_evidence.append("exclude_future_observed_or_available_lens_from_original_asof_permission")
        if effect == "acceptance_evidence" and (
            not _truthy(lens, "lifecycle_ref") or not _truthy(lens, "state_evidence_ids")
        ):
            blockers.append("theory_lens_acceptance_effect_without_lifecycle_evidence")
        if effect == "execution_geometry_input" and not _truthy(lens, "execution_geometry_ref"):
            blockers.append("theory_lens_execution_effect_without_geometry_reference")
        if lens.get("observation_state") in {None, "unknown"} and effect in {
            "acceptance_evidence", "execution_geometry_input", "quality_assessment",
        }:
            blockers.append("theory_lens_unknown_observation_claims_completed_effect")
        if lens.get("forced_synonymy_forbidden") is not True:
            blockers.append("theory_lens_forced_synonymy_enabled")
        if effect == "replace_parent_task":
            chain_ref = lens.get("parent_acceptance_chain_ref")
            chain = verified_parent_chains.get(chain_ref)
            chain_scope_matches = bool(
                chain
                and lens.get("requested_parent_task_id") == chain.get("parent_task_id")
                and lens.get("task_id") in (chain.get("requesting_task_ids") or [])
                and lens.get("parent_child_relation_id") in (chain.get("parent_child_relation_ids") or [])
            )
            if (
                lens.get("separate_parent_acceptance_chain") is not True
                or not _truthy(lens, "parent_acceptance_chain_ref")
                or not chain_scope_matches
            ):
                blockers.append("theory_lens_composition_parent_replacement_without_acceptance_chain")
                next_evidence.append("bind_parent_replacement_request_to_a_resolvable_parent_acceptance_chain")

    lens_id_values = [
        lens.get("lens_id") for lens in lenses
        if isinstance(lens, dict) and _truthy(lens, "lens_id")
    ]
    lens_ids = set(lens_id_values)
    if len(lens_id_values) != len(lens_ids):
        blockers.append("theory_lens_duplicate_lens_id")
        next_evidence.append("assign_one_unique_identity_to_each_source_claim_lens")
    clusters = composition.get("causal_clusters")
    if clusters is not None:
        if not isinstance(clusters, list):
            blockers.append("theory_lens_causal_clusters_invalid")
        else:
            for cluster in clusters:
                if not isinstance(cluster, dict) or not _truthy(cluster, "causal_cluster_id"):
                    blockers.append("theory_lens_causal_cluster_identity_missing")
                    continue
                members = cluster.get("member_lens_ids")
                objects = cluster.get("member_object_ids")
                if not isinstance(members, list) or not members or not isinstance(objects, list) or not objects:
                    blockers.append("theory_lens_causal_cluster_members_or_objects_missing")
                if lens_ids and any(member not in lens_ids for member in (members or [])):
                    blockers.append("theory_lens_causal_cluster_unknown_lens_reference")
                if cluster.get("same_evidence_not_multiple_votes") is not True:
                    blockers.append("theory_lens_causal_cluster_double_counts_shared_evidence")

    measurement_relations = composition.get("cross_model_measurement_relations")
    if measurement_relations is not None:
        if not isinstance(measurement_relations, list):
            blockers.append("theory_lens_cross_model_measurement_relations_invalid")
        else:
            relation_ids: set[str] = set()
            for relation in measurement_relations:
                if not isinstance(relation, dict):
                    blockers.append("theory_lens_cross_model_measurement_relation_invalid")
                    continue
                required = (
                    "relation_id", "left_lens_id", "right_lens_id",
                    "left_measurement_family", "right_measurement_family",
                    "relation", "next_discriminating_evidence",
                )
                if not all(_truthy(relation, field) for field in required):
                    blockers.append("theory_lens_cross_model_measurement_relation_incomplete")
                    continue
                relation_id = relation["relation_id"]
                if relation_id in relation_ids:
                    blockers.append("theory_lens_cross_model_measurement_relation_id_duplicated")
                relation_ids.add(relation_id)
                if relation.get("left_lens_id") == relation.get("right_lens_id") or any(
                    lens_id not in lens_ids
                    for lens_id in (relation.get("left_lens_id"), relation.get("right_lens_id"))
                ):
                    blockers.append("theory_lens_cross_model_measurement_relation_lens_unresolved")
                if relation.get("relation") not in {"price_overlap", "task_compatible", "task_conflicted", "unknown"}:
                    blockers.append("theory_lens_cross_model_measurement_relation_type_invalid")
                if relation.get("source_specific_anchors_preserved") is not True:
                    blockers.append("theory_lens_cross_model_measurement_relation_erases_source_anchors")
                if relation.get("formula_equivalence") != "forbidden":
                    blockers.append("theory_lens_cross_model_measurement_relation_claims_formula_equivalence")
                if relation.get("coincidence_is_not_independent_direction_vote") is not True:
                    blockers.append("theory_lens_cross_model_measurement_relation_double_counts_overlap")
                if relation.get("future_outcome_used") is not False:
                    blockers.append("theory_lens_cross_model_measurement_relation_hindsight_contamination")

    branches = composition.get("unresolved_same_scope_branches")
    if branches is not None:
        if not isinstance(branches, list):
            blockers.append("theory_lens_same_scope_branches_invalid")
        else:
            for branch in branches:
                if not isinstance(branch, dict):
                    blockers.append("theory_lens_same_scope_branch_invalid")
                    continue
                required = ("branch_id", "task_id", "timeframe", "object_ids", "as_of_utc", "lens_ids", "competing_requirements")
                if not all(_truthy(branch, field) for field in required):
                    blockers.append("theory_lens_same_scope_branch_identity_or_requirements_missing")
                if branch.get("future_outcome_used") is not False:
                    blockers.append("theory_lens_same_scope_branch_hindsight_contamination")
                resolution_state = branch.get("resolution_state")
                if resolution_state == "unresolved":
                    blockers.append("theory_lens_same_scope_branch_unresolved")
                    next_evidence.append("observe_time_ordered_close_acceptance_target_or_risk_evidence_for_same_scope_branch")
                elif resolution_state == "resolved":
                    if not _truthy(branch, "resolution_evidence_ids"):
                        blockers.append("theory_lens_same_scope_branch_resolved_without_evidence")
                else:
                    blockers.append("theory_lens_same_scope_branch_resolution_state_invalid")
    return blockers, next_evidence


def evaluate_snapshot(snapshot: Dict[str, Any]) -> Decision:
    """Evaluate one as-of snapshot; never infer missing authority."""

    blockers: List[str] = []
    next_evidence: List[str] = []
    identity = snapshot.get("identity", {})
    evidence = snapshot.get("evidence_boundary", {})
    weekly = snapshot.get("weekly_profile", {})
    vp = snapshot.get("vp_profile_context", {})
    location = snapshot.get("location", {})
    structure = snapshot.get("structure", {})
    event = snapshot.get("liquidity_lifecycle", {})
    quality = snapshot.get("market_quality", {})
    al10_setup = snapshot.get("al10_setup") or {}
    execution = snapshot.get("execution_geometry", {})
    parent = snapshot.get("hierarchical_context", {})
    wave = snapshot.get("wave_and_measurement", {})
    digger = snapshot.get("digger_context", {})
    close_process = snapshot.get("timeframe_close_process", {})
    resonance = snapshot.get("timeframe_resonance", {})
    pattern_authority = snapshot.get("pattern_authority", {})
    breakout_force = snapshot.get("breakout_force", {})
    amd = snapshot.get("amd_context", {})
    high_probability_poi = snapshot.get("high_probability_poi_chain", {})
    institutional_origin_ob = snapshot.get("institutional_origin_ob_lifecycle", {})
    integrated_adjudication = snapshot.get("integrated_adjudication", {})
    structural_transition = snapshot.get("structural_transition", {})
    multitimeframe_background = snapshot.get("multitimeframe_background", {})
    kline86_context = snapshot.get("kline86_permission_context", {})
    threepush_measurement = snapshot.get("threepush_threewave_measurement", {})
    nested_delivery_task = snapshot.get("nested_delivery_task", {})
    trade_construction_pipeline = snapshot.get("trade_construction_pipeline", {})
    pullback_completion_audit = snapshot.get("pullback_completion_audit", {})
    nested_ratio_threepush = snapshot.get("nested_ratio_threepush_entry_admission", {})
    market_structure_spine = snapshot.get("market_structure_spine", {})
    force_sweep_interpretation = snapshot.get("force_sweep_interpretation", {})
    constructed_reclaim = snapshot.get("constructed_reclaim", {})
    delivery_quality = snapshot.get("delivery_quality", {})
    second_attempt_counterforce = snapshot.get("second_attempt_counterforce", {})
    multitimeframe_reversal_management = snapshot.get("multitimeframe_reversal_energy_management", {})
    theory_lens_composition = snapshot.get("theory_lens_composition", {})
    source_case = snapshot.get("source_case", {})
    elasticity = wave.get("elasticity_transition") or {}
    digger_gobi_state = _gobi_digger_adjudication(elasticity, digger)

    weekly_blockers, weekly_next_evidence = _weekly_profile_gates(weekly)
    blockers.extend(weekly_blockers)
    next_evidence.extend(weekly_next_evidence)
    weekly_execution_blockers, weekly_execution_next_evidence = _weekly_alexander_execution_context_gates(weekly)
    blockers.extend(weekly_execution_blockers)
    next_evidence.extend(weekly_execution_next_evidence)
    weekly_family_blockers, weekly_family_next_evidence = _weekly_family_resolution_gates(weekly)
    blockers.extend(weekly_family_blockers)
    next_evidence.extend(weekly_family_next_evidence)
    al10_blockers, al10_next_evidence = _al10_setup_gates(al10_setup)
    blockers.extend(al10_blockers)
    next_evidence.extend(al10_next_evidence)
    kline86_blockers, kline86_next_evidence = _kline86_permission_gates(kline86_context)
    blockers.extend(kline86_blockers)
    next_evidence.extend(kline86_next_evidence)
    weekly_event_blockers, weekly_event_next_evidence = _weekly_event_realization_gates(weekly)
    blockers.extend(weekly_event_blockers)
    next_evidence.extend(weekly_event_next_evidence)
    pattern_blockers, pattern_next_evidence = _pattern_authority_gates(pattern_authority, breakout_force)
    blockers.extend(pattern_blockers)
    next_evidence.extend(pattern_next_evidence)
    amd_blockers, amd_next_evidence = _amd_gates(amd)
    blockers.extend(amd_blockers)
    next_evidence.extend(amd_next_evidence)
    poi_blockers, poi_next_evidence = _high_probability_poi_gates(high_probability_poi)
    blockers.extend(poi_blockers)
    next_evidence.extend(poi_next_evidence)
    ob_lifecycle_blockers, ob_lifecycle_next_evidence = _institutional_origin_ob_lifecycle_gates(
        institutional_origin_ob, identity.get("decision_time_utc")
    )
    blockers.extend(ob_lifecycle_blockers)
    next_evidence.extend(ob_lifecycle_next_evidence)
    integrated_blockers, integrated_next_evidence = _integrated_adjudication_gates(integrated_adjudication)
    blockers.extend(integrated_blockers)
    next_evidence.extend(integrated_next_evidence)
    transition_blockers, transition_next_evidence = _structural_transition_gates(structural_transition)
    blockers.extend(transition_blockers)
    next_evidence.extend(transition_next_evidence)
    vp_balance_blockers, vp_balance_next_evidence = _vp_wyckoff_balance_gates(vp)
    blockers.extend(vp_balance_blockers)
    next_evidence.extend(vp_balance_next_evidence)
    background_blockers, background_next_evidence = _multitimeframe_background_gates(multitimeframe_background)
    blockers.extend(background_blockers)
    next_evidence.extend(background_next_evidence)
    threepush_blockers, threepush_next_evidence = _threepush_measurement_gates(threepush_measurement)
    blockers.extend(threepush_blockers)
    next_evidence.extend(threepush_next_evidence)
    nested_delivery_blockers, nested_delivery_next_evidence = _nested_delivery_task_gates(nested_delivery_task)
    blockers.extend(nested_delivery_blockers)
    next_evidence.extend(nested_delivery_next_evidence)
    pipeline_blockers, pipeline_next_evidence = _trade_construction_pipeline_gates(trade_construction_pipeline)
    blockers.extend(pipeline_blockers)
    next_evidence.extend(pipeline_next_evidence)
    route_priority_blockers, route_priority_next_evidence = _trade_route_reprioritization_gates(
        trade_construction_pipeline, market_structure_spine, identity.get("decision_time_utc"),
        _case_declared_source_refs(snapshot, identity),
    )
    blockers.extend(route_priority_blockers)
    next_evidence.extend(route_priority_next_evidence)
    timeframe_descent_blockers, timeframe_descent_next_evidence = _trade_pipeline_timeframe_descent_gates(
        trade_construction_pipeline
    )
    blockers.extend(timeframe_descent_blockers)
    next_evidence.extend(timeframe_descent_next_evidence)
    pullback_audit_blockers, pullback_audit_next_evidence = _pullback_completion_audit_gates(
        pullback_completion_audit,
        trade_construction_pipeline,
        identity.get("decision_time_utc"),
        market_structure_spine.get("as_of_utc") if isinstance(market_structure_spine, dict) else None,
        _case_declared_source_refs(snapshot, identity),
    )
    blockers.extend(pullback_audit_blockers)
    next_evidence.extend(pullback_audit_next_evidence)
    role_blockers, role_next_evidence = _measurement_target_role_gates(
        market_structure_spine,
        trade_construction_pipeline,
        identity.get("decision_time_utc"),
        _case_declared_source_refs(snapshot, identity),
    )
    blockers.extend(role_blockers)
    next_evidence.extend(role_next_evidence)
    nested_ratio_blockers, nested_ratio_next_evidence = _nested_ratio_threepush_entry_gates(
        nested_ratio_threepush,
        market_structure_spine,
        _case_declared_source_refs(snapshot, identity),
        identity.get("decision_time_utc"),
    )
    blockers.extend(nested_ratio_blockers)
    next_evidence.extend(nested_ratio_next_evidence)
    spine_blockers, spine_next_evidence = _market_structure_spine_gates(
        market_structure_spine, identity.get("decision_time_utc")
    )
    blockers.extend(spine_blockers)
    next_evidence.extend(spine_next_evidence)
    spine_authority_blockers, spine_authority_next_evidence = _structure_authority_presence_gate(
        market_structure_spine,
        trade_construction_pipeline,
        nested_delivery_task,
        nested_ratio_threepush,
        execution,
    )
    blockers.extend(spine_authority_blockers)
    next_evidence.extend(spine_authority_next_evidence)
    selected_chain_blockers, selected_chain_next_evidence = _selected_force_node_target_gates(
        market_structure_spine, trade_construction_pipeline,
        identity.get("decision_time_utc"), _case_declared_source_refs(snapshot, identity),
    )
    blockers.extend(selected_chain_blockers)
    next_evidence.extend(selected_chain_next_evidence)
    force_sweep_blockers, force_sweep_next_evidence = _force_sweep_interpretation_gates(force_sweep_interpretation)
    blockers.extend(force_sweep_blockers)
    next_evidence.extend(force_sweep_next_evidence)
    delivery_join_blockers, delivery_join_next_evidence = _force_delivery_spine_join_gates(
        force_sweep_interpretation, market_structure_spine,
        identity.get("decision_time_utc"), _case_declared_source_refs(snapshot, identity),
    )
    blockers.extend(delivery_join_blockers)
    next_evidence.extend(delivery_join_next_evidence)
    reclaim_blockers, reclaim_next_evidence = _constructed_reclaim_gates(constructed_reclaim)
    blockers.extend(reclaim_blockers)
    next_evidence.extend(reclaim_next_evidence)
    quality_blockers, quality_next_evidence = _delivery_quality_container_gates(delivery_quality)
    blockers.extend(quality_blockers)
    next_evidence.extend(quality_next_evidence)
    counterforce_blockers, counterforce_next_evidence = _second_attempt_counterforce_gates(second_attempt_counterforce)
    blockers.extend(counterforce_blockers)
    next_evidence.extend(counterforce_next_evidence)
    reversal_management_blockers, reversal_management_next_evidence = _multitimeframe_reversal_management_gates(
        multitimeframe_reversal_management
    )
    blockers.extend(reversal_management_blockers)
    next_evidence.extend(reversal_management_next_evidence)
    lens_blockers, lens_next_evidence = _theory_lens_composition_gates(
        theory_lens_composition, identity.get("decision_time_utc")
    )
    blockers.extend(lens_blockers)
    next_evidence.extend(lens_next_evidence)
    source_case_blockers, source_case_next_evidence = _source_case_provenance_gates(
        source_case,
        identity,
        execution,
        _case_declared_source_refs(snapshot, identity),
    )
    blockers.extend(source_case_blockers)
    next_evidence.extend(source_case_next_evidence)

    if not _truthy(identity, "decision_time_utc"):
        blockers.append("missing_decision_time")
    if evidence.get("future_dependency") is True:
        blockers.append("future_information_dependency")
    if evidence.get("source_bound") is not True:
        blockers.append("source_provenance_not_bound")
        next_evidence.append("bind_message_chart_or_data_source_to_asof_snapshot")
    source_refs = evidence.get("source_refs")
    if not isinstance(source_refs, list) or not any(isinstance(ref, str) and ref for ref in source_refs):
        blockers.append("source_provenance_reference_missing")
        next_evidence.append("record_at_least_one_stable_source_reference")
    if evidence.get("known_unknown_separated") is not True:
        blockers.append("asof_known_unknown_boundary_missing")
        next_evidence.append("separate_known_unknown_and_later_only_information")

    # A Weekly Profile is hard theory for temporal/liquidity context, but an
    # absent/no-profile state cannot manufacture a structural veto.  It blocks
    # only a caller that explicitly claims a Weekly-based execution authority;
    # otherwise retain the missing context as evidence to collect while the
    # structure→target→force→container chain remains independently auditable.
    if weekly.get("hypothesis_state") in {None, "precontext"}:
        if weekly.get("claims_weekly_execution_authority") is True:
            blockers.append("weekly_execution_claim_without_formed_profile")
        next_evidence.append("known_economic_window_and_candidate_release_side")

    if vp:
        if vp.get("independent_vote_allowed") is not False:
            blockers.append("vp_independent_vote_not_forbidden")
        if vp.get("autonomous_direction_forbidden") is not True:
            blockers.append("vp_claims_autonomous_direction")
        if vp.get("structure_role") in {"target_map", "liquidity_discovery", "retest_location"} and vp.get("price_action_gate") not in {"passed", "required"}:
            blockers.append("vp_location_role_without_price_action_gate")

    if not _truthy(location, "active_dol_queue"):
        blockers.append("active_dol_unknown")
        next_evidence.append("name_parent_dol_and_lifecycle_state")
    if not _truthy(location, "active_pd_arrays"):
        blockers.append("pd_array_unknown")
        next_evidence.append("bind_location_to_parent_pd_array")

    event_state = event.get("acceptance", {})
    sweep_state = event.get("sweep", {})
    if not (_truthy(sweep_state, "confirmed") or _truthy(event_state, "confirmed")):
        blockers.append("liquidity_event_not_confirmed")
        next_evidence.append("closed_sweep_or_valid_retest")

    local = structure.get("local_events", [])
    if not local:
        blockers.append("local_trigger_missing")
        next_evidence.append("closed_local_displacement_and_structure_change")

    parent_acceptance = structure.get("parent_acceptance") or {}
    if parent_acceptance.get("confirmed") is not True:
        blockers.append("parent_acceptance_missing")
        next_evidence.append("parent_timeframe_close_and_no_reentry")

    if quality.get("news_state") in {"event", "gap"}:
        blockers.append("news_contamination")
    if quality.get("spread_known") is not True:
        blockers.append("spread_unknown")
    if quality.get("slippage_known") is not True:
        blockers.append("slippage_unknown")

    for key in ("candidate_entry", "invalidation_object", "first_target", "effective_rr_after_costs"):
        if not _truthy(execution, key):
            blockers.append(f"execution_{key}_missing")
    if isinstance(execution.get("effective_rr_after_costs"), (int, float)) and execution["effective_rr_after_costs"] <= 0:
        blockers.append("non_positive_effective_rr")

    entry_modality = execution.get("entry_modality")
    if entry_modality == "brooks_force_close_discouraged":
        blockers.append("discouraged_brooks_force_close_entry")
    if entry_modality == "smc_location_micro_close":
        confirmation = execution.get("micro_confirmation") or {}
        if confirmation.get("bar_closed") is not True:
            blockers.append("micro_close_entry_before_closed_bar")
            next_evidence.append("specified_lower_timeframe_closed_confirmation_bar")

    if close_process:
        if close_process.get("framework_premise") != "alexander_timeframe_close_liquidity_condition":
            blockers.append("timeframe_close_premise_not_declared")
        if close_process.get("direction_from_close_time_alone") != "forbidden":
            blockers.append("timeframe_close_claims_autonomous_direction")
        observations = close_process.get("observations", [])
        if not isinstance(observations, list):
            blockers.append("timeframe_close_observations_invalid")
        else:
            for observation in observations:
                if not isinstance(observation, dict):
                    blockers.append("timeframe_close_observation_invalid")
                    continue
                if observation.get("permission_effect") == "supports_existing_chain":
                    has_response = (
                        observation.get("close_body_relation") in {"outside", "reclaimed"}
                        or observation.get("post_close_follow_through") == "confirmed"
                    )
                    if not has_response:
                        blockers.append("timeframe_close_support_without_closed_response")
                        next_evidence.append("closed_price_response_at_named_timeframe_boundary")

    if resonance:
        if resonance.get("direction_from_ratio_alone") != "forbidden":
            blockers.append("timeframe_resonance_claims_autonomous_direction")
        if resonance.get("relation") == "exact_fourfold" and resonance.get("adjacent_ratio") != 4:
            blockers.append("timeframe_resonance_exact_without_four_ratio")

    if digger.get("integration_status") == "mapped_crosscheck":
        mappings = digger.get("mapped_objects", [])
        has_exact_mapping = any(
            isinstance(item, dict)
            and item.get("mapping_status") == "exact"
            and item.get("same_feed_and_timezone") == "yes"
            for item in mappings
        )
        if digger.get("chart_identity_verified") != "yes" or not has_exact_mapping:
            blockers.append("digger_crosscheck_unmapped_or_cross_feed")
            next_evidence.append("verify_digger_object_against_same_feed_timezone_primary_object")
    if digger.get("permission_effect") in {"supports_location_map", "supports_continuation_quality"} and digger.get("autonomous_direction_forbidden") is not True:
        blockers.append("digger_context_claims_autonomous_direction")

    if digger_gobi_state == "conflicted_wait":
        blockers.append("digger_gobi_conflict_unresolved")
        next_evidence.append("closed_price_action_resolve_digger_hold_fold_vs_elasticity")

    if elasticity:
        if elasticity.get("observed_on_closed_bar") != "yes":
            blockers.append("elasticity_transition_not_closed_bar")
        if elasticity.get("parent_elasticity_state") == "expanding" and elasticity.get("child_elasticity_state") == "countermove":
            candidate_direction = execution.get("direction")
            counter_direction = elasticity.get("child_countermove_direction")
            if candidate_direction is None:
                next_evidence.append("execution_direction_for_elasticity_hierarchy")
            elif counter_direction in {"long", "short"} and candidate_direction == counter_direction:
                blockers.append("elasticity_countermove_against_expanding_parent")
                next_evidence.append("parent_target_or_structure_change_before_countertrend_execution")

    parent_states = {
        tf: state.get("state")
        for tf, state in parent.items()
        if isinstance(state, dict)
    }

    if blockers:
        action = "BLOCKED" if any("missing" in b or "unknown" in b or "contamination" in b for b in blockers) else "WATCH"
        return Decision(
            action=action,
            permission="BLOCKED",
            blockers=sorted(set(blockers)),
            next_evidence=sorted(set(next_evidence)),
            state={
                "parent_states": parent_states,
                "statistical_prior_can_authorize": False,
                "elasticity_hierarchy": elasticity or "not_recorded",
                "gobi_digger_adjudication": digger_gobi_state,
                "timeframe_close_process": close_process or "not_recorded",
                "timeframe_resonance": resonance or "not_recorded",
                "vp_profile_context": vp or "not_recorded",
                "entry_modality": entry_modality or "not_recorded",
                "pattern_authority": pattern_authority or "not_recorded",
                "breakout_force": breakout_force or "not_recorded",
                "amd_context": amd or "not_recorded",
                "high_probability_poi_chain": high_probability_poi or "not_recorded",
                "institutional_origin_ob_lifecycle": institutional_origin_ob or "not_recorded",
                "integrated_adjudication": integrated_adjudication or "not_recorded",
                "structural_transition": structural_transition or "not_recorded",
                "multitimeframe_background": multitimeframe_background or "not_recorded",
                "kline86_permission_context": kline86_context or "not_recorded",
                "threepush_threewave_measurement": threepush_measurement or "not_recorded",
                "market_structure_spine": market_structure_spine or "not_recorded",
                "force_sweep_interpretation": force_sweep_interpretation or "not_recorded",
                "constructed_reclaim": constructed_reclaim or "not_recorded",
                "delivery_quality": delivery_quality or "not_recorded",
                "second_attempt_counterforce": second_attempt_counterforce or "not_recorded",
                "multitimeframe_reversal_energy_management": multitimeframe_reversal_management or "not_recorded",
                "theory_lens_composition": theory_lens_composition or "not_recorded",
                "weekly_event_realization": weekly.get("event_realization") or "not_recorded",
            },
        )

    return Decision(
        action="RESEARCH_CANDIDATE",
        permission="AUTHORIZED",
        state={
            "parent_states": parent_states,
            "statistical_prior_can_authorize": False,
            "elasticity_hierarchy": elasticity or "not_recorded",
            "gobi_digger_adjudication": digger_gobi_state,
            "timeframe_close_process": close_process or "not_recorded",
            "timeframe_resonance": resonance or "not_recorded",
            "vp_profile_context": vp or "not_recorded",
            "entry_modality": entry_modality or "not_recorded",
            "pattern_authority": pattern_authority or "not_recorded",
            "breakout_force": breakout_force or "not_recorded",
            "amd_context": amd or "not_recorded",
            "high_probability_poi_chain": high_probability_poi or "not_recorded",
            "institutional_origin_ob_lifecycle": institutional_origin_ob or "not_recorded",
            "integrated_adjudication": integrated_adjudication or "not_recorded",
            "structural_transition": structural_transition or "not_recorded",
            "multitimeframe_background": multitimeframe_background or "not_recorded",
            "kline86_permission_context": kline86_context or "not_recorded",
            "threepush_threewave_measurement": threepush_measurement or "not_recorded",
            "market_structure_spine": market_structure_spine or "not_recorded",
            "force_sweep_interpretation": force_sweep_interpretation or "not_recorded",
            "constructed_reclaim": constructed_reclaim or "not_recorded",
            "delivery_quality": delivery_quality or "not_recorded",
            "second_attempt_counterforce": second_attempt_counterforce or "not_recorded",
            "multitimeframe_reversal_energy_management": multitimeframe_reversal_management or "not_recorded",
            "theory_lens_composition": theory_lens_composition or "not_recorded",
            "weekly_event_realization": weekly.get("event_realization") or "not_recorded",
        },
    )
