"""Use verified buffers at explicit task C events in the real scene reducer.

State and review priority are engineering workflow decisions. No conversion of
an indicator's geometry into author elasticity, author hold, or trade admission.
"""
from collections import Counter
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import json
import math

VERSION='gobi_digger_task_review_v1'


def time(value):
    try:
        t=datetime.fromisoformat(str(value).replace('Z','+00:00'))
        return t.astimezone(timezone.utc) if t.tzinfo else None
    except (ValueError,TypeError):return None


def receipt(value):
    return sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def task_review(task, context, cutoff, minutes):
    tf=task.get('timeframe');owner=task.get('owner_id');source=task.get('source_id')
    out=dict(task_id=task.get('task_id'),task_owner_id=owner,task_source_id=source,native_timeframe=tf,
        as_of_utc=cutoff,known_at_utc=context.get('known_at_utc'),state='wait_task_identity',
        binding='unverified',owner_equivalence=False,entry_permission=False,blockers=[])
    now=time(cutoff);known=time(task.get('known_at_utc'))
    if (not task.get('task_id') or not owner or not source or task.get('own_C_valid') is not True
            or time(task.get('as_of_utc'))!=now or known is None or now is None or known>now
            or task.get('automatic_trade_permission',False) is not False):
        out['blockers']=['task_identity_or_clock_invalid'];return out
    direction=task.get('direction')
    if direction not in (-1,1) or isinstance(direction,bool):
        out['blockers']=['task_direction_unknown'];return out
    ind=context.get('process_indicators') or {};frame=(ind.get('gobi') or {}).get(tf)
    if (ind.get('task_frame') or {}).get('native_timeframe')==tf:frame=ind['task_frame']
    if not frame:
        out.update(state='wait_native_indicator',blockers=['own_native_frame_missing']);return out
    c=(task.get('source') or {}).get('C') or {}
    pivot=time(c.get('pivot_timestamp_utc'));confirmed=time(c.get('confirmed_at_utc'))
    try:price=float(c['price'])
    except (ValueError,TypeError,KeyError):price=float('nan')
    if (pivot is None or confirmed is None or not math.isfinite(price) or confirmed>now
            or confirmed<pivot+timedelta(minutes=minutes[tf])):
        out.update(state='wait_native_anchor',blockers=['C_confirmation_missing_or_invalid']);return out
    rows=frame['input_bars'];series=frame['series']
    index=next((i for i,b in enumerate(rows) if time(b['timestamp_utc'])==pivot),None)
    if index is None:
        out.update(state='wait_native_anchor',blockers=['C_bar_outside_retained_native_window']);return out
    bar=rows[index]
    if price!=bar['low' if direction==1 else 'high']:
        out.update(state='wait_native_anchor',blockers=['C_price_not_own_native_extreme']);return out
    # This binds a measurement request to the named C bar, not a claim that
    # the historical task already existed at the pivot/confirmation timestamp.
    out.update(binding='explicit_task_C_native_bar_verified',C=deepcopy(c),C_input_bar=deepcopy(bar),
        C_indicator=deepcopy(series[index]),sampling_role='retrospective_C_measurement_at_current_task_asof',
        source_claims=deepcopy(ind['source_claims']),producer_receipt_id=context['producer_receipt_id'])
    out['fractal_variant_at_C']={period:dict(
        source_identity=obs['source_identity'],original_attachment_parity=obs['original_attachment_parity'],
        observation=next((deepcopy(r) for r in obs['records'] if time(r['pivot_bar_utc'])==pivot
                          and r['kind']==('low' if direction==1 else 'high')),None),
        relation='same_native_C_bar_comparison_not_author_confirmation')
        for period,obs in frame.get('fractal_variant_observations',{}).items()}
    latest=frame['latest'];out['latest_indicator']=deepcopy(latest)
    out['known_at_utc']=max([context['known_at_utc'],task['known_at_utc'],c['confirmed_at_utc']],key=time)
    terminal=task.get('target_state') in {'already_reached','invalidated_source'}
    if terminal:
        out.update(state='retired_task',blockers=['task_target_already_reached_or_source_invalidated']);return out
    if task.get('target_state')!='pending':
        out.update(state='wait_task_lifecycle',blockers=['task_target_state_unknown']);return out
    pivot_map=context.get('pivotgauge_context') or {}
    pivot_events=[]
    if pivot_map.get('chart_timeframe')==tf:
        for level in pivot_map.get('levels',[]):
            events=[deepcopy(e) for e in level['process']['events'] if time(e['bar_open_utc'])>=confirmed]
            if events:
                pivot_events.append(dict(object_id=level['object_id'],level_period=level['native_timeframe'],
                    formula_family=level['formula_family'],source_timeframe=level['source_timeframe'],
                    source_construction=level['source_construction'],price=level['price'],events=events,
                    relation='post_C_location_context_not_owner_equivalence'))
    out['post_C_pivotgauge_events']=pivot_events
    sequence=context.get('digger_sequence_observations')
    if sequence is not None and sequence.get('interaction_timeframe')==tf:
        out['post_C_digger_sequence']=[dict(object_id=o['object_id'],level_native_timeframe=o['level_native_timeframe'],
            left_censored=o['left_censored'],relation='post_C_observed_path_not_author_hold_or_target',
            events=[deepcopy(e) for e in o['events'] if time(e['bar_open_utc'])>=confirmed])
            for o in sequence['objects'] if any(time(e['bar_open_utc'])>=confirmed for e in o['events'])]
    inventory=context.get('digger_event_time_inventory')
    if inventory is not None and inventory.get('chart_timeframe')==tf:
        bysource={s['source_version_id']:s for s in inventory['source_versions']}
        streams={s['source_version_id']:s for s in inventory['source_streams']}
        eligible=[e for e in inventory['events'] if time(e['bar_open_utc'])>=confirmed]
        out['post_C_digger_inventory']=[dict(source_version_id=sid,
            position_object_id=bysource[sid]['position_object_id'],feed_id=inventory['feed_identity']['feed_id'],
            active_in_current_inventory=streams[sid]['active_in_current_inventory'],
            relation='post_C_event_time_inventory_not_author_hold_target_or_owner',
            events=[deepcopy(e) for e in eligible if e['source_version_id']==sid])
            for sid in sorted({e['source_version_id'] for e in eligible})]
    out['pivotgauge_probability_status']=pivot_map.get('probability_status','not_produced')
    if any(latest.get(k) is None or series[index].get(k) is None for k in ('fast_k','slow_k')):
        out.update(state='wait_indicator_warmup',blockers=['C_or_latest_K_support_incomplete']);return out
    # Native discontinuities in the measured C->asof interval are never silently
    # treated as continuous price delivery (weekend/calendar cause is unknown).
    gaps=[g for g in frame['timestamp_discontinuities'] if time(g['right'])>pivot]
    if gaps:
        out.update(state='wait_native_continuity',blockers=['C_to_asof_native_gap_unresolved'],gaps=deepcopy(gaps));return out
    divergences=[d for d in frame['divergence_observations']
        if time(d['price_pivots'][1]['pivot_bar_utc'])>=pivot and confirmed<=time(d['known_at_utc'])<=now]
    aligned=[d for d in divergences if d['kind'].endswith('bullish' if direction==1 else 'bearish')]
    contrary=[d for d in divergences if d not in aligned]
    v=(context['gobi_observations'].get(tf) or {}).get('v_pattern') or {}
    # The source three-bar pattern must be at/after this task's C; a pattern
    # whose oldest bar predates C cannot be reassigned to that C event.
    v_eligible=bool(v.get('bar_refs')) and all(time(t)>=pivot for t in v['bar_refs'])
    desired='bullish_closed_shape' if direction==1 else 'bearish_closed_shape'
    v_closed=v_eligible and desired in v.get('shapes',[])
    inside=v.get('inside_fourth_observation') or {}
    if (inside.get('directional_fourth_close') is True and inside.get('shape')==
            ('bullish_inside_exception' if direction==1 else 'bearish_inside_exception')
            and all(time(t)>=pivot for t in inside['bar_refs'])):v_closed=True
    motion=latest['fast_k_change']
    recovery=motion is not None and motion*direction>0 and latest['separation_change']=='narrowing'
    out.update(numerical_recovery_compatible=recovery,closed_V_compatible=v_closed,
        aligned_divergence_geometry=deepcopy(aligned),contrary_divergence_geometry=deepcopy(contrary))
    # Digger events belong to explicit location objects and this chart period.
    # Never attach another timeframe's chart events to the task.
    location=[]
    digger=ind.get('digger') or {}
    if digger.get('interaction_timeframe')==tf:
        for line in digger.get('level_processes',[]):
            events=[deepcopy(e) for e in line['events'] if time(e['bar_open_utc'])>=confirmed]
            if events:location.append(dict(object_id=line['object_id'],native_timeframe=line['native_timeframe'],
                price=line['price'],events=events,relation='post_C_location_context_not_owner_equivalence'))
    out['post_C_location_events']=location
    out['state']=('review_conflicting_geometry' if contrary and (aligned or v_closed or recovery) else
        'review_recovery_geometry' if v_closed and recovery else
        'review_divergence_geometry' if aligned else 'wait_closed_price_confirmation')
    out['blockers']=['author_elasticity_sufficiency_unknown','independent_parent_acceptance_required',
        'author_hold_fold_unknown','author_fractal_parity_unverified']
    return out


def build_review(scene,context,minutes):
    cutoff=scene.get('cutoff_utc')
    base=dict(schema=VERSION,as_of_utc=cutoff,timeframe=scene.get('timeframe'),status='unavailable',tasks=[],
        review_queue=[],state_counts={},read_only=True,automatic_trade_permission=False,
        entry_permission=False,future_bars_used=False,score_effect='none',direction_effect='none')
    if context.get('status')!='consumed_native_observations' or not context.get('process_indicators'):
        base['reason']='verified_process_indicators_missing';return base
    tasks=[task_review(t,context,cutoff,minutes) for t in (scene.get('structure_logic') or {}).get('tasks',[])]
    base.update(status='task_measurements_evaluated',tasks=tasks,
        producer_receipt_id=context['producer_receipt_id'],known_at_utc=context['known_at_utc'],
        state_counts=dict(Counter(t['state'] for t in tasks)))
    rank={'review_conflicting_geometry':0,'review_recovery_geometry':1,'review_divergence_geometry':2,
          'wait_closed_price_confirmation':3}
    base['review_queue']=[dict(task_id=t['task_id'],task_owner_id=t['task_owner_id'],state=t['state'],
        next_required='independent_parent_and_location_acceptance',binding=t['binding'])
        for t in sorted(tasks,key=lambda t:(rank.get(t['state'],9),str(t['task_id']))) if t['state'] in rank]
    base['receipt_id']=receipt(base)
    return base


def attach_review(scene,packet,context,minutes):
    review=build_review(scene,context,minutes);packet['gobi_digger_review']=review
    key=lambda t:(t.get('task_id'),t.get('task_owner_id',t.get('owner_id')),t.get('native_timeframe',t.get('timeframe')))
    keys=Counter(key(t) for t in review['tasks'])
    by_id={key(t):t for t in review['tasks'] if t['task_id'] and keys[key(t)]==1}
    for task in (scene.get('structure_logic') or {}).get('tasks',[]):
        task['gobi_digger_review']=deepcopy(by_id.get(key(task)))
    for route in packet.get('routes',[]):
        route['gobi_digger_review']=deepcopy(by_id.get(key(route)))
    if isinstance(scene.get('book_logic'),dict):scene['book_logic']['gobi_digger_review']=deepcopy(review)
    return review
