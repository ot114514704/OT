"""Follow a same-bar Book dual close on its frozen geometry for three subsequent H1 bars."""
from collections import Counter
from fractions import Fraction

from book_viewport_structure import stamp


def line_at(anchors, anchor, position, index):
    left, right = anchors[:2]
    first, last = index[left[0]], index[right[0]]
    slope = (Fraction(str(right[1])) - Fraction(str(left[1]))) / (last - first)
    return Fraction(str(anchor[1])) + slope * (position - index[anchor[0]])


def observe(bars, index, event, last, report):
    """Read through last only. Preserve separate clocks for the cross and later evidence."""
    observations = []
    for pair in report.get('pairs', []):
        if pair['event'] != 'same_bar':
            continue
        event_close = stamp(bars[event].closed_at)
        if report['clock'] != event_close or pair['pair_known'] > stamp(bars[event].time):
            raise ValueError('Book pair was not frozen before this event')
        sign = 1 if pair['direction'] == 'down' else -1
        former_extreme = Fraction(str(pair['terminal'][1]))
        first_reentry = None
        new_extreme = None
        records = []
        gap = None
        for j in range(event, min(event + 3, last) + 1):
            if j > event and bars[j-1].closed_at != bars[j].time:
                gap = stamp(bars[j].time)
                break
            clock = stamp(bars[j].closed_at)
            close = Fraction(str(bars[j].close))
            trend = line_at(pair['trend'], pair['trend'][0], j, index)
            turning = line_at(pair['turning'], pair['turning'][2], j, index)
            trend_side = sign * (close - trend)
            turning_side = sign * (close - turning)
            outside = trend_side > 0 and turning_side > 0
            if j == event and not outside:
                raise ValueError('Frozen rails do not reproduce the original close')
            # Returning to the safe side of the turning line requires a strict close.
            # A later close must clear the old wave extreme to document both observations.
            if first_reentry and not new_extreme and sign * (close - former_extreme) < 0:
                new_extreme = clock
            if turning_side < 0 and first_reentry is None:
                first_reentry = clock
            records.append(dict(clock=clock, close=float(close), trend=float(trend), turning=float(turning),
                                outside_both=outside, turning_relation='outside' if turning_side > 0 else
                                'inside' if turning_side < 0 else 'touch'))
        observations.append(dict(owner=pair['owner'], direction=pair['direction'], event=event_close,
                                 former_extreme=float(former_extreme), observations=records, gap_at=gap,
                                 first_reentry=first_reentry, later_directional_extreme=new_extreme))
    return observations


def summary(items):
    groups = Counter()
    for item in items:
        records = item['observations']
        count = len(records) - 1
        if item['later_directional_extreme']:
            status = '收回拐点线后再收过原波段极值'
        elif item['gap_at']:
            status = f'已跟踪{count}根，缺柱中止'
        elif not count:
            status = '双破后待下一收盘'
        elif item['first_reentry']:
            status = f'已收回拐点线，现居线{dict(inside="内",outside="外",touch="上")[records[-1]["turning_relation"]]}'
        elif all(r['outside_both'] for r in records[1:]):
            status = f'后续连续{count}根仍收在双线外'
        else:
            status = '双线外收盘未持续，尚无拐点线收回'
        groups[status] += 1
    return 'Book双破跟踪：' + '、'.join(f'{s} {n}组' for s,n in groups.items()) + '；A点另核'

