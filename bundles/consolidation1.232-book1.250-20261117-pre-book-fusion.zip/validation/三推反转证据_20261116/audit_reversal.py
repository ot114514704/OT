import sys,json,re,copy,subprocess,hashlib
from pathlib import Path
H=Path(__file__).parent;ROOT=Path('D:/盘整研究资料/项目/盘整研究');EXP=ROOT/'mt5/experiment'
sys.path.insert(0,str(EXP))
import audit_pa_shapes_1246 as original
from audit_original_overlay import adapt
from build_original_overlay import function

oldsource=original.translated_source()
original.SOURCE=H/'staging';newsource=original.translated_source()
assert newsource==oldsource,'Original classifier changed'
header=(H/'staging/BookThreePushReversal.mqh').read_text('utf-8')
code=newsource+'\n'+adapt(header[:header.index('string OverlayReversalPhase(')])
cases=[]
def add(name,c,phase):
    for suffix,case in [('',c),('_mirror',original.mirror(c))]:
        cases.append(dict(name=name+suffix,case=case,phase=phase))
base=original.fixture();append=original.appended
add('candidate',base,1)
rail=append(base,109);add('rail_only',rail,2)
struct=append(rail,107);add('structure_only',struct,3)
follow=append(struct,106);add('later_close_follow',follow,4)
add('flat_close_not_progress',append(struct,107),3)
add('reclaim_before_follow',append(struct,109),5)
add('reclaim_after_follow',append(follow,108),5)
add('third_extreme_invalidates',append(rail,118),5)
add('wrong_way_first_exit',append(base,130),5)
wick=append(base,114,90);add('wick_is_not_close_break',wick,1)
forming=copy.deepcopy(follow);forming['cutoff']-=60;add('forming_follow_excluded',forming,3)
forming['rows'][-1].update(open=9999,high=9999,low=-9999,close=9999)
add('future_extremes_ignored',forming,3)
bad=append(struct,106);bad['rows'][-1]['high']=bad['rows'][-1]['low']-1;add('invalid_follow_data_stop',bad,6)
gap=append(struct,106);gap['rows'][-1]['time']+=60;gap['cutoff']+=60;add('missing_bar_no_immediate_follow',gap,3)
gap=append(gap,105);add('resumed_consecutive_closed_follow',gap,4)
late=append(append(append(base,107),106),105);late['group']['known']=late['cutoff']
add('preknow_break_not_backdated',late,6)
flag=append(original.fixture(-1,True),90);add('continuation_not_reversal',flag,0)
unknown=copy.deepcopy(base);unknown['strict']=False
for r in unknown['rows'][:30]:r.update(open=100,close=100,high=101,low=99)
add('unverified_background_not_reversal',append(unknown,90),0)

native=[];captured=ROOT/'work/threepush_completeness_20261110'
for period,seconds in [('H1',3600),('M15',900)]:
    rows=json.loads((captured/f'{period}_closed.json').read_text('utf-8'))[-4000:]
    groups=json.loads((captured/f'{period}_original_recent4000.json').read_text('utf-8'))
    native.append(dict(period=period,seconds=seconds,rows=rows,groups=groups,cutoff=rows[-1]['time']+seconds,strict=False))
host=r'''
const fs=require('fs'),assert=require('assert/strict'),i=JSON.parse(fs.readFileSync(0,'utf8'));
const ArraySize=a=>a.length,ArrayResize=(a,n)=>{while(a.length<n)a.push({});a.length=n;return n};
const MathIsValidNumber=Number.isFinite,MathMin=Math.min,MathMax=Math.max,MathAbs=Math.abs;
eval(i.source);
function evaluate(c){let o={},v={};OverlayPAEvaluate(c.rows,c.group,c.seconds,c.cutoff,o,c.strict??true);
 const before=JSON.stringify({p:c.group,o});OverlayReversalEvaluate(c.rows,c.group,o,c.seconds,c.cutoff,v);
 assert.equal(JSON.stringify({p:c.group,o}),before,'Existing anchors/PA changed');return {o,v};}
let checks=[];
for(const t of i.cases){const {v}=evaluate(t.case);assert.equal(v.phase,t.phase,t.name+JSON.stringify(v));
 if(v.follow)assert.ok(v.known<=v.rail&&v.rail<=v.structure&&v.structure<v.follow&&v.follow<=t.case.cutoff);
 for(const k of ['rail','structure','follow','failed','checked'])assert.ok(v[k]<=t.case.cutoff);
 checks.push({name:t.name,passed:true,...v});}
for(const t of i.legacy){const {o}=evaluate(t.case);assert.equal(o.category,t.category,t.name);assert.equal(o.state,t.state,t.name);}
let prefixChecks=0;
function prefixes(c,cutoffs){let frozen={};for(const cutoff of cutoffs){
 const full=evaluate({...c,cutoff}),truncated=evaluate({...c,cutoff,rows:c.rows.filter(r=>r.time+c.seconds<=cutoff)});
 assert.deepEqual(full,truncated,'Future rows changed closed evidence');
 for(const key of ['rail','structure','follow','failed']){if(frozen[key])assert.equal(full.v[key],frozen[key],key+' changed');if(full.v[key])frozen[key]=full.v[key];}
 prefixChecks++;}}
for(const t of i.cases)prefixes(t.case,t.case.rows.filter(r=>r.time+t.case.seconds>=t.case.group.known&&r.time+t.case.seconds<=t.case.cutoff).map(r=>r.time+t.case.seconds));
const native=i.native.map(c=>{const rows=c.groups.map(group=>({known:group.known,start:group.points[0].time,...evaluate({...c,group})}));
 let eligible=rows.filter(r=>r.o.category===1);for(const item of eligible.slice(0,4)){
 const group=c.groups.find(g=>g.known===item.known&&g.points[0].time===item.start);
 prefixes({...c,group},c.rows.filter(r=>r.time+c.seconds>=group.known).slice(0,32).map(r=>r.time+c.seconds));}
 return {period:c.period,bars:c.rows.length,groups:rows};});
process.stdout.write(JSON.stringify({checks,legacyChecks:i.legacy.length,prefixChecks,native}));
'''
run=subprocess.run(['node','-e',host],input=json.dumps(dict(source=code,cases=cases,legacy=original.fixtures(),native=native)),text=True,encoding='utf-8',capture_output=True,timeout=120)
assert run.returncode==0,run.stderr[-6000:]
result=json.loads(run.stdout)
(H/'reversal_native_and_fixtures.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
report=dict(passed=True,fixtures=len(result['checks']),legacy_checks=result['legacyChecks'],closed_prefix_checks=result['prefixChecks'],original_classifier_byte_identical=True,
    native=[dict(period=c['period'],bars=c['bars'],groups=len(c['groups']),reversal_candidates=sum(g['o']['category']==1 for g in c['groups']),phases={str(k):sum(g['v']['phase']==k for g in c['groups']) for k in range(7)}) for c in result['native']],
    scope='Actual MQL numerical evaluator translated to JS; captured native input and deterministic causal fixtures. Not native EX5 UI verification, historical accuracy or a strategy backtest.')
(H/'reversal_acceptance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(report,ensure_ascii=False))
