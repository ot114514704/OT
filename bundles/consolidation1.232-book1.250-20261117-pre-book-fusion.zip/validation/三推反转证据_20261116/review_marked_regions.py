import json,sys,subprocess
from pathlib import Path
from datetime import datetime,timezone
H=Path(__file__).parent;ROOT=Path('D:/盘整研究资料/项目/盘整研究')
sys.path.insert(0,str(ROOT/'mt5/experiment'))
import audit_pa_shapes_1246 as pa
from audit_original_overlay import adapt
pa.SOURCE=H/'staging'
text=(H/'staging/BookThreePushReversal.mqh').read_text('utf-8')
source=pa.translated_source()+'\n'+adapt(text[:text.index('string OverlayReversalPhase(')])
capture=ROOT/'work/threepush_completeness_20261110'
rows=json.loads((capture/'H1_closed.json').read_text('utf-8'))
groups=json.loads((capture/'H1_original_all_groups.json').read_text('utf-8'))
regions=[('july_consolidation_first','2026-07-29','2026-08-05'),('august_channel','2026-08-05','2026-08-08'),('august_late_channel','2026-08-21','2026-08-29')]
cases=[]
stamp=lambda d:int(datetime.fromisoformat(d).replace(tzinfo=timezone.utc).timestamp())
for name,start,end in regions:
    left,right=stamp(start),stamp(end)
    selected=[g for g in groups if g['points'][0]['time']<right and g['points'][-1]['time']>=left]
    cases.append(dict(name=name,left=left,right=right,groups=selected))
host=r'''
const fs=require('fs'),i=JSON.parse(fs.readFileSync(0,'utf8'));
const ArraySize=a=>a.length,ArrayResize=(a,n)=>{while(a.length<n)a.push({});a.length=n;return n};
const MathIsValidNumber=Number.isFinite,MathMin=Math.min,MathMax=Math.max,MathAbs=Math.abs;
eval(i.source);
let results=i.cases.map(c=>({name:c.name,left:c.left,right:c.right,groups:c.groups.map(p=>{
 let o={},v={},cutoff=c.right+3*86400;OverlayPAEvaluate(i.rows,p,3600,cutoff,o,false);OverlayReversalEvaluate(i.rows,p,o,3600,cutoff,v);
 return {known:p.known,anchors:p.points.map(x=>({time:x.time,price:x.price,kind:x.kind})),category:o.category,state:o.state,classification_reason:o.reason,reversal:v};})}));
process.stdout.write(JSON.stringify(results));
'''
run=subprocess.run(['node','-e',host],input=json.dumps(dict(source=source,rows=rows,cases=cases)),capture_output=True,text=True,encoding='utf-8',timeout=90)
assert run.returncode==0,run.stderr
result=json.loads(run.stdout)
report=dict(regions=result,scope='Previously captured native H1 and existing Book groups overlapping user-marked dates. This is not exact manual-boundary matching, fresh terminal data, or an alternative three-push detector. Each region evaluated only through three days after its endpoint.')
(H/'marked_regions_review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps([dict(name=c['name'],overlapping_groups=len(c['groups']),categories=[g['category'] for g in c['groups']]) for c in result]))
