from pathlib import Path
import shutil,subprocess,time,hashlib,json
H=Path(__file__).parent
R=Path('D:/盘整研究资料/项目/盘整研究/mt5/experiment/pa_reversal_1250')
S=H/'d_receipt_build'
S.mkdir(exist_ok=False)
for p in R.iterdir():
    if p.suffix in ('.mq5','.mqh'): shutil.copy2(p,S/p.name)
p=S/'BookPADisplay.mqh'
old=p.read_text('utf-8')
needle='FileOpen("BookThreePushReversal_"'
assert old.count(needle)==1
p.write_text(old.replace(needle,'FileOpen("IPDA_Consolidation\\\\BookThreePushReversal_"'),'utf-8')
source=S/'book三推形态_PA.mq5';log=S/'compile.log';started=time.time()
subprocess.run(['C:/Program Files/MetaTrader 5/MetaEditor64.exe','/compile:'+str(source),'/log:'+str(log)],creationflags=subprocess.CREATE_NO_WINDOW,timeout=60)
assert source.with_suffix('.ex5').stat().st_mtime>=started
assert '0 errors, 0 warnings' in log.read_text('utf-16')
for dest in (R,Path('D:/盘整研究资料/安装/Book_PA_Shapes')):
    for name in ('BookPADisplay.mqh','book三推形态_PA.ex5'):shutil.copy2(S/name,dest/name)
report={'change':'Only new reversal TSV location routed through existing D-drive IPDA_Consolidation junction','compiled':'0 errors, 0 warnings','binary_sha256':hashlib.sha256(source.with_suffix('.ex5').read_bytes()).hexdigest(),'native_reload_pending':True}
(H/'d_receipt_build.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(report))
