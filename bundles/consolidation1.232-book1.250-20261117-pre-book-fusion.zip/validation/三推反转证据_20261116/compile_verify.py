from pathlib import Path
import subprocess,time,json,hashlib,sys,re
H=Path(__file__).parent;ROOT=Path('D:/盘整研究资料/项目/盘整研究');SRC=H/'staging'
sys.path.insert(0,str(ROOT/'mt5/experiment'))
def function(text,name):
    match=re.search(r'^(?:void|bool|int|double|color|string) '+re.escape(name)+r'\(',text,re.M)
    assert match,name
    start=text.index('{',match.start());end=start+1;depth=1
    while depth:
        depth+=(text[end]=='{')-(text[end]=='}');end+=1
    return text[match.start():end]
source=SRC/'book三推形态_PA.mq5';log=H/'compile.log';start=time.time()
subprocess.run(['C:/Program Files/MetaTrader 5/MetaEditor64.exe','/compile:'+str(source),'/log:'+str(log)],creationflags=subprocess.CREATE_NO_WINDOW,timeout=60)
assert log.stat().st_mtime>=start and source.with_suffix('.ex5').stat().st_mtime>=start
assert '0 errors, 0 warnings' in log.read_text('utf-16'),log.read_text('utf-16')[-2500:]
base=ROOT/'mt5/experiment/pa_shapes'
same=[]
for name in ('Machine1_UnifiedNativeKernel.mqh','Machine1_UnifiedNativeLegacyPush.mqh','Machine1_UnifiedNativeColours.mqh','BookThreePushPA.mqh','BookThreePushWindow.mqh'):
    assert (base/name).read_bytes()==(SRC/name).read_bytes(),name;same.append(name)
for filename,names in [('BookPADisplay.mqh',['PADrawGroup','PATileEnd','PAGroupId']),('BookPAVisual.mqh',['PAInk','PAState','PAShort','PALabelLane','PAPixelText','PANativeText','PALabel','PAPushLabels','PAVisualControls'])]:
    old=(base/filename).read_text('utf-8');new=(SRC/filename).read_text('utf-8')
    for name in names:
        assert function(old,name)==function(new,name),name;same.append(name)
report=dict(passed=True,compiled='0 errors, 0 warnings',version='1.250',unchanged=same,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(source.with_suffix('.ex5').read_bytes()).hexdigest(),native_reload_pending=True,scope='Compiled evidence extension; original admission and geometry renderer preserved. No native visual acceptance claimed.')
(H/'compile_acceptance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(report,ensure_ascii=False))
