from pathlib import Path
import json,hashlib,shutil,zipfile,time
H=Path(__file__).parent;ROOT=Path('D:/盘整研究资料/项目/盘整研究')
BASE=ROOT/'mt5/experiment/pa_shapes';SRC=H/'staging';DEST=ROOT/'mt5/experiment/pa_reversal_1250'
audit=json.loads((H/'reversal_acceptance.json').read_text('utf-8'))
compiled=json.loads((H/'compile_acceptance.json').read_text('utf-8'))
assert audit['passed'] and compiled['passed']
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(SRC/'book三推形态_PA.ex5')==compiled['binary_sha256']
backup=H/'before_1249'
assert not backup.exists() and not DEST.exists(),'Existing preparation must be inspected before replacing'
shutil.copytree(BASE,backup);DEST.mkdir(parents=True)
for p in SRC.iterdir():
    if p.suffix in ('.mq5','.mqh','.ex5'):shutil.copy2(p,DEST/p.name)
files={p.name:digest(p) for p in DEST.iterdir() if p.is_file()}
oldprov=json.loads((BASE/'PROVENANCE.json').read_text('utf-8'))
provenance=dict(version='1.250',baseline_version='1.249',original_admission_geometry_and_labels_unchanged=True,
    description='Independent first-attempt reversal evidence, alongside original PA classification; no signal/order execution.',
    policy=dict(eligible='Only existing category 1 same-direction converging reversal candidates with validated native six anchors',
                structural_level='Original fourth-index point: the pullback preceding the third push',
                follow='A later closed bar stays beyond that level and advances beyond structural-break close; immediate predecessor must be adjacent native period',
                failure='Close beyond third-push extreme, wrong-way first boundary exit, or reclaim of structural level after its break; first attempt stops and earlier evidence remains',
                unverified='Category 4 background, continuation categories, invalid data, early break and forming bars cannot confirm reversal',
                phase4='Reverse structure and later-close evidence present; not a claim that a full trend reversal is proven'),
    baseline_provenance=oldprov,files=files,evidence=str(H/'reversal_acceptance.json'))
install=dict(version='1.250',prepared=True,compiled=True,compile_result='0 errors, 0 warnings',installed=False,native_reload_verified=False,native_visual_verified=False,
    installed_version_kept='1.249',installed_source_untouched=True,
    pending='Native chart reload and inspection require resuming computer interaction after the user Escape interruption. Current generated bundle is on D only.',files=files)
(DEST/'PROVENANCE.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2),'utf-8')
(DEST/'INSTALLATION.json').write_text(json.dumps(install,ensure_ascii=False,indent=2),'utf-8')
(DEST/'PA_AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),'utf-8')
shutil.copy2(H/'compile.log',DEST/'compile.log')
(DEST/'README.txt').write_text('三推反转证据扩展 1.250：已编译，尚未替换当前MT5 1.249。\n\n保留原Book六点、原三推准入、旗楔分类、轮廓、颜色、标题及布局。新增独立说明和TSV证据，不新增交易操作或图形锚点。\n\n反转证据阶段：未建立背景 → 候选 → 反向收盘破轨 → 关键回撤点突破 → 后续收盘反向推进。破轨与结构突破可以同柱，后续跟进必须来自另一根已收盘K线。影线穿越不算收盘接受，形成柱不算确认。\n\n跟踪首轮尝试：收盘越过第三推极值、首次沿原推动方向越轨，或结构突破后又收回关键位，记录首轮失效/回收并停止。已有破轨、结构及跟进时间保留；不把后来重新上涨/下跌倒签成首轮成功。数据错误停止证据链。结构与后续收盘已具备并不等于已证明完整趋势反转，也不用于改写原PA状态。\n\n单组说明顶部增加阶段；完整触发价格、逐事件时间与原因在工具提示中；每次已收盘模型重建更新 BookThreePushReversal_<ChartID>.tsv，拖图不会重复计算或重复写该记录。\n\n验证：36个反转用例、41个原分类用例、172次截断比较；H1/M15各4000根已捕获原生柱、共126组原Book三推。原分类和几何/标签函数保持一致。原生加载、交互、说明可读性尚未验收；全历史准确性不由这些有限检查证明。\n\n部署时只更新当前已存在的PA实例，不增加重复实例；先保留1.249回退点，保持H1周期和可见区域，按现有实例属性重载后核对锚点、布局、说明与TSV。不要自动恢复此前被用户停止的电脑操作。','utf-8')
manifest=[dict(path=p.name,sha256=digest(p),bytes=p.stat().st_size) for p in sorted(DEST.iterdir()) if p.is_file()]
(DEST/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),'utf-8')
package=H/'三推反转证据_1.250_待原生验收.zip'
with zipfile.ZipFile(package,'x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(DEST.iterdir()):
        if p.is_file():z.write(p,p.name)
with zipfile.ZipFile(package) as z:
    for item in manifest:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
terminal=Path('C:/Users/qkn/AppData/Roaming/MetaQuotes/Terminal/D0E8209F77C8CF37AD8BF550E51FF075/MQL5/Indicators/Book_PA_Shapes')
old=json.loads((BASE/'INSTALLATION.json').read_text('utf-8'))
for name,expected in old['files'].items():
    assert digest(BASE/name)==expected and digest(terminal/name)==expected,name
report=dict(prepared_at=time.time(),project=str(DEST),package=str(package),package_sha256=digest(package),package_bytes=package.stat().st_size,files_verified=len(manifest),baseline_backup=str(backup),installed_1249_unchanged=True,native_acceptance_pending=True)
(H/'delivery.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(report,ensure_ascii=False))
