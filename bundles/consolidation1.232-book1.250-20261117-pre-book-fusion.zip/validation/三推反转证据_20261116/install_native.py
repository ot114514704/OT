"""Keep physical indicator files on D:, preserving the prior C: directory."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path

H=Path(__file__).parent
READY=Path('D:/盘整研究资料/项目/盘整研究/mt5/experiment/pa_reversal_1250')
DEST=Path('D:/盘整研究资料/安装/Book_PA_Shapes')
INDICATORS=Path('C:/Users/qkn/AppData/Roaming/MetaQuotes/Terminal/D0E8209F77C8CF37AD8BF550E51FF075/MQL5/Indicators')
CURRENT=INDICATORS/'Book_PA_Shapes'
PREVIOUS=INDICATORS/'Book_PA_Shapes_beforeD_20261117'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
accept=json.loads((H/'compile_acceptance.json').read_text('utf-8'))
assert accept['passed'] and sha(READY/'book三推形态_PA.ex5')==accept['binary_sha256']
assert CURRENT.is_dir() and not os.path.isjunction(CURRENT) and not CURRENT.is_symlink()
assert CURRENT.resolve().parent==INDICATORS.resolve()
assert not DEST.exists() and not PREVIOUS.exists()
assert DEST.drive.upper()=='D:' and DEST.parent.resolve()==Path('D:/盘整研究资料/安装').resolve()
old={p.relative_to(CURRENT).as_posix():sha(p) for p in CURRENT.rglob('*') if p.is_file()}
assert all(sha(H/'before_1249'/rel)==digest for rel,digest in old.items()),'Installed PA baseline changed'
shutil.copytree(READY,DEST)
assert all(sha(DEST/p.name)==sha(p) for p in READY.iterdir() if p.is_file())
script=r"""
$parent = 'C:\Users\qkn\AppData\Roaming\MetaQuotes\Terminal\D0E8209F77C8CF37AD8BF550E51FF075\MQL5\Indicators'
$source = Join-Path $parent 'Book_PA_Shapes'
$previous = Join-Path $parent 'Book_PA_Shapes_beforeD_20261117'
$destination = 'D:\盘整研究资料\安装\Book_PA_Shapes'
if ((Resolve-Path -LiteralPath $source).Path -ne $source) { throw 'Unexpected resolved source' }
if ((Split-Path -Parent $previous) -ne $parent -or (Test-Path -LiteralPath $previous)) { throw 'Unexpected preserved path' }
if ((Resolve-Path -LiteralPath $destination).Path -ne $destination) { throw 'Unexpected D destination' }
Rename-Item -LiteralPath $source -NewName 'Book_PA_Shapes_beforeD_20261117' -ErrorAction Stop
try { New-Item -ItemType Junction -Path $source -Target $destination -ErrorAction Stop | Out-Null }
catch { Rename-Item -LiteralPath $previous -NewName 'Book_PA_Shapes' -ErrorAction Stop; throw }
"""
subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],check=True,
    creationflags=subprocess.CREATE_NO_WINDOW,capture_output=True,text=True)
assert os.path.isjunction(CURRENT) and CURRENT.resolve()==DEST.resolve()
assert all(sha(PREVIOUS/rel)==digest for rel,digest in old.items())
assert sha(CURRENT/'book三推形态_PA.ex5')==accept['binary_sha256']
receipt=dict(at=time.time(),version='1.250',installed_on_disk=True,native_reload_pending=True,
    physical_installation=str(DEST),terminal_junction=str(CURRENT),previous_1249_directory=str(PREVIOUS),
    old_files_preserved=old,new_binary_sha256=accept['binary_sha256'],book_original_overlay_changed=False)
(H/'native_installation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='old_files_preserved'},ensure_ascii=False))
