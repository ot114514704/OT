@echo off
cd /d "%~dp0"
"C:\Users\qkn\AppData\Local\Programs\Python\Python312\python.exe" -X utf8 app.py --port 8773 --snapshot-dir work/live_8773/data
pause
