$ErrorActionPreference = 'Stop'
$projectPath = $PSScriptRoot
$pythonPath = Join-Path $projectPath '.venv\Scripts\python.exe'
$pythonWindowless = Join-Path $projectPath '.venv\Scripts\pythonw.exe'
if (-not (Test-Path -LiteralPath $pythonWindowless)) { throw '未找到 pythonw.exe' }
& $pythonPath -c 'import MetaTrader5, tzdata; from zoneinfo import ZoneInfo; ZoneInfo("America/New_York")'
if ($LASTEXITCODE -ne 0) { throw '独立运行环境依赖不完整，未启用任务' }
$supervisorPath = Join-Path $projectPath 'supervisor.py'
$stopPath = Join-Path $projectPath 'work\live_8773\stop.request'
if (Test-Path -LiteralPath $stopPath) { Remove-Item -LiteralPath $stopPath }
$arguments = '"' + $supervisorPath + '"'
$taskName = 'IPDA-Consolidation-8773'
$currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$action = New-ScheduledTaskAction -Execute $pythonWindowless -Argument $arguments -WorkingDirectory $projectPath
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $currentUser
$principal = New-ScheduledTaskPrincipal -UserId $currentUser -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
$existing = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($existing -and ($existing.Actions.Arguments -ne $arguments -or $existing.Actions.WorkingDirectory -ne $projectPath)) { throw '同名计划任务属于其他程序，未覆盖' }
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description '本用户登录后守护盘整研究8773，只读行情，不下单。' -Force | Out-Null
Start-ScheduledTask -TaskName $taskName
Write-Output '已启用登录自启与后台守护：IPDA-Consolidation-8773'
