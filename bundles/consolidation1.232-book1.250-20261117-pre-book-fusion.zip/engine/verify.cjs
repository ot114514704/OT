const {chromium}=require('playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true});
 try{
  const page=await browser.newPage({viewport:{width:1500,height:1200}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:8772/');
  await page.waitForFunction(()=>document.querySelectorAll('.episode').length>0,null,{timeout:90000});
  const data=await page.evaluate(async()=>await(await fetch('/api/state')).json());
  assert.ok(data.charts.H1.bars.length>0);assert.ok(data.charts.M15.episodes.length>0);
  for(const chart of Object.values(data.charts)){
   assert.equal(chart.bars.at(-1).closed_at,chart.closed_end);
   for(const e of chart.episodes){assert.ok(e.score.score>=0&&e.score.score<=100);assert.equal(e.score.maximum,100);assert.ok(e.first_known_at<=e.observed_at)}
  }
  await page.locator('.episode').first().click();
  await page.waitForFunction(()=>document.querySelector('.episode.active'));
  assert.ok((await page.locator('#details').innerText()).includes('/100'));
  await page.locator('#range').selectOption('120');
  await page.locator('#latest').click();
  assert.equal(await page.locator('.episode.active').count(),0);
  assert.deepEqual(errors,[]);
  await page.screenshot({path:'preview.png',fullPage:true});
  console.log(JSON.stringify({status:data.status,error:data.analysis_error,H1:data.charts.H1.episodes.length,M15:data.charts.M15.episodes.length,quote:data.quote,browserErrors:errors}));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
