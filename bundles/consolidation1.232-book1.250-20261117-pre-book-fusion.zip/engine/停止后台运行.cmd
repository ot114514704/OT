@echo off
cd /d "%~dp0"
python supervisor.py --stop
echo 已请求停止本项目后台守护。再次运行启用后台运行.ps1可恢复。
pause
