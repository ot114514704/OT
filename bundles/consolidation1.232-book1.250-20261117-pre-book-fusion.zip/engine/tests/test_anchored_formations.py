import json,unittest
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
from datetime import timedelta
from ict_trader.core import Bar,instant
from ict_trader.anchored_formations import observe_anchored_formations,anchored_convergence
from ict_trader.candidate_audit import candidate_evidence_errors
from ict_trader.freeze_ledger import active_ranges,_exit_after
from ict_trader.mt5_bridge import display_records
from ict_trader.display_selection import select_balance_first
from tests.test_consolidation_invariants import transformed


class AnchoredFormationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        rows=json.loads((Path(__file__).parent/'fixtures/h1_august_outer_channel.json').read_text('utf-8'))
        cls.bars=[Bar(instant(r['time']),*(r[k] for k in ('open','high','low','close')),r['spread'],3600) for r in rows]
        cls.result=observe_anchored_formations(cls.bars,cls.bars[-1].closed_at)
        cls.channel=next(x for x in cls.result['structural_ranges'] if x['observed_from']=='2026-08-25T03:00:00+00:00')
        cls.triangle=next(x for x in cls.result['geometric_ranges'] if x['observed_from']=='2026-08-28T20:00:00+00:00')

    def test_native_full_shapes_and_display(self):
        self.assertEqual(self.channel['first_observed_at'],'2026-08-26T23:00:00+00:00')
        self.assertEqual(self.channel['geometry']['frame'][0]['price'],4696.75)
        self.assertEqual(self.channel['end_at'],'2026-08-28T20:00:00+00:00')
        self.assertEqual(self.triangle['first_observed_at'],'2026-08-31T18:00:00+00:00')
        self.assertEqual(self.triangle['end_at'],'2026-09-01T09:00:00+00:00')
        self.assertEqual(self.triangle['geometry']['frame'][0]['time'],self.triangle['observed_from'])
        from ict_trader.viewport_history import recognize
        selected=select_balance_first(recognize(dict(bars=self.bars,period='H1'))['records'])
        ids={x.split('\t')[12] for x in selected}
        self.assertIn(self.channel['id'],ids);self.assertIn(self.triangle['id'],ids)
        self.assertNotIn('price_structure_candidate_v5:72:auto:2026-08-27T12:00:00+00:00',ids)

    def test_first_known_frozen_and_future_independent(self):
        for kind,box in [('structural',self.channel),('geometric',self.triangle)]:
            known=instant(box['first_observed_at'])
            prefix=observe_anchored_formations(self.bars,known)
            first=next(x for x in prefix[kind+'_ranges'] if x['id']==box['id'])
            for key in ('geometry','checks','metrics','observed_from'):self.assertEqual(first[key],box[key])
            earlier=observe_anchored_formations(self.bars,known-timedelta(seconds=1))
            self.assertFalse(any(x['id']==box['id'] for x in earlier[kind+'_ranges']))
            changed=[replace(b,open=b.open+1000,high=b.high+1000,low=b.low+1000,close=b.close+1000) if b.closed_at>known else b for b in self.bars]
            self.assertEqual(prefix,observe_anchored_formations(changed,known))
            self.assertEqual(candidate_evidence_errors(box,self.bars,kind),[])
            forged=deepcopy(box);forged['geometry']['frame'][0]['price']+=1
            self.assertIn('candidate_frozen_geometry_source',candidate_evidence_errors(forged,self.bars,kind))

    def test_price_mirror_and_no_m15_change(self):
        mirror=observe_anchored_formations(transformed(self.bars,-1,10000),self.bars[-1].closed_at)
        matching=next(x for x in mirror['structural_ranges'] if x['observed_from']==self.channel['observed_from'])
        self.assertIn(':low:',matching['id'])
        self.assertAlmostEqual(matching['slope_per_bar'],-self.channel['slope_per_bar'])
        short=[replace(b,seconds=900) for b in self.bars]
        self.assertFalse(any(observe_anchored_formations(short,short[-1].closed_at).values()))

    def test_gap_and_active_exit_use_native_candle_axis(self):
        start=next(i for i,b in enumerate(self.bars) if b.time.isoformat()==self.triangle['observed_from'])
        end=start+self.triangle['window']-1
        self.assertIsNotNone(anchored_convergence(self.bars,start,end))
        broken=self.bars[:start+5]+self.bars[start+10:]
        self.assertIsNone(anchored_convergence(broken,start,end-5))
        known=instant(self.triangle['first_observed_at'])
        first=observe_anchored_formations(self.bars,known)
        chart={**first,'closed_end':known.isoformat()}
        raw=[dict(time=b.time.isoformat(),closed_at=b.closed_at.isoformat(),open=b.open,high=b.high,low=b.low,close=b.close) for b in self.bars]
        active=active_ranges({'H1':chart},{'H1':raw})
        target=next(v for v in active.values() if v['range_id']==self.triangle['id'])
        self.assertTrue(any(':anchored:' in k for k in active))
        self.assertEqual(_exit_after(target,raw),'line_intersection')

    def test_display_extension_keeps_frozen_native_rails_and_closed_end(self):
        from ict_trader.display_geometry_audit import anchored_display_errors
        for kind in ('structural','geometric'):
            for box in self.result[kind+'_ranges']:
                self.assertEqual(anchored_display_errors(box,self.bars),[],box['id'])
        for box in (self.channel,self.triangle):
            changed=deepcopy(box);changed['display_geometry']['frame'][1]['price']+=1
            self.assertIn('display_rail_refitted',anchored_display_errors(changed,self.bars))
            changed=deepcopy(box);changed['display_geometry']['display_through']='2099-01-01T00:00:00+00:00'
            self.assertIn('display_extension_future',anchored_display_errors(changed,self.bars))
            changed=deepcopy(box);changed['display_geometry']['upper'][0]['price']+=1
            self.assertIn('display_frozen_evidence_changed',anchored_display_errors(changed,self.bars))

if __name__=='__main__':unittest.main()
