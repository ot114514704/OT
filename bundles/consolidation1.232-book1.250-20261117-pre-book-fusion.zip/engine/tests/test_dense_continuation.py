"""Continuation is permitted only for an unchanged complete closed prefix."""
import unittest
import json
from pathlib import Path
from copy import deepcopy
from dataclasses import replace
from datetime import timedelta,timezone
from unittest.mock import patch
from ict_trader import dense_pauses as dense
from tests.test_dense_pauses import bars_fixture
from tests.test_consolidation_invariants import transformed


class DenseContinuationTests(unittest.TestCase):
    def assert_matches(self,cache,bars,asof=None):
        asof=asof or bars[-1].closed_at
        actual=cache.observe(bars,asof)
        self.assertEqual(actual,dense.observe_dense_pauses(bars,asof))
        return actual

    def test_every_new_close_mirrors_and_gap_boundaries(self):
        original=bars_fixture()
        for scale,offset in ((1,0),(-1,300)):
            for gap in (False,True):
                bars=transformed(original,scale,offset)
                if gap:bars=bars[:30]+[replace(b,time=b.time+timedelta(days=4)) for b in bars[30:]]
                cache=dense.DensePauseContinuation()
                for stop in range(12,len(bars)+1):
                    self.assert_matches(cache,bars[:stop])
                    self.assertEqual(cache.last_processed,12 if stop==12 else 1)
                self.assertEqual(cache.builds,1)

    def test_revisions_truncation_and_left_edge_changes_force_full_scan(self):
        bars=bars_fixture();cache=dense.DensePauseContinuation()
        for data in (bars,bars[:48],bars[3:],bars,[replace(b,spread=b.spread+.1) for b in bars],bars):
            self.assert_matches(cache,data);self.assertEqual(cache.last_mode,'full')
        changed=bars.copy();changed[10]=replace(changed[10],high=changed[10].high+10)
        self.assert_matches(cache,changed);self.assertEqual(cache.last_mode,'full')

    def test_parameters_are_part_of_checkpoint_identity(self):
        bars=bars_fixture();cache=dense.DensePauseContinuation();self.assert_matches(cache,bars)
        with patch.dict(dense.PARAMETERS,width_atr_max=dense.PARAMETERS['width_atr_max']*.8):
            self.assert_matches(cache,bars);self.assertEqual(cache.last_mode,'full')
        self.assert_matches(cache,bars);self.assertEqual(cache.last_mode,'full')

    def test_equal_instants_with_different_source_labels_rebuild(self):
        bars=bars_fixture();cache=dense.DensePauseContinuation();self.assert_matches(cache,bars)
        shifted=[replace(b,time=b.time.astimezone(timezone(timedelta(hours=8)))) for b in bars]
        self.assertEqual(shifted,bars)  # datetime equality alone cannot preserve labels.
        self.assert_matches(cache,shifted);self.assertEqual(cache.last_mode,'full')

    def test_forming_prices_never_enter_checkpoint(self):
        bars=bars_fixture();cache=dense.DensePauseContinuation();cutoff=bars[31].closed_at
        before=self.assert_matches(cache,bars,cutoff)
        future=bars[:32]+[replace(b,high=b.high+100) for b in bars[32:]]
        self.assertEqual(cache.observe(future,cutoff),before)
        self.assertEqual(cache.last_mode,'identical');self.assertEqual(len(cache._bars),32)
        self.assert_matches(cache,future,future[32].closed_at)
        self.assertEqual(cache.last_mode,'append');self.assertEqual(cache.last_processed,1)

    def test_returned_and_prior_graphs_do_not_mutate_checkpoint(self):
        bars=bars_fixture();cache=dense.DensePauseContinuation()
        result=self.assert_matches(cache,bars[:32]);self.assertTrue(result)
        pristine=deepcopy(result)
        result[0]['metrics']['oscillation']['completed_legs']=-99;result[0]['gaps'].append({'bad':True})
        again=self.assert_matches(cache,bars[:32]);self.assertEqual(again,pristine)
        saved=deepcopy(again);self.assert_matches(cache,bars)
        self.assertEqual(again,saved)

    def test_failed_append_cannot_corrupt_last_successful_state(self):
        bars=bars_fixture();cache=dense.DensePauseContinuation();expected=cache.observe(bars[:32],bars[31].closed_at)
        original=dense.observe_dense_pauses
        def failed(*args,**kwargs):
            original(*args,**kwargs)
            raise RuntimeError('injected failure after checkpoint mutation')
        with patch.object(dense,'observe_dense_pauses',side_effect=failed):
            with self.assertRaises(RuntimeError):cache.observe(bars,bars[-1].closed_at)
        self.assertEqual(cache.observe(bars[:32],bars[31].closed_at),expected)
        self.assert_matches(cache,bars);self.assertEqual(cache.last_mode,'append')

    def test_native_weekend_and_returning_samples_across_observation_boundaries(self):
        from ict_trader.core import Bar,instant
        from tests import test_dense_pauses
        fixtures=Path(test_dense_pauses.__file__).parent/'fixtures'
        for name in ('h1_august_weekend_pause.json','h1_july_dense_reference.json','h1_nov9_returning_pause.json'):
            rows=json.loads((fixtures/name).read_text('utf-8'))
            if isinstance(rows,dict):rows=rows['bars']
            bars=[Bar(instant(r['time']),*(r[k] for k in ('open','high','low','close')),r.get('spread',0),3600) for r in rows]
            stops=set(range(16,len(bars),23))|{len(bars)}
            for i in range(1,len(bars)):
                if (bars[i].time-bars[i-1].closed_at).total_seconds()>3*3600:
                    stops.update((i,i+1,min(i+2,len(bars))))
            cache=dense.DensePauseContinuation()
            for stop in sorted(stops):self.assert_matches(cache,bars[:stop])

    def test_pipeline_h1_and_m15_append_then_historical_revision(self):
        import app
        from functools import partial
        from ict_trader.analysis_cache import H1AnalysisCache
        bars=bars_fixture()[:36]
        raw={p:[app.row(replace(b,time=bars[0].time+timedelta(seconds=i*seconds),seconds=seconds)) for i,b in enumerate(bars)] for p,seconds in (('H1',3600),('M15',900))}
        caches={p:dense.DensePauseContinuation() for p in raw}
        h1=H1AnalysisCache(partial(app.prepare_h1,dense_cache=caches))
        for h,m in ((24,24),(24,25),(25,26),(36,36)):
            sample={'H1':raw['H1'][:h],'M15':raw['M15'][:m]}
            self.assertEqual(app.calculate(sample,h1_cache=h1,dense_cache=caches),app.calculate(sample))
        self.assertEqual(caches['H1'].builds,1);self.assertEqual(caches['M15'].builds,1)
        revised=deepcopy(raw);revised['H1'][3]['high']+=10;revised['M15'][3]['high']+=10
        self.assertEqual(app.calculate(revised,h1_cache=h1,dense_cache=caches),app.calculate(revised))
        self.assertEqual(caches['H1'].last_mode,'full');self.assertEqual(caches['M15'].last_mode,'full')


if __name__=='__main__':unittest.main()
