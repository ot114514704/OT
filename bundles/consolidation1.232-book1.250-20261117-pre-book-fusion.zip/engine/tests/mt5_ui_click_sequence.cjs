// Run production event handlers against native paired-click orderings.
// This catches control clicks reaching a shape after the panel has closed.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
function extract(name){
 const m=source.match(new RegExp('(?:bool|void) '+name+'\\([^)]*\\)\\s*\\{'));
 assert.ok(m,name);let end=m.index+m[0].length,depth=1;
 while(depth){const c=source[end++];if(c==='{')depth++;if(c==='}')depth--;}
 return source.slice(m.index,end);
}
function js(s){return s.replace(/^(bool|void) /,'function ').replace(/const (int|long|double|string|bool|ulong)\s*&?/g,'').replace(/\b(int|bool|string|double|long|ulong) (?=\w)/g,'let ').replace(/\(int\)/g,'');}
let handler=source.slice(source.indexOf('void OnChartEvent('),source.indexOf('   if(id==CHARTEVENT_MOUSE_WHEEL)',source.indexOf('void OnChartEvent(')))+'\n}';
const legacy=handler.replace(/   \/\/ MT5 can emit[\s\S]*?(?=   if\(id==CHARTEVENT_OBJECT_CLICK && sparam==prefix\+"MORPH"\))/,'');
function setup(code=handler){
 const c=vm.createContext({prefix:'IPDA_',now:1000,MathAbs:Math.abs,StringFind:(a,b)=>a.indexOf(b),
  CHARTEVENT_OBJECT_CLICK:1,CHARTEVENT_CHART_CHANGE:2,CHARTEVENT_CLICK:3,OBJPROP_STATE:4,
  CHART_AUTOSCROLL:5,CHART_END:6,CHART_CURRENT_POS:7,CHART_WIDTH_IN_BARS:8,CHART_FIRST_VISIBLE_BAR:9,
  selected_key:'old',detail_page:0,detail_pages:2,detailOpen:true,picks:0,closed:0,
  show_h1:true,show_m15:false,show_large:true,show_small:true,show_current:true,compact:true,morphology:0,
  drag_active:false,drag_moved:false,last_drag_end:0,dirty:false,view_key:'same',view_pending:false,
  ui_echo_pending:false,last_ui_click:0,last_ui_x:0,last_ui_y:0,
  shapes:[{key:'wanted'}],ArraySize:a=>a.length,MathMax:Math.max,MathMin:Math.min,
  ViewKey:()=> 'same',ChartRedraw:()=>{},ObjectSetInteger:()=>{},SaveDisplayPreferences:()=>{},FillVisibility:()=>{},
  ChartSetInteger:()=>{},ChartNavigate:()=>{},ChartGetInteger:()=>100,Bars:()=>1000,_Symbol:'XAUUSD',_Period:3600});
 c.GetTickCount64=()=>c.now;c.CloseDetail=()=>{c.detailOpen=false;c.closed++;};
 c.ShowDetail=()=>{c.detailOpen=true;};c.InsideDetail=()=>c.detailOpen;
 c.PickDetail=()=>{c.picks++;c.selected_key='behind';c.detailOpen=true;};c.FinishDrag=()=>{c.drag_active=false;};
 for(const n of ['OwnedUiClick','UiEchoClick'])vm.runInContext(js(extract(n)),c);
 vm.runInContext(js(code),c);return c;
}
let checks=0;function check(p,msg){assert.ok(p,msg);checks++;}
function object(c,name='DETAIL_CLOSE',x=20,y=104){c.OnChartEvent(c.CHARTEVENT_OBJECT_CLICK,x,y,'IPDA_'+name);}
function click(c,x=20,y=104){c.OnChartEvent(c.CHARTEVENT_CLICK,x,y,'');}
let c=setup(legacy);object(c);click(c);check(c.picks===1&&c.detailOpen,'regression reproduces on previous handler');
c=setup();object(c);c.now+=250;click(c);check(c.picks===0&&!c.detailOpen&&c.selected_key==='','close release cannot reopen underlying shape');
click(c);check(c.picks===1,'consumed echo does not block a subsequent deliberate click');
c=setup();click(c);object(c);check(c.picks===0&&!c.detailOpen,'reverse event order also closes without selecting behind');
c=setup();object(c,'DETAIL_BODY');click(c);check(c.picks===0&&c.detailOpen,'panel body cannot pick through');
c=setup();object(c);click(c,100,104);check(c.picks===1,'different nearby-time click remains usable');
c=setup();object(c);c.now+=301;click(c);check(c.picks===1,'later same-coordinate click remains usable');
c=setup();object(c,'H1');click(c);check(!c.show_h1&&c.picks===0&&!c.detailOpen,'timeframe toggle is processed exactly once');
c=setup();object(c,'TEXTwanted');click(c);check(c.selected_key==='wanted'&&c.picks===0,'label selection cannot be replaced by a second hit test');
c=setup();c.detailOpen=false;click(c);check(c.picks===1,'ordinary chart selection unaffected');
c=setup();c.detailOpen=false;c.OnChartEvent(c.CHARTEVENT_OBJECT_CLICK,20,104,'foreign_control');check(c.picks===1,'foreign object is not consumed as our control');
c=setup();check(!c.UiEchoClick(false,1,0,0,0,0)&&!c.UiEchoClick(true,301,0,0,0,0)&&c.UiEchoClick(true,300,3,-3,0,0),'guard boundaries are finite and coordinate bound');
console.log(JSON.stringify({passed:true,checks,scope:'Production control/chart click sequences; physical MT5 acceptance is separate.'},null,2));
