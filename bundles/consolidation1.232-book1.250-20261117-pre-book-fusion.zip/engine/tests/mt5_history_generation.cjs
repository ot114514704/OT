// Execute the production reset helper translated to JS; no native UI claims.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
const helper=source.match(/void AcceptHistoryGeneration\(const string incoming\)\s*\{[\s\S]*?\n  \}/)[0]
 .replace('void AcceptHistoryGeneration(const string incoming)','function AcceptHistoryGeneration(incoming)');
const state={history_generation:'old',history_key:'view',history_token:'pending-old',
 history_loaded:'complete-old',history_shapes:[{key:'preserve'}],history_from:10,history_to:20,
 backfill_source:'broker',backfill_token:'page-old',backfill_cursor:100,history_status:'ready',dirty:false,
 first_visible_bar:250,auto_scroll:false};
const ctx=vm.createContext(state);vm.runInContext(helper,ctx);
const before=JSON.stringify(state);
vm.runInContext('AcceptHistoryGeneration("");AcceptHistoryGeneration("old")',ctx);
assert.equal(JSON.stringify(state),before,'empty/same generation must not restart scans');
vm.runInContext('AcceptHistoryGeneration("new")',ctx);
for(const key of ['history_key','history_token','backfill_source','backfill_token'])assert.equal(state[key],'');
assert.equal(state.backfill_cursor,0);assert.equal(state.dirty,true);
assert.equal(state.history_loaded,'complete-old');assert.equal(state.history_shapes[0].key,'preserve');
assert.equal(state.history_from,10);assert.equal(state.history_to,20);
assert.equal(state.first_visible_bar,250);assert.equal(state.auto_scroll,false);
state.history_token='pending-new';state.history_key='same-view';state.backfill_cursor=200;
vm.runInContext('AcceptHistoryGeneration("new")',ctx);
assert.equal(state.history_token,'pending-new');assert.equal(state.backfill_cursor,200);
const load=source.slice(source.indexOf('void LoadShapes()'),source.indexOf('bool ShapeSnapshotComplete'));
assert.ok(load.indexOf('if(!ShapeSnapshotComplete')<load.indexOf('AcceptHistoryGeneration(h[5])'));
assert.match(load,/h\[2\]==revision && .*h\[5\]==history_generation/);
assert.match(source,/StringSplit\(saved,'\\t',p\)==7.*p\[6\]==history_generation/);
assert.match(source,/h\[7\]\+"\\t"\+history_generation/);
// Live replies use the pending token; retained replies must additionally match
// the calculation generation and broker source before their saved token is used.
const historyLoad=source.slice(source.indexOf('void LoadHistory('),source.indexOf('color LineColor('));
assert.match(historyLoad,/string expected=history_token/);
assert.match(historyLoad,/m\[2\]!=history_generation \|\| m\[3\]!=HistorySource\(\) \|\| m\[4\]==""/);
assert.match(historyLoad,/expected=m\[4\];suffix="\.retained\.tsv"/);
assert.match(historyLoad,/h\[2\]!=expected/);
assert.match(historyLoad,/complete=a\[1\]==expected/);
assert.doesNotMatch(helper,/ChartNavigate|ArrayResize|ObjectsDelete|history_loaded\s*=/);
console.log('PASS: generation invalidation, same-generation stability, drawing/viewport retention, checkpoint and complete-snapshot wiring (not native execution)');
