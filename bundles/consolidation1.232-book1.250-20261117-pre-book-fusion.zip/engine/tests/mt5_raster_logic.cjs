// Exercise the production raster routines with clipped, sloping and tiled geometry.
// No market simulation; native alignment still requires a real MT5 screenshot.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
function routine(name){
 const m=source.match(new RegExp('void '+name+'\\([^)]*\\)\\s*\\{'));
 let end=m.index+m[0].length,depth=1;
 while(depth){const c=source[end++];if(c==='{')depth++;if(c==='}')depth--;}
 return source.slice(m.index,end).replace(/^void /,'function ')
  .replace(/double p\[4\],q\[4\];/g,'let p=[],q=[];')
  .replace(/double cuts\[\];/g,'let cuts=[];')
  .replace(/(?:const )?(?:int|uint|double) &?(\w+)\[\]/g,'$1')
  .replace(/const (int|uint|double) /g,'')
  .replace(/\((int|uint|double)\)/g,'')
  .replace(/\b(int|uint|double) /g,'let ')
  .replace(/ArrayResize\((\w+),([^;]+)\);/g,'$1.length=$2;')
  .replace(/ArraySize\((\w+)\)/g,'$1.length')
  .replace(/ArraySort\((\w+)\);/g,'$1.sort((a,b)=>a-b);');
}
const ctx=vm.createContext({MathMax:Math.max,MathMin:Math.min,MathAbs:Math.abs,MathCeil:Math.ceil,MathFloor:Math.floor,MathRound:Math.round});
for(const name of ['FillPolygon','StrokeSegment'])vm.runInContext(routine(name),ctx);
let checks=0;const check=(name,value)=>{assert.ok(value,name);checks++;};
function draw(xs,ys,width,height,top=0){
 const p=Array(width*height).fill(0);ctx.FillPolygon(p,width,height,top,xs,ys,1);
 for(let k=0;k<4;k++)ctx.StrokeSegment(p,width,height,top,xs[k],ys[k],xs[(k+1)%4],ys[(k+1)%4],2,1);
 return p;
}
const xs=[12,83,83,12],ys=[8,31,65,88],w=100,h=100,p=draw(xs,ys,w,h);
check('all four vertices share fill and outline coordinates',xs.every((x,k)=>p[ys[k]*w+x]===2));
check('wedge interior is filled',p[48*w+50]===1);
check('outside right edge stays transparent',p[48*w+85]===0);
check('outside sloping top stays transparent',p[10*w+70]===0);
const tiled=[...draw(xs,ys,w,50,0),...draw(xs,ys,w,50,50)];
check('tile boundary has no vertical offset or seam',JSON.stringify(p)===JSON.stringify(tiled));
const edge=Array(40*30).fill(0);ctx.StrokeSegment(edge,40,30,0,-100000,15,100000,15,2,1);
check('large offscreen segment clips to viewport',edge.filter(v=>v===2).length===40);
const vertical=Array(40*30).fill(0);ctx.StrokeSegment(vertical,40,30,0,20,-10000,20,10000,2,2);
check('thick vertical border stays bounded',vertical.filter(v=>v===2).length===60);
const outside=Array(40*30).fill(0);ctx.StrokeSegment(outside,40,30,0,-100,-100,-5,-5,2,1);
check('fully outside border is not painted',outside.every(v=>v===0));
const clipped=draw([-20,70,70,-20],[-20,30,70,120],w,h);
check('clipped polygon retains interior',clipped[50*w+30]===1);
check('clipped polygon has no overflow',clipped.length===w*h);
console.log(JSON.stringify({passed:true,checks,scope:'Actual MQ5 fill/stroke routines translated to JS; pixel alignment, clipping, hit-test coordinates and tiling. Native UI checked separately.'},null,2));
