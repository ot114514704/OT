// Native UI state logic from the production indicator, executed without MT5.
// Physical panning/zooming is separately verified on the attached terminal.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
function extract(name){
 const match=source.match(new RegExp('(?:bool|void|datetime) '+name+'\\([^)]*\\)\\s*\\{'));
 assert.ok(match,name);let end=match.index+match[0].length,depth=1;
 while(depth){const ch=source[end++];if(ch==='{')depth++;if(ch==='}')depth--;}
 return source.slice(match.index,end).replace(/^(bool|void|datetime) /,'function ')
  .replace(/const (int|string|bool) /g,'').replace(/\b(int|datetime) (\w+)\s*=/g,'let $2=').replace(/\(int\)/g,'');
}
const store=new Map(),ctx=vm.createContext({show_h1:true,show_m15:false,show_large:true,show_small:true,compact:true,preference_key:'chart1',
 GlobalVariableSet:(k,v)=>store.set(k,v),GlobalVariableCheck:k=>store.has(k),GlobalVariableGet:k=>store.get(k),
 ArraySize:a=>a.length,shapes:[{seconds:3600,kind:'intraday',t:[1]},{seconds:900,kind:'local',t:[10]},
 {seconds:3600,kind:'structural',t:[20]},{seconds:900,kind:'local',t:[30]}]});
for(const name of ['PeriodEnabled','SaveDisplayPreferences','RestoreDisplayPreferences','FirstHistoryTime'])vm.runInContext(extract(name),ctx);
let checks=0;function check(name,p){assert.ok(p,name);checks++;}
for(let flags=0;flags<8;flags++){
 ctx.show_h1=!!(flags&1);ctx.show_m15=!!(flags&2);ctx.compact=!!(flags&4);
 ctx.SaveDisplayPreferences();ctx.show_h1=ctx.show_m15=ctx.compact=null;ctx.RestoreDisplayPreferences();
 check('reload preserves layer/detail state '+flags,ctx.show_h1===!!(flags&1)&&ctx.show_m15===!!(flags&2)&&ctx.compact===!!(flags&4));
}
for(let size=0;size<4;size++){
 ctx.show_large=!!(size&1);ctx.show_small=!!(size&2);ctx.SaveDisplayPreferences();
 ctx.show_large=ctx.show_small=null;ctx.RestoreDisplayPreferences();
 check('reload preserves independent size layers '+size,ctx.show_large===!!(size&1)&&ctx.show_small===!!(size&2));
}
ctx.preference_key='new-chart';ctx.show_h1=false;ctx.show_m15=true;ctx.RestoreDisplayPreferences();
check('new chart retains its own initial period',!ctx.show_h1&&ctx.show_m15);
store.set('new-chart',99);ctx.RestoreDisplayPreferences();check('invalid settings ignored',!ctx.show_h1&&ctx.show_m15);
check('M15 history start follows enabled layer',ctx.FirstHistoryTime()===10);
ctx.show_h1=true;ctx.show_m15=false;check('H1 excludes duplicated intraday projection',ctx.FirstHistoryTime()===20);
ctx.show_m15=true;check('both use earliest enabled source',ctx.FirstHistoryTime()===10);
ctx.show_h1=ctx.show_m15=false;check('both disabled has no misleading history destination',ctx.FirstHistoryTime()===0);
const chartChangeStart=source.indexOf('if(id==CHARTEVENT_CHART_CHANGE)');
assert.ok(chartChangeStart>=0);
const chartChange=source.slice(chartChangeStart,source.indexOf('if(id==CHARTEVENT_OBJECT_CLICK',chartChangeStart));
check('chart change immediately invalidates canvas and labels',chartChange.includes('FillVisibility(false)')&&chartChange.includes('dirty=true'));
check('view key includes history load and chart margin',source.includes('IntegerToString(Bars(_Symbol,_Period))')&&source.includes('CHART_SHIFT_SIZE'));
console.log(JSON.stringify({passed:true,checks,scope:'Production settings/history logic and chart invalidation wiring; native interaction verified separately.'},null,2));
