// A transport-state change must update chart captions without redrawing rails.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const elements=new Map();let now=1000;
function element(){return {dataset:{},children:[],textContent:'',classList:{add(){}},
 append(...items){this.children.push(...items)},replaceChildren(){this.children=[]}}}
const node=id=>{if(!elements.has(id))elements.set(id,element());return elements.get(id)};
const context=vm.createContext({performance:{now:()=>now},document:{getElementById:node,createElement:element}});
vm.runInContext(fs.readFileSync(process.argv[2]||'ui/app.js','utf8').split('async function refresh()')[0],context);
const base={H1:'所选大盘整：已结束 · 首次确认 11-02 08:30',M15:'局部：已确认盘整 · 已收盘依据截至 11-13 23:45'};
for(const p of ['H1','M15']){node('shapeCurrent'+p).dataset.closedLabel=base[p];node('shapeCurrent'+p).textContent=base[p]}
const report={availability:'live',poll_age_seconds:0,known_at:'2026-11-13T23:45:00+00:00',
 verdict:'confirmed',label:'已确认盘整',checks:{compact:true},profile:{tags:[]},score:80};
const initial={current_consolidation:{H1:structuredClone(report),M15:structuredClone(report)}};
context.input=JSON.stringify(initial);
vm.runInContext('state=JSON.parse(input);receivedAt=1000;renderCurrentVerdicts()',context);
for(const p of ['H1','M15'])assert.equal(node('shapeCurrent'+p).textContent,base[p]);
const unavailable=p=>{
 const nodeValue=node('shapeCurrent'+p);
 assert.ok(nodeValue.textContent.startsWith('上次收盘结构（'));
 assert.ok(nodeValue.textContent.includes('非当前结论'));
 assert.ok(nodeValue.textContent.endsWith(base[p]));
 assert.notEqual(nodeValue.dataset.availability,'live');
};
for(const health of ['quote_idle','analysis_pending','history_recalculating','disconnected','source_mismatch','bars_lagging']){
 context.health=health;
 vm.runInContext('state.current_consolidation.M15.availability=health;renderCurrentVerdicts();renderCurrentVerdicts()',context);
 unavailable('M15');assert.equal(node('shapeCurrentH1').textContent,base.H1);
 assert.equal(node('shapeCurrentM15').textContent.split('上次收盘结构').length,2,'do not duplicate warning prefixes');
}
vm.runInContext("state.current_consolidation.M15.availability='live';renderCurrentVerdicts()",context);
assert.equal(node('shapeCurrentM15').textContent,base.M15);
now=16001;vm.runInContext('renderCurrentVerdicts()',context);unavailable('H1');unavailable('M15');
vm.runInContext('receivedAt=performance.now();networkDown=true;renderCurrentVerdicts()',context);unavailable('H1');unavailable('M15');
vm.runInContext('networkDown=false;renderCurrentVerdicts()',context);
for(const p of ['H1','M15'])assert.equal(node('shapeCurrent'+p).textContent,base[p]);
assert.equal(vm.runInContext('JSON.stringify(state)',context),JSON.stringify(initial));
console.log(JSON.stringify({passed:true,scope:'Served chart caption renderer, stale timer without canvas redraw, independent periods, recovery, historical selection and immutable evidence; not physical browser visual acceptance'}));
