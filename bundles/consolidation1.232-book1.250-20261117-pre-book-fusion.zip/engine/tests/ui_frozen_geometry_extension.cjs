// Exercise the production canvas renderer: extended rails must reach the
// observed end while frozen evidence remains intact. No browser/UI claim.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
let path=[],polygons=[],arcs=0,touchSquares=0;
const target={beginPath(){path=[]},moveTo(x,y){path.push([x,y])},lineTo(x,y){path.push([x,y])},
 fill(){if(this.fillStyle==='#74bde519')polygons.push(path.slice())},arc(){arcs++},
 strokeRect(x,y,w,h){if(w===6&&h===6)touchSquares++},measureText(t){return {width:t.length*5}}};
const g=new Proxy(target,{get:(o,k)=>k in o?o[k]:()=>{}});
const elements=new Map();
function root(id){if(!elements.has(id))elements.set(id,{value:'1',dataset:{},style:{},getBoundingClientRect:()=>({width:800}),getContext:()=>g});return elements.get(id)}
const context=vm.createContext({document:{getElementById:root},devicePixelRatio:1,performance:{now:()=>1000}});
vm.runInContext(fs.readFileSync('ui/app.js','utf8').split('async function refresh()')[0],context);
const time=i=>new Date(Date.UTC(2026,7,31,i)).toISOString();
const bars=Array.from({length:10},(_,i)=>({time:time(i),closed_at:time(i+1),open:100,close:101,high:110,low:90}));
const point=(i,price)=>({time:time(i),price});
const geometry={ready:true,validated:true,basis:'confirmed_pivots',subtype:'triangle',
 upper:[point(0,110),point(4,106)],lower:[point(0,90),point(4,94)],
 frame:[point(0,110),point(4,106),point(4,94),point(0,90)]};
const display={...geometry,frame:[point(0,110),point(8,102),point(8,98),point(0,90)]};
const box={id:'test',window:5,observed_from:time(0),first_observed_at:time(5),end_at:time(9),
 shape:'converging',status:'候选',geometry,display_geometry:display,observed_high:110,observed_low:90,gaps:[]};
function render(item,structural=false){polygons=[];arcs=0;touchSquares=0;context.input=JSON.stringify({charts:{H1:{bars,closed_end:time(10),[structural?'structural_ranges':'geometric_ranges']:[item]}}});
 vm.runInContext('state=JSON.parse(input);draw("H1");',context);return JSON.parse(vm.runInContext('JSON.stringify(state)',context))}
const after=render(box);
assert.equal(polygons[0][1][0],8+(8+.5)*720/10,'right edge must reach the last observed native bar');
assert.deepEqual(after.charts.H1.geometric_ranges[0],box,'rendering may not mutate frozen evidence');
assert.equal(arcs,4,'confirmed pivot anchors remain visible');
const old={...box};delete old.display_geometry;render(old);
assert.equal(polygons[0][1][0],8+(4+.5)*720/10,'old geometries remain supported');
render({...box,shape:'tilted',display_geometry:{...display,basis:'frozen_rails_through_native_observed_bars',starting_pivot:{time:time(0),price:110}}},true);
assert.equal(arcs,0,'regression envelope endpoints must not appear as confirmed pivots');
render({...box,display_geometry:{...display,upper:[{...display.upper[0],anchor_kind:'boundary_touch'},display.upper[1]]}});
assert.equal(arcs,3,'a boundary touch must not use the confirmed-pivot circle');
assert.equal(touchSquares,1,'a boundary touch has a distinct hollow square');
console.log(JSON.stringify({passed:true,checks:7,scope:'Production canvas drawing and frozen input integrity; no physical screenshot claim'}));
