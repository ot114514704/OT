import copy,importlib.util,json,unittest
from pathlib import Path
import ict_trader.display_selection as candidate
trace=json.loads((Path(__file__).parent/'fixtures/h1_parent_display_overlap.json').read_text('utf-8'))
outer=next(r['row'] for r in trace['trace'] if r['row'][1]=='f8927cbf67799ae9')
child=next(r['row'] for r in trace['trace'] if r['row'][1]=='2866e428684227ad')
early=next(r for r in trace['trace'][0]['blockers'] if r[12].startswith('price_structure_candidate_v5:48:'))

def mirror(row):
    a=list(row)
    for target,source in ((7,8),(8,7),(14,20),(16,18),(18,16),(20,14)):a[target]=str(9000-float(row[source]))
    return a

class ParentDisplayTests(unittest.TestCase):
    def test_actual_hidden_parent_is_added_without_replacing_old_drawings(self):
        lines=trace['chosen']+['\t'.join(outer)];original=list(lines)
        previous=trace['chosen'];new=candidate.select_balance_first(lines)
        self.assertNotIn('\t'.join(outer),previous);self.assertIn('\t'.join(outer),new)
        self.assertTrue(set(previous)<=set(new));self.assertEqual(lines,original)
        self.assertEqual(new,candidate.select_balance_first(lines[::-1]))
        self.assertEqual(new,candidate.select_balance_first(new))

    def test_price_mirror_keeps_both_independent_relationships(self):
        for transform in (list,mirror):
            self.assertTrue(candidate.successive_parent_ranges(transform(early),transform(outer)))
            self.assertTrue(candidate.formation_nested_context(transform(outer),transform(child)))

    def test_live_or_cutoff_only_old_parent_cannot_claim_completed_episode(self):
        for fields in ({10:'1'},{9:'形态候选 · 历史片段末观察'},{6:str(int(outer[5])+1)}):
            changed=list(early)
            for k,v in fields.items():changed[k]=v
            self.assertFalse(candidate.successive_parent_ranges(changed,outer))

    def test_large_overlap_or_foreign_period_keeps_competition(self):
        changed=list(outer);changed[13]=str(int(early[15])-18*3600);changed[4]=changed[13]
        self.assertFalse(candidate.successive_parent_ranges(early,changed))
        changed=list(outer);changed[0]='900'
        self.assertFalse(candidate.successive_parent_ranges(early,changed))

    def test_child_requires_earlier_small_formation_and_contained_frozen_prices(self):
        for fields in ({5:str(int(outer[5])+1)},{15:str(int(outer[15])+3600),17:str(int(outer[15])+3600)},
                       {23:child[23].replace('观察 8 根','观察 20 根')},{18:str(float(outer[20])-1),20:str(float(outer[20])-1)},
                       {3:'intraday'},{0:'900'}):
            changed=list(child)
            for k,v in fields.items():changed[k]=v
            self.assertFalse(candidate.formation_nested_context(outer,changed))

    def test_identical_box_is_not_promoted_as_broader_context(self):
        changed=list(child)
        for index in (14,16,18,20):changed[index]=outer[index]
        self.assertFalse(candidate.formation_nested_context(outer,changed))

if __name__=='__main__':unittest.main()
