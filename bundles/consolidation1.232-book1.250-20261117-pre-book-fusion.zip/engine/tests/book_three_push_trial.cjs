// Execute the production MQL admission functions; native/UI verification separate.
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const source=fs.readFileSync('mt5/experiment/BookThreePush.mqh','utf8');
function extract(name){
 const m=source.match(new RegExp('(?:bool|double) '+name+'\\([^)]*\\)\\s*\\{'));assert(m,name);
 let e=m.index+m[0].length,d=1;while(d){let c=source[e++];if(c==='{')d++;if(c==='}')d--;}
 const raw=source.slice(m.index,e),params=raw.slice(raw.indexOf('(')+1,raw.indexOf(')')).split(',').map(p=>p.trim().split(/\s+/).at(-1).replace(/[&\[\]]/g,''));
 let body=raw.slice(raw.indexOf('{'));
 body=body.replace(/\/\/[^\n]*/g,'').replace(/\((?:double|int|long)\)/g,'')
 .replace(/\b(?:double|int|datetime|bool|string) (\w+)\[\]=\{([^}]+)\}/g,'let $1=[$2]')
 .replace(/\b(?:double|int|datetime|bool|string) (\w+)\[\]/g,'let $1=[]')
 .replace(/\b(?:double|int|datetime|bool|string) /g,'let ')
 .replace(/a\[n\/2-1\]/g,'a[Math.floor(n/2)-1]').replace(/a\[n\/2\]/g,'a[Math.floor(n/2)]');
 return `function ${name}(${params.join(',')})${body}`;
}
const rejected={};const ctx=vm.createContext({MathMin:Math.min,MathMax:Math.max,MathAbs:Math.abs,
 ArrayCopy:(a,b)=>{a.splice(0,a.length,...b);},ArraySort:a=>a.sort((x,y)=>x-y),ArraySize:a=>a.length,
 ArrayResize:(a,n)=>a.length=n,PeriodSeconds:()=>3600,IntegerToString:String,DoubleToString:(n,d)=>n.toFixed(d),
 TimeToString:String,_Digits:2});
for(const n of ['BTPMedian','BTPBalance','BTPBuild']){
 let code=extract(n);if(n==='BTPBuild'&&process.env.BTP_DIAGNOSTIC){let reason=0;code=code.replace(/return false/g,()=>`return btpReject(${++reason})`);ctx.btpReject=k=>{rejected[k]=(rejected[k]||0)+1;return false;};}
 vm.runInContext(code,ctx);
}
let checks=0;function check(n,x){assert(x,n);checks++;}
check('balanced progressive overlapping pushes',ctx.BTPBalance(100,110,103.5,112.5,107,115,1));
check('mirror symmetric',ctx.BTPBalance(100,90,96.5,87.5,93,85,-1));
check('horizontal triple top not silently a directional wedge',!ctx.BTPBalance(100,110,100,110,100,110,1));
check('disconnected drives rejected',!ctx.BTPBalance(100,110,112,122,124,134,1));
check('unbalanced amplitudes rejected',!ctx.BTPBalance(100,110,103,128,106,114,1));
check('failed third progression disclosed as unsupported subset',!ctx.BTPBalance(100,110,103,112,106,111,1));
const native=process.argv[2]?JSON.parse(fs.readFileSync(process.argv[2],'utf8')):[];
function scan(rows){
 let ix=[],p=[],side=[],out=[];
 for(let end=4;end<rows.length;end++){
  let k=end-2,hi=true,lo=true;
  for(let j=k-2;j<=k+2;j++)if(j!==k){if(rows[j].high>=rows[k].high)hi=false;if(rows[j].low<=rows[k].low)lo=false;}
  if(hi===lo)continue;
  let sign=hi?1:-1,price=hi?rows[k].high:rows[k].low;
  if(side.at(-1)===sign){if(sign*(price-p.at(-1))<=0)continue;ix[ix.length-1]=k;p[p.length-1]=price;}
  else{ix.push(k);p.push(price);side.push(sign);}
  if(ix.length<6)continue;
  const s={p:[],t:[]};if(ctx.BTPBuild(rows,ix,p,ix.length,sign,end,s))out.push(s);
 }
 return out;
}
const found=scan(native);
for(const s of found){
 check('known two closed bars after third tip',s.known===s.until+10800);
 const prefix=native.filter(b=>b.time<s.known),again=scan(prefix).find(x=>x.key===s.key);
 check('prefix causal and frozen geometry',again&&JSON.stringify(again)===JSON.stringify(s));
 check('third pivot not known one bar too early',!scan(prefix.slice(0,-1)).some(x=>x.key===s.key));
 const later=native.map(b=>b.time>=s.known?{...b,open:b.open+1000,high:b.high+1000,low:b.low+1000,close:b.close+1000}:b);
 check('later price cannot rewrite frozen vertices',JSON.stringify(scan(later).find(x=>x.key===s.key))===JSON.stringify(s));
 const scaled=native.map(b=>({...b,open:b.open*7,high:b.high*7,low:b.low*7,close:b.close*7}));
 const q=scan(scaled).find(x=>x.key===s.key);
 check('price-unit invariant',q&&q.p.every((v,i)=>Math.abs(v-7*s.p[i])<1e-6));
 const mirrored=native.map(b=>({...b,open:10000-b.open,close:10000-b.close,high:10000-b.low,low:10000-b.high}));
 const m=scan(mirrored).find(x=>x.t[0]===s.t[0]&&x.until===s.until);
 check('whole wedge mirror exists',!!m);
 const gap=native.map(b=>({...b,time:b.time+(b.time>=s.t[0]+3600?3600:0)}));
 check('missing native candle does not preserve same candidate',!scan(gap).some(x=>x.t[0]===s.t[0]&&x.until===s.until+3600));
 const impulse=native.map(b=>({...b}));
 for(let k=0;k<impulse.length;k++)if(impulse[k].time>=s.t[0]&&impulse[k].time<=s.until){let v=100+k*10;Object.assign(impulse[k],{open:v,close:v+9,high:v+10,low:v-1});}
 check('single directional displacement not a wedge',!scan(impulse).some(x=>x.t[0]===s.t[0]));
 check('unconfirmed and non-scoring description',s.detail.includes('不计分、不下单')&&s.detail.includes('非IPDA已确认盘整'));
}
const trial=fs.readFileSync('mt5/experiment/book三推试验板.mq5','utf8');
check('closed native candles only',source.includes('newest=MathMax(1,'));
check('independent Book toggle',trial.includes('sparam==prefix+"BOOK"'));
check('single raster geometry and fill vertices preserved',trial.includes('FillPolygon(pixels,width,h,top,xs,ys')&&trial.includes('StrokeSegment(pixels,width,h,top,xs[edge],ys[edge]'));
check('stable namespace untouched by trial',trial.includes('IPDA_TRIAL_')&&trial.includes('IPDA.Trial.Display.'));
console.log(JSON.stringify({passed:true,checks,native_candidates:found.length,candidates:found,rejected,scope:'Actual MQL admission functions via JS translation; no outcome backtest, no manual accuracy assertion.'},null,2));
