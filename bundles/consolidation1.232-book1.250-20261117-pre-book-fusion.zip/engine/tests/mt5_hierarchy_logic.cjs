// Execute actual native hierarchy predicates. This is not native UI acceptance.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
function extract(name){
 const m=source.match(new RegExp('(?:bool|double|string) '+name+'\\([^)]*\\)\\s*\\{'));assert(m,name);
 let end=m.index+m[0].length,depth=1;while(depth){const c=source[end++];if(c==='{')depth++;if(c==='}')depth--;}
 return source.slice(m.index,end).replace(/^(bool|double|string) /,'function ')
  .replace(/const (bool|int|double|string) /g,'').replace(/\b(double|int|bool|string) /g,'let ').replace(/\(double\)/g,'');
}
const ctx=vm.createContext({MathMax:Math.max,MathMin:Math.min,ArraySize:a=>a.length,
 StringToInteger:s=>parseInt(s,10)||0,StringFind:(s,t)=>s.indexOf(t),StringSubstr:(s,i,n)=>n===undefined?s.slice(i):s.slice(i,i+n),morphology:0});
for(const name of ['RailPrice','FormationHours','InnerDisplayRegion','NestedRectangle','NestedPriceOverlap','LargeRange','ShapePriority','ShapeTypeEnabled'])vm.runInContext(extract(name),ctx);
function shape(geometry,start,end,high,low,n=24,seconds=3600,title='候选'){
 return {geometry,t:[start,end,end,start],p:[high,high,low,low],seconds,title,kind:'structural',detail:`依据：观察 ${n} 根；`};
}
ctx.shapes=[shape('rectangle',0,100,120,90),shape('converging',10,30,115,95),shape('channel',35,50,115,95,16),shape('rectangle',60,80,115,95,12,3600,'下跌中继'),shape('channel',40,120,115,95,96)];
let checks=0;function check(name,yes){assert(yes,name);checks++;}
check('outer rectangle is selected before every inner structure',[1,2,3].every(i=>ctx.ShapePriority(0)>ctx.ShapePriority(i)));
check('same H1 triangle/channel/relay remain nested',[1,2,3].every(i=>ctx.NestedRectangle(0,i)));
ctx.shapes.push(shape('rectangle',15,35,125,100,8));
check('independent inner range may protrude through outer edge',ctx.NestedPriceOverlap(0,5));
check('out of time range cannot use nested overlap',!ctx.NestedPriceOverlap(0,4));
ctx.shapes.pop();
check('crossing oversized channel is not a child',!ctx.NestedRectangle(0,4));
check('enclosing rectangle is large even with 24 observed bars',ctx.LargeRange(0));
check('children retain their small native scale',[1,2,3].every(i=>!ctx.LargeRange(i)));
check('channel does not become the enclosing parent',!ctx.NestedRectangle(4,2));
check('triangle and dense relay win over broad fitted channel',ctx.ShapePriority(1)>ctx.ShapePriority(4)&&ctx.ShapePriority(3)>ctx.ShapePriority(4));
ctx.shapes.push({...shape('rectangle',101,111,115,95,4),detail:'依据：观察 4 根；长影线共同接受区'});
check('dense common body acceptance wins over broad fitted triangle',ctx.ShapePriority(5)>ctx.ShapePriority(1));
ctx.shapes.pop();
check('short channel wins over broad alternative',ctx.ShapePriority(2)>ctx.ShapePriority(4));
const original=JSON.stringify(ctx.shapes);
for(const [mode,expected] of [[0,[0,1,2,3,4]],[1,[0,3]],[2,[1]],[3,[2,4]],[4,[3]]]){
 ctx.morphology=mode;check('shape family '+mode,JSON.stringify(ctx.shapes.map((_,i)=>i).filter(i=>ctx.ShapeTypeEnabled(i)))===JSON.stringify(expected));
}
check('selection does not edit frozen coordinates',JSON.stringify(ctx.shapes)===original);
ctx.shapes=[shape('rectangle',0,100,120,90,48,900),shape('rectangle',200,300,120,90,24,3600)];
check('large/small uses native bars not wall-clock hours',ctx.LargeRange(0)&&!ctx.LargeRange(1));
const selection=source.slice(source.indexOf('void SelectDisplayShapes('),source.indexOf('bool HeartbeatFresh('));
check('nested exception precedes conflict rejection',selection.indexOf('if(NestedRectangle(i,j)')<selection.indexOf('if(DisplayConflict('));
check('layer toggles run after representative selection',selection.indexOf('if(!ShapeTypeEnabled(i)')>selection.indexOf('if(!duplicate)'));
check('channel outlines omit end caps',source.includes('geometry=="channel" && (edge==1 || edge==3)'));
check('hit testing omits invisible channel end caps',source.includes('geometry=="channel" && (k==1 || k==3)'));
check('both size buttons are wired',source.includes('sparam==prefix+"LARGE"')&&source.includes('sparam==prefix+"SMALL"'));
ctx.shapes=[shape('rectangle',0,100,120,90,16),shape('rectangle',20,40,115,95,8),shape('channel',-10,90,125,85,10)];
ctx.shapes[0].detail='依据：观察 16 根；短横盘候选；按实体范围';
ctx.shapes[2].detail='依据：观察 10 根；大实体反向回访';
check('dense rectangle is not promoted merely by another nested sample',ctx.ShapePriority(0)<400000);
check('revisited full sloping segment precedes crossing unconfirmed dense alternatives',ctx.ShapePriority(2)>ctx.ShapePriority(0));
console.log(JSON.stringify({passed:true,checks,scope:'Production MQ5 hierarchy/family/size predicates and wiring; no native screenshot acceptance.'},null,2));
