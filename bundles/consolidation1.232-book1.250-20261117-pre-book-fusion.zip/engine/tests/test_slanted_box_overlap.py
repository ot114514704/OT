import unittest
from unittest.mock import patch
from ict_trader.display_selection import select_balance_first,slanted_box_coexist

def row(key,geometry,p,kind='structural',seconds=3600):
    a=['']*24
    a[0]=str(seconds);a[1]=key;a[2]=geometry;a[3]=kind;a[5]='1100000';a[11]='H1';a[12]='overlap_test:'+key
    a[13]=a[19]='1000000';a[15]=a[17]='1090000'
    for i,v in zip((14,16,18,20),p):a[i]=str(v)
    a[23]='观察 25 根'
    return '\t'.join(a)

class SlantedBoxOverlapTests(unittest.TestCase):
    def test_existing_box_retained_with_one_crossing_shape_mirror_and_scale(self):
        with patch('ict_trader.layout_preferences.preferences',return_value=[]):
            for sign,offset in ((1,0),(-1,300),(10,1000)):
                def points(p):
                    v=[x*sign+offset for x in p]
                    return v if sign>0 else [v[3],v[2],v[1],v[0]]
                box=row('box','rectangle',points([120,120,100,100]),'local')
                for geometry,p in [('channel',[130,110,90,110]),('converging',[125,113,107,95])]:
                    slant=row('slant',geometry,points(p));duplicate=row('repeat',geometry,points(p))
                    rows=[box,slant,duplicate];snapshot=list(rows)
                    result=select_balance_first(rows)
                    self.assertEqual(len(result),2)
                    self.assertIn(box,result)
                    self.assertEqual(result,select_balance_first(rows[::-1]))
                    self.assertEqual(result,select_balance_first(result))
                    self.assertEqual(rows,snapshot)
                    self.assertTrue(set(result)<=set(rows))

    def test_wedge_duplicate_box_and_disabled_projection_do_not_gain_exception(self):
        box=row('box','rectangle',[120,120,100,100],'local')
        with patch('ict_trader.layout_preferences.preferences',return_value=[]):
            for other in [row('wedge','converging',[130,115,95,100]),
                          row('projection','channel',[130,110,90,110],'intraday'),
                          row('duplicate','rectangle',[120,120,100,100])]:
                self.assertEqual(select_balance_first([box,other]),[box])
        foreign=row('foreign','channel',[130,110,90,110],seconds=900)
        self.assertFalse(slanted_box_coexist(box.split('\t'),foreign.split('\t')))

if __name__=='__main__':unittest.main()
