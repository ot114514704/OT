from copy import deepcopy
from dataclasses import replace
from datetime import timedelta,timezone
import unittest
from unittest.mock import patch
from ict_trader import dense_pauses as dense
from tests.test_dense_pauses import bars_fixture
from tests.test_consolidation_invariants import transformed

class DenseWindowMemoTests(unittest.TestCase):
    def compare(self,memo,bars,cutoff=None):
        cutoff=cutoff or bars[-1].closed_at
        expected=dense.observe_dense_pauses(bars,cutoff)
        self.assertEqual(memo.observe(bars,cutoff),expected)
        return expected

    def test_successive_closes_mirrors_and_gaps(self):
        for scale,offset in ((1,0),(-1,300)):
            bars=transformed(bars_fixture(),scale,offset)
            for source in (bars,bars[:22]+bars[29:]):
                memo=dense.DenseWindowMemo()
                for end in range(16,len(source)+1):self.compare(memo,source[:end])
                self.assertEqual(memo.rebuilds,1)

    def test_cached_windows_reduce_evaluation_without_changing_output(self):
        bars=bars_fixture();memo=dense.DenseWindowMemo()
        memo.observe(bars[:-1],bars[-2].closed_at)
        with patch.object(dense,'_candidate',wraps=dense._candidate) as cached:
            actual=memo.observe(bars,bars[-1].closed_at);cached_calls=cached.call_count
        with patch.object(dense,'_candidate',wraps=dense._candidate) as fresh:
            expected=dense.observe_dense_pauses(bars,bars[-1].closed_at);fresh_calls=fresh.call_count
        self.assertEqual(actual,expected);self.assertLess(cached_calls,fresh_calls/4)

    def test_revision_truncation_left_edge_and_labels_reset(self):
        bars=bars_fixture()
        variants=[bars[:-1],bars[1:],bars[:10]+[replace(bars[10],spread=bars[10].spread+.1)]+bars[11:],
            [replace(b,time=b.time.astimezone(timezone(timedelta(hours=2)))) for b in bars],
            [replace(b,open=b.open+3,high=b.high+3,low=b.low+3,close=b.close+3) for b in bars]]
        for revised in variants:
            memo=dense.DenseWindowMemo();self.compare(memo,bars);self.compare(memo,revised)
            self.assertEqual(memo.rebuilds,2);self.assertEqual(memo.last_reused,0)

    def test_forming_bar_prices_are_excluded(self):
        bars=bars_fixture();memo=dense.DenseWindowMemo();cutoff=bars[-2].closed_at
        expected=self.compare(memo,bars,cutoff)
        altered=bars[:-1]+[replace(bars[-1],open=500,high=600,low=400,close=450)]
        self.assertEqual(memo.observe(altered,cutoff),expected);self.assertEqual(memo.rebuilds,1)
        self.compare(memo,altered)

    def test_output_mutation_and_failed_scan_leave_pristine_metrics(self):
        bars=bars_fixture();memo=dense.DenseWindowMemo();result=self.compare(memo,bars[:-1])
        for r in result:r['metrics'].clear();r['checks'].clear()
        before=deepcopy(memo._windows);keys=memo._keys
        with patch.object(dense,'_candidate',side_effect=RuntimeError('evaluation failed')):
            with self.assertRaisesRegex(RuntimeError,'evaluation failed'):memo.observe(bars,bars[-1].closed_at)
        self.assertEqual(memo._windows,before);self.assertEqual(memo._keys,keys)
        self.compare(memo,bars)

    def test_parameter_change_and_memory_caps(self):
        bars=bars_fixture();memo=dense.DenseWindowMemo(window_limit=3)
        self.compare(memo,bars[:-1]);self.assertLessEqual(len(memo._windows),3)
        self.compare(memo,bars);self.assertLessEqual(len(memo._windows),3)
        with patch.dict(dense.PARAMETERS,overlap_min=.9):self.compare(memo,bars)
        self.assertEqual(memo.rebuilds,2)
        capped=dense.DenseWindowMemo(bar_limit=10);self.compare(capped,bars)
        self.assertEqual(capped.metadata()['retained_bars'],0)
        self.assertEqual(capped.metadata()['retained_windows'],0)
        for invalid in (0,-1,True,1.5):
            with self.assertRaises(ValueError):dense.DenseWindowMemo(window_limit=invalid)

if __name__=='__main__':unittest.main()
