// Execute the production archive ownership predicate, rather than a copied
// implementation. Native drawing/reload remains a separate acceptance step.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
const match=source.match(/bool HistoryOwnsArchive\([^)]*\)\s*\{/);
assert.ok(match);let end=match.index+match[0].length,depth=1;
while(depth){const c=source[end++];if(c==='{')depth++;if(c==='}')depth--;}
const body=source.slice(match.index,end).replace(/^bool /,'function ').replace(/const (int|long) /g,'');
const ctx=vm.createContext({});vm.runInContext(body,ctx);
let checks=0;
for(const [name,start,finish,period,replace] of [
 ['fully covered record refreshed',110,190,3600,true],
 ['exactly covered record refreshed',100,200,3600,true],
 ['formation before scan preserved',90,180,3600,false],
 ['end after scan preserved',110,210,3600,false],
 ['whole outer range preserved',90,210,3600,false],
 ['older history preserved',20,80,3600,false],
 ['newer history preserved',220,280,3600,false],
 ['other period archive preserved',110,190,900,false]
]){assert.equal(ctx.HistoryOwnsArchive(period,3600,start,finish,100,200),replace,name);checks++;}
console.log(JSON.stringify({passed:true,checks,scope:'Production finite history scope ownership; no native UI claim'},null,2));
