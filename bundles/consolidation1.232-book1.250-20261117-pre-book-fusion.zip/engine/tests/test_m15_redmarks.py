"""Native candle regressions for the three user-marked M15 screenshots.

Coverage of these examples is not full-history accuracy or native UI acceptance.
"""
import json
import unittest
from dataclasses import replace
from pathlib import Path
from ict_trader.core import Bar,instant
from ict_trader.dense_pauses import observe_dense_pauses,closed_m15_pause,PARAMETERS,_candidate
from ict_trader.long_geometry import observe_long_geometry
from tests.test_consolidation_invariants import transformed


class M15RedmarkTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw=json.loads((Path(__file__).parent/'fixtures/m15_redmarks_20261114.json').read_text('utf-8'))
        cls.segments={name:[Bar(instant(b['time']),*(b[k] for k in ('open','high','low','close','spread')),900)
                            for b in rows] for name,rows in raw['segments'].items()}

    def test_october_triangle_retains_actual_pivots(self):
        bars=self.segments['oct21']
        out=observe_long_geometry(bars,bars[-1].closed_at,compact_scales=True)
        box=next(b for b in out['ranges'] if b['id']=='long_converging_candidate_v1:48:2026-10-21T20:30:00+00:00')
        self.assertIn(box['geometry']['subtype'],('triangle','ascending_triangle'))
        self.assertGreater(box['geometry']['lower'][1]['price'],box['geometry']['lower'][0]['price'])
        self.assertFalse(box['confirmed']);self.assertFalse(box['score_included'])

    def test_internal_closed_pauses_are_independent_of_wide_older_box(self):
        bars=self.segments['nov9'];ranges=observe_dense_pauses(bars,bars[-1].closed_at)
        for stamp in ('2026-11-10T06:30:00+00:00','2026-11-10T11:00:00+00:00'):
            box=next(b for b in ranges if b['id']=='dense_horizontal_pause_v1:m15closed6:'+stamp)
            self.assertTrue(box['metrics']['large_body_closed_revisited'])
            self.assertGreaterEqual(box['metrics']['oscillation']['completed_legs'],2)
            self.assertFalse(box['confirmed']);self.assertFalse(box['score_included'])

    def test_later_marked_pauses_already_have_raw_native_evidence(self):
        for name,stamp in [('nov11','2026-11-11T19:45:00+00:00'),('nov13','2026-11-13T13:15:00+00:00')]:
            bars=self.segments[name];out=observe_dense_pauses(bars,bars[-1].closed_at)
            self.assertTrue(any(b['first_observed_at']==stamp and b['shape']=='rectangle' for b in out))

    def test_added_records_are_causal_and_mirror_symmetric(self):
        bars=self.segments['nov9'];full=observe_dense_pauses(bars,bars[-1].closed_at)
        box=next(b for b in full if b['id']=='dense_horizontal_pause_v1:m15closed6:2026-11-10T06:30:00+00:00')
        cutoff=instant(box['first_observed_at']);prefix=[b for b in bars if b.closed_at<=cutoff]
        prior=observe_dense_pauses(bars,cutoff)
        self.assertEqual(prior,observe_dense_pauses(prefix,cutoff))
        earlier=next(b for b in prior if b['id']==box['id'])
        for key in ('observed_from','known_at','high','low','checks','metrics'):
            self.assertEqual(earlier[key],box[key])
        changed=[b if b.closed_at<=cutoff else replace(b,open=b.open+200,high=b.high+200,low=b.low+200,close=b.close+200) for b in bars]
        self.assertEqual(prior,observe_dense_pauses(changed,cutoff))
        mirrored=observe_dense_pauses(transformed(prefix,-1,9000),cutoff)
        other=next(b for b in mirrored if b['id']==box['id'])
        self.assertEqual(other['checks'],box['checks'])
        self.assertAlmostEqual(other['high'],9000-box['low'])
        self.assertAlmostEqual(other['low'],9000-box['high'])

    def test_one_way_march_and_single_unrevisited_body_are_not_pauses(self):
        bars=self.segments['nov9'][:16]
        one_way=[replace(b,open=100+i,close=100.8+i,low=99.5+i,high=101.3+i) for i,b in enumerate(bars)]
        for end in range(5,len(one_way)):
            start=end-5;c=_candidate(one_way,start,end,PARAMETERS,include_profile=False)
            self.assertFalse(closed_m15_pause(one_way,start,end,c))
        # The same actual oscillation cannot be confirmed early by a wick.
        bars=[b for b in self.segments['nov9'] if '2026-11-10T05:00'<=b.time.isoformat()<='2026-11-10T06:15:00+00:00']
        changed=bars[:3]+[replace(b,open=4109.4,close=4109.5,low=4108,high=4115) for b in bars[3:]]
        c=_candidate(changed,0,len(changed)-1,PARAMETERS,include_profile=False)
        self.assertFalse(closed_m15_pause(changed,0,len(changed)-1,c))


if __name__=='__main__':unittest.main()
