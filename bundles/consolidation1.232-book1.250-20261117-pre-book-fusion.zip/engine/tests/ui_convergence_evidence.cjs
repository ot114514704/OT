const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
function element(){return {dataset:{},children:[],textContent:'',append(...items){this.children.push(...items)},replaceChildren(){this.children=[]}}}
const roots=new Map(),root=id=>{if(!roots.has(id))roots.set(id,element());return roots.get(id)};
const context=vm.createContext({document:{getElementById:root,createElement:element},performance:{now:()=>1000}});
vm.runInContext(fs.readFileSync('ui/app.js','utf8').split('async function refresh()')[0],context);
const time='2026-08-31T18:00:00+00:00',p={time,known_at:time,price:4400};
const box={id:'target',first_observed_at:time,status:'形态候选',
 geometry:{subtype:'triangle',validation:{overlap_bars:21,close_coverage:1},reason:'按原生已观察K线拟合；休市不补造价格',
 upper:[{...p,anchor_kind:'boundary_touch'},p],lower:[p,p]},
 metrics:{oscillation:{basis:'compact_convergence_two_sided_reversals_and_four_pivots',completed_legs:2,threshold:20}},
 missing:['首根触点没有左侧局部拐点确认']};
const flatten=n=>[n.textContent,...n.children.flatMap(flatten)].join('\n');
function render(b){context.input=JSON.stringify(b);vm.runInContext('state={charts:{H1:{geometric_ranges:[JSON.parse(input)]}}};selected={period:"H1",id:state.charts.H1.geometric_ranges[0].id,kind:"geometric"};renderPhaseScores("H1");',context);return flatten(root('scoresH1'))}
let text=render(box);
assert.match(text,/小尺度收盘折返 2 段/);
assert.doesNotMatch(text,/完成强摆动|强双向摆动 2/);
assert.match(text,/上沿边界触点（非确认拐点）/);
assert.equal((text.match(/已确认摆动锚点/g)||[]).length,3);
assert.match(text,/休市不补造价格/);
assert.match(text,/待验证：首根触点没有左侧局部拐点确认/);
assert.match(text,/候选不计确认分/);
text=render({...box,metrics:{oscillation:{basis:'closed_prices',completed_legs:4,threshold:30}},geometry:{...box.geometry,upper:[p,p]}});
assert.match(text,/强双向摆动 4 段/);
assert.doesNotMatch(text,/小尺度收盘折返|边界触点（非确认拐点）/);
let native={ranges:0,compact:0,boundary_touches:0};
if(process.argv[2]){
 const data=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
 for(const chart of Object.values((data.payload||data).charts))for(const b of chart.geometric_ranges||[]){
  const before=JSON.stringify(b),detail=render(b),compact=b.metrics.oscillation.basis==='compact_convergence_two_sided_reversals_and_four_pivots';
  assert.equal(JSON.stringify(b),before);assert.ok(!/undefined|NaN/.test(detail));
  assert.ok(detail.includes((compact?'小尺度收盘折返':'强双向摆动')+' '+b.metrics.oscillation.completed_legs+' 段'));
  native.ranges++;native.compact+=Number(compact);
  for(const p of [...b.geometry.upper,...b.geometry.lower])if(p.anchor_kind==='boundary_touch'){assert.match(detail,/边界触点（非确认拐点）/);native.boundary_touches++}
 }
 assert.ok(native.ranges>0&&native.compact>0&&native.boundary_touches>0);
}
console.log(JSON.stringify({passed:true,checks:9,native,scope:'Production detail DOM distinguishes compact reversals, boundary touches and mature oscillation; no physical screenshot claim'}));
