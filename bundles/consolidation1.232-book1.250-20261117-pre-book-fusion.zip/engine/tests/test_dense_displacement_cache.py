"""Prior displacement reuse must preserve each window's own threshold."""
import unittest
from dataclasses import replace
from datetime import timedelta
from ict_trader import dense_pauses as dense
from tests.test_dense_pauses import bars_fixture
from tests.test_consolidation_invariants import transformed


class DisplacementCacheTests(unittest.TestCase):
    def test_all_starts_threshold_boundaries_gaps_and_mirrors(self):
        source=bars_fixture()
        trend=[replace(b,open=100+i,close=101+i,high=101.2+i,low=99.8+i) for i,b in enumerate(source)]
        for original in (source,trend,trend[:22]+trend[28:]):
            for scale,offset in ((1,0),(-1,300)):
                bars=transformed(original,scale,offset)
                cache=dense._DisplacementCache(bars,bars[-1].closed_at)
                for start in range(len(bars)+1):
                    thresholds=[.1,.5,1.,3.,8.,100.]
                    for n in (3,6,8,12):
                        if start>=n:
                            threshold=abs(bars[start-1].close-bars[start-n].open)/2.5
                            if threshold:thresholds.extend((threshold*(1-1e-12),threshold,threshold*(1+1e-12)))
                    for atr in thresholds:
                        self.assertEqual(cache(start,atr),dense.displacement_before(bars,start,atr),(start,atr))

    def test_each_result_is_independent_and_atr_is_not_cached(self):
        bars=[replace(b,open=100+i,close=101+i,high=101.2+i,low=99.8+i) for i,b in enumerate(bars_fixture())]
        cache=dense._DisplacementCache(bars,bars[-1].closed_at)
        original=cache(12,1.)
        self.assertIsNotNone(original)
        self.assertIsNone(cache(12,100.))
        changed=cache(12,1.);changed['direction']=0;changed['known_at']='changed'
        self.assertEqual(cache(12,1.),original)
        self.assertEqual(cache(12,.5)['net_atr'],2*original['net_atr'])

    def test_cutoff_and_new_snapshot_do_not_reuse_future_or_old_prices(self):
        bars=[replace(b,open=100+i,close=101+i,high=101.2+i,low=99.8+i) for i,b in enumerate(bars_fixture())]
        cutoff=bars[23].closed_at-timedelta(seconds=1)
        visible=dense.visible(bars,cutoff)
        original=dense._DisplacementCache(bars,cutoff)
        revised=bars[:23]+[replace(b,open=500,close=400,high=501,low=399) for b in bars[23:]]
        future=dense._DisplacementCache(revised,cutoff)
        for start in range(len(visible)+1):
            self.assertEqual(original(start,1.),future(start,1.))
            self.assertEqual(original(start,1.),dense.displacement_before(visible,start,1.))
        full=dense._DisplacementCache(bars,bars[-1].closed_at)
        changed=dense._DisplacementCache(revised,revised[-1].closed_at)
        self.assertNotEqual(full(40,1.),changed(40,1.))
        self.assertEqual(changed(40,1.),dense.displacement_before(revised,40,1.))


if __name__=='__main__':unittest.main()
