const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
function extract(name){const m=source.match(new RegExp('(?:int|bool) '+name+'\\([^)]*\\)\\s*\\{'));assert.ok(m,name);let end=m.index+m[0].length,depth=1;while(depth){const c=source[end++];if(c==='{')depth++;if(c==='}')depth--;}return source.slice(m.index,end).replace(/^(int|bool) /,'function ').replace(/const (int|string) /g,'').replace(/\bint /g,'let ').replace(/\(int\)/g,'');}
let scale=1;
const measure=s=>[...s].reduce((n,c)=>n+(c.codePointAt(0)>127?15:c==='i'?3:8)*scale,0);
const ctx=vm.createContext({MathFloor:Math.floor,MathMax:Math.max,StringLen:s=>s.length,StringGetCharacter:(s,i)=>s.charCodeAt(i),StringSubstr:(s,i,n)=>s.slice(i,i+n),DetailTextWidth:measure,detail_width:660,detail_height:300});
for(const name of ['DetailChunkLength','InsideDetail'])vm.runInContext(extract(name),ctx);
let count=0;
for(const dpi of [1,1.25,1.5,2])for(const width of [200,628])for(const text of ['上下轨逐步收窄；方向效率0.13；双边测试2/2次；缺失验证：机构意图未验证。'.repeat(3),'2026-11-06T14:45:00+00:00 → 2026-11-06T15:15:00+00:00','边界✅候选尚未确认；已结束与当前候选分开呈现。']){
 scale=dpi;let at=0,parts=[];while(at<text.length){let n=ctx.DetailChunkLength(text,at,width);assert(n>0);let part=text.slice(at,at+n);assert(measure(part)<=width);assert(!/[\uD800-\uDBFF]$/.test(part));parts.push(part);at+=n;assert(parts.length<=text.length);}
 assert.equal(parts.join(''),text);count++;
}
assert(ctx.InsideDetail(20,104));assert(ctx.InsideDetail(670,404));assert(!ctx.InsideDetail(671,104));assert(!ctx.InsideDetail(20,103));count+=4;
assert.match(source,/TextSetFont\("Microsoft YaHei",-90,FW_NORMAL\)/);
assert.match(source,/wrapped\[start\+i\]/);assert.match(source,/detail_pages=MathMax\(1,\(int\)MathCeil/);
assert.match(source,/InsideDetail\(x,y\) \|\| x<0/);assert.match(source,/DETAIL_PREV/);assert.match(source,/DETAIL_NEXT/);
console.log(JSON.stringify({passed:true,checks:count,scope:'Production detail chunking, mixed Chinese/Latin/UTF16 text across simulated DPI metrics, no text loss, panel hit bounds; native font and UI verified separately.'},null,2));
