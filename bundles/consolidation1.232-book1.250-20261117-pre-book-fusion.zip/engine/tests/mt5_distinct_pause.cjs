// Execute production MQL selection helpers and loop over captured native rows.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
function convert(s){return s.replace(/const (bool|int|double|string) /g,'').replace(/\b(double|int|bool|string) /g,'let ').replace(/\(double\)/g,'').replace(/let (\w+)\[\];/g,'let $1=[];');}
function extract(name){const m=source.match(new RegExp('(?:bool|double|string) '+name+'\\([^)]*\\)\\s*\\{'));assert(m,name);let e=m.index+m[0].length,d=1;while(d){const c=source[e++];if(c==='{')d++;if(c==='}')d--;}return convert(source.slice(m.index,e).replace(/^(bool|double|string) /,'function '));}
const ctx=vm.createContext({MathMax:Math.max,MathMin:Math.min,StringFind:(s,q)=>s.indexOf(q),StringSubstr:(s,i)=>s.slice(i),StringToInteger:s=>parseInt(s)||0,ArraySize:a=>a.length,ArrayResize:(a,n)=>a.length=n});
for(const n of ['FormationHours','RailPrice','InnerDisplayRegion','NestedRectangle','NestedPriceOverlap','EarlyNestedPriceOverlap','SuccessiveFormations','IndependentM15Layer','DistinctClosedPause','AdjacentDisplayRegions','DisplayConflict','ShapePriority'])vm.runInContext(extract(n),ctx);
function shape(line){const a=line.split('\t');return {seconds:+a[0],key:a[1],geometry:a[2],kind:a[3],observed_from:+a[4],known:+a[5],source_id:a[12],t:[+a[13],+a[15],+a[17],+a[19]],p:[+a[14],+a[16],+a[18],+a[20]],title:a[21],detail:a[23]};}
const start=source.indexOf('   int representatives[];'),end=source.indexOf('   for(int slot=0;slot<ArraySize(representatives);slot++)',start);
assert(start>0&&end>start);const block=convert(source.slice(start,end));
function select(lines,updated){ctx.shapes=lines.map(shape);ctx.candidates=ctx.shapes.map((s,i)=>({i,rank:ctx.ShapePriority(i)+(s.seconds===3600?1e6:(['macro','local'].includes(s.kind)?1e5:0))})).sort((a,b)=>b.rank-a.rank||ctx.shapes[a.i].known-ctx.shapes[b.i].known||ctx.shapes[a.i].key.localeCompare(ctx.shapes[b.i].key)).map(x=>x.i);return vm.runInContext('(function(){'+(updated?block:block.replace('pass<4','pass<3'))+';return representatives;})()',ctx);}
const fixture=JSON.parse(fs.readFileSync('tests/fixtures/m15_nov10_adjacent_display.json','utf8'));
let before=select(fixture,false),after=select(fixture,true);assert.equal(after.length,3);assert(before.every(i=>after.includes(i)));
const target=fixture.findIndex(x=>x.includes(':m15closed6:'));assert(!before.includes(target));assert(after.includes(target));
ctx.shapes=fixture.map(shape);assert(!ctx.DistinctClosedPause(target,target));
const other=fixture.findIndex((x,i)=>i!==target);assert(ctx.DistinctClosedPause(target,other));
ctx.shapes[target].observed_from-=3600;assert(!ctx.DistinctClosedPause(target,other));
assert.match(source,/s\.observed_from=\(datetime\)StringToInteger\(a\[4\]\)/);assert.match(source,/s\.source_id=a\[12\]/);
let result={passed:true,scope:'Translated production MQL helpers and selection loop; not native rendering'};
if(process.argv[2]){const lines=JSON.parse(fs.readFileSync(process.argv[2],'utf8')).filter(x=>x.split('\t')[3]!=='intraday');before=select(lines,false);after=select(lines,true);assert(before.every(i=>after.includes(i)));const t=lines.findIndex(x=>x.split('\t')[0]==='900'&&x.includes(':m15closed6:2026-11-10T06:30'));assert(t>=0&&after.includes(t));result={...result,input:lines.length,before:before.length,after:after.length,old_representatives_retained:true,target_restored:true};}
console.log(JSON.stringify(result));
