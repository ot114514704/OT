import copy,json,unittest
from pathlib import Path
from ict_trader.display_selection import successive_dense_levels,select_balance_first

FIXTURE=json.loads((Path(__file__).parent/'fixtures/h1_staged_dense_levels.json').read_text('utf-8'))
def pair(name):return copy.deepcopy(FIXTURE[name])
def lines(rows):return ['\t'.join(r) for r in rows]
def mirror(row):
    r=row.copy()
    for hi,lo in ((7,8),(14,20),(16,18)):
        r[hi],r[lo]=str(-float(row[lo])),str(-float(row[hi]))
    return r

class StagedDenseDisplayTests(unittest.TestCase):
    def test_native_higher_level_and_earlier_bearish_stage_both_survive(self):
        for name in FIXTURE:
            early,later=pair(name)
            self.assertTrue(successive_dense_levels(early,later))
            before=lines([early,later]);snapshot=list(before)
            chosen=select_balance_first(before)
            self.assertEqual(set(chosen),set(before));self.assertEqual(before,snapshot)
            self.assertEqual(chosen,select_balance_first(before[::-1]))
            self.assertEqual(chosen,select_balance_first(chosen))

    def test_symmetric_price_reflection_retains_both(self):
        for name in FIXTURE:
            early,later=map(mirror,pair(name))
            self.assertTrue(successive_dense_levels(early,later))
            self.assertEqual(set(select_balance_first(lines([early,later]))),set(lines([early,later])))

    def test_contemporary_and_same_birth_hypotheses_still_compete(self):
        early,later=pair('higher')
        early[5]=str(int(later[4])+3600)
        self.assertFalse(successive_dense_levels(early,later))
        self.assertEqual(len(select_balance_first(lines([early,later]))),1)
        early,later=pair('higher');later[4]=early[4]
        self.assertFalse(successive_dense_levels(early,later))

    def test_same_or_nearly_same_price_level_not_promoted(self):
        early,later=pair('higher')
        for hi,lo in ((14,20),(16,18)):
            later[hi]=early[hi];later[lo]=early[lo]
        self.assertFalse(successive_dense_levels(early,later))
        for k in (14,20,16,18):later[k]=str(float(later[k])+1)
        self.assertFalse(successive_dense_levels(early,later))

    def test_foreign_period_family_shape_or_nonhorizontal_rail_rejected(self):
        for key,value in ((0,'900'),(2,'channel'),(3,'intraday'),(12,'price_structure_candidate_v5:24:horizontal:x'),(16,'4541.2')):
            early,later=pair('higher');later[key]=value
            self.assertFalse(successive_dense_levels(early,later),(key,value))

    def test_nested_wider_box_and_reversed_time_not_sequential_level(self):
        early,later=pair('higher');later[20]=later[18]=str(float(early[20])-1)
        self.assertFalse(successive_dense_levels(early,later))
        early,later=pair('higher')
        self.assertFalse(successive_dense_levels(later,early))
        later[15]=early[15]
        self.assertFalse(successive_dense_levels(early,later))

    def test_unrelated_overlapping_hypothesis_still_blocks_promotion(self):
        early,later=pair('higher');other=later.copy();other[1]='test-alternative'
        other[12]='dense_horizontal_pause_v1:body24:test-alternative'
        other[23]=other[23].replace('观察 8 根','观察 24 根')
        # Identical same-birth alternatives must produce one later representative.
        chosen=select_balance_first(lines([early,later,other]))
        self.assertEqual(len(chosen),2)
        self.assertIn('\t'.join(early),chosen)
