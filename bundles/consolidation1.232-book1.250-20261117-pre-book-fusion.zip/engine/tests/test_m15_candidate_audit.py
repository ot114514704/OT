"""Frozen M15 candidate evidence must survive audit without being promoted."""
import json
import unittest
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
from ict_trader.core import Bar, instant
from ict_trader.dense_pauses import observe_dense_pauses
from ict_trader.candidate_audit import candidate_evidence_errors

class M15CandidateAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw=json.loads((Path(__file__).parent/'fixtures/m15_closed_pause_native.json').read_text('utf-8'))
        cls.bars=[Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),x['spread'],900) for x in raw]
        cls.boxes=[x for x in observe_dense_pauses(cls.bars,cls.bars[-1].closed_at) if ':m15closed' in x['id']]

    def test_real_native_candidates_and_future_isolation(self):
        self.assertTrue(self.boxes)
        for box in self.boxes:
            self.assertEqual(candidate_evidence_errors(box,self.bars,'structural'),[])
            changed=[replace(b,open=b.open+999,high=b.high+999,low=b.low+999,close=b.close+999)
                     if b.time>=instant(box['first_observed_at']) else b for b in self.bars]
            self.assertEqual(candidate_evidence_errors(box,changed,'structural'),[])

    def test_corrupt_frozen_evidence_and_promotion_rejected(self):
        box=self.boxes[0]
        for key in ('high','body_high','frozen_atr'):
            bad=deepcopy(box);bad[key]+=1
            self.assertIn('candidate_frozen_'+key+'_source',candidate_evidence_errors(bad,self.bars,'structural'))
        for key in ('confirmed','score_included'):
            bad=deepcopy(box);bad[key]=True
            self.assertIn('candidate_confirmation_or_score',candidate_evidence_errors(bad,self.bars,'structural'))
        bad=deepcopy(box);bad['metrics']['closed_turns']+=1
        self.assertIn('candidate_frozen_metrics_source',candidate_evidence_errors(bad,self.bars,'structural'))
        missing=[b for b in self.bars if b.time!=instant(box['observed_from'])]
        self.assertIn('candidate_formation_source_coverage',candidate_evidence_errors(box,missing,'structural'))

if __name__=='__main__':unittest.main()
