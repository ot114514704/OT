import json,unittest
from pathlib import Path
from unittest.mock import patch
from dataclasses import replace
from ict_trader.core import Bar,instant
from ict_trader import structural_ranges as sr
from ict_trader.mt5_bridge import shape_record
from ict_trader.display_selection import select_balance_first,channel_context
from tests.test_consolidation_invariants import transformed


class IntermediateChannelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        rows=json.loads((Path(__file__).parent/'fixtures/h1_august_outer_channel.json').read_text('utf-8'))
        cls.bars=[Bar(instant(r['time']),*(r[k] for k in ('open','high','low','close')),r['spread'],3600) for r in rows]

    def scan(self,bars,asof=None):return sr.observe_structures(bars,asof or bars[-1].closed_at,short_channels=True)

    def test_existing_ranges_remain_exact_and_outer_channel_is_added(self):
        with patch.dict(sr.PARAMETERS,channel_windows_h1=[]):before=self.scan(self.bars)
        after=self.scan(self.bars);byid={r['id']:r for r in after['ranges']}
        for r in before['ranges']:self.assertEqual(r,byid[r['id']])
        target=byid['price_structure_candidate_v5:72:auto:2026-08-27T12:00:00+00:00']
        self.assertEqual(target['shape'],'tilted');self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
        self.assertEqual(target['end_at'],'2026-08-28T20:00:00+00:00')
        self.assertTrue(all(target['checks'].values()))

    def test_same_scale_is_causal_and_mirrored(self):
        known=instant('2026-08-27T12:00:00+00:00')
        identity='price_structure_candidate_v5:72:auto:'+known.isoformat()
        for scale,offset in ((1,0),(-1,10000)):
            bars=transformed(self.bars,scale,offset)
            prefix=self.scan(bars,known);full=self.scan(bars)
            a=next(r for r in prefix['ranges'] if r['id']==identity);b=next(r for r in full['ranges'] if r['id']==identity)
            for key in ('geometry','known_at','observed_from','checks','high','low','slope_per_bar'):
                self.assertEqual(a[key],b[key])
            changed=[replace(r,open=r.open+500,high=r.high+500,low=r.low+500,close=r.close+500) if r.closed_at>known else r for r in bars]
            self.assertEqual(prefix,self.scan(changed,known))

    def test_directional_leg_does_not_become_a_channel_candidate(self):
        trend=[replace(b,open=4000+i,high=4001.1+i,low=3999.9+i,close=4001+i) for i,b in enumerate(self.bars)]
        result=self.scan(trend)
        self.assertFalse(any(r['window'] in (36,60,72,84) for r in result['ranges']))

    def test_display_keeps_outer_channel_and_all_previous_representatives(self):
        from ict_trader.viewport_history import recognize
        # The anchor-aware display has its own replacement test. This checks
        # the legacy context exception when no stronger anchored outline exists.
        records=[r for r in recognize(dict(bars=self.bars,period='H1'))['records'] if not r.split('\t')[12].startswith('anchored_')]
        with patch('ict_trader.display_selection.channel_context',return_value=False):
            previous=select_balance_first(records)
        selected=select_balance_first(records)
        self.assertTrue(set(previous)<=set(selected))
        identity='price_structure_candidate_v5:72:auto:2026-08-27T12:00:00+00:00'
        target=next(x.split('\t') for x in records if identity in x)
        self.assertTrue(any(identity in x for x in selected))
        self.assertFalse(channel_context(target,target))
        inner=next(x.split('\t') for x in previous if channel_context(target,x.split('\t')))
        projected=inner.copy();projected[0]='900'
        self.assertFalse(channel_context(target,projected))
        displaced=inner.copy()
        for k in (14,16,18,20):displaced[k]=str(float(displaced[k])+1000)
        self.assertFalse(channel_context(target,displaced))

    def test_archived_broad_box_does_not_erase_channel(self):
        records=json.loads((Path(__file__).parent/'fixtures/h1_august_merged_display.json').read_text('utf-8'))
        selected=select_balance_first(records)
        channel='price_structure_candidate_v5:72:auto:2026-08-27T12:00:00+00:00'
        box='price_structure_candidate_v5:96:horizontal:2026-08-28T08:00:00+00:00'
        a=next(x.split('\t') for x in records if x.split('\t')[12]==channel)
        b=next(x.split('\t') for x in records if x.split('\t')[12]==box)
        self.assertTrue(channel_context(a,b))
        for identity in (channel,box):self.assertTrue(any(x.split('\t')[12]==identity for x in selected))
        short=b.copy();short[23]=short[23].replace('观察 96 根','观察 24 根')
        self.assertFalse(channel_context(a,short))
        confirmed=b.copy();confirmed[3]='macro'
        self.assertFalse(channel_context(a,confirmed))
