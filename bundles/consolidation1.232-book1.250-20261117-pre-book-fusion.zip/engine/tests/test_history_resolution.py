import hashlib,json,sqlite3,unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from ict_trader.history_resolution import ResolutionReview,recognize_reviewed,review_for
from ict_trader.history_archive import HistoryArchive
from ict_trader.viewport_history import parse_request,process_request,recognize,_recognize_unchecked,VERSION
from tests.test_history_archive import native_request,record,result


class ResolutionTests(unittest.TestCase):
    def request(self):return parse_request(native_request())

    def test_unaffected_request_passes_through_verbatim(self):
        request=self.request();expected={'records':['sentinel'],'state':'fixture'}
        with patch('ict_trader.history_resolution.review_for',return_value=ResolutionReview()):
            self.assertIs(recognize_reviewed(request,lambda x:expected),expected)

    def test_source_and_period_binding(self):
        known=review_for('TradeMax Global Limited | TradeMaxGlobal-Live','M15')
        self.assertEqual(len(known.times),5832)
        self.assertFalse(review_for('other server','M15').times)
        self.assertFalse(review_for('TradeMax Global Limited | TradeMaxGlobal-Live','D1').times)

    def test_all_conflicted_does_not_call_recognition(self):
        request=self.request();review=ResolutionReview('r',[dict(time=int(b.time.timestamp())) for b in request['bars']])
        with patch('ict_trader.history_resolution.review_for',return_value=review):
            answer=recognize_reviewed(request,lambda x:self.fail('Coarse evidence reached recognition'))
        self.assertFalse(answer['records']);self.assertIn('证据不足',answer['state'])
        self.assertEqual(answer['resolution_review']['excluded_bars'],30)

    def test_mixed_window_matches_fresh_valid_suffix_exactly(self):
        request=self.request();review=ResolutionReview('r',[dict(time=int(b.time.timestamp())) for b in request['bars'][:5]])
        expected=_recognize_unchecked({**request,'bars':request['bars'][5:]})
        with patch('ict_trader.history_resolution.review_for',return_value=review):answer=recognize(request)
        self.assertEqual(answer['records'],expected['records'])
        self.assertEqual(answer['state'],'部分历史证据不足；'+expected['state'])
        self.assertEqual(answer['count'],30)

    def test_gap_segments_do_not_become_breakout_or_current_confirmation(self):
        request=self.request();review=ResolutionReview('r',[dict(time=int(request['bars'][15].time.timestamp()))])
        calls=[]
        def scan(part):
            calls.append(part['bars']);return result(part,[record(part,active=True)])
        with patch('ict_trader.history_resolution.review_for',return_value=review):answer=recognize_reviewed(request,scan)
        self.assertEqual([len(x) for x in calls],[15,14])
        old,new=[r.split('\t') for r in answer['records']]
        self.assertEqual(old[10],'0');self.assertIn('不能解释为突破或失效',old[23]);self.assertEqual(new[10],'1')

    def test_latest_conflict_reports_insufficient(self):
        request=self.request();review=ResolutionReview('r',[dict(time=int(request['bars'][-1].time.timestamp()))])
        with patch('ict_trader.history_resolution.review_for',return_value=review):answer=recognize_reviewed(request,lambda r:result(r,[]))
        self.assertEqual(answer['state'],'证据不足：历史源周期待核验')

    def test_archive_exclusion_is_bound_to_source_evidence_and_line(self):
        line='verbatim';review=ResolutionReview('r',exclusions=[dict(scope='s',evidence='e',line_sha256=hashlib.sha256(line.encode()).hexdigest())])
        self.assertFalse(review.accept_record('s','e',line))
        self.assertTrue(review.accept_record('other','e',line))
        self.assertTrue(review.accept_record('s','corrected',line))
        self.assertTrue(review.accept_record('s','e','revised'))

    def test_reply_filters_archive_without_replacing_old_scope(self):
        request=self.request();line=record(request,active=True)
        scope=f"{int(request['bars'][0].time.timestamp())}:{int(request['bars'][-1].closed_at.timestamp())}"
        review=ResolutionReview('r',[dict(time=int(b.time.timestamp())) for b in request['bars']],
            [dict(scope=scope,evidence='old-input',line_sha256=hashlib.sha256(line.encode()).hexdigest())])
        with TemporaryDirectory() as d:
            cache=Path(d)/'cache';archive=HistoryArchive(cache/'archive',VERSION,request['source'],'H1')
            archive.remember(request,result(request,[line]),'old-input')
            before=archive.path.read_bytes()
            path=Path(d)/'viewport_test.request.tsv';path.write_text(native_request(),'utf-8')
            with patch('ict_trader.viewport_history.review_for',return_value=review),patch('ict_trader.history_resolution.review_for',return_value=review):
                self.assertTrue(process_request(path,cache))
                # Same evidence cache cannot restore the quarantined record.
                self.assertTrue(process_request(path,cache))
            reply=path.with_name('viewport_test.reply.tsv').read_text('utf-8')
            self.assertNotIn(line,reply);self.assertIn('证据不足',reply);self.assertTrue(reply.endswith('END\tone\t0\n'))
            self.assertEqual(archive.path.read_bytes(),before)
            self.assertEqual(list(archive.visible(request['left'],request['right'],request['forming']).values())[0][0],line)

if __name__=='__main__':unittest.main()
