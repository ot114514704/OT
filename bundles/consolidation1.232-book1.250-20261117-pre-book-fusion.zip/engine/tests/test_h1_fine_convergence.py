import json,unittest
from copy import deepcopy
from dataclasses import replace
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch
from ict_trader.core import Bar,instant
from ict_trader import long_geometry as lg
from ict_trader.candidate_audit import candidate_evidence_errors
from ict_trader.display_selection import select_balance_first,fine_convergence_context
from tests.test_consolidation_invariants import transformed


class FineConvergenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        rows=json.loads((Path(__file__).parent/'fixtures/h1_august_outer_channel.json').read_text('utf-8'))
        cls.bars=[Bar(instant(r['time']),*(r[k] for k in ('open','high','low','close')),r['spread'],3600) for r in rows]
        cls.identity='long_converging_candidate_v1:fine:24:2026-09-01T02:00:00+00:00'

    def scan(self,bars,asof=None):
        return lg.observe_long_geometry(bars,asof or bars[-1].closed_at,compact_scales=True)

    def test_original_observers_unchanged_and_new_evidence_audited(self):
        with patch.dict(lg.PARAMETERS,fine_windows_h1=[]):before=self.scan(self.bars)
        after=self.scan(self.bars);byid={r['id']:r for r in after['ranges']}
        for box in before['ranges']:self.assertEqual(box,byid[box['id']])
        fine=[r for r in after['ranges'] if ':fine:' in r['id']]
        self.assertTrue(fine);self.assertIn(self.identity,byid)
        for box in fine:
            self.assertEqual(candidate_evidence_errors(box,self.bars,'geometric'),[],box['id'])
            self.assertGreaterEqual(box['geometry']['validation']['overlap_bars'],box['window']/2)
            self.assertFalse(box['confirmed']);self.assertFalse(box['score_included'])
        target=byid[self.identity]
        self.assertEqual(target['observed_from'],'2026-08-31T01:00:00+00:00')
        self.assertEqual(target['end_at'],'2026-09-01T08:00:00+00:00')

    def test_causality_frozen_anchors_and_price_mirror(self):
        known=instant('2026-09-01T02:00:00+00:00')
        original=None
        for scale,offset in ((1,0),(-1,10000)):
            bars=transformed(self.bars,scale,offset)
            prefix=self.scan(bars,known);full=self.scan(bars)
            a=next(r for r in prefix['ranges'] if r['id']==self.identity)
            b=next(r for r in full['ranges'] if r['id']==self.identity)
            for key in ('geometry','first_observed_at','known_at','observed_from','checks','metrics'):
                self.assertEqual(a[key],b[key])
            self.assertEqual(candidate_evidence_errors(a,bars,'geometric'),[])
            future=[replace(r,open=r.open+500,high=r.high+500,low=r.low+500,close=r.close+500) if r.closed_at>known else r for r in bars]
            self.assertEqual(prefix,self.scan(future,known))
            self.assertFalse(any(r['id']==self.identity for r in self.scan(bars,known-timedelta(seconds=1))['ranges']))
            if original is None:original=a
            else:
                self.assertAlmostEqual(a['observed_high'],10000-original['observed_low'])
                self.assertAlmostEqual(a['observed_low'],10000-original['observed_high'])

    def test_weekend_gap_and_wrong_period_cannot_create_fine_candidate(self):
        target=next(r for r in self.scan(self.bars)['ranges'] if r['id']==self.identity)
        window=[b for b in self.bars if b.time>=instant(target['observed_from']) and b.closed_at<=instant(target['known_at'])]
        self.assertIsNotNone(lg.candidate(window,compact=True))
        gap=[replace(b,time=b.time+timedelta(hours=49)) if i>=12 else b for i,b in enumerate(window)]
        self.assertIsNone(lg.candidate(gap,compact=True))
        m15=[replace(b,seconds=900) for b in self.bars]
        self.assertEqual(lg.observe_long_geometry(m15,m15[-1].closed_at,compact_scales=True,_fine_scan=True)['ranges'],[])
        damaged=deepcopy(target);damaged['confirmed']=True
        self.assertIn('candidate_confirmation_or_score',candidate_evidence_errors(damaged,self.bars,'geometric'))
        damaged=deepcopy(target);damaged['geometry']['frame'][0]['price']+=1
        self.assertIn('candidate_frozen_geometry_source',candidate_evidence_errors(damaged,self.bars,'geometric'))

    def test_wide_triangle_selected_without_erasing_existing_representatives(self):
        from ict_trader.viewport_history import recognize
        # Test the fine-only fallback independently of the newer anchored
        # outline, whose deliberate priority is checked separately below.
        records=[r for r in recognize(dict(bars=self.bars,period='H1'))['records']
                 if not r.split('\t')[12].startswith('anchored_')]
        with patch('ict_trader.display_selection.fine_convergence_context',return_value=False):
            previous=select_balance_first(records)
        selected=select_balance_first(records)
        self.assertTrue(set(previous)<=set(selected))
        identity='long_converging_candidate_v1:fine:32:2026-09-01T10:00:00+00:00'
        target=next(x.split('\t') for x in selected if identity in x)
        self.assertFalse(fine_convergence_context(target,target))
        inner=next(x.split('\t') for x in previous if fine_convergence_context(target,x.split('\t')))
        projected=inner.copy();projected[0]='900'
        self.assertFalse(fine_convergence_context(target,projected))
        displaced=inner.copy()
        for k in (14,16,18,20):displaced[k]=str(float(displaced[k])+1000)
        self.assertFalse(fine_convergence_context(target,displaced))

    def test_full_selection_prefers_anchored_outline_but_retains_fine_evidence(self):
        from ict_trader.viewport_history import recognize
        records=recognize(dict(bars=self.bars,period='H1'))['records']
        fine='long_converging_candidate_v1:fine:32:2026-09-01T10:00:00+00:00'
        anchored='anchored_convergence_candidate_v1:21:2026-08-31T18:00:00+00:00'
        self.assertTrue(any(r.split('\t')[12]==fine for r in records))
        selected=select_balance_first(records)
        self.assertTrue(any(r.split('\t')[12]==anchored for r in selected))
        self.assertFalse(any(r.split('\t')[12]==fine for r in selected))

