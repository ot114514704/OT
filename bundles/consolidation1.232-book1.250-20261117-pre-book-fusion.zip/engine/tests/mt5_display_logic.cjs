// Runs display predicates from the production MQ5 source; not a native chart test.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
function extract(name){
 const m=source.match(new RegExp('(?:bool|double|string) '+name+'\\([^)]*\\)\\s*\\{'));
 assert.ok(m,name);let end=m.index+m[0].length,depth=1;
 while(depth){const c=source[end++];if(c==='{')depth++;if(c==='}')depth--;}
 return source.slice(m.index,end).replace(/^(bool|double|string) /,'function ')
  .replace(/const (bool|int|double|string) /g,'').replace(/\b(double|int|bool|string) /g,'let ').replace(/\(double\)/g,'')
  .replace('StringReplace(stamp,"T"," ");','stamp=stamp.replaceAll("T"," ");');
}
const ctx=vm.createContext({MathMax:Math.max,MathMin:Math.min,MathSqrt:Math.sqrt,
 StringToInteger:s=>parseInt(s,10)||0,
 StringFind:(s,t)=>s.indexOf(t),StringSubstr:(s,start,length)=>length===undefined?s.slice(start):s.slice(start,start+length),
 show_h1:true,show_m15:false,h1_brief:'H1 LIVE',m15_brief:'M15 PENDING'});
for(const name of ['MorphologyEnabled','PeriodEnabled','RailPrice','PriceOverlap','SameDisplayRegion','DisplayPriority','FormationHours','ReadableFootprint','ReadableCandleSpan','InnerDisplayRegion','ValidDisplayFrame','AdjacentDisplayRegions','DisplayConflict','GeometryNote','EvidenceNote','SegmentDistance','LabelSpace','PeriodHealth','SelectedHealth'])
 vm.runInContext(extract(name),ctx);
let count=0;function check(name,value){assert.ok(value,name);count++;}
vm.runInContext(extract('ChannelContextRegion'),ctx);
vm.runInContext(extract('FineContextRegion'),ctx);
check('wide fine triangle coexists with overlapping balance box',ctx.FineContextRegion(0,100,120,112,100,108,10,90,119,119,101,101,false));
check('comparable triangles still compete',!ctx.FineContextRegion(0,100,120,112,100,108,10,90,119,113,101,107,true));
check('fine context does not admit price-disjoint box',!ctx.FineContextRegion(0,100,120,112,100,108,10,90,140,140,130,130,false));
check('fine context rejects small temporal intersection',!ctx.FineContextRegion(0,100,120,112,100,108,95,195,119,119,101,101,false));
check('fine context rejects crossed rails',!ctx.FineContextRegion(0,100,120,100,100,108,10,90,119,119,101,101,false));
check('long channel permits smaller overlapping box',ctx.ChannelContextRegion(0,100,120,100,100,80,20,60,115,110,100,95,false));
check('comparable channel remains competing',!ctx.ChannelContextRegion(0,100,120,100,100,80,10,90,118,102,98,82,true));
check('price-disjoint shape is not inner channel context',!ctx.ChannelContextRegion(0,100,120,100,100,80,20,60,215,210,200,195,false));
check('tiny time overlap cannot restore unrelated shape',!ctx.ChannelContextRegion(0,100,120,100,100,80,95,125,105,100,95,90,false));
check('invalid reversed rails remain rejected',!ctx.ChannelContextRegion(0,100,80,80,100,100,20,60,95,95,90,90,false));
check('matching broad structural box cannot erase independent channel',ctx.ChannelContextRegion(0,100,120,100,100,80,-5,105,120,120,85,85,false,true));
check('broad box permission needs substantial common time',!ctx.ChannelContextRegion(0,100,120,100,100,80,40,140,120,120,85,85,false,true));
check('same-sized box has no exception without broad evidence',!ctx.ChannelContextRegion(0,100,120,100,100,80,-5,105,120,120,85,85,false,false));
check('default keeps all geometry families', ['rectangle','channel','converging'].every(g=>ctx.MorphologyEnabled(g,false)));
check('convergence view retains triangles and wedges',ctx.MorphologyEnabled('converging',true));
check('convergence view excludes boxes and channels without deleting records',!ctx.MorphologyEnabled('rectangle',true)&&!ctx.MorphologyEnabled('channel',true));
check('H1 switch does not enable M15',ctx.PeriodEnabled(3600,'local',true,false)&&!ctx.PeriodEnabled(900,'local',true,false));
check('M15 switch does not enable H1',ctx.PeriodEnabled(900,'local',false,true)&&!ctx.PeriodEnabled(3600,'local',false,true));
check('both can be enabled',ctx.PeriodEnabled(900,'macro',true,true)&&ctx.PeriodEnabled(3600,'macro',true,true));
check('both can be disabled',!ctx.PeriodEnabled(900,'local',false,false)&&!ctx.PeriodEnabled(3600,'local',false,false));
check('M15-on-H1 duplicate is excluded',!ctx.PeriodEnabled(3600,'intraday',true,true));
const box=[0,100,120,120,100,100];
check('same region suppressed',ctx.SameDisplayRegion(...box,0,100,121,121,99,99));
check('sliding repeated candidate suppressed',ctx.SameDisplayRegion(...box,10,110,120,120,100,100));
check('rectangle and nearly parallel channel share a region',ctx.SameDisplayRegion(...box,0,100,121,119,101,99));
check('small nested region preserved',!ctx.SameDisplayRegion(...box,60,95,112,112,105,105));
check('narrow nested range preserved',!ctx.SameDisplayRegion(...box,0,100,111,111,106,106));
check('adjacent stage preserved',!ctx.SameDisplayRegion(...box,100,200,120,120,100,100));
check('different price level preserved',!ctx.SameDisplayRegion(...box,0,100,145,145,125,125));
check('crossed rails not merged',!ctx.SameDisplayRegion(...box,0,100,95,95,100,100));
check('invalid duration not merged',!ctx.SameDisplayRegion(...box,50,50,120,120,100,100));
check('confirmation preferred to active unconfirmed alternative',ctx.DisplayPriority(true,'geometric',12)<ctx.DisplayPriority(false,'macro',96));
check('active preferred within same scale',ctx.DisplayPriority(true,'geometric',12)>ctx.DisplayPriority(false,'geometric',12));
check('confirmed preferred within same scale',ctx.DisplayPriority(false,'local',24)>ctx.DisplayPriority(false,'geometric',24));
check('complete channel outranks fragmented confirmed box',ctx.DisplayPriority(false,'structural',48)>ctx.DisplayPriority(false,'local',6));
check('a later oversized window gets no extra scale bonus',ctx.DisplayPriority(false,'structural',96)===ctx.DisplayPriority(false,'structural',48));
check('native timeframe formation counts share an hour scale',ctx.FormationHours(900,'依据：观察 192 根；')===ctx.FormationHours(3600,'依据：观察 48 根；'));
check('weekend duration cannot inflate formation evidence',ctx.FormationHours(3600,'依据：观察 24 根；')===24);
check('missing formation evidence gets no broad range bonus',ctx.FormationHours(3600,'候选')===0);
check('wide formation preferred within layer',ctx.DisplayPriority(false,'structural',96)>ctx.DisplayPriority(false,'structural',24));
check('tiny ended geometry hidden in compact mode',!ctx.ReadableFootprint(false,false,true,10,10));
check('short historical relay remains visible at normal H1 zoom',ctx.ReadableFootprint(false,false,true,24,60));
check('two-bar-width candidate remains visible',ctx.ReadableFootprint(false,false,true,12,40));
check('subpixel-height noise remains hidden',!ctx.ReadableFootprint(false,false,true,24,4));
check('active tiny geometry retained',ctx.ReadableFootprint(true,false,true,10,10));
check('footprint predicate optional relaxation',ctx.ReadableFootprint(false,false,false,10,10));
check('overlapping labels rejected',!ctx.LabelSpace(10,10,150,20,15,150));
check('two-line labels do not overlap',!ctx.LabelSpace(10,10,150,10,35,150));
check('separate labels accepted',ctx.LabelSpace(10,10,150,10,50,150));
check('one chart candle fragments rejected',!ctx.ReadableCandleSpan(1,1));
check('two intervals retain a readable inner formation',ctx.ReadableCandleSpan(2,2));
check('edge slice of an offscreen structure rejected',!ctx.ReadableCandleSpan(40,1));
check('partial but meaningful history remains visible',ctx.ReadableCandleSpan(40,5));
check('small child gives parent quieter fill',ctx.InnerDisplayRegion(20,60,115,113,103,105,...box));
check('adjacent formation is not an inner child',!ctx.InnerDisplayRegion(100,130,115,113,103,105,...box));
check('same-size repeated region is not nesting',!ctx.InnerDisplayRegion(...box,...box));
check('price-outside formation is not nested',!ctx.InnerDisplayRegion(20,60,130,128,123,125,...box));
check('crossed child rails are invalid',!ctx.InnerDisplayRegion(20,60,110,102,104,106,...box));
check('minor wick excursion within 2 percent parent height remains nested',ctx.InnerDisplayRegion(20,60,120.1,119,103,105,...box));
check('protruding child beyond parent tolerance is not nested',!ctx.InnerDisplayRegion(20,60,120.5,119,103,105,...box));
check('valid frame',ctx.ValidDisplayFrame(...box));
check('crossed final rails rejected',!ctx.ValidDisplayFrame(0,100,120,98,100,100));
check('same-period rectangle and channel cannot coexist',ctx.DisplayConflict(3600,...box,3600,10,110,125,115,105,95));
check('same-period nested alternative cannot coexist',ctx.DisplayConflict(3600,...box,3600,20,60,115,113,103,105));
check('adjacent periods stay independent',!ctx.DisplayConflict(3600,...box,3600,100,200,120,120,100,100));
check('sliver intersection still excluded',ctx.DisplayConflict(3600,...box,3600,99.99,200,120,120,100,100));
check('successive distinct levels sharing a small corner stay visible',!ctx.DisplayConflict(3600,...box,3600,95,150,145,145,118,118));
check('successive level exception symmetric',!ctx.DisplayConflict(3600,95,150,145,145,118,118,3600,...box));
check('substantial time overlap still excluded',ctx.DisplayConflict(3600,...box,3600,70,150,145,145,118,118));
check('substantial price overlap still excluded',ctx.DisplayConflict(3600,...box,3600,95,150,125,125,105,105));
check('rails swapping relative order cannot use adjacent exception',ctx.DisplayConflict(3600,...box,3600,95,150,150,-510,148,-512));
check('M15 child contained in H1 is allowed',!ctx.DisplayConflict(3600,...box,900,20,60,115,113,103,105));
check('nested rule symmetric in selection order',!ctx.DisplayConflict(900,20,60,115,113,103,105,3600,...box));
check('M15 protruding into H1 edge is excluded',ctx.DisplayConflict(3600,...box,900,20,60,121,113,103,105));
check('H1 and M15 duplicate region excluded',ctx.DisplayConflict(3600,...box,900,...box));
check('opposite channels crossing excluded',ctx.DisplayConflict(3600,0,100,140,110,130,100,900,20,90,105,145,95,135));
check('non-overlapping history preserved',!ctx.DisplayConflict(900,0,25,115,113,103,105,3600,30,100,120,120,100,100));
check('wedge note preserves candidate qualification',ctx.GeometryNote('converging','三角收敛','geometric')==='上下轨逐步收窄 · 候选未确认');
check('box note preserves confirmed qualification',ctx.GeometryNote('rectangle','局部水平区间','local')==='水平边界内往返 · 平衡已确认');
check('ended channel note is not called active',ctx.GeometryNote('channel','倾斜通道·已离开','structural')==='沿倾斜双轨往返 · 已离开');
check('restores full evidence in chart note',ctx.EvidenceNote('完成摆动 4 段','依据：观察24根；方向效率 0.13；已验证轨道覆盖')==='完成摆动 4 段；方向效率 0.13');
check('evidence extraction stops before next line',ctx.EvidenceNote('测试 2/2 次','方向效率 0.16\n资格：候选')==='测试 2/2 次；方向效率 0.16');
check('does not duplicate evidence',ctx.EvidenceNote('方向效率 0.13','方向效率 0.13')==='方向效率 0.13');
check('edge hit test uses exact rendered segment',ctx.SegmentDistance(5,5,0,0,10,10)===0);
check('hit test does not select extension outside segment',ctx.SegmentDistance(20,20,0,0,10,10)>7);
check('degenerate segment hit test',ctx.SegmentDistance(3,4,0,0,0,0)===5);
const h1=ctx.PeriodHealth('H1','live','H1 非盘整 / 间隔后10/12根 / M15 证据不足 · 收盘 11-06 11:45 / H1收盘','2026-11-06T11:00:00+00:00');
check('H1 excludes companion M15 status and time',!h1.includes('M15')&&!h1.includes('11:45')&&h1.includes('11:00'));
check('full tooltip retains readiness',h1.includes('间隔后10/12根'));
check('brief header drops detailed clauses',!ctx.PeriodHealth('H1','live','H1 非盘整 / 间隔后10/12根','2026-11-06T11:00:00+00:00',true).includes('间隔后'));
check('M15 retains own pending state and close',ctx.PeriodHealth('M15','analysis_pending','证据不足','2026-11-06T11:45:00+00:00',true)==='M15 新收盘重算中 · 证据不足 · 收盘 11-06 11:45');
check('unavailable is explicit',ctx.PeriodHealth('M15','stale','盘整','2026-11-06T11:45:00+00:00',true).includes('当前不可用（stale）'));
check('H1-only status',ctx.SelectedHealth()==='H1 LIVE');
ctx.show_h1=false;ctx.show_m15=true;
check('M15-only status',ctx.SelectedHealth()==='M15 PENDING');
ctx.show_h1=true;
check('both status',ctx.SelectedHealth()==='H1 LIVE | M15 PENDING');
ctx.show_h1=false;ctx.show_m15=false;
check('both hidden remains live background',ctx.SelectedHealth().includes('后台继续读取'));
// Native chart wiring: selections only gate drawing, never rewrite source rows.
const selection=source.slice(source.indexOf('void SelectDisplayShapes('),source.indexOf('bool HeartbeatFresh('));
assert.match(selection,/DisplayConflict\(shapes\[i\]\.seconds/);
assert.doesNotMatch(selection,/if\(compact\)for/);
assert.ok(selection.indexOf('int representatives[]')<selection.indexOf('frame_x[i][k]=x'));
assert.doesNotMatch(selection,/ranks\[n\]\+=20000/);
assert.doesNotMatch(selection,/shapes\[[^\]]+\]\.\w+\s*=(?!=)/);
assert.match(source,/if\(!found \|\| ArraySize\(label_x\)>=/);
assert.doesNotMatch(source,/Keep a label for every visible segment/);
assert.match(selection,/ArrayResize\(paint_shapes,ArraySize\(selected_shapes\)\)/);
assert.match(selection,/ShapeArea\(paint_shapes\[j\]\)>ShapeArea\(paint_shapes\[j-1\]\)/);
assert.match(source,/int i=paint_shapes\[slot\]/);
assert.match(source,/outer\?MathMin\(14,InpFillAlpha\):InpFillAlpha/);
assert.match(source,/StrokeSegment\(pixels,width,h,top,xs\[edge\],ys\[edge\],xs\[next\],ys\[next\],ColorToARGB\(line_color,255\),outer\?1:2\)/);
assert.doesNotMatch(source,/ObjectCreate\(0,name,OBJ_TREND/);
assert.match(source,/PickDetail\(\(int\)lparam,\(int\)dparam\)/);
// All geometry, labels and click targeting consume the same captured frame.
const render=source.slice(source.indexOf('void Render()'),source.indexOf('int OnInit()'));
const hit=source.slice(source.indexOf('void PickDetail('),source.indexOf('// Measure the exact'));
assert.doesNotMatch(render,/ChartTimePriceToXY/);
assert.doesNotMatch(hit,/ChartTimePriceToXY/);
assert.match(render,/xs\[k\]=frame_x\[i\]\[k\];ys\[k\]=frame_y\[i\]\[k\]/);
assert.match(render,/ExplainShape\(i,frame_x\[i\]\[0\],frame_y\[i\]\[0\]/);
assert.match(render,/if\(frame_view!=ViewKey\(\)\)\{FillVisibility\(false\);dirty=true;view_pending=true;return;\}/);
const visibility=source.slice(source.indexOf('void FillVisibility('),source.indexOf('void LatestButton('));
assert.match(visibility,/prefix\+"FILL"/);assert.match(visibility,/prefix\+"TEXT"/);
const timer=source.slice(source.indexOf('void OnTimer()'),source.indexOf('void OnChartEvent('));
assert.ok(timer.indexOf('string current=ViewKey()')<timer.indexOf('last_poll<2000'));
assert.match(source,/IntegerToString\(\(long\)iTime\(_Symbol,_Period,0\)\)/);
// Inspect real exported history with the same production overlap/rank predicates.
const input=process.argv[2];let groups=[];
if(input){
 const lines=fs.readFileSync(input,'utf8').trim().split(/\r?\n/).slice(1);
 const rows=lines.map(line=>{const a=line.split('\t');return {period:+a[0],key:a[1],kind:a[3],known:+a[5],detail:a[23],active:a[10]==='1',title:a[21],t0:+a[13],t1:+a[15],g:[+a[13],+a[15],+a[14],+a[16],+a[20],+a[18]]};});
 for(const period of [3600,900,0]){
  const all=rows.filter(r=>(!period||r.period===period)&&r.kind!=='intraday'&&ctx.ValidDisplayFrame(...r.g));
  const rank=a=>ctx.DisplayPriority(a.active,a.kind,ctx.FormationHours(a.period,a.detail))+(!period?(a.period===3600?1000000:(['macro','local'].includes(a.kind)?100000:0)):0);
  const selected=[];const sorted=[...all].sort((a,b)=>rank(b)-rank(a)||a.known-b.known||a.key.localeCompare(b.key));
  for(const a of sorted)if(!selected.some(b=>ctx.DisplayConflict(a.period,...a.g,b.period,...b.g)))selected.push(a);
  check('each source period still has history',selected.length>0);
  check('all selected historical pairs are compatible',selected.every((a,i)=>selected.slice(i+1).every(b=>!ctx.DisplayConflict(a.period,...a.g,b.period,...b.g))));
  // Regression anchors identify existing source records, never add geometry.
  const expected=period===900?[
   ['2026-10-14T18:30:00','channel','2026-10-19T11:30:00'],
   ['2026-11-02T01:','rectangle','2026-11-04']
  ]:[['2026-10-14T19:00:00','channel','2026-10-19T13:00:00'],['2026-11-02T02:','rectangle','2026-11-04']];
  for(const [start,geometry,end] of expected){
   const primary=selected.filter(r=>r.period===(period||3600));
   check('whole reference stage survives '+start,primary.some(r=>new Date(r.t0*1000).toISOString().startsWith(start)&&new Date(r.t1*1000).toISOString().startsWith(end)&&r.title.includes(geometry==='channel'?'通道':'箱体')));
  }
  if(!period)check('standard confirmed inner rectangle retained beside H1 context',selected.some(r=>r.period===900&&r.kind==='macro'&&new Date(r.t0*1000).toISOString().startsWith('2026-11-05T07:00:00')&&new Date(r.t1*1000).toISOString().startsWith('2026-11-05T18:00:00')));
  groups.push({period,total:all.length,selected:selected.length,overlap_hidden:all.length-selected.length,keys:selected.map(r=>r.key)});
 }
}
console.log(JSON.stringify({passed:true,checks:count,scope:'Display predicates from actual MQ5 source, synthetic geometry and exported-history reduction. Not accuracy/backtest/native UI acceptance.',groups},null,2));
