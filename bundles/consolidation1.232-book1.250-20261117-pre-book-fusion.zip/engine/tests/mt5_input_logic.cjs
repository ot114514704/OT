// Execute the production MQL input arithmetic. Native gestures are verified
// separately: these checks cannot prove Windows/MT5 event ordering or painting.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
function extract(name){
 const match=source.match(new RegExp('(?:int|bool|void) '+name+'\\([^)]*\\)\\s*\\{'));
 assert.ok(match,name);let end=match.index+match[0].length,depth=1;
 while(depth){const c=source[end++];if(c==='{')depth++;if(c==='}')depth--;}
 return source.slice(match.index,end).replace(/^(int|bool|void) /,'function ')
  .replace(/const (int|double|bool|ulong) /g,'').replace(/\b(?:int|ulong) (\w+)\s*=/g,'let $1=').replace(/\(int\)/g,'');
}
const ctx=vm.createContext({MathMax:Math.max,MathMin:Math.min,MathRound:x=>Math.sign(x)*Math.round(Math.abs(x))});
for(const name of ['BoundFirstBar','DragFirstBar','DragLeaseExpired','ShapeSnapshotComplete'])vm.runInContext(extract(name),ctx);
let checks=0;function check(name,p){assert.ok(p,name);checks++;}
check('outside-window release cannot keep overlays hidden indefinitely',ctx.DragLeaseExpired(true,900));
check('recent mouse movement retains gesture ownership',!ctx.DragLeaseExpired(true,899));
check('inactive gesture does not force repeated repaint',!ctx.DragLeaseExpired(false,100000));
check('partial snapshot cannot replace previous history',!ctx.ShapeSnapshotComplete(true,false,20,13));
check('truncated snapshot with trailer still rejected',!ctx.ShapeSnapshotComplete(true,true,20,13));
check('malformed row invalidates entire snapshot',!ctx.ShapeSnapshotComplete(false,true,20,20));
check('complete snapshot accepted',ctx.ShapeSnapshotComplete(true,true,20,20));
check('intentional complete empty snapshot accepted',ctx.ShapeSnapshotComplete(true,true,0,0));
check('130 pixels at 13 pixels/bar moves exactly ten bars',ctx.DragFirstBar(91,130,13,85,1000)===101);
check('opposite drag returns to the initial bar',ctx.DragFirstBar(101,-130,13,85,1000)===91);
check('movement uses original press anchor across repeated events',
 [26,65,130,130].map(p=>ctx.DragFirstBar(91,p,13,85,1000)).join(',')==='93,96,101,101');
check('drag out and back restores anchor even below initial threshold',ctx.DragFirstBar(91,0,13,85,1000)===91);
check('oldest received bar bounds dragging',ctx.DragFirstBar(998,1000,13,85,1000)===999);
check('latest full viewport bounds dragging',ctx.DragFirstBar(91,-1000,13,85,1000)===84);
check('history shorter than viewport remains valid',ctx.BoundFirstBar(100,85,12)===11);
check('no loaded bars cannot produce negative index',ctx.BoundFirstBar(100,85,0)===0);
check('fractional bar spacing follows pixel displacement',ctx.DragFirstBar(200,36,2.4,100,1000)===215);
check('zero bar spacing is guarded',Number.isFinite(ctx.DragFirstBar(200,36,0,100,1000)));
// Exactly one asynchronous disable at activation, exactly one restoration on
// unload. Press/release/history/latest must never re-enable the native handler.
const scrollCalls=[...source.matchAll(/ChartSetInteger\(0,CHART_MOUSE_SCROLL,([^)]*)\)/g)].map(m=>m[1]);
check('single owner for the entire gesture',scrollCalls.join(',')==='previous_mouse_scroll,false');
check('mouse settings restored on removal',source.includes('CHART_EVENT_MOUSE_WHEEL,previous_mouse_wheel')&&source.includes('CHART_EVENT_MOUSE_MOVE,previous_mouse_move'));
check('wheel navigation remains available',source.includes('id==CHARTEVENT_MOUSE_WHEEL')&&source.includes('wheel_remainder-=steps*120'));
const press=source.slice(source.indexOf('if(left && !drag_active)'),source.indexOf('if(left && drag_active)'));
check('detail press does not hide all valid drawings',!press.includes('FillVisibility(false)'));
const move=source.slice(source.indexOf('if(left && drag_active)'),source.indexOf('if(!left && drag_active)'));
check('actual pan hides old pixel frame before navigation',move.indexOf('FillVisibility(false)')>=0&&move.indexOf('FillVisibility(false)')<move.indexOf('FlushDragNavigation('));
check('mouse movement does not force a paint or read chart dimensions',!move.includes('ChartRedraw(')&&!move.includes('ChartGetInteger('));
let clock=1000,first=100,navigations=0;
Object.assign(ctx,{drag_navigation_pending:false,last_drag_navigation:0,drag_target:100,
 GetTickCount64:()=>clock,ChartGetInteger:()=>first,CHART_FIRST_VISIBLE_BAR:1,CHART_CURRENT_POS:2,
 ChartNavigate:(_chart,_position,offset)=>{first-=offset;navigations++;}});
for(const name of ['DragNavigationDue','FlushDragNavigation'])vm.runInContext(extract(name),ctx);
check('no queued movement remains idle',!ctx.DragNavigationDue(false,true,1000,0));
check('new gesture moves without initial delay',ctx.DragNavigationDue(true,false,1000,0));
check('intermediate events are coalesced',!ctx.DragNavigationDue(true,false,1032,1000));
check('navigation resumes at 33ms',ctx.DragNavigationDue(true,false,1033,1000));
for(let elapsed=0;elapsed<1000;elapsed++){
 clock=1000+elapsed;ctx.drag_target=100+Math.floor(elapsed/10);ctx.drag_navigation_pending=true;
 ctx.FlushDragNavigation(false);
}
check('1000 move events submit at most 31 navigations',navigations<=31&&navigations>0);
ctx.drag_target=287;ctx.drag_navigation_pending=true;ctx.FlushDragNavigation(true);
check('release flushes the final cursor target exactly',first===287&&!ctx.drag_navigation_pending);
ctx.drag_target=100;ctx.drag_navigation_pending=true;ctx.FlushDragNavigation(true);
check('coalescing preserves return to original anchor',first===100);
const timer=source.slice(source.indexOf('void OnTimer()'),source.indexOf('bool OwnedUiClick('));
check('active drag returns before file/model read',timer.indexOf('else {FlushDragNavigation(false);return;}')<timer.indexOf('RequestHistory();'));
console.log(JSON.stringify({passed:true,checks,scope:'Production drag arithmetic and input ownership wiring; physical gestures require native acceptance.'},null,2));
