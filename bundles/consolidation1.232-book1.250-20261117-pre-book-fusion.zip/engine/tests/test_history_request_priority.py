import os
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from ict_trader.viewport_history import ordered_requests


class HistoryRequestPriorityTests(unittest.TestCase):
    def test_latest_visible_chart_goes_first_without_dropping_other_charts(self):
        with TemporaryDirectory() as directory:
            root=Path(directory);paths=[]
            for name,stamp in [('viewport_old_H1.request.tsv',10),('backfill_M15.request.tsv',40),
                               ('viewport_active_M15.request.tsv',30),('viewport_other_H1.request.tsv',20)]:
                p=root/name;p.write_text('closed native request');stamp=(1700000000+stamp)*1_000_000_000
                os.utime(p,ns=(stamp,stamp));paths.append(p)
            ordered=ordered_requests(paths)
            self.assertEqual([p.name for p in ordered],[paths[2].name,paths[3].name,paths[0].name,paths[1].name])
            self.assertEqual(set(ordered),set(paths))


if __name__=='__main__':unittest.main()
