// Execute the actual MQ5 predicates over captured native records. No UI claim.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
function extract(name){
 const m=source.match(new RegExp('(?:bool|double|string) '+name+'\\([^)]*\\)\\s*\\{'));
 assert.ok(m,name);let end=m.index+m[0].length,depth=1;
 while(depth){const c=source[end++];if(c==='{')depth++;if(c==='}')depth--;}
 return source.slice(m.index,end).replace(/^(bool|double|string) /,'function ')
 .replace(/const (bool|int|double|string) /g,'').replace(/\b(double|int|bool|string) /g,'let ').replace(/\(double\)/g,'');
}
const ctx=vm.createContext({MathMax:Math.max,MathMin:Math.min,ArraySize:a=>a.length,
 StringToInteger:s=>parseInt(s,10)||0,StringFind:(s,t)=>s.indexOf(t),
 StringSubstr:(s,a,n)=>n===undefined?s.slice(a):s.slice(a,a+n)});
for(const n of ['RailPrice','InnerDisplayRegion','NestedRectangle','NestedPriceOverlap','EarlyNestedPriceOverlap',
 'ReadableNativePause','SuccessiveFormations','FormationHours','ShapePriority','AdjacentDisplayRegions','DisplayConflict','IndependentM15Layer'])
 vm.runInContext(extract(n),ctx);
const outer={seconds:3600,geometry:'rectangle',kind:'structural',t:[0,100,100,0],p:[120,120,100,100]};
const inner={seconds:900,geometry:'converging',kind:'geometric',t:[20,60,60,20],p:[123,119,108,104]};
ctx.shapes=[outer,inner];assert.equal(ctx.IndependentM15Layer(1,0),true);
ctx.shapes=[outer,{...inner,t:[-1,60,60,-1]}];assert.equal(ctx.IndependentM15Layer(1,0),true);
ctx.shapes=[outer,{...inner,seconds:3600}];assert.equal(ctx.IndependentM15Layer(1,0),false);
ctx.shapes=[outer,{...inner,kind:'intraday'}];assert.equal(ctx.IndependentM15Layer(1,0),false);
ctx.shapes=[{...outer,seconds:900},inner];assert.equal(ctx.IndependentM15Layer(1,0),false);
assert.equal(ctx.ReadableNativePause(true,6,6,6,25),true);
assert.equal(ctx.ReadableNativePause(false,6,6,6,25),false);
assert.equal(ctx.ReadableNativePause(true,1,1,6,25),false);
assert.equal(ctx.ReadableNativePause(true,6,1,6,25),false);
assert.equal(ctx.ReadableNativePause(true,6,6,6,2),false);
const fixture=process.argv[2];let result={passed:true,synthetic_checks:10,native_records:0};
if(fixture){
 const rows=JSON.parse(fs.readFileSync(fixture,'utf8')).map(s=>s.split('\t')).filter(r=>r[3]!=='intraday');
 ctx.shapes=rows.map(r=>({seconds:+r[0],key:r[1],geometry:r[2],kind:r[3],known:+r[5],
  t:[+r[13],+r[15],+r[17],+r[19]],p:[+r[14],+r[16],+r[18],+r[20]],title:r[21],detail:r[23]}));
 const shapes=ctx.shapes;
 const ordered=shapes.map((s,i)=>({i,rank:ctx.ShapePriority(i)+(s.seconds===3600?1e6:(['macro','local'].includes(s.kind)?1e5:0))}))
  .sort((a,b)=>b.rank-a.rank||shapes[a.i].known-shapes[b.i].known||shapes[a.i].key.localeCompare(shapes[b.i].key)).map(x=>x.i);
 function choose(newPass){
  const keep=[];
  const conflict=(i,j,pass)=>{
   if(ctx.NestedRectangle(i,j)||ctx.NestedRectangle(j,i)||ctx.NestedPriceOverlap(i,j)||ctx.NestedPriceOverlap(j,i))return false;
   if(pass>=0&&(ctx.EarlyNestedPriceOverlap(i,j)||ctx.EarlyNestedPriceOverlap(j,i)))return false;
   if(pass>=1&&(ctx.SuccessiveFormations(i,j)||ctx.SuccessiveFormations(j,i)))return false;
   if(pass>=2&&ctx.IndependentM15Layer(i,j))return false;
   const a=shapes[i],b=shapes[j];
   return ctx.DisplayConflict(a.seconds,a.t[0],a.t[1],a.p[0],a.p[1],a.p[3],a.p[2],b.seconds,b.t[0],b.t[1],b.p[0],b.p[1],b.p[3],b.p[2]);
  };
  for(let pass=-1;pass<(newPass?3:2);pass++)for(const i of ordered)
   if(!keep.includes(i)&&!keep.some(j=>conflict(i,j,pass)))keep.push(i);
  return {keep,conflict};
 }
 const previous=choose(false),updated=choose(true),before=previous.keep,after=updated.keep;assert.ok(before.every(i=>after.includes(i)));
 const targets=rows.map((r,i)=>({r,i})).filter(({r})=>r[0]==='900'&&(
  r[12]==='long_converging_candidate_v1:48:2026-10-21T20:30:00+00:00'||
  r[12]==='dense_horizontal_pause_v1:body6:2026-11-11T19:45:00+00:00'||
  r[12]==='dense_horizontal_pause_v1:2026-11-13T12:15:00+00:00'));
 assert.equal(targets.length,3);assert.ok(targets.every(({i})=>after.includes(i)));
 result={...result,native_records:rows.length,before:before.length,after:after.length,old_representatives_retained:true,
  targets:targets.map(({r,i})=>({id:r[12],before:before.includes(i),after:after.includes(i),
    blockers:after.filter(j=>j!==i&&updated.conflict(i,j,2)).map(j=>({id:rows[j][12],period:rows[j][0],
     start:new Date(shapes[j].t[0]*1000).toISOString(),end:new Date(shapes[j].t[1]*1000).toISOString(),shape:rows[j][2]}))}))};
}
console.log(JSON.stringify(result,null,2));
