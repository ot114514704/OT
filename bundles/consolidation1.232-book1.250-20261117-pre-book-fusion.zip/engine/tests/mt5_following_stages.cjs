// Execute the production native representative loop on actual exported records.
// No claim of physical MT5 rendering or native MQL execution.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('mt5/IPDA_Consolidation.mq5','utf8');
function convert(code){return code.replace(/const (bool|int|double|string) /g,'').replace(/\b(double|int|bool|string) /g,'let ').replace(/\(double\)/g,'').replace(/let (\w+)\[\];/g,'let $1=[];');}
function extract(name){
 const m=source.match(new RegExp('(?:bool|double|string) '+name+'\\([^)]*\\)\\s*\\{'));assert(m,name);
 let end=m.index+m[0].length,depth=1;while(depth){const c=source[end++];if(c==='{')depth++;if(c==='}')depth--;}
 return convert(source.slice(m.index,end).replace(/^(bool|double|string) /,'function '));
}
const ctx=vm.createContext({MathMax:Math.max,MathMin:Math.min,ArraySize:a=>a.length,ArrayResize:(a,n)=>a.length=n});
for(const name of ['RailPrice','InnerDisplayRegion','NestedRectangle','NestedPriceOverlap','EarlyNestedPriceOverlap','SuccessiveFormations','AdjacentDisplayRegions','DisplayConflict'])vm.runInContext(extract(name),ctx);
function shape(line){const a=line.split('\t');return {seconds:+a[0],kind:a[3],geometry:a[2],known:+a[5],t:[+a[13],+a[15],+a[17],+a[19]],p:[+a[14],+a[16],+a[18],+a[20]]};}
const start=source.indexOf('   int representatives[];'),end=source.indexOf('   for(int slot=0;slot<ArraySize(representatives);slot++)',start);
assert(start>0&&end>start);
const block=convert(source.slice(start,end));
let checks=0;function check(name,value){assert(value,name);checks++;}
function selection(rows,order){ctx.shapes=rows.map(shape);ctx.candidates=order;return vm.runInContext('(function(){'+block+';return representatives;})()',ctx);}
const may=JSON.parse(fs.readFileSync('tests/fixtures/may15_following_tail_overlap.json','utf8'));
let out=selection(may,[1,0]);
check('later wide box retains original representative',out[0]===1);
check('actual earlier native compact channel restored',out.includes(0)&&out.length===2);
check('actual channel passes only forward successive relation',ctx.SuccessiveFormations(0,1)&&!ctx.SuccessiveFormations(1,0));
ctx.shapes[0].known=ctx.shapes[1].t[0]+1;
check('concurrent formation cannot use following-tail exception',!ctx.SuccessiveFormations(0,1));
ctx.shapes=may.map(shape);ctx.shapes[0].t[1]+=3600;
check('too much tail overlap rejected',!ctx.SuccessiveFormations(0,1));
ctx.shapes=may.map(shape);ctx.shapes[1].geometry='converging';
check('crossing geometric parent rejected',!ctx.SuccessiveFormations(0,1));
const november=JSON.parse(fs.readFileSync('tests/fixtures/nov9_live_display_overlap.json','utf8')).filter(x=>x.split('\t')[3]!=='intraday');
const narrow=november.findIndex(x=>x.includes(':return4:')),wide=1-narrow;
out=selection(november,[wide,narrow]);
check('known H1 four-bar rectangle survives later wider rectangle',out.includes(narrow)&&out.includes(wide));
check('new exceptions append after legacy representative selection',block.indexOf('for(let pass=0;pass<2;pass++)')>block.indexOf('if(!duplicate)'));
check('supplementary pass retains originals without removal',!block.includes('ArrayRemove'));
console.log(JSON.stringify({passed:true,checks,scope:'Production native predicates and representative loop; native desktop rendering pending.'},null,2));
