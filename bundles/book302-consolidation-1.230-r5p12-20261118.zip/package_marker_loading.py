"""Create and verify a restoration backup from the installed marker-loading release."""
from hashlib import sha1
import json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

from package_book_outline_side import ROOT,read,sha
from verify_marker_loading import OUT


def main():
    native=read(OUT/'native_acceptance.json')
    assert native['stage']=='full' and native['present_objects']==12
    assert native['ex5']==sha((ROOT/'source/Book302_Consolidation_Experiment.ex5').read_bytes())
    assert native['worker']==sha((ROOT/'worker.py').read_bytes())
    assert 'OK' in (OUT/'regression.txt').read_text('utf-8-sig').splitlines()
    names=['worker.py','source/BookExperimentGuard.mqh','source/Book302_Consolidation_Experiment.ex5',
           'test_request_return.py','verify_marker_loading.py','package_marker_loading.py',
           'replay_may_cross_context.py','check_may_outline_ownership.py','rank_may_shared_ranges.py','plot_may_shared_ranges.py']
    names.extend(p.relative_to(ROOT).as_posix() for p in OUT.iterdir() if p.is_file() and p.name!='OT_receipt.json')
    may=ROOT/'verification/book_cross_context_may_20261118'
    names.extend(p.relative_to(ROOT).as_posix() for p in may.iterdir() if p.is_file() and p.name!='request_replay.json')
    result={}
    for kind,prior in read(ROOT/'PACKAGE_R5P11.json').items():
        base=Path(prior['path'])
        assert sha(base.read_bytes())==prior['sha256']
        with ZipFile(base) as z:
            contents={k:z.read(k) for k in z.namelist() if k!='R5P11_PACKAGE_MANIFEST.json'}
        contents.update({k:(ROOT/k).read_bytes() for k in names})
        contents['README_R5P12.txt']=(OUT/'版本与恢复说明.txt').read_bytes()
        manifest={k:sha(data) for k,data in contents.items()}
        path=base.parent/f'Book302_1.230-r5p12_内穿标注快速加载_{kind}_20261118.zip'
        with ZipFile(path,'x',ZIP_DEFLATED) as z:
            for k,data in contents.items():z.writestr(k,data)
            z.writestr('R5P12_PACKAGE_MANIFEST.json',json.dumps(manifest,indent=2,ensure_ascii=False).encode())
        with ZipFile(path) as z:
            assert z.testzip() is None and all(sha(z.read(k))==v for k,v in manifest.items())
        data=path.read_bytes()
        result[kind]=dict(path=str(path),bytes=len(data),files_verified=len(manifest),sha256=sha(data),
                          git_blob_sha=sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
    (ROOT/'PACKAGE_R5P12.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),'utf8')


if __name__=='__main__':
    main()
