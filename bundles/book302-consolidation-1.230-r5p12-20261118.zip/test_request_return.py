"""A completed viewport must not suppress recovery from an abandoned request."""
import tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import worker,research_adapter

class ReturnViewportTests(unittest.TestCase):
 def test_return_to_completed_view_republishes_after_abandoned_pending(self):
  original=(worker.BASE/'verification/native_r3/final/request_102923304041429_3600.tsv').read_text('utf-8-sig')
  token=original.splitlines()[0].split('\t')[2]
  a=original.replace(token,'view-a');b=original.replace(token,'view-b')
  with tempfile.TemporaryDirectory(dir=worker.BASE/'verification') as name:
   folder=Path(name);path=folder/'request_test.tsv';path.write_text(a,'utf8');calls=[];sleeps=[]
   def solve(req,progress,on_marks=None):
    calls.append(req['token'])
    if req['token']=='view-b':path.write_text(a,'utf8')
    return []
   def export(output,req,charts):
    output.mkdir(exist_ok=True)
    (output/'heartbeat.tsv').write_text('\t'.join(['IPDA_LIVE','1','0',req['token'],'experiment_snapshot','ready','','','ready','','','','0']),'utf8')
   def sleep(_):
    sleeps.append(1)
    if len(calls)==1:path.write_text(b,'utf8')
    if len(calls)>=3 or len(sleeps)>=5:(folder/'worker.stop').write_text('test complete','utf8')
   with patch.object(worker,'solve',solve),patch.object(research_adapter,'run',return_value=({'available':True},{'H1':{}})),patch.object(research_adapter,'export_companion',export),patch.object(worker.time,'sleep',sleep):
    worker.serve(folder)
   self.assertEqual(calls,['view-a','view-b','view-a'])
   state=(folder/'companion_test/heartbeat.tsv').read_text('utf8').split('\t')
   self.assertEqual(state[3:6],['view-a','experiment_snapshot','ready'])
   self.assertTrue((folder/'progress_test.txt').read_text('utf8').startswith('view-a\t完成'))

if __name__=='__main__':unittest.main()
