"""Plot native closed-bar boundaries for one triangle and one overlapping channel/box."""
from datetime import datetime

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from book_pair_recovery import line_at
from replay_may_cross_context import OUT,history,inspect_close,read,recognize,stamp


def main():
    bars=history()
    opens={stamp(b.time):i for i,b in enumerate(bars)}
    closes={stamp(b.closed_at):i for i,b in enumerate(bars)}
    rows=read(OUT/'selected.json')
    plt.rcParams.update({'font.family':'Microsoft YaHei','axes.unicode_minus':False})
    fig,axes=plt.subplots(2,1,figsize=(9.2,6.8),layout='constrained')
    for ax,target,title in zip(axes,('2026-05-21T21','2026-05-26T04'),('收破双线，同时收在三角和箱体上方','收破双线，收在箱体下方，仍在通道内')):
        r=next(r for r in rows if r['clock'].startswith(target))
        i=closes[r['clock']]
        p=next(p for p in inspect_close(bars[i-511:i+1])['pairs'] if p['owner']==r['owner'])
        s=r['selected']
        box=s['overlap_box']
        ticks=list(range(i-9,i+1))
        ranges={j:{c['id']:c for c in recognize(tuple(bars[i-512:j+1]))[0]} for j in ticks}
        for k,ref,label,color in [('shape',s,'三角' if s['shape']=='triangle' else '通道','#297878'),
                                  ('box',box,'重叠箱体','#c79534')]:
            js=[j for j in ticks if ref['id'] in ranges[j]]
            low=[ranges[j][ref['id']]['low'] for j in js]
            high=[ranges[j][ref['id']]['high'] for j in js]
            assert js[-1]==i and (low[-1],high[-1])==(ref['low'],ref['high'])
            ax.fill_between(js,low,high,color=color,alpha=.11,label=label)
            ax.plot(js,low,color=color,lw=1)
            ax.plot(js,high,color=color,lw=1)
        for j in ticks:
            b=bars[j]
            color='#176d5e' if b.close>=b.open else '#a3443d'
            ax.vlines(j,b.low,b.high,color=color,lw=.9)
            ax.vlines(j,b.open,b.close,color=color,lw=4)
        for role,k,color,label in [('trend',0,'#284fa2','Book 趋势线'),('turning',2,'#96588b','Book 拐点线')]:
            js=[j for j in ticks if stamp(bars[j].time)>=p['pair_known']]
            ax.plot(js,[float(line_at(p[role],p[role][k],j,opens)) for j in js],color=color,lw=1.6,label=label)
        ax.scatter([i],[bars[i].close],s=38,color='#222',zorder=5)
        ax.set_title(r['clock'][5:10]+' '+r['clock'][11:16]+' UTC   '+title,loc='left',fontsize=12)
        ax.set_ylabel('XAUUSD')
        ax.legend(loc='upper left',ncol=4,fontsize=8,framealpha=.86)
        ax.set_xticks(ticks[::3],[bars[j].closed_at.strftime('%m-%d\n%H:%M') for j in ticks[::3]])
        ax.grid(axis='y',alpha=.15)
        ax.spines[['top','right']].set_visible(False)
    fig.suptitle('Book 双线与事前可见的盘整范围',fontsize=16)
    fig.savefig(OUT/'五月通道三角与重叠箱体.png',dpi=145)
    plt.close(fig)


if __name__=='__main__':
    main()
