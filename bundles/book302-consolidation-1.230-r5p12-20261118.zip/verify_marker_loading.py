"""Replay an actual MT5 viewport and compare every early caption with its final result."""
import json
import time
from pathlib import Path

from package_book_outline_side import BRIDGE,KEY,read,tsv
from worker import encode_reply,parse_request,solve

OUT=Path(__file__).resolve().parent/'verification/book_marks_20261118'


def replay():
    req=parse_request((OUT/f'before_request_{KEY}.tsv').read_text('utf-8-sig'))
    old=read(OUT/f'before_audit_{KEY}.json')
    assert req['token']==old['token']
    baseline={r['id']:r for r in old['results']}
    epochs=[]
    start=time.monotonic()
    def marks(rows):
        assert len(rows)==len({r['id'] for r in rows})
        for r in rows:
            b=baseline[r['id']]
            assert r['code'] in (1,2,8) and r['id']!='__CURRENT'
            for k in ('code','clock','side','context','label','fixed','nmatches','pa'):
                assert r[k]==b[k],(r['id'],k)
        wire=encode_reply(req,rows,time.monotonic()-start,'marks')
        assert wire.splitlines()[0].split('\t')[2]==req['token']
        epochs.append(dict(seconds=round(time.monotonic()-start,3),ids=[r['id'] for r in rows]))
    result=solve(req,on_marks=marks)
    assert [r['id'] for r in result]==list(baseline)
    for r in result:
        b=baseline[r['id']].copy()
        suffix='；原研究全模型只作当前快照旁证，不回填此历史事件'
        if r['id']=='__CURRENT':
            assert b['detail'].startswith(r['detail']+'；')
            b['detail']=r['detail']
        else:
            assert b['detail'].endswith(suffix)
            b['detail']=b['detail'][:-len(suffix)]
        assert r==b,(r['id'],[k for k in r if r[k]!=b.get(k)])
    eligible={r['id'] for r in result if r['id']!='__CURRENT' and r['code'] in (1,2,8)}
    assert eligible and set(epochs[-1]['ids'])==eligible
    report=dict(token=req['token'],confirmed_records=len(result),eligible=len(eligible),
                prior_full_seconds=old['elapsed_seconds'],new_core_seconds=round(time.monotonic()-start,3),early=epochs)
    (OUT/'speed_replay.json').write_text(json.dumps(report,indent=2),'utf8')
    print('first',epochs[0]['seconds'],'core',report['new_core_seconds'],'eligible',len(eligible),flush=True)


def monitor(duration=360):
    start=time.monotonic()
    records=[]
    seen=None
    while time.monotonic()-start<duration:
        try:
            f=tsv(BRIDGE/f'render_state_{KEY}.tsv')[0].split('\t')
            key=(f[3],f[4],f[5],f[7],tuple(f[14:]))
            if key!=seen:
                seen=key
                records.append(dict(seconds=round(time.monotonic()-start,3),fields=f))
                (OUT/'native_stages.json').write_text(json.dumps(records,indent=2),'utf8')
                if len(f)>=17 and f[5]=='marks' and int(f[16])>0:
                    image=BRIDGE/f'experiment_{KEY}.png'
                    if image.exists():
                        (OUT/'native_marks.png').write_bytes(image.read_bytes())
                if len(f)>=17 and f[5]=='full' and int(f[16])>0 and any(r['fields'][3]==f[3] and r['fields'][5]=='marks' for r in records):
                    print('Verified marks and full on the same chart request',flush=True)
                    return
        except (OSError,IndexError,ValueError):
            pass
        time.sleep(.5)


if __name__=='__main__':
    replay()
