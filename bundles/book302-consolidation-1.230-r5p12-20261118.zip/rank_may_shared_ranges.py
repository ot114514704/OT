"""Select a shared range only with continuous price history, Book rails and range identity."""
import json
from functools import lru_cache

from replay_may_cross_context import IDENTITY,OUT,history,inspect_close,read,stamp


def main():
    bars=history()
    closes={stamp(b.closed_at):i for i,b in enumerate(bars)}
    @lru_cache(maxsize=256)
    def book(i):
        return inspect_close(bars[i-511:i+1]).get('pairs',())
    results=[]
    for c in read(OUT/'context.json')['cases']:
        start,end=closes[c['first']],closes[c['clock']]
        p=next(p for p in book(end) if p['owner']==c['owner'])
        expected=tuple(p[k] for k in IDENTITY)
        signed=[]
        for i in range(start,end+1):
            if bars[i].time!=bars[i-1].closed_at:
                signed.append(dict(clock=stamp(bars[i].closed_at),issue='bar_gap'))
                continue
            matches=[q for q in book(i) if tuple(q[k] for k in IDENTITY)==expected]
            if len(matches)!=1:
                signed.append(dict(clock=stamp(bars[i].closed_at),issue='original_pair_not_unique_or_absent'))
            elif i<end and not (matches[0]['source_alive'] and matches[0]['same_terminal']):
                signed.append(dict(clock=stamp(bars[i].closed_at),issue='source_retired_or_extended_before_last'))
        role='turning' if p['turning_break_bar']>=p['trend_break_bar'] else 'trend'
        def pick(n):
            data=c['context'][str(n)]
            if signed or not c['identity_reproduced']:
                return None
            # Pre-crossing rank is the existing selector's insertion order. On the final
            # close both rails have been witnessed; a later range cannot be backdated.
            shared=[(rid,r) for rid,r in data['rails'][role].items() if rid in data['continuous']]
            if not shared:
                return None
            rid,r=shared[0]
            box=next((dict(id=k,low=b['low'],high=b['high'],close_inside=b['close_inside']) for k,b in shared
                      if r['shape']!='box' and b['shape']=='box'),None)
            return dict(id=rid,shape=r['shape'],low=r['low'],high=r['high'],close_inside=r['close_inside'],
                        known=r['frozen'][1],selected_at=c['clock'],overlap_box=box)
        selected=pick(512)
        assert selected==pick(256)
        results.append(dict(clock=c['clock'],owner=p['owner'],direction=p['direction'],span=c['span'],reference=c['reference'],
                            close=c['close'],selected=selected,interruptions=signed,
                            geometry_only_common=len(c['context']['512']['continuous']),
                            owner_at_final_close=p['source_alive'] and p['same_terminal']))
    (OUT/'selected.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),'utf8')
    for r in results:
        s=r['selected']
        print(r['clock'],r['span'],None if not s else (s['shape'],s['low'],s['high'],s['close_inside'],s['overlap_box']),
              sorted({v['issue'] for v in r['interruptions']}),r['owner_at_final_close'])


if __name__=='__main__':
    main()
