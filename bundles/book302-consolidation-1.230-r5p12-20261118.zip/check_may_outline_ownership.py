"""Check original six-pivot geometry and the first post-formation rail exit in May."""
import csv
import json
from datetime import datetime,timezone

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from replay_book_outline_side import EXPORT,fit
from replay_may_cross_context import OUT,history,read


def main():
    cases=read(OUT/'context.json')['cases']
    matches=[(c,p) for c in cases for p in c['last_outlines']]
    shape_ids={(p['start'],p['end'],p['known']) for _,p in matches}
    assert len(shape_ids)==1
    start,end,known=shape_ids.pop()
    lines=EXPORT.read_text('utf-16').splitlines()
    h=next(i for i,s in enumerate(lines) if s.startswith('known\tstart\t'))
    rows=[r for r in csv.DictReader(lines[h:],delimiter='\t')
          if (r['start'],r['end'],r['known'])==tuple(map(str,(start,end,known)))]
    assert len(rows)==1 and rows[0]['category']=='4'
    row=rows[0]
    bars=history()
    index={int(b.time.timestamp()):i for i,b in enumerate(bars)}
    points=[(index[int(t)],float(v)) for t,v in (i.split('@') for i in row['original_anchors'].split(';'))]
    a,z=points[0][0],points[-1][0]
    direction=1 if points[1][1]>points[0][1] else -1
    for j,(i,v) in enumerate(points):
        assert v==getattr(bars[i],'low' if (j%2==0)==(direction==1) else 'high')
    g=fit(points,bars[:z+1],False)
    strict=fit(points,bars[:z+1],True)
    def rails(i):
        return g['l']+g['ls']*(i-a),g['u']+g['us']*(i-a)
    for i in range(z+1,len(bars)):
        low,high=rails(i)
        assert low<high
        close=bars[i].close
        if not low<=close<=high:
            break
    clock=int(bars[i].closed_at.timestamp())
    assert clock==int(row['event']) and clock>=known
    seen=[dict(clock=c['clock'],direction=next(q['direction'] for q in read(OUT.parent/'book_frozen_A_20261118/may_replay.json')['cases']
                  if (q['clock'],q['owner'])==(c['clock'],c['owner'])),owner=c['owner'],
               pre_first=any((q['start'],q['end'],q['known'])==(start,end,known) for q in c['first_outlines']))
          for c,p in matches]
    report=dict(anchor_count=len(points),known=datetime.fromtimestamp(known,timezone.utc).isoformat(),
                first_outside=bars[i].closed_at.isoformat(),side='above' if close>high else 'below',close=close,
                upper=high,lower=low,adaptive_fit=g['shape'],strict_fit=strict,book_category=4,
                native_reason=row['reason'],associated_by_time=seen)
    (OUT/'outline.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
    plt.rcParams.update({'font.family':'Microsoft YaHei','axes.unicode_minus':False})
    fig,ax=plt.subplots(figsize=(9.4,4.6),layout='constrained')
    for j in range(a-2,i+4):
        b=bars[j]
        shade='#13796d' if b.close>=b.open else '#aa4b43'
        ax.vlines(j,b.low,b.high,color=shade,lw=1)
        ax.vlines(j,b.open,b.close,color=shade,lw=4)
    ax.plot([j for j,v in points],[v for j,v in points],color='#8c6a30',marker='o',markersize=4,lw=1,label='原指标导出的六个锚点')
    k=next(j for j in range(z,i+1) if int(bars[j].closed_at.timestamp())==known)
    for side in (0,1):
        ax.plot([a,k],[rails(a)[side],rails(k)[side]],color='#397bb0',ls=':',label='轮廓形成段' if side==0 else None)
        ax.plot([k,i],[rails(k)[side],rails(i)[side]],color='#397bb0',label='可知后的原轨' if side==0 else None)
    ax.axvline(k,color='#53616a',lw=1,ls='--',label='轮廓首次可知')
    ax.scatter([i],[close],s=50,facecolors='white',edgecolors='#27292b',zorder=5,label='首次收盘越轨')
    ax.set_title('5 月原始三推轮廓  ·  收盘越轨与反转确认分开复核',loc='left')
    ticks=sorted(set([a,z,k,i]))
    ax.set_xticks(ticks,[bars[j].closed_at.strftime('%m-%d\n%H:%M') for j in ticks],fontsize=9)
    ax.set_xlabel('XAUUSD H1 已记录收盘（UTC，休市空档压缩）')
    ax.set_ylabel('价格')
    ax.legend(loc='upper right',fontsize=8)
    ax.grid(axis='y',alpha=.15)
    ax.spines[['top','right']].set_visible(False)
    fig.savefig(OUT/'五月原三推与收盘越轨.png',dpi=145)
    plt.close(fig)
    print(report)


if __name__=='__main__':
    main()
