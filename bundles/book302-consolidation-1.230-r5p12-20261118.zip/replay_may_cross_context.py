"""Reconstruct range and outline evidence at each rail's own crossing close."""
import csv
import json
from collections import Counter
from datetime import datetime
from fractions import Fraction
from functools import lru_cache

from book_auxiliary import select
from book_pair_recovery import line_at
from book_viewport_structure import inspect_close, stamp
from package_book_outline_side import ROOT, read, sha
from replay_book_outline_side import EXPORT
from test_book_pair_recovery import history
from worker import recognize

OUT=ROOT/'verification/book_cross_context_may_20261118'
IDENTITY=('owner','origin','terminal','direction','pair_known','trend','turning')
FIXED=('id','known','start','kind','low0','high0','fixed_low','fixed_high','rail_subtype')


def main():
    bars=history()
    by_open={stamp(b.time):i for i,b in enumerate(bars)}
    by_close={stamp(b.closed_at):i for i,b in enumerate(bars)}
    outlines=EXPORT.read_text('utf-16').splitlines()
    header=next(i for i,r in enumerate(outlines) if r.startswith('known\tstart\t'))
    pa=[r for r in csv.DictReader(outlines[header:],delimiter='\t') if r.get('category') in ('1','2','3','4')]
    targets=read(ROOT/'verification/book_frozen_A_20261118/may_replay.json')['cases']

    @lru_cache(maxsize=64)
    def book(i):
        return inspect_close(bars[i-511:i+1])

    @lru_cache(maxsize=256)
    def ranges(first,i):
        return recognize(tuple(bars[first:i+1]))[0]

    def rail_matches(pair,role,i,n):
        line=pair[role]
        anchor=line[0 if role=='trend' else 2]
        level=line_at(line,anchor,i,by_open)
        slope=level-line_at(line,anchor,i-1,by_open)
        event=dict(clock=int(bars[i].closed_at.timestamp()),known=int(datetime.fromisoformat(pair['pair_known']).timestamp()),
                   id=pair['owner']+'/'+role,owner_a=pair['origin'][0],owner_b=pair['terminal'][0],
                   state='first_close_break',line=float(level),slope=float(slope))
        data=select(event,bars[i-1],bars[i],ranges(i-n,i-1),ranges(i-n,i))
        hits=[v for v in (data['primary'],*data['alternatives']) if v]
        return {v['range']['id']:dict(shape=v['kind'],frozen=[v['range'].get(k) for k in FIXED],
                                      active=v['range']['active'],close_inside=v['event_close_inside'],
                                      low=v['range']['low'],high=v['range']['high']) for v in hits}

    cases=[]
    for t in targets:
        end=by_close[t['clock']]
        p=next(p for p in book(end)['pairs'] if p['owner']==t['owner'])
        steps={r:by_open[p[r+'_break_bar']] for r in ('trend','turning')}
        first=min(steps.values())
        matches=[q for q in book(first).get('pairs',[]) if all(q[k]==p[k] for k in IDENTITY)]
        first_label=('same_bar' if first==end else 'trend_only' if steps['trend']==first else 'turn_only')
        reproduced=len(matches)==1 and matches[0]['event']==first_label
        links={}
        for n in (256,512):
            refs={r:rail_matches(p,r,i,n) for r,i in steps.items()}
            common={}
            for rid in refs['trend'].keys() & refs['turning'].keys():
                frozen=refs['trend'][rid]['frozen']
                if not reproduced or refs['turning'][rid]['frozen']!=frozen:
                    continue
                continuous=all(bars[i-1].closed_at==bars[i].time and
                               any(v['active'] and [v.get(k) for k in FIXED]==frozen for v in ranges(first-n,i))
                               for i in range(first,end))
                if continuous and (first==end or bars[end-1].closed_at==bars[end].time):
                    common[rid]=refs['trend'][rid]['shape']
            links[n]=dict(rails=refs,continuous=common)
        signs={}
        for role,index in [('trend',0),('turning',2)]:
            delta=Fraction(str(bars[end].close))-line_at(p[role],p[role][index],end,by_open)
            outward=delta*(1 if p['direction']=='down' else -1)
            signs[role]='outside' if outward>0 else 'inside' if outward<0 else 'touch'
        def available(i):
            cutoff=int(bars[i].time.timestamp())
            return [dict(start=int(r['start']),end=int(r['end']),known=int(r['known']),category=int(r['category']),
                         archived_state=int(r['state']) if 0<int(r['event'])<=cutoff else None)
                    for r in pa if p['origin'][0]<=int(r['start'])<int(r['end'])<=p['terminal'][0]
                    and int(r['end'])<=int(r['known'])<=cutoff]
        cases.append(dict(clock=t['clock'],owner=p['owner'],event=p['event'],first=stamp(bars[first].closed_at),
                          span=end-first,reference=t['reference'],identity_reproduced=reproduced,close=bars[end].close,
                          closing_sides=signs,context=links,first_outlines=available(first),last_outlines=available(end),
                          range_sensitivity=links[256]!=links[512]))
    counts=Counter()
    for c in cases:
        counts['pairs']+=1
        counts['both_outside']+=all(s=='outside' for s in c['closing_sides'].values())
        counts['common_range']+=bool(c['context'][512]['continuous'])
        counts['range_sensitivity']+=c['range_sensitivity']
        counts['first_outline']+=bool(c['first_outlines'])
        counts['last_outline']+=bool(c['last_outlines'])
        counts['first_reproduced']+=c['identity_reproduced']
    report=dict(counts=counts,range_warmups=[256,512],archive=sha(EXPORT.read_bytes()),cases=cases)
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'context.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),'utf8')
    print(dict(counts),flush=True)
    for c in cases:
        print(c['clock'],c['span'],c['closing_sides'],c['context'][512]['continuous'],c['reference']['status'])


if __name__=='__main__':
    main()
