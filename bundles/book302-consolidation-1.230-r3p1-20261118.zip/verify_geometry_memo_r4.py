"""Offline equivalence/timing experiment only; never touches live worker files."""
from pathlib import Path
from dataclasses import replace
import json,time,unittest
import worker
from geometry_window_memo import GeometryWindowMemo
from ict_trader import long_geometry,native_triangles,oscillation

B=Path(__file__).parent
V=B/'verification/performance_r3_20261118'
request=worker.parse_request((B/'verification/native_r3/final/request_102923304041429_3600.tsv').read_text('utf-8-sig'))


class MemoIsolation(unittest.TestCase):
    def setUp(self):
        self.calls=[]
        self.config={'threshold':1}
        def compute(bars,**flags):
            self.calls.append((bars,flags))
            return {'geometry':{'anchors':[bars[0].close]},'flags':flags,'config':dict(self.config)}
        self.memo=GeometryWindowMemo(compute,worker.NativeBar,lambda:self.config,max_entries=2)
        self.bars=request['bars'][-24:]

    def test_qualifier_mutation_cannot_poison_reuse(self):
        first=self.memo(self.bars);first['geometry']['anchors'].append(999)
        second=self.memo(self.bars)
        self.assertEqual(second['geometry']['anchors'],[self.bars[0].close])
        second['flags']['compact']='mutated'
        self.assertIs(self.memo(self.bars)['flags']['compact'],False)
        self.assertEqual(len(self.calls),1)

    def test_prior_bar_revision_and_session_policy_invalidate(self):
        self.memo(self.bars)
        changed=[replace(self.bars[0],spread=self.bars[0].spread+.01)]+self.bars[1:]
        self.memo(changed)
        self.memo([replace(self.bars[0],calendar_weekends=False)]+self.bars[1:])
        self.assertEqual(len(self.calls),3)

    def test_flags_and_parameters_invalidate(self):
        self.memo(self.bars)
        self.memo(self.bars,triangle_first=True)
        self.config['threshold']=2
        self.assertEqual(self.memo(self.bars)['config']['threshold'],2)
        self.assertEqual(len(self.calls),3)

    def test_eviction_never_substitutes_other_window(self):
        for n in (24,23,22,24):
            out=self.memo(self.bars[-n:])
            self.assertEqual(out['geometry']['anchors'],[self.bars[-n].close])
        self.assertEqual(len(self.calls),4)
        self.assertLessEqual(len(self.memo.cache),2)

    def test_unknown_bar_subclass_bypasses(self):
        class Unknown(worker.NativeBar):pass
        bar=self.bars[0]
        other=Unknown(bar.time,bar.open,bar.high,bar.low,bar.close,bar.spread,bar.seconds)
        self.memo([other]);self.memo([other])
        self.assertEqual(self.memo.bypasses,2)
        self.assertEqual(len(self.memo.cache),0)


if __name__=='__main__':
    test=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(MemoIsolation))
    assert test.wasSuccessful()
    original=long_geometry.candidate
    memo=GeometryWindowMemo(original,worker.NativeBar,lambda:(long_geometry.PARAMETERS,oscillation.PARAMETERS))
    worker.recognize.cache_clear()
    old_alias=native_triangles.candidate
    start=time.perf_counter()
    try:
        long_geometry.candidate=memo;native_triangles.candidate=memo
        cached=worker.solve(request,lambda msg:print('memo '+msg,flush=True))
    finally:
        long_geometry.candidate=original;native_triangles.candidate=old_alias
    memo_seconds=time.perf_counter()-start
    saved=json.loads((V/'baseline_results.json').read_text('utf8'))
    assert cached==saved,'Full output differs from preserved baseline'
    print('FULL_OUTPUT_EXACT; measuring unprofiled baseline',flush=True)
    worker.recognize.cache_clear()
    start=time.perf_counter()
    direct=worker.solve(request,lambda msg:print('direct '+msg,flush=True))
    direct_seconds=time.perf_counter()-start
    assert direct==cached
    receipt={'passed':True,'full_output_exact':True,'records':len(cached),'memo':memo.metadata(),
             'seconds':{'direct':direct_seconds,'memo':memo_seconds},
             'reduction_fraction':1-memo_seconds/direct_seconds,'unit_checks':test.testsRun,
             'live_deployed':False,
             'scope':'One existing H1 native request, complete output exact. Unprofiled process timings; not whole live model latency or universal speedup. The live worker and bundled research snapshot remain unchanged.'}
    (V/'geometry_memo_acceptance.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf8')
    print(json.dumps(receipt,ensure_ascii=False),flush=True)
