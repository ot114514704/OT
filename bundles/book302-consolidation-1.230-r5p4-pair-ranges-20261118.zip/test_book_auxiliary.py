import copy
import unittest
from datetime import datetime, timezone, timedelta
from dataclasses import replace
from research_cases import NativeBar
from book_auxiliary import select, range_evidence_note

class BookAuxiliaryTests(unittest.TestCase):
    def setUp(self):
        t = datetime(2026,11,9,12,tzinfo=timezone.utc)
        self.prev = NativeBar(t,104,106,103,105,0,3600)
        self.bar = NativeBar(t+timedelta(hours=1),105,106,101,102,0,3600)
        opening = int(self.bar.time.timestamp())
        self.event = dict(id='line',family='GUIDED_TURNING',clock=opening+3600,
                          known=opening-3600,state='closed_bar_cross_observed',
                          line=104,slope=0,owner_a=opening-86400,owner_b=opening-7200)
        self.box = dict(id='box',kind='dense',known=opening-7200,start=opening-18000,
                        end=opening,active=True,low=100.,high=110.,low0=100.,high0=110.,
                        fixed_low=99.,fixed_high=111.,shape='rectangle',status='candidate')
        self.triangle = dict(self.box,id='tri',kind='geometric',shape='converging',low0=98.,high0=113.)
        self.channel = dict(self.box,id='channel',kind='structural',shape='tilted')
        self.before = [self.box,self.triangle,self.channel]
        self.after = [dict(c,end=opening+3600) for c in self.before]
        self.pattern = dict(event_id='line',category=1,trend=1,direction=1,known=opening-3600,
                            event=opening+3600,state=1,start=opening-14400,end=opening-7200)

    def run_case(self, **kwargs):
        return select(kwargs.get('event',self.event),kwargs.get('prev',self.prev),kwargs.get('bar',self.bar),
                      kwargs.get('before',self.before),kwargs.get('after',self.after),kwargs.get('pa',[self.pattern]))

    def test_triangle_preference_keeps_box_and_original_shapes(self):
        old = copy.deepcopy((self.event,self.before,self.after))
        r=self.run_case();self.assertEqual(r['primary']['kind'],'triangle');self.assertEqual(r['box']['range']['id'],'box')
        self.assertEqual((self.event,self.before,self.after),old)
        self.assertFalse(r['trend_override']);self.assertFalse(r['confirmed_reversal'])

    def test_parallel_geometry_with_converging_label(self):
        from book_auxiliary import shape_kind
        c = dict(self.triangle, low0=90., high0=100.)
        self.assertEqual(shape_kind(c), 'channel')
        self.assertEqual(shape_kind(dict(c, high=112.)), 'expanding')

    def test_pa_after_owner_end_is_excluded(self):
        p = dict(self.pattern, start=self.event['owner_b']+1, end=self.event['owner_b']+2)
        self.assertEqual(self.run_case(pa=[p])['pa'], [])

    def test_prior_inside_cannot_bind_line_that_has_left_the_range(self):
        r=self.run_case(event=dict(self.event,line=113,slope=9))
        self.assertIsNone(r['primary'])
        self.assertTrue(all(x['reason']=='穿线当根原线已在盘整外' for x in r['rejected']))

    def test_subtype_preserves_a_native_wedge(self):
        before=dict(self.triangle,rail_subtype='rising_wedge')
        after=dict(self.after[1],rail_subtype='rising_wedge')
        self.assertEqual(self.run_case(before=[before],after=[after])['primary']['kind'],'wedge')
        self.assertIsNone(self.run_case(before=[before],after=[dict(after,rail_subtype='channel')])['primary'])

    def test_old_or_future_snapshot_cannot_supply_current_edge(self):
        for end in (self.event['clock']-3600,self.event['clock']+3600):
            self.assertIsNone(self.run_case(after=[dict(self.after[0],end=end)])['primary'])

    def test_channel_and_box_can_coexist(self):
        r=self.run_case(before=[self.box,self.channel],after=[self.after[0],self.after[2]])
        self.assertEqual(r['primary']['kind'],'channel');self.assertIsNotNone(r['box'])
        self.assertIn('重叠箱体 100.00～110.00，收盘在箱内',range_evidence_note(r))

    def test_nested_boxes_can_disagree_on_the_same_close(self):
        small=dict(self.box,id='small',low=103.,high=108.)
        wide=dict(self.box,id='wide',low=98.,high=112.)
        before=[small,self.box,wide]
        r=self.run_case(before=before,after=[dict(c,end=self.event['clock']) for c in before])
        self.assertEqual(r['primary']['range']['id'],'small')
        self.assertIn('收盘在区外；外层箱体 98.00～112.00，收盘在箱内',range_evidence_note(r))

    def test_offset_wider_box_is_not_an_enclosing_box(self):
        offset=dict(self.box,id='offset',low=101.,high=115.)
        before=[self.box,offset]
        r=self.run_case(before=before,after=[dict(c,end=self.event['clock']) for c in before])
        self.assertNotIn('外层箱体',range_evidence_note(r))

    def test_range_born_on_cross_cannot_backfill(self):
        a=[dict(c,known=self.event['clock']) for c in self.after]
        self.assertIsNone(self.run_case(after=a)['primary'])

    def test_changed_frozen_bounds_rejected(self):
        a=[dict(c,fixed_high=120) for c in self.after]
        self.assertIsNone(self.run_case(after=a)['primary'])

    def test_ended_range_not_revived(self):
        p=[dict(c,active=False) for c in self.before]
        self.assertIsNone(self.run_case(before=p)['primary'])

    def test_far_price_range_not_selected_by_time_alone(self):
        p=[dict(c,low=200.,high=210.) for c in self.before]
        a=[dict(c,low=200.,high=210.) for c in self.after]
        self.assertIsNone(self.run_case(before=p,after=a)['primary'])

    def test_missing_original_line_clock_is_unknown(self):
        self.assertIsNone(self.run_case(event=dict(self.event,known=0))['primary'])

    def test_retrospective_line_is_not_causal(self):
        self.assertIsNone(self.run_case(event=dict(self.event,state='retrospective'))['primary'])

    def test_missing_native_bar_stops_binding(self):
        self.assertIsNone(self.run_case(prev=replace(self.prev,time=self.prev.time-timedelta(hours=1)))['primary'])

    def test_pa_event_id_does_not_prove_wave_membership(self):
        p=dict(self.pattern,start=self.event['owner_a']-7200,end=self.event['owner_a']-3600)
        self.assertEqual(self.run_case(pa=[p])['pa'],[])

    def test_pa_cannot_substitute_A_or_confirm_reversal(self):
        r=self.run_case();self.assertEqual(len(r['pa']),1)
        self.assertFalse(r['pa'][0]['book_A_equivalence']);self.assertFalse(r['pa'][0]['book_scope_membership_verified'])
        self.assertEqual(r['book'],self.event)

    def test_future_pa_lifecycle_is_withheld(self):
        p=dict(self.pattern,event=self.event['clock']+3600,state=2)
        q=self.run_case(pa=[p])['pa'][0]
        self.assertEqual(q['observed_state'],0);self.assertTrue(q['later_state_withheld'])

    def test_future_pa_geometry_not_backfilled(self):
        p=dict(self.pattern,known=self.event['clock']+3600)
        self.assertEqual(self.run_case(pa=[p])['pa'],[])

    def test_duplicate_pa_not_counted_twice(self):
        self.assertEqual(len(self.run_case(pa=[self.pattern,self.pattern])['pa']),1)

    def test_reflection_and_scaling_preserve_selection(self):
        expected=self.run_case()
        for scale,offset in [(-1,20000),(100,0),(.00001,0)]:
            f=lambda x: offset+scale*x
            bar=lambda b:replace(b,open=f(b.open),close=f(b.close),low=min(f(b.low),f(b.high)),high=max(f(b.low),f(b.high)))
            def context(c):
                d=dict(c)
                for a,z in [('low','high'),('low0','high0'),('fixed_low','fixed_high')]:d[a],d[z]=sorted([f(c[a]),f(c[z])])
                return d
            r=self.run_case(event=dict(self.event,line=f(self.event['line']),slope=scale*self.event['slope']),
                            prev=bar(self.prev),bar=bar(self.bar),before=list(map(context,self.before)),after=list(map(context,self.after)))
            self.assertEqual(r['primary']['range']['id'],expected['primary']['range']['id'])
            self.assertEqual(r['box']['range']['id'],expected['box']['range']['id'])

if __name__=='__main__':unittest.main()
