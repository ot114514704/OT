param([string]$TerminalDataPath = '', [string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'
$packageRoot = $PSScriptRoot
if (-not $ProjectRoot) {
    try {
        $runtime = Invoke-RestMethod -Uri 'http://127.0.0.1:8773/api/runtime' -TimeoutSec 3
        if ($runtime.service -eq 'ipda_consolidation' -and (Test-Path -LiteralPath (Join-Path $runtime.project_root 'app.py'))) {
            $ProjectRoot = $runtime.project_root
        }
    } catch { }
}
if (-not $ProjectRoot) { $ProjectRoot = Join-Path $packageRoot 'engine' }
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'app.py'))) { throw 'Invalid engine directory.' }
if (-not $TerminalDataPath) {
    $terminalRoot = Join-Path $env:APPDATA 'MetaQuotes\Terminal'
    $candidates = @(Get-ChildItem -LiteralPath $terminalRoot -Directory | Where-Object {
        (Test-Path -LiteralPath (Join-Path $_.FullName 'MQL5')) -and (Test-Path -LiteralPath (Join-Path $_.FullName 'origin.txt'))
    })
    if ($candidates.Count -ne 1) { throw 'Multiple or no MT5 terminals found. Run Install.ps1 -TerminalDataPath with the data folder shown by MT5 File > Open Data Folder.' }
    $TerminalDataPath = $candidates[0].FullName
}
$TerminalDataPath = (Resolve-Path -LiteralPath $TerminalDataPath).Path
if (-not (Test-Path -LiteralPath (Join-Path $TerminalDataPath 'MQL5'))) { throw 'The target must be an MT5 data directory containing MQL5.' }
$targetDir = Join-Path $TerminalDataPath 'MQL5\Indicators\IPDA_Research'
$bridgeDir = Join-Path $TerminalDataPath 'MQL5\Files\IPDA_Consolidation'
$backupDir = Join-Path $ProjectRoot ('work\indicator_backups\' + (Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
New-Item -ItemType Directory -Path $targetDir,$bridgeDir,$backupDir -Force | Out-Null
foreach ($name in @('IPDA_Consolidation.mq5','IPDA_Consolidation.ex5')) {
    $from = Join-Path $packageRoot ('indicator\' + $name)
    $target = Join-Path $targetDir $name
    if (Test-Path -LiteralPath $target) { Copy-Item -LiteralPath $target -Destination $backupDir }
    Copy-Item -LiteralPath $from -Destination $target -Force
    if ((Get-FileHash -LiteralPath $from).Hash -ne (Get-FileHash -LiteralPath $target).Hash) { throw 'Indicator copy verification failed.' }
}
$utf8 = New-Object System.Text.UTF8Encoding($false)
$settingsDir = Join-Path $ProjectRoot 'mt5'
New-Item -ItemType Directory -Path $settingsDir -Force | Out-Null
$settingsPath = Join-Path $settingsDir 'bridge_settings.json'
if (Test-Path -LiteralPath $settingsPath) { Copy-Item -LiteralPath $settingsPath -Destination $backupDir }
[IO.File]::WriteAllText($settingsPath,(@{ enabled = $true; files_directory = $bridgeDir } | ConvertTo-Json),$utf8)
[IO.File]::WriteAllText((Join-Path $packageRoot 'installation.json'),(@{ project_root = $ProjectRoot; terminal_data = $TerminalDataPath; backup = $backupDir } | ConvertTo-Json),$utf8)
Write-Output ('Installed indicator 1.05: ' + $targetDir)
Write-Output ('Engine: ' + $ProjectRoot)
Write-Output 'Next: run Start.ps1, then refresh MT5 Navigator and attach IPDA_Research/IPDA_Consolidation to XAUUSD H1 or M15. Replace an old instance instead of attaching duplicates.'
