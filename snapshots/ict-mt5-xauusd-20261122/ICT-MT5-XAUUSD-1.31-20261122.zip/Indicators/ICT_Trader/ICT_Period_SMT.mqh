// Compare native, closed MT5 bars on their common broker timestamps.
// Indices address consecutive matched bars within a segment, never chart pixels.
struct MatchedBar {
   datetime stamp;
   double goldHigh,goldLow,peerHigh,peerLow;
};

string tfName(){return StringSubstr(EnumToString(_Period),7);}

datetime periodEnd(datetime t){
   if(_Period!=PERIOD_MN1) return t+PeriodSeconds(_Period);
   MqlDateTime d;TimeToStruct(t,d);
   d.day=1;d.mon++;
   if(d.mon==13){d.mon=1;d.year++;}
   return StructToTime(d);
}

bool consecutive(datetime a,datetime b){
   datetime next=periodEnd(a);
   if(b==next) return true;
   if(_Period!=PERIOD_D1) return false;
   MqlDateTime d;TimeToStruct(a,d);
   return d.day_of_week==5 && b==a+3*86400;
}

double extreme(const MatchedBar &b,bool peer,bool high){
   if(peer) return high?b.peerHigh:b.peerLow;
   return high?b.goldHigh:b.goldLow;
}

bool isPivot(const MatchedBar &rows[],int c,bool peer,bool high,int radius){
   double center=extreme(rows[c],peer,high);
   bool approach=false;
   for(int k=c-radius;k<=c+radius;k++){
      if(k==c) continue;
      double other=extreme(rows[k],peer,high);
      if((high?other>center:other<center) || (k>c && other==center)) return false;
      if(k<c && other!=center) approach=true;
   }
   return approach;
}

void appendSmt(Mark &out[],string kind,datetime a,datetime b,double p,double q,string label){
   int n=ArraySize(out);
   ArrayResize(out,n+1,256);
   out[n].kind=kind;out[n].start=a;out[n].finish=b;out[n].first=p;out[n].last=q;out[n].label=label;
}

void scanSwings(const MatchedBar &rows[],int first,int end,bool high,bool inverse,Mark &out[]){
   const int radius=4;
   int oldGold=-1,oldPeer=-1,gold=-1,peer=-1;
   string market=inverse?"美元指数":"白银";
   for(int c=first+radius;c+radius<end;c++){
      if(c-gold>2) gold=-1;
      if(c-peer>2) peer=-1;
      if(isPivot(rows,c,false,high,radius)) gold=c;
      if(isPivot(rows,c,true,high,radius)) peer=c;
      if(gold<0 || peer<0) continue;
      int a=oldGold,b=oldPeer;
      oldGold=gold;oldPeer=peer;gold=-1;peer=-1;
      if(a<0 || oldGold-a>48 || rows[a].stamp<D'2026.09.01 07:00') continue;
      double p=extreme(rows[a],false,high),q=extreme(rows[oldGold],false,high);
      double u=extreme(rows[b],true,high),v=extreme(rows[oldPeer],true,high);
      if((q-p)*(v-u)>=0) continue;
      bool goldLed=high?q>p:q<p;
      string g=high?"高":"低",s=inverse?(high?"低":"高"):g;
      string title=(high?"↓ 看跌":"↑ 看涨")+" SMT "+tfName()+" · "+market;
      string desc=goldLed?"黄金破前"+g+"，"+market+"未破前"+s:market+"破前"+s+"，黄金未破前"+g;
      int event=ArraySize(out);
      appendSmt(out,high?"smt_down":"smt_up",rows[a].stamp,rows[oldGold].stamp,p,q,title+"｜"+desc+
                " · 确认 "+easternTime(periodEnd(rows[c+radius].stamp))+" 美东");
      bool caught=false;
      for(int k=c+radius+1;k<end;k++){
         double value=extreme(rows[k],goldLed,high),level=goldLed?u:p;
         if(high?value<=level:value>=level) continue;
         double price=extreme(rows[k],false,high);
         string follow=(goldLed?market:"黄金")+"补破前"+(goldLed?s:g)+" · "+easternTime(periodEnd(rows[k].stamp))+" 美东";
         out[event].label+=" · "+follow;
         caught=true;
         break;
      }
      if(!caught) out[event].label+=" · 连续对齐行情内未观察到补破";
   }
}

// Match the actual weekly-path vertex to its native bar. Require uninterrupted
// coverage around each vertex separately; the two days can span a session break.
int pathWindow(const MatchedBar &rows[],int n,const Mark &m,bool high,double &peer){
   int lo=0,hi=n;
   while(lo<hi){
      int mid=(lo+hi)/2;
      if(rows[mid].stamp<=m.start) lo=mid+1;else hi=mid;
   }
   int c=lo-1;
   if(c<2 || c+2>=n || m.start>=periodEnd(rows[c].stamp) ||
      MathAbs(extreme(rows[c],false,high)-m.first)>_Point/2) return -1;
   // Keep the last bar of a flat high/low, then wait for two closed bars.
   while(c+1<n && consecutive(rows[c].stamp,rows[c+1].stamp) &&
         extreme(rows[c+1],false,high)==m.first) c++;
   if(c+2>=n) return -1;
   for(int j=c-1;j<=c+2;j++) if(!consecutive(rows[j-1].stamp,rows[j].stamp)) return -1;
   if(!isPivot(rows,c,false,high,2)) return -1;
   peer=extreme(rows[c-2],true,high);
   for(int j=c-1;j<=c+2;j++){
      double v=extreme(rows[j],true,high);
      peer=high?MathMax(v,peer):MathMin(v,peer);
   }
   return c;
}

void scanPath(const MatchedBar &rows[],int n,bool inverse,Mark &out[]){
   int prior[2]={-1,-1};
   for(int i=0;i<ArraySize(marks);i++){
      Mark m=marks[i];
      if(m.kind=="week"){prior[0]=-1;prior[1]=-1;continue;}
      bool high=m.kind=="week_high";
      if(!high && m.kind!="week_low") continue;
      int side=high?1:0,prev=prior[side];prior[side]=i;
      if(prev<0) continue;
      Mark ref=marks[prev];
      if(m.start-ref.start>4*86400 || ref.label=="形成中") continue;
      double before,after;
      int a=pathWindow(rows,n,ref,high,before),b=pathWindow(rows,n,m,high,after);
      if(a<0 || b<=a+4 || ref.finish>periodEnd(rows[b+2].stamp)) continue;
      bool goldBreak=high?m.first>ref.first:m.first<ref.first;
      bool peerBreak=high?after>before:after<before;
      if(goldBreak==peerBreak) continue;
      string market=inverse?"美元指数":"白银",field=high?"高":"低";
      string other=inverse?(high?"低":"高"):field;
      int digits=(int)SymbolInfoInteger(inverse?"USIDX":"XAGUSD",SYMBOL_DIGITS);
      string label="周折线"+field+"点 · "+tfName()+" · "+m.label+"\n黄金 "+
         DoubleToString(ref.first,_Digits)+" → "+DoubleToString(m.first,_Digits)+(goldBreak?" 破前":" 未破前")+field+
         "\n"+market+" "+DoubleToString(MathAbs(before),digits)+" → "+DoubleToString(MathAbs(after),digits)+
         (peerBreak?" 窗口内破前":" 窗口内未破前")+other+
         "\n摆动确认 "+easternTime(periodEnd(rows[b+2].stamp))+" 美东";
      // Follow the lagging market from confirmation until the first missing bar.
      bool caught=false;
      for(int k=b+3;k<n && consecutive(rows[k-1].stamp,rows[k].stamp);k++){
         double value=extreme(rows[k],goldBreak,high),level=goldBreak?before:ref.first;
         if(high?value<=level:value>=level) continue;
         label+="\n"+(goldBreak?market:"黄金")+"补破 · "+easternTime(periodEnd(rows[k].stamp))+" 美东";
         caught=true;break;
      }
      if(!caught) label+="\n连续对齐行情内未观察到补破";
      appendSmt(out,high?"major_down":"major_up",rows[a].stamp,rows[b].stamp,ref.first,m.first,label);
   }
}

int peerSmt(const MqlRates &gold[],string symbol,bool inverse,datetime since,datetime now,Mark &out[]){
   if(!SymbolSelect(symbol,true)) return -1;
   MqlRates quotes[];
   int n=CopyRates(symbol,_Period,since,now,quotes);
   if(n<=0) return -1;
   MatchedBar rows[];
   int i=0,j=0,count=0,start=0;
   ArrayResize(rows,MathMin(ArraySize(gold),n));
   while(i<ArraySize(gold) && j<n){
      datetime t=gold[i].time;
      if(t<quotes[j].time){i++;continue;}
      if(t>quotes[j].time){j++;continue;}
      if(periodEnd(t)>now) break;
      if(count>0 && !consecutive(rows[count-1].stamp,t)){
         scanSwings(rows,start,count,false,inverse,out);scanSwings(rows,start,count,true,inverse,out);
         start=count;
      }
      rows[count].stamp=t;rows[count].goldHigh=gold[i].high;rows[count].goldLow=gold[i].low;
      rows[count].peerHigh=inverse?-quotes[j].low:quotes[j].high;
      rows[count].peerLow=inverse?-quotes[j].high:quotes[j].low;
      count++;i++;j++;
   }
   scanSwings(rows,start,count,false,inverse,out);scanSwings(rows,start,count,true,inverse,out);
   scanPath(rows,count,inverse,out);
   return count;
}

Mark periodSignals[];
string smtStatus="";
long loadedState[9];

bool readPeriodSmt(bool force=false){
   if(!showSMT) return false;
   string symbols[3]={"XAUUSD","XAGUSD","USIDX"};
   long state[9]; bool same=true;
   for(int i=0;i<3;i++){
      if(!SymbolSelect(symbols[i],true)) return false;
      state[3*i]=SeriesInfoInteger(symbols[i],_Period,SERIES_LASTBAR_DATE);
      state[3*i+1]=SeriesInfoInteger(symbols[i],_Period,SERIES_FIRSTDATE);
      state[3*i+2]=SeriesInfoInteger(symbols[i],_Period,SERIES_BARS_COUNT);
   }
   datetime now=TimeTradeServer();
   for(int i=0;i<3;i++) if(state[3*i]>0 && periodEnd((datetime)state[3*i])<=now) state[3*i]*=-1;
   for(int i=0;i<9;i++) if(state[i]!=loadedState[i]) same=false;
   if(!force && same && StringLen(smtStatus)>0 && StringFind(smtStatus,"同步中")<0) return false;
   MqlRates gold[];Mark fresh[];
   datetime start=D'2026.08.24';
   // Respect the terminal's available-history limit, including on minute charts.
   int capacity=(int)TerminalInfoInteger(TERMINAL_MAXBARS);
   if(capacity>1 && iBars(_Symbol,_Period)>=capacity){
      datetime oldest=iTime(_Symbol,_Period,capacity-1);
      if(oldest>start) start=oldest;
   }
   int n=CopyRates(_Symbol,_Period,start,now,gold);
   int silver=n>0?peerSmt(gold,"XAGUSD",false,start,now,fresh):-1;
   int index=n>0?peerSmt(gold,"USIDX",true,start,now,fresh):-1;
   string status=(silver<0?"白银同步中":"白银 "+IntegerToString(silver)+" 根")+
                 " · "+(index<0?"美元指数同步中":"美元指数 "+IntegerToString(index)+" 根");
   if(n<=0 || (silver<0 && index<0)){
      bool changed=status!=smtStatus;smtStatus=status;return changed;
   }
   ArraySwap(periodSignals,fresh);ArrayCopy(loadedState,state);smtStatus=status;
   return true;
}
