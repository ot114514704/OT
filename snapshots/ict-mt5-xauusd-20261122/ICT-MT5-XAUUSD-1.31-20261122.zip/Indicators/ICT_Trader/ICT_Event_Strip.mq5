#property version "1.00"
#property indicator_separate_window
#property indicator_height 58
#property indicator_minimum 0
#property indicator_maximum 1
#property indicator_plots 0

struct Release {datetime at;string tag,details;int priority;};
Release events[];
string title="ICT 美元经济日历",prefix="ICT_NEWS_",source="";
datetime refreshAt=0,observedBar=0;

void addEvent(Release &list[],datetime at,string tag,string details,int priority){
   for(int i=0;i<ArraySize(list);i++) if(list[i].at==at){
      if(StringFind(list[i].details,details)<0) list[i].details+="\n"+details;
      if(priority>list[i].priority){list[i].tag=tag;list[i].priority=priority;}
      return;
   }
   int n=ArraySize(list);ArrayResize(list,n+1,64);
   list[n].at=at;list[n].tag=tag;list[n].details=details;list[n].priority=priority;
}

int schedule(Release &list[]){
   int f=FileOpen("ICT_Trader\\H1Profiles.tsv",FILE_READ|FILE_CSV|FILE_UNICODE|FILE_COMMON|FILE_SHARE_READ|FILE_SHARE_WRITE,'\t');
   if(f==INVALID_HANDLE) return 0;
   FileReadString(f);int n=(int)StringToInteger(FileReadString(f)),added=0;
   for(int i=0;i<n && !FileIsEnding(f);i++){
      string kind=FileReadString(f),at=FileReadString(f);
      FileReadString(f);FileReadString(f);FileReadString(f);string caption=FileReadString(f);
      if(kind=="calendar"){addEvent(list,StringToTime(at),caption,"BLS 排期 · "+caption,2);added++;}
   }
   FileClose(f);return added;
}

void load(){
   datetime now=TimeTradeServer();
   MqlCalendarValue values[];Release fresh[];
   int total=CalendarValueHistory(values,D'2026.09.01',now+7*86400,"US","USD"),accepted=0;
   for(int i=0;i<total;i++){
      MqlCalendarEvent e;
      if(!CalendarEventById(values[i].event_id,e) || e.time_mode!=CALENDAR_TIMEMODE_DATETIME) continue;
      string id=e.event_code;StringToLower(id);
      string tag=e.name;int priority=1;
      if(StringFind(id,"nonfarm-payroll")>=0 && StringFind(id,"adp")<0){tag="非农 NFP";priority=4;}
      else if(StringFind(id,"cpi")>=0 || StringFind(id,"consumer-price-index")>=0){tag="CPI";priority=4;}
      else if(StringFind(id,"fomc")>=0 || StringFind(id,"fed-interest-rate")>=0){tag="FOMC";priority=4;}
      else if(StringFind(id,"producer-price-index")>=0 || StringFind(id,"ppi-")>=0){tag="PPI";priority=3;}
      if(priority==1 && e.importance!=CALENDAR_IMPORTANCE_HIGH) continue;
      addEvent(fresh,values[i].time,tag,"MT5 · "+e.name,priority);accepted++;
   }
   int official=schedule(fresh);
   if(total>=0 || ArraySize(events)==0){
      ArraySwap(events,fresh);
      source=accepted>0?"MT5 美元经济日历":official>0?"BLS 公布排期":"日历暂无可用记录";
   }else if(StringFind(source,"缓存")<0) source+="（缓存）";
   PrintFormat("ICT calendar: MT5=%d, included=%d, BLS=%d, times=%d",total,accepted,official,ArraySize(events));
   refreshAt=now+(accepted>0?900:180);
}

string reaction(datetime at,datetime now){
   if(now<at) return "待公布";
   if((long)at%300!=0) return "核对发布时间";
   MqlRates pre[],post[];
   if(CopyRates(_Symbol,PERIOD_M5,at-1800,at-1,pre)!=6) return "报价待核";
   double high=pre[0].high,low=pre[0].low;
   for(int j=0;j<6;j++){
      if(pre[j].time!=at-1800+300*j) return "报价待核";
      high=MathMax(high,pre[j].high);low=MathMin(low,pre[j].low);
   }
   int expected=(int)MathMin(6,(now-at)/300);
   if(expected<=0) return "观察中";
   if(CopyRates(_Symbol,PERIOD_M5,at,at+300*expected-1,post)!=expected) return "报价待核";
   bool above=false,below=false,buy=false,sell=false;
   for(int j=0;j<expected;j++){
      if(post[j].time!=at+300*j) return "报价待核";
      above|=post[j].high>high && post[j].low<=high;
      below|=post[j].low<low && post[j].high>=low;
      buy|=above && post[j].close<high;sell|=below && post[j].close>low;
   }
   if(buy && sell) return "双向清扫";
   if(buy || sell) return buy?"扫买方":"扫卖方";
   return expected<6?"观察中":"未见扫回";
}

void label(int wnd,string key,int x,int y,string caption,string tip,color ink){
   string name=prefix+key;
   ObjectCreate(0,name,OBJ_LABEL,wnd,0,0);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,name,OBJPROP_COLOR,ink);ObjectSetInteger(0,name,OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,name,OBJPROP_TEXT,caption);
   ObjectSetString(0,name,OBJPROP_TOOLTIP,tip);
}

void paint(){
   int wnd=ChartWindowFind();
   if(wnd<1) return;
   ObjectsDeleteAll(0,prefix,wnd);
   int w=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS);
   int bins[];ArrayResize(bins,w/165+2);ArrayInitialize(bins,-1);
   Release groups[];
   double price=ChartGetDouble(0,CHART_PRICE_MAX,0);
   for(int i=0;i<ArraySize(events);i++){
      int x,y;
      if(!ChartTimePriceToXY(0,0,events[i].at,price,x,y) || x<0 || x>=w) continue;
      int bin=x/165,k=bins[bin];
      string when=TimeToString(events[i].at,TIME_DATE|TIME_MINUTES)+" 服务器";
      string state=reaction(events[i].at,TimeTradeServer());
      string head=events[i].tag;
      if(StringLen(head)>12) head=StringSubstr(head,0,12)+"…";
      string tip=when+"\n"+events[i].details+"\n波动注入观察 · "+state+"（公布前后各30分钟 M5）";
      if(k<0){
         k=ArraySize(groups);ArrayResize(groups,k+1);bins[bin]=k;groups[k]=events[i];
         groups[k].tag=head+" · 注入观察 · "+state;groups[k].details=tip;
      }else{groups[k].details+="\n"+tip;if(StringFind(groups[k].tag,"＋")<0) groups[k].tag+=" ＋";}
      label(wnd,"t"+IntegerToString(i),x,10,"│",tip,clrGoldenrod);
   }
   for(int i=0;i<ArraySize(groups);i++){
      int x,y;
      if(ChartTimePriceToXY(0,0,groups[i].at,price,x,y))
         label(wnd,"n"+IntegerToString(i),MathMax(0,MathMin(x,w-165)),30,groups[i].tag,groups[i].details,clrWheat);
   }
   if(ArraySize(groups)==0)
      label(wnd,"status",8,28,source+" · 当前视窗无已列事件","按美国重要经济事件和已核对的 BLS 排期显示",clrSilver);
   ChartRedraw();
}
int OnInit(){IndicatorSetString(INDICATOR_SHORTNAME,title);EventSetTimer(5);return INIT_SUCCEEDED;}
void OnTimer(){
   bool changed=TimeTradeServer()>=refreshAt;
   if(changed) load();
   datetime bar=iTime(_Symbol,PERIOD_M5,0);
   if(changed || bar!=observedBar){observedBar=bar;paint();}
}
void OnChartEvent(const int id,const long &l,const double &d,const string &s){if(id==CHARTEVENT_CHART_CHANGE) paint();}
int OnCalculate(const int n,const int prev,const datetime &t[],const double &o[],const double &hi[],const double &lo[],
                const double &c[],const long &v[],const long &real[],const int &spread[]){return n;}
void OnDeinit(const int reason){EventKillTimer();ObjectsDeleteAll(0,prefix);}
