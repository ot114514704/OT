﻿// Price-path candidates. IPDA ipda_ranges.py supplies body balance; phase-two
// structural_ranges.py supplies independent edge visits. The course AMD clip
// (52–229 and 280–365 s) distinguishes A→M→D from a direct A→D expansion.
Mark amdStages[];
bool showAMD=true;
datetime amdBar=0;
int amdHistory=0;

double quantile(const double &sorted[],double fraction){
   double p=(ArraySize(sorted)-1)*fraction;int i=(int)p;
   return sorted[i]+(sorted[MathMin(i+1,ArraySize(sorted)-1)]-sorted[i])*(p-i);
}

bool accumulation(const MqlRates &r[],int end,int n,double &bottom,double &top,double &wickLow,double &wickHigh){
   int first=end-n+1;
   double upper[],lower[],tr[];
   ArrayResize(upper,n);ArrayResize(lower,n);ArrayResize(tr,n);
   wickHigh=r[first].high;wickLow=r[first].low;
   double travel=0,overlap=0;
   for(int j=0;j<n;j++){
      int k=first+j;
      upper[j]=MathMax(r[k].open,r[k].close);lower[j]=MathMin(r[k].open,r[k].close);
      wickHigh=MathMax(wickHigh,r[k].high);wickLow=MathMin(wickLow,r[k].low);
      tr[j]=r[k].high-r[k].low;
      if(!j) continue;
      travel+=MathAbs(r[k].close-r[k-1].close);
      overlap+=MathMax(0.,MathMin(r[k].high,r[k-1].high)-MathMax(r[k].low,r[k-1].low))/
               MathMax(_Point,MathMin(tr[j],r[k-1].high-r[k-1].low));
      tr[j]=MathMax(tr[j],MathMax(MathAbs(r[k].high-r[k-1].close),MathAbs(r[k].low-r[k-1].close)));
   }
   if(travel<=0 || MathAbs(r[end].close-r[first].close)>.30*travel || overlap<.50*(n-1)) return false;
   ArraySort(upper);ArraySort(lower);ArraySort(tr);
   top=quantile(upper,.9);bottom=quantile(lower,.1);
   double atr=quantile(tr,.5),width=top-bottom,mid=(top+bottom)/2;
   if(atr<=0 || width<=0 || width>5.5*atr) return false;
   int occupied=0,upVisits=0,downVisits=0,cross=0,last=0;bool up=true,down=true;
   for(int k=first;k<=end;k++){
      double bh=MathMax(r[k].open,r[k].close),bl=MathMin(r[k].open,r[k].close);
      if(bh<=top+.1*atr && bl>=bottom-.1*atr) occupied++;
      int side=r[k].close>mid?1:(r[k].close<mid?-1:0);
      if(side!=0){if(last && last!=side) cross++;last=side;}
      bool touchU=r[k].high>=wickHigh-.2*(wickHigh-wickLow);
      bool touchL=r[k].low<=wickLow+.2*(wickHigh-wickLow);
      if(touchU && touchL) continue;
      if(touchU && up){upVisits++;up=false;}
      if(touchL && down){downVisits++;down=false;}
      if(!touchU && side<=0) up=true;
      if(!touchL && side>=0) down=true;
   }
   return occupied>=.8*n && cross>=4 && upVisits>=2 && downVisits>=2 &&
          r[end].close>=bottom && r[end].close<=top;
}

// Shared morphology with ict_ai/amd.py: confirmed pivots, common observed
// span, price coverage and compactness. Freeze recent confirmed pivots for M/D.
string amdSwingShape(const MqlRates &r[],int end,int n,double &low,double &high){
   int first=end-n+1,h0=-1,h1=-1,l0=-1,l1=-1;
   for(int i=first+1;i<end;i++){
      if(r[i].high>r[i-1].high && r[i].high>=r[i+1].high){h0=h1;h1=i;}
      if(r[i].low<r[i-1].low && r[i].low<=r[i+1].low){l0=l1;l1=i;}
   }
   if(h0<0 || l0<0 || h0==l0 || h0==l1 || h1==l0 || h1==l1 || end-MathMax(h1,l1)>3 || MathMin(h0,l0)-first>n/3) return "";
   low=r[l1].low;high=r[h1].high;
   if(low>=high) return "";
   for(int i=h1+1;i<=end;i++) if(r[i].high>high) return "";
   for(int i=l1+1;i<=end;i++) if(r[i].low<low) return "";
   int left=MathMax(h0,l0),right=MathMin(h1,l1);
   if(right-left<2) return "";
   double us=(r[h1].high-r[h0].high)/(h1-h0),ls=(r[l1].low-r[l0].low)/(l1-l0);
   double width=r[h0].high+(left-h0)*us-(r[l0].low+(left-l0)*ls);
   double du=us*(right-left),dl=ls*(right-left),last=width+du-dl;
   double spans[];ArrayResize(spans,n);
   for(int i=first;i<=end;i++) spans[i-first]=r[i].high-r[i].low;
   ArraySort(spans);double scale=quantile(spans,.5),tol=.15*scale;
   if(MathMin(width,last)<=0 || scale<=0) return "";
   int wick=0,closes=0;
   for(int i=left;i<=right;i++){
      double hi=r[h0].high+(i-h0)*us,lo=r[l0].low+(i-l0)*ls;
      if(r[i].high<=hi+tol && r[i].low>=lo-tol) wick++;
      if(r[i].close<=hi+tol && r[i].close>=lo-tol) closes++;
   }
   if(wick<.8*(right-left+1) || closes<.9*(right-left+1)) return "";
   double motion=MathMax(MathAbs(du),MathAbs(dl)),flat=MathMin(tol,.05*motion);
   bool narrowing=last<width*(1-1e-10);
   if(narrowing && MathAbs(du)<=flat && dl>0) return "上升三角";
   if(narrowing && MathAbs(dl)<=flat && du<0) return "下降三角";
   if(du<0 && dl>0) return "对称三角";
   if(du*dl>0 && MathAbs(du-dl)<=.20*motion && MathAbs(last-width)<=.10*width){
      if(MathMax(width,last)<=3*scale) return du>0?"上行密集通道":"下行密集通道";
      return "";
   }
   if(narrowing && du*dl>0) return du>0?"上升楔形":"下降楔形";
   return "";
}

void amdMark(string kind,datetime a,datetime z,double low,double high,string reason){
   appendSmt(amdStages,kind,a,z,low,high,reason+" · "+tfName()+" · "+easternTime(z)+" 美东收线可知");
   amdStages[ArraySize(amdStages)-1].invalidAt=0;
}

void retireCandidate(int accumulationIndex,int manipulationIndex,int confirmedA,datetime known){
   if(accumulationIndex>=0 && accumulationIndex!=confirmedA) amdStages[accumulationIndex].invalidAt=known;
   if(manipulationIndex>=0) amdStages[manipulationIndex].invalidAt=known;
}

void deliveryTarget(int idx,const MqlRates &r[],int formation,int dStart,int confirmed,bool up,double edge){
   // Prior NY day/week only. Choose the nearest untouched directional level at
   // A confirmation, before inspecting M or D. Never roll it to a later target.
   datetime known=periodEnd(r[formation].time);
   double selected=0;string source="";
   for(int k=0;k<2;k++){
      string kind=k==0?"day":"week";int ref=-1;
      for(int j=0;j<ArraySize(marks);j++)
         if(marks[j].kind==kind && marks[j].finish<=known && (ref<0 || marks[j].finish>marks[ref].finish)) ref=j;
      if(ref<0) continue;
      MqlRates prev[];int n=CopyRates(_Symbol,PERIOD_M5,marks[ref].start,marks[ref].finish-1,prev);
      if(n<=0 || prev[0].time!=marks[ref].start) continue;
      double level=up?prev[0].high:prev[0].low;
      for(int j=1;j<n;j++) level=up?MathMax(level,prev[j].high):MathMin(level,prev[j].low);
      if(up?level<=edge:level>=edge) continue;
      MqlRates between[];int obs=0;
      if(known>marks[ref].finish) obs=CopyRates(_Symbol,PERIOD_M5,marks[ref].finish,known-1,between);
      if(obs<0) continue;
      bool taken=false;
      for(int j=0;j<obs && !taken;j++) taken=up?between[j].high>=level:between[j].low<=level;
      if(!taken && (selected==0 || MathAbs(level-edge)<MathAbs(selected-edge))){
         selected=level;source=(k==0?"前日":"前周")+(up?"高（买方）":"低（卖方）");
      }
   }
   amdStages[idx].dol=selected;
   if(selected==0){amdStages[idx].label+="\nA 收线时未找到可核的前日/前周方向目标";return;}
   amdStages[idx].label+="\nA 收线时冻结 DOL 候选 · "+source+" "+DoubleToString(selected,_Digits);
   for(int j=formation+1;j<=confirmed;j++) if(up?r[j].high>=selected:r[j].low<=selected){
      amdStages[idx].dolHit=periodEnd(r[j].time);
      amdStages[idx].label+=(j<dStart?" · D 段前已触":" · D 段内已触");break;
   }
}

void trimDelivery(const MqlRates &bars[]){
   // The frozen A edge is a path invalidation level. The visible delivery
   // ends at its last directional extreme, which can precede invalidation.
   for(int s=0;s+1<ArraySize(amdStages);s++){
      Mark stage=amdStages[s];
      if(stage.kind!="D" || amdStages[s+1].kind!="D_confirm") continue;
      bool up=StringFind(stage.label,"向上")>=0;
      int l=0,r=ArraySize(bars);
      while(l<r){int mid=(l+r)/2;if(bars[mid].time<stage.start) l=mid+1;else r=mid;}
      if(l==ArraySize(bars)) continue;
      int last=l;double high=bars[l].high,low=bars[l].low;
      double extreme=up?high:low;
      for(int j=l+1;j<ArraySize(bars) && bars[j].time<stage.finish;j++){
         bool extends=up?bars[j].high>extreme:bars[j].low<extreme;
         if(extends){last=j;extreme=up?bars[j].high:bars[j].low;}
         if(stage.dolHit>stage.start && periodEnd(bars[j].time)>=stage.dolHit) break;
         if(j<l+2 || periodEnd(bars[j].time)<=amdStages[s+1].finish) continue;
         bool reverse=up?(bars[j].close<bars[j-1].low && bars[j-1].close<bars[j-2].close):
                         (bars[j].close>bars[j-1].high && bars[j-1].close>bars[j-2].close);
         if(reverse) break;
      }
      for(int j=l+1;j<=last;j++){high=MathMax(high,bars[j].high);low=MathMin(low,bars[j].low);}
      amdStages[s].first=low;amdStages[s].last=high;amdStages[s].finish=periodEnd(bars[last].time);
      if(stage.dolHit>amdStages[s].finish){
         amdStages[s].dolHit=0;StringReplace(amdStages[s].label," · D 段内已触","");
      }
      amdStages[s].label+="\n最后顺向极值 "+DoubleToString(extreme,_Digits)+" · "+easternTime(bars[last].time)+" 美东";
   }
}

bool refreshAMD(){
   if(!showAMD) return false;
   datetime now=TimeTradeServer(),last=iTime(_Symbol,_Period,0);
   int bars=iBars(_Symbol,_Period);
   datetime key=periodEnd(last)<=now?-last:last;
   if(amdBar==key && bars==amdHistory) return false;
   MqlRates r[];
   int shift=iBarShift(_Symbol,_Period,D'2026.08.24'),cap=(int)TerminalInfoInteger(TERMINAL_MAXBARS);
   int n=CopyRates(_Symbol,_Period,0,MathMin(cap,shift<0?bars:shift+1),r);
   if(n<1) return false;
   ArrayResize(amdStages,0);
   int segment=0,formed=-1,side=0,exc=-1,reclaim=-1,run=0;
   int delivery=-1,direction=0,activeA=-1,activeM=-1,confirmedA=-1,expires=-1;
   bool direct=false;
   double brokenEdge=0;
   double low=0,high=0,bottom=0,top=0,ext=0,typicalBody=0;
   for(int i=0;i<n && periodEnd(r[i].time)<=now;i++){
      if(i && !consecutive(r[i-1].time,r[i].time)){
         if(formed>=0) retireCandidate(activeA,activeM,confirmedA,r[i].time);
         formed=-1;delivery=-1;activeM=-1;direct=false;segment=i;
      }
      if(delivery>=0){
         if(amdStages[delivery].dol>0 && !amdStages[delivery].dolHit &&
            (direction>0?r[i].high>=amdStages[delivery].dol:r[i].low<=amdStages[delivery].dol) &&
            direction*(r[i].close-brokenEdge)>0){
            amdStages[delivery].dolHit=periodEnd(r[i].time);amdStages[delivery].label+=" · D 段内已触";
         }
         if(direction*(r[i].close-brokenEdge)<=0){
            if(direct && formed>=0){
               amdStages[delivery].label+="\n直接扩张结束，收回冻结边界 · "+easternTime(periodEnd(r[i].time))+" 美东";
               side=0;exc=-1;reclaim=-1;run=0;expires=i+24;
               // A re-entry alone does not assign a manipulation side. The
               // next fresh excursion must independently demonstrate a reclaim.
               if(r[i].close>=low && r[i].close<=high){direct=false;delivery=-1;continue;}
            }
            direct=false;delivery=-1;
         }
         else{
            amdStages[delivery].finish=periodEnd(r[i].time);
            amdStages[delivery].first=MathMin(amdStages[delivery].first,r[i].low);
            amdStages[delivery].last=MathMax(amdStages[delivery].last,r[i].high);
            if(direct) continue;
         }
      }
      if(formed>=0 && i>expires){
         retireCandidate(activeA,activeM,confirmedA,periodEnd(r[i].time));
         formed=-1;activeM=-1;segment=i;
      }
      if(formed<0){
         int chosen=0;string shape="";
         for(int window=24;window>=8;window-=4){
            if(window!=24 && window!=16 && window!=12 && window!=8) continue;
            if(i-segment+1<window || r[i-window+1].time<D'2026.09.01 07:00') continue;
            shape=amdSwingShape(r,i,window,low,high);
            if(shape!=""){
               bottom=MathMin(r[i].open,r[i].close);top=MathMax(r[i].open,r[i].close);
               for(int k=i-window+1;k<i;k++){
                  bottom=MathMin(bottom,MathMin(r[k].open,r[k].close));top=MathMax(top,MathMax(r[k].open,r[k].close));
               }
               chosen=window;break;
            }
            if((window==12 || window==24) && accumulation(r,i,window,bottom,top,low,high)){
               chosen=window;shape="箱形平衡";break;
            }
         }
         if(!chosen) continue;
         double bodies[];ArrayResize(bodies,chosen);
         for(int k=0;k<chosen;k++) bodies[k]=MathAbs(r[i-k].close-r[i-k].open);
         ArraySort(bodies);typicalBody=MathMax(_Point,quantile(bodies,.5));
         formed=i;expires=i+24;activeM=-1;side=0;exc=-1;reclaim=-1;run=0;
         double boxLow=low,boxHigh=high;
         for(int k=i-chosen+1;k<=i;k++){boxLow=MathMin(boxLow,r[k].low);boxHigh=MathMax(boxHigh,r[k].high);}
         amdMark("A",r[i-chosen+1].time,periodEnd(r[i].time),boxLow,boxHigh,
                 "A 积累候选 · "+shape+" · 冻结扫荡边界 "+DoubleToString(low,_Digits)+"–"+DoubleToString(high,_Digits));
         activeA=ArraySize(amdStages)-1;
         continue;
      }
      if(activeM>=0) amdStages[activeM].watchEnd=periodEnd(r[i].time);
      if(r[i].high>high && r[i].low<low){
         retireCandidate(activeA,activeM,confirmedA,periodEnd(r[i].time));
         formed=-1;activeM=-1;segment=i+1;continue;
      }
      if(reclaim>=0){
         if(side==1?r[i].high>ext:r[i].low<ext){
            retireCandidate(activeA,activeM,confirmedA,periodEnd(r[i].time));
            formed=-1;segment=i+1;continue;
         }
         bool outside=side==1?r[i].close<low:r[i].close>high;
         run=outside?run+1:0;
         if(run>=2){
            // Require a directional body at least as large as the median in frozen A.
            // Two drifting closes outside the edge alone do not confirm displacement.
            double body1=-side*(r[i-1].close-r[i-1].open),body2=-side*(r[i].close-r[i].open);
            if(MathMax(body1,body2)<typicalBody) continue;
            double dLow=r[reclaim].low,dHigh=r[reclaim].high;
            for(int j=reclaim+1;j<=i;j++){dLow=MathMin(dLow,r[j].low);dHigh=MathMax(dHigh,r[j].high);}
            amdMark("D",r[reclaim].time,periodEnd(r[i].time),dLow,dHigh,
                    (side==1?"D 向下派发候选":"D 向上派发候选")+" · 连续两根收在对侧外，顺向实体达到 A 段实体中位数 "+
                    DoubleToString(typicalBody,_Digits)+" · 框回溯至 M 收回棒");
            delivery=ArraySize(amdStages)-1;direction=-side;brokenEdge=direction>0?high:low;
            confirmedA=activeA;
            amdStages[delivery].protectedPrice=ext;
            amdStages[delivery].originKnown=periodEnd(r[reclaim].time);
            amdStages[delivery].aKnown=periodEnd(r[formed].time);
            deliveryTarget(delivery,r,formed,reclaim,i,direction>0,brokenEdge);
            amdMark("D_confirm",r[i].time,periodEnd(r[i].time),r[i].close,r[i].close,
                    direction>0?"向上派发确认 · 对侧连续收线且出现顺向位移":"向下派发确认 · 对侧连续收线且出现顺向位移");
            formed=-1;segment=i+1;
         }
         continue;
      }
      int crossed=r[i].high>high?1:r[i].low<low?-1:0;
      if(!side && crossed){side=crossed;exc=i;ext=side==1?r[i].high:r[i].low;}
      if(!side) continue;
      if(crossed && crossed!=side){
         retireCandidate(activeA,activeM,confirmedA,periodEnd(r[i].time));
         formed=-1;segment=i+1;continue;
      }
      ext=side==1?MathMax(ext,r[i].high):MathMin(ext,r[i].low);
      if(r[i].close>=low && r[i].close<=high){
         reclaim=i;run=0;
         double mLow=r[exc].low,mHigh=r[exc].high;
         for(int j=exc+1;j<=i;j++){mLow=MathMin(mLow,r[j].low);mHigh=MathMax(mHigh,r[j].high);}
         // A later sweep can reuse the frozen range after direct delivery.
         // Keep the A box that was already displayed with that confirmed D.
         if(activeA!=confirmedA) amdStages[activeA].finish=periodEnd(r[exc].time);
         amdMark("M",r[exc].time,periodEnd(r[i].time),mLow,mHigh,
                 (side==1?"M 操纵候选 · 扫上沿买方流动性 ":"M 操纵候选 · 扫下沿卖方流动性 ")+
                 DoubleToString(side==1?high:low,_Digits)+" · 最远越界 "+DoubleToString(side==1?ext-high:low-ext,_Digits)+
                 (r[i].close>=bottom && r[i].close<=top?" · 收回积累实体区":" · 收回影线区间，未回到实体区"));
         activeM=ArraySize(amdStages)-1;
         amdStages[activeM].originKnown=periodEnd(r[i].time);
         amdStages[activeM].aKnown=periodEnd(r[formed].time);
         amdStages[activeM].watchEnd=periodEnd(r[i].time);
         amdStages[activeM].protectedPrice=ext;
         deliveryTarget(activeM,r,formed,i,i,side<0,side<0?high:low);
      }else{
         bool outside=side==1?r[i].close>high:r[i].close<low;
         run=outside?run+1:0;
         if(run>=2){
            amdMark("D",r[i-1].time,periodEnd(r[i].time),MathMin(r[i].low,r[i-1].low),MathMax(r[i].high,r[i-1].high),
                    (side>0?"D 向上直接扩张候选":"D 向下直接扩张候选")+" · A→D，未观察到 M");
            delivery=ArraySize(amdStages)-1;direction=side;brokenEdge=direction>0?high:low;
            confirmedA=activeA;
            amdStages[delivery].protectedPrice=0;
            amdStages[delivery].originKnown=periodEnd(r[formed].time);
            amdStages[delivery].aKnown=amdStages[delivery].originKnown;
            deliveryTarget(delivery,r,formed,i-1,i,direction>0,brokenEdge);
            amdMark("D_confirm",r[i].time,periodEnd(r[i].time),r[i].close,r[i].close,
                    direction>0?"向上直接扩张确认":"向下直接扩张确认");
            direct=true;
         }
      }
   }
   trimDelivery(r);amdBar=key;amdHistory=bars;return true;
}

struct PhaseHit {int l,r,t,b,labelX,labelY,labelWidth;string tip;};
PhaseHit phaseHits[];
void amdHoverAt(int x,int y,string &key,string &body){
   for(int i=ArraySize(phaseHits)-1;i>=0;i--){
      PhaseHit p=phaseHits[i];
      bool title=x>=p.labelX && x<=p.labelX+p.labelWidth && y>=p.labelY-17 && y<=p.labelY;
      bool edge=x>=p.l-3 && x<=p.r+3 && y>=p.t-3 && y<=p.b+3 &&
                (MathAbs(x-p.l)<=3 || MathAbs(x-p.r)<=3 || MathAbs(y-p.t)<=3 || MathAbs(y-p.b)<=3);
      if(title || edge){key="amd"+IntegerToString(i);body=p.tip;return;}
   }
}
void drawAMD(int w,int h){
   ObjectsDeleteAll(0,prefix+"AMD_");
   ArrayResize(phaseHits,0);
   if(!showAMD) return;
   int left=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
   datetime start=iTime(_Symbol,_Period,left);
   datetime finish=periodEnd(iTime(_Symbol,_Period,MathMax(0,left-(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS)-1)));
   for(int i=0;i<ArraySize(amdStages);i++){
      Mark m=amdStages[i];if(m.invalidAt || m.finish<start || m.start>finish) continue;
      color ink=m.kind=="A"?clrLightSteelBlue:m.kind=="M"?clrOrchid:clrPaleGreen;
      string name=prefix+"AMD_"+IntegerToString(i),text=m.kind=="A"?"A 积累":m.kind=="M"?"M 操纵":"D 派发";
      if(m.kind=="D_confirm"){
         ObjectCreate(0,name,OBJ_ARROW,0,m.start,m.first);
         ObjectSetInteger(0,name,OBJPROP_ARROWCODE,159);ObjectSetInteger(0,name,OBJPROP_COLOR,clrGold);
         ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
         int dx,dy;
         if(ChartTimePriceToXY(0,0,m.start,m.first,dx,dy)) detailHit(dx-4,dy-4,dx+4,dy+4,m.label,4);
         continue;
      }
      if(m.kind=="D"){
         bool up=StringFind(m.label,"向上")>=0;
         ink=up?clrAquamarine:clrLightSalmon;
         text=(up?"D ↑ ":"D ↓ ")+(StringFind(m.label,"直接扩张")>=0?"直接扩张":"派发");
         int x1,y1,x2,y2;
         if(ChartTimePriceToXY(0,0,m.start,m.last,x1,y1) && ChartTimePriceToXY(0,0,m.finish,m.first,x2,y2)){
            uint wash=ColorToARGB(ink,49);
            for(int row=MathMax(0,y1);row<=MathMin(h-1,y2);row++)
               for(int col=MathMax(0,x1);col<=MathMin(w-1,x2);col++){
                  int p=row*w+col;pixels[p]=sourceOver(wash,pixels[p]);
               }
         }
      }
      ObjectCreate(0,name,OBJ_RECTANGLE,0,m.start,m.first,m.finish,m.last);
      ObjectSetInteger(0,name,OBJPROP_FILL,false);ObjectSetInteger(0,name,OBJPROP_COLOR,ink);
      ObjectSetInteger(0,name,OBJPROP_STYLE,m.kind=="D"?STYLE_SOLID:STYLE_DOT);
      ObjectSetInteger(0,name,OBJPROP_WIDTH,m.kind=="D"?2:1);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
      string tip=m.label;
      if(m.kind=="D"){
         if(m.dol>0) tip+=m.dolHit?"\nDOL 已触 · "+easternTime(m.dolHit)+" 美东":"\n截至本段观察结束，DOL 未触";
         for(int j=0;j<ArraySize(events);j++) if(events[j].stageStart==m.start && events[j].stageKnown==m.originKnown)
            tip+="\n"+events[j].tag+" · "+events[j].assessment;
      }
      ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
      priceText(name+"_t",(datetime)MathMax(start,m.start),m.last,text,ink,true);
      if(m.kind=="D") ObjectSetInteger(0,name+"_t",OBJPROP_FONTSIZE,10);
      int l,r,t,b,lx,ly;
      if(ChartTimePriceToXY(0,0,m.start,m.last,l,t) && ChartTimePriceToXY(0,0,m.finish,m.first,r,b) &&
         ChartTimePriceToXY(0,0,(datetime)MathMax(start,m.start),m.last,lx,ly)){
         int n=ArraySize(phaseHits);ArrayResize(phaseHits,n+1,32);
         phaseHits[n].l=l;phaseHits[n].r=r;phaseHits[n].t=t;phaseHits[n].b=b;
         phaseHits[n].labelX=lx;phaseHits[n].labelY=ly;phaseHits[n].labelWidth=textWidth(text)+6;phaseHits[n].tip=tip;
      }
   }
}
