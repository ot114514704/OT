"""Prospective DOL checkpoints and subsequent observed XAU price contacts."""
from bisect import bisect_left
from datetime import datetime, timedelta, timezone
import hashlib
import json
import sqlite3

from .dol_outlook import M5, outlook
from .po3 import po3_zones
from .profile_lifecycle import _day_bounds, daily_profile_lifecycle
from .timebase import NY, session_windows


def week_start(day):
    return day+timedelta(days=1) if day.weekday()==6 else day-timedelta(days=day.weekday())


def batch_id(at, price, targets):
    raw=json.dumps([at.isoformat(),price,targets],sort_keys=True,separators=(',',':'))
    return hashlib.sha256(raw.encode()).hexdigest()


def chart_receipts(directory, now):
    # Logs are appended by MT5 in UTC, including across the midnight boundary.
    if not directory.is_dir():
        return {}
    received={}
    for path in sorted(directory.glob('????.??.??.tsv')):
        try:
            lines=path.read_bytes().decode('utf-8').splitlines(keepends=True)
        except PermissionError:
            continue  # MT5 is appending; the next poll will read the durable record.
        for line in lines:
            fields=line.rstrip().split('\t')
            if not line.endswith('\n') or len(fields)!=2:continue
            key,epoch=fields
            if len(key)!=64 or not epoch.isascii() or not epoch.isdigit() or len(epoch)>10:continue
            stamp=datetime.fromtimestamp(int(epoch),timezone.utc)
            if stamp<=now and (key not in received or stamp<received[key]):
                received[key]=stamp
    return received


def live_reviews(path, at, now, price, targets, bars, receipts):
    """Stage the exact ranks. Only chart-acknowledged batches enter forward reviews."""
    path.parent.mkdir(parents=True, exist_ok=True)
    db=sqlite3.connect(path, timeout=5)
    try:
        with db:
            db.execute("CREATE TABLE IF NOT EXISTS chart_batches(id TEXT PRIMARY KEY, cutoff TEXT, received TEXT, payload TEXT NOT NULL)")
            db.execute("CREATE INDEX IF NOT EXISTS batch_cutoff ON chart_batches(cutoff)")
            db.execute("CREATE TABLE IF NOT EXISTS chart_reviews(scope TEXT, stamp TEXT, body TEXT, PRIMARY KEY(scope,stamp))")
            day=(at-M5).astimezone(NY).date()
            active=timedelta(0)<=now-at<2*M5 and day.weekday()!=5
            if active:
                payload=json.dumps(dict(at=at.isoformat(),price=price,targets=targets),ensure_ascii=False)
                db.execute("INSERT OR IGNORE INTO chart_batches VALUES (?,?,NULL,?)",(batch_id(at,price,targets),at.isoformat(),payload))
            for key,cut in db.execute("SELECT id,cutoff FROM chart_batches WHERE received IS NULL").fetchall():
                ack=receipts.get(key)
                if ack is not None and datetime.fromisoformat(cut)<=ack<=now:
                    db.execute("UPDATE chart_batches SET received=? WHERE id=?",(ack.isoformat(),key))
            # Re-evaluate the current and previous trading week across weekend/restart.
            monday=week_start(day)-timedelta(days=8)
            floor=_day_bounds(monday)[0]
            history=[]
            for raw,stamp in db.execute("SELECT payload,received FROM chart_batches WHERE cutoff>=? AND received IS NOT NULL ORDER BY received,cutoff,id",(floor.isoformat(),)):
                snapshot=json.loads(raw)
                received=datetime.fromisoformat(stamp)
                if received-datetime.fromisoformat(snapshot['at'])>=2*M5:
                    continue
                snapshot['published_at']=stamp
                history.append(snapshot)
            seen=set()
            for snapshot in history:
                key_day=(datetime.fromisoformat(snapshot['at'])-M5).astimezone(NY).date()
                unique=[]
                for item in snapshot['targets']:
                    key=(key_day,item['side'],item['lo'],item['hi'],item['source'])
                    if key not in seen:
                        unique.append(item)
                        seen.add(key)
                snapshot['targets']=unique
            summaries,_=settle(history,bars,now)
            db.executemany("INSERT OR REPLACE INTO chart_reviews VALUES (?,?,?)",
                           [(s,d,json.dumps(v,ensure_ascii=False)) for (s,d),v in summaries.items()])
            return {(s,d):json.loads(v) for s,d,v in db.execute("SELECT scope,stamp,body FROM chart_reviews")}
    finally:
        db.close()


def forecast(m5, h1, m15, at, peers, news, judas):
    day=(at-M5).astimezone(NY).date()
    reopening=day.weekday()==6
    if reopening:
        day+=timedelta(days=1)  # Sunday reopening is the lead-in to Monday's NY profile.
    a,z=session_windows(day)['asia']
    start=min(a,_day_bounds(day-timedelta(days=day.weekday()))[0])
    if reopening:
        start=min(start,_day_bounds(day-timedelta(days=1))[0]+timedelta(hours=18))
    core=[b for b in m5 if start<=b.time and b.time+M5<=at]
    quarters=[b for b in m15 if start<=b.time and b.time+3*M5<=at]
    profile=daily_profile_lifecycle(quarters,day,at,reference_m5=core,include_reconstruction=False)
    phases=po3_zones(quarters,a,z,_day_bounds(day)[1],at)
    ranked=[]
    rows=outlook(m5,h1,quarters,at,profile,phases,peers,releases=news,judas=judas,ranked=ranked)
    return rows,ranked


def settle(snapshots,bars,as_of):
    times=[b.time for b in bars]
    summaries={}
    stats={}
    for snap in snapshots:
        at=datetime.fromisoformat(snap['at'])
        published=datetime.fromisoformat(snap.get('published_at',snap['at']))
        day=(at-M5).astimezone(NY).date()
        monday=week_start(day)
        day_end=_day_bounds(day)[1]
        week_end=_day_bounds(monday+timedelta(days=4))[1]
        first=bisect_left(times,max(at,published))
        future=bars[first:bisect_left(times,min(as_of,week_end))]
        first_touches=[]
        for p in snap['targets']:
            side,lo,hi=p['side'],p['lo'],p['hi']
            levels=[lo if side==1 else hi]
            if hi!=lo:levels.extend([(hi+lo)/2,hi if side==1 else lo])
            hits=[]
            for level in levels:
                touch=next((b for b in future if b.time+M5<=as_of and b.low<=level<=b.high),None)
                hits.append((touch.time+M5) if touch else None)
            hit=hits[0]
            first_touches.append(hit)
            p['touches']=[t.isoformat() if t else None for t in hits]
            for scope,key,end in [('day',day,day_end),('week',monday,week_end)]:
                done=hit is not None and hit<=end
                p[scope]='observed_hit' if done else 'no_observed_hit' if as_of>=end else 'open'
                if not done:continue
                group=summaries.setdefault((scope,str(key)),{})
                identity=(side,lo,hi,p['source'])
                if identity in group:continue
                when=hit.astimezone(NY)
                clock=(f'{published.astimezone(NY):%m-%d %H:%M:%S} 图表收到（依据 {at.astimezone(NY):%H:%M}）'
                       if 'published_at' in snap else f'{at.astimezone(NY):%m-%d %H:%M} 列出')
                detail=f'{clock} #{p["rank"]} {p["score"]}分 · {p["source"]} {lo:.2f}'
                if hi!=lo:detail+=f'–{hi:.2f}'
                detail+=f' → {when:%m-%d %H:%M} M5 已见触达；{p["reason"]}'
                if hi!=lo:
                    for tag,t in zip(('中点','远端'),hits[1:]):
                        detail+=f'；{tag} '+(t.astimezone(NY).strftime('%m-%d %H:%M') if t and t<=end else '期内未见')
                group[identity]=detail
            stop=min(at+timedelta(hours=4),day_end)
            if as_of>=stop:
                bucket=str(p['score']//10*10)
                counts=stats.setdefault(bucket,{'listed':0,'hit_within_horizon':0})
                counts['listed']+=1
                counts['hit_within_horizon']+=int(hit is not None and hit<=stop)
        timed=[t for t in first_touches if t and t<=min(day_end,at+timedelta(hours=4))]
        snap['first_ranks']=[p['rank'] for p,t in zip(snap['targets'],first_touches) if timed and t==min(timed)]
    return {k:[v for v in rows.values()] for k,rows in summaries.items()},stats
