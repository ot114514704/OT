"""Shape definitions read from timed HD frames, cross-checked with prior PPT/DOC.

The frames are visual samples, not an assertion of full audio/frame review.
Source illustrations do not establish predictive accuracy or trading approval.
"""
from copy import deepcopy


DAILY={
 'classic_buy':('趋势',750,'零点后逆偏见运行 → 伦敦候选反转 → 纽约扩张'),
 'classic_sell_mirror':('趋势',750,'经典买入日的卖出镜像，镜像需独立验证'),
 'classic_reversal_variant':('反转',810,'伦敦未完成反转 → 纽约形成候选极点 → 扩张'),
 'consolidation_expansion':('趋势',930,'范围内盘整 → 新闻后直接扩张'),
 'news_manipulation_expansion':('趋势',1050,'新闻前盘整 → 逆偏见突破并回收 → 反向扩张'),
 'double_sweep':('反转',1110,'早期顺偏见推进 → 纽约反向扫荡 → 恢复扩张'),
 'manipulation_expansion_consolidation':('盘整',1230,'伦敦反转并扩张 → 纽约无跟随、转为盘整'),
 'seek_destroy':('盘整',1350,'伦敦双向扫亚洲 → 纽约双向扫伦敦 → 缺少持续扩张'),
}
WEEKLY={
 'weekly_tuesday_extreme':('趋势',930,'周一参考范围 → 周二逆向越界反转 → 周三周四扩张'),
 'weekly_wednesday_extreme':('反转',1110,'周二仍逆偏见运行 → 周三越界反转 → 周四周五扩张'),
 'weekly_wednesday_double_sweep':('反转',1230,'周二先顺偏见推进 → 周三反向扫周初范围 → 周四周五扩张'),
 'weekly_thursday_consolidation_reversal':('趋势',1350,'周一至周三盘整 → 周四越界形成候选极点 → 周五反向扩张，回收可延后'),
 'weekly_consolidation_expansion':('趋势',1410,'周初范围盘整 → 周四可开始扩张 → 观察周五跟随，极点日期不固定'),
 'weekly_seek_destroy':('盘整',1470,'多次双向运动 → 周实体小、上下影长 → 缺乏持续扩张'),
}
SOURCE_HASHES={
 'daily':'fde8650d20a79632c10bac8031ec6c280376e8339e01b179a46bc823f629c934',
 'weekly':'ea7519ddafd5e67579f6d722f9810267444d306aa23b1d50b94d0abc4e658870',
}
WEEKLY_TRANSCRIPT_INTERVALS={
 'weekly_tuesday_extreme':[902,1067],
 'weekly_wednesday_extreme':[1067,1171],
 'weekly_wednesday_double_sweep':[1171,1298],
 'weekly_thursday_consolidation_reversal':[1298,1378],
 'weekly_consolidation_expansion':[1378,1430],
 'weekly_seek_destroy':[1430,1477],
}


def profile_source(ident,weekly=False):
    row=(WEEKLY if weekly else DAILY).get(ident)
    if not row:return None
    family,seconds,sequence=row
    result={'author':'交易员无畏','source_key':'time3_weekly' if weekly else 'time2_daily',
            'source_sha256':SOURCE_HASHES['weekly' if weekly else 'daily'],
            'frame_seconds':seconds,'category':family,'sequence':sequence,
            'visual_frame_reviewed':True,'full_audio_review_complete':False,
            'full_asr_draft_read':True,
            'review_scope':'full_local_ASR_draft_read_and_sampled_HD_illustrations_crosschecked_with_PPT_DOC'}
    if weekly:result['transcript_interval_seconds']=WEEKLY_TRANSCRIPT_INTERVALS[ident].copy()
    return result


def profile_catalog():
    return deepcopy({'daily':{k:profile_source(k) for k in DAILY},
                     'weekly':{k:profile_source(k,True) for k in WEEKLY}})
