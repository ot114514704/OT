"""Causal range-relative liquidity *price proxies*, not observed stop orders.

Trader Wuwei's foundations video at 238.84–305 seconds and bias-intro
video at 259.4–308.5 / 374.2–394 seconds
distinguish range edges/outside price references from smaller internal swings
and internal imbalances. The previous complete NY research day/week is an
explicit engineering reference; it is not the course's only dealing range.
Range identity and relation availability are frozen before observations begin.
"""
from __future__ import annotations

from bisect import bisect_left, bisect_right
from copy import deepcopy
from datetime import date, datetime, time, timedelta, timezone
import hashlib

from .features import geometric_fvgs
from .liquidity import closed_day_references
from .timebase import NY


M15 = timedelta(minutes=15)
M5 = timedelta(minutes=5)
SOURCE_REFS = [
    {'source': 'ICT交易基础教学：底层逻辑、高阻力低阻力流动性、高质量PD阵列、外内部流动性、SMT、CE、交付状态改变市场结构、折扣溢价.mp4',
     'author': '交易员无畏', 'start_seconds': 238.84, 'end_seconds': 305,
     'topic': 'external edges, internal smaller swings and FVG; reference range required'},
    {'source': 'ICT基础入门教学｜建立你的偏见，摆脱乱交易！.mp4',
     'author': '交易员无畏', 'seconds': [[259.4, 308.5], [374.2, 394.0]],
     'topic': 'paired range anchors; enclosed swings and inefficiencies may both be IRL'},
]


def _local(day, hour):
    return datetime.combine(day, time(hour), NY).astimezone(timezone.utc)


def _day_end(day):
    return _local(day, 17) if day.weekday() == 4 else _local(day + timedelta(days=1), 0)


def _m5_reference_day(bars, day, as_of):
    """Audit observed M5 coverage under the explicitly assumed TMGM study hours."""
    start = _local(day, 0)
    end = _local(day, 16) + timedelta(minutes=55) if day.weekday() == 4 else _day_end(day)
    actual = {b.time: b for b in bars if start <= b.time < end and b.time + M5 <= as_of}
    expected = []
    stamp = start
    while stamp < end:
        if _research_open(stamp):
            expected.append(stamp)
        stamp += M5
    missing = [stamp for stamp in expected if stamp not in actual]
    status = 'complete' if as_of >= end and expected and not missing else 'incomplete'
    return {'date': day.isoformat(), 'status': status, 'missing_bars': len(missing),
            'expected_bars': len(expected), 'observed_bars': len(actual),
            'available_at': end.isoformat(), 'start': start, 'end': end,
            'bars': [actual[stamp] for stamp in expected if stamp in actual]}


def _research_open(stamp):
    local = stamp.astimezone(NY)
    weekday, hour = local.weekday(), local.hour
    if weekday == 5 or (weekday == 6 and hour < 18):
        return False
    if weekday == 4:
        return (hour, local.minute) < (16, 55)
    return not (weekday < 4 and hour == 17)


def _key(*parts):
    return hashlib.sha256('|'.join(str(x) for x in parts).encode('utf-8')).hexdigest()[:24]


class _Coverage:
    """Prefix counts make coverage checks independent of the number of pools."""
    def __init__(self, start, cutoff, bars, period):
        self.period = period
        self.cutoff = cutoff
        self.expected = []
        stamp = start
        while stamp + period <= cutoff:
            if _research_open(stamp):
                self.expected.append(stamp)
            stamp += period
        quotes = {b.time for b in bars}
        self.missing = [0]
        for stamp in self.expected:
            self.missing.append(self.missing[-1] + int(stamp not in quotes))
        seconds = int(period.total_seconds())
        floor = datetime.fromtimestamp(int(cutoff.timestamp()) // seconds * seconds, timezone.utc)
        self.partial_open_bar = floor < cutoff and _research_open(floor)

    def gap(self, start, end):
        lo = bisect_left(self.expected, start)
        hi = bisect_right(self.expected, end - self.period)
        return hi > lo and self.missing[hi] != self.missing[lo]

    def complete(self, available):
        return not self.gap(available, self.cutoff) and not self.partial_open_bar


def _swings(bars, period):
    """Strict radius-one pivots; confirmation is the right bar's CLOSE."""
    points = []
    for left, anchor, right in zip(bars, bars[1:], bars[2:]):
        if left.time + period != anchor.time or anchor.time + period != right.time:
            continue
        if anchor.high > left.high and anchor.high > right.high:
            points.append((anchor, 'buy_side_proxy', anchor.high, right.time + period))
        if anchor.low < left.low and anchor.low < right.low:
            points.append((anchor, 'sell_side_proxy', anchor.low, right.time + period))
    return points


def _pool_state(pool, bars, stamps, period, coverage):
    # Reclassification into a later range must preserve the already observable
    # life of a confirmed pivot; it must not resurrect a visited price proxy.
    available = datetime.fromisoformat(pool['level_available_at'])
    buy = pool['side'] == 'buy_side_proxy'
    price = pool['price']
    touch = excursion = reclaim = None
    pending_excursion = False
    previous = None
    for bar in bars[bisect_left(stamps, available):]:
        if previous is not None and coverage.gap(previous.time + period, bar.time):
            pending_excursion = False
        known = (bar.time + period).isoformat()
        if touch is None and bar.low <= price <= bar.high:
            touch = known
        outside = bar.high > price if buy else bar.low < price
        if outside:
            if excursion is None:
                excursion = known
            pending_excursion = True
        if reclaim is None and pending_excursion and (bar.close < price if buy else bar.close > price):
            reclaim = known
        previous = bar
        if touch and excursion and reclaim:
            break
    complete = coverage.complete(available)
    pool.update(observed_touch=touch is not None, first_touch_known_at=touch,
                observed_excursion=excursion is not None, first_excursion_known_at=excursion,
                reclaim_known_at=reclaim, coverage_complete=complete,
                # A bar entirely beyond the level proves excursion, but a
                # gap across it cannot prove that the actual level traded.
                untouched=False if touch else True if complete and not excursion else None,
                actual_stop_orders_observed=False, selected_as_dol=False,
                observation_basis='Closed M15 OHLC; touch requires price inside wick range; '
                                  'excursion requires strict breach; reclaim is observed close back across level',
                order_exhaustion_confirmed=False)


def _array_state(array, bars, stamps, period, coverage):
    available = datetime.fromisoformat(array['formation_available_at'])
    lower, upper = array['lower'], array['upper']
    midpoint = (lower + upper) / 2
    bullish = array['direction'] == 'bullish'
    touch = ce = mitigation = invalidation = None
    for bar in bars[bisect_left(stamps, available):]:
        known = (bar.time + period).isoformat()
        if touch is None and bar.low <= upper and bar.high >= lower:
            touch = known
        if ce is None and bar.low <= midpoint <= bar.high:
            ce = known
        far_edge = lower if bullish else upper
        if mitigation is None and bar.low <= far_edge <= bar.high:
            mitigation = known
        if invalidation is None and (bar.close < lower if bullish else bar.close > upper):
            invalidation = known
        if touch and ce and mitigation and invalidation:
            break
    complete = coverage.complete(available)
    array.update(ce=midpoint, observed_touch=touch is not None,
                 first_touch_known_at=touch, ce_known_at=ce,
                 full_mitigation_known_at=mitigation, invalidation_known_at=invalidation,
                 observed_full_wick_mitigation=mitigation is not None,
                 observed_close_invalidation=invalidation is not None,
                 coverage_complete=complete,
                 untouched=False if touch else True if complete and not invalidation else None,
                 full_mitigation_basis='Observed far-edge price contact, not proof every price in the gap traded')


def range_liquidity_map(bars, dates, as_of, period=M15, reference_bars=None):
    """Return a day/week map using only bars CLOSED by the clamped cutoff.

    ``dates`` is one weekday or an ordered Monday–Friday list. Daily maps use
    the previous weekday (Monday uses Friday); weekly maps use all five days
    of the preceding week. Every reference day must pass quote completeness.
    ``coverage_complete`` is conditional on the stated research closure model,
    and is false when the cutoff contains an unobserved forming candle.
    """
    if period != M15:
        raise ValueError('This research map requires fixed M15 bars')
    if as_of.tzinfo is None or as_of.utcoffset() is None:
        raise ValueError('Timezone-aware cutoff required')
    if any(b.time.tzinfo is None or b.time.utcoffset() is None for b in bars):
        raise ValueError('Timezone-aware bar times required')
    if any(a.time >= b.time for a, b in zip(bars, bars[1:])):
        raise ValueError('Unique chronological bars required')
    if reference_bars is not None:
        if any(b.time.tzinfo is None or b.time.utcoffset() is None for b in reference_bars):
            raise ValueError('Timezone-aware M5 reference bar times required')
        if any(a.time >= b.time for a, b in zip(reference_bars, reference_bars[1:])):
            raise ValueError('Unique chronological M5 reference bars required')
    if not dates or any(not isinstance(d, date) or isinstance(d, datetime) for d in dates):
        raise ValueError('Research dates must be date objects')
    if len(dates) == 1 and dates[0].weekday() < 5:
        timeframe = 'D1'
        previous = dates[0] - timedelta(days=3 if dates[0].weekday() == 0 else 1)
        reference_dates = [previous]
    elif len(dates) == 5 and dates[0].weekday() == 0 and all(d == dates[0] + timedelta(days=i) for i, d in enumerate(dates)):
        timeframe = 'W1'
        reference_dates = [d - timedelta(days=7) for d in dates]
    else:
        raise ValueError('One weekday or ordered Monday–Friday dates required')
    cutoff = min(as_of.astimezone(timezone.utc), _day_end(dates[-1]))
    start, end = _local(reference_dates[0], 0), _day_end(reference_dates[-1])
    closed = [b for b in bars if start <= b.time and b.time + period <= cutoff]
    result = {
        'status': 'insufficient_reference', 'as_of': cutoff.isoformat(), 'range': None,
        'pools': [], 'arrays': [], 'analysis_timeframe': 'M15',
        'view_dates': [d.isoformat() for d in dates],
        'qualified_range': False, 'execution_allowed': False, 'orders_sent': 0,
        'historical_clock_verified': False, 'session_calendar_verified': False,
        'actual_stop_orders_observed': False,
        'source_refs': deepcopy(SOURCE_REFS),
        'engineering_choices': [
            'Previous complete NY research day/week, not the unique source-defined dealing range',
            ('Weekday study closure 17:00–18:00 NY; observed Friday M5 last bar 16:50 '
             'and study close 16:55; Sunday resumes 18:00'
             if reference_bars is not None else
             'Weekday study closure 17:00–18:00 NY; Friday M15 close assumed 17:00; Sunday resumes 18:00'),
            'Strict confirmed M15 swing radius 1; no tolerance-based equal-high/low aggregation',
            'Classification is relative to a frozen reference range; later ranges are new relation versions',
            'No claims about stop-order quantity, exhaustion, institutional intent or predictive probability',
        ],
        'reference_checks': [],
    }
    references = ([_m5_reference_day(reference_bars, d, cutoff) for d in reference_dates]
                  if reference_bars is not None else
                  [closed_day_references(closed, d, period, cutoff) for d in reference_dates])
    result['reference_checks'] = [{'date': item['date'], 'status': item['status'],
                                   'missing_bars': item.get('missing_bars', 0),
                                   'source_period_minutes': 5 if reference_bars is not None else 15}
                                  for item in references]
    if any(item['status'] != 'complete' for item in references):
        return result
    if reference_bars is not None:
        end = references[-1]['end']
    # Quote completeness of every reference day is established above; closure
    # slots remain explicitly excluded and do not silently replace missing bars.
    ref_parts = ([b for item in references for b in item['bars']]
                 if reference_bars is not None else
                 [b for b in closed if start <= b.time < end and _research_open(b.time)])
    low, high = min(b.low for b in ref_parts), max(b.high for b in ref_parts)
    if low >= high:
        result['status'] = 'degenerate_reference'
        return result
    available = max(datetime.fromisoformat(item['available_at']) for item in references)
    range_id = _key('NY-research-range-v2' if reference_bars is not None else 'NY-research-range-v1', timeframe,
                    *(d.isoformat() for d in reference_dates),
                    start.isoformat(), end.isoformat(), float(low).hex(), float(high).hex())
    ref = {'id': range_id, 'timeframe': timeframe, 'low': low, 'high': high,
           'available_at': available.isoformat(), 'reference_dates': [d.isoformat() for d in reference_dates],
           'start': start.isoformat(), 'end': end.isoformat(),
           'basis': 'Previous complete NY 00:00 research ' + ('day' if timeframe == 'D1' else 'Monday–Friday week')
                    + ('; M5 quote coverage, observed Friday last bar 16:50 / study close 16:55 NY'
                       if reference_bars is not None else '; fixed M15 quote coverage, Friday 17:00 study close')
                    + '; historical broker session calendar not verified; not broker native D1/W1',
           'source_definition_confirmed': False}
    result.update(status='available', range=ref)
    coverage = _Coverage(start, cutoff, closed, period)
    stamps = [b.time for b in closed]
    candidates = []
    for side, price, field in [('buy_side_proxy', high, 'high'), ('sell_side_proxy', low, 'low')]:
        anchor = next(b for b in ref_parts if getattr(b, field) == price)
        candidates.append((anchor, side, price, available, 'ERL', 'range_edge_pool', available))
    for anchor, side, price, confirmed in _swings(closed, period):
        if anchor.time < start:
            continue
        relation_known = max(available, confirmed)
        classification = 'IRL' if low < price < high else 'ERL'
        semantic = 'internal_swing_pool' if classification == 'IRL' else 'external_swing_pool'
        candidates.append((anchor, side, price, relation_known, classification, semantic, confirmed))
    # Edges take precedence over coincident same-side pivots. The first pivot
    # per side/price owns a stable ID; a later repeat does not prove new orders.
    candidates.sort(key=lambda item: (item[3], item[5] != 'range_edge_pool', item[0].time))
    seen = set()
    for anchor, side, price, known, classification, semantic, level_known in candidates:
        if known > cutoff or (side, price) in seen:
            continue
        seen.add((side, price))
        external = classification == 'ERL'
        label = classification + '（' + ('外部' if external else '内部') + ('买方流动性' if side == 'buy_side_proxy' else '卖方流动性') + '）'
        pool = {'id': _key(range_id, 'pool', side, float(price).hex()), 'range_id': range_id,
                'classification': classification, 'side': side, 'price': price,
                'available_at': known.isoformat(), 'anchor_time': anchor.time.isoformat(),
                'level_available_at': level_known.isoformat(),
                'label': label, 'semantic_kind': semantic, 'analysis_timeframe': 'M15'}
        _pool_state(pool, closed, stamps, period, coverage)
        result['pools'].append(pool)
    for gap in geometric_fvgs(closed, period, cutoff):
        lower, upper = gap['lower'], gap['upper']
        known = max(available, datetime.fromisoformat(gap['available_at']))
        if low < lower and upper < high:
            classification = 'IRL'
        elif upper <= low or lower >= high:
            classification = 'outside_range'
        else:
            classification = 'straddles_range'
        bullish = gap['direction'] == 'bullish'
        prefix = 'IRL FVG' if classification == 'IRL' else 'FVG 跨参照边界' if classification == 'straddles_range' else 'FVG 参照范围外'
        label = prefix + '（' + ('内部' if classification == 'IRL' else '') + ('买方不平衡' if bullish else '卖方不平衡') + '）'
        array = {
            **gap, 'id': _key(range_id, 'fvg', gap['formation_bar_open'], gap['direction'], float(lower).hex(), float(upper).hex()),
            'range_id': range_id, 'classification': classification, 'label': label,
            'anchor_time': (datetime.fromisoformat(gap['formation_bar_open']) - 2 * period).isoformat(),
            'formation_available_at': gap['available_at'], 'available_at': known.isoformat(),
            'semantic_kind': 'internal_imbalance_array' if classification == 'IRL' else 'imbalance_array',
            'imbalance_side': 'buy_side_imbalance' if bullish else 'sell_side_imbalance',
            'stop_order_side': None, 'actual_stop_orders_observed': False,
            'qualified_pda': False, 'analysis_timeframe': 'M15',
        }
        _array_state(array, closed, stamps, period, coverage)
        result['arrays'].append(array)
    return result
