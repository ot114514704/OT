"""Synthetic geometry/clock contract tests; no predictive performance claims."""
import unittest
from dataclasses import replace
from datetime import date, datetime, time, timedelta, timezone

from brooks_ai.types import Bar
from ict_ai.range_liquidity import M5, M15, range_liquidity_map
from ict_ai.timebase import NY


def local(day, hour=0, minute=0):
    return datetime.combine(day, time(hour, minute), NY).astimezone(timezone.utc)


def reference_day(day):
    last = 68 if day.weekday() == 4 else 96
    rows = [Bar(local(day) + i * M15, 100, 104, 96, 100, 0)
            for i in range(last) if not 68 <= i < 72]
    rows[2] = replace(rows[2], high=110)
    rows[4] = replace(rows[4], low=90)
    return rows


def quiet_day(day):
    return [Bar(local(day) + i * M15, 100, 103, 97, 100, 0)
            for i in range(68 if day.weekday() == 4 else 96) if not 68 <= i < 72]


def pivot_at(rows, index, high=None, low=None):
    rows[index] = replace(rows[index], **({} if high is None else {'high': high}),
                          **({} if low is None else {'low': low}))


class RangeLiquidityTest(unittest.TestCase):
    def setUp(self):
        self.day = date(2026, 10, 13)  # Tuesday
        self.reference = reference_day(self.day - timedelta(days=1))
        self.today = quiet_day(self.day)

    def result(self, cutoff, today=None, reference=None):
        return range_liquidity_map((self.reference if reference is None else reference)
                                   + (self.today if today is None else today), [self.day], cutoff)

    @staticmethod
    def pool(result, side, price):
        return next(item for item in result['pools'] if item['side'] == side and item['price'] == price)

    def test_range_edges_available_only_after_complete_reference(self):
        before = self.result(local(self.day) - timedelta(microseconds=1))
        self.assertEqual(before['status'], 'insufficient_reference')
        self.assertIsNone(before['range'])
        self.assertEqual(before['pools'], [])
        ready = self.result(local(self.day))
        self.assertEqual(ready['status'], 'available')
        self.assertEqual((ready['range']['low'], ready['range']['high']), (90, 110))
        self.assertEqual(ready['range']['available_at'], local(self.day).isoformat())
        for side, price in [('buy_side_proxy', 110), ('sell_side_proxy', 90)]:
            edge = self.pool(ready, side, price)
            self.assertEqual(edge['classification'], 'ERL')
            self.assertEqual(edge['semantic_kind'], 'range_edge_pool')
            self.assertFalse(edge['actual_stop_orders_observed'])
        self.assertFalse(ready['qualified_range'])
        self.assertFalse(ready['execution_allowed'])
        self.assertEqual(ready['orders_sent'], 0)

    def test_friday_m5_reference_closes_at_observed_1655_boundary(self):
        friday=date(2026,10,9)
        monday=date(2026,10,12)
        m5=[Bar(local(friday)+i*M5,100,105,95,100,0) for i in range(203)]
        m5[-1]=replace(m5[-1],high=112)
        m15=reference_day(friday)+quiet_day(monday)
        ready=range_liquidity_map(m15,[monday],local(monday),reference_bars=m5)
        self.assertEqual(ready['status'],'available')
        self.assertEqual(ready['range']['high'],112)
        self.assertEqual(ready['range']['available_at'],local(friday,16,55).isoformat())
        self.assertEqual(ready['reference_checks'][0]['missing_bars'],0)
        missing=range_liquidity_map(m15,[monday],local(monday),reference_bars=m5[:-1])
        self.assertEqual(missing['status'],'insufficient_reference')
        self.assertEqual(missing['reference_checks'][0]['missing_bars'],1)

    def test_internal_pivot_waits_for_right_bar_close(self):
        today = list(self.today)
        pivot_at(today, 2, high=107)
        unavailable = self.result(local(self.day) + 3 * M15, today)
        self.assertFalse(any(p['price'] == 107 for p in unavailable['pools']))
        known = self.result(local(self.day) + 4 * M15, today)
        pool = self.pool(known, 'buy_side_proxy', 107)
        self.assertEqual(pool['classification'], 'IRL')
        self.assertEqual(pool['semantic_kind'], 'internal_swing_pool')
        self.assertEqual(pool['label'], 'IRL（内部买方流动性）')
        self.assertEqual(pool['available_at'], (local(self.day) + 4 * M15).isoformat())
        self.assertFalse(pool['observed_touch'])

    def test_classification_and_ids_are_frozen_under_future_prefixes(self):
        today = list(self.today)
        pivot_at(today, 2, high=107)
        pivot_at(today, 8, high=114)
        pivot_at(today, 10, low=87)
        bars = self.reference + today
        for i in range(1, 16):
            cutoff = local(self.day) + i * M15
            actual = range_liquidity_map(bars, [self.day], cutoff)
            prefix = range_liquidity_map([b for b in bars if b.time + M15 <= cutoff], [self.day], cutoff)
            self.assertEqual(actual, prefix)
        early = self.result(local(self.day) + 4 * M15, today)
        late = self.result(local(self.day) + 12 * M15, today)
        self.assertEqual(self.pool(early, 'buy_side_proxy', 107)['id'],
                         self.pool(late, 'buy_side_proxy', 107)['id'])
        self.assertEqual(early['range'], late['range'])
        self.assertEqual(self.pool(late, 'buy_side_proxy', 114)['semantic_kind'], 'external_swing_pool')
        self.assertEqual(self.pool(late, 'sell_side_proxy', 87)['classification'], 'ERL')

    def test_coincident_edges_and_repeated_internal_swings_are_deduplicated(self):
        today = list(self.today)
        pivot_at(today, 2, high=110)
        pivot_at(today, 5, high=107)
        pivot_at(today, 8, high=107)
        result = self.result(local(self.day) + 10 * M15, today)
        self.assertEqual(sum(p['side'] == 'buy_side_proxy' and p['price'] == 110 for p in result['pools']), 1)
        self.assertEqual(self.pool(result, 'buy_side_proxy', 110)['semantic_kind'], 'range_edge_pool')
        self.assertEqual(sum(p['side'] == 'buy_side_proxy' and p['price'] == 107 for p in result['pools']), 1)
        self.assertEqual(self.pool(result, 'buy_side_proxy', 107)['classification'], 'IRL')
        self.assertEqual(self.pool(result, 'buy_side_proxy', 107)['anchor_time'], today[5].time.isoformat())

    def test_touch_excursion_and_closed_return_are_separate_events(self):
        today = list(self.today)
        today[0] = Bar(today[0].time, 105, 110, 104, 109, 0)
        touched = self.pool(self.result(local(self.day) + M15, today), 'buy_side_proxy', 110)
        self.assertTrue(touched['observed_touch'])
        self.assertFalse(touched['observed_excursion'])
        self.assertIsNone(touched['reclaim_known_at'])
        today[1] = Bar(today[1].time, 109, 113, 108, 111, 0)
        breached = self.pool(self.result(local(self.day) + 2 * M15, today), 'buy_side_proxy', 110)
        self.assertTrue(breached['observed_excursion'])
        self.assertIsNone(breached['reclaim_known_at'])
        today[2] = Bar(today[2].time, 111, 112, 107, 109, 0)
        returned = self.pool(self.result(local(self.day) + 3 * M15, today), 'buy_side_proxy', 110)
        self.assertEqual(returned['first_touch_known_at'], (local(self.day) + M15).isoformat())
        self.assertEqual(returned['first_excursion_known_at'], (local(self.day) + 2 * M15).isoformat())
        self.assertEqual(returned['reclaim_known_at'], (local(self.day) + 3 * M15).isoformat())
        self.assertFalse(returned['untouched'])
        self.assertFalse(returned['order_exhaustion_confirmed'])

    def test_missing_quote_and_unclosed_candle_cannot_assert_untouched(self):
        full = self.result(local(self.day) + 4 * M15)
        self.assertTrue(self.pool(full, 'buy_side_proxy', 110)['untouched'])
        missing = self.result(local(self.day) + 4 * M15, self.today[:1] + self.today[2:])
        pool = self.pool(missing, 'buy_side_proxy', 110)
        self.assertFalse(pool['coverage_complete'])
        self.assertIsNone(pool['untouched'])
        forming = self.result(local(self.day) + 4 * M15 + timedelta(seconds=1))
        self.assertIsNone(self.pool(forming, 'buy_side_proxy', 110)['untouched'])
        self.assertEqual(self.pool(forming, 'buy_side_proxy', 110)['first_touch_known_at'], None)

    def test_missing_path_cannot_bridge_old_excursion_to_later_close(self):
        today = list(self.today)
        today[0] = Bar(today[0].time, 111, 113, 111, 112, 0)
        today[2] = Bar(today[2].time, 108, 109, 106, 107, 0)
        missing = self.result(local(self.day) + 3 * M15, today[:1] + today[2:])
        pool = self.pool(missing, 'buy_side_proxy', 110)
        self.assertTrue(pool['observed_excursion'])
        self.assertFalse(pool['observed_touch'])
        self.assertIsNone(pool['reclaim_known_at'])
        self.assertIsNone(pool['untouched'])

    def test_gap_over_level_proves_excursion_but_cannot_prove_level_unvisited(self):
        today = list(self.today)
        today[0] = Bar(today[0].time, 111, 113, 111, 112, 0)
        result = self.result(local(self.day) + M15, today)
        pool = self.pool(result, 'buy_side_proxy', 110)
        self.assertTrue(pool['coverage_complete'])
        self.assertTrue(pool['observed_excursion'])
        self.assertFalse(pool['observed_touch'])
        self.assertIsNone(pool['untouched'])
        self.assertIsNone(pool['reclaim_known_at'])

    def test_preexisting_pivot_does_not_reset_visited_state_when_range_closes(self):
        reference = list(self.reference)
        pivot_at(reference, 8, high=107)
        pivot_at(reference, 20, high=109)
        result = self.result(local(self.day), reference=reference)
        pool = self.pool(result, 'buy_side_proxy', 107)
        self.assertEqual(pool['level_available_at'], (reference[9].time + M15).isoformat())
        self.assertEqual(pool['available_at'], local(self.day).isoformat())
        self.assertEqual(pool['first_touch_known_at'], (reference[20].time + M15).isoformat())
        self.assertEqual(pool['first_excursion_known_at'], (reference[20].time + M15).isoformat())
        self.assertEqual(pool['reclaim_known_at'], (reference[20].time + M15).isoformat())
        self.assertFalse(pool['untouched'])
        self.assertLess(datetime.fromisoformat(pool['first_touch_known_at']),
                        datetime.fromisoformat(pool['available_at']))

    def test_fvg_imbalance_direction_never_becomes_stop_order_side(self):
        today = list(self.today)
        today[0] = Bar(today[0].time, 100, 101, 99, 100, 0)
        today[1] = Bar(today[1].time, 100, 106, 99, 105, 0)
        today[2] = Bar(today[2].time, 105, 106, 104, 105, 0)
        before = self.result(local(self.day) + 2 * M15, today)
        self.assertEqual(before['arrays'], [])
        ready = self.result(local(self.day) + 3 * M15, today)
        gap = next(item for item in ready['arrays'] if item['formation_bar_open'] == today[2].time.isoformat())
        self.assertEqual(gap['classification'], 'IRL')
        self.assertEqual(gap['direction'], 'bullish')
        self.assertEqual(gap['label'], 'IRL FVG（内部买方不平衡）')
        self.assertEqual(gap['imbalance_side'], 'buy_side_imbalance')
        self.assertIsNone(gap['stop_order_side'])
        self.assertNotIn('side', gap)
        self.assertEqual(gap['available_at'], (local(self.day) + 3 * M15).isoformat())

    def test_fvg_boundary_relation_is_not_silently_internal(self):
        today = list(self.today)
        today[0] = Bar(today[0].time, 108, 110, 107, 109, 0)
        today[1] = Bar(today[1].time, 109, 114, 108, 113, 0)
        today[2] = Bar(today[2].time, 113, 114, 112, 113, 0)
        outside = self.result(local(self.day) + 3 * M15, today)['arrays'][0]
        self.assertEqual(outside['classification'], 'outside_range')
        today[0] = Bar(today[0].time, 108, 109, 107, 108, 0)
        crosses = self.result(local(self.day) + 3 * M15, today)['arrays'][0]
        self.assertEqual(crosses['classification'], 'straddles_range')

    def test_old_fvg_keeps_touch_ce_fill_and_invalidation_before_range_availability(self):
        reference = list(self.reference)
        reference[10] = Bar(reference[10].time, 100, 101, 99, 100, 0)
        reference[11] = Bar(reference[11].time, 100, 107, 99, 106, 0)
        reference[12] = Bar(reference[12].time, 106, 107, 104, 106, 0)
        reference[13] = Bar(reference[13].time, 103, 105, 99, 100, 0)
        result = self.result(local(self.day), reference=reference)
        gap = next(item for item in result['arrays'] if item['formation_bar_open'] == reference[12].time.isoformat())
        self.assertEqual(gap['formation_available_at'], (reference[12].time + M15).isoformat())
        self.assertEqual(gap['available_at'], local(self.day).isoformat())
        self.assertEqual(gap['ce'], 102.5)
        for field in ['first_touch_known_at', 'ce_known_at', 'full_mitigation_known_at', 'invalidation_known_at']:
            self.assertEqual(gap[field], (reference[13].time + M15).isoformat())
            self.assertLess(datetime.fromisoformat(gap[field]), datetime.fromisoformat(gap['available_at']))
        self.assertTrue(gap['coverage_complete'])
        self.assertFalse(gap['untouched'])

    def test_fvg_missing_path_prevents_untouched_and_future_fill_does_not_backfill(self):
        today = [Bar(b.time, 106, 108, 105, 106, 0) for b in self.today]
        today[0] = Bar(today[0].time, 100, 101, 99, 100, 0)
        today[1] = Bar(today[1].time, 100, 107, 99, 106, 0)
        today[2] = Bar(today[2].time, 106, 107, 104, 106, 0)
        today[6] = Bar(today[6].time, 103, 108, 99, 100, 0)
        before = self.result(local(self.day) + 6 * M15, today)
        gap = next(item for item in before['arrays'] if item['formation_bar_open'] == today[2].time.isoformat())
        self.assertTrue(gap['untouched'])
        self.assertIsNone(gap['first_touch_known_at'])
        self.assertIsNone(gap['ce_known_at'])
        self.assertIsNone(gap['full_mitigation_known_at'])
        self.assertIsNone(gap['invalidation_known_at'])
        missing = self.result(local(self.day) + 6 * M15, today[:3] + today[4:])
        unknown = next(item for item in missing['arrays'] if item['formation_bar_open'] == today[2].time.isoformat())
        self.assertIsNone(unknown['untouched'])
        self.assertFalse(unknown['coverage_complete'])
        reached = self.result(local(self.day) + 7 * M15, today)
        filled = next(item for item in reached['arrays'] if item['formation_bar_open'] == today[2].time.isoformat())
        self.assertFalse(filled['untouched'])
        self.assertEqual(filled['full_mitigation_known_at'], (today[6].time + M15).isoformat())
        prefix = self.result(local(self.day) + 6 * M15, today[:6])
        self.assertEqual(before, prefix)

    def test_bearish_fvg_uses_sell_imbalance_and_far_upper_edge(self):
        today = list(self.today)
        today[0] = Bar(today[0].time, 105, 106, 104, 105, 0)
        today[1] = Bar(today[1].time, 105, 106, 98, 100, 0)
        today[2] = Bar(today[2].time, 100, 101, 99, 100, 0)
        today[3] = Bar(today[3].time, 102, 105, 100, 105, 0)
        result = self.result(local(self.day) + 4 * M15, today)
        gap = next(item for item in result['arrays'] if item['formation_bar_open'] == today[2].time.isoformat())
        self.assertEqual(gap['label'], 'IRL FVG（内部卖方不平衡）')
        self.assertEqual(gap['imbalance_side'], 'sell_side_imbalance')
        self.assertIsNone(gap['stop_order_side'])
        self.assertEqual(gap['full_mitigation_known_at'], (today[3].time + M15).isoformat())
        self.assertEqual(gap['invalidation_known_at'], (today[3].time + M15).isoformat())

    def test_gap_below_fvg_records_invalidation_without_inventing_fill(self):
        today = list(self.today)
        today[0] = Bar(today[0].time, 100, 101, 99, 100, 0)
        today[1] = Bar(today[1].time, 100, 107, 99, 106, 0)
        today[2] = Bar(today[2].time, 106, 107, 104, 106, 0)
        today[3] = Bar(today[3].time, 99, 100, 98, 99, 0)
        result = self.result(local(self.day) + 4 * M15, today)
        gap = next(item for item in result['arrays'] if item['formation_bar_open'] == today[2].time.isoformat())
        self.assertTrue(gap['coverage_complete'])
        self.assertFalse(gap['observed_touch'])
        self.assertIsNone(gap['ce_known_at'])
        self.assertIsNone(gap['full_mitigation_known_at'])
        self.assertEqual(gap['invalidation_known_at'], (today[3].time + M15).isoformat())
        self.assertIsNone(gap['untouched'])

    def test_missing_reference_day_is_not_filled_with_other_quotes(self):
        result = self.result(local(self.day) + timedelta(hours=2), reference=self.reference[:8] + self.reference[9:])
        self.assertEqual(result['status'], 'insufficient_reference')
        self.assertEqual(result['reference_checks'][0]['status'], 'missing_quotes')
        self.assertEqual(result['pools'], [])
        self.assertEqual(result['arrays'], [])

    def test_monday_uses_friday_and_sunday_reopening_coverage(self):
        monday = date(2026, 10, 12)
        friday = monday - timedelta(days=3)
        reference = reference_day(friday)
        sunday = monday - timedelta(days=1)
        reopening = [Bar(local(sunday, 18) + i * M15, 100, 104, 96, 100, 0) for i in range(24)]
        today = quiet_day(monday)
        ready = range_liquidity_map(reference + reopening + today, [monday], local(monday) + 2 * M15)
        self.assertEqual(ready['range']['reference_dates'], [friday.isoformat()])
        self.assertEqual(ready['range']['available_at'], local(friday, 17).isoformat())
        self.assertTrue(self.pool(ready, 'buy_side_proxy', 110)['coverage_complete'])
        missing = range_liquidity_map(reference + reopening[1:] + today, [monday], local(monday) + 2 * M15)
        self.assertIsNone(self.pool(missing, 'buy_side_proxy', 110)['untouched'])

    def test_sunday_reopening_after_dst_transition_does_not_create_false_missing_bar(self):
        monday = date(2026, 11, 2)
        friday = monday - timedelta(days=3)
        sunday = monday - timedelta(days=1)
        reopening = [Bar(local(sunday, 18) + i * M15, 100, 104, 96, 100, 0) for i in range(24)]
        rows = reference_day(friday) + reopening + quiet_day(monday)
        result = range_liquidity_map(rows, [monday], local(monday) + M15)
        self.assertEqual(result['range']['available_at'], local(friday, 17).isoformat())
        self.assertEqual(local(friday, 17).hour, 21)
        self.assertEqual(local(sunday, 18).hour, 23)
        self.assertTrue(self.pool(result, 'buy_side_proxy', 110)['coverage_complete'])
        self.assertFalse(result['historical_clock_verified'])
        self.assertFalse(result['session_calendar_verified'])

    def test_weekly_requires_all_reference_days_and_clamps_to_friday(self):
        monday = date(2026, 10, 12)
        dates = [monday + timedelta(days=i) for i in range(5)]
        previous = [d - timedelta(days=7) for d in dates]
        reference = [b for d in previous for b in reference_day(d)]
        current = [b for d in dates for b in quiet_day(d)]
        pivot_at(current, len(current) - 3, high=107)
        cutoff = local(dates[-1], 17)
        baseline = range_liquidity_map(reference + current, dates, cutoff)
        future = [Bar(local(dates[-1] + timedelta(days=3)), 100, 200, 50, 100, 0)]
        self.assertEqual(range_liquidity_map(reference + current + future, dates, cutoff + timedelta(days=4)), baseline)
        self.assertEqual(baseline['range']['timeframe'], 'W1')
        self.assertEqual(baseline['range']['reference_dates'], [d.isoformat() for d in previous])
        missing = range_liquidity_map(reference[:100] + reference[101:] + current, dates, cutoff)
        self.assertIsNone(missing['range'])
        self.assertEqual(missing['pools'], [])

    def test_week_prefix_cannot_see_later_extremes(self):
        monday = date(2026, 10, 12)
        dates = [monday + timedelta(days=i) for i in range(5)]
        previous = [d - timedelta(days=7) for d in dates]
        bars = [b for d in previous for b in reference_day(d)]
        current = [b for d in dates for b in quiet_day(d)]
        pivot_at(current, 200, high=120)
        bars += current
        cutoff = local(dates[1], 10)
        result = range_liquidity_map(bars, dates, cutoff)
        self.assertEqual(result, range_liquidity_map([b for b in bars if b.time + M15 <= cutoff], dates, cutoff))
        self.assertFalse(any(p['price'] == 120 for p in result['pools']))

    def test_no_swing_confirmation_across_gap(self):
        today = list(self.today)
        pivot_at(today, 2, high=107)
        result = self.result(local(self.day) + 5 * M15, today[:3] + today[4:])
        self.assertFalse(any(p['price'] == 107 for p in result['pools']))

    def test_new_reference_range_produces_new_relation_version(self):
        today = list(self.today)
        pivot_at(today, 2, high=107)
        first = self.result(local(self.day) + 4 * M15, today)
        next_day = self.day + timedelta(days=1)
        second = range_liquidity_map(self.reference + today + quiet_day(next_day), [next_day], local(next_day) + M15)
        old = self.pool(first, 'buy_side_proxy', 107)
        new = self.pool(second, 'buy_side_proxy', 107)
        self.assertEqual(old['classification'], 'IRL')
        self.assertEqual(new['classification'], 'ERL')
        self.assertNotEqual(old['id'], new['id'])
        self.assertNotEqual(first['range']['id'], second['range']['id'])
        self.assertEqual(old['available_at'], (local(self.day) + 4 * M15).isoformat())
        self.assertEqual(new['available_at'], local(next_day).isoformat())

    def test_timezone_and_research_date_contracts(self):
        cases = [([], local(self.day), M15), ([date(2026, 10, 17)], local(self.day), M15),
                 ([self.day], datetime(2026, 10, 13), M15), ([self.day], local(self.day), timedelta(minutes=5)),
                 ([self.day, self.day + timedelta(days=1)], local(self.day), M15)]
        for dates, cutoff, period in cases:
            with self.assertRaises(ValueError):
                range_liquidity_map(self.reference + self.today, dates, cutoff, period)
        with self.assertRaises(ValueError):
            range_liquidity_map(self.reference + [self.today[0], self.today[0]], [self.day], local(self.day) + M15)


if __name__ == '__main__':
    unittest.main()
