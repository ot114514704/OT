import unittest
from datetime import datetime, timedelta, timezone
from ict_ai.clock_observation import SourceClockObserver
from scripts.serve_ict_live import assessed_quote


class ClockObservationTests(unittest.TestCase):
    def setUp(self):
        self.start = datetime(2026, 10, 29, 15, tzinfo=timezone.utc)

    def sample(self, observer, seconds, hours=3, raw_seconds=None, wall_shift=0):
        return observer.observe(self.start.timestamp()+(seconds if raw_seconds is None else raw_seconds)+hours*3600,
                                self.start+timedelta(seconds=seconds+wall_shift), seconds)

    def test_multiple_advancing_ticks_required(self):
        observer = SourceClockObserver()
        self.assertEqual(self.sample(observer, 0)['status'], 'collecting')
        self.assertEqual(self.sample(observer, 2)['status'], 'collecting')
        result = self.sample(observer, 4)
        self.assertEqual(result['status'], 'stable_current_observation')
        self.assertFalse(result['historical_alignment_verified'])

    def test_static_hour_old_quote_does_not_become_new_offset(self):
        observer = SourceClockObserver()
        # A fixed raw quote with +2 looks fresh at first even if it is an old +3 tick.
        for sec in (0,2,4,6):
            result = self.sample(observer, sec, hours=2, raw_seconds=0)
            self.assertIsNone(result['observed_offset_hours'])
        self.assertEqual(result['status'], 'no_recent_clock_match')

    def test_fall_back_requires_new_segment_and_does_not_rewrite_history(self):
        observer = SourceClockObserver()
        for sec in (0,2,4):self.sample(observer, sec)
        self.assertEqual(self.sample(observer, 6, hours=2)['status'], 'collecting')
        self.sample(observer, 8, hours=2)
        result = self.sample(observer, 10, hours=2)
        self.assertEqual(result['status'], 'offset_mismatch')
        self.assertEqual(result['observed_offset_hours'], 2)
        self.assertEqual(result['applied_offset_hours'], 3)
        self.assertFalse(result['automatic_offset_change'])

    def test_spring_forward_or_api_utc_transition_is_not_silently_adopted(self):
        for applied, observed in ((2,3),(3,0)):
            observer = SourceClockObserver(applied_hours=applied)
            for sec in (0,2,4):result=self.sample(observer,sec,hours=observed)
            self.assertEqual(result['status'], 'offset_mismatch')

    def test_host_clock_jump_latches_until_new_observer(self):
        observer = SourceClockObserver()
        self.sample(observer, 0)
        for sec in (2,4,6):
            result = self.sample(observer, sec, wall_shift=3600)
            self.assertEqual(result['status'], 'host_clock_discontinuity')
            self.assertIsNone(result['observed_offset_hours'])

    def test_long_observation_gap_requires_recollection(self):
        observer = SourceClockObserver()
        for sec in (0,2,4):self.sample(observer,sec)
        result = self.sample(observer, 30)
        self.assertEqual(result['status'], 'collecting')
        self.assertEqual(result['distinct_ticks'], 1)

    def test_fresh_looking_quote_cannot_override_clock_discontinuity(self):
        q = {'status':'live','bid':4000,'ask':4000.1,'quote_time':self.start.isoformat(),
             'read_at':self.start.isoformat(),'pending':{'5':[1,2,3]},
             'clock_observation':{'status':'host_clock_discontinuity'}}
        result = assessed_quote(q, self.start)
        self.assertEqual(result['status'], 'clock_unverified')
        self.assertFalse(result['analysis_eligible'])
        self.assertEqual(result['pending'], {})


if __name__=='__main__':unittest.main()
