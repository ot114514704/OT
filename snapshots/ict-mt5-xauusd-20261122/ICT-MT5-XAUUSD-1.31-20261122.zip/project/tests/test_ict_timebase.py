import unittest
from datetime import date,datetime,timedelta,timezone
from ict_ai.timebase import epoch_to_utc,manifest_epoch_to_utc,clock_policy_metadata,require_replay_clock,previous_week,session_windows,eastern_clock_spans


class TestTimebase(unittest.TestCase):
    def test_clock_feed_switches_at_exact_second_even_with_partial_first_hour(self):
        broker=timedelta(hours=2)
        for month,day,switch,before,after in [(3,8,9,-7,-6),(11,1,8,-6,-7)]:
            boundary=datetime(2026,month,day,switch,tzinfo=timezone.utc)
            a,b=boundary-timedelta(minutes=17,seconds=12),boundary+timedelta(minutes=31)
            self.assertEqual(list(eastern_clock_spans(a,b,broker)),
                             [(a,boundary,before*3600),(boundary,b,after*3600)])

    def test_price_hash_does_not_authorize_changed_historical_clock(self):
        source={'source_clock_offset_hours':2,'source_clock_segments':[
            {'raw_until':'2026-11-01T00:00:00+00:00','offset_hours':3},
            {'raw_from':'2026-11-01T00:00:00+00:00','offset_hours':2}]}
        report=clock_policy_metadata(source)
        require_replay_clock(source,report)
        changed={**source,'source_clock_segments':[]}
        with self.assertRaisesRegex(ValueError,'clock mapping mismatch'):
            require_replay_clock(changed,report)

    def test_legacy_constant_clock_reports_remain_explicit(self):
        require_replay_clock({'source_clock_offset_hours':3},{'source_clock_offset_hours':3})
        with self.assertRaises(ValueError):
            require_replay_clock({'source_clock_offset_hours':2},{'source_clock_offset_hours':3})

    def test_explicit_intervals_do_not_apply_current_offset_to_october(self):
        segments=[{'raw_until':'2026-11-01T00:00:00+00:00','offset_hours':3},
                  {'raw_from':'2026-11-01T00:00:00+00:00','offset_hours':2}]
        meta={'source_clock_offset_hours':2,'source_clock_segments':segments}
        for month,day,expected in [(10,30,9),(11,16,10)]:
            raw=datetime(2026,month,day,12,tzinfo=timezone.utc)
            self.assertEqual(manifest_epoch_to_utc(raw,meta).hour,expected)

    def test_uncovered_or_overlapping_clock_intervals_fail(self):
        raw=datetime(2026,11,16,tzinfo=timezone.utc)
        for segments in ([{'raw_until':'2026-11-01T00:00:00+00:00','offset_hours':3}],
                         [{'offset_hours':2},{'offset_hours':3}]):
            with self.assertRaises(ValueError):
                manifest_epoch_to_utc(raw,{'source_clock_segments':segments})

    def test_ny_local_windows_follow_dst(self):
        summer=session_windows(date(2026,10,9))["london"]
        winter=session_windows(date(2026,11,9))["london"]
        self.assertEqual(summer[0].hour,6)
        self.assertEqual(winter[0].hour,7)

    def test_asia_crosses_dst_boundary_without_forcing_four_utc_hours(self):
        start,end=session_windows(date(2026,11,2))["asia"]
        self.assertEqual(end-start,timedelta(hours=4))
        self.assertEqual(end.hour,5)

    def test_broker_hypothesis_is_explicit_and_separate_from_ny_dst(self):
        raw=datetime(2026,10,9,15,tzinfo=timezone.utc)
        self.assertEqual(epoch_to_utc(raw,timedelta(hours=3)).hour,12)
        self.assertEqual(epoch_to_utc(raw,timedelta(0)).hour,15)

    def test_previous_week_is_five_weekdays(self):
        self.assertEqual(previous_week(date(2026,10,12)),[date(2026,10,d) for d in range(5,10)])

    def test_ny_midnight_bounds_have_23_or_25_hours_on_transition_days(self):
        from ict_ai.timebase import NY
        for first,second,hours in ((date(2026,3,8),date(2026,3,9),23),
                                   (date(2026,11,1),date(2026,11,2),25)):
            start=datetime.combine(first,datetime.min.time(),NY).astimezone(timezone.utc)
            end=datetime.combine(second,datetime.min.time(),NY).astimezone(timezone.utc)
            self.assertEqual(end-start,timedelta(hours=hours))


if __name__ == "__main__":
    unittest.main()
