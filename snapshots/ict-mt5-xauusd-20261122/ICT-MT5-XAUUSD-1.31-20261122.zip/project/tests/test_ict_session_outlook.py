import unittest
from datetime import datetime,timedelta,timezone

from brooks_ai.types import Bar
from ict_ai.session_path import previous_session, after_window, price_purposes, STEP
from ict_ai.session_review import window_summary
from ict_ai.dol_outlook import H1, PeerEvidence, outlook, peer_evidence, remaining_gap
from ict_ai.range_liquidity import _Coverage
from ict_ai.smt import smt_observation
from ict_ai.profile_extrema import extreme_reviews
from ict_ai.timebase import NY


class SessionEvidenceTest(unittest.TestCase):
    def setUp(self):
        self.at=datetime(2026,11,20,15,tzinfo=timezone.utc)
        self.warm=[Bar(self.at+i*STEP,100,102,99,101,0) for i in range(-24,0)]
        self.body=[Bar(self.at+i*STEP,101,103,100,102,0) for i in range(12)]

    def test_before_previous_session_closes_no_final_extremes(self):
        prior=self.warm[-12:]
        result=previous_session(self.body,self.at,self.at+STEP,prior,self.at,self.at+2*STEP,'EU')
        self.assertIn('前盘仍在交易',result)
        self.assertNotIn('前高',result)

    def test_extreme_review_hides_unclosed_extreme_and_keeps_first_equal_touch(self):
        start=datetime(2026,11,16,0,tzinfo=NY)
        days=[start.date()+timedelta(days=i) for i in range(5)]
        bars=[Bar(start+i*STEP,101,high,99,101,0) for i,high in enumerate((102,105,105,110))]
        early=extreme_reviews(bars,[],days,start+3*STEP)
        self.assertEqual(early,extreme_reviews(bars[:3],[],days,start+3*STEP))
        for kind in ('day_extreme','week_extreme'):
            hi=next(row for row in early if row[0]==kind)
            self.assertEqual((hi[1],hi[4]),(start+STEP,105))
            self.assertIn('形成中',hi[3])
            self.assertIn('共 2 根',hi[3])
        closed=extreme_reviews(bars,[],days,start+timedelta(days=6))
        self.assertEqual(closed[0][4],110)
        self.assertIn('报价不全',closed[0][3])

    def test_open_window_summary_stable_with_future_quotes_hidden(self):
        now=self.at+3*STEP
        def summary(body,later):
            return window_summary('纽约上午银弹',self.at,self.at+12*STEP,body,self.warm[-12:],
                                  now,{},True,warm=self.warm,later=later)
        self.assertEqual(summary(self.body,self.body),summary(self.body[:3],[]))
        self.assertIn('窗后走势待观察',summary(self.body,[])[0])
        self.assertIn('报价中断',price_purposes(self.body[:2]+self.body[3:],self.warm))

    def test_post_window_comparison_uses_close_and_closed_quotes_only(self):
        end=self.at+12*STEP
        later=[Bar(end,102,105,100,104,0),Bar(end+STEP,104,140,101,130,0)]
        text=after_window(self.body,end,later,end+STEP,1)
        self.assertIn('末收 104.00（+2.00）',text)
        self.assertNotIn('130',text)

    def test_smt_retires_at_observable_catch_up_or_missing_bar_close(self):
        event={'available_at':self.at.isoformat(),'direction':'bearish',
               'primary':[{'price':102},{'price':104}],
               'secondary':[{'price':103},{'price':102}]}
        row=Bar(self.at,101,104,99,101,0)
        for secondary,field in (([row],'catch_up_at'),([],'gap_known_at')):
            info=smt_observation(event,[row],secondary,H1,self.at+2*H1)
            ended=datetime.fromisoformat(info[field])
            self.assertEqual(ended,self.at+H1)
            peer=PeerEvidence(self.at,'看跌 SMT · 白银',-1,ended,info['status'])
            self.assertEqual(peer_evidence([peer],self.at-H1,ended-STEP)[1],[(peer.title,-1)])
            observed,active=peer_evidence([peer],self.at-H1,ended)
            self.assertIn(info['status'],observed[0])
            self.assertEqual(active,[])

    def test_gap_target_only_shrinks_after_contact_bar_closes(self):
        h1=[Bar(self.at+(i-3)*H1,*prices,0) for i,prices in enumerate([
            (98,100,97,99),(99,106,98,105),(105,108,104,107)])]
        m5=[Bar(self.at+i*STEP,106,108,105,107,0) for i in range(-36,1)]
        m5.extend([Bar(self.at+STEP,106,107,102,106,0),Bar(self.at+2*STEP,106,108,99,107,0)])
        profile={'weekly_background':{'label':'','reason':''},'profile_label':'','profile_reason':''}
        po3={'phase_evidence':{'D':{'status':'not_confirmed'}},'reason':''}
        def gaps(at,bars):
            return [(lo,hi) for _,_,_,label,lo,hi in outlook(bars,h1,[],at,profile,po3,[])
                    if 'H1 FVG' in label]
        for i,expected in enumerate(([(100,104)],[(100,102)],[]),1):
            at=self.at+i*STEP
            self.assertEqual(gaps(at,m5),expected)
            self.assertEqual(gaps(at,[b for b in m5 if b.time+STEP<=at]),expected)
        self.assertEqual(gaps(self.at+2*STEP,m5[37:]),[])

    def test_jumps_inside_gap_require_observed_connection_to_near_edge(self):
        for bull in (True,False):
            gap=dict(lower=100,upper=110,direction='bullish' if bull else 'bearish')
            def quotes(*ranges):
                result=[]
                for i,(a,b) in enumerate(ranges):
                    lo,hi=(a,b) if bull else (210-b,210-a)
                    result.append(Bar(self.at+i*STEP,lo,hi,lo,hi,0))
                return result
            self.assertIsNone(remaining_gap(gap,quotes((103,106))))
            for ranges in [((103,106),(106,112)),((106,112),(103,106))]:
                self.assertEqual(remaining_gap(gap,quotes(*ranges)),(100,103) if bull else (107,110))
            self.assertIsNone(remaining_gap(gap,quotes((97,99),(106,112))))

    def test_m5_gap_coverage_across_friday_close_and_sunday_reopening(self):
        friday=datetime(2026,11,13,16,50,tzinfo=NY)
        sunday=datetime(2026,11,15,18,tzinfo=NY)
        rows=[Bar(t,102,103,101,102,0) for t in (friday,sunday,sunday+STEP)]
        cutoff=sunday+2*STEP
        self.assertTrue(_Coverage(friday,cutoff,rows,STEP).complete(friday))
        for missing in (0,1,2):
            self.assertFalse(_Coverage(friday,cutoff,rows[:missing]+rows[missing+1:],STEP).complete(friday))
