import csv,json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from scripts.export_mt5_native import native_time,objects,write_snapshot

POLICY={'source_clock_offset_hours':2,'source_clock_segments':[
 {'raw_until':'2026-11-01T00:00:00+00:00','offset_hours':3},
 {'raw_from':'2026-11-01T00:00:00+00:00','offset_hours':2}]}

class NativeTests(unittest.TestCase):
 def test_native_time_never_inherits_the_windows_timezone_or_a_missing_server_offset(self):
  with self.assertRaisesRegex(ValueError,'explicit UTC offset'):
   native_time('2026-11-18T00:00:00',POLICY)
  with self.assertRaisesRegex(ValueError,'broker clock policy'):
   native_time('2026-11-18T00:00:00-05:00',{})
  for value in ('2026-11-18T00:00:00-05:00','2026-11-18T05:00:00Z','2026-11-18T13:00:00+08:00',1794978000000):
   self.assertEqual(native_time(value,POLICY),'2026.11.18 07:00:00')
 def fixture(self):
  bars=[[1794286800000,4100,4120,4090,4110]]
  d={'date':'2026-11-10','daily_open':4100,'charts':{'60':{'bars':bars}},'profile_label':'测试'}
  return {'snapshot_read_at':'2026-11-11T00:00:00Z','scenarios':[{'id':'broker-plus3','days':[d],'weeks':[],'month':{}}]}
 def test_ny_winter_midnight_is_server_seven_and_summer_midnight_also_follows_policy(self):
  self.assertEqual(native_time('2026-11-10T00:00:00-05:00',POLICY),'2026.11.10 07:00:00')
  self.assertEqual(native_time('2026-10-20T00:00:00-04:00',POLICY),'2026.10.20 07:00:00')
 def test_hourly_day_divider_and_open_share_true_midnight_not_first_bar(self):
  rows=objects(self.fixture(),POLICY)
  divider=next(r for r in rows if r[3]=='VLINE')
  opening=next(r for r in rows if r[2]=='OPEN')
  self.assertEqual(divider[1],'60')
  self.assertEqual(divider[5],'2026.11.10 07:00:00')
  self.assertEqual(opening[5],divider[5])
 def test_identical_data_keeps_file_identity_and_utf16_is_readable(self):
  with TemporaryDirectory() as temp:
   folder=Path(temp);p=self.fixture()
   write_snapshot(folder,p,None,POLICY)
   first=(folder/'state.txt').read_text(encoding='utf16').splitlines()[0]
   write_snapshot(folder,p,{'status':'live'},POLICY)
   self.assertEqual((folder/'state.txt').read_text(encoding='utf16').splitlines()[0],first)
   with (folder/first).open(encoding='utf16',newline='') as f:rows=list(csv.reader(f,delimiter='\t'))
   self.assertTrue(all(len(r)==12 for r in rows))
   self.assertTrue(any('纽约' in r[9] for r in rows))
