"""Reconstruct what was available at each daily or weekly chart checkpoint."""

from bisect import bisect_left, bisect_right
from datetime import date, timedelta

from .profile_lifecycle import _day_bounds, daily_profile_lifecycle, weekly_profile_lifecycle
from .profile_session_followthrough import session_followthrough
from .range_liquidity import M5, _research_open
from .timebase import session_windows
from .weekly_close_candidates import friday_expansion_watch
from .weekly_path import consolidation_evidence, weekly_path


M15 = timedelta(minutes=15)


def checkpoint_rows(points, start, end, as_of, latest_close):
    closed = as_of >= end
    current = min(as_of, latest_close)
    current = current.replace(minute=current.minute//15*15,second=0,microsecond=0)
    limit = end if closed else current
    if limit <= start:
        return []
    visible = {at:label for at,label in points if start<at<=limit}
    visible[limit] = '收盘核验' if closed else visible.get(limit,'最新已收 M15')
    return sorted(visible.items())


def availability(bars, start, at):
    seen = {b.time for b in bars if start<=b.time and b.time+M5<=at}
    missing = []
    expected = 0
    for offset in range((at-start)//M5):
        stamp = start+offset*M5
        if _research_open(stamp):
            expected += 1
            if stamp not in seen:
                missing.append(stamp)
    return dict(expected_m5=expected, missing_m5=len(missing),
                first_missing_m5=missing[0].isoformat() if missing else None)


def checkpoint_state(profile, *, weekly):
    covered = profile.get('coverage_complete_under_study_calendar',False)
    mode = profile['mode']
    closed = mode in ('closed_review','closed_week_review')
    rendered = []
    if weekly and closed:
        records = [r for r in profile['realized_candidates'] if r.get('observed_sequence')]
        for card in records:
            rendered.append(dict(id=card['id'],label=card['profile'],direction=card.get('direction'),
                                 state=('insufficient_data' if not covered else 'confirmed' if card.get('path_complete') else 'partial'),
                                 evidence=card['reason']))
    else:
        for card in profile['candidates']:
            if not card['observed_sequence']:
                continue
            state = ('confirmed' if covered and closed and card.get('path_matched') else
                     'partial' if covered and closed and card['status']=='active' else
                     card['status'])
            rendered.append(dict(id=card['id'],label=card['label'],direction=card.get('direction'),state=state,
                                 evidence=card.get('failed_close_condition') or card['evidence'],
                                 awaiting=card.get('awaiting'),invalidation=card.get('invalidation')))
    return dict(covered=covered,closed=closed,label=profile['profile_label'],status=profile['profile_status'],cards=rendered)


def developments(previous, current):
    if previous is None or not previous['covered'] or not current['covered']:
        return []

    def key(card):
        return card['id'],card['direction']

    before = {key(c):c for c in previous['cards']}
    after = {key(c):c for c in current['cards']}
    moves = []
    for ident,card in after.items():
        state = card['state']
        old = before.get(ident,{}).get('state')
        if state!=old and (state in ('active','confirmed') or state in ('invalidated','partial') and old=='active'):
            moves.append(dict(label=card['label'],state=state,direction=card['direction']))
    for ident,card in before.items():
        if card['state']=='active' and ident not in after:
            moves.append(dict(label=card['label'],state='no_longer_listed',direction=card['direction']))
    return moves


class QuoteSeries:
    def __init__(self, rows):
        self.rows = rows
        self.times = [bar.time for bar in rows]

    def closed(self, start, at, period):
        return self.rows[bisect_left(self.times,start):bisect_right(self.times,at-period)]


def daily_timeline(m5, m15, day, as_of, latest_close):
    start,end = _day_bounds(day)
    windows = session_windows(day)
    ny = windows['new_york'][0]
    points = [(windows['london'][1],'伦敦窗结束'),(ny,'纽约窗开始'),
              (ny+timedelta(minutes=90),'纽约 08:30'),(ny+timedelta(minutes=150),'纽约 09:30'),
              (windows['new_york'][1],'纽约窗结束'),(windows['london_close'][1],'伦敦收盘窗结束')]
    asia = windows['asia'][0]
    history_start = min(asia,_day_bounds(day-timedelta(days=day.weekday()))[0])
    result = []
    for at,title in checkpoint_rows(points,start,end,as_of,latest_close):
        five = m5.closed(history_start,at,M5)
        quarters = m15.closed(history_start,at,M15)
        profile = daily_profile_lifecycle(quarters,day,at,include_reconstruction=False,reference_m5=five)
        state = checkpoint_state(profile,weekly=False)
        state.update(as_of=at.isoformat(),title=title,coverage=availability(five,start,at),
                     asia_coverage=availability(five,asia,windows['asia'][1]))
        state['session_evidence'] = session_followthrough(five,quarters,day,at,state['covered'])
        state['changes'] = developments(result[-1] if result else None,state)
        result.append(state)
    return result


def weekly_timeline(m5, m15, days, as_of, latest_close):
    start,_ = _day_bounds(days[0])
    friday,end = _day_bounds(days[-1])
    points = [(_day_bounds(d)[1],f'周{day}收线') for day,d in zip('一二三四',days[:4],strict=True)]
    points.extend((friday+delta,label) for delta,label in (
        (timedelta(hours=10),'周五 10:00'),(timedelta(hours=13),'周五 13:00'),
        (timedelta(hours=16,minutes=45),'周五 16:45')))
    result = []
    for at,title in checkpoint_rows(points,start,end,as_of,latest_close):
        five = m5.closed(start,at,M5)
        quarters = m15.closed(start,at,M15)
        realized = weekly_path(five,days,at)
        profile = weekly_profile_lifecycle(quarters,days,at,realized)
        state = checkpoint_state(profile,weekly=True)
        state.update(as_of=at.isoformat(), title=title, coverage=availability(five,start,at),
                     complete_days=sum(d['ended'] and d['coverage_complete'] for d in realized['daily']))
        watch = friday_expansion_watch(realized,quarters,days,at,state['covered'])
        if watch:
            state['friday_watch'] = watch
        midweek = midweek_range_watch(realized,days,at)
        if midweek:
            state['midweek_range_watch'] = midweek
        state['changes'] = developments(result[-1] if result else None,state)
        result.append(state)
    return result


def midweek_range_watch(realized, days, at):
    """Preserve the frozen Monday–Wednesday range as unsigned context."""
    known = _day_bounds(days[2])[1]
    if at < known:
        return None
    first = realized['daily'][:3]
    if [r['date'] for r in first]!=[d.isoformat() for d in days[:3]] or not all(
        r['ended'] and r['coverage_complete'] for r in first
    ):
        return None
    range_ = consolidation_evidence(first)
    if range_['matched']:
        return dict(known_at=known.isoformat(),range_low=range_['low'],range_high=range_['high'],
                    overlap_ratio=range_['overlap_ratio'])
    return None


def attach_profile_timeline(primary, series, as_of, latest_close):
    m5,m15 = (QuoteSeries(series[k]) for k in ('5','15'))
    for record in primary['days']:
        day = date.fromisoformat(record['date'])
        record['profile_timeline'] = daily_timeline(m5,m15,day,as_of,latest_close)
    for record in primary.get('weeks',[]):
        days = [date.fromisoformat(d) for d in record['days']]
        record['profile_timeline'] = weekly_timeline(m5,m15,days,as_of,latest_close)
