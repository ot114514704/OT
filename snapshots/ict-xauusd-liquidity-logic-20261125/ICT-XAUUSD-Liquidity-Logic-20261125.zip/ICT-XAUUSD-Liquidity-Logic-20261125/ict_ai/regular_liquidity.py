"""Conventional price pools, separate from IRL/ERL and path-nature claims.

Authority: Trader Wuwei foundations 238.84–305s; bias intro 259–308,
610–619 and 663–740s; resistance/liquidity 94–227 and 234–343s.
The equality tolerance and pivot parameters are disclosed research choices.
"""
from datetime import datetime,time,timedelta,timezone
from bisect import bisect_left
import hashlib
from .timebase import NY
from .range_liquidity import _swings,_m5_reference_day,_Coverage
from .sweep_response import RESPONSE_BARS, crossing_response

M5=timedelta(minutes=5);M15=timedelta(minutes=15)


def _id(*items):return hashlib.sha256('|'.join(map(str,items)).encode()).hexdigest()[:24]


def _observe(level,rows,as_of):
    available=datetime.fromisoformat(level.get('level_available_at',level['available_at']));price=level['price']
    buy=level['side']=='buy_side_proxy';touch=sweep=reclaim=None;pending=False;last=None;excursion=False
    first_cross_index=None
    coverage=_Coverage(available,as_of,rows,M5)
    start=bisect_left([b.time for b in rows],available)
    for i,b in enumerate(rows[start:],start):
        if last is not None and coverage.gap(last.time+M5,b.time):pending=False
        known=(b.time+M5).isoformat()
        excursion=excursion or (b.high>price if buy else b.low<price)
        if b.low<=price<=b.high:
            touch=touch or known
            if b.high>price if buy else b.low<price:
                if sweep is None:sweep,first_cross_index=known,i
                pending=True
        if pending and (b.close<price if buy else b.close>price):reclaim=reclaim or known
        last=b
    response=None
    if first_cross_index is not None:
        i=first_cross_index
        response=crossing_response(1 if buy else -1,price,rows[max(0,i-15):i],
                                   rows[i],rows[i+1:i+1+RESPONSE_BARS],as_of)
    level.update(first_touch_known_at=touch,sweep_known_at=sweep,reclaim_known_at=reclaim,crossing_response=response,
                 untouched=False if touch else True if coverage.complete(available) and not excursion else None,
                 coverage_complete=coverage.complete(available),actual_stop_orders_observed=False,
                 nature='待判定',nature_reason='缺少在触及前记录并核实的 DOL；不从内外位置推断预设或工程。')
    return level


def regular_liquidity(m15,m5,day,as_of,reference=None,equality_tolerance=.03):
    if as_of.tzinfo is None or equality_tolerance<0:raise ValueError('Aware cutoff and nonnegative tolerance required')
    if any(a.time>=b.time for a,b in zip(m5,m5[1:])) or any(a.time>=b.time for a,b in zip(m15,m15[1:])):
        raise ValueError('Unique chronological bars required')
    rows=[b for b in m5 if b.time+M5<=as_of]
    start=datetime.combine(day-timedelta(days=1),time(20),NY).astimezone(timezone.utc)
    finish=datetime.combine(day+timedelta(days=1),time(0),NY).astimezone(timezone.utc)
    cutoff=min(as_of,finish);rows=[b for b in rows if b.time>=start and b.time+M5<=cutoff]
    bars=[b for b in m15 if start-M15<=b.time and b.time+M15<=cutoff]
    ref=reference.get('range') if reference else None
    levels=[];previous={}
    for anchor,side,price,known in _swings(bars,M15):
        if anchor.time<start:continue
        kind='BSL' if side=='buy_side_proxy' else 'SSL'
        classification=('IRL' if ref['low']<price<ref['high'] else 'ERL') if ref else None
        relation_known=max(known,datetime.fromisoformat(ref['available_at'])) if ref else known
        value={'id':_id('regular-M15',anchor.time,side,ref['id'] if ref else 'unclassified'), 'kind':kind,'side':side,'price':price,
               'anchor_time':anchor.time.isoformat(),'available_at':relation_known.isoformat(),'level_available_at':known.isoformat(),
               'classification':classification,'source_scope':'M15 前高' if kind=='BSL' else 'M15 前低',
               'source_timeframe':'M15','source_author':'交易员无畏','range_id':ref['id'] if ref else None}
        levels.append(_observe(value,rows,cutoff))
        old=previous.get(side);previous[side]=(anchor,price,known)
        if old is None:continue
        prior,old_price,old_known=old
        middle=[b for b in bars if prior.time<=b.time<=anchor.time]
        if known-old_known>timedelta(hours=12) or abs(price-old_price)>equality_tolerance+1e-9 or any(a.time+M15!=b.time for a,b in zip(middle,middle[1:])):continue
        edge=max(price,old_price) if kind=='BSL' else min(price,old_price)
        classification=('IRL' if ref['low']<edge<ref['high'] else 'ERL') if ref else None
        equal={**value,'id':_id('regular-equal-M15',prior.time,anchor.time,side,ref['id'] if ref else 'unclassified'),
               'kind':'EQH' if kind=='BSL' else 'EQL','price':edge,'first_anchor_time':prior.time.isoformat(),
               'lower':min(price,old_price),'upper':max(price,old_price),'classification':classification,
               'source_scope':'M15 相对等高' if kind=='BSL' else 'M15 相对等低',
               'equality_tolerance_price':equality_tolerance}
        levels.append(_observe(equal,rows,cutoff))
    return {'as_of':cutoff.isoformat(),'levels':levels,'source_author':'交易员无畏',
            'engineering_choices':['Strict three-bar M15 pivots',f'Relative equality tolerance {equality_tolerance} XAU price units; not a video-specified threshold','Maximum equal-pivot span 12 hours'],
            'nature_context_qualified':False,'execution_allowed':False,'orders_sent':0}


def weekly_stage_liquidity(m5,dates,as_of):
    """Freeze *week-to-date* range edges at complete research-day closes.

    These are not daily internal pivots or a final weekly range known early.
    A quoted strict crossing is labelled an observed sweep; it does not prove
    every order was consumed. Gaps across a level do not count as a sweep.
    """
    if as_of.tzinfo is None or len(dates)!=5 or dates[0].weekday()!=0 or any(d!=dates[0]+timedelta(days=i) for i,d in enumerate(dates)):
        raise ValueError('Aware cutoff and ordered Monday–Friday dates required')
    if any(a.time>=b.time for a,b in zip(m5,m5[1:])):raise ValueError('Unique chronological bars required')
    end=datetime.combine(dates[-1],time(16,55),NY).astimezone(timezone.utc);cutoff=min(as_of,end)
    start=datetime.combine(dates[0],time(0),NY).astimezone(timezone.utc)
    rows=[b for b in m5 if start<=b.time and b.time+M5<=cutoff];part=[];levels=[];seen=set();checks=[]
    for day in dates:
        record=_m5_reference_day(rows,day,cutoff)
        checks.append({k:record[k] for k in ('date','status','missing_bars','available_at')})
        if record['status']!='complete':break
        part+=record['bars'];known=record['available_at']
        for field,side,kind in [('high','buy_side_proxy','BSL'),('low','sell_side_proxy','SSL')]:
            anchor=(max if field=='high' else min)(part,key=lambda b:getattr(b,field));price=getattr(anchor,field)
            if (side,price) in seen:continue
            seen.add((side,price));range_id=_id('week-stage',dates[0],day,min(b.low for b in part),max(b.high for b in part))
            level={'id':_id('week-stage-pool',dates[0],side,price,known),'range_id':range_id,
                   'classification':'ERL','kind':kind,'side':side,'price':price,
                   'source_scope':'周内阶段前高' if kind=='BSL' else '周内阶段前低',
                   'source_timeframe':'W1_stage','source_author':'交易员无畏',
                   'reference_dates':[d.isoformat() for d in dates if d<=day],
                   'anchor_time':anchor.time.isoformat(),'available_at':known}
            levels.append(_observe(level,rows,cutoff))
    return {'as_of':cutoff.isoformat(),'levels':levels,'reference_checks':checks,
            'scope':'Frozen week-to-date high/low at each complete NY research-day close; not M15/day internal pools',
            'source_author':'交易员无畏','historical_calendar_verified':False,'execution_allowed':False,'orders_sent':0}
