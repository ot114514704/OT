"""List published IRL/ERL candidates and their verified Bid sweeps for two NY days."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter
from contextlib import closing
from datetime import datetime, time, timedelta
from html import escape
from pathlib import Path
import json
import sqlite3

import numpy as np

from brooks_ai.types import Bar
from ict_ai.dol_history import _deadline, batch_id
from ict_ai.range_liquidity import _Coverage
from ict_ai.sweep_response import CROSSING_LABELS, RESPONSE_BARS, crossing_response
from ict_ai.timebase import manifest_epoch_to_utc
from scripts import backtest_ict_liquidity_account as replay


OUT = replay.RESEARCH / 'ict_recent_liquidity_20261124'
M5 = replay.M5
NY = replay.NY


def dt(value):
    return datetime.fromisoformat(value)


def published(start, cutoff, observed):
    with closing(sqlite3.connect(replay.DATABASE.resolve().as_uri()+'?mode=ro', uri=True)) as db:
        query = ('SELECT id,cutoff,received,payload FROM chart_batches WHERE cutoff>=? AND cutoff<=? '
                 'ORDER BY cutoff, received, id')
        records = db.execute(query,(start.isoformat(),cutoff.isoformat())).fetchall()
    found = {}
    unacknowledged = set()
    for key, stamp, receipt, raw in records:
        at = dt(stamp)
        if not receipt or dt(receipt)>observed:
            unacknowledged.add(stamp)
            continue
        seen = dt(receipt)
        sample = json.loads(raw)
        if seen < at or sample['at'] != stamp or batch_id(at,sample['price'],[sample['targets'],sample['pools']]) != key:
            raise ValueError(f'Invalid published chart batch at {stamp}')
        found.setdefault(stamp,dict(chart_batch=key,at=stamp,receipt=receipt,price=sample['price'],pools=sample['pools']))
    return list(found.values()), sorted(unacknowledged-found.keys())


def capture():
    import MetaTrader5 as api

    policy = json.loads(replay.CLOCK.read_bytes())
    if not api.initialize(str(replay.TERMINAL), timeout=10000):
        raise RuntimeError(f'TMGM unavailable: {api.last_error()}')
    try:
        account = replay.checked_terminal(api)
        identity = account.login, account.server
        tick = api.symbol_info_tick('XAUUSD')
        last = manifest_epoch_to_utc(datetime.fromtimestamp(tick.time,replay.UTC),policy)
        if not timedelta(seconds=-1) <= datetime.now(replay.UTC)-last <= timedelta(minutes=1):
            raise ValueError('TMGM quote / broker clock is stale')
        cutoff = datetime.fromtimestamp(int(last.timestamp())//300*300,replay.UTC)
        yesterday = cutoff.astimezone(NY).date()-timedelta(days=1)
        start = datetime.combine(yesterday,time(0),NY).astimezone(replay.UTC)
        batches, unacknowledged = published(start, cutoff, last)
        bars = replay.collect_bars(api,start,cutoff,policy)
        if not batches or bars[-1].time+M5 != cutoff:
            raise ValueError('Latest closed price or chart receipts are unavailable')
        replay.write_zip(OUT/'batches.json.gz',batches)
        replay.write_zip(OUT/'m5.json.gz',[[b.time.isoformat(),*replay.ohlc(b)] for b in bars])
        chunks = {}
        for index, day in enumerate((yesterday,yesterday+timedelta(days=1))):
            begin = datetime.combine(day,time(0),NY).astimezone(replay.UTC)
            finish = min(cutoff,datetime.combine(day+timedelta(days=1),time(0),NY).astimezone(replay.UTC))
            if begin >= finish:
                continue
            stamp,bid,_ = replay.capture_ticks(api,begin,finish,policy)
            path = OUT/f'bid_day{index+1}.npz'
            np.savez_compressed(path,stamp=stamp,bid=bid)
            chunks[day.isoformat()] = dict(start=begin.isoformat(),end=finish.isoformat(),file=path.name,
                                          count=len(stamp),sha256=replay.digest(path))
            print(day,f'{len(stamp):,} Bid quotes',flush=True)
        replay.checked_terminal(api,identity)
        manifest = dict(start=start.isoformat(),cutoff=cutoff.isoformat(),quote_seen_at=last.isoformat(),
                        server=account.server, batches=len(batches), unacknowledged=unacknowledged, quotes=chunks,
                        inputs={p.name:replay.digest(p) for p in (replay.CLOCK,OUT/'m5.json.gz',OUT/'batches.json.gz')},
                        orders_sent=0)
        replay.atomic_json(OUT/'capture.json',manifest)
    finally:
        api.shutdown()


def review_target(target, future, receipt, stamps, bids, bad_bars, exhausted):
    side, outer = target['side'], replay.far(target)
    receipt_last_ms = replay.time_ms(receipt) + 999
    touched = False
    for b in future:
        hit_zone = b.low<=target['hi'] and b.high>=target['lo']
        touched |= hit_zone and b.time>=receipt
        if side*(replay.excursion(b,side)-outer)<=0:
            continue
        opened = replay.time_ms(b.time)
        if opened in bad_bars:
            return dict(state='unverified_bid_bucket', checked_m5=b.time.isoformat())
        lo,hi = np.searchsorted(stamps,[opened,opened+300000])
        cross = np.flatnonzero(side*(bids[lo:hi]-outer)>0)
        if not len(cross):
            return dict(state='unverified_bid_bucket', checked_m5=b.time.isoformat())
        i = lo+int(cross[0])
        tick_at = datetime.fromtimestamp(int(stamps[i])/1000,replay.UTC).isoformat(timespec='milliseconds')
        event = dict(tick_at=tick_at, tick_bid=float(bids[i]), checked_m5=(b.time+M5).isoformat())
        if stamps[i] <= receipt_last_ms:
            return dict(state='before_receipt',**event)
        if not b.low<=outer<=b.high or i==lo:
            return dict(state='gap_over',**event)
        return dict(state='swept',**event)
    return dict(state=('touched' if touched else 'untouched') if exhausted else
                      ('touched_pending' if touched else 'pending'))


def ny_stamp(value):
    return dt(value).astimezone(NY).strftime('%H:%M:%S')


def day_report(batches, bars, times, coverage, cutoff, quote_item):
    path = OUT/quote_item['file']
    if replay.digest(path) != quote_item['sha256']:
        raise ValueError(f'Historical Bid changed: {path}')
    with np.load(path) as raw:
        stamps, bids = raw['stamp'], raw['bid']
    chart = {replay.time_ms(b.time):replay.ohlc(b) for b in bars}
    boundary = [dt(quote_item[k]) for k in ('start','end')]
    matched,bad = replay.verify_quote_bars(stamps,bids,chart,*boundary)
    rows, united = [], {}
    counts = Counter()
    responses = {}
    for batch in batches:
        at, receipt = (dt(batch[k]) for k in ('at','receipt'))
        end = min(cutoff,_deadline(at))
        i = bisect_left(times,at)
        terminal_close = bars[i-1].close if i and bars[i-1].time+M5 == at else None
        matched_close = terminal_close == batch['price']
        chunk = bars[i:bisect_left(times,end)]
        complete = not coverage.gap(at,end)
        candidates = []
        for target in batch['pools']:
            state = (dict(state='published_reference_disagreement') if not matched_close else
                     dict(state='empty_observation_window') if end<=receipt else
                     review_target(target,chunk,receipt,stamps,bids,bad,end==_deadline(at)) if complete else
                     dict(state='missing_chart_m5'))
            evidence = dict(target,**state,cutoff=batch['at'],receipt=batch['receipt'],deadline=_deadline(at).isoformat(),
                            outer=replay.far(target))
            if state['state']=='swept':
                known=dt(state['checked_m5'])
                event=(target['side'],evidence['outer'],known)
                if event not in responses:
                    j=bisect_left(times,known-M5)
                    responses[event]=crossing_response(target['side'],evidence['outer'],bars[max(0,j-15):j],
                                                         bars[j],bars[j+1:j+1+RESPONSE_BARS],cutoff)
                evidence['crossing_response']=responses[event]
            candidates.append(evidence)
            counts[evidence['state']] += 1
            key = target['scope'],target['side'],evidence['outer']
            group = united.setdefault(key,dict(best_rank=target['rank'],first=evidence,hit=None,states=Counter()))
            group['best_rank'] = min(group['best_rank'],target['rank'])
            group['states'][state['state']] += 1
            if state['state']=='swept' and (group['hit'] is None or evidence['tick_at'] < group['hit']['tick_at']):
                group['hit'] = evidence
        rows.append(dict(batch,candidates=candidates, reference_verified=matched_close, terminal_close=terminal_close))
    swept = sorted((g['hit'] for g in united.values() if g['hit']),key=lambda row: row['tick_at'])
    scopes = {}
    for s in ('irl','erl'):
        group=[g for key,g in united.items() if key[0]==s]
        scopes[s]=dict(distinct_preselected=len(group),distinct_swept=sum(g['hit'] is not None for g in group),
                       buy_swept=sum(g['hit'] is not None and g['hit']['side']==1 for g in group),
                       sell_swept=sum(g['hit'] is not None and g['hit']['side']==-1 for g in group))
    return dict(batches=len(batches),counts=dict(counts),scope=scopes,published_history=rows,
                latest=rows[-1] if rows else None, swept=swept, distinct=list(united.values()),
                reference_disagreements=[dict(at=r['at'],published=r['price'],terminal=r['terminal_close'])
                                         for r in rows if not r['reference_verified']],
                latest_verified=next((r for r in reversed(rows) if r['reference_verified']),None),
                bid_ticks=len(stamps),reconciled_m5=matched,bid_disagreements=len(bad))


def scoped_rows(rows):
    labels = dict(swept='已扫', before_receipt='回执之前已越过', gap_over='跳过外沿', pending='待扫',
                  untouched='窗口到期未扫', touched='触及后到期', touched_pending='已触及，待扫',
                  unverified_bid_bucket='逐笔未核实', missing_chart_m5='行情缺失',
                  published_reference_disagreement='预选参考价需核对', empty_observation_window='尚无已收线观察窗')
    result = ['<table><thead><tr><th>范围</th><th>侧</th><th>候选价带</th><th>外沿</th><th>冻结</th>'
              '<th>图表收到</th><th>名次／分</th><th>状态</th><th>越过时刻／Bid</th>'
              '<th>扫荡／真破判词</th></tr></thead><tbody>']
    for row in rows:
        s = row['side']
        band = f'{row["lo"]:.2f}–{row["hi"]:.2f}' if row['hi'] != row['lo'] else f'{row["lo"]:.2f}'
        tick = f'{ny_stamp(row["tick_at"])}／{row["tick_bid"]:.2f}' if row.get('tick_at') else '—'
        response = row.get('crossing_response')
        verdict = CROSSING_LABELS[response['status']] if response else '—'
        if response and response['known_at']:
            verdict += ' · '+ny_stamp(response['known_at'])
        fields = [row['scope'].upper(), '买方上沿' if s == 1 else '卖方下沿', band, f'{row["outer"]:.2f}',
                  ny_stamp(row['cutoff']), ny_stamp(row['receipt']), f'{row["rank"]}／{row["score"]}',
                  labels[row['state']], tick, verdict]
        result.append('<tr>'+''.join(f'<td>{escape(str(text))}</td>' for text in fields)+'</tr>')
    return '\n'.join(result+['</tbody></table>'])


def render(report):
    cutoff = dt(report['cutoff']).astimezone(NY).strftime('%m-%d %H:%M')
    html = ['<!doctype html><html lang="zh-CN"><meta charset="utf-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1">',
            '<title>TMGM 黄金 · 流动性预选与已扫</title>',
            '''<style>
body{max-width:1260px;margin:26px auto;padding:0 18px;background:#f3f6f8;color:#142630;font:15px system-ui,sans-serif}
header,section{margin:14px 0;padding:14px 20px;background:white;border:1px solid #cbd9de;border-radius:9px}
p{line-height:1.55}h1{font-size:25px}h2{font-size:20px}summary{margin:13px 0;cursor:pointer;font-weight:650}
.scroll{overflow:auto}table{width:100%;border-collapse:collapse;white-space:nowrap;font:13px system-ui,sans-serif;font-variant-numeric:tabular-nums}
th,td{padding:6px 10px;text-align:right;border-bottom:1px solid #dae3e7}th:first-child,td:first-child{text-align:left}
</style>''', '<body><header><h1>TMGM 黄金 · 流动性预选与已扫</h1>',
            f'<p>纽约时间。行情核对到 {cutoff} 收线。成功清扫使用图表收到预选后、同根 M5 内严格越过的第一条 Bid。</p>',
            '<p>当天合并同范围、同侧和同外沿的重复预选。各批次仍保留原始榜单。</p></header>']
    for day, row in report['days'].items():
        irl, erl = [row['scope'][s] for s in ('irl','erl')]
        html.append(f'<section><h2>{day}</h2><p>{row["batches"]} 次回执 · IRL {irl["distinct_swept"]}/{irl["distinct_preselected"]} · '
                    f'ERL {erl["distinct_swept"]}/{erl["distinct_preselected"]} · {row["reconciled_m5"]} 根 M5 四价吻合</p>')
        html.append('<h3>已成功扫荡</h3><div class="scroll">'+scoped_rows(row['swept'])+'</div>')
        if row['latest']:
            html.append('<h3>最后一次已发布的预选</h3><div class="scroll">'+scoped_rows(row['latest']['candidates'])+'</div>')
            if not row['latest']['reference_verified'] and row['latest_verified']:
                html.append('<h3>最近一次参考价已核对的预选</h3><div class="scroll">'
                            +scoped_rows(row['latest_verified']['candidates'])+'</div>')
        html.append('<details><summary>全部回执与逐批预选</summary>')
        for batch in row['published_history']:
            html.append(f'<details><summary>{ny_stamp(batch["at"])} 冻结，{ny_stamp(batch["receipt"])} 收到</summary>'
                        '<div class="scroll">'+scoped_rows(batch['candidates'])+'</div></details>')
        html.append('</details></section>')
    return '\n'.join(html+['</body></html>'])


def make_report():
    manifest = json.loads((OUT/'capture.json').read_bytes())
    for path in (replay.CLOCK,OUT/'m5.json.gz',OUT/'batches.json.gz'):
        if replay.digest(path) != manifest['inputs'][path.name]:
            raise ValueError(f'Archived input changed: {path}')
    start, cutoff = (dt(manifest[k]) for k in ('start','cutoff'))
    bars = [Bar(dt(t),o,h,l,c,0) for t,o,h,l,c in replay.read_zip(OUT/'m5.json.gz')]
    times = [b.time for b in bars]
    batches = replay.read_zip(OUT/'batches.json.gz')
    coverage = _Coverage(start,cutoff,bars,M5)
    days = {}
    for day,item in manifest['quotes'].items():
        group = [p for p in batches if str(dt(p['at']).astimezone(NY).date())==day]
        days[day] = day_report(group,bars,times,coverage,cutoff,item)
        data = days[day]
        print(day,data['batches'],data['scope'],data['bid_disagreements'],data['latest']['at'] if data['latest'] else None)
    report = dict(cutoff=manifest['cutoff'],quote_seen_at=manifest['quote_seen_at'],server=manifest['server'],
                  coverage_missing_m5=coverage.missing[-1],unacknowledged=manifest['unacknowledged'],days=days,
                  methodology='Published 1.34 top-ten chart receipts. Strict first Bid excursion occurs after receipt, '
                  'after the one-second chart receipt interval, from the inside of a reconciled M5 bucket and no later than four hours or NY study day end. '
                  'If the published reference and source M5 close differ, the original candidate remains in view but no confirmed sweep is attributed to that receipt. '
                  'Count distinct side/outer edge per IRL or ERL per date. Repeated rows are retained in the full journal.',
                  code_sha256=replay.digest(Path(__file__)),capture_sha256=replay.digest(OUT/'capture.json'),orders_sent=0)
    replay.atomic_json(OUT/'report.json',report)
    (OUT/'report.html').write_text(render(report),encoding='utf-8')


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture',action='store_true')
    args = parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    if args.capture:
        capture()
    make_report()


if __name__ == '__main__':
    main()
