"""Screen all available May 11–29 H1 closes for pre-break Book adjustment evidence."""
import json
from collections import Counter
from functools import lru_cache
from pathlib import Path

from book_frozen_adjustment import attach
from book_pair_recovery import observe
from book_viewport_structure import inspect_close,stamp
from test_frozen_adjustment import OUT,history
from review_summer_context import counterleg


def main():
    bars=history()
    positions={stamp(b.time):i for i,b in enumerate(bars)}
    eligible=[i for i,b in enumerate(bars) if '2026-05-11'<=stamp(b.closed_at)[:10]<'2026-05-30']
    scopes={}
    @lru_cache(maxsize=10)
    def checked(i):
        report=inspect_close(bars[i-511:i+1])
        attach(report,bars,positions,i,scopes)
        return report
    metrics=Counter()
    cases=[]
    for i in eligible:
        r=checked(i)
        metrics['bars']+=1
        metrics[r['status']]+=1
        for p in r.get('pairs',[]):
            ref=p.get('adjustment_reference')
            if not ref: continue
            metrics[ref['status']]+=1
            first=positions[min(p['turning_break_bar'],p['trend_break_bar'])]
            alt={n:counterleg(p,bars,first,i,n) for n in (256,512,768)}
            case=dict(clock=r['clock'],owner=p['owner'],direction=p['direction'],event=p['event'],reference=ref,
                      warmups=alt,source_alive=p['source_alive'],same_terminal=p['same_terminal'])
            if ref['status']=='candidate':
                case['level_reproduced']=all(v.get('price')==ref['price'] and
                    v.get('freeze')==ref['freeze'] for v in alt.values())
                tracked=observe(bars,positions,i,min(eligible[-1],i+3),r,checked)
                case['after']=next((o.get('adjustment_follow') for o in tracked if o['owner']==p['owner']),None)
            cases.append(case)
    result=dict(first=stamp(bars[eligible[0]].closed_at),last=stamp(bars[eligible[-1]].closed_at),counts=metrics,
                dual_clocks=len({x['clock'] for x in cases}),cases=cases)
    (OUT/'may_replay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
    print(dict(metrics),result['dual_clocks'],[(c['clock'],c['reference']['price'],c['level_reproduced'])
                                            for c in cases if 'level_reproduced' in c],flush=True)


if __name__=='__main__':
    main()

