"""Freeze a direct Book counterleg at the open of the first broken H1 boundary."""

from book_viewport_structure import REFERENCE_LOCATION, WINDOW, load_reference, stamp


def freeze(scopes, owner, before, cutoff):
    """The supplied bars and scope snapshot both end at the first break's open."""
    if not before or before[-1].closed_at != cutoff or scopes['as_of_utc'] != stamp(cutoff):
        return dict(status='incomplete_prefix')
    contra = [c for c in (*scopes['active'],*scopes['retired']) if c.get('terminal')
              and c['direction']!=owner['direction'] and (c.get('parent_scope_id')==owner['scope_id']
              or owner['scope_id'] in c.get('ambiguous_parent_scope_ids',()))]
    if not contra:
        return dict(status='no_direct_counterleg')
    last = max(c['terminal'][0] for c in contra)
    latest = [c for c in contra if c['terminal'][0]==last]
    if len(latest)!=1 or latest[0].get('parent_scope_id')!=owner['scope_id']:
        return dict(status='ambiguous_latest_counterleg')
    child = latest[0]
    if (child.get('parent_relation')!='internal_return_stage' or
        child.get('historical_range_state')!='completed_excursion_before_origin_breach' or
        not child.get('membership_known_at_utc') or child['membership_known_at_utc']>stamp(cutoff)):
        return dict(status='incomplete_latest_counterleg')
    extreme,price = child['terminal']
    sign = 1 if owner['direction']=='down' else -1
    resumed = None
    for bar in before:
        if bar.time.timestamp()<=extreme:
            continue
        if sign*(bar.close-price)>0:
            return dict(status='already_crossed_before_first')
        if resumed is None and sign*(bar.close-child['origin'][1])<0:
            resumed=stamp(bar.closed_at)
    if resumed is None:
        return dict(status='resumption_missing')
    return dict(status='candidate',price=price,extreme=extreme,child=child['scope_id'],owner=owner['scope_id'],
                membership_known=child['membership_known_at_utc'],resumed=resumed,freeze=stamp(cutoff),
                author_degree_verified=False)


def location(bar,price,direction):
    distance=(bar.close-price)*(1 if direction=='down' else -1)
    if distance>0: return 'outside'
    if distance==0: return 'touch'
    if (bar.open-price)*(1 if direction=='down' else -1)>0:
        return 'body_back'
    wick=bar.high>price if direction=='down' else bar.low<price
    return 'wick_back' if wick else 'inside'


def attach(report,bars,positions,event,cache):
    for pair in report.get('pairs',()):
        if pair['event'] not in ('same_bar','later_line'):
            continue
        first=positions[min(pair['trend_break_bar'],pair['turning_break_bar'])]
        cutoff=bars[first].time
        before=bars[max(0,first-WINDOW+1):first]
        if not before or before[-1].closed_at!=cutoff:
            pair['adjustment_reference']=dict(status='gap_before_first')
            continue
        if first not in cache:
            rows=[dict(timestamp_utc=stamp(b.time),timeframe='H1',symbol='XAUUSD',provider='MT5_experiment',
                       open=b.open,high=b.high,low=b.low,close=b.close) for b in before]
            cache[first]=load_reference()[0](rows,'H1',stamp(cutoff))
        scopes=cache[first]
        owner=next((o for o in scopes['active'] if o['scope_id']==pair['owner'] and o['direction']==pair['direction']
                    and o['origin']==pair['origin'] and o.get('terminal')==pair['terminal']),None)
        ref=freeze(scopes,owner,before,cutoff) if owner else dict(status='source_not_reproduced_before_first')
        if ref['status']=='candidate':
            ref['first_close']=stamp(bars[first].closed_at)
            ref['first_location']=location(bars[first],ref['price'],pair['direction'])
            ref['dual_location']=location(bars[event],ref['price'],pair['direction'])
        pair['adjustment_reference']=ref


def track(ref,pair,bars,event,through):
    """Record close locations separately from the native owner's lifetime."""
    points=[]
    stop=None
    up=pair['direction']=='up'
    for i in range(event,through+1):
        b=bars[i]
        if i>event and b.time!=bars[i-1].closed_at:
            stop='gap'
            break
        retired=b.low<pair['origin'][1] if up else b.high>pair['origin'][1]
        extended=b.high>pair['terminal'][1] if up else b.low<pair['terminal'][1]
        points.append(dict(clock=stamp(b.closed_at),close=b.close,location=location(b,ref['price'],pair['direction'])))
        if retired or extended or (i==event and not (pair['source_alive'] and pair['same_terminal'])):
            stop='origin_breached' if retired else 'terminal_extended' if extended else 'source_changed'
            break
    return dict(price=ref['price'],freeze=ref['freeze'],points=points,stop=stop)


def describe(items):
    labels=[]
    for item in items:
        path=item.get('adjustment_follow')
        if not path:
            continue
        states=[]
        previous=None
        for p in path['points']:
            if p['location']!=previous:
                states.append(p['clock'][11:16]+REFERENCE_LOCATION[p['location']])
                previous=p['location']
        text=f"候选A {path['price']:.2f} "+'→'.join(states)
        if path['stop']:
            text+='（'+{'gap':'缺柱中止','origin_breached':'原波段起点已破','terminal_extended':'波段端点已更新',
                         'source_changed':'原波段归属待核'}[path['stop']]+'）'
        if text not in labels:
            labels.append(text)
    return '、'.join(labels)

