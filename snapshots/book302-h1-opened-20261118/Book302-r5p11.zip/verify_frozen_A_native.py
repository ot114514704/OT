"""Compare the H1 chart receipt and all prior fields against the preserved request."""
import json
from collections import Counter
from copy import deepcopy

from book_pair_recovery import summary
from book_viewport_structure import note
from package_book_outline_side import ROOT, KEY, BRIDGE, read, sha, tsv
from test_frozen_adjustment import OUT


def verify():
    before=OUT/'before'
    request=f'request_{KEY}.tsv'
    assert (before/request).read_bytes()==(BRIDGE/request).read_bytes()
    old,new=[read(d/f'audit_{KEY}.json') for d in (before,BRIDGE)]
    prior,lines=[tsv(d/f'reply_{KEY}.tsv') for d in (before,BRIDGE)]
    header=lines[0].split('\t')
    rev=tsv(BRIDGE/f'reply_revision_{KEY}.tsv')[0].split('\t')
    render=tsv(BRIDGE/f'render_state_{KEY}.tsv')[0].split('\t')
    identity=read(BRIDGE/'worker_identity.json')
    assert identity['script_sha256']==sha((ROOT/'worker.py').read_bytes())
    assert min(int(rev[5]),int(render[12]))>=identity['started']
    assert old['token']==new['token']==header[2]==rev[2]==render[3]==render[4]
    assert header[7]==rev[3]==render[5]=='full' and new['full_model']['available']
    assert header[8]==rev[4]==sha(('\n'.join(lines[1:])+'\n').encode())
    assert len(lines)==len(prior) and len(old['results'])==len(new['results'])==int(header[3])
    counts=Counter()
    changed=[]
    for a,b in zip(old['results'],new['results']):
        row=deepcopy(b)
        scope=row.get('book_structure')
        if scope:
            assert 'adjustment_error' not in scope
            prefix=note(scope)+'；'
            assert row['detail'].startswith(prefix)
            remainder=row['detail'][len(prefix):]
            for pair in scope.get('pairs',[]):
                ref=pair.pop('adjustment_reference',None)
                if ref:
                    counts[ref['status']]+=1
            row['detail']=note(scope)+'；'+remainder
        recovery=row.get('book_pair_recovery')
        if recovery:
            prefix=summary(recovery)+'。'
            assert row['follow'].startswith(prefix)
            remainder=row['follow'][len(prefix):]
            for item in recovery:
                item.pop('adjustment_follow',None)
            row['follow']=summary(recovery)+'。'+remainder
        assert a==row, (b['id'],[k for k in row if a.get(k)!=row[k]])
        if (a['detail'],a['follow'])!=(b['detail'],b['follow']):
            changed.append(b['id'])
    for a,b in zip(prior[1:],lines[1:]):
        aa,bb=a.split('\t'),b.split('\t')
        if aa[0]=='R':
            bb[11],bb[14]=aa[11],aa[14]
        assert aa==bb
    assert int(render[11])==sum(r.startswith('C\t') for r in lines)
    return dict(rows=len(new['results']),continuations=int(render[11]),native_pair_references=counts,
                changed_text_rows=changed,token=header[2],revision=rev[4],
                render_clock=render[12],worker=identity)


if __name__=='__main__':
    result=verify()
    (OUT/'native.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
    print(result)
