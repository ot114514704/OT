"""Plot two observed H1 events, using the rails frozen before each close."""
import json
from datetime import datetime

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

from book_pair_recovery import line_at
from book_viewport_structure import inspect_close,stamp
from test_frozen_adjustment import OUT,history


def main():
    bars=history()
    positions={stamp(b.time):i for i,b in enumerate(bars)}
    closes={stamp(b.closed_at):i for i,b in enumerate(bars)}
    cases=json.loads((OUT/'may_replay.json').read_text('utf8'))['cases']
    cases=[c for c in cases if c.get('level_reproduced')]
    plt.rcParams.update({'font.family':'Microsoft YaHei','axes.unicode_minus':False})
    fig,axes=plt.subplots(len(cases),1,figsize=(9,6.8),layout='constrained')
    for ax,c in zip(axes,cases):
        i=closes[c['clock']]
        p=next(p for p in inspect_close(bars[i-511:i+1])['pairs'] if p['owner']==c['owner'])
        ref=c['reference']
        for k in range(-9,4):
            b=bars[i+k]
            color='#167970' if b.close>=b.open else '#ae4742'
            ax.vlines(k,b.low,b.high,color=color,linewidth=1)
            ax.add_patch(Rectangle((k-.28,min(b.open,b.close)),.56,max(.08,abs(b.open-b.close)),color=color))
        for role,anchor,label,color in [('trend',0,'趋势线','#66509a'),('turning',2,'拐点线','#3071aa')]:
            ks=[k for k in range(-9,1) if stamp(bars[i+k].time)>=p['pair_known']]
            ax.plot(ks,[float(line_at(p[role],p[role][anchor],i+k,positions)) for k in ks],color=color,label=label)
        price=ref['price']
        freeze=datetime.fromisoformat(ref['freeze']).timestamp()
        start=next(k for k in range(-9,1) if bars[i+k].time.timestamp()>=freeze)
        ax.hlines(price,start,3.4,color='#905c14',ls='--',label=f'候选 A  {price:.2f}')
        ax.axvline(0,color='#65747e',lw=.9,ls=':')
        label='同柱双破，收盘仍在 A 点内侧' if c['event']=='same_bar' else '本柱补破，影线越过 A 点后收回'
        ax.set_title(c['clock'][5:10]+'  '+c['clock'][11:16]+' UTC   |   '+label,loc='left',fontsize=12)
        ax.set_xticks([-9,-6,-3,0,3],[stamp(bars[i+k].closed_at)[11:16] for k in (-9,-6,-3,0,3)])
        ax.set_ylabel('XAUUSD')
        ax.legend(loc='upper left',fontsize=8,ncol=3,framealpha=.9)
        ax.grid(axis='y',alpha=.15)
        ax.spines[['top','right']].set_visible(False)
    fig.suptitle('Book H1 破位复盘  ·  2026 年 5 月',fontsize=16)
    axes[-1].set_xlabel('H1 收盘时间（UTC） ·  竖虚线为事件收盘')
    fig.savefig(OUT/'五月双破复盘.png',dpi=145)
    plt.close(fig)


if __name__=='__main__':
    main()
