"""Verify pre-break adjustment candidates and their timeline on native H1 snapshots."""
import json
from dataclasses import replace
from datetime import datetime,timedelta,timezone
from functools import lru_cache
from pathlib import Path
import unittest

from book_frozen_adjustment import attach,freeze,location,track
from book_pair_recovery import observe
from book_viewport_structure import inspect_close,stamp,note
from test_book_pair_recovery import history
from worker import NativeBar,parse_request,solve,encode_reply

OUT=Path(__file__).resolve().parent/'verification/book_frozen_A_20261118'
CLOCKS={'03-18T14':4970.23,'04-02T09':None,'07-29T22':4047.8,'09-01T12':4450.62,
        '09-29T09':4171.33,'10-01T06':4164.38,'10-02T19':None,'11-06T21':None,'11-10T13':4084.71}


def inspect_dates():
    bars=history()
    positions={stamp(b.time):i for i,b in enumerate(bars)}
    ends={stamp(b.closed_at):i for i,b in enumerate(bars)}
    cache={}
    @lru_cache(maxsize=32)
    def check(i):
        report=inspect_close(bars[max(0,i-511):i+1])
        attach(report,bars,positions,i,cache)
        return report
    samples=[]
    for day,price in CLOCKS.items():
        i=ends['2026-'+day+':00:00Z']
        report=check(i)
        refs=[p for p in report['pairs'] if 'adjustment_reference' in p]
        matches=[p for p in refs if p['adjustment_reference']['status']=='candidate']
        assert refs and {p['adjustment_reference']['price'] for p in matches}==({price} if price else set())
        for p in matches:
            r=p['adjustment_reference']
            assert not r['author_degree_verified'] and r['freeze']==min(p['trend_break_bar'],p['turning_break_bar'])
            assert max(r['resumed'],r['membership_known'])<=r['freeze']
        observations=observe(bars,positions,i,i+3,report,check)
        samples.append(dict(clock=report['clock'],detail=note(report),pairs=[dict(id=p['owner'],direction=p['direction'],
                            reference=p['adjustment_reference']) for p in refs],
                            follow=[r['adjustment_follow'] for r in observations if 'adjustment_follow' in r]))
    return samples


def physical_requests():
    bars=history()
    ends={stamp(b.closed_at):i for i,b in enumerate(bars)}
    samples=[]
    for day in ('07-29T22','10-01T06','11-10T13'):
        i=ends['2026-'+day+':00:00Z']
        for end in range(i-1,i+4):
            selected=bars[i-516:end+1]
            cutoff=int(selected[-1].closed_at.timestamp())
            token=f'A-{cutoff}'
            lines=[f'BEXP\t1\t{token}\t3600\t{cutoff}\t{len(selected)}\tarchive\tXAUUSD\t0.01']
            lines.extend('\t'.join(map(str,('B',int(b.time.timestamp()),b.open,b.high,b.low,b.close,round(b.spread/.01))))
                         for b in selected)
            req=parse_request('\n'.join([*lines,'END\t'+token]))
            results=solve(req)
            current=results[-1]
            assert current['id']=='__CURRENT' and current['follow'] in encode_reply(req,results,0)
            event=stamp(bars[i].closed_at)
            matches=[o for o in current.get('book_pair_recovery',[]) if o['event']==event and o.get('adjustment_follow')]
            assert len(matches)==int(end>=i)
            if matches:
                f=matches[0]['adjustment_follow']
                assert f['price']==CLOCKS[day] and all(p['clock']<=stamp(selected[-1].closed_at) for p in f['points'])
                if day=='10-01T06':
                    assert len(f['points'])==end-i+1 and f['points'][0]['location']=='inside'
                    if end>i:
                        assert f['points'][1]['location']=='outside' and f['points'][1]['clock']=='2026-10-01T07:00:00Z'
                if day=='07-29T22':
                    assert len(f['points'])==1 and f['stop']=='origin_breached'
            samples.append(dict(clock=stamp(selected[-1].closed_at),event=event,matches=len(matches),
                                detail=current['detail'].split('；',1)[0],follow=current['follow']))
    return samples


class Adjustment(unittest.TestCase):
    def test_mirror_and_ambiguity(self):
        for s in (1,-1):
            start=datetime(2026,1,1,tzinfo=timezone.utc)
            price=lambda v:100+s*v
            bars=[NativeBar(start+timedelta(hours=i),price(v),price(v)+.5,price(v)-.5,price(v),0,3600)
                  for i,v in enumerate((12,10,7,12,13))]
            cut=bars[-1].closed_at
            owner=dict(scope_id='parent',direction='up' if s==1 else 'down')
            child=dict(scope_id='child',parent_scope_id='parent',direction='down' if s==1 else 'up',
                       origin=[bars[0].time.timestamp(),price(11)],terminal=[bars[2].time.timestamp(),price(6.5)],
                       parent_relation='internal_return_stage',historical_range_state='completed_excursion_before_origin_breach',
                       membership_known_at_utc=stamp(cut))
            def run(children,series=bars):
                return freeze(dict(active=[],retired=children,as_of_utc=stamp(cut)),owner,series,cut)['status']
            self.assertEqual(run([child]),'candidate')
            newer=dict(child,scope_id='new',terminal=[bars[3].time.timestamp(),price(7)])
            self.assertEqual(run([child,dict(newer,parent_relation='post_extreme_return_candidate')]),'incomplete_latest_counterleg')
            self.assertEqual(run([child,dict(newer,parent_scope_id=None,ambiguous_parent_scope_ids=['parent','other'])]),'ambiguous_latest_counterleg')
            self.assertEqual(run([child,dict(child,scope_id='tied')]),'ambiguous_latest_counterleg')
            self.assertEqual(run([dict(child,parent_scope_id='other')]),'no_direct_counterleg')
            self.assertEqual(run([child],bars[:-1]),'incomplete_prefix')
            v=price(5)
            self.assertEqual(run([child],bars[:-1]+[replace(bars[-1],open=v,high=v,low=v,close=v)]),'already_crossed_before_first')
            wick=replace(bars[2],high=max(price(8),price(5)),low=min(price(8),price(5)))
            self.assertEqual(location(wick,price(6.5),owner['direction']),'wick_back')
            self.assertEqual(location(replace(wick,open=price(5)),price(6.5),owner['direction']),'body_back')
            self.assertEqual(location(replace(wick,close=price(6.5)),price(6.5),owner['direction']),'touch')

    def test_native_refs(self):
        result=inspect_dates()
        nov=result[-1]['pairs'][0]['reference']
        self.assertEqual((nov['first_location'],nov['dual_location']),('wick_back','outside'))
        (OUT/'references.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),'utf8')


if __name__=='__main__':
    unittest.main()

