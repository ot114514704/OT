"""Check range exits and protected-origin breaks on two archived XAUUSD weeks."""
import json
import sys
from collections import Counter
from dataclasses import replace
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ict_ai.ipda_reference.core import aggregate, load_bars
from ict_ai.ipda_reference.ipda_phases import detect_phases
from ict_ai.timebase import NY, manifest_epoch_to_utc


def check(folder, first, policy):
    raw = load_bars(ROOT / "data/real" / folder / "XAUUSD_M5.csv")
    bars = [replace(b, time=manifest_epoch_to_utc(b.time, policy)) for b in raw]
    bars = [b for b in bars if first-timedelta(days=7) <= b.time.astimezone(NY).date() < first+timedelta(days=5)]
    quarters = aggregate(bars, 900, bars[-1].closed_at)
    rows = detect_phases(quarters, quarters[-1].closed_at)
    counts = Counter()
    checked = set()
    for i, (bar, row) in enumerate(zip(quarters, rows, strict=True)):
        if bar.time.astimezone(NY).date() < first:
            continue
        evidence = row["consolidation_evidence"]
        event = evidence["event"]
        if event == "breakout_confirmed":
            assert row["phase"] == "expansion" and row["direction"] == evidence["ended"]["breakout_side"]
        elif event in ("breakout_pending", "range_reclaimed"):
            assert row["phase"] == "consolidation"
        elif row["phase"] == "reversal":
            anchor = row["reference_before"]
            assert anchor and (bar.close < anchor["low"] if anchor["direction"] == 1 else bar.close > anchor["high"])
            event = "protected_break"
        else:
            continue
        counts[event] += 1
        if event not in checked:
            assert detect_phases(quarters[:i+1], bar.closed_at)[-1] == row
            checked.add(event)
    return counts


if __name__ == "__main__":
    settings = json.loads((ROOT / "research/live_clock_20261116.json").read_text(encoding="utf-8"))
    total = Counter()
    for archive, week in [("TMGM_ICT_D1_basis_20261014_132250", date(2026, 10, 5)),
                          ("TMGM_XAU_extrema_close_20261121", date(2026, 11, 16))]:
        result = check(archive, week, settings)
        print(week, dict(result), flush=True)
        total.update(result)
    assert all(total[k] for k in ("breakout_confirmed", "breakout_pending", "range_reclaimed", "protected_break"))
