"""Replay the unmodified MT5 draft against subsequent detector labels."""
import argparse
import hashlib
import json
import re
import sys
from collections import Counter
from dataclasses import replace
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ict_ai.ipda_reference.core import Bar, load_bars
from ict_ai.ipda_reference.ipda_phases import detect_phases
from ict_ai.ipda_outlook import DIRECT, NAMES, phase_note
from ict_ai.timebase import NY, manifest_epoch_to_utc
from scripts.prepare_ict_week import aggregate_bars

parser = argparse.ArgumentParser()
parser.add_argument("--start",type=date.fromisoformat,default=date(2026,11,16))
parser.add_argument("--source",type=Path,default=ROOT/"data/real/TMGM_XAU_extrema_close_20261121/XAUUSD_M5.csv")
args = parser.parse_args()
if args.start.weekday()!=0:
    parser.error("Week must start on Monday")
source = args.source.resolve()
policy = json.loads((ROOT / "research/live_clock_20261116.json").read_text(encoding="utf-8"))
def selected(b):
    return args.start-timedelta(days=25)<=b.time.astimezone(NY).date()<=args.start+timedelta(days=5)

def archive_bars(path, seconds):
    import numpy as np
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == json.loads(path.with_name("capture.json").read_bytes())["series"][path.stem]["sha256"]
    with np.load(path,allow_pickle=False) as dataset:
        bars = []
        for row in dataset["rates"]:
            t = datetime.fromtimestamp(int(row["time"]),timezone.utc)
            if not args.start-timedelta(days=26)<=t.date()<=args.start+timedelta(days=6):
                continue
            b = Bar(manifest_epoch_to_utc(t,policy), *(float(row[k]) for k in ("open","high","low","close")), seconds=seconds)
            if selected(b):
                bars.append(b)
    return bars

if source.suffix == ".npz":
    m5 = archive_bars(source,300)
else:
    raw = load_bars(source,300)
    m5 = [b for r in raw if selected(b:=replace(r,time=manifest_epoch_to_utc(r.time,policy)))]
end = m5[-1].closed_at
def aggregate(minutes):
    return [Bar(b.time,b.open,b.high,b.low,b.close,seconds=minutes*60)
            for b in aggregate_bars(m5,5,minutes,end)]
m15 = aggregate(15)
h1 = archive_bars(source.with_name("XAUUSDH1.npz"),3600) if source.suffix==".npz" else aggregate(60)
dest = ROOT / ("output/research/ipda_hourly_holdout" if source.suffix==".npz" else "output/research/ipda_draft_validation_20261122")
dest.mkdir(parents=True,exist_ok=True)
records = []
hours = (3,8,10,12,14,15)
for i, bar in enumerate(m15):
    t = bar.closed_at.astimezone(NY)
    scheduled=t.minute==0 and t.hour in hours
    boundary=source.suffix==".npz" and (t.hour,t.minute) in ((16,0),(16,45))
    if not args.start<=t.date()<=args.start+timedelta(days=4) or not (scheduled or boundary):
        continue
    note = phase_note(m15[max(0,i-799):i+1],t,[b for b in h1 if b.closed_at<=t][-250:])
    title = note.split("｜")[0]
    future = m15[i+1:i+5]
    complete=len(future)==4 and all(b.time==bar.closed_at+j*timedelta(minutes=15) for j,b in enumerate(future))
    if "跨休市，暂停评分" in title:
        records.append(dict(ny=t.isoformat(),title=title,status="scheduled_pause",four_bars_observed=complete))
        continue
    if not complete:
        records.append(dict(ny=t.isoformat(),title=title,status="future_gap"))
        continue
    # Same initialization as the production prefix, followed by exactly four new bars.
    path = detect_phases(m15[max(0,i-799):i+5],future[-1].closed_at)[-5:]
    current = path[0]["phase"]
    assert title.startswith("IPDA M15 "+NAMES[current])
    actual = next((r["phase"] for r in path[1:] if r["phase"] not in (current,"undetermined")),
                  current if path[-1]["phase"]==current else "undetermined")
    ranked = re.search(r"一小时候选 (?:维持)?(\S+) (\d+)/100",title)
    records.append(dict(ny=t.isoformat(),title=title,current=NAMES[current],actual=NAMES[actual],
                        status="ranked" if ranked else "abstain",forecast=ranked[1] if ranked else None,
                        score=int(ranked[2]) if ranked else None))
ranked=[r for r in records if r["status"]=="ranked"]
unknown=NAMES["undetermined"]
settled=[r for r in ranked if r["actual"]!=unknown]
allowed={NAMES[k]:{NAMES[p] for p in targets} for k,targets in DIRECT.items()}
transitions=[r for r in settled if r["actual"]!=r["current"]]
summary=dict(week=str(args.start),source=str(source.relative_to(ROOT)), resolved=len(settled),
             unresolved=len(ranked)-len(settled),
             skipped_edges=sum(r["actual"] not in allowed[r["current"]] for r in transitions),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
             schedule_ny=list(hours),status=dict(Counter(r["status"] for r in records)),
             boundary_times_ny=["16:00","16:45"] if source.suffix==".npz" else [],
             rank1=sum(r["forecast"]==r["actual"] for r in ranked),
             persistence=sum(r["current"]==r["actual"] for r in ranked),
             different=sum(r["current"]!=r["forecast"] for r in ranked),
             transition_hits=sum(r["forecast"]==r["actual"]!=r["current"] for r in ranked),
             transitions=len(transitions))
(dest/f"{args.start}_逐点核验.json").write_text(json.dumps(dict(summary=summary,records=records),ensure_ascii=False,indent=2),encoding="utf-8")
print(summary)
