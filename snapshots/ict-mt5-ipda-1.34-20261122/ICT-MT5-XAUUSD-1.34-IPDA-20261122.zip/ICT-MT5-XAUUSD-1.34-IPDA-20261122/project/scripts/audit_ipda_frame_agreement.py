"""Compare four closed-bar phase streams with the archived independent OHLC rubric."""
import json
import sys
from collections import Counter
from dataclasses import replace
from datetime import date, datetime, timedelta, timezone
from hashlib import sha256
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "output/research/ipda_four_cycle_validation_20261122"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(REFERENCE))
from reference_labels import label_market
from ict_ai.ipda_outlook import ny_four_hour_bars
import numpy as np
from ict_ai.ipda_reference.core import Bar, aggregate, load_bars
from ict_ai.ipda_reference.ipda_phases import detect_phases
from ict_ai.timebase import NY, manifest_epoch_to_utc


def evaluate(bars, monday, carry_maintenance=False, *, maintenance_atr=False):
    step = bars[0].seconds
    # The archived rubric measures distances in bars, using a 900-second index.
    # Scale elapsed time to that index so genuine gaps still reset its state.
    base = bars[0].time
    market = {}
    for b in bars:
        elapsed = int((b.time-base).total_seconds())
        key = elapsed*900//step
        market[key] = (b.open, b.high, b.low, b.close)
    control = label_market(market)
    if carry_maintenance:
        # Isolated candidate. Use the existing one-hour-gap option only inside
        # groups that can span a verified regular NY 17:00–18:00 maintenance.
        groups = []
        for bar in bars:
            if not groups:
                groups.append([])
            elif bar.time != groups[-1][-1].closed_at:
                end = groups[-1][-1].closed_at.astimezone(NY)
                if not (end.weekday()<4 and (end.hour,end.minute)==(17,0) and
                        bar.time-groups[-1][-1].closed_at==timedelta(hours=1)):
                    groups.append([])
            groups[-1].append(bar)
        live = [row for group in groups for row in
                detect_phases(group, group[-1].closed_at, timeframe_seconds=step, background_gap_seconds=3600)]
    else:
        live = detect_phases(bars, bars[-1].closed_at, timeframe_seconds=step, maintenance_atr=maintenance_atr)
    matrix = Counter()
    disagreements = Counter()
    for bar, row, ref in zip(bars, live, control, strict=True):
        if not monday <= bar.time.astimezone(NY).date() < monday + timedelta(days=5):
            continue
        assert row["known_at"] == bar.closed_at.isoformat()
        label, target = row["phase"], ref["phase"]
        matrix[target, label] += 1
        if target == label and label != "undetermined" and ref["side"] != row["direction"]:
            disagreements[label] += 1
    known = sum(v for (ref, _), v in matrix.items() if ref != "undetermined")
    agreed = sum(v for (ref, tag), v in matrix.items() if ref == tag != "undetermined")
    return dict(bars=sum(matrix.values()), reference_known=known, same_phase=agreed,
                same_phase_and_direction=agreed-sum(disagreements.values()),
                indicator_unknown=sum(v for (_, tag), v in matrix.items() if tag == "undetermined"),
                matrix={f"{ref}/{tag}": v for (ref, tag), v in sorted(matrix.items())})


if __name__ == "__main__":
    policy=json.loads((ROOT/"research/live_clock_20261116.json").read_bytes())
    report={"reference_sha256":sha256((REFERENCE/"reference_labels.py").read_bytes()).hexdigest(),
            "scope":"Indicator at close versus retrospective OHLC rubric; not independently human-labeled.", "weeks":{}}
    for folder, monday in [("TMGM_ICT_D1_basis_20261014_132250",date(2026,10,5)),
                           ("TMGM_XAU_extrema_close_20261121",date(2026,11,16))]:
        source=ROOT/"data/real"/folder/"XAUUSD_M5.csv"
        five=[replace(b,time=manifest_epoch_to_utc(b.time,policy)) for b in load_bars(source,300)]
        five=[b for b in five if monday-timedelta(days=9)<=b.time.astimezone(NY).date()<monday+timedelta(days=6)]
        cutoff=five[-1].closed_at
        frames={"M5":five,"M15":aggregate(five,900,cutoff),"H1":aggregate(five,3600,cutoff),
                "H4":ny_four_hour_bars(five,cutoff)}
        report["weeks"][str(monday)]={"source_sha256":sha256(source.read_bytes()).hexdigest(),
                                      "frames":{k:evaluate(v,monday) for k,v in frames.items()},
                                      "H1_regular_maintenance_trial":evaluate(frames["H1"],monday,True)}
    archive=ROOT/"output/research/dol_expansion_20261122"
    native=archive/"XAUUSDH1.npz"
    digest=sha256(native.read_bytes()).hexdigest()
    assert digest==json.loads((archive/"capture.json").read_bytes())["series"]["XAUUSDH1"]["sha256"]
    with np.load(native,allow_pickle=False) as dataset:
        native_bars=[Bar(manifest_epoch_to_utc(datetime.fromtimestamp(int(r["time"]),timezone.utc),policy),
                         *(float(r[k]) for k in ("open","high","low","close")),seconds=3600)
                     for r in dataset["rates"] if int(r["time"])>=datetime(2026,5,20,tzinfo=timezone.utc).timestamp()]
    report["native_H1"]={"source_sha256":digest,"weeks":{}}
    monday=date(2026,6,1)
    while monday<=date(2026,11,16):
        sample=[b for b in native_bars if monday-timedelta(days=9)<=b.time.astimezone(NY).date()<monday+timedelta(days=5)]
        if any(b.time.astimezone(NY).date()==monday for b in sample):
            report["native_H1"]["weeks"][str(monday)]={key:evaluate(sample,monday,trial) for key,trial in
                                                       (("original",False),("maintenance",True))}
            report["native_H1"]["weeks"][str(monday)]["maintenance_atr"]=evaluate(sample,monday,maintenance_atr=True)
        monday+=timedelta(days=7)
    output=ROOT/"output/research/ipda_frame_agreement.json"
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    for frame in frames:
        rows=[w["frames"][frame] for w in report["weeks"].values()]
        print(frame, {k:sum(r[k] for r in rows) for k in rows[0] if k!="matrix"})
    for week,w in report["weeks"].items():
        print(week, "H1 current vs maintenance", [(r["same_phase_and_direction"],r["reference_known"],r["indicator_unknown"])
              for r in (w["frames"]["H1"],w["H1_regular_maintenance_trial"])])
