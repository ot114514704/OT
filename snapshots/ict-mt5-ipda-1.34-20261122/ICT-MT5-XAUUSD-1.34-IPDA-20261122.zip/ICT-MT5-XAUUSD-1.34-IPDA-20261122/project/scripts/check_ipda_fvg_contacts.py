"""Verify phase evidence by reconstructing untouched FVG bounds from archived OHLC."""
from collections import Counter
from dataclasses import replace
from datetime import date, timedelta
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ict_ai.ipda_outlook import ny_four_hour_bars
from ict_ai.ipda_reference.core import aggregate, load_bars
from ict_ai.ipda_reference.ipda_phases import detect_phases
from ict_ai.timebase import NY, manifest_epoch_to_utc


def verify(bars, week):
    rows = detect_phases(bars, bars[-1].closed_at, timeframe_seconds=bars[0].seconds)
    counts = Counter()
    checked = set()
    start = 0
    for i, (b, row) in enumerate(zip(bars, rows, strict=True)):
        if i and bars[i-1].closed_at != b.time:
            start = i
        if b.time.astimezone(NY).date() < week:
            continue
        counts['bars'] += 1
        expected = []
        anchor = row['reference_before']
        old_count = 0
        if anchor:
            for j in range(start, i-2):
                first, third = bars[j], bars[j+2]
                up = anchor['direction'] == 1
                lo, hi = (first.high, third.low) if up else (third.high, first.low)
                if not (anchor['low'] <= lo < hi <= anchor['high'] and
                        first.time.isoformat() >= anchor['origin_at'] and b.low <= hi and b.high >= lo):
                    continue
                since = bars[j+3:i]
                if any(x.close < lo if up else x.close > hi for x in since):
                    continue
                old_count += 1
                left = lo if up else max([lo]+[x.high for x in since])
                right = min([hi]+[x.low for x in since]) if up else hi
                if left < right and b.high >= left and b.low <= right:
                    expected.append((first.time.isoformat(), left, right))
        actual = [(f['formed_at'], f['remaining_low'], f['remaining_high']) for f in row['pda_contacts']]
        assert actual == expected, (b.time, actual, expected)
        counts['valid_contacts'] += len(actual)
        counts['obsolete_contacts'] += old_count-len(actual)
        lost = old_count > 0 and not actual
        if row['phase']=='retracement' and lost:
            counts['retracement_bars_losing_support'] += 1
        case = (anchor['direction'],bool(actual),lost) if anchor else None
        if case and case not in checked:
            assert detect_phases(bars[:i+1], b.closed_at, timeframe_seconds=b.seconds)[-1] == row
            checked.add(case)
    return counts


if __name__ == '__main__':
    policy = json.loads((ROOT/'research/live_clock_20261116.json').read_bytes())
    result = {}
    for folder, week in [('TMGM_ICT_D1_basis_20261014_132250',date(2026,10,5)),
                         ('TMGM_XAU_extrema_close_20261121',date(2026,11,16))]:
        raw = load_bars(ROOT/'data/real'/folder/'XAUUSD_M5.csv')
        five = [replace(b,time=manifest_epoch_to_utc(b.time,policy)) for b in raw]
        five = [b for b in five if week-timedelta(days=7)<=b.time.astimezone(NY).date()<week+timedelta(days=5)]
        end = five[-1].closed_at
        frames = {'M5':five,'M15':aggregate(five,900,end),'H1':aggregate(five,3600,end),
                  'H4':ny_four_hour_bars(five,end)}
        result[str(week)] = {k:dict(verify(v,week)) for k,v in frames.items()}
    print(json.dumps(result,indent=2))
