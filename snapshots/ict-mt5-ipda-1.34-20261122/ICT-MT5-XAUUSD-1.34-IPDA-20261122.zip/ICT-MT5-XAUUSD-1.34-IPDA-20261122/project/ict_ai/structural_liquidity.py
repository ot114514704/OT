"""Merge standard MT5 candle periods into one dealing-range liquidity ranking."""
from bisect import bisect_left,bisect_right
from collections import defaultdict
from datetime import datetime,time,timedelta,timezone
from statistics import median

from .range_liquidity import M5,_Coverage
from .timebase import NY

ONE=timedelta(minutes=1)
MINUTES=(5,6,10,12,15,20,30,60,120,180,240,360,480,720)
DURATION={f'M{n}' if n<60 else f'H{n//60}':n for n in MINUTES}
EXTERNAL=('D1','W1','MN1')
ORDER={k:i for i,k in enumerate((*DURATION,*EXTERNAL))}
WEIGHT={k:13 if n<60 else 17 if n<=240 else 11 for k,n in DURATION.items()}
WEIGHT.update(D1=17,W1=15,MN1=14)


def trade_day(at):
    day=at.astimezone(NY).date()
    return day+timedelta(days=1) if day.weekday()==6 else day


def anchor_clusters(anchors,side,tolerance):
    groups={'ERL':[],'IRL':[]}
    for level in sorted(level for direction,level in anchors if direction==side):
        tags=anchors[side,level]
        scope='ERL' if any(tf in EXTERNAL for origin in tags.values() for tf,_ in origin) else 'IRL'
        lists=groups[scope]
        if not lists or level-lists[-1][0]>tolerance:
            lists.append([])
        lists[-1].append(level)
    for scope,lists in groups.items():
        for levels in lists:
            yield scope,levels


def external_bounds(day,frame):
    start=datetime.combine(day,time(),NY)
    if frame=='D1':
        finish=start.replace(hour=16,minute=55) if day.weekday()==4 else start+timedelta(days=1)
    elif frame=='W1':
        start-=timedelta(days=day.weekday())
        finish=start+timedelta(days=4,hours=16,minutes=55)
    else:
        start=start.replace(day=1)
        finish=(start+timedelta(days=32)).replace(day=1)
    return start.astimezone(timezone.utc),finish.astimezone(timezone.utc)


def grouped_extrema(rows, step, at, frames):
    groups={key:{} for key in frames}
    if not rows:
        return groups
    coverage=_Coverage(rows[0].time,at,rows,step)
    dates={}
    epoch_start=datetime(1970,1,1,tzinfo=timezone.utc)
    for i,b in enumerate(rows):
        local=b.time.astimezone(NY)
        minute=local.hour*60+local.minute
        utc_minute=(b.time-epoch_start)//ONE
        date=local.date()
        if date.weekday()<5 and date not in dates:
            dates[date]={k:external_bounds(date,k) for k in frames if k in EXTERNAL}
        for tf,parts in groups.items():
            if tf in EXTERNAL:
                if date.weekday()>=5:continue
                key=dates[date][tf]
            else:
                units=DURATION[tf]
                key=utc_minute-minute%units
            if key not in parts:
                parts[key]=[i,i]
            else:
                hi,lo=parts[key]
                if b.high>rows[hi].high:parts[key][0]=i
                if b.low<rows[lo].low:parts[key][1]=i
    periods={}
    for tf,parts in groups.items():
        result=[]
        for key,(hi,lo) in parts.items():
            if tf in EXTERNAL:
                start,finish=key
                if start<at<finish:
                    finish=at
            else:
                start=epoch_start+key*ONE
                finish=start+DURATION[tf]*ONE
            valid=rows[0].time<=start and finish<=at and not coverage.gap(start,finish)
            result.append((start,finish,rows[hi],rows[lo]) if valid else None)
        periods[tf]=(result,coverage)
    return periods


def swing_points(periods, coverage, side):
    index=2 if side==1 else 3
    field='high' if side==1 else 'low'
    def extreme(part):
        return side*getattr(part[index],field)
    i=1
    while i<len(periods)-1:
        if periods[i] is None:
            i+=1
            continue
        center=periods[i]
        j=i
        while j+1<len(periods) and periods[j+1] and extreme(periods[j+1])==extreme(center):
            j+=1
        left=periods[i-1]
        right=periods[j+1] if j+1<len(periods) else None
        if left and right and extreme(center)>max(extreme(left),extreme(right)) and not coverage.gap(left[0],right[1]):
            yield center[index]
        i=j+1


def micro_swing_span(rows, i, level, side):
    """Count five to ten consecutive closed M5 candles around an intact swing."""
    start, end = i - 2, i + 3
    if start < 0 or end > len(rows):
        return 0
    center = rows[i]

    def relative(bar):
        return side * ((bar.high if side == 1 else bar.low) - level)

    window = rows[start:end]
    if any(bar.time != center.time + (offset - 2) * M5 for offset, bar in enumerate(window)):
        return 0
    if relative(center) != 0 or any(relative(bar) > 0 for bar in window):
        return 0
    if not any(relative(bar) < 0 for bar in window[:2]) or not any(relative(bar) < 0 for bar in window[3:]):
        return 0
    while end - start < 10:
        if start > 0 and rows[start - 1].time + M5 == rows[start].time and relative(rows[start - 1]) <= 0:
            start -= 1
        elif end < len(rows) and rows[end - 1].time + M5 == rows[end].time and relative(rows[end]) <= 0:
            end += 1
        else:
            break
    return end - start


def structural_ranking(bars,at,dol=(),*,minute_bars=(),limit=10):
    """Rank two structural lists from M5 through MN1.

    D1, W1 and MN1 use range edges. M6 and M12 swings are grouped on the
    same M5 bucket as coarse anchors so aggregation cannot duplicate an extreme.
    """
    rows=[b for b in bars if b.time+M5<=at]
    if not rows or rows[-1].time+M5!=at:return []
    minutes=[b for b in minute_bars if rows[0].time<=b.time and b.time+ONE<=at]
    timestamps=[b.time for b in rows]
    coarse=[tf for tf,n in DURATION.items() if n%5==0]
    fine=[tf for tf,n in DURATION.items() if n%5!=0]
    periods=grouped_extrema(rows,M5,at,[*coarse,*EXTERNAL])
    if minutes:
        periods.update(grouped_extrema(minutes,ONE,at,fine))
    upper=[float('-inf')]*(len(rows)+1)
    lower=[float('inf')]*(len(rows)+1)
    for i in reversed(range(len(rows))):
        upper[i]=max(upper[i+1],rows[i].high)
        lower[i]=min(lower[i+1],rows[i].low)
    minute_times=[b.time for b in minutes]
    anchors=defaultdict(lambda:defaultdict(set))
    price=rows[-1].close
    coverage=periods['H1'][1]
    reference={}
    micro_spans={}

    def add(bar,side,tf,tag):
        level=bar.high if side==1 else bar.low
        i=bisect_right(timestamps,bar.time)-1
        if side*(level-price)<=0 or coverage.gap(timestamps[i],at):return
        bar_extreme=rows[i].high if side==1 else rows[i].low
        if tf in fine and side*(bar_extreme-level)>0:
            nearby=minutes[bisect_right(minute_times,bar.time):bisect_left(minute_times,timestamps[i]+M5)]
            if any(side*((b.high if side==1 else b.low)-level)>0 for b in nearby):return
            if bar_extreme!= (max if side==1 else min)(
                    (b.high if side==1 else b.low for b in minutes[bisect_left(minute_times,timestamps[i]):bisect_left(minute_times,timestamps[i]+M5)]),
                    default=level):
                return
        if (upper[i+1]>level if side==1 else lower[i+1]<level):return
        if tf in DURATION and DURATION[tf]<=12:
            key=(side,i,level)
            if key not in micro_spans:
                micro_spans[key]=micro_swing_span(rows,i,level,side)
            if not micro_spans[key]:
                return
        anchors[side,level][i].add((tf,tag))

    for tf,(entries,source_coverage) in periods.items():
        if tf in EXTERNAL:
            for p in entries:
                if p is None:continue
                start,finish,hi,lo=p
                reference[tf]=(lo.low,hi.high,start)
                if tf == 'D1' and finish < external_bounds(start.astimezone(NY).date(),tf)[1]:
                    continue
                suffix=start.astimezone(NY).strftime('%Y-%m-%d')
                add(hi,1,tf,'纽约区间高 ERL '+suffix)
                add(lo,-1,tf,'纽约区间低 ERL '+suffix)
        else:
            for side in (1,-1):
                for b in swing_points(entries,source_coverage,side):
                    add(b,side,tf,'摆动高' if side==1 else '摆动低')
    ranges=[p[2].high-p[3].low for p in periods['H1'][0] if p and p[2].high>p[3].low][-24:]
    if not ranges:return []
    typical=median(ranges)
    tolerance=max(.01,.08*typical)
    today=trade_day(at-M5)
    prior_day=today-timedelta(days=3 if today.weekday()==0 else 1)
    origin_days=[trade_day(t) for t in timestamps]
    ranked=[]
    for side in (1,-1):
        clusters=list(anchor_clusters(anchors,side,tolerance))
        route=sorted(levels[0] if side==1 else -levels[-1] for _,levels in clusters)
        targets=[p for p in dol if p['side']==side]
        alignment=next((p['score_components']['alignment'] for p in targets
                        if 'alignment' in p.get('score_components',{})),None)
        context=0 if alignment is None else max(0,min(6,round((alignment-12)/3)))
        gaps=[p for p in targets if 'FVG 剩余区' in p.get('source','')]
        for scope,levels in clusters:
            lo,hi=levels[0],levels[-1]
            containing=[(tf,a,b,stamp) for tf,(a,b,stamp) in reference.items()
                        if a<lo<=hi<b and a<=price<=b]
            if scope=='IRL' and not containing:
                continue
            origins=defaultdict(set)
            for level in levels:
                for i,tags in anchors[side,level].items():
                    origins[i].update(tags)
            frames=sorted({tf for tags in origins.values() for tf,_ in tags},key=ORDER.get)
            near=lo if side==1 else hi
            far=hi if side==1 else lo
            distance=abs(near-price)
            groups={0 if DURATION.get(tf,1440)<60 else 1 if tf not in EXTERNAL else 2 for tf in frames}
            votes=[p for p in targets if lo-.005<=(p['lo'] if side==1 else p['hi'])<=hi+.005]
            independent=[]
            for i in sorted(origins,key=lambda i:(-max(WEIGHT[tf] for tf,_ in origins[i]),-i)):
                if all(abs(timestamps[i]-timestamps[j])>=5*M5 for j in independent):
                    independent.append(i)
            newest=max(origin_days[i] for i in origins)
            recency=12 if newest==today else 7 if newest==prior_day else 0
            obstacles=bisect_left(route,side*near-.005)
            parts=dict(structure=max(WEIGHT[k] for k in frames)+recency,
                       anchors=min(19,7+6*(len(independent)-1)),frames=4*(len(groups)-1),
                       reach=int(.5+27/(1+distance/(3*typical))),dol=7 if votes else 0,
                       path=max(0,4-obstacles),context=context)
            sources=sorted({tf+' '+tag for tags in origins.values() for tf,tag in tags})
            if recency:sources.append('纽约当日锚点' if newest==today else '前一交易日锚点')
            confirmed_m5=max((micro_spans.get((side,i,level),0) for level in levels
                              for i in anchors[side,level]),default=0)
            if confirmed_m5:
                sources.append(f'{confirmed_m5} 根已收 M5 确认')
            if containing and scope=='IRL':
                tf,a,b,stamp=containing[0]
                sources.append(f'参照 {tf} {stamp.astimezone(NY):%m-%d} {a:.2f}–{b:.2f}')
            for tf,(a,b,_) in reference.items():
                if a<=price<=b:
                    where='区间内' if a<lo and hi<b else '跨外沿' if a<=near<=b and (far<a or far>b) else '外沿或区间外'
                    sources.append(f'{tf} {where}')
            sources.append(f'同侧更近流动性 {obstacles} 层')
            earlier_gap=next((p for p in sorted(gaps,key=lambda p:p['distance'])
                              if p['distance']<distance),None)
            if earlier_gap:
                sources.append(f'到达前有待回补 FVG {earlier_gap["lo"]:.2f}–{earlier_gap["hi"]:.2f}')
            if targets and 'reason' in targets[0]:
                sources.extend(targets[0]['reason'].split('；')[1:3])
            short=frames if len(frames)<=5 else frames[:1]+frames[-3:]
            ranked.append(dict(side=side,lo=lo,hi=hi,score=sum(parts.values()),distance=distance,classification=scope,
                               source='/'.join(short),sources=sources,timeframes=frames,origins=len(independent),
                               hourly_range=typical,anchor_times=[timestamps[i].isoformat() for i in sorted(independent)],
                               components=parts,dol_rank=min((p['rank'] for p in votes),default=None)))
    ranked.sort(key=lambda p:(-p['score'],p['distance'],p['lo'],p['hi']))
    results=[]
    for scope in ('IRL','ERL'):
        selected=[p for p in ranked if p['classification']==scope][:limit]
        for rank,p in enumerate(selected,1):
            p['rank']=rank
        results.extend(selected)
    return results
