"""Prospective DOL checkpoints and subsequent observed XAU price contacts."""
from bisect import bisect_left, bisect_right
from datetime import datetime, timedelta, timezone
import hashlib
import json
import sqlite3

from .dol_outlook import M5, outlook
from .po3 import po3_zones
from .profile_lifecycle import _day_bounds, daily_profile_lifecycle
from .range_liquidity import _Coverage
from .timebase import NY, session_windows, daily_profile_history_start


def week_start(day):
    return day+timedelta(days=1) if day.weekday()==6 else day-timedelta(days=day.weekday())


def batch_id(at, price, targets):
    raw=json.dumps([at.isoformat(),price,targets],sort_keys=True,separators=(',',':'))
    return hashlib.sha256(raw.encode()).hexdigest()


def chart_receipts(directory, now):
    # Logs are appended by MT5 in UTC, including across the midnight boundary.
    if not directory.is_dir():
        return {}
    received={}
    for path in sorted(directory.glob('????.??.??.tsv')):
        try:
            lines=path.read_bytes().decode('utf-8').splitlines(keepends=True)
        except PermissionError:
            continue  # MT5 is appending; the next poll will read the durable record.
        for line in lines:
            fields=line.rstrip().split('\t')
            if not line.endswith('\n') or len(fields)!=2:continue
            key,epoch=fields
            if len(key)!=64 or not epoch.isascii() or not epoch.isdigit() or len(epoch)>10:continue
            stamp=datetime.fromtimestamp(int(epoch),timezone.utc)
            if stamp<=now and (key not in received or stamp<received[key]):
                received[key]=stamp
    return received


def live_reviews(path, at, now, price, targets, bars, receipts):
    """Stage the exact ranks. Only chart-acknowledged batches enter forward reviews."""
    path.parent.mkdir(parents=True, exist_ok=True)
    db=sqlite3.connect(path, timeout=5)
    try:
        with db:
            db.execute("CREATE TABLE IF NOT EXISTS chart_batches(id TEXT PRIMARY KEY, cutoff TEXT, received TEXT, payload TEXT NOT NULL)")
            db.execute("CREATE INDEX IF NOT EXISTS batch_cutoff ON chart_batches(cutoff)")
            db.execute("CREATE TABLE IF NOT EXISTS chart_reviews(scope TEXT, stamp TEXT, body TEXT, PRIMARY KEY(scope,stamp))")
            day=(at-M5).astimezone(NY).date()
            active=timedelta(0)<=now-at<2*M5 and day.weekday()!=5
            if active:
                payload=json.dumps(dict(at=at.isoformat(),price=price,targets=targets),ensure_ascii=False)
                db.execute("INSERT OR IGNORE INTO chart_batches VALUES (?,?,NULL,?)",(batch_id(at,price,targets),at.isoformat(),payload))
            for key,cut in db.execute("SELECT id,cutoff FROM chart_batches WHERE received IS NULL").fetchall():
                ack=receipts.get(key)
                if ack is not None and datetime.fromisoformat(cut)<=ack<=now:
                    db.execute("UPDATE chart_batches SET received=? WHERE id=?",(ack.isoformat(),key))
            # Re-evaluate the current and previous trading week across weekend/restart.
            monday=week_start(day)-timedelta(days=8)
            floor=_day_bounds(monday)[0]
            history=[]
            for raw,stamp in db.execute("SELECT payload,received FROM chart_batches WHERE cutoff>=? AND received IS NOT NULL ORDER BY received,cutoff,id",(floor.isoformat(),)):
                snapshot=json.loads(raw)
                received=datetime.fromisoformat(stamp)
                if received-datetime.fromisoformat(snapshot['at'])>=2*M5:
                    continue
                snapshot['published_at']=stamp
                history.append(snapshot)
            summaries,_=settle(history,bars,now)
            # Replace even an empty reviewed day/week when a quote correction
            # removes its last hit or its only contact was after the deadline.
            reviewed_days={(datetime.fromisoformat(s['at'])-M5).astimezone(NY).date() for s in history}
            keys={('day',d.isoformat()) for d in reviewed_days}
            keys.update(('week',week_start(d).isoformat()) for d in reviewed_days)
            db.executemany('DELETE FROM chart_reviews WHERE scope=? AND stamp=?',keys)
            db.executemany("INSERT OR REPLACE INTO chart_reviews VALUES (?,?,?)",
                           [(s,d,json.dumps(v,ensure_ascii=False)) for (s,d),v in summaries.items()])
            return {(s,d):json.loads(v) for s,d,v in db.execute("SELECT scope,stamp,body FROM chart_reviews")}
    finally:
        db.close()


def forecast(m5, h1, m15, at, peers, news, judas, *, nearby_priority=False):
    day=(at-M5).astimezone(NY).date()
    reopening=day.weekday()==6
    if reopening:
        day+=timedelta(days=1)  # Sunday reopening is the lead-in to Monday's NY profile.
    a,z=session_windows(day)['asia']
    start=daily_profile_history_start(day)
    if reopening:
        start=min(start,_day_bounds(day-timedelta(days=1))[0]+timedelta(hours=18))
    core=[b for b in m5 if start<=b.time and b.time+M5<=at]
    quarters=[b for b in m15 if start<=b.time and b.time+3*M5<=at]
    profile=daily_profile_lifecycle(quarters,day,at,reference_m5=core,include_reconstruction=False)
    phases=po3_zones(quarters,a,z,_day_bounds(day)[1],at)
    ranked=[]
    rows=outlook(m5,h1,quarters,at,profile,phases,peers,releases=news,judas=judas,
                 ranked=ranked,nearby_priority=nearby_priority)
    return rows,ranked


def _deadline(at):
    day = (at-M5).astimezone(NY).date()
    return min(at+timedelta(hours=4), _day_bounds(day)[1])


def settled_summaries(snapshots):
    """Render frozen ranks and recorded contacts without re-scoring history."""
    summaries={}
    for snap in snapshots:
        at=datetime.fromisoformat(snap['at'])
        published=datetime.fromisoformat(snap.get('published_at',snap['at']))
        day=(at-M5).astimezone(NY).date()
        monday=week_start(day)
        day_end=_day_bounds(day)[1]
        week_end=_day_bounds(monday+timedelta(days=4))[1]
        deadline=_deadline(at)
        for p in snap['targets']:
            side,lo,hi=p['side'],p['lo'],p['hi']
            hits=[datetime.fromisoformat(t) if t else None for t in p['touches']]
            hit=hits[0]
            if hit is None or hit>deadline:continue
            for scope,key,end in [('day',day,day_end),('week',monday,week_end)]:
                if hit>end:continue
                group=summaries.setdefault((scope,str(key)),{})
                identity=(side,lo,hi,p['source'])
                if identity in group:continue
                when=hit.astimezone(NY)
                clock=(f'{published.astimezone(NY):%m-%d %H:%M:%S} 图表收到（依据 {at.astimezone(NY):%H:%M}）'
                       if 'published_at' in snap else f'{at.astimezone(NY):%m-%d %H:%M} 历史重建')
                detail=f'{clock} #{p["rank"]} {p["score"]}分 · {p["source"]} {lo:.2f}'
                if hi!=lo:detail+=f'–{hi:.2f}'
                detail+=f' → {when:%m-%d %H:%M} M5 已见触达（期限内，截止 {deadline.astimezone(NY):%m-%d %H:%M}）；{p["reason"]}'
                if hi!=lo:
                    for tag,t in zip(('中点','远端'),hits[1:]):
                        detail+=f'；{tag} '+(t.astimezone(NY).strftime('%m-%d %H:%M') if t and t<=end else '期内未见')
                group[identity]=detail
    return {k:list(rows.values()) for k,rows in summaries.items()}


def _levels(target):
    lo,hi=target['lo'],target['hi']
    if lo==hi:
        return (lo,)
    return (lo,(hi+lo)/2,hi) if target['side']==1 else (hi,(hi+lo)/2,lo)


def settle(snapshots,bars,as_of):
    if not snapshots:
        return {}, {}
    times=[b.time for b in bars]
    cutoffs=[datetime.fromisoformat(s['at']) for s in snapshots]
    coverage=_Coverage(min(cutoffs),min(as_of,max(_deadline(t) for t in cutoffs)),bars,M5)
    # Index only requested levels and closed bars, once per settlement batch.
    prices=sorted({level for snap in snapshots for p in snap['targets'] for level in _levels(p)})
    contacts={level:[] for level in prices}
    for bar in bars[bisect_left(times,min(cutoffs)):bisect_right(times,as_of-M5)]:
        for level in prices[bisect_left(prices,bar.low):bisect_right(prices,bar.high)]:
            contacts[level].append(bar.time)
    stats={}
    for snap,at in zip(snapshots,cutoffs):
        published=max(at,datetime.fromisoformat(snap.get('published_at',snap['at'])))
        day=(at-M5).astimezone(NY).date()
        day_end=_day_bounds(day)[1]
        week_end=_day_bounds(week_start(day)+timedelta(days=4))[1]
        stop=_deadline(at)
        # Aggregate outcomes and first-arrival comparisons require a fully observed
        # opportunity, including the opening partial candle after a chart receipt.
        missing=coverage.gap(published,stop)
        if published!=at and published<stop:
            elapsed=(published-at)%M5
            if elapsed:
                partial_time=published-elapsed
                i=bisect_left(times,partial_time)
                if i==len(bars) or times[i]!=partial_time:
                    missing=True
                elif partial_time+M5<=as_of:
                    bar=bars[i]
                    missing |= any(bar.low <= (p['lo'] if p['side']==1 else p['hi']) <= bar.high
                                   for p in snap['targets'])
        opportunity=(bisect_right(coverage.expected,stop-M5)>bisect_left(coverage.expected,published)
                     or bisect_right(times,stop-M5)>bisect_left(times,published))
        eligible=as_of>=stop and published<stop and opportunity and not missing
        first_touches=[]
        for p in snap['targets']:
            hits=[]
            for level in _levels(p):
                stamps=contacts[level]
                i=bisect_left(stamps,published)
                hits.append(stamps[i]+M5 if i<len(stamps) and stamps[i]+M5<=week_end else None)
            hit=hits[0]
            first_touches.append(hit)
            p['touches']=[t.isoformat() if t else None for t in hits]
            p['horizon_status']=('observed_hit' if hit and hit<=stop else 'open' if as_of<stop else
                                 'unverified' if not eligible else 'observed_late' if hit else 'no_hit')
            for scope,end in [('day',day_end),('week',week_end)]:
                p[scope]='observed_hit' if hit is not None and hit<=end else 'no_observed_hit' if as_of>=end else 'open'
            if eligible:
                bucket=str(p['score']//10*10)
                counts=stats.setdefault(bucket,{'listed':0,'hit_within_horizon':0})
                counts['listed']+=1
                counts['hit_within_horizon']+=int(hit is not None and hit<=stop)
        first_hit=min((t for t in first_touches if eligible and t and t<=stop),default=None)
        leaders=[p for p,t in zip(snap['targets'],first_touches) if first_hit and t==first_hit]
        if len(leaders)>1:
            opening=bars[bisect_left(times,first_hit-M5)].open
            at_open=[p for p in leaders if abs(_levels(p)[0]-opening)<1e-8]
            leaders=at_open or leaders
        snap['first_ranks']=[p['rank'] for p in leaders]
        ranks=snap['first_ranks']
        first_levels={_levels(p)[0] for p in leaders}
        snap['first_touch_status']=('no_targets' if not snap['targets'] else 'open' if as_of<stop else
                                   'expired_before_observation' if published>=stop else
                                   'no_observation_window' if not opportunity else
                                   'insufficient_coverage' if missing else 'no_hit' if not ranks else
                                   'unique' if len(ranks)==1 else 'same_level' if len(first_levels)==1 else 'same_m5_bar')
    return settled_summaries(snapshots),stats
