"""Intraday hypotheses followed by an explicitly separate closed-day review.

时间（二）PPT 16–22 and 时间（三）10–15 / weekly guide 61–63.
Two closed-bar extensions and small-body thresholds are engineering choices.
Price-path confirmation does not verify prior bias/PDA/DOL or news causality.
"""
from datetime import datetime, time, timedelta, timezone
from math import isclose

from .timebase import NY, session_windows
from .profile_sources import course_reference, profile_source, WEEKLY
from .amd import amd_events
from .weekly_path import consolidation_evidence
from .range_liquidity import M5, _m5_reference_day


def _day_bounds(day):
    start = datetime.combine(day, time(0), NY).astimezone(timezone.utc)
    end = datetime.combine(day, time(17), NY) if day.weekday() == 4 else datetime.combine(day+timedelta(days=1), time(0), NY)
    return start, end.astimezone(timezone.utc)


def _complete(part, start, end, period):
    return len(part) == int((end-start)/period) and all(b.time == start+i*period for i,b in enumerate(part))


def _study_recess(at):
    # Explicit research calendar, not a verified historical broker schedule.
    return at.astimezone(NY).hour == 17


def _coverage(part, start, end, period):
    present={b.time for b in part}
    at=start
    while at+period<=end:
        if not _study_recess(at) and at not in present:
            return False
        at+=period
    return bool(part)


def _continuous(previous, current, period):
    at=previous+period
    while at<current:
        if not _study_recess(at):
            return False
        at+=period
    return at==current


def _reclaim(part, level, side, period=timedelta(minutes=15)):
    breached = False
    previous = None
    for b in part:
        if previous is not None and not _continuous(previous.time,b.time,period):
            breached=False
        breached |= b.high > level if side == 1 else b.low < level
        if breached and (b.close < level if side == 1 else b.close > level):
            return b
        previous=b
    return None


def _broken(part, reclaim, direction, reclaim_end=None):
    """Freeze the extreme known at reclaim; later extremes invalidate it."""
    if reclaim is None:
        return False
    before=[b for b in part if b.time<reclaim_end] if reclaim_end else [b for b in part if b.time<=reclaim.time]
    after=[b for b in part if b.time>=reclaim_end] if reclaim_end else [b for b in part if b.time>reclaim.time]
    if not before:
        return False
    edge=min(b.low for b in before) if direction==1 else max(b.high for b in before)
    return any(b.low<edge if direction==1 else b.high>edge for b in after)


def _extreme_reclaim(part, level, breach_side, period):
    """A new session extreme needs its own closed-bar return across the frozen boundary."""
    extreme = level
    pending = False
    confirmed = previous = None
    for bar in part:
        if previous is not None and not _continuous(previous.time, bar.time, period):
            pending = False
        price = bar.high if breach_side == 1 else bar.low
        if breach_side * (price - extreme) > 0:
            extreme = price
            pending = True
        if pending and breach_side * (bar.close - level) < 0:
            confirmed = bar
            pending = False
        previous = bar
    return confirmed


def _extension(part, level, side, period, after=None):
    previous = None
    for b in part:
        if after is not None and b.time < after:
            continue
        outside = b.close > level if side == 1 else b.close < level
        if outside and previous is not None and b.time == previous.time+period:
            return b
        previous = b if outside else None
    return None


def _weekly_background(rows, day, cutoff, period):
    monday = day-timedelta(days=day.weekday())
    summaries = []
    for i in range(day.weekday()):
        d = monday+timedelta(days=i); start, end = _day_bounds(d)
        part = [b for b in rows if start <= b.time < end]
        if cutoff < end or not _coverage(part,start,end,period):
            continue
        summaries.append({'date': d.isoformat(), 'high': max(b.high for b in part),
                          'low': min(b.low for b in part), 'close': part[-1].close,
                          'midnight_open_present': part[0].time == start})
    label = '周背景待形成'; reason = '周初完整交易日尚不足；星期本身不能确认极点。'; direction = None
    sources = {'course_slides': [10,11,12,13,14,15], 'guide_pages': [61,62,63], 'free_guide_pages': [2,3,4,5,6,7]}
    today_start, _ = _day_bounds(day)
    today = [b for b in rows if today_start <= b.time]
    if summaries:
        high = max(d['high'] for d in summaries); low = min(d['low'] for d in summaries)
        reason = f'此前已结束日的已观察周范围 {low:.2f}–{high:.2f}；该范围不含未来交易日。'
        label = '周初范围：延续与反转待区分'
        reclaim_for_day = _extreme_reclaim if day.weekday() in (1,2) else _reclaim
        down = reclaim_for_day(today, low, -1,period); up = reclaim_for_day(today, high, 1,period)
        down=down if not _broken(today,down,1) else None
        up=up if not _broken(today,up,-1) else None
        if down and not up:
            direction = 1; label = ('周三' if day.weekday()==2 else '周四' if day.weekday()==3 else '当日')+'扫低回收 · 看涨反转候选'
            reason += ' 今日越过下边界后已有收盘回收；尚待 HTF PDA、交付变化及后续扩张。'
        elif up and not down:
            direction = -1; label = ('周三' if day.weekday()==2 else '周四' if day.weekday()==3 else '当日')+'扫高回收 · 看跌反转候选'
            reason += ' 今日越过上边界后已有收盘回收；尚待 HTF PDA、交付变化及后续扩张。'
        elif up and down:
            label = '周范围双向回收 · 反转与震荡待区分'
        elif {monday.isoformat(),(monday+timedelta(days=1)).isoformat()} <= {d['date'] for d in summaries}:
            by_date={d['date']:d for d in summaries}
            m,t = by_date[monday.isoformat()],by_date[(monday+timedelta(days=1)).isoformat()]
            later=[b for b in rows if b.time.astimezone(NY).date()>monday+timedelta(days=1)]
            low_held=t['low']<m['low'] and t['close']>m['low'] and not any(b.low<t['low'] for b in later)
            high_held=t['high']>m['high'] and t['close']<m['high'] and not any(b.high>t['high'] for b in later)
            # Each already-completed midweek close is a necessary part of the
            # Tuesday expansion path. A still-open day's price cannot rule it out.
            previous=t
            for index in range(2,day.weekday()):
                finished=by_date.get((monday+timedelta(days=index)).isoformat())
                if finished is None:
                    low_held=high_held=False
                    break
                low_held=low_held and finished['close']>previous['close']
                high_held=high_held and finished['close']<previous['close']
                previous=finished
            if low_held and high_held:
                label='周二双向扫荡 · 扩张方向待分'
            elif low_held:
                direction=1; label='周二扫低回收 · 经典扩张候选'
            elif high_held:
                direction=-1; label='周二扫高回收 · 经典扩张候选'
            elif t['high']<=m['high'] and t['low']>=m['low']:
                label='周初盘整 · 周中反转 / 后续扩张待分'
        return {'label':label,'reason':reason,'scenario_direction':direction,'prior_range':{'low':low,'high':high},
                'sources':sources,'as_of':cutoff.isoformat(),'prior_bias_verified':False,'final_week_extreme_known':False}
    return {'label':label,'reason':reason,'scenario_direction':direction,'sources':sources,
            'as_of':cutoff.isoformat(),'prior_bias_verified':False,'final_week_extreme_known':False}


def _live_profile_cards(cards, *, daily):
    active = [card for card in cards if card['status'] == 'active' and card['observed_sequence']]
    if daily:
        specific = [card for card in active if card['id'] not in
                    ('consolidation_expansion', 'news_manipulation_expansion')]
        active = specific or active
    return active[:2]


def profile_hover_detail(profile, *, include_references=True):
    detail = profile['profile_reason']
    if profile.get('coverage_complete_under_study_calendar') is False:
        return detail
    mode = profile['mode']
    cards = profile['candidates']
    if mode == 'closed_review':
        if profile['profile_status'] == 'confirmed_path':
            selected = [card for card in cards if card['path_matched']]
        elif profile['profile_status'] == 'closed_partial':
            selected = [card for card in cards if card['status'] == 'active' and card['observed_sequence']][:2]
        else:
            return detail
    elif mode == 'closed_week_review':
        selected = profile.get('realized_candidates', [])[:2]
    else:
        selected = _live_profile_cards(cards, daily=mode == 'intraday_hypothesis')

    weekly = mode in ('closed_week_review', 'intraweek_hypothesis')
    references = []
    for card in selected:
        if not card.get('observed_sequence'):
            continue
        reference = course_reference(card.get('id'), weekly) if include_references else None
        if reference and reference not in references:
            references.append(reference)
        sequence = card.get('price_sequence')
        if sequence:
            times = []
            for key, label in [('range_available_at', '确认盘整范围'),
                               ('sweep_reclaim_available_at', '扫荡后收回'),
                               ('expansion_available_at', '连续两根收盘确认扩张')]:
                if sequence.get(key):
                    stamp = datetime.fromisoformat(sequence[key]).astimezone(NY)
                    times.append(f'{stamp:%H:%M} {label}')
            side = '向上' if card['direction'] == 1 else '向下'
            detail += f'｜美东时间（{side}路径） ' + ' → '.join(times)
            detail += '。两根收盘为本项目识别条件，新闻关联待核实。'
    if references:
        course = '时间（三）' if weekly else '时间（二）'
        detail += f'｜课件对照《{course}》 ' + ' / '.join(references)
    return detail


def profile_brief_reason(lifecycle):
    """Explain only the selected, observed state; never promote fallback scenarios."""
    if not lifecycle:
        return '等待已收盘行情。'
    basis=lifecycle.get('daily_price_basis',{})
    if basis.get('study_calendar_contradicted'):
        return '实际报价超出假设收盘时段，须核对交易日历后再确认形态。'
    if basis.get('aggregate_matches_source') is False:
        return '分析 K 线与 M5 原始行情不一致，暂不确认形态。'
    if lifecycle.get('coverage_complete_under_study_calendar') is False:
        return '报价覆盖不完整，暂不确认完整形态。'
    closed=lifecycle.get('mode') in ('closed_review','closed_week_review')
    cards=lifecycle.get('realized_candidates',[]) if lifecycle.get('mode')=='closed_week_review' else lifecycle.get('candidates',[])
    if lifecycle.get('mode')=='closed_review':
        chosen=[c for c in cards if c.get('path_matched')]
        if not chosen:
            # Keep an observed partial path visible instead of collapsing it
            # into the same generic label as a day with no usable sequence.
            # This is a classification aid only; it never promotes the path
            # to a confirmed ICT profile.
            partial=[c for c in cards if c.get('status')=='active' and c.get('observed_sequence')]
            if partial:
                reasons=[]
                for card in partial[:2]:
                    evidence=(card.get('evidence') or '').split('。')[0]
                    awaiting=(card.get('awaiting') or '').split('。')[0]
                    if evidence:
                        text=f"{card.get('label','候选')}：{evidence}。"
                        if card.get('close_followthrough_review'):
                            text+=card['close_followthrough_review']
                        elif awaiting:text+=f"尚缺{awaiting}。"
                        reasons.append(text)
                text=' '.join(reasons) or '已观察到部分路径，但完整条件尚未齐备。'
                if basis.get('close') is not None:text+=f" 日收 {basis['close']:.2f}（M5）。"
                return text
            text='当日已结束；越界回收、后续扩张或最终收盘条件未形成完整匹配。'
            checks=lifecycle.get('session_price_checks')
            if checks:
                if not checks['london_sweep_low_reclaim'] and not checks['london_sweep_high_reclaim']:
                    text+='伦敦未形成对亚洲边界的越界回收。'
                if not checks['ny_two_closes_above_london'] and not checks['ny_two_closes_below_london']:
                    text+='纽约未出现向伦敦范围外的两根连续收盘。'
                if checks['daily_open'] is not None:
                    text+=f" 日 O/C {checks['daily_open']:.2f}/{checks['daily_close']:.2f}。"
            return text
    elif lifecycle.get('mode')=='closed_week_review':
        reasons=[c['reason'].split('。')[0]+'。' for c in cards if c.get('reason')]
        return ' '.join(reasons[:2]) or '周已结束，已观察价格路径不足以确定周型。'
    else:
        chosen=_live_profile_cards(cards, daily=lifecycle.get('mode')=='intraday_hypothesis')
    if not chosen:
        return ('此前候选已触发失效条件，等待新的完整路径。' if any(c.get('status')=='invalidated' for c in cards)
                else '已收盘路径尚不足以区分典型概况，继续观察范围、回收与扩张。')
    reasons=[]
    for card in chosen[:2]:
        evidence=card.get('evidence') or card.get('reason')
        if evidence:
            sentence=evidence.split('。')[0]+'。'
            if closed and card.get('confirmation_evidence'):
                sentence+=card['confirmation_evidence']
            if sentence not in reasons:reasons.append(sentence)
    text=' '.join(reasons) or '现有证据不足，保留未归类。'
    if lifecycle.get('mode')=='closed_review' and basis.get('close') is not None:
        text+=f" 日收 {basis['close']:.2f}（M5）。"
    if not closed:text+=' 后续延续待验证。'
    if len(chosen)>1:text+=' 存在形态重叠，暂不强行单选。'
    return text


def _daily_reference(core, reference_m5, day, cutoff, period):
    """Use actual M5 prices without turning an incomplete M15 bucket into a bar.

    Session/reclaim/two-close evidence remains on the analysis timeframe.
    Daily final prices and wick invalidations use the finer source. Matching
    full analysis bars are required, so an unrelated source cannot certify it.
    """
    if period<M5 or period % M5:
        raise ValueError('M5 reference requires an analysis period divisible by five minutes')
    if any(b.time.tzinfo is None or b.time.second or b.time.microsecond or b.time.minute%5 for b in reference_m5):
        raise ValueError('Aware aligned M5 reference required')
    if any(a.time>=b.time for a,b in zip(reference_m5,reference_m5[1:])):
        raise ValueError('Unique chronological M5 reference required')
    audit=_m5_reference_day(reference_m5,day,cutoff)
    prices=audit['bars']; end=min(cutoff,audit['end']); by_time={b.time:b for b in prices}
    count=int(period/M5); matched=True
    for bar in core:
        part=[by_time.get(bar.time+i*M5) for i in range(count)]
        if not all(part):
            matched=False;break
        expected=(part[0].open,max(b.high for b in part),min(b.low for b in part),part[-1].close)
        if not all(isclose(x,y,rel_tol=0,abs_tol=1e-8) for x,y in zip((bar.open,bar.high,bar.low,bar.close),expected)):
            matched=False;break
    source_covered=_coverage(prices,audit['start'],end,M5)
    analysis_covered=_coverage(core,audit['start'],end,period)
    # Unexpected quoted bars after the assumed Friday close contradict that
    # research calendar. Do not silently discard them and certify a full day.
    session_end=_day_bounds(day)[1]
    unexpected=any(audit['end']<=b.time<session_end and b.time+M5<=cutoff for b in reference_m5)
    covered=source_covered and analysis_covered and matched and not unexpected
    summary={'source_period_minutes':5,'analysis_period_minutes':period.total_seconds()/60,
             'open':prices[0].open if prices and prices[0].time==audit['start'] else None,
             'high':max((b.high for b in prices),default=None),'low':min((b.low for b in prices),default=None),
             'close':prices[-1].close if prices else None,
             'last_close_at':(prices[-1].time+M5).isoformat() if prices else None,
             'expected_end':audit['end'].isoformat(),'source_coverage_complete':source_covered,
             'analysis_coverage_complete':analysis_covered,'aggregate_matches_source':matched,
             'study_calendar_contradicted':unexpected,
             'unaggregated_closed_m5':sum(b.time>=core[-1].time+period for b in prices) if core else len(prices),
             'historical_calendar_verified':False,'partial_analysis_bars_created':False}
    return prices,audit['end'],covered,summary


def daily_profile_lifecycle(bars, day, as_of, period=timedelta(minutes=15), include_reconstruction=True, *,
                            reference_m5=None, research_late_classic_and_longer_range=False,
                            research_ny_reclaim=False):
    if as_of.tzinfo is None or period<=timedelta(0) or day.weekday()>4:
        raise ValueError('Aware cutoff, positive period and weekday required')
    if any(a.time>=b.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Unique chronological bars required')
    start,end = _day_bounds(day); cutoff=min(as_of,end)
    rows=[b for b in bars if b.time+period<=cutoff]
    core=[b for b in rows if start<=b.time<end]
    weekly=_weekly_background(rows,day,cutoff,period)
    ended=as_of>=end
    result={'mode':'closed_review' if ended else 'intraday_hypothesis','as_of':cutoff.isoformat(),
            'day_end':end.isoformat(),'weekly_background':weekly,'candidates':[], 'actual_paths':[],
            'profile_label':'暂不归类' if ended else '概况候选待形成',
            'profile_status':'closed_unclassified' if ended else 'forecast',
            'source_rule_files':['research/ict_daily_profiles/rules.json','research/ict_weekly_profiles/rules.json',
                                 'research/ict_weekly_profiles/smc_free_guide/integration.json'],
            'full_ict_profile_confirmed':False,'execution_allowed':False,'model_trained':False,
            'limitations':['周背景是条件路径，不是事先 HTF 方向偏见', '历史服务器时钟偏移与完整新闻仍待验证',
                           '两根连续收盘及实体/振幅 0.25 是待验证工程阈值，不是课程胜率',
                           '已确认指价格路径；事先偏见、HTF PDA、DOL 和新闻归因未确认',
                           '覆盖检查暂允许纽约 17–18 点研究休市窗口；历史券商日历未验证']}
    if not core:
        if ended:
            result.update(profile_status='closed_insufficient_data', profile_label='日已结束 · 报价覆盖不足',
                          coverage_complete_under_study_calendar=False)
        result['profile_reason']=profile_brief_reason(result) if ended else '等待已收盘行情。'
        return result
    price_rows=core; price_period=period; expected_end=end
    covered=_coverage(core,start,cutoff,period)
    if reference_m5 is not None:
        price_rows,expected_end,covered,basis=_daily_reference(core,reference_m5,day,cutoff,period)
        price_period=M5
        result.update(daily_price_basis=basis,coverage_source_period_minutes=5,
                      analysis_period_minutes=period.total_seconds()/60,
                      coverage_policy='M5 daily prices plus complete matching analysis bars; assumed NY 17–18 recess and Friday 16:55 study close; historical broker calendar unverified')
    result['coverage_complete_under_study_calendar']=covered
    if ended and not covered:
        result.update(profile_status='closed_insufficient_data',profile_label='日已结束 · 报价覆盖不足')
    if not price_rows:
        result['profile_reason']=profile_brief_reason(result)
        return result
    parts={k:[b for b in rows if a<=b.time<b_end] for k,(a,b_end) in session_windows(day).items()}
    windows=session_windows(day)
    complete={k:_complete(part,*windows[k],period) for k,part in parts.items()}
    a,l,n=(parts[k] for k in ('asia','london','new_york'))
    open_price=price_rows[0].open if price_rows[0].time==start else None
    close_price=price_rows[-1].close
    day_width=max(b.high for b in price_rows)-min(b.low for b in price_rows)
    small_body=open_price is not None and day_width>0 and abs(close_price-open_price)/day_width<=.25
    whole_day=ended and covered and price_rows[-1].time+price_period==expected_end and open_price is not None
    cards=[]; actual=[]
    def add(ident,label,direction,evidence,expect,invalidate,slide,path=False,invalid=False,confirmation=None):
        status='invalidated' if invalid else 'active' if covered else 'insufficient_data'
        path=path and status=='active'
        card={'id':ident,'label':label,'direction':direction,'evidence':evidence,'awaiting':expect,
              'observed_sequence':True,
              'invalidation':invalidate,'source_slides':[slide], 'path_matched':bool(path),
              'hd_source':profile_source(ident),
              'confirmation_evidence':confirmation if path else None,
              'weekly_context':weekly['label'],'probability':None,'status':status}
        cards.append(card)
        if ended and path:
            actual.append({'id':ident,'label':label,'direction':direction,'source_slides':[slide],
                           'scope':'confirmed_observed_price_path_only'})
    if complete['asia'] and complete['london']:
        ah,al=max(b.high for b in a),min(b.low for b in a)
        lh,ll=max(b.high for b in l),min(b.low for b in l)
        ld,lu=_reclaim(l,al,-1,period),_reclaim(l,ah,1,period)
        nd,nu=_reclaim(n,ll,-1,period),_reclaim(n,lh,1,period)
        nxu,nxd=_extension(n,lh,1,period),_extension(n,ll,-1,period)
        def known_at(bar):return (bar.time+period).isoformat() if bar else None
        result['session_price_checks']={
            'analysis_period_minutes':period.total_seconds()/60,
            'asia':{'high':ah,'low':al},'london':{'high':lh,'low':ll},
            'london_sweep_low_reclaim':known_at(ld),'london_sweep_high_reclaim':known_at(lu),
            'ny_sweep_low_reclaim':known_at(nd),'ny_sweep_high_reclaim':known_at(nu),
            'ny_two_closes_above_london':known_at(nxu),'ny_two_closes_below_london':known_at(nxd),
            'daily_open':open_price,'daily_close':close_price,'closed_day':whole_day,
            'source_scope':'closed_price_observations_only_not_prior_bias_or_CSD'}
        whole=complete['new_york'] and whole_day
        after_london=[b for b in price_rows if b.time>=windows['london'][1]]
        if ld:
            add('classic_buy','经典买入日',1,f'伦敦低点 {ll:.2f} 越过亚洲低点 {al:.2f} 后收回。',
                f'纽约两根连续收盘站上伦敦高点 {lh:.2f} 并保持扩张。',
                f'再次跌破伦敦低点 {ll:.2f}，或纽约持续缺乏跟随。',16,
                whole and nxu is not None and close_price>lh,any(b.low<ll for b in after_london),
                f'纽约已连续两根收盘站上伦敦高点 {lh:.2f}，日收 {close_price:.2f} 仍在其上；伦敦低点此后未被再破。')
        if lu:
            add('classic_sell_mirror','经典卖出日（镜像）',-1,f'伦敦高点 {lh:.2f} 越过亚洲高点 {ah:.2f} 后收回。',
                f'纽约两根连续收盘跌破伦敦低点 {ll:.2f} 并保持扩张。',
                f'重新站上伦敦高点 {lh:.2f}，或纽约持续缺乏跟随。',16,
                whole and nxd is not None and close_price<ll,any(b.high>lh for b in after_london),
                f'纽约已连续两根收盘跌破伦敦低点 {ll:.2f}，日收 {close_price:.2f} 仍在其下；伦敦高点此后未被再破。')
        if research_ny_reclaim:
            traces=[]
            for side,asia_edge,extreme,london_reclaim,expansion_edge,ident,label in (
                (1,al,ll,ld,max(al,lh),'classic_buy','经典买入'),
                (-1,ah,lh,lu,min(ah,ll),'classic_sell_mirror','经典卖出（镜像）'),
            ):
                if london_reclaim or side*(asia_edge-extreme)<=0:
                    continue
                returned=next((b for b in n if side*(b.close-asia_edge)>0),None)
                expanded=_extension(n,expansion_edge,side,period,returned.time) if returned else None
                extreme_key='low' if side==1 else 'high'
                broken=next((b for b in after_london if side*(getattr(b,extreme_key)-extreme)<0),None)
                traces.append({'id':ident,'direction':side,'asia_edge':asia_edge,'london_extreme':extreme,
                               'expansion_edge':expansion_edge,'london_known_at':windows['london'][1].isoformat(),
                               'ny_reclaim_known_at':known_at(returned),'ny_expansion_known_at':known_at(expanded),
                               'extreme_broken_known_at':(broken.time+price_period).isoformat() if broken else None,
                               'active_for_replay':bool(expanded and covered and not broken)})
                if expanded is None:
                    continue
                ny_clock=(expanded.time+period).astimezone(NY).strftime('%H:%M')
                note=f'伦敦已越过亚洲边界 {asia_edge:.2f}；纽约收回后，两根连续收盘越过确认线 {expansion_edge:.2f}，纽约 {ny_clock} 确认。'
                add(ident,f'{label} · 纽约回收试验',side,note,'观察日收盘能否维持在确认线外。',
                    '伦敦已冻结极点被进一步打破。',16,whole and side*(close_price-expansion_edge)>0,
                    broken is not None,note)
            result['research_ny_reclaim_sequences']=traces
        for side,reclaim,level,early,edge in [
            (1,nd,ll,open_price is not None and l[-1].close>open_price and not ld,lh),
            (-1,nu,lh,open_price is not None and l[-1].close<open_price and not lu,ll)]:
            if reclaim:
                ident='double_sweep' if early else 'classic_reversal_variant'
                label='双重扫荡日' if early else '经典反转 1.1'
                following=_extension(n,edge,side,period,reclaim.time+period)
                confirmation=None
                if research_late_classic_and_longer_range and not early and following is None:
                    following=_extension(n + parts['london_close'],edge,side,period,reclaim.time+period)
                    if following is not None:
                        confirmed_at=(following.time+period).astimezone(NY).isoformat()
                        confirmation=f'纽约越界回收后，伦敦收盘窗口有两根连续收盘越过 {edge:.2f}；第二根收盘 {confirmed_at}。'
                add(ident,label,side,('早期顺向运行后，' if early else '')+f'纽约越过伦敦边界 {level:.2f} 后收回。',
                    f'回收之后向{ "上" if side==1 else "下" }突破另一端 {edge:.2f}，并出现后续跟随。',
                    '回收失败，重新创新极点，或扩张不持续。',19 if early else 17,
                    whole and following is not None and side*(close_price-edge)>0,
                    _broken([b for b in price_rows if b.time>=windows['new_york'][0]],reclaim,side,reclaim.time+period),
                    confirmation)
                if whole and cards[-1]['status']=='active' and not cards[-1]['path_matched']:
                    window_end = windows['london_close' if research_late_classic_and_longer_range and not early else 'new_york'][1]
                    deadline = window_end.astimezone(NY).strftime('%H:%M')
                    if following:
                        detail=f'窗口内已有连续两根收盘越过 {edge:.2f}，但日收未守住该边界。'
                    else:
                        later = _extension(core,edge,side,period,reclaim.time+period)
                        detail=f'纽约 {deadline} 窗口结束时，回收后仍缺连续两根收盘越过 {edge:.2f}。'
                        if later and later.time+period>window_end:
                            observed=(later.time+period).astimezone(NY).strftime('%H:%M')
                            detail+=f'当日首次满足该跟随条件是在纽约 {observed}。'
                    cards[-1]['close_followthrough_review']=detail
        london_expands=(ld and _extension(l,ah,1,period,ld.time+period)) or (lu and _extension(l,al,-1,period,lu.time+period))
        after=[b for b in price_rows if b.time>=windows['new_york'][0]]
        after_analysis=[b for b in core if b.time>=windows['new_york'][0]]
        contained=bool(n) and all(ll<=b.low and b.high<=lh for b in after)
        if london_expands:
            add('manipulation_expansion_consolidation','操纵扩张后盘整日',None,
                '伦敦已观察到逆向越界回收及向亚洲另一端的两根收盘扩张。',
                '纽约及更晚会话保持在伦敦范围内，未持续扩张；最终净实体应较小，接近十字形。',
                '纽约或更晚会话持续扩张，或最终仍是大净实体。',21,whole and contained and small_body,
                bool(_extension(after_analysis,lh,1,period) or _extension(after_analysis,ll,-1,period) or (whole and not small_body)))
        if ld and lu:
            add('seek_destroy','寻找与毁灭日（心电图日）',None,'伦敦对亚洲两端均有越界后收盘回收。'+('纽约对伦敦两端也已回收。' if nd and nu else ''),
                '纽约双向回收，全天缺乏持续扩张，收盘净位移较小。',
                '出现持续单向交付；双重扫荡后恢复趋势时转向趋势形态。',22,
                whole and nd is not None and nu is not None and small_body and nxu is None and nxd is None,
                bool(nxu or nxd))
    # Recognise the price sequence independently of any asserted news cause.
    # The whole prefix from midnight must fit the frozen A range, so a small
    # local consolidation inside a trend cannot classify the entire day.
    found=set()
    for event in amd_events(core,period,cutoff):
        if event['phase']!='D':continue
        low,high=event['range_low'],event['range_high']
        known=datetime.fromisoformat(event['available_at'])
        sequence=[e for e in amd_events(core,period,known) if e['id']==event['id']]
        accumulation=next((e for e in sequence if e['phase']=='A'),None)
        if accumulation is None:continue
        a_end=datetime.fromisoformat(accumulation['available_at'])
        before=[b for b in core if b.time+period<=a_end]
        if open_price is None or len(before)<8 or not all(accumulation['lower']<=b.low and b.high<=accumulation['upper'] for b in before):continue
        direct=event['route']=='AD_no_M';ident='consolidation_expansion' if direct else 'news_manipulation_expansion'
        if direct and research_late_classic_and_longer_range and a_end-start < timedelta(minutes=90):continue
        side=1 if event['direction']=='bullish' else -1
        if (ident,side) in found:continue
        found.add((ident,side));edge=high if side==1 else low
        holds=side*(close_price-edge)>0
        full=whole_day
        add(ident,('盘整扩张' if direct else '盘整操纵扩张')+'（新闻关联待核实）',side,
            f'零点以来价格受已冻结范围 {low:.2f}–{high:.2f} 包含，随后已观察'+('两根连续收盘直接突破。' if direct else '先越界收回，再向另一端两根收盘扩张。'),
            '保持扩张，并独立核实新闻实际发布、事前偏见及 DOL；价格顺序不证明新闻因果。',
            '扩张收回、后续转为双向盘整，或缺少完整报价覆盖。',5 if direct else 18,
            full and holds,full and not holds)
        manipulation=next((e for e in sequence if e['phase']=='M'),None)
        cards[-1].update(calendar_event_verified=False,news_causality_verified=False,
                         price_sequence={'route':event['route'],'range_low':low,'range_high':high,
                                         'range_available_at':a_end.isoformat(),
                                         'sweep_reclaim_available_at':manipulation['available_at'] if manipulation else None,
                                         'expansion_start':event['start'],'expansion_available_at':event['available_at']})
    # In the absence of either observed sequence, preserve both alternatives.
    if not cards:
        for ident,label,expect,slide in [
            ('consolidation_expansion','盘整扩张日','范围形成后直接突破并延续；新闻时点与事前范围待核实。',5),
            ('news_manipulation_expansion','新闻前盘整操纵扩张日','先逆向扫荡并收回，再反向扩张；实际新闻与事前偏见待核实。',18)]:
            add(ident,label,None,'当前不足以形成已确认的伦敦 / 纽约典型路径；保留来源中的条件情景。',
                expect,'尚无范围或新闻证据；不能仅因有 CPI 计划而确定形态。',slide)
            cards[-1]['observed_sequence']=False
    # Put realised paths first, retaining ambiguity and all alternative evidence.
    cards.sort(key=lambda c:(c['status']!='active',not c['path_matched']))
    result['candidates']=cards
    result['actual_paths']=actual
    if ended:
        if actual:
            result['profile_label']=' / '.join(dict.fromkeys(p['label'] for p in actual))
            result['profile_status']='confirmed_path'
        else:
            partial=[c for c in cards if c.get('status')=='active' and c.get('observed_sequence')]
            if partial:
                result['profile_label']=' / '.join(dict.fromkeys(c['label'] for c in partial[:2]))+'（部分路径）'
                result['profile_status']='closed_partial'
    else:
        active=_live_profile_cards(cards, daily=True)
        result['profile_label']=(' / '.join(dict.fromkeys(c['label'] for c in active))+'（候选）') if active else ('数据覆盖不足 · 暂缓推测' if not covered else '前述候选已失效 · 等待新路径' if any(c['status']=='invalidated' for c in cards) else '概况候选待形成')
    if ended and include_reconstruction:
        snapshots=[]
        for hour in (5,7):
            at=datetime.combine(day,time(hour),NY).astimezone(timezone.utc)
            prior=daily_profile_lifecycle(bars,day,at,period,False,reference_m5=reference_m5,
                                          research_late_classic_and_longer_range=research_late_classic_and_longer_range,
                                          research_ny_reclaim=research_ny_reclaim)
            snapshots.append({'as_of':at.isoformat(),'label':prior['profile_label'],
                              'candidate_ids':[c['id'] for c in prior['candidates']],
                              'origin':'historical_prefix_reconstruction_not_recorded_live_forecast'})
        result['earlier_hypotheses']=snapshots
    result['profile_reason']=profile_brief_reason(result)
    return result


def weekly_profile_lifecycle(bars, days, as_of, realized_review, period=timedelta(minutes=15)):
    """Conditional weekly scenarios without backfilling final weekly extremes."""
    if as_of.tzinfo is None or period<=timedelta(0) or len(days)!=5 or days[0].weekday()!=0 or days!=[days[0]+timedelta(days=i) for i in range(5)]:
        raise ValueError('Aware cutoff, positive period and ordered Monday–Friday dates required')
    if any(a.time>=b.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Unique chronological bars required')
    start,_=_day_bounds(days[0]); _,end=_day_bounds(days[-1])
    cutoff=min(as_of,end)
    rows=[b for b in bars if start<=b.time and b.time+period<=cutoff]
    parts={d.weekday():[b for b in rows if b.time.astimezone(NY).date()==d] for d in days}
    complete={d.weekday():cutoff>=_day_bounds(d)[1] and _coverage(parts[d.weekday()],*_day_bounds(d),period) for d in days}
    covered=all(_coverage(parts[d.weekday()],_day_bounds(d)[0],min(cutoff,_day_bounds(d)[1]),period)
                for d in days if _day_bounds(d)[0]+period<=cutoff)
    result={'mode':'closed_week_review' if as_of>=end else 'intraweek_hypothesis',
            'as_of':cutoff.isoformat(),'candidates':[],'profile_label':realized_review['profile_label'],
            'profile_status':'closed_unclassified' if as_of>=end else 'forecast',
            'week_ended':as_of>=end,'final_week_extreme_known':False,'execution_allowed':False,
            'full_ict_profile_confirmed':False,'prior_bias_verified':False,
            'coverage_complete_under_study_calendar':covered,
            'coverage_policy':'NY 17–18 assumed recess; historical broker calendar unverified'}
    if as_of>=end:
        result['realized_candidates']=realized_review['candidates']
        # Closed-week geometry is derived from complete M5 reference days.
        # An incomplete final M15 bucket (Friday's 16:45–16:55 research close)
        # must not falsely negate that M5 coverage or its matching explanation.
        realized_days=realized_review.get('daily',[])
        if len(realized_days)==5 and [d.get('date') for d in realized_days]==[d.isoformat() for d in days]:
            result['m15_coverage_complete_under_study_calendar']=covered
            result['coverage_complete_under_study_calendar']=all(d.get('ended') and d.get('coverage_complete') for d in realized_days)
            result['coverage_source_period_minutes']=5
            result['coverage_policy']='Complete M5 NY reference days; assumed 17–18 recess and Friday 16:55 study close; historical broker calendar unverified'
            result['final_week_extreme_known']=result['coverage_complete_under_study_calendar']
        if not result['coverage_complete_under_study_calendar']:
            result['profile_status']='closed_insufficient_data'
            result['profile_label']='周已结束 · 报价覆盖不足'
        elif any(c.get('id') in WEEKLY and c.get('observed_sequence') and c.get('path_complete',True)
                 for c in result['realized_candidates']):
            result['profile_status']='confirmed_path'
        elif any(c.get('path_complete') is False for c in result['realized_candidates']):
            result['profile_status']='closed_partial'
        result['profile_reason']=profile_brief_reason(result)
        return result
    candidates=[]
    def add(ident,label,evidence,awaiting,invalidation,slides,pages,invalid=False,**extra):
        candidates.append({'id':ident,'label':label,'evidence':evidence,'awaiting':awaiting,
                           'invalidation':invalidation,'course_slides':slides,'guide_pages':pages,
                           'hd_source':profile_source(ident,True),
                           'probability':None,'htf_pda_dol_pending':True,'observed_sequence':True,
                           'status':'invalidated' if invalid else 'active' if covered else 'insufficient_data',**extra})
    m,t,w,th=(parts[i] for i in range(4))
    if complete[0] and t:
        high,low=max(b.high for b in m),min(b.low for b in m)
        td,tu=_extreme_reclaim(t,low,-1,period),_extreme_reclaim(t,high,1,period)
        observed=t+w+th+parts[4]
        low_broken=_broken(observed,td,1)
        high_broken=_broken(observed,tu,-1)
        for side,reclaim,level,broken,opposite,opposite_broken in (
            (1,td,low,low_broken,tu,high_broken),
            (-1,tu,high,high_broken,td,low_broken),
        ):
            if not reclaim or (opposite and (broken or not opposite_broken)):
                continue
            point='低点' if side==1 else '高点'
            direction='看涨' if side==1 else '看跌'
            reason=f'周二越过周一{point} {level:.2f} 后收盘回收。'
            if opposite:
                reason+='另一侧回收时的极点已被后续报价突破。'
            failed=''
            if complete[1] and side*(t[-1].close-level)<=0:
                failed='周二日收未保持在回收一侧。'
            elif complete[2] and side*(w[-1].close-t[-1].close)<=0:
                failed='周三日收未沿候选方向越过周二收盘。'
            elif complete[3] and side*(th[-1].close-w[-1].close)<=0:
                failed='周四日收未沿候选方向越过周三收盘。'
            add('weekly_tuesday_extreme',f'经典周二{point} · {direction}扩张候选',reason,
                '等待周三、周四沿反转方向交付，并核实事前 HTF PDA、CISD 与 DOL。',
                f'重新突破回收时已知{point}，或缺少后续扩张。',[10],[61],broken or bool(failed),
                failed_close_condition=failed,
                direction=side,reclaim_known_at=(reclaim.time+period).isoformat(),
                opposite_reclaim_invalidated=bool(opposite and opposite_broken))
    if complete[0] and complete[1] and w:
        early=m+t; high,low=max(b.high for b in early),min(b.low for b in early)
        wd,wu=_extreme_reclaim(w,low,-1,period),_extreme_reclaim(w,high,1,period)
        for side,reclaim,level in [(1,wd,low),(-1,wu,high)]:
            if reclaim:
                direction='看涨' if side==1 else '看跌'
                double=side*(t[-1].close-t[0].open)>0 and side*(t[-1].close-m[-1].close)>0
                counter=side*(t[-1].close-t[0].open)<0 and side*(t[-1].close-m[-1].close)<0
                variant='双重扫荡' if double else '经典' if counter else '经典 / 双重扫荡待分'
                ident='weekly_wednesday_double_sweep' if double else 'weekly_wednesday_extreme' if counter else 'weekly_wednesday_unresolved'
                failed=''
                if complete[2] and side*(w[-1].close-level)<=0:
                    failed='周三日收未保持在回收一侧。'
                elif complete[3] and side*(th[-1].close-w[-1].close)<=0:
                    failed='周四日收未沿候选方向越过周三收盘。'
                add(ident,f'周三扫{ "低" if side==1 else "高" }反转 · {variant} · {direction}候选',
                    f'周三越过已冻结的周一至周二边界 {level:.2f} 后收盘回收；'+('周二实体与收盘推进同向，符合双重扫荡早期顺向路径。' if double else '周二实体与收盘推进反向，符合经典反转的前段路径。' if counter else '周二方向不一致，两个子类待分。'),
                    '周四、周五沿反转方向扩张；价格路径子类不能替代事前偏见，仍须核实 HTF PDA / CISD / DOL。',
                    '重新突破回收时已知极点；后半周扩张缺失。',[11,12],[62],
                    _broken(w+th+parts[4],reclaim,side) or bool(failed),direction=side,
                    failed_close_condition=failed,reclaim_known_at=(reclaim.time+period).isoformat())
        if not wd and not wu:
            add('weekly_midweek_observe','周中反转 / 盘整后扩张 · 待分',
                f'周初范围 {low:.2f}–{high:.2f} 已形成，目前未观察到周三外部越界后收回。',
                '外部范围越界回收支持周中反转；直接突破并持续交付支持扩张；继续盘整则观察周四。',
                '不能因今天是周三就认定周三极点。',[11,13,14],[62,63],observed_sequence=False)
    if all(complete[i] for i in range(3)) and th:
        early=m+t+w; high,low=max(b.high for b in early),min(b.low for b in early)
        summary=[{'open':p[0].open,'close':p[-1].close,'high':max(b.high for b in p),'low':min(b.low for b in p)} for p in (m,t,w)]
        consolidation=consolidation_evidence(summary)
        result['early_week_consolidation']=consolidation
        friday=parts[4];last=(friday or th)[-1]
        th_high,th_low=max(b.high for b in th),min(b.low for b in th)
        if consolidation['matched']:
            for side,breached,edge in [(1,th_low<low,low),(-1,th_high>high,high)]:
                if not breached:continue
                returned=side*(last.close-edge)>0
                invalid=complete[3] and any((b.low<th_low if side==1 else b.high>th_high) for b in friday)
                add('weekly_thursday_consolidation_reversal','周四'+('扫低' if side==1 else '扫高')+'极点 · 反向扩张候选'+('' if returned else '（待回收）'),
                    f'已冻结的周一至周三范围 {low:.2f}–{high:.2f} 符合盘整研究阈值；周四向'+('下' if side==1 else '上')+'越界，'+('当前收盘已回到范围一侧。' if returned else '目前尚未回收，可继续等待周五，原片不要求周四当日收回。'),
                    '等待周四结束、周五反向扩张并核实该极点是否保持；事前 HTF 偏见、PDA / DOL 和实际新闻仍待验证。',
                    '周五突破周四对应极点，或最终没有反向扩张。',[13],[63],invalid,
                    direction=side,phase='range_reclaimed_awaiting_expansion' if returned else 'range_breach_awaiting_reclaim',
                    consolidation=consolidation,calendar_event_verified=False,
                    thursday_extreme_final_for_day=complete[3],thursday_same_day_reclaim_required=False)
            for side,edge in [(1,high),(-1,low)]:
                expansion=_extension(th,edge,side,period)
                if expansion is None:continue
                preceding=[b for b in th if b.time<=expansion.time]
                direct=all(b.low>=low for b in preceding) if side==1 else all(b.high<=high for b in preceding)
                if not direct:continue  # Preserve the opposite-sweep alternative above.
                invalid=bool(_extension(friday,low if side==1 else high,-side,period))
                add('weekly_consolidation_expansion','周四扩张 · 盘整扩张周候选',
                    f'周一至周三盘整范围 {low:.2f}–{high:.2f} 已冻结；周四两根连续收盘向'+('上' if side==1 else '下')+'越过外缘，突破前未见反向破范围。',
                    '等周四结束并观察周五跟随；先核实新闻、事前偏见和 DOL，不把周五固定成首次突破日。',
                    '突破收回且转为反向扩张，或周五没有跟随。',[14],[59],invalid,
                    direction=side,phase='thursday_expansion_awaiting_friday',consolidation=consolidation,
                    calendar_event_verified=False,variant='thursday_expansion_friday_followthrough')
        elif th_low<low or th_high>high:
            add('weekly_range_observation','周四范围突破 · 类型待分',
                f'周四已越过周初范围 {low:.2f}–{high:.2f}，但前三日不符合当前盘整研究阈值。',
                '等待更完整路径及 HTF 背景；不把趋势中突破直接归成盘整操纵或盘整扩张。',
                '事前范围、盘整或延续证据缺失。',[13,14],[59,63],
                consolidation=consolidation,calendar_event_verified=False)
    if not candidates:
        add('weekly_open_alternatives','周二 / 周三反转或后续扩张 · 待观察',
            '周内已收盘路径尚不足以区分典型周概况。',
            '先冻结周初范围，再等外部越界、回收与后续交付；持续双向运行时保留心电图周备选。',
            '事前范围与 HTF 背景未齐；不从星期或单次涨跌直接判断。',[10,11,13,14,15],[61,62,63],observed_sequence=False)
    candidates.sort(key=lambda c:(c['status']!='active',not c['observed_sequence'],c.get('phase')=='range_breach_awaiting_reclaim'))
    result['candidates']=candidates
    active=_live_profile_cards(candidates, daily=False)
    result['profile_label']=' / '.join(c['label'] for c in active) if active else ('数据覆盖不足 · 周概况暂缓推测' if not covered else '前述周概况候选已失效 · 等待新路径' if any(c['status']=='invalidated' for c in candidates) else '周概况候选待形成')
    result['observed_range']={'high':max(b.high for b in rows),'low':min(b.low for b in rows)} if rows else None
    result['profile_reason']=profile_brief_reason(result)
    return result
