"""Independent OHLC evidence rubric. Unclear cases keep an unknown label."""
from statistics import median
import gzip
import json

from freeze_inputs import HERE, aggregate, as_utc


PHASES = ("expansion", "retracement", "reversal", "consolidation")


def sign(value):
    return (value > 0) - (value < 0)


def label_market(market):
    """Use close trajectories, a rolling envelope, and two-bar follow-through."""
    stamps = list(market)
    prices = list(market.values())
    answer = []
    anchor = None
    run_start = 0
    for i, (raw, bar) in enumerate(zip(stamps, prices)):
        if i and raw - stamps[i - 1] != 900:
            run_start, anchor = i, None
        result = {"raw_close": raw + 900, "phase": "undetermined", "side": 0,
                  "evidence": "insufficient_or_mixed", "verified_by": raw + 900,
                  "leg": None}
        answer.append(result)
        if i - run_start < 12:
            continue
        prior = prices[i - 12:i]
        close = bar[3]
        typical = median(row[1] - row[2] for row in prior)
        if typical <= 0:
            continue
        follow = prices[i + 1:i + 3]
        if stamps[i + 1:i + 3] != [raw + 900, raw + 1800]:
            follow = []
        seq = [row[3] for row in prices[i - 4:i + 1]]
        diffs = [b - a for a, b in zip(seq, seq[1:])]
        move = seq[-1] - seq[0]
        side = sign(move)
        outer = max(row[1] for row in prior[:-3]) if side > 0 else min(
            row[2] for row in prior[:-3]
        )
        edge_break = side * (close - outer) >= .15 * typical
        directional = (
            abs(move) >= 1.35 * typical
            and sum(sign(delta) == side for delta in diffs) >= 3
        )
        advanced = follow and all(side * (item[3] - outer) > 0 for item in follow)
        advanced = advanced and max(side * (item[3] - close) for item in follow) >= .20 * typical
        if anchor:
            leg_side, origin, extreme, leg_verified = anchor
            invalid = leg_side * (close - origin) < -.10 * typical
        else:
            leg_side, origin, extreme, leg_verified, invalid = 0, 0, 0, 0, False
        if directional and edge_break and advanced:
            phase = "expansion"
            if leg_side and leg_side != side:
                if invalid:
                    phase = "reversal"
                else:
                    phase = "retracement"
            result.update(phase=phase, side=side, verified_by=max(raw + 2700, leg_verified),
                          evidence="close_beyond_range_with_follow_through")
            if phase != "retracement":
                if leg_side != side:
                    origin = min(row[2] for row in prices[i - 4:i + 1]) if side > 0 else max(
                        row[1] for row in prices[i - 4:i + 1]
                    )
                    extreme = bar[1] if side > 0 else bar[2]
                else:
                    extreme = max(extreme, bar[1]) if side > 0 else min(extreme, bar[2])
                anchor = (side, origin, extreme, result["verified_by"])
        elif directional and edge_break:
            result["evidence"] = "break_without_verified_follow_through"
        elif anchor and invalid:
            anchor = None
            result["evidence"] = "origin_broken_without_directional_confirmation"
        else:
            recent = prices[i - 8:i + 1]
            bodies = [row[3] for row in recent]
            box = max(bodies) - min(bodies)
            middle = median(bodies)
            crossings = sum((a < middle < b or b < middle < a)
                            for a, b in zip(bodies, bodies[1:]))
            requested = leg_side * (extreme - close) if anchor else 0
            width = abs(extreme - origin)
            contained = (
                width >= 1.8 * typical and .20 * width <= requested <= .70 * width
                and leg_side * (close - seq[-3]) <= -.30 * typical
            )
            if box <= 2.25 * typical and abs(bodies[-1] - bodies[0]) <= .52 * typical and crossings >= 3:
                result.update(phase="consolidation", evidence="contained_repeated_close_crossings")
            elif anchor and contained:
                result.update(phase="retracement", side=-leg_side,
                              evidence="counter_move_inside_frozen_leg",
                              verified_by=max(raw + 900, leg_verified))
            elif anchor and leg_side * (close - extreme) > 0:
                extreme = bar[1] if leg_side > 0 else bar[2]
                anchor = (leg_side, origin, extreme, leg_verified)
                result.update(phase="expansion", side=leg_side, evidence="close_extends_verified_leg",
                              verified_by=max(raw + 900, leg_verified))
        if anchor:
            result["leg"] = {"side": anchor[0], "origin": anchor[1], "extreme": anchor[2]}
    return answer


def observable_outcomes(rows):
    for index, record in enumerate(rows):
        if record["phase"] not in PHASES:
            record["next"] = None
            continue
        time = record["raw_close"]
        future = rows[index + 1:index + 5]
        if [row["raw_close"] for row in future] != [time + 900 * n for n in range(1, 5)]:
            record["next"] = None
            continue
        change = next((row for row in future if row["phase"] in PHASES
                       and row["phase"] != record["phase"]), None)
        observed = change or (future[-1] if future[-1]["phase"] == record["phase"] else None)
        record["next"] = None if observed is None else {
            "phase": observed["phase"], "at": observed["raw_close"],
            "verified_by": max(observed["verified_by"], record["verified_by"]),
        }


def main():
    data = json.loads(gzip.decompress((HERE / "prices.json.gz").read_bytes()))
    m5 = {raw: tuple(ohlc) for raw, *ohlc in data["bars"]["M5"]}
    market, _ = aggregate(m5, 300, 900)
    rows = label_market(market)
    observable_outcomes(rows)
    for row in rows:
        row["known_at"] = as_utc(row["raw_close"]).isoformat()
    artifact = {"kind": "Independent deterministic OHLC proxy, no indicator inputs or hand labels.",
                "rows": rows}
    (HERE / "reference_labels.json.gz").write_bytes(gzip.compress(
        json.dumps(artifact, ensure_ascii=False, separators=(",", ":")).encode(), mtime=0,
    ))
    from collections import Counter
    print(Counter(row["phase"] for row in rows))


if __name__ == "__main__":
    main()
