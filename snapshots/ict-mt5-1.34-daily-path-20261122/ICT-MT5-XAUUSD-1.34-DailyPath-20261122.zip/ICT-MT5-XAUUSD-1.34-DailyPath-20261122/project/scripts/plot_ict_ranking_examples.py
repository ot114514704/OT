"""Plot the first held-out discordant cases selected by audit_ict_target_ranking."""
import gzip
import json
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as dates
from matplotlib.font_manager import FontProperties


def main():
    base = Path(__file__).resolve().parents[1] / 'output/research'
    study = base / 'pool_dol_20261122'
    def read(path):
        return json.loads(gzip.decompress(path.read_bytes()))
    reports = json.loads((base/'ict_walkforward_ranking.json').read_bytes())['results']
    forecasts = {s['at']:s for s in read(study/'frozen.json.gz')}
    labels = {s['at']:s for s in read(study/'outcomes.json.gz')}
    quotes = read(base/'ranked_dol/TMGM_20261122.json.gz')['series']['XAUUSDM5']
    candles = [(datetime.fromisoformat(row[0]), *row[1:]) for row in quotes]
    tz = ZoneInfo('America/New_York')
    plt.rcParams['font.family'] = FontProperties(fname='C:/Windows/Fonts/msyh.ttc').get_name()
    cases = [
            ('dol','learned_only','DOL · 学习排序选中触及目标'),
            ('dol','nearest_only','DOL · 最近价位触及，学习排序漏选'),
            ('pools','nearest_only','流动性积累 · 最近区域被扫，学习排序漏选'),
            ('dol','picked_later','DOL · 预测目标晚于另一候选触及'),
            ('pools','picked_later','流动性积累 · 首先清扫另一候选'),
            ('dol','tied','DOL · 同根 M5 首次触及多个目标')]
    for number, (family, key, title) in enumerate(cases, 1):
        case = reports[family]['first_disagreements' if number <= 3 else 'order_examples'][key]
        stamp = case['at']
        start = datetime.fromisoformat(stamp)
        end = datetime.fromisoformat(case['end'])
        fig, ax = plt.subplots(figsize=(9, 4))
        for t, o, h, l, c in candles:
            if start-timedelta(hours=1) <= t < end:
                # Plot at bar close: the last bar on the forecast line was observable.
                x = t + timedelta(minutes=5)
                color = '#177264' if c >= o else '#ac5148'
                ax.vlines(x,l,h,color=color,linewidth=0.8)
                ax.vlines(x,min(o,c),max(o,c),color=color,linewidth=2.8)
        ax.axvline(start, color='#333333', linestyle=':', label='冻结候选时刻')
        comparison = [('learned_index','学习排序'), ('nearest_index','最近价位')]
        if key == 'picked_later':
            comparison = [('learned_index','预测首选'), ('observed_index','实际最早')]
        elif key == 'tied':
            comparison = [('observed_index','同根候选一'), ('also_first_index','同根候选二')]
        for (field, name), color in zip(comparison, ['#6639a7','#bd6506']):
            i = case[field]
            target = forecasts[stamp][family][i]
            lo, hi = target['lo'], target['hi']
            side = target['side']
            pool = family == 'pools'
            edge = (hi if side>0 else lo) if pool else (lo if side>0 else hi)
            hit = labels[stamp]['short'][family][i]['sweep' if pool else 'touch']
            desc = '已清扫' if pool and hit else '已触及' if hit else '未达成'
            if hi>lo:
                ax.fill_between([start,end],lo,hi,color=color,alpha=.08)
            ax.hlines(edge,start,end,color=color,linestyle='--',label=f'{name}  {edge:.2f}  {desc}')
            if hit:
                ax.scatter(datetime.fromisoformat(hit),edge,color=color,s=38,zorder=5)
        ax.xaxis.set_major_formatter(dates.DateFormatter('%H:%M',tz=tz))
        ax.set_xlabel(f'{start.astimezone(tz):%Y-%m-%d}  纽约时间  ·  M5 收盘时刻')
        ax.set_ylabel('XAUUSD')
        ax.set_title(title,loc='left')
        ax.grid(axis='y',alpha=.15)
        ax.legend(loc='upper center', bbox_to_anchor=(.5,-.22),ncol=3,frameon=False)
        fig.subplots_adjust(bottom=.26)
        fig.savefig(base/f'ict_ranking_example_{number}.png', dpi=135,bbox_inches='tight')
        plt.close(fig)


if __name__ == '__main__':
    main()
