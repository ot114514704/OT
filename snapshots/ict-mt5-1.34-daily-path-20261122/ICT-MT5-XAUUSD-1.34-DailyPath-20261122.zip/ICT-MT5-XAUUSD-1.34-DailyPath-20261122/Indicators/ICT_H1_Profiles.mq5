#property version "1.34"
#property description "ICT 日周概况工作稿"
#property indicator_chart_window
#property indicator_plots 0

struct Mark {
   string kind, label;
   datetime start, finish;
   double first, last, dol;
   datetime dolHit,originKnown,aKnown,watchEnd,invalidAt;
   double protectedPrice;
   datetime paintStart,paintFinish;
   double paintEdge,paintExtreme,deliveryEdge;
   int formationBars,parentM;
};
Mark marks[];
int h4ReviewIndices[];
struct ClockSpan {datetime start,finish;int offset;};
ClockSpan nyClock[];
struct Release {datetime at;string tag,details;int priority;string path,assessment;bool strong,swept;int stageIndex;};
Release events[];

string prefix="ICTH1P_", revision="", bitmap;
bool showSMT=true, showPath=true, showSilver=true, showDaily=true, showOpen=true, showSessions=true;
bool showDayPath=true;
bool showDOL=false,showPool=false,poolExternal=false,showIPDA=false;
bool showPrice=false,showRealized=false;
int realizedOffset=0;
bool showH4=false;
string dolBatch="";
datetime dolReceivedUtc=0,dolReceivedServer=0;
bool dolBatchDrawn=false;
int dolPage=0,dolPages=1,dolIrlPage=0,dolPanelLeft=0,dolPanelTop=0,dolPanelBottom=0;
uint pixels[];
#include "ICT_Period_SMT.mqh"
#include "ICT_AMD.mqh"
#include "ICT_News_Labels.mqh"
#include "ICT_Session_View.mqh"
#include "ICT_Week_Scale.mqh"
#include "ICT_FVG_View.mqh"
#include "ICT_SMC_View.mqh"

string smtCaption(bool bullish){return bullish?"看涨 SMT":"看跌 SMT";}

datetime receiptServerTime(datetime utc){
   for(int j=0;j<ArraySize(marks);j++){
      if(marks[j].kind!="news_clock")continue;
      datetime local=utc+(int)marks[j].first;
      if(marks[j].start<=local && local<marks[j].finish)return local;
   }
   return 0;
}
void recordDOLReceipt(){
   if(!dolBatchDrawn || StringLen(dolBatch)!=64 || dolReceivedUtc>0)return;
   // TimeGMT has second precision. Use the following second as a conservative boundary.
   datetime acknowledged=TimeGMT()+1;
   string name="ICT_Trader\\DOLReceipts\\"+TimeToString(acknowledged,TIME_DATE)+".tsv";
   int file=FileOpen(name,FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI|FILE_COMMON|FILE_SHARE_READ,'\t',CP_UTF8);
   if(file==INVALID_HANDLE)return;
   bool found=false;
   while(!FileIsEnding(file)){
      string key=FileReadString(file);
      datetime first=(datetime)StringToInteger(FileReadString(file));
      if(key==dolBatch && first>0){acknowledged=first;found=true;break;}
   }
   if(!found){
      FileSeek(file,0,SEEK_END);
      if(FileWrite(file,dolBatch,(long)acknowledged)==0){FileClose(file);return;}
      FileFlush(file);
   }
   FileClose(file);
   dolReceivedUtc=acknowledged;dolReceivedServer=receiptServerTime(acknowledged);
}

bool readMarks(){
   int h=FileOpen("ICT_Trader\\H1Profiles.tsv",FILE_READ|FILE_CSV|FILE_UNICODE|FILE_COMMON|FILE_SHARE_READ|FILE_SHARE_WRITE,'\t');
   if(h==INVALID_HANDLE) return false;
   string version=FileReadString(h);
   int count=(int)StringToInteger(FileReadString(h));
   if(version==revision || StringLen(version)!=64 || count<1 || count>50000){FileClose(h);return false;}
   Mark fresh[];
   ArrayResize(fresh,count);
   for(int i=0;i<count;i++){
      fresh[i].kind=FileReadString(h);
      fresh[i].start=StringToTime(FileReadString(h));
      fresh[i].finish=StringToTime(FileReadString(h));
      fresh[i].first=StringToDouble(FileReadString(h));
      fresh[i].last=StringToDouble(FileReadString(h));
      fresh[i].label=FileReadString(h);
      if(fresh[i].kind=="week") fresh[i].start=fresh[i].finish-5*86400;
      if(fresh[i].start<=0 || fresh[i].finish<=0){FileClose(h);return false;}
   }
   FileClose(h);
   ArraySwap(fresh,marks);revision=version;
   ArrayResize(nyClock,0);
   for(int j=0;j<count;j++){
      if(marks[j].kind!="et_clock")continue;
      int k=ArraySize(nyClock);ArrayResize(nyClock,k+1);
      nyClock[k].start=marks[j].start;nyClock[k].finish=marks[j].finish;nyClock[k].offset=(int)marks[j].first;
   }
   string batch="";
   ArrayResize(h4ReviewIndices,0);
   for(int j=0;j<count;j++){
      if(marks[j].kind=="dol_batch")batch=marks[j].label;
      if(marks[j].kind=="h4_review"){
         int k=ArraySize(h4ReviewIndices);ArrayResize(h4ReviewIndices,k+1,128);
         h4ReviewIndices[k]=j;
      }
   }
   if(batch!=dolBatch){dolBatch=batch;dolReceivedUtc=0;dolReceivedServer=0;dolBatchDrawn=false;}
   return true;
}

void button(string id,string caption,int x,bool on,int width=96,int fontSize=8){
   string name=prefix+id;
   if(ObjectFind(0,name)<0) ObjectCreate(0,name,OBJ_BUTTON,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_RIGHT_UPPER);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,name,OBJPROP_YDISTANCE,63);
   ObjectSetInteger(0,name,OBJPROP_XSIZE,width);
   ObjectSetInteger(0,name,OBJPROP_YSIZE,23);
   ObjectSetInteger(0,name,OBJPROP_BGCOLOR,on?clrDarkSlateGray:clrDimGray);
   ObjectSetInteger(0,name,OBJPROP_COLOR,clrWhite);
   ObjectSetInteger(0,name,OBJPROP_ZORDER,5);
   ObjectSetInteger(0,name,OBJPROP_STATE,false);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,fontSize);
   ObjectSetString(0,name,OBJPROP_TEXT,caption+(on?" 开":" 关"));
   ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
}

void priceText(string name,datetime stamp,double price,string caption,color ink,bool above,string description=""){
   if(ObjectFind(0,name)<0) ObjectCreate(0,name,OBJ_TEXT,0,stamp,price);
   else ObjectMove(0,name,0,stamp,price);
   ObjectSetInteger(0,name,OBJPROP_ANCHOR,above?ANCHOR_LEFT_LOWER:ANCHOR_LEFT_UPPER);
   ObjectSetInteger(0,name,OBJPROP_COLOR,ink);
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");
   ObjectSetString(0,name,OBJPROP_TEXT,caption);
   ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
}

void visibleSweeps(datetime left,datetime right,int w){
   static datetime oldLeft=0,oldRight=0;static string oldRevision="";
   static int oldWidth=0;
   if(left==oldLeft && right==oldRight && oldRevision==revision && oldWidth==w)return;
   oldLeft=left;oldRight=right;oldWidth=w;oldRevision=revision;
   string base=prefix+"DAYSW_";ObjectsDeleteAll(0,base);
   for(int i=0;i<ArraySize(marks);i++){
      Mark m=marks[i];
      if(StringFind(m.kind,"day_sweep_")!=0 || m.start>right || m.finish<left)continue;
      string name=base+IntegerToString(i);bool buy=StringFind(m.label,"买方")>=0;
      datetime sweepBar=m.finish-300;
      ObjectCreate(0,name,OBJ_TREND,0,m.start,m.first,sweepBar,m.first);
      ObjectSetInteger(0,name,OBJPROP_RAY_RIGHT,false);ObjectSetInteger(0,name,OBJPROP_RAY_LEFT,false);
      ObjectSetInteger(0,name,OBJPROP_STYLE,STYLE_DOT);ObjectSetInteger(0,name,OBJPROP_COLOR,clrSilver);
      ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
      string tip=m.label;StringReplace(tip,"｜","\n");
      ObjectSetString(0,name,OBJPROP_TOOLTIP,tip);
      // Short swings retain their line and hover without crowding adjacent candles.
      int x1,y1,x2,y2;
      if(ChartTimePriceToXY(0,0,m.start,m.first,x1,y1) && ChartTimePriceToXY(0,0,sweepBar,m.first,x2,y2) && x2-x1>=42)
         priceText(name+"_label",sweepBar,m.first,buy?"买方已扫":"卖方已扫",clrSilver,buy,tip);
   }
}
void paths(){
   ObjectsDeleteAll(0,prefix+"P_");
   for(int i=0;i<ArraySize(marks);i++){
      Mark m=marks[i];
      string name=prefix+"P_"+IntegerToString(i);
      bool sweep=m.kind=="week_sweep";
      bool dayPath=m.kind=="day_path";
      if(!sweep && !(dayPath && showDayPath) && !(m.kind=="path" && showPath))continue;
      ObjectCreate(0,name,OBJ_TREND,0,m.start,m.first,m.finish,m.last);
      ObjectSetInteger(0,name,OBJPROP_COLOR,dayPath?clrLightSeaGreen:(sweep?clrSilver:clrDarkOrange));
      ObjectSetInteger(0,name,OBJPROP_WIDTH,1);
      ObjectSetInteger(0,name,OBJPROP_STYLE,dayPath?STYLE_SOLID:(sweep?STYLE_DOT:STYLE_DASH));
      ObjectSetInteger(0,name,OBJPROP_RAY_LEFT,false);
      ObjectSetInteger(0,name,OBJPROP_RAY_RIGHT,false);
      ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
      ObjectSetString(0,name,OBJPROP_TOOLTIP,dayPath?"日概况折线 · 美东 "+easternTime(m.start)+" 至 "+easternTime(m.finish):"\n");
      if(sweep){
         int split=StringFind(m.label,"｜");
         string caption=split<0?m.label:StringSubstr(m.label,0,split);
         bool buy=StringFind(caption,"买方")>=0;
         priceText(name+"_label",m.finish,m.last,caption,clrWhite,buy);
         ObjectSetInteger(0,name+"_label",OBJPROP_ANCHOR,buy?ANCHOR_RIGHT_LOWER:ANCHOR_RIGHT_UPPER);
      }
   }
   button("SMT","SMT/犹大",207,showSMT);
   button("PATH","周概况折线",105,showPath);
   button("SILVER","银弹",309,showSilver);
   button("DAILY","日K覆盖",411,showDaily);
   button("OPEN","纽约开/4H收",513,showOpen);
   button("AMDB","大AMD",615,showAmdLarge,48,6);
   button("AMDSB","小AMD",565,showAmdSmall,46,6);
   button("FVGB","FVG",717,showFVG);
}

void rectangle(int w,int h,int x1,int y1,int x2,int y2,uint ink){
   int left=MathMax(0,x1),right=MathMin(w-1,x2);
   if(right<left) return;
   for(int y=MathMax(0,y1);y<=MathMin(h-1,y2);y++)
      ArrayFill(pixels,y*w+left,right-left+1,ink);
}

void silverBox(int i,int x,int z,int w,int h){
   int left=MathMax(0,x),right=MathMin(w,MathMax(x+1,z));
   if(left>=right) return;
   Mark m=marks[i];int unused,top,bottom;
   bool priced=m.first>0 && m.last>=m.first &&
      ChartTimePriceToXY(0,0,m.start,m.last,unused,top) &&
      ChartTimePriceToXY(0,0,m.start,m.first,unused,bottom);
   color ink=C'128,190,255';
   uint band=ColorToARGB(ink,24),fill=ColorToARGB(ink,76),edge=ColorToARGB(ink,235);
   for(int y=0;y<h;y++){
      bool inside=priced && y>=top && y<=bottom;
      for(int col=left;col<right;col++){
         uint fg=inside?((y==top || y==bottom || col==x || col==MathMax(x,z-1))?edge:fill):band;
         int k=y*w+col;pixels[k]=sourceOver(fg,pixels[k]);
      }
   }
   if(!priced){
      if(TimeTradeServer()>=m.start)windowHit(i,left,MathMax(0,h-58),right,MathMax(0,h-30));
      return;
   }
   if(bottom<0 || top>=h) return;
   windowHit(i,left,MathMax(0,top),right,MathMin(h-1,bottom));
   string tip="";
   string caption=silverCaption(m,tip);
   if(caption=="")return;
   if(right-left>=2 && bottom>=0 && top<h-45){
      StringReplace(tip,"｜","\n");
      int y=MathMax(0,top)+1;
      screenNote(prefix+"Z_SB"+IntegerToString(i),left+2,y,caption,ink,tip,7);
      windowHit(i,left,y,left+2+textWidth(caption),y+14,true);
   }
}

void smtBracket(const Mark &m,int index,int w,int h){
   int x0,y0,x1,y1;
   bool judas=StringFind(m.kind,"judas_")==0;
   bool watching=StringFind(m.kind,"judas_watch_")==0;
   bool major=StringFind(m.kind,"major_")==0;
   bool bull=m.kind=="smt_up" || m.kind=="major_up" || m.kind=="judas_up" || m.kind=="judas_watch_up",dollar=StringFind(m.label,"美元指数")>=0;
   datetime anchor=judas?m.start:m.finish;
   double anchorPrice=judas?m.first:m.last;
   if(judas){
      int bar=iBarShift(_Symbol,_Period,m.start,false);
      if(bar<0)return;
      anchor=iTime(_Symbol,_Period,bar);
      anchorPrice=bull?iLow(_Symbol,_Period,bar):iHigh(_Symbol,_Period,bar);
   }
   if(!ChartTimePriceToXY(0,0,anchor,anchorPrice,x1,y1) || x1<0 || x1>=w) return;
   if(major || judas){
      int half=MathMax(12,MathMin(35,(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS)/MathMax(1,(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS))*2));
      x0=x1-half;x1+=half;y0=y1;
   }else if(!ChartTimePriceToXY(0,0,m.start,m.first,x0,y0) || x1<=x0) return;
   int sign=bull?1:-1;
   // Keep each bracket outside all wicks between its two gold swing bars.
   MqlRates bars[];
   int count=(major || judas)?0:CopyRates(_Symbol,_Period,m.start,m.finish,bars);
   int edge=bull?MathMax(y0,y1):MathMin(y0,y1);
   for(int i=0;i<count;i++){
      int x,y;
      if(ChartTimePriceToXY(0,0,bars[i].time,bull?bars[i].low:bars[i].high,x,y))
         edge=bull?MathMax(edge,y):MathMin(edge,y);
   }
   int base=edge+sign*(judas?37:dollar?25:5);
   double depth=MathMin(19.,MathMax(6.,(x1-x0)*0.16));
   if(major || judas) base=(int)MathMax(depth+18,MathMin(h-depth-35,base));
   int samples=(int)MathCeil(x1-x0+4*depth);
   double length=0,px=x0,py=base;
   color ink=major?(bull?clrAqua:clrSalmon):(bull?clrCadetBlue:clrRosyBrown);
   for(int part=0;part<6;part++){
      double a=part/6.,b=(part+1)/6.;
      detailHit((int)(x0+(x1-x0)*a),(int)(base+sign*4*depth*a*(1-a)),
                (int)(x0+(x1-x0)*b),(int)(base+sign*4*depth*b*(1-b)),m.label,4,true);
   }
   for(int j=0;j<=samples;j++){
      double t=(double)j/samples,x=x0+(x1-x0)*t,y=base+sign*4*depth*t*(1-t);
      length+=MathSqrt((x-px)*(x-px)+(y-py)*(y-py));
      px=x;py=y;
      if(judas || MathMod(length,5.)<3.){
         int ix=(int)MathRound(x),iy=(int)MathRound(y);
         rectangle(w,h,ix,iy,ix,iy+(major?2:1),ColorToARGB(ink,(uchar)(major?255:200)));
      }
   }
   int cx=(x0+x1)/2,cy=(int)MathRound(base+sign*(depth+3));
   if(cx<0 || cx>=w || cy<0 || cy>=h) return;
   string name=prefix+(judas?"S_J":"S_")+IntegerToString(index);
   ObjectCreate(0,name,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_ANCHOR,bull?ANCHOR_UPPER:ANCHOR_LOWER);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,cx);
   ObjectSetInteger(0,name,OBJPROP_YDISTANCE,cy);
   ObjectSetInteger(0,name,OBJPROP_COLOR,ink);
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");
   ObjectSetString(0,name,OBJPROP_TEXT,watching?"犹大待确认":judas?(bull?"看涨犹大":"看跌犹大"):smtCaption(bull));
   ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
   detailHit(cx-28,cy+(bull?0:-17),cx+28,cy+(bull?17:0),m.label,4);
}

void drawSignals(const Mark &signals[],int w,int h){
   int left=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
   datetime visibleStart=iTime(_Symbol,_Period,left);
   int end=MathMax(0,left-(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS)-1);
   datetime visibleEnd=periodEnd(iTime(_Symbol,_Period,end));
   // Merge both comparators at the same gold pivot; prefer the weekly-path arc.
   Mark visible[];
   for(int i=0;i<ArraySize(signals);i++){
      Mark m=signals[i];
      if(m.finish<visibleStart || m.finish>visibleEnd) continue;
      bool bull=m.kind=="smt_up" || m.kind=="major_up";
      int j=ArraySize(visible)-1;
      for(;j>=0;j--){
         bool sameSide=(visible[j].kind=="smt_up" || visible[j].kind=="major_up")==bull;
         if(visible[j].finish==m.finish && sameSide) break;
      }
      if(j<0){int n=ArraySize(visible);ArrayResize(visible,n+1,32);visible[n]=m;}
      else{
         string details=visible[j].label+"\n"+m.label;
         if(StringFind(m.kind,"major_")==0) visible[j]=m;
         visible[j].label=details;
      }
   }
   for(int i=0;i<ArraySize(visible);i++){
      bool overshadowed=false;
      if(StringFind(visible[i].kind,"smt_")==0){
         for(int j=0;j<ArraySize(visible);j++){
            if(StringFind(visible[j].kind,"major_")!=0 || (visible[i].kind=="smt_up")!=(visible[j].kind=="major_up")) continue;
            if(MathAbs(visible[i].finish-visible[j].finish)<=2*PeriodSeconds(_Period)){overshadowed=true;break;}
         }
      }
      if(!overshadowed) smtBracket(visible[i],i,w,h);
   }
}

void dailyExtremeHit(const Mark &day,bool high,double price,int x,int y,int center,bool hasLetter){
   string side=high?"日高":"日低",tip=side+" "+DoubleToString(price,_Digits)+"｜该价位的已收 M5 复盘待更新";
   for(int i=0;i<ArraySize(marks);i++){
      Mark m=marks[i];
      if(m.kind=="day_extreme" && day.start<=m.start && m.start<day.finish && StringFind(m.label,side)==0 &&
         MathAbs(price-m.first)<_Point/2){tip=m.label;break;}
   }
   detailHit(center-4,y-4,center+4,y+4,tip,9);
   detailHit(x-4,y-4,x+4,y+4,tip,9);
   if(hasLetter) detailHit(x-2,high?y-15:y,x+10,high?y:y+15,tip,10);
}
void dailyOverlay(const Mark &m,int w,int h){
   // The H1 candles use the same broker-time anchors as the NY boundary feed.
   MqlRates bars[];
   ENUM_TIMEFRAMES source=PeriodSeconds(_Period)<3600?_Period:PERIOD_H1;
   int n=CopyRates(_Symbol,source,m.start,m.finish-1,bars);
   if(n<=0 || bars[0].time!=m.start) return;
   int hi=0,lo=0;
   for(int j=1;j<n;j++){
      if(bars[j].high>bars[hi].high) hi=j;
      if(bars[j].low<bars[lo].low) lo=j;
   }
   int xO,yO,xC,yC,xH,yH,xL,yL,right,unused;
   datetime observed=(datetime)MathMin((long)m.finish,(long)bars[n-1].time+PeriodSeconds(source));
   if(!ChartTimePriceToXY(0,0,m.start,bars[0].open,xO,yO) ||
      !ChartTimePriceToXY(0,0,bars[n-1].time,bars[n-1].close,xC,yC) ||
      !ChartTimePriceToXY(0,0,bars[hi].time,bars[hi].high,xH,yH) ||
      !ChartTimePriceToXY(0,0,bars[lo].time,bars[lo].low,xL,yL) ||
      !ChartTimePriceToXY(0,0,observed,bars[0].open,right,unused)) return;
   int width=MathMax(1,right-xO),center=xO+width/2;
   if(showDaily){
      color ink=bars[n-1].close>=bars[0].open?clrMediumSeaGreen:clrTomato;
      rectangle(w,h,center,yH,center+1,yL,ColorToARGB(ink,210));
      dailyExtremeHit(m,true,bars[hi].high,xH,yH,center,width>=48);
      dailyExtremeHit(m,false,bars[lo].low,xL,yL,center,width>=48);
      int pad=(int)(width*.08);
      uint tint=ColorToARGB(ink,96);
      for(int row=MathMax(0,MathMin(yO,yC));row<=MathMin(h-1,MathMax(yO,yC));row++)
         for(int col=MathMax(0,xO+pad);col<=MathMin(w-1,right-pad);col++){
            int k=row*w+col;pixels[k]=sourceOver(tint,pixels[k]);
         }
      if(width>=48){
         string key=prefix+"D_"+IntegerToString(m.start);
         priceText(key+"O",m.start,bars[0].open,"O",ink,false,"开盘价");
         priceText(key+"H",bars[hi].time,bars[hi].high,"H",ink,true,"最高价");
         priceText(key+"L",bars[lo].time,bars[lo].low,"L",ink,false,"最低价");
         bool forming=StringFind(m.label,"进行中")>=0;
         priceText(key+"C",bars[n-1].time,bars[n-1].close,"C",ink,true,forming?"暂收价":"收盘价");
         ObjectSetInteger(0,key+"C",OBJPROP_ANCHOR,ANCHOR_RIGHT_LOWER);
         detailHit(xO,yO,xO+10,yO+15,"开盘价 · "+DoubleToString(bars[0].open,_Digits),5);
         detailHit(xC-10,yC-15,xC,yC,(forming?"暂收价 · ":"收盘价 · ")+DoubleToString(bars[n-1].close,_Digits),5);
      }
   }
   if(showOpen && yO>=0 && yO<h){
      detailHit(MathMax(0,xO),yO,MathMin(right,w),yO,"纽约零点开盘 · "+DoubleToString(bars[0].open,_Digits),1,true);
      for(int x=MathMax(0,xO);x<MathMin(right,w);x++)
         if((x-xO)%9<6) pixels[yO*w+x]=ColorToARGB(clrGold,235);
   }
}

void fourHourCloseLine(int w,int h,datetime start,datetime until,datetime confirmed,double level){
   int x,y,z,unused;
   if(!ChartTimePriceToXY(0,0,start,level,x,y) || !ChartTimePriceToXY(0,0,until,level,z,unused))return;
   if(y<0 || y>=h || z<0 || x>=w)return;
   int left=MathMax(0,x),right=MathMin(w-1,z);
   for(int col=left;col<=right;col++)
      if((col-x)%5<2)pixels[y*w+col]=ColorToARGB(clrLightSkyBlue,245);
   detailHit(left,y,right,y,"美东四小时收盘 · "+easternTime(confirmed)+" · "+DoubleToString(level,_Digits),7,true);
}
bool fridayShortClose(datetime bucket,datetime lastM5End){
   MqlDateTime wall;TimeToStruct(bucket,wall);
   return wall.day_of_week==5 && wall.hour==16 && nyWall(lastM5End)==bucket+55*60;
}
struct EasternH4 {
   MqlRates candle;
   datetime bucket,end,tailEnd,until;
   bool friday,confirmed,covered;
};
bool expectedGoldHour(datetime wallTime){
   MqlDateTime d;TimeToStruct(wallTime,d);
   if(d.day_of_week==6)return false;
   if(d.day_of_week==0)return d.hour>=18;
   if(d.day_of_week==5)return d.hour<17;
   return d.hour!=17;
}
int easternFourHours(datetime start,datetime stop,datetime tickTime,EasternH4 &out[]){
   ArrayResize(out,0);
   MqlRates candles[];
   int count=CopyRates(_Symbol,PERIOD_H1,start,stop,candles);
   MqlRates five[];
   int fiveCount=CopyRates(_Symbol,PERIOD_M5,start,stop,five),k=0;
   for(int i=0;i<count;){
      int firstHour=i;
      MqlRates b=candles[i++];
      datetime local=nyWall(b.time);
      if(!local)continue;
      datetime bucket=local-local%14400;
      while(i<count){
         datetime next=nyWall(candles[i].time);
         if(next<bucket || next>=bucket+14400)break;
         b.high=MathMax(b.high,candles[i].high);b.low=MathMin(b.low,candles[i].low);
         b.close=candles[i].close;i++;
      }
      datetime end=nyRaw(bucket+14400);
      if(!end)continue;
      while(k<fiveCount && five[k].time<end)k++;
      bool tailMatches=k>0 && five[k-1].time>=candles[i-1].time &&
                       five[k-1].time<candles[i-1].time+3600 && five[k-1].close==b.close;
      datetime tailEnd=tailMatches?five[k-1].time+300:0;
      bool friday=tailMatches && fridayShortClose(bucket,tailEnd);
      bool confirmed=tickTime>=end && tailMatches && (tailEnd==end || friday);
      datetime until=(datetime)MathMin(MathMin(end,tailMatches?tailEnd:candles[i-1].time+3600),tickTime);
      if(until<b.time)continue;
      int ix=ArraySize(out);ArrayResize(out,ix+1,128);
      out[ix].candle=b;out[ix].bucket=bucket;out[ix].end=end;out[ix].tailEnd=tailEnd;
      out[ix].until=until;out[ix].friday=friday;out[ix].confirmed=confirmed;
      out[ix].covered=true;
      int observed=firstHour;
      for(datetime slot=nyRaw(bucket);slot>0 && slot<end;slot+=3600){
         while(observed<i && candles[observed].time<slot)observed++;
         if(expectedGoldHour(nyWall(slot)) && (observed==i || candles[observed].time!=slot)){out[ix].covered=false;break;}
      }
   }
   return ArraySize(out);
}
bool adjacentEasternH4(const EasternH4 &a,const EasternH4 &b){
   return a.bucket+14400==b.bucket || (a.friday && a.bucket+2*86400==b.bucket);
}
int h4ReviewIndex(datetime stamp){
   int lo=0,hi=ArraySize(h4ReviewIndices);
   while(lo<hi){
      int i=lo+(hi-lo)/2;
      if(marks[h4ReviewIndices[i]].start<stamp)lo=i+1;else hi=i;
   }
   if(lo<ArraySize(h4ReviewIndices) && marks[h4ReviewIndices[lo]].start==stamp)return h4ReviewIndices[lo];
   return -1;
}
void fourHourOverlay(int w,int h){
   if(!showH4 && !showOpen)return;
   int left=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
   int right=MathMax(0,left-(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS)-2);
   datetime first=iTime(_Symbol,_Period,left),last=iTime(_Symbol,_Period,right);
   MqlTick tick;if(first<=0 || last<=0 || !SymbolInfoTick(_Symbol,tick))return;
   EasternH4 groups[];
   int count=easternFourHours((datetime)MathMax(D'2026.06.01',first-4*86400),
                              (datetime)MathMin(tick.time,periodEnd(last)+5*3600-1),tick.time,groups);
   for(int i=0;i<count;i++){
      EasternH4 current=groups[i];MqlRates b=current.candle;
      datetime local=nyWall(b.time),bucket=current.bucket,until=current.until,tailEnd=current.tailEnd,end=current.end;
      bool friday=current.friday,confirmed=current.confirmed;
      int review=tailEnd?h4ReviewIndex(tailEnd):-1;
      if(review>=0 && MathAbs(marks[review].first-b.close)<=_Point/2)confirmed=true;
      else review=-1;
      if(showOpen && i>0 && groups[i-1].confirmed && adjacentEasternH4(groups[i-1],current))
         fourHourCloseLine(w,h,b.time,until,groups[i-1].tailEnd,groups[i-1].candle.close);
      if(!showH4)continue;
      int x,yO,z,yC,ignore,yH,yL;
      if(!ChartTimePriceToXY(0,0,b.time,b.open,x,yO) || !ChartTimePriceToXY(0,0,until,b.close,z,yC) ||
         !ChartTimePriceToXY(0,0,b.time,b.high,ignore,yH) || !ChartTimePriceToXY(0,0,b.time,b.low,ignore,yL))continue;
      if(z<0 || x>=w)continue;
      int width=MathMax(1,z-x),pad=width/7,mid=x+width/2;
      color ink=b.close>=b.open?C'75,208,169':C'241,126,107';
      rectangle(w,h,mid,yH,mid,yL,ColorToARGB(ink,205));
      int top=MathMin(yO,yC),bottom=MathMax(yO,yC);
      for(int row=MathMax(0,top);row<=MathMin(h-1,bottom);row++){
         for(int col=MathMax(0,x+pad);col<=MathMin(w-1,z-pad);col++){
            int pos=row*w+col;
            bool edge=(row==top || row==bottom || col==x+pad || col==z-pad);
            pixels[pos]=sourceOver(ColorToARGB(ink,(uchar)(edge?195:55)),pixels[pos]);
         }
      }
      string tip="美东 H4 分段 · "+TimeToString(bucket,TIME_DATE|TIME_MINUTES)+"–"+TimeToString(bucket+14400,TIME_MINUTES)+
         (local!=bucket?" · 首根 H1 "+TimeToString(local,TIME_MINUTES):"")+"｜"+
         StringFormat("O %s  H %s  L %s  %s %s",DoubleToString(b.open,_Digits),DoubleToString(b.high,_Digits),
            DoubleToString(b.low,_Digits),confirmed?"C":"末价",DoubleToString(b.close,_Digits));
      if(tailEnd)
         tip+="｜末根 M5 "+easternTime(tailEnd-300,TIME_MINUTES)+"–"+easternTime(tailEnd,TIME_MINUTES)+
              (tick.time<tailEnd?" · 最近报价 "+easternTime(tick.time,TIME_SECONDS):
               friday?" · 周五截短":!confirmed && tick.time>=end?" · 后续覆盖待核":"");
      else tip+="｜M5 末价待核";
      if(review>=0){
         Mark note=marks[review];
         tip+="｜"+note.label;
         for(int j=0;j<ArraySize(events);j++){
            Release item=events[j];
            if(item.at<note.start || item.at>=note.finish || item.priority<2)continue;
            bool strong,swept;
            tip+="｜同期 MT5 日历 · "+item.tag+" · "+reaction(item.at,note.finish,strong,swept);
         }
      }else if(confirmed)tip+="｜收盘后交付分析待同步";
      if(width>=8)detailHit(x+pad,yC,z-pad,yC,tip,6,true);
      if(width>=52){
         string root=prefix+"D_H4"+IntegerToString(b.time);
         screenNote(root+"C",z-pad-18,yC-13,confirmed?"4H C":"4H 末",ink,tip,7);
         screenNote(root+"O",x+pad,yO,"O",ink,tip,7);
         screenNote(root+"H",mid+2,yH-12,"H",ink,tip,7);
         screenNote(root+"L",mid+2,yL,"L",ink,tip,7);
      }
   }
}

string profileCaption(const Mark &m){
   string s=m.label;
   int tail=StringFind(s,"｜");if(tail>=0) s=StringSubstr(s,0,tail);
   bool daily=m.kind=="day";
   if(daily){
      int sep=StringFind(s," · ");
      if(StringSubstr(s,0,2)=="周五" && sep>=0) sep=StringFind(s," · ",sep+3);
      if(sep>=0) s=StringSubstr(s,sep+3);
   }
   if(daily && StringSubstr(m.label,0,2)=="周五"){
      if(s=="" || s=="概况候选待形成" || s=="暂不归类" || s=="未归类")
         s=StringFind(m.label,"进行中")>=0?"待定":"暂不归类";
      return "周五日型 · "+s;
   }
   bool pending=StringFind(s,"候选")>=0 || StringFind(s,"部分路径")>=0 || StringFind(m.label,"进行中")>=0;
   bool unresolved=StringFind(s,"未归类")>=0 || StringFind(s,"暂不归类")>=0;
   int detail=StringFind(s," · ");if(detail>=0) s=StringSubstr(s,0,detail);
   int paren=StringFind(s,"（");if(paren>=0) s=StringSubstr(s,0,paren);
   if(unresolved && (s=="暂不归类" || s=="未归类")) s="待定";
   else if((pending || unresolved) && StringFind(s,"候选")<0) s+="?";
   return daily?StringSubstr(m.label,0,2)+" · "+s:s;
}

void dolLines(string &lines[],string value,int width){
   string parts[];int n=StringSplit(value,'｜',parts);
   for(int i=0;i<n;i++) newsLine(lines,parts[i],width);
}
int internalClosedShift(ENUM_TIMEFRAMES tf){
   datetime t=iTime(_Symbol,tf,0);
   if(t<=0 || tf==PERIOD_MN1)return 1;
   return TimeTradeServer()>=t+PeriodSeconds(tf)?0:1;
}
bool internalBalance(const MqlRates &r[],int end,int n,double &bottom,double &top,double &wickLow,double &wickHigh){
   int first=end-n+1;
   double upper[],lower[],tr[];
   ArrayResize(upper,n);ArrayResize(lower,n);ArrayResize(tr,n);
   wickHigh=r[first].high;wickLow=r[first].low;
   double travel=0,overlap=0;
   for(int j=0;j<n;j++){
      int k=first+j;
      upper[j]=MathMax(r[k].open,r[k].close);lower[j]=MathMin(r[k].open,r[k].close);
      wickHigh=MathMax(wickHigh,r[k].high);wickLow=MathMin(wickLow,r[k].low);
      tr[j]=r[k].high-r[k].low;
      if(!j) continue;
      travel+=MathAbs(r[k].close-r[k-1].close);
      overlap+=MathMax(0.,MathMin(r[k].high,r[k-1].high)-MathMax(r[k].low,r[k-1].low))/
               MathMax(_Point,MathMin(tr[j],r[k-1].high-r[k-1].low));
      tr[j]=MathMax(tr[j],MathMax(MathAbs(r[k].high-r[k-1].close),MathAbs(r[k].low-r[k-1].close)));
   }
   if(travel<=0 || MathAbs(r[end].close-r[first].close)>.30*travel || overlap<.50*(n-1)) return false;
   ArraySort(upper);ArraySort(lower);ArraySort(tr);
   top=quantile(upper,.9);bottom=quantile(lower,.1);
   double atr=quantile(tr,.5),width=top-bottom,mid=(top+bottom)/2;
   if(atr<=0 || width<=0 || width>5.5*atr) return false;
   int occupied=0,upVisits=0,downVisits=0,cross=0,last=0;bool up=true,down=true;
   for(int k=first;k<=end;k++){
      double bh=MathMax(r[k].open,r[k].close),bl=MathMin(r[k].open,r[k].close);
      if(bh<=top+.1*atr && bl>=bottom-.1*atr) occupied++;
      int side=r[k].close>mid?1:(r[k].close<mid?-1:0);
      if(side!=0){if(last && last!=side) cross++;last=side;}
      bool touchU=r[k].high>=wickHigh-.2*(wickHigh-wickLow);
      bool touchL=r[k].low<=wickLow+.2*(wickHigh-wickLow);
      if(touchU && touchL) continue;
      if(touchU && up){upVisits++;up=false;}
      if(touchL && down){downVisits++;down=false;}
      if(!touchU && side<=0) up=true;
      if(!touchL && side>=0) down=true;
   }
   return occupied>=.8*n && cross>=4 && upVisits>=2 && downVisits>=2 &&
          r[end].close>=bottom && r[end].close<=top;
}

int closedEasternH4(MqlRates &bars[],datetime &lastClose,datetime cutoff=0){
   if(cutoff==0){
      MqlTick tick;if(!SymbolInfoTick(_Symbol,tick))return 0;
      cutoff=tick.time;
   }
   EasternH4 groups[];
   int n=easternFourHours((datetime)MathMax(D'2026.06.01',cutoff-35*86400),cutoff-1,cutoff,groups);
   int last=n-1;
   while(last>=0 && groups[last].end>cutoff)last--;
   if(last<0 || (last+1<n && !adjacentEasternH4(groups[last],groups[last+1])))return 0;
   int first=last+1;
   while(first>0 && last-first+1<96){
      int j=first-1;
      if(!groups[j].confirmed || !groups[j].covered || (j<last && !adjacentEasternH4(groups[j],groups[j+1])))break;
      first=j;
   }
   int count=last-first+1;ArrayResize(bars,count);
   for(int j=0;j<count;j++)bars[j]=groups[first+j].candle;
   if(count)lastClose=groups[last].tailEnd;
   return count;
}
string internalReading(ENUM_TIMEFRAMES tf){
   string frame=StringSubstr(EnumToString(tf),7);MqlRates b[];
   datetime lastClose=0;
   int n=tf==PERIOD_H4?closedEasternH4(b,lastClose):CopyRates(_Symbol,tf,internalClosedShift(tf),96,b),start=0;
   if(tf==PERIOD_H4)frame="美东 H4";
   while(start<n && b[start].time<D'2026.06.01')start++;
   if(n-start<10)return frame+" · 已收周期数不足，内部范围待定";
   int freeze=n-MathMin(12,(n-start)/2);double hi=0,lo=0;int ih=-1,il=-1;
   for(int j=freeze-2;j>start;j--){
      if(ih<0 && b[j].high>b[j-1].high && b[j].high>b[j+1].high){ih=j;hi=b[j].high;}
      if(il<0 && b[j].low<b[j-1].low && b[j].low<b[j+1].low){il=j;lo=b[j].low;}
      if(ih>=0 && il>=0)break;
   }
   string basis="摆动区间";int rangeStart=MathMin(ih,il);
   double bodyLo,bodyHi,wickLo,wickHi;
   for(int window=24;window>=12;window-=12){
      if(freeze-start<window || !internalBalance(b,freeze-1,window,bodyLo,bodyHi,wickLo,wickHi))continue;
      basis=StringFormat("实体平衡 %.2f–%.2f，影线边缘",bodyLo,bodyHi);
      hi=wickHi;lo=wickLo;rangeStart=freeze-window;break;
   }
   if(basis=="摆动区间" && (ih<0 || il<0 || hi<=lo || ih==il))return frame+" · 缺少可配对的已确认高低锚点";
   double c=b[n-1].close,buy=0,sell=0,gapLo=0,gapHi=0,best=DBL_MAX;
   string swept="";
   int lastReclaim=-1;
   for(int j=MathMax(start+1,rangeStart+1);j<n-1;j++){
      for(int side=-1;side<=1;side+=2){
         double p=side>0?b[j].high:b[j].low;
         if(p<=lo || p>=hi || (side>0?(p<=b[j-1].high || p<=b[j+1].high):(p>=b[j-1].low || p>=b[j+1].low)))continue;
         bool used=false,breach=false;
         for(int k=j+2;k<n;k++){
            bool touched=b[k].low<=p && b[k].high>=p;
            bool outside=(side>0?b[k].high>p:b[k].low<p);
            used|=touched || outside;breach|=touched && outside;
            if(breach && side*(b[k].close-p)<0){
               if(k>=freeze && k>lastReclaim){lastReclaim=k;swept=(side>0?"扫内部高后收回 ":"扫内部低后收回 ")+DoubleToString(p,_Digits);}
               break;
            }
         }
         if(!used && side>0 && p>c && (buy==0 || p<buy))buy=p;
         if(!used && side<0 && p<c && p>sell)sell=p;
      }
   }
   for(int j=rangeStart+2;j<n;j++){
      if(tf==PERIOD_H4){
         datetime last=nyWall(b[j].time),middle=nyWall(b[j-1].time),first=nyWall(b[j-2].time);
         if(last/14400-middle/14400!=1 || middle/14400-first/14400!=1)continue;
      }
      bool bull=b[j].low>b[j-2].high;
      if(!bull && b[j].high>=b[j-2].low)continue;
      double a=bull?b[j-2].high:b[j].high,z=bull?b[j].low:b[j-2].low;
      if(a<=lo || z>=hi || b[j-1].low>a || b[j-1].high<z)continue;
      for(int k=j+1;k<n && a<z;k++){
         if(b[k].high<a || b[k].low>z)continue;
         if(bull)z=MathMin(z,b[k].low);else a=MathMax(a,b[k].high);
      }
      double dist=MathMax(0,MathMax(a-c,c-z));
      if(a<z && dist<best){best=dist;gapLo=a;gapHi=z;}
   }
   string result=frame+(tf==PERIOD_H4?" "+easternTime(lastClose):"")+" 收 "+DoubleToString(c,_Digits)+" · "+basis+" "+DoubleToString(lo,_Digits)+"–"+DoubleToString(hi,_Digits);
   if(c<lo || c>hi)result+="（已收出参照区间）";
   result+=" · 内部买方 "+(buy?DoubleToString(buy,_Digits):"待定")+" / 卖方 "+(sell?DoubleToString(sell,_Digits):"待定");
   if(swept!="")result+=" · "+swept;
   return result+" · 区内剩余 FVG "+(gapLo?DoubleToString(gapLo,_Digits)+"–"+DoubleToString(gapHi,_Digits):"未见");
}
void internalTimeframes(string &lines[],int width){
   ENUM_TIMEFRAMES frames[]={PERIOD_M1,PERIOD_M2,PERIOD_M3,PERIOD_M4,PERIOD_M5,PERIOD_M6,PERIOD_M10,PERIOD_M12,PERIOD_M15,PERIOD_M20,PERIOD_M30,PERIOD_H1,PERIOD_H4,PERIOD_D1,PERIOD_W1};
   static datetime closed[15];static string summary[15];
   newsLine(lines,"多周期 IRL · 各自冻结观察段之前的一对确认摆动，按该周期已收行情解释。",width);
   for(int i=0;i<ArraySize(frames);i++){
      datetime t=frames[i]==PERIOD_H4?iTime(_Symbol,PERIOD_M5,0):iTime(_Symbol,frames[i],internalClosedShift(frames[i]));
      if(t!=closed[i] || summary[i]=="" || StringFind(summary[i],"周期数不足")>=0){
         summary[i]=internalReading(frames[i]);closed[i]=t;
      }
      newsLine(lines,summary[i],width);
   }
}
#include "ICT_Liquidity_Pool.mqh"
#include "ICT_IPDA_View.mqh"
#include "ICT_Price_Brief.mqh"

void realizedDayLines(string &lines[],int width,datetime latest){
   datetime dates[];string scope=showDOL?"DOL":(poolExternal?"ERL":"IRL");
   for(int j=0;j<ArraySize(marks);j++){
      if(marks[j].kind!="day" || marks[j].start>=latest)continue;
      int n=ArraySize(dates);ArrayResize(dates,n+1);dates[n]=marks[j].start;
   }
   ArraySort(dates);int count=ArraySize(dates);
   if(count==0){newsLine(lines,"等待纽约交易日记录",width);return;}
   realizedOffset=MathMax(0,MathMin(count-1,realizedOffset));
   datetime start=dates[count-1-realizedOffset];
   newsLine(lines,easternTime(start,TIME_DATE)+"　"+scope+" 每日已实现目标",width);
   string live=showDOL?"dol_review_day":(poolExternal?"dol_review_pool_erl":"dol_review_pool_irl");
   bool found=false;
   for(int j=0;j<ArraySize(marks);j++){
      Mark m=marks[j];if(m.start!=start || m.kind!=live)continue;
      string entries[];int n=StringSplit(m.label,'｜',entries);
      for(int k=0;k<n;k++)if(StringFind(entries[k],"图表收到")>=0){newsLine(lines,entries[k],width);found=true;}
   }
   if(!found)newsLine(lines,"本日暂未核实图表事前登记的"+scope+"目标。",width);
   newsLine(lines,showDOL?"DOL 以登记后的完整 M5 触及近沿确认。":"按 M5 收线时前十名登记，登记后的完整 M5 须越过外沿。",width);
   found=false;
   for(int j=0;j<ArraySize(marks);j++){
      Mark m=marks[j];if(m.start!=start || m.kind!=(showDOL?"dol_study_day":"pool_study_day"))continue;
      string entries[];int n=StringSplit(m.label,'｜',entries);
      for(int k=0;k<n;k++){
         string row=entries[k];
         if(StringFind(row,"历史重建")==0)continue;
         if(!showDOL && StringFind(row,scope)<0)continue;
         if(!found)newsLine(lines,"历史重建 · "+(showDOL?"DOL":"来源明确标注 "+scope),width);
         newsLine(lines,row,width);found=true;
      }
   }
   if(!found)newsLine(lines,"此日无可归入本栏的重建记录。",width);
   if(showPool){
      newsLine(lines,"当日前高前低清扫 · 按前一纽约交易日区间分层",width);
      bool observed=false;string wanted=poolExternal?"day_sweep_erl":"day_sweep_irl";
      for(int j=0;j<ArraySize(marks);j++){
         Mark m=marks[j];if(m.kind!=wanted || easternTime(m.start,TIME_DATE)!=easternTime(start,TIME_DATE))continue;
         dolLines(lines,m.label,width);observed=true;
      }
      if(!observed)newsLine(lines,"暂无该层级已核实的日内清扫。",width);
   }
}
void drawOutlook(int w,int h){
   string base=prefix+"DOLVIEW_";ObjectsDeleteAll(0,base);
   button("DOL","DOL 预判",105,showDOL);
   ObjectSetInteger(0,prefix+"DOL",OBJPROP_YDISTANCE,w<830?118:90);
   button("POOL","内部流动性积累",323,showPool && !poolExternal,110,7);
   button("POOL_ERL","外部流动性积累",439,showPool && poolExternal,110,7);
   ObjectSetInteger(0,prefix+"POOL",OBJPROP_YDISTANCE,w<830?118:90);
   ObjectSetInteger(0,prefix+"POOL_ERL",OBJPROP_YDISTANCE,w<830?118:90);
   int priceX=w>=740?730:(w>=640?100:285);
   int priceY=w>=830?90:(w>=740?118:145);
   button("PRICE","价格实况",priceX,showPrice,91);
   ObjectSetInteger(0,prefix+"PRICE",OBJPROP_YDISTANCE,priceY);
   if(!showDOL && !showPool && !showIPDA && !showPrice) return;
   int width=MathMin(438,w-12),top=MathMax(priceY+27,w<830?144:117);
   if(width<90 || h<top+70) return;
   string lines[];int per=MathMax(1,MathMin(16,(h-top-95)/18));dolIrlPage=0;TextSetFont("Microsoft YaHei",-103);
   MqlTick tick;bool quoted=SymbolInfoTick(_Symbol,tick) && tick.bid>0;
   datetime now=TimeTradeServer();int state=-1;
   for(int i=0;i<ArraySize(marks);i++) if(marks[i].kind=="dol_context") state=i;
   if(showPrice)priceBriefLines(lines,width-18,state,quoted,tick);
   else if(showIPDA)ipdaPanelLines(lines,width-18);
   else if(showRealized)realizedDayLines(lines,width-18,state>=0?marks[state].start:tick.time);
   else if(showPool)poolLines(lines,width-18);
   else{
   if(quoted) newsLine(lines,"XAUUSD   Bid "+DoubleToString(tick.bid,_Digits)+"  Ask "+DoubleToString(tick.ask,_Digits)+"   美东 "+easternTime(tick.time),width-18);
   if(state<0) newsLine(lines,"等待行情桥的已收 M5 背景",width-18);
   else{
      datetime at=marks[state].start;
      newsLine(lines,"证据截至美东 "+easternTime(at)+" · "+(quoted && now-tick.time>900?"最近报价":"最近已收 M5"),width-18);
      newsLine(lines,"DOL 条件路径 · 获取流动性 / 平衡不平衡",width-18);
      MqlRates since[];int n=0;
      datetime visibleFrom=(datetime)MathMax(at,dolReceivedServer);
      bool received=dolReceivedServer>0;
      if(quoted && received && tick.time>=visibleFrom)n=CopyRates(_Symbol,PERIOD_M5,visibleFrom,tick.time,since);
      string details[];
      newsLine(lines,"近期优先级 / 100 · 最长4小时，限纽约当日",width-18);
         for(int j=0;j<ArraySize(marks);j++){
            Mark m=marks[j];if((m.kind!="dol_up" && m.kind!="dol_down") || m.start!=at) continue;
            int side=m.kind=="dol_up"?1:-1;
            double edge=side>0?m.first:m.last;
            bool crossed=false;
            for(int k=0;k<n && !crossed;k++) crossed=since[k].time>=visibleFrom && since[k].time+300<=tick.time &&
                                                       since[k].low<=edge && since[k].high>=edge;
            string range=DoubleToString(m.first,_Digits)+(m.last!=m.first?"–"+DoubleToString(m.last,_Digits):"");
            string title=(m.first==m.last?"流动性 ":"不平衡 ")+range;
            if(crossed) title+=" · M5 已见触达";
            else if(received && quoted && tick.time>=visibleFrom && MathAbs(tick.bid-edge)<_Point/2)title+=" · 当前报价触及";
            else if(quoted) title+=StringFormat(" · 距 Bid %.2f",MathAbs(tick.bid-edge));
            if(quoted && tick.time-at>600) title+=" · 背景延迟，待更新";
            int split=StringFind(m.label,"｜");
            string rank=split<0?m.label:StringSubstr(m.label,0,split);
            int dot=StringFind(rank,". "),slash=StringFind(rank,"/100");
            if(dot>0 && slash>dot){
               int ordinal=(int)StringToInteger(StringSubstr(rank,0,dot));
               int score=(int)StringToInteger(StringSubstr(rank,dot+2,slash-dot-2));
               rank=StringFormat("#%02d   %d/100",ordinal,score)+StringSubstr(rank,slash+4);
            }
            newsLine(lines,rank+" · "+title,width-30);
            dolLines(details,m.label,width-18);
         }
      if(PeriodSeconds(_Period)<=3600 || _Period==PERIOD_H4 || _Period==PERIOD_D1 || _Period==PERIOD_W1)
         newsLine(lines,"当前周期 IRL · "+internalReading(_Period),width-18);
      for(int j=0;j<ArraySize(details);j++)newsLine(lines,details[j],width-18);
      dolLines(lines,marks[state].label,width-18);
      for(int j=ArraySize(events)-1;j>=0;j--){
         if(events[j].at>now || events[j].at<at-4*3600 || events[j].at>at) continue;
         newsLine(lines,"最近公布 · "+easternTime(events[j].at)+" "+events[j].tag+" · "+events[j].path,width-18);
         newsLine(lines,eventWeek(events[j].at,now),width-18);break;
      }
      int listed=0;for(int j=0;j<ArraySize(events) && listed<4;j++){
         if(events[j].at<now || events[j].at>now+7*86400) continue;
         newsLine(lines,"待公布 · "+easternTime(events[j].at)+" "+events[j].tag,width-18);listed++;
      }
      if(!listed)newsLine(lines,"未来7天尚无已载入排期",width-18);
      MqlDateTime today;TimeToStruct(now,today);
      int ref=weekReference(now+(today.day_of_week==6?2:(today.day_of_week==0?1:0))*86400);
      if(ref>=0) dolLines(lines,weeklyScenario(marks[ref]),width-18);
      newsLine(lines,"公布前观察双向路径。公布后核对扫回、收破和跟随；冲突时保留两侧。",width-18);
      dolIrlPage=(ArraySize(lines)+per-1)/per;
      ArrayResize(lines,dolIrlPage*per);
      internalTimeframes(lines,width-18);
      newsLine(lines,"依据《如何寻找偏见和DOL》4:27–6:44、10:29–13:14。等级表示证据方向，尚无样本外概率。",width-18);
   }
   }
   dolPages=MathMax(1,(ArraySize(lines)+per-1)/per);dolPage=MathMax(0,MathMin(dolPage,dolPages-1));
   int from=dolPage*per,to=MathMin(from+per,ArraySize(lines)),x=w-width-5;
   bool tabs=showDOL || showPool;
   if(showIPDA || showPrice)top=MathMax(top,h-52-(to-from+1)*18-12);
   dolPanelLeft=x;dolPanelTop=top;dolPanelBottom=top+(to-from+1)*18+12+(tabs?22:0);
   ObjectCreate(0,base+"bg",OBJ_RECTANGLE_LABEL,0,0,0);
   ObjectSetInteger(0,base+"bg",OBJPROP_XDISTANCE,x);ObjectSetInteger(0,base+"bg",OBJPROP_YDISTANCE,top);
   ObjectSetInteger(0,base+"bg",OBJPROP_XSIZE,width);ObjectSetInteger(0,base+"bg",OBJPROP_YSIZE,dolPanelBottom-top);
   ObjectSetInteger(0,base+"bg",OBJPROP_BGCOLOR,C'24,31,38');ObjectSetInteger(0,base+"bg",OBJPROP_BORDER_TYPE,BORDER_FLAT);
   for(int k=from;k<to;k++){
      string id=base+IntegerToString(k);bool heading=StringFind(lines[k],"#")==0;
      color ink=clrWhite;
      if(heading){
         int score=(int)StringToInteger(StringSubstr(lines[k],StringFind(lines[k]," ")));
         ink=score>=70?clrAquamarine:score>=50?clrLightSkyBlue:clrSilver;
         if(StringFind(lines[k],"#01 ")==0)ink=clrGold;
      }
      bool phaseHeading=showIPDA && (StringFind(lines[k],"当前 M15")==0 || StringFind(lines[k],"上次 M15")==0);
      bool phaseScore=showIPDA && StringFind(lines[k],"形态支持   ")==0;
      bool forecast=showIPDA && StringFind(lines[k],"未来一小时   ")==0;
      if(phaseHeading)ink=clrWhite;
      if(phaseScore)ink=clrGold;
      if(forecast)ink=clrLightSkyBlue;
      screenNote(id,x+8,top+5+(k-from)*18,lines[k],ink,"\n",phaseHeading || phaseScore?10:(heading || forecast?9:8));
      if(heading || phaseHeading || phaseScore || forecast)ObjectSetString(0,id,OBJPROP_FONT,"Microsoft YaHei UI Bold");
   }
   screenNote(base+"prev",x+8,dolPanelBottom-21,"‹ 上一页",clrLightBlue,"上一页");
   screenNote(base+"next",x+98,dolPanelBottom-21,StringFormat("%d / %d   下一页 ›",dolPage+1,dolPages),clrLightBlue,"下一页");
   ObjectSetInteger(0,base+"next",OBJPROP_ZORDER,12);ObjectSetInteger(0,base+"prev",OBJPROP_ZORDER,12);
   if(tabs){
      screenNote(base+"realized",x+8,dolPanelBottom-43,showRealized?"‹ 返回排名":"每日已实现目标 ›",clrGold,"切换目标记录");
      ObjectSetInteger(0,base+"realized",OBJPROP_ZORDER,12);
      if(showRealized){
         screenNote(base+"older",x+123,dolPanelBottom-43,"‹ 前一日",clrLightBlue,"前一交易日");
         screenNote(base+"newer",x+205,dolPanelBottom-43,"后一日 ›",clrLightBlue,"后一交易日");
         ObjectSetInteger(0,base+"older",OBJPROP_ZORDER,12);ObjectSetInteger(0,base+"newer",OBJPROP_ZORDER,12);
      }
   }
   if(width>285 && state>=0 && showDOL && !showRealized){
      screenNote(base+"irl",x+220,dolPanelBottom-21,"各周期 IRL",clrLightBlue,"跳到分周期内部流动性详情");
      ObjectSetInteger(0,base+"irl",OBJPROP_ZORDER,12);
   }
}
void header(string name,string title,string full,int left,int right,int y){
   int space=right-left;
   if(space<35){ObjectDelete(0,name);return;}
   string caption=title;
   TextSetFont("Microsoft YaHei",-90);
   uint tw,th;
   while(StringLen(caption)>1 && TextGetSize(caption,tw,th) && (int)tw>space-8){
      caption=StringSubstr(caption,0,StringLen(caption)-1);
   }
   if(caption!=title) caption+="…";
   if(ObjectFind(0,name)<0) ObjectCreate(0,name,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_UPPER);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,(left+right)/2);
   ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,name,OBJPROP_COLOR,ChartGetInteger(0,CHART_COLOR_FOREGROUND));
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,9);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");
   ObjectSetString(0,name,OBJPROP_TEXT,caption);
   ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
   int half=textWidth(caption)/2+3;
   int markIndex=(int)StringToInteger(StringSubstr(name,StringLen(prefix+"H_")));
   addProfileHit((left+right)/2-half,(left+right)/2+half,y,markIndex,full);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
}

string deliveryContext(const Mark &phase){
   datetime at=phase.finish;
   int silver=-1,h4=-1;
   for(int j=0;j<ArraySize(marks);j++){
      Mark item=marks[j];
      if(item.start>at || item.start<at-4*3600)continue;
      if(item.kind=="silver" && (silver<0 || item.start>marks[silver].start))silver=j;
      if(item.kind=="h4_review" && item.finish<=at && (h4<0 || item.start>marks[h4].start))h4=j;
   }
   string detail=phase.label,parts[];
   if(silver>=0 && StringSplit(marks[silver].label,StringGetCharacter("｜",0),parts)>=3){
      string filter=silverNewsFilter(marks[silver]);
      detail+="｜最近银弹 · "+parts[1]+" · "+(filter==""?parts[0]:"未触发killzone · "+filter+" 过滤")+" · 价格观察 · "+parts[2];
   }
   if(h4>=0 && StringSplit(marks[h4].label,StringGetCharacter("｜",0),parts)>=2)
      detail+="｜"+parts[0]+" · "+parts[1];
   int count=0;
   for(int j=0;j<ArraySize(events);j++){
      if(events[j].at<at-4*3600 || events[j].at>at)continue;
      bool strong,swept;
      detail+="｜"+easternTime(events[j].at,TIME_MINUTES)+" "+events[j].tag+" · "+reaction(events[j].at,at,strong,swept);
      count++;
   }
   if(count==0)detail+="｜此前四小时已载入日历中无重大公布记录";
   return detail;
}
void layout(){
   int w=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),h=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   if(w<2 || h<2 || ArrayResize(pixels,w*h)!=w*h) return;
   ArrayInitialize(pixels,0);
   ArrayResize(detailHits,0);
   ArrayResize(profileHits,0);
   bool wrapSessions=w<830;
   button("DAYPATH","日概况折线",w>=930?921:(w>=830?822:309),showDayPath);
   ObjectSetInteger(0,prefix+"DAYPATH",OBJPROP_YDISTANCE,w>=930?63:90);
   button("SESS","三盘",wrapSessions?105:819,showSessions);
   button("H4","H4覆盖",207,showH4);
   ObjectSetInteger(0,prefix+"H4",OBJPROP_YDISTANCE,90);
   ObjectSetInteger(0,prefix+"SESS",OBJPROP_YDISTANCE,wrapSessions?90:63);
   int sx=w-(wrapSessions?105:819),sy=wrapSessions?90:63;
   detailHit(sx,sy,sx+96,sy+23,"东京 TK · 伦敦 EU · 纽约 NY",7);
   ObjectDelete(0,prefix+"IPDA");
   string latest="";int viewCount=0;
   int far=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
   datetime visStart=iTime(_Symbol,_Period,far),visEnd=periodEnd(iTime(_Symbol,_Period,MathMax(0,far-(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS))));
   visibleSweeps(visStart,visEnd,w);
   for(int k=0;k<ArraySize(marks);k++){
      if(marks[k].kind=="judas_status")latest=marks[k].label;
      if((marks[k].kind=="judas_up" || marks[k].kind=="judas_down") && marks[k].start>=visStart && marks[k].start<visEnd)viewCount++;
   }
   detailHit(w-207,63,w-111,86,tfName()+" SMT 虚线 · 黄金 / 白银、美元指数 · "+smtStatus+
      "｜实线 · M1 / M5 犹大摆动 · 当前视野 "+IntegerToString(viewCount)+" 个确认｜"+latest,7);
   detailHit(w-309,63,w-213,86,"纽约 03–04、10–11、14–15 · 已收 M5 窗口",7);
   sessionBoxes(w,h);
   ObjectsDeleteAll(0,prefix+"D_");
   double price=ChartGetDouble(0,CHART_PRICE_MAX);
   // Daily bodies, silver tint over those bodies, then dividers on top.
   for(int layer=0;layer<4;layer++){
      if(layer==1)fourHourOverlay(w,h);
      string kind=layer==1?"silver":layer==3?"week":"day";
      for(int i=0;i<ArraySize(marks);i++){
         Mark m=marks[i];
         if(m.kind!=kind || (layer==1 && !showSilver)) continue;
         int x,endX,unused;
         string name=prefix+"H_"+IntegerToString(i);
         if(m.kind=="day" && layer==2 && StringSubstr(m.label,0,2)=="周五")ObjectDelete(0,name+"_TGIF");
         if(!ChartTimePriceToXY(0,0,m.start,price,x,unused) || !ChartTimePriceToXY(0,0,m.finish,price,endX,unused)){
            if(layer>=2) ObjectDelete(0,name);
            continue;
         }
         int left=MathMax(0,x),right=MathMin(w,endX);
         if(layer==0){
            if(right>left && (showDaily || showOpen)) dailyOverlay(m,w,h);
            continue;
         }
         if(layer==1){
            silverBox(i,x,endX,w,h);
            continue;
         }
         if(right-left>=35)header(name,profileCaption(m),m.label+profileNews(m),left,right,layer==3?18:38);
         else ObjectDelete(0,name);
         if(x>=0 && x<w){
            int thickness=MathMin(layer==3?3:2,w-x);
            uint ink=layer==3?ColorToARGB(clrRed,255):ColorToARGB(clrWhite,225);
            for(int y=0;y<h;y++) if(layer==3 || y%10<6) ArrayFill(pixels,y*w+x,thickness,ink);
         }
      }
   }
   for(int j=0;j<ArraySize(marks);j++){
      Mark week=marks[j];if(week.kind!="week") continue;
      int x,z,y;
      if(!ChartTimePriceToXY(0,0,week.start,price,x,y) || !ChartTimePriceToXY(0,0,week.finish,price,z,y) || x>=w || z<0) continue;
      string reason;
      string status=weeklyRulers(week.start,w,h,reason);
      datetime fri=week.finish-86400;
      for(int i=0;i<ArraySize(marks);i++){
         Mark day=marks[i];if(day.kind!="day" || day.start!=fri) continue;
         int fx;if(!ChartTimePriceToXY(0,0,fri,price,fx,y)) continue;
         string tgif=tgifCaption(status,reason);
         string detail=(TimeTradeServer()>=fri+17*3600?"收盘核对 · ":"盘中评估 · ")+tgif+"（"+status+"）";
         if(reason!="") detail+="\n"+reason;
         detail+="\n周初对侧极点 · 周二至四同向扩张 · 周五前未触及周幅20%–30%回撤带";
         header(prefix+"H_"+IntegerToString(i)+"_TGIF",tgif,detail+"\n"+profileCaption(day)+"｜"+day.label+profileNews(day),MathMax(0,fx),MathMin(w,z),1);
      }
   }
   ObjectsDeleteAll(0,prefix+"S_");
   if(showSMT){
      drawSignals(periodSignals,w,h);
      for(int j=0;j<ArraySize(marks);j++)
         if(StringFind(marks[j].kind,"judas_")==0) smtBracket(marks[j],j,w,h);
   }
   drawAMD(w,h);
   drawFilteredFVG();
   timeAxis(w,h);
   if(ResourceCreate(bitmap,pixels,w,h,0,0,w,COLOR_FORMAT_ARGB_NORMALIZE)){
      string bg=prefix+"BG";
      if(ObjectFind(0,bg)<0) ObjectCreate(0,bg,OBJ_BITMAP_LABEL,0,0,0);
      ObjectSetString(0,bg,OBJPROP_BMPFILE,0,bitmap);
      ObjectSetInteger(0,bg,OBJPROP_XSIZE,w);
      ObjectSetInteger(0,bg,OBJPROP_YSIZE,h);
      ObjectSetInteger(0,bg,OBJPROP_BACK,true);
      ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);
      ObjectSetString(0,bg,OBJPROP_TOOLTIP,"\n");
   }
   drawNewsLabels();
   drawSmc(w);
   // Paint the opaque detail panel after the chart annotations it covers.
   drawOutlook(w,h);
   hoverKey="refresh";hoverWindows(lastMouseX,lastMouseY);
   ChartRedraw();
   dolBatchDrawn=true;
   recordDOLReceipt();
}

string switchKey(){return "ICTProfilesLayers_"+IntegerToString(ChartID());}
int OnInit(){
   if(_Symbol!="XAUUSD") return INIT_FAILED;
   hadScale=(bool)ChartGetInteger(0,CHART_SHOW_DATE_SCALE);hadMouse=(bool)ChartGetInteger(0,CHART_EVENT_MOUSE_MOVE);viewReady=true;
   ChartSetInteger(0,CHART_SHOW_DATE_SCALE,false);ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,true);
   if(GlobalVariableCheck(switchKey())){
      int flags=(int)GlobalVariableGet(switchKey());
      showSMT=(flags&1)!=0;showPath=(flags&2)!=0;showSilver=(flags&4)!=0;showDaily=(flags&8)!=0;showOpen=(flags&16)!=0;showAmdLarge=(flags&32)!=0;showFVG=(flags&64)!=0;
      showAmdSmall=(flags&8192)!=0?(flags&16384)!=0:showAmdLarge;
      showSessions=(flags&128)==0; // Older saved charts displayed all three sessions.
      showH4=(flags&256)!=0;
      showDayPath=(flags&32768)==0;
      showPool=(flags&512)!=0;
      poolExternal=(flags&1024)!=0;
      showSMC=(flags&2048)!=0;showIPDA=(flags&4096)==0;
      GlobalVariableDel(switchKey());
   }
   string smcKey=switchKey()+"_SMC";
   if(GlobalVariableCheck(smcKey)){
      int state=(int)GlobalVariableGet(smcKey);
      if((state&(1<<21))!=0)
         for(int k=0;k<SM_OPTIONS;k++)smcOptions[k]=(state&(1<<k))!=0;
      breakTier=((state>>16)&3)-1;equalTier=((state>>18)&3)-1;
      smcPanel=(state&(1<<21))!=0 && (state&(1<<20))!=0;GlobalVariableDel(smcKey);
   }
   bitmap="::ICT_H1_Profile_"+IntegerToString(ChartID());
   IndicatorSetString(INDICATOR_SHORTNAME,"ICT 日周概况 "+tfName());
   int oldWindow=ChartWindowFind(0,"ICT 美元经济日历");
   if(oldWindow>0) ChartIndicatorDelete(0,oldWindow,"ICT 美元经济日历");
   EventSetMillisecondTimer(200);
   revision="";smtStatus="";ArrayResize(periodSignals,0);ArrayInitialize(loadedState,0);
   readMarks();readPeriodSmt();refreshAMD();paths();layout();
   Print("ICT Profiles ready: ",tfName()," · IPDA H4/H1/M15/M5 independent view · ",smtStatus);
   return INIT_SUCCEEDED;
}
void OnTimer(){
   serviceProfileHover();
   static ulong maintenanceAt=0;
   if(GetTickCount64()<maintenanceAt)return;
   maintenanceAt=GetTickCount64()+5000;
   recordDOLReceipt();
   bool newsChanged=false;
   if(TimeTradeServer()>=newsRefreshAt){loadNews();newsChanged=true;}
   if(iTime(_Symbol,PERIOD_M5,0)!=newsObservedBar){
      newsObservedBar=iTime(_Symbol,PERIOD_M5,0);newsChanged=true;
   }
   bool feed=readMarks(),signals=readPeriodSmt(feed),amd=refreshAMD();
   if(newsChanged || amd || feed) updateNewsPaths(TimeTradeServer(),amd || feed);
   if(newsChanged || feed || signals || amd){ObjectsDeleteAll(0,prefix+"H_");paths();layout();}
   else{
      static long lastTick=0;
      MqlTick tick;
      if(SymbolInfoTick(_Symbol,tick) && lastTick!=tick.time_msc){lastTick=tick.time_msc;layout();}
   }
}
void OnChartEvent(const int id,const long &l,const double &d,const string &s){
   if(id==CHARTEVENT_KEYDOWN && l==27 && profileStart){closeProfile();return;}
   if(id==CHARTEVENT_KEYDOWN && hoverPages>1 && (l==219 || l==221)){
      turnHoverPage(l==221?1:-1);return;
   }
   if(id==CHARTEVENT_OBJECT_CLICK && StringFind(s,prefix+"TIP_nav")==0){
      if(s==prefix+"TIP_navDOL"){switchProfileTab(1);return;}
      if(s==prefix+"TIP_navPool"){switchProfileTab(2);return;}
      if(s==prefix+"TIP_navClose"){closeProfile();return;}
      turnHoverPage(s==prefix+"TIP_navNext"?1:s==prefix+"TIP_navPrev"?-1:0);return;
   }
   if(id==CHARTEVENT_MOUSE_MOVE){hoverWindows((int)l,(int)d);return;}
   if(id==CHARTEVENT_CHART_CHANGE){layout();return;}
   if(id!=CHARTEVENT_OBJECT_CLICK) return;
   if(s==prefix+"PRICE"){showPrice=!showPrice;showPool=false;showIPDA=false;showDOL=false;smcPanel=false;dolPage=0;layout();return;}
   if(smcClick(s)){showPrice=false;layout();return;}
   if(s==prefix+"DOL" || s==prefix+"POOL" || s==prefix+"POOL_ERL"){smcPanel=false;showIPDA=false;showPrice=false;showRealized=false;realizedOffset=0;}
   if(s==prefix+"DOLVIEW_realized"){showRealized=!showRealized;dolPage=0;realizedOffset=0;layout();return;}
   if(s==prefix+"DOLVIEW_older" || s==prefix+"DOLVIEW_newer"){realizedOffset+=s==prefix+"DOLVIEW_older"?1:-1;dolPage=0;layout();return;}
   if(s==prefix+"DOL"){showDOL=!showDOL;showPool=false;dolPage=0;layout();return;}
   if(s==prefix+"POOL" || s==prefix+"POOL_ERL"){
      bool external=s==prefix+"POOL_ERL";
      showPool=!showPool || external!=poolExternal;
      poolExternal=external;showDOL=false;dolPage=0;layout();return;
   }
   if(s==prefix+"DOLVIEW_irl"){dolPage=dolIrlPage;layout();return;}
   if(s==prefix+"DOLVIEW_next" || s==prefix+"DOLVIEW_prev"){
      dolPage=(dolPage+dolPages+(s==prefix+"DOLVIEW_next"?1:-1))%dolPages;layout();return;
   }
   if(clickNews(s)){lastMouseX=-1;lastMouseY=-1;layout();return;}
   if(s==prefix+"SESS"){showSessions=!showSessions;layout();return;}
   if(s==prefix+"H4"){showH4=!showH4;layout();return;}
   if(s==prefix+"SMT") showSMT=!showSMT;
   else if(s==prefix+"PATH") showPath=!showPath;
   else if(s==prefix+"DAYPATH") showDayPath=!showDayPath;
   else if(s==prefix+"SILVER") showSilver=!showSilver;
   else if(s==prefix+"DAILY") showDaily=!showDaily;
   else if(s==prefix+"OPEN") showOpen=!showOpen;
   else if(s==prefix+"FVGB") showFVG=!showFVG;
   else if(s==prefix+"AMDB") showAmdLarge=!showAmdLarge;
   else if(s==prefix+"AMDSB") showAmdSmall=!showAmdSmall;
   else return;
   readPeriodSmt();if(refreshAMD()) updateNewsPaths(TimeTradeServer(),true);paths();layout();
}
int OnCalculate(const int total,const int prev,const datetime &times[],const double &o[],const double &hi[],const double &lo[],const double &cl[],const long &tv[],const long &v[],const int &sp[]){
   if(total!=prev && prev>0) layout();
   else if((showPool || showPrice) && prev>0){
      static ulong painted=0;
      if(GetTickCount64()-painted>=250){
         painted=GetTickCount64();drawOutlook((int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS));ChartRedraw();
      }
   }
   return total;
}
void OnDeinit(const int reason){
   if(reason==REASON_CHARTCHANGE || reason==REASON_RECOMPILE){
      GlobalVariableTemp(switchKey());
      GlobalVariableSet(switchKey(),(showSMT?1:0)+(showPath?2:0)+(showSilver?4:0)+(showDaily?8:0)+(showOpen?16:0)+(showAmdLarge?32:0)+(showFVG?64:0)+(showSessions?0:128)+(showH4?256:0)+(showPool?512:0)+(poolExternal?1024:0)+(showSMC?2048:0)+(showIPDA?0:4096)+8192+(showAmdSmall?16384:0)+(showDayPath?0:32768));
      int state=(1<<21)|((breakTier+1)<<16)|((equalTier+1)<<18)|(smcPanel?(1<<20):0);
      for(int k=0;k<SM_OPTIONS;k++)if(smcOptions[k])state|=1<<k;
      string smcKey=switchKey()+"_SMC";GlobalVariableTemp(smcKey);GlobalVariableSet(smcKey,state);
   }
   if(viewReady){ChartSetInteger(0,CHART_SHOW_DATE_SCALE,hadScale);ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,hadMouse);}
   EventKillTimer();ObjectsDeleteAll(0,prefix);if(bitmap!="")ResourceFree(bitmap);
}
