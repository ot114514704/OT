// Closed native candles. Work inside each continuous run and each swing tier.
bool showSMC=true,smcPanel=false;
enum SmcOption {SM_BREAK,SM_EQUAL,SM_CISD,SM_ST,SM_IT,SM_LT,SM_COMPARE,SM_LINK,SM_FIRST,SM_STRONG,SM_ACTIVE,SM_CHOCH,SM_OPTIONS};
bool smcOptions[SM_OPTIONS]={true,false,true,false,false,false,false,false,false,false,false,false};
string smcNames[SM_OPTIONS]={"BOS/CHoCH","EQH/EQL","CISD","ST","IT","LT","HH/HL","同层连线","首次/待定","强位移","仅有效等位","CHoCH"};
color smcInks[SM_OPTIONS+4]={clrLightSkyBlue,clrKhaki,clrPlum,clrPaleGreen,clrTurquoise,clrLightSteelBlue,
                            clrPeachPuff,clrLightCyan,clrLavender,clrLightSalmon,clrWheat,clrCoral,
                            clrAquamarine,clrMistyRose,clrPowderBlue,clrPaleGoldenrod};
string smcTier[3]={"ST","IT","LT"};
int breakTier=-1,equalTier=-1;
struct SmcMark {int kind,tier,side;datetime a,z,known;double p,q;string label,relative;bool strong,active;};
SmcMark smcMarks[];
string smcSnapshot="";

int smcAdd(int kind,int tier,int side,datetime a,datetime z,datetime known,double p,double q,string label){
   int n=ArraySize(smcMarks);ArrayResize(smcMarks,n+1,128);
   smcMarks[n].kind=kind;smcMarks[n].tier=tier;smcMarks[n].side=side;smcMarks[n].a=a;smcMarks[n].z=z;
   smcMarks[n].known=known;smcMarks[n].p=p;smcMarks[n].q=q;smcMarks[n].label=label;
   smcMarks[n].relative="";smcMarks[n].strong=false;smcMarks[n].active=true;return n;
}
double smcExtreme(const MqlRates &bar,int side){return side>0?bar.high:bar.low;}
double smcATR(const MqlRates &r[],int i,int start){
   if(i-start<14)return 0;
   double total=0;
   for(int j=i-14;j<i;j++){
      double span=r[j].high-r[j].low;
      if(j>start)span=MathMax(span,MathMax(MathAbs(r[j].high-r[j-1].close),MathAbs(r[j].low-r[j-1].close)));
      total+=span;
   }
   return total/14;
}
void smcRun(const MqlRates &r[],int start,int end,bool gapAfter){
   int basis[3][2],second[3][2],direction[3]={0,0,0};
   bool used[3][2];ArrayInitialize(basis,-1);ArrayInitialize(second,-1);ArrayInitialize(used,false);
   int seq=-1,moveBefore=0,opposite=-1,triggers=0;bool cisd=false;
   for(int i=start;i<end;i++){
      datetime known=periodEnd(r[i].time);
      double atr=smcATR(r,i,start);
      for(int tier=0;tier<3;tier++){
         int nextDirection=0,counts=0,firstMark=ArraySize(smcMarks);
         for(int s=0;s<2;s++){
            int side=s==0?-1:1,pivot=basis[tier][s];
            if(pivot<0 || used[tier][s])continue;
            double ref=smcExtreme(r[pivot],side);
            if(side*(r[i].close-ref)<=0)continue;
            int ix=smcAdd(SM_BREAK,tier,side,r[pivot].time,r[i].time,known,ref,ref,
                 direction[tier]==0?"INIT":(direction[tier]==side?"BOS":"CHoCH"));
            double span=r[i].high-r[i].low,body=side*(r[i].close-r[i].open);
            smcMarks[ix].strong=atr>0 && span>=1.2*atr && body>=.6*span && side*(r[i].close-ref)>=.1*atr;
            used[tier][s]=true;nextDirection=side;counts++;
         }
         if(counts>1){for(int k=firstMark;k<ArraySize(smcMarks);k++)smcMarks[k].label="待定";direction[tier]=0;}
         else if(counts==1)direction[tier]=nextDirection;
      }
      if(i>=start+2){
         for(int s=0;s<2;s++){
            int side=s==0?-1:1,pivot=i-1;
            if(side*smcExtreme(r[pivot],side)<=MathMax(side*smcExtreme(r[i-2],side),side*smcExtreme(r[i],side)))continue;
            for(int tier=0;tier<3;tier++){
               int prev=basis[tier][s],older=second[tier][s];
               double p=smcExtreme(r[pivot],side);
               int ix=smcAdd(SM_ST+tier,tier,side,r[pivot].time,r[pivot].time,known,p,p,smcTier[tier]+(side>0?"H":"L"));
               if(prev>=0){
                  double old=smcExtreme(r[prev],side);
                  smcMarks[ix].relative=p==old?"EQ":(side>0?(p>old?"HH":"LH"):(p>old?"HL":"LL"));
                  smcAdd(SM_LINK,tier,side,r[prev].time,r[pivot].time,known,old,p,"");
                  double tol=MathMax(2*_Point,.1*smcATR(r,pivot,start));
                  if(pivot-prev>=2 && MathAbs(p-old)<=tol+_Point*1e-8){
                     double mid=(old+p)/2,edge=MathMax(side*p,side*old)+tol;
                     int eq=smcAdd(SM_EQUAL,tier,side,r[prev].time,r[pivot].time,known,mid,mid,side>0?"EQH":"EQL");
                     for(int j=prev+1;j<end;j++)if(side*smcExtreme(r[j],side)>edge){smcMarks[eq].active=false;break;}
                     if(gapAfter)smcMarks[eq].active=false;
                  }
               }
               second[tier][s]=prev;basis[tier][s]=pivot;used[tier][s]=false;
               for(int j=pivot+1;j<=i;j++)if(side*(r[j].close-p)>0){used[tier][s]=true;break;}
               if(older<0 || side*smcExtreme(r[prev],side)<=MathMax(side*smcExtreme(r[older],side),side*p))break;
               pivot=prev;
            }
         }
      }
      int move=r[i].close>r[i].open?1:(r[i].close<r[i].open?-1:0);
      if(move==0){seq=-1;moveBefore=0;opposite=-1;continue;}
      if(move!=moveBefore){opposite=seq;seq=i;cisd=false;triggers=0;}
      if(opposite>=0 && !cisd && ++triggers<=2 && atr>0){
         double body=0,span=0;
         for(int k=seq;k<=i;k++){body+=MathAbs(r[k].close-r[k].open);span+=r[k].high-r[k].low;}
         if(move*(r[i].close-r[opposite].open)>0 && span>0 && body>=.65*atr && body>=.6*span){
            smcAdd(SM_CISD,0,move,r[opposite].time,r[i].time,known,r[opposite].open,r[opposite].open,"CISD");
            cisd=true;
         }
      }
      moveBefore=move;
   }
}
void smcToggleButton(string id,string caption,int x,int y,bool on){
   button(id,caption,x,on,90,8);ObjectSetInteger(0,prefix+id,OBJPROP_YDISTANCE,y);
}
void drawSmc(int w){
   int row=w<830?118:90;
   int x=w>=640?535:96;
   if(w<640)row+=27;
   smcToggleButton("SMCB","SMC",x,row,showSMC);
   smcToggleButton("IPDAB","IPDA",w>=640?629:190,row,showIPDA);
   string root=prefix+"SMCplot_";ObjectsDeleteAll(0,root);
   ObjectsDeleteAll(0,prefix+"SMCopt_");
   if(!showSMC)return;
   if(!showDOL && !showPool && !showPrice){
      int order[]={SM_BREAK,SM_CISD,-1,SM_EQUAL,SM_ST,SM_IT,SM_LT,SM_COMPARE,SM_LINK,SM_FIRST,SM_STRONG,SM_ACTIVE,SM_OPTIONS,SM_OPTIONS+1,SM_OPTIONS+2,SM_OPTIONS+3};
      for(int slot=0;slot<(smcPanel?ArraySize(order):3);slot++){
         int k=order[slot],colCount=MathMax(1,MathMin(5,w/97));
         int bx=96+(slot%colCount)*94,by=row+27+(slot/colCount)*25;
         if(k<0){
            smcToggleButton("SMCopt_MORE","更多",bx,by,smcPanel);
            ObjectSetString(0,prefix+"SMCopt_MORE",OBJPROP_TEXT,smcPanel?"收起 ▴":"更多 ▾");
            continue;
         }
         string id="SMCopt_"+IntegerToString(k);
         string label=k<SM_OPTIONS?smcNames[k]:(k==SM_OPTIONS?"全部显示":(k==SM_OPTIONS+1?"全部隐藏":(k==SM_OPTIONS+2?"突破层级":"等位层级")));
         int filter=k==SM_OPTIONS+2?breakTier:equalTier;
         if(k>=SM_OPTIONS+2)label+=" "+(filter<0?"全部":smcTier[filter]);
         smcToggleButton(id,label,bx,by,k<SM_OPTIONS?smcOptions[k]:false);
         bool enabled=k<SM_OPTIONS && smcOptions[k];
         ObjectSetInteger(0,prefix+id,OBJPROP_COLOR,smcInks[k]);
         ObjectSetInteger(0,prefix+id,OBJPROP_BGCOLOR,enabled?C'34,65,78':C'29,33,41');
         ObjectSetInteger(0,prefix+id,OBJPROP_BORDER_COLOR,enabled?smcInks[k]:clrSlateGray);
         if(k>=SM_OPTIONS)ObjectSetString(0,prefix+id,OBJPROP_TEXT,label);
      }
   }
   int far=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR),width=(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS);
   int near=MathMax(0,far-width-1),count=iBars(_Symbol,_Period);
   int left=MathMin(count-1,far+512);
   if(left<near)return;
   datetime latest=iTime(_Symbol,_Period,0);
   int shift=(periodEnd(latest)>TimeTradeServer()?1:0);
   string key=StringFormat("%d/%d/%d/%d/%I64d",left,near,count,shift,latest);
   if(key!=smcSnapshot){
      MqlRates r[];int last=MathMax(near,shift),want=left-last+1;
      if(want<3)return;
      int n=CopyRates(_Symbol,_Period,last,want,r);
      if(n!=want)return;
      ArrayResize(smcMarks,0);int start=0;
      for(int i=1;i<=n;i++)if(i==n || !consecutive(r[i-1].time,r[i].time)){
         smcRun(r,start,i,i<n);start=i;
      }
      smcSnapshot=key;
   }
   datetime firstTime=iTime(_Symbol,_Period,MathMin(far,count-1));
   for(int i=0;i<ArraySize(smcMarks);i++){
      SmcMark m=smcMarks[i];
      int layer=m.label=="CHoCH"?SM_CHOCH:m.kind;
      if(!smcOptions[m.kind] || m.z<firstTime)continue;
      if(m.kind==SM_BREAK && ((breakTier>=0 && breakTier!=m.tier) || (smcOptions[SM_STRONG] && !m.strong) ||
            (!smcOptions[SM_FIRST] && (m.label=="INIT" || m.label=="待定"))))continue;
      if(m.kind==SM_EQUAL && ((equalTier>=0 && equalTier!=m.tier) || (smcOptions[SM_ACTIVE] && !m.active)))continue;
      if(m.kind==SM_LINK && !smcOptions[SM_ST+m.tier])continue;
      string name=root+IntegerToString(i),caption=m.label;
      color ink=clrSilver;
      switch(layer==SM_LINK?SM_ST+m.tier:layer){
         case SM_BREAK: ink=clrAquamarine; break;
         case SM_CHOCH: ink=clrCoral; break;
         case SM_CISD: ink=clrViolet; break;
         case SM_EQUAL: ink=m.side>0?clrPeachPuff:clrSandyBrown; break;
         case SM_ST: ink=m.side>0?clrGainsboro:clrSilver; break;
         case SM_IT: ink=m.side>0?clrPaleGreen:clrDarkSeaGreen; break;
         case SM_LT: ink=m.side>0?clrLightPink:clrPaleVioletRed; break;
      }
      if(m.a!=m.z){
         ObjectCreate(0,name,OBJ_TREND,0,m.a,m.p,m.z,m.q);
         ObjectSetInteger(0,name,OBJPROP_RAY_RIGHT,false);ObjectSetInteger(0,name,OBJPROP_COLOR,ink);
         ObjectSetInteger(0,name,OBJPROP_STYLE,STYLE_DOT);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
         ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
      }
      if(caption=="")continue;
      if(smcOptions[SM_COMPARE] && m.relative!="")caption+=" "+m.relative;
      string tip=tfName()+" · "+caption+" · "+DoubleToString(m.q,_Digits)+"｜美东确认 "+easternTime(m.known);
      if(m.kind==SM_BREAK)tip+="｜"+smcTier[m.tier]+" 同层收盘突破 · "+(m.strong?"实体位移成立":"位移待证");
      if(m.kind==SM_EQUAL)tip+="｜"+smcTier[m.tier]+" · 截至视窗右端"+(m.active?"仍有效":"已越界或数据段结束");
      if(m.kind==SM_CISD)tip+="｜反向实体收破前一连续方向序列首根开盘";
      int ax,ay;if(!ChartTimePriceToXY(0,0,m.z,m.q,ax,ay))continue;
      int y=m.side>0?ay-15:ay+2;
      screenNote(name+"_t",MathMax(0,ax),MathMax(0,y),caption,ink,tip,7);
   }
}
bool smcClick(string name){
   if(name==prefix+"IPDAB"){showIPDA=!showIPDA;dolPage=0;if(showIPDA){showPool=false;showDOL=false;smcPanel=false;}return true;}
   if(name==prefix+"SMCB"){showSMC=!showSMC;smcPanel=false;if(showSMC){showPool=false;showDOL=false;}return true;}
   if(name==prefix+"SMCopt_MORE"){smcPanel=!smcPanel;return true;}
   if(StringFind(name,prefix+"SMCopt_")!=0)return false;
   int k=(int)StringToInteger(StringSubstr(name,StringLen(prefix+"SMCopt_")));
   if(k>=0 && k<SM_OPTIONS)smcOptions[k]=!smcOptions[k];
   else if(k==SM_OPTIONS || k==SM_OPTIONS+1){for(int i=0;i<=SM_LINK;i++)smcOptions[i]=(k==SM_OPTIONS);}
   else if(k==SM_OPTIONS+2)breakTier=breakTier==2?-1:breakTier+1;
   else if(k==SM_OPTIONS+3)equalTier=equalTier==2?-1:equalTier+1;
   return true;
}
