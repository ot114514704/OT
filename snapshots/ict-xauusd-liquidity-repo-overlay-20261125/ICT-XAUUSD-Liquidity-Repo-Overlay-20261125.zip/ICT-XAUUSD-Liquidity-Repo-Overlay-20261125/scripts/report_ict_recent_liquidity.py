"""List published IRL/ERL candidates and their verified Bid sweeps for two NY days."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter
from contextlib import closing
from datetime import datetime, time, timedelta, timezone
from html import escape
from pathlib import Path
import json
import sqlite3

import numpy as np

from brooks_ai.types import Bar
from ict_ai.dol_history import _deadline, batch_id
from ict_ai.range_liquidity import _Coverage
from ict_ai.sweep_response import CROSSING_LABELS, RESPONSE_BARS, crossing_response
from ict_ai.timebase import manifest_epoch_to_utc
from scripts import backtest_ict_liquidity_account as replay


OUT = replay.RESEARCH / 'ict_recent_liquidity_20261124'
M5 = replay.M5
NY = replay.NY


def dt(value):
    return datetime.fromisoformat(value)


def published(start, cutoff, observed):
    with closing(sqlite3.connect(replay.DATABASE.resolve().as_uri()+'?mode=ro', uri=True)) as db:
        query = ('SELECT id,cutoff,received,payload FROM chart_batches WHERE cutoff>=? AND cutoff<=? '
                 'ORDER BY cutoff, received, id')
        records = db.execute(query,(start.isoformat(),cutoff.isoformat())).fetchall()
    found = {}
    unacknowledged = set()
    for key, stamp, receipt, raw in records:
        at = dt(stamp)
        if not receipt or dt(receipt)>observed:
            unacknowledged.add(stamp)
            continue
        seen = dt(receipt)
        sample = json.loads(raw)
        if seen < at or sample['at'] != stamp or batch_id(at,sample['price'],[sample['targets'],sample['pools']]) != key:
            raise ValueError(f'Invalid published chart batch at {stamp}')
        found.setdefault(stamp,dict(chart_batch=key,at=stamp,receipt=receipt,price=sample['price'],pools=sample['pools']))
    return list(found.values()), sorted(unacknowledged-found.keys())


def capture():
    import MetaTrader5 as api

    policy = json.loads(replay.CLOCK.read_bytes())
    if not api.initialize(str(replay.TERMINAL), timeout=10000):
        raise RuntimeError(f'TMGM unavailable: {api.last_error()}')
    try:
        account = replay.checked_terminal(api)
        identity = account.login, account.server
        tick = api.symbol_info_tick('XAUUSD')
        last = manifest_epoch_to_utc(datetime.fromtimestamp(tick.time,replay.UTC),policy)
        if not timedelta(seconds=-1) <= datetime.now(replay.UTC)-last <= timedelta(minutes=1):
            raise ValueError('TMGM quote / broker clock is stale')
        cutoff = datetime.fromtimestamp(int(last.timestamp())//300*300,replay.UTC)
        yesterday = cutoff.astimezone(NY).date()-timedelta(days=1)
        start = datetime.combine(yesterday,time(0),NY).astimezone(replay.UTC)
        batches, unacknowledged = published(start, cutoff, last)
        bars = replay.collect_bars(api,start,cutoff,policy)
        if not batches or bars[-1].time+M5 != cutoff:
            raise ValueError('Latest closed price or chart receipts are unavailable')
        replay.write_zip(OUT/'batches.json.gz',batches)
        replay.write_zip(OUT/'m5.json.gz',[[b.time.isoformat(),*replay.ohlc(b)] for b in bars])
        chunks = {}
        for index, day in enumerate((yesterday,yesterday+timedelta(days=1))):
            begin = datetime.combine(day,time(0),NY).astimezone(replay.UTC)
            finish = min(cutoff,datetime.combine(day+timedelta(days=1),time(0),NY).astimezone(replay.UTC))
            if begin >= finish:
                continue
            stamp,bid,_ = replay.capture_ticks(api,begin,finish,policy)
            path = OUT/f'bid_day{index+1}.npz'
            np.savez_compressed(path,stamp=stamp,bid=bid)
            chunks[day.isoformat()] = dict(start=begin.isoformat(),end=finish.isoformat(),file=path.name,
                                          count=len(stamp),sha256=replay.digest(path))
            print(day,f'{len(stamp):,} Bid quotes',flush=True)
        replay.checked_terminal(api,identity)
        manifest = dict(start=start.isoformat(),cutoff=cutoff.isoformat(),quote_seen_at=last.isoformat(),
                        server=account.server, batches=len(batches), unacknowledged=unacknowledged, quotes=chunks,
                        inputs={p.name:replay.digest(p) for p in (replay.CLOCK,OUT/'m5.json.gz',OUT/'batches.json.gz')},
                        orders_sent=0)
        replay.atomic_json(OUT/'capture.json',manifest)
    finally:
        api.shutdown()


def review_target(target, future, receipt, stamps, bids, bad_bars, exhausted):
    side, outer = target['side'], replay.far(target)
    receipt_last_ms = replay.time_ms(receipt) + 999
    touched = False
    for b in future:
        hit_zone = b.low<=target['hi'] and b.high>=target['lo']
        touched |= hit_zone and b.time>=receipt
        if side*(replay.excursion(b,side)-outer)<=0:
            continue
        opened = replay.time_ms(b.time)
        if opened in bad_bars:
            return dict(state='unverified_bid_bucket', checked_m5=b.time.isoformat())
        lo,hi = np.searchsorted(stamps,[opened,opened+300000])
        cross = np.flatnonzero(side*(bids[lo:hi]-outer)>0)
        if not len(cross):
            return dict(state='unverified_bid_bucket', checked_m5=b.time.isoformat())
        i = lo+int(cross[0])
        tick_at = datetime.fromtimestamp(int(stamps[i])/1000,replay.UTC).isoformat(timespec='milliseconds')
        event = dict(tick_at=tick_at, tick_bid=float(bids[i]), checked_m5=(b.time+M5).isoformat())
        if stamps[i] <= receipt_last_ms:
            return dict(state='before_receipt',**event)
        if not b.low<=outer<=b.high or i==lo:
            return dict(state='gap_over',**event)
        return dict(state='swept',**event)
    return dict(state=('touched' if touched else 'untouched') if exhausted else
                      ('touched_pending' if touched else 'pending'))


def ny_stamp(value):
    return dt(value).astimezone(NY).strftime('%H:%M:%S')


def day_report(batches, bars, times, coverage, cutoff, quote_item):
    path = OUT/quote_item['file']
    if replay.digest(path) != quote_item['sha256']:
        raise ValueError(f'Historical Bid changed: {path}')
    with np.load(path) as raw:
        stamps, bids = raw['stamp'], raw['bid']
    chart = {replay.time_ms(b.time):replay.ohlc(b) for b in bars}
    boundary = [dt(quote_item[k]) for k in ('start','end')]
    matched,bad = replay.verify_quote_bars(stamps,bids,chart,*boundary)
    rows, united = [], {}
    counts = Counter()
    responses = {}
    for batch in batches:
        at, receipt = (dt(batch[k]) for k in ('at','receipt'))
        end = min(cutoff,_deadline(at))
        i = bisect_left(times,at)
        terminal_close = bars[i-1].close if i and bars[i-1].time+M5 == at else None
        matched_close = terminal_close == batch['price']
        chunk = bars[i:bisect_left(times,end)]
        complete = not coverage.gap(at,end)
        candidates = []
        for target in batch['pools']:
            state = (dict(state='published_reference_disagreement') if not matched_close else
                     dict(state='empty_observation_window') if end<=receipt else
                     review_target(target,chunk,receipt,stamps,bids,bad,end==_deadline(at)) if complete else
                     dict(state='missing_chart_m5'))
            evidence = dict(target,**state,cutoff=batch['at'],receipt=batch['receipt'],deadline=_deadline(at).isoformat(),
                            outer=replay.far(target))
            if state['state']=='swept':
                known=dt(state['checked_m5'])
                event=(target['side'],evidence['outer'],known)
                if event not in responses:
                    j=bisect_left(times,known-M5)
                    responses[event]=crossing_response(target['side'],evidence['outer'],bars[max(0,j-15):j],
                                                         bars[j],bars[j+1:j+1+RESPONSE_BARS],cutoff)
                evidence['crossing_response']=responses[event]
            candidates.append(evidence)
            counts[evidence['state']] += 1
            key = target['scope'],target['side'],evidence['outer']
            group = united.setdefault(key,dict(best_rank=target['rank'],first=evidence,hit=None,states=Counter()))
            group['best_rank'] = min(group['best_rank'],target['rank'])
            group['states'][state['state']] += 1
            if state['state']=='swept' and (group['hit'] is None or evidence['tick_at'] < group['hit']['tick_at']):
                group['hit'] = evidence
        rows.append(dict(batch,candidates=candidates, reference_verified=matched_close, terminal_close=terminal_close))
    swept = sorted((g['hit'] for g in united.values() if g['hit']),key=lambda row: row['tick_at'])
    scopes = {}
    for s in ('irl','erl'):
        group=[g for key,g in united.items() if key[0]==s]
        scopes[s]=dict(distinct_preselected=len(group),distinct_swept=sum(g['hit'] is not None for g in group),
                       buy_swept=sum(g['hit'] is not None and g['hit']['side']==1 for g in group),
                       sell_swept=sum(g['hit'] is not None and g['hit']['side']==-1 for g in group))
    return dict(batches=len(batches),counts=dict(counts),scope=scopes,published_history=rows,
                latest=rows[-1] if rows else None, swept=swept, distinct=list(united.values()),
                reference_disagreements=[dict(at=r['at'],published=r['price'],terminal=r['terminal_close'])
                                         for r in rows if not r['reference_verified']],
                latest_verified=next((r for r in reversed(rows) if r['reference_verified']),None),
                bid_ticks=len(stamps),reconciled_m5=matched,bid_disagreements=len(bad))


def scoped_rows(rows):
    labels = dict(swept='已扫', before_receipt='回执之前已越过', gap_over='跳过外沿', pending='待扫',
                  untouched='窗口到期未扫', touched='触及后到期', touched_pending='已触及，待扫',
                  unverified_bid_bucket='逐笔未核实', missing_chart_m5='行情缺失',
                  published_reference_disagreement='预选参考价需核对', empty_observation_window='尚无已收线观察窗')
    result = ['<table><thead><tr><th>范围</th><th>侧</th><th>候选价带</th><th>外沿</th><th>冻结</th>'
              '<th>图表收到</th><th>名次／分</th><th>状态</th><th>越过时刻／Bid</th>'
              '<th>扫荡／真破判词</th></tr></thead><tbody>']
    for row in rows:
        s = row['side']
        band = f'{row["lo"]:.2f}–{row["hi"]:.2f}' if row['hi'] != row['lo'] else f'{row["lo"]:.2f}'
        tick = f'{ny_stamp(row["tick_at"])}／{row["tick_bid"]:.2f}' if row.get('tick_at') else '—'
        response = row.get('crossing_response')
        verdict = CROSSING_LABELS[response['status']] if response else '—'
        if response and response['known_at']:
            verdict += ' · '+ny_stamp(response['known_at'])
        fields = [row['scope'].upper(), '买方上沿' if s == 1 else '卖方下沿', band, f'{row["outer"]:.2f}',
                  ny_stamp(row['cutoff']), ny_stamp(row['receipt']), f'{row["rank"]}／{row["score"]}',
                  labels[row['state']], tick, verdict]
        result.append('<tr>'+''.join(f'<td>{escape(str(text))}</td>' for text in fields)+'</tr>')
    return '\n'.join(result+['</tbody></table>'])


def render(report):
    cutoff = dt(report['cutoff']).astimezone(NY).strftime('%m-%d %H:%M')
    html = ['<!doctype html><html lang="zh-CN"><meta charset="utf-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1">',
            '<title>TMGM 黄金 · 流动性预选与已扫</title>',
            '''<style>
body{max-width:1260px;margin:26px auto;padding:0 18px;background:#f3f6f8;color:#142630;font:15px system-ui,sans-serif}
header,section{margin:14px 0;padding:14px 20px;background:white;border:1px solid #cbd9de;border-radius:9px}
p{line-height:1.55}h1{font-size:25px}h2{font-size:20px}summary{margin:13px 0;cursor:pointer;font-weight:650}
.scroll{overflow:auto}table{width:100%;border-collapse:collapse;white-space:nowrap;font:13px system-ui,sans-serif;font-variant-numeric:tabular-nums}
th,td{padding:6px 10px;text-align:right;border-bottom:1px solid #dae3e7}th:first-child,td:first-child{text-align:left}
</style>''', '<body><header><h1>TMGM 黄金 · 流动性预选与已扫</h1>',
            f'<p>纽约时间。行情核对到 {cutoff} 收线。成功清扫使用图表收到预选后、同根 M5 内严格越过的第一条 Bid。</p>',
            '<p>当天合并同范围、同侧和同外沿的重复预选。各批次仍保留原始榜单。</p></header>']
    for day, row in report['days'].items():
        irl, erl = [row['scope'][s] for s in ('irl','erl')]
        html.append(f'<section><h2>{day}</h2><p>{row["batches"]} 次回执 · IRL {irl["distinct_swept"]}/{irl["distinct_preselected"]} · '
                    f'ERL {erl["distinct_swept"]}/{erl["distinct_preselected"]} · {row["reconciled_m5"]} 根 M5 四价吻合</p>')
        html.append('<h3>已成功扫荡</h3><div class="scroll">'+scoped_rows(row['swept'])+'</div>')
        if row['latest']:
            html.append('<h3>最后一次已发布的预选</h3><div class="scroll">'+scoped_rows(row['latest']['candidates'])+'</div>')
            if not row['latest']['reference_verified'] and row['latest_verified']:
                html.append('<h3>最近一次参考价已核对的预选</h3><div class="scroll">'
                            +scoped_rows(row['latest_verified']['candidates'])+'</div>')
        html.append('<details><summary>全部回执与逐批预选</summary>')
        for batch in row['published_history']:
            html.append(f'<details><summary>{ny_stamp(batch["at"])} 冻结，{ny_stamp(batch["receipt"])} 收到</summary>'
                        '<div class="scroll">'+scoped_rows(batch['candidates'])+'</div></details>')
        html.append('</details></section>')
    return '\n'.join(html+['</body></html>'])


def make_report():
    manifest = json.loads((OUT/'capture.json').read_bytes())
    for path in (replay.CLOCK,OUT/'m5.json.gz',OUT/'batches.json.gz'):
        if replay.digest(path) != manifest['inputs'][path.name]:
            raise ValueError(f'Archived input changed: {path}')
    start, cutoff = (dt(manifest[k]) for k in ('start','cutoff'))
    bars = [Bar(dt(t),o,h,l,c,0) for t,o,h,l,c in replay.read_zip(OUT/'m5.json.gz')]
    times = [b.time for b in bars]
    batches = replay.read_zip(OUT/'batches.json.gz')
    coverage = _Coverage(start,cutoff,bars,M5)
    days = {}
    for day,item in manifest['quotes'].items():
        group = [p for p in batches if str(dt(p['at']).astimezone(NY).date())==day]
        days[day] = day_report(group,bars,times,coverage,cutoff,item)
        data = days[day]
        print(day,data['batches'],data['scope'],data['bid_disagreements'],data['latest']['at'] if data['latest'] else None)
    report = dict(cutoff=manifest['cutoff'],quote_seen_at=manifest['quote_seen_at'],server=manifest['server'],
                  coverage_missing_m5=coverage.missing[-1],unacknowledged=manifest['unacknowledged'],days=days,
                  methodology='Published 1.34 top-ten chart receipts. Strict first Bid excursion occurs after receipt, '
                  'after the one-second chart receipt interval, from the inside of a reconciled M5 bucket and no later than four hours or NY study day end. '
                  'If the published reference and source M5 close differ, the original candidate remains in view but no confirmed sweep is attributed to that receipt. '
                  'Count distinct side/outer edge per IRL or ERL per date. Repeated rows are retained in the full journal.',
                  code_sha256=replay.digest(Path(__file__)),capture_sha256=replay.digest(OUT/'capture.json'),orders_sent=0)
    replay.atomic_json(OUT/'report.json',report)
    (OUT/'report.html').write_text(render(report),encoding='utf-8')


def comparison_table(headers, rows):
    heading = ''.join(f'<th scope="col">{escape(value)}</th>' for value in headers)
    body = ''.join('<tr>' + ''.join(f'<td>{escape(str(value))}</td>' for value in row) + '</tr>' for row in rows)
    return '<div class="scroll" tabindex="0"><table><thead><tr>' + heading + '</tr></thead><tbody>' + body + '</tbody></table></div>'


def hit_rate(hits, windows):
    return f'{hits}/{windows}（{hits / windows:.1%}）' if windows else '—'


def render_paired_windows(groups, labels):
    tabs = [(group, minutes) for group, horizons in groups.items() for minutes in horizons]
    tabs.sort(key=lambda tab: tab != ('current_week_H1', '15'))
    html = ['<details id="paired-windows"><summary>逐窗对照 · 候选价位与扫荡时间</summary>',
            '<p>时间按纽约显示。逐笔严格扫过候选外沿才计为命中。差异筛选对照仓库原版与本地版。</p>',
            '<div class="comparison-filters"><label>样本与窗口 <select id="pair-window">']
    html.extend(f'<option value="{i}">{escape(labels[group])} · {minutes} 分钟</option>'
                for i, (group, minutes) in enumerate(tabs))
    html.extend(['</select></label><label>结果 <select id="pair-outcome">',
                 '<option value="different">仅看命中差异</option><option value="all">全部窗口</option>',
                 '<option value="local">仅本地命中</option><option value="repo">仅仓库命中</option>',
                 '<option value="both">两套都命中</option></select></label></div>',
                 '<p id="pair-count" role="status"></p>'])
    statuses = {'sweep': '已扫', 'before_board': '起算前越界', 'gap_over': '跳越', 'not_swept': '未扫'}
    arms = ('repo', 'repo_unique', 'local')
    for index, (group, minutes) in enumerate(tabs):
        html.append(f'<div class="scroll" tabindex="0" data-pair-window="{index}"{" hidden" if index else ""}>')
        html.append('<table><thead><tr><th scope="col">截点／开始核对</th><th scope="col">仓库原版</th>'
                    '<th scope="col">仓库去重补位</th><th scope="col">本地版 ERL</th></tr></thead><tbody>')
        for case in reversed(groups[group][minutes]['cases']):
            books = case['outcomes']
            repo, local = (any(mark['status'] == 'sweep' for mark in books[arm]) for arm in ('repo', 'local'))
            kind = 'both' if repo and local else 'repo' if repo else 'local' if local else 'none'
            cutoff = dt(case['cutoff']).astimezone(NY).strftime('%m-%d %H:%M')
            ready = dt(case['checked_from']).astimezone(NY).strftime('%H:%M:%S')
            html.append(f'<tr data-pair-kind="{kind}"><td>{cutoff}<br>自 {ready}</td>')
            for arm in arms:
                cells = []
                for mark in books[arm]:
                    side = '上' if mark['side'] > 0 else '下'
                    edge = mark['hi'] if mark['side'] > 0 else mark['lo']
                    status = mark['status']
                    stamp = mark['bid_time_ms']
                    time_text = (datetime.fromtimestamp(stamp / 1000, timezone.utc).astimezone(NY)
                                 .strftime('%H:%M:%S.%f')[:-3]) if stamp is not None else ''
                    hit = ' class="pair-hit"' if status == 'sweep' else ''
                    cells.append(f'<div{hit}>{side} {edge:.2f} · {statuses[status]} {time_text}</div>')
                html.append('<td>' + ''.join(cells) + '</td>')
            html.append('</tr>')
        html.append('</tbody></table></div>')
    html.append('''<script>
(() => {
  const frame = document.getElementById('paired-windows');
  const windows = frame.querySelector('#pair-window');
  const outcomes = frame.querySelector('#pair-outcome');
  const tables = frame.querySelectorAll('[data-pair-window]');
  const count = frame.querySelector('#pair-count');
  function filter() {
    for (const panel of tables) panel.hidden = panel.dataset.pairWindow !== windows.value;
    const rows = [...tables[Number(windows.value)].querySelectorAll('[data-pair-kind]')];
    for (const row of rows) {
      const kind = row.dataset.pairKind;
      const selected = outcomes.value;
      row.hidden = !(selected === 'all' || kind === selected ||
        (selected === 'different' && (kind === 'local' || kind === 'repo')));
    }
    const visible = rows.filter(row => !row.hidden).length;
    count.textContent = visible ? `显示 ${visible} / ${rows.length} 个窗口` : `没有符合筛选的窗口（共 ${rows.length} 个）`;
  }
  windows.addEventListener('change', filter);
  outcomes.addEventListener('change', filter);
  filter();
})();
</script></details>''')
    return html


def render_comparisons(comparisons):
    if not comparisons:
        return []
    html = ['<section id="rank-comparisons" aria-labelledby="comparison-title">',
            '<h2 id="comparison-title">流动性预选回测对比</h2>']
    headers = ('样本', '窗口', '仓库原版', '仓库去重补位', '本地版 ERL')
    dual = comparisons.get('dual')
    if dual:
        labels = {'oct_nov_H1': '10/1–11/20 · H1 对齐', 'current_week_H1': '11/23 起 · H1 对齐',
                  'current_week_H4': '11/23 起 · H4 对齐'}
        rows = [(labels[group], f'{minutes} 分钟',
                 *(hit_rate(result['counts'][method], result['counts']['windows'])
                   for method in ('original_top2', 'unique_top2', 'local_top2')))
                for group, results in dual['results'].items() for minutes, result in results.items()]
        html.extend(['<details id="repo-local-backtest" open><summary>仓库版与本地版 · 前二任一价位被扫</summary>',
                     '<p>两套规则各自产生候选，共用逐笔 Bid 验证。命中率分母为全部有效对齐窗口。'
                     f'11/23 起的样本截止纽约时间 {ny_stamp(dual["week_end"])}。</p>',
                     comparison_table(headers, rows), '</details>'])
        blend = comparisons.get('overlay')
        if blend:
            rows = [(labels[group], f'{minutes} 分钟', hit_rate(cell['local'], cell['windows']),
                     hit_rate(cell['fixed_two'], cell['windows']), hit_rate(cell['supplement'], cell['windows']),
                     cell['fixed_two_lost']) for group, horizons in blend.items() for minutes, cell in horizons.items()]
            html.extend(['<details id="repo-overlay-backtest" open><summary>本地＋仓库补漏 · 同样只选两个</summary>',
                         '<p>保留本地第一名。仓库候选须在同侧更近或填补未覆盖一侧，比本地第二名更近才进入前二。'
                         '历史回放使用已冻结候选，整合规则待独立实时验证。</p>',
                         comparison_table(('样本', '窗口', '本地前二', '整合前二', '本地前二＋一个备选', '整合前二丢失窗口'), rows),
                         '</details>'])
        html.extend(render_paired_windows(dual['results'], labels))
        rows = [(period, hit_rate(cell['original_top2'], cell['windows']), hit_rate(cell['unique_top2'], cell['windows']))
                for period, cell in dual['native'].items()]
        html.extend(['<details id="repo-native-backtest"><summary>仓库原生 120 根 K 线 · 首个扫荡</summary>',
                     '<p>2026 年 6–9 月样本外验证，沿用仓库的首根扫荡 K 线标签。</p>',
                     comparison_table(('周期', '仓库原版前二', '去重补位前二'), rows), '</details>'])
    methods = ('score_1', 'near_1', 'score_2', 'near_2')
    method_headers = ('范围', '最高分', '距离最近', '分数前二', '距离前二')
    historical = comparisons.get('historical')
    if historical:
        start = dt(historical['start']).strftime('%m/%d')
        end = (dt(historical['end_exclusive']) - timedelta(days=1)).strftime('%m/%d')
        rows = [(scope, f'{delay} 秒', *(hit_rate(cell['wins'][method], cell['windows'])
                                        for method in (*methods, 'near_plus_score')))
                for delay, scopes in historical['ranks'].items() for scope, cell in scopes.items()]
        html.extend(['<details id="historical-ranking"><summary>本地历史排序 · 15 分钟 · 首个扫荡</summary>',
                     f'<p>{start}–{end}。每种排序使用同一批历史候选。混合排序先取距离最近的价位，再取余下分数最高的价位。</p>',
                     comparison_table((method_headers[0], '起算延迟', *method_headers[1:], '最近加最高分'), rows),
                     '</details>'])
    live = comparisons.get('live')
    if live:
        rows = [(scope, f'{minutes} 分钟', *(hit_rate(cell[f'{method}_first'], cell['windows']) for method in methods))
                for minutes, scopes in live['ranks'].items() for scope, cell in scopes.items()]
        html.extend(['<details id="live-ranking"><summary>本地实时登记排序 · 首个扫荡</summary>',
                     f'<p>核对至纽约时间 {ny_stamp(live["observed_at"])}。仅纳入报价齐全的已登记窗口。</p>',
                     comparison_table((method_headers[0], '窗口', *method_headers[1:]), rows), '</details>'])
    return html + ['</section>']


def render_window_preselection(report):
    outcome = {'sweep': '已严格越界', 'before_board': '登记前已越界', 'not_swept': '首根未扫',
               'gap_over': '跳越外沿', 'pending': '待下根收盘核验', 'incomplete': '逐笔证据不足',
               'too_late': '登记晚于窗口', 'no_post_registration_quote': '登记后无报价'}
    response_labels = {'sweep': '偏收回', 'break': '偏真破', 'pending': '待收线', 'candidate': '待定',
                       'missing_prior': '波幅资料不足', 'incomplete': '报价不足', 'unresolved': '仍未决'}
    html = ['<!doctype html><html lang="zh-CN"><meta charset="utf-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1">',
            '<title>XAUUSD · M5 窗口预选</title>',
            '''<style>
body{max-width:1280px;margin:26px auto;padding:0 14px;background:#10151b;color:#edf2f7;font:14px/1.5 system-ui,sans-serif}
h1{margin:0;font-size:26px}p,th{color:#a4b2c1}header,details{margin:12px 0;padding:12px 14px;border:1px solid #303b48;border-radius:10px;background:#171e26}
summary{cursor:pointer;font-weight:650;color:#f0c681}.scroll{margin-top:10px;overflow:auto}
table{width:100%;border-collapse:collapse;white-space:nowrap;font-variant-numeric:tabular-nums}
th,td{border-bottom:1px solid #303b48;padding:6px 8px;text-align:left}td[data-hit]{color:#69d6c4}
.priority{margin:12px 0;padding:12px 14px;border:1px solid #303b48;border-radius:10px;background:#171e26}
.priority h2,#rank-comparisons h2{font-size:18px;margin:0}.priority th,.priority td{white-space:normal}.priority tbody td:nth-child(2){color:#f0c681}
#rank-comparisons{margin:18px 0}.scroll:focus-visible{outline:2px solid #f0c681;outline-offset:3px}
.comparison-filters{display:flex;gap:10px 18px;flex-wrap:wrap}.comparison-filters label{display:grid;gap:4px}
.comparison-filters select{font:inherit;color:inherit;background:#10151b;border:1px solid #556272;border-radius:5px;padding:6px}
.pair-hit{color:#69d6c4}#paired-windows td{vertical-align:top}[hidden]{display:none!important}
</style>''',
            '<body><header><h1>XAUUSD · M5 窗口预选</h1>',
            f'<p>纽约时间 · 快照 {dt(report["observed_at"]).astimezone(NY):%m-%d %H:%M:%S}'
            f' · {len(report["windows"])} 个实际登记窗口</p>',
            '<p>四根候选须在同侧 1 ATR 内，其余按五根确认。主榜按现有综合分；最近外沿排名在本窗口、同一范围的前十中对照。'
            '15／60 分钟扫后判断只显示当时已登记的结果。</p></header>']
    html.extend(render_comparisons(report.get('comparisons', {})))
    dual = report.get('dual_forecast')
    if dual:
        instant = dt(dual['observed_at']).astimezone(NY).strftime('%m-%d %H:%M:%S')
        html.append('<details id="dual-forecast"><summary>仓库与本地流动性预测</summary>'
                    f'<p>纽约时间 · 同一取样时刻 {instant}。仓库使用 TMGM 重训模型，各规则按自身周期收盘更新。</p>'
                    '<div class="scroll"><table><thead><tr><th>规则</th><th>最近可用截点</th>'
                    '<th>范围</th><th>候选一</th><th>候选二</th></tr></thead><tbody>')
        current = dual['current']
        forecasts = [('仓库 · TMGM 重训', values['closed_at'], period + ' ERL',
                      [(p['side'], p['price']) for p in values['ranked']])
                     for period, values in current['repo_tm_gm_refit'].items()]
        local = current['local']
        if local:
            forecasts.extend(('本地 · 实际登记', local['cutoff'], scope,
                              [(p['side'], p['hi'] if p['side'] == 1 else p['lo']) for p in rows[:2]])
                             for scope, rows in local['early'].items())
        for name, cutoff, scope, values in forecasts:
            edges = [f'{"上" if side > 0 else "下"} {price:.2f}' for side, price in values]
            fields = [name, dt(cutoff).astimezone(NY).strftime('%m-%d %H:%M'), scope, *(edges + ['—', '—'])[:2]]
            html.append('<tr>' + ''.join(f'<td>{escape(value)}</td>' for value in fields) + '</tr>')
        html.append('</tbody></table></div></details>')
    priority = report.get('published_priority')
    if priority:
        html.append('<section class="priority" aria-labelledby="priority-title"><h2 id="priority-title">已登记的优先观察位</h2>'
                    f'<p>{dt(priority["cutoff"]).astimezone(NY):%m-%d %H:%M} 截点 · {ny_stamp(priority["available_at"])} 可用</p>'
                    '<table><thead><tr><th>范围</th><th>最近外沿前二</th><th>综合分前二</th></tr></thead><tbody>')
        for scope, methods in priority['picks'].items():
            fields = [scope, *('、'.join(f'{"上" if side > 0 else "下"} {edge:.2f}' for side, edge in methods[name]) or '—'
                               for name in ('near_2', 'score_2'))]
            html.append('<tr>' + ''.join(f'<td>{escape(value)}</td>' for value in fields) + '</tr>')
        html.append('</tbody></table></section>')
    for index, window in enumerate(reversed(report['windows'])):
        html.append(('<details open>' if index == 0 else '<details>') +
                    f'<summary>{dt(window["cutoff"]).astimezone(NY):%m-%d %H:%M} 截点'
                    f' · {ny_stamp(window["available_at"])} 可用 · '
                    f'收盘 {window["price"]:.2f}</summary><div class="scroll">')
        html.append('<table><thead><tr><th>范围</th><th>候选外沿</th><th>新版名次／分</th><th>原五根名次／分</th>'
                    '<th>最近外沿名次</th><th>进入方式</th><th>首根 M5</th><th>扫后登记</th></tr></thead><tbody>')
        for row in window['candidates']:
            hit = row['first_m5'] == 'sweep'
            opened = '上' if row['side'] > 0 else '下'
            old = f'{row["former_rank"]}／{row["former_score"]}' if row['former_rank'] is not None else '—'
            follow = '；'.join(f'{minutes} 分 {response_labels.get(entry["v7b"], entry["v7b"])} '
                              f'· {ny_stamp(entry["available_at"])}'
                              for minutes, entry in sorted(row.get('after_crossing', {}).items(), key=lambda item: int(item[0])))
            fields = [row['scope'], f'{opened} {row["outer"]:.2f}', f'{row["rank"]}／{row["score"]}', old,
                      row['distance_rank'], '四根锚点' if row['four_bar_anchor'] else '常规筛选',
                      outcome[row['first_m5']], follow or ('待扫后登记' if hit else '—')]
            cells = [f'<td{" data-hit" if i == 6 and hit else ""}>{escape(str(value))}</td>'
                     for i, value in enumerate(fields)]
            html.append('<tr>' + ''.join(cells) + '</tr>')
        html.append('</tbody></table></div></details>')
    return '\n'.join(html + ['</body></html>'])


def main():
    parser = ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--capture',action='store_true')
    mode.add_argument('--window-preselection', action='store_true', help='Read the optimized, paired real-time M5 boards')
    args = parser.parse_args()
    if args.window_preselection:
        from scripts.ict_liquidity_window_preselection import write_report
        write_report(render_window_preselection)
        return
    OUT.mkdir(parents=True,exist_ok=True)
    if args.capture:
        capture()
    make_report()


if __name__ == '__main__':
    main()
