"""Register 15/60-minute sweep responses from the paired live M5 boards."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from hashlib import sha256
import json
from pathlib import Path
from time import sleep

from ict_ai.sweep_response import crossing_response, sequence
from ict_ai.sweep_state import crossing_state
from scripts import audit_ict_early_liquidity_response as research
from scripts import audit_ict_micro_liquidity_missing_boards as market


source, fixed, live, M5 = research.stream, research.fixed, research.live, research.M5
OUT = research.OUT.with_name('ict_early_liquidity_response_forward_20261125')
POLICY = OUT / 'policy.json'
WINDOWS = research.WINDOWS
HOLD = 6 * M5
FOLDERS = ('events', 'decisions', 'receipts', 'outcomes')
read, digest = fixed.read, source.digest
# This revision changes verification of JSON arrays; its decisions and settlement rules are identical.
PREVIOUS_VERIFIER_SHA256 = '6a5e5a9afa9708465daebf8dff04b0221927f23f12f006ca20adc64ec1f8476a'


def load_policy():
    source.load_policy()
    root = live.feed.ROOT
    paths = (Path(__file__).resolve(), source.POLICY, Path(research.__file__), research.OUT,
             root / 'ict_ai/sweep_response.py', root / 'ict_ai/sweep_state.py')
    pins = {p.name: digest(p) for p in paths}
    if not POLICY.exists():
        if read(research.OUT)['inputs'][Path(research.__file__).name] != pins[Path(research.__file__).name]:
            raise ValueError('The forward rules are not the archived comparison rules')
        live.atomic_json(POLICY, dict(frozen_at=live.now().isoformat(), pins=pins, horizons=WINDOWS,
                                     sampling='Both arms of the verified live M5 board, with arm and scope retained.',
                                     verification='Six contiguous M5 closes strictly on one side of the edge.',
                                     orders_sent=0))
    policy = read(POLICY)
    prior_pins = pins | {Path(__file__).name: PREVIOUS_VERIFIER_SHA256}
    if policy['pins'] not in (pins, prior_pins) or tuple(policy['horizons']) != WINDOWS:
        raise ValueError('The forward response policy has changed')
    return policy


def witnessed(session, source_policy):
    report = read(session)
    if report['state'] != 'scored' or not any(row['baseline_hits'] or row['early_hits']
                                               for row in report['paired'].values()):
        return {}
    receipt = source.OUT / 'receipts' / session.name
    bid = source.OUT / 'bid' / session.with_suffix('.json.gz').name
    if report['receipts_sha256'] != digest(receipt) or report['bid_sha256'] != digest(bid):
        raise ValueError(f'Crossing evidence changed at {session.name}')
    data, at, ready = source.load_board(source_policy, receipt)
    buckets = fixed.board.joint.read_zip(bid)
    verified = fixed.grade(data, ready, buckets, 1)
    if source.paired(verified) != report['paired']:
        raise ValueError(f'Crossings did not reproduce at {at}')

    events = {}
    for arm in ('baseline', 'early'):
        for scope in research.fixed.board.SCOPES:
            for row in verified['outcomes'][arm][scope]:
                if row['status'] != 'sweep':
                    continue
                side, edge = source.expiry.outer(row)
                key = sha256(json.dumps([session.stem, scope, side, edge]).encode()).hexdigest()[:24]
                event = events.setdefault(key, dict(cutoff=at.isoformat(), crossing_close=(at + M5).isoformat(),
                                                     first_bid_ms=row['bid_time_ms'], scope=scope, side=side, edge=edge,
                                                     crossing_ohlc=buckets[0]['ohlc'], arms={}, source=session.name,
                                                     settlement_sha256=digest(session), receipt_sha256=digest(receipt),
                                                     orders_sent=0))
                if event['first_bid_ms'] != row['bid_time_ms']:
                    raise ValueError(f'The same outer edge has different first crossings at {at}')
                event['arms'].setdefault(arm, {'side': side, 'lo': row['lo'], 'hi': row['hi']})
    return events


def encode(rows):
    return [[bar.time.isoformat(), *live.quotes.ohlc(bar)] for bar in rows]


def decision(event, minutes, prices):
    crossing_close = datetime.fromisoformat(event['crossing_close'])
    opened = crossing_close - M5
    cutoff = crossing_close + timedelta(minutes=minutes)
    observed = [prices.get(opened + i * M5) for i in range(1 + minutes // 5)]
    if not all(observed):
        return None
    crossing, *follow = observed
    if list(live.quotes.ohlc(crossing)) != event['crossing_ohlc']:
        raise ValueError('The crossing M5 is inconsistent with the witnessed tick')
    prior = [prices.get(opened + i * M5) for i in range(-24, 0)]
    if not all(prior[-15:]):
        return None
    side, edge = event['side'], event['edge']
    response = crossing_response(side, edge, prior[-15:], crossing, follow, cutoff)
    state = crossing_state(side, edge, crossing, follow, cutoff, response['prior_atr'])
    reversal = {arm: sequence(level, prior, observed, opened) for arm, level in event['arms'].items()} if all(prior) else {}
    distance = side * (observed[-1].close - edge)
    label = 'sweep' if distance < 0 else 'break' if distance > 0 else None
    return dict(minutes=minutes, cutoff=cutoff.isoformat(), v7b=response, state2=state, close_side=label,
                structure=reversal, quotes=encode([bar for bar in (*prior, *observed) if bar]))


def outcome(event, frozen, prices):
    start = datetime.fromisoformat(frozen['cutoff'])
    prior = [(prices.get(datetime.fromisoformat(t)), values) for t, *values in frozen['quotes']]
    rows = [prices.get(start + i * M5) for i in range(6)]
    if any(bar and list(live.quotes.ohlc(bar)) != values for bar, values in prior):
        label = 'changed_prefix'
    elif any(bar is None for bar, _ in prior) or not all(rows):
        label = 'incomplete'
    else:
        signs = [event['side'] * (bar.close - event['edge']) for bar in rows]
        label = 'sweep' if all(x < 0 for x in signs) else 'break' if all(x > 0 for x in signs) else 'mixed'
    tape = [bar for bar, _ in prior if bar] + [bar for bar in rows if bar]
    return dict(label=label, quotes=encode(tape))


def enroll(policy, processed):
    freeze = datetime.fromisoformat(policy['frozen_at'])
    source_policy = read(source.POLICY)
    for session in sorted((source.OUT / 'settlements').glob('*.json')):
        if session.name in processed:
            continue
        stamp = datetime.strptime(session.stem, '%Y%m%dT%H%M%SZ').replace(tzinfo=freeze.tzinfo)
        if stamp + M5 + timedelta(minutes=max(WINDOWS)) >= freeze:
            for key, event in witnessed(session, source_policy).items():
                path = OUT / 'events' / f'{key}.json'
                if not path.exists():
                    live.atomic_json(path, event)
        processed.add(session.name)


def pending_work(policy, now):
    freeze = datetime.fromisoformat(policy['frozen_at'])
    for path in sorted((OUT / 'events').glob('*.json')):
        event = read(path)
        opened = datetime.fromisoformat(event['cutoff'])
        for minutes in WINDOWS:
            cut = opened + M5 + timedelta(minutes=minutes)
            if not freeze <= cut <= now:
                continue
            name = f'{path.stem}_{minutes}.json'
            receipt, settled = OUT / 'receipts' / name, OUT / 'outcomes' / name
            if settled.exists():
                continue
            if receipt.exists():
                ready = datetime.fromisoformat(read(receipt)['available_at'])
                due = cut <= ready < cut + M5 and now >= cut + HOLD + fixed.SYNC
            else:
                due = now < cut + M5
            if due:
                yield path, event, minutes, cut, name


def poll(policy, alive, processed):
    enroll(policy, processed)
    work = list(pending_work(policy, live.now()))
    if not work or not alive():
        return
    now = live.now()
    with live.terminal() as (api, clock):
        prices = {bar.time: bar for bar in live.quotes.collect_bars(
            api, min(datetime.fromisoformat(event['cutoff']) for _, event, *_ in work) - 24 * M5, now, clock)}
    if not alive():
        raise RuntimeError('The configured MT5 terminal closed during the read')
    policy_sha = digest(POLICY)
    for path, event, minutes, cut, name in work:
        target, receipt = OUT / 'decisions' / name, OUT / 'receipts' / name
        if receipt.exists():
            evidence = read(receipt)
            frozen = read(target)
            if evidence['decision_sha256'] != digest(target) or frozen['event_sha256'] != digest(path):
                raise ValueError(f'Registered response changed at {cut}')
            if not cut <= datetime.fromisoformat(evidence['available_at']) < cut + M5:
                continue
            review = outcome(event, frozen, prices)
            if review['label'] == 'incomplete' and now < cut + HOLD + 2 * M5:
                continue
            live.atomic_json(OUT / 'outcomes' / name,
                             dict(**review, receipt_sha256=digest(receipt), settled_at=live.now().isoformat()))
            continue
        ready = live.now()
        if not cut <= ready < cut + M5:
            continue
        data = decision(event, minutes, prices)
        if data is None:
            continue
        live.atomic_json(target, dict(**data, event_sha256=digest(path), policy_sha256=policy_sha))
        published = live.now()
        live.atomic_json(receipt, dict(available_at=published.isoformat(), decision_sha256=digest(target)))


def verify_summary(policy, *, verify=False):
    stage = defaultdict(Counter)
    freeze = datetime.fromisoformat(policy['frozen_at'])
    observed = live.now()
    source_policy = read(source.POLICY)
    by_session = {}
    for path in sorted((OUT / 'events').glob('*.json')):
        event = read(path)
        if verify:
            if event['source'] not in by_session:
                by_session[event['source']] = witnessed(source.OUT / 'settlements' / event['source'], source_policy)
            if by_session[event['source']].get(path.stem) != event:
                raise ValueError(f'Event differs from original source: {path.name}')
        for minutes in WINDOWS:
            cut = datetime.fromisoformat(event['crossing_close']) + timedelta(minutes=minutes)
            if cut < freeze:
                continue
            group = stage[str(minutes)]
            group['eligible_events'] += 1
            name = f'{path.stem}_{minutes}.json'
            receipt, saved = OUT / 'receipts' / name, OUT / 'outcomes' / name
            if not receipt.exists():
                state = 'awaiting_cutoff' if observed < cut else 'awaiting_registration' if observed < cut + M5 else 'missed'
                group[state] += 1
                continue
            proof, target = read(receipt), OUT / 'decisions' / name
            data = read(target)
            stamp = datetime.fromisoformat(proof['available_at'])
            if (data['cutoff'] != cut.isoformat() or proof['decision_sha256'] != digest(target)
                    or data['policy_sha256'] != digest(POLICY) or data['event_sha256'] != digest(path)):
                raise ValueError(f'Registered decision failed provenance: {name}')
            if not cut <= stamp < cut + M5:
                group['late'] += 1
                continue
            group['registered'] += 1
            if verify:
                known = {bar.time: bar for bar in market.unpack(data['quotes'])}
                rebuilt = decision(event, minutes, known)
                stored_shape = json.loads(json.dumps(rebuilt, allow_nan=False))
                if stored_shape is None or any(data[key] != value for key, value in stored_shape.items()):
                    raise ValueError(f'Registered decision did not reproduce: {name}')
            if not saved.exists():
                continue
            result = read(saved)
            label = result['label']
            if result['receipt_sha256'] != digest(receipt) or datetime.fromisoformat(result['settled_at']) < cut + HOLD:
                raise ValueError(f'Follow-through has invalid timing: {name}')
            if verify:
                joined = {bar.time: bar for bar in market.unpack(result['quotes'])}
                rebuilt = outcome(event, data, joined)
                if any(result[key] != value for key, value in rebuilt.items()):
                    raise ValueError(f'Follow-through did not reproduce: {name}')
            group['settled/' + label] += 1
    return dict(frozen_at=policy['frozen_at'], observed_at=observed.isoformat(),
                events=len(list((OUT / 'events').glob('*.json'))), horizons=stage, orders_sent=0)


def main():
    import msvcrt

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('watch', 'verify'))
    parser.add_argument('--terminal-pid', type=int)
    args = parser.parse_args()
    if args.mode == 'verify':
        if not POLICY.is_file():
            raise FileNotFoundError(POLICY)
        print(json.dumps(verify_summary(load_policy(), verify=True), ensure_ascii=False))
        return
    if not args.terminal_pid:
        parser.error('--terminal-pid is required in watch mode')
    for name in FOLDERS:
        (OUT / name).mkdir(parents=True, exist_ok=True)
    with fixed.open_terminal(args.terminal_pid) as alive, (OUT / 'watch.lock').open('a+b') as lock:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        policy = load_policy()
        processed = set()
        while alive():
            try:
                poll(policy, alive, processed)
                status = verify_summary(policy)
            except (OSError, RuntimeError, ValueError) as error:
                status = dict(observed_at=live.now().isoformat(), error=str(error), orders_sent=0)
            live.atomic_json(OUT / 'status.json', status)
            sleep(5)


if __name__ == '__main__':
    main()
