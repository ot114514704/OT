from datetime import datetime, timedelta, timezone
import unittest

from brooks_ai.types import Bar
from ict_ai.silver_trigger import assess

STEP=timedelta(minutes=5)
START=datetime(2026,11,20,15,tzinfo=timezone.utc)


class SilverConfirmation(unittest.TestCase):
    def test_new_gap_must_precede_retest_and_later_failure_preserves_trigger(self):
        before=[Bar(START+(i-24)*STEP,100,101,99,100,0) for i in range(24)]
        before[-1]=Bar(START-STEP,100.5,101,99,100,0)
        values=[(100,100.5,98,99.7),(99.7,104,99.5,103.8),
                (103.8,105,103,104),(104,104,102,103),(103,103,97,97.5)]
        body=[Bar(START+i*STEP,*prices,0) for i,prices in enumerate(values)]
        def observed(n):
            return assess(before,body[:n],START,START+n*STEP,STEP)
        self.assertEqual(observed(2)[0],2)
        self.assertIn("CISD",observed(2)[2])
        self.assertIn("缺新生 FVG",observed(2)[2])
        self.assertEqual(observed(3)[0],3)
        self.assertEqual(observed(4)[1],START+4*STEP)
        self.assertEqual(observed(5)[1],START+4*STEP)
        self.assertIn("失效",observed(5)[2])
        # The fifth candle is missing. A later invalidation across the gap
        # is unknowable, while the fourth candle's trigger remains observed.
        resumed=Bar(START+5*STEP,98,99,96,97,0)
        gapped=assess(before,body[:4]+[resumed],START,START+6*STEP,STEP)
        self.assertEqual(gapped[1],observed(4)[1])
        self.assertIn("缺报价",gapped[2])
        self.assertNotIn("模型失效",gapped[2])
        self.assertIsNone(assess(before,body[:3]+[resumed],START,START+6*STEP,STEP))
        self.assertEqual(assess(before,body,START,START+3*STEP,STEP),observed(3))

        self.assertIsNone(assess(before,body[1:],START,START+5*STEP,STEP))

    def test_far_edge_failure_is_known_only_at_close_and_keeps_the_path(self):
        before=[Bar(START+(i-24)*STEP,100,101,99,100,0) for i in range(24)]
        before[-1]=Bar(START-STEP,100.5,101,99,100,0)
        values=[(100,100.5,98,99.7),(99.7,104,99.5,103.8),
                (103.8,105,103,104),(104,104,99,99.5),(99.5,100,97,97.5)]
        body=[Bar(START+i*STEP,*prices,0) for i,prices in enumerate(values)]
        def at(n):return assess(before,body,START,START+n*STEP,STEP)
        self.assertIn("尚缺窗内回踩确认",at(3)[2])
        self.assertIsNone(at(4)[1])
        self.assertIn("穿过缺口远沿 100.50",at(4)[2])
        self.assertNotIn("尚缺窗内回踩确认",at(4)[2])
        self.assertIn("确认 CISD",at(5)[2])
        self.assertIn("实体收破扫荡极值",at(5)[2])
        earlier_gap=before[:4]+before[6:]
        self.assertEqual(at(5),assess(earlier_gap,body,START,START+5*STEP,STEP))
        self.assertIsNone(assess(before[:12]+before[14:],body,START,START+5*STEP,STEP))

