"""As-of frames for the standalone daily review. Minute zero is New York midnight."""
from datetime import timedelta

from brooks_ai.types import utc_time
from ict_ai.amd import amd_events
from ict_ai.daily_context import _open
from ict_ai.profile_lifecycle import _day_bounds, daily_profile_lifecycle
from ict_ai.timebase import session_windows


def midnight_target_replay(day, rows, review):
    """Verify the chart's target observations against the archived route review."""
    start,_ = _day_bounds(day)
    frozen = review["frozen"]
    if utc_time(frozen["frozen_at"]) != start:
        raise ValueError(f"Target was not frozen at NY midnight on {day}")
    selected = frozen["selected_route"]
    if not selected:
        return {"status":frozen["status"]}
    target = selected["target"]
    if max(utc_time(selected["origin_known_at"]),utc_time(target["available_at"])) > start:
        raise ValueError("Target requires information after NY midnight")
    price = selected["target_reference_price"]
    outcome = review["outcome"]
    through = int((utc_time(outcome["through_ny"])-start).total_seconds()//60)
    candles = {row[0]:row for row in rows}
    first_hit = first_gap = None
    gaps = 0
    for minute in range(5,through+1,5):
        if not _open(start+timedelta(minutes=minute-5)):
            continue
        candle = candles.get(minute)
        if candle is None:
            gaps += 1
            if first_gap is None:
                first_gap = minute
        elif first_hit is None and candle[3] <= price <= candle[2]:
            first_hit = minute
    recorded = outcome["contact_known_at_ny"].get("route_target")
    if (None if not recorded else int((utc_time(recorded)-start).total_seconds()//60)) != first_hit or (
            gaps != outcome["missing_m5_slots"]):
        raise ValueError(f"Chart target coverage differs from route review on {day}")
    return {"status":frozen["status"],"price":price,"direction":frozen["direction"],
            "route":selected["route"],"timeframe":selected["timeframe"],"target":target,
            "firstHit":first_hit,"firstGap":first_gap,"through":through}


def day_replay(m5,m15,day,news,close):
    start,end=_day_bounds(day)
    step=timedelta(minutes=5)
    quarter=3*step
    def minute(at):
        return int((at-start).total_seconds()//60)
    asia=session_windows(day)["asia"][0]
    bars=[[minute(b.time+step),b.open,b.high,b.low,b.close] for b in m5 if asia<=b.time and b.time+step<=end]
    core=[b for b in m15 if start<=b.time and b.time+quarter<=end]
    events=[]
    origins={}
    for stage in amd_events(core,quarter,end):
        at=utc_time(stage["available_at"])
        phase=stage["phase"]
        label={"A":"积累区间形成","M":"越界后收回","D":"向上扩张" if stage["direction"]=="bullish" else "向下扩张"}[phase]
        if phase=="A":
            origins[stage["id"]]=minute(at)
            label="A 积累候选 · "+stage["shape_label"]
        events.append([minute(at),label,stage["range_low"],stage["range_high"],origins[stage["id"]]])
    for event in news:
        events.append([minute(utc_time(event["scheduled_ny"])),"、".join(event["announcements"]),None,None])
    events.sort(key=lambda e:e[0])
    states=[]
    intervals=[]
    open_intervals={}
    # Store transitions only. Compute each state from the bars that were closed
    # at that minute, including the evidence available before the NY day began.
    for minutes in range(0,minute(end)+1,15):
        at=start+timedelta(minutes=minutes)
        source=[b for b in m5 if b.time+step<=at]
        analyzed=[b for b in m15 if b.time+quarter<=at]
        view=daily_profile_lifecycle(analyzed,day,at,reference_m5=source,include_reconstruction=False)
        # An episode begins only on an observed intraday path. The close is a
        # separate adjudication, so it can end an episode but cannot start one.
        observed={(c["id"],c["direction"]):c for c in view["candidates"] if c["observed_sequence"]}
        active={key for key,card in observed.items() if card["status"]=="active" and at<end}
        for key in tuple(open_intervals):
            if key in active:
                continue
            episode=open_intervals.pop(key)
            card=observed.get(key,{})
            if not view.get("coverage_complete_under_study_calendar"):
                reason="insufficient_coverage"
            elif card.get("status")=="invalidated":
                reason="invalidated"
            elif at==end:
                reason="matched_at_close" if card.get("path_matched") else "unmatched_at_close"
            else:
                reason="no_longer_active"
            episode.update(end=minutes,end_reason=reason)
        for key,card in observed.items():
            if key in active and key not in open_intervals:
                episode={"id":key[0],"direction":key[1],"label":card["label"],"start":minutes}
                intervals.append(episode)
                open_intervals[key]=episode
        state=[view["profile_label"],view["profile_reason"]]
        if not states or states[-1][1:]!=state or at==end:
            states.append([minutes,*state])
    if states[-1][1:]!=[close["profile_label"],close["profile_reason"]]:
        raise ValueError(f"Replay and end-of-day review differ on {day}")
    return {"end":minute(end),"bars":bars,"states":states,"events":events,"candidate_intervals":intervals}
