"""Replay frozen classic 1.1 reversal orders against original TMGM Bid/Ask quotes."""
from argparse import ArgumentParser
from bisect import bisect_right
from collections import Counter, defaultdict
from dataclasses import asdict, replace
from datetime import date, datetime, time, timedelta, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from brooks_ai.types import Instrument, Tick, utc_time
from ict_ai.tick_portfolio import replay_tick_portfolio
from ict_ai.timebase import NY
from scripts import check_pool_priority, replay_pool_and_dol as archive
from scripts.export_mt5_native import native_time
from scripts.replay_ict_news import STEP
from scripts.replay_profile_one_tick_orders import freeze_orders

UTC = timezone.utc
EPOCH = datetime(1970,1,1,tzinfo=UTC)
START = date(2026,6,1)
END = date(2026,11,20)
CONTRACT = ROOT/'data/real/TMGM_ICT_live_start_20261120_174514/XAU/provenance.json'
ARTIFACT = archive.RESEARCH/'ict_classic_reversal_tmgm_bidask.json.gz'
REPORT = archive.RESEARCH/'ict_classic_reversal_tmgm_bidask.json'


def reference(start,end):
    capture = archive.read_zip(archive.QUOTES)
    bars, _ = check_pool_priority.read_market()
    shared = {b.time:(b.open,b.high,b.low,b.close) for b in bars}
    common = [shared.get(utc_time(t)) == (o,h,l,c)
              for t,o,h,l,c in capture['series']['XAUUSDM5'] if utc_time(t) in shared]
    if not common or not all(common):
        raise ValueError('Long archive and TMGM overlap disagree')
    meta = json.loads(CONTRACT.read_bytes())
    if meta['server'] != capture['server'] or meta['symbol'] != 'XAUUSD':
        raise ValueError('Contract manifest and quote source disagree')
    info = meta['current_symbol_observation']
    spec = Instrument(meta['symbol'],info['point'],info['trade_tick_size'],info['trade_contract_size'],
                      info['volume_min'],info['volume_step'],info['volume_max'],
                      account_currency=meta['account_currency'],profit_currency=info['currency_profit'])
    bars = [b for b in bars if start<=b.time.astimezone(NY).date()<=end]
    if not bars:
        raise ValueError('Requested dates have no archived candles')
    return bars, spec, capture


def session_spans(orders):
    spans = {}
    for order in orders:
        day = order.available_at.astimezone(NY).date()
        first = order.available_at-timedelta(seconds=11)
        rounded = first.replace(second=0,microsecond=0)-timedelta(minutes=first.minute%5)
        finish = datetime.combine(day,time(16,55),NY).astimezone(UTC)
        spans[str(day)] = min(rounded,spans.get(str(day),(rounded,finish))[0]),finish
    return spans


def broker_wall(at, policy):
    raw = at.astimezone(NY).replace(tzinfo=UTC)+timedelta(hours=7)
    if at>=datetime(2026,3,8,7,tzinfo=UTC):
        recorded = datetime.strptime(native_time(at.isoformat(),policy),'%Y.%m.%d %H:%M:%S').replace(tzinfo=UTC)
        if recorded!=raw:
            raise ValueError('Earlier verified broker clock and recent clock policy disagree')
    return raw


def capture_quotes(spans, source):
    import MetaTrader5 as mt5

    terminal = 'C:/Program Files/MetaTrader 5/terminal64.exe'
    if not mt5.initialize(terminal,timeout=10000):
        raise RuntimeError(f'MT5 unavailable: {mt5.last_error()}')
    output = {}
    try:
        account = mt5.account_info()
        initial = mt5.terminal_info()
        if not account or not initial or not initial.connected or account.server!=source['server']:
            raise RuntimeError('Expected the original TMGM terminal and quote server')
        identity = account.login,account.server
        for day,(start,end) in sorted(spans.items()):
            raw_from,raw_until = (broker_wall(t,source['clock']) for t in (start,end))
            shift = int((raw_from-start).total_seconds()*1000)
            if raw_until-end != raw_from-start:
                raise ValueError('Clock offset changes inside intraday tape')
            lo,hi = int(raw_from.timestamp())*1000,int(raw_until.timestamp())*1000
            rows = mt5.copy_ticks_range('XAUUSD',raw_from,raw_until,mt5.COPY_TICKS_INFO)
            if rows is None:
                output[day] = dict(error=str(mt5.last_error()),rows=[])
                continue
            tape = [[int(q['time_msc'])-shift,float(q['bid']),float(q['ask'])] for q in rows
                    if lo<=int(q['time_msc'])<hi and 0<q['bid']<=q['ask']]
            if any(a[0]>b[0] for a,b in zip(tape,tape[1:])):
                raise ValueError(f'Quote ordering decreased for {day}')
            output[day] = dict(rows=tape)
            print(day,len(tape),flush=True)
        final = mt5.account_info()
        if not final or (final.login,final.server)!=identity:
            raise RuntimeError('Terminal origin changed during collection')
    finally:
        mt5.shutdown()
    return output


def verify_tape(bars, spans, sessions):
    acknowledgements = {}
    ticks = []
    step_ms = int(STEP.total_seconds())*1000
    bar_map = {b.time:(b.open,b.high,b.low,b.close) for b in bars}
    for day,(start,end) in sorted(spans.items()):
        rows = sessions[day]['rows']
        grouped = defaultdict(list)
        for stamp,bid,ask in rows:
            when = EPOCH+timedelta(milliseconds=stamp)
            if not start<=when<end:
                raise ValueError(f'Quote lies outside its frozen range: {day}')
            key = EPOCH+timedelta(milliseconds=(stamp//step_ms)*step_ms)
            grouped[key].append(bid)
        expected = [start+i*STEP for i in range(int((end-start)//STEP))]
        missing = [t for t in expected if t not in grouped or t not in bar_map]
        different = [t for t,values in grouped.items() if t in bar_map and
                     (values[0],max(values),min(values),values[-1])!=bar_map[t]]
        gaps = sum(b[0]-a[0]>60000 for a,b in zip(rows,rows[1:]))
        eligible = not missing and not different and not gaps
        acknowledgements[day] = dict(quotes=len(rows),expected_bars=len(expected),
            missing=[t.isoformat() for t in missing],differences=[t.isoformat() for t in different],
            quote_gaps_over_minute=gaps,reconciled=eligible,source_error=sessions[day].get('error'))
        if eligible:
            ticks.extend(Tick(EPOCH+timedelta(milliseconds=stamp),bid,ask) for stamp,bid,ask in rows)
    return ticks, acknowledgements


def verify_decision_prefixes(orders,ticks,spec,equity,risk,decisions):
    times = [tick.time for tick in ticks]
    cutoffs = sorted({order.available_at for order in orders})
    for cutoff in cutoffs:
        quotes = ticks[:bisect_right(times,cutoff)]
        original = [row for row in decisions if utc_time(row['available_at'])<=cutoff]
        prefix = replay_tick_portfolio(orders,quotes,spec,cutoff,equity,risk)
        if prefix['decisions']!=original:
            raise ValueError(f'Future execution data changed a decision at {cutoff}')
    return len(cutoffs)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture',action='store_true')
    parser.add_argument('--start',type=date.fromisoformat,default=START)
    parser.add_argument('--end',type=date.fromisoformat,default=END)
    args = parser.parse_args()
    if not date(2025,7,1)<=args.start<=args.end<=END:
        parser.error('Choose complete dates in 2025-07-01 to 2026-11-20')
    artifact, report_path = ARTIFACT, REPORT
    historical = (args.start,args.end)!=(START,END)
    if historical:
        tag = f'ict_classic_reversal_tmgm_bidask_{args.start:%Y%m%d}_{args.end:%Y%m%d}'
        artifact = ARTIFACT.with_name(tag+'.json.gz')
        report_path = REPORT.with_name(tag+'.json')
    bars,spec,source = reference(args.start,args.end)
    signals,orders,checks = freeze_orders(bars,spec)
    spans = session_spans(orders)
    config_path = ROOT/'config/strategy.json'
    config = json.loads(config_path.read_bytes())
    risk = {k:config[k] for k in ('risk_fraction','daily_loss_limit','max_drawdown','max_consecutive_losses')}
    meta = dict(bars_sha256=archive.digest(check_pool_priority.ARCH/'XAUUSDM5.npz'),
                contract_sha256=archive.digest(CONTRACT),risk_config_sha256=archive.digest(config_path),
                clock=source['clock'],server=source['server'],
                orders=json.loads(json.dumps([asdict(o) for o in orders],default=lambda t:t.isoformat())))
    if historical:
        meta.update(earlier_clock='Broker wall equals New York wall +7 hours',
                    clock_witness_sha256=archive.digest(check_pool_priority.ARCH/'clock_validation.json'))
    if args.capture:
        if artifact.exists():
            raise FileExistsError(artifact)
        sessions = capture_quotes(spans,source)
        archive.write_zip(artifact,dict(meta=meta,sessions=sessions))
    data = archive.read_zip(artifact)
    if data['meta']!=meta:
        raise ValueError('Replay archive no longer matches frozen orders or source')
    ticks,witnesses = verify_tape(bars,spans,data['sessions'])
    verified = [o for o in orders if witnesses[str(o.available_at.astimezone(NY).date())]['reconciled']]
    cutoff = bars[-1].time+STEP
    books = {}
    for key,commission,slippage in [('spread_only',0.,0.),('base',7.,.05),('adverse',14.,.15)]:
        cost = replace(spec,commission_round_turn=commission,slippage=slippage)
        outcome = replay_tick_portfolio(verified,ticks,cost,cutoff,config['initial_equity'],risk)
        outcome['status_counts'] = dict(Counter(row['status'] for row in outcome['decisions']))
        outcome['exit_counts'] = dict(Counter(row['outcome'].get('reason',row['outcome']['status'])
                                              for row in outcome['completed']))
        outcome['costs_assumed'] = dict(commission_round_turn_per_lot=commission,adverse_slippage=slippage)
        if key=='base':
            outcome['decision_prefix_checks'] = verify_decision_prefixes(
                verified,ticks,cost,config['initial_equity'],risk,outcome['decisions'])
        for row in outcome['completed']:
            trade = row['outcome']
            if trade['status']=='closed':
                breakdown = trade['cost_breakdown']
                costs = sum(amount for item,amount in breakdown.items() if item!='midpoint_move_pnl')
                if abs(breakdown['midpoint_move_pnl']-costs-trade['pnl_net'])>1e-7:
                    raise ValueError('Execution cost ledger fails to reconcile')
        books[key] = outcome
    report = dict(start=str(args.start),end=str(args.end),chart_days=len({b.time.astimezone(NY).date() for b in bars
                  if b.time.astimezone(NY).weekday()<5}),signal_prefix_checks=checks,signals=signals,
                  verified_orders=[o.id for o in verified],witnesses=witnesses,inputs=meta,
                  raw_tick_archive_sha256=archive.digest(artifact),books=books,orders_sent=0,
                  assumptions=('Bid/Ask recorded by TMGM. Limit queue and fill quality unobserved. '
                               'Cost scenarios assume historical commission and slippage. '
                               'Contract grid is the recorded November reference.'))
    report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2,default=lambda t:t.isoformat())+'\n',
                           encoding='utf-8')
    print('Frozen',len(orders),'verified',len(verified),'quotes',len(ticks))
    print({name:(book['status_counts'],book['exit_counts'],book['final_realized_equity']) for name,book in books.items()})


if __name__=='__main__':
    main()
