"""Test pre-existing D1/W1 route ideas at fixed NY times and candidate cutoffs."""
from argparse import ArgumentParser
from collections import Counter
from datetime import date, datetime, time, timedelta
from hashlib import sha256
import json
from pathlib import Path

from brooks_ai.types import utc_time
from ict_ai.daily_context import _open, daily_weekly_context
from ict_ai.delivery import delivery_hypotheses
from ict_ai.route_study import assess_route, freeze_route
from ict_ai.timebase import NY, clock_policy_metadata, session_windows
from scripts.replay_ict_news import ROOT, STEP, load_history


SOURCE = "research/ict_price_videos/bias_dol/integration.json"


def merge_history(early, late):
    first_meta, first_hash, first = load_history(early)
    last_meta, last_hash, last = load_history(late)
    lo, hi = min(last), max(first)
    if not min(first) < lo <= hi < max(last):
        raise ValueError("Require ordered, extending snapshots with an overlap")
    shared = {at for at in first if lo <= at <= hi}
    if not shared or shared != {at for at in last if lo <= at <= hi}:
        raise ValueError("M5 snapshots disagree on the timestamps of their overlap")
    if any(first[at] != last[at] for at in shared):
        raise ValueError("M5 snapshots disagree on recorded overlap prices or spreads")
    merged = dict(sorted({**first, **last}.items()))
    sources = [
        {"manifest": str(path), "manifest_sha256": sha256(path.read_bytes()).hexdigest(),
         "quote_sha256": digest, **clock_policy_metadata(meta)}
        for path, digest, meta in ((early, first_hash, first_meta), (late, last_hash, last_meta))
    ]
    return merged, sources, len(shared), max(last) + STEP


def analyze_prior(rows, at):
    frame = daily_weekly_context(rows, at)
    delivery = delivery_hypotheses(frame, rows, at)
    route = freeze_route({"context": frame, "delivery_hypotheses": delivery})
    counts = {name: {
        "closed_periods": len(info["periods"]),
        "confirmed_swings": len(info["confirmed_swings"]),
        "geometric_fvgs": len(info["fvg_candidates"]),
        "pending_routes": sum(idea["timeframe"] == name and idea["stage"] == "idea_pending_validation"
                              for idea in delivery["hypotheses"]),
    } for name, info in frame["frames"].items()}
    return route, counts


def freeze_checked(rows, at):
    frozen = analyze_prior(rows, at)
    if frozen != analyze_prior([bar for bar in rows if bar.time + STEP <= at], at):
        raise AssertionError(f"Future prices changed prior route at {at}")
    return frozen


def observe_pair(bars, at, horizon, history_end, price, target):
    # A mirrored line at equal distance supplies a descriptive reference only.
    levels = {"route_target": target, "mirror_level": 2 * price - target}
    contacts = {}
    first = None
    missing = 0
    stamp = at
    while stamp + STEP <= min(horizon, history_end):
        if _open(stamp):
            bar = bars.get(stamp)
            if bar is None:
                missing += 1
            else:
                hits = [key for key, level in levels.items()
                        if key not in contacts and bar.low <= level <= bar.high]
                for key in hits:
                    contacts[key] = stamp + STEP
                if hits and first is None:
                    first = ("unknown_prior_gap" if missing else
                             "same_m5_order_unknown" if len(hits) == 2 else hits[0])
        stamp += STEP
    status = first or ("unknown_prior_gap" if missing else
                       "horizon_incomplete" if stamp < horizon else "neither_observed")
    return {"through_ny": stamp.astimezone(NY).isoformat(), "horizon_ny": horizon.astimezone(NY).isoformat(),
            "missing_m5_slots": missing, "first_contact": status, "levels": levels,
            "contact_known_at_ny": {key: at.astimezone(NY).isoformat() for key, at in contacts.items()}}


def run(early, late, start, end, decision_paths):
    if start > end:
        raise ValueError("Ordered NY date span required")
    bars, sources, shared, history_end = merge_history(early, late)
    rows = list(bars.values())
    checkpoints = []
    for i in range((end - start).days + 1):
        day = start + timedelta(days=i)
        if day.weekday() > 4:
            continue
        midnight = datetime.combine(day, time.min, NY)
        morning, morning_end = session_windows(day)["new_york"]
        finish = (datetime.combine(day, time(16, 55), NY) if day.weekday() == 4 else
                  datetime.combine(day + timedelta(days=1), time.min, NY))
        for label, at in (("00:00", midnight), ("07:00", morning)):
            if at > history_end:
                continue
            route, coverage = freeze_checked(rows, at)
            selected = route["selected_route"]
            observation = ({name: observe_pair(bars, at, through, history_end, route["price"],
                                                selected["target_reference_price"])
                            for name, through in (("ny_10", morning_end), ("day_close", finish))}
                           if selected else {})
            checkpoints.append({"day": day.isoformat(), "clock_ny": label,
                                "available_at_ny": at.astimezone(NY).isoformat(), "frozen": route,
                                "htf_coverage": coverage, "observations": observation})

    reevaluations = []
    source_hashes = {entry["quote_sha256"] for entry in sources}
    for path in decision_paths:
        raw = path.read_bytes()
        report = json.loads(raw)
        if report["quote_sha256"] not in source_hashes:
            raise ValueError("Candidate report must name an input quote snapshot")
        cases = []
        for case in report["cases"]:
            at = utc_time(case["sweep_started_at_ny"])
            known = utc_time(case["confirmed_at_ny"])
            if not min(bars) <= at <= known <= history_end:
                raise ValueError("Candidate is outside the merged history")
            route, coverage = freeze_checked(rows, at)
            event = {"sweep_started_at": at.isoformat(), "available_at": known.isoformat(),
                     "side": case["direction_known_at_confirmation"]}
            observed = assess_route(route, event, rows)
            cases.append({"id": case["event_id"], "sweep_started_at_ny": case["sweep_started_at_ny"],
                          "confirmed_at_ny": case["confirmed_at_ny"], "htf_coverage": coverage,
                          "prior_plan_status": case["full_context_plan"]["status"],
                          "old_route_status": case["route_at_confirmation"]["status"],
                          "merged_route_status": observed["status"],
                          "frozen": route, "assessment": observed})
        reevaluations.append({"report": str(path), "sha256": sha256(raw).hexdigest(), "cases": cases})

    summaries = {}
    for label in ("00:00", "07:00"):
        subset = [row for row in checkpoints if row["clock_ny"] == label]
        selected = [row for row in subset if row["frozen"]["selected_route"]]
        summaries[label] = {
            "freeze_statuses": dict(Counter(row["frozen"]["status"] for row in subset)),
            "distinct_routes": len({row["frozen"]["selected_route"]["id"] for row in selected}),
            "route_frames": dict(Counter(row["frozen"]["selected_route"]["timeframe"] for row in selected)),
            "first_contact_by_ny_10": dict(Counter(row["observations"]["ny_10"]["first_contact"] for row in selected)),
            "first_contact_by_day_close": dict(Counter(row["observations"]["day_close"]["first_contact"] for row in selected)),
        }
    dependencies = (SOURCE, "ict_ai/daily_context.py", "ict_ai/delivery.py", "ict_ai/range_liquidity.py",
                    "ict_ai/route_study.py", "ict_ai/timebase.py", "scripts/replay_ict_news.py",
                    "scripts/replay_ict_route_checkpoints.py")
    return {"sources": sources, "overlap_exact_m5_rows": shared, "merged_m5_rows": len(bars),
            "history_until_ny": history_end.astimezone(NY).isoformat(), "summary": summaries,
            "prefix_checks": len(checkpoints) + sum(len(row["cases"]) for row in reevaluations),
            "source_sha256": {p: sha256((ROOT / p).read_bytes()).hexdigest() for p in dependencies},
            "frozen_checkpoints": checkpoints, "candidate_reevaluations": reevaluations,
            "limits": [
                "Retrospective prefix reconstruction at fixed NY 00:00 and 07:00 using the last closed M5 price.",
                "D1/W1 only, historical clock and assumed session schedules. Missing expected slots remain unknown.",
                "Near-edge Bid contact and mirrored equal-distance contact are descriptive, without an entry or fill.",
                "One existing route can persist across days and checkpoints. Count of occurrences is not independent sample size.",
                "Route proxy remains an idea pending directional and PDA validation; news and costs do not qualify it.",
            ],
            "execution_allowed": False, "orders_sent": 0}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--early", type=Path, required=True)
    parser.add_argument("--late", type=Path, required=True)
    parser.add_argument("--from-ny", type=date.fromisoformat, required=True)
    parser.add_argument("--through-ny", type=date.fromisoformat, required=True)
    parser.add_argument("--decisions", type=Path, action="append", default=[])
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    report = run(args.early, args.late, args.from_ny, args.through_ny, args.decisions)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report["summary"]))
