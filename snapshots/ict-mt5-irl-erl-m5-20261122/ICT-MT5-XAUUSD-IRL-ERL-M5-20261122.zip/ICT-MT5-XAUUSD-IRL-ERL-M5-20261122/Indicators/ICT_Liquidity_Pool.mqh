// Closed-bar structure comes from the feed. Only distance and sweep state use live quotes.
struct PoolRow { int mark,score,reach; double distance; };
void poolLines(string &lines[],int width){
   int context=-1;
   for(int j=0;j<ArraySize(marks);j++)if(marks[j].kind=="pool_context")context=j;
   if(context<0){newsLine(lines,"流动性积累 · 等待已收 M5 结构",width);return;}
   Mark anchor=marks[context];MqlTick tick;
   bool quoted=SymbolInfoTick(_Symbol,tick) && tick.bid>0;
   bool live=quoted && tick.time>=anchor.start;
   double price=live?tick.bid:anchor.first,upper=price,lower=price;
   string scope=poolExternal?"ERL":"IRL",kindPrefix=poolExternal?"pool_erl_":"pool_irl_";
   newsLine(lines,(poolExternal?"外部流动性积累 ":"内部流动性积累 ")+scope+" · "+(live?"Bid ":"最近收盘 ")+DoubleToString(price,_Digits),width);
   newsLine(lines,"结构 "+easternTime(anchor.start)+" 美东 · "+anchor.label,width);
   if(live){
      MqlRates bars[];
      int n=CopyRates(_Symbol,PERIOD_M5,anchor.start,tick.time,bars);
      if(n<0){newsLine(lines,"正在同步区间行情，稍后更新排名",width);return;}
      for(int i=0;i<n;i++)if(bars[i].time>=anchor.start){
         upper=MathMax(upper,bars[i].high);lower=MathMin(lower,bars[i].low);
      }
   }
   PoolRow top[10];int count=0,swept=0;
   for(int j=0;j<ArraySize(marks);j++){
      Mark m=marks[j];bool buy=m.kind==kindPrefix+"buy";
      if((!buy && m.kind!=kindPrefix+"sell") || m.start!=anchor.start || anchor.last<=0)continue;
      if(buy?upper>m.last:lower<m.first){swept++;continue;}
      double distance=MathMax(0.,buy?m.first-price:price-m.last);
      int reach=(int)MathRound(27./(1.+distance/(3.*anchor.last)));
      PoolRow item;item.mark=j;item.reach=reach;item.distance=distance;
      item.score=(int)StringToInteger(m.label)+reach;
      int pos=0;
      while(pos<count && (top[pos].score>item.score || (top[pos].score==item.score &&
            (top[pos].distance<distance || (top[pos].distance==distance && marks[top[pos].mark].first<=m.first)))))pos++;
      if(pos>=10)continue;
      count=MathMin(10,count+1);
      for(int k=count-1;k>pos;k--)top[k]=top[k-1];
      top[pos]=item;
   }
   if(count==0)newsLine(lines,"当前没有可核实的待扫目标",width);
   for(int pass=0;pass<2;pass++)for(int i=0;i<count;i++){
      PoolRow row=top[i];string fields[];int n=StringSplit(marks[row.mark].label,'｜',fields);
      if(n<4)continue;
      string rank=StringFormat("#%02d  %d/100  ",i+1,row.score);
      if(pass==0)newsLine(lines,rank+fields[1],width);
      else{
         newsLine(lines,rank+fields[1]+" · 距离 "+DoubleToString(row.distance,_Digits),width);
         newsLine(lines,fields[2],width);newsLine(lines,fields[3]+"、距离 "+IntegerToString(row.reach),width);
      }
   }
   newsLine(lines,StringFormat("结构更新后已越过 %d 处 · %s",swept,poolExternal?"日、周、月外沿":"纽约当日和前一交易日摆动优先"),width);
   newsLine(lines,"评分衡量结构证据与距离。挂单数量无法从黄金 K 线直接观测。",width);
}
