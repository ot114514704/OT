@echo off
cd /d "%~dp0"
"runtime\python.exe" -B -u -m scripts.export_mt5_profiles
pause
