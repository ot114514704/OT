@echo off
cd /d "%~dp0"
"runtime\python.exe" -B -u -m scripts.install_h1
pause
