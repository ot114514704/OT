from pathlib import Path
import shutil
import MetaTrader5 as mt5

if not mt5.initialize():
    raise SystemExit("Open your MT5 terminal and retry.")
try:
    destination = Path(mt5.terminal_info().data_path) / "MQL5/Indicators/ICT_Trader"
finally:
    mt5.shutdown()
destination.mkdir(parents=True, exist_ok=True)
for source in (Path(__file__).resolve().parents[2] / "Indicators").iterdir():
    shutil.copy2(source, destination / source.name)
print("Installed ICT_H1_Profiles in", destination)
