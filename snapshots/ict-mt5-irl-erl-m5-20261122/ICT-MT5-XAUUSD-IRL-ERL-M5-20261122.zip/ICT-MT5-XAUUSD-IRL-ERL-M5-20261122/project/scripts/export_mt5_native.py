"""Read-only MT5 native-object bridge using the existing ICT analysis engine."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
import csv,json,os,sys,time,threading,argparse,hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from ict_ai.timebase import NY,manifest_epoch_to_utc

def native_time(value,policy):
    if isinstance(value,(int,float)):utc=datetime.fromtimestamp(value/1000,timezone.utc)
    else:
        stamp=datetime.fromisoformat(value.replace('Z','+00:00'))
        if stamp.utcoffset() is None:
            raise ValueError('Chart timestamp requires an explicit UTC offset')
        utc=stamp.astimezone(timezone.utc)
    segments=policy.get('source_clock_segments')
    if not segments:
        if 'source_clock_offset_hours' not in policy:
            raise ValueError('Chart timestamp requires an explicit broker clock policy')
        segments=[{'offset_hours':policy['source_clock_offset_hours']}]
    matches=[]
    for segment in segments:
        raw=utc+timedelta(hours=segment['offset_hours'])
        if (not segment.get('raw_from') or raw>=datetime.fromisoformat(segment['raw_from'])) and (not segment.get('raw_until') or raw<datetime.fromisoformat(segment['raw_until'])):
            matches.append(raw)
    if len(matches)!=1:raise ValueError('Ambiguous native chart time')
    return matches[0].strftime('%Y.%m.%d %H:%M:%S')

def objects(payload,policy):
    rows=[];serial=0
    def add(scope,period,group,kind,a,p,b,q,label,col,width=1):
        nonlocal serial
        if a is None or b is None or p is None or q is None:return
        serial+=1
        rows.append([scope,str(period),group,kind,str(serial),native_time(a,policy),str(p),native_time(b,policy),str(q),label.replace('\n',' ')[:210],col,str(width)])
    s=next(s for s in payload['scenarios'] if s['id']=='broker-plus3')
    for scope,records in [('DAY',s['days']),('WEEK',s['weeks']),('MONTH',[s['month']])]:
        for r in records:
            for period in (5,15,60):
                c=r.get('charts',{}).get(str(period),{})
                bars=c.get('bars') or (r.get('bars',[]) if period==(60 if scope=='MONTH' else 15) else [])
                if not bars:continue
                start,end=bars[0][0],bars[-1][0]+period*60000
                low=min(b[3] for b in bars);high=max(b[2] for b in bars)
                label=(r.get('date') or (r.get('days') or [r.get('month','')])[0])+' '+r.get('profile_label','')
                if scope=='DAY':
                    midnight=datetime.fromisoformat(r['date']).replace(tzinfo=NY)
                    midnight_ms=int(midnight.timestamp()*1000)
                    # The context may include the previous NY evening. Keep the
                    # title inside this date and above the bars belonging to it.
                    day_bars=[bar for bar in bars if bar[0]>=midnight_ms]
                    if day_bars:
                        day_high=max(bar[2] for bar in day_bars)
                        title_time=(midnight_ms+end)//2
                        state='复盘' if r.get('day_completed') else '进行中'
                        title=f"{r['date'][5:]} {state} · {r.get('profile_label') or '待归类'}"
                        add(scope,period,'BASE','TEXT',title_time,day_high,end,day_high,title,'info')
                    add(scope,period,'OPEN','LINE',midnight.isoformat(),r.get('daily_open'),end,r.get('daily_open'),'纽约 00:00 开盘','info')
                else:
                    add(scope,period,'BASE','TEXT',start,high,end,high,label,'info')
                dates=[r['date']] if scope=='DAY' else r.get('days') or [d['date'] for d in r.get('daily',[])]
                for date in dates:
                    midnight=datetime.fromisoformat(date).replace(tzinfo=NY)
                    add(scope,period,'BASE','VLINE',midnight.isoformat(),low,midnight.isoformat(),high,date+' NY 00:00','muted')
                for g in c.get('fvgs',r.get('fvgs',[]) if scope=='MONTH' else []):
                    t=g.get('available_at')
                    if not t:continue
                    a=datetime.fromisoformat(t)-timedelta(minutes=3*period)
                    b=min(datetime.fromtimestamp(end/1000,timezone.utc),datetime.fromisoformat(t)+timedelta(minutes=period*12))
                    if b<=a:continue
                    bull=g['direction']=='bullish'
                    add(scope,period,'FVG','BOX',a.isoformat(),g['lower'],b.isoformat(),g['upper'],'看涨 FVG' if bull else '看跌 FVG','bull' if bull else 'bear')
                for e in r.get('amd_events',[]):
                    add(scope,period,'AMD','BOX',e['start'],e['lower'],e['end'],e['upper'],'AMD '+e['phase']+' 候选',{'A':'asia','M':'london','D':'ny'}.get(e['phase'],'info'))
                for e in r.get('po3',{}).get('zones',[]) if scope=='DAY' else r.get('po3_zones',[]):
                    a=e.get('start_ms') or e.get('start');b=e.get('end_ms') or e.get('end')
                    add(scope,period,'PO3','BOX',a,e.get('lower'),b,e.get('upper'),'PO3 '+e.get('phase','')+' 候选','london')
                for e in c.get('smt',[]):
                    points=e['primary'];a,b=points[0],points[-1]
                    add(scope,period,'SMT','LINE',a['time_ms'],a['price'],b['time_ms'],b['price'],'SMT 候选','info',2)
                if scope=='DAY':
                    for key,e in r.get('sessions',{}).items():
                        if e.get('high') is not None:add(scope,period,'SESSION','BOX',e['start'],e['low'],e['end'],e['high'],key,{'asia':'asia','london':'london'}.get(key,'ny'))
                    for e in r.get('silver_windows',[]):add(scope,period,'SILVER','FRAME',e['start_ms'],low,e['end_ms'],high,'银弹 '+e['ny_time'],'london')
                if scope!='MONTH':
                    for e in r.get('liquidity',{}).get('pools',[]):
                        group=e['classification']
                        if scope=='WEEK' and group!='ERL':continue
                        swept=e.get('reclaim_known_at');a=e.get('anchor_time') or e['available_at']
                        finish=swept or (min(end,datetime.fromisoformat(a).timestamp()*1000+period*4*60000) if group=='IRL' else end)
                        source=r.get('liquidity',{}).get('range',{}).get('timeframe','')
                        label=group+('（买方）' if e['side']=='buy_side_proxy' else '（卖方）')+' '+source+(' 已清扫' if swept else '')
                        add(scope,period,group,'LINE',a,e['price'],finish,e['price'],label,'muted' if swept else 'info',2 if group=='ERL' else 1)
                    for e in r.get('regular_liquidity',{}).get('levels',[]):
                        a=e.get('anchor_time') or e['available_at'];finish=e.get('sweep_known_at') or end
                        add(scope,period,'REG','LINE',a,e['price'],finish,e['price'],e['kind']+' '+e.get('source_scope','')+(' 已清扫' if e.get('sweep_known_at') else ''),'muted',1)
                if scope=='WEEK':
                    points=r.get('weekly_path',{}).get('points',[])
                    for a,b in zip(points,points[1:]):add(scope,period,'PATH','LINE',a['time_ms'],a['price'],b['time_ms'],b['price'],'周高低点','info',2)
    return rows

def write_snapshot(folder,payload,quote,policy):
    folder.mkdir(parents=True,exist_ok=True)
    stamp=payload['snapshot_read_at'];rows=objects(payload,policy)
    generation=hashlib.sha256(json.dumps(rows,ensure_ascii=False).encode()).hexdigest()[:24]
    # Versioned data + small atomic pointer: the indicator never reads half a CSV.
    name='objects_'+generation+'.csv'
    if not (folder/name).exists():
        with (folder/name).open('w',encoding='utf-16',newline='') as f:
            csv.writer(f,delimiter='\t').writerows(rows)
    status='LIVE' if quote and quote.get('status')=='live' else 'SNAPSHOT / STALE'
    tmp=folder/'state.tmp'
    tmp.write_text(name+'\n'+status+' | '+stamp+' | 时标推定 | 仅分析\n',encoding='utf-16')
    os.replace(tmp,folder/'state.txt')
    old=sorted(folder.glob('objects_*.csv'),key=lambda p:p.stat().st_mtime,reverse=True)
    for p in old[3:]:
        try:p.unlink()
        except OSError:pass

def main():
    from scripts.serve_ict_live import LiveState,capture,checked_account
    ap=argparse.ArgumentParser();ap.add_argument('--once',action='store_true');ap.add_argument('--terminal',default='C:/Program Files/MetaTrader 5/terminal64.exe');args=ap.parse_args()
    policy=json.loads((ROOT/'research/live_clock_20261116.json').read_text(encoding='utf8'))
    folder=Path(os.environ['APPDATA'])/'MetaQuotes/Terminal/Common/Files/ICT_Trader'
    state=LiveState(ROOT/'runtime/mt5-native',args.terminal,2,policy)
    import MetaTrader5 as api
    try:
        if not api.initialize(path=args.terminal,timeout=15000):raise RuntimeError(str(api.last_error()))
        checked_account(api)
        xau=capture(api,'XAUUSD',state.workspace/'current/XAU',timedelta(hours=2),policy)
        xag=capture(api,'XAGUSD',state.workspace/'current/XAG',timedelta(hours=2),policy)
        state.payload=state.build_snapshot(xau,xag,datetime.now(NY).date().isoformat())
    finally:api.shutdown()
    write_snapshot(folder,state.payload,None,policy)
    print('MT5 objects ready: '+str(folder),flush=True)
    if args.once:return
    worker=threading.Thread(target=state.worker,daemon=True);worker.start()
    try:
        while True:
            data=state.response('live')
            if data:write_snapshot(folder,data,data.get('live'),policy)
            time.sleep(5)
    except KeyboardInterrupt:state.stop.set()

if __name__=='__main__':main()
