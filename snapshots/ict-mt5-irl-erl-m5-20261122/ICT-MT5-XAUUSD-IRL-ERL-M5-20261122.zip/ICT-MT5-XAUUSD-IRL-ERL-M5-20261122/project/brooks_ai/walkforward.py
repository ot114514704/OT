"""Fixed-protocol rolling evaluation; no model selection on future test results."""
from dataclasses import asdict,replace
from datetime import datetime,timezone
import hashlib
from pathlib import Path
from .backtest import run
from .data import load_json,save_json
from .model import Classifier,collect,fit,evaluate,chronological_samples,policy_fingerprint,digest


def plan_folds(length,train_bars,validation_bars,test_bars):
    for name,value in (("length",length),("train_bars",train_bars),
                       ("validation_bars",validation_bars),("test_bars",test_bars)):
        if type(value) is not int or value<=0:
            raise ValueError(name+" must be a positive integer")
    if train_bars<80:
        raise ValueError("Training window must contain at least 80 bars")
    width=train_bars+validation_bars+test_bars
    if width>length:
        raise ValueError("Insufficient history for one complete rolling fold")
    folds=[]
    origin=0
    while origin+width<=length:
        a=origin+train_bars
        b=a+validation_bars
        end=b+test_bars
        folds.append({"train":[origin,a],"validation":[a,b],"test":[b,end]})
        origin+=test_bars  # Test segments never overlap; windows may reuse now-known past data.
    return folds


def slice_audit(samples,start,end):
    located=[s for s in samples if start<=s["signal_index"]<end]
    selected=chronological_samples(samples,start,end)
    return {"candidates_in_slice":len(located),"matured_samples":len(selected),
            "purged_boundary_labels":len(located)-len(selected),
            "latest_label_exit_index":max((s["exit_index"] for s in selected),default=None)}


def performance_gates(result,probability,cfg):
    m=result["metrics"]
    return {"minimum_trades":m["trades"]>=cfg["validation_min_trades"],
            "positive_net_pnl":m["net_pnl"]>0,
            "profit_factor":m["profit_factor"] is not None and m["profit_factor"]>=cfg["validation_min_profit_factor"],
            "drawdown":m["max_drawdown"]<=cfg["max_drawdown"],
            "probability_improves_prior":probability["brier"]<probability["prior_brier"]}


def walk_forward(bars,spec,cfg,data_path,out_path,train_bars=10000,validation_bars=3000,test_bars=3000,execution=None):
    plans=plan_folds(len(bars),train_bars,validation_bars,test_bars)
    provenance_path=Path(str(data_path)+".provenance.json")
    provenance=load_json(provenance_path) if provenance_path.exists() else {}
    synthetic=provenance.get("synthetic",False) is True
    collect_fn=execution.collect if execution is not None else collect
    run_fn=execution.run if execution is not None else run
    samples=collect_fn(bars,spec,cfg)
    stress_spec=replace(spec,commission_round_turn=2*spec.commission_round_turn,slippage=2*spec.slippage)
    stress_bars=[replace(b,spread=2*b.spread) for b in bars]
    folds=[]
    details=[]
    for number,plan in enumerate(plans,1):
        result={"fold":number,"slices":plan,"index_convention":"start inclusive, end exclusive",
                "periods":{name:{"from":bars[lo].time.isoformat(),"last_bar":bars[hi-1].time.isoformat()}
                           for name,(lo,hi) in plan.items()},
                "label_audit":{name:slice_audit(samples,*bounds) for name,bounds in plan.items()}}
        train_samples=chronological_samples(samples,*plan["train"])
        validation=chronological_samples(samples,*plan["validation"])
        test=chronological_samples(samples,*plan["test"])
        # Explicit insufficiency is an outcome of this protocol; never shrink/tune a fold to make it pass.
        try:
            artifact=fit(train_samples)
            model=Classifier(artifact)
            validation_prob=evaluate(model,validation,artifact["training_prior"])
            test_prob=evaluate(model,test,artifact["training_prior"])
        except ValueError as e:
            result.update({"status":"insufficient_samples","reason":str(e),"passed":False})
            folds.append(result)
            continue
        va,vb=plan["validation"]
        ta,tb=plan["test"]
        validation_run=run_fn(bars,spec,cfg,model,start=va,end=vb-1)
        test_run=run_fn(bars,spec,cfg,model,start=ta,end=tb-1)
        baseline=run_fn(bars,spec,cfg,start=ta,end=tb-1)
        stress=execution.stress(spec,cfg,model,ta,tb-1) if execution is not None else run(stress_bars,stress_spec,cfg,model,start=ta,end=tb-1)
        gates={"validation":performance_gates(validation_run,validation_prob,cfg),
               "test":performance_gates(test_run,test_prob,cfg),
               "stress":{"positive_net_pnl":stress["metrics"]["net_pnl"]>0,
                         "drawdown":stress["metrics"]["max_drawdown"]<=cfg["max_drawdown"]}}
        if execution is not None:
            runs={"validation":validation_run,"test":test_run,"baseline_test":baseline,"double_cost_test":stress}
            result["execution_audit"]={name:{"quote_audit":value["quote_audit"],"boundary_policy":value["boundary_policy"]}
                                       for name,value in runs.items()}
            gates["tick_boundaries"]={name:value["quote_audit"]["end_of_history_trades"]==0
                                     and value["boundary_policy"]["require_mature_horizon"] is True for name,value in runs.items()}
        result.update({"status":"evaluated","probability":{"validation":validation_prob,"test":test_prob},
                       "metrics":{"validation":validation_run["metrics"],"test":test_run["metrics"],
                                  "baseline_test":baseline["metrics"],"double_cost_test":stress["metrics"]},
                       "fitted_parameters_digest":digest(artifact),"gates":gates,
                       "passed":all(value for group in gates.values() for value in group.values())})
        folds.append(result)
        details.append({"fold":number,"model_parameters":artifact,"validation":validation_run,
                        "test":test_run,"baseline_test":baseline,"double_cost_test":stress})
    evaluated=[f for f in folds if f["status"]=="evaluated"]
    summary={"planned_folds":len(folds),"evaluated_folds":len(evaluated),
             "insufficient_folds":len(folds)-len(evaluated),"passing_folds":sum(f["passed"] for f in folds),
             "minimum_three_folds":len(folds)>=3,
             "every_planned_fold_passes":all(f["passed"] for f in folds),
             "contract_and_costs_verified":spec.verified is True and spec.costs_verified is True,
             "synthetic":synthetic,
             "worst_fold_drawdown":max((f["metrics"]["test"]["max_drawdown"] for f in evaluated),default=None),
             "positive_test_folds":sum(f["metrics"]["test"]["net_pnl"]>0 for f in evaluated)}
    summary["rolling_research_gates_pass"]=all((summary["minimum_three_folds"],summary["every_planned_fold_passes"],
                                                summary["contract_and_costs_verified"],not synthetic))
    basis=execution.basis if execution is not None else "bid_ohlc"
    detail_artifact={"synthetic":synthetic,"execution_basis":basis,"folds":details}
    report={"schema":1,"kind":"rolling_research_evaluation","created_at_utc":datetime.now(timezone.utc).isoformat(),
            "history_bars":len(bars),"details_digest":digest(detail_artifact),
            "execution_basis":basis,"execution_evidence":execution.evidence() if execution is not None else {"basis":basis},
            "symbol":spec.symbol,"account_currency":spec.account_currency,"instrument":asdict(spec),
            "policy_fingerprint":policy_fingerprint(cfg),"data_sha256":hashlib.sha256(Path(data_path).read_bytes()).hexdigest(),
            "protocol":{"train_bars":train_bars,"validation_bars":validation_bars,"test_bars":test_bars,
                        "step_bars":test_bars,"training":"fixed rolling window; fit/scaler use training slice only",
                        "thresholds":"preconfigured, unchanged between folds",
                        "portfolio":"each validation/test/stress segment resets equity and risk state; not a continuous portfolio",
                        "unconsumed_tail_bars":len(bars)-plans[-1]["test"][1]},
            "summary":summary,"folds":folds,"execution_authorization":False,
            "limitations":["Sample labels can be correlated across framework families",
                           "Recorded quote coverage or OHLC path assumptions and constant contract/cost inputs still require validation",
                           "Window choices must be fixed before viewing results; reruns are further research, not a new untouched holdout",
                           "Use qualify-rolling to bind the final evaluated parameters to this report; it does not replace broker forward testing"]}
    report["integrity"]=digest(report)
    save_json(out_path,report)
    save_json(str(Path(out_path).with_suffix(".details.json")),detail_artifact)
    return report
