from decimal import Decimal, ROUND_FLOOR
import math


def size_volume(budget, loss_per_lot, spec):
    if not math.isfinite(budget) or not math.isfinite(loss_per_lot) or budget <= 0 or loss_per_lot <= 0:
        return 0.0
    raw = min(budget/loss_per_lot, spec.volume_max)
    steps = (Decimal(str(raw))/Decimal(str(spec.volume_step))).to_integral_value(rounding=ROUND_FLOOR)
    volume = float(steps*Decimal(str(spec.volume_step)))
    return volume if volume+1e-12 >= spec.volume_min and volume*loss_per_lot <= budget+1e-8 else 0.0


def entry_allowed(equity, peak, day_start, cfg, consecutive_losses=0):
    if not all(math.isfinite(x) and x > 0 for x in (equity,peak,day_start)):
        return False, "Invalid equity"
    if equity <= peak*(1-cfg["max_drawdown"]):
        return False, "Maximum drawdown halt"
    if equity <= day_start*(1-cfg["daily_loss_limit"]):
        return False, "Daily loss halt"
    if consecutive_losses >= cfg["max_consecutive_losses"]:
        return False, "Consecutive loss halt"
    return True, "ok"

