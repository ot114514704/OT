"""MT5 integration restricted to a specifically bound DEMO account.

All order sends pass through one guard. Unknown/partial results are journaled
and stop new entries until reconciled; failed requests are never blindly retried.
"""
from dataclasses import asdict
from datetime import datetime, timezone, timedelta
from decimal import Decimal, ROUND_FLOOR, ROUND_CEILING
import csv
import importlib
import json
import math
from pathlib import Path
import sqlite3
import time
from .types import Bar, Instrument, Tick, utc_time
from .data import save_json
from .model import Classifier, policy_fingerprint
from .strategy import detect, select, context
from .risk import size_volume, entry_allowed

TIMEFRAME_SECONDS={"M1":60,"M5":300,"M15":900,"M30":1800,"H1":3600,"H4":14400,"D1":86400}


class Refused(RuntimeError):
    pass


class Journal:
    def __init__(self,path):
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(path,timeout=10)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("CREATE TABLE IF NOT EXISTS intent (id TEXT PRIMARY KEY, account TEXT, status TEXT, payload TEXT)")
        self.db.execute("CREATE TABLE IF NOT EXISTS state (account TEXT PRIMARY KEY, payload TEXT)")
        self.db.commit()

    def reserve(self,key,account,payload):
        try:
            self.db.execute("INSERT INTO intent VALUES (?,?,?,?)",(key,account,"reserved",json.dumps(payload)))
            self.db.commit()
            return True
        except sqlite3.IntegrityError:
            self.db.rollback()
            return False

    def finish(self,key,status,payload):
        self.db.execute("UPDATE intent SET status=?,payload=? WHERE id=?",(status,json.dumps(payload),key))
        self.db.commit()

    def unresolved(self,account):
        return self.db.execute("SELECT id,status,payload FROM intent WHERE account=? AND status IN ('reserved','unknown','partial')",(account,)).fetchall()

    def load_state(self,account):
        row=self.db.execute("SELECT payload FROM state WHERE account=?",(account,)).fetchone()
        return json.loads(row[0]) if row else None

    def save_state(self,account,payload):
        self.db.execute("INSERT OR REPLACE INTO state VALUES (?,?)",(account,json.dumps(payload)))
        self.db.commit()

    def close(self):
        self.db.close()


class ProcessLock:
    """OS lock released automatically on process exit; no stale PID lock reuse."""
    def __init__(self,path):
        self.path=Path(path)

    def __enter__(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.file=self.path.open("a+b")
        self.file.seek(0)
        self.file.write(b"0")
        self.file.flush()
        self.file.seek(0)
        try:
            import msvcrt
            msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
        except ImportError:
            import fcntl
            fcntl.flock(self.file.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError as e:
            self.file.close()
            raise Refused("Another demo process owns the project lock") from e
        return self

    def __exit__(self,*args):
        self.file.close()


def rounded(price,step,up):
    mode=ROUND_CEILING if up else ROUND_FLOOR
    return float((Decimal(str(price))/Decimal(str(step))).to_integral_value(rounding=mode)*Decimal(str(step)))


class Gateway:
    def __init__(self,cfg,api=None):
        self.cfg=cfg
        self.api=api or importlib.import_module("MetaTrader5")
        self._tick_bars_cache=None

    def connect(self):
        if self.cfg["timeframe"] not in TIMEFRAME_SECONDS:
            raise Refused("Unsupported timeframe")
        kwargs={"timeout":10000}
        if self.cfg.get("terminal_path"):
            ok=self.api.initialize(self.cfg["terminal_path"],**kwargs)
        else:
            ok=self.api.initialize(**kwargs)
        if not ok:
            raise Refused(f"MT5 initialize failed: {self.api.last_error()}. Open the TMGM MT5 demo terminal first.")

    def shutdown(self):
        self.api.shutdown()

    def identity(self):
        account=self.api.account_info()
        terminal=self.api.terminal_info()
        if account is None or terminal is None or not terminal.connected:
            raise Refused("No connected MT5 account")
        if account.trade_mode!=self.api.ACCOUNT_TRADE_MODE_DEMO:
            raise Refused("Only DEMO accounts supported. Real and contest accounts are refused.")
        if self.cfg["broker"].upper()=="TMGM":
            identity=(account.company+" "+account.server).casefold()
            if "tmgm" not in identity and "trademax" not in identity:
                raise Refused("Connected demo broker does not identify as TMGM/Trademax")
        return account,terminal

    def guard(self,orders=False):
        account,terminal=self.identity()
        expected=self.cfg.get("expected_account_login")
        server=self.cfg.get("expected_server")
        if expected is None or server is None:
            raise Refused("Use mt5-bind to bind this connected demo account before execution")
        if account.login!=expected or account.server!=server:
            raise Refused("Account or server switched after binding")
        if orders and (not account.trade_allowed or not account.trade_expert or not terminal.trade_allowed or terminal.tradeapi_disabled):
            raise Refused("Automated trading is disabled by terminal/account settings")
        return account

    def symbol(self):
        name=self.cfg["symbol"]
        info=self.api.symbol_info(name)
        if info is None:
            raise Refused("Exact broker symbol missing: "+name)
        if not info.visible:
            if not self.api.symbol_select(name,True):
                raise Refused("Cannot select exact symbol")
            info=self.api.symbol_info(name)
        if info is None or info.point<=0 or info.trade_tick_size<=0:
            raise Refused("Invalid instrument metadata")
        return info

    def tick(self):
        tick=self.api.symbol_info_tick(self.cfg["symbol"])
        if tick is None or not all(math.isfinite(x) for x in (tick.bid,tick.ask)) or tick.bid<=0 or tick.ask<tick.bid:
            raise Refused("Invalid bid/ask quote")
        tick_time=tick.time_msc/1000 if tick.time_msc else tick.time
        age=time.time()-tick_time
        if age>self.cfg["max_tick_age_seconds"] or age < -5:
            raise Refused("Stale or future quote")
        return tick

    def bars(self,count=500):
        info=self.symbol()
        tf=getattr(self.api,"TIMEFRAME_"+self.cfg["timeframe"])
        rates=self.api.copy_rates_from_pos(self.cfg["symbol"],tf,1,count)
        if rates is None or len(rates)<80:
            raise Refused("Not enough closed bars in MT5 chart history")
        result=[Bar(utc_time(int(z["time"])),float(z["open"]),float(z["high"]),float(z["low"]),
                    float(z["close"]),float(z["spread"])*info.point) for z in rates]
        if any(b.time<=a.time for a,b in zip(result,result[1:])):
            raise Refused("MT5 history is not strictly chronological")
        now=datetime.now(timezone.utc)
        seconds=TIMEFRAME_SECONDS[self.cfg["timeframe"]]
        if result[-1].time+timedelta(seconds=seconds)>now:
            raise Refused("Unclosed bar returned")
        return result

    def bars_from_ticks(self,count=120):
        """Match tick-trained feature aggregation; require chart-price agreement."""
        from .tickbacktest import aggregate_ticks
        account,_=self.identity()
        original_identity=(account.login,account.server)
        info=self.symbol()
        closed=self.bars(count+1)
        if len(closed)<count+1:
            raise Refused("Not enough closed history for tick-model feature window")
        expected=closed[-count:]
        key=(account.login,account.server,self.cfg["timeframe"],count,expected[-1].time)
        cache=self._tick_bars_cache
        if cache is not None and cache[0]==key:
            result=cache[1]
        else:
            now=datetime.now(timezone.utc)
            quotes=self.api.copy_ticks_range(self.cfg["symbol"],closed[0].time,now,self.api.COPY_TICKS_INFO)
            if quotes is None:
                raise Refused("Tick-model feature history unavailable: "+str(self.api.last_error()))
            epoch=datetime(1970,1,1,tzinfo=timezone.utc)
            ticks=[]
            for row in quotes:
                tick=Tick(epoch+timedelta(milliseconds=int(row["time_msc"])),float(row["bid"]),float(row["ask"]))
                if closed[0].time<=tick.time<=now:
                    ticks.append(tick)
            result,_=aggregate_ticks(ticks,TIMEFRAME_SECONDS[self.cfg["timeframe"]])
            if len(result)<count:
                raise Refused("Tick-model aggregation lacks the required closed buckets or current edge quote")
            result=result[-count:]
        tolerance=info.trade_tick_size/2+1e-10
        if any(a.time!=b.time or any(not math.isclose(getattr(a,name),getattr(b,name),rel_tol=0,abs_tol=tolerance)
                                   for name in ("open","high","low","close")) for a,b in zip(result,expected)):
            self._tick_bars_cache=None
            raise Refused("Tick-model bars disagree with terminal chart; incomplete or inconsistent history")
        current,_=self.identity()
        if (current.login,current.server)!=original_identity:
            self._tick_bars_cache=None
            raise Refused("Account changed while constructing tick-model features")
        self._tick_bars_cache=(key,result)
        return result

    def spec(self):
        info=self.symbol()
        account,_=self.identity()
        commission=self.cfg.get("commission_round_turn")
        if commission is None or not isinstance(commission,(int,float)) or not math.isfinite(commission) or commission<0:
            raise Refused("Set actual round-turn commission per lot in account currency")
        # Swap mode varies. Never silently interpret broker points as cash.
        cash_costs=self.cfg.get("swap_long_account_per_lot") is not None and self.cfg.get("swap_short_account_per_lot") is not None
        return Instrument(info.name,info.point,info.trade_tick_size,info.trade_contract_size,
                          info.volume_min,info.volume_step,info.volume_max,account.currency,info.currency_profit,
                          commission,self.cfg["deviation_points"]*info.point,
                          self.cfg.get("swap_long_account_per_lot") or 0,
                          self.cfg.get("swap_short_account_per_lot") or 0,
                          self.cfg["swap_triple_weekday"],self.cfg["swap_rollover_hour_utc"],
                          verified=True,costs_verified=cash_costs)

    def filling(self,info):
        if info.filling_mode & 2:
            return self.api.ORDER_FILLING_IOC
        if info.filling_mode & 1:
            return self.api.ORDER_FILLING_FOK
        if info.trade_exemode!=self.api.SYMBOL_TRADE_EXECUTION_MARKET:
            return self.api.ORDER_FILLING_RETURN
        raise Refused("No supported market-order filling policy")

    def exposures(self):
        positions,orders=self.api.positions_get(),self.api.orders_get()
        if positions is None or orders is None:
            raise Refused("Cannot establish current account exposures")
        return positions,orders

    def send_guarded(self,request):
        self.guard(orders=True)  # Called immediately before every opening and closing send.
        if request["symbol"]!=self.cfg["symbol"] or request["magic"]!=self.cfg["magic"]:
            raise Refused("Request does not match configured symbol/magic")
        self.tick()
        check=self.api.order_check(request)
        if check is None or check.retcode!=0:
            raise Refused("Broker order_check refused request")
        self.guard(orders=True)
        return self.api.order_send(request)


def bind(gateway,config_path):
    gateway.connect()
    try:
        account,terminal=gateway.identity()
        info=gateway.symbol()
        gateway.cfg.update({"expected_account_login":int(account.login),"expected_server":account.server,
                            "terminal_path":terminal.path+"/terminal64.exe"})
        save_json(config_path,gateway.cfg)
        return {"status":"demo account bound","server":account.server,"symbol":info.name,
                "account_currency":account.currency,"commission_required":gateway.cfg["commission_round_turn"] is None}
    finally:
        gateway.shutdown()


def export_history(gateway,out_csv,out_spec,count):
    gateway.connect()
    try:
        gateway.identity()
        bars=gateway.bars(count)
        spec=gateway.spec()
        if spec.profit_currency!=spec.account_currency:
            raise Refused("Historical currency conversion requires extra market data; use account-currency-quoted symbols")
        Path(out_csv).parent.mkdir(parents=True,exist_ok=True)
        with open(out_csv,"w",encoding="utf-8",newline="") as f:
            writer=csv.writer(f)
            writer.writerow(["time","open","high","low","close","spread"])
            for b in bars:
                writer.writerow([b.time.isoformat(),b.open,b.high,b.low,b.close,b.spread])
        save_json(out_spec,asdict(spec))
        info=gateway.symbol()
        # Raw broker swap properties preserved separately for deliberate cash conversion.
        save_json(str(out_spec)+".provenance.json",{
            "provider":"MT5 connected demo terminal","broker":gateway.cfg["broker"],
            "symbol":spec.symbol,"timeframe":gateway.cfg["timeframe"],"bars":len(bars),
            "first_bar_utc":bars[0].time.isoformat(),"last_bar_utc":bars[-1].time.isoformat(),
            "swap_mode":info.swap_mode,"swap_long_raw":info.swap_long,"swap_short_raw":info.swap_short,
            "swap_rollover3days":info.swap_rollover3days,
            "cost_note":"Swap values must be verified in account-currency cash per lot; raw broker units may be points or rates"})
        return {"bars":len(bars),"csv":out_csv,"spec":out_spec,"swap_conversion_required":not spec.costs_verified}
    finally:
        gateway.shutdown()


def export_ticks(gateway,out_csv,out_spec,date_from,date_to):
    """Read-only, daily chunks with half-open UTC bounds; preserve tied quote order."""
    import hashlib
    start,end=utc_time(date_from),utc_time(date_to)
    if start>=end or end>datetime.now(timezone.utc):
        raise Refused("Tick export requires a past UTC interval with from < to")
    target=Path(out_csv)
    if target.resolve()==Path(out_spec).resolve():
        raise Refused("Tick CSV and specification paths must differ")
    temporary=target.with_suffix(target.suffix+".tmp")
    gateway.connect()
    try:
        account,_=gateway.identity()
        identity=(account.login,account.server)
        gateway.symbol()
        spec=gateway.spec()
        if spec.profit_currency!=spec.account_currency:
            raise Refused("Tick history needs per-quote historical account conversion; export cannot substitute today's rate")
        target.parent.mkdir(parents=True,exist_ok=True)
        count=0
        previous=None
        chunks=[]
        epoch=datetime(1970,1,1,tzinfo=timezone.utc)
        with temporary.open("w",encoding="utf-8",newline="") as stream:
            writer=csv.writer(stream)
            writer.writerow(["time","bid","ask"])
            cursor=start
            while cursor<end:
                until=min(end,cursor+timedelta(days=1))
                current,_=gateway.identity()
                if (current.login,current.server)!=identity:
                    raise Refused("Account changed during tick export")
                quotes=gateway.api.copy_ticks_range(spec.symbol,cursor,until,gateway.api.COPY_TICKS_INFO)
                if quotes is None:
                    raise Refused("Tick history request failed: "+str(gateway.api.last_error()))
                written=0
                for row in quotes:
                    tick=Tick(epoch+timedelta(milliseconds=int(row["time_msc"])),float(row["bid"]),float(row["ask"]))
                    if not cursor<=tick.time<until:
                        continue  # MT5 bounds may include the shared chunk end; keep it in the next chunk only.
                    if previous is not None and tick.time<previous:
                        raise Refused("Broker tick history is out of order")
                    writer.writerow([tick.time.isoformat(),tick.bid,tick.ask])
                    previous=tick.time
                    count+=1
                    written+=1
                chunks.append({"from":cursor.isoformat(),"to_exclusive":until.isoformat(),"ticks":written})
                cursor=until
        current,_=gateway.identity()
        if (current.login,current.server)!=identity:
            raise Refused("Account changed before export completion")
        if not count:
            raise Refused("No valid historical quotes returned; export is not a usable dataset")
        temporary.replace(target)
        save_json(out_spec,asdict(spec))
        save_json(str(target)+".provenance.json",{
            "synthetic":False,"provider":"MT5 COPY_TICKS_INFO","broker":gateway.cfg["broker"],
            "server":account.server,"symbol":spec.symbol,"requested_from_utc":start.isoformat(),
            "requested_to_exclusive_utc":end.isoformat(),"downloaded_at_utc":datetime.now(timezone.utc).isoformat(),
            "ticks":count,"chunks":chunks,"data_sha256":hashlib.sha256(target.read_bytes()).hexdigest(),
            "equal_timestamps":"retained in broker response order; no sorting or price-based deduplication",
            "coverage_verified":False,"specification_scope":"current terminal metadata, not historical contract reconstruction",
            "empty_chunk_note":"No returned quotes may mean market closure or unavailable history; independent coverage audit required"})
        return {"ticks":count,"csv":str(target),"spec":str(out_spec),"orders_sent":False,"coverage_verified":False}
    finally:
        if temporary.exists():
            temporary.unlink()
        gateway.shutdown()


def verify_model(model,gateway,spec):
    a=model.artifact
    if not a.get("qualified_for_demo"):
        raise Refused("Model has not passed chronological evaluation gates")
    from .qualification import verify_rolling_binding
    try:
        verify_rolling_binding(a,gateway.cfg)
    except ValueError as exc:
        raise Refused(str(exc)) from exc
    if a.get("policy_fingerprint")!=policy_fingerprint(gateway.cfg):
        raise Refused("Strategy/risk policy changed after evaluation; reevaluate")
    if a.get("symbol")!=spec.symbol or a.get("account_currency")!=spec.account_currency or a.get("profit_currency")!=spec.profit_currency:
        raise Refused("Model instrument or currency mismatch")
    evaluated=a["instrument"]
    for key in ("point","tick_size","contract_size","volume_min","volume_step","volume_max","commission_round_turn",
                "slippage","swap_long","swap_short","swap_triple_weekday","swap_rollover_hour_utc"):
        if not math.isclose(getattr(spec,key),evaluated[key],rel_tol=1e-8,abs_tol=1e-10):
            raise Refused("Broker specification/cost changed after evaluation: "+key)
    if not evaluated.get("verified"):
        raise Refused("Model trained with unverified example contract")
    if not evaluated.get("costs_verified") or not spec.costs_verified:
        raise Refused("Costs not fully verified for training/execution")


def account_state(journal,gateway,account,now):
    key=f"{account.server}:{account.login}"
    state=journal.load_state(key)
    day=now.date().isoformat()
    if state is None:
        state={"started_at_utc":now.isoformat(),"day":day,"day_start":account.equity,
               "peak":account.equity,"observed_balance":account.balance,"halt":None,"day_halt":None}
    if state["day"]!=day:
        state.update({"day":day,"day_start":account.equity,"day_halt":None})
    state["peak"]=max(state["peak"],account.equity)
    start=utc_time(state["started_at_utc"])
    deals=gateway.api.history_deals_get(start,now)
    if deals is None:
        raise Refused("Cannot reconcile broker deal history")
    # Deposits/withdrawals after baseline invalidate equity comparisons; halt rather than rebasing silently.
    if any(d.type in (gateway.api.DEAL_TYPE_BALANCE,gateway.api.DEAL_TYPE_CREDIT) and d.time>start.timestamp() for d in deals):
        state["halt"]="Balance operation after risk baseline; explicit new baseline required"
    own=[d for d in deals if d.magic==gateway.cfg["magic"] and d.symbol==gateway.cfg["symbol"]]
    exits=[d for d in own if d.entry in (gateway.api.DEAL_ENTRY_OUT,gateway.api.DEAL_ENTRY_OUT_BY)]
    pnl={}
    for d in own:
        pnl[d.position_id]=pnl.get(d.position_id,0)+d.profit+d.swap+d.commission+d.fee
    consecutive=0
    seen=set()
    today_exits=[d for d in exits if utc_time(d.time).date()==now.date()]
    for d in sorted(today_exits,key=lambda d:d.time_msc,reverse=True):
        if d.position_id in seen:
            continue
        seen.add(d.position_id)
        if pnl[d.position_id]<0:
            consecutive+=1
        else:
            break
    # Consecutive halt persists only for that UTC monitoring day.
    allowed,reason=entry_allowed(account.equity,state["peak"],state["day_start"],gateway.cfg,consecutive)
    if not allowed:
        if reason=="Maximum drawdown halt":
            state["halt"]=reason
        else:
            state["day_halt"]=reason
    journal.save_state(key,state)
    last_exit=max((d.time for d in exits),default=0)
    return key,state,last_exit


def close_owned(gateway,position,journal,account_key,reason,now):
    if position.magic!=gateway.cfg["magic"] or position.symbol!=gateway.cfg["symbol"]:
        raise Refused("Position ownership mismatch")
    tick=gateway.tick()
    info=gateway.symbol()
    side=1 if position.type==gateway.api.POSITION_TYPE_BUY else -1
    request={"action":gateway.api.TRADE_ACTION_DEAL,"symbol":position.symbol,"volume":position.volume,
             "position":position.ticket,"type":gateway.api.ORDER_TYPE_SELL if side==1 else gateway.api.ORDER_TYPE_BUY,
             "price":tick.bid if side==1 else tick.ask,"deviation":gateway.cfg["deviation_points"],
             "magic":gateway.cfg["magic"],"type_filling":gateway.filling(info),"comment":"PA-close"}
    key=f"{account_key}:close:{position.ticket}:{int(now.timestamp())}"
    if not journal.reserve(key,account_key,{"request":request,"reason":reason}):
        raise Refused("Close intent already reserved")
    try:
        result=gateway.send_guarded(request)
    except Exception:
        journal.finish(key,"unknown",{"request":request,"reason":reason})
        raise
    if result is None or result.retcode!=gateway.api.TRADE_RETCODE_DONE:
        journal.finish(key,"unknown",{"request":request,"reason":reason,"retcode":None if result is None else result.retcode})
        raise Refused("Close outcome uncertain; broker reconciliation required")
    journal.finish(key,"closed",{"request":request,"reason":reason,"deal":result.deal,"order":result.order})


def demo_once(gateway,journal,model_path,kill_path="runtime/STOP"):
    account=gateway.guard(orders=True)
    now=datetime.now(timezone.utc)
    key,state,last_exit=account_state(journal,gateway,account,now)
    positions,orders=gateway.exposures()
    owned=[p for p in positions if p.magic==gateway.cfg["magic"] and p.symbol==gateway.cfg["symbol"]]
    killed=Path(kill_path).exists()
    age_limit=TIMEFRAME_SECONDS[gateway.cfg["timeframe"]]*gateway.cfg["max_holding_bars"]
    closed=[]
    for p in owned:
        reason="kill switch" if killed else state["halt"] or state["day_halt"]
        if not reason and (p.sl<=0 or p.tp<=0):
            reason="Protective exits missing"
        if not reason and now.timestamp()-p.time>=age_limit:
            reason="Maximum holding horizon"
        if reason:
            # An unresolved CLOSE intent cannot be retried before reconciliation.
            if any(":close:" in row[0] for row in journal.unresolved(key)):
                raise Refused("Uncertain close exists; reconcile before retry")
            close_owned(gateway,p,journal,key,reason,now)
            closed.append(p.ticket)
    if closed:
        return {"status":"closed_owned_positions","count":len(closed)}
    if killed or state["halt"] or state["day_halt"]:
        return {"status":"halt","reason":"kill switch" if killed else state["halt"] or state["day_halt"]}
    if journal.unresolved(key):
        raise Refused("Unresolved order intent: reconcile broker history before any new entry")
    if positions or orders:
        return {"status":"wait","reason":"Account already has exposure; one position account-wide"}
    if now.timestamp()-last_exit < TIMEFRAME_SECONDS[gateway.cfg["timeframe"]]*gateway.cfg["cooldown_bars"]:
        return {"status":"wait","reason":"Cooldown after broker exit"}
    model=Classifier.load(model_path)
    spec=gateway.spec()
    verify_model(model,gateway,spec)
    basis=getattr(model,"artifact",{}).get("execution_basis","bid_ohlc")
    bars=gateway.bars_from_ticks() if basis=="recorded_bid_ask_ticks" else gateway.bars()
    now=datetime.now(timezone.utc)  # History retrieval may be slow; use current signal age after it completes.
    seconds=TIMEFRAME_SECONDS[gateway.cfg["timeframe"]]
    age=now.timestamp()-bars[-1].time.timestamp()-seconds
    if age<0 or age>gateway.cfg["max_signal_age_seconds"]:
        return {"status":"wait","reason":"Outside fresh closed-bar window"}
    signals=detect(bars[-120:],gateway.cfg,spec.tick_size)
    signal=select(signals,model,gateway.cfg["min_probability"],gateway.cfg["min_expected_r"])
    if signal is None:
        return {"status":"no_signal"}
    tick,info=gateway.tick(),gateway.symbol()
    s=signal.side
    if info.trade_mode!=gateway.api.SYMBOL_TRADE_MODE_FULL:
        raise Refused("Symbol is not in full trading mode")
    entry=tick.ask if s==1 else tick.bid
    c=context(bars[-120:])
    spread=tick.ask-tick.bid
    if spread/c.atr>gateway.cfg["max_spread_atr"]:
        return {"status":"wait","reason":"Spread filter"}
    stop=rounded(signal.stop,info.trade_tick_size,up=s<0)
    target=rounded(signal.target,info.trade_tick_size,up=s<0)
    distance=s*(entry-stop)
    reward=s*(target-entry)
    broker_distance=info.trade_stops_level*info.point
    exit_quote=tick.bid if s==1 else tick.ask
    if min(s*(exit_quote-stop),s*(target-exit_quote))<broker_distance:
        return {"status":"wait","reason":"Broker stop distance"}
    if distance<=0 or reward/distance<gateway.cfg["min_reward_risk"] or distance>gateway.cfg["max_stop_atr"]*c.atr:
        return {"status":"wait","reason":"Entry moved beyond risk/reward envelope"}
    action=gateway.api.ORDER_TYPE_BUY if s==1 else gateway.api.ORDER_TYPE_SELL
    adverse_entry=entry+s*gateway.cfg["deviation_points"]*info.point
    adverse_exit=stop-s*spec.slippage
    loss=gateway.api.order_calc_profit(action,spec.symbol,1.0,adverse_entry,adverse_exit)
    if loss is None or not math.isfinite(loss) or loss>=0:
        raise Refused("Cannot calculate account-currency stop loss")
    budget=account.equity*gateway.cfg["risk_fraction"]
    volume=size_volume(budget,-loss+spec.commission_round_turn,spec)
    if not volume:
        return {"status":"wait","reason":"Minimum lot exceeds risk budget"}
    margin=gateway.api.order_calc_margin(action,spec.symbol,volume,adverse_entry)
    if margin is None or not math.isfinite(margin) or margin<0 or margin>account.margin_free*gateway.cfg["max_margin_fraction"]:
        return {"status":"wait","reason":"Margin budget"}
    comment="PA-"+str(int(signal.time.timestamp()))
    request={"action":gateway.api.TRADE_ACTION_DEAL,"symbol":spec.symbol,"volume":volume,"type":action,
             "price":entry,"sl":stop,"tp":target,"deviation":gateway.cfg["deviation_points"],
             "magic":gateway.cfg["magic"],"comment":comment,"type_filling":gateway.filling(info)}
    intent=f"{key}:{spec.symbol}:{gateway.cfg['timeframe']}:{int(signal.time.timestamp())}"
    payload={"request":request,"signal":{**asdict(signal),"time":signal.time.isoformat()},"risk_budget":budget,
             "created_at_utc":now.isoformat()}
    if not journal.reserve(intent,key,payload):
        return {"status":"wait","reason":"Signal already processed"}
    try:
        # Guard against another actor opening exposure while the plan was calculated.
        fresh_positions,fresh_orders=gateway.exposures()
        fresh=gateway.guard(orders=True)
        if fresh_positions or fresh_orders or fresh.equity<account.equity-.001 or Path(kill_path).exists():
            journal.finish(intent,"cancelled",payload)
            return {"status":"wait","reason":"Account state changed before send"}
        result=gateway.send_guarded(request)
    except Exception:
        journal.finish(intent,"unknown",payload)
        raise
    if result is None or result.retcode!=gateway.api.TRADE_RETCODE_DONE:
        payload["retcode"]=None if result is None else result.retcode
        # Even a broker rejection remains quarantined until explicitly reconciled.
        journal.finish(intent,"unknown",payload)
        raise Refused("Order result uncertain or rejected; reconcile, no blind retry")
    payload.update({"deal":result.deal,"order":result.order,"fill_price":result.price,"fill_volume":result.volume})
    # Leave intent unresolved until exposure and protections are confirmed.
    positions,_=gateway.exposures()
    owned=[p for p in positions if p.magic==gateway.cfg["magic"] and p.symbol==spec.symbol]
    if len(owned)!=1:
        journal.finish(intent,"unknown",payload)
        raise Refused("Fill acknowledged but position state is not confirmed")
    p=owned[0]
    actual_loss=gateway.api.order_calc_profit(action,spec.symbol,p.volume,p.price_open,p.sl) if p.sl>0 else None
    exits_match=math.isclose(p.sl,stop,abs_tol=info.trade_tick_size/2) and math.isclose(p.tp,target,abs_tol=info.trade_tick_size/2)
    if p.sl<=0 or p.tp<=0 or not exits_match or actual_loss is None or p.volume>volume+1e-8 or -actual_loss+p.volume*spec.commission_round_turn>budget+1e-8:
        journal.finish(intent,"protected_exit_required",payload)
        close_owned(gateway,p,journal,key,"Post-fill protection/risk check",datetime.now(timezone.utc))
        return {"status":"closed","reason":"Post-fill risk exceeded or protections missing"}
    journal.finish(intent,"filled",payload)
    return {"status":"demo_filled","setup":signal.setup,"side":s,"volume":p.volume,
            "probability":signal.probability,"stop":p.sl,"target":p.tp,"sources":signal.sources}


def reconcile(gateway,journal):
    account=gateway.guard()
    key=f"{account.server}:{account.login}"
    unresolved=journal.unresolved(key)
    positions,orders=gateway.exposures()
    changes=[]
    for intent,status,text in unresolved:
        payload=json.loads(text)
        request=payload["request"]
        if ":close:" in intent:
            if any(p.ticket==request["position"] for p in positions):
                changes.append({"intent":intent,"status":"still_unresolved","reason":"Position remains; inspect broker execution"})
                continue
            # Absence of exposure alone does not prove why it closed: require matching closing deal.
            now=datetime.now(timezone.utc)
            deals=gateway.api.history_deals_get(now-timedelta(days=30),now)
            if deals is None:
                raise Refused("Deal history unavailable")
            matched=[d for d in deals if d.position_id==request["position"] and d.entry in
                     (gateway.api.DEAL_ENTRY_OUT,gateway.api.DEAL_ENTRY_OUT_BY)]
            if matched:
                journal.finish(intent,"reconciled_closed",payload)
                changes.append({"intent":intent,"status":"reconciled_closed"})
            else:
                changes.append({"intent":intent,"status":"still_unresolved"})
        else:
            now=datetime.now(timezone.utc)
            start=utc_time(payload["created_at_utc"])-timedelta(minutes=5)
            history=gateway.api.history_orders_get(start,now)
            deals=gateway.api.history_deals_get(start,now)
            if history is None or deals is None:
                raise Refused("History unavailable; unresolved state preserved")
            matched=[x for x in [*history,*deals,*orders,*positions] if x.magic==gateway.cfg["magic"] and
                     x.symbol==request["symbol"] and x.comment==request["comment"]]
            if matched:
                journal.finish(intent,"reconciled_observed",payload)
                changes.append({"intent":intent,"status":"reconciled_observed"})
            else:
                # Empty history is not proof of rejection during a broker outage.
                changes.append({"intent":intent,"status":"still_unresolved","reason":"No affirmative broker evidence"})
    return {"changes":changes}
