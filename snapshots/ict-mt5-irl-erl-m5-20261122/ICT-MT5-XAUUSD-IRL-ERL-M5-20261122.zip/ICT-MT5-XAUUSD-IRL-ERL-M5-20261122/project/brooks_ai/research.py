import json
import re
from pathlib import Path


def retrieve(query,path="research/corpus.jsonl",limit=5):
    terms=re.findall(r"[a-zA-Z0-9_]+|[\u4e00-\u9fff]+",query.lower())
    terms=[x for term in terms for x in ([term] if len(term)<4 or term.isascii() else
                                       [term]+[term[i:i+2] for i in range(len(term)-1)])]
    terms=list(dict.fromkeys(terms))
    hits=[]
    with Path(path).open(encoding="utf-8") as f:
        for line in f:
            chunk=json.loads(line)
            text=chunk["text"].lower()
            score=sum((3 if len(t)>2 else 1)*min(3,text.count(t)) for t in terms)
            if score:
                hits.append({**chunk,"score":score})
    hits.sort(key=lambda x:(-x["score"],x["document"],x["pdf_page"],x["offset"]))
    unique=[]
    pages=set()
    for hit in hits:
        key=(hit["document"],hit["pdf_page"])
        if key not in pages:
            unique.append(hit)
            pages.add(key)
        if len(unique)==limit:
            break
    return unique

