import math
from .strategy import SETUPS
from .data import load_json


def load_config(path):
    cfg=load_json(path)
    if not cfg["enabled_setups"] or any(x not in SETUPS for x in cfg["enabled_setups"]):
        raise ValueError("Unknown/empty enabled setups")
    if len(set(cfg["enabled_setups"]))!=len(cfg["enabled_setups"]):
        raise ValueError("Duplicate setup")
    for key in ("risk_fraction","daily_loss_limit","max_drawdown","max_spread_atr","max_margin_fraction"):
        if not isinstance(cfg[key],(int,float)) or not math.isfinite(cfg[key]) or not 0<cfg[key]<1:
            raise ValueError("Invalid "+key)
    if not 0<cfg["risk_fraction"]<cfg["daily_loss_limit"]<=cfg["max_drawdown"]:
        raise ValueError("Risk must be below daily loss limit, which must not exceed max drawdown")
    for key in ("initial_equity","min_reward_risk","max_stop_atr","validation_min_profit_factor"):
        if not isinstance(cfg[key],(int,float)) or not math.isfinite(cfg[key]) or cfg[key]<=0:
            raise ValueError("Invalid "+key)
    for key in ("max_consecutive_losses","max_holding_bars","cooldown_bars","max_tick_age_seconds",
                "max_signal_age_seconds","deviation_points","validation_min_trades"):
        if type(cfg[key]) is not int or cfg[key]<1:
            raise ValueError("Invalid "+key)
    if not 0<=cfg["min_probability"]<=1 or not math.isfinite(cfg["min_expected_r"]):
        raise ValueError("Invalid model threshold")
    hour=cfg["session_open_hour_utc"]
    if hour is not None and (type(hour) is not int or not 0<=hour<=23):
        raise ValueError("Session open must be null or UTC hour 0..23")
    if "opening_reversal" in cfg["enabled_setups"] and hour is None:
        raise ValueError("Opening reversal requires an explicit session definition")
    for key in ("commission_round_turn","swap_long_account_per_lot","swap_short_account_per_lot"):
        value=cfg[key]
        if value is not None and (not isinstance(value,(int,float)) or not math.isfinite(value)):
            raise ValueError("Invalid "+key)
    if cfg["commission_round_turn"] is not None and cfg["commission_round_turn"]<0:
        raise ValueError("Commission must be nonnegative")
    if type(cfg["swap_triple_weekday"]) is not int or not 0<=cfg["swap_triple_weekday"]<=6:
        raise ValueError("Invalid triple swap weekday")
    if type(cfg["swap_rollover_hour_utc"]) is not int or not 0<=cfg["swap_rollover_hour_utc"]<=23:
        raise ValueError("Invalid rollover UTC hour")
    return cfg
