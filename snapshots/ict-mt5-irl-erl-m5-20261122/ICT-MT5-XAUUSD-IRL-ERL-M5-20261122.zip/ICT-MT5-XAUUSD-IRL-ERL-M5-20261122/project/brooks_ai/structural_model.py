"""Research classifier of boundary persistence, never net-profit probability.

Distinct artifact schema prevents its use by the trading Classifier. Future
structural outcomes are labels only; the inputs are the causal 26 features.
"""
import math
import numpy as np
from .strategy import FEATURES
from .types import utc_time

SCHEMA='brooks_structural_hold_v1'


class StructuralClassifier:
    def __init__(self,artifact):
        if artifact.get('schema')!=SCHEMA or artifact.get('features')!=FEATURES:
            raise ValueError('Incompatible structural artifact')
        if artifact.get('target')!='hold_frozen_boundary_for_20_closed_bars':
            raise ValueError('Unknown structural target')
        self.mean=np.asarray(artifact['mean'],dtype=float)
        self.scale=np.asarray(artifact['scale'],dtype=float)
        self.weights=np.asarray(artifact['weights'],dtype=float)
        self.bias=float(artifact['bias'])
        if any(x.shape!=(len(FEATURES),) or not np.all(np.isfinite(x)) for x in
               (self.mean,self.scale,self.weights)) or np.any(self.scale<=0) or not math.isfinite(self.bias):
            raise ValueError('Invalid structural parameters')

    def predict_hold_probability(self,features):
        x=np.asarray(features,dtype=float)
        if x.shape!=self.mean.shape or not np.all(np.isfinite(x)):
            raise ValueError('Invalid structural model inputs')
        z=float(np.clip((x-self.mean)/self.scale,-8,8)@self.weights+self.bias)
        return float(1/(1+np.exp(-np.clip(z,-40,40))))


def fit_structural(samples):
    x=np.asarray([s['features'] for s in samples],dtype=float)
    y=np.asarray([s['label'] for s in samples],dtype=float)
    if x.ndim!=2 or x.shape[1]!=len(FEATURES) or not np.all(np.isfinite(x)) or not np.all(np.isin(y,[0,1])):
        raise ValueError('Finite causal features and binary structural labels required')
    if len(samples)<80 or min(y.sum(),len(y)-y.sum())<15:
        raise ValueError('Need 80 samples and 15 per class')
    mean=x.mean(axis=0);scale=np.maximum(x.std(axis=0),.001)
    normalized=np.clip((x-mean)/scale,-8,8)
    weights=np.zeros(len(FEATURES));bias=float(np.log(y.mean()/(1-y.mean())))
    for _ in range(800):
        p=1/(1+np.exp(-np.clip(normalized@weights+bias,-40,40)))
        error=p-y
        weights-=.03*(normalized.T@error/len(y)+.02*weights)
        bias-=.03*error.mean()
    return dict(schema=SCHEMA,target='hold_frozen_boundary_for_20_closed_bars',features=FEATURES,
                mean=mean.tolist(),scale=scale.tolist(),weights=weights.tolist(),bias=bias,
                training_prior=float(y.mean()),model_type='L2 logistic regression',
                qualified_execution=False,probability_semantics='Uncalibrated probability of all 20 post-activation bid closes staying outside; not profit')


def purge_before_context(samples,next_partition):
    if not next_partition:raise ValueError('Empty next partition')
    boundary=min(utc_time(s['feature_context_start_time']) for s in next_partition)
    retained=[s for s in samples if utc_time(s['target_available_after_label'])<boundary]
    return retained,len(samples)-len(retained)


def evaluate_structural(model,samples,training_prior):
    if not samples or not 0<training_prior<1:raise ValueError('Evaluation samples and finite prior required')
    y=np.asarray([s['label'] for s in samples],dtype=float)
    if not np.all(np.isin(y,[0,1])):raise ValueError('Binary evaluation labels required')
    p=np.asarray([model.predict_hold_probability(s['features']) for s in samples])
    p=np.clip(p,1e-12,1-1e-12)
    pos=p[y==1];neg=p[y==0]
    auc=float(np.mean((pos[:,None]>neg).astype(float)+.5*(pos[:,None]==neg))) if len(pos) and len(neg) else None
    return dict(samples=len(samples),positive_rate=float(y.mean()),mean_predicted_probability=float(p.mean()),
                brier=float(np.mean((p-y)**2)),prior_brier=float(np.mean((training_prior-y)**2)),
                log_loss=float(-np.mean(y*np.log(p)+(1-y)*np.log(1-p))),
                prior_log_loss=float(-np.mean(y*np.log(training_prior)+(1-y)*np.log(1-training_prior))),
                auc=auc)
