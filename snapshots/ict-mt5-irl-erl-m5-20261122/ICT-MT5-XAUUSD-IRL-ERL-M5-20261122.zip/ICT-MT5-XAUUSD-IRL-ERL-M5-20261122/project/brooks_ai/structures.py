"""Point-in-time line objects for research; does not create trading signals.

Wick-swing pairs and translated boundaries are subsets of Trends chapter 13.
The 60/120-bar horizons and tick tolerances are engineering choices. An object
or line crossing does not establish a dominant trend, flag, profitable breakout
or major reversal. This registry is not yet consumed by the trading detector.
"""
import math
from datetime import timedelta
from .strategy import pivots, line_value


def object_price(obj, index):
    return line_value(obj['anchors'], index)+obj['parallel_offset']


def line_objects(bars, tick_size, interval_seconds=900):
    """Confirmed primary lines plus frozen translated opposite boundaries."""
    if (not math.isfinite(tick_size) or tick_size<=0 or
        type(interval_seconds) is not int or interval_seconds<=0):
        raise ValueError('Positive tick and integer interval required')
    r=bars[-120:]
    if len(r)<60:
        return []
    hs,ls=pivots(r)
    objects=[]
    for i in range(59,len(r)):
        for role,points,outside in (('support',ls,-1),('resistance',hs,1)):
            known=[p for p in points if i-59<=p[0]<=i-2]
            if len(known)<2:
                continue
            a,b=known[-2:]
            if b[0]+2!=i:
                continue
            slope=(b[1]-a[1])/(b[0]-a[0])
            kind=('horizontal_swing_line' if abs(b[1]-a[1])<tick_size/2 else
                  'trend_line' if outside*slope<0 else 'trend_channel_line')
            ident=f"line:{role}:{r[a[0]].time.isoformat()}:{r[b[0]].time.isoformat()}"
            atr=sum(max(x.high-x.low,abs(x.high-p.close),abs(x.low-p.close))
                    for p,x in zip(r[i-14:i],r[i-13:i+1]))/14
            primary=dict(object_id=ident,kind=kind,role=role,outside_side=outside,
                         anchors=[a,b],anchor_bar_times=[r[a[0]].time.isoformat(),r[b[0]].time.isoformat()],
                         anchor_confirmation_indices=[a[0]+2,b[0]+2],known_index=i,
                         known_bar_time=r[i].time.isoformat(),
                         available_after_label=(r[i].time+timedelta(seconds=interval_seconds)).isoformat(),
                         available_time_basis='Source-clock label plus bar interval; UTC mapping unverified',
                         known_atr=atr,slope_per_observed_bar=slope,parallel_offset=0.,
                         parent_object_id=None,construction='latest two confirmed wick swings',
                         source=[{'document':'best10','pdf_pages':[10,10]},
                                 {'document':'trends','pdf_pages':[202,211]}],
                         reference_frame_start_bar_time=r[0].time.isoformat(),
                         price_basis='wick extremes; bar-index projection',
                         scope='Research geometry only; no flag or dominant-trend assertion')
            objects.append(primary)
            # Opposite observed extremes between the two anchors are available
            # at line confirmation. Preserve the most enclosing translation.
            offsets=[(j,(r[j].high if role=='support' else r[j].low)-line_value([a,b],j))
                     for j in range(a[0],b[0]+1)]
            at,offset=(max(offsets,key=lambda x:x[1]) if role=='support' else min(offsets,key=lambda x:x[1]))
            if outside*offset>=0 or abs(offset)<tick_size:
                continue
            parallel=dict(primary)
            parallel.update(object_id=ident+':parallel',kind='translated_channel_boundary',
                            role='resistance' if role=='support' else 'support',outside_side=-outside,
                            parallel_offset=offset,parent_object_id=ident,
                            construction='frozen extreme residual between original anchors',
                            offset_anchor_index=at,offset_anchor_bar_time=r[at].time.isoformat())
            # Mark penetrations of the original side rather than silently
            # redrawing a historical line to make its geometry look perfect.
            violations=sum(outside*((r[j].low if role=='support' else r[j].high)-
                                   line_value([a,b],j))>tick_size*1e-7
                           for j in range(a[0],b[0]+1))
            parallel['original_boundary_formation_violations']=violations
            objects.append(parallel)
    return objects


def crossing_records(bars, objects, tick_size, interval_seconds=900):
    """First closed crossing and its observed resolution, without orders."""
    if (not math.isfinite(tick_size) or tick_size<=0 or
        type(interval_seconds) is not int or interval_seconds<=0):
        raise ValueError('Positive tick and integer interval required')
    r=bars[-120:]
    records=[]
    for obj in objects:
        if not r or obj['reference_frame_start_bar_time']!=r[0].time.isoformat():
            raise ValueError('Object index frame differs from price history')
        k=obj['known_index']
        side=obj['outside_side']
        state=dict(object_id=obj['object_id'],kind=obj['kind'],side=side,
                   phase='awaiting_cross',first_cross_index=None,first_cross_bar_time=None,
                   first_cross_atr=None,first_return_inside_index=None,first_return_inside_bar_time=None,
                   first_nonmonotone_index=None,strict_followthrough_failed=False,
                   contiguous_closed_followthrough_bars=0,terminal_bar_time=None,
                   trading_signal=False,confirmed_major_reversal=False)
        for i in range(k,min(len(r),k+60)):
            if i>k and (r[i].time-r[i-1].time).total_seconds()!=interval_seconds:
                state.update(phase='invalidated_by_clock_gap',terminal_bar_time=r[i].time.isoformat())
                break
            distance=side*(r[i].close-object_price(obj,i))
            if state['first_cross_index'] is None:
                atr=sum(max(x.high-x.low,abs(x.high-a.close),abs(x.low-a.close))
                        for a,x in zip(r[i-14:i],r[i-13:i+1]))/14
                if atr>0 and distance>=max(tick_size,.15*atr)-tick_size*1e-7:
                    state.update(phase='cross_observed',first_cross_index=i,
                                 first_cross_bar_time=r[i].time.isoformat(),first_cross_atr=atr)
            elif distance<=tick_size*1e-7:
                state.update(phase='returned_inside',first_return_inside_index=i,
                             first_return_inside_bar_time=r[i].time.isoformat(),terminal_bar_time=r[i].time.isoformat())
                break
            elif side*(r[i].close-r[i-1].close)>=-tick_size*1e-7:
                if not state['strict_followthrough_failed']:
                    state['contiguous_closed_followthrough_bars']+=1
            else:
                # A retreat outside the line breaks strict follow-through,
                # but does not prove a return inside. Keep observing that
                # separate event without rewriting the first crossing.
                if not state['strict_followthrough_failed']:
                    state.update(phase='nonmonotone_followthrough',first_nonmonotone_index=i,
                                 strict_followthrough_failed=True)
        if len(r)-1-k>=60 and state['terminal_bar_time'] is None:
            state.update(phase='expired',terminal_bar_time=r[k+60].time.isoformat())
        records.append(state)
    return records
