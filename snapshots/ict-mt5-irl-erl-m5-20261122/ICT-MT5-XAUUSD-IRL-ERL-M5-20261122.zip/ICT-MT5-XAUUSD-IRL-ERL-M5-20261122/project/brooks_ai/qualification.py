"""Bind rolling evidence to the exact evaluated parameters; no fitting or orders."""
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
from pathlib import Path
from .data import load_json, save_json
from .model import Classifier, digest, fitted_parameters, policy_fingerprint
from .types import utc_time
from .walkforward import performance_gates, plan_folds


def checked_report(report, cfg):
    try:
        return _checked_report(report, cfg)
    except (KeyError, TypeError, AttributeError, IndexError) as exc:
        raise ValueError("Incomplete rolling evaluation report; regenerate it") from exc


def _checked_report(report, cfg):
    """Recompute gates instead of trusting summary flags in a saved report."""
    body = {k: v for k, v in report.items() if k != "integrity"}
    if report.get("integrity") != digest(body):
        raise ValueError("Rolling report integrity mismatch")
    if report.get("schema") != 1 or report.get("kind") != "rolling_research_evaluation":
        raise ValueError("Unsupported rolling evaluation report")
    if report.get("policy_fingerprint") != policy_fingerprint(cfg):
        raise ValueError("Rolling strategy/risk implementation changed; reevaluate")
    if report.get("execution_basis") not in ("bid_ohlc","recorded_bid_ask_ticks"):
        raise ValueError("Unknown or missing rolling execution basis")
    if report["execution_evidence"]["basis"]!=report["execution_basis"]:
        raise ValueError("Rolling execution evidence basis mismatch")
    instrument = report["instrument"]
    if instrument.get("verified") is not True or instrument.get("costs_verified") is not True:
        raise ValueError("Rolling contract and costs must be verified")
    if report["summary"].get("synthetic") is not False:
        raise ValueError("Synthetic or unspecified rolling evidence cannot qualify a model")
    protocol = report["protocol"]
    plans = plan_folds(report["history_bars"], protocol["train_bars"],
                       protocol["validation_bars"], protocol["test_bars"])
    if len(plans) < 3 or len(report["folds"]) != len(plans) or protocol["step_bars"] != protocol["test_bars"]:
        raise ValueError("All planned rolling folds, at least three, are required")
    for number, (fold, plan) in enumerate(zip(report["folds"], plans), 1):
        if fold["fold"] != number or fold["slices"] != plan or fold["status"] != "evaluated":
            raise ValueError("Rolling fold missing, reordered or insufficient")
        for name, (lo, hi) in plan.items():
            audit = fold["label_audit"][name]
            last = audit["latest_label_exit_index"]
            if audit["matured_samples"] <= 0 or last is None or not lo <= last < hi:
                raise ValueError("Rolling labels cross a chronological boundary")
            period = fold["periods"][name]
            if utc_time(period["from"]) > utc_time(period["last_bar"]):
                raise ValueError("Invalid rolling period")
        for left, right in (("train", "validation"), ("validation", "test")):
            if utc_time(fold["periods"][left]["last_bar"]) >= utc_time(fold["periods"][right]["from"]):
                raise ValueError("Rolling periods overlap")
        checks = []
        for name in ("validation", "test"):
            checks.extend(performance_gates({"metrics": fold["metrics"][name]},
                                           fold["probability"][name], cfg).values())
        stress = fold["metrics"]["double_cost_test"]
        checks.extend((stress["net_pnl"] > 0, stress["max_drawdown"] <= cfg["max_drawdown"]))
        if not all(checks):
            raise ValueError("Rolling fold failed measured evaluation gates")
        if report["execution_basis"]=="recorded_bid_ask_ticks":
            for name in ("validation","test","baseline_test","double_cost_test"):
                audit=fold["execution_audit"][name]
                if audit["quote_audit"]["end_of_history_trades"]!=0 or audit["boundary_policy"]["require_mature_horizon"] is not True:
                    raise ValueError("Tick evaluation includes censored trades or lacks full-horizon boundary controls")
    return report["folds"][-1]


def verify_rolling_binding(artifact, cfg):
    """Used at execution time after loading an integrity-checked model artifact."""
    report = artifact.get("rolling_evidence")
    if not isinstance(report, dict):
        raise ValueError("Model lacks bound rolling evaluation evidence")
    try:
        last = checked_report(report, cfg)
        if digest(fitted_parameters(artifact)) != last["fitted_parameters_digest"]:
            raise ValueError("Model parameters differ from the evaluated final rolling fold")
        if artifact["policy_fingerprint"] != report["policy_fingerprint"]:
            raise ValueError("Model policy differs from bound evidence")
        if artifact["data_sha256"] != report["data_sha256"] or artifact["instrument"] != report["instrument"]:
            raise ValueError("Model data or contract differs from bound evidence")
        if artifact["deployment_fold"] != last["fold"]:
            raise ValueError("Deployment fold differs from evaluated model")
        if artifact["execution_basis"]!=report["execution_basis"]:
            raise ValueError("Model execution basis differs from bound evidence")
    except (KeyError, TypeError) as exc:
        raise ValueError("Incomplete rolling model evidence") from exc
    return last


def export_rolling_model(report_path, data_path, spec, cfg, out_path):
    """Export only the final fold's frozen parameters, never retrain on its test."""
    detail_path = Path(report_path).with_suffix(".details.json")
    inputs = (Path(report_path), Path(data_path), detail_path, Path(str(data_path) + ".provenance.json"))
    if Path(out_path).resolve() in {p.resolve() for p in inputs}:
        raise ValueError("Model output must not overwrite research inputs")
    report = load_json(report_path)
    last = checked_report(report, cfg)
    if report["instrument"] != asdict(spec) or report["symbol"] != spec.symbol:
        raise ValueError("Rolling instrument mismatch")
    data_hash = hashlib.sha256(Path(data_path).read_bytes()).hexdigest()
    if data_hash != report["data_sha256"]:
        raise ValueError("Rolling history file changed after evaluation")
    provenance_path = Path(str(data_path) + ".provenance.json")
    if provenance_path.exists() and load_json(provenance_path).get("synthetic"):
        raise ValueError("Synthetic data cannot qualify a model")
    details = load_json(detail_path)
    if digest(details) != report["details_digest"] or details.get("synthetic") is not False:
        raise ValueError("Rolling detail file changed or is synthetic")
    if details.get("execution_basis")!=report["execution_basis"]:
        raise ValueError("Rolling detail execution basis mismatch")
    if len(details["folds"]) != len(report["folds"]):
        raise ValueError("Rolling details omit folds")
    for fold, detail in zip(report["folds"], details["folds"]):
        if detail["fold"] != fold["fold"] or digest(detail["model_parameters"]) != fold["fitted_parameters_digest"]:
            raise ValueError("Rolling parameters do not match evaluated folds")
        for name, detail_name in (("validation", "validation"), ("test", "test"),
                                 ("baseline_test", "baseline_test"), ("double_cost_test", "double_cost_test")):
            if detail[detail_name]["metrics"] != fold["metrics"][name]:
                raise ValueError("Rolling execution details differ from report metrics")
            if report["execution_basis"]=="recorded_bid_ask_ticks":
                observed={"quote_audit":detail[detail_name]["quote_audit"],"boundary_policy":detail[detail_name]["boundary_policy"]}
                if observed!=fold["execution_audit"][name]:
                    raise ValueError("Rolling tick boundary details differ from report evidence")
    artifact = dict(details["folds"][-1]["model_parameters"])
    Classifier(artifact)  # Shape/finiteness validation before saving.
    artifact.update({"trained_at_utc":report["created_at_utc"],
                     "qualified_at_utc":datetime.now(timezone.utc).isoformat(),
                     "symbol":spec.symbol,"account_currency":spec.account_currency,"profit_currency":spec.profit_currency,
                     "instrument":asdict(spec),"policy_fingerprint":report["policy_fingerprint"],"data_sha256":data_hash,
                     "deployment_fold":last["fold"],"rolling_evidence":report,
                     "execution_basis":report["execution_basis"],
                     "period":last["periods"]["train"],"qualified_for_demo":True,
                     "limitations":["Frozen final rolling fit; its validation and test were not used to refit parameters",
                                    "Checksum binding detects inconsistent files, not forged evidence or false provenance",
                                    "Research eligibility for guarded demo only; broker forward validation remains required"]})
    verify_rolling_binding(artifact, cfg)
    artifact["integrity"] = digest(artifact)
    save_json(out_path, artifact)
    return artifact
