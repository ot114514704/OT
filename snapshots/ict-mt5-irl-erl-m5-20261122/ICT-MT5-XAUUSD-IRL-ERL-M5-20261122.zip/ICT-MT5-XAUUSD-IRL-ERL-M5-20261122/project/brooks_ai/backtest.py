from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from .strategy import detect, select, context
from .risk import size_volume, entry_allowed
from .types import Trade


def rollover_cost(entry_time, end_time, side, spec, volume):
    result = 0.0
    day = entry_time.date()
    while day <= end_time.date():
        roll = datetime(day.year,day.month,day.day,spec.swap_rollover_hour_utc,tzinfo=timezone.utc)
        if entry_time < roll <= end_time and day.weekday() < 5:
            multiple = 3 if day.weekday()==spec.swap_triple_weekday else 1
            result += volume*(spec.swap_long if side==1 else spec.swap_short)*multiple
        day += timedelta(days=1)
    return result


def simulate(signal, bars, entry_index, spec, cfg, equity, max_exit_index=None, risk_context=None):
    """Signal uses bars ending at entry_index-1. OHLC uncertainty resolves stop first."""
    first = bars[entry_index]
    intervals={"M1":60,"M5":300,"M15":900,"M30":1800,"H1":3600,"H4":14400,"D1":86400}
    if (first.time-signal.time).total_seconds()!=intervals[cfg["timeframe"]]:
        return None  # Do not carry Friday/missing-history signals across a session gap.
    side = signal.side
    entry = first.open+(first.spread if side==1 else 0)+side*spec.slippage
    distance = side*(entry-signal.stop)
    reward = side*(signal.target-entry)
    atr = context(bars[max(0,entry_index-100):entry_index]).atr
    if distance <= 0 or reward/distance < cfg["min_reward_risk"] or distance > cfg["max_stop_atr"]*atr:
        return None
    if first.spread/atr > cfg["max_spread_atr"]:
        return None
    loss_per_lot = (distance+spec.slippage)*spec.contract_size*first.conversion+spec.commission_round_turn
    volume = size_volume(equity*cfg["risk_fraction"],loss_per_lot,spec)
    if not volume:
        return None
    end = min(len(bars)-1,entry_index+cfg["max_holding_bars"]-1)
    if max_exit_index is not None:
        end = min(end,max_exit_index)
    stop, target = signal.stop, signal.target
    reason, exit_price, ambiguous = "time",None,False
    risk_state=risk_context
    for j in range(entry_index,end+1):
        b = bars[j]
        # Longs close at bid; shorts close at ask. CSV ask path uses bar spread approximation.
        extra = b.spread if side == -1 else 0
        lo, hi, op = b.low+extra,b.high+extra,b.open+extra
        hit_stop = lo <= stop if side==1 else hi >= stop
        hit_target = hi >= target if side==1 else lo <= target
        # A resting exit crossed at the open precedes any later intrabar excursion.
        gap_stop = op <= stop if side==1 else op >= stop
        gap_target = op >= target if side==1 else op <= target
        if gap_stop:
            exit_price=op-side*spec.slippage
            reason="stop"
            break
        if gap_target:
            exit_price=target-side*spec.slippage  # Do not credit favourable price improvement.
            reason="target"
            break
        if hit_stop:
            exit_price = min(stop,op)-spec.slippage if side==1 else max(stop,op)+spec.slippage
            reason, ambiguous = "stop",hit_target
            break
        if hit_target:
            exit_price = target-side*spec.slippage
            reason = "target"
            break
        if risk_state is not None:
            liquidation=b.close+extra-side*spec.slippage
            floating=side*(liquidation-entry)*spec.contract_size*volume*b.conversion-spec.commission_round_turn*volume
            floating+=rollover_cost(first.time,b.time,side,spec,volume)
            marked=equity+floating
            if b.time.date()!=risk_state["day"]:
                risk_state.update({"day":b.time.date(),"day_start":marked})
            risk_state["peak"]=max(risk_state["peak"],marked)
            ok,risk_reason=entry_allowed(marked,risk_state["peak"],risk_state["day_start"],cfg)
            if not ok:
                exit_price,reason=liquidation,risk_reason
                break
    else:
        j = end
        b = bars[j]
        exit_price = b.close+(b.spread if side==-1 else 0)-side*spec.slippage
    pnl = side*(exit_price-entry)*spec.contract_size*volume*bars[j].conversion
    pnl -= spec.commission_round_turn*volume
    pnl += rollover_cost(first.time,bars[j].time,side,spec,volume)
    return Trade(signal.time.isoformat(),first.time.isoformat(),bars[j].time.isoformat(),signal.setup,side,
                 entry,exit_price,stop,target,volume,pnl,volume*loss_per_lot,reason,ambiguous,j,entry_index-1,
                 signal.features,signal.sources)


def metrics(trades, initial, equity_curve):
    pnl = [t.pnl for t in trades]
    gains, losses = sum(max(0,x) for x in pnl),-sum(min(0,x) for x in pnl)
    peak, dd = initial,0.0
    for x in equity_curve:
        peak=max(peak,x)
        dd=max(dd,(peak-x)/peak)
    return {"trades":len(trades),"net_pnl":sum(pnl),"return_fraction":sum(pnl)/initial,
            "win_rate":sum(x>0 for x in pnl)/len(pnl) if pnl else None,
            "profit_factor":gains/losses if losses else None,
            "max_drawdown":dd,"mean_r":sum(t.pnl/t.initial_risk for t in trades)/len(trades) if trades else None,
            "ambiguous_bars":sum(t.ambiguous for t in trades),"ending_equity":initial+sum(pnl)}


def run(bars,spec,cfg,model=None,start=60,end=None):
    end=len(bars)-1 if end is None else end
    equity=cfg["initial_equity"]
    peak,day_start=equity,equity
    day=None
    trades,curve,events=[],[equity],[]
    halted_days=set()
    consecutive=0
    i=max(start,60)
    while i<end:
        b=bars[i]
        if b.time.date()!=day:
            day,day_start=b.time.date(),equity
            consecutive=0
        if day in halted_days:
            i+=1
            continue
        allowed,reason=entry_allowed(equity,peak,day_start,cfg,consecutive)
        if not allowed:
            events.append({"time":b.time.isoformat(),"reason":reason})
            if reason=="Maximum drawdown halt":
                break
            i+=1
            continue
        s=select(detect(bars[max(0,i-119):i+1],cfg,spec.tick_size),model,cfg["min_probability"],cfg["min_expected_r"])
        if s:
            risk_state={"peak":peak,"day":day,"day_start":day_start}
            t=simulate(s,bars,i+1,spec,cfg,equity,max_exit_index=end,risk_context=risk_state)
            if t:
                # Per-bar floating equity, including estimated liquidation costs and swap.
                for j in range(i+1,t.exit_index):
                    z=bars[j]
                    close=z.close+(z.spread if t.side==-1 else 0)-t.side*spec.slippage
                    floating=t.side*(close-t.entry)*spec.contract_size*t.volume*z.conversion-spec.commission_round_turn*t.volume
                    curve.append(equity+floating+rollover_cost(bars[i+1].time,z.time,t.side,spec,t.volume))
                equity+=t.pnl
                peak=max(peak,*curve,equity)
                trades.append(t)
                curve.append(equity)
                consecutive=consecutive+1 if t.pnl<0 else 0
                if risk_state["day"]!=day:
                    day,day_start=risk_state["day"],risk_state["day_start"]
                    consecutive=int(t.pnl<0)
                if t.reason=="Daily loss halt":
                    halted_days.add(bars[t.exit_index].time.date())
                    events.append({"time":t.exit_time,"reason":t.reason})
                if t.reason=="Maximum drawdown halt":
                    events.append({"time":t.exit_time,"reason":t.reason})
                    break
                i=t.exit_index+cfg["cooldown_bars"]
                continue
        i+=1
    return {"metrics":metrics(trades,cfg["initial_equity"],curve),"trades":[asdict(t) for t in trades],
            "risk_events":events,"equity_curve":curve,
            "limitations":["Bid OHLC + constant per-bar spread approximates ask path; ticks needed to resolve intrabar sequence",
                           "Stops first on bars touching both exits; stop gaps and slippage modeled",
                           "Margin, historical contract changes and intra-bar floating-equity stops are not modeled"]}

