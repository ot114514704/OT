"""Brooks-inspired research engine; book descriptions are hypotheses, not trained weights."""
__version__ = "0.1.0"

