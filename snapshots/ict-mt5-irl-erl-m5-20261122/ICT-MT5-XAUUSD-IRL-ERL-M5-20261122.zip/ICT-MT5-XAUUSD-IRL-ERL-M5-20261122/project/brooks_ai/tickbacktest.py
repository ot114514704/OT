"""Research-only quote-path replay; signals remain closed-bar and causal."""
from dataclasses import asdict
from datetime import datetime,timedelta,timezone
from .types import Bar,Trade
from .strategy import context,detect,select
from .risk import size_volume,entry_allowed
from .backtest import metrics,rollover_cost

INTERVALS={"M1":60,"M5":300,"M15":900,"M30":1800,"H1":3600,"H4":14400,"D1":86400}


def aggregate_ticks(ticks,seconds):
    if type(seconds) is not int or seconds<=0 or 86400%seconds:
        raise ValueError("Bar interval must divide a UTC day")
    groups=[]
    start=0
    for i,tick in enumerate(ticks):
        if i and tick.time<ticks[i-1].time:
            raise ValueError("Ticks must be in original chronological order")
        bucket=int(tick.time.timestamp())//seconds*seconds
        if i and bucket!=int(ticks[start].time.timestamp())//seconds*seconds:
            groups.append((start,i))
            start=i
    if ticks:
        groups.append((start,len(ticks)))
    # Neither edge bucket is known to be fully observed from tick timestamps alone.
    groups=groups[1:-1]
    bars=[]
    for lo,hi in groups:
        segment=ticks[lo:hi]
        first,last=segment[0],segment[-1]
        timestamp=int(first.time.timestamp())//seconds*seconds
        bars.append(Bar(datetime.fromtimestamp(timestamp,timezone.utc),first.bid,max(t.bid for t in segment),
                        min(t.bid for t in segment),last.bid,last.ask-last.bid,last.conversion))
    return bars,groups


def simulate_ticks(signal,bars,ticks,spans,entry_index,spec,cfg,equity,end=None,risk_context=None):
    seconds=INTERVALS[cfg["timeframe"]]
    first=ticks[spans[entry_index][0]]
    decision=signal.time+timedelta(seconds=seconds)
    if bars[entry_index].time!=decision or not 0<=(first.time-decision).total_seconds()<=cfg["max_signal_age_seconds"]:
        return None
    side=signal.side
    entry=(first.ask if side==1 else first.bid)+side*spec.slippage
    distance=side*(entry-signal.stop)
    reward=side*(signal.target-entry)
    prior=context(bars[max(0,entry_index-100):entry_index])
    if prior is None or distance<=0 or reward/distance<cfg["min_reward_risk"] or distance>cfg["max_stop_atr"]*prior.atr:
        return None
    if (first.ask-first.bid)/prior.atr>cfg["max_spread_atr"]:
        return None
    loss_per_lot=(distance+spec.slippage)*spec.contract_size*first.conversion+spec.commission_round_turn
    volume=size_volume(equity*cfg["risk_fraction"],loss_per_lot,spec)
    if not volume:
        return None
    end=len(bars)-1 if end is None else min(end,len(bars)-1)
    if end<entry_index:
        raise ValueError("Tick replay end precedes entry")
    deadline=first.time+timedelta(seconds=seconds*cfg["max_holding_bars"])
    marks=[]
    j=entry_index
    reason="end_of_history"
    for k in range(spans[entry_index][0],spans[end][1]):
        quote=ticks[k]
        while j<end and k>=spans[j][1]:
            j+=1
        price=quote.bid if side==1 else quote.ask
        liquidation=price-side*spec.slippage
        quote_reason=None
        if side*(price-signal.stop)<=0:
            quote_reason="stop"  # Observed adverse quote, including jumps; no stop interpolation.
        elif side*(price-signal.target)>=0:
            liquidation=signal.target-side*spec.slippage  # Do not credit favourable improvement.
            quote_reason="target"
        elif quote.time>=deadline:
            quote_reason="time"  # First executable quote at/after wall-clock holding deadline.
        pnl=side*(liquidation-entry)*spec.contract_size*volume*quote.conversion-spec.commission_round_turn*volume
        pnl+=rollover_cost(first.time,quote.time,side,spec,volume)
        marked=equity+pnl
        marks.append(marked)
        if risk_context is not None:
            if quote.time.date()!=risk_context["day"]:
                risk_context.update(day=quote.time.date(),day_start=marked)
            risk_context["peak"]=max(risk_context["peak"],marked)
        if quote_reason is None and risk_context is not None:
            allowed,risk_reason=entry_allowed(marked,risk_context["peak"],risk_context["day_start"],cfg)
            if not allowed:
                quote_reason=risk_reason
        if quote_reason is None:
            continue
        reason=quote_reason
        break
    quote=ticks[k]
    pnl=side*(liquidation-entry)*spec.contract_size*volume*quote.conversion-spec.commission_round_turn*volume
    pnl+=rollover_cost(first.time,quote.time,side,spec,volume)
    marks[-1]=equity+pnl
    trade=Trade(signal.time.isoformat(),first.time.isoformat(),quote.time.isoformat(),signal.setup,side,
                entry,liquidation,signal.stop,signal.target,volume,pnl,volume*loss_per_lot,reason,False,j,
                entry_index-1,signal.features,signal.sources)
    return {"trade":trade,"equity_marks":marks,"entry_tick_index":spans[entry_index][0],"exit_tick_index":k}


def run_ticks(ticks,spec,cfg,model=None,start=60,end=None,require_mature_horizon=False):
    seconds=INTERVALS.get(cfg["timeframe"])
    if seconds is None:
        raise ValueError("Unsupported tick aggregation timeframe")
    bars,spans=aggregate_ticks(ticks,seconds)
    if len(bars)<80:
        raise ValueError("At least 80 internal, fully bounded observed tick-bar buckets required")
    end=len(bars)-1 if end is None else min(end,len(bars)-1)
    equity=cfg["initial_equity"]
    peak,day_start=equity,equity
    day=None
    consecutive=0
    trades,curve,events,traces=[],[equity],[],[]
    halted_days=set()
    late_entries=0
    i=max(start,60)
    while i<end:
        b=bars[i]
        if b.time.date()!=day:
            day,day_start=b.time.date(),equity
            consecutive=0
        if day in halted_days:
            i+=1
            continue
        allowed,reason=entry_allowed(equity,peak,day_start,cfg,consecutive)
        if not allowed:
            events.append({"time":b.time.isoformat(),"reason":reason})
            if reason=="Maximum drawdown halt":
                break
            i+=1
            continue
        selected=select(detect(bars[max(0,i-119):i+1],cfg,spec.tick_size),model,cfg["min_probability"],cfg["min_expected_r"])
        if selected:
            first=ticks[spans[i+1][0]]
            if require_mature_horizon and first.time+timedelta(seconds=seconds*cfg["max_holding_bars"])>bars[end].time:
                late_entries+=1
                i+=1
                continue  # Known study cutoff, independent of whether a late trade would win or lose.
            state={"peak":peak,"day":day,"day_start":day_start}
            result=simulate_ticks(selected,bars,ticks,spans,i+1,spec,cfg,equity,end,state)
            if result:
                t=result["trade"]
                curve.extend(result["equity_marks"])
                equity+=t.pnl
                peak=max(peak,state["peak"],equity)
                trades.append(t)
                traces.append({"entry_tick_index":result["entry_tick_index"],"exit_tick_index":result["exit_tick_index"]})
                consecutive=consecutive+1 if t.pnl<0 else 0
                if state["day"]!=day:
                    day,day_start=state["day"],state["day_start"]
                    consecutive=int(t.pnl<0)
                if t.reason in ("Daily loss halt","Maximum drawdown halt"):
                    events.append({"time":t.exit_time,"reason":t.reason})
                    if t.reason=="Maximum drawdown halt":
                        break
                    halted_days.add(day)
                i=t.exit_index+cfg["cooldown_bars"]
                continue
        i+=1
    equal,max_gap=0,None
    for a,b in zip(ticks,ticks[1:]):
        gap=(b.time-a.time).total_seconds()
        equal+=int(gap==0)
        max_gap=gap if max_gap is None else max(max_gap,gap)
    return {"kind":"tick_path_research_backtest","metrics":metrics(trades,cfg["initial_equity"],curve),
            "trades":[asdict(t) for t in trades],"tick_traces":traces,"equity_curve":curve,"risk_events":events,
            "quote_audit":{"ticks":len(ticks),"internal_bar_buckets":len(bars),"edge_buckets_discarded":2,
                           "equal_timestamp_pairs":equal,"maximum_quote_gap_seconds":max_gap,
                           "missing_bar_buckets":sum(max(0,int((b.time-a.time).total_seconds()/seconds)-1) for a,b in zip(bars,bars[1:])),
                           "end_of_history_trades":sum(t.reason=="end_of_history" for t in trades)},
            "boundary_policy":{"require_mature_horizon":require_mature_horizon,"late_entries_skipped":late_entries},
            "execution_authorization":False,
            "limitations":["Recorded quote order resolves observed exit sequence, not broker latency, liquidity or execution queues",
                           "Missing quotes and market closures cannot be distinguished without independent coverage evidence",
                           "Signals use last-quote spread of closed bars; entries and exits use their actual recorded bid/ask",
                           "Edge buckets discarded; interior buckets still may contain missing quotes",
                           "Historical margin, liquidation and contract changes remain unmodelled",
                           "Standalone replay does not qualify a deployment model; tick training/rolling commands bind separate evidence"]}
