"""Small supervised classifier, trained only on historical candidate outcomes.

Book text supplies the feature specification, not statistical training labels.
Final chronological holdout is never used for scaling, fitting or threshold tuning.
"""
from dataclasses import asdict
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
from .strategy import FEATURES, detect
from .backtest import simulate, run
from .data import save_json, load_json

FIT_KEYS = ("schema", "features", "mean", "scale", "weights", "bias", "training_prior", "weights_r", "bias_r")


def fitted_parameters(artifact):
    return {key: artifact[key] for key in FIT_KEYS}


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()


def policy_fingerprint(cfg):
    keys = ["timeframe","enabled_setups","session_open_hour_utc","initial_equity","risk_fraction","daily_loss_limit",
            "max_drawdown","max_consecutive_losses","max_stop_atr","max_spread_atr","min_reward_risk",
            "max_holding_bars","cooldown_bars","min_probability","min_expected_r",
            "validation_min_trades","validation_min_profit_factor","max_signal_age_seconds"]
    root=Path(__file__).parent
    implementation={name:hashlib.sha256((root/name).read_bytes()).hexdigest()
                    for name in ("strategy.py","risk.py","backtest.py","types.py","model.py","data.py",
                                 "walkforward.py","qualification.py","tickbacktest.py","tickmodel.py","mt5.py")}
    return digest({"configuration":{k:cfg[k] for k in keys},"implementation":implementation})


class Classifier:
    def __init__(self, artifact):
        if artifact.get("features") != FEATURES or artifact.get("schema") != 1:
            raise ValueError("Incompatible feature schema")
        self.artifact=artifact
        self.mean=np.array(artifact["mean"],dtype=float)
        self.scale=np.array(artifact["scale"],dtype=float)
        self.weights=np.array(artifact["weights"],dtype=float)
        self.bias=float(artifact["bias"])
        self.weights_r=np.array(artifact["weights_r"],dtype=float)
        self.bias_r=float(artifact["bias_r"])
        if not all(x.shape==(len(FEATURES),) for x in (self.mean,self.scale,self.weights,self.weights_r)):
            raise ValueError("Invalid model shape")
        if not all(np.all(np.isfinite(x)) for x in (self.mean,self.scale,self.weights,self.weights_r)) or not np.isfinite(self.bias) or not np.isfinite(self.bias_r) or np.any(self.scale<=0):
            raise ValueError("Invalid model parameters")

    @classmethod
    def load(cls,path):
        artifact=load_json(path)
        claimed=artifact.pop("integrity",None)
        if claimed!=digest(artifact):
            raise ValueError("Model artifact integrity mismatch")
        return cls(artifact)

    def predict(self,features):
        x=np.array(features,dtype=float)
        if x.shape!=self.mean.shape or not np.all(np.isfinite(x)):
            raise ValueError("Invalid model input")
        z=float(np.dot(np.clip((x-self.mean)/self.scale,-8,8),self.weights)+self.bias)
        return float(1/(1+np.exp(-np.clip(z,-40,40))))

    def predict_r(self,features):
        x=np.array(features,dtype=float)
        if x.shape!=self.mean.shape or not np.all(np.isfinite(x)):
            raise ValueError("Invalid model input")
        return float(np.dot(np.clip((x-self.mean)/self.scale,-8,8),self.weights_r)+self.bias_r)


def fit(samples):
    x=np.array([s["features"] for s in samples],dtype=float)
    y=np.array([s["label"] for s in samples],dtype=float)
    if x.ndim!=2 or x.shape[1]!=len(FEATURES) or not np.all(np.isfinite(x)):
        raise ValueError("Training inputs do not match the current finite feature schema")
    if len(samples)<80 or min(y.sum(),len(y)-y.sum())<15:
        raise ValueError("Training needs >=80 matured candidates and >=15 outcomes of each class")
    mean,scale=x.mean(axis=0),x.std(axis=0)
    scale=np.maximum(scale,.001)
    x=np.clip((x-mean)/scale,-8,8)
    w=np.zeros(x.shape[1])
    bias=float(np.log(y.mean()/(1-y.mean())))
    for _ in range(800):
        p=1/(1+np.exp(-np.clip(x@w+bias,-40,40)))
        error=p-y
        w-=.03*(x.T@error/len(y)+.02*w)
        bias-=.03*error.mean()
    net_r=np.array([s["net_r"] for s in samples],dtype=float)
    design=np.column_stack([x,np.ones(len(x))])
    penalty=np.eye(design.shape[1])*.1*len(x)
    penalty[-1,-1]=0
    coefficients=np.linalg.solve(design.T@design+penalty,design.T@net_r)
    return {"schema":1,"features":FEATURES,"mean":mean.tolist(),"scale":scale.tolist(),
            "weights":w.tolist(),"bias":bias,"training_prior":float(y.mean()),
            "weights_r":coefficients[:-1].tolist(),"bias_r":float(coefficients[-1])}


def collect(bars,spec,cfg):
    samples=[]
    last_exit={}
    # Do not train labels artificially truncated by the end of the supplied history.
    for i in range(60,len(bars)-cfg["max_holding_bars"]-1):
        for signal in detect(bars[max(0,i-119):i+1],cfg,spec.tick_size):
            if i<=last_exit.get(signal.setup,-1):
                continue
            trade=simulate(signal,bars,i+1,spec,cfg,cfg["initial_equity"])
            if trade:
                samples.append({"signal_index":i,"exit_index":trade.exit_index,
                                "features":signal.features,"label":int(trade.pnl>0),
                                "net_r":trade.pnl/trade.initial_risk,"setup":trade.setup})
                last_exit[signal.setup]=trade.exit_index
    return samples


def chronological_samples(samples,start,end):
    """A slice is [start,end); every fitted/evaluated outcome must finish inside it."""
    if type(start) is not int or type(end) is not int or start<0 or end<=start:
        raise ValueError("Invalid chronological sample slice")
    return [s for s in samples if start<=s["signal_index"]<=s["exit_index"]<end]


def evaluate(model,samples,prior):
    if not samples:
        raise ValueError("No matured candidates in chronological evaluation slice")
    y=np.array([s["label"] for s in samples])
    p=np.array([model.predict(s["features"]) for s in samples])
    return {"samples":len(samples),"brier":float(np.mean((p-y)**2)),
            "prior_brier":float(np.mean((prior-y)**2)),
            "positive_rate":float(y.mean()),"mean_predicted_probability":float(p.mean()),
            "probability_semantics":"Probability of positive net outcome within max holding horizon; uncalibrated baseline"}


def train(bars,spec,cfg,data_path,out_path,execution=None):
    metadata_path=Path(str(data_path)+".provenance.json")
    if metadata_path.exists() and load_json(metadata_path).get("synthetic"):
        raise ValueError("Synthetic engineering fixtures cannot qualify a trading model")
    n=len(bars)
    if n<1000:
        raise ValueError("At least 1000 real historical bars required for training; more are usually needed")
    a,b=int(n*.6),int(n*.8)
    collect_fn=execution.collect if execution is not None else collect
    run_fn=execution.run if execution is not None else run
    samples=collect_fn(bars,spec,cfg)
    # Purge any target interval that crosses a slice boundary. Indicators remain causal.
    train_samples=chronological_samples(samples,0,a)
    validation=chronological_samples(samples,a,b)
    holdout=chronological_samples(samples,b,n)
    artifact=fit(train_samples)
    model=Classifier(artifact)
    validation_prob=evaluate(model,validation,artifact["training_prior"])
    holdout_prob=evaluate(model,holdout,artifact["training_prior"])
    validation_bt=run_fn(bars,spec,cfg,model,start=a,end=b-1)
    holdout_bt=run_fn(bars,spec,cfg,model,start=b,end=n-1)
    baseline=run_fn(bars,spec,cfg,start=b,end=n-1)
    gates={}
    for name,result,prob in (("validation",validation_bt,validation_prob),("holdout",holdout_bt,holdout_prob)):
        m=result["metrics"]
        gates[name]={"minimum_trades":m["trades"]>=cfg["validation_min_trades"],
                     "positive_net_pnl":m["net_pnl"]>0,
                     "profit_factor":m["profit_factor"] is not None and m["profit_factor"]>=cfg["validation_min_profit_factor"],
                     "drawdown":m["max_drawdown"]<=cfg["max_drawdown"],
                     "probability_improves_prior":prob["brier"]<prob["prior_brier"]}
    stress_spec=asdict(spec)
    stress_spec["commission_round_turn"]*=2
    stress_spec["slippage"]*=2
    from .types import Instrument, Bar
    stress_bars=[Bar(z.time,z.open,z.high,z.low,z.close,z.spread*2,z.conversion) for z in bars]
    stress=execution.stress(spec,cfg,model,b,n-1) if execution is not None else run(stress_bars,Instrument(**stress_spec),cfg,model,start=b,end=n-1)
    gates["stress"]={"positive_net_pnl":stress["metrics"]["net_pnl"]>0,
                     "drawdown":stress["metrics"]["max_drawdown"]<=cfg["max_drawdown"]}
    gates["provenance"]={"broker_contract_verified":spec.verified,"costs_verified":spec.costs_verified}
    qualified=all(v for group in gates.values() for v in group.values())
    artifact.update({"trained_at_utc":datetime.now(timezone.utc).isoformat(),"symbol":spec.symbol,
                     "account_currency":spec.account_currency,"profit_currency":spec.profit_currency,
                     "data_sha256":hashlib.sha256(Path(data_path).read_bytes()).hexdigest(),
                     "execution_basis":execution.basis if execution is not None else "bid_ohlc",
                     "execution_evidence":execution.evidence() if execution is not None else {"basis":"bid_ohlc"},
                     "policy_fingerprint":policy_fingerprint(cfg),"instrument":asdict(spec),
                     "period":{"from":bars[0].time.isoformat(),"to":bars[-1].time.isoformat()},
                     "splits":{"train_end":bars[a-1].time.isoformat(),"validation_end":bars[b-1].time.isoformat(),
                               "holdout_from":bars[b].time.isoformat()},
                     "sample_counts":{"train":len(train_samples),"validation":len(validation),"holdout":len(holdout)},
                     "evaluation":{"validation":validation_prob,"holdout":holdout_prob,
                                   "validation_backtest":validation_bt["metrics"],"holdout_backtest":holdout_bt["metrics"],
                                   "baseline_holdout":baseline["metrics"],"double_cost_stress":stress["metrics"]},
                     "gates":gates,"single_holdout_gates_pass":qualified,"qualified_for_demo":False,
                     "limitations":["Small logistic baseline, not a deep neural network",
                                    "Overlapping samples across setup families can remain correlated",
                                    "A one-dataset chronological holdout is not a substitute for broker demo forward testing",
                                    "Research artifact only; use qualify-rolling to export the exact final evaluated rolling model"]})
    artifact["integrity"]=digest(artifact)
    save_json(out_path,artifact)
    save_json(str(Path(out_path).with_suffix(".holdout.json")),holdout_bt)
    return artifact

