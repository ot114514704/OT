"""Recorded quote execution for candidate labels and fixed rolling evaluation."""
from dataclasses import replace
from datetime import timedelta
from .strategy import detect
from .tickbacktest import aggregate_ticks,simulate_ticks,run_ticks,INTERVALS


class TickExecution:
    basis="recorded_bid_ask_ticks"

    def __init__(self,ticks,cfg):
        self.ticks=ticks
        self.timeframe=cfg["timeframe"]
        if self.timeframe not in INTERVALS:
            raise ValueError("Unsupported tick model timeframe")
        self.seconds=INTERVALS[self.timeframe]
        self.bars,self.spans=aggregate_ticks(ticks,self.seconds)
        if len(self.bars)<80:
            raise ValueError("Tick model needs at least 80 internal observed bar buckets")
        self.collection_audit={}

    def check(self,bars,cfg):
        if bars is not self.bars or cfg["timeframe"]!=self.timeframe:
            raise ValueError("Tick labels and evaluation must share the same aggregation and timeframe")

    def collect(self,bars,spec,cfg):
        self.check(bars,cfg)
        samples=[]
        last_exit={}
        audit={"late_horizon_candidates":0,"censored_outcomes_rejected":0,"matured_candidates":0}
        for i in range(60,len(bars)-1):
            first=self.ticks[self.spans[i+1][0]]
            horizon_fits=first.time+timedelta(seconds=self.seconds*cfg["max_holding_bars"])<=bars[-1].time
            for signal in detect(bars[max(0,i-119):i+1],cfg,spec.tick_size):
                if i<=last_exit.get(signal.setup,-1):
                    continue
                if not horizon_fits:
                    audit["late_horizon_candidates"]+=1
                    continue
                result=simulate_ticks(signal,bars,self.ticks,self.spans,i+1,spec,cfg,cfg["initial_equity"])
                if result is None:
                    continue
                trade=result["trade"]
                if trade.reason=="end_of_history":
                    audit["censored_outcomes_rejected"]+=1
                    continue
                samples.append({"signal_index":i,"exit_index":trade.exit_index,"features":signal.features,
                                "label":int(trade.pnl>0),"net_r":trade.pnl/trade.initial_risk,"setup":trade.setup,
                                "entry_tick_index":result["entry_tick_index"],"exit_tick_index":result["exit_tick_index"],
                                "entry_time":trade.entry_time,"exit_time":trade.exit_time,"exit_reason":trade.reason})
                last_exit[signal.setup]=trade.exit_index
        audit["matured_candidates"]=len(samples)
        self.collection_audit=audit
        return samples

    def run(self,bars,spec,cfg,model=None,start=60,end=None):
        self.check(bars,cfg)
        return run_ticks(self.ticks,spec,cfg,model,start,end,require_mature_horizon=True)

    def stress(self,spec,cfg,model,start,end):
        if cfg["timeframe"]!=self.timeframe:
            raise ValueError("Tick stress timeframe mismatch")
        stressed=[replace(t,ask=t.bid+2*(t.ask-t.bid)) for t in self.ticks]
        stress_spec=replace(spec,commission_round_turn=2*spec.commission_round_turn,slippage=2*spec.slippage)
        return run_ticks(stressed,stress_spec,cfg,model,start,end,require_mature_horizon=True)

    def evidence(self):
        return {"basis":self.basis,"ticks":len(self.ticks),"aggregated_bars":len(self.bars),
                "edge_buckets_discarded":2,"collection_audit":dict(self.collection_audit),
                "label_semantics":"Net quote-path outcome at stop/target or first quote at the wall-clock deadline",
                "boundary_policy":"Labels with insufficient full horizon rejected before seeing outcome; crossing slice labels purged; evaluation skips entries whose full horizon cannot fit inside the predeclared segment",
                "coverage":"Internal buckets and quotes may be missing; recorded order is not proof of complete history"}
