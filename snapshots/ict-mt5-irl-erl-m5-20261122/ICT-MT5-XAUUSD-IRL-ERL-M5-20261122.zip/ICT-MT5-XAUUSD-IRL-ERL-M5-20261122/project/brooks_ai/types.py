from dataclasses import dataclass, field
from datetime import datetime, timezone
import math


def utc_time(value):
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, timezone.utc)
    result = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise ValueError("Time must include a timezone; UTC is recommended")
    return result.astimezone(timezone.utc)


@dataclass(frozen=True)
class Bar:
    time: datetime
    open: float
    high: float
    low: float
    close: float
    spread: float
    conversion: float = 1.0

    def __post_init__(self):
        vals = (self.open, self.high, self.low, self.close, self.spread, self.conversion)
        if not all(math.isfinite(x) for x in vals):
            raise ValueError("Non-finite quote")
        if min(vals[:4]) <= 0 or self.spread < 0 or self.conversion <= 0:
            raise ValueError("Invalid price, spread or account conversion")
        if self.low > min(self.open, self.close) or self.high < max(self.open, self.close):
            raise ValueError("Inconsistent OHLC")
        if self.time.tzinfo is None:
            raise ValueError("Bar time must include timezone")


@dataclass(frozen=True)
class Tick:
    time: datetime
    bid: float
    ask: float
    conversion: float = 1.0

    def __post_init__(self):
        if self.time.tzinfo is None or not all(math.isfinite(x) for x in (self.bid,self.ask,self.conversion)):
            raise ValueError("Invalid tick timestamp or non-finite quote")
        if self.bid<=0 or self.ask<self.bid or self.conversion<=0:
            raise ValueError("Invalid bid/ask or account conversion")


@dataclass(frozen=True)
class Instrument:
    symbol: str
    point: float
    tick_size: float
    contract_size: float
    volume_min: float
    volume_step: float
    volume_max: float
    account_currency: str = "USD"
    profit_currency: str = "USD"
    commission_round_turn: float = 0.0
    slippage: float = 0.0
    swap_long: float = 0.0
    swap_short: float = 0.0
    swap_triple_weekday: int = 2
    swap_rollover_hour_utc: int = 22
    verified: bool = False
    costs_verified: bool = False

    def __post_init__(self):
        nums = (self.point, self.tick_size, self.contract_size, self.volume_min,
                self.volume_step, self.volume_max)
        if not all(math.isfinite(x) and x > 0 for x in nums):
            raise ValueError("Invalid instrument specification")
        if self.volume_max < self.volume_min:
            raise ValueError("Invalid volume limits")
        if not all(math.isfinite(x) for x in (self.commission_round_turn, self.slippage,
                                               self.swap_long, self.swap_short)):
            raise ValueError("Invalid costs")
        if self.commission_round_turn < 0 or self.slippage < 0:
            raise ValueError("Costs must be nonnegative")
        if not 0 <= self.swap_triple_weekday <= 6 or not 0 <= self.swap_rollover_hour_utc <= 23:
            raise ValueError("Invalid rollover settings")


@dataclass
class Signal:
    time: datetime
    side: int
    setup: str
    stop: float
    target: float
    reference: float
    features: list[float]
    reasons: list[str]
    sources: list[dict] = field(default_factory=list)
    probability: float | None = None
    pattern: dict = field(default_factory=dict)


@dataclass
class Trade:
    signal_time: str
    entry_time: str
    exit_time: str
    setup: str
    side: int
    entry: float
    exit: float
    stop: float
    target: float
    volume: float
    pnl: float
    initial_risk: float
    reason: str
    ambiguous: bool
    exit_index: int
    sample_index: int
    features: list[float]
    sources: list[dict]

