"""Causal, explicit engineering approximations of the ten book frameworks.

No centered indicator is exposed before its confirmation bar. No assertion of
the author's empirical probabilities is used in decisions.
"""
from dataclasses import dataclass
import math
from .types import Signal

SETUPS = ["major_reversal", "final_flag", "breakout", "h2_l2", "wedge",
          "channel", "measured_move", "range_reversal", "opening_reversal", "magnet"]
PRESSURE_FEATURES=["side_body_pressure","body_overlap","side_ema_gap_run",
                   "side_ema_hold_fraction","side_micro_gap_rate","pressure_coverage"]
FEATURES = ["side_slope", "efficiency", "overlap", "side_body", "close_strength",
            "range_location", "risk_atr", "reward_risk", "spread_atr", "micro_run"] + PRESSURE_FEATURES + SETUPS
SOURCE_MAP = {
    "major_reversal": [("best10", 2, 6), ("reversals", 47, 71)],
    "final_flag": [("best10", 7, 9), ("reversals", 135, 157)],
    "breakout": [("best10", 10, 10), ("ranges", 25, 27), ("trends", 105, 110), ("trends", 296, 305)],
    "h2_l2": [("best10", 11, 15), ("trends", 188, 189), ("ranges", 177, 214)],
    "wedge": [("best10", 16, 20), ("reversals", 107, 129)],
    "channel": [("best10", 21, 24), ("trends", 220, 246)],
    "measured_move": [("best10", 25, 27), ("ranges", 98, 114)],
    "range_reversal": [("best10", 28, 32), ("ranges", 233, 266)],
    "opening_reversal": [("best10", 33, 36), ("reversals", 287, 302)],
    # Pages 42-44 introduce third-party appendix opinions, not this framework.
    "magnet": [("best10", 37, 41), ("ranges", 88, 98)],
}


@dataclass
class Context:
    atr: float
    ema: float
    slope: float
    efficiency: float
    overlap: float
    low: float
    high: float
    regime: str
    micro_run: int


def ema20_series(history):
    """Causal EMA20 seeded at the first available close; no future backfill."""
    ema=history[0].close
    result=[]
    for b in history:
        ema+=(2/21)*(b.close-ema)
        result.append(ema)
    return result


def context(bars):
    if len(bars) < 60:
        return None
    means=ema20_series(bars[-60:])
    ema,before=means[-1],means[-11]
    recent = bars[-20:]
    atr = sum(max(b.high - b.low, abs(b.high - a.close), abs(b.low - a.close))
              for a, b in zip(bars[-15:-1], bars[-14:])) / 14
    if atr <= 0:
        return None
    path = sum(abs(b.close - a.close) for a, b in zip(recent, recent[1:]))
    efficiency = abs(recent[-1].close - recent[0].close) / max(path, 1e-12)
    overlap = sum(max(0, min(a.high, b.high) - max(a.low, b.low)) /
                  max(min(a.high - a.low, b.high - b.low), 1e-12)
                  for a, b in zip(recent, recent[1:])) / 19
    slope = (ema - before) / atr
    regime = "range" if efficiency < .28 and overlap > .45 else "transition"
    if efficiency > .36 and abs(slope) > .55:
        regime = "bull" if slope > 0 else "bear"
    side = 1 if slope > 0 else -1
    run = 0
    for a, b in reversed(list(zip(bars[-11:-1], bars[-10:]))):
        if (b.low >= a.low if side == 1 else b.high <= a.high):
            run += 1
        else:
            break
    return Context(atr, ema, slope, efficiency, overlap,
                   min(b.low for b in bars[-21:-1]), max(b.high for b in bars[-21:-1]), regime, run)


def pivots(bars, width=2):
    """Only return swings whose right-hand confirming bars already closed."""
    highs, lows = [], []
    for i in range(width, len(bars) - width):
        window = bars[i-width:i+width+1]
        if all(bars[i].high > b.high for j, b in enumerate(window) if j != width):
            highs.append((i, bars[i].high))
        if all(bars[i].low < b.low for j, b in enumerate(window) if j != width):
            lows.append((i, bars[i].low))
    return highs, lows


def signal_bar(b, side):
    span = max(b.high - b.low, 1e-12)
    body = side * (b.close - b.open) / span
    location = (b.close - b.low) / span if side == 1 else (b.high - b.close) / span
    return body > .25 and location >= .7


def trend_pressure(bars,side,tick_size,interval_seconds):
    """Closed-bar strength inputs, not probabilities or mandatory entry gates.

    EMA20 is seeded at the first of sixty available bars; the first forty are
    warmup. Only the final twenty, ending at the latest closed bar, are scored.
    Clock gaps reset the scored tail conservatively; complete source coverage
    cannot be inferred from regular timestamps. All scales are engineering.
    """
    if len(bars)<60 or side not in (1,-1) or not math.isfinite(tick_size) or tick_size<=0 or type(interval_seconds) is not int or interval_seconds<=0:
        raise ValueError("Invalid pressure history, side, tick or interval")
    history=bars[-60:]
    means=ema20_series(history)
    start=40
    for i in range(59,40,-1):
        if (history[i].time-history[i-1].time).total_seconds()!=interval_seconds:
            start=i
            break
    recent=history[start:]
    recent_means=means[start:]
    tolerance=tick_size*1e-7
    body_pressure=sum(side*(b.close-b.open)/max(b.high-b.low,tick_size) for b in recent)/20
    bodies=[(min(b.open,b.close),max(b.open,b.close)) for b in recent]
    overlap=sum(max(0,min(a[1],b[1])-max(a[0],b[0]))/
                max(min(a[1]-a[0],b[1]-b[0]),tick_size)
                for a,b in zip(bodies,bodies[1:]))/max(len(bodies)-1,1) if len(bodies)>1 else 1.
    last,mean=recent[-1],recent_means[-1]
    gap_side=1 if last.low>mean+tolerance else -1 if last.high<mean-tolerance else 0
    gap_run=0
    if gap_side:
        for b,mean in reversed(list(zip(recent,recent_means))):
            held=b.low>mean+tolerance if gap_side==1 else b.high<mean-tolerance
            if not held: break
            gap_run+=1
    close_hold=sum(side*(b.close-mean)>tolerance for b,mean in zip(recent,recent_means))/20
    micro_gaps=0
    for before,middle,after in zip(recent,recent[1:],recent[2:]):
        gap=after.low-before.high if side==1 else before.low-after.high
        if gap>=-tolerance and signal_bar(middle,side): micro_gaps+=1
    return {"side_body_pressure":body_pressure,"body_overlap":overlap,
            "side_ema_gap_run":side*gap_side*gap_run/20,"side_ema_hold_fraction":close_hold,
            "side_micro_gap_rate":micro_gaps/18,"pressure_coverage":len(recent)/20}


def line_value(points, index):
    (a, x), (b, y) = points[-2:]
    return y + (y-x) / (b-a) * (index-b)


def major_reversal_episodes(bars, tick_size, interval_seconds=900):
    """Replay bounded, frozen line episodes using only confirmed observations.

    A line is born when its second pivot becomes known. Its lifetime is sixty
    bars from that observation, preceded by sixty bars for anchor context, so
    the latest event is reconstructible from a 120-bar prefix. These horizons,
    ATR distances and five-close invalidation are engineering definitions.
    Related lines can be distinct episodes; they are not independent trades.
    """
    if (not math.isfinite(tick_size) or tick_size <= 0 or
        type(interval_seconds) is not int or interval_seconds <= 0):
        raise ValueError('Positive tick size and integer interval required')
    r=bars[-120:]
    if len(r)<60:
        return []
    hs,ls=pivots(r)
    # Pivots computed once are gated by their two-right-bar availability below.
    tr=[0.]+[max(b.high-b.low,abs(b.high-a.close),abs(b.low-a.close)) for a,b in zip(r,r[1:])]
    totals=[0.]
    for value in tr: totals.append(totals[-1]+value)
    states=[]
    tolerance=tick_size*1e-7
    stamp=lambda i:r[i].time.isoformat() if i is not None else None
    for i in range(59,len(r)):
        atr=(totals[i+1]-totals[i-13])/14
        if atr<=0:
            continue
        for old_side,points,extremes in ((1,ls,hs),(-1,hs,ls)):
            known=[p for p in points if i-59<=p[0]<=i-2]
            if len(known)<2:
                continue
            p1,p2=known[-2:]
            # No retroactive invention of an older line at the left boundary.
            if p2[0]+2!=i or old_side*(p2[1]-p1[1])<=0:
                continue
            available=[e for e in extremes if i-59<=e[0]<=i-2]
            if len(available)<2:
                continue
            states.append(dict(old_side=old_side,side=-old_side,anchors=[p1,p2],
                anchor_confirmation_indices=[p1[0]+2,p2[0]+2],line_known_index=i,
                line_known_bar_time=stamp(i),first_break_index=None,first_break_bar_time=None,
                old_extreme=None,old_extreme_confirmation_index=None,old_extreme_available_index=None,retest=None,retest_kind=None,
                retest_confirmation_index=None,retest_bar_time=None,activation_index=None,
                activation_bar_time=None,invalidated_index=None,invalidated_bar_time=None,
                max_consecutive_closes_beyond_old_extreme=0,consecutive_closes=0,
                phase='awaiting_line_break',confirmed_new_trend=False,atr=None,
                protective_low=None,protective_high=None,
                episode_id=f"mtr:{old_side}:{stamp(p1[0])}:{stamp(p2[0])}",
                window_start=len(bars)-len(r),
                stage_time_semantics='Bar-open labels; usable only after the named bars close',
                scope='Frozen confirmed line; 60-bar lifetime from line availability; related lines are dependent; dominant trend and later new-trend confirmation unvalidated'))
        for state in states:
            if state['phase'] in ('second_reversal_candidate','invalidated_by_trend_resumption',
                                   'invalidated_by_clock_gap','expired'):
                continue
            if i-state['line_known_index']>=60:
                state['phase']='expired'
                state['invalidated_index']=i
                state['invalidated_bar_time']=stamp(i)
                continue
            if i>state['line_known_index'] and (r[i].time-r[i-1].time).total_seconds()!=interval_seconds:
                state['phase']='invalidated_by_clock_gap'
                state['invalidated_index']=i
                state['invalidated_bar_time']=stamp(i)
                continue
            old_side=state['old_side'];side=-old_side
            extremes=hs if old_side==1 else ls
            if state['first_break_index'] is None:
                distance=old_side*(r[i].close-line_value(state['anchors'],i))
                if distance>=-max(tick_size,.15*atr)+tolerance:
                    continue
                # The pre-break price extreme is already observable, even if
                # two right-hand bars have not yet confirmed it as a pivot.
                # Never substitute an older confirmed but less extreme price.
                observed=[(j,r[j].high if old_side==1 else r[j].low)
                          for j in range(state['anchors'][0][0],i)]
                extreme=max(observed,key=lambda e:(old_side*e[1],e[0]))
                confirmed=any(e==extreme and e[0]+2<=i for e in extremes)
                state.update(first_break_index=i,first_break_bar_time=stamp(i),
                             old_extreme=extreme,old_extreme_confirmation_index=extreme[0]+2 if confirmed else None,
                             old_extreme_available_index=i-1,
                             atr=atr,phase='line_break_observed',
                             protective_low=min(r[i].low,extreme[1]),
                             protective_high=max(r[i].high,extreme[1]))
                continue
            state['protective_low']=min(state['protective_low'],r[i].low)
            state['protective_high']=max(state['protective_high'],r[i].high)
            beyond=old_side*(r[i].close-state['old_extreme'][1])>=tick_size-tolerance
            state['consecutive_closes']=state['consecutive_closes']+1 if beyond else 0
            state['max_consecutive_closes_beyond_old_extreme']=max(
                state['max_consecutive_closes_beyond_old_extreme'],state['consecutive_closes'])
            if state['consecutive_closes']>=5:
                state.update(phase='invalidated_by_trend_resumption',invalidated_index=i,
                             invalidated_bar_time=stamp(i))
                continue
            if state['retest'] is None:
                newly_known=[e for e in extremes if e[0]+2==i and e[0]>state['first_break_index']
                             and abs(e[1]-state['old_extreme'][1])<1.1*state['atr']]
                if newly_known:
                    test=newly_known[-1];difference=test[1]-state['old_extreme'][1]
                    kind=('double_top' if old_side==1 else 'double_bottom') if abs(difference)<tick_size/2 else (
                        ('higher_high' if difference>0 else 'lower_high') if old_side==1 else
                        ('higher_low' if difference>0 else 'lower_low'))
                    state.update(retest=test,retest_confirmation_index=i,retest_bar_time=stamp(test[0]),
                                 retest_kind=kind,phase='retest_confirmed')
            resumed=r[i].close<r[i-1].low if side==-1 else r[i].close>r[i-1].high
            if state['retest'] is not None and resumed and signal_bar(r[i],side):
                state.update(activation_index=i,activation_bar_time=stamp(i),phase='second_reversal_candidate')
    return states


def major_reversal_patterns(bars, tick_size, interval_seconds=900):
    """Latest diagnostics and first activation, at most one per direction."""
    states=major_reversal_episodes(bars,tick_size,interval_seconds)
    r=bars[-120:]
    stamp=lambda i:r[i].time.isoformat() if i is not None else None
    result=[]
    last=len(r)-1
    for side in (1,-1):
        live=[s for s in states if s['side']==side and last-s['line_known_index']<60]
        if not live: continue
        # Same-bar overlapping lines yield one candidate per direction. All
        # qualified episodes are consumed, including ones later rejected by risk.
        fresh=[s for s in live if s['activation_index']==last]
        chosen=dict(max(fresh or live,key=lambda s:s['line_known_index']))
        chosen['first_activation_index']=chosen['activation_index']
        chosen['first_activation_bar_time']=chosen['activation_bar_time']
        chosen['activation_index']=last if chosen['activation_index']==last else None
        chosen['activation_bar_time']=stamp(chosen['activation_index'])
        chosen['related_episode_ids']=[s['episode_id'] for s in fresh]
        chosen.pop('consecutive_closes')
        result.append(chosen)
    return result


def breakout_events(bars,tick_size,interval_seconds):
    """First qualified closed follow-through of a horizontal breakout episode.

    The original twenty-bar boundary and breakout-time ATR remain frozen.
    A leg cannot emit repeated events merely by extending to new highs/lows.
    A close back inside, or a new wholly outside two-sided twenty-bar base,
    can re-arm it. This subset does not identify every kind of book breakout.
    """
    if not math.isfinite(tick_size) or tick_size<=0 or type(interval_seconds) is not int or interval_seconds<=0:
        raise ValueError("Invalid breakout tick size or interval")
    active={1:None,-1:None}
    events=[]
    tolerance=tick_size*1e-7
    for i in range(20,len(bars)):
        b,prev=bars[i],bars[i-1]
        base=bars[i-20:i]
        high,low=max(x.high for x in base),min(x.low for x in base)
        atr=sum(max(x.high-x.low,abs(x.high-a.close),abs(x.low-a.close))
                for a,x in zip(bars[i-14:i],bars[i-13:i+1]))/14
        if atr<=0:
            continue
        path=sum(abs(x.close-a.close) for a,x in zip(base,base[1:]))
        efficiency=abs(base[-1].close-base[0].close)/max(path,1e-12)
        overlap=sum(max(0,min(a.high,x.high)-max(a.low,x.low))/
                    max(min(a.high-a.low,x.high-x.low),1e-12)
                    for a,x in zip(base,base[1:]))/19
        for side in (1,-1):
            state=active[side]
            if state is not None:
                held=side*(b.close-state["level"])>tolerance
                new_base=(i-state["index"]>=20 and efficiency<.28 and overlap>.45 and
                          (low>state["level"]+tolerance if side==1 else high<state["level"]-tolerance))
                if not held or new_base:
                    active[side]=state=None
                else:
                    age=i-state["index"]
                    contiguous=(b.time-prev.time).total_seconds()==interval_seconds
                    continued=side*(b.close-b.open)>0 and side*(b.close-prev.close)>=-tolerance
                    if not contiguous or not continued:
                        state["failed_followthrough"]=True
                    if (not state["emitted"] and not state["failed_followthrough"] and 1<=age<=3 and
                        side*(b.close-prev.close)>=tick_size-tolerance and signal_bar(b,side)):
                        state["emitted"]=True
                        if i==len(bars)-1:
                            j=state["index"]
                            observed=bars[j:i+1]
                            before=bars[j-1]
                            first_after=bars[j+1]
                            gap=(first_after.low-before.high if side==1 else before.low-first_after.high)
                            bodies=[(min(x.open,x.close),max(x.open,x.close)) for x in observed]
                            body_overlap=sum(max(0,min(a[1],x[1])-max(a[0],x[0]))/
                                             max(min(a[1]-a[0],x[1]-x[0]),tick_size)
                                             for a,x in zip(bodies,bodies[1:]))/(len(bodies)-1)
                            events.append({"side":side,"formation_type":"horizontal_breakout_followthrough",
                                           "boundary":state["level"],"base_high":state["high"],"base_low":state["low"],
                                           "base_start_index":j-20,"base_end_index":j-1,
                                           "base_start_time":bars[j-20].time.isoformat(),"base_end_time":before.time.isoformat(),
                                           "breakout_index":j,"breakout_time":bars[j].time.isoformat(),
                                           "activation_index":i,"activation_time":b.time.isoformat(),"followthrough_bars":age,
                                           "breakout_atr":state["atr"],"breakout_close_distance_atr":state["distance_atr"],
                                           "breakout_close_distance_ticks":side*(bars[j].close-state["level"])/tick_size,
                                           "micro_gap_present":gap>=-tolerance,"micro_gap_ticks":gap/tick_size,
                                           "body_overlap":body_overlap,"base_efficiency":state["efficiency"],"base_overlap":state["overlap"],
                                           "protective_low":min(x.low for x in observed),"protective_high":max(x.high for x in observed),
                                           "scope":"closed horizontal extreme subset; next-bar market entry; left history may be censored"})
                    continue
            level=high if side==1 else low
            distance=side*(b.close-level)
            if (distance>=max(tick_size,.10*atr)-tolerance and side*(prev.close-level)<=tolerance and signal_bar(b,side)):
                active[side]={"index":i,"level":level,"high":high,"low":low,"atr":atr,
                              "distance_atr":distance/atr,"efficiency":efficiency,"overlap":overlap,
                              "emitted":False,"failed_followthrough":False}
    return events


def second_entry_event(bars,side,tick_size):
    """Return only a NEW second resumption attempt on the latest closed bar.

    A new trend extreme ends the active pullback. Contiguous extensions count
    as one attempt; a paused/counter move must re-arm the next attempt. This is
    a strict bar-count approximation, not recognition of all ABC/H4 variants.
    Indices refer to the supplied (causal, possibly left-censored) history.
    """
    if side not in (1,-1) or not math.isfinite(tick_size) or tick_size<=0:
        raise ValueError("Invalid second-entry direction or tick size")
    if len(bars)<4:
        return None
    def extreme(bar):
        return bar.high if side==1 else -bar.low
    anchor=extreme(bars[0])
    anchor_index=0
    start=None
    attempts=0
    armed=False
    first_attempt=None
    tolerance=tick_size*1e-7
    for i in range(1,len(bars)):
        before,current=extreme(bars[i-1]),extreme(bars[i])
        new_extreme=current-anchor>=tick_size-tolerance
        event=None
        if start is None:
            if new_extreme:
                anchor,anchor_index=current,i
            elif current<=before+tolerance:
                start=i
                attempts=0
                armed=True
                first_attempt=None
        else:
            if current<=before+tolerance:
                armed=True
            elif armed and current-before>=tick_size-tolerance:
                attempts+=1
                armed=False
                if attempts==1:
                    first_attempt=i
                elif attempts==2 and i==len(bars)-1:
                    active=bars[start:i+1]
                    event={"ordinal":2,"side":side,"trigger_index":i,"signal_index":i-1,
                           "pullback_start_index":start,"trend_extreme_index":anchor_index,
                           "trend_extreme":anchor if side==1 else -anchor,
                           "trend_extreme_time":bars[anchor_index].time.isoformat(),
                           "pullback_start_time":bars[start].time.isoformat(),
                           "first_attempt_time":bars[first_attempt].time.isoformat(),
                           "signal_bar_time":bars[i-1].time.isoformat(),
                           "first_attempt_index":first_attempt,"pullback_low":min(x.low for x in active),
                           "pullback_high":max(x.high for x in active),
                           "trigger_level":bars[i-1].high+tick_size if side==1 else bars[i-1].low-tick_size,
                           "counter_scope":"strict bar-count; confirmed history only"}
            if new_extreme:
                anchor,anchor_index=current,i
                start=None
                attempts=0
                armed=False
                first_attempt=None
        if event is not None:
            return event
    return None


def wedge_events(bars,atr,tick_size):
    """Confirmed swing subset of three-push flags and second-entry reversals.

    Pushes need intervening confirmed counter-swings, not just three wicks.
    Thresholds are engineering choices, not probabilities claimed by a book.
    Confirmation/close-based execution intentionally lags intrabar entries.
    """
    if not math.isfinite(atr) or atr<=0 or not math.isfinite(tick_size) or tick_size<=0:
        raise ValueError("Invalid wedge ATR or tick size")
    if len(bars)<60:
        return []
    offset=max(0,len(bars)-60)
    hs,ls=pivots(bars[offset:])
    hs=[(i+offset,p) for i,p in hs]
    ls=[(i+offset,p) for i,p in ls]
    n=len(bars)-1
    current=context(bars)
    events=[]
    depth=max(tick_size,.25*atr)
    for push_side,pushes,counters in ((1,hs,ls),(-1,ls,hs)):
        side=-push_side
        for end in range(len(pushes)-1,max(1,len(pushes)-5),-1):
            tri=pushes[end-2:end+1]
            if len(tri)!=3 or n-tri[-1][0]>20:
                continue
            valleys=[]
            for left,right in zip(tri,tri[1:]):
                between=[p for p in counters if left[0]<p[0]<right[0]]
                if not between:
                    break
                valley=min(between,key=lambda p:push_side*p[1])
                if min(push_side*(left[1]-valley[1]),push_side*(right[1]-valley[1]))<depth:
                    break
                valleys.append(valley)
            if len(valleys)!=2:
                continue
            third_index,third_price=tri[-1]
            original=context(bars[:tri[0][0]+1])
            original_side=1 if original and original.regime=="bull" else -1 if original and original.regime=="bear" else 0
            current_side=1 if current and current.regime=="bull" else -1 if current and current.regime=="bear" else 0
            flag=original_side==side and current_side!=push_side
            range_entry=original is not None and original.regime=="range" and current is not None and current.regime=="range"
            trigger_index=third_index
            first_break=None
            retest=None
            route="trend_pullback" if flag else "range_reversal" if range_entry else "countertrend_second_entry"
            if not (flag or range_entry):
                # Do not fade three pushes alone: require break, counter leg and a confirmed retest.
                retests=[p for p in pushes if third_index<p[0]<=n-2]
                eligible=[]
                extreme=max(push_side*p for _,p in tri)
                for test in retests:
                    reactions=[p for p in counters if third_index<p[0]<test[0]]
                    if not reactions or push_side*test[1]>extreme+.5*atr:
                        continue
                    reaction=min(reactions,key=lambda p:push_side*p[1])
                    if push_side*(test[1]-reaction[1])<depth:
                        continue
                    breaks=[i for i in range(third_index+1,test[0])
                            if push_side*(bars[i].close-line_value(valleys,i))<-.15*atr
                            and push_side*(third_price-bars[i].close)>=.5*atr]
                    if breaks:
                        eligible.append((test,breaks[0]))
                if not eligible:
                    continue
                retest,first_break=eligible[-1]
                trigger_index=retest[0]
                if n-trigger_index>7:
                    continue
            elif n-third_index>7:
                continue
            level=bars[trigger_index].low-tick_size if side==-1 else bars[trigger_index].high+tick_size
            confirmed_now=n==trigger_index+2
            crossed_now=side*(bars[-2].close-level)<=0 and side*(bars[-1].close-level)>0
            if side*(bars[-1].close-level)<-tick_size*1e-7 or not (confirmed_now or crossed_now):
                continue
            active=bars[tri[0][0]:]
            extreme=max(x.high for x in active) if side==-1 else min(x.low for x in active)
            base=valleys[0][1]  # First pullback defines the source's initial structure target.
            pushes_trace=[{"index":i,"time":bars[i].time.isoformat(),"price":p,"confirmed_index":i+2,
                           "confirmed_time":bars[i+2].time.isoformat()} for i,p in tri]
            counter_trace=[{"index":i,"time":bars[i].time.isoformat(),"price":p} for i,p in valleys]
            first_slope=push_side*(tri[1][1]-tri[0][1])/(tri[1][0]-tri[0][0])
            last_slope=push_side*(tri[2][1]-tri[1][1])/(tri[2][0]-tri[1][0])
            events.append({"side":side,"formation_type":route,"pushes":pushes_trace,
                           "counter_swings":counter_trace,"third_push_new_extreme":push_side*(third_price-tri[1][1])>0,
                           "second_push_new_extreme":push_side*(tri[1][1]-tri[0][1])>0,
                           "accelerating":last_slope>first_slope,"prior_regime":original.regime if original else "unavailable",
                           "current_regime":current.regime if current else "unavailable",
                           "initial_break_index":first_break,"initial_break_time":bars[first_break].time.isoformat() if first_break is not None else None,
                           "retest_index":retest[0] if retest else None,"retest_time":bars[retest[0]].time.isoformat() if retest else None,
                           "trigger_level":level,"protective_extreme":extreme,"first_structure_target":base,
                           "measured_extension_target":base+side*abs(extreme-base),
                           "scope":"confirmed swing subset; engineering depth and break thresholds"})
            break  # One currently activated structure per direction.
    return events


def range_reversal_events(bars, tick_size, interval_seconds):
    """Causal second counter-attempt at a previously observed range edge.

    Sixty prior closed bars define the broader two-sided background; that
    boundary and ATR freeze on contact. A first close through the preceding
    bar's counter-side extreme, later directional retreat near the contact
    extreme, then a second close through a preceding-bar extreme are distinct
    stages. No intrabar stop fill is inferred. Numerical cutoffs, expiry and
    invalidation are engineering choices, not the author's probabilities.
    """
    if not math.isfinite(tick_size) or tick_size <= 0 or type(interval_seconds) is not int or interval_seconds <= 0:
        raise ValueError("Invalid range-event tick or interval")
    states = {1: None, -1: None}
    events = []
    contiguous_start = 0
    tolerance = tick_size*1e-7
    for i in range(1, len(bars)):
        b, prev = bars[i], bars[i-1]
        if (b.time-prev.time).total_seconds() != interval_seconds:
            states = {1: None, -1: None}
            contiguous_start = i
            continue
        if i-contiguous_start < 60:
            continue
        background = None
        for side in (1, -1):
            state = states[side]
            if state is not None:
                low, high, atr = state['range_low'], state['range_high'], state['frozen_atr']
                mid = (low+high)/2
                # A completed escape or reaching the centre ends this edge visit.
                if (i-state['contact_index'] > 30 or
                    b.close < low-.5*atr or b.close > high+.5*atr or
                    side*(b.close-mid) >= -tolerance):
                    states[side] = None
                    continue  # Never rebase on the invalidating bar.
                state['protective_low'] = min(state['protective_low'], b.low)
                state['protective_high'] = max(state['protective_high'], b.high)
                if state['emitted']:
                    continue
            else:
                if background is None:
                    prior = bars[i-60:i]
                    low = min(x.low for x in prior)
                    high = max(x.high for x in prior)
                    atr = sum(max(y.high-y.low,abs(y.high-x.close),abs(y.low-x.close))
                              for x,y in zip(prior[-15:-1],prior[-14:]))/14
                    path = sum(abs(y.close-x.close) for x,y in zip(prior,prior[1:]))
                    efficiency = abs(prior[-1].close-prior[0].close)/max(path,tick_size)
                    overlap = sum(max(0,min(x.high,y.high)-max(x.low,y.low))/
                                  max(min(x.high-x.low,y.high-y.low),tick_size)
                                  for x,y in zip(prior,prior[1:]))/59
                    width = high-low
                    two_sided = (any(x.close <= low+width/3 for x in prior) and
                                 any(x.close >= high-width/3 for x in prior))
                    background = (low,high,atr,efficiency,overlap,two_sided)
                low,high,atr,efficiency,overlap,two_sided = background
                width = high-low
                edge = low+width/3 if side==1 else high-width/3
                touched = b.low <= edge if side==1 else b.high >= edge
                edge_close = side*(b.close-edge) <= tolerance
                if not (atr > 0 and width >= 2*atr and efficiency < .28 and overlap > .45 and
                        two_sided and touched and edge_close and low-.5*atr <= b.close <= high+.5*atr):
                    continue
                state = {'side':side,'range_low':low,'range_high':high,'frozen_atr':atr,
                         'base_start_index':i-60,'base_end_index':i-1,
                         'base_efficiency':efficiency,'base_wick_overlap':overlap,
                         'contact_index':i,'contact_extreme':b.low if side==1 else b.high,
                         'protective_low':b.low,'protective_high':b.high,
                         'first_attempt_index':None,'retest_index':None,'emitted':False}
                states[side] = state
                continue  # Same-bar contact and first break chronology is unknown.
            level = prev.high+tick_size if side==1 else prev.low-tick_size
            crossed = side*(b.close-level) >= -tolerance
            if state['first_attempt_index'] is None:
                if crossed:
                    state['first_attempt_index'] = i
                    state['first_trigger_level'] = level
                    state['contact_extreme'] = (state['protective_low'] if side==1 else state['protective_high'])
                continue
            if state['retest_index'] is None:
                extreme = b.low if side==1 else b.high
                returned = side*(extreme-state['contact_extreme']) <= .5*atr
                retreat = side*(b.close-prev.close) <= -tick_size+tolerance
                if returned and retreat:
                    state['retest_index'] = i
                continue  # Retest and second trigger require different closed bars.
            edge = low+(high-low)/3 if side==1 else high-(high-low)/3
            if crossed and low <= b.close <= high and side*(b.close-edge) <= tolerance:
                state['emitted'] = True  # This visit never turns extensions into more entries.
                if i == len(bars)-1:
                    event = dict(state)
                    event.update(activation_index=i,trigger_level=level,signal_index=i-1,
                                 first_structure_target=high-.1*(high-low) if side==1 else low+.1*(high-low),
                                 scope='Frozen 60-bar background; closed-bar second-entry subset; no higher-timeframe feed')
                    for name in ('base_start','base_end','contact','first_attempt','retest','signal','activation'):
                        event[name+'_time'] = bars[event[name+'_index']].time.isoformat()
                    events.append(event)
    return events


def detect(bars, cfg, point):
    c = context(bars)
    if c is None:
        return []
    b, prev = bars[-1], bars[-2]
    recent = bars[-60:]
    hs, ls = pivots(recent)
    candidates = []
    buffer = max(point, c.atr * .08)
    atr = c.atr
    width = c.high - c.low
    trend_side = 1 if c.slope >= 0 else -1
    intervals={"M1":60,"M5":300,"M15":900,"M30":1800,"H1":3600,"H4":14400,"D1":86400}
    pressure_cache={}

    def add(name, side, stop, target, reasons, pattern=None):
        if name not in cfg["enabled_setups"] or not signal_bar(b, side):
            return
        ref = b.close + (b.spread if side == 1 else 0)
        risk = side * (ref - stop)
        reward = side * (target - ref)
        if risk < .4 * atr or risk > cfg["max_stop_atr"] * atr or reward <= 0:
            return
        rr = reward / risk
        if rr < cfg["min_reward_risk"]:
            return
        body = (b.close-b.open) / max(b.high-b.low, point)
        close_strength = (b.close-b.low) / max(b.high-b.low, point)
        if side < 0:
            close_strength = 1 - close_strength
        features = [side*c.slope, c.efficiency, c.overlap, side*body, close_strength,
                    (b.close-c.low) / max(width, atr), risk/atr, rr, b.spread/atr, c.micro_run/10]
        if side not in pressure_cache:
            pressure_cache[side]=trend_pressure(bars,side,point,intervals[cfg["timeframe"]])
        features += [pressure_cache[side][key] for key in PRESSURE_FEATURES]
        features += [float(name == item) for item in SETUPS]
        sources = [{"document": doc, "pdf_pages": [start, end]} for doc, start, end in SOURCE_MAP[name]]
        for doc,start,end in (("trends",296,305),("ranges",25,40)):
            source={"document":doc,"pdf_pages":[start,end]}
            if source not in sources: sources.append(source)
        candidates.append(Signal(b.time, side, name, stop, target, ref, features, reasons, sources,
                                 pattern=pattern or {}))

    for event in breakout_events(bars,point,intervals[cfg["timeframe"]]) if "breakout" in cfg["enabled_setups"] else []:
        side=event["side"]
        stop=event["protective_low"]-buffer if side==1 else event["protective_high"]+buffer+b.spread
        risk=side*((b.close+(b.spread if side==1 else 0))-stop)
        add("breakout",side,stop,b.close+side*max(2*risk,event["base_high"]-event["base_low"]),
            ["Frozen pre-breakout horizontal boundary","First qualified directional follow-through",
             "Body overlap and micro-gap retained as strength diagnostics"],event)

    # H2/L2: count within an active pullback, reset on resumed trend extremes.
    if c.regime in ("bull", "bear"):
        s = trend_side
        event=second_entry_event(bars,s,point)
        near_ema=event is not None and (event["pullback_low"]<=c.ema+.4*atr if s==1 else event["pullback_high"]>=c.ema-.4*atr)
        # Next-bar market execution is deliberately later than the book's intrabar stop order.
        close_confirmed=event is not None and s*(b.close-event["trigger_level"])>=-point*1e-7
        if event is not None and close_confirmed and near_ema:
            stop = event["pullback_low"]-buffer if s == 1 else event["pullback_high"]+buffer+b.spread
            risk = s*((b.close+(b.spread if s == 1 else 0))-stop)
            add("h2_l2", s, stop, b.close+s*2*risk,
                ["Trend context", "Second attempt within the same active pullback", "Close confirms trigger"],event)

    # Candidate stages and original-trend resumption invalidation share chart logic.
    n = len(recent)-1
    for pattern in major_reversal_patterns(bars,point,intervals[cfg['timeframe']]) if 'major_reversal' in cfg['enabled_setups'] else []:
        if pattern['activation_index'] is None:
            continue
        old_extreme=pattern['old_extreme'][1]
        test_price=pattern['retest'][1]
        side=pattern['side']
        reversal_buffer=max(point,pattern['atr']*.08)
        stop = pattern['protective_high']+reversal_buffer+b.spread if side == -1 else pattern['protective_low']-reversal_buffer
        risk = side*((b.close+(b.spread if side == 1 else 0))-stop)
        add("major_reversal", side, stop, b.close+side*2*risk,
            ["Confirmed swing trend line broken", "Extreme retest confirmed", "Second reversal candidate; new trend not confirmed"],pattern)

    for event in wedge_events(bars,atr,point):
        side=event["side"]
        stop=event["protective_extreme"]+buffer+b.spread if side==-1 else event["protective_extreme"]-buffer
        add("wedge",side,stop,event["first_structure_target"],
            ["Three pushes with confirmed intervening counter-swings",event["formation_type"],
             "Closed-bar activation after causal confirmation"],event)

    for event in range_reversal_events(bars,point,intervals[cfg['timeframe']]) if 'range_reversal' in cfg['enabled_setups'] else []:
        side = event['side']
        stop = event['protective_low']-buffer if side==1 else event['protective_high']+buffer+b.spread
        add('range_reversal',side,stop,event['first_structure_target'],
            ['Frozen two-sided broader range','First counter break then separate edge retest',
             'Second counter trigger within edge third'],event)

    # Linear channel from two historical same-side swings; trade with slope only.
    for s, pts in ((1, ls), (-1, hs)):
        if len(pts) >= 2 and s*c.slope > .25 and c.micro_run < 5:
            level = line_value(pts[-2:],n)
            touched = b.low <= level+.3*atr if s == 1 else b.high >= level-.3*atr
            held = s*(b.close-level) > 0
            if touched and held and s*(pts[-1][1]-pts[-2][1]) > 0:
                stop = min(level,b.low)-buffer if s == 1 else max(level,b.high)+buffer+b.spread
                risk = s*((b.close+(b.spread if s == 1 else 0))-stop)
                add("channel",s,stop,b.close+s*2*risk,["Confirmed sloped channel", "Trend-side channel rejection"])

    # Last compact flag in an established leg, then failed breakout back into flag.
    flag = bars[-8:-2]
    fh, fl = max(x.high for x in flag), min(x.low for x in flag)
    old_ctx = context(bars[:-8])
    if old_ctx and old_ctx.regime in ("bull","bear") and fh-fl <= 2.5*atr:
        old = 1 if old_ctx.regime == "bull" else -1
        failed = prev.high > fh and b.close < fh if old == 1 else prev.low < fl and b.close > fl
        if failed and c.micro_run < 5:
            side = -old
            stop = max(prev.high,b.high)+buffer+b.spread if side == -1 else min(prev.low,b.low)-buffer
            risk = side*((b.close+(b.spread if side == 1 else 0))-stop)
            add("final_flag",side,stop,b.close+side*2*risk,["Prior trend and compact pause", "Flag breakout failed back inside"])

    # Measured-move is a target framework attached to breakout retests, not a forecast.
    for j in range(len(bars)-8, len(bars)-2):
        base = bars[j-20:j]
        if len(base) < 20:
            continue
        mh, ml = max(x.high for x in base), min(x.low for x in base)
        for s, level in ((1,mh),(-1,ml)):
            z = bars[j]
            crossed = s*(z.close-level) > .2*atr and signal_bar(z,s)
            tested = b.low <= level+.25*atr and b.close > level if s == 1 else b.high >= level-.25*atr and b.close < level
            if crossed and tested and s*c.slope > 0:
                stop = min(b.low,level)-buffer if s == 1 else max(b.high,level)+buffer+b.spread
                add("measured_move",s,stop,level+s*(mh-ml),["Confirmed breakout retest", "One range-height target"])

    # Yesterday's levels + EMA are context; EMA only permits trend-side bounce.
    previous_days = [x for x in bars if x.time.date() < b.time.date()]
    if previous_days:
        day = previous_days[-1].time.date()
        daybars = [x for x in previous_days if x.time.date() == day]
        dh, dl = max(x.high for x in daybars), min(x.low for x in daybars)
        if c.regime != "bear" and b.low <= dl+.2*atr and b.close > dl:
            stop = min(b.low,dl)-buffer
            add("magnet",1,stop,b.close+2*((b.close+b.spread)-stop),["Previous UTC-day low", "Support rejection"])
        if c.regime != "bull" and b.high >= dh-.2*atr and b.close < dh:
            stop = max(b.high,dh)+buffer+b.spread
            add("magnet",-1,stop,b.close-2*(stop-b.close),["Previous UTC-day high", "Resistance rejection"])

        # Must explicitly name a session open in UTC. No stock-market open carried into gold by default.
        hour = cfg.get("session_open_hour_utc")
        if hour is not None:
            minutes = b.time.hour*60+b.time.minute-hour*60
            if 0 <= minutes <= 90:
                today = [x for x in bars if x.time.date()==b.time.date() and x.time.hour >= hour]
                if len(today) >= 3:
                    if min(x.low for x in today) < dl and b.close > dl and b.close > prev.high:
                        stop = min(x.low for x in today)-buffer
                        add("opening_reversal",1,stop,b.close+2*((b.close+b.spread)-stop),["Configured session window", "Prior-day low sweep and reclaim"])
                    if max(x.high for x in today) > dh and b.close < dh and b.close < prev.low:
                        stop = max(x.high for x in today)+buffer+b.spread
                        add("opening_reversal",-1,stop,b.close-2*(stop-b.close),["Configured session window", "Prior-day high sweep and reject"])
    # One stable priority order; same used for training and execution.
    candidates.sort(key=lambda x: SETUPS.index(x.setup))
    return candidates


def select(signals, model=None, minimum_probability=.55, minimum_expectancy=.10):
    if model is None:
        return signals[0] if signals else None
    accepted = []
    for s in signals:
        s.probability = model.predict(s.features)
        expected = model.predict_r(s.features)
        # Separate regression on realized net R handles time exits, cost and gap losses.
        if s.probability >= minimum_probability and expected >= minimum_expectancy:
            accepted.append(s)
    return max(accepted,key=lambda s:s.probability) if accepted else None

