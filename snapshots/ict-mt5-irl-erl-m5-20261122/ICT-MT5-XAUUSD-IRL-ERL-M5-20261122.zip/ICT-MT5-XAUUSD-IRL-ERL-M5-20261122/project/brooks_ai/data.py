import csv
import json
from pathlib import Path
from .types import Bar, Instrument, Tick, utc_time


def load_bars(path, spec):
    with open(path, encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        required = {"time", "open", "high", "low", "close", "spread"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("CSV requires UTC time, bid OHLC, spread in price units")
        if spec.profit_currency != spec.account_currency and "account_conversion" not in reader.fieldnames:
            raise ValueError("Non-account quote currency requires historical account_conversion per bar")
        bars=[]
        for row_number,r in enumerate(reader,2):
            conversion=r.get("account_conversion")
            if spec.profit_currency!=spec.account_currency and (conversion is None or not conversion.strip()):
                raise ValueError(f"Missing historical account_conversion on CSV row {row_number}")
            bars.append(Bar(utc_time(r["time"]),*(float(r[k]) for k in ("open","high","low","close","spread")),
                            float(conversion or 1)))
    if any(b.time <= a.time for a, b in zip(bars, bars[1:])):
        raise ValueError("Bars must be strictly chronological with no duplicate time")
    if len(bars) < 80:
        raise ValueError("At least 80 bars required")
    return bars


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def load_ticks(path,spec,max_ticks=5000000):
    ticks=[]
    with open(path,encoding="utf-8-sig",newline="") as stream:
        reader=csv.DictReader(stream)
        if not {"time","bid","ask"}.issubset(reader.fieldnames or []):
            raise ValueError("Tick CSV requires timezone-aware time, bid and ask")
        for number,row in enumerate(reader,2):
            conversion=row.get("account_conversion")
            if spec.profit_currency!=spec.account_currency and (conversion is None or not conversion.strip()):
                raise ValueError(f"Missing historical tick account_conversion on CSV row {number}")
            tick=Tick(utc_time(row["time"]),float(row["bid"]),float(row["ask"]),float(conversion or 1))
            if ticks and tick.time<ticks[-1].time:
                raise ValueError(f"Tick time decreases on CSV row {number}; file order must be preserved")
            ticks.append(tick)  # Equal timestamps are valid; their source order can change exit sequence.
            if len(ticks)>max_ticks:
                raise ValueError("Tick file exceeds in-memory replay limit; split it into recorded study periods")
    if not ticks:
        raise ValueError("Tick file is empty")
    return ticks


def load_spec(path):
    return Instrument(**load_json(path))


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)

