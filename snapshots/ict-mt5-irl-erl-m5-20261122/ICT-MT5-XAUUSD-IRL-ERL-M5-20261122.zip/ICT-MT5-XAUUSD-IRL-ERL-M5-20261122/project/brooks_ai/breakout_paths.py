"""Post-activation structural outcomes, separate from entry-time features.

These describe closed bid OHLC relative to a frozen horizontal boundary. A
return inside is not a losing trade; holding outside is not a profitable one.
The horizon, ATR band and resumption test are explicit engineering choices.
"""
import math
from datetime import timedelta


def trace_horizontal_breakout(bars,event,activation_index,tick_size,horizon=20,interval_seconds=900):
    if (not math.isfinite(tick_size) or tick_size<=0 or type(horizon) is not int or horizon<=0 or
        type(interval_seconds) is not int or interval_seconds<=0 or type(activation_index) is not int or
        not 0<=activation_index<len(bars)):
        raise ValueError('Invalid path parameters')
    side=event['side'];boundary=event['boundary'];atr=event['breakout_atr']
    if side not in (-1,1) or not math.isfinite(boundary) or boundary<=0 or not math.isfinite(atr) or atr<=0:
        raise ValueError('Invalid frozen breakout reference')
    if event['activation_time']!=bars[activation_index].time.isoformat():
        raise ValueError('Activation time differs from history index')
    age=event['activation_index']-event['breakout_index']
    break_index=activation_index-age
    if age<1 or break_index<0 or event['breakout_time']!=bars[break_index].time.isoformat():
        raise ValueError('Breakout index/time mapping differs')
    if side*(bars[activation_index].close-boundary)<=tick_size*1e-7:
        raise ValueError('Activation does not hold outside frozen boundary')
    band=max(tick_size,.10*atr);tol=tick_size*1e-7
    result=dict(schema=1,kind='horizontal_boundary_post_activation',side=side,boundary=boundary,
                frozen_breakout_atr=atr,touch_band=band,horizon_bars=horizon,
                activation_bar_time=bars[activation_index].time.isoformat(),
                feature_available_after_label=(bars[activation_index].time+timedelta(seconds=interval_seconds)).isoformat(),
                observed_bars=0,status='right_censored',events=[],first_touch_index=None,
                first_return_inside_index=None,first_resumption_index=None,first_reclaim_index=None,
                final_close_distance_atr=None,max_close_distance_atr=None,min_close_distance_atr=None,
                target_hold_outside=None,target_available_after_label=None,
                purpose='Future structural outcome sidecar; never an entry feature or execution qualification',
                intrabar_order_inferred=False,net_profit_label=None,orders_sent=0)
    pending=None;returned=False;distances=[]
    last=activation_index
    def add(name,index):
        result['events'].append(dict(event=name,index=index,bar_time=bars[index].time.isoformat(),
                                available_after_label=(bars[index].time+timedelta(seconds=interval_seconds)).isoformat(),
                                close=bars[index].close,close_distance_atr=side*(bars[index].close-boundary)/atr))
    for i in range(activation_index+1,min(len(bars),activation_index+horizon+1)):
        b=bars[i]
        if (b.time-bars[i-1].time).total_seconds()!=interval_seconds:
            result.update(status='censored_by_clock_gap',gap_before_bar_time=b.time.isoformat())
            break
        result['observed_bars']+=1;last=i
        distance=side*(b.close-boundary)
        distances.append(distance/atr)
        intersects=b.low<=boundary+band+tol and b.high>=boundary-band-tol
        if intersects and result['first_touch_index'] is None:
            result['first_touch_index']=i;add('wick_intersects_boundary_band',i)
        if distance<=tol:
            if not returned:
                result['first_return_inside_index']=i;add('first_close_inside_or_on_boundary',i)
            returned=True;pending=None
        else:
            if returned and result['first_reclaim_index'] is None:
                result['first_reclaim_index']=i;add('first_close_reclaims_boundary',i)
            if pending is not None and result['first_resumption_index'] is None:
                if side*(b.close-bars[pending].close)>=tick_size-tol and side*(b.close-b.open)>tol:
                    result['first_resumption_index']=i;add('directional_close_after_held_touch',i)
                    pending=None
            if intersects and pending is None and result['first_resumption_index'] is None:
                pending=i
    if distances:
        result.update(final_close_distance_atr=distances[-1],max_close_distance_atr=max(distances),
                      min_close_distance_atr=min(distances))
    if result['observed_bars']==horizon:
        result.update(status='complete',target_hold_outside=int(not returned),
                      target_available_after_label=(bars[last].time+timedelta(seconds=interval_seconds)).isoformat())
    result['observed_through_bar_time']=bars[last].time.isoformat()
    return result
