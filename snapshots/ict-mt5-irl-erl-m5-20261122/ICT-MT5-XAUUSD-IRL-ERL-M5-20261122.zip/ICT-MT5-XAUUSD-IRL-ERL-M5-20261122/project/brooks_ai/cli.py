import argparse
from dataclasses import asdict
from datetime import datetime,timezone
import json
from pathlib import Path
import sys
import time
from .config import load_config
from .data import load_spec,load_bars,load_ticks,save_json,load_json
from .model import Classifier,train,policy_fingerprint
from .backtest import run
from .strategy import context,detect,select
from .research import retrieve

ROOT=Path(__file__).resolve().parents[1]


def report(value):
    print(json.dumps(value,ensure_ascii=False,indent=2,default=lambda x:x.isoformat(),allow_nan=False))


def main(argv=None):
    p=argparse.ArgumentParser(description="Brooks price-action AI: research, backtest, supervised training and MT5 DEMO only")
    p.add_argument("--config",default=str(ROOT/"config/strategy.json"))
    sub=p.add_subparsers(dest="command",required=True)
    q=sub.add_parser("research",help="Retrieve private source paragraphs with PDF page numbers")
    q.add_argument("query")
    q.add_argument("--limit",type=int,default=5)
    q.add_argument("--corpus",default=str(ROOT/"research/corpus.jsonl"))
    q=sub.add_parser("qualify-rolling",help="Export the exact final model from passing rolling evidence; sends no orders")
    q.add_argument("--report",required=True)
    q.add_argument("--data",required=True)
    q.add_argument("--spec",required=True)
    q.add_argument("--out",default="output/demo_model.json")
    q=sub.add_parser("tick-backtest",help="Replay recorded bid/ask quote paths; research only")
    q.add_argument("--data",required=True)
    q.add_argument("--spec",required=True)
    q.add_argument("--model")
    q.add_argument("--out",default="output/tick_backtest.json")
    for name in ("backtest","train","signal","walk-forward","train-ticks","walk-forward-ticks"):
        q=sub.add_parser(name)
        q.add_argument("--data",required=True)
        q.add_argument("--spec",required=True)
        if name in ("walk-forward","walk-forward-ticks"):
            q.add_argument("--out",default="output/tick_walk_forward.json" if name.endswith("ticks") else "output/walk_forward.json")
            q.add_argument("--train-bars",type=int,default=10000)
            q.add_argument("--validation-bars",type=int,default=3000)
            q.add_argument("--test-bars",type=int,default=3000)
        elif name in ("train","train-ticks"):
            q.add_argument("--out",default="output/tick_model.json" if name.endswith("ticks") else "output/model.json")
        else:
            q.add_argument("--model")
            if name=="backtest":
                q.add_argument("--out",default="output/backtest.json")
    for name in ("mt5-status","mt5-bind","mt5-export","mt5-export-ticks","demo-once","demo-loop","mt5-reconcile"):
        q=sub.add_parser(name)
        if name=="mt5-export":
            q.add_argument("--count",type=int,default=50000)
            q.add_argument("--out",default="data/XAUUSD_M15.csv")
            q.add_argument("--spec-out",default="data/XAUUSD_spec.json")
        if name=="mt5-export-ticks":
            q.add_argument("--from",dest="date_from",required=True)
            q.add_argument("--to",dest="date_to",required=True)
            q.add_argument("--out",default="data/XAUUSD_ticks.csv")
            q.add_argument("--spec-out",default="data/XAUUSD_tick_spec.json")
        if name in ("demo-once","demo-loop"):
            q.add_argument("--model",required=True)
        if name=="demo-loop":
            q.add_argument("--interval",type=int,default=5)
    args=p.parse_args(argv)
    try:
        if args.command=="research":
            report(retrieve(args.query,args.corpus,args.limit))
            return 0
        cfg=load_config(args.config)
        if args.command=="tick-backtest":
            from .tickbacktest import run_ticks
            import hashlib
            inputs=[args.data,args.spec,str(args.data)+".provenance.json"]
            if args.model:
                inputs.append(args.model)
            if Path(args.out).resolve() in {Path(x).resolve() for x in inputs}:
                raise ValueError("Tick report must not overwrite input data, model or specification")
            spec=load_spec(args.spec)
            if spec.symbol!=cfg["symbol"]:
                raise ValueError("Config and instrument symbol mismatch")
            ticks=load_ticks(args.data,spec)
            model=Classifier.load(args.model) if args.model else None
            if model and (model.artifact["symbol"]!=spec.symbol or model.artifact["policy_fingerprint"]!=policy_fingerprint(cfg)):
                raise ValueError("Model/config mismatch")
            provenance=Path(str(args.data)+".provenance.json")
            metadata=load_json(provenance) if provenance.exists() else {}
            data_hash=hashlib.sha256(Path(args.data).read_bytes()).hexdigest()
            if metadata.get("data_sha256") and metadata["data_sha256"]!=data_hash:
                raise ValueError("Tick data differs from its saved source provenance")
            result=run_ticks(ticks,spec,cfg,model)
            result.update({"synthetic":metadata.get("synthetic",False),
                           "source_provenance":metadata if metadata else {"status":"unprovided; source and coverage unverified"},
                           "research_only":True,"policy_fingerprint":policy_fingerprint(cfg),
                           "data_sha256":data_hash,"instrument":asdict(spec)})
            save_json(args.out,result)
            report({"output":args.out,"metrics":result["metrics"],"quote_audit":result["quote_audit"],
                    "synthetic":result["synthetic"],"execution_authorization":False})
            return 0
        if args.command=="qualify-rolling":
            from .qualification import export_rolling_model
            spec=load_spec(args.spec)
            if spec.symbol!=cfg["symbol"]:
                raise ValueError("Config and instrument symbol mismatch")
            artifact=export_rolling_model(args.report,args.data,spec,cfg,args.out)
            report({"model":args.out,"qualified_for_demo":artifact["qualified_for_demo"],
                    "deployment_fold":artifact["deployment_fold"],"orders_sent":False})
            return 0
        if args.command in ("backtest","train","signal","walk-forward","train-ticks","walk-forward-ticks"):
            spec=load_spec(args.spec)
            if spec.symbol!=cfg["symbol"]:
                raise ValueError("Config and instrument symbol mismatch")
            execution=None
            if args.command.endswith("ticks"):
                from .tickmodel import TickExecution
                import hashlib
                source=Path(str(args.data)+".provenance.json")
                metadata=load_json(source) if source.exists() else {}
                if metadata.get("data_sha256") and metadata["data_sha256"]!=hashlib.sha256(Path(args.data).read_bytes()).hexdigest():
                    raise ValueError("Tick data differs from its saved source provenance")
                inputs={Path(x).resolve() for x in (args.data,args.spec,str(source))}
                outputs={Path(args.out).resolve(),Path(args.out).with_suffix(".details.json").resolve(),
                         Path(args.out).with_suffix(".holdout.json").resolve()}
                if inputs & outputs:
                    raise ValueError("Tick training outputs must not overwrite research inputs")
                execution=TickExecution(load_ticks(args.data,spec),cfg)
                bars=execution.bars
            else:
                bars=load_bars(args.data,spec)
            model=Classifier.load(args.model) if getattr(args,"model",None) else None
            if model and (model.artifact["symbol"]!=spec.symbol or model.artifact["policy_fingerprint"]!=policy_fingerprint(cfg)):
                raise ValueError("Model/config mismatch")
            if args.command in ("walk-forward","walk-forward-ticks"):
                from .walkforward import walk_forward
                result=walk_forward(bars,spec,cfg,args.data,args.out,args.train_bars,args.validation_bars,args.test_bars,execution)
                report({"output":args.out,"summary":result["summary"],"execution_basis":result["execution_basis"],"execution_authorization":False})
            elif args.command in ("train","train-ticks"):
                artifact=train(bars,spec,cfg,args.data,args.out,execution)
                report({"model":args.out,"qualified_for_demo":artifact["qualified_for_demo"],
                        "execution_basis":artifact["execution_basis"],
                        "single_holdout_gates_pass":artifact["single_holdout_gates_pass"],
                        "evaluation":artifact["evaluation"],"gates":artifact["gates"]})
            elif args.command=="backtest":
                result=run(bars,spec,cfg,model)
                result["research_only"]=not spec.verified or not spec.costs_verified
                provenance=Path(str(args.data)+".provenance.json")
                result["synthetic"]=load_json(provenance).get("synthetic",False) if provenance.exists() else False
                if result["synthetic"]:
                    result["interpretation"]="Synthetic engineering fixture, not historical trading performance"
                save_json(args.out,result)
                report({"output":args.out,"metrics":result["metrics"],"research_only":result["research_only"],
                        "synthetic":result["synthetic"]})
            else:
                signals=detect(bars[-120:],cfg,spec.tick_size)
                chosen=select(signals,model,cfg["min_probability"],cfg["min_expected_r"])
                report({"context":asdict(context(bars[-120:])),"candidates":[asdict(x) for x in signals],
                        "selected":asdict(chosen) if chosen else None,"orders_sent":False})
            return 0
        from .mt5 import Gateway,Journal,ProcessLock,bind,export_history,export_ticks,demo_once,reconcile
        gateway=Gateway(cfg)
        if args.command=="mt5-bind":
            report(bind(gateway,args.config))
            return 0
        if args.command=="mt5-export":
            report(export_history(gateway,args.out,args.spec_out,args.count))
            return 0
        if args.command=="mt5-export-ticks":
            report(export_ticks(gateway,args.out,args.spec_out,args.date_from,args.date_to))
            return 0
        gateway.connect()
        try:
            if args.command=="mt5-status":
                a,t=gateway.identity()
                info=gateway.symbol()
                report({"connected":t.connected,"mode":"demo","server":a.server,
                        "symbol":info.name,"account_currency":a.currency,"orders_sent":False})
                return 0
            with ProcessLock(ROOT/"runtime/demo.lock"):
                journal=Journal(ROOT/"runtime/journal.sqlite")
                try:
                    if args.command=="mt5-reconcile":
                        report(reconcile(gateway,journal))
                    elif args.command=="demo-once":
                        report(demo_once(gateway,journal,args.model,ROOT/"runtime/STOP"))
                    else:
                        if not 1<=args.interval<=60:
                            raise ValueError("Loop interval must be 1..60 seconds")
                        last=None
                        while True:
                            result=demo_once(gateway,journal,args.model,ROOT/"runtime/STOP")
                            if result!=last:
                                record={"time_utc":datetime.now(timezone.utc).isoformat(),**result}
                                report(record)
                                with (ROOT/"runtime/events.jsonl").open("a",encoding="utf-8") as f:
                                    f.write(json.dumps(record,ensure_ascii=False)+"\n")
                                last=result
                            time.sleep(args.interval)
                finally:
                    journal.close()
        finally:
            gateway.shutdown()
        return 0
    except KeyboardInterrupt:
        print("Stopped. Broker-side SL/TP remain active; use runtime/STOP before exit to request closure on next cycle.")
        return 130
    except (ValueError,RuntimeError,OSError,ImportError) as e:
        print(str(e),file=sys.stderr)
        return 2


if __name__=="__main__":
    raise SystemExit(main())

