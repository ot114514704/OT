"""Closed-M5 Judas geometry. Sources: ICT 精翻 pp.173–175 and 时间（四）.

Wick/body, displacement and maximum wait are research definitions for XAU.
Bars alone do not establish stop volume, order ownership or intrabar sequence.
"""
from datetime import datetime, time, timedelta
from statistics import median
from bisect import bisect_left

from .timebase import NY, session_windows
from .range_liquidity import _m5_reference_day

STEP = timedelta(minutes=5)


def judas_history(bars, now, news, pending=None, *, step=STEP, reference_m5=None):
    closed = [bar for bar in bars if bar.time + step <= now]
    if not closed:
        return []
    times = [b.time for b in closed]
    ref_rows = closed if reference_m5 is None else reference_m5
    ref_times = times if reference_m5 is None else [b.time for b in ref_rows]
    day = times[0].astimezone(NY).date()
    events = []
    release_times = {t for t, _ in news}
    while day <= times[-1].astimezone(NY).date():
        if day.weekday() < 5:
            prior = day - timedelta(days=3 if day.weekday() == 0 else 1)
            start = datetime.combine(prior, time(), NY)
            end = datetime.combine(day + timedelta(days=1), time(), NY)
            part = closed[bisect_left(times, start):bisect_left(times, end)]
            reference = _m5_reference_day(ref_rows[bisect_left(ref_times,start):bisect_left(ref_times,end)], prior, now)
            events.extend(day_signals(day, part, reference, release_times, step=step,
                                     pending=pending if day==now.astimezone(NY).date() else None))
        day += timedelta(days=1)
    return events


def chart_label(e):
    clock = lambda t: t.astimezone(NY).strftime('%H:%M')
    return ('看涨犹大' if e['side']==1 else '看跌犹大') + (
        f'｜{e.get("timeframe","M5")} · {e["window"]} · 纽约时间｜{clock(e["sweep"])} 扫{e["refs"]}后收回，极值 {e["edge"]:.2f}'
        f'｜{clock(e["impulse_at"])} 反向位移；{clock(e["mss_at"])} 收破结构 {e["structure"]:.2f}'
        f'；{clock(e["cisd_at"])} 收破反向交付起点 {e["cisd"]:.2f}'
        f'｜{clock(e["known"])} 收线确认 FVG {e["lo"]:.2f}–{e["hi"]:.2f}，此时起才可识别'
        f'｜扫前背景 · {e["background"]}。弧线定位扫荡棒，实际止损成交量未知。')


def day_signals(day, bars, prior, releases, *, pending=None, step=STEP):
    a,z = session_windows(day)['asia']
    asia = [b for b in bars if a<=b.time<z]
    refs = []
    if len(asia)==int((z-a)/step) and all(b.time==a+i*step for i,b in enumerate(asia)):
        refs.append(('亚洲', max(b.high for b in asia), min(b.low for b in asia),z))
    if prior and prior.get('status')=='complete':
        ref = prior['bars']
        refs.append(('前日',max(b.high for b in ref),min(b.low for b in ref),prior['end']))
    if not refs:
        return []
    def local(h,m=0):
        return datetime.combine(day,time(h,m),NY)
    news10 = any(t==local(10) for t in releases)
    windows = [(local(2),local(3),'伦敦严格窗'),(local(8),local(9,30),'纽约严格窗')]
    windows.append((local(10),local(10,10),'纽约十点新闻') if news10 else
                   (local(9,30),local(9,45),'纽约 09:30 观察'))
    result = []
    for start,end,name in windows:
        for i,b in enumerate(bars):
            if not start<=b.time<end or i<6:
                continue
            pre=bars[i-6:i]
            if b.time-pre[0].time!=6*step:
                continue
            for side in (1,-1):
                edge=b.low if side==1 else b.high
                wick=min(b.open,b.close)-b.low if side==1 else b.high-max(b.open,b.close)
                if wick<=0 or wick<.35*(b.high-b.low):
                    continue
                raided=[]
                for tag,hi,lo,known in refs:
                    p=lo if side==1 else hi
                    if known>b.time or not side*(p-edge)>0 or not side*(b.close-p)>0:
                        continue
                    if any((x.low<p if side==1 else x.high>p) for x in bars if known<=x.time<b.time):
                        continue
                    raided.append(f'{tag}{"低" if side==1 else "高"} {p:.2f}')
                if not raided:
                    continue
                structure=max(x.high for x in pre) if side==1 else min(x.low for x in pre)
                # Freeze the open of the latest contiguous opposing delivery run.
                opposing=[k for k,x in enumerate(pre+[b]) if side*(x.close-x.open)<0]
                if not opposing:
                    continue
                run=pre+[b]; k=opposing[-1]
                while k>0 and side*(run[k-1].close-run[k-1].open)<0:
                    k-=1
                cisd=run[k].open
                typical=median(x.high-x.low for x in pre)
                if typical<=0:
                    continue
                prior_rows=prior['bars'] if prior and prior.get('status')=='complete' else []
                background='前日资料不全，方向待核'
                if prior_rows:
                    move=prior_rows[-1].close-prior_rows[0].open
                    background=f'前日开收净移 {move:+.2f}，与本次反向交付'+('同向' if move*side>0 else '反向' if move else '无方向')
                shift=delivery=impulse=None
                resolved=False
                for j in range(i+1,min(i+7,len(bars))):
                    q=bars[j]
                    if q.time!=b.time+(j-i)*step or (q.low<edge if side==1 else q.high>edge):
                        resolved=True
                        break
                    at=q.time+step
                    if side*(q.close-structure)>0 and shift is None: shift=at
                    if side*(q.close-cisd)>0 and delivery is None: delivery=at
                    if side*(q.close-q.open)>=typical and impulse is None: impulse=at
                    left=bars[j-2]
                    lo,hi=(left.high,q.low) if side==1 else (q.high,left.low)
                    middle=bars[j-1]
                    if j<i+2 or hi<=lo or middle.low>lo or middle.high<hi or not (shift and delivery and impulse):
                        continue
                    result.append(dict(side=side,sweep=b.time,known=at,edge=edge,confirm=q.close,
                        timeframe=f'M{int(step.total_seconds()//60)}',refs=' / '.join(raided),window=name,structure=structure,cisd=cisd,
                        mss_at=shift,cisd_at=delivery,impulse_at=impulse,lo=lo,hi=hi,background=background))
                    resolved=True
                    break
                if pending is not None and not resolved and bars[-1].time-b.time<6*step:
                    pending.append(dict(side=side,sweep=b.time,edge=edge,known=b.time+step,
                        timeframe=f'M{int(step.total_seconds()//60)}', refs=' / '.join(raided), window=name,background=background))
    return sorted(result,key=lambda e:e['known'])
