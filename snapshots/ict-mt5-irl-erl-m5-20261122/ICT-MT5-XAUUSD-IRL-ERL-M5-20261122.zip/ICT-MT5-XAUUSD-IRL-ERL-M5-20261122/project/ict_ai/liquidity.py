"""Price references for DOL research, not observed order-book liquidity.

Concept source: ICT 精翻 pp. 32, 39–42. NY midnight aggregation and assumed
weekday XAUUSD closure 17:00–18:00 are explicit research boundaries; they are
not the broker's native D1 bar or a verified holiday calendar.
"""
from datetime import datetime,time,timedelta,timezone
import math
from .timebase import NY


def closed_day_references(bars,day,period,as_of,friday_close_minutes=17*60):
    if period<=timedelta(0) or as_of.tzinfo is None or as_of.utcoffset() is None:
        raise ValueError('Positive period and aware cutoff required')
    if any(a.time>=b.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Unique chronological bars required')
    if friday_close_minutes not in (16*60+55,17*60):
        raise ValueError('Explicit Friday study-close hypothesis must be 16:55 or 17:00 NY')
    result={'date':day.isoformat(),'status':'unavailable','levels':[],
            'basis':'NY 00:00 research day; assumed weekday closure 17:00–18:00; not native broker D1',
            'session_calendar_verified':False,'source_pages':[32,39,41,42],
            'friday_close_minutes_ny':friday_close_minutes}
    if day.weekday()>=5:return result
    local=lambda h:datetime.combine(day,time(h),NY).astimezone(timezone.utc)
    start,end=local(0),local(17)
    if day.weekday()==4:
        end=local(0)+timedelta(minutes=friday_close_minutes)
        result['basis']+=f'; Friday study-close hypothesis {friday_close_minutes//60:02d}:{friday_close_minutes%60:02d}'
    windows=[(start,end)]
    if day.weekday()!=4:windows.append((local(18),datetime.combine(day+timedelta(days=1),time(0),NY).astimezone(timezone.utc)))
    cutoff=windows[-1][1]
    if cutoff>as_of:
        result['status']='not_closed';return result
    expected=[]
    for begin,finish in windows:
        if (finish-begin)%period:raise ValueError('Period must divide every study window')
        t=begin
        while t<finish:expected.append(t);t+=period
    data={b.time:b for b in bars if b.time+period<=as_of}
    if day.weekday()==4 and any(end<=at<local(17) for at in data):
        result.update(status='study_calendar_contradicted',reason='Observed closed bars after selected Friday study close')
        return result
    missing=[t for t in expected if t not in data]
    if missing:
        result.update(status='missing_quotes',missing_bars=len(missing),
                      missing_expected_times=[t.isoformat() for t in missing],
                      expected_bars=len(expected),
                      reason='Missing relative to the selected unverified study calendar; not proof of broker quote loss')
        return result
    part=[data[t] for t in expected]
    result.update(status='complete',bars=len(part),available_at=cutoff.isoformat(),open=part[0].open,close=part[-1].close)
    for kind,price,side in [('PDH',max(b.high for b in part),'buy_side_proxy'),('PDL',min(b.low for b in part),'sell_side_proxy')]:
        reached=next((b for b in bars if b.time>=cutoff and b.time+period<=as_of and (b.high>=price if kind=='PDH' else b.low<=price)),None)
        result['levels'].append({'id':day.isoformat()+'-'+kind,'kind':kind,'price':price,'liquidity_side':side,
                                 'available_at':cutoff.isoformat(),'price_touched':reached is not None,
                                 'first_touch_known_at':(reached.time+period).isoformat() if reached else None,
                                 'actual_stop_orders_observed':False})
    return result


def equal_extreme_references(bars,period,as_of,tick_size,tolerance_ticks=3,pivot_radius=2,max_anchor_bars=48):
    """Freeze EQH/EQL only after the second pivot's right bars close.

    Equality tolerance, radius and anchor span are engineering choices. These
    levels are candidate zones and cannot prove an order count or future draw.
    """
    if period<=timedelta(0) or as_of.tzinfo is None or not math.isfinite(tick_size) or tick_size<=0 or tolerance_ticks<0 or pivot_radius<1:
        raise ValueError('Valid clock, tick size and pivot parameters required')
    if any(a.time>=b.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Unique chronological bars required')
    closed=[b for b in bars if b.time+period<=as_of];previous={};events=[];start=0;r=pivot_radius
    for i,b in enumerate(closed):
        if i and b.time!=closed[i-1].time+period:start=i;previous={}
        if i-start<2*r:continue
        center=i-r;point=closed[center];window=closed[i-2*r:i+1]
        for field,kind in [('high','EQH'),('low','EQL')]:
            value=getattr(point,field);others=[getattr(z,field) for j,z in enumerate(window) if j!=r]
            if not (all(value>x for x in others) if field=='high' else all(value<x for x in others)):continue
            old=previous.get(field);previous[field]=(center,point)
            if not old:continue
            old_index,old_point=old;old_value=getattr(old_point,field)
            if center-old_index>max_anchor_bars or abs(value-old_value)>tick_size*tolerance_ticks+1e-10:continue
            events.append({'kind':kind,'lower':min(value,old_value),'upper':max(value,old_value),
                           'first_anchor':old_point.time.isoformat(),'second_anchor':point.time.isoformat(),
                           'available_at':(b.time+period).isoformat(),'source_pages':[32,38,39,41],
                           'tolerance_price':tick_size*tolerance_ticks,'actual_stop_orders_observed':False})
    return events
