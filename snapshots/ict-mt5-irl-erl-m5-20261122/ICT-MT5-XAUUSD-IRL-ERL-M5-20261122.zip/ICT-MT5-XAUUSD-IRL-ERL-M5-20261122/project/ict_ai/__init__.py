"""Evidence-linked ICT research. Does not submit trading orders."""
