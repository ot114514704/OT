"""Conditional commentary from observed bars; no prediction or order authority."""
from .timebase import NY
from .knowledge import timestamp


def daily_analysis(day,as_of,previous_day=None,peer_last_closed=None):
    now=timestamp(as_of) if isinstance(as_of,str) else as_of
    result={'date':day['date'],'as_of':now.isoformat(),'status':'conditional_research',
            'execution_allowed':False,'sections':[],'source_slides':[16,17,21],
            'limitations':['事先方向与高周期 PDA/DOL 未验证','经济日历只接入部分官方计划','行情为快照，非自动实时刷新']}
    rows=result['sections'];sessions=day['sessions'];a=sessions['asia'];l=sessions['london'];n=sessions['new_york']
    add=lambda label,text:rows.append({'label':label,'text':text})
    lifecycle=day.get('profile_lifecycle')
    if lifecycle:
        add('当前概况',day.get('profile_label','待确认')+'。'+('盘中推测，可随新证据调整。' if lifecycle['mode']=='intraday_hypothesis' else '当日已结束；确认范围仅限已观察价格形态，完整 ICT 背景仍待核实。'))
        add('Weekly profile 背景',lifecycle['weekly_background']['label']+'。'+lifecycle['weekly_background']['reason'])
    else:
        add('当前概况',day.get('profile_label','待确认')+'，仍是价格路径候选。'+('今日未结束，后续走势可能改变判断。' if not day['day_completed'] else '该日已结束，以下为事后复盘条件。'))
    if not a.get('complete') or not l.get('complete'):
        add('当前策略','亚洲或伦敦窗口未完整，先等待参考区间形成，暂不提出方向性触发价。');return result
    lh,ll,ah,al=l['high'],l['low'],a['high'],a['low']
    opening=f"{day['daily_open']:.2f}" if day.get('daily_open') is not None else '缺少零点报价，未补值'
    add('关键价位',f"纽约零点开盘 {opening}；亚洲高/低 {ah:.2f} / {al:.2f}；伦敦高/低 {lh:.2f} / {ll:.2f}。")
    if n.get('bars'):
        nc,nl,nh=n['close'],n['low'],n['high']
        add('纽约当前证据',f"截至已收盘 M15，纽约窗口开 {n['open']:.2f}、高 {nh:.2f}、低 {nl:.2f}、最近收盘 {nc:.2f}；窗口"+('已结束。' if n['complete'] else '进行中。'))
        if nl<ll and nc>ll:
            add('判断调整',f"纽约已跌破伦敦低点 {ll:.2f}，但最近收回其上。早期偏空延续条件尚未成立，当前应同时观察扫低后修复与再次向下扩张，不能只因伦敦回落就追空。")
        elif nh>lh and nc<lh:
            add('判断调整',f"纽约已越过伦敦高点 {lh:.2f} 后收回，向上突破未持续；关注结构确认，不把越界本身当作方向反转。")
        else:add('判断调整','目前只描述已发生路径，等待收盘突破及后续跟随；局部上涨或下跌不等于全日概况已确认。')
    else:
        add('纽约当前证据','纽约窗口尚未形成完整观察，先等待其实际价格路径。')
    down=min(ll,n.get('low',ll));up=lh
    short_target=f"前一纽约日低点 {previous_day['low']:.2f}" if previous_day and previous_day.get('low',down)<down else f"亚洲低点 {al:.2f}"
    long_target=f"前一纽约日高点 {previous_day['high']:.2f}" if previous_day and previous_day.get('high',up)>up else '经事先标定的更高周期流动性目标'
    add('向下条件',f"只有跌回 {ll:.2f} 下方，并对当前已知低点 {down:.2f} 形成收盘突破与位移，再观察看跌 FVG 回测是否守住。{short_target}仅作目标参考；还需核实事先看跌偏见及高周期位置，未核实前只观察。")
    add('向上条件',f"若重新站上亚洲高点 {ah:.2f}，继而突破并守住伦敦高点 {up:.2f}，早期经典卖出情景减弱。等待看涨结构变化与 FVG 回测，再核对{long_target}；单次刺破不能确认反转。")
    add('等待与风险','价格反复穿越区间、没有位移或只有单独 SMT 时继续等待。模拟研究单笔风险上限暂设 0.25%，止损依据确认结构，扣除成本后的盈亏比不足 1.5 或成本未知时不生成可执行计划。')
    smts=day['charts'].get('15',{}).get('smt',[])
    if smts:
        e=smts[-1];add('SMT 辅助',f"最近 M15 黄金/白银为{'看涨' if e['direction']=='bullish' else '看跌'}背离候选，确认于 {timestamp(e['available_at']).astimezone(NY).strftime('%m-%d %H:%M')} 纽约。它用于核对叙事，不能替代结构和高周期方向。")
    if peer_last_closed and (now-timestamp(peer_last_closed)).total_seconds()>900:
        add('数据覆盖',f"白银最新已收盘行情只到 {timestamp(peer_last_closed).astimezone(NY).strftime('%m-%d %H:%M')} 纽约，之后的 SMT 尚无同步数据支持。")
    return result
