"""Research quote-side check before a proposed limit order is activated."""
from bisect import bisect_left
from datetime import timedelta
from decimal import Decimal
from operator import attrgetter

from .tick_limit import simulate_tick_limit


def limit_quote_check(order, quote, max_age=timedelta(seconds=10)):
    """Project the stop-side quote using only a quote available before the order.

    Future spreads and price gaps can still cross the stop after a pass.
    """
    if max_age <= timedelta(0):
        raise ValueError("Quote age bound must be positive")
    result = {"order_id": order.id, "checked_at": order.available_at.isoformat(),
              "max_quote_age_seconds": max_age.total_seconds()}
    if quote is None:
        return {**result, "status": "missing_prior_quote"}
    age = order.available_at - quote.time
    if age <= timedelta(0):
        raise ValueError("Quote timestamp must strictly precede order activation")
    result.update(quote_at=quote.time.isoformat(), quote_age_seconds=age.total_seconds(),
                  bid=quote.bid, ask=quote.ask)
    if age > max_age:
        return {**result, "status": "stale_prior_quote"}
    bid, ask, limit, stop = (Decimal(str(value)) for value in (quote.bid, quote.ask, order.entry, order.stop))
    spread = ask - bid
    if order.side == 1:
        projected_entry = min(limit, ask)
        projected_exit = projected_entry - spread
    else:
        projected_entry = max(limit, bid)
        projected_exit = projected_entry + spread
    clearance = order.side * (projected_exit - stop)
    return {
        **result, "status": "stop_already_exposed" if clearance <= 0 else "stop_side_clear",
        "projected_entry": float(projected_entry), "projected_stop_side_quote": float(projected_exit),
        "spread": float(spread), "planned_stop_distance": float(order.side * (limit - stop)),
        "projected_stop_clearance": float(clearance),
    }


def simulate_preflight_limit(order, ticks, spec, as_of, *, max_age=timedelta(seconds=10)):
    """Leave a blocked order unplaced; never cancel a resting order retroactively."""
    if as_of.utcoffset() is None:
        raise ValueError("An aware cutoff is required")
    if as_of < order.available_at:
        return simulate_tick_limit(order, [], spec, as_of)
    if any(a.time > b.time for a, b in zip(ticks, ticks[1:])):
        raise ValueError("Keep recorded quote order")
    i = bisect_left(ticks, order.available_at, key=attrgetter("time"))
    check = limit_quote_check(order, ticks[i - 1] if i else None, max_age)
    if check["status"] == "stop_side_clear":
        return {**simulate_tick_limit(order, ticks[i:], spec, as_of), "quote_preflight": check}
    return {"order_id": order.id, "status": "withheld_before_activation", "filled": False, "pnl_net": None,
            "outcome_available_at": order.available_at.isoformat(), "quote_preflight": check,
            "orders_sent": 0, "execution_allowed": False}
