"""Source-linked ERL/IRL path ideas, prior to directional confirmation.

Bias/DOL video 629–794 seconds supplies the two illustrative routes. Using
first observed reclaim / far-edge contact as an origin is an engineering
proxy; these are neither qualified bias nor trade entry signals.
"""
from collections import Counter
import hashlib,json

from brooks_ai.types import utc_time
from .daily_context import M5,_open,_state,_gap_state


def _observe(target,bars,origin,now):
    lower=target.get('lower',target.get('price'));upper=target.get('upper',target.get('price'))
    bytime={b.time:b for b in bars if origin<=b.time and b.time+M5<=now}
    stamp=origin;missing=0;touch=None
    while stamp+M5<=now:
        if _open(stamp):
            b=bytime.get(stamp)
            if b is None:missing+=1
            elif touch is None and b.low<=upper and b.high>=lower:touch=(stamp+M5).isoformat()
        stamp+=M5
    return {'target_contact_known_at':touch,'missing_expected_m5':missing,
            'target_not_observed':False if touch else None if missing else True}


def delivery_hypotheses(context,bars,as_of):
    """Consume a same-cutoff daily_weekly_context snapshot, not asserted bias.

    Targets must already exist and have verified study-slot coverage at the
    origin. Prior visits disqualify this strict untouched-target subset.
    Eligibility is evaluated at the origin and never reselected at the end.
    Only same-timeframe pairs are covered; counterexamples are retained.
    """
    now=utc_time(as_of)
    if utc_time(context['as_of'])!=now:raise ValueError('Same-cutoff HTF evidence required')
    if any(a.time>=b.time for a,b in zip(bars,bars[1:])):raise ValueError('Chronological M5 source required')
    closed=[b for b in bars if b.time+M5<=now]
    closes={b.time+M5:b.close for b in closed}
    routes=[];rejected=Counter()
    for timeframe,frame in context['frames'].items():
        if timeframe not in ('D1','W1'):continue
        periods=frame['periods'];points=frame['confirmed_swings'];gaps=frame.get('fvg_candidates',[])
        origins=[]
        for point in points:
            state=_state(point,closed,now)
            if state['reclaim_known_at']:
                origins.append(('ERL_to_IRL',point,utc_time(state['reclaim_known_at']),-1 if point['kind']=='H' else 1,gaps))
        for gap in gaps:
            state=_gap_state(gap,closed,periods,now)
            if state['full_mitigation_known_at']:
                origins.append(('IRL_to_ERL',gap,utc_time(state['full_mitigation_known_at']),1 if gap['direction']=='bullish' else -1,points))
        for kind,source,origin,direction,targets in origins:
            if origin>now or origin not in closes:continue
            price=closes[origin]
            source_at=(_state(source,closed,origin) if kind=='ERL_to_IRL' else _gap_state(source,closed,periods,origin))
            if not source_at['closed_slot_coverage_complete'] or source_at.get('close_invalidation_known_at'):
                rejected['source_coverage_or_close_invalidation']+=1;continue
            for target in targets:
                if utc_time(target['available_at'])>origin:
                    rejected['target_not_available_at_origin']+=1;continue
                if kind=='ERL_to_IRL':
                    correct=target['direction']==('bullish' if direction==-1 else 'bearish')
                    reference=target['upper'] if direction==-1 else target['lower']
                    state_at=_gap_state(target,closed,periods,origin)
                    untouched=state_at['untouched'] is True and not state_at['close_invalidation_known_at']
                    frozen_target={k:target[k] for k in ('id','timeframe','direction','lower','upper','available_at')}
                    invalid=_gap_state(target,closed,periods,now)['close_invalidation_known_at']
                else:
                    correct=target['kind']==('H' if direction==1 else 'L')
                    reference=target['price'];state_at=_state(target,closed,origin)
                    untouched=state_at['not_revisited'] is True
                    frozen_target={k:target[k] for k in ('id','timeframe','kind','price','available_at')}
                    invalid=_gap_state(source,closed,periods,now)['close_invalidation_known_at']
                if not correct or direction*(reference-price)<=0:
                    rejected['target_direction_or_location']+=1;continue
                if not untouched:
                    rejected['target_visited_or_unknown_at_origin']+=1;continue
                frozen={'route':kind,'timeframe':timeframe,'source_id':source['id'],
                        'origin_known_at':origin.isoformat(),'origin_close':price,'direction':direction,
                        'target':frozen_target,'target_reference_price':reference}
                digest=hashlib.sha256(json.dumps(frozen,sort_keys=True,separators=(',',':')).encode()).hexdigest()
                observation=_observe(frozen_target,closed,origin,now)
                contact=observation['target_contact_known_at']
                invalid_first=invalid and (not contact or utc_time(invalid)<utc_time(contact))
                stage='source_or_target_close_invalidated' if invalid_first else 'target_observed' if contact else 'quote_path_unknown' if observation['missing_expected_m5'] else 'idea_pending_validation'
                routes.append({'id':digest[:24],'frozen_sha256':digest,**frozen,'stage':stage,
                               'observation':observation,'close_invalidation_known_at':invalid,
                               'source_state_at_origin':source_at,'target_state_at_origin':state_at,
                               'direction_confirmed':False,'selected_as_bias':False,'selected_as_dol':False,
                               'execution_allowed':False,'source_video_seconds':[629,794]})
    return {'as_of':now.isoformat(),'hypotheses':sorted(routes,key=lambda r:(r['origin_known_at'],r['id'])),
            'rejected_pair_counts':dict(rejected),'qualified_context':False,'execution_allowed':False,'orders_sent':0,
            'source_video':'research/ict_price_videos/bias_dol/integration.json',
            'engineering_choices':['Same-timeframe pairs only','Observed reclaim / far-edge contact as origin proxy',
                                   'Strict prior untouched target with complete assumed study-slot coverage',
                                   'Near edge of FVG as contact reference, no entry or outcome profitability'],
            'awaiting':['Directional delivery validation','Full daily/weekly narrative and higher-timeframe hierarchy',
                        'Historical clock, calendar and costs verification','Risk plan and execution qualification']}
