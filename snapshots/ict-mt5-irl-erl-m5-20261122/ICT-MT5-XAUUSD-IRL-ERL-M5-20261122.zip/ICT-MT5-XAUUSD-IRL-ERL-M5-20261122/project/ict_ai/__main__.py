import argparse
import json
from pathlib import Path
from .knowledge import evaluate, load_rules, search


def main():
    parser = argparse.ArgumentParser(description="ICT 来源检索与证据核对（研究工具，不下单）")
    commands = parser.add_subparsers(dest="command", required=True)
    profiles = commands.add_parser("profiles", help="列出每日或每周概况")
    profiles.add_argument("--scope", choices=["daily", "weekly"], default="daily")
    lookup = commands.add_parser("search", help="检索原文；多个词用空格分开")
    lookup.add_argument("query")
    lookup.add_argument("--limit", type=int, default=8)
    check = commands.add_parser("evaluate", help="按截止时间核对已提供的证据")
    check.add_argument("observations", type=Path)
    check.add_argument("--as-of", required=True)
    check.add_argument("--scope", choices=["daily", "weekly"], default="daily")
    args = parser.parse_args()
    if args.command == "profiles":
        rules = load_rules(scope=args.scope)
        output = {"profiles": rules["profiles"], "variants": rules["variants"]}
    elif args.command == "search":
        output = search(args.query, args.limit)
    else:
        output = evaluate(json.loads(args.observations.read_text(encoding="utf-8")), args.as_of, load_rules(scope=args.scope))
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
