"""Research-only PO3 context gate.

The gate separates observable A/M/D price-path evidence from the sourced
context required before a setup can be studied. It never creates an order.
"""
from datetime import datetime
from .knowledge import timestamp


def po3_research_gate(po3, context, as_of):
    """Return a causal context decision for one PO3 candidate.

    ``context`` fields use the same ``value/available_at/source`` contract as
    :func:`ict_ai.planning.research_plan`. HTF bias/PDA/DOL must be available
    before the observed M phase; clock and calendar must be verified by the
    current cutoff. A partial A/M path is never promoted to a research setup.
    """
    now = timestamp(as_of) if isinstance(as_of, str) else as_of
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError('Aware PO3 cutoff required')
    context = context or {}
    result = {
        'status': 'pending_context',
        'missing': [],
        'contradictions': [],
        'context_used': {},
        'execution_allowed': False,
        'orders_sent': 0,
        'model_trained': False,
        'research_only': True,
    }
    if not isinstance(po3, dict):
        result['missing'].append('po3_candidate')
        return result
    if po3.get('execution_allowed') is True or po3.get('actual_orders_observed') is True:
        result['contradictions'].append('PO3 metadata cannot authorize or claim observed orders')
    if po3.get('future_data_safe') is not True:
        result['contradictions'].append('PO3 phase evidence is not future-data safe')
    evidence = po3.get('phase_evidence') or {}
    known = {}
    for phase in ('A', 'M', 'D'):
        item = evidence.get(phase) or {}
        if item.get('status') != 'candidate':
            result['missing'].append('po3_' + phase + '_candidate')
        elif not item.get('available_at'):
            result['missing'].append('po3_' + phase + '_available_at')
        else:
            known[phase] = timestamp(item['available_at'])
            if known[phase] > now:
                result['missing'].append('po3_' + phase + ' (future)')
    if any(known[a] >= known[b] for a,b in (('A','M'),('M','D')) if a in known and b in known):
        result['contradictions'].append('PO3 phases are out of order')
    if po3.get('status') != 'candidate':
        result['missing'].append('po3_complete_A_M_D_path')
    m_cutoff = known.get('M', now)
    for key in ('htf_bias', 'htf_pda', 'dol', 'calendar_clear', 'clock_verified'):
        item = context.get(key)
        if not item or item.get('value') is None:
            result['missing'].append(key)
            continue
        if not isinstance(item.get('source'), str) or not item['source'].strip():
            raise ValueError('Context provenance required: ' + key)
        available_at = timestamp(item.get('available_at'))
        if available_at > now:
            result['missing'].append(key + ' (future)')
            continue
        if key in ('htf_bias', 'htf_pda', 'dol') and available_at > m_cutoff:
            result['missing'].append(key + ' (after M cutoff)')
            continue
        result['context_used'][key] = item
        if key in ('calendar_clear', 'clock_verified') and item['value'] is not True:
            result['contradictions'].append(key + ' is not verified')
    direction = po3.get('direction')
    bias = result['context_used'].get('htf_bias', {}).get('value')
    if direction in ('bullish', 'bearish') and bias in (-1, 1):
        expected = 1 if direction == 'bullish' else -1
        if bias != expected:
            result['contradictions'].append('PO3 direction conflicts with frozen HTF bias')
    result['status'] = 'ready_for_research' if not result['missing'] and not result['contradictions'] else 'pending_context'
    return result
