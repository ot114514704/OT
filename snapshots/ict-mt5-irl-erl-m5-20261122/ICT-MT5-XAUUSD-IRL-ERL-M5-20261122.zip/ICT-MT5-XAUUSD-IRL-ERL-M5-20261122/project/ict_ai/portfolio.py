"""Single-order replay with decisions based on realized, as-of account state."""
from dataclasses import asdict, replace
from datetime import timedelta
import math

from brooks_ai.risk import entry_allowed, size_volume
from .backtest import simulate_limit
from .timebase import NY


def replay_portfolio(templates, bars, spec, cutoff, initial_equity, risk_config, *,
                     period=timedelta(minutes=5), spread_multiplier=1.0):
    templates = tuple(templates)
    risk_fraction = risk_config["risk_fraction"]
    if not math.isfinite(initial_equity) or initial_equity <= 0 or not 0 < risk_fraction <= .01:
        raise ValueError("Require positive initial equity and risk fraction in (0, 1%]")
    if cutoff.tzinfo is None or cutoff.utcoffset() is None:
        raise ValueError("Portfolio replay requires an aware cutoff")
    if len({order.id for order in templates}) != len(templates):
        raise ValueError("Portfolio replay requires unique signal IDs")
    for key in ("max_drawdown", "daily_loss_limit"):
        if not 0 < risk_config[key] < 1:
            raise ValueError(f"Invalid portfolio risk limit {key}")
    if risk_config["max_consecutive_losses"] < 1:
        raise ValueError("Consecutive loss limit must be positive")
    equity = peak = day_start = initial_equity
    drawdown = 0.0
    consecutive_losses = 0
    current_day = None
    blocked_by_unknown = None
    active = None
    decisions, settled = [], []

    def settle(now):
        nonlocal active, equity, peak, drawdown, consecutive_losses, blocked_by_unknown
        if active is None:
            return None
        order, budget = active
        outcome = simulate_limit(order, bars, spec, now, period, spread_multiplier)
        status = outcome["status"]
        if status in ("pending", "open_censored_at_cutoff", "pending_censored_at_cutoff"):
            return outcome
        if status.startswith("censored"):
            # Unknown exposure can carry over to the next candidate. Do not
            # treat a missing quote as a broker cancellation or a flat book.
            blocked_by_unknown = order.id
        if status == "closed":
            pnl = outcome["pnl_net"]
            equity += pnl
            peak = max(peak, equity)
            drawdown = max(drawdown, (peak - equity) / peak)
            consecutive_losses = consecutive_losses + 1 if pnl < 0 else 0
        pnl = outcome["pnl_net"]
        settled.append({"outcome": outcome, "equity_after": equity, "risk_budget": budget,
                        "loss_exceeded_original_budget": None if pnl is None else -pnl > budget + 1e-8})
        active = None
        return outcome

    for template in sorted(templates, key=lambda item: (item.available_at, item.id)):
        known = template.available_at
        if known > cutoff:
            break
        settle(known)
        day = known.astimezone(NY).date()
        if day != current_day:
            day_start = equity
            current_day = day
        record = {"id": template.id, "available_at": known.isoformat(),
                  "realized_equity_before": equity, "day_start_equity": day_start,
                  "consecutive_losses_before": consecutive_losses}
        decisions.append(record)
        if blocked_by_unknown is not None:
            record.update(status="blocked_by_unknown_exposure", blocking_order=blocked_by_unknown)
            continue
        if active is not None:
            record.update(status="blocked_by_existing_order", blocking_order=active[0].id)
            continue
        allowed, reason = entry_allowed(equity, peak, day_start, risk_config, consecutive_losses)
        if not allowed:
            record.update(status="blocked_by_risk_limit", reason=reason)
            continue
        loss_per_lot = ((abs(template.entry - template.stop) + 2 * spec.slippage)
                        * spec.contract_size + spec.commission_round_turn)
        budget = equity * risk_fraction
        volume = size_volume(budget, loss_per_lot, spec)
        if not volume:
            record.update(status="minimum_size_exceeds_budget", risk_budget=budget)
            continue
        order = replace(template, volume=volume)
        active = (order, budget)
        record.update(status="accepted", risk_budget=budget, estimated_stop_risk=volume * loss_per_lot,
                      order=asdict(order))

    remaining = settle(cutoff)
    return {
        "initial_equity": initial_equity, "final_realized_equity": equity,
        "max_realized_drawdown_fraction": drawdown, "decisions": decisions, "completed": settled,
        "active_at_cutoff": remaining if active is not None else None,
        "active_risk_budget_at_cutoff": active[1] if active is not None else None,
        "unknown_exposure_order": blocked_by_unknown,
        "risk_limits": dict(risk_config), "orders_sent": 0, "execution_allowed": False,
    }
