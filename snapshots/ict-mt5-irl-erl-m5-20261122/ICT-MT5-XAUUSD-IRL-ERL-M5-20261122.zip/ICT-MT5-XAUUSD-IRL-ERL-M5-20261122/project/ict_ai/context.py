"""Causal HTF price evidence, separate from a qualified directional plan.

ICT 精翻 physical pp.119,135–136,184–185,239–242. A pair of confirmed
swings is a research range candidate, not proof that both liquidity sides were
taken. Premium/discount alone never generates a verified HTF bias or DOL.
"""
from datetime import timedelta
import hashlib
from brooks_ai.types import utc_time
from .features import geometric_fvgs


def confirmed_swings(bars,period,as_of,radius=1):
    if period<=timedelta(0) or as_of.tzinfo is None or radius<1:
        raise ValueError('Aware cutoff, positive period and pivot width required')
    if any(a.time>=b.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Strictly chronological bars required')
    closed=[b for b in bars if b.time+period<=as_of]
    points=[]
    for i in range(radius,len(closed)-radius):
        window=closed[i-radius:i+radius+1]
        if any(a.time+period!=b.time for a,b in zip(window,window[1:])):continue
        center=closed[i];others=[b for j,b in enumerate(window) if j!=radius]
        for kind,price,valid in [('H',center.high,all(center.high>b.high for b in others)),
                                 ('L',center.low,all(center.low<b.low for b in others))]:
            if not valid:continue
            key=f'{period.total_seconds()}|{center.time.isoformat()}|{kind}'
            known=window[-1].time+period
            later=[b for b in closed if b.time>=known]
            first=next((b for b in later if b.high>=price),None) if kind=='H' else next((b for b in later if b.low<=price),None)
            points.append({'id':hashlib.sha256(key.encode()).hexdigest()[:20], 'kind':kind,'price':price,
                           'anchor_time':center.time.isoformat(),'available_at':known.isoformat(),
                           'price_revisited_after_confirmation':first is not None,
                           'first_observed_revisit_known_at':(first.time+period).isoformat() if first else None,
                           'source_pages':[185,239,240],'pivot_radius':radius})
    return points


def htf_snapshot(bars,period,as_of,timeframe,radius=1,max_anchor_bars=64):
    """Freeze anchors at confirmation; attach state observed by this cutoff.

    The latest two opposite confirmed swings are an engineering range choice.
    Full FVG wick mitigation and close invalidation remain separate observations.
    Unknown paths across missing buckets prevent a claim of untouched liquidity.
    """
    if max_anchor_bars<2 or not timeframe:raise ValueError('Timeframe and anchor span required')
    swings=confirmed_swings(bars,period,as_of,radius)
    closed=[b for b in bars if b.time+period<=as_of]
    result={'timeframe':timeframe,'as_of':as_of.isoformat(),'bars':len(closed),'range':None,
            'fvg_candidates':[],'external_level_candidates':[],'bias_value':None,'dol_value':None,
            'qualified_context':False,'source_pages':[89,90,119,135,136,184,185,239,240,241,242],
            'engineering_choices':['Latest opposite confirmed swing anchors',f'Pivot radius {radius}',f'Maximum anchor span {max_anchor_bars} bars'],
            'limitations':['Range candidate is not automatic proof of a source-defined dealing range',
                           'Price geometry cannot establish institutional intent',
                           'No verified directional bias or DOL selection is inferred from location alone']}
    if not closed:return result
    result.update(last_closed_at=(closed[-1].time+period).isoformat(),last_close=closed[-1].close)
    by_kind={}
    for point in swings:by_kind[point['kind']]=point
    high,low=by_kind.get('H'),by_kind.get('L')
    if high and low and low['price']<high['price']:
        earliest=min(utc_time(high['anchor_time']),utc_time(low['anchor_time']))
        anchor_indices=[i for i,b in enumerate(closed) if b.time>=earliest]
        contiguous=all(a.time+period==b.time for a,b in zip(closed[anchor_indices[0]:],closed[anchor_indices[0]+1:]))
        if len(anchor_indices)<=max_anchor_bars and contiguous:
            eq=(low['price']+high['price'])/2;price=closed[-1].close
            position='below_range' if price<low['price'] else 'above_range' if price>high['price'] else 'discount' if price<eq else 'premium' if price>eq else 'equilibrium'
            result['range']={'id':high['id']+'-'+low['id'],'low':low['price'],'high':high['price'],
                             'equilibrium':eq,'high_anchor':high,'low_anchor':low,
                             'available_at':max(utc_time(high['available_at']),utc_time(low['available_at'])).isoformat(),
                             'position_at_cutoff':position,'position_known_at':result['last_closed_at'],
                             'source_pages':[119,184,185],'source_definition_confirmed':False}
    fvgs=geometric_fvgs(closed,period,as_of)
    for gap in fvgs:
        known=utc_time(gap['available_at']);later=[b for b in closed if b.time>=known]
        touched=next((b for b in later if b.low<=gap['upper'] and b.high>=gap['lower']),None)
        bullish=gap['direction']=='bullish'
        fully=next((b for b in later if b.low<=gap['lower']<=b.high),None) if bullish else next((b for b in later if b.low<=gap['upper']<=b.high),None)
        invalid=next((b for b in later if b.close<gap['lower']),None) if bullish else next((b for b in later if b.close>gap['upper']),None)
        formation=next(i for i,b in enumerate(closed) if b.time+period==known)
        trail=closed[formation:]
        coverage=all(a.time+period==b.time for a,b in zip(trail,trail[1:])) and as_of-(closed[-1].time+period)<period
        eq=result['range']['equilibrium'] if result['range'] else None
        location=None if eq is None else 'discount' if gap['upper']<eq else 'premium' if gap['lower']>eq else 'straddles_equilibrium'
        result['fvg_candidates'].append({**gap,'timeframe':timeframe,
                                        'observed_touch':touched is not None,'observed_full_wick_mitigation':fully is not None,
                                        'observed_close_invalidation':invalid is not None,
                                        'touch_known_at':(touched.time+period).isoformat() if touched else None,
                                        'full_mitigation_known_at':(fully.time+period).isoformat() if fully else None,
                                        'invalidation_known_at':(invalid.time+period).isoformat() if invalid else None,
                                        'continuous_quote_coverage_since_formation':coverage,
                                        'untouched':not touched if coverage else None,
                                        'current_range_location':location,
                                        'range_location_known_at':as_of.isoformat(),
                                        'qualified_pda':False})
    for point in swings:
        known=utc_time(point['available_at']);tail=[b for b in closed if b.time+period>=known]
        coverage=all(a.time+period==b.time for a,b in zip(tail,tail[1:])) and as_of-(closed[-1].time+period)<period
        not_revisited=not point['price_revisited_after_confirmation'] if coverage else None
        if (point['kind']=='H' and point['price']>closed[-1].close) or (point['kind']=='L' and point['price']<closed[-1].close):
            result['external_level_candidates'].append({**point,'liquidity_side_proxy':'BSL' if point['kind']=='H' else 'SSL',
                                                       'not_revisited':not_revisited,'coverage_complete':coverage,
                                                       'selected_as_dol':False,'actual_stop_orders_observed':False})
    return result
