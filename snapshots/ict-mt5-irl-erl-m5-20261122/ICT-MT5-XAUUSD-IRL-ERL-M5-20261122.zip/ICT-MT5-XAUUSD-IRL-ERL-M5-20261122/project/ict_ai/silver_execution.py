"""Causal Silver Bullet observations and an entry-time gate for research fills.

时间（四）PPT 7/9/14/24/25/29/30: an already confirmed PDA may be reused;
the actual entry belongs inside a NY window. Geometry/time alone is not an
ICT setup. These functions do not select HTF bias, DOL, a stop or order size.
"""
from dataclasses import replace
from datetime import datetime, timedelta, timezone
import hashlib

from brooks_ai.types import utc_time
from .backtest import simulate_limit
from .features import geometric_fvgs
from .silver_bullet import silver_bullet_windows
from .timebase import NY


def silver_fvg_visits(bars, period, as_of, max_age=timedelta(hours=48)):
    """First observed visit per FVG/window, known at the visiting bar's CLOSE.

    A 48-hour lookback and rejection after a far-edge close are engineering
    choices. Prior touches do not delete a zone. Partial window overlaps and
    missing quotes remain explicit uncertainty, never exact entry timestamps.
    """
    if as_of.tzinfo is None or not timedelta(0) < period <= timedelta(hours=1) or max_age <= timedelta(0):
        raise ValueError('Aware cutoff, period up to one hour and positive lookback required')
    gaps = geometric_fvgs(bars, period, as_of)
    formed = {}
    for gap in gaps:
        known = utc_time(gap['available_at'])
        formed.setdefault(known, []).append(gap)
    active = []; events = []; seen = set(); previous = None
    for b in bars:
        end = b.time + period
        if end > as_of:
            break
        active = [s for s in active if b.time-s['known'] <= max_age and not s['invalid']]
        windows = silver_bullet_windows(b.time.astimezone(NY).date())
        for state in active:
            gap = state['gap']
            if previous is None or previous.time+period != b.time:
                state['coverage'] = False
            touched = b.low <= gap['upper'] and b.high >= gap['lower']
            invalid = b.close < gap['lower'] if gap['direction'] == 'bullish' else b.close > gap['upper']
            if touched:
                for window in windows:
                    start = datetime.fromtimestamp(window['start_ms']/1000, timezone.utc)
                    finish = datetime.fromtimestamp(window['end_ms']/1000, timezone.utc)
                    if end <= start or b.time >= finish:
                        continue
                    key = (state['id'], start)
                    if key in seen:
                        continue
                    seen.add(key)
                    inside = start <= b.time and end <= finish
                    events.append({
                        'id': state['id']+'-'+start.isoformat(), 'kind': 'silver_fvg_price_visit',
                        'side': 1 if gap['direction'] == 'bullish' else -1,
                        'pda': gap, 'window': window, 'ny_date': start.astimezone(NY).date().isoformat(),
                        'visit_bar_open': b.time.isoformat(), 'available_at': end.isoformat(),
                        'possible_visit_interval': [b.time.isoformat(), end.isoformat()],
                        'interval_end_exclusive': True, 'exact_trigger_time': None,
                        'whole_bar_inside_window': inside,
                        'timing_status': 'whole_bar_inside' if inside else 'ambiguous_window_boundary',
                        'pda_confirmed_before_window': state['known'] < start,
                        'pda_confirmed_by_window_open': state['known'] <= start,
                        'prior_observed_touch_bars': state['touches'],
                        'continuous_quotes_since_confirmation': state['coverage'],
                        'far_edge_close_on_visit_bar': invalid,
                        'source_ppt_slides': [7,9,14,24,25,29,30],
                        'signal_qualified': False, 'execution_allowed': False,
                        'missing_context': ['frozen HTF bias/PDA/DOL and daily/weekly narrative',
                                            'verified clock/calendar and executable bid/ask path',
                                            'pre-existing order, protective stop and cost-aware risk size']})
                state['touches'] += 1
            state['invalid'] = invalid
        # Add only AFTER examining this bar: a third formation candle cannot
        # serve as a visit to the FVG that becomes known at its own close.
        for gap in formed.get(end, []):
            key = f"{period.total_seconds()}|{gap['available_at']}|{gap['direction']}"
            active.append({'id': hashlib.sha256(key.encode()).hexdigest()[:20], 'gap': gap,
                           'known': end, 'touches': 0, 'coverage': True, 'invalid': False})
        previous = b
    return events


def simulate_silver_limit(order, pda_available_at, bars, spec, as_of, day, window_id,
                          period=timedelta(minutes=5), spread_multiplier=1.0):
    """Apply a PRESELECTED NY entry window to an existing frozen research order.

    The order is staged until window start and expires at window end. Position
    exits may occur later. A window and PDA must be selected before replaying
    outcomes; this gate never chooses a profitable window from future prices.
    """
    known = utc_time(pda_available_at)
    if known > order.available_at:
        raise ValueError('PDA was not confirmed when the research order was prepared')
    windows = silver_bullet_windows(day)
    window = next((w for w in windows if w['id'] == window_id), None)
    if window is None:
        raise ValueError('A weekday and one of the three source-defined windows are required')
    if as_of.tzinfo is None or not timedelta(0) < period <= timedelta(hours=1) or 3600 % period.total_seconds():
        raise ValueError('Aware cutoff and a whole-hour-dividing period up to one hour required')
    start = datetime.fromtimestamp(window['start_ms']/1000, timezone.utc)
    end = datetime.fromtimestamp(window['end_ms']/1000, timezone.utc)
    active_at = max(order.available_at, start)
    expires_at = min(order.expires_at, end)
    meta = {'window': window, 'order_prepared_at': order.available_at.isoformat(),
            'pda_available_at': known.isoformat(), 'entry_active_at': active_at.isoformat(),
            'entry_expires_at': expires_at.isoformat(), 'whole_entry_interval_in_window': None,
            'exact_recorded_fill_time': None, 'source_ppt_slides': [7,9,14,24,25,29,30],
            'full_ict_strategy_qualified': False}
    if active_at >= expires_at:
        return {'order_id': order.id, 'status': 'no_active_silver_interval', 'filled': False,
                'pnl_net': None, 'silver': meta, 'execution_allowed': False, 'orders_sent': 0}
    seconds = period.total_seconds()
    if active_at.timestamp() % seconds or expires_at.timestamp() % seconds or any(b.time.timestamp() % seconds for b in bars):
        raise ValueError('Partial-bar activation/expiry requires finer quotes; cannot infer an intrabar entry')
    effective = replace(order, available_at=active_at, expires_at=expires_at)
    result = simulate_limit(effective, bars, spec, as_of, period, spread_multiplier)
    if result['filled']:
        first = utc_time(result['entry_bar_open'])
        # simulate_limit only reports a fill after the full bar has closed.
        meta['possible_entry_interval'] = [first.isoformat(), (first+period).isoformat()]
        meta['interval_end_exclusive'] = True
        meta['whole_entry_interval_in_window'] = start <= first and first+period <= end
        if not meta['whole_entry_interval_in_window']:
            raise AssertionError('Silver entry escaped the frozen window')
    result['silver'] = meta
    return result
