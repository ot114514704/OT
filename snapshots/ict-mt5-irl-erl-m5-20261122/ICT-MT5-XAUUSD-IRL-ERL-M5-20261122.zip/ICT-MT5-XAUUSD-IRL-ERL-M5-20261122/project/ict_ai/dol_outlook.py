"""Conditional DOL scenarios (bias/DOL course 267–404, 629–794, 932–1058s)."""
from datetime import datetime, timedelta
from dataclasses import dataclass
from bisect import bisect_left
from statistics import median
from math import sqrt
from functools import lru_cache
from pathlib import Path
import json

from .daily_context import daily_weekly_context
from .features import geometric_fvgs
from .range_liquidity import _Coverage
from .regular_liquidity import regular_liquidity
from .session_path import VENUES, hours, covered, et_clock_text, displacement, local_structure, previous_session
from .silver_bullet import silver_bullet_windows
from .timebase import NY, session_windows

M5=timedelta(minutes=5)
H1=timedelta(hours=1)


@lru_cache(maxsize=1)
def _contact_model():
    return json.loads(Path(__file__).with_name('dol_contact_calibration.json').read_text(encoding='utf-8'))


def low_score_history(score,distance,h1_width,at):
    """Conditional contact estimate, kept separate from the priority ranking."""
    if score>=50 or h1_width<=0:
        return ''
    model=_contact_model()
    if at.astimezone(NY).date().isoformat()<model['available_from_ny']:
        return ''
    band=score//10*10
    cells=model['cells']
    group=cells.get(str(band))
    if not group:
        return ''
    ratio=distance/h1_width
    bucket=next((str(n) for n in (1,2,4) if ratio<=n),'far')
    cell=cells.get(f'{band}/{bucket}')
    prior=(group['hits']+1)/(group['n']+2)
    basis=f'历史 {band}–{band+9} 分档'
    if cell and cell['n']>=model['minimum_targets'] and cell['weeks']>=model['minimum_weeks']:
        ranges={'1':'≤1','2':'1–2','4':'2–4','far':'>4'}
        basis+=f' · 距离 {ranges[bucket]} 个 H1 波幅'
        weight=model['smoothing']
        rate=(cell['hits']+weight*prior)/(cell['n']+weight)
    else:
        basis+=' · 同距离样本不足，参考全档'
        cell,rate=group,prior
    return f'{basis} · 期限内触达 {cell["hits"]}/{cell["n"]} 次，平滑估计 {rate:.1%}（训练截至美东 2026-03-31）'


def remaining_gap(gap, bars):
    """One continuous residual, evidenced by closed M5 ranges after formation.

    A quote jump can land inside an imbalance without visiting its near edge.
    Withhold that fragmented target until the ranges join. A visit to, or a
    jump past, the far edge retires the directional target in either case.
    """
    lower,upper=gap['lower'],gap['upper']
    bull=gap['direction']=='bullish'
    contacts=[]
    for bar in bars:
        if (bull and bar.low<=lower) or (not bull and bar.high>=upper):
            return None
        left,right=max(bar.low,lower),min(bar.high,upper)
        if left<=right:
            contacts.append((left,right))
    if not contacts:
        return lower,upper
    # Walk from the entry edge toward the far edge, merging overlapping wicks.
    edge=upper if bull else lower
    for left,right in sorted(contacts,key=lambda r:r[1] if bull else r[0],reverse=bull):
        if (bull and right<edge) or (not bull and left>edge):
            return None
        edge=min(edge,left) if bull else max(edge,right)
    return (lower,edge) if bull else (edge,upper)

@dataclass(frozen=True)
class PeerEvidence:
    confirmed: datetime
    title: str
    direction: int
    ended: datetime | None
    end_reason: str


def peer_evidence(peers, start, at):
    active = {}
    observations = []
    for row in sorted(peers, key=lambda item: item.confirmed):
        if not start < row.confirmed <= at:
            continue
        if row.ended is not None and row.ended <= at:
            observations.append(f'{row.title} · {row.end_reason}')
        else:
            observations.append(row.title)
            active[row.title] = row.direction
    return list(dict.fromkeys(observations)), list(active.items())


def outlook(m5,h1,m15,now,profile,po3,peers,*,releases=(),judas=(),ranked=None,nearby_priority=False):
    closed=[b for b in m5 if b.time+M5<=now]
    if not closed:return []
    at=closed[-1].time+M5
    price=closed[-1].close
    context=daily_weekly_context(closed,at)
    coverage=_Coverage(closed[0].time,at,closed,M5)
    targets={}
    stamps=[b.time for b in closed]
    gap_details={}
    def pool(tag,p,side,known):
        if side*(p-price)<=0 or not coverage.complete(known):return
        if any((b.high>=p if side==1 else b.low<=p) for b in closed if b.time>=known):return
        targets.setdefault((side,p,p),[]).append(tag)
    gaps=[]
    for tf,frame in context['frames'].items():
        if frame['periods']:
            p=frame['periods'][-1];known=datetime.fromisoformat(p['available_at'])
            pool(tf+' 已收高',p['high'],1,known);pool(tf+' 已收低',p['low'],-1,known)
        for t in frame['dol_candidates']:
            pool(tf+' 摆动'+('高' if t['kind']=='H' else '低'),t['price'],t['direction_from_current_price'],datetime.fromisoformat(t['available_at']))
        gaps.extend((tf,g) for g in frame['fvg_candidates'] if g['state'] in ('untouched','touched') and not g['observed_price_beyond_far_edge'])
    h1=[b for b in h1 if b.time+H1<=at]
    gaps.extend(('H1',g) for g in geometric_fvgs(h1[-240:],H1,at))
    recent15=[b for b in m15 if b.time+3*M5<=at][-96:]
    gaps.extend(('M15',g) for g in geometric_fvgs(recent15,3*M5,at))
    for tf,g in gaps:
        known=datetime.fromisoformat(g['available_at'])
        if known<closed[0].time or not coverage.complete(known):continue
        remainder=remaining_gap(g,closed[bisect_left(stamps,known):])
        if remainder is None:continue
        lo,hi=remainder
        side=1 if lo>price else -1 if hi<price else 0
        if side:
            key=(side,lo,hi)
            targets.setdefault(key,[]).append(tf+' FVG 剩余区')
            direction='看涨' if g['direction']=='bullish' else '看跌'
            gap_details.setdefault(key,[]).append(
                f'{tf} {direction} FVG · 美东 {known.astimezone(NY):%m-%d %H:%M} 形成，'
                f'原区 {g["lower"]:.2f}–{g["upper"]:.2f}，M5 剩余 {lo:.2f}–{hi:.2f}')
    day=(at-timedelta(microseconds=1)).astimezone(NY).date()
    for t in regular_liquidity(m15,closed,day,at)['levels']:
        if t['untouched'] is True:
            pool(t['source_scope'],t['price'],1 if t['side']=='buy_side_proxy' else -1,
                 datetime.fromisoformat(t['level_available_at']))
    sessions=[]
    for offset in range(-4,2):
        d=day+timedelta(days=offset)
        if d.weekday()>=5:continue
        for v in VENUES:
            a,z=hours(d,v)
            if a>=at:continue
            part=[b for b in closed if a<=b.time<z]
            if not part:continue
            sessions.append((a,z,v[1],part))
            if z<=at and covered(part,a,z):
                pool(v[1]+' 盘高',max(b.high for b in part),1,z)
                pool(v[1]+' 盘低',min(b.low for b in part),-1,z)
    sessions.sort(key=lambda item:item[0])
    notes=[];session_side=None
    if len(sessions)>=2:
        a,z,tag,part=sessions[-1];p,q,old,prior=sessions[-2]
        check_end=min(z,at);path=[b for b in part if b.time>=max(a,q)]
        notes.append(tag+' 对前盘 · '+previous_session(part,a,check_end,prior,p,q,old))
        if path and covered(prior,p,q) and covered(path,max(a,q),check_end):
            session_side=1 if path[-1].close>max(b.high for b in prior) else -1 if path[-1].close<min(b.low for b in prior) else None
    w=profile['weekly_background'];weekly=w.get('scenario_direction')
    notes.extend([profile['profile_label']+' · '+profile['profile_reason'],w['label']+' · '+w['reason']])
    phase=po3['phase_evidence']['D']['status']
    direction={'bullish':1,'bearish':-1}.get(po3.get('direction')) if phase=='candidate' else None
    if direction and po3['zones'][-1]['end']!=at.isoformat():
        if datetime.fromisoformat(po3['zones'][-1]['end'])+timedelta(minutes=15)<=at:direction=None
    notes.append('跨盘 AMD · '+po3['reason'])
    recent=[b for b in closed if at-H1<=b.time]
    warm=[b for b in closed if at-3*H1<=b.time<at-H1]
    strength,impulse=displacement(recent,warm)
    notes.extend([strength,local_structure(recent,warm)])
    smt,active_smt=peer_evidence(peers,at-4*H1,at)
    notes.append('H1 SMT · '+('、'.join(smt) or '近4小时无新确认记录'))
    clock=now.astimezone(NY).date()
    windows=[]
    for offset in range(5):
        d=clock+timedelta(days=offset)
        if d.weekday()>=5:continue
        for k,(a,z) in session_windows(d).items():
            windows.append((a,z,{'asia':'亚洲','london':'伦敦','new_york':'纽约','london_close':'伦敦收盘'}[k]+' KZ'))
        for win in silver_bullet_windows(d):
            a,z=(datetime.fromtimestamp(win[k]/1000,NY) for k in ('start_ms','end_ms'))
            windows.append((a,z,win['label']))
    clocks=sorted((a,z,label) for a,z,label in windows if z>now)
    notes.append('时间过滤 · '+'、'.join(f'{label} {a.astimezone(NY):%m-%d %H:%M}–{z.astimezone(NY):%H:%M} NY'
                                    for a,z,label in clocks[:4]))
    out=[('dol_context',at,at,'｜'.join(notes),price,price)]
    forecasts=[]
    last_hours=[b.high-b.low for b in h1[-24:] if b.high>b.low]
    typical=median(last_hours) if last_hours else max(b.high for b in recent)-min(b.low for b in recent)
    boundary=datetime.combine(day,datetime.min.time(),NY)+timedelta(hours=17 if day.weekday()==4 else 24)
    remaining=max(1/12,min(4,(boundary-at).total_seconds()/3600))
    active_windows=[label for a,z,label in windows if a<=at<z]
    upcoming=[(t,name) for t,name in releases if at<=t<=at+timedelta(hours=remaining)]
    news='、'.join(name for _,name in upcoming[:3])
    active_j=[e for e in judas if at-H1<=e['known']<=at and not any(
        (b.low<e['edge'] if e['side']==1 else b.high>e['edge']) for b in recent if b.time>=e['known'])]
    direction_votes={c.get('direction') for c in profile.get('candidates',[]) if c.get('observed_sequence') and c.get('status')=='active'}
    daily=next(iter(direction_votes)) if len(direction_votes)==1 else None
    for side,tag in ((1,'上方'),(-1,'下方')):
        choices=sorted((abs((lo if side==1 else hi)-price),lo,hi,names)
                       for (s,lo,hi),names in targets.items() if s==side)
        factors=[('周型',weekly),('有效 D',direction),('位移',impulse),('盘间收破',session_side)]
        factors.extend(active_smt)
        sides=[s for _,s in factors if s in (-1,1)]
        state=('证据相冲' if side in sides and -side in sides else
               '同向依据较多' if len(sides)>=2 and all(v==side for v in sides) else
               '逆当前证据' if -side in sides else '待更多确认')
        trigger=('扫低收回后向上收破摆动高' if side==1 else '扫高收回后向下收破摆动低')
        factors.append(('日型',daily))
        if active_j: factors.append(('犹大摆动',active_j[-1]['side']))
        aligns='、'.join(dict.fromkeys(k for k,s in factors if s==side)) or '待确认'
        against='、'.join(dict.fromkeys(k for k,s in factors if s==-side)) or '暂无'
        def vote(values):
            return max(-1,min(1,sum(v for v in values if v in (-1,1))))*side
        # Cap correlated observations (e.g. the Judas displacement and AMD D).
        alignment=18+5*vote([weekly,daily])+7*vote([direction,impulse,active_j[-1]['side'] if active_j else None])+3*vote([session_side])+3*vote([v for _,v in active_smt])
        edges=sorted(set(c[0] for c in choices))
        for dist,lo,hi,names in choices:
            names=list(dict.fromkeys(names))
            reach=round(35/(1+dist/max(.01,typical*sqrt(remaining))))
            quality=8+min(5,2*(len(names)-1))+ (5 if any(n.startswith(('D1','W1')) for n in names) else 2)
            timing=5 if active_windows and impulse==side else 2 if active_windows else 0
            obstacle=11-min(11,2*edges.index(dist))
            score_components = dict(reach=reach, alignment=alignment, quality=quality,
                                    timing=timing, obstacle=obstacle)
            # Threshold fixed in the discovery sample; use only already closed H1s.
            if nearby_priority:
                score_components['nearby'] = 12 if last_hours and dist == edges[0] and dist <= typical / 4 else 0
            score=min(100,max(0,sum(score_components.values())))
            reason=f'距离 {dist:.2f}；同向 {aligns}；反向 {against}；近端有 {edges.index(dist)} 层目标'
            if score_components.get('nearby'):
                reason+=f'；同侧最近且距离≤H1波幅中位数¼（{typical / 4:.2f}），加12分，总分封顶100'
            if nearby_priority and last_hours:
                historical=low_score_history(score,dist,typical,at)
                if historical:reason+='；'+historical
            if (side,lo,hi) in gap_details:
                reason+='；'+'；'.join(dict.fromkeys(gap_details[(side,lo,hi)]))
            if active_windows: reason+='；'+ '/'.join(active_windows)
            if news: reason+='；待公布 '+news+'，方向待观察'
            forecasts.append(dict(score=score,side=side,lo=lo,hi=hi,distance=dist,source='/'.join(names),
                                  reason=reason,trigger=trigger,score_components=score_components))
    forecasts.sort(key=lambda p:(-p['score'],p['distance'],p['lo'],p['hi']))
    for rank,p in enumerate(forecasts,1):
        p['rank']=rank
        label=f"{rank}. {p['score']}/100 {'上' if p['side']==1 else '下'} · {p['source']}｜{p['reason']}；观察{p['trigger']}"
        out.append(('dol_up' if p['side']==1 else 'dol_down',at,at,label,p['lo'],p['hi']))
    if ranked is not None:ranked.extend(forecasts)
    return out
