"""Research-only limit-order replay on an ordered Bid/Ask stream."""
from datetime import datetime, time, timedelta

from .timebase import NY


def simulate_tick_limit(order, ticks, spec, as_of, max_gap=timedelta(seconds=60)):
    """Evaluate one frozen intraday order against observed quotes.

    Quote touches stand in for fills; liquidity and queue priority are
    unobserved. The first adverse quote supplies the stop exit before the
    assumed slippage. Equal quote timestamps retain recorded input order.
    """
    if as_of.utcoffset() is None or max_gap <= timedelta(0):
        raise ValueError("An aware cutoff and positive quote-gap bound are required")
    if spec.account_currency != spec.profit_currency:
        raise ValueError("Historical FX conversion is not implemented")
    if not spec.volume_min <= order.volume <= spec.volume_max or abs(
            order.volume / spec.volume_step - round(order.volume / spec.volume_step)) > 1e-7:
        raise ValueError("Volume outside instrument grid")
    if any(a.time > b.time for a, b in zip(ticks, ticks[1:])):
        raise ValueError("Keep recorded quote order")
    result = {"order_id": order.id, "status": "not_yet_available", "filled": False, "pnl_net": None,
              "intrabar_spread_assumed_constant": False, "limit_queue_and_liquidity_verified": False,
              "source_costs_verified": spec.costs_verified, "orders_sent": 0, "execution_allowed": False}
    if as_of < order.available_at:
        return result
    day = order.available_at.astimezone(NY).date()
    flat = datetime.combine(day, time(order.flat_ny_hour, order.flat_ny_minute), NY)
    expiry = min(flat, order.expires_at)
    if expiry <= order.available_at:
        raise ValueError("Order has no active intraday interval")
    previous = order.available_at
    entry = None
    side = order.side
    for tick in ticks:
        if tick.time < order.available_at:
            continue
        if tick.time > as_of:
            break
        pending_end = min(tick.time, expiry) if entry is None else tick.time
        if pending_end - previous > max_gap:
            break
        if entry is None and tick.time >= expiry:
            break
        previous = tick.time
        executable_entry = tick.ask if side == 1 else tick.bid
        executable_exit = tick.bid if side == 1 else tick.ask
        if entry is None:
            if side * (executable_entry - order.entry) > 0:
                continue
            entry = executable_entry
            result.update(filled=True, entry=entry, entry_known_at=tick.time.isoformat(),
                          entry_bid=tick.bid, entry_ask=tick.ask)
        if tick.time >= flat:
            reason, exit_price = "intraday_flatten", executable_exit - side * spec.slippage
        elif side * (executable_exit - order.stop) <= 0:
            reason, exit_price = "stop", executable_exit - side * spec.slippage
        elif side * (executable_exit - order.target) >= 0:
            reason, exit_price = "target", order.target
        else:
            continue
        gross = side * (exit_price - entry) * spec.contract_size * order.volume
        commission = spec.commission_round_turn * order.volume
        units = spec.contract_size * order.volume
        entry_spread = (result["entry_ask"] - result["entry_bid"]) * units / 2
        exit_spread = (tick.ask - tick.bid) * units / 2
        midpoint_move = side * ((tick.bid + tick.ask) - (result["entry_bid"] + result["entry_ask"])) * units / 2
        exit_adjustment = side * (executable_exit - exit_price) * units
        return {**result, "status": "closed", "reason": reason, "exit": exit_price,
                "outcome_available_at": tick.time.isoformat(), "exit_bid": tick.bid, "exit_ask": tick.ask,
                "pnl_gross": gross, "commission": commission, "pnl_net": gross - commission,
                "cost_breakdown": {"midpoint_move_pnl": midpoint_move, "entry_half_spread": entry_spread,
                                   "exit_half_spread": exit_spread,
                                   "modeled_exit_slippage": exit_adjustment if reason!="target" else 0.,
                                   "foregone_target_improvement": exit_adjustment if reason=="target" else 0.,
                                   "assumed_commission": commission}}
    required = min(as_of, expiry) if entry is None else as_of
    if required - previous > max_gap:
        status = "censored_quote_gap" if entry is not None else "censored_pending_quote_gap"
    elif entry is not None:
        status = "open_censored_at_cutoff"
    elif as_of >= expiry:
        status = "cancelled_session_end" if flat <= order.expires_at else "expired"
    else:
        status = "pending"
    return {**result, "status": status}
