"""Source-linked weekly review geometry. Not a predictive trade classifier.

Daily extremes may move until the day ends; the connecting line is retrospective.
Sweep markers require a previously frozen, complete NY-day reference and a later
closed-bar return. Price evidence does not establish actual stop orders.
"""
from datetime import datetime, time, timedelta, timezone
from .timebase import NY
from .liquidity import closed_day_references
from .range_liquidity import _m5_reference_day
from .profile_sources import profile_source, WEEKLY


def consolidation_evidence(daily):
    """Research geometry shared by live and retrospective weekly candidates.

    The video says an obvious range but gives no numerical threshold. These
    overlap/union thresholds are explicit engineering choices, not source law.
    Callers must first freeze complete source days at their information cutoff.
    """
    if len(daily)<3:
        return {'matched':False,'reason':'至少需要三个已冻结完整日范围'}
    high=max(d['high'] for d in daily);low=min(d['low'] for d in daily)
    width=high-low;largest=max(d['high']-d['low'] for d in daily)
    overlap=min(d['high'] for d in daily)-max(d['low'] for d in daily)
    overlap_ratio=overlap/width if width>0 else None
    union_ratio=width/largest if largest>0 else None
    return {'matched':bool(width>0 and overlap_ratio>=.2 and union_ratio<=1.5),
            'high':high,'low':low,'overlap_ratio':overlap_ratio,'union_to_largest_day_ratio':union_ratio,
            'engineering_thresholds':{'minimum_overlap_ratio':.2,'maximum_union_to_largest_day_ratio':1.5},
            'source_provided_numeric_threshold':False}


def weekly_path(bars, days, as_of, period=timedelta(minutes=5)):
    if period <= timedelta(0) or as_of.tzinfo is None:
        raise ValueError('Positive period and aware cutoff required')
    if any(a.time >= b.time for a, b in zip(bars, bars[1:])):
        raise ValueError('Unique chronological bars required')
    points, sweeps, daily, ambiguous = [], [], [], []
    for day in days:
        start = datetime.combine(day, time(0), NY).astimezone(timezone.utc)
        finish = datetime.combine(day + timedelta(days=1), time(0), NY).astimezone(timezone.utc)
        if day.weekday() == 4:
            finish = datetime.combine(day, time(17), NY).astimezone(timezone.utc)
        part = [b for b in bars if start <= b.time < finish and b.time + period <= as_of]
        if not part:
            continue
        high, low = max(part, key=lambda b: b.high), min(part, key=lambda b: b.low)
        ended = as_of >= finish
        daily.append({'date': day.isoformat(), 'open': part[0].open, 'close': part[-1].close,
                      'high': high.high, 'low': low.low, 'high_time': high.time.isoformat(),
                      'low_time': low.time.isoformat(), 'ended': ended,
                      'coverage_complete':_m5_reference_day(bars,day,as_of)['status']=='complete'
                         if period==timedelta(minutes=5) else False})
        if high.time == low.time:
            ambiguous.append(day.isoformat())  # OHLC cannot tell high/low order.
        else:
            for kind, b, price in [('H', high, high.high), ('L', low, low.low)]:
                points.append({'date': day.isoformat(), 'kind': kind, 'price': price,
                               'time_ms': int(b.time.timestamp()*1000), 'provisional': not ended,
                               'available_at': min(as_of, finish).isoformat()})
        prior = day - timedelta(days=1)
        reference = closed_day_references(bars, prior, period, as_of)
        if reference['status'] != 'complete':
            continue
        for level in reference['levels']:
            upper = level['kind'] == 'PDH'
            active = None
            previous = None
            for b in part:
                if previous is not None and b.time != previous + period:
                    active = None  # no inference across missing quotes / recess.
                previous = b.time
                breach = b.high > level['price'] if upper else b.low < level['price']
                if breach and active is None:
                    active = b
                if active is not None:
                    if (upper and b.high > active.high) or (not upper and b.low < active.low):
                        active = b
                    returned = b.close < level['price'] if upper else b.close > level['price']
                    if returned:
                        sweeps.append({'date': day.isoformat(), 'kind': 'BSL' if upper else 'SSL',
                                       'label': '上扫前日高点' if upper else '下扫前日低点',
                                       'time_ms': int(active.time.timestamp()*1000),
                                       'price': active.high if upper else active.low,
                                       'reference_price': level['price'], 'reference_date': prior.isoformat(),
                                       'available_at': (b.time+period).isoformat(),
                                       'actual_stop_orders_observed': False})
                        break  # one first confirmed episode per side and day.
    points.sort(key=lambda p: p['time_ms'])
    candidates = _profile_candidates(daily, days, as_of)
    return {'points': points, 'sweeps': sweeps, 'daily': daily, 'ambiguous_days': ambiguous,
            'profile_label': ' / '.join(c['profile'] for c in candidates[:2]), 'candidates': candidates,
            'classification_ambiguous':len(candidates)>1,
            'basis': '紫色虚线：已收盘 M5 的纽约日高低点复盘连接，圆点 H / L；当日极点暂定，不补未来折线。三角：越过完整前日范围后收盘回收（PDH 前日高 / PDL 前日低），不是止损订单观测。纽约休市边界为研究假设，非券商原生日线。',
            'source_guide_pages': [3,4,5,61,62,63], 'source_course_slides': [10,11,12,13],
            'trade_signal': False, 'as_of': as_of.isoformat()}


def _profile_candidates(daily, days, as_of):
    by = {d['date']: d for d in daily}
    ds = [by.get(d.isoformat()) for d in days]
    m, t, w, th, f = ds
    missing = '事先周偏见、H1 以上 PDA 接触、CISD、DOL 和完整经济日历尚未核实；此标签仅为价格路径候选。'
    notes = []
    def add(ident,name,reason,slide,pages,**extra):
        matched=ident in WEEKLY
        notes.append({'id':ident,'profile':name+(' · 价格路径已匹配' if matched else ' · 子类待分'),'reason':reason,
                      'path_complete':matched,
                      'missing':missing,'source_slide':slide,'guide_pages':pages,
                      'hd_source':profile_source(ident,True),'observed_sequence':True,
                      'calendar_event_verified':False,'prior_bias_verified':False,**extra})
    if m and t and w and th and f and all(d['ended'] and d.get('coverage_complete',True) for d in ds):
        early_high, early_low = max(m['high'], t['high']), min(m['low'], t['low'])
        bullish = w['low'] == min(d['low'] for d in daily) and w['low'] < early_low and w['close'] > early_low and th['close'] > w['close'] and f['high'] > early_high and f['close'] > th['close']
        bearish = w['high'] == max(d['high'] for d in daily) and w['high'] > early_high and w['close'] < early_high and th['close'] < w['close'] and f['low'] < early_low and f['close'] < th['close']
        if bullish or bearish:
            # The HD slide distinguishes Tuesday's *prior path*, not simply
            # whether Wednesday ended up the weekly extreme. Direction here
            # describes the observed later route, never a reconstructed bias.
            side=1 if bullish else -1
            double=side*(t['close']-t['open'])>0 and side*(t['close']-m['close'])>0
            counter=side*(t['close']-t['open'])<0 and side*(t['close']-m['close'])<0
            name = '双重扫荡周三极点' if double else '经典周三极点' if counter else '周三极点（经典 / 双重扫荡待分）'
            direction = '看涨' if bullish else '看跌'
            add('weekly_wednesday_double_sweep' if double else 'weekly_wednesday_extreme' if counter else 'weekly_wednesday_unresolved',f'{name} · {direction}',
                f'周三{ "低点跌破" if bullish else "高点突破" }周一、周二范围后收盘回收；周四、周五同方向推进并越过周初另一端。'
                +('周二实体及收盘推进与后续扩张同向，对照双重扫荡的早期顺向阶段。' if double else '周二仍沿后续扩张的反方向推进。' if counter else '周二路径不足以区分两个子类。')
                +'方向仅描述收盘后路径，不能替代事先偏见。',12 if double else 11,[41,42,62],direction=side)
        for direction, extreme, value in [('看涨','low',min(d['low'] for d in daily)),('看跌','high',max(d['high'] for d in daily))]:
            is_bull = direction == '看涨'
            continuation = (w['close'] > t['close'] and th['close'] > w['close']) if is_bull else (w['close'] < t['close'] and th['close'] < w['close'])
            engagement=t['low']<m['low'] and t['close']>m['low'] if is_bull else t['high']>m['high'] and t['close']<m['high']
            if t[extreme] == value and continuation and engagement:
                add('weekly_tuesday_extreme',f'经典周二极点 · {direction}',
                    '周二先越过周一对应边界，收盘回收；该端保持为已观察周极点，周三、周四沿反转方向推进。',10,[7,8,61],
                    direction=1 if is_bull else -1)
        consolidation3=consolidation_evidence(ds[:3]);consolidation4=consolidation_evidence(ds[:4])
        high3=max(d['high'] for d in ds[:3]);low3=min(d['low'] for d in ds[:3])
        high4=max(d['high'] for d in ds[:4]);low4=min(d['low'] for d in ds[:4])
        for side in (1,-1):
            # HD frame 1350: Thursday may CLOSE outside the early range;
            # the opposite expansion occurs Friday. Do not require Thursday
            # itself to reclaim the range, or backdate Friday confirmation.
            swept=(th['low']<low3 and th['low']==min(d['low'] for d in ds)) if side==1 else (th['high']>high3 and th['high']==max(d['high'] for d in ds))
            expanded=(f['close']>high3 and f['close']>th['close']) if side==1 else (f['close']<low3 and f['close']<th['close'])
            if consolidation3['matched'] and swept and expanded:
                add('weekly_thursday_consolidation_reversal','盘整操纵后扩张周四极点 · '+('看涨' if side==1 else '看跌'),
                    '周一至周三范围重叠；周四向一端越界且该端保持为周极点，周五收盘到达另一端之外。周四可收在范围外；回收和扩张最晚到周五才可知。',13,[22,23,63],
                    direction=side,variant='thursday_extreme_friday_reversal',consolidation=consolidation3,
                    thursday_closed_outside=th['close']<low3 if side==1 else th['close']>high3)
            friday_break=f['close']>high4 if side==1 else f['close']<low4
            thursday_break=th['close']>high3 if side==1 else th['close']<low3
            friday_follow=(f['high']>th['high'] and f['close']>high3) if side==1 else (f['low']<th['low'] and f['close']<low3)
            no_opposite_thursday_breach=th['low']>=low3 if side==1 else th['high']<=high3
            if consolidation3['matched'] and thursday_break and friday_follow and no_opposite_thursday_breach:
                add('weekly_consolidation_expansion','盘整扩张周 · '+('看涨' if side==1 else '看跌'),
                    '周一至周三在重叠范围内整理；周四已收盘突破，周五进一步创新极点且收盘仍在范围外。对应原片周四扩张、观察周五的子路径。',14,[59],
                    direction=side,variant='thursday_expansion_friday_followthrough',consolidation=consolidation3)
            elif consolidation4['matched'] and friday_break:
                add('weekly_consolidation_expansion','盘整扩张周 · '+('看涨' if side==1 else '看跌'),
                    '前四日范围持续重叠，周五收盘突破前四日外缘；这是极点日期不固定的研究子路径，不把周五设为本类唯一突破日。',14,[59],
                    direction=side,variant='friday_expansion_after_four_day_range',consolidation=consolidation4)
        high=max(d['high'] for d in ds);low=min(d['low'] for d in ds);width=high-low
        moves=[ds[i]['close']-ds[i-1]['close'] for i in range(1,5)]
        turns=sum(a*b<0 for a,b in zip(moves,moves[1:]))
        opening=m['open'];closing=f['close']
        if not notes and width>0 and abs(closing-opening)/width<=.25 and turns>=3 and high-max(opening,closing)>=width*.2 and min(opening,closing)-low>=width*.2:
            add('weekly_seek_destroy','心电图周 · 双向盘整',
                '周内四段收盘位移三次交替反向；周净实体不超过振幅四分之一，且上下影各不少于振幅五分之一。阈值为工程近似，未从星期直接判断。',15,[60])
    if not notes:
        # A completed week can show a meaningful range break without meeting
        # the source profile's reclaim-and-follow-through sequence. Keep that
        # evidence as an explicit partial path so the chart can explain why it
        # remains unclassified, rather than hiding it behind a blank fallback.
        if m and t and w and th and f and all(d['ended'] and d.get('coverage_complete',True) for d in ds):
            early_high=max(m['high'],t['high']); early_low=min(m['low'],t['low'])
            if w['low'] < early_low and w['close'] > early_low:
                friday_note=f'周五高点 {f["high"]:.2f}，周初上界 {early_high:.2f}，周五收 {f["close"]:.2f}，周四收 {th["close"]:.2f}'
                notes.append({'id':'weekly_partial_reclaim','profile':'周三扫低回收 · 后续扩张不足（未归类）',
                              'reason':f'周三低点 {w["low"]:.2f} 跌破周初低点 {early_low:.2f} 后收回；{friday_note}，后续路径未通过完整扩张检验。',
                              'missing':missing,'source_slide':12,'guide_pages':[62],
                              'observed_sequence':True,'path_complete':False,
                              'calendar_event_verified':False,'prior_bias_verified':False})
            elif w['high'] > early_high and w['close'] < early_high:
                friday_note=f'周五低点 {f["low"]:.2f}，周初下界 {early_low:.2f}，周五收 {f["close"]:.2f}，周四收 {th["close"]:.2f}'
                notes.append({'id':'weekly_partial_reclaim','profile':'周三扫高回收 · 后续扩张不足（未归类）',
                              'reason':f'周三高点 {w["high"]:.2f} 突破周初高点 {early_high:.2f} 后收回；{friday_note}，后续路径未通过完整扩张检验。',
                              'missing':missing,'source_slide':12,'guide_pages':[62],
                              'observed_sequence':True,'path_complete':False,
                              'calendar_event_verified':False,'prior_bias_verified':False})
            elif w['low'] < early_low and w['close'] <= early_low:
                notes.append({'id':'weekly_partial_breakout','profile':'周中下破未回收（未归类）',
                              'reason':f'周三低点 {w["low"]:.2f} 跌破周一至周二低点 {early_low:.2f}，但周三收盘仍在外侧；缺少回收与后续完整扩张。',
                              'missing':missing,'source_slide':13,'guide_pages':[63],
                              'observed_sequence':True,'path_complete':False,
                              'calendar_event_verified':False,'prior_bias_verified':False})
            elif w['high'] > early_high and w['close'] >= early_high:
                notes.append({'id':'weekly_partial_breakout','profile':'周中上破未回收（未归类）',
                              'reason':f'周三高点 {w["high"]:.2f} 突破周一至周二高点 {early_high:.2f}，但周三收盘仍在外侧；缺少回收与后续完整扩张。',
                              'missing':missing,'source_slide':13,'guide_pages':[63],
                              'observed_sequence':True,'path_complete':False,
                              'calendar_event_verified':False,'prior_bias_verified':False})
    if not notes:
        reason = '尚不满足已实现的周二/周三反转后扩张路径；保留未归类。'
        if len(daily)==5 and all(d['ended'] for d in daily) and any(not d.get('coverage_complete',True) for d in daily):
            reason='周内报价覆盖不完整，不能确认六类完整价格路径；保留未归类。'
        if m and t and not w:
            inside = t['high'] <= m['high'] and t['low'] >= m['low']
            reason = (f'周一范围 {m["low"]:.2f}–{m["high"]:.2f}；周二截至快照'+('仍在该范围内，' if inside else '已越过该范围，')+'周三至周五尚未发生。继续观察周中反转 / 盘整后扩张，不能确认最终周极点。')
        ended=as_of>=datetime.combine(days[-1],time(17),NY)
        if ended and len(by)<5:
            reason='缺少完整交易日的报价，无法核对整周形态。'
        notes.append({'profile': '周概况未归类' if ended else '周概况待确认（进行中）',
                      'reason': reason, 'missing': missing, 'guide_pages': [61,62,63], 'observed_sequence':False})
    return notes
