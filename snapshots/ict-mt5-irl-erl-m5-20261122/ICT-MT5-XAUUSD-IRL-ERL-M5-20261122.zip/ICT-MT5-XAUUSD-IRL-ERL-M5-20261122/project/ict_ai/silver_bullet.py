"""Time filter from 时间（四） PPT slides 7/9; not a trading signal."""
from datetime import datetime,time,timezone
from .timebase import NY


def silver_bullet_windows(day):
    if day.weekday()>=5:return []
    windows=[]
    for key,label,start,end in [('london','伦敦银弹',3,4),('ny_am','纽约上午银弹',10,11),('ny_pm','纽约下午银弹',14,15)]:
        a=datetime.combine(day,time(start),NY).astimezone(timezone.utc)
        b=datetime.combine(day,time(end),NY).astimezone(timezone.utc)
        windows.append({'id':key,'label':label,'start_ms':int(a.timestamp()*1000),'end_ms':int(b.timestamp()*1000),
                        'ny_time':f'{start:02d}:00–{end:02d}:00','timezone':'America/New_York',
                        'source_ppt_slides':[7,9],'price_zone':False,'trade_signal':False})
    return windows


def silver_time_filter(trigger_time):
    if trigger_time.tzinfo is None:raise ValueError('Aware trigger time required')
    local=trigger_time.astimezone(NY);ms=trigger_time.timestamp()*1000
    window=next((w for w in silver_bullet_windows(local.date()) if w['start_ms']<=ms<w['end_ms']),None)
    return {'is_silver_time':window is not None,'window':window,'execution_allowed':False,
            'reason':'仅核对实际触发时间；还需事先 DOL、每日/每周叙事、PDA 与可验证执行条件。'}
