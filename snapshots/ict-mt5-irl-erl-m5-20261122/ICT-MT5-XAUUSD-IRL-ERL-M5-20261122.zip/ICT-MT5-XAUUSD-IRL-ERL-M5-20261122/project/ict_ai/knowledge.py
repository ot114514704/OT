from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def timestamp(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("Timestamp must include timezone")
    return parsed.astimezone(timezone.utc)


def load_rules(path: Path | None = None, scope: str = "daily") -> dict:
    if scope not in ("daily", "weekly"):
        raise ValueError("Scope must be daily or weekly")
    return json.loads((path or ROOT / f"research/ict_{scope}_profiles/rules.json").read_text(encoding="utf-8"))


def search(query: str, limit: int = 8, corpus: Path | None = None) -> list[dict]:
    """Literal term retrieval, not a semantic model or a claim of full review."""
    terms = query.casefold().split()
    if not terms or not 1 <= limit <= 100:
        raise ValueError("Provide query terms and limit 1..100")
    entries = []
    with (corpus or ROOT / "research/ict_corpus.jsonl").open(encoding="utf-8") as f:
        for line in f:
            item = json.loads(line)
            lowered = item["text"].casefold()
            matched = sum(term in lowered for term in terms)
            if matched:
                item["matched_query_terms"] = matched
                entries.append(item)
    return sorted(entries, key=lambda x: (-x["matched_query_terms"], x["id"]))[:limit]


def evaluate(observations: list[dict], as_of: str, rules: dict | None = None) -> dict:
    """Match supplied fact assessments, using only assessments available as_of.

    Each observation has fact, value (bool or null), available_at and source.
    False means an explicitly completed negative assessment, never absence of
    an event so far in an unfinished session. Automated market extraction and
    verification of these assessments are a separate, not yet completed step.
    """
    rules = rules or load_rules()
    cutoff = timestamp(as_of)
    allowed = {fact for card in rules["profiles"] + rules["variants"] for fact in card["required_facts"]}
    known = {}
    ignored_future = 0
    for item in observations:
        fact, value = item["fact"], item["value"]
        if fact not in allowed:
            raise ValueError(f"Unknown fact: {fact}")
        if value is not None and type(value) is not bool:
            raise ValueError("Evidence value must be boolean or null")
        if not isinstance(item.get("source"), str) or not item["source"].strip():
            raise ValueError("Every observation needs provenance")
        available = timestamp(item["available_at"])
        if available > cutoff:
            ignored_future += 1
            continue
        if fact in known:
            previous = known[fact]
            previous_time = timestamp(previous["available_at"])
            if available == previous_time and previous["value"] != value:
                raise ValueError(f"Conflicting simultaneous evidence: {fact}")
            if available < previous_time:
                continue
        known[fact] = dict(item)
    candidates = []
    for card in rules["profiles"] + rules["variants"]:
        supports, contradicts, missing = [], [], []
        for fact, expected in card["required_facts"].items():
            item = known.get(fact)
            if item is None or item["value"] is None:
                missing.append(fact)
            elif item["value"] == expected:
                supports.append(item)
            else:
                contradicts.append({**item, "expected": expected})
        status = "contradicted" if contradicts else ("incomplete" if missing else "evidence_match")
        candidates.append({"id": card["id"], "name": card["name"], "status": status, "supports": supports, "contradicts": contradicts, "missing": missing, "source_slides": card["slides"], "guide_physical_pages": card.get("guide_physical_pages", []), "doc_location": card["doc_location"]})
    return {"as_of": cutoff.isoformat(), "mode": "supplied_evidence_review", "not_an_order_signal": True, "rules_sha256": hashlib.sha256(json.dumps(rules, ensure_ascii=False, sort_keys=True).encode()).hexdigest(), "ignored_future_observations": ignored_future, "candidates": candidates, "limitation": "匹配人工或上游提供的事实评估；尚未自动核实 OHLC、新闻与时钟，不代表概况已被预测或策略有盈利能力。"}
