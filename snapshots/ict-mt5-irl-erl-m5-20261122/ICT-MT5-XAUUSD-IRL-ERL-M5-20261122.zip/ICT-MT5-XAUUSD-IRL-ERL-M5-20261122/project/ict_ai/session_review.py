"""Closed-bar MT5 hover summaries. Full sessions, Kill Zones and PO3 are separate clocks."""
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from .timebase import NY, session_windows
from .session_path import covered, displacement, after_window, local_structure, price_purposes

M5 = timedelta(minutes=5)

KZ = {"asia": "亚洲", "london": "伦敦开盘", "new_york": "纽约开盘", "london_close": "伦敦收盘"}


def silver_path(bars, reference, warm=()):
    """One explicit variant. Reference = preceding closed hour, price evidence only."""
    if not covered(reference,bars[0].time-12*M5,bars[0].time):
        return "前一小时报价不足，扫荡路径待核"
    upper, lower = max(b.high for b in reference), min(b.low for b in reference)
    best = 0
    details = "未见扫前一小时高低并收回"
    for i, b in enumerate(bars):
        up, down = b.high > upper, b.low < lower
        if up == down or not lower <= b.close <= upper:
            continue
        side = "前高" if up else "前低"
        evidence = f"{b.time.astimezone(NY):%H:%M} 扫{side} {upper if up else lower:.2f} 并收回"
        if best < 1:
            best, details = 1, evidence + "，待反向 FVG"
        for j in range(i+2, len(bars)):
            # The impulse and the confirming third candle follow the sweep.
            first, impulse, third = bars[j-2:j+1]
            lo, hi = (third.high, first.low) if up else (first.high, third.low)
            directional = impulse.close < impulse.open if up else impulse.close > impulse.open
            if lo >= hi or not directional:
                continue
            side=-1 if up else 1
            _, strength_side=displacement([impulse],list(warm or reference)+bars[:j-1])
            if strength_side!=side:
                continue
            if any(x.high>b.high if up else x.low<b.low for x in bars[i+1:j+1]):
                break
            gap = f"{'看跌' if up else '看涨'} FVG {lo:.2f}–{hi:.2f}"
            if best < 2:
                best, details = 2, evidence + "｜" + gap + "，窗内未见后续回踩"
            for retest in bars[j+1:]:
                if (up and retest.high>b.high) or (down and retest.low<b.low):
                    break
                if retest.low <= hi and retest.high >= lo:
                    return evidence + "｜" + gap + f"，{retest.time.astimezone(NY):%H:%M} 回触"
                if (up and retest.low > hi) or (down and retest.high < lo):
                    break
    return details


def window_summary(title, start, end, bars, prior, now, po3, silver=False, *, warm=(), later=()):
    cutoff = min(now, end)
    body = [b for b in bars if start <= b.time and b.time + M5 <= cutoff]
    clock = f"美东 {start.astimezone(NY):%m-%d %H:%M}–{end.astimezone(NY):%m-%d %H:%M}"
    lines = [title, clock]
    if not body:
        return "｜".join(lines + ["待已收 M5 报价"]), 0, 0
    high, low = max(b.high for b in body), min(b.low for b in body)
    full = covered(body,start,cutoff)
    close = body[-1].close
    lines += [("复盘" if cutoff == end else "进行中") + ("" if full else " · 报价不全") +
              f"　开 {body[0].open:.2f} → 末 {close:.2f}（{close-body[0].open:+.2f}）",
              f"高 {high:.2f}　低 {low:.2f}　振幅 {high-low:.2f} 美元/盎司"]
    if full and warm:lines.append(price_purposes(body,warm))
    if silver:
        windows = session_windows(start.astimezone(NY).date())
        overlap = [KZ[key] for key, (a,z) in windows.items() if start < z and a < end]
        lines.append("Kill Zone · " + ("、".join(overlap) if overlap else "课程四窗以外"))
        lines.append(silver_path(body, prior, warm) if full else "窗口缺报价，扫荡路径待核")
        if full:
            strength,side = displacement(body,warm)
            lines.extend([strength,local_structure(body,warm),after_window(body,end,later,now,side)])
            if side and covered(prior,start-12*M5,start):
                old_move=prior[-1].close-prior[0].open
                alignment='同向推进' if old_move*side>0 else '反向推进' if old_move*side<0 else '前窗净方向未定'
                lines.append(f'前一小时净移 {old_move:+.2f}，最强位移与前窗{alignment}；核对扫回顺序及结构收破')
        lines.append("时间（四）11、18–19、24–25页 · 核对既有扩张或扫回后的扩张；事前 DOL、PDA 和实际成交另核")
    else:
        roles = []
        for zone in po3["zones"]:
            # Attribute the close that first established the stage. The interval
            # ending exactly at a shared boundary belongs to the preceding bar.
            known = datetime.fromisoformat(zone["available_at"])
            if not start < known <= cutoff:
                continue
            phase = zone["phase"]
            tag = {"A": "A 积累", "M": "M 操纵", "D": "D 派发"}[phase]
            roles.append(tag)
            if phase == "A":
                reason = f"冻结亚洲观察区 {zone['lower']:.2f}–{zone['upper']:.2f}"
            elif phase == "M":
                reason = "扫上沿后收回" if po3["phase_evidence"]["M"]["side"] == "above_range" else "扫下沿后收回"
            else:
                reason = ("向上" if po3["direction"] == "bullish" else "向下") + "连续两根 M15 收在对侧外"
            lines.append(f"{known.astimezone(NY):%H:%M} {tag}候选 · {reason}")
        if roles:
            lines[0] += " · " + " / ".join(roles) + "候选"
        else:
            lines.append("本盘未确认新的跨盘 PO3 阶段")
        state = po3["phase_evidence"]["D"]
        if state["status"] in ("invalidated", "unknown_due_to_gap") and start < datetime.fromisoformat(state["available_at"]) <= cutoff:
            lines.append("原 M 路径失效" if state["status"] == "invalidated" else "M 后报价中断")
    return "｜".join(lines), low, high
