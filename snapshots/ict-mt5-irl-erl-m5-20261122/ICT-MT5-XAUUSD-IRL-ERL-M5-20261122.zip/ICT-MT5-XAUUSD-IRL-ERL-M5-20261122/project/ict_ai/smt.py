"""Confirmed cross-market high/low divergence candidates (no orders).

ICT 精翻 pp. 120–125: compare correlated markets, use as contextual evidence.
Gold/silver pair, pivot width, pairing tolerance and maximum anchor span are
engineering choices; no claim of validated correlation or predictive success.
"""
from datetime import datetime, timedelta
import hashlib


def smt_divergences(primary,secondary,period,as_of,pivot_radius=2,pair_tolerance_bars=2,max_anchor_bars=48):
    if period<=timedelta(0) or as_of.tzinfo is None or as_of.utcoffset() is None:
        raise ValueError('Positive period and aware cutoff required')
    if not isinstance(pivot_radius,int) or pivot_radius<1 or pair_tolerance_bars<0 or max_anchor_bars<1:
        raise ValueError('Valid pivot and matching parameters required')
    for rows in (primary,secondary):
        if any(a.time>=b.time for a,b in zip(rows,rows[1:])):
            raise ValueError('Each series must have unique chronological bars')
    peers={b.time:b for b in secondary if b.time+period<=as_of}
    # Pair exact same timestamps. Gaps break pivot windows AND earlier anchors.
    joined=[(a,peers[a.time]) for a in primary if a.time+period<=as_of and a.time in peers]
    r=pivot_radius;start=0;events=[]
    pending={k:[[],[]] for k in ('high','low')};previous={}
    def point(bar,field,known):
        return {'time_ms':int(bar.time.timestamp()*1000),'price':getattr(bar,field),'available_at':known}
    for i,pair in enumerate(joined):
        if i and pair[0].time!=joined[i-1][0].time+period:
            start=i;pending={k:[[],[]] for k in ('high','low')};previous={}
        if i-start<2*r:continue
        center=i-r;window=joined[i-2*r:i+1];known=pair[0].time+period
        for field in ('high','low'):
            queues=pending[field]
            for market in (0,1):
                value=getattr(joined[center][market],field)
                others=[getattr(row[market],field) for j,row in enumerate(window) if j!=r]
                pivot=all(value>x for x in others) if field=='high' else all(value<x for x in others)
                if pivot:queues[market].append(point(joined[center][market],field,known))
            while queues[0] and queues[1]:
                a=queues[0][0]
                candidates=[(abs(b['time_ms']-a['time_ms']),j,b) for j,b in enumerate(queues[1]) if abs(b['time_ms']-a['time_ms'])<=pair_tolerance_bars*period.total_seconds()*1000]
                if not candidates:
                    if queues[1][0]['time_ms']<a['time_ms']:queues[1].pop(0)
                    else:queues[0].pop(0)
                    continue
                _,j,b=min(candidates,key=lambda x:(x[0],x[1]))
                queues[0].pop(0);queues[1].pop(j)
                old=previous.get(field);previous[field]=(a,b)
                if not old:continue
                old_a,old_b=old
                if a['time_ms']-old_a['time_ms']>max_anchor_bars*period.total_seconds()*1000:continue
                da=a['price']-old_a['price'];db=b['price']-old_b['price']
                if da*db>=0:continue
                direction='bearish' if field=='high' else 'bullish'
                confirmation=max(a['available_at'],b['available_at'])
                key='|'.join((direction,str(old_a['time_ms']),str(a['time_ms']),str(old_b['time_ms']),str(b['time_ms']),str(period)))
                anchors=lambda values:[{'time_ms':p['time_ms'],'price':p['price']} for p in values]
                events.append({'id':hashlib.sha256(key.encode()).hexdigest()[:20],
                               'direction':direction,'primary':anchors((old_a,a)),
                               'secondary':anchors((old_b,b)),
                               'available_at':confirmation.isoformat(),
                               'primary_pattern':('HH' if da>0 else 'LH') if field=='high' else ('HL' if da>0 else 'LL'),
                               'secondary_pattern':('HH' if db>0 else 'LH') if field=='high' else ('HL' if db>0 else 'LL'),
                               'candidate':True,'trade_signal':False})
            # Expire unmatched points only after any possible counterpart's
            # confirmation time has passed. Future pivots cannot rewrite pairs.
            earliest=(known-(pair_tolerance_bars+r+1)*period).timestamp()*1000
            for queue in queues:queue[:]=[p for p in queue if p['time_ms']>=earliest]
    return events


def smt_observation(event, primary, secondary, period, as_of):
    """Later price follow-up, distinct from historical pivot availability.

    The user video requires prior narrative/location and CSD validation but
    does not define CSD's candle anchor. No automatic validation is claimed.
    A peer subsequently crossing its old anchor may just have been lagging.
    """
    known = datetime.fromisoformat(event['available_at'])
    field = 'high' if event['direction'] == 'bearish' else 'low'
    extends = lambda value, anchor: value > anchor if field == 'high' else value < anchor
    market = 'primary' if not extends(event['primary'][1]['price'], event['primary'][0]['price']) else 'secondary'
    anchor = event[market][0]['price']
    peers = {b.time:b for b in secondary if b.time+period <= as_of}
    joined = [(a, peers[a.time]) for a in primary if a.time >= known and a.time+period <= as_of and a.time in peers]
    result = {'status':'geometry_only','observed_as_of':as_of.isoformat(),
              'prior_narrative':'pending','htf_location':'pending','csd_validation':'undefined_in_source',
              'optional':True,'trade_signal':False}
    expected = known
    for a,b in joined:
        if a.time != expected:
            result.update(status='followup_gap',gap_known_at=(expected+period).isoformat())
            return result
        if extends(getattr(a if market=='primary' else b,field),anchor):
            result.update(status='peer_caught_up',catch_up_at=(a.time+period).isoformat(),lagging_market=market)
            return result
        expected = a.time+period
    if expected+period <= as_of:
        result.update(status='followup_gap',gap_known_at=(expected+period).isoformat())
    return result
