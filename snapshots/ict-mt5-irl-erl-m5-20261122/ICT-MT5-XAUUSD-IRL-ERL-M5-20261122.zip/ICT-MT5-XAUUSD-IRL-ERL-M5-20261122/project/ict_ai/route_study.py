"""Freeze an auditable HTF route hypothesis independently of the later trigger."""
from datetime import timedelta

from brooks_ai.types import utc_time
from .planning import target_path


def freeze_route(frozen):
    context = frozen["context"]
    as_of = utc_time(context["as_of"])
    price = context.get("last_observed_price")
    result = {"frozen_at": as_of.isoformat(), "price": price, "direction": None,
              "selected_route": None, "status": "no_eligible_route", "qualified_dol": False}
    if price is None or utc_time(context["price_available_at"]) != as_of:
        return {**result, "status": "missing_price_at_cutoff"}
    if utc_time(frozen["delivery_hypotheses"]["as_of"]) != as_of:
        raise ValueError("Route and price context must use the same cutoff")
    routes = [
        route for route in frozen["delivery_hypotheses"]["hypotheses"]
        if route["stage"] == "idea_pending_validation"
        and route["timeframe"] in ("D1", "W1")
        and utc_time(route["origin_known_at"]) <= as_of
        and utc_time(route["target"]["available_at"]) <= as_of
        and route["direction"] * (route["target_reference_price"] - price) > 0
    ]
    if not routes:
        return result
    if len({route["direction"] for route in routes}) > 1:
        return {**result, "status": "conflicting_routes"}
    # W1 first, then nearest pending target within that frame. No trigger input.
    selected = min(routes, key=lambda r: (r["timeframe"] != "W1",
                                         abs(r["target_reference_price"] - price), r["id"]))
    return {**result, "status": "research_route_selected", "direction": selected["direction"],
            "selected_route": selected}


def assess_route(watch, event, bars, period=timedelta(minutes=5)):
    """Check trigger alignment and still-untouched routing at closed-bar confirmation."""
    known = utc_time(event["available_at"])
    origin = utc_time(watch["frozen_at"])
    if origin != utc_time(event["sweep_started_at"]) or known <= origin:
        raise ValueError("Require a frozen route at the sweep start, before confirmation")
    if watch["selected_route"] is None:
        return {"status": watch["status"], "available_at": known.isoformat()}
    if watch["direction"] != event["side"]:
        return {"status": "direction_conflicts_with_route", "available_at": known.isoformat()}
    target = watch["selected_route"]["target_reference_price"]
    path = target_path(bars, origin, known, period, watch["direction"], target)
    status = {"reached": "target_reached_before_entry", "unknown": "incomplete_path_to_confirmation",
              "untouched": "target_open_at_confirmation"}[path["status"]]
    return {"status": status, "available_at": known.isoformat(), "target_reference_price": target,
            "target_reached_known_at": path["observed_contact_known_at"],
            "coverage_complete": path["coverage_complete"]}
