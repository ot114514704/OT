"""Build sourced research plans; MT5 execution qualification is separate."""
from datetime import timedelta
import math
from .knowledge import timestamp
from .timebase import NY,session_windows
from brooks_ai.risk import size_volume


def target_path(bars, start, end, period, side, target):
    """Assess an already chosen target using only bars closed by the cutoff."""
    if period <= timedelta(0) or end < start or side not in (-1, 1):
        raise ValueError('Invalid target observation interval or direction')
    cursor = start
    complete = True
    first_contact = None
    for bar in bars:
        close_time = bar.time + period
        if bar.time < start or close_time > end:
            continue
        if bar.time != cursor:
            complete = False
        cursor = close_time
        extent = bar.high if side == 1 else bar.low
        if side * (extent - target) >= 0:
            if first_contact is None or close_time < first_contact:
                first_contact = close_time
    complete = complete and cursor == end
    status = 'reached' if first_contact else ('untouched' if complete else 'unknown')
    return {'status': status, 'coverage_complete': complete,
            'observed_contact_known_at': first_contact.isoformat() if first_contact else None}


def research_plan(event,context,bars,as_of,spec=None,equity=None,risk_fraction=.0025,period=timedelta(minutes=5)):
    """Context fields have value/available_at/source; unknown remains unknown.

    Source concepts: frozen bias/PDA/DOL in 时间（二）, ICT 精翻 pp. 19,
    91, 119, 146. FVG midpoint, one-tick buffer and .25% budget are explicitly
    engineering choices, not source-proven performance or automatic orders.
    """
    now=timestamp(as_of) if isinstance(as_of,str) else as_of
    if now.tzinfo is None or now.utcoffset() is None or not 0<risk_fraction<=.01 or period<=timedelta(0):
        raise ValueError('Aware cutoff and research risk fraction in (0, 1%] required')
    known=timestamp(event['available_at']);side=event['side']
    if event['kind']!='sweep_mss_fvg_candidate' or side not in (-1,1):
        raise ValueError('Complete directional motif required')
    result={'event_id':event['id'],'as_of':now.isoformat(),'status':'pending_context',
            'missing':[],'contradictions':[],'watch':None,'execution_allowed':False,
            'execution_scope':'research_only; demo qualification and binding remain separate',
            'engineering_choices':['FVG midpoint watch price','One tick beyond frozen sweep extreme','Risk budget fraction '+str(risk_fraction)]}
    if known>now:
        result['status']='not_yet_available';return result
    # Direction must be recorded before the event's manipulation begins.
    frozen_before=timestamp(event.get('sweep_started_at',event['reference']['available_at']))
    accepted={}
    for key in ('htf_bias','htf_pda','dol','calendar_clear','clock_verified'):
        item=context.get(key)
        if not item or item.get('value') is None:
            result['missing'].append(key);continue
        if not isinstance(item.get('source'),str) or not item['source'].strip():
            raise ValueError('Context provenance required: '+key)
        available=timestamp(item['available_at'])
        if available>now or key in ('htf_bias','htf_pda','dol') and available>frozen_before:
            result['missing'].append(key+' (not available before required cutoff)');continue
        accepted[key]=item
    if 'htf_bias' in accepted and accepted['htf_bias']['value']!=side:
        result['contradictions'].append('direction conflicts with frozen HTF bias')
    for key in ('calendar_clear','clock_verified'):
        if key in accepted and accepted[key]['value'] is not True:
            result['contradictions'].append(key+' is not verified clear')
    local=known.astimezone(NY);windows=session_windows(local.date())
    in_window=any(windows[k][0]<known<=windows[k][1] for k in ('london','new_york'))
    if not in_window:result['contradictions'].append('formation confirmed outside selected London/NY course windows')
    fvg=event['fvg'];entry=(fvg['lower']+fvg['upper'])/2
    if 'htf_pda' in accepted:
        pda=accepted['htf_pda']['value']
        if not isinstance(pda,dict) or not pda.get('timeframe') or not 0<pda['lower']<pda['upper']:
            raise ValueError('Sourced HTF PDA range and timeframe required')
        if not pda['lower']<=entry<=pda['upper']:
            result['contradictions'].append('watch price outside frozen HTF PDA')
    target=None
    if 'dol' in accepted:
        target=accepted['dol']['value']
        if not isinstance(target,(int,float)) or not math.isfinite(target) or target<=0:
            raise ValueError('Finite price target required')
        path=target_path(bars,timestamp(accepted['dol']['available_at']),known,period,side,target)
        result['dol_path']=path
        if path['status']=='reached':result['contradictions'].append('DOL already reached before motif confirmation')
        if path['status']=='unknown':result['missing'].append('continuous_DOL_quote_coverage')
        if side*(target-entry)<=0:result['contradictions'].append('DOL is not beyond watch price in planned direction')
    result['context_used']=accepted
    if spec is None or equity is None:
        result['missing'].append('instrument_costs_and_equity')
    elif not spec.verified or not spec.costs_verified:
        result['missing'].append('verified_contract_and_costs')
    elif spec.account_currency!=spec.profit_currency:
        result['missing'].append('historical_account_currency_conversion')
    elif target is not None:
        if not math.isfinite(equity) or equity<=0:raise ValueError('Positive equity required')
        stop=event['sweep_extreme']-side*spec.tick_size
        distance=side*(entry-stop)
        if distance<=0:result['contradictions'].append('stop is not protective')
        else:
            loss_per_lot=(distance+2*spec.slippage)*spec.contract_size+spec.commission_round_turn
            volume=size_volume(equity*risk_fraction,loss_per_lot,spec)
            if not volume:result['contradictions'].append('minimum volume exceeds risk budget')
            if not result['missing'] and not result['contradictions']:
                result['watch']={'entry_midpoint':entry,'stop':stop,'target':target,'volume':volume,
                                 'estimated_risk_cash':volume*loss_per_lot,'risk_budget_cash':equity*risk_fraction,
                                 'reward_risk_before_costs':side*(target-entry)/distance,
                                 'entry_confirmed':False,'mitigation_not_assumed':True}
    result['status']='contradicted' if result['contradictions'] else ('pending_context' if result['missing'] else 'watch_for_mitigation')
    return result
