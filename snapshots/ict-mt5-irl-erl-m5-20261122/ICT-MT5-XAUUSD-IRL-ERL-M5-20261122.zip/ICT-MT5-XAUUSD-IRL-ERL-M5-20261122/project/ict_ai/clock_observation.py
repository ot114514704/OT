"""Observe clock hypotheses from advancing quotes, without calibrating history.

A fresh-looking timestamp alone can be a stale quote plus a different offset.
Require advancing ticks across multiple reads and compare host wall/monotonic
elapsed times. Even a stable match is not independent proof of true UTC: the
host clock or feed can be wrong. This observer never changes the applied offset.
"""
from datetime import datetime, timezone
from math import isfinite


class SourceClockObserver:
    def __init__(self, applied_hours=3, candidates=(0, 2, 3)):
        self.applied_hours = applied_hours
        self.candidates = tuple(candidates)
        self.previous = None
        self.samples = []
        self.host_jump = False

    def observe(self, raw_epoch_seconds, now, monotonic_seconds):
        if now.tzinfo is None or not all(isfinite(v) for v in (raw_epoch_seconds, monotonic_seconds)):
            raise ValueError('Aware host time and finite source/monotonic times required')
        wall = now.timestamp()
        ages = {str(h): wall-raw_epoch_seconds+h*3600 for h in self.candidates}
        plausible = [h for h in self.candidates if -2 <= ages[str(h)] <= 5]
        candidate = plausible[0] if len(plausible) == 1 else None
        previous = self.previous
        current = (raw_epoch_seconds, wall, monotonic_seconds, candidate)
        self.previous = current
        if previous:
            raw_elapsed, wall_elapsed, mono_elapsed = (current[i]-previous[i] for i in range(3))
            if mono_elapsed < 0 or abs(wall_elapsed-mono_elapsed) > 1:
                self.host_jump = True
            if (candidate != previous[3] or raw_elapsed < 0 or mono_elapsed > 10
                    or (raw_elapsed > 0 and abs(raw_elapsed-wall_elapsed) > 7)):
                self.samples = []
        if self.host_jump or candidate is None:
            self.samples = []
        elif not self.samples or raw_epoch_seconds > self.samples[-1][0]:
            self.samples.append(current)
            self.samples = self.samples[-6:]
        span = self.samples[-1][2]-self.samples[0][2] if self.samples else 0
        stable = len(self.samples) >= 3 and span >= 4
        status = ('host_clock_discontinuity' if self.host_jump else
                  'offset_mismatch' if stable and candidate != self.applied_hours else
                  'stable_current_observation' if stable else 'collecting' if candidate is not None else
                  'no_recent_clock_match')
        return {'status': status, 'applied_offset_hours': self.applied_hours,
                'candidate_offset_hours': candidate,
                'observed_offset_hours': candidate if stable else None,
                'distinct_ticks': len(self.samples), 'observation_span_seconds': span,
                'ages_by_offset_seconds': ages,
                'observed_at_utc': now.astimezone(timezone.utc).isoformat(),
                'raw_tick_epoch_seconds': raw_epoch_seconds,
                'sample_window': [{'raw_epoch_seconds': row[0],
                                  'host_utc': datetime.fromtimestamp(row[1], timezone.utc).isoformat(),
                                  'monotonic_seconds': row[2]} for row in self.samples],
                'automatic_offset_change': False,
                'host_clock_independently_verified': False,
                'historical_alignment_verified': False}
