"""Closed NY research D1/W1 evidence for bias/DOL preparation.

Bias/DOL video 267–404 and 932–1058 seconds requires confirmed swings and
at least daily context. NY midnight periods and the assumed TMGM study hours
are engineering choices, not broker-native D1/W1 or a directional strategy.
"""
from datetime import datetime, time, timedelta, timezone
import hashlib

from brooks_ai.types import utc_time
from .timebase import NY
from .range_liquidity import _m5_reference_day, _research_open as _open

M5=timedelta(minutes=5)


def _next_day(day):
    day+=timedelta(days=1)
    while day.weekday()>4:day+=timedelta(days=1)
    return day


def _state(level,bars,as_of):
    known=utc_time(level['available_at']);price=level['price'];buy=level['kind']=='H'
    closed=[b for b in bars if known<=b.time and b.time+M5<=as_of]
    bytime={b.time:b for b in closed}
    stamp=known;missing=0;touch=excursion=reclaim=None;pending=False
    while stamp+M5<=as_of:
        if _open(stamp):
            bar=bytime.get(stamp)
            if bar is None:
                missing+=1;pending=False
            else:
                end=(stamp+M5).isoformat()
                if touch is None and bar.low<=price<=bar.high:touch=end
                beyond=bar.high>price if buy else bar.low<price
                if beyond:
                    if excursion is None:excursion=end
                    pending=True
                if pending and reclaim is None and (bar.close<price if buy else bar.close>price):reclaim=end
        stamp+=M5
    return {'touch_known_at':touch,'excursion_known_at':excursion,'reclaim_known_at':reclaim,
            'missing_expected_m5':missing,'closed_slot_coverage_complete':missing==0,
            'not_revisited':False if touch else None if missing or excursion else True,
            'observed_through':stamp.isoformat(), 'actual_stop_orders_observed':False}


def _gap_state(gap,bars,periods,as_of):
    """M5 wick contact and source-timeframe close invalidation are distinct."""
    known=utc_time(gap['available_at']);lower=gap['lower'];upper=gap['upper']
    bullish=gap['direction']=='bullish';ce=(lower+upper)/2
    quotes={b.time:b for b in bars if known<=b.time and b.time+M5<=as_of}
    touch=midpoint=far=None;missing=0;skipped=False;stamp=known
    while stamp+M5<=as_of:
        if _open(stamp):
            b=quotes.get(stamp)
            if b is None:missing+=1
            else:
                end=(stamp+M5).isoformat()
                if touch is None and b.low<=upper and b.high>=lower:touch=end
                if midpoint is None and b.low<=ce<=b.high:midpoint=end
                edge=lower if bullish else upper
                if far is None and b.low<=edge<=b.high:far=end
                if (b.high<lower if bullish else b.low>upper):skipped=True
        stamp+=M5
    invalid=next((p['available_at'] for p in periods if utc_time(p['start'])>=known
                  and utc_time(p['available_at'])<=as_of
                  and (p['close']<lower if bullish else p['close']>upper)),None)
    state='close_invalidated' if invalid else 'far_edge_touched' if far else 'touched' if touch else 'unknown' if missing or skipped else 'untouched'
    return {'ce':ce,'touch_known_at':touch,'ce_known_at':midpoint,
            'full_mitigation_known_at':far,'close_invalidation_known_at':invalid,
            'invalidation_timeframe':gap['timeframe'],'state':state,
            'missing_expected_m5':missing,'closed_slot_coverage_complete':missing==0,
            'untouched':False if touch else None if missing or skipped else True,
            'observed_price_beyond_far_edge':skipped,'observed_through':stamp.isoformat(),
            'mitigation_basis':'Observed M5 contact with far edge; not proof every price traded',
            'qualified_pda':False,'actual_stop_orders_observed':False}


def daily_weekly_context(bars,as_of):
    """Use only complete periods; missing days break pivot adjacency.

    Swings become available at the right period's close. Periods that have not
    closed or have missing M5 slots are never filled or counted as confirmed.
    M5 observations after confirmation attach state without rewriting anchors.
    """
    now=utc_time(as_of)
    if any(b.time.tzinfo is None for b in bars) or any(a.time>=b.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Aware, unique chronological M5 bars required')
    if any(b.time.second or b.time.microsecond or b.time.minute%5 for b in bars):
        raise ValueError('Aligned M5 source required')
    closed=[b for b in bars if b.time+M5<=now]
    result={'as_of':now.isoformat(),'frames':{},'bias_value':None,'dol_value':None,
            'qualified_context':False,'execution_allowed':False,'orders_sent':0,
            'source_video':'research/ict_price_videos/bias_dol/integration.json',
            'source_seconds':[267,404,575,629,794,932,1058], 'historical_clock_verified':False,
            'session_calendar_verified':False,
            'basis':'NY-midnight research periods; assumed weekday recess 17–18 NY, Friday close 16:55; not native D1/W1'}
    days=[];checks=[]
    if closed:
        result['last_observed_price']=closed[-1].close
        result['price_available_at']=(closed[-1].time+M5).isoformat()
        day=closed[0].time.astimezone(NY).date();last=now.astimezone(NY).date()
        while day<=last:
            if day.weekday()<5:
                check=_m5_reference_day(closed,day,now)
                audit={k:v for k,v in check.items() if k in ('date','status','missing_bars','expected_bars','observed_bars','available_at')}
                if utc_time(check['available_at'])>now:
                    audit.update(status='in_progress',missing_bars=None)
                checks.append(audit)
                if check['status']=='complete':
                    part=check['bars']
                    days.append({'date':day.isoformat(),'start':check['start'].isoformat(),
                                 'available_at':check['available_at'],'open':part[0].open,
                                 'high':max(b.high for b in part),'low':min(b.low for b in part),'close':part[-1].close})
            day+=timedelta(days=1)
    bydate={d['date']:d for d in days};weeks=[]
    for row in days:
        monday=datetime.fromisoformat(row['date']).date()
        if monday.weekday()!=0:continue
        part=[bydate.get((monday+timedelta(days=i)).isoformat()) for i in range(5)]
        if not all(part):continue
        weeks.append({'date':monday.isoformat(),'start':part[0]['start'],'available_at':part[-1]['available_at'],
                      'open':part[0]['open'],'high':max(d['high'] for d in part),
                      'low':min(d['low'] for d in part),'close':part[-1]['close']})
    for timeframe,periods in [('D1',days),('W1',weeks)]:
        points=[];gaps=[]
        for left,anchor,right in zip(periods,periods[1:],periods[2:]):
            dates=[datetime.fromisoformat(d['date']).date() for d in (left,anchor,right)]
            adjacent=(_next_day(dates[0])==dates[1] and _next_day(dates[1])==dates[2]) if timeframe=='D1' else all(b-a==timedelta(days=7) for a,b in zip(dates,dates[1:]))
            if not adjacent:continue
            if right['low']>left['high']:
                direction,lower,upper='bullish',left['high'],right['low']
            elif right['high']<left['low']:
                direction,lower,upper='bearish',right['high'],left['low']
            else:direction=None
            if direction and anchor['low']<=lower and anchor['high']>=upper:
                identity=f'{timeframe}|FVG|{right["date"]}|{direction}|{lower}|{upper}'
                gap={'id':hashlib.sha256(identity.encode()).hexdigest()[:24],
                     'kind':'geometric_fvg','timeframe':timeframe,'direction':direction,
                     'lower':lower,'upper':upper,'formation_period_start':right['start'],
                     'anchor_period_start':anchor['start'],'available_at':right['available_at'],
                     'source_pages':[89,90],'source_video_seconds':[404,575],
                     'trade_signal':False}
                gap.update(_gap_state(gap,closed,periods,now));gaps.append(gap)
            for kind,field in [('H','high'),('L','low')]:
                valid=anchor[field]>max(left[field],right[field]) if kind=='H' else anchor[field]<min(left[field],right[field])
                if not valid:continue
                identity=f'{timeframe}|{anchor["date"]}|{kind}|{anchor[field]}'
                point={'id':hashlib.sha256(identity.encode()).hexdigest()[:24],
                       'timeframe':timeframe,'kind':kind,'price':anchor[field],
                       'anchor_period_start':anchor['start'],'available_at':right['available_at'],
                       'side':'buy_side_proxy' if kind=='H' else 'sell_side_proxy','selected_as_dol':False}
                point.update(_state(point,closed,now));points.append(point)
        candidates=[];uncertain=[]
        if closed:
            for point in points:
                direction=1 if point['kind']=='H' else -1
                distance=direction*(point['price']-closed[-1].close)
                if distance<=0 or point['not_revisited'] is False:continue
                candidate={**point,'direction_from_current_price':direction,
                           'distance_price':distance,'position_known_at':result['price_available_at'],
                           'candidate_reason':'Confirmed old '+timeframe+' '+point['kind']+' beyond current observed price; no DOL selection or directional validation',
                           'qualified_target':False}
                (candidates if point['not_revisited'] is True else uncertain).append(candidate)
        result['frames'][timeframe]={'periods':periods,'confirmed_swings':points,
                                    'fvg_candidates':gaps,
                                    'dol_candidates':sorted(candidates,key=lambda p:p['distance_price']),
                                    'uncertain_target_candidates':sorted(uncertain,key=lambda p:p['distance_price'])}
    result['daily_coverage_checks']=checks
    return result
