"""Compare user retrospective narratives with measured prices, never relabel signals."""
from datetime import datetime


def weekly_review(week, narrative, as_of):
    if datetime.fromisoformat(narrative['available_at']) > datetime.fromisoformat(as_of):
        return None
    daily=[d for d in week['daily'] if d.get('open') is not None and d.get('close') is not None]
    if not daily or daily[0]['date'] != narrative['week_start']:
        return None
    high=max(d['high'] for d in daily); low=min(d['low'] for d in daily)
    lowday=min(daily,key=lambda d:d['low'])
    opening=daily[0]['open']; close=daily[-1]['close']
    claims=narrative['claims']
    facts=f'纽约周 O/H/L/C {opening:.2f} / {high:.2f} / {low:.2f} / {close:.2f}；最低在 {lowday["date"]}。'
    checks=[f'周开盘：原叙述约 {claims["weekly_open"]:.2f}，实测 {opening:.2f}。']
    # Friday is determined from the supplied records, not a fixed calendar day.
    friday=next((d for d in daily if datetime.fromisoformat(d['date']).weekday()==4),None)
    if friday:
        checks.append(f'周五低/高/收 {friday["low"]:.2f} / {friday["high"]:.2f} / {friday["close"]:.2f}；原叙述低点 {claims["friday_low"]:.2f}、反弹高 {claims["friday_rebound_high"]:.2f}。')
        if friday['low']>low:
            checks.append('周五未刷新周内最低；“周五终极扫低”不受这些日高低支持。')
    rows=[]
    for d in daily:
        note=narrative['days'].get(d['date'])
        if not note:continue
        rows.append({'date':d['date'],'user_label':note['label'],'user_reason':note['reason'],
                     'measured_label':d.get('profile_label','未归类'),
                     'measured_reason':d.get('profile_reason',''),
                     'ohlc':{k:d[k] for k in ('open','high','low','close')}})
    return {'label':narrative['weekly_label'],'facts':facts,'checks':checks,'days':rows,
            'measured_direction':'看跌周' if close<opening else '看涨周' if close>opening else '平收周',
            'authority':narrative['authority'],'available_at':narrative['available_at'],
            'historical_clock_verified':False,'signal_override':False,
            'note':'用户事后叙述对照；课程形态独立保留。OHLC 不能证明机构意图、所有止损被清空或未来底部。历史时间映射待独立校准。'}
