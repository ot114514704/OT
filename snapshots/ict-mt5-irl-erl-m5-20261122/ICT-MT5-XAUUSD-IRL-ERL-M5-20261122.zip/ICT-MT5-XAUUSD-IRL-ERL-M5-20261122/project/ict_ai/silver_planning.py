"""Frozen Silver Bullet research plans, separate from demo qualification.

时间（四）PPT 13–19/23–25/29–30: DOL before narrative, confirmed PDA before
use, actual entry inside Silver time. 时间（二）/（三）supply profile context.
Provenance strings record assertions; they do not prove the assertions true.
"""
from copy import deepcopy
from dataclasses import asdict
from datetime import date, datetime, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path

from brooks_ai.risk import size_volume
from brooks_ai.types import utc_time
from .backtest import LimitStudyOrder
from .features import geometric_fvgs
from .silver_bullet import silver_bullet_windows
from .silver_execution import simulate_silver_limit


def _sourced(item):
    return isinstance(item,dict) and isinstance(item.get('source'),str) and bool(item['source'].strip())


def plan_digest(plan):
    frozen={k:v for k,v in plan.items() if k!='plan_sha256'}
    return hashlib.sha256(json.dumps(frozen,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def _coverage(bars,start,end,period):
    """Require all observed slots; no guessed market-closure calendar."""
    if start==end:return True
    if start>end or start.timestamp()%period.total_seconds() or end.timestamp()%period.total_seconds():return False
    relevant=[b for b in bars if start<=b.time and b.time+period<=end]
    return bool(relevant and relevant[0].time==start and relevant[-1].time+period==end
                and all(a.time+period==b.time for a,b in zip(relevant,relevant[1:])))


def silver_research_plan(selection,context,pda_bars,quotes,as_of,spec=None,equity=None,
                         period=timedelta(minutes=5),risk_fraction=.0025):
    """No future bars/context can rewrite this explicitly prepared order.

    selection: id, side, prepared_at, context_frozen_before, ny_date, window_id,
      pda (geometric FVG incl timeframe/source), entry, stop (sourced price).
    context fields: sourced value/available_at for htf_bias, htf_pda, dol,
      daily_narrative, weekly_narrative, calendar_clear, clock_verified.
    htf_bias must carry timeframe D1/W1/MN1 (user video 1028–1058s).
    A research watch does not grant demo or live execution permission.
    """
    now=utc_time(as_of);prepared=utc_time(selection['prepared_at'])
    frozen=utc_time(selection['context_frozen_before']);side=selection['side']
    if not selection.get('id') or type(side) is not int or side not in (-1,1) or frozen>prepared:
        raise ValueError('Unique selection ID, direction and prior context cutoff required')
    if not timedelta(0)<period<=timedelta(hours=1) or 3600%period.total_seconds() or not 0<risk_fraction<=.01:
        raise ValueError('Aligned intraday quote period and research risk in (0, 1%] required')
    if any(a.time>=b.time for a,b in zip(quotes,quotes[1:])):
        raise ValueError('Strictly chronological quotes required')
    day=date.fromisoformat(selection['ny_date'])
    window=next((w for w in silver_bullet_windows(day) if w['id']==selection['window_id']),None)
    if window is None:raise ValueError('Source-defined weekday window required')
    start=datetime.fromtimestamp(window['start_ms']/1000,timezone.utc)
    end=datetime.fromtimestamp(window['end_ms']/1000,timezone.utc)
    result={'selection_id':selection['id'],'prepared_at':prepared.isoformat(),'as_of':now.isoformat(),
            'context_frozen_before':frozen.isoformat(),'selection':deepcopy(selection),
            'quote_period_minutes':period.total_seconds()/60,
            'status':'pending_context','missing':[],'contradictions':[],'context_used':{},
            'watch':None,'instrument_binding':None,'execution_allowed':False,'orders_sent':0,
            'model_trained':False,'demo_qualified':False,'source_ppt_slides':[13,14,18,19,23,24,25,29,30],
            'bias_source_video':'research/ict_price_videos/bias_dol/integration.json',
            'bias_source_seconds':[1028,1058],
            'engineering_choices':['Sourced explicit limit/stop prices, not retrospectively chosen visit prices',
                                   'Far-edge close invalidation; previous touches alone do not remove a PDA',
                                   'Strict continuous quote coverage; broker closure calendar still unverified',
                                   'One research order, no portfolio qualification; 0.25% default risk budget']}
    if now<prepared:
        result['status']='not_yet_prepared';return result
    if max(start,prepared)>=end:result['contradictions'].append('order prepared after selected window ended')
    if prepared.timestamp()%period.total_seconds():result['missing'].append('finer_quotes_for_partial_bar_preparation')
    accepted={}
    for key in ('htf_bias','htf_pda','dol','daily_narrative','weekly_narrative','calendar_clear','clock_verified'):
        item=context.get(key)
        if not item or item.get('value') is None:
            result['missing'].append(key);continue
        if not _sourced(item):raise ValueError('Context provenance required: '+key)
        available=utc_time(item['available_at'])
        cutoff=prepared if key in ('calendar_clear','clock_verified') else frozen
        if available>cutoff:
            result['missing'].append(key+' (not available before frozen cutoff)');continue
        accepted[key]=deepcopy(item)
    result['context_used']=accepted
    if 'htf_bias' in accepted:
        value=accepted['htf_bias']['value']
        if type(value) is not int or value not in (-1,1):raise ValueError('Explicit directional HTF bias required')
        if accepted['htf_bias'].get('timeframe') not in ('D1','W1','MN1'):
            result['missing'].append('bias_basis_at_least_D1')
        if value!=side:result['contradictions'].append('direction conflicts with frozen HTF bias')
    for key in ('calendar_clear','clock_verified'):
        if key in accepted and accepted[key]['value'] is not True:
            result['contradictions'].append(key+' is not verified clear')
    for key in ('daily_narrative','weekly_narrative'):
        if key in accepted:
            value=accepted[key]['value']
            if not isinstance(value,dict) or not value.get('profile_id') or not value.get('reason') or type(value.get('provisional')) is not bool:
                raise ValueError('A reasoned narrative hypothesis and provisional flag are required')
            if value.get('direction')!=side:result['contradictions'].append(key+' conflicts with selected direction')
    pda=selection['pda'];pda_known=utc_time(pda['available_at'])
    timeframes={'M5':5,'M15':15,'H1':60,'H4':240}
    if not _sourced(pda) or pda.get('kind')!='geometric_fvg' or pda.get('timeframe') not in timeframes:
        raise ValueError('Sourced geometric FVG and explicit timeframe required; other PDA types not implemented')
    lower,upper=pda['lower'],pda['upper'];entry=selection['entry'];stop=selection['stop']
    if not all(isinstance(x,(int,float)) and math.isfinite(x) and x>0 for x in (lower,upper,entry)) or lower>=upper:
        raise ValueError('Finite positive PDA and entry prices required')
    if pda['direction']!=('bullish' if side==1 else 'bearish'):
        result['contradictions'].append('selected FVG direction conflicts with order')
    if not lower<=entry<=upper:result['contradictions'].append('entry outside selected FVG')
    if pda_known>prepared:
        result['missing'].append('PDA not confirmed at preparation')
    else:
        pda_period=timedelta(minutes=timeframes[pda['timeframe']])
        matching=any(g['available_at']==pda_known.isoformat() and g['direction']==pda['direction']
                     and abs(g['lower']-lower)<1e-8 and abs(g['upper']-upper)<1e-8
                     for g in geometric_fvgs(pda_bars,pda_period,prepared))
        if not matching:result['missing'].append('independently_confirmed_PDA_geometry')
        if not _coverage(quotes,pda_known,prepared,period):result['missing'].append('continuous_PDA_quote_coverage')
        later=[b for b in quotes if pda_known<=b.time and b.time+period<=prepared]
        invalid=any(b.close<lower if side==1 else b.close>upper for b in later)
        result['prior_observed_pda_touch_bars']=sum(b.low<=upper and b.high>=lower for b in later)
        if invalid:result['contradictions'].append('selected PDA closed beyond far edge before preparation')
    if not _sourced(stop):raise ValueError('Protective stop source required')
    stop_price=stop['price']
    if not isinstance(stop_price,(int,float)) or not math.isfinite(stop_price) or stop_price<=0:
        raise ValueError('Finite positive protective stop price required')
    if utc_time(stop['available_at'])>prepared:result['missing'].append('stop not available at preparation')
    if side*(entry-stop_price)<=0:result['contradictions'].append('stop is not protective')
    target=None
    if 'htf_pda' in accepted:
        zone=accepted['htf_pda']['value']
        if not isinstance(zone,dict) or not zone.get('timeframe') or not 0<zone['lower']<zone['upper']:
            raise ValueError('Frozen HTF PDA bounds and timeframe required')
        if not zone['lower']<=entry<=zone['upper']:result['contradictions'].append('entry outside frozen HTF PDA')
    if 'dol' in accepted:
        dol=accepted['dol']['value']
        if not isinstance(dol,dict) or not dol.get('reason') or not dol.get('timeframe'):
            raise ValueError('Frozen DOL price, timeframe and selection reason required')
        target=dol['price']
        if not isinstance(target,(int,float)) or not math.isfinite(target) or target<=0:raise ValueError('Finite positive DOL required')
        available=utc_time(accepted['dol']['available_at'])
        if not _coverage(quotes,available,prepared,period):result['missing'].append('continuous_DOL_quote_coverage')
        if any((b.high>=target if side==1 else b.low<=target) for b in quotes if available<=b.time and b.time+period<=prepared):
            result['contradictions'].append('DOL already reached before preparation')
        if side*(target-entry)<=0:result['contradictions'].append('DOL is not beyond entry in planned direction')
    if spec is None or equity is None:
        result['missing'].append('instrument_costs_and_equity')
    elif not spec.verified or not spec.costs_verified:
        result['missing'].append('verified_contract_and_costs')
    elif spec.symbol!='XAUUSD' or spec.account_currency!=spec.profit_currency:
        result['missing'].append('matching_gold_contract_and_currency_conversion')
    else:
        if not math.isfinite(equity) or equity<=0:raise ValueError('Positive account equity required')
        result['instrument_binding']=asdict(spec)
        if target is not None:
            if any(abs(p/spec.tick_size-round(p/spec.tick_size))>1e-7 for p in (entry,stop_price,target)):
                result['contradictions'].append('order price outside instrument tick grid')
            distance=side*(entry-stop_price)
            if distance>0:
                loss_per_lot=(distance+2*spec.slippage)*spec.contract_size+spec.commission_round_turn
                volume=size_volume(equity*risk_fraction,loss_per_lot,spec)
                if not volume:result['contradictions'].append('minimum volume exceeds risk budget')
                result['risk_estimate']={'equity':equity,'risk_fraction':risk_fraction,'budget_cash':equity*risk_fraction,
                                         'volume':volume,'estimated_loss_cash':volume*loss_per_lot}
                if not result['missing'] and not result['contradictions']:
                    result['watch']={'id':selection['id'],'side':side,'available_at':prepared.isoformat(),
                                     'expires_at':end.isoformat(),'entry':entry,'stop':stop_price,'target':target,'volume':volume}
    result['status']='contradicted' if result['contradictions'] else 'pending_context' if result['missing'] else 'watch_for_silver_entry'
    # File identity detects code drift, not authenticity of the context claims.
    paths=['ict_ai/silver_planning.py','ict_ai/silver_execution.py','ict_ai/backtest.py','ict_ai/features.py','ict_ai/silver_bullet.py','brooks_ai/risk.py','brooks_ai/types.py']
    root=Path(__file__).resolve().parents[1]
    result['code_sha256']={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
    result['plan_sha256']=plan_digest(result)
    return result


def simulate_silver_plan(plan,bars,spec,as_of,period=timedelta(minutes=5),spread_multiplier=1.0):
    """Research simulation only; refuses missing context or changed conditions."""
    if plan['status']!='watch_for_silver_entry' or not plan['watch']:
        raise ValueError('A complete frozen research watch is required')
    if plan.get('plan_sha256')!=plan_digest(plan):raise ValueError('Frozen plan changed; prepare and validate a new plan')
    if period.total_seconds()/60!=plan['quote_period_minutes']:raise ValueError('Quote period changed since preparation')
    if asdict(spec)!=plan['instrument_binding']:raise ValueError('Instrument or costs changed since preparation')
    root=Path(__file__).resolve().parents[1]
    if any(hashlib.sha256((root/p).read_bytes()).hexdigest()!=sha for p,sha in plan['code_sha256'].items()):
        raise ValueError('Plan code changed; replay and freeze a new plan')
    watch=dict(plan['watch'])
    watch['available_at']=utc_time(watch['available_at']);watch['expires_at']=utc_time(watch['expires_at'])
    order=LimitStudyOrder(**watch)
    chosen=plan['selection']
    now=utc_time(as_of)
    result=simulate_silver_limit(order,chosen['pda']['available_at'],bars,spec,now,
                                 date.fromisoformat(chosen['ny_date']),chosen['window_id'],period,spread_multiplier)
    fill_at=utc_time(result['entry_bar_open']) if result.get('filled') else None
    active_at=utc_time(result['silver']['entry_active_at'])
    expire_at=utc_time(result['silver']['entry_expires_at'])
    pda=chosen['pda'];previous=None;covered_until=order.available_at
    observed=[b for b in bars if order.available_at<=b.time and b.time+period<=now and b.time<expire_at
              and (fill_at is None or b.time<=fill_at)]
    def pending_outcome(status,b,reason,uncertain=False):
        return {'order_id':order.id,'status':status,'reason':reason,'filled':None if uncertain else False,
                'pnl_net':None,'outcome_available_at':(b.time+period).isoformat() if b else now.isoformat(),
                'silver':result['silver'],'plan_sha256':plan['plan_sha256'],
                'entry_candidate_observed':uncertain,'execution_allowed':False,'orders_sent':0}
    for b in observed:
        expected=order.available_at if previous is None else previous+period
        if b.time!=expected:
            return pending_outcome('censored_pending_context_gap',b,'Unknown DOL/PDA state across missing pending-order quotes')
        previous=b.time;covered_until=b.time+period
        target_hit=b.high>=order.target if order.side==1 else b.low<=order.target
        invalid=b.close<pda['lower'] if order.side==1 else b.close>pda['upper']
        at_fill=fill_at is not None and b.time==fill_at
        if at_fill:
            # A close invalidation happens after a within-bar active fill. It
            # cannot retroactively cancel an already entered position.
            if target_hit and not result['entry_at_open']:
                return pending_outcome('censored_entry_dol_order',b,
                                       'DOL and limit entry both observed; their intrabar order is unknown',True)
            break
        if target_hit:
            return pending_outcome('cancelled_dol_before_entry',b,'Frozen DOL reached while no entry was observed')
        if invalid:
            return pending_outcome('cancelled_pda_before_entry',b,'Selected PDA closed beyond its far edge before entry')
    # An unseen trailing interval while pending can contain a target touch or
    # invalidation, including the staged period before the window begins.
    if fill_at is None:
        closed_until=datetime.fromtimestamp((min(now,expire_at).timestamp()//period.total_seconds())*period.total_seconds(),timezone.utc)
        if covered_until<closed_until and now>=order.available_at:
            return pending_outcome('censored_pending_context_gap',None,'Missing trailing quote coverage while order was pending')
    result['plan_sha256']=plan['plan_sha256']
    result['pending_dol_and_pda_checked']=True
    result['staged_quotes_checked']=sum(b.time<active_at for b in observed)
    return result
