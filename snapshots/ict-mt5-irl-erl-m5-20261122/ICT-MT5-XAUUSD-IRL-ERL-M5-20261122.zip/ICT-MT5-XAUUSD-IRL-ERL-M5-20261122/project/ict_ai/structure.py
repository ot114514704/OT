"""Causal sweep / displaced structure / FVG observations, without orders.

Sources: ICT 精翻 physical pp. 47–49, 89–92 and 时间（一） PO3 lesson.
Pivot width, displacement ratios and timeout are research parameters. These
motifs do not establish frozen HTF bias, PDA, DOL, calendar or profitability.
"""
from dataclasses import dataclass
from datetime import datetime,timedelta
import math
from statistics import median
import hashlib
import json


@dataclass(frozen=True)
class FrozenRange:
    id: str
    low: float
    high: float
    available_at: datetime
    valid_until: datetime
    source: str

    def __post_init__(self):
        if not self.id or not self.source or not all(math.isfinite(x) for x in (self.low,self.high)) or not 0<self.low<self.high:
            raise ValueError('Valid sourced range required')
        if any(t.tzinfo is None or t.utcoffset() is None for t in (self.available_at,self.valid_until)) or self.valid_until<=self.available_at:
            raise ValueError('Aware, ordered range availability and expiry required')


@dataclass(frozen=True)
class StructureParameters:
    pivot_radius: int=2
    prior_range_bars: int=14
    displacement_range_ratio: float=1.5
    minimum_body_fraction: float=.6
    max_confirmation_bars: int=8

    def __post_init__(self):
        if self.pivot_radius<1 or self.prior_range_bars<3 or self.max_confirmation_bars<1:
            raise ValueError('Positive lookback and expiry parameters required')
        if not math.isfinite(self.displacement_range_ratio) or self.displacement_range_ratio<=0 or not 0<self.minimum_body_fraction<=1:
            raise ValueError('Valid displacement thresholds required')


def sweep_structure_events(bars,reference,period,as_of,parameters=None):
    """Every event is available only at a closed bar, with immutable anchors.

    A pivot needs right-hand bars already closed BEFORE the sweep begins.
    Same-bar two-sided range sweeps are skipped: ordering is unknowable.
    Gaps and stop-anchor violations cancel active motifs. The FVG must surround
    the actual displaced MSS candle, not a random pre-existing imbalance.
    """
    cfg=parameters or StructureParameters()
    if period<=timedelta(0) or as_of.tzinfo is None or as_of.utcoffset() is None:
        raise ValueError('Positive timeframe and aware cutoff required')
    if any(a.time>=b.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Strictly chronological unique bars required')
    closed=[b for b in bars if b.time+period<=as_of]
    events=[];active=None;swing_high=None;swing_low=None;run_start=0
    def emit(kind,b,details):
        key='|'.join((reference.id,kind,b.time.isoformat(),str(details['side'])))
        e={'id':hashlib.sha256(key.encode()).hexdigest()[:24],'kind':kind,
           'bar_open':b.time.isoformat(),'available_at':(b.time+period).isoformat(),
           'reference':{'id':reference.id,'low':reference.low,'high':reference.high,
                        'available_at':reference.available_at.isoformat(),'source':reference.source},
           'trade_signal':False,'execution_allowed':False,
           'missing_context':['frozen_htf_bias','htf_pda','uncompleted_dol','verified_calendar'],
           'source_physical_pages':[47,48,49,89,90,91,92],**details}
        events.append(e);return e
    r=cfg.pivot_radius
    for i,b in enumerate(closed):
        if i and b.time!=closed[i-1].time+period:
            active=None;swing_high=None;swing_low=None;run_start=i
        # Confirm the newest pivot using only bars preceding the current bar.
        center=i-1-r
        if center-r>=run_start:
            window=closed[center-r:center+r+1];point=closed[center]
            if all(point.high>z.high for j,z in enumerate(window) if j!=r):
                swing_high={'price':point.high,'bar_open':point.time.isoformat(),'available_at':(closed[i-1].time+period).isoformat()}
            if all(point.low<z.low for j,z in enumerate(window) if j!=r):
                swing_low={'price':point.low,'bar_open':point.time.isoformat(),'available_at':(closed[i-1].time+period).isoformat()}
        if b.time<reference.available_at or b.time+period>reference.valid_until:
            active=None;continue
        upper=b.high>reference.high;lower=b.low<reference.low
        if upper and lower:
            active=None;continue
        if active is not None:
            side=active['side']
            if active['stage']!='excursion' and (b.low<active['extreme'] if side==1 else b.high>active['extreme']):
                active=None
            elif i-active['first_index']>cfg.max_confirmation_bars:
                active=None
        if active is None:
            if not (upper or lower):continue
            side=1 if lower else -1
            structure=swing_high if side==1 else swing_low
            if structure is None:continue
            active={'side':side,'stage':'excursion','first_index':i,'first_time':b.time.isoformat(),
                    'extreme':b.low if side==1 else b.high,'structure':dict(structure)}
        side=active['side']
        if active['stage']=='excursion':
            active['extreme']=min(active['extreme'],b.low) if side==1 else max(active['extreme'],b.high)
            if reference.low<=b.close<=reference.high:
                active['stage']='reclaimed';active['reclaim_index']=i
                active['sweep']=emit('liquidity_sweep',b,{'side':side,'sweep_started_at':active['first_time'],'sweep_extreme':active['extreme'],'frozen_structure':active['structure']})
            # Enforce a later MSS bar; do not infer wick ordering within the sweep.
            continue
        if active['stage']=='reclaimed':
            prior=closed[max(run_start,i-cfg.prior_range_bars):i]
            if len(prior)<cfg.prior_range_bars:continue
            true_ranges=[max(z.high-z.low,abs(z.high-closed[j-1].close),abs(z.low-closed[j-1].close)) if j>run_start else z.high-z.low for j,z in enumerate(closed[max(run_start,i-cfg.prior_range_bars):i],max(run_start,i-cfg.prior_range_bars))]
            typical=median(true_ranges);width=b.high-b.low
            beyond=b.close>active['structure']['price'] if side==1 else b.close<active['structure']['price']
            directional=(b.close-b.open)*side>0
            if not (beyond and directional and typical>0 and width>=cfg.displacement_range_ratio*typical and width>0 and abs(b.close-b.open)/width>=cfg.minimum_body_fraction):continue
            active['stage']='mss';active['mss_index']=i
            active['mss']=emit('mss_candidate',b,{'side':side,'sweep_id':active['sweep']['id'],'sweep_extreme':active['extreme'],'frozen_structure':active['structure'],'range_ratio':width/typical,'body_fraction':abs(b.close-b.open)/width})
            continue
        if active['stage']=='mss':
            if i!=active['mss_index']+1 or i<2:
                active=None;continue
            a,m,c=closed[i-2:i+1]
            low,high=(a.high,c.low) if side==1 else (c.high,a.low)
            if low<high and m.low<=low and m.high>=high:
                emit('sweep_mss_fvg_candidate',b,{'side':side,'sweep_id':active['sweep']['id'],'mss_id':active['mss']['id'],'sweep_extreme':active['extreme'],'frozen_structure':active['structure'],'fvg':{'lower':low,'upper':high,'available_at':(b.time+period).isoformat()},'range_ratio':active['mss']['range_ratio'],'body_fraction':active['mss']['body_fraction']})
            active=None
    return events
