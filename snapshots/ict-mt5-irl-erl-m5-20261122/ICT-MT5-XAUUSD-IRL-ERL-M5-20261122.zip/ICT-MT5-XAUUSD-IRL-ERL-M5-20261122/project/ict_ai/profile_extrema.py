"""Day/week extreme explanations from observed M5 prices and as-of profile rules."""
from bisect import bisect_left
from datetime import timedelta

from .profile_lifecycle import daily_profile_lifecycle, _day_bounds
from .po3 import po3_zones
from .range_liquidity import _Coverage, _m5_reference_day, _swings
from .session_path import VENUES, hours, covered, local_structure, displacement, price_purposes
from .timebase import NY, session_windows

STEP = timedelta(minutes=5)
HOUR = timedelta(hours=1)
DAY = timedelta(days=1)


def ny(stamp):
    return stamp.astimezone(NY).strftime('%m-%d %H:%M')


def extreme_anchor(body, high):
    """Earliest closed bar at the observed extreme, including equal-price retests."""
    field = (lambda b: b.high) if high else (lambda b: b.low)
    anchor = (max if high else min)(body, key=field)
    price = field(anchor)
    return anchor, price, sum(field(b) == price for b in body)


def extreme_reviews(m5, m15, days, now):
    """Inputs include the previous week for frozen levels. All timestamps are bar opens."""
    bars = [b for b in m5 if b.time+STEP<=now]
    if not bars:
        return []
    times = [b.time for b in bars]
    coverage = _Coverage(times[0],times[-1]+STEP,bars,STEP)
    def span(a,z):
        return bars[bisect_left(times,a):bisect_left(times,z)]
    audits = {}
    sessions = []
    references = []
    def register(label, part, known):
        references.append((label,known,max(b.high for b in part),min(b.low for b in part)))
    for i in range(-7,6):
        day = days[0]+i*DAY
        if day.weekday()>=5:
            continue
        audit = _m5_reference_day(bars,day,now)
        audits[day] = audit
        if audit['status']=='complete':
            register(f'{day:%m-%d} 日',audit['bars'],audit['end'])
        for venue in VENUES:
            a,z = hours(day,venue)
            part = span(a,z)
            sessions.append((a,z,venue[1]))
            if z<=now and part and covered(part,a,z):
                register(f'{day:%m-%d} {venue[1]}',part,z)
    prior = [audits[day-7*DAY] for day in days]
    if all(d['status']=='complete' for d in prior):
        register('前周',[b for d in prior for b in d['bars']],prior[-1]['end'])
    pivots = list(_swings([b for b in m15 if b.time+3*STEP<=now],3*STEP))
    def describe(scope, dates):
        start = audits[dates[0]]['start']
        end = _day_bounds(dates[-1])[1]
        stop = min(end,now)
        body = span(start,stop)
        if not body:
            return []
        full = stop==end and all(audits[d]['status']=='complete' for d in dates)
        state = '收盘已确认（研究交易时段）' if full else '已结束，报价不全' if now>=end else '形成中'
        records = []
        for high in (True,False):
            field = 'high' if high else 'low'
            side = 1 if high else -1
            name = ('周' if scope=='week' else '日')+('高' if high else '低')
            anchor,price,touches = extreme_anchor(body,high)
            t = anchor.time
            known = t+STEP
            session = '/'.join(tag for a,z,tag in sessions if a<=t<z) or '盘间'
            lines = [f'{name} {price:.2f} · {state} · 首见 {ny(t)} NY {session}，M5 于 {ny(known)} 收线',
                     f'截至 {ny(body[-1].time+STEP)} NY，同价极值共 {touches} 根 M5']
            # Each range was already closed before the bar that first crossed it.
            # Skip disconnected paths and gaps that jump a level without trading across it.
            refs = [(s,k,h if high else l) for s,k,h,l in references if k<=t and
                    (s=='前周' or t-k<=4*DAY)]
            refs += [('M15 摆动',k,p) for _,kind,p,k in pivots if t-24*HOUR<=k<=t and
                     kind==('buy_side_proxy' if high else 'sell_side_proxy')]
            raids = []
            for tag,k,p in refs:
                path = span(k,known)
                breach = next((b for b in path if side*(getattr(b,field)-p)>0),None)
                if breach is None or breach.time<start or not breach.low<=p<=breach.high:
                    continue
                if k<times[0] or coverage.gap(k,breach.time+STEP):
                    continue
                back = next((b for b in path if b.time>=breach.time and side*(b.close-p)<0),None)
                returned = back and not coverage.gap(breach.time,back.time+STEP)
                info = f'{ny(breach.time)} 越 {tag}{"高" if high else "低"} {p:.2f}'
                info += f'，{ny(back.time+STEP)} 收回' if returned else '，收回未证实'
                raids.append((breach.time,tag,p,info))
            major = sorted(r for r in raids if r[1]!='M15 摆动')
            swings = sorted(r for r in raids if r[1]=='M15 摆动')
            chosen = sorted(major[-3:]+swings[-1:])
            lines.append('首次越界（纽约时间） · '+('；'.join(r[3] for r in chosen) or '未核实对事前参考价位的清扫'))
            # Split overlapping venues into distinct intervals, so their moves are not double counted.
            boundaries = sorted({start,known,*[v for a,z,_ in sessions for v in (a,z) if start<v<known]})
            previous = None
            for a,z in zip(boundaries,boundaries[1:]):
                leg = span(a,z)
                if not leg:
                    continue
                tags = '/'.join(s for x,y,s in sessions if x<=a<y) or '盘间'
                delta = leg[-1].close-leg[0].open
                width = max(b.high for b in leg)-min(b.low for b in leg)
                move = '区间往返' if not width or abs(delta)<=width*.25 else '向上推进' if delta>0 else '向下推进'
                if previous is not None and move!='区间往返':
                    last_move,last_high,last_low = previous
                    if delta*last_move<0:
                        move += '，反向收出前段区间' if (leg[-1].close>last_high if delta>0 else leg[-1].close<last_low) else '，仍属反向回撤候选'
                    elif delta*last_move>0:
                        move += '，延续前段方向'
                lines.append(f'{ny(leg[0].time)}–{ny(leg[-1].time+STEP)} {tags} · {move}，{leg[0].open:.2f} → {leg[-1].close:.2f}')
                previous = None if move=='区间往返' else (delta,max(b.high for b in leg),min(b.low for b in leg))
            day = t.astimezone(NY).date()
            prof = daily_profile_lifecycle(m15,day,t,include_reconstruction=False,reference_m5=bars)
            w = prof['weekly_background']
            def relation(dirs):
                return ('双向条件并存' if side in dirs and -side in dirs else '支持向该侧推进' if side in dirs
                        else '与向该侧推进冲突' if -side in dirs else '方向待定')
            directions = [c['direction'] for c in prof['candidates'] if c['observed_sequence'] and c['status']=='active']
            lines.append(f'极值棒开盘前 · 日 {prof["profile_label"]}（{relation(directions)}）；周 {w["label"]}（{relation([w.get("scenario_direction")])}）')
            a,z = session_windows(day)['asia']
            phases = po3_zones(m15,a,z,_day_bounds(day)[1],known)
            lines.append('截至极值棒收线的 PO3 · '+phases['reason'])
            warm = span(t-2*HOUR,t)
            lines.extend(('近端参照（美东时间） · '+price_purposes([anchor],warm),
                          '位移（美东时间） · '+displacement([anchor],warm)[0]))
            after = span(known,min(known+HOUR,stop))
            if after and covered(after,known,after[-1].time+STEP):
                lines.append(f'事后至 {ny(after[-1].time+STEP)} · 收 {after[-1].close:.2f}，距极值 {after[-1].close-price:+.2f}')
                lines.append(local_structure(after,warm+[anchor]))
            else:
                lines.append('事后连续 M5 待观察')
            lines.append('行情 TMGM XAUUSD M5 · 课程《时间（二）》925–1105 秒、《时间（三）》周型、基础教学 239–305 秒。服务器历史时差按项目分段换算。')
            records.append((scope+'_extreme',t,body[-1].time+STEP,'｜'.join(lines),price,price))
        return records
    return [r for d in days for r in describe('day',[d])]+describe('week',days)
