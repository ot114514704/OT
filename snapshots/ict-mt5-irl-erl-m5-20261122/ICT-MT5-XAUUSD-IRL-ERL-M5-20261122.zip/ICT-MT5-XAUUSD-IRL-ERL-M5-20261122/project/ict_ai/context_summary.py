"""Compact day-open evidence for the chart; no inferred directional commitment."""
from copy import deepcopy
from datetime import datetime, time, timezone
from functools import lru_cache

from brooks_ai.types import utc_time
from .daily_context import daily_weekly_context, M5
from .delivery import delivery_hypotheses
from .timebase import NY


@lru_cache(maxsize=32)
def _frozen_summary(prefix, cutoff):
    evidence = daily_weekly_context(prefix, cutoff)
    delivery = delivery_hypotheses(evidence, prefix, cutoff)
    paths=[{k:r[k] for k in ('id','route','timeframe','origin_known_at','origin_close',
                            'direction','target','target_reference_price','stage',
                            'source_video_seconds','close_invalidation_known_at')}
           for r in delivery['hypotheses']]
    price = evidence.get('last_observed_price')
    frames = []
    for name, frame in evidence['frames'].items():
        reference = frame['periods'][-1] if frame['periods'] else None
        targets = frame['dol_candidates']
        buys = [p for p in targets if p['kind']=='H']
        sells = [p for p in targets if p['kind']=='L']
        gaps = [g for g in frame['fvg_candidates'] if price is not None
                and g['lower']<=price<=g['upper'] and not g['close_invalidation_known_at']]
        compact = lambda p: {k:p[k] for k in ('price','available_at','anchor_period_start')}
        frames.append({'timeframe':name, 'reference_period':reference,
                       'location':None if reference is None or price is None else
                                  'above' if price>reference['high'] else 'below' if price<reference['low'] else 'inside',
                       'buy_side_levels':[compact(p) for p in buys[:3]],
                       'sell_side_levels':[compact(p) for p in sells[:3]],
                       'buy_side_total':len(buys), 'sell_side_total':len(sells),
                       'uncertain_level_count':len(frame['uncertain_target_candidates']),
                       'overlapping_fvgs':[{k:g[k] for k in ('lower','upper','direction','available_at','state')}
                                           for g in gaps],
                       'complete_period_count':len(frame['periods'])})
    return {'status':'frozen_day_open_evidence', 'cutoff_utc':cutoff.isoformat(),
            'price':price, 'price_available_at':evidence.get('price_available_at'),
            'frames':frames, 'delivery_paths':paths,
            'delivery_rejected_pair_counts':delivery['rejected_pair_counts'],
            'bias_selected':None, 'dol_selected':None,
            'execution_allowed':False, 'historical_clock_verified':False,
            'source_video':evidence['source_video'], 'source_seconds':evidence['source_seconds'],
            'basis':evidence['basis'], 'listed_levels_per_side_limit':3,
            'interpretation':'Prior completed D1/W1 and confirmed old swings, frozen at NY midnight. Reference periods are not selected ICT dealing ranges; listed levels are not a selected DOL.'}


def daily_open_context(bars, day, as_of):
    cutoff = datetime.combine(day, time(0), NY).astimezone(timezone.utc)
    if utc_time(as_of)<cutoff:
        return {'status':'not_yet_available','cutoff_utc':cutoff.isoformat(),'frames':[],
                'execution_allowed':False}
    # Cache keys include all causal source rows, so a corrected or missing bar
    # invalidates the evidence. Never key on date alone or use today's final OHLC.
    prefix = tuple(b for b in bars if b.time+M5<=cutoff)
    return deepcopy(_frozen_summary(prefix, cutoff))
