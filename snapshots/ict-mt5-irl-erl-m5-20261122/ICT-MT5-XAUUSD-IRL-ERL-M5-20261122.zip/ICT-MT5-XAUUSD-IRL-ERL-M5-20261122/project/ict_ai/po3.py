"""Retrospective PO3 geometry for chart annotation, not an order signal.

Concept source: 时间（一） transcript 16:51–18:03. Thresholds below are
explicit research choices, not rules quoted from ICT or measured win rates.
"""
from datetime import timedelta


def po3_zones(bars, asia_start, asia_end, finish, as_of, period=timedelta(minutes=15)):
    cutoff=min(finish,as_of)
    closed=[b for b in bars if asia_start<=b.time and b.time+period<=cutoff]
    asia=[b for b in closed if b.time<asia_end]
    result={'status':'incomplete','zones':[], 'source':'时间（一）16:51–18:03',
            'basis':'M15 价格路径候选；亚洲完整区间的净位移/振幅≤0.35、扫荡收回、对侧连续两根收盘突破为工程识别条件；不代表机构真实意图。',
            'future_data_safe':True,'actual_orders_observed':False,'execution_allowed':False,
            'phase_evidence':{'A':{'status':'not_confirmed','available_at':None},
                              'M':{'status':'not_confirmed','available_at':None},
                              'D':{'status':'not_confirmed','available_at':None}}}
    if not asia or len(asia)!=int((asia_end-asia_start)/period) or any(b.time!=asia_start+i*period for i,b in enumerate(asia)):
        result['reason']='亚洲参考窗口未完整，PO3 暂不标注。'
        result['phase_evidence']['A'].update(status='incomplete',reason='完整连续 K 线不足，不能冻结积累范围。')
        return result
    low=min(b.low for b in asia);high=max(b.high for b in asia)
    if high<=low or abs(asia[-1].close-asia[0].open)/(high-low)>.35:
        result['reason']='亚洲窗口单向位移较大，不把它强制视为积累区。'
        result['phase_evidence']['A'].update(status='rejected',available_at=asia_end.isoformat(),reason='净位移/振幅超过工程阈值；形状不能单独证明积累。')
        return result
    def zone(name,part,start,end,known):
        return {'phase':name,'start':start.isoformat(),'end':end.isoformat(),'lower':min(b.low for b in part),'upper':max(b.high for b in part),'available_at':known.isoformat(),'candidate':True}
    result['zones'].append(zone('A',asia,asia_start,asia_end,asia_end))
    result['phase_evidence']['A'].update(status='candidate',available_at=asia_end.isoformat(),reason='连续亚洲窗口已完成且净位移/振幅不超过工程阈值；这是范围候选，不是订单事实。')
    after=[b for b in closed if b.time>=asia_end]
    # Find an ordered excursion/reclaim. A candle sweeping both sides has no
    # known intrabar ordering and cannot establish the manipulation direction.
    active=None;manipulation=None;side=None;reclaim=None
    for i,b in enumerate(after):
        if i and b.time!=after[i-1].time+period:
            active=None
        if b.high>high and b.low<low:
            active=None;continue
        if active is None:
            if b.high>high: active=(i,1)
            elif b.low<low: active=(i,-1)
        if active is not None:
            first,direction=active
            returned=low<=b.close<=high
            if returned:
                manipulation=after[first:i+1];side=direction;reclaim=i
                break
    if manipulation is None:
        result['reason']='仅识别 A 积累候选，尚未出现可排序的越界扫荡及收回。'
        result['phase_evidence']['M'].update(status='not_confirmed',reason='尚无单侧、可排序的越界与收回；双侧同棒不推断盘内顺序。')
        result['phase_evidence']['D'].update(status='blocked_by_M',reason='M 未确认，不能确认派发。')
        return result
    returned_at=after[reclaim].time+period
    result['zones'].append(zone('M',manipulation,manipulation[0].time,returned_at,returned_at))
    result['phase_evidence']['M'].update(status='candidate',available_at=returned_at.isoformat(),side='above_range' if side==1 else 'below_range',reason='已冻结范围的一侧先越界，随后收回范围内；OHLC 只确认价格路径，不确认真实止损量。')
    extreme=max(c.high for c in manipulation) if side==1 else min(c.low for c in manipulation)
    def beyond(c):
        return c.close<low if side==1 else c.close>high
    for i in range(reclaim+1,len(after)):
        a,b=after[i-1],after[i]
        gap=b.time!=a.time+period
        invalid=b.high>extreme if side==1 else b.low<extreme
        if gap or invalid:
            reason=('M 后报价中断，无法确认原路径是否延续。' if gap else
                    'D 确认前价格再次突破 M 扫荡极值，原路径失效。')
            result.update(status='partial',reason=reason)
            result['phase_evidence']['D'].update(status='unknown_due_to_gap' if gap else 'invalidated',
                                                 available_at=(b.time+period).isoformat(),reason=reason)
            return result
        if i==reclaim+1 or not (beyond(a) and beyond(b)):continue
        part=[a,b]
        for c in after[i+1:]:
            if c.time!=part[-1].time+period or not beyond(c):break
            part.append(c)
        result['zones'].append(zone('D',part,a.time,part[-1].time+period,b.time+period))
        result['status']='candidate'
        result['direction']='bearish' if side==1 else 'bullish'
        result['reason']='完整亚洲参考区间后，价格'+('向上扫荡收回，随后向下' if side==1 else '向下扫荡收回，随后向上')+'越过区间对侧，连续两根 M15 收盘在外；标为 PO3 候选。'
        result['phase_evidence']['D'].update(status='candidate',available_at=(b.time+period).isoformat(),direction=result['direction'],reason='M 之后出现对侧连续两根闭合收盘并保持方向性交付；这是 D 候选。')
        return result
    result['status']='partial'
    result['phase_evidence']['D'].update(status='not_confirmed',reason='A 与 M 已出现，但尚无对侧连续两根收盘扩张；保留部分路径，不晋级完整 PO3。')
    result['reason']='已识别 A 积累及 M 操纵候选；尚无对侧连续两根收盘扩张，保留部分路径，D 派发待确认。'
    return result
