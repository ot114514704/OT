"""Ordered, single-exposure paper replay of frozen limit ideas."""
from bisect import bisect_left, bisect_right
from dataclasses import asdict, replace
from datetime import timedelta
import math

from brooks_ai.risk import entry_allowed, size_volume
from .quote_preflight import limit_quote_check
from .tick_limit import simulate_tick_limit
from .timebase import NY


def replay_tick_portfolio(templates, ticks, spec, cutoff, initial_equity, risk, *, preflight=True):
    """Price decisions see only pre-activation ticks and realized account state."""
    templates = sorted(templates, key=lambda order: (order.available_at, order.id))
    times = [quote.time for quote in ticks]
    if any(a > b for a, b in zip(times, times[1:])):
        raise ValueError("Keep recorded quote order")
    if not math.isfinite(initial_equity) or initial_equity <= 0 or cutoff.utcoffset() is None:
        raise ValueError("Positive seed equity and an aware cutoff required")
    if (not 0 < risk["risk_fraction"] <= .01 or not 0 < risk["max_drawdown"] < 1
            or not 0 < risk["daily_loss_limit"] < 1 or risk["max_consecutive_losses"] < 1):
        raise ValueError("Invalid account risk limits")
    if len({item.id for item in templates}) != len(templates):
        raise ValueError("Candidate IDs must be unique")
    equity = day_start = peak = initial_equity
    drawdown = 0.0
    losing = 0
    day = unknown = active = None
    decisions, settled = [], []

    def settle(at, quote_end):
        nonlocal equity, peak, drawdown, losing, unknown, active
        if active is None:
            return None
        order, quote_start, budget = active
        result = simulate_tick_limit(order, ticks[quote_start:quote_end], spec, at)
        state = result["status"]
        if state in ("pending", "open_censored_at_cutoff"):
            return result
        if state.startswith("censored"):
            unknown = order.id
        pnl = result["pnl_net"]
        if state == "closed":
            equity += pnl
            peak = max(peak, equity)
            drawdown = max(drawdown, (peak - equity) / peak)
            losing = losing + 1 if pnl < 0 else 0
        settled.append({"order_id": order.id, "outcome": result, "realized_equity_after": equity,
                        "loss_exceeded_original_budget": pnl is not None and -pnl > budget + 1e-8})
        active = None
        return result

    for template in templates:
        known = template.available_at
        if known > cutoff:
            break
        # Quotes stamped exactly at a signal cutoff belong to the next step,
        # so one quote cannot close a prior position and free risk for that signal.
        i = bisect_left(times, known)
        settle(known, i)
        local_day = known.astimezone(NY).date()
        if day != local_day:
            day, day_start = local_day, equity
        record = {"id": template.id, "available_at": known.isoformat(), "realized_equity_before": equity,
                  "day_start_equity": day_start, "consecutive_losses_before": losing}
        decisions.append(record)
        if unknown is not None:
            record.update(status="blocked_by_unknown_exposure", blocking_order=unknown)
            continue
        if active is not None:
            record.update(status="blocked_by_existing_order", blocking_order=active[0].id)
            continue
        permitted, reason = entry_allowed(equity, peak, day_start, risk, losing)
        if not permitted:
            record.update(status="blocked_by_risk_limit", reason=reason)
            continue
        if preflight:
            check = limit_quote_check(template, ticks[i - 1] if i else None, timedelta(seconds=10))
            record["quote_preflight"] = check
            if check["status"] != "stop_side_clear":
                record["status"] = "withheld_before_activation"
                continue
        budget = equity * risk["risk_fraction"]
        loss_per_lot = ((abs(template.entry - template.stop) + 2 * spec.slippage)
                        * spec.contract_size + spec.commission_round_turn)
        volume = size_volume(budget, loss_per_lot, spec)
        if not volume:
            record.update(status="minimum_size_exceeds_budget", risk_budget=budget)
            continue
        order = replace(template, volume=volume)
        active = (order, i, budget)
        record.update(status="accepted", order=asdict(order), risk_budget=budget,
                      estimated_stop_risk=volume * loss_per_lot)
    remaining = settle(cutoff, bisect_right(times, cutoff))
    return {"initial_equity": initial_equity, "final_realized_equity": equity,
            "max_realized_drawdown_fraction": drawdown, "decisions": decisions, "completed": settled,
            "active_at_cutoff": remaining if active is not None else None, "unknown_exposure_order": unknown,
            "risk_limits": dict(risk), "preflight_enabled": preflight, "orders_sent": 0, "execution_allowed": False}
