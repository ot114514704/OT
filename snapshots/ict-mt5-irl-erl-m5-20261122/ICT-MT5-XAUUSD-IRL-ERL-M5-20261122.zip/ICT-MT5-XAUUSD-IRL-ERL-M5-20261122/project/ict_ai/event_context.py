"""Freeze D1/W1 evidence before a candidate's sweep; do not invent prior bias.

The eventual candidate side is evaluated at motif confirmation, not backdated
to the earlier context cutoff. Source ideas: bias/DOL video 267–404, 629–794,
932–1058 seconds. Range positioning and compatibility summaries are engineering
descriptions, not source-qualified directional decisions.
"""
import hashlib
import json

from brooks_ai.types import utc_time
from .daily_context import daily_weekly_context
from .delivery import delivery_hypotheses


def event_context(event, bars, as_of):
    now = utc_time(as_of)
    known = utc_time(event['available_at'])
    frozen_at = utc_time(event['sweep_started_at'])
    if event.get('kind') != 'sweep_mss_fvg_candidate' or event['side'] not in (-1, 1):
        raise ValueError('Complete directional motif required')
    if frozen_at > known:
        raise ValueError('Sweep cannot begin after motif confirmation')
    if now < known:
        return {'event_id':event['id'], 'status':'not_yet_available',
                'execution_allowed':False, 'orders_sent':0}
    context = daily_weekly_context(bars, frozen_at)
    routes = delivery_hypotheses(context, bars, frozen_at)
    frozen = {'context':context, 'delivery_hypotheses':routes}
    encoded = json.dumps(frozen, sort_keys=True, separators=(',',':'), ensure_ascii=False).encode()
    price = context.get('last_observed_price')
    frames = {}
    for timeframe, frame in context['frames'].items():
        last = frame['periods'][-1] if frame['periods'] else None
        position = None
        if last is not None and price is not None:
            width = last['high']-last['low']
            position = {'reference_period_date':last['date'],
                        'reference_available_at':last['available_at'],
                        'reference_low':last['low'], 'reference_high':last['high'],
                        'observed_close':price, 'price_available_at':context['price_available_at'],
                        'relative_position':(price-last['low'])/width if width else None,
                        'location':'above' if price>last['high'] else 'below' if price<last['low'] else 'inside',
                        'selected_ict_dealing_range':False}
        targets = frame['dol_candidates']
        same = [p for p in targets if p['direction_from_current_price']==event['side']]
        opposite = [p for p in targets if p['direction_from_current_price']!=event['side']]
        gaps = [g for g in frame['fvg_candidates'] if price is not None
                and g['lower']<=price<=g['upper'] and not g['close_invalidation_known_at']]
        pending = [r for r in routes['hypotheses'] if r['timeframe']==timeframe
                   and r['stage']=='idea_pending_validation']
        frames[timeframe] = {'last_completed_period_position':position,
                            'same_direction_untouched_level_candidates':same,
                            'opposite_direction_untouched_level_candidates':opposite,
                            'price_overlapping_uninvalidated_fvgs':gaps,
                            'uncertain_target_candidates':frame['uncertain_target_candidates'],
                            'same_direction_route_ideas':[r for r in pending if r['direction']==event['side']],
                            'opposite_direction_route_ideas':[r for r in pending if r['direction']!=event['side']]}
    reasons = []
    for timeframe, frame in frames.items():
        p = frame['last_completed_period_position']
        if p:
            reasons.append(f"{timeframe}：扫荡前价格 {price:.2f} 位于最近完整周期 {p['reference_low']:.2f}–{p['reference_high']:.2f} 的{ {'above':'上方','below':'下方','inside':'内部'}[p['location']]}。")
        else:
            reasons.append(f'{timeframe}：没有已闭合且覆盖齐全的参考周期。')
        reasons.append(f"{timeframe}：候选方向上有 {len(frame['same_direction_untouched_level_candidates'])} 个未观察重访的旧摆动目标；反方向有 {len(frame['opposite_direction_untouched_level_candidates'])} 个。目标数量不构成方向评分。")
    return {'event_id':event['id'], 'status':'frozen_background_evidence_only',
            'context_cutoff_utc':frozen_at.isoformat(), 'assessment_available_at':known.isoformat(),
            'candidate_side_assessed_at_confirmation':event['side'],
            'origin':'historical_prefix_reconstruction_not_recorded_prior_bias',
            'frozen_sha256':hashlib.sha256(encoded).hexdigest(), 'frozen_evidence':frozen,
            'frames':frames, 'brief_reasons':reasons,
            'planning_context':{}, 'bias_selected':None, 'dol_selected':None,
            'qualified_context':False, 'execution_allowed':False, 'orders_sent':0,
            'remaining':['Validate directional delivery and higher-timeframe hierarchy',
                         'Record a sourced bias, PDA and DOL before the sweep',
                         'Verify historical clocks, calendar and executable costs'],
            'source_video':'research/ict_price_videos/bias_dol/integration.json',
            'source_seconds':[267,404,629,794,932,1058],
            'limitations':['Latest completed period is a reference range, not a selected ICT dealing range',
                           'Candidate side is learned at confirmation; it is not proof of a prior bias',
                           'Uncertain quote coverage remains unknown; real stop orders are not observed']}
