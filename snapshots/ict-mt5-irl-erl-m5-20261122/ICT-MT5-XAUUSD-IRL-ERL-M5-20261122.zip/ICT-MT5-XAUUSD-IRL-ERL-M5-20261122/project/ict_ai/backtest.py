"""Causal OHLC limit-order research, never a broker execution interface.

Buy entry uses Ask=Bid+bar spread; sell entry uses Bid. Long exits use Bid,
short exits Ask. Constant intrabar spread and touch fills are assumptions.
https://www.metatrader5.com/en/terminal/help/trading/general_concept
"""
from dataclasses import dataclass
from datetime import datetime, timedelta
import math
from .timebase import NY


@dataclass(frozen=True)
class LimitStudyOrder:
    id: str
    side: int
    available_at: datetime
    expires_at: datetime
    entry: float
    stop: float
    target: float
    volume: float
    flat_ny_hour: int = 16
    flat_ny_minute: int = 50

    def __post_init__(self):
        if not self.id or self.side not in (-1,1):
            raise ValueError('ID and direction required')
        if any(t.tzinfo is None for t in (self.available_at,self.expires_at)) or self.expires_at<=self.available_at:
            raise ValueError('Aware availability and later expiry required')
        if not all(math.isfinite(v) and v>0 for v in (self.entry,self.stop,self.target,self.volume)):
            raise ValueError('Finite positive prices and size required')
        if self.side*(self.entry-self.stop)<=0 or self.side*(self.target-self.entry)<=0:
            raise ValueError('Protective stop and directional target required')
        if not 0<=self.flat_ny_hour<=23 or not 0<=self.flat_ny_minute<=59:
            raise ValueError('Valid intraday flatten clock required')


def simulate_limit(order,bars,spec,as_of,period=timedelta(minutes=5),spread_multiplier=1.0,
                   *, cancel_pending_on_target=False):
    """Only consume closed bars; return censored states rather than fake closes.

    Entry cannot use the formation candle. A limit touch within the entry bar
    cannot prove that its earlier high/low happened AFTER entry. We book a
    protective stop when reached, but defer that bar's target unless the limit
    was marketable at its open. The deferred target is an uncertainty flag.
    A missing quote interval censors both open trades and pending-order paths.
    All bar outcomes become known at bar close, not a guessed tick time.
    """
    if as_of.tzinfo is None or period<=timedelta(0) or not math.isfinite(spread_multiplier) or spread_multiplier<=0:
        raise ValueError('Aware cutoff, positive period and spread multiplier required')
    if any(a.time>=b.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Unique chronological quotes required')
    if spec.account_currency!=spec.profit_currency:
        raise ValueError('Historical FX conversion is not implemented')
    if order.volume<spec.volume_min-1e-9 or order.volume>spec.volume_max+1e-9 or abs(order.volume/spec.volume_step-round(order.volume/spec.volume_step))>1e-7:
        raise ValueError('Volume outside instrument grid')
    result={'order_id':order.id,'status':'not_yet_available','pnl_net':None,'filled':False,
            'source_costs_verified':spec.costs_verified,'intrabar_spread_assumed_constant':True,
            'limit_queue_and_liquidity_verified':False,'ambiguous':False,
            'entry_bar_target_deferred':False,'orders_sent':0,'execution_allowed':False}
    if as_of<order.available_at:return result
    result['status']='pending'
    selected=[b for b in bars if b.time>=order.available_at and b.time+period<=as_of]
    entry=None;previous=None

    def exit_trade(b,price,reason):
        gross=order.side*(price-entry)*spec.contract_size*order.volume
        commission=spec.commission_round_turn*order.volume
        result.update(status='closed',exit_bar_open=b.time.isoformat(),
                      outcome_available_at=(b.time+period).isoformat(),exit=price,
                      pnl_gross=gross,commission=commission,pnl_net=gross-commission,
                      reason=reason,overnight_held=False,swap_charged=0.0,
                      swap_basis='Intraday flatten; no simulated overnight holding')
        return result

    for b in selected:
        if (previous is None and b.time!=order.available_at) or (previous is not None and b.time!=previous+period):
            result.update(status='censored_quote_gap' if entry is not None else 'censored_pending_quote_gap',
                          outcome_available_at=b.time.isoformat(),reason='Unknown path across missing quote slots')
            return result
        previous=b.time
        local=b.time.astimezone(NY)
        spread=b.spread*spread_multiplier
        quote_open=b.open if order.side==1 else b.open+spread
        at_flat=(local.hour,local.minute)>=(order.flat_ny_hour,order.flat_ny_minute)
        if at_flat:
            if entry is not None:return exit_trade(b,quote_open-order.side*spec.slippage,'intraday_flatten')
            result.update(status='cancelled_session_end',outcome_available_at=b.time.isoformat());return result
        newly_filled=False;at_open=False
        if entry is None:
            if b.time>=order.expires_at:
                result.update(status='expired',outcome_available_at=b.time.isoformat());return result
            entry_open=b.open+spread if order.side==1 else b.open
            touched=b.low+spread<=order.entry if order.side==1 else b.high>=order.entry
            at_open=entry_open<=order.entry if order.side==1 else entry_open>=order.entry
            if cancel_pending_on_target and not at_open:
                target_seen=b.high>=order.target if order.side==1 else b.low<=order.target
                if target_seen:
                    target_first=not touched or order.side*(b.open-order.target)>=0
                    result.update(status='cancelled_target_before_entry' if target_first else 'censored_entry_target_order',
                                  outcome_available_at=(b.time+period).isoformat(),ambiguous=not target_first)
                    return result
            if not touched:continue
            entry=entry_open if at_open else order.entry
            result.update(filled=True,entry=entry,entry_bar_open=b.time.isoformat(),
                          entry_known_at=(b.time+period).isoformat(),entry_at_open=at_open)
            if at_open and order.side*(quote_open-order.stop)<=0:
                # A previously active pending order cannot be cancelled using
                # the newly observed open as though cancellation preceded fill.
                result['protective_stop_breached_at_entry_open']=True
            newly_filled=True
        # For a carried position the executable open precedes both intrabar
        # extremes. Resolve a crossed resting exit there before testing wicks.
        if not newly_filled:
            if order.side*(quote_open-order.target)>=0:
                return exit_trade(b,order.target,'target')
            if order.side*(quote_open-order.stop)<=0:
                return exit_trade(b,quote_open-order.side*spec.slippage,'stop')
        stop_hit=b.low<=order.stop if order.side==1 else b.high+spread>=order.stop
        target_hit=b.high>=order.target if order.side==1 else b.low+spread<=order.target
        if stop_hit:
            result['ambiguous']=result['ambiguous'] or target_hit
            price=min(order.stop,quote_open) if order.side==1 else max(order.stop,quote_open)
            return exit_trade(b,price-order.side*spec.slippage,'stop_first_ambiguous' if target_hit else 'stop')
        if target_hit:
            if newly_filled and not at_open:
                result.update(ambiguous=True,entry_bar_target_deferred=True)
            else:
                return exit_trade(b,order.target,'target')
    if entry is not None:
        result['status']='open_censored_at_cutoff'
        if selected:
            last=selected[-1];mark=last.close if order.side==1 else last.close+last.spread*spread_multiplier
            result['unrealized_before_exit_costs']=order.side*(mark-entry)*spec.contract_size*order.volume
    elif not selected or selected[-1].time+period<min(as_of,order.expires_at):
        result['status']='pending_censored_at_cutoff'
    elif as_of>=order.expires_at:
        result.update(status='expired',outcome_available_at=order.expires_at.isoformat())
    return result
