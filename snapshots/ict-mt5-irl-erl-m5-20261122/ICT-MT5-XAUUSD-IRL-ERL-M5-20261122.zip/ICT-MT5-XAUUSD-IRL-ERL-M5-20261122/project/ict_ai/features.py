"""Causal geometric observations, separate from contextual trade signals."""
from __future__ import annotations
from datetime import datetime, timedelta
from brooks_ai.types import Bar


def geometric_fvgs(bars: list[Bar], period: timedelta, as_of: datetime) -> list[dict]:
    """ICT 精翻 pp. 89-90, geometry only. Bar.time is OPEN time.

    Third-bar close is the earliest event availability. Input time basis is
    preserved; this function cannot calibrate the MT5 source clock.
    """
    if period <= timedelta(0) or as_of.tzinfo is None or as_of.utcoffset() is None:
        raise ValueError("Positive period and timezone-aware cutoff required")
    if any(a.time >= b.time for a, b in zip(bars, bars[1:])):
        raise ValueError("Bars must be strictly chronological without duplicates")
    events = []
    for a, b, c in zip(bars, bars[1:], bars[2:]):
        if c.time + period > as_of:
            break
        if b.time - a.time != period or c.time - b.time != period:
            continue
        if c.low > a.high:
            direction, lower, upper = "bullish", a.high, c.low
        elif c.high < a.low:
            direction, lower, upper = "bearish", c.high, a.low
        else:
            continue
        if not (b.low <= lower and b.high >= upper):
            continue
        events.append({"kind": "geometric_fvg", "direction": direction, "lower": lower, "upper": upper, "formation_bar_open": c.time.isoformat(), "available_at": (c.time + period).isoformat(), "source_pages": [89, 90], "trade_signal": False})
    return events
