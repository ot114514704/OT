struct WindowHit { int ix,l,t,r,b; bool caption; };
WindowHit hits[];
bool hadScale=true,hadMouse=false,viewReady=false;
string hoverKey="";
struct ProfileHit {int left,right,y;datetime start;bool daily;string body;};
ProfileHit profileHits[];
datetime profileStart=0,candidateStart=0;
bool profileDaily=false,candidateDaily=false;
int profileTab=0,profilePages[3]={0,0,0};
ulong candidateSince=0;
string profileBase="";

void addProfileHit(int left,int right,int y,int index,string body){
   int n=ArraySize(profileHits);ArrayResize(profileHits,n+1);
   profileHits[n].left=left;profileHits[n].right=right;profileHits[n].y=y;
   profileHits[n].daily=marks[index].kind=="day";
   profileHits[n].start=marks[index].start;profileHits[n].body=body;
}
int lastMouseX=-1,lastMouseY=-1;
struct DetailHit {int x,y,z,b,priority;bool segment;string text;};
DetailHit detailHits[];
int hoverPage=0,hoverPages=1;
string hoverSource="";
string hoverBody="";
int hoverX=-1,hoverY=-1,pagerX=-1,pagerY=-1;
const int pagerWidth=116,pagerHeight=23;
int pagerAnchorX=-1,pagerAnchorY=-1,pagerChartW=-1,pagerChartH=-1;
string pagerSource="";

void placePager(int w,int h,int tipTop,int tipWidth){
   if(pagerSource==hoverSource && pagerAnchorX==hoverX && pagerAnchorY==hoverY &&
      w==pagerChartW && h==pagerChartH && pagerX>=0) return;
   pagerSource=hoverSource;pagerAnchorX=hoverX;pagerAnchorY=hoverY;pagerChartW=w;pagerChartH=h;
   int best=2147483647;
   for(int i=0;i<8;i++){
      int x=hoverX+((i%2)==0?10:-pagerWidth-10);
      int y=hoverY-pagerHeight/2+(i/2==1?32:i/2==2?-32:i/2==3?57:0);
      x=MathMax(0,MathMin(w-pagerWidth,x));y=MathMax(0,MathMin(h-pagerHeight,y));
      int r=x+pagerWidth,b=y+pagerHeight,cost=MathAbs(y+pagerHeight/2-hoverY);
      if(x<=hoverX && hoverX<=r && y<=hoverY && hoverY<=b)cost+=5000;
      if((r>w-830 && y<90 && b>62) || ((showDOL || showPool) && r>dolPanelLeft && y<dolPanelBottom && b>90))cost+=2000;
      if((y<h && b>=h-44) || (x<=tipWidth+8 && b>tipTop && y<h-44))cost+=800;
      for(int k=0;k<ArraySize(detailHits);k++){
         DetailHit p=detailHits[k];
         if(x<=MathMax(p.x,p.z)+3 && r>=MathMin(p.x,p.z)-3 && y<=MathMax(p.y,p.b)+3 && b>=MathMin(p.y,p.b)-3)
            cost+=p.segment?12:60;
      }
      for(int k=0;k<ArraySize(hits);k++){
         WindowHit p=hits[k];
         if(x<p.r && r>p.l && y<p.b && b>p.t)cost+=p.caption?70:6;
      }
      if(cost<best){best=cost;pagerX=x;pagerY=y;}
   }
}

bool onHoverPager(int x,int y){
   if(hoverPages<2 || pagerX<0) return false;
   // A small bridge keeps the same item while crossing from its wick to the buttons.
   bool buttons=x>=pagerX-2 && x<=pagerX+pagerWidth+2 && y>=pagerY-2 && y<=pagerY+pagerHeight+2;
   double dx=MathMax(pagerX,MathMin(pagerX+pagerWidth,hoverX))-hoverX;
   double dy=pagerY+pagerHeight/2-hoverY,dist=dx*dx+dy*dy;
   double t=dist>0?((x-hoverX)*dx+(y-hoverY)*dy)/dist:0;
   bool bridge=t>0 && t<=1 && MathPow(x-hoverX-t*dx,2)+MathPow(y-hoverY-t*dy,2)<=64;
   return buttons || bridge;
}
void hoverPagerButton(string id,string caption,int x,int y,int width,bool enabled){
   string name=prefix+"TIP_nav"+id;
   ObjectCreate(0,name,OBJ_BUTTON,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,name,OBJPROP_XSIZE,width);ObjectSetInteger(0,name,OBJPROP_YSIZE,pagerHeight);
   ObjectSetInteger(0,name,OBJPROP_BGCOLOR,C'37,48,57');ObjectSetInteger(0,name,OBJPROP_BORDER_COLOR,C'73,85,97');
   ObjectSetInteger(0,name,OBJPROP_COLOR,enabled?clrWhite:clrDarkGray);ObjectSetInteger(0,name,OBJPROP_FONTSIZE,9);
   ObjectSetInteger(0,name,OBJPROP_ZORDER,40);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,name,OBJPROP_TEXT,caption);
   ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
}
void detailHit(int x,int y,int z,int b,string text,int priority=3,bool segment=false){
   if(text=="" || text=="\n") return;
   int n=ArraySize(detailHits);ArrayResize(detailHits,n+1,128);
   detailHits[n].x=x;detailHits[n].y=y;detailHits[n].z=z;detailHits[n].b=b;
   detailHits[n].text=text;detailHits[n].priority=priority;detailHits[n].segment=segment;
}
void findDetail(int x,int y,string &key,string &body){
   int best=0;
   for(int i=ArraySize(detailHits)-1;i>=0;i--){
      DetailHit p=detailHits[i];
      if(p.priority<=best || x<MathMin(p.x,p.z)-3 || x>MathMax(p.x,p.z)+3 ||
         y<MathMin(p.y,p.b)-3 || y>MathMax(p.y,p.b)+3) continue;
      if(p.segment){
         double dx=p.z-p.x,dy=p.b-p.y,len=dx*dx+dy*dy;
         double f=len>0?MathMax(0.,MathMin(1.,((x-p.x)*dx+(y-p.y)*dy)/len)):0.;
         if(MathPow(x-p.x-f*dx,2)+MathPow(y-p.y-f*dy,2)>16) continue;
      }
      best=p.priority;key="detail"+IntegerToString(i);body=p.text;
   }
}

datetime nyWall(datetime raw){
   for(int i=0;i<ArraySize(nyClock);i++)
      if(raw>=nyClock[i].start && raw<nyClock[i].finish)return raw+nyClock[i].offset;
   return 0;
}
datetime nyRaw(datetime local){
   for(int i=0;i<ArraySize(nyClock);i++){
      datetime raw=local-nyClock[i].offset;
      if(raw>=nyClock[i].start && raw<nyClock[i].finish)return raw;
   }
   return 0;
}
string easternTime(datetime raw,int mode=TIME_DATE|TIME_MINUTES){
   datetime local=nyWall(raw);
   return local?TimeToString(local,mode):"时差待核";
}
void screenNote(string name,int x,int y,string s,color ink,string tip,int size=8){
   if(ObjectFind(0,name)<0) ObjectCreate(0,name,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,name,OBJPROP_COLOR,ink);ObjectSetInteger(0,name,OBJPROP_FONTSIZE,size);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,name,OBJPROP_TEXT,s);
   bool dol=StringFind(name,prefix+"DOLVIEW_")==0;
   ObjectSetString(0,name,OBJPROP_TOOLTIP,dol?tip:"\n");
   if(!dol && StringFind(name,prefix+"Z_")!=0 && tip!="\n")
      detailHit(x,y,x+textWidth(s),y+15,tip);
}
void windowHit(int i,int x,int y,int right,int bottom,bool caption=false){
   int n=ArraySize(hits);ArrayResize(hits,n+1,64);
   hits[n].ix=i;hits[n].l=x;hits[n].r=right;hits[n].t=y;hits[n].b=bottom;hits[n].caption=caption;
}
void sessionCaption(int i,int lane,int l,int r,int top,int bottom,int w,int h,color ink){
   string caption=lane==0?"TK":lane==1?"EU":"NY";
   TextSetFont("Microsoft YaHei",-70);
   uint tw,th;
   if(!TextGetSize(caption,tw,th)) return;
   int width=(int)tw+6,height=(int)th+4;
   if(r-l<width) return;
   int x=(l+r-width)/2;
   int minY=(x+width>w-(w<830?727:829))?88:56;
   if(w<830 && x+width>w-108) minY=116;
   for(int step=0;step<4;step++){
      int offset=8+(step/2)*(height+3);
      int y=step%2==0?top-offset-height:bottom+offset;
      if(y<minY || y+height>h-56) continue;
      bool occupied=false;
      for(int j=0;j<ArraySize(hits);j++){
         WindowHit a=hits[j];
         if(a.caption && x<a.r+3 && x+width>a.l-3 && y<a.b+2 && y+height>a.t-2){occupied=true;break;}
      }
      if(occupied) continue;
      string tip=marks[i].label;StringReplace(tip,"｜","\n");
      screenNote(prefix+"Z_"+IntegerToString(i),x,y,caption,ink,tip,7);
      windowHit(i,x,y,x+width,y+height,true);
      return;
   }
}
uint sourceOver(uint fg,uint bg){
   uint fa=fg>>24,ba=((bg>>24)*(255-fa)+127)/255,a=fa+ba;
   if(a==0) return 0;
   return (a<<24)|(((((fg>>16)&255)*fa+((bg>>16)&255)*ba)/a)<<16)|
          (((((fg>>8)&255)*fa+((bg>>8)&255)*ba)/a)<<8)|(((fg&255)*fa+(bg&255)*ba)/a);
}
void sessionBoxes(int w,int h){
   ObjectsDeleteAll(0,prefix+"Z_");ArrayResize(hits,0);
   for(int i=0;i<ArraySize(marks);i++){
      Mark m=marks[i];
      if(m.kind=="week_sweep" || (m.kind=="path" && showPath)){
         int ax,ay,bx,by;
         if(ChartTimePriceToXY(0,0,m.start,m.first,ax,ay) && ChartTimePriceToXY(0,0,m.finish,m.last,bx,by) &&
            MathMin(ax,bx)<w && MathMax(ax,bx)>=0)
            detailHit(ax,ay,bx,by,m.kind=="week_sweep"?m.label:"周概况折线",1,true);
      }
      if(m.kind=="week_sweep"){
         int ex,ey;
         if(ChartTimePriceToXY(0,0,m.finish,m.last,ex,ey) && ex>0 && ex-130<w && ey>=0 && ey<h){
            int ty=StringFind(m.label,"买方")>=0?ey-16:ey;
            windowHit(i,MathMax(0,ex-125),ty,MathMin(w,ex+3),ty+17,true);
         }
         continue;
      }
      int lane=m.kind=="tokyo"?0:m.kind=="london"?1:m.kind=="newyork"?2:-1;
      if(lane<0 || !showSessions) continue;
      int x,y,z,b;
      if(!ChartTimePriceToXY(0,0,m.start,m.last,x,y) || !ChartTimePriceToXY(0,0,m.finish,m.first,z,b)) continue;
      int l=MathMax(0,x),r=MathMin(w,MathMax(x+1,z));
      if(r<=l) continue;
      if(m.last<=m.first) continue;
      int top=MathMax(0,y),bot=MathMin(h-1,b);
      if(bot<top) continue;
      color ink=lane==0?C'184,145,252':lane==1?C'238,204,76':C'125,201,247';
      uint fill=ColorToARGB(ink,52),edge=ColorToARGB(ink,185);
      for(int row=top;row<=bot;row++){
         for(int col=l;col<r;col++){
            int k=row*w+col;
            pixels[k]=sourceOver((row==y || row==b || col==x || col==z-1)?edge:fill,pixels[k]);
         }
      }
      windowHit(i,l,top,r,bot);
      sessionCaption(i,lane,l,r,y,b,w,h,ink);
   }
}
void timeAxis(int w,int h){
   ObjectsDeleteAll(0,prefix+"ET_");
   color ink=(color)ChartGetInteger(0,CHART_COLOR_FOREGROUND);
   screenNote(prefix+"ET_title",4,h-20,"美东时间",ink,"America/New_York · EST / EDT");
   int midnightX[],half=textWidth("11.18 00:00")/2+3;
   double anchorPrice=ChartGetDouble(0,CHART_PRICE_MAX);
   for(int i=0;i<ArraySize(marks);i++){
      if(marks[i].kind!="day")continue;
      datetime stamp=marks[i].start;int x,y;
      if(!ChartTimePriceToXY(0,0,stamp,anchorPrice,x,y) || x-half<65 || x+half>=w)continue;
      int n=ArraySize(midnightX);
      if(n && MathAbs(midnightX[n-1]-x)<2*half+6)continue;
      string clock=easternTime(stamp);
      if(StringSubstr(clock,11)!="00:00")continue;
      ArrayResize(midnightX,n+1);midnightX[n]=x;
      string name=prefix+"ET_mid"+IntegerToString(stamp);
      screenNote(name,x,h-20,StringSubstr(clock,5),ink,"\n");
      ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_UPPER);
      detailHit(x-half,h-20,x+half,h-4,clock+" 美东 · 纽约日界");
   }
   int lastTickX=-100;
   for(int x=75;x<w-92;x+=125){
      datetime stamp;double price;int sub;
      if(!ChartXYToTimePrice(0,x,h/2,sub,stamp,price) || sub!=0) continue;
      int shift=iBarShift(_Symbol,_Period,stamp,false);
      if(shift<0) continue;
      datetime bar=iTime(_Symbol,_Period,shift);int bx,by;
      if(!ChartTimePriceToXY(0,0,bar,price,bx,by) || MathAbs(bx-x)>45 || bx<65) continue;
      string clock=easternTime(bar);
      if(clock=="时差待核" || bx-half<65 || bx+half>=w || bx-lastTickX<2*half+6)continue;
      bool reserved=false;
      for(int j=0;j<ArraySize(midnightX);j++)if(MathAbs(bx-midnightX[j])<2*half+6){reserved=true;break;}
      if(reserved)continue;
      string name=prefix+"ET_"+IntegerToString(bar);
      screenNote(name,bx,h-20,StringSubstr(clock,5),ink,"\n");
      ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_UPPER);
      detailHit(bx-half,h-20,bx+half,h-4,clock+" 美东");
      lastTickX=bx;
   }
}
void hoverWindows(int x,int y){
   lastMouseX=x;lastMouseY=y;
   if(newsExpanded>0 || reviewStart>0){
      if(profileStart)closeProfile();
      candidateStart=0;
   }else{
      int hit=-1;
      for(int k=ArraySize(profileHits)-1;k>=0;k--){
         ProfileHit p=profileHits[k];
         if(x>=p.left && x<=p.right && y>=p.y && y<p.y+16){hit=k;break;}
      }
      if(hit<0)candidateStart=0;
      else{
         ProfileHit p=profileHits[hit];
         if(p.start!=candidateStart || p.daily!=candidateDaily){
            candidateStart=p.start;candidateDaily=p.daily;candidateSince=GetTickCount64();
         }
         if(hoverKey=="refresh" && profileStart==p.start && profileDaily==p.daily)profileBase=p.body;
      }
      if(profileStart){
         if(hoverKey=="refresh")refreshProfile();
         return;
      }
      if(hit>=0)return;
   }
   if(newsExpanded==0 && reviewStart==0 && onHoverPager(x,y)){
      if(hoverKey=="refresh") renderHover();
      return;
   }
   string key="",body="";int detailIx=-1;
   int w=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),h=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   if(x>=0 && y>=0 && y<h && newsExpanded==0 && reviewStart==0 &&
      !((showDOL || showPool) && x>=dolPanelLeft && y>=90 && y<=dolPanelBottom)){
      findDetail(x,y,key,body);
      if(key=="") for(int j=0;j<ArraySize(hits);j++){
         WindowHit a=hits[j];
         if(a.caption && x>=a.l && x<a.r && y>=a.t && y<=a.b){
            key="caption"+IntegerToString(a.ix);body=marks[a.ix].label;detailIx=a.ix;break;
         }
      }
      if(key=="") amdHoverAt(x,y,key,body);
      if(key=="") for(int j=0;j<ArraySize(hits);j++){
         WindowHit a=hits[j];
         if(marks[a.ix].kind=="silver" && x>=a.l && x<a.r && y>=a.t && y<=a.b){
            key="silver"+IntegerToString(a.ix);body=marks[a.ix].label;detailIx=a.ix;break;
         }
      }
      if(key=="" && y>85) for(int j=0;j<ArraySize(hits);j++){
         WindowHit a=hits[j];
         if(a.caption || x<a.l || x>=a.r || y<a.t || y>a.b) continue;
         key+="."+IntegerToString(a.ix);
         body+=(body==""?"":"｜")+marks[a.ix].label;
         detailIx=a.ix;
      }
   }
   if(key==hoverKey){
      if(key!="" && hoverPages>1 && (MathAbs(x-hoverX)>pagerWidth || MathAbs(y-hoverY)>pagerHeight*2)){
         hoverX=x;hoverY=y;renderHover();
      }
      return;
   }
   if(body!="" && (StringFind(body,"日高 ")==0 || StringFind(body,"日低 ")==0)){
      for(int i=0;i<ArraySize(marks);i++) if(marks[i].kind=="day_extreme" && marks[i].label==body){
         body+="｜"+extremeNews(marks[i].start);break;
      }
   }
   if(detailIx>=0 && marks[detailIx].kind!="week_sweep"){
      int seen=0;
      datetime cutoff=(datetime)MathMin(TimeTradeServer(),marks[detailIx].finish);
      for(int j=0;j<ArraySize(events);j++) if(marks[detailIx].start<=events[j].at && events[j].at<cutoff){
         bool strong,swept;string path=reaction(events[j].at,cutoff,strong,swept);
         body+="｜"+easternTime(events[j].at,TIME_MINUTES)+" "+events[j].tag+" · "+path;seen++;
      }
      if(seen==0) body+="｜本段无已载入的重大公布";
   }
   if(hoverSource!=key){hoverPage=0;hoverSource=key;hoverX=x;hoverY=y;}
   // Large session rectangles also acquire the pager beside the current pointer.
   if(hoverX<0 || MathAbs(x-hoverX)>pagerWidth || MathAbs(y-hoverY)>pagerHeight*2){hoverX=x;hoverY=y;}
   hoverKey=key;hoverBody=body;renderHover();
}
void renderHover(){
   string body=hoverBody;int w=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),h=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   hoverKey=hoverSource;ObjectsDeleteAll(0,prefix+"TIP_");
   if(body==""){hoverPages=1;pagerX=-1;ChartRedraw();return;}
   StringReplace(body,"\n","｜");
   string raw[],parts[];int count=StringSplit(body,'｜',raw),wide=0;
   TextSetFont("Microsoft YaHei",-105);
   for(int j=0;j<count;j++) newsLine(parts,raw[j],MathMax(80,MathMin(480,w-24)));
   int per=MathMax(1,MathMin(10,(h-(profileStart?120:88))/17));
   hoverPages=MathMax(1,(ArraySize(parts)+per-1)/per);hoverPage=MathMin(hoverPage,hoverPages-1);
   int from=hoverPage*per,n=MathMin(per,ArraySize(parts)-from);
   for(int i=0;i<n;i++) wide=MathMax(wide,textWidth(parts[from+i]));
   wide=MathMin(w-8,wide+20);
   if(profileStart)wide=MathMin(w-12,MathMax(wide,294));
   int rows=n,left=8,top=MathMax(2,h-54-rows*17-(profileStart?28:0));
   string bg=prefix+"TIP_0";
   ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);
   ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,left);ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,top);
   ObjectSetInteger(0,bg,OBJPROP_XSIZE,wide);ObjectSetInteger(0,bg,OBJPROP_YSIZE,rows*17+8+(profileStart?28:0));
   ObjectSetString(0,bg,OBJPROP_TOOLTIP,"\n");
   ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,(color)ChartGetInteger(0,CHART_COLOR_BACKGROUND));
   ObjectSetInteger(0,bg,OBJPROP_BORDER_TYPE,BORDER_FLAT);
   ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);
   for(int i=0;i<n;i++) screenNote(prefix+"TIP_l"+IntegerToString(i),left+5,top+3+i*17,parts[from+i],
                              (color)ChartGetInteger(0,CHART_COLOR_FOREGROUND),"\n");
   if(profileStart){
      int y=h-51-pagerHeight;
      hoverPagerButton("DOL",profileTab==1?"● DOL":"DOL",left+3,y,52,true);
      hoverPagerButton("Pool",profileTab==2?"● 流动性":"流动性",left+58,y,68,true);
      hoverPagerButton("Prev","‹",left+132,y,32,hoverPage>0);
      hoverPagerButton("Count",StringFormat("%d/%d",hoverPage+1,hoverPages),left+164,y,49,true);
      hoverPagerButton("Next","›",left+213,y,32,hoverPage+1<hoverPages);
      hoverPagerButton("Close","×",left+252,y,32,true);
   }else if(hoverPages>1){
      placePager(w,h,top,wide);
      hoverPagerButton("Prev","‹",pagerX,pagerY,30,hoverPage>0);
      hoverPagerButton("Count",StringFormat("%d / %d",hoverPage+1,hoverPages),pagerX+30,pagerY,56,true);
      hoverPagerButton("Next","›",pagerX+86,pagerY,30,hoverPage+1<hoverPages);
   }
   ChartRedraw();
}
void turnHoverPage(int delta){
   hoverPage=MathMax(0,MathMin(hoverPages-1,hoverPage+delta));renderHover();
}

void closeProfile(){
   profileStart=0;candidateStart=0;profileTab=0;profileBase="";hoverPage=0;
   hoverBody="";hoverSource="";hoverKey="";pagerX=-1;renderHover();
}

void refreshProfile(){
   int ix=-1;
   string kind=profileDaily?"day":"week";
   for(int j=0;j<ArraySize(marks);j++)if(marks[j].kind==kind && marks[j].start==profileStart){ix=j;break;}
   if(ix<0){closeProfile();return;}
   hoverSource="profile_"+kind+IntegerToString(profileStart);
   if(profileTab==0){hoverBody=profileBase;renderHover();return;}
   Mark p=marks[ix];bool dol=profileTab==1;
   string contents="",study="",real="",live="";
   string suffix=profileDaily?"day":"week";
   int liveCount=0;
   for(int j=0;j<ArraySize(marks);j++){
      Mark m=marks[j];
      if(m.start>=p.start && m.start<p.finish){
         if(m.kind==(dol?"dol_study_":"pool_study_")+suffix)study+="｜"+m.label;
         if(dol && m.kind=="dol_review_"+suffix)real+="｜"+m.label;
      }
      if(!dol && m.kind=="week_sweep" && m.finish>p.start && m.finish<=p.finish)
         real+="｜"+m.label;
      if(m.start<=p.start || m.start>p.finish || liveCount>=10)continue;
      if(dol && (m.kind=="dol_up" || m.kind=="dol_down")){
         int cut=StringFind(m.label,"｜");live+="｜"+StringSubstr(m.label,0,cut)+" · "+DoubleToString(m.first,_Digits);
         liveCount++;
      }
      if(!dol && (m.kind=="pool_buy" || m.kind=="pool_sell")){
         string fields[];
         if(StringSplit(m.label,'｜',fields)>=2){live+="｜"+fields[1];liveCount++;}
      }
   }
   if(live!="")contents+="｜最近已收 M5 排名"+live;
   if(real!="")contents+=(dol?"｜原有 DOL 核实记录":"｜已观察的 ERL 清扫")+real;
   if(study!="")contents+="｜联合回放 · "+(dol?"期限内触及":profileDaily?"四小时内越过外沿":"截至周五越过外沿")+study;
   if(contents=="")contents="｜这一周期暂无可核实记录";
   hoverBody=easternTime(p.start,TIME_DATE)+" · "+(profileDaily?"每日概况":"每周概况")+" · "+(dol?"DOL":"流动性")+contents;
   renderHover();
}
void serviceProfileHover(){
   if(!candidateStart || newsExpanded>0 || reviewStart>0 ||
      (profileStart==candidateStart && profileDaily==candidateDaily) || GetTickCount64()-candidateSince<450)return;
   for(int k=ArraySize(profileHits)-1;k>=0;k--){
      ProfileHit p=profileHits[k];if(p.start!=candidateStart || p.daily!=candidateDaily)continue;
      profileStart=p.start;profileDaily=p.daily;profileBase=p.body;profileTab=0;
      hoverPage=0;ArrayInitialize(profilePages,0);refreshProfile();return;
   }
}
void switchProfileTab(int next){
   if(!profileStart)return;
   profilePages[profileTab]=hoverPage;profileTab=profileTab==next?0:next;
   hoverPage=profilePages[profileTab];refreshProfile();
}
