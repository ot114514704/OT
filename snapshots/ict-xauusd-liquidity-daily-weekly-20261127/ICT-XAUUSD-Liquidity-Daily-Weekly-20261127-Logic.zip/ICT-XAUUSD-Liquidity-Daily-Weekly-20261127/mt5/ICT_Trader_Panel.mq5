#property copyright "ICT research panel - local read-only bridge"
#property version "1.00"
#property indicator_chart_window
#property indicator_plots 0
input string DataFolder="ICT_Trader";
input int RefreshSeconds=5;
input ENUM_TIMEFRAMES MainTimeframe=PERIOD_H1;
input bool StartWithExtraLayers=false;
string prefix="ICTN_",scope="DAY",lastfile="",status="Waiting for START_MT5_PANEL.cmd";
string groups[]={"FVG","AMD","PO3","SMT","ERL","IRL","REG","OPEN","SESSION","SILVER","PATH"};
bool enabled[11];
string key(string item){return prefix+IntegerToString(ChartID())+"_"+item;}
color tint(string name,bool fill=false){
 color c=clrSteelBlue;
 if(name=="bull")c=clrSeaGreen; if(name=="bear")c=clrIndianRed;
 if(name=="muted")c=clrSlateGray; if(name=="asia")c=clrMediumPurple;
 if(name=="london")c=clrDarkOrange; if(name=="ny")c=clrTeal;
 if(!fill)return c;
 long bg=ChartGetInteger(0,CHART_COLOR_BACKGROUND);
 int r=(int)((c&255)*.20+(bg&255)*.80);
 int g=(int)(((c>>8)&255)*.20+((bg>>8)&255)*.80);
 int b=(int)(((c>>16)&255)*.20+((bg>>16)&255)*.80);
 return (color)(r+(g<<8)+(b<<16));
}
bool visible(string group){for(int i=0;i<ArraySize(groups);i++)if(groups[i]==group)return enabled[i];return true;}
void button(string id,string text,int x,int y,int width,bool on){
 string n=prefix+"B_"+id;
 if(ObjectFind(0,n)<0)ObjectCreate(0,n,OBJ_BUTTON,0,0,0);
 ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_RIGHT_UPPER);
 ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);
 ObjectSetInteger(0,n,OBJPROP_XSIZE,width);ObjectSetInteger(0,n,OBJPROP_YSIZE,22);
 ObjectSetString(0,n,OBJPROP_TEXT,text);ObjectSetString(0,n,OBJPROP_FONT,"Microsoft YaHei");
 ObjectSetInteger(0,n,OBJPROP_FONTSIZE,8);ObjectSetInteger(0,n,OBJPROP_COLOR,clrWhite);
 ObjectSetInteger(0,n,OBJPROP_BGCOLOR,on?clrDarkSlateGray:clrDimGray);
 ObjectSetInteger(0,n,OBJPROP_STATE,false);ObjectSetInteger(0,n,OBJPROP_ZORDER,100);
}
void controls(){
 for(int i=0;i<11;i++)button(groups[i],(enabled[i]?"● ":"○ ")+groups[i],125,45+i*24,115,enabled[i]);
 button("DAY","日概况",125,315,115,scope=="DAY");button("WEEK","周概况",125,339,115,scope=="WEEK");button("MONTH","月内背景",125,363,115,scope=="MONTH");
 button("M5","5m",125,391,36,_Period==PERIOD_M5);button("M15","15m",85,391,36,_Period==PERIOD_M15);button("H1","60m",45,391,36,_Period==PERIOD_H1);
 string n=prefix+"STATUS";if(ObjectFind(0,n)<0)ObjectCreate(0,n,OBJ_LABEL,0,0,0);
 ObjectSetInteger(0,n,OBJPROP_XDISTANCE,12);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,22);
 ObjectSetString(0,n,OBJPROP_FONT,"Microsoft YaHei");ObjectSetInteger(0,n,OBJPROP_FONTSIZE,9);
 ObjectSetInteger(0,n,OBJPROP_COLOR,clrSteelBlue);ObjectSetString(0,n,OBJPROP_TEXT,status);
}
void render(){
 int state=FileOpen(DataFolder+"\\state.txt",FILE_READ|FILE_TXT|FILE_UNICODE|FILE_COMMON|FILE_SHARE_READ|FILE_SHARE_WRITE);
 if(state==INVALID_HANDLE){status="等待本地同步：启动 START_MT5_PANEL.cmd";controls();return;}
 string file=FileReadString(state);status=FileReadString(state);FileClose(state);
 if(TimeLocal()-(datetime)FileGetInteger(DataFolder+"\\state.txt",FILE_MODIFY_DATE,true)>30)status="同步已停止 / 快照 | "+status;
 if(_Symbol!="XAUUSD"){status="请使用 TMGM XAUUSD 图表；"+status;controls();return;}
 if(file==lastfile){controls();return;}
 int h=FileOpen(DataFolder+"\\"+file,FILE_READ|FILE_CSV|FILE_UNICODE|FILE_COMMON|FILE_SHARE_READ,'\t');
 if(h==INVALID_HANDLE){controls();return;}
 ObjectsDeleteAll(0,prefix+"O_");
 int count=0;
 while(!FileIsEnding(h)){
  string r[12];for(int i=0;i<12;i++)r[i]=FileReadString(h);
  if(r[0]!=scope||StringToInteger(r[1])!=PeriodSeconds()/60||!visible(r[2]))continue;
  datetime a=StringToTime(r[5]),b=StringToTime(r[7]);double p=StringToDouble(r[6]),q=StringToDouble(r[8]);
  string n=prefix+"O_"+r[4];ENUM_OBJECT kind=OBJ_TREND;
  if(r[3]=="BOX"||r[3]=="FRAME")kind=OBJ_RECTANGLE;
  if(r[3]=="TEXT")kind=OBJ_TEXT;if(r[3]=="VLINE")kind=OBJ_VLINE;
  if(!ObjectCreate(0,n,kind,0,a,p,b,q))continue;
  bool fill=r[3]=="BOX";
  ObjectSetInteger(0,n,OBJPROP_COLOR,tint(r[10],fill));ObjectSetInteger(0,n,OBJPROP_WIDTH,(int)StringToInteger(r[11]));
  ObjectSetInteger(0,n,OBJPROP_STYLE,fill?STYLE_SOLID:STYLE_DOT);ObjectSetInteger(0,n,OBJPROP_FILL,fill);
  ObjectSetInteger(0,n,OBJPROP_BACK,fill);ObjectSetInteger(0,n,OBJPROP_RAY_RIGHT,false);ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
  ObjectSetString(0,n,OBJPROP_TOOLTIP,r[9]);
  string text=n+"T";if(kind==OBJ_TEXT)text=n;else ObjectCreate(0,text,OBJ_TEXT,0,a,p);
  ObjectSetString(0,text,OBJPROP_TEXT,r[9]);ObjectSetString(0,text,OBJPROP_FONT,"Microsoft YaHei");
  ObjectSetInteger(0,text,OBJPROP_FONTSIZE,8);ObjectSetInteger(0,text,OBJPROP_COLOR,tint(r[10]));
  ObjectSetInteger(0,text,OBJPROP_SELECTABLE,false);count++;
  if(kind==OBJ_TEXT && r[0]=="DAY" && r[2]=="BASE"){
   ObjectSetInteger(0,text,OBJPROP_ANCHOR,ANCHOR_LOWER);
   ObjectSetInteger(0,text,OBJPROP_COLOR,ChartGetInteger(0,CHART_COLOR_FOREGROUND));
   ObjectSetInteger(0,text,OBJPROP_FONTSIZE,9);
  }
 }
 FileClose(h);lastfile=file;status+=" | "+IntegerToString(count)+" overlays";controls();ChartRedraw();
}
int OnInit(){
 if(!GlobalVariableCheck(key("timeframe_chosen"))){GlobalVariableSet(key("timeframe_chosen"),1);if(_Period!=MainTimeframe)ChartSetSymbolPeriod(0,_Symbol,MainTimeframe);}
 for(int i=0;i<11;i++)enabled[i]=GlobalVariableCheck(key(groups[i]))?GlobalVariableGet(key(groups[i]))!=0:StartWithExtraLayers;
 if(GlobalVariableCheck(key("scope"))){int s=(int)GlobalVariableGet(key("scope"));scope=s==1?"WEEK":s==2?"MONTH":"DAY";}
 IndicatorSetString(INDICATOR_SHORTNAME,"ICT Trader Panel (read-only)");EventSetTimer(MathMax(1,RefreshSeconds));controls();render();return INIT_SUCCEEDED;
}
void OnDeinit(const int reason){EventKillTimer();ObjectsDeleteAll(0,prefix);}
void OnTimer(){render();}
int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[]){return rates_total;}
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam){
 if(id!=CHARTEVENT_OBJECT_CLICK||StringFind(sparam,prefix+"B_")!=0)return;
 string cmd=StringSubstr(sparam,StringLen(prefix+"B_"));
 for(int i=0;i<11;i++)if(groups[i]==cmd){enabled[i]=!enabled[i];GlobalVariableSet(key(groups[i]),enabled[i]?1:0);}
 if(cmd=="DAY"||cmd=="WEEK"||cmd=="MONTH"){scope=cmd;GlobalVariableSet(key("scope"),scope=="WEEK"?1:scope=="MONTH"?2:0);}
 lastfile="";
 if(cmd=="M5"||cmd=="M15"||cmd=="H1")GlobalVariableSet(key("timeframe_chosen"),1);
 if(cmd=="M5")ChartSetSymbolPeriod(0,_Symbol,PERIOD_M5);if(cmd=="M15")ChartSetSymbolPeriod(0,_Symbol,PERIOD_M15);if(cmd=="H1")ChartSetSymbolPeriod(0,_Symbol,PERIOD_H1);
 render();
}
