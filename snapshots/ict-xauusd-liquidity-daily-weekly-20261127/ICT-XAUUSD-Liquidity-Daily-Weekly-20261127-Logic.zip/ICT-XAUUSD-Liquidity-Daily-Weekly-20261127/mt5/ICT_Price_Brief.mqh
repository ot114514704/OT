// Read the same published observations and targets as the individual panels.
// No retrospective daily close or IPDA phase vote is used to rank a target.
string briefPart(string value,int n){
   string parts[];int count=StringSplit(value,'｜',parts);
   return n>=0 && n<count?parts[n]:"";
}

string briefSwing(const MqlRates &bars[],int count,string frame,int &side){
   side=0;
   if(count<7)return frame+" 收线不足，方向待核";
   double hi=0,lo=0,level=0;
   for(int i=4;i<count;i++){
      int j=i-2;
      if(bars[j].high>bars[j-1].high && bars[j].high>bars[j-2].high &&
         bars[j].high>=bars[j+1].high && bars[j].high>=bars[i].high)hi=bars[j].high;
      if(bars[j].low<bars[j-1].low && bars[j].low<bars[j-2].low &&
         bars[j].low<=bars[j+1].low && bars[j].low<=bars[i].low)lo=bars[j].low;
      if(hi>0 && bars[i].close>hi){side=1;level=hi;hi=0;}
      if(lo>0 && bars[i].close<lo){side=-1;level=lo;lo=0;}
   }
   if(side==0)return frame+" 尚无收破摆动边界";
   if(side*(bars[count-1].close-level)<=0){side=0;return frame+" 已退回突破位 "+ipdaPrice(level)+"，方向待确认";}
   return frame+(side>0?" 收破前高 ":" 收破前低 ")+ipdaPrice(level)+(side>0?" 后保持在上方":" 后保持在下方");
}

void priceBriefLines(string &lines[],int width,int context,bool quoted,const MqlTick &tick){
   if(context<0 || !quoted){newsLine(lines,"价格实况 · 等待黄金报价及已收 M5 结构",width);return;}
   datetime at=marks[context].start;
   newsLine(lines,"价格实况　"+ipdaPrice(tick.bid)+"　美东 "+easternTime(tick.time),width);
   bool stale=TimeTradeServer()-tick.time>900 || tick.time-at>600 || tick.time<at-300;
   if(stale)newsLine(lines,"最近快照 · 结构截至 "+easternTime(at)+"，等待同步报价与收线。",width);
   datetime newest=iTime(_Symbol,PERIOD_M5,0);
   datetime structureAt=(datetime)MathMax(at,MathMin(newest,tick.time));
   static datetime cached=0;static string rev="",macro="",micro="";
   if(cached!=structureAt || rev!=revision || macro==""){
      datetime confirmed=0;MqlRates h4[],hour[],quarter[],five[];
      int a,b,c,d;
      int nh=closedEasternH4(h4,confirmed,structureAt);
      string h=briefSwing(h4,nh,"H4",a);
      int n=ipdaClosed(PERIOD_H1,structureAt,hour);
      string hh=briefSwing(hour,n,"H1",b);
      n=ipdaClosed(PERIOD_M15,structureAt,quarter);
      string q=briefSwing(quarter,n,"M15",c);
      n=ipdaClosed(PERIOD_M5,structureAt,five);
      string m=briefSwing(five,n,"M5",d);
      macro=h+"，"+hh+"。";micro=q+"，"+m+"。";
      if(a && d)micro+=(a==d?"短线与 H4 同向。":"短线与 H4 方向相反。");
      if(nh>=7 && n>=7){cached=structureAt;rev=revision;}
   }
   string contextParts[];StringSplit(marks[context].label,'｜',contextParts);
   for(int i=0;i<ArraySize(contextParts);i++)if(StringFind(contextParts[i],"周型 · ")==0){
      string s=contextParts[i];int end=StringFind(s," · ",5);
      newsLine(lines,"周内　"+StringSubstr(s,5,end<0?-1:end-5)+"。",width);break;
   }
   newsLine(lines,"大周期　"+macro,width);
   newsLine(lines,"日内　"+micro,width);
   string nearIRL=nearestInternalPool(at,quoted,tick);
   if(nearIRL!="")newsLine(lines,nearIRL,width);
   int narrative=-1,silver=-1,up=-1,down=-1;
   MqlRates after[];datetime quoteEnd=tick.time;
   if(quoteEnd>=at)CopyRates(_Symbol,PERIOD_M5,at,quoteEnd,after);
   double high=tick.bid,low=tick.bid;
   for(int k=0;k<ArraySize(after);k++)if(after[k].time>=at){high=MathMax(high,after[k].high);low=MathMin(low,after[k].low);}
   for(int j=0;j<ArraySize(marks);j++){
      Mark m=marks[j];
      if(m.kind=="ipda_context" && m.finish==at)narrative=j;
      if(m.kind=="silver" && m.start<at && m.finish>=at-3600 && (silver<0 || m.start>marks[silver].start))silver=j;
      if(m.start!=at)continue;
      if(m.kind=="dol_up" && high<m.first && (up<0 || (int)StringToInteger(m.label)<(int)StringToInteger(marks[up].label)))up=j;
      if(m.kind=="dol_down" && low>m.last && (down<0 || (int)StringToInteger(m.label)<(int)StringToInteger(marks[down].label)))down=j;
   }
   string observations[];
   if(narrative>=0)StringSplit(marks[narrative].label,'｜',observations);
   for(int i=0;i<ArraySize(observations);i++){
      string s=observations[i];
      if(StringFind(s,"获取流动性")==0 || StringFind(s,"平衡不平衡")==0){
         int pos=StringFind(s," · ");newsLine(lines,(pos>=0?StringSubstr(s,pos+3):s)+"。",width);
      }
   }
   if(silver>=0)newsLine(lines,(at>marks[silver].finish?"最近的银弹　":"银弹　")+briefPart(marks[silver].label,1)+"，"+briefPart(marks[silver].label,0)+"。",width);
   if(!stale){
      int candidates[2];candidates[0]=up;candidates[1]=down;
      if(down>=0 && (up<0 || StringToInteger(marks[down].label)<StringToInteger(marks[up].label))){candidates[0]=down;candidates[1]=up;}
      for(int i=0;i<2;i++){
         int j=candidates[i];if(j<0)continue;
         Mark m=marks[j];bool bull=m.kind=="dol_up";
         string label=briefPart(m.label,0);int dot=StringFind(label," · ");
         string reason=briefPart(m.label,1);int cond=StringFind(reason,"观察");
         string test=cond>=0?StringSubstr(reason,cond+2):(bull?"向上收破":"向下收破");
         newsLine(lines,(i==0?"优先观察　":"另一条路径　")+test+"，再看"+(dot>=0?StringSubstr(label,dot+3):label)+" "+
                  ipdaPrice(m.first)+(m.last>m.first?"–"+ipdaPrice(m.last):"")+"。",width);
      }
      if(up<0 && down<0)newsLine(lines,"本批没有待验证的方向目标，等下一次收线。",width);
   }
   for(int i=0;i<ArraySize(observations);i++){
      string s=observations[i];
      if(StringFind(s,"跨盘 AMD")==0 || StringFind(s," 对前盘")>=0 || StringFind(s,"H1 SMT")==0 || StringFind(s,"日型 · ")==0)newsLine(lines,s,width);
   }
   if(silver>=0)newsLine(lines,briefPart(marks[silver].label,2),width);
   for(int i=ArraySize(events)-1;i>=0;i--){
      if(events[i].at>at || events[i].at<at-3600)continue;
      bool strong,swept;
      newsLine(lines,easternTime(events[i].at,TIME_MINUTES)+" "+events[i].tag+" 公布后，"+reaction(events[i].at,at,strong,swept),width);break;
   }
   if(stale && narrative>=0)for(int i=0;i<ArraySize(observations);i++)
      if(StringFind(observations[i],"方路径")==1)newsLine(lines,"当时的"+observations[i],width);
}
