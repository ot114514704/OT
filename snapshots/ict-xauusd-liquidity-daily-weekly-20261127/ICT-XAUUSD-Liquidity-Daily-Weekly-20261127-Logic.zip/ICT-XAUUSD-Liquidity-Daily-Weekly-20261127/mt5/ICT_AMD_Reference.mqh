// Single-period representative selection from the production IPDA_Consolidation indicator.
struct ResearchFrame {
   int seconds; string key,kind,geometry,title,detail; bool active,preferred;
   datetime known,observed,t[4]; double p[4];
};
ResearchFrame ipdaShapes[];
int selectedTriangles[];
string sourceRevision="";
bool sourceCoversPeriod=false;
bool ipdaTriangleShape(const int i)
  {
   if(ipdaShapes[i].geometry!="converging")return false;
   double width=ipdaShapes[i].p[0]-ipdaShapes[i].p[3];
   double du=ipdaShapes[i].p[1]-ipdaShapes[i].p[0],dl=ipdaShapes[i].p[2]-ipdaShapes[i].p[3];
   if(width<=0 || ipdaShapes[i].p[1]-ipdaShapes[i].p[2]>=width)return false;
   double flat=.05*width;
   return (du<0 && dl>0) || (MathAbs(du)<=flat && dl>flat) || (MathAbs(dl)<=flat && du<-flat);
  }

bool ipdaNestedRectangle(const int outer,const int inner)
  {
   return ipdaShapes[outer].seconds==ipdaShapes[inner].seconds && ipdaShapes[outer].geometry=="rectangle" &&
      ipdaInnerDisplayRegion(ipdaShapes[inner].t[0],ipdaShapes[inner].t[1],ipdaShapes[inner].p[0],ipdaShapes[inner].p[1],ipdaShapes[inner].p[3],ipdaShapes[inner].p[2],
                         ipdaShapes[outer].t[0],ipdaShapes[outer].t[1],ipdaShapes[outer].p[0],ipdaShapes[outer].p[1],ipdaShapes[outer].p[3],ipdaShapes[outer].p[2]);
  }

bool ipdaNestedPriceOverlap(const int outer,const int inner)
  {
   if(ipdaShapes[outer].seconds!=ipdaShapes[inner].seconds || ipdaShapes[outer].geometry!="rectangle")return false;
   double a=(double)ipdaShapes[outer].t[0],b=(double)ipdaShapes[outer].t[1],c=(double)ipdaShapes[inner].t[0],d=(double)ipdaShapes[inner].t[1];
   if(b<=a || d<=c || c<a || d>b || (d-c)/(b-a)>0.70)return false;
   double oh=MathMax(ipdaShapes[outer].p[0],ipdaShapes[outer].p[1]),ol=MathMin(ipdaShapes[outer].p[2],ipdaShapes[outer].p[3]);
   double ih=MathMax(ipdaShapes[inner].p[0],ipdaShapes[inner].p[1]),il=MathMin(ipdaShapes[inner].p[2],ipdaShapes[inner].p[3]);
   return MathMin(oh-ol,ih-il)>0 && MathMin(oh,ih)-MathMax(ol,il)>=0.5*MathMin(oh-ol,ih-il);
  }

bool ipdaEarlyNestedPriceOverlap(const int outer,const int inner)
  {
   if(ipdaShapes[outer].seconds!=ipdaShapes[inner].seconds || ipdaShapes[outer].kind!="structural" || ipdaShapes[inner].kind!="structural" ||
      ipdaShapes[outer].geometry!="rectangle" || ipdaShapes[inner].geometry!="rectangle")return false;
   double a=(double)ipdaShapes[outer].t[0],b=(double)ipdaShapes[outer].t[1],c=(double)ipdaShapes[inner].t[0],d=(double)ipdaShapes[inner].t[1];
   if(b<=a || d<=c || c>=a || d>b || (d-c)/(b-a)>0.5)return false;
   if(a-c>MathMin(ipdaShapes[inner].seconds,0.25*(d-c)) || ipdaShapes[inner].known>=ipdaShapes[outer].known)return false;
   double oh=MathMax(ipdaShapes[outer].p[0],ipdaShapes[outer].p[1]),ol=MathMin(ipdaShapes[outer].p[2],ipdaShapes[outer].p[3]);
   double ih=MathMax(ipdaShapes[inner].p[0],ipdaShapes[inner].p[1]),il=MathMin(ipdaShapes[inner].p[2],ipdaShapes[inner].p[3]);
   return MathMin(oh-ol,ih-il)>0 && MathMin(oh,ih)-MathMax(ol,il)>=0.8*MathMin(oh-ol,ih-il);
  }

bool ipdaSuccessiveFormations(const int early,const int later)
  {
   if(ipdaShapes[early].seconds!=ipdaShapes[later].seconds || ipdaShapes[early].kind=="intraday" ||
      ipdaShapes[later].kind!="structural" || ipdaShapes[later].geometry!="rectangle")return false;
   double a=(double)ipdaShapes[early].t[0],b=(double)ipdaShapes[early].t[1],c=(double)ipdaShapes[later].t[0],d=(double)ipdaShapes[later].t[1];
   if(!(a<c && c<b && b<=d) || b-a>0.5*(d-c))return false;
   if(ipdaShapes[early].known>c || ipdaShapes[later].known<b)return false;
   return b-c<=0.25*(b-a);
  }

double ipdaShapePriority(const int i)
  {
   bool dense=ipdaShapes[i].geometry=="rectangle" &&
      (StringFind(ipdaShapes[i].detail,"短横盘候选")>=0 || StringFind(ipdaShapes[i].detail,"强位移后密集停顿候选")>=0 ||
       StringFind(ipdaShapes[i].detail,"密集横盘：")>=0 || StringFind(ipdaShapes[i].detail,"长影线密集候选")>=0);
   if(!dense)for(int j=0;j<ArraySize(ipdaShapes);j++)if(i!=j && ipdaNestedRectangle(i,j))return 500000+MathMin(48,ipdaFormationHours(ipdaShapes[i].seconds,ipdaShapes[i].detail));
   int tier=(ipdaShapes[i].kind=="macro" || ipdaShapes[i].kind=="local") && ipdaShapes[i].geometry=="rectangle"?4:
      ipdaShapes[i].geometry=="converging" || StringFind(ipdaShapes[i].title,"中继")>=0?3:ipdaShapes[i].geometry=="rectangle"?2:1;
   double hours=ipdaFormationHours(ipdaShapes[i].seconds,ipdaShapes[i].detail);
   double rank=tier*100000+MathMin(48,hours);
   if(tier<4 && ipdaShapes[i].geometry=="rectangle" &&
      (StringFind(ipdaShapes[i].detail,"按实体范围")>=0 || StringFind(ipdaShapes[i].detail,"长影线共同接受区")>=0 ||
       StringFind(ipdaShapes[i].detail,"完整范围已完成双向收盘折返")>=0))rank=325000+MathMin(48,hours);
   if(ipdaShapes[i].geometry=="channel" && hours*3600/ipdaShapes[i].seconds<24)rank=250000+hours;
   if(ipdaShapes[i].geometry=="channel" && StringFind(ipdaShapes[i].detail,"大实体反向回访")>=0)rank=350000+MathMin(48,hours);
   return rank;
  }

double ipdaRailPrice(const double t,const double start,const double end,const double a,const double b)
  {return end<=start?a:a+(b-a)*(t-start)/(end-start);}

double ipdaPriceOverlap(const double ah,const double al,const double bh,const double bl)
  {
   double span=MathMax(ah,bh)-MathMin(al,bl);
   return span<=0?0:MathMax(0,MathMin(ah,bh)-MathMax(al,bl))/span;
  }

bool ipdaSameDisplayRegion(const double a0,const double a1,const double ah0,const double ah1,const double al0,const double al1,
                       const double b0,const double b1,const double bh0,const double bh1,const double bl0,const double bl1)
  {
   double da=a1-a0,db=b1-b0,left=MathMax(a0,b0),right=MathMin(a1,b1);
   if(da<=0 || db<=0 || right<=left)return false;
   // A truly smaller nested structure or an adjacent stage stays independent.
   if(MathMin(da,db)/MathMax(da,db)<0.50 || (right-left)/MathMin(da,db)<0.78)return false;
   double overlap=0;
   for(int k=0;k<3;k++)
     {
      double t=left+(right-left)*(k+0.5)/3;
      double ah=ipdaRailPrice(t,a0,a1,ah0,ah1),al=ipdaRailPrice(t,a0,a1,al0,al1);
      double bh=ipdaRailPrice(t,b0,b1,bh0,bh1),bl=ipdaRailPrice(t,b0,b1,bl0,bl1);
      if(ah<=al || bh<=bl)return false;
      overlap+=ipdaPriceOverlap(ah,al,bh,bl);
     }
   return overlap/3>=0.60;
  }

double ipdaDisplayPriority(const bool active,const string kind,const double bars)
  {
   // bars is the evidenced formation duration in hours, not wall-clock span.
   // Prioritise a complete observed stage. Saturation prevents an ever longer
   // rolling window from swallowing successive, already distinct stages.
   double rank=kind=="macro"?60:kind=="local"?50:kind=="structural"?30:25;
   return MathMin(48,MathMax(0,bars))*1000+((kind=="macro" || kind=="local")?200:0)+(active?100:0)+rank;
  }

double ipdaFormationHours(const int seconds,const string detail)
  {
   int at=StringFind(detail,"观察 ");
   if(at<0)return 0; // Missing evidence must not acquire a broad-range bonus.
   double bars=(double)StringToInteger(StringSubstr(detail,at+3));
   return MathMax(0,bars)*seconds/3600.0;
  }

bool ipdaInnerDisplayRegion(const double a0,const double a1,const double ah0,const double ah1,const double al0,const double al1,
                        const double b0,const double b1,const double bh0,const double bh1,const double bl0,const double bl1)
  {
   double da=a1-a0,db=b1-b0;
   if(da<=0 || db<=da || da/db>0.70 || a0<b0 || a1>b1)return false;
   for(int k=0;k<3;k++)
     {
      double t=a0+da*k/2;
      double ah=ipdaRailPrice(t,a0,a1,ah0,ah1),al=ipdaRailPrice(t,a0,a1,al0,al1);
      double bh=ipdaRailPrice(t,b0,b1,bh0,bh1),bl=ipdaRailPrice(t,b0,b1,bl0,bl1);
      double tolerance=0.02*(bh-bl);
      if(ah<=al || bh<=bl || ah>bh+tolerance || al<bl-tolerance)return false;
     }
   return true;
  }

bool ipdaValidDisplayFrame(const double t0,const double t1,const double h0,const double h1,const double l0,const double l1)
  {return t1>t0 && h0>l0 && h1>l1;}

bool ipdaAdjacentDisplayRegions(const double a0,const double a1,const double ah0,const double ah1,const double al0,const double al1,
                            const double b0,const double b1,const double bh0,const double bh1,const double bl0,const double bl1)
  {
   double left=MathMax(a0,b0),right=MathMin(a1,b1),span=MathMin(a1-a0,b1-b0);
   if(span<=0 || right<=left || right-left>0.25*span)return false;
   int direction=0;
   for(int k=0;k<3;k++)
     {
      double t=left+(right-left)*(k+0.5)/3;
      double ah=ipdaRailPrice(t,a0,a1,ah0,ah1),al=ipdaRailPrice(t,a0,a1,al0,al1);
      double bh=ipdaRailPrice(t,b0,b1,bh0,bh1),bl=ipdaRailPrice(t,b0,b1,bl0,bl1);
      double width=MathMin(ah-al,bh-bl);
      if(width<=0 || MathMax(0,MathMin(ah,bh)-MathMax(al,bl))>0.25*width)return false;
      int side=ah>=bh && al>=bl?1:ah<=bh && al<=bl?-1:0;
      if(side==0 || (direction!=0 && side!=direction))return false;
      direction=side;
     }
   return true;
  }

bool ipdaDisplayConflict(const int ap,const double a0,const double a1,const double ah0,const double ah1,const double al0,const double al1,
                     const int bp,const double b0,const double b1,const double bh0,const double bh1,const double bl0,const double bl1)
  {
   if(MathMin(a1,b1)<=MathMax(a0,b0))return false;
   // Successive levels may share a small corner during exit follow-through.
   // Keep actual crossing/repeated alternatives mutually exclusive.
   if(ap==bp)return !ipdaAdjacentDisplayRegions(a0,a1,ah0,ah1,al0,al1,b0,b1,bh0,bh1,bl0,bl1);
   // When both buttons are on, only a wholly contained M15 child can coexist
   // with its H1 parent. Partial intersections and crossing rails never coexist.
   if(ap==900 && bp==3600 && ipdaInnerDisplayRegion(a0,a1,ah0,ah1,al0,al1,b0,b1,bh0,bh1,bl0,bl1))return false;
   if(bp==900 && ap==3600 && ipdaInnerDisplayRegion(b0,b1,bh0,bh1,bl0,bl1,a0,a1,ah0,ah1,al0,al1))return false;
   return true;
  }

bool ipdaChannelBoxCoexist(const int a,const int b)
  {
   return ipdaShapes[a].seconds==ipdaShapes[b].seconds &&
      (((ipdaShapes[a].geometry=="channel" || ipdaTriangleShape(a)) && ipdaShapes[b].geometry=="rectangle") ||
       ((ipdaShapes[b].geometry=="channel" || ipdaTriangleShape(b)) && ipdaShapes[a].geometry=="rectangle"));
  }

bool ipdaChannelContext(const int outer,const int inner)
  {
   if(ipdaShapes[outer].seconds!=ipdaShapes[inner].seconds || ipdaShapes[outer].geometry!="channel")return false;
   double a=(double)ipdaShapes[outer].t[0],b=(double)ipdaShapes[outer].t[1],c=(double)ipdaShapes[inner].t[0],d=(double)ipdaShapes[inner].t[1];
   if(b<=a || d<=c || d>b || d-c>.7*(b-a))return false;
   if(ipdaShapes[inner].geometry=="channel" && d-c>.25*(b-a))return false;
   if(c<a && !(a<d && d<=ipdaShapes[outer].known && ipdaShapes[inner].known<=ipdaShapes[outer].known && d-c<=.25*(b-a)))return false;
   double high=MathMax(ipdaShapes[outer].p[0],ipdaShapes[outer].p[1]),low=MathMin(ipdaShapes[outer].p[2],ipdaShapes[outer].p[3]);
   return high>low && MathMin(ipdaShapes[inner].p[2],ipdaShapes[inner].p[3])>=low-.02*(high-low) && MathMax(ipdaShapes[inner].p[0],ipdaShapes[inner].p[1])<=high+.02*(high-low);
  }
void SelectReferenceTriangles(){
   ArrayResize(selectedTriangles,0);
   int candidates[],preferred_shapes[];double ranks[];
   for(int i=0;i<ArraySize(ipdaShapes);i++)
     {
      
      if(!ipdaValidDisplayFrame(ipdaShapes[i].t[0],ipdaShapes[i].t[1],ipdaShapes[i].p[0],ipdaShapes[i].p[1],ipdaShapes[i].p[3],ipdaShapes[i].p[2]))continue;
      if(ipdaShapes[i].preferred){int q=ArraySize(preferred_shapes);ArrayResize(preferred_shapes,q+1);preferred_shapes[q]=i;continue;}
      int n=ArraySize(candidates);ArrayResize(candidates,n+1);ArrayResize(ranks,n+1);candidates[n]=i;
      ranks[n]=ipdaShapePriority(i);
      // H1 supplies the outer context when both layers are enabled; an M15
      // duplicate may not suppress it. Valid contained M15 stages still pass.
      // Within the same scale/qualification, keep the earliest known stage.
      // Later oversized alternatives cannot retroactively erase that stage.
      for(int j=n;j>0 && (ranks[j]>ranks[j-1] || (ranks[j]==ranks[j-1] &&
           (ipdaShapes[candidates[j]].known<ipdaShapes[candidates[j-1]].known ||
           (ipdaShapes[candidates[j]].known==ipdaShapes[candidates[j-1]].known && StringCompare(ipdaShapes[candidates[j]].key,ipdaShapes[candidates[j-1]].key)<0))));j--)
        {double rank=ranks[j-1];ranks[j-1]=ranks[j];ranks[j]=rank;int c=candidates[j-1];candidates[j-1]=candidates[j];candidates[j]=c;}
     }
   // Resolve alternatives over the entire received history BEFORE clipping to
   // the viewport, so panning/zooming cannot change the chosen interpretation.
   int representatives[];
   for(int n=0;n<ArraySize(candidates);n++)
     {
      int i=candidates[n];bool duplicate=false;
      for(int k=0;k<ArraySize(representatives);k++)
        {
         int j=representatives[k];
         if(ipdaNestedRectangle(i,j) || ipdaNestedRectangle(j,i))continue;
         if(ipdaNestedPriceOverlap(i,j) || ipdaNestedPriceOverlap(j,i))continue;
         if(ipdaDisplayConflict(ipdaShapes[i].seconds,ipdaShapes[i].t[0],ipdaShapes[i].t[1],ipdaShapes[i].p[0],ipdaShapes[i].p[1],ipdaShapes[i].p[3],ipdaShapes[i].p[2],
                            ipdaShapes[j].seconds,ipdaShapes[j].t[0],ipdaShapes[j].t[1],ipdaShapes[j].p[0],ipdaShapes[j].p[1],ipdaShapes[j].p[3],ipdaShapes[j].p[2])){duplicate=true;break;}
        }
      if(!duplicate){int count=ArraySize(representatives);ArrayResize(representatives,count+1);representatives[count]=i;}
     }
   // Preserve all prior representatives first, then restore independent
   // stages hidden only by narrowly overlapping formation/following frames.
   // New exceptions cannot reshuffle the old representative set.
   for(int pass=0;pass<2;pass++)for(int n=0;n<ArraySize(candidates);n++)
     {
      int i=candidates[n];bool duplicate=false;
      for(int k=0;k<ArraySize(representatives);k++)
        {
         int j=representatives[k];if(i==j){duplicate=true;break;}
         if(ipdaNestedRectangle(i,j) || ipdaNestedRectangle(j,i) || ipdaNestedPriceOverlap(i,j) || ipdaNestedPriceOverlap(j,i))continue;
         if(ipdaEarlyNestedPriceOverlap(i,j) || ipdaEarlyNestedPriceOverlap(j,i))continue;
         if(pass==1 && (ipdaSuccessiveFormations(i,j) || ipdaSuccessiveFormations(j,i)))continue;
         if(ipdaDisplayConflict(ipdaShapes[i].seconds,ipdaShapes[i].t[0],ipdaShapes[i].t[1],ipdaShapes[i].p[0],ipdaShapes[i].p[1],ipdaShapes[i].p[3],ipdaShapes[i].p[2],
                            ipdaShapes[j].seconds,ipdaShapes[j].t[0],ipdaShapes[j].t[1],ipdaShapes[j].p[0],ipdaShapes[j].p[1],ipdaShapes[j].p[3],ipdaShapes[j].p[2])){duplicate=true;break;}
        }
      if(!duplicate){int count=ArraySize(representatives);ArrayResize(representatives,count+1);representatives[count]=i;}
     }
   // Add allowed overlapping layers after the old representatives are fixed.
   for(int n=0;n<ArraySize(candidates);n++)
     {
      int i=candidates[n];bool duplicate=false;
      for(int k=0;k<ArraySize(representatives);k++)
        {
         int j=representatives[k];if(i==j){duplicate=true;break;}
         if(ipdaChannelBoxCoexist(i,j) || ipdaChannelContext(i,j) || ipdaChannelContext(j,i))continue;
         if(ipdaNestedRectangle(i,j) || ipdaNestedRectangle(j,i) || ipdaNestedPriceOverlap(i,j) || ipdaNestedPriceOverlap(j,i))continue;
         if(ipdaEarlyNestedPriceOverlap(i,j) || ipdaEarlyNestedPriceOverlap(j,i))continue;
         if(ipdaSuccessiveFormations(i,j) || ipdaSuccessiveFormations(j,i))continue;
         if(ipdaDisplayConflict(ipdaShapes[i].seconds,ipdaShapes[i].t[0],ipdaShapes[i].t[1],ipdaShapes[i].p[0],ipdaShapes[i].p[1],ipdaShapes[i].p[3],ipdaShapes[i].p[2],
                            ipdaShapes[j].seconds,ipdaShapes[j].t[0],ipdaShapes[j].t[1],ipdaShapes[j].p[0],ipdaShapes[j].p[1],ipdaShapes[j].p[3],ipdaShapes[j].p[2])){duplicate=true;break;}
        }
      if(!duplicate){int count=ArraySize(representatives);ArrayResize(representatives,count+1);representatives[count]=i;}
     }
   // Locally approved eligible candidates arrive as display metadata. They
   // do not take part in ranking unrelated existing ipdaShapes.
   for(int q=0;q<ArraySize(preferred_shapes);q++)
     {int count=ArraySize(representatives);ArrayResize(representatives,count+1);representatives[count]=preferred_shapes[q];}

   for(int j=0;j<ArraySize(representatives);j++){
      int k=representatives[j];if(ipdaShapes[k].geometry!="rectangle" && !ipdaTriangleShape(k))continue;
      int n=ArraySize(selectedTriangles);ArrayResize(selectedTriangles,n+1);selectedTriangles[n]=k;
   }
}

bool ReadReferenceTriangles(){
   int f=FileOpen("IPDA_Consolidation\\shapes.tsv",FILE_READ|FILE_TXT|FILE_ANSI|FILE_SHARE_READ|FILE_SHARE_WRITE,0,CP_UTF8);
   if(f==INVALID_HANDLE)return false;
   string h[];int nh=StringSplit(FileReadString(f),'\t',h);
   if(nh<5 || h[0]!="IPDA_SHAPES" || h[1]!="2" || h[3]!=_Symbol || h[2]==""){FileClose(f);return false;}
   if(h[2]==sourceRevision){FileClose(f);return false;}
   ResearchFrame incoming[];int seen=0;bool done=false;
   while(!FileIsEnding(f)){
      string line=FileReadString(f),v[];
      if(line=="END\t"+h[2]){done=true;break;}
      if(line=="")continue;
      if(StringSplit(line,'\t',v)<24)break;
      seen++;
      if((int)StringToInteger(v[0])!=PeriodSeconds(_Period) || v[3]=="intraday")continue;
      ResearchFrame s;s.seconds=PeriodSeconds(_Period);s.key=v[1];s.geometry=v[2];s.kind=v[3];
      s.observed=(datetime)StringToInteger(v[4]);s.known=(datetime)StringToInteger(v[5]);
      s.active=v[10]=="1";s.title=v[21];s.detail=v[23];s.preferred=ArraySize(v)>24 && v[24]=="USER_LAYOUT_V1";
      for(int k=0;k<4;k++){s.t[k]=(datetime)StringToInteger(v[13+2*k]);s.p[k]=StringToDouble(v[14+2*k]);}
      int n=ArraySize(incoming);ArrayResize(incoming,n+1,64);incoming[n]=s;
   }
   FileClose(f);if(!done || seen!=(int)StringToInteger(h[4]))return false;
   ArraySwap(incoming,ipdaShapes);sourceRevision=h[2];sourceCoversPeriod=ArraySize(ipdaShapes)>0;
   SelectReferenceTriangles();return true;
}
