#include "ICT_AMD_Reference.mqh"
// Frozen range candidates seed A only. Later closed bars establish M and D.
// The AMD course (52–229 and 280–365 s) distinguishes A→M→D from a direct A→D expansion.
Mark amdStages[];
bool showAmdLarge=true,showAmdSmall=true;
datetime amdBar=0;
int amdHistory=0;

double quantile(const double &sorted[],double fraction){
   double p=(ArraySize(sorted)-1)*fraction;int i=(int)p;
   return sorted[i]+(sorted[MathMin(i+1,ArraySize(sorted)-1)]-sorted[i])*(p-i);
}

// Shared morphology with ict_ai/amd.py: confirmed pivots, common observed
// span, price coverage and compactness. Freeze recent confirmed pivots for M/D.
string amdTriangleShape(const MqlRates &r[],int end,int n,double &low,double &high){
   int first=end-n+1,h0=-1,h1=-1,l0=-1,l1=-1;
   for(int i=first+1;i<end;i++){
      if(r[i].high>r[i-1].high && r[i].high>=r[i+1].high){h0=h1;h1=i;}
      if(r[i].low<r[i-1].low && r[i].low<=r[i+1].low){l0=l1;l1=i;}
   }
   if(h0<0 || l0<0 || h0==l0 || h0==l1 || h1==l0 || h1==l1 || end-MathMax(h1,l1)>3 || MathMin(h0,l0)-first>n/3) return "";
   low=r[l1].low;high=r[h1].high;
   if(low>=high) return "";
   for(int i=h1+1;i<=end;i++) if(r[i].high>high) return "";
   for(int i=l1+1;i<=end;i++) if(r[i].low<low) return "";
   int left=MathMax(h0,l0),right=MathMin(h1,l1);
   if(right-left<2) return "";
   double us=(r[h1].high-r[h0].high)/(h1-h0),ls=(r[l1].low-r[l0].low)/(l1-l0);
   double width=r[h0].high+(left-h0)*us-(r[l0].low+(left-l0)*ls);
   double du=us*(right-left),dl=ls*(right-left),last=width+du-dl;
   double spans[];ArrayResize(spans,n);
   for(int i=first;i<=end;i++) spans[i-first]=r[i].high-r[i].low;
   ArraySort(spans);double scale=quantile(spans,.5),tol=.15*scale;
   if(MathMin(width,last)<=0 || scale<=0) return "";
   int wick=0,closes=0;
   for(int i=left;i<=right;i++){
      double hi=r[h0].high+(i-h0)*us,lo=r[l0].low+(i-l0)*ls;
      if(r[i].high<=hi+tol && r[i].low>=lo-tol) wick++;
      if(r[i].close<=hi+tol && r[i].close>=lo-tol) closes++;
   }
   if(wick<.8*(right-left+1) || closes<.9*(right-left+1)) return "";
   double motion=MathMax(MathAbs(du),MathAbs(dl)),flat=MathMin(tol,.05*motion);
   bool narrowing=last<width*(1-1e-10);
   string shape="";
   if(narrowing && MathAbs(du)<=flat && dl>0) shape="上升三角";
   else if(narrowing && MathAbs(dl)<=flat && du<0) shape="下降三角";
   else if(du<0 && dl>0) shape="对称三角";
   return shape;

}

// Native fallback for periods beyond the research feed. Use the same turns,
// overlap and net-travel checks as the box branch in ict_ai/amd.py.
bool amdOverlappingBox(const MqlRates &r[],int end,int n,double &low,double &high){
   int first=end-n+1,turns=0,previous=0;
   low=r[first].low;high=r[first].high;
   double overlap=0;
   for(int j=first+1;j<=end;j++){
      low=MathMin(low,r[j].low);high=MathMax(high,r[j].high);
      double move=r[j].close-r[j-1].close;
      int side=move>0?1:(move<0?-1:0);
      if(side!=0){if(previous!=0 && side!=previous)turns++;previous=side;}
      double width=MathMax(r[j-1].high-r[j-1].low,r[j].high-r[j].low);
      if(width>0)
         overlap+=MathMax(0,MathMin(r[j-1].high,r[j].high)-MathMax(r[j-1].low,r[j].low))/width;
   }
   return high>low && turns>=3 && overlap/(n-1)>=.45 && MathAbs(r[end].close-r[first].open)/(high-low)<=.35;
}

void amdMark(string kind,datetime a,datetime z,double low,double high,int formationBars,string reason){
   appendSmt(amdStages,kind,a,z,low,high,reason+" · "+tfName()+" · "+easternTime(z)+" 美东收线可知");
   int idx=ArraySize(amdStages)-1;
   amdStages[idx].formationBars=formationBars;
   amdStages[idx].parentM=-1;
   amdStages[idx].invalidAt=0;amdStages[idx].paintStart=0;amdStages[idx].paintFinish=0;
   amdStages[idx].paintEdge=0;amdStages[idx].paintExtreme=0;
}

void retireCandidate(int accumulationIndex,int manipulationIndex,int confirmedA,datetime known){
   if(accumulationIndex>=0 && accumulationIndex!=confirmedA) amdStages[accumulationIndex].invalidAt=known;
   if(manipulationIndex>=0) amdStages[manipulationIndex].invalidAt=known;
}

void markAmdRetirement(int accumulationIndex,int manipulationIndex,int confirmedA,datetime invalidAt,
                       const MqlRates &bar,double low,double high,string reason){
   retireCandidate(accumulationIndex,manipulationIndex,confirmedA,invalidAt);
   if(accumulationIndex<0)return;
   amdMark("X",bar.time,periodEnd(bar.time),bar.close,bar.close,amdStages[accumulationIndex].formationBars,
           "AMD 候选中止 · "+reason+"｜冻结区间 "+DoubleToString(low,_Digits)+"–"+DoubleToString(high,_Digits));
}

void deliveryTarget(int idx,const MqlRates &r[],int formation,int dStart,int confirmed,bool up,double edge){
   // Prior NY day/week only. Choose the nearest untouched directional level at
   // A confirmation, before inspecting M or D. Never roll it to a later target.
   datetime known=periodEnd(r[formation].time);
   double selected=0;string source="";
   for(int k=0;k<2;k++){
      string kind=k==0?"day":"week";int ref=-1;
      for(int j=0;j<ArraySize(marks);j++)
         if(marks[j].kind==kind && marks[j].finish<=known && (ref<0 || marks[j].finish>marks[ref].finish)) ref=j;
      if(ref<0) continue;
      MqlRates prev[];int n=CopyRates(_Symbol,PERIOD_M5,marks[ref].start,marks[ref].finish-1,prev);
      if(n<=0 || prev[0].time!=marks[ref].start) continue;
      double level=up?prev[0].high:prev[0].low;
      for(int j=1;j<n;j++) level=up?MathMax(level,prev[j].high):MathMin(level,prev[j].low);
      if(up?level<=edge:level>=edge) continue;
      MqlRates between[];int obs=0;
      if(known>marks[ref].finish) obs=CopyRates(_Symbol,PERIOD_M5,marks[ref].finish,known-1,between);
      if(obs<0) continue;
      bool taken=false;
      for(int j=0;j<obs && !taken;j++) taken=up?between[j].high>=level:between[j].low<=level;
      if(!taken && (selected==0 || MathAbs(level-edge)<MathAbs(selected-edge))){
         selected=level;source=(k==0?"前日":"前周")+(up?"高（买方）":"低（卖方）");
      }
   }
   amdStages[idx].dol=selected;
   if(selected==0){amdStages[idx].label+="\nA 收线时未找到可核的前日/前周方向目标";return;}
   amdStages[idx].label+="\nA 收线时冻结 DOL 候选 · "+source+" "+DoubleToString(selected,_Digits);
   for(int j=formation+1;j<=confirmed;j++) if(up?r[j].high>=selected:r[j].low<=selected){
      amdStages[idx].dolHit=periodEnd(r[j].time);
      amdStages[idx].label+=(j<dStart?" · D 段前已触":" · D 段内已触");break;
   }
}

// A shallow pullback can remain inside the envelope. Once a counter-leg
// is confirmed, end the displayed leg at its last directional extreme.
int amdPaintLast(const MqlRates &bars[],int first,int end,int confirmed,int direction,
                 double entry,bool fromReclaim,bool boundaryReturned,double &extreme,int &reversal){
   int peak=first;
   reversal=-1;
   extreme=fromReclaim?entry:(direction>0?bars[first].high:bars[first].low);
   for(int j=first+1;j<end;j++){
      if(j>confirmed && j>=first+2){
         bool breaks=direction>0?bars[j].close<bars[j-1].low:bars[j].close>bars[j-1].high;
         if(breaks && direction*(bars[j-1].close-bars[j-2].close)<0){reversal=j;return peak;}
      }
      double p=direction>0?bars[j].high:bars[j].low;
      if(direction*(p-extreme)>0){peak=j;extreme=p;}
   }
   if(boundaryReturned){reversal=end;return peak;}
   return end-1;
}

void trimDelivery(const MqlRates &bars[],datetime now){
   for(int s=0;s+1<ArraySize(amdStages);s++){
      Mark stage=amdStages[s];
      if(stage.kind!="D" || amdStages[s+1].kind!="D_confirm") continue;
      bool up=StringFind(stage.label,"向上")>=0;
      int l=0,r=ArraySize(bars);
      while(l<r){int mid=(l+r)/2;if(bars[mid].time<stage.start) l=mid+1;else r=mid;}
      if(l==ArraySize(bars)) continue;
      int end=amdBarAtOrAfter(bars,stage.finish);
      if(end<=l)continue;
      int confirmed=amdBarAtOrAfter(bars,amdStages[s+1].start);
      bool returned=end<ArraySize(bars) && periodEnd(bars[end].time)<=now &&
                    consecutive(bars[end-1].time,bars[end].time) &&
                    (up?bars[end].close<=stage.deliveryEdge:bars[end].close>=stage.deliveryEdge);
      double paintExtreme;int reversal;
      int paintLast=amdPaintLast(bars,l,end,confirmed,up?1:-1,stage.paintEdge,stage.protectedPrice>0,
                                 returned,paintExtreme,reversal);
      amdStages[s].paintFinish=periodEnd(bars[paintLast].time);
      amdStages[s].paintExtreme=paintExtreme;
      if(reversal>=0)amdStages[s].label+="\n框结束于 "+easternTime(bars[paintLast].time)+
         " 的顺向极值棒 · "+easternTime(periodEnd(bars[reversal].time))+
         (reversal==end?" 收回冻结边界":" 反向结构收破")+"后确认（美东）";
      int last=l;double high=bars[l].high,low=bars[l].low;
      double extreme=up?high:low;
      for(int j=l+1;j<end && (reversal<0 || j<reversal);j++){
         bool extends=up?bars[j].high>extreme:bars[j].low<extreme;
         if(extends){last=j;extreme=up?bars[j].high:bars[j].low;}
         if(stage.dolHit>stage.start && periodEnd(bars[j].time)>=stage.dolHit) break;
      }
      for(int j=l+1;j<=last;j++){high=MathMax(high,bars[j].high);low=MathMin(low,bars[j].low);}
      amdStages[s].first=low;amdStages[s].last=high;amdStages[s].finish=periodEnd(bars[last].time);
      if(stage.dolHit>amdStages[s].finish){
         amdStages[s].dolHit=0;StringReplace(amdStages[s].label," · D 段内已触","");
      }
      amdStages[s].label+="\n最后顺向极值 "+DoubleToString(extreme,_Digits)+" · "+easternTime(bars[last].time)+" 美东";
   }
}

int amdBarAtOrAfter(const MqlRates &r[],datetime stamp){
   int lo=0,hi=ArraySize(r);
   while(lo<hi){int mid=(lo+hi)/2;if(r[mid].time<stamp)lo=mid+1;else hi=mid;}
   return lo;
}
void scanAMD(const MqlRates &r[],datetime now,int refIndex,bool largeFallback=false){
   int n=ArraySize(r),begin=0,first=0;
   ResearchFrame ref={};
   if(refIndex>=0){
      ref=ipdaShapes[refIndex];
      if(ref.known>now || ref.t[1]>now || ref.observed<r[0].time)return;
      begin=amdBarAtOrAfter(r,ref.known)-1;first=amdBarAtOrAfter(r,ref.observed);
      if(begin<first || begin>=n || periodEnd(r[begin].time)!=ref.known)return;
   }
   int segment=0,formed=-1,side=0,exc=-1,reclaim=-1,run=0,formationBars=0;
   int delivery=-1,direction=0,activeA=-1,activeM=-1,confirmedA=-1,expires=-1;
   bool direct=false,repeated=false;
   double brokenEdge=0;
   double low=0,high=0,bottom=0,top=0,ext=0,typicalBody=0;
   for(int i=begin;i<n && periodEnd(r[i].time)<=now;i++){
      if(i && !consecutive(r[i-1].time,r[i].time)){
         if(formed>=0) markAmdRetirement(activeA,activeM,confirmedA,r[i].time,r[i],low,high,"行情不连续");
         if(refIndex>=0 && i>begin)break;
         formed=-1;delivery=-1;activeM=-1;direct=false;segment=i;
      }
      if(delivery>=0){
         if(amdStages[delivery].dol>0 && !amdStages[delivery].dolHit &&
            (direction>0?r[i].high>=amdStages[delivery].dol:r[i].low<=amdStages[delivery].dol) &&
            direction*(r[i].close-brokenEdge)>0){
            amdStages[delivery].dolHit=periodEnd(r[i].time);amdStages[delivery].label+=" · D 段内已触";
         }
         if(direction*(r[i].close-brokenEdge)<=0){
            if(direct && formed>=0){
               amdStages[delivery].label+="\n直接扩张结束，收回冻结边界 · "+easternTime(periodEnd(r[i].time))+" 美东";
               side=0;exc=-1;reclaim=-1;run=0;repeated=false;expires=i+24;
               // A re-entry alone does not assign a manipulation side. The
               // next fresh excursion must independently demonstrate a reclaim.
               if(r[i].close>=low && r[i].close<=high){direct=false;delivery=-1;continue;}
            }
            direct=false;delivery=-1;
         }
         else{
            amdStages[delivery].finish=periodEnd(r[i].time);
            amdStages[delivery].watchEnd=amdStages[delivery].finish;
            amdStages[delivery].first=MathMin(amdStages[delivery].first,r[i].low);
            amdStages[delivery].last=MathMax(amdStages[delivery].last,r[i].high);
            if(direct) continue;
         }
      }
      if(formed>=0 && i>expires){
         markAmdRetirement(activeA,activeM,confirmedA,periodEnd(r[i].time),r[i],low,high,"观察期到期");
         formed=-1;activeM=-1;segment=i;
      }
      if(formed<0){
         int chosen=0;string shape="";
         if(refIndex>=0){
            if(i!=begin){if(delivery>=0)continue;break;}
            chosen=i-first+1;
            // Freeze the observed OHLC range when the research pattern first became known.
            low=r[first].low;high=r[first].high;bottom=DBL_MAX;top=-DBL_MAX;
            for(int k=first;k<=i;k++){
               low=MathMin(low,r[k].low);high=MathMax(high,r[k].high);
               bottom=MathMin(bottom,MathMin(r[k].open,r[k].close));top=MathMax(top,MathMax(r[k].open,r[k].close));
            }
            shape="盘整研究 · "+ref.title;
         }else{
            const int sizes[]={24,16,12,8};
            for(int pass=0;pass<2 && chosen==0;pass++){
               for(int w=0;w<ArraySize(sizes);w++){
                  int window=sizes[w];
                  if((window>=16)!=largeFallback)continue;
                  if(i-segment+1<window || r[i-window+1].time<D'2026.06.01 07:00')continue;
                  if(pass==0)shape=amdTriangleShape(r,i,window,low,high);
                  else if(amdOverlappingBox(r,i,window,low,high))shape="箱形重叠整理";
                  if(shape!=""){shape="本周期 · "+shape;chosen=window;break;}
               }
            }
            if(chosen>0){
               bottom=MathMin(r[i].open,r[i].close);top=MathMax(r[i].open,r[i].close);
               for(int k=i-chosen+1;k<i;k++){
                  bottom=MathMin(bottom,MathMin(r[k].open,r[k].close));top=MathMax(top,MathMax(r[k].open,r[k].close));
               }
            }
         }
         if(!chosen) continue;
         double bodies[];ArrayResize(bodies,chosen);
         for(int k=0;k<chosen;k++) bodies[k]=MathAbs(r[i-k].close-r[i-k].open);
         ArraySort(bodies);typicalBody=MathMax(_Point,quantile(bodies,.5));
         formed=i;expires=i+24;activeM=-1;side=0;exc=-1;reclaim=-1;run=0;repeated=false;
         // Freeze the M/D decision prices and extend only the time of the rectangle.
         formationBars=chosen;
         amdMark("A",r[i-chosen+1].time,periodEnd(r[i].time),low,high,formationBars,
                 "A 积累候选 · "+shape+" · 冻结扫荡边界 "+DoubleToString(low,_Digits)+"–"+DoubleToString(high,_Digits));
         activeA=ArraySize(amdStages)-1;
         continue;
      }
      if(activeM>=0) amdStages[activeM].watchEnd=periodEnd(r[i].time);
      if(r[i].high>high && r[i].low<low){
         string opening=r[i].open>high?"上沿外":r[i].open<low?"下沿外":"区间内或边界";
         markAmdRetirement(activeA,activeM,confirmedA,periodEnd(r[i].time),r[i],low,high,
                           "同一根 K 线越过两端，顺序待核｜开盘 "+DoubleToString(r[i].open,_Digits)+" 位于"+opening);
         formed=-1;activeM=-1;segment=i+1;continue;
      }
      if(reclaim>=0 && (side==1?r[i].high>ext:r[i].low<ext)){
         // Allow one fresh, same-side sweep only when this closed bar also reclaims A.
         if(repeated || r[i].close<low || r[i].close>high){
            markAmdRetirement(activeA,activeM,confirmedA,periodEnd(r[i].time),r[i],low,high,"扫荡极值继续延伸");
            formed=-1;segment=i+1;continue;
         }
         amdStages[activeM].invalidAt=periodEnd(r[i].time);
         activeM=-1;exc=i;reclaim=-1;run=0;repeated=true;
      }
      if(reclaim>=0){
         bool outside=side==1?r[i].close<low:r[i].close>high;
         run=outside?run+1:0;
         if(run>=2){
            // Require a directional body at least as large as the median in frozen A.
            // Two drifting closes outside the edge alone do not confirm displacement.
            double body1=-side*(r[i-1].close-r[i-1].open),body2=-side*(r[i].close-r[i].open);
            if(MathMax(body1,body2)<typicalBody) continue;
            double dLow=r[reclaim].low,dHigh=r[reclaim].high;
            for(int j=reclaim+1;j<=i;j++){dLow=MathMin(dLow,r[j].low);dHigh=MathMax(dHigh,r[j].high);}
            amdMark("D",r[reclaim].time,periodEnd(r[i].time),dLow,dHigh,formationBars,
                    (side==1?"D 向下派发候选":"D 向上派发候选")+" · 连续两根收在对侧外，顺向实体达到 A 段实体中位数 "+
                    DoubleToString(typicalBody,_Digits)+" · 框回溯至 M 收回棒");
            delivery=ArraySize(amdStages)-1;direction=-side;brokenEdge=direction>0?high:low;
            amdStages[delivery].deliveryEdge=brokenEdge;
            amdStages[delivery].parentM=activeM;
            amdStages[delivery].watchEnd=amdStages[delivery].finish;
            confirmedA=activeA;
            amdStages[delivery].protectedPrice=ext;
            amdStages[delivery].originKnown=periodEnd(r[reclaim].time);
            amdStages[delivery].aKnown=periodEnd(r[formed].time);
            amdStages[delivery].paintStart=r[reclaim].time;amdStages[delivery].paintEdge=r[reclaim].close;
            deliveryTarget(delivery,r,formed,reclaim,i,direction>0,brokenEdge);
            amdMark("D_confirm",r[i].time,periodEnd(r[i].time),r[i].close,r[i].close,formationBars,
                    direction>0?"向上派发确认 · 对侧连续收线且出现顺向位移":"向下派发确认 · 对侧连续收线且出现顺向位移");
            formed=-1;segment=i+1;
         }
         continue;
      }
      int crossed=r[i].high>high?1:r[i].low<low?-1:0;
      // An in-range bar extends A. A wick sweep that closes back immediately
      // belongs to both A and M. Never extend A across an earlier expansion.
      if(!side && activeA!=confirmedA && (!crossed || (r[i].close>=low && r[i].close<=high)))
         amdStages[activeA].finish=periodEnd(r[i].time);
      if(!side && crossed){side=crossed;exc=i;ext=side==1?r[i].high:r[i].low;}
      if(!side) continue;
      if(crossed && crossed!=side){
         markAmdRetirement(activeA,activeM,confirmedA,periodEnd(r[i].time),r[i],low,high,"收回前已越过对侧");
         formed=-1;segment=i+1;continue;
      }
      ext=side==1?MathMax(ext,r[i].high):MathMin(ext,r[i].low);
      if(r[i].close>=low && r[i].close<=high){
         reclaim=i;run=0;
         double mLow=r[exc].low,mHigh=r[exc].high;
         for(int j=exc+1;j<=i;j++){mLow=MathMin(mLow,r[j].low);mHigh=MathMax(mHigh,r[j].high);}
         amdMark("M",r[exc].time,periodEnd(r[i].time),mLow,mHigh,formationBars,
                 (side==1?"M 操纵候选 · 扫上沿买方流动性 ":"M 操纵候选 · 扫下沿卖方流动性 ")+
                 DoubleToString(side==1?high:low,_Digits)+" · 最远越界 "+DoubleToString(side==1?ext-high:low-ext,_Digits)+
                 (r[i].close>=bottom && r[i].close<=top?" · 收回积累实体区":" · 收回影线区间，未回到实体区")+
                 (repeated?" · 同侧二次扫回，沿用原 A 边界":""));
         activeM=ArraySize(amdStages)-1;
         amdStages[activeM].originKnown=periodEnd(r[i].time);
         amdStages[activeM].aKnown=periodEnd(r[formed].time);
         amdStages[activeM].watchEnd=periodEnd(r[i].time);
         amdStages[activeM].protectedPrice=ext;
         amdStages[activeM].paintEdge=r[i].close;
         deliveryTarget(activeM,r,formed,i,i,side<0,side<0?high:low);
      }else{
         bool outside=side==1?r[i].close>high:r[i].close<low;
         run=outside?run+1:0;
         if(run>=2){
            double body1=side*(r[i-1].close-r[i-1].open),body2=side*(r[i].close-r[i].open);
            if(MathMax(body1,body2)<typicalBody)continue;
            amdMark("D",r[i-1].time,periodEnd(r[i].time),MathMin(r[i].low,r[i-1].low),MathMax(r[i].high,r[i-1].high),formationBars,
                    (side>0?"D 向上直接扩张候选":"D 向下直接扩张候选")+" · A→D，未观察到 M · 两根同侧收破且一根顺向实体达到 A 段中位数");
            delivery=ArraySize(amdStages)-1;direction=side;brokenEdge=direction>0?high:low;
            amdStages[delivery].deliveryEdge=brokenEdge;
            amdStages[delivery].watchEnd=amdStages[delivery].finish;
            confirmedA=activeA;
            amdStages[delivery].protectedPrice=0;
            amdStages[delivery].originKnown=periodEnd(r[formed].time);
            amdStages[delivery].aKnown=amdStages[delivery].originKnown;
            amdStages[delivery].paintStart=r[i-1].time;amdStages[delivery].paintEdge=brokenEdge;
            deliveryTarget(delivery,r,formed,i-1,i,direction>0,brokenEdge);
            amdMark("D_confirm",r[i].time,periodEnd(r[i].time),r[i].close,r[i].close,formationBars,
                    direction>0?"向上直接扩张确认":"向下直接扩张确认");
            direct=true;
         }
      }
   }
}
void scanLiveAmdRanges(const MqlRates &r[],datetime now){
   // A short formation can be active while a separate larger range develops.
   scanAMD(r,now,-1,false);
   scanAMD(r,now,-1,true);
}
bool refreshAMD(){
   if(!showAmdLarge && !showAmdSmall) return false;
   datetime now=TimeTradeServer(),last=iTime(_Symbol,_Period,0);
   int bars=iBars(_Symbol,_Period);
   datetime key=periodEnd(last)<=now?-last:last;
   bool revised=ReadReferenceTriangles();
   if(!revised && amdBar==key && bars==amdHistory) return false;
   MqlRates r[];
   int shift=iBarShift(_Symbol,_Period,D'2026.05.24'),cap=(int)TerminalInfoInteger(TERMINAL_MAXBARS);
   int n=CopyRates(_Symbol,_Period,0,MathMin(cap,shift<0?bars:shift+1),r);
   if(n<1) return false;
   ArrayResize(amdStages,0);
   if(ArraySize(selectedTriangles)>0){
      for(int j=0;j<ArraySize(selectedTriangles);j++)scanAMD(r,now,selectedTriangles[j]);
      datetime lastReference=0;
      for(int j=0;j<ArraySize(selectedTriangles);j++)
         lastReference=(datetime)MathMax(lastReference,ipdaShapes[selectedTriangles[j]].known);
      int first=amdBarAtOrAfter(r,lastReference);
      if(n-first>=8){
         MqlRates tail[];ArrayCopy(tail,r,0,first,n-first);scanLiveAmdRanges(tail,now);
      }
   }else scanLiveAmdRanges(r,now);
   trimDelivery(r,now);amdBar=key;amdHistory=bars;return true;
}

struct PhaseHit {int l,r,t,b,labelX,labelY,labelWidth;string tip;};
PhaseHit phaseHits[];
void amdHoverAt(int x,int y,string &key,string &body){
   for(int i=ArraySize(phaseHits)-1;i>=0;i--){
      PhaseHit p=phaseHits[i];
      bool title=x>=p.labelX && x<=p.labelX+p.labelWidth && y>=p.labelY-17 && y<=p.labelY;
      bool edge=x>=p.l-3 && x<=p.r+3 && y>=p.t-3 && y<=p.b+3 &&
                (MathAbs(x-p.l)<=3 || MathAbs(x-p.r)<=3 || MathAbs(y-p.t)<=3 || MathAbs(y-p.b)<=3);
      if(title || edge){key="amd"+IntegerToString(i);body=p.tip;return;}
   }
}
void drawAMD(int w,int h){
   ObjectsDeleteAll(0,prefix+"AMD_");
   ArrayResize(phaseHits,0);
   if(!showAmdLarge && !showAmdSmall) return;
   int left=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
   datetime start=iTime(_Symbol,_Period,left);
   datetime finish=periodEnd(iTime(_Symbol,_Period,MathMax(0,left-(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS)-1)));
   for(int i=0;i<ArraySize(amdStages);i++){
      Mark m=amdStages[i];
      // The engine keeps the confirming bar's open for looking up its OHLC.
      // The point, viewport check and hover all use the close that made D known.
      if(m.kind=="D_confirm" || m.kind=="X")m.start=m.finish;
      if(m.invalidAt || MathMax(m.finish,m.paintFinish)<start || m.start>finish) continue;
      bool large=m.formationBars>=16;
      if(large?!showAmdLarge:!showAmdSmall)continue;
      color ink=m.kind=="A"?C'194,178,104':(m.kind=="M"?C'227,199,89':C'247,221,117');
      string scale=StringFormat("%s范围 · A 确认时 %d 根 %s",large?"大":"小",m.formationBars,tfName());
      string name=prefix+"AMD_"+IntegerToString(i),text=m.kind=="A"?"A 积累":m.kind=="M"?"M 操纵":"D 派发";
      if(m.kind=="X"){
         int dx,dy;
         if(!ChartTimePriceToXY(0,0,m.start,m.first,dx,dy) || dx<0 || dx>=w || dy<0 || dy>=h)continue;
         priceText(name,m.start,m.first,"×",C'184,156,143',large);
         ObjectSetInteger(0,name,OBJPROP_ANCHOR,large?ANCHOR_LOWER:ANCHOR_UPPER);
         int y=large?dy-12:dy;
         detailHit(dx-7,y,dx+7,y+12,m.label+"｜"+scale,4);
         continue;
      }
      if(m.kind=="D_confirm"){
         ObjectCreate(0,name,OBJ_ARROW,0,m.start,m.first);
         ObjectSetInteger(0,name,OBJPROP_ARROWCODE,159);ObjectSetInteger(0,name,OBJPROP_COLOR,clrGold);
         ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
         int dx,dy;
         if(ChartTimePriceToXY(0,0,m.start,m.first,dx,dy))
            detailHit(dx-4,dy-4,dx+4,dy+4,m.label+"｜确认收盘价 "+DoubleToString(m.first,_Digits)+"｜"+scale,4);
         continue;
      }
      if(m.kind=="D"){
         bool up=StringFind(m.label,"向上")>=0;
         text=(up?"D ↑ ":"D ↓ ")+(StringFind(m.label,"直接扩张")>=0?"直接扩张":"派发");
      }
      if(m.kind=="M" && m.paintEdge>0){
         m.first=MathMin(m.paintEdge,m.protectedPrice);m.last=MathMax(m.paintEdge,m.protectedPrice);
      }
      if(m.kind=="D" && m.paintEdge>0){
         m.first=MathMin(m.paintEdge,m.paintExtreme);m.last=MathMax(m.paintEdge,m.paintExtreme);
         m.start=m.paintStart;m.finish=m.paintFinish;
         if(m.finish<=m.start || m.last<=m.first)continue;
      }
      ObjectCreate(0,name,OBJ_RECTANGLE,0,m.start,m.first,m.finish,m.last);
      ObjectSetInteger(0,name,OBJPROP_FILL,false);ObjectSetInteger(0,name,OBJPROP_COLOR,ink);
      ObjectSetInteger(0,name,OBJPROP_STYLE,STYLE_SOLID);
      ObjectSetInteger(0,name,OBJPROP_WIDTH,1);ObjectSetInteger(0,name,OBJPROP_BACK,true);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
      ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
      string tip=m.label+"｜"+scale;
      if(m.kind=="D"){
         if(m.dol>0) tip+=m.dolHit?"\nDOL 已触 · "+easternTime(m.dolHit)+" 美东":"\n截至本段观察结束，DOL 未触";
         for(int j=0;j<ArraySize(events);j++){
            int linked=events[j].stageIndex;
            if(linked>=0 && (linked==i || linked==m.parentM))
               tip+="\n"+events[j].tag+(linked==i?" · ":" · 当时仅确认 M · ")+events[j].assessment;
         }
      }
      priceText(name+"_t",(datetime)MathMax(start,m.start),m.last,text,ink,true);
      ObjectSetInteger(0,name+"_t",OBJPROP_FONTSIZE,7);
      int l,r,t,b,lx,ly;
      if(ChartTimePriceToXY(0,0,m.start,m.last,l,t) && ChartTimePriceToXY(0,0,m.finish,m.first,r,b) &&
         ChartTimePriceToXY(0,0,(datetime)MathMax(start,m.start),m.last,lx,ly)){
         int n=ArraySize(phaseHits);ArrayResize(phaseHits,n+1,32);
         phaseHits[n].l=l;phaseHits[n].r=r;phaseHits[n].t=t;phaseHits[n].b=b;
         phaseHits[n].labelX=lx;phaseHits[n].labelY=ly;phaseHits[n].labelWidth=textWidth(text)+6;phaseHits[n].tip=tip;
      }
   }
}
