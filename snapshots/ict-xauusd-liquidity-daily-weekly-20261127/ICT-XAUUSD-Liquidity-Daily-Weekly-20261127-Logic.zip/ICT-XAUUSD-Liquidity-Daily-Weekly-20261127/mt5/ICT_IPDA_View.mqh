// Independent chart reader. Only its panel consumes these observations.
string ipdaPrice(double value){return DoubleToString(value,_Digits);}
string ipdaAt(datetime stamp){return easternTime(stamp,TIME_DATE|TIME_MINUTES);}

int ipdaClosed(ENUM_TIMEFRAMES tf,datetime cutoff,MqlRates &bars[]){
   int step=PeriodSeconds(tf);
   int n=CopyRates(_Symbol,tf,(datetime)(cutoff-step),256,bars);
   while(n>0 && bars[n-1].time+step>cutoff)n--;
   return n;
}

// Evaluate every closed M5 after the M15 reclaim, including the first one.
// Earlier M5 bars establish the body/ATR reference only.
enum IpdaFollow {FOLLOW_WAIT,FOLLOW_CONFIRMED,FOLLOW_LOST,FOLLOW_GAP,FOLLOW_MISSING};
int ipdaFollow(const MqlRates &five[],int n,datetime known,datetime cutoff,int side,double protectedPrice,
               datetime &confirmation,double &level){
   confirmation=0;level=0;
   if(cutoff<=known)return FOLLOW_WAIT;
   if(n<=0)return FOLLOW_MISSING;
   datetime expected=known;
   int segment=0;
   for(int i=0;i<n && five[i].time+300<=cutoff;i++){
      if(i>0 && five[i].time!=five[i-1].time+300)segment=i;
      if(five[i].time<known)continue;
      if(five[i].time!=expected)return FOLLOW_GAP;
      expected+=300;
      if(side>0?five[i].low<protectedPrice:five[i].high>protectedPrice)return FOLLOW_LOST;
      if(confirmation>0 || i-segment<14)continue;
      double body=side*(five[i].close-five[i].open),span=five[i].high-five[i].low;
      if(body<=0 || span<=0 || body<.6*span)continue;
      int j=i-1;
      while(j>=segment && side*(five[j].close-five[j].open)<0)j--;
      if(j==i-1 || j<segment)continue;
      double anchor=five[j+1].open;
      if(side*(five[i].close-anchor)>0 && body>=.65*smcATR(five,i,segment)){
         confirmation=expected;level=anchor;
      }
   }
   if(expected<cutoff)return FOLLOW_MISSING;
   return confirmation>0?FOLLOW_CONFIRMED:FOLLOW_WAIT;
}

void ipdaSequence(string &rows[],datetime cutoff){
   ArrayResize(rows,5);
   rows[0]="H4 · 等待已确认的美东四小时结构";
   rows[1]="H1 · 等待 H4 方向，再冻结观察区";
   rows[2]="M15 · 等待 H1 区内扫荡与收回";
   rows[3]="M5 · 等待扫荡确认后的同向 CISD";
   rows[4]="共振待定";
   MqlRates h4[],hour[],quarter[],five[];
   datetime lastClose=0;
   int n=closedEasternH4(h4,lastClose,cutoff);
   if(n<4 || lastClose>cutoff)return;
   int side=0,at=-1;
   for(int i=n-1;i>=MathMax(2,n-6);i--){
      if(h4[i].close>MathMax(h4[i-1].high,h4[i-2].high))side=1;
      if(h4[i].close<MathMin(h4[i-1].low,h4[i-2].low))side=-1;
      if(side!=0){at=i;break;}
   }
   if(at<0){rows[0]="H4 · 最近六根收线未突破各自前两根高低，方向待定";return;}
   datetime anchor=at==n-1?lastClose:nyRaw(nyWall(h4[at].time)-nyWall(h4[at].time)%14400+14400);
   if(anchor<=0 || anchor>cutoff)return;
   bool up=side>0;
   string direction=up?"向上":"向下";
   rows[0]="H4 · "+direction+"收破前两根区间 · 美东 "+ipdaAt(anchor);
   double target=0;
   for(int i=1;i<at;i++){
      bool pivot=up?(h4[i].high>h4[i-1].high && h4[i].high>h4[i+1].high):
                    (h4[i].low<h4[i-1].low && h4[i].low<h4[i+1].low);
      if(!pivot)continue;
      double p=up?h4[i].high:h4[i].low;
      bool intact=true;
      for(int j=i+1;j<n && intact;j++)intact=up?h4[j].high<p:h4[j].low>p;
      if(intact && (target==0 || side*(p-target)<0))target=p;
   }
   bool targetReached=false,targetBeyond=false;
   if(target>0 && cutoff>lastClose){
      MqlRates progress[];
      int np=CopyRates(_Symbol,PERIOD_M5,lastClose,(datetime)(cutoff-1),progress);
      for(int j=0;j<np && progress[j].time+300<=cutoff;j++){
         if(progress[j].low<=target && progress[j].high>=target){targetReached=true;break;}
         if(up?progress[j].low>target:progress[j].high<target)targetBeyond=true;
      }
   }
   if(target>0){
      string status=targetReached?" · 已触及原摆动目标 ":targetBeyond?" · 报价在目标之外，触及待核 ":" · 尚未观察到触及 ";
      rows[0]+=status+ipdaPrice(target);
   }else rows[0]+=" · 窗内未见待扫同向摆动目标";
   double biggestLow=0,biggestHigh=0;
   for(int i=n-1;i>=2;i--){
      datetime first=nyWall(h4[i-2].time),last=nyWall(h4[i].time);
      if(first<=0 || last/14400-first/14400!=2)continue;
      double lower=up?h4[i-2].high:h4[i].high,upper=up?h4[i].low:h4[i-2].low;
      for(int j=i+1;j<n && lower<upper;j++){
         if(up)upper=MathMin(upper,h4[j].low);else lower=MathMax(lower,h4[j].high);
      }
      if(upper-lower>biggestHigh-biggestLow){
         biggestLow=lower;biggestHigh=upper;
      }
   }
   if(biggestHigh>biggestLow)
      rows[0]+=" · 窗内最大同向 H4 FVG 余区 "+ipdaPrice(biggestLow)+"–"+ipdaPrice(biggestHigh);
   for(int j=at+1;j<n;j++)if(up?h4[j].close<h4[at].low:h4[j].close>h4[at].high){
      rows[4]="方向冲突 · 后续 H4 收破推动棒另一端";return;
   }
   int nh=ipdaClosed(PERIOD_H1,anchor,hour);
   if(nh<4)return;
   double lo=0,hi=0;
   // An unfilled H1 gap or a confirmed swing known at the H4 close.
   for(int i=nh-1;i>=MathMax(2,nh-24);i--){
      if(hour[i].time-hour[i-2].time!=7200)continue;
      double a=up?hour[i-2].high:hour[i].high,b=up?hour[i].low:hour[i-2].low;
      if(a>=b)continue;
      for(int j=i+1;j<nh && a<b;j++){
         if(up)b=MathMin(b,hour[j].low);else a=MathMax(a,hour[j].high);
      }
      if(a<b){lo=a;hi=b;break;}
   }
   string basis="剩余 FVG";
   if(lo==0){
      basis="摆动边缘";
      for(int i=nh-2;i>=MathMax(1,nh-24);i--){
         if(hour[i].time-hour[i-1].time!=3600 || hour[i+1].time-hour[i].time!=3600)continue;
         bool pivot=up?(hour[i].low<hour[i-1].low && hour[i].low<hour[i+1].low):
                       (hour[i].high>hour[i-1].high && hour[i].high>hour[i+1].high);
         if(!pivot)continue;
         lo=up?hour[i].low:MathMax(hour[i].open,hour[i].close);
         hi=up?MathMin(hour[i].open,hour[i].close):hour[i].high;
         bool intact=true;
         for(int j=i+1;j<nh && intact;j++)intact=up?hour[j].close>=lo:hour[j].close<=hi;
         if(intact)break;
         lo=0;hi=0;
      }
   }
   if(lo==0){rows[1]="H1 · 缺少同向有效 FVG 或摆动边缘";return;}
   rows[1]="H1 · "+basis+" "+ipdaPrice(lo)+"–"+ipdaPrice(hi);
   if(basis=="剩余 FVG" && cutoff>anchor){
      double far=up?lo:hi;
      bool farObserved=false,beyond=false,entered=false;
      MqlRates traced[];
      int count=CopyRates(_Symbol,PERIOD_M5,anchor,(datetime)(cutoff-1),traced);
      for(int t=0;t<count && traced[t].time+300<=cutoff;t++){
         if(traced[t].low<=far && traced[t].high>=far){farObserved=true;break;}
         if(up?traced[t].high<lo:traced[t].low>hi)beyond=true;
         if(traced[t].low<=hi && traced[t].high>=lo)entered=true;
      }
      string state=farObserved?"已触及远端":beyond?"已越至远端之外，触及待核":entered?"已入区，未见远端触及":"尚未观察到触及";
      rows[1]="H1 · 冻结 FVG "+ipdaPrice(lo)+"–"+ipdaPrice(hi)+" · "+state;
   }
   int nq=ipdaClosed(PERIOD_M15,cutoff,quarter),sweep=-1,touch=-1;
   int priorSweeps[];
   if(nq<5){rows[2]="M15 · 已收行情不足";return;}
   for(int i=4;i<nq;i++){
      if(quarter[i].time<anchor)continue;
      if(quarter[i].time!=quarter[i-1].time+900){
         touch=-1;sweep=-1;rows[2]="M15 · 报价间隔后重新观察扫荡与收回";
         ArrayResize(priorSweeps,0);
      }
      if(up?quarter[i].close<lo:quarter[i].close>hi){
         rows[2]="M15 · 收破 H1 区间远端 "+ipdaAt(quarter[i].time+900);
         rows[4]="该路径失效 · 等待 H4/H1 重新定位";return;
      }
      if(quarter[i].high<lo || quarter[i].low>hi)continue;
      if(touch<0)touch=i;
      if(quarter[i].time-quarter[i-4].time!=3600)continue;
      double edge=up?quarter[i-1].low:quarter[i-1].high;
      for(int j=i-4;j<i;j++)edge=up?MathMin(edge,quarter[j].low):MathMax(edge,quarter[j].high);
      if(up?(quarter[i].low<edge && quarter[i].close>edge):(quarter[i].high>edge && quarter[i].close<edge)){
         if(sweep>=0){
            int old=ArraySize(priorSweeps);
            ArrayResize(priorSweeps,old+1,16);priorSweeps[old]=sweep;
         }
         sweep=i;
         rows[2]="M15 · "+(up?"扫低":"扫高")+ipdaPrice(edge)+" 后收回 · "+ipdaAt(quarter[i].time+900);
      }
   }
   if(sweep<0){rows[4]=touch<0?"等待价格进入 H1 区":"H1 已触及 · 等待 M15 扫回";return;}
   datetime known=quarter[sweep].time+900;
   double protectedPrice=up?quarter[sweep].low:quarter[sweep].high;
   int nf=CopyRates(_Symbol,PERIOD_M5,(datetime)(known-32*300),(datetime)(cutoff-1),five);
   datetime confirmation=0;double level=0;
   int follow=ipdaFollow(five,nf,known,cutoff,side,protectedPrice,confirmation,level);
   if(confirmation>0)
      rows[3]="M5 · "+direction+"实体收破反向序列首开 "+ipdaPrice(level)+" · "+ipdaAt(confirmation);
   switch(follow){
      case FOLLOW_CONFIRMED: rows[4]="四周期顺序已观察到";break;
      case FOLLOW_LOST: rows[4]="扫荡极值再次失守 · 该次路径失效";break;
      case FOLLOW_GAP: rows[4]="扫回后 M5 报价中断 · 连续路径待核";break;
      case FOLLOW_MISSING: rows[4]="M5 报价尚未覆盖观察时点 · 等待数据";break;
      default: rows[4]="已扫回 · 等待后续 M5 位移收盘";
   }
   if(follow!=FOLLOW_CONFIRMED && ArraySize(priorSweeps)>0 && touch>=0){
      // A newer sweep can start a separate path before the previous path fails.
      MqlRates trail[];
      int nt=CopyRates(_Symbol,PERIOD_M5,(datetime)(quarter[touch].time-32*300),(datetime)(cutoff-1),trail);
      for(int j=ArraySize(priorSweeps)-1;j>=0;j--){
         int old=priorSweeps[j];
         datetime oldKnown=quarter[old].time+900;
         double protection=up?quarter[old].low:quarter[old].high;
         bool entered=false;
         for(int k=0;k<nt && trail[k].time+300<=oldKnown;k++)
            if(trail[k].time>=quarter[touch].time && trail[k].high>=lo && trail[k].low<=hi){
               entered=true;break;
            }
         if(!entered)continue;
         datetime oldConfirmation;double oldLevel;
         if(ipdaFollow(trail,nt,oldKnown,cutoff,side,protection,oldConfirmation,oldLevel)==FOLLOW_CONFIRMED &&
            oldConfirmation<=known){
            rows[4]+=" ｜前一路径 M5 已于 "+ipdaAt(oldConfirmation)+" 确认，保护极值 "+ipdaPrice(protection)+" 未失守";
            break;
         }
      }
   }
}

void ipdaFrameRows(string &lines[],int width,datetime cutoff,int review,string stage,string support,string &reasons[]){
   string frames[]={"H4","H1","M15","M5"};
   int selected[]={-1,-1,-1,-1};
   for(int i=ArraySize(marks)-1;i>=0;i--){
      if(StringFind(marks[i].kind,"ipda_frame_")!=0 || marks[i].finish>cutoff)continue;
      for(int j=0;j<4;j++)
         if(marks[i].kind=="ipda_frame_"+frames[j] && (selected[j]<0 || marks[i].finish>marks[selected[j]].finish))selected[j]=i;
   }
   bool up=false,down=false;
   int directional=0;
   for(int j=0;j<4;j++){
      string caption="",score="待核";
      datetime at=0;
      if(j==2 && review>=0){caption=stage;score=support;at=marks[review].start;}
      else if(selected[j]>=0){
         Mark m=marks[selected[j]];
         string fields[];
         int n=StringSplit(m.label,'｜',fields);
         if(n>0)caption=fields[0];
         if(n>1)newsLine(reasons,frames[j]+" · "+fields[1],width);
         at=m.finish;
         if(m.first>=0)score=IntegerToString((int)m.first)+"/100";
      }
      if(at==0){newsLine(lines,frames[j]+"   等待已收行情",width);continue;}
      int sec=j==0?14400:(j==1?3600:(j==2?900:300));
      bool old=cutoff-at>=sec;
      newsLine(lines,frames[j]+"   "+caption+"   "+score+"   "+(old?"上次 ":"")+easternTime(at,TIME_DATE|TIME_MINUTES),width);
      if(!old && (StringFind(caption,"↑")>=0 || StringFind(caption,"↓")>=0)){
         up=up || StringFind(caption,"↑")>=0;down=down || StringFind(caption,"↓")>=0;directional++;
      }
   }
   string alignment=up && down?"阶段方向分歧":(directional==4?(up?"四周期均向上":"四周期均向下"):"方向尚未齐备");
   newsLine(lines,"周期对照 · "+alignment,width);
}

void ipdaPanelLines(string &lines[],int width){
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol,tick)){newsLine(lines,"等待 XAUUSD 报价",width);return;}
   static datetime sampled=0;static string rows[];static ulong retry=0;
   datetime cutoff=tick.time-tick.time%300;
   if(sampled!=cutoff || ArraySize(rows)==0 || GetTickCount64()>=retry){
      ipdaSequence(rows,cutoff);sampled=cutoff;retry=GetTickCount64()+60000;
   }
   // Older feeds bundle M5 context with the phase. Honor their later finish.
   int review=-1,context=-1;
   for(int k=ArraySize(marks)-1;k>=0;k--){
      if(marks[k].finish>cutoff || marks[k].start<=0 || marks[k].finish<marks[k].start)continue;
      if(marks[k].kind=="ipda_phase" && (review<0 || marks[k].finish>marks[review].finish))review=k;
      if(marks[k].kind=="ipda_context" && (context<0 || marks[k].finish>marks[context].finish))context=k;
   }
   string parts[],stage="待定",support="待核",next="待定";
   int count=0;
   if(review>=0){
      count=StringSplit(marks[review].label,'｜',parts);
      if(count>0 && StringFind(parts[0],"IPDA M15 ")==0){
         string title=StringSubstr(parts[0],9);
         int split=StringFind(title," · ");
         stage=split<0?title:StringSubstr(title,0,split);
         string key="一小时候选 ";
         int at=StringFind(title,key);
         if(at>=0)next=StringSubstr(title,at+StringLen(key));
      }
      for(int k=1;k<count;k++)if(StringFind(parts[k],"当前阶段形态支持度 ")==0){
         int a=StringFind(parts[k],"（"),b=StringFind(parts[k],"/100）");
         if(a>=0 && b>a)support=StringSubstr(parts[k],a+1,b+4-a-1);
      }
   }
   bool stale=review>=0 && cutoff-marks[review].start>=PeriodSeconds(PERIOD_M15);
   newsLine(lines,(stale?"上次 M15 · ":"当前 M15 · ")+stage,width);
   newsLine(lines,"形态支持   "+support,width);
   newsLine(lines,"未来一小时   "+next,width);
   string reasons[];
   ipdaFrameRows(lines,width,cutoff,review,stage,support,reasons);
   if(stale)
      newsLine(lines,"下一根 M15 复核待更新",width);
   newsLine(lines,"四周期 · "+rows[4],width);
   for(int j=0;j<4;j++)newsLine(lines,rows[j],width);
   newsLine(lines,"最近报价 · 美东 "+ipdaAt(tick.time),width);
   if(review<0){newsLine(lines,"等待截至当前报价的 M15 阶段记录",width);return;}
   for(int i=1;i<count;i++)if(StringFind(parts[i],"截至美东")!=0)newsLine(lines,parts[i],width);
   for(int i=0;i<ArraySize(reasons);i++)newsLine(lines,reasons[i],width);
   if(context>=0 && marks[context].start==marks[review].start)
      dolLines(lines,marks[context].label,width);
}
