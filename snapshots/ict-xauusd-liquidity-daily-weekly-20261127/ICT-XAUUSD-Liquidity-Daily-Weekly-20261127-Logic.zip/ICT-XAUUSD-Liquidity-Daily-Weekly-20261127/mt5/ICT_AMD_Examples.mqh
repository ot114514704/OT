struct AMDExampleBox {
   datetime start, finish;
   double low, high;
   string stage, day, images, reading;
   bool partial;
};
#include "ICT_AMD_Example_Data.mqh"

bool showAmdExamples=false;

void drawAmdExamples(int w,int h,datetime start,datetime finish){
   string group=prefix+"AMDEXAMPLE_";
   ObjectsDeleteAll(0,group);
   if(!showAmdExamples || _Period!=PERIOD_M15) return;
   for(int i=0;i<ArraySize(amdExampleBoxes);i++){
      AMDExampleBox box=amdExampleBoxes[i];
      if(box.finish<start || box.start>finish)continue;
      int x,z,y,b;
      if(!ChartTimePriceToXY(0,0,box.start,box.high,x,y) ||
         !ChartTimePriceToXY(0,0,box.finish,box.low,z,b))continue;
      int left=MathMax(0,x),right=MathMin(w-1,z),top=MathMax(0,y),bottom=MathMin(h-1,b);
      if(left>=right || top>=bottom)continue;
      color tint=box.stage=="A"?C'93,134,179':box.stage=="M"?C'185,137,65':C'36,143,139';
      uint fill=ColorToARGB(tint,42),edge=ColorToARGB(C'108,159,196',138);
      for(int row=top;row<=bottom;row++)
         for(int col=left;col<=right;col++){
            bool border=row==y || row==b || col==x || col==z;
            if(border && (row+col)%4>=2)continue;
            int at=row*w+col;
            pixels[at]=sourceOver(border?edge:fill,pixels[at]);
         }
      string caption=box.stage=="A"?"A 积累":box.stage=="M"?"M 操纵":"D 派发";
      string tip="原图 "+box.images+" · "+box.day+" · "+caption+
         "\n美东 "+easternTime(box.start)+" – "+easternTime(box.finish)+
         "\n按 TMGM M15 同位置复画 · 图例时窗"+
         (box.partial?" · 截图只到 A 段前半":"")+"\n"+box.reading;
      if(y>=14 && y<h)priceText(group+IntegerToString(i),(datetime)MathMax(start,box.start),box.high,caption,C'140,192,229',true);
      detailHit(left,top,right,top,tip,4,true);
   }
}
