bool showFVG=false;
string fvgCache="";
Mark fvgBounds[];
void fvgHoverRegions(){
   for(int i=0;i<ArraySize(fvgBounds);i++){
      Mark m=fvgBounds[i];int x,y,z,b;
      if(!ChartTimePriceToXY(0,0,m.start,m.last,x,y) || !ChartTimePriceToXY(0,0,m.finish,m.first,z,b)) continue;
      detailHit(x,y,z,b,m.label,2);
      detailHit(x,y,z,y,m.label,6,true);detailHit(x,b,z,b,m.label,6,true);
      detailHit(x,y,x,b,m.label,3,true);detailHit(z,y,z,b,m.label,3,true);
   }
}

datetime silverReclaim(const MqlRates &bar,bool bull,double lo,double hi,const Mark &windows[]){
   datetime end=periodEnd(bar.time);
   int l=0,r=ArraySize(windows);
   while(l<r){int mid=(l+r)/2;if(windows[mid].finish<=bar.time) l=mid+1;else r=mid;}
   for(int j=l;j<ArraySize(windows) && windows[j].start<end;j++){
      datetime a=(datetime)MathMax(bar.time,windows[j].start),z=(datetime)MathMin(end,windows[j].finish);
      if(a>=z) continue;
      if(a==bar.time && z==end && PeriodSeconds(_Period)<=300)
         return (bull?(bar.low<lo && bar.close>=lo):(bar.high>hi && bar.close<=hi))?end:0;
      MqlRates sub[];
      ENUM_TIMEFRAMES fine=(PeriodSeconds(_Period)%300==0 && (long)a%300==0 && (long)z%300==0)?PERIOD_M5:PERIOD_M1;
      int n=CopyRates(_Symbol,fine,a,z-1,sub);
      for(int k=0;k<n;k++){
         if(sub[k].time<a || sub[k].time+PeriodSeconds(fine)>z) continue;
         if(bull?(sub[k].low<lo && sub[k].close>=lo):(sub[k].high>hi && sub[k].close<=hi))
            return sub[k].time+PeriodSeconds(fine);
      }
   }
   return 0;
}

void drawFilteredFVG(){
   if(!showFVG){if(fvgCache!="") ObjectsDeleteAll(0,prefix+"FVG_");fvgCache="";return;}
   int left=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
   int right=MathMax(0,left-(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS)-1);
   int first=MathMin(iBars(_Symbol,_Period)-1,left+100);
   if(first<right) return;
   string key=StringFormat("%d/%d/%d/%I64d/%s",first,right,iBars(_Symbol,_Period),iTime(_Symbol,_Period,0),revision);
   if(key==fvgCache){fvgHoverRegions();return;}
   MqlRates b[];int n=CopyRates(_Symbol,_Period,right,first-right+1,b);
   if(n<4) return;
   ObjectsDeleteAll(0,prefix+"FVG_");ArrayResize(fvgBounds,0);fvgCache=key;
   Mark wins[];
   for(int i=0;i<ArraySize(marks);i++) if(marks[i].kind=="silver"){
      int k=ArraySize(wins);ArrayResize(wins,k+1,128);wins[k]=marks[i];
   }
   datetime now=TimeTradeServer(),visible=iTime(_Symbol,_Period,left);
   for(int i=2;i<n;i++){
      if(!consecutive(b[i-2].time,b[i-1].time) || !consecutive(b[i-1].time,b[i].time)) continue;
      bool bull=b[i].low>b[i-2].high;
      if(!bull && b[i].high>=b[i-2].low) continue;
      double lo=bull?b[i-2].high:b[i].high,hi=bull?b[i].low:b[i-2].low;
      if(b[i-1].low>lo || b[i-1].high<hi) continue;
      datetime reaction=0,sweep=0,touch=0;
      double touchEdge=0,followClose=0;
      for(int j=i+1;j<n && j<=i+96 && periodEnd(b[j].time)<=now;j++){
         if(!consecutive(b[j-1].time,b[j].time)) break;
         if(!sweep && (bull?b[j].low<lo:b[j].high>hi)) sweep=silverReclaim(b[j],bull,lo,hi,wins);
         if(bull?b[j].close<lo:b[j].close>hi) break;
         bool prevTouch=j>i+1 && b[j-1].low<=hi && b[j-1].high>=lo;
         if(!reaction && prevTouch && (bull?(b[j].close>b[j-1].high && b[j].close>b[j].open && b[j].close>hi):
                                             (b[j].close<b[j-1].low && b[j].close<b[j].open && b[j].close<lo)))
         {
            reaction=periodEnd(b[j].time);touch=b[j-1].time;
            touchEdge=bull?b[j-1].high:b[j-1].low;followClose=b[j].close;
         }
         if(reaction && sweep) break;
      }
      datetime known=(datetime)MathMax(reaction,sweep);
      if(!known || known<=visible) continue;
      string name=prefix+"FVG_"+IntegerToString(b[i].time);
      ObjectCreate(0,name,OBJ_RECTANGLE,0,b[i-2].time,lo,known,hi);
      color ink=bull?clrMediumAquamarine:clrLightCoral;
      ObjectSetInteger(0,name,OBJPROP_COLOR,ink);ObjectSetInteger(0,name,OBJPROP_FILL,false);
      ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_STYLE,STYLE_DOT);
      string caption=bull?"看涨 FVG":"看跌 FVG";
      string tip=caption+" · "+tfName()+" · "+DoubleToString(lo,_Digits)+"–"+DoubleToString(hi,_Digits);
      tip+="｜三根 K 线形成 · 第三根收线 "+easternTime(periodEnd(b[i].time))+" 美东 · 缺口宽 "+DoubleToString(hi-lo,_Digits);
      if(reaction) tip+="｜"+easternTime(touch)+" 回触；"+easternTime(reaction)+" 美东收 "+DoubleToString(followClose,_Digits)+
         (bull?"，收在回触棒高点 ":"，收在回触棒低点 ")+DoubleToString(touchEdge,_Digits)+(bull?" 之上":" 之下");
      if(sweep) tip+="\n银弹内越过缺口远端并收回 · "+easternTime(sweep)+" 美东";
      ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
      int k=ArraySize(fvgBounds);ArrayResize(fvgBounds,k+1,32);
      fvgBounds[k].start=b[i-2].time;fvgBounds[k].finish=known;
      fvgBounds[k].first=lo;fvgBounds[k].last=hi;fvgBounds[k].label=tip;
   }
   fvgHoverRegions();
}
