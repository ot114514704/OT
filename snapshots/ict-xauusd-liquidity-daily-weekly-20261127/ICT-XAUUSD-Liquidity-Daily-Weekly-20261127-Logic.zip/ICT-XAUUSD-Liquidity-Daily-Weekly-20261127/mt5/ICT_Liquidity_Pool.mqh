// Closed-bar structure comes from the feed. Only distance and sweep state use live quotes.
struct PoolRow { int mark,score,reach; double distance; };
int latestPoolContext(){
   int chosen=-1;
   for(int j=0;j<ArraySize(marks);j++)
      if(marks[j].kind=="pool_context" && (chosen<0 || marks[j].start>=marks[chosen].start))chosen=j;
   return chosen;
}
bool poolObservedRange(datetime start,const MqlTick &tick,double &upper,double &lower){
   upper=tick.bid;lower=tick.bid;
   MqlRates bars[];
   int n=CopyRates(_Symbol,PERIOD_M5,start,tick.time,bars);
   if(n<0)return false;
   for(int i=0;i<n;i++)if(bars[i].time>=start){
      upper=MathMax(upper,bars[i].high);lower=MathMin(lower,bars[i].low);
   }
   return true;
}
string nearestInternalPool(datetime expected,bool quoted,const MqlTick &tick){
   int context=latestPoolContext();
   if(context<0 || marks[context].start!=expected || marks[context].last<=0)return "";
   bool live=quoted && tick.time>=expected;
   double price=live?tick.bid:marks[context].first,upper=price,lower=price;
   if(live && !poolObservedRange(expected,tick,upper,lower))return "";
   int nearest=-1;
   double distance=0,edge=0;
   bool buySide=false;
   for(int j=0;j<ArraySize(marks);j++){
      Mark m=marks[j];bool buy=m.kind=="pool_irl_buy";
      if((!buy && m.kind!="pool_irl_sell") || m.start!=expected)continue;
      double outer=buy?m.last:m.first;
      if(buy?upper>outer:lower<outer)continue;
      double away=MathAbs(outer-price);
      if(nearest>=0 && away>=distance)continue;
      nearest=j;distance=away;edge=outer;buySide=buy;
   }
   if(nearest<0)return "";
   return "最近待扫 IRL · "+(buySide?"买方 ":"卖方 ")+DoubleToString(edge,_Digits)+
          " · "+(live?"距 Bid ":"距上次收盘 ")+DoubleToString(distance,_Digits);
}
void poolLines(string &lines[],int width){
   int context=latestPoolContext();
   if(context<0){newsLine(lines,"流动性积累 · 等待已收 M5 结构",width);return;}
   Mark anchor=marks[context];MqlTick tick;
   bool quoted=SymbolInfoTick(_Symbol,tick) && tick.bid>0;
   bool live=quoted && tick.time>=anchor.start;
   double price=live?tick.bid:anchor.first,upper=price,lower=price;
   string scope=poolExternal?"ERL":"IRL",kindPrefix=poolExternal?"pool_erl_":"pool_irl_";
   newsLine(lines,(poolExternal?"外部流动性积累 ":"内部流动性积累 ")+scope+" · "+(live?"Bid ":"最近收盘 ")+DoubleToString(price,_Digits),width);
   newsLine(lines,"结构 "+easternTime(anchor.start)+" 美东 · "+anchor.label,width);
   if(live && !poolObservedRange(anchor.start,tick,upper,lower)){
      newsLine(lines,"正在同步区间行情，稍后更新排名",width);return;
   }
   PoolRow top[10];int count=0,swept=0;
   for(int j=0;j<ArraySize(marks);j++){
      Mark m=marks[j];bool buy=m.kind==kindPrefix+"buy";
      if((!buy && m.kind!=kindPrefix+"sell") || m.start!=anchor.start || anchor.last<=0)continue;
      if(buy?upper>m.last:lower<m.first){swept++;continue;}
      double distance=MathMax(0.,buy?m.first-price:price-m.last);
      int reach=(int)MathRound(27./(1.+distance/(3.*anchor.last)));
      PoolRow item;item.mark=j;item.reach=reach;item.distance=distance;
      item.score=MathMin(100,(int)StringToInteger(m.label)+reach);
      int pos=0;
      while(pos<count && (top[pos].score>item.score || (top[pos].score==item.score &&
            (top[pos].distance<distance || (top[pos].distance==distance && marks[top[pos].mark].first<=m.first)))))pos++;
      if(pos>=10)continue;
      count=MathMin(10,count+1);
      for(int k=count-1;k>pos;k--)top[k]=top[k-1];
      top[pos]=item;
   }
   if(count==0)newsLine(lines,"当前没有可核实的待扫目标",width);
   for(int pass=0;pass<2;pass++)for(int i=0;i<count;i++){
      PoolRow row=top[i];string fields[];int n=StringSplit(marks[row.mark].label,'｜',fields);
      if(n<4)continue;
      string rank=StringFormat("#%02d  %d/100  ",i+1,row.score);
      if(pass==0)newsLine(lines,rank+fields[1],width);
      else{
         newsLine(lines,rank+fields[1]+" · 距离 "+DoubleToString(row.distance,_Digits),width);
         newsLine(lines,fields[2],width);newsLine(lines,fields[3]+"、距离 "+IntegerToString(row.reach),width);
      }
   }
   newsLine(lines,StringFormat("结构更新后已越过 %d 处 · %s",swept,poolExternal?"日、周、月外沿":"参照纽约日周月区间，日内摆动优先"),width);
   newsLine(lines,"评分衡量结构证据与距离。挂单数量无法从黄金 K 线直接观测。",width);
}
