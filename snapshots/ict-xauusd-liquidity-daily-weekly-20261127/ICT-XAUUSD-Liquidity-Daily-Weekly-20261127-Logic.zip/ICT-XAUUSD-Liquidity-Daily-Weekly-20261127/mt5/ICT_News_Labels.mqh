datetime newsRefreshAt=0,newsObservedBar=0,newsExpanded=0;
int newsPage=0;
datetime openNewsGroup=0;
datetime reviewStart=0,reviewEnd=0,newsMinute=0;

string releaseNumber(long raw,const MqlCalendarEvent &e){
   if(raw==LONG_MIN) return "—";
   string scale="",unit="";
   switch(e.multiplier){
      case CALENDAR_MULTIPLIER_THOUSANDS: scale="千";break;
      case CALENDAR_MULTIPLIER_MILLIONS: scale="百万";break;
      case CALENDAR_MULTIPLIER_BILLIONS: scale="十亿";break;
      case CALENDAR_MULTIPLIER_TRILLIONS: scale="万亿";break;
   }
   switch(e.unit){
      case CALENDAR_UNIT_PERCENT: unit="%";break;
      case CALENDAR_UNIT_CURRENCY: case CALENDAR_UNIT_USD: unit="美元";break;
      case CALENDAR_UNIT_BARREL: unit="桶";break;
      case CALENDAR_UNIT_JOB: unit="个岗位";break;
      case CALENDAR_UNIT_PEOPLE: unit="人";break;
      case CALENDAR_UNIT_HOUR: unit="小时";break;
      case CALENDAR_UNIT_RIG: unit="台";break;
      case CALENDAR_UNIT_CUBICFEET: unit="立方英尺";break;
      case CALENDAR_UNIT_NONE: break;
      default: unit=StringSubstr(EnumToString(e.unit),14);
   }
   return DoubleToString((double)raw/1000000,(int)MathMin(8,e.digits))+scale+unit;
}
void addEvent(Release &list[],datetime at,string tag,string details,int priority){
   for(int i=0;i<ArraySize(list);i++) if(list[i].at==at){
      if(StringFind(list[i].details,details)<0) list[i].details+="\n"+details;
      if(priority>list[i].priority){list[i].tag=tag;list[i].priority=priority;}
      return;
   }
   int n=ArraySize(list);ArrayResize(list,n+1,64);
   list[n].at=at;list[n].tag=tag;list[n].details=details;list[n].priority=priority;list[n].stageIndex=-1;
}

bool newsChartTime(datetime apiTime,int currentOffset,datetime &stamp){
   int matches=0;
   for(int i=0;i<ArraySize(marks);i++){
      if(marks[i].kind!="news_clock") continue;
      datetime raw=apiTime-currentOffset+(int)marks[i].first;
      if(raw>=marks[i].start && raw<marks[i].finish){stamp=raw;matches++;}
   }
   return matches==1;
}

void loadNews(){
   datetime now=TimeTradeServer();
   long diff=now-TimeGMT();
   int offset=(int)MathRound(diff/900.0)*900;
   bool validOffset=now>0 && MathAbs(offset)<=14*3600 && MathAbs(diff-offset)<90;
   MqlCalendarValue values[];Release fresh[];
   int total=CalendarValueHistory(values,D'2026.06.01',now+14*86400,"US","USD"),accepted=0;
   for(int i=0;i<total;i++){
      MqlCalendarEvent e;
      if(!CalendarEventById(values[i].event_id,e) || e.time_mode!=CALENDAR_TIMEMODE_DATETIME) continue;
      string id=e.event_code;StringToLower(id);
      string tag=e.name;int priority=1;
      if(StringFind(id,"nonfarm-payroll")>=0 && StringFind(id,"adp")<0){tag="非农 NFP";priority=4;}
      else if(StringFind(id,"cpi")>=0 || StringFind(id,"consumer-price-index")>=0){tag="CPI";priority=4;}
      else if(StringFind(id,"fomc")>=0 || StringFind(id,"fed-interest-rate")>=0){tag="FOMC";priority=4;}
      else if(StringFind(id,"producer-price-index")>=0 || StringFind(id,"ppi-")>=0){tag="PPI";priority=3;}
      if(priority==1 && e.importance!=CALENDAR_IMPORTANCE_HIGH) continue;
      datetime stamp=0;
      if(!validOffset || !newsChartTime(values[i].time,offset,stamp)) continue;
      string details="MT5 · "+e.name;
      if(e.type==CALENDAR_TYPE_INDICATOR){
         details+="\n公布 "+releaseNumber(values[i].actual_value,e)+"  预期 "+releaseNumber(values[i].forecast_value,e)+
                  "  前值 "+releaseNumber(values[i].prev_value,e);
         if(values[i].revised_prev_value!=LONG_MIN) details+="  修正前值 "+releaseNumber(values[i].revised_prev_value,e);
      }
      addEvent(fresh,stamp,tag,details,priority);accepted++;
   }
   int official=0;
   for(int j=0;j<ArraySize(marks);j++)
      if(marks[j].kind=="calendar"){
         addEvent(fresh,marks[j].start,marks[j].label,"BLS 排期 · "+marks[j].label+"（仅时间）",0);
         official++;
      }
   if(total>=0 || ArraySize(events)==0){
      ArraySwap(events,fresh);
      // Keep viewport groups in chronological order across both sources.
      for(int j=1;j<ArraySize(events);j++){
         Release item=events[j];int k=j;
         while(k>0 && events[k-1].at>item.at){events[k]=events[k-1];k--;}
         events[k]=item;
      }
   }
   PrintFormat("ICT calendar: MT5=%d, included=%d, BLS=%d, times=%d",total,accepted,official,ArraySize(events));
   newsRefreshAt=now+(accepted>0?900:180);
}

string reaction(datetime at,datetime now,bool &strong,bool &swept){
   strong=false;swept=false;
   if(now<at) return "待公布";
   if((long)at%300!=0) return "核对发布时间";
   MqlRates pre[],post[];
   if(CopyRates(_Symbol,PERIOD_M5,at-1800,at-1,pre)!=6) return "报价待核";
   double high=pre[0].high,low=pre[0].low,average=0;
   for(int j=0;j<6;j++){
      if(pre[j].time!=at-1800+300*j) return "报价待核";
      high=MathMax(high,pre[j].high);low=MathMin(low,pre[j].low);
      average+=(pre[j].high-pre[j].low)/6.;
   }
   int expected=(int)MathMin(6,(now-at)/300);
   if(expected<=0) return "观察中";
   if(CopyRates(_Symbol,PERIOD_M5,at,at+300*expected-1,post)!=expected) return "报价待核";
   bool above=false,below=false,buy=false,sell=false;
   bool up=false,down=false;
   for(int j=0;j<expected;j++){
      if(post[j].time!=at+300*j) return "报价待核";
      above|=post[j].high>high && post[j].low<=high;
      below|=post[j].low<low && post[j].high>=low;
      buy|=above && post[j].close<high;sell|=below && post[j].close>low;
      double body=post[j].close-post[j].open;
      if(average>0 && MathAbs(body)>=.65*average && MathAbs(body)>=.60*(post[j].high-post[j].low)){
         up|=body>0 && post[j].close>high;down|=body<0 && post[j].close<low;
      }
   }
   strong=up || down;swept=buy || sell;
   string move=up && down?"双向强位移":up?"向上强位移":down?"向下强位移":"未见强位移";
   string sweep=buy && sell?"双向扫回":buy?"扫前高买方":sell?"扫前低卖方":"未见扫回";
   return move+" · "+sweep+(expected<6?"（观察中）":"");
}

int newsAmdStage(datetime at,datetime cutoff,datetime firstCloseAfterEvent){
   int selected=-1;
   for(int i=0;i<ArraySize(amdStages);i++){
      Mark m=amdStages[i];
      if(m.kind!="M" && m.kind!="D")continue;
      if(m.invalidAt && m.invalidAt<=cutoff)continue;
      if(!m.originKnown || at<m.aKnown || m.originKnown>cutoff || m.originKnown>=at+1800)continue;
      if(m.kind=="D" && (i+1>=ArraySize(amdStages) || amdStages[i+1].kind!="D_confirm" ||
                         amdStages[i+1].finish>cutoff))continue;
      if(at<m.originKnown && (m.start<at || m.start>=at+1800))continue;
      if(at!=m.originKnown && (at>=m.watchEnd ||
         (m.watchEnd>cutoff && (firstCloseAfterEvent<=at || firstCloseAfterEvent>cutoff))))continue;
      if(selected<0){selected=i;continue;}
      Mark prior=amdStages[selected];
      if(m.originKnown>prior.originKnown || (m.originKnown==prior.originKnown &&
         (m.aKnown>prior.aKnown || (m.aKnown==prior.aKnown &&
          ((m.kind=="D" && prior.kind=="M") || (m.kind==prior.kind && m.formationBars<prior.formationBars))))))selected=i;
   }
   return selected;
}

string newsDelivery(Release &news,datetime now){
   news.stageIndex=-1;
   if(now<news.at)return "";
   datetime cutoff=(datetime)MathMin(now,news.at+1800);
   int shift=iBarShift(_Symbol,_Period,news.at,false);
   datetime bar=shift>=0?iTime(_Symbol,_Period,shift):0;
   news.stageIndex=newsAmdStage(news.at,cutoff,bar>0?periodEnd(bar):0);
   if(news.stageIndex<0)return "";
   Mark m=amdStages[news.stageIndex];
   if(!m.dol || !m.protectedPrice) return "D 路径 · "+(m.dol==0?"事前 DOL 待核":"直接扩张，缺少已确认的 M 保护极点");
   bool up=m.kind=="M"?StringFind(m.label,"扫下沿")>=0:StringFind(m.label,"向上")>=0;
   if(now<news.at+300) return "待公布后 M5 收线";
   MqlRates before[];
   int n=news.at>m.originKnown?CopyRates(_Symbol,PERIOD_M5,m.originKnown,news.at-1,before):0;
   if(news.at>m.originKnown && n*300!=news.at-m.originKnown)return "公布前路径待核";
   if(m.dolHit && m.dolHit<=m.originKnown) return "目标在 M 收回前已触";
   for(int i=0;i<n;i++){
      if(before[i].time!=m.originKnown+i*300)return "公布前路径待核";
      if((up?before[i].low<m.protectedPrice:before[i].high>m.protectedPrice) &&
         (up?before[i].high>=m.dol:before[i].low<=m.dol))return "公布前同棒触目标和破极点，先后待核";
      if(up?before[i].low<m.protectedPrice:before[i].high>m.protectedPrice) return "公布前极点已失守";
      if(up?before[i].high>=m.dol:before[i].low<=m.dol) return "公布前 DOL 已触";
   }
   int count=(int)MathMin(6,(now-news.at)/300);MqlRates post[],pre[];
   if(CopyRates(_Symbol,PERIOD_M5,news.at,news.at+count*300-1,post)!=count ||
      CopyRates(_Symbol,PERIOD_M5,news.at-1800,news.at-1,pre)!=6) return "公布窗口报价待核";
   double mean=0,edge=up?pre[0].high:pre[0].low;
   for(int i=0;i<6;i++){
      if(pre[i].time!=news.at-1800+i*300) return "公布前报价待核";
      mean+=(pre[i].high-pre[i].low)/6.;edge=up?MathMax(edge,pre[i].high):MathMin(edge,pre[i].low);
   }
   bool moved=false,pullback=false;
   for(int i=0;i<count;i++){
      if(post[i].time!=news.at+300*i) return "公布后报价待核";
      if(post[i].time<m.originKnown) continue;
      bool lost=up?post[i].low<m.protectedPrice:post[i].high>m.protectedPrice;
      bool hit=up?post[i].high>=m.dol:post[i].low<=m.dol;
      if(lost && hit) return "同棒触目标和破极点，先后待核";
      if(lost) return "保护极点失守，原目标路径失效";
      if(hit) return "保护极点守住 · DOL 已触 "+DoubleToString(m.dol,_Digits);
      double body=(up?1.:-1.)*(post[i].close-post[i].open);
      if(!moved && body<0) pullback=true;
      if(body>=.65*mean && body>=.6*(post[i].high-post[i].low) && (up?post[i].close>edge:post[i].close<edge)) moved=true;
   }
   return moved?((m.originKnown>news.at?"公布后扫回立极点":"极点守住")+" · "+(pullback?"回调后顺向强位移":"顺向强位移")+" · 支持 DOL "+DoubleToString(m.dol,_Digits)):
                "尚无顺向强位移支持原 DOL";
}

void updateNewsPaths(datetime now,bool refreshStages){
   for(int i=0;i<ArraySize(events);i++){
      if(!refreshStages && events[i].path!="" && now>=events[i].at+1800 && newsMinute>=events[i].at+1800 &&
         StringFind(events[i].path,"待核")<0 && StringFind(events[i].assessment,"待核")<0) continue;
      events[i].path=reaction(events[i].at,now,events[i].strong,events[i].swept);
      events[i].assessment=newsDelivery(events[i],now);
   }
   newsMinute=now;
}
string realizedDOL(datetime start,datetime finish,bool daily){
   string rows="";
   for(int j=0;j<ArraySize(marks);j++){
      if(marks[j].kind!=(daily?"dol_review_day":"dol_review_week") ||
         marks[j].start<start-3600 || marks[j].start>=finish) continue;
      rows+="｜"+marks[j].label;
   }
   return rows==""?"":"｜DOL 已实现 · 纽约时间（M5 收线核实）"+rows;
}
string profileNews(const Mark &m){
   int count=0,strong=0,swept=0;
   for(int i=0;i<ArraySize(events);i++){
      if(events[i].at<m.start || events[i].at>=m.finish) continue;
      count++;if(events[i].strong) strong++;if(events[i].swept) swept++;
   }
   string news=count?StringFormat(" · 新闻%d组 强移%d 扫回%d",count,strong,swept):"";
   return news;
}

int newsPageCount=0;
string newsKey(){return prefix+"NEWS_";}

string eventStructure(datetime at,datetime now,ENUM_TIMEFRAMES tf){
   int step=PeriodSeconds(tf);string frame=tf==PERIOD_M5?"M5":"H1";
   if(at>now) return frame+" 待公布";
   int shift=iBarShift(_Symbol,tf,at,false);if(shift<0) return frame+" 报价待核";
   datetime anchor=iTime(_Symbol,tf,shift);
   if(anchor>at || anchor+step<=at) return frame+" 公布棒缺失";
   MqlRates pre[],post[];
   int n=CopyRates(_Symbol,tf,shift+1,36,pre);
   if(n<5 || pre[n-1].time+step!=anchor) return frame+" 前序摆动待核";
   int start=n-1;while(start>0 && pre[start-1].time+step==pre[start].time) start--;
   int count=(int)MathMin(tf==PERIOD_M5?6:4,(now-anchor)/step);
   if(count<1) return frame+" 待收线";
   if(CopyRates(_Symbol,tf,anchor,anchor+count*step-1,post)!=count) return frame+" 后续报价待核";
   for(int i=0;i<count;i++) if(post[i].time!=anchor+i*step) return frame+" 后续报价中断";
   string msg="";
   for(int side=-1;side<=1;side+=2){
      double level=0;
      for(int j=n-3;j>=start+2;j--){
         double p=side>0?pre[j].high:-pre[j].low;bool pivot=true;
         for(int k=j-2;k<=j+2;k++) if(k!=j && (side>0?pre[k].high:-pre[k].low)>=p) pivot=false;
         for(int k=j+3;k<n && pivot;k++) if(side*pre[k].close>p) pivot=false;
         if(pivot){level=side*p;break;}
      }
      if(level==0) continue;
      int first=-1;
      for(int j=0;j<count;j++) if(side*(post[j].close-level)>0){first=j;break;}
      string state=first<0?"未收破":(easternTime(post[first].time+step,TIME_MINUTES)+" 收破"+
                      (side*(post[count-1].close-level)>0?"后保持":"后撤回"));
      msg+=(msg==""?"":"，")+(side>0?"前高 ":"前低 ")+DoubleToString(level,_Digits)+" "+state;
   }
   return frame+"（截至美东 "+easternTime(post[count-1].time+step,TIME_MINUTES)+"）"+
          (msg==""?"缺少已确认摆动":msg);
}

int weekReference(datetime at){
   for(int i=0;i<ArraySize(marks);i++)
      if(marks[i].kind=="week_ref" && marks[i].start<=at && at<marks[i].finish) return i;
   return -1;
}

string weeklyScenario(const Mark &ref){
   return ref.label+"｜收破并守住 "+DoubleToString(ref.last,_Digits)+" 支持向上扩张；跌破并保持在 "+
          DoubleToString(ref.first,_Digits)+" 下方支持向下扩张。越界后收回支持扫荡反转候选，区间内优先保留盘整。";
}

string eventWeek(datetime at,datetime now){
   int ref=weekReference(at);if(ref<0) return "周级参照报价待核";
   Mark m=marks[ref];double hi=m.last,lo=m.first;
   if(now<at) return m.label+" · 待公布及收线核对";
   MqlRates pre[],bars[];int n=(int)MathMin(6,(now-at)/300);
   if(n<1 || (long)at%300!=0 || CopyRates(_Symbol,PERIOD_M5,at-300,at-1,pre)!=1 || pre[0].time!=at-300 ||
      CopyRates(_Symbol,PERIOD_M5,at,at+n*300-1,bars)!=n) return "周边界反应待连续 M5 收线";
   bool brokeHi=false,brokeLo=false;
   for(int j=0;j<n;j++){
      if(bars[j].time!=at+j*300) return "周边界反应报价中断";
      brokeHi|=bars[j].high>hi;brokeLo|=bars[j].low<lo;
   }
   double last=bars[n-1].close;
   string result=last>hi?(pre[0].close>hi?"维持上周高点上方":"收破上周高点，向上扩张候选"):
                 last<lo?(pre[0].close<lo?"维持上周低点下方":"收破上周低点，向下扩张候选"):
                 brokeHi && brokeLo?"双向越过后收回上周范围":
                 brokeHi?"越过上周高点后收回，扫高路径":brokeLo?"越过上周低点后收回，扫低路径":"仍在上周范围内，未证实周级突破";
   return StringFormat("公布后 %d 分钟 · %s（上周 %.2f–%.2f）",n*5,result,lo,hi);
}

void newsText(string key,int x,int y,string caption,string tip,color ink,int priority){
   string name=newsKey()+key;
   ObjectCreate(0,name,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,name,OBJPROP_COLOR,ink);
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,name,OBJPROP_ZORDER,priority);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");
   ObjectSetString(0,name,OBJPROP_TEXT,caption);
   ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
   if(StringSubstr(key,0,1)=="k") detailHit(x-7,y-15,x+7,y,tip,7);
   else detailHit(x,y,x+textWidth(caption),y+16,tip,6);
}

int textWidth(string value){
   uint w,h;
   return TextGetSize(value,w,h)?(int)w:StringLen(value)*12;
}

void newsLine(string &lines[],string value,int available){
   while(StringLen(value)>0){
      int count=StringLen(value);
      while(count>1 && textWidth(StringSubstr(value,0,count))>available) count--;
      int n=ArraySize(lines);ArrayResize(lines,n+1,16);
      lines[n]=StringSubstr(value,0,count);value=StringSubstr(value,count);
   }
}

void newsDetail(int first,int last,int x,int w,int bottom,color ink){
   int width=MathMin(380,w-8);
   x=MathMax(4,MathMin(x,w-width-4));
   string lines[];
   for(int i=first;i<=last;i++){
      newsLine(lines,easternTime(events[i].at)+" 美东 · "+events[i].tag,width);
      string parts[];int n=StringSplit(events[i].details,'\n',parts);
      int lead=n>1 && StringFind(parts[1],"公布 ")==0?2:1;
      for(int j=0;j<MathMin(lead,n);j++) newsLine(lines,parts[j],width);
      datetime at=events[i].at,now=TimeTradeServer();
      MqlRates pre[],bars[];
      if(now>=at && (long)at%300==0 && CopyRates(_Symbol,PERIOD_M5,at-300,at-1,pre)==1 && pre[0].time==at-300){
         double base=pre[0].close,hi=base,lo=base;
         newsLine(lines,"黄金公布前收价 "+DoubleToString(base,_Digits)+" · 美元/盎司",width);
         int closed=(int)MathMin(6,(now-at)/300);
         int got=closed>0?CopyRates(_Symbol,PERIOD_M5,at,at+closed*300-1,bars):0;
         int k=0;
         for(;k<got && bars[k].time==at+300*k;k++){
            hi=MathMax(hi,bars[k].high);lo=MathMin(lo,bars[k].low);
            if(k==0 || k==2 || k==5){
               double delta=bars[k].close-base;
               newsLine(lines,StringFormat("%d分钟  收 %s  净移 %+.2f  ↑%.2f  ↓%.2f",
                  5*(k+1),DoubleToString(bars[k].close,_Digits),delta,hi-base,base-lo),width);
            }
         }
         if(k<closed) newsLine(lines,"后续 M5 报价有缺口",width);
         else if(closed<6) newsLine(lines,"等待其余观察窗口收线",width);
      }else newsLine(lines,now<at?"公布后开始观察黄金位移":"黄金基准报价待核",width);
      newsLine(lines,"同期价格反应 · "+events[i].path,width);
      if(now>=at){
         newsLine(lines,eventStructure(at,now,PERIOD_M5),width);
         newsLine(lines,eventStructure(at,now,PERIOD_H1),width);
         newsLine(lines,eventWeek(at,now),width);
         newsLine(lines,"公布棒及后续收线只验证同期价格路径；同刻多项数据共用该路径。",width);
      }
      if(events[i].assessment!="") newsLine(lines,"派发复盘 · "+events[i].assessment,width);
      for(int j=lead;j<n;j++) newsLine(lines,parts[j],width);
   }
   int perPage=MathMax(1,MathMin(8,(bottom-34)/18));
   newsPageCount=(ArraySize(lines)+perPage-1)/perPage;
   newsPage=MathMax(0,MathMin(newsPageCount-1,newsPage));
   int end=MathMin((newsPage+1)*perPage,ArraySize(lines)),start=newsPage*perPage;
   int base=bottom-18*(end-start+(newsPageCount>1?1:0));
   for(int j=start;j<end;j++)
      newsText("d"+IntegerToString(j),x,base+18*(j-start),lines[j],lines[j],ink,8);
   if(newsPageCount>1)
      newsText("more",x,bottom-18,StringFormat("%d / %d   下一页 ›",newsPage+1,newsPageCount),
               "点击翻页，末页后返回第一页",clrGoldenrod,10);
}

string extremeNews(datetime start){
   string detail="";
   for(int i=0;i<ArraySize(events);i++){
      if(events[i].at<start-4*3600 || events[i].at>=start+300) continue;
      bool strong,swept;
      string timing=events[i].at>=start?"极值同棒，棒内先后未定":StringFormat("极值棒前 %d 分钟",(start-events[i].at)/60);
      string source=StringFind(events[i].details,"MT5 · ")>=0?"MT5 经济日历":"项目归档排期";
      detail+=timing+" · "+easternTime(events[i].at)+" 美东 "+events[i].tag+" · "+reaction(events[i].at,start+300,strong,swept)+"｜";
      detail+=source+" · 同期价格反应，消息驱动未证实｜";
   }
   return detail==""?"极值前四小时至本棒的已载入日历无匹配事件":StringSubstr(detail,0,StringLen(detail)-1);
}
void drawNewsLabels(){
   openNewsGroup=0;
   ObjectsDeleteAll(0,newsKey(),0);
   int w=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),h=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   if(w<90 || h<70) return;
   double price=ChartGetDouble(0,CHART_PRICE_MAX,0);
   datetime now=TimeTradeServer();
   int xPositions[];ArrayResize(xPositions,ArraySize(events));ArrayInitialize(xPositions,-1);
   for(int i=0;i<ArraySize(events);i++){
      int x,y;
      datetime at=events[i].at;
      if(!ChartTimePriceToXY(0,0,at,price,x,y) || x<0 || x>=w) continue;
      if(at<now){
         // Weekend/holiday gaps collapse on the MT5 time axis. A neighbouring
         // quote cannot act as the publication candle, even on a weekly chart.
         if(iBarShift(_Symbol,PERIOD_M5,at-(long)at%300,true)<0) continue;
      }
      xPositions[i]=x;
   }
   TextSetFont("Microsoft YaHei",-105);
   color ink=(color)ChartGetInteger(0,CHART_COLOR_FOREGROUND);
   int maxWidth=MathMin(150,w-8);
   int selectedFirst=-1,selectedLast=-1,selectedX=0;
   datetime lastMarkedBar=0;
   for(int i=0;i<ArraySize(events);i++){
      if(xPositions[i]<0) continue;
      int x=MathMax(2,MathMin(xPositions[i],w-maxWidth-2)),last=i;
      while(last+1<ArraySize(events) && xPositions[last+1]>=0 &&
            MathMin(xPositions[last+1],w-maxWidth-2)<x+maxWidth) last++;
      bool expanded=newsExpanded>=events[i].at && newsExpanded<=events[last].at;
      if(expanded){selectedFirst=i;selectedLast=last;selectedX=x;openNewsGroup=events[i].at;}
      for(int j=i;j<=last;j++){
         newsText("t"+IntegerToString(events[j].at),xPositions[j],h-33,"│",
                  easternTime(events[j].at)+" 美东 · "+events[j].tag,clrGoldenrod,7);
         datetime at=events[j].at;
         if(at>now) continue;
         int shift=iBarShift(_Symbol,_Period,at,false);
         if(shift<0) continue;
         datetime bar=iTime(_Symbol,_Period,shift);
         if(bar==0 || bar==lastMarkedBar || at>=periodEnd(bar)) continue;
         int bx,by;
         if(!ChartTimePriceToXY(0,0,bar,iHigh(_Symbol,_Period,shift),bx,by) || bx<0 || bx>=w || by<10 || by>=h) continue;
         string key="k"+IntegerToString(at);
         newsText(key,bx,by-2,"◆",events[j].tag+" · 公布所在K线 · 点击看同期位移",clrGold,10);
         ObjectSetInteger(0,newsKey()+key,OBJPROP_ANCHOR,ANCHOR_LOWER);
         lastMarkedBar=bar;
      }
      string head=events[i].tag;
      string orig=head;
      while(StringLen(head)>1 && textWidth(head+"…")>maxWidth-5)
         head=StringSubstr(head,0,StringLen(head)-1);
      newsText("n"+IntegerToString(events[i].at),x,h-50,head+(head!=orig?"…":""),
               easternTime(events[i].at,TIME_MINUTES)+" 美东 · "+orig+(expanded?" · 点击收起":" · 点击展开"),clrGoldenrod,9);
      i=last;
   }
   datetime wkNow=now;MqlDateTime weekClock;TimeToStruct(now,weekClock);
   if(weekClock.day_of_week==6 || weekClock.day_of_week==0) wkNow=now+2*86400;
   int currentRef=weekReference(wkNow);
   if(currentRef>=0)
      newsText("agenda",w-104,h-70,"本周 / 下周日历","按交易周展开公布排期与上周价位",clrGoldenrod,9);
   if(reviewStart>0){
      string lines[];int width=MathMin(510,w-12);
      bool daily=reviewEnd-reviewStart<=25*3600;
      newsLine(lines,easternTime(reviewStart)+" 起 · "+(daily?"分段复盘":"本交易周日历与条件路径"),width);
      string realized[];int nr=StringSplit(realizedDOL(reviewStart,reviewEnd,daily),'｜',realized);
      for(int k=0;k<nr;k++) if(realized[k]!="")newsLine(lines,realized[k],width);
      for(int k=0;k<ArraySize(marks);k++){
         Mark m=marks[k];if(m.kind!=(daily?"day_extreme":"week_extreme") || m.start<reviewStart || m.start>=reviewEnd)continue;
         int cut=StringFind(m.label,"｜");
         newsLine(lines,cut<0?m.label:StringSubstr(m.label,0,cut),width);
      }
      for(int k=0;k<ArraySize(marks);k++){
         Mark m=marks[k];if(m.kind!=(daily?"day_extreme":"week_extreme") || m.start<reviewStart || m.start>=reviewEnd)continue;
         string parts[];int total=StringSplit(m.label,'｜',parts);
         if(total>0)newsLine(lines,parts[0],width);
         string nearby[];int ne=StringSplit(extremeNews(m.start),'｜',nearby);
         for(int i=0;i<ne;i++)newsLine(lines,nearby[i],width);
         for(int j=1;j<total;j++)newsLine(lines,parts[j],width);
      }
      int ref=weekReference(reviewStart);
      if(ref>=0){
         string context[];int n=StringSplit(weeklyScenario(marks[ref]),'｜',context);
         for(int j=0;j<n;j++) newsLine(lines,context[j],width);
      }
      if(daily) for(int k=0;k<ArraySize(marks);k++){
         Mark m=marks[k];if(m.kind!="day_leg" || m.start<reviewStart || m.start>=reviewEnd) continue;
         newsLine(lines,easternTime(m.start,TIME_MINUTES)+"–"+easternTime(m.finish,TIME_MINUTES)+" 美东",width);
         string detail[];int n=StringSplit(m.label,'｜',detail);
         for(int j=0;j<n;j++) newsLine(lines,detail[j],width);
         for(int i=0;i<ArraySize(events);i++) if(m.start<=events[i].at && events[i].at<m.finish){
            bool strong,swept;datetime cutoff=(datetime)MathMin(now,m.finish);
            newsLine(lines,events[i].tag+" · "+reaction(events[i].at,cutoff,strong,swept),width);
            newsLine(lines,eventStructure(events[i].at,cutoff,PERIOD_M5),width);
         }
      }
      int listed=0;
      for(int i=0;i<ArraySize(events);i++){
         if(events[i].at<reviewStart || events[i].at>=reviewEnd) continue;
         listed++;
         newsLine(lines,easternTime(events[i].at)+" 美东  "+events[i].tag+" · "+events[i].path,width);
         if(events[i].at>now){
            string previews[];int n=StringSplit(events[i].details,'\n',previews);
            for(int j=0;j<n;j++) newsLine(lines,previews[j],width);
         }
         if(events[i].assessment!="") newsLine(lines,"  派发复盘 · "+events[i].assessment,width);
         string items[];int n=StringSplit(events[i].details,'\n',items);
         for(int j=0;j<n;j++) if(StringFind(items[j],"MT5 · ")==0) newsLine(lines,"  "+items[j],width);
      }
      if(listed==0) newsLine(lines,"该周或该日尚无已载入排期，日历将随终端更新",width);
      int size=MathMax(1,MathMin(7,(h-140)/18));
      newsPageCount=(ArraySize(lines)+size-1)/size;newsPage=MathMin(newsPage,newsPageCount-1);
      int from=newsPage*size,to=MathMin(from+size,ArraySize(lines)),x=10,y=h-75-(to-from)*18;
      for(int i=from;i<to;i++) newsText("review"+IntegerToString(i),x,y+18*(i-from),lines[i],lines[i],ink,9);
      newsText("close",x,h-75,"收起复盘","收起",clrGoldenrod,10);
      if(newsPageCount>1) newsText("more",x+110,h-75,StringFormat("%d/%d  下一页 ›",newsPage+1,newsPageCount),"点击翻页",clrGoldenrod,10);
      if(!daily && currentRef>=0 && reviewStart==marks[currentRef].start)
         newsText("nextweek",x+250,h-75,"下一周排期 ›","查看已载入的下一周事件",clrGoldenrod,10);
   }else if(selectedFirst>=0) newsDetail(selectedFirst,selectedLast,8,w,h-52,ink);
}

bool clickNews(string name){
   if(StringFind(name,prefix+"H_")==0){
      int ix=(int)StringToInteger(StringSubstr(name,StringLen(prefix+"H_")));
      if(ix<0 || ix>=ArraySize(marks)) return false;
      bool same=reviewStart==marks[ix].start && reviewEnd==marks[ix].finish;
      reviewStart=same?0:marks[ix].start;reviewEnd=marks[ix].finish;newsExpanded=0;newsPage=0;
      return true;
   }
   string key=newsKey();
   if(StringFind(name,key)!=0) return false;
   string id=StringSubstr(name,StringLen(key));
   if(id=="agenda"){
      datetime at=TimeTradeServer();MqlDateTime clock;TimeToStruct(at,clock);
      if(clock.day_of_week==0 || clock.day_of_week==6) at+=2*86400;
      int ref=weekReference(at);if(ref<0) return true;
      datetime start=marks[ref].start,finish=marks[ref].finish;
      if(reviewStart==start && reviewEnd==finish){reviewStart=0;}
      else {reviewStart=start;reviewEnd=finish;}
      newsExpanded=0;newsPage=0;
   }else if(id=="nextweek"){
      reviewStart+=7*86400;reviewEnd=reviewStart+7*86400;newsPage=0;
   }else if(id=="close"){reviewStart=0;newsPage=0;}
   else if(id=="more"){if(newsPageCount>0) newsPage=(newsPage+1)%newsPageCount;}
   else if(StringSubstr(id,0,1)=="n" || StringSubstr(id,0,1)=="t" || StringSubstr(id,0,1)=="k"){
      datetime at=(datetime)StringToInteger(StringSubstr(id,1));
      bool open=newsExpanded==at || (StringSubstr(id,0,1)=="n" && openNewsGroup==at);
      newsExpanded=open?0:at;newsPage=0;reviewStart=0;
   }else return true;
   return true;
}
