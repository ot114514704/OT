// The existing week divider is NY Monday midnight. Saturday's NY boundary
// closes the study week. Both dates have the same server offset on TMGM.
void scaleTicks(datetime at,string key,int x,int w,int h,const double &prices[],const string &labels[],string detail,color ink){
   if(x<0 || x>w-12) return;
   int used[];ArrayResize(used,0);
   for(int i=0;i<ArraySize(prices);i++){
      int bx,y;if(!ChartTimePriceToXY(0,0,at,prices[i],bx,y) || y<2 || y>=h-20) continue;
      rectangle(w,h,x,y,x+9,y+1,ColorToARGB(ink,230));
      int ly=MathMax(1,y-8);
      for(int j=0;j<ArraySize(used);j++) if(MathAbs(ly-used[j])<15){ly=used[j]+15;j=-1;}
      if(ly>=h-26){
         ly=y-8;
         for(int j=0;j<ArraySize(used);j++) if(MathAbs(ly-used[j])<15){ly=used[j]-15;j=-1;}
      }
      int n=ArraySize(used);ArrayResize(used,n+1);used[n]=ly;
      string text=labels[i];
      int split=StringFind(text," ");if(split>=0) text=StringSubstr(text,0,split);
      int labelX=x+12;
      if(labelX+textWidth(text)>w) labelX=MathMax(0,x-textWidth(text)-4);
      screenNote(prefix+"D_scale"+key+IntegerToString(i),labelX,ly,text,ink,labels[i]+" · "+DoubleToString(prices[i],_Digits)+"\n"+detail);
   }
}

string tgifCaption(string state,string reason){
   if(state=="TGIF 已确认") return "TGIF 已实现 · 可实现";
   if(state=="TGIF 未成立"){
      if(reason=="未观察到顺向回撤触带") return "TGIF 未实现 · 可实现";
      if(reason=="周五开盘前已触目标" || reason=="周初对侧极点或周二至四同向扩张不符")
         return "TGIF 未实现 · 不可实现";
      return "TGIF 未实现 · 可行性待核";
   }
   if(state=="TGIF 回撤候选") return "TGIF 可实现 · 已触带";
   if(state=="TGIF 回撤待观察") return "TGIF 可实现 · 待触带";
   if(state=="TGIF 目标已提前触及" || state=="TGIF 前提不足") return "TGIF 不可实现";
   return "TGIF 待核";
}

string weeklyRulers(datetime monday,int w,int h,string &reason){
   reason="";
   datetime fri=monday+4*86400,end=fri+86400,now=TimeTradeServer();
   MqlRates b[];
   int n=CopyRates(_Symbol,PERIOD_M5,monday,(datetime)MathMin(end-1,now),b);
   if(n<1 || b[0].time!=monday) return "周行情不足";
   double high=b[0].high,low=b[0].low,op=b[0].open,close=b[n-1].close;
   datetime due=(datetime)MathMin((long)now/300*300,(long)fri+17*3600);
   // TMGM study grid: Mon–Thu 17–18 NY recess, Fri last M5 opens 16:50 NY.
   // Friday 17:00 is the evaluation deadline. An extra closed bar contradicts the grid.
   datetime expected=monday,studyEnd=fri+16*3600+55*60;
   bool grid=true;
   double auditHigh=-DBL_MAX,auditLow=DBL_MAX;
   int last[5];
   ArrayInitialize(last,-1);
   for(int i=0;i<n;i++){
      int day=(int)((b[i].time-monday)/86400);
      last[day]=i;
      high=MathMax(high,b[i].high);
      low=MathMin(low,b[i].low);
      if(b[i].time>=studyEnd && b[i].time+300<=now)grid=false;
      if(b[i].time+300<=due){
         if(b[i].time!=expected) grid=false;
         expected=b[i].time+300;
         if(day<4 && (expected-monday)%86400==17*3600)expected+=3600;
         auditHigh=MathMax(auditHigh,b[i].high);auditLow=MathMin(auditLow,b[i].low);
      }
   }
   color ink=(color)ChartGetInteger(0,CHART_COLOR_FOREGROUND);
   string key=IntegerToString(monday),detail="纽约周一零点起 · "+easternTime(b[n-1].time)+" 美东 M5";
   int x,y;double levels[4]={high,op,close,low};
   bool fridayClosed=now>=fri+17*3600;
   bool covered=grid && expected==(datetime)MathMin(due,studyEnd);
   string labels[4]={"周高","周开","周暂收","周低"};
   if(fridayClosed){
      labels[2]=covered?"周收":"末价";
      if(!covered)detail+=" · 周收待核，M5 报价与研究时段不匹配";
   }
   if(ChartTimePriceToXY(0,0,monday,op,x,y)) scaleTicks(monday,key+"W",x,w,h,levels,labels,detail,ink);
   if(now<fri || high<=low || last[3]<0) return "待周五";
   double bias=b[last[3]].close-op;
   if(bias==0) return "TGIF 周方向待核";
   bool up=bias>0;
   double span=high-low;
   double fib[4]={high,up?high-.2*span:low+.2*span,up?high-.3*span:low+.3*span,low};
   string names[4]={"0 周高","0.2 回撤20%","0.3 回撤30%","1 周低"};
   if(!up){names[1]="0.8 回升20%";names[2]="0.7 回升30%";}
   // Keep tick-driven geometry separate from the audited, closed-M5 touch record.
   // Expired observations or a newly extended range cannot confirm these levels.
   string state="TGIF 等待M5核对";
   bool matched=false;string observation="";
   for(int i=0;i<ArraySize(marks);i++){
      Mark m=marks[i];
      if(m.kind!="fri_check" || m.start!=fri || m.finish<due || m.finish>now) continue;
      int split=StringFind(m.label,"｜");
      string headline=split<0?m.label:StringSubstr(m.label,0,split);
      if(m.first==0 && m.last==0){state=headline;if(split>=0) reason=StringSubstr(m.label,split+1);break;}
      // The open M5 can move the live ruler but cannot erase a prior ordered touch.
      bool auditMatches=covered && MathAbs(m.first-auditLow)<_Point/2 && MathAbs(m.last-auditHigh)<_Point/2;
      matched=auditMatches && MathAbs(m.first-low)<_Point/2 && MathAbs(m.last-high)<_Point/2;
      if(auditMatches || headline=="TGIF 报价待核"){
         state=headline;
         if(split>=0) observation=StringSubstr(m.label,split+1);
         string parts[];
         int count=StringSplit(observation,'｜',parts);
         if(count>=4) reason=parts[count-1];
         if(auditMatches && !matched)observation+="｜当前未收 M5 已移动刻度，最新刻度触价待收线";
      }else if(!covered){
         state="TGIF 报价待核";reason="已收 M5 与纽约研究时段不匹配";
      }
      break;
   }
   if(matched){
      for(int i=0;i<ArraySize(marks);i++){
         Mark m=marks[i];
         if(m.kind!="fri_fib" || m.start!=fri) continue;
         for(int k=1;k<=2;k++){
            double fraction=(k==1?0.2:0.3);
            double ratio=up?fraction:1-fraction;
            if(MathAbs(m.last-ratio)<0.00001 && MathAbs(m.first-fib[k])<_Point/2) names[k]+=" "+m.label;
         }
      }
   }
   detail=state+"\n"+(up?"自周高向下回撤":"自周低向上回升")+" · 按周波幅的 20% / 30% 核对周五触价";
   if(observation!=""){StringReplace(observation,"｜","\n");detail+="\n"+observation;}
   if(ChartTimePriceToXY(0,0,fri,op,x,y)) scaleTicks(fri,key+"F",x,w,h,fib,names,detail,clrGoldenrod);
   return state;
}
