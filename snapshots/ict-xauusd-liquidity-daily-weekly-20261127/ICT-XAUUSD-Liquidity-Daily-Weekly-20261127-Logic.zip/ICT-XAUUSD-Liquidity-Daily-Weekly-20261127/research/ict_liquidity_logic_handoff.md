# XAUUSD 流动性识别与回测交接

快照日期为 2026-11-23。指标为 MT5 XAUUSD 1.34，资料和回测采用纽约时间。解压后保持目录层级。当前生产排序、盘面回顾和离线候选实验有各自的观察口径。

## 怎样识别流动性

项目用价格验证两类交付路径：越过已知高低点寻找流动性，以及回到 FVG 等失衡区进行回补。高点外侧是买方流动性候选，低点外侧是卖方流动性候选。OHLC 可以证明报价的触达、穿越、回收和结构变化。实际挂单量、订单是否耗尽及参与者意图需要额外证据。

| 功能 | 识别要点 | 入口 |
| --- | --- | --- |
| 内外区间地图 | 在已完成的纽约前日或前周范围中分类。边界可用时冻结参照范围和关系版本。确认后的 M15 极点才能出现在图上。FVG 保存边界、中点、触达、回补及收线失效。 | [range_liquidity.py](../ict_ai/range_liquidity.py) |
| 常规流动性 | 前高前低、相对等高等低、前日与前周高低分别登记。M15 常规等位研究阈值默认为 0.03 美元，同侧两摆动须连续、最多相隔 12 小时。该阈值独立于预测榜的价格聚合阈值。 | [regular_liquidity.py](../ict_ai/regular_liquidity.py) · [liquidity.py](../ict_ai/liquidity.py) · [daily_context.py](../ict_ai/daily_context.py) |
| 日内和外部积累榜 | IRL 需要候选区域和现价同属于已知的纽约日、周或月参照范围。ERL 来源为 D1／W1／MN1 区间外沿。同一方向的聚合极值去重，保留价带、来源、确认时刻、同侧路径和 DOL 交集。 | [structural_liquidity.py](../ict_ai/structural_liquidity.py) |
| 日内与周内已扫 | 日图按已确认的结构高低点寻找严格穿越，归类取当时可知的参照范围。周内按已完成的每个纽约交易日更新阶段周高低，再观察后来首次越过。当日和周内清扫各有展示标记。 | [regular_liquidity.py](../ict_ai/regular_liquidity.py) · [export_mt5_profiles.py](../scripts/export_mt5_profiles.py) |
| 扫后结构 | 记录初次越界、SFP 或收回、位移、CISD、已确认摆动的收破、FVG 和后续延续或失效。MSS、CISD、反向位移和继续推进均有独立时间。 | [sweep_response.py](../ict_ai/sweep_response.py) · [session_path.py](../ict_ai/session_path.py) · [structure.py](../ict_ai/structure.py) |
| 交付背景 | DOL 提供方向与候选，AMD 提供盘整、越界收回和扩张的顺序，日周概况提供上下文。交易时段、经济事件、银弹、犹大摆动、SMT 和未回补 FVG 可以解释到达路径。整数、趋势线和 IDM 是研究线索，按实际源码核对是否进入评分。 | [dol_history.py](../ict_ai/dol_history.py) · [dol_outlook.py](../ict_ai/dol_outlook.py) · [po3.py](../ict_ai/po3.py) · [silver_trigger.py](../ict_ai/silver_trigger.py) · [judas.py](../ict_ai/judas.py) · [资料综合](ict_price_videos/liquidity_h4_synthesis.md) |

预测榜最小级别是 M5。M5、M6、M10、M12 需有极值前后各两根在内的连续已收 M5，记录 5–10 根支撑。M6／M12 的原生时间聚合依赖 M1。M15 到 H12 使用已确认摆动，D1、W1、MN1 使用纽约范围。已有报价严格越过、原点后报价缺段、与现价侧别不符的候选会被淘汰。同侧同类价位以最高 `max(0.01, 0.08 × R)` 的价带合并，`R` 为最近至多 24 个有效已收 H1 波幅的中位数。活跃日、周、月参考以当时已有的行情计算，历史确认时刻和极值发生时刻分别保存。

## 生产评分及 MT5 接入

| 分项 | 分数 |
| --- | --- |
| 周期与新近度 | 取最高周期权重。分钟组 13，H1–H4 为 17，H6–H12 为 11，D1、W1、MN1 分别为 17、15、14。纽约当日或前一交易日分别加 12 或 7，最高 29。 |
| 独立极点 | 第一个 7，其后每个 +6，最高 19。相隔至少五根 M5，跨周期同一原点只计一次。 |
| 跨周期来源 | 分钟组、小时组、日周月组，每增加一组 +4，最高 8。 |
| 距离 | `floor(0.5 + 27 / (1 + d / (3 × R)))`，`d` 是现价到区域近端的距离。 |
| 同向 DOL 与路径 | 同向 DOL 的近端落在价带时 +7。同侧每一层更近的流动性使路径分从 4 减 1，最低 0。 |
| 方向背景 | 同向 DOL 对齐分经转换后最高贡献 6 分。 |
| 同侧最近外沿提档 | 距现价在 `1R / 0.5R / 0.25R` 内分别 +6／+12／+18。半倍波幅内有两个独立原点和同向 DOL 重叠时再 +4。加总封顶 100。 |

行情桥在新 M5 截点生成候选和结构证据。MT5 通过最新 Bid 更新近端距离分，筛除已越界及落在错误方向的候选，分 IRL／ERL 展示各自的前十。已扫标记与 BOS／CHoCH 有各自的标签和详情。同根影线收回时，点线从原位连到越界棒，色带覆盖越界外沿到影线极值。DOL 与已实现目标按各自定义显示。

首次严格越过外沿后，按仓库 V7B 的收盘逻辑观察。连续 14 根已收 M5 的真实波幅均值固定为 ATR，越界棒及随后最多 48 根连续收线参与判别。收盘回原侧且离位达到 1 ATR 为收回离位。连续两根收在外侧且第二根离位达到 1 ATR 为收外跟随。先达到的条件保留当时的确认时间。缺前置报价或后续报价时保留待核状态。该判词用于复盘扫后行为，预选命中继续使用严格越界。 [仓库实现](https://github.com/alexander094683-projects/forex-ai-source/blob/b2e15dfb9734a3587de8e48ee43fe2f56ff934b9/docs_layered/work_backup/sweep_v7.py) · [逐根回测](../output/research/ict_sweep_verdict_20261124/流动性逐根回测.md)

[MT5 读取与开关](../mt5/ICT_H1_Profiles.mq5) · [积累榜与动态分](../mt5/ICT_Liquidity_Pool.mqh) · [提档逻辑](../ict_ai/target_priority.py) · [行情桥](../scripts/export_mt5_profiles.py) · [旧五周期榜](../ict_ai/liquidity_accumulation.py)

## 回测如何复核

1. 数据取固定 TMGM XAUUSD 快照。使用归档的服务器时间映射再转成 `America/New_York`，按实际夏令时切换。默认检查点为纽约 00:05、02:00、08:00、10:00、14:00。全天以纽约零点切分，周尾研究截止以归档 M5 的周五 16:55 为准。
2. 在截点冻结候选、分值、锚点、DOL 证据和可用的 M1。每个 IRL／ERL 最多 50 个。独立比较前 10、20、30、50，记录实际候选数、空缺、缺行情及结果尚未到期。成熟短窗为最多四小时且不跨研究日界，周窗追踪到周五收盘。
3. 触达要求报价范围与区域相交。严格清扫要求同一根已收 M5 同时经过并严格越过远端。整根跳过区间另记。第 19 轮在清扫当根及随后三根连续 M5 观察收回。DOL 触价按近端，采用不同的标签。无细粒度证据时保留同根内顺序不明。
4. 逐周训练只用最早测试截点前已到期的记录。现版、外沿最近和试验模型使用同一冻结候选及报价窗口。比较走势、时段、形态和删项后的增益，按周配对统计波动范围。多个截点可对应同一次实际清扫，样本数为截点与候选的组合。
5. 每轮保留上一轮漏选但实现的目标，以及当时可见的近距反例。低分按 45 及以下、46–55、56–65、65 以上分层。只有发生在决策前的方向、收回、已确认近端清扫等条件可参与追踪，目标结果只用于打标签。其余事后证据用于解释历史走势。
6. 新闻既有回放按官方实际公布时间对齐，并检查当时可知的排期。同一时段的对照需筛查已知其他事件。新闻窗口里的低分漏选增益专项仍待完成，最新排行采用现有验证权重。

| 证据与输出 | 内容 |
| --- | --- |
| [第 19 轮冻结与基线](../output/research/ipda_four_cycle_validation_20261122/round19_liquidity_baseline.json) | 6–11 月每榜最多 50 个的严格扫荡、触达、回收、完整窗口与缺名次统计 |
| [逐名次排序](../output/research/ict_liquidity_rank_walkforward.json) | 10–11 月逐周样本、现版与外沿距离、学习排序、可用候选上限 |
| [时间、走势与形态](../output/research/ict_liquidity_context_walkforward.json) | 15 分钟、1 小时和 4 小时净位移，纽约时段、盘整／扩张／回收，含逐周对照 |
| [漏选与对照](../output/research/ict_liquidity_miss_audit.json) | 逐个保存上一轮 555 个漏选已扫样本，并补录 6–9 月 1,070 个原榜外、65 分及以下的已扫记录 |
| [扫后结构](../output/research/sweep_followthrough_20261122/扫荡后结构复盘.md) | 价格到达、扫后收回、反向收破与后续证据 |
| [官方新闻回放](../output/research/vintage_news_targets_20261122/官方新闻回放.md) | 24 个早期官方事件的发布前后走势、区间与候选，附排期和来源 |
| [图例](../output/research/ict_liquidity_miss_examples/) | 低分补回、替换造成漏选以及研究对照 |

10–11 月前十严格清扫率如下。逐名次未达全部超过 60% 的目标，尤其四小时 ERL。四小时 IRL 的动态近端扫荡规则在 13 次符合条件时命中 5 次，同样 13 次都和当时按距离选择的目标一致。

| 期限及范围 | 现版 | 清扫外沿距离 | 加入走势、时段和形态 |
| --- | ---: | ---: | ---: |
| 四小时 IRL | 26.1% | 27.8% | 27.8%（497/1785） |
| 四小时 ERL | 6.5% | 6.5% | 6.5%（120/1840） |
| 周内 IRL | 59.0% | 62.2% | 62.6%（1124/1795） |
| 周内 ERL | 23.2% | 24.2% | 24.9%（460/1850） |

## 复现与核验

在解压后的根目录使用 Windows x64 可用的 Python 3.11+。离线研究需要 NumPy、`tzdata` 和 `MetaTrader5` Python 包。一些历史载入器在导入时依赖后者。下列最短回放路径读取已冻结快照，无需启动交易终端。可选的图例重渲染还需要 Matplotlib。其他历史脚本所需的额外本机原始档案按原证据路径引用。

```powershell
python -m pip install numpy tzdata MetaTrader5
python -m unittest discover -s tests -p "test_ict_*liquidity*.py" -q
python -m unittest discover -s tests -p "test_ict_sweep_response.py" -q
python output/research/ipda_four_cycle_validation_20261122/round19_liquidity_freeze.py score
python scripts/replay_ict_liquidity_rank.py
python scripts/replay_ict_liquidity_context.py
python scripts/replay_ict_liquidity_misses.py
```

需要重建候选时，在归档副本中运行 `round19_liquidity_freeze.py freeze` 后再执行 `score`。候选、行情和脚本均有固定哈希。源文件可能存在不同历史版本；归档保留原始锁和研究结果。压缩包内的 `MANIFEST.json` 列出每个文件、SHA-256 及角色。原始课程、外部视频、账户资料及运行数据库使用独立的本地保存方式。
