# XAUUSD 流动性、每日与每周概况 · 2026-11-27

TMGM / MetaTrader 5 工作区快照，MT5 指标源码版本 1.34。压缩包内的 `ICT_H1_Profiles.ex5` 对应本次纳入的 `ICT_H1_Profiles.mq5`。日周候选、扫后状态和仓库补漏都带有验证依据。压缩包可离线阅读和回放。

| 逻辑 | 当前判断 | 源码和证据 |
|---|---|---|
| 流动性预选 | 依参考区间分 IRL／ERL，保留结构排序和原五根确认。四根候选须满足同侧 1 ATR 条件。首次严格 Bid 越界、登记前越界和报价缺口分别记录。 | [预选实现](scripts/ict_liquidity_window_preselection.py) · [窗口对比](output/visualizations/ict-liquidity-window-preselection.html) |
| 扫过后的价格反应 | 记录首次越界、首次收回及结构变化。恰好收在边界会中断连续外侧收盘，保留此前状态。旧实时报表按其冻结规则复核。 | [中性边界](ict_ai/sweep_state_strict.py) · [逐根对照](output/research/ict_sweep_state3_tmgm_20261126_neutral_edge.json) |
| 仓库候选补漏 | 保留本地首选，仓库候选按同侧距离及未覆盖方向决定是否补入第二位。独立保留短窗口与更长观察期。 | [整合规则](ict_ai/liquidity_repo_overlay.py) · [补位来源](output/research/ict_repo_vs_local_forecast_20261125/repo_overlay_source_ablation.json) |
| 每日概况 | 纽约交易日按已收盘的时段价格路径保留候选，单列信号所缺的高周期位置、流动性反应和后续方向。收盘后核对路径，保存盘中暂不判断的结果。 | [日型规则](research/ict_daily_profiles/rules.json) · [盘中筛选回测](output/research/ict_intraday_abstention_20261126.json) |
| 每周概况 | 按已结束的纽约研究日冻结范围与极点。周五分别观察周四越界后的反转及顺向扩张后的跟随，回放显示满足或失效时点。 | [周型规则](research/ict_weekly_profiles/rules.json) · [周五跟随复算](output/research/ict_weekly_friday_followthrough_verified_reopen_20261126.json) · [离线复盘](output/visualizations/ict-week-friday-followthrough.html) |

[日型课程索引](research/ict_time_videos/time2_daily/integration.json) · [周型课程索引](research/ict_time_videos/time3_weekly/integration.json) · [旧版补漏交接](OVERLAY_BASELINE.md) · [逐文件校验](MANIFEST.json)

先解压再打开 HTML。Python 3.12 在解压根目录可复跑下列离线检查。周五比较使用侦测时点之后的收盘路径做验证。这些输出供研究和行情复盘使用。

```powershell
python -m pip install numpy tzdata
python -m unittest discover -s tests -p "test_ict_weekly*.py" -q
python -m unittest discover -s tests -p "test_ict_sweep_state.py" -q
python -B -m scripts.audit_ict_profile_timeline --out output/research/replay_profile_timeline.json
python -B -m scripts.audit_ict_weekly_friday_followthrough --reopen-audit output/research/ict_weekly_reopen_gaps_20261126.json --out output/research/replay_friday_followthrough.json
```

MT5 行情桥另需 Windows x64、MetaTrader5 Python 模块和用户本机已连接的终端。归档未携带本机账户、令牌或私有终端数据库。

逐笔历史样本与旧版完整报表延续存于 [11 月 25 日 OT 快照](https://github.com/ot114514704/OT/tree/12e84e4f6081a07fc1004ef0e1f530d2e168eb84/snapshots/ict-xauusd-liquidity-repo-overlay-20261125)。本包含当前逻辑、主要报告、复盘页面及上述两条日周复现命令使用的 M5 存档。
