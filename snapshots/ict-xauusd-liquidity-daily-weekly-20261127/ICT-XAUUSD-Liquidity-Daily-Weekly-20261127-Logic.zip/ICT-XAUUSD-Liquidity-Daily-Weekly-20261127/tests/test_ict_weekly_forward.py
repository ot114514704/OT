from dataclasses import replace
from datetime import date, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from brooks_ai.types import Bar
from ict_ai.range_liquidity import _research_open
from scripts import watch_ict_weekly_candidates as watch


class WeeklyForwardTests(unittest.TestCase):
    def setUp(self):
        self.monday = date(2026, 6, 1)
        self.days, self.start, self.end, self.times = watch.schedule(self.monday)
        self.at = self.times['friday_1000']
        self.week = []
        stamp = self.start
        while stamp < self.end:
            if _research_open(stamp):
                price = 112 if self.at-timedelta(minutes=45)<=stamp else 100
                self.week.append(Bar(stamp, price, price+1, price-1, price, 0))
            stamp += watch.M5
        self.prefix = [b for b in self.week if b.time+watch.M5<=self.at]
        self.witness = watch.encode_bars(self.prefix[-1:])[0]
        self.protocol = {'fixture_protocol':1}
        self.captured = self.end+watch.SYNC_GRACE

    def freeze(self, started=None, recorded=None, witness=None, quote=None):
        return watch.forecast(self.days,'friday_1000',self.prefix,witness or self.witness,self.at,
                              started or self.start,recorded or self.at,quote or self.at,self.protocol)

    def finish(self, frozen, market=None):
        return watch.settlement(self.days,self.end,self.week if market is None else market,self.captured,
                                {'friday_1000':frozen},self.protocol)

    def test_week_schedule_respects_new_york_summer_and_winter(self):
        _, _, _, winter = watch.schedule(date(2026, 11, 23))
        self.assertEqual((self.times['tuesday'].weekday(),self.times['tuesday'].hour),(2,4))
        self.assertEqual((winter['tuesday'].weekday(),winter['tuesday'].hour),(2,5))
        self.assertEqual((self.at.hour,winter['friday_1000'].hour),(14,15))

    def test_forecast_rejects_late_registration_and_inconsistent_source(self):
        for kwargs in (dict(started=self.at+watch.M5),dict(recorded=self.at+watch.WINDOW),
                       dict(witness=[*self.witness[:-1],99]),dict(quote=self.at-watch.M5)):
            with self.subTest(kwargs=kwargs),self.assertRaises(ValueError):
                self.freeze(**kwargs)

    def test_forecast_and_settlement_recompute_from_distinct_prefixes(self):
        frozen = self.freeze()
        self.assertEqual(frozen['state']['friday_watch']['direction'],1)
        result = self.finish(frozen)
        self.assertTrue(result['coverage_complete'])
        self.assertTrue(result['checkpoints']['friday_1000']['counts']['watch_exact_variant'])
        self.assertEqual(result['checkpoints']['friday_1000']['counts']['with_friday_watch']['matched'],1)
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            folder = root/self.monday.isoformat()
            path = folder/'friday_1000.json'
            watch.atomic_json(path,frozen)
            watch.atomic_json(folder/'settlement.json',result)
            state = watch.archive_state(root,self.protocol,self.captured)
            self.assertEqual(state[folder.name]['status'],'settled')
            total = watch.summary(state)['friday_1000']
            self.assertEqual(total['statuses']['scored'],1)
            self.assertEqual(total['added_variant_matches'],1)
            frozen['state']['friday_watch']['direction'] = -1
            watch.atomic_json(path,frozen)
            with self.assertRaisesRegex(ValueError,'Unreproducible forecast'):
                watch.archive_state(root,self.protocol,self.captured)

    def test_revisions_and_missing_tail_are_excluded_from_scoring(self):
        frozen = self.freeze()
        revised = [replace(self.week[0],close=100.5),*self.week[1:]]
        result = self.finish(frozen,revised)['checkpoints']['friday_1000']
        self.assertEqual(result['status'],'history_changed')
        self.assertIsNone(result['counts'])
        result = self.finish(frozen,self.week[:-1])['checkpoints']['friday_1000']
        self.assertEqual(result['status'],'insufficient_coverage')
        self.assertIsNone(result['counts'])
