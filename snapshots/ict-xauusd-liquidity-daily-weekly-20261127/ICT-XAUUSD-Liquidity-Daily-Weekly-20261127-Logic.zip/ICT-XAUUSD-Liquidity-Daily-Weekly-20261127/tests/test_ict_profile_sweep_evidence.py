from datetime import date, timedelta
from unittest import TestCase

from brooks_ai.types import Bar
from ict_ai.profile_sweep_evidence import candidate_sweep
from ict_ai.range_liquidity import M5
from ict_ai.timebase import session_windows


class ProfileSweepEvidenceTests(TestCase):
    def setUp(self):
        self.day = date(2026,11,24)
        windows = session_windows(self.day)
        start,end = windows['asia'][0],windows['london'][1]
        self.cross = windows['london'][0]+M5
        self.times = [start+i*M5 for i in range((end-start)//M5)]
        self.bars = [Bar(t,100,101,99,100,0) for t in self.times]
        i = self.times.index(self.cross)
        self.bars[i] = Bar(self.cross,100,101,97,99.5,0)
        self.bars[i+1] = Bar(self.cross+M5,99.5,102,99,101.5,0)
        self.key = 'classic_buy',1

    def observed(self,as_of):
        return candidate_sweep(self.bars,self.times,self.day,as_of,self.key)

    def test_unclosed_candle_cannot_publish_a_sweep_or_response(self):
        self.assertEqual(self.observed(self.cross+timedelta(minutes=4))['state'],'no_strict_cross')
        self.assertEqual(self.observed(self.cross+M5)['state'],'pending')
        proven = self.observed(self.cross+2*M5)
        self.assertEqual(proven['state'],'sweep')
        self.assertEqual(proven['verdict_known_at'],(self.cross+2*M5).isoformat())

    def test_outside_candle_does_not_establish_a_witnessed_cross(self):
        i = self.times.index(self.cross)
        self.bars[i] = Bar(self.cross,98,98.5,97,97.5,0)
        observed = self.observed(self.cross+2*M5)
        self.assertEqual(observed['state'],'outside_without_witnessed_cross')
        self.assertEqual(observed['features'],[0,0,0,0,0])
