from datetime import datetime, timezone
from unittest import TestCase

from brooks_ai.types import Bar
from scripts.audit_ict_dol_route_through_liquidity import M5, first_destination, freeze_route, landmark


class DolLiquidityRouteTests(TestCase):
    def setUp(self):
        self.start = datetime(2026, 11, 24, 12, tzinfo=timezone.utc)
        self.target = dict(lo=110, hi=112, side=1)
        self.gate = dict(lo=103, hi=104, side=1, rank=2)
        self.route = freeze_route([self.target], [self.gate], 100)

    def bars(self, *prices):
        return [Bar(self.start + i * M5, o, h, l, c, 0) for i, o, h, l, c in prices]

    def test_route_does_not_use_inside_overlapping_or_opposite_side_levels(self):
        leader = dict(lo=102, hi=103, side=1)
        invalid_gates = [dict(lo=99, hi=101, side=1, rank=1),
                         dict(lo=107, hi=110, side=1, rank=1),
                         dict(lo=105, hi=106, side=-1, rank=1)]
        route = freeze_route([leader, self.target], [*invalid_gates, self.gate], 100)
        self.assertEqual(route['dol_rank'], 2)
        self.assertEqual(route['gate'], self.gate)

    def test_only_complete_post_cross_closes_can_resolve_reaction(self):
        prices = self.bars((0, 103, 104, 101, 103), (1, 103, 106, 103, 105),
                           (2, 105, 105, 103, 104.5), (3, 105, 106, 104, 105.5))
        self.assertEqual(landmark(prices[:1], self.route)['status'], 'gate_not_crossed')
        self.assertEqual(landmark(prices[:3], self.route)['status'], 'gate_crossed_without_landmark')
        observation = landmark(prices, self.route)
        self.assertEqual(observation['reaction'], 'accepted')
        self.assertEqual(observation['available_at'], (self.start + 4 * M5).isoformat())

    def test_reclaim_distinguishes_outer_edge_from_full_zone(self):
        prefix = self.bars((0, 103, 106, 103, 105), (1, 105, 106, 104, 105))
        inner = landmark(prefix + self.bars((2, 105, 105, 103, 103.5)), self.route)
        full = landmark(prefix + self.bars((2, 105, 105, 102, 102.5)), self.route)
        equal = landmark(prefix + self.bars((2, 105, 105, 103, 104)), self.route)
        self.assertEqual((inner['reaction'], inner['reclaimed_full_zone']), ('reclaimed', False))
        self.assertEqual((full['reaction'], full['reclaimed_full_zone']), ('reclaimed', True))
        self.assertEqual(equal['reaction'], 'unresolved')

    def test_target_touch_through_landmark_and_unobserved_gaps_are_censored(self):
        cross = self.bars((0, 103, 106, 103, 105))
        gap_cross = landmark(self.bars((0, 105, 106, 105, 106)), self.route)
        gap_after = landmark(cross + self.bars((2, 105, 106, 104, 105)), self.route)
        target_on_landmark = landmark(cross + self.bars((1, 105, 107, 104, 106),
                                                        (2, 106, 110, 105, 107)), self.route)
        self.assertEqual(gap_cross['status'], 'gate_gap_over')
        self.assertEqual(gap_after['status'], 'gap_after_gate_cross')
        self.assertEqual(target_on_landmark['status'], 'dol_reached_or_jumped_before_landmark')

    def test_destination_is_mirrored_and_gap_is_not_witnessed_contact(self):
        prices = self.bars((0, 107, 109, 106, 108), (1, 108, 110, 107, 109))
        reverse = [Bar(b.time, 200 - b.open, 200 - b.low, 200 - b.high, 200 - b.close, 0) for b in prices]
        down_route = freeze_route([dict(lo=88, hi=90, side=-1)],
                                  [dict(lo=96, hi=97, side=-1, rank=1)], 100)
        self.assertEqual(first_destination(prices, self.route), first_destination(reverse, down_route))
        self.assertEqual(first_destination(prices, self.route)[0], 'contact')
        self.assertEqual(first_destination(self.bars((0, 111, 113, 111, 112)), self.route)[0],
                         'unwitnessed_gap_over')
