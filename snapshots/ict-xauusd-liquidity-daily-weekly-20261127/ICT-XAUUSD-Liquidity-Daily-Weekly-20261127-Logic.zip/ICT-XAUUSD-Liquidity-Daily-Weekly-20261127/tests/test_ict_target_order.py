import unittest
from datetime import datetime, timedelta, timezone

from brooks_ai.types import Bar
from scripts.audit_ict_target_order import MinuteOrder
from scripts.audit_ict_target_ticks import boundary_time


class TargetOrderTests(unittest.TestCase):
    def setUp(self):
        at = datetime(2026, 10, 12, 12, tzinfo=timezone.utc)
        self.end = (at + timedelta(minutes=5)).isoformat()
        self.records = [[(at+timedelta(minutes=i)).isoformat(), *row] for i,row in enumerate([
            (100,102,100,101), (101,101,97,98), (98,100,98,99), (99,100,98,100), (100,100,99,99)
        ])]
        self.five = Bar(at,100,102,97,99,0)
        self.targets = [dict(side=-1,lo=98,hi=98),dict(side=1,lo=101,hi=101)]

    def refine(self, records, targets=None, sweep=False):
        return MinuteOrder(records,[self.five]).refine(
            targets or self.targets,[self.end,self.end],[True,True],sweep=sweep)

    def test_reconciled_minutes_improve_tied_m5_order(self):
        self.assertEqual(self.refine(self.records), ([1],'m1_unique'))
        self.assertEqual(self.refine(self.records,sweep=True), ([1],'m1_unique'))

    def test_missing_minute_cannot_break_tie(self):
        self.assertEqual(self.refine(self.records[1:]), ([0,1],'unreconciled_m1'))

    def test_identical_price_boundary_is_a_shared_event(self):
        same_boundary = [dict(side=1,lo=101,hi=101),dict(side=1,lo=101,hi=102)]
        self.assertEqual(self.refine(self.records,same_boundary), ([0,1],'shared_boundary'))

    def test_missing_minutes_create_a_probe_for_the_whole_m5(self):
        probe = {}
        MinuteOrder(self.records[1:],[self.five]).refine(
            self.targets,[self.end,self.end],[True,True],sweep=False,unresolved=probe)
        self.assertEqual(probe['duration'],300)
        self.assertEqual(probe['ohlc'],[100,102,97,99])
        self.assertEqual(probe['boundaries'],[(0,-1,98),(1,1,101)])

    def test_ticks_preserve_same_millisecond_and_require_strict_sweep(self):
        quotes = [(0,100),(100,101),(100,102),(300,103)]
        self.assertEqual(boundary_time(quotes,1,101,False),100)
        self.assertEqual(boundary_time(quotes,1,102,False),100)
        self.assertEqual(boundary_time(quotes,1,102,True),300)
        self.assertIsNone(boundary_time(quotes,1,99,True))
