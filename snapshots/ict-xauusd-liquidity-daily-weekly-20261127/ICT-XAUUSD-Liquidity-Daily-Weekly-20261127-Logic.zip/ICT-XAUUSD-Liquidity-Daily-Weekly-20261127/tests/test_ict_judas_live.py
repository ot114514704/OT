import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from brooks_ai.types import Bar
from ict_ai.dol_history import batch_id, chart_receipts, live_reviews, settle
from ict_ai.judas import STEP, day_signals
from scripts.replay_judas_retests import quote_contact
from brooks_ai.types import Tick
from ict_ai.timebase import NY


class LiveRecognitionTest(unittest.TestCase):
    def test_pool_receipt_strict_edge_and_intrabar_ambiguity(self):
        at=datetime(2026,11,18,15,tzinfo=timezone.utc)
        ack=at+timedelta(seconds=40)
        pools=[dict(scope='irl',side=1,lo=101,hi=102,rank=1,score=58,name='内部买方'),
               dict(scope='erl',side=-1,lo=97,hi=98,rank=2,score=52,name='外部卖方')]
        bars=[Bar(at,100,102,96,100,0),Bar(at+STEP,100,103,96,101,0)]
        with tempfile.TemporaryDirectory() as folder:
            db=Path(folder)/'r.sqlite'
            key=batch_id(at,100,[[],pools])
            live_reviews(db,at,at,100,[],[],{},pools=pools,batch=key)
            result=live_reviews(db,at+2*STEP,at+2*STEP,101,[],bars,{key:ack})
            self.assertIn('内部买方',result['pool_irl','2026-11-18'][0])
            self.assertNotIn(('pool_erl','2026-11-18'),result)
            self.assertFalse(live_reviews(db,at+2*STEP,at+2*STEP,101,[],bars[:1],{}))

    def test_retest_uses_chart_bid_only_in_the_post_confirmation_window(self):
        at=datetime(2026,9,11,12,45,tzinfo=timezone.utc)
        ticks=[Tick(at-timedelta(milliseconds=1),100,101),Tick(at,99,100),
               Tick(at+STEP,100,101)]
        self.assertIsNone(quote_contact(ticks,99.5,100,at,at+STEP))
        self.assertEqual(quote_contact(ticks,99.5,100,at,at+2*STEP)['utc'],(at+STEP).isoformat())

    def test_sweep_transitions_only_after_the_confirming_bar_is_available(self):
        start=datetime(2026,11,18,8,tzinfo=NY)
        def candle(i,o,h,l,c):
            return Bar(start+i*STEP,o,h,l,c,0)
        prior=dict(status='complete',end=start-12*STEP,bars=[candle(-100,102,120,100,104)])
        before=[candle(i,104,105,102,103) for i in range(-6,0)]
        sweep=candle(0,103,104,98,102)
        impulse=candle(1,102,110,101,109)
        third=candle(2,109,113,107,111)
        watch=[]
        self.assertEqual(day_signals(start.date(),before+[sweep,impulse],prior,[],pending=watch),[])
        self.assertEqual(len(watch),1)
        watch=[]
        confirmed=day_signals(start.date(),before+[sweep,impulse,third],prior,[],pending=watch)
        self.assertEqual(watch,[])
        self.assertEqual([(e['known'],e['lo'],e['hi']) for e in confirmed],
                         [(third.time+STEP,104,107)])
        self.assertFalse(day_signals(start.date(),before+[sweep,candle(1,102,108,97,107),third],prior,[]))

    def test_live_targets_freeze_before_touch_and_survive_restart(self):
        at=datetime(2026,11,18,15,tzinfo=timezone.utc)
        target=dict(side=1,lo=102,hi=104,score=71,rank=1,source='M15 FVG',reason='距离 2')
        first=Bar(at-STEP,100,106,99,100,0)
        with tempfile.TemporaryDirectory() as folder:
            db=Path(folder)/'r.sqlite'
            receipt={batch_id(at,100,[target]):at}
            self.assertFalse(live_reviews(db,at,at,100,[target],[first],{}))
            self.assertFalse(live_reviews(db,at,at,100,[dict(target,score=2)],[first],receipt))
            later=Bar(at,100,103.5,99,103,0)
            result=live_reviews(db,at+STEP,at+STEP,103,[],[first,later],{})
            day=result['day','2026-11-18']
            self.assertEqual(len(day),1)
            self.assertIn('71分',day[0])
            self.assertIn('远端 期内未见',day[0])

    def test_only_complete_bars_after_chart_receipt_count(self):
        at=datetime(2026,11,18,15,tzinfo=timezone.utc)
        target=dict(side=1,lo=102,hi=102,score=62,rank=1,source='前高',reason='距离 2')
        first=Bar(at-STEP,100,101,99,100,0)
        straddles=Bar(at,100,106,99,100,0)
        after=Bar(at+STEP,100,103,99,101,0)
        received=at+timedelta(seconds=41)
        with tempfile.TemporaryDirectory() as folder:
            db=Path(folder)/'r.sqlite'
            key=batch_id(at,100,[target])
            receipt={key:received}
            self.assertFalse(live_reviews(db,at,at,100,[target],[first],{}))
            self.assertFalse(live_reviews(db,at+STEP,at+STEP,100,[],[first,straddles],{}))
            self.assertFalse(live_reviews(db,at+STEP,at+STEP,100,[],[first,straddles],receipt))
            result=live_reviews(db,at+2*STEP,at+2*STEP,101,[],[first,straddles,after],{})
            row=result['day','2026-11-18'][0]
            self.assertIn('10:00:41 图表收到',row)
            self.assertIn('10:10 M5 已见触达',row)

    def test_late_first_listing_can_qualify_on_a_later_publication(self):
        at=datetime(2026,11,18,12,tzinfo=timezone.utc)
        target=dict(side=1,lo=102,hi=102,score=51,rank=1,source='前高',reason='当时依据')
        bars=[Bar(at+i*STEP,100,101,99,100,0) for i in range(60)]
        bars[-1]=Bar(bars[-1].time,100,103,99,101,0)
        later=at+46*STEP
        with tempfile.TemporaryDirectory() as folder:
            db=Path(folder)/'r.sqlite'
            for t,score in [(at,51),(later,69)]:
                targets=[dict(target,score=score)]
                live_reviews(db,t,t,100,targets,[],{batch_id(t,100,targets):t})
            now=at+60*STEP
            summary=live_reviews(db,now,now,101,[],bars,{})
            day=summary['day','2026-11-18']
            self.assertEqual(len(day),1)
            self.assertIn('69分',day[0])
            self.assertNotIn('51分',day[0])
            self.assertIn('期限内',day[0])
            self.assertFalse(live_reviews(db,now,now,101,[],bars[:-1],{}))

    def test_dol_horizon_distinguishes_missing_tied_and_expired(self):
        at=datetime(2026,11,18,12,tzinfo=timezone.utc)
        bars=[Bar(at+i*STEP,100,101,99,100,0) for i in range(49)]
        bars[3]=Bar(bars[3].time,100,103,97,100,0)
        bars[-1]=Bar(bars[-1].time,100,104,99,100,0)
        snap=dict(at=at.isoformat(),targets=[
            dict(rank=i+1,score=71,side=side,lo=p,hi=p,source=str(p),reason='依据')
            for i,(side,p) in enumerate([(1,102),(-1,98),(1,104)])])
        end=bars[-1].time+STEP
        summaries,stats=settle([snap],bars,end)
        self.assertEqual(snap['first_touch_status'],'same_m5_bar')
        self.assertEqual(snap['first_ranks'],[1,2])
        self.assertEqual(snap['targets'][2]['horizon_status'],'observed_late')
        self.assertEqual(stats['70'],{'listed':3,'hit_within_horizon':2})
        self.assertEqual(len(summaries['day','2026-11-18']),2)
        opened_on_target=bars.copy()
        opened_on_target[3]=Bar(bars[3].time,102,103,97,100,0)
        settle([snap],opened_on_target,end)
        self.assertEqual((snap['first_touch_status'],snap['first_ranks']),('unique',[1]))
        _,stats=settle([snap],bars[1:],end)
        self.assertEqual((snap['first_touch_status'],snap['first_ranks'],stats),('insufficient_coverage',[],{}))
        settle([snap],bars,at+3*STEP)
        self.assertEqual(snap['first_touch_status'],'open')
        self.assertEqual(snap['targets'][0]['touches'],[None])

        snap['targets'][1].update(side=1,lo=102,hi=102)
        settle([snap],bars,end)
        self.assertEqual(snap['first_touch_status'],'same_level')
        friday=datetime(2026,11,20,16,55,tzinfo=NY)
        snap['at']=friday.isoformat()
        _,stats=settle([snap],[],friday+timedelta(days=1))
        self.assertEqual((snap['first_touch_status'],stats),('no_observation_window',{}))

    def test_receipt_log_requires_complete_record_and_retains_first_ack(self):
        at=datetime(2026,11,18,15,tzinfo=timezone.utc)
        key='a'*64
        with tempfile.TemporaryDirectory() as folder:
            file=Path(folder)/'2026.11.18.tsv'
            line=f'{key}\t{int(at.timestamp())}'
            file.write_bytes(line.encode())
            self.assertFalse(chart_receipts(file.parent,at))
            file.write_bytes((line+'\r\n'+f'{key}\t{int(at.timestamp())+2}\r\n').encode())
            self.assertEqual(chart_receipts(file.parent,at+STEP),{key:at})
