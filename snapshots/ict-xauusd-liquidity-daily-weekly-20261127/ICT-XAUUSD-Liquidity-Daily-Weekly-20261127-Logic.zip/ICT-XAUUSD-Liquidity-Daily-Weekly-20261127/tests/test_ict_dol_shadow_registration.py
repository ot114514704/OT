import contextlib
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from ict_ai.dol_history import _deadline, batch_id
from scripts import settle_ict_dol_shadow as shadow


class ShadowRegistrationTest(unittest.TestCase):
    def setUp(self):
        work = TemporaryDirectory()
        self.addCleanup(work.cleanup)
        self.root = Path(work.name)
        self.predictions = self.root / 'predictions'
        self.predictions.mkdir()
        lock = self.root / 'model.json'
        database = self.root / 'chart.sqlite3'
        at = datetime(2026, 11, 23, 14, tzinfo=timezone.utc)
        received = (at + timedelta(minutes=1)).isoformat()
        lock.write_text(json.dumps(dict(frozen_at=(at-timedelta(days=1)).isoformat(), code={})), encoding='utf-8')
        targets = [dict(rank=1, side=1, lo=4050.0, hi=4050.0, score=65)]
        identity = batch_id(at, 4040.0, [targets, []])
        sample = dict(at=at.isoformat(), price=4040.0, targets=targets, pools=[])
        with contextlib.closing(sqlite3.connect(database)) as db, db:
            db.execute('CREATE TABLE chart_batches(id,cutoff,received,payload)')
            db.execute('INSERT INTO chart_batches VALUES (?,?,?,?)',
                       (identity, at.isoformat(), received, json.dumps(sample)))
        self.selection = dict(chart_rank1=0, nearest_near_edge=0, learned_contact=0)
        self.row = dict(chart_batch=identity, cutoff=at.isoformat(), chart_received=received,
                        recorded_at=(at+timedelta(minutes=2)).isoformat(), end=_deadline(at).isoformat(),
                        model_sha256=shadow.archive.digest(lock), price=sample['price'], targets=targets,
                        selection=self.selection)
        paths = patch.multiple(shadow, FOLDER=self.root, LOCK=lock, DATABASE=database)
        paths.start()
        self.addCleanup(paths.stop)
        choice = patch.object(shadow, 'choose', return_value=self.selection)
        choice.start()
        self.addCleanup(choice.stop)

    def save(self, name='first.json'):
        (self.predictions/name).write_text(json.dumps(self.row), encoding='utf-8')

    def test_bound_receipt_is_accepted(self):
        self.save()
        records = shadow.read_registrations()
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]['published_at'],self.row['recorded_at'])

    def test_candidate_value_change_is_rejected_even_with_same_selection(self):
        self.row['targets'][0]['lo'] += .1
        self.save()
        with self.assertRaisesRegex(ValueError, 'candidates differ'):
            shadow.read_registrations()

    def test_duplicate_cutoff_is_not_counted_twice(self):
        self.save()
        self.save('duplicate.json')
        with self.assertRaisesRegex(ValueError, 'Invalid or altered'):
            shadow.read_registrations()
