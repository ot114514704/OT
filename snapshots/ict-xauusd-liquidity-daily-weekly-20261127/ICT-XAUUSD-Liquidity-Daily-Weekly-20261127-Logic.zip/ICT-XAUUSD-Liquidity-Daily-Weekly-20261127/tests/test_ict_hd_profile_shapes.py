import unittest
from datetime import date,datetime,timezone
from ict_ai.weekly_path import _profile_candidates
from ict_ai.profile_sources import profile_source
from ict_ai.range_liquidity import SOURCE_REFS


class HDProfileShapeTests(unittest.TestCase):
    def classify(self,prices,missing=None):
        days=[date(2026,10,d) for d in range(5,10)]
        daily=[dict(date=d.isoformat(),open=o,high=h,low=l,close=c,ended=True,
                    coverage_complete=i!=missing) for i,(d,(o,h,l,c)) in enumerate(zip(days,prices))]
        return _profile_candidates(daily,days,datetime(2026,10,10,tzinfo=timezone.utc))

    def test_tuesday_extreme_alone_is_insufficient(self):
        p=[(100,105,95,102),(102,104,90,99),(99,108,97,106),(106,114,104,112),(112,116,109,114)]
        self.assertEqual(self.classify(p)[0]['id'],'weekly_tuesday_extreme')
        p[1]=(102,104,90,94)  # lower low, no close back into Monday range
        self.assertNotIn('weekly_tuesday_extreme',[c.get('id') for c in self.classify(p)])

    def test_wednesday_subtypes_depend_on_tuesday_path(self):
        classic=[(100,105,95,102),(102,104,93,96),(96,106,90,100),(100,110,98,108),(108,115,104,112)]
        double=[(100,105,95,102),(102,110,96,108),(108,109,90,100),(100,114,98,112),(112,120,108,118)]
        self.assertEqual(self.classify(classic)[0]['id'],'weekly_wednesday_extreme')
        result=self.classify(double)[0]
        self.assertEqual(result['id'],'weekly_wednesday_double_sweep')
        self.assertEqual(result['hd_source']['frame_seconds'],1230)
        self.assertIn('事先周偏见',result['missing'])

    def test_thursday_sweep_and_friday_direct_expansion_are_different(self):
        early=[(100,104,96,102),(102,105,97,101),(101,104,96,100)]
        sweep=early+[(100,103,90,98),(98,112,97,110)]
        direct=early+[(100,103,97,101),(101,112,99,110)]
        self.assertEqual(self.classify(sweep)[0]['id'],'weekly_thursday_consolidation_reversal')
        self.assertEqual(self.classify(direct)[0]['id'],'weekly_consolidation_expansion')

    def test_original_fourth_figure_allows_thursday_outside_close(self):
        # Matches the timing of HD frame 1350, not purported market data:
        # Thursday still closes below the early range; Friday reverses it.
        early=[(100,104,96,102),(102,105,97,101),(101,104,96,100)]
        for side in (1,-1):
            prices=early+[(100,103,90,92),(92,112,91,110)]
            if side==-1:prices=[tuple(200-v for v in (o,l,h,c)) for o,h,l,c in prices]
            notes=self.classify(prices)
            fourth=next(c for c in notes if c.get('id')=='weekly_thursday_consolidation_reversal')
            self.assertTrue(fourth['thursday_closed_outside'])
            self.assertFalse(fourth['calendar_event_verified'])
            self.assertEqual(fourth['hd_source']['transcript_interval_seconds'],[1298,1378])
            self.assertIn('周四可收在范围外',fourth['reason'])

    def test_original_fifth_figure_can_start_expansion_on_thursday(self):
        prices=[(100,104,96,102),(102,105,97,101),(101,104,96,100),
                (100,112,97,110),(110,118,108,115)]
        fifth=next(c for c in self.classify(prices) if c.get('id')=='weekly_consolidation_expansion')
        self.assertEqual(fifth['variant'],'thursday_expansion_friday_followthrough')
        self.assertIn('周四已收盘突破',fifth['reason'])
        # Removing the pre-existing range invalidates that classification.
        trending=[(90,94,86,92),(100,104,96,102),(110,114,106,112),
                  (112,124,110,122),(122,128,120,126)]
        self.assertNotIn('weekly_consolidation_expansion',[c.get('id') for c in self.classify(trending)])

    def test_later_friday_extreme_invalidates_the_thursday_extreme_family(self):
        p=[(100,104,96,102),(102,105,97,101),(101,104,96,100),
           (100,103,90,92),(92,112,89,110)]
        self.assertNotIn('weekly_thursday_consolidation_reversal',[c.get('id') for c in self.classify(p)])

    def test_seek_destroy_requires_both_sides_and_repeated_turns(self):
        p=[(100,109,92,104),(104,108,90,96),(96,110,91,104),(104,109,92,96),(96,108,92,101)]
        self.assertEqual(self.classify(p)[0]['id'],'weekly_seek_destroy')
        p[-1]=(96,112,92,111)
        self.assertNotIn('weekly_seek_destroy',[c.get('id') for c in self.classify(p)])

    def test_midweek_reclaim_without_followthrough_is_explained_as_partial(self):
        # A Wednesday sweep/reclaim is useful evidence, but the source shape
        # still needs the later directional delivery. Keep the partial path
        # visible rather than relabelling it as a completed profile.
        p=[(100,105,95,102),(102,104,93,96),(96,106,90,100),
           (100,102,94,99),(99,103,95,98)]
        result=self.classify(p)
        self.assertEqual(result[0]['id'],'weekly_partial_reclaim')
        self.assertFalse(result[0]['path_complete'])
        self.assertIn('后续扩张不足',result[0]['profile'])

    def test_missing_coverage_blocks_closed_week_classification(self):
        p=[(100,105,95,102),(102,104,90,99),(99,108,97,106),(106,114,104,112),(112,116,109,114)]
        self.assertEqual(self.classify(p,missing=0)[0]['profile'],'周概况未归类')

    def test_sources_are_sampled_frames_not_full_video_training(self):
        source=profile_source('classic_reversal_variant')
        self.assertEqual(source['frame_seconds'],810)
        self.assertFalse(source['full_audio_review_complete'])
        self.assertEqual(source['author'],'交易员无畏')
        self.assertTrue(all(s.get('author')=='交易员无畏' and s['source'].endswith('.mp4') for s in SOURCE_REFS))


if __name__=='__main__':unittest.main()
