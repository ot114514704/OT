"""Synthetic adversarial fixtures, not measured market success or costs."""
from copy import deepcopy
from dataclasses import replace
from datetime import date, datetime, timedelta, timezone
import unittest

from brooks_ai.types import Bar, Instrument
from ict_ai.features import geometric_fvgs
from ict_ai.silver_planning import plan_digest, silver_research_plan, simulate_silver_plan
from ict_ai.timebase import NY


class SilverPlanningTests(unittest.TestCase):
    def setUp(self):
        self.start = datetime(2026, 10, 13, 10, tzinfo=NY).astimezone(timezone.utc)
        self.p = timedelta(minutes=5)
        self.prepared = self.start-self.p
        self.frozen = self.start-2*self.p
        self.spec = Instrument('XAUUSD', .01, .01, 100, .01, .01, 100,
                               commission_round_turn=7, slippage=.1,
                               verified=True, costs_verified=True)
        self.formation = [self.b(-4, 99, 100, 98, 99), self.b(-3, 99, 103, 99, 102),
                          self.b(-2, 102, 103, 101, 102)]
        self.pda = geometric_fvgs(self.formation, self.p, self.prepared)[0]
        self.pda.update(kind='geometric_fvg', timeframe='M5', source='synthetic fixture; not user market data')
        self.selection = {'id': 'synthetic-plan', 'side': 1, 'prepared_at': self.prepared.isoformat(),
                          'context_frozen_before': self.frozen.isoformat(), 'ny_date': '2026-10-13',
                          'window_id': 'ny_am', 'pda': self.pda, 'entry': 100.5,
                          'stop': {'price': 98, 'available_at': self.frozen.isoformat(), 'source': 'fixture low'}}
        narrative = {'profile_id': 'classic_buy_candidate', 'direction': 1,
                     'reason': 'Synthetic direction assertion for timing tests', 'provisional': True}
        self.context = {
            'htf_bias': {**self.sourced(1),'timeframe':'D1'},
            'htf_pda': self.sourced({'timeframe': 'H4', 'lower': 99, 'upper': 105}),
            'dol': self.sourced({'price': 106, 'timeframe': 'H1', 'reason': 'fixture prior high'}),
            'daily_narrative': self.sourced(narrative), 'weekly_narrative': self.sourced(narrative),
            'calendar_clear': self.sourced(True, self.prepared),
            'clock_verified': self.sourced(True, self.prepared)}

    def sourced(self, value, at=None):
        return {'value': deepcopy(value), 'available_at': (at or self.frozen).isoformat(),
                'source': 'synthetic assertion; not independently verified historical context'}

    def b(self, i, o, h, l, c, spread=.2):
        return Bar(self.start+i*self.p, o, h, l, c, spread)

    def plan(self, quotes=None, selection=None, context=None, spec=None, as_of=None, equity=10000):
        return silver_research_plan(selection or self.selection, self.context if context is None else context,
                                    self.formation, self.formation if quotes is None else quotes,
                                    as_of or self.prepared, spec or self.spec, equity)

    def simulate(self, plan, bars, as_of=None, spec=None, period=None):
        return simulate_silver_plan(plan, bars, spec or self.spec,
                                    as_of or bars[-1].time+self.p, period or self.p)

    def test_complete_fixture_freezes_context_and_cost_aware_risk(self):
        plan = self.plan()
        self.assertEqual(plan['status'], 'watch_for_silver_entry')
        self.assertEqual(plan['watch']['volume'], .09)
        self.assertAlmostEqual(plan['risk_estimate']['estimated_loss_cash'], 24.93)
        self.assertLessEqual(plan['risk_estimate']['estimated_loss_cash'], 25)
        self.assertEqual(plan['plan_sha256'], plan_digest(plan))
        self.context['dol']['value']['price'] = 200
        self.selection['entry'] = 120
        self.assertEqual(plan['context_used']['dol']['value']['price'], 106)
        self.assertEqual(plan['selection']['entry'], 100.5)
        self.assertFalse(plan['execution_allowed'])
        self.assertFalse(plan['demo_qualified'])

    def test_missing_future_or_contradicted_context_cannot_create_watch(self):
        plan = self.plan(context={})
        self.assertEqual(plan['status'], 'pending_context')
        self.assertIsNone(plan['watch'])

        future = deepcopy(self.context)
        future['dol']['available_at'] = self.start.isoformat()
        self.assertIsNone(self.plan(context=future)['watch'])
        conflict = deepcopy(self.context)
        conflict['htf_bias']['value'] = -1
        conflict['clock_verified']['value'] = False
        plan = self.plan(context=conflict)
        self.assertEqual(plan['status'], 'contradicted')
        self.assertIsNone(plan['watch'])

    def test_intraday_or_unspecified_bias_cannot_replace_daily_idea_basis(self):
        for timeframe in (None,'M5','M15','H1','H4'):
            context=deepcopy(self.context)
            context['htf_bias']['timeframe']=timeframe
            plan=self.plan(context=context)
            self.assertEqual(plan['status'],'pending_context')
            self.assertIn('bias_basis_at_least_D1',plan['missing'])
            self.assertIsNone(plan['watch'])
        self.assertEqual(self.plan()['status'],'watch_for_silver_entry')

    def test_quotes_after_preparation_do_not_change_the_watch(self):
        prefix = self.plan()
        future = self.formation+[self.b(-1, 102, 107, 99, 99), self.b(0, 99, 108, 97, 104)]
        self.assertEqual(prefix, self.plan(quotes=future))
        later = self.plan(quotes=future, as_of=self.start+2*self.p)
        self.assertEqual(prefix['watch'], later['watch'])
        self.assertEqual(prefix['context_used'], later['context_used'])

    def test_future_or_invented_pda_and_stop_do_not_create_watch(self):
        selection = deepcopy(self.selection)
        selection['pda']['available_at'] = self.start.isoformat()
        self.assertIsNone(self.plan(selection=selection)['watch'])
        selection = deepcopy(self.selection)
        selection['pda']['lower'] = 100.1
        selection['stop']['available_at'] = self.start.isoformat()
        plan = self.plan(selection=selection)
        self.assertIsNone(plan['watch'])
        self.assertIn('independently_confirmed_PDA_geometry', plan['missing'])

    def test_dol_reached_or_quote_gap_before_preparation_prevents_watch(self):
        quotes = deepcopy(self.formation)
        quotes[-1] = replace(quotes[-1], high=106)
        self.assertEqual(self.plan(quotes=quotes)['status'], 'contradicted')
        plan = self.plan(quotes=quotes[:-1])
        self.assertIsNone(plan['watch'])
        self.assertIn('continuous_DOL_quote_coverage', plan['missing'])

    def test_unverified_costs_min_volume_or_price_grid_prevents_watch(self):
        self.assertIsNone(self.plan(spec=replace(self.spec, costs_verified=False))['watch'])
        self.assertIsNone(self.plan(equity=100)['watch'])
        selection = deepcopy(self.selection)
        selection['entry'] = 100.505
        self.assertIsNone(self.plan(selection=selection)['watch'])

    def test_changed_plan_costs_or_quote_period_rejected(self):
        plan = self.plan()
        changed = deepcopy(plan); changed['watch']['target'] = 107
        with self.assertRaisesRegex(ValueError, 'Frozen plan changed'):
            self.simulate(changed, [], self.start)
        with self.assertRaisesRegex(ValueError, 'Instrument or costs changed'):
            self.simulate(plan, [], self.start, spec=replace(self.spec, commission_round_turn=8))
        with self.assertRaisesRegex(ValueError, 'Quote period changed'):
            self.simulate(plan, [], self.start, period=timedelta(minutes=15))

    def test_dol_and_pda_cancellation_while_staged_before_window(self):
        plan = self.plan()
        reached = [self.b(-1, 102, 106, 101, 105), self.b(0, 100.2, 101, 99, 100.6)]
        result = self.simulate(plan, reached)
        self.assertEqual(result['status'], 'cancelled_dol_before_entry')
        self.assertFalse(result['filled'])
        invalid = [self.b(-1, 102, 103, 99, 99.5), self.b(0, 100.2, 101, 99, 100.6)]
        self.assertEqual(self.simulate(plan, invalid)['status'], 'cancelled_pda_before_entry')

    def test_missing_staged_quotes_censors_later_apparent_fill(self):
        plan = self.plan()
        result = self.simulate(plan, [self.b(0, 100.2, 101, 99, 100.6)])
        self.assertEqual(result['status'], 'censored_pending_context_gap')
        self.assertIsNone(result['pnl_net'])

    def test_intrabar_dol_and_entry_order_is_unknown_but_open_fill_is_ordered(self):
        plan = self.plan()
        staged = self.b(-1, 102, 103, 101, 102)
        ambiguous = self.simulate(plan, [staged, self.b(0, 102, 107, 100, 105)])
        self.assertEqual(ambiguous['status'], 'censored_entry_dol_order')
        self.assertIsNone(ambiguous['filled'])
        self.assertIsNone(ambiguous['pnl_net'])
        open_fill = self.simulate(plan, [staged, self.b(0, 100.2, 107, 100, 106)])
        self.assertTrue(open_fill['filled'])
        self.assertEqual(open_fill['reason'], 'target')

    def test_active_fill_then_far_edge_close_is_not_retroactively_cancelled(self):
        plan = self.plan()
        bars = [self.b(-1, 102, 103, 101, 102), self.b(0, 100.2, 101, 97, 99)]
        result = self.simulate(plan, bars)
        self.assertTrue(result['filled'])
        self.assertEqual(result['reason'], 'stop')
        self.assertIsNotNone(result['pnl_net'])

    def test_every_closed_bar_prefix_hides_future_fill_and_outcome(self):
        plan = self.plan()
        bars = [self.b(-1, 102, 103, 101, 102), self.b(0, 102, 103, 101, 102),
                self.b(1, 100.2, 102, 100, 101), self.b(2, 101, 107, 100, 106)]
        for n, bar in enumerate(bars, 1):
            cutoff = bar.time+self.p
            self.assertEqual(self.simulate(plan, bars, cutoff), self.simulate(plan, bars[:n], cutoff))
        before = self.simulate(plan, bars, self.start+timedelta(minutes=9))
        self.assertFalse(before['filled'])
        self.assertTrue(self.simulate(plan, bars)['filled'])

    def test_window_expiry_has_no_post_window_entry(self):
        plan = self.plan()
        bars = [self.b(i, 102, 103, 101.2, 102) for i in range(-1, 12)]
        bars.append(self.b(12, 100.2, 101, 100, 100.6))
        result = self.simulate(plan, bars)
        self.assertFalse(result['filled'])
        self.assertEqual(result['orders_sent'], 0)


if __name__ == '__main__':
    unittest.main()
