from datetime import date,datetime,timedelta,timezone
import unittest

from brooks_ai.types import Bar
from ict_ai.structural_liquidity import (
    DURATION, EXTERNAL, anchor_clusters, external_bounds, grouped_extrema, micro_swing_span, structural_ranking,
)


class StructuralLiquidityTests(unittest.TestCase):
    def test_all_standard_periods_and_dst_month_open(self):
        self.assertEqual(len(DURATION)+len(EXTERNAL),17)
        self.assertEqual(min(DURATION.values()),5)
        self.assertEqual(DURATION['M12'],12)
        self.assertEqual(DURATION['H8'],480)
        start,finish=external_bounds(date(2026,3,12),'MN1')
        self.assertEqual(start.isoformat(),'2026-03-01T05:00:00+00:00')
        self.assertEqual(finish.isoformat(),'2026-04-01T04:00:00+00:00')

    def test_short_period_requires_actual_complete_minute_input(self):
        at=datetime(2026,8,13,14,4,tzinfo=timezone.utc)
        minute=timedelta(minutes=1)
        at=at.replace(minute=6)
        rows=[Bar(at-(6-i)*minute,99,101+i,98,99,0) for i in range(6)]
        parts,_=grouped_extrema(rows,minute,at,['M6'])['M6']
        self.assertEqual([p[2].high for p in parts],[106])
        parts,_=grouped_extrema([rows[0],*rows[2:]],minute,at,['M6'])['M6']
        self.assertIsNone(parts[0])

    def test_nearby_internal_levels_are_not_folded_into_erl(self):
        anchors={(1,101):{0:{('M15','摆动高'),('D1','日高')}},
                 (1,101.15):{1:{('M5','摆动高')}},
                 (1,101.33):{2:{('H1','摆动高')}}}
        self.assertEqual(list(anchor_clusters(anchors,1,.5)),
                         [('ERL',[101]),('IRL',[101.15,101.33])])

    def test_internal_swing_needs_two_closed_bars_on_both_sides(self):
        start = datetime(2026, 8, 13, 14, tzinfo=timezone.utc)
        step = timedelta(minutes=5)
        rows = [Bar(start+i*step, 99, high, 96, 99, 0)
                for i, high in enumerate((100, 101, 105, 100, 101, 102, 103, 100, 101, 104, 103))]
        self.assertEqual(micro_swing_span(rows[:4], 2, 105, 1), 0)
        self.assertEqual(micro_swing_span(rows[:5], 2, 105, 1), 5)
        self.assertEqual(micro_swing_span(rows, 2, 105, 1), 10)
        self.assertEqual(micro_swing_span([*rows[:3], *rows[4:]], 2, 105, 1), 0)
        self.assertEqual(micro_swing_span(rows, 2, 96, -1), 0)

    def test_micro_target_uses_named_range_and_keeps_outer_boundary_separate(self):
        start = datetime(2026, 8, 13, 4, tzinfo=timezone.utc)
        step = timedelta(minutes=5)
        highs = [107] + [101]*21 + [105, 100, 101, 103]
        rows = [Bar(start+i*step, 99, high, 95 if i == 0 else 96, 99, 0)
                for i, high in enumerate(highs)]
        at = rows[24].time + step
        dol = [
            dict(rank=1, side=1, lo=104, hi=104.5, distance=5, source='H1 FVG 剩余区',
                 score_components={'alignment': 30}),
            dict(rank=2, side=1, lo=105, hi=105, distance=6, source='M15 前高',
                 score_components={'alignment': 30}),
        ]
        provisional = structural_ranking(rows, at-step, dol)
        self.assertFalse(any(p['hi']==105 and p['classification']=='IRL' for p in provisional))
        confirmed = structural_ranking(rows, at, dol)
        target = next(p for p in confirmed if p['hi']==105 and p['classification']=='IRL')
        self.assertTrue(any(source.startswith('参照 D1 08-13') for source in target['sources']))
        self.assertTrue(any('待回补 FVG' in source for source in target['sources']))
        self.assertEqual(target['components']['context'], 6)
        self.assertEqual(target['dol_rank'], 2)
        self.assertFalse(any(p['hi']==107 and p['classification']=='IRL' for p in confirmed))


if __name__=='__main__':
    unittest.main()
