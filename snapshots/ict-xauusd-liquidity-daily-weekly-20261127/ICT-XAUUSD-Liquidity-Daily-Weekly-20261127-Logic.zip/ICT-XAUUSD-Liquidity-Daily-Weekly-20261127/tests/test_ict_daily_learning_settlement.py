from datetime import date, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from brooks_ai.types import Bar
from ict_ai.range_liquidity import _research_open
from scripts import settle_ict_daily_learning as settlement


class DailyLearningSettlementTest(unittest.TestCase):
    def setUp(self):
        self.day = date(2026, 11, 23)
        start, self.end = settlement.learning._day_bounds(self.day)
        self.at = settlement.registration.local_cutoff(self.day)
        self.reviewed_at = self.end + settlement.COVERAGE_GRACE
        bars = [Bar(stamp, 3600, 3601, 3599, 3600, 0)
                for i in range(int((self.end - start) / settlement.M5))
                if _research_open(stamp := start + i * settlement.M5)]
        self.prefix = [bar for bar in bars if bar.time < self.at]
        self.tail = [bar for bar in bars if bar.time >= self.at - settlement.M5]
        self.record = dict(cutoff=self.at.isoformat(), status='scores_recorded', candidates=[
            dict(profile='classic_buy', direction=1, learned_probability=.3, signed_family_prior=.6)])

    def test_both_probabilities_are_scored_against_the_same_closed_day(self):
        result = settlement.evaluate(self.record, self.prefix, self.tail, self.reviewed_at)
        self.assertEqual(result['status'], 'scored')
        self.assertEqual(result['candidate_results'][0]['matched'], 0)
        self.assertAlmostEqual(result['scores']['learned']['brier'], .09)
        self.assertAlmostEqual(result['scores']['signed_family_prior']['brier'], .36)

    def test_missing_future_bar_remains_unscored(self):
        result = settlement.evaluate(self.record, self.prefix, self.tail[:1] + self.tail[2:], self.reviewed_at)
        self.assertEqual(result['status'], 'insufficient_m5_coverage')
        self.assertIsNone(result['scores'])
        self.assertIsNone(result['actual_paths'])

    def test_no_candidate_is_an_abstention(self):
        record = dict(cutoff=self.at.isoformat(), status='no_candidate', candidates=[])
        result = settlement.evaluate(record, self.prefix, self.tail, self.reviewed_at)
        self.assertEqual(result['status'], 'no_candidate')
        self.assertIsNone(result['scores'])
        self.assertIsNotNone(result['actual_paths'])

    def test_rejects_early_outcome_mismatched_anchor_and_next_day_bar(self):
        for tail, captured in [(self.tail, self.end), (self.tail[1:], self.reviewed_at),
                               (self.tail + [Bar(self.end, 3600, 3601, 3599, 3600, 0)], self.reviewed_at)]:
            with self.subTest(last=tail[-1].time, first=tail[0].time, captured=captured):
                with self.assertRaises(ValueError):
                    settlement.evaluate(self.record, self.prefix, tail, captured)

    def test_early_checkpoints_settle_replay_and_remain_separate(self):
        bars = self.prefix + self.tail[1:]
        with TemporaryDirectory() as directory:
            folder = Path(directory)
            for name,minutes,probability in [('0730',150,.2),('0830',90,.4)]:
                cutoff = self.at-timedelta(minutes=minutes)
                path = folder/f'{self.day}_{name}.json'
                record = dict(cutoff=cutoff.isoformat(),forecast_end=self.end.isoformat(),status='scores_recorded',
                              candidates=[dict(profile='classic_buy',direction=1,pooled_probability=probability,
                                               signed_family_prior=.6)])
                settlement.atomic_json(path,record)
                settlement.archive.write_zip(path.with_name(f'{path.stem}-M5.json.gz'),
                    settlement.encode_bars([b for b in bars if b.time < cutoff]))

            def fetch(start,end):
                return [b for b in bars if start <= b.time < end],self.reviewed_at

            model = dict(server='fixture')
            settled = []
            with patch.object(settlement.intraday,'FOLDER',folder),patch.object(settlement.intraday,'verify',return_value=2):
                pending = settlement.settle_due(model,fetch,self.end,settled,{},early=True)
                self.assertEqual(set(pending.values()),{'waiting_for_day_end'})
                self.assertFalse(settlement.settle_due(model,fetch,self.reviewed_at,settled,{},early=True))
                self.assertEqual(settlement.verify(model,early=True),(2,settled))
                self.assertFalse(settlement.settle_due(model,fetch,self.reviewed_at,settled,{},early=True))

            counts = settlement.summary(settled,True)['checkpoints']
            self.assertEqual([counts[name]['settled'] for name in ('07:30','08:30','09:30')],[1,1,0])
            self.assertAlmostEqual(counts['07:30']['rule_check']['learned']['brier'],.04)
            self.assertAlmostEqual(counts['08:30']['rule_check']['learned']['brier'],.16)
