from unittest import TestCase

from ict_ai.liquidity_repo_overlay import compare_shortlists


def level(side, edge):
    return dict(side=side, lo=edge, hi=edge)


class RepoOverlayTests(TestCase):
    def test_duplicate_and_farther_levels_keep_local_priority(self):
        first, second = level(1, 106), level(-1, 98)
        result = compare_shortlists([first, second], [first, level(1, 109)], 100)
        self.assertIsNone(result['extra'])
        self.assertEqual(result['fixed_two'], [first, second])

    def test_inside_level_can_supplement_or_replace_second(self):
        first, second = level(1, 106), level(-1, 96)
        supplement = level(1, 105)
        result = compare_shortlists([first, second], [supplement], 100)
        self.assertEqual(result['supplement'], [first, second, supplement])
        self.assertEqual(result['fixed_two'], [first, second])
        closer = level(1, 103)
        self.assertEqual(compare_shortlists([first, second], [closer], 100)['fixed_two'], [first, closer])

    def test_uncovered_side_rejects_on_or_behind_price(self):
        first, second = level(1, 106), level(1, 108)
        below = level(-1, 97)
        self.assertEqual(compare_shortlists([first, second], [level(-1, 100), below], 100)['extra'], below)
        self.assertEqual(compare_shortlists([first], [below], 100)['fixed_two'], [first, below])
