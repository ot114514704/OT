import unittest
from dataclasses import replace
from datetime import date, datetime, timedelta, timezone

from brooks_ai.types import Bar, Instrument, utc_time
from ict_ai.backtest import LimitStudyOrder
from ict_ai.silver_execution import silver_fvg_visits, simulate_silver_limit
from ict_ai.timebase import NY


class SilverExecutionTests(unittest.TestCase):
    def setUp(self):
        self.day = date(2026,10,13)
        self.start = datetime(2026,10,13,10,tzinfo=NY).astimezone(timezone.utc)
        self.p = timedelta(minutes=5)
        self.spec = Instrument('XAUUSD',.01,.01,100,.01,.01,100,commission_round_turn=7,slippage=.1)
        self.order = LimitStudyOrder('fixture',1,self.start-self.p,self.start+timedelta(hours=2),100,98,104,.1)

    def b(self,i,o,h,l,c,spread=.2):
        return Bar(self.start+i*self.p,o,h,l,c,spread)

    def run_order(self,bars,as_of=None,order=None):
        return simulate_silver_limit(order or self.order,self.start-2*self.p,bars,self.spec,
                                     as_of or bars[-1].time+self.p,self.day,'ny_am')

    def fvg_bars(self):
        # Third candle closes at 09:55 NY: FVG [100,101] is already known.
        return [self.b(-4,99,100,98,99), self.b(-3,99,103,99,102),
                self.b(-2,102,103,101,102), self.b(-1,102,103,100.5,102),
                self.b(0,102,103,100.5,102), self.b(1,102,103,100.4,102)]

    def test_prior_pda_order_waits_until_window_start(self):
        bars=[self.b(-1,99.5,101,99,100),self.b(0,99.5,101,99,100)]
        before=self.run_order(bars,self.start)
        self.assertFalse(before['filled'])
        result=self.run_order(bars)
        self.assertEqual(result['entry_bar_open'],self.start.isoformat())
        self.assertTrue(result['silver']['whole_entry_interval_in_window'])

    def test_last_bar_fill_known_at_end_is_inside_but_end_bar_is_not(self):
        bars=[self.b(i,102,103,101,102) for i in range(11)]
        bars += [self.b(11,99.5,101,99,100)]
        result=self.run_order(bars)
        self.assertTrue(result['filled'])
        self.assertEqual(result['entry_known_at'],(self.start+timedelta(hours=1)).isoformat())
        no_touch=[self.b(i,102,103,101,102) for i in range(12)]+[self.b(12,99.5,101,99,100)]
        self.assertFalse(self.run_order(no_touch)['filled'])

    def test_after_window_exit_keeps_costs_and_position(self):
        bars=[self.b(0,99.5,101,99,100)]+[self.b(i,100,101,99,100) for i in range(1,12)]
        bars += [self.b(12,101,105,100,104)]
        result=self.run_order(bars)
        self.assertEqual(result['reason'],'target')
        self.assertAlmostEqual(result['pnl_net'],42.3)
        self.assertFalse(result['source_costs_verified'])

    def test_future_pda_and_intrabar_activation_rejected(self):
        with self.assertRaises(ValueError):
            simulate_silver_limit(self.order,self.start,[],self.spec,self.start,self.day,'ny_am')
        with self.assertRaises(ValueError):
            self.run_order([],self.start+timedelta(hours=1),replace(self.order,available_at=self.start+timedelta(minutes=2)))

    def test_missing_quotes_do_not_become_successful_window_fill(self):
        result=self.run_order([self.b(1,99.5,101,99,100)])
        self.assertEqual(result['status'],'censored_pending_quote_gap')
        self.assertIsNone(result['silver']['whole_entry_interval_in_window'])

    def test_fill_is_hidden_until_bar_closes_and_future_does_not_change_it(self):
        bars=[self.b(0,99.5,101,99,100),self.b(1,100,105,99,104)]
        self.assertFalse(self.run_order(bars,self.start+timedelta(minutes=4))['filled'])
        self.assertEqual(self.run_order(bars,self.start+self.p),self.run_order(bars[:1]))

    def test_used_pda_can_reappear_and_visits_are_not_orders(self):
        bars=self.fvg_bars();events=silver_fvg_visits(bars,self.p,bars[-1].time+self.p)
        self.assertEqual(len(events),1)
        event=events[0]
        self.assertEqual(event['prior_observed_touch_bars'],1)
        self.assertTrue(event['pda_confirmed_before_window'])
        self.assertIsNone(event['exact_trigger_time'])
        self.assertFalse(event['signal_qualified'])
        self.assertEqual(event['available_at'],(self.start+self.p).isoformat())

    def test_formation_candle_cannot_touch_its_own_new_zone(self):
        bars=self.fvg_bars()[:3]
        # Shift formation close inside Silver; first touch is still later.
        bars=[replace(b,time=b.time+3*self.p) for b in bars]
        self.assertEqual(silver_fvg_visits(bars,self.p,bars[-1].time+self.p),[])

    def test_gap_and_same_bar_close_invalidation_remain_explicit(self):
        bars=self.fvg_bars()[:3]+[self.b(1,102,103,99,99.5)]
        event=silver_fvg_visits(bars,self.p,bars[-1].time+self.p)[0]
        self.assertFalse(event['continuous_quotes_since_confirmation'])
        self.assertTrue(event['far_edge_close_on_visit_bar'])
        bars += [self.b(2,101,102,100,101)]
        self.assertEqual(len(silver_fvg_visits(bars,self.p,bars[-1].time+self.p)),1)

    def test_prior_close_invalidated_zone_is_not_revived(self):
        bars=self.fvg_bars()[:3]+[self.b(-1,102,103,99,99.5),self.b(0,101,102,100,101)]
        self.assertEqual(silver_fvg_visits(bars,self.p,bars[-1].time+self.p),[])

    def test_partial_window_overlap_not_exactly_in_window(self):
        bars=self.fvg_bars()
        bars=[replace(b,time=b.time-timedelta(minutes=2)) for b in bars]
        event=silver_fvg_visits(bars,self.p,bars[-1].time+self.p)[0]
        self.assertFalse(event['whole_bar_inside_window'])
        self.assertEqual(event['timing_status'],'ambiguous_window_boundary')

    def test_observation_prefixes_are_stable(self):
        bars=self.fvg_bars()
        all_events=silver_fvg_visits(bars,self.p,bars[-1].time+self.p)
        for n,b in enumerate(bars,1):
            cutoff=b.time+self.p
            expected=[e for e in all_events if utc_time(e['available_at'])<=cutoff]
            self.assertEqual(silver_fvg_visits(bars,self.p,cutoff),expected)
            self.assertEqual(silver_fvg_visits(bars[:n],self.p,cutoff),expected)


if __name__=='__main__':unittest.main()
