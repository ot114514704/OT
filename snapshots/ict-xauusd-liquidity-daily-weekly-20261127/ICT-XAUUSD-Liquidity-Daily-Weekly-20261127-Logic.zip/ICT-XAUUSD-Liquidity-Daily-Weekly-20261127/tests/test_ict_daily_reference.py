"""Synthetic fixtures verify actual-source tail handling, not trading accuracy."""
from dataclasses import replace
from datetime import date, datetime, time, timedelta, timezone
import unittest

from brooks_ai.types import Bar
from ict_ai.profile_lifecycle import daily_profile_lifecycle
from ict_ai.timebase import NY
from scripts.prepare_ict_week import aggregate_bars


class DailyReferenceTests(unittest.TestCase):
    def setUp(self):
        self.day=date(2026,10,9)
        self.start=datetime.combine(self.day,time(),NY).astimezone(timezone.utc)
        self.end=self.start+timedelta(hours=17)
        self.p5=timedelta(minutes=5)

    def classic(self):
        origin=self.start-timedelta(hours=4)
        rows=[]
        for i in range(int((self.end-self.p5-origin)/self.p5)):
            at=origin+i*self.p5
            b=Bar(at,100,101,99,100,.2)
            if self.start+timedelta(hours=2)<=at<self.start+timedelta(hours=3):b=replace(b,low=98)
            if self.start+timedelta(hours=4,minutes=45)<=at<self.start+timedelta(hours=5):b=replace(b,high=102,close=101)
            if at>=self.start+timedelta(hours=7):b=replace(b,open=103,high=104,low=102.5,close=103)
            rows.append(b)
        return rows

    def classify(self,rows,at=None,m15=None):
        if m15 is None:m15=aggregate_bars(rows,5,15,self.end)
        return daily_profile_lifecycle(m15,self.day,at or self.end,reference_m5=rows)

    def card(self,result,ident='classic_buy'):
        return next(c for c in result['candidates'] if c['id']==ident)

    def test_friday_real_m5_tail_confirms_without_creating_a_partial_m15(self):
        rows=self.classic();m15=aggregate_bars(rows,5,15,self.end)
        self.assertEqual(m15[-1].time+timedelta(minutes=15),self.end-timedelta(minutes=15))
        got=self.classify(rows)
        self.assertTrue(self.card(got)['path_matched'])
        self.assertTrue(got['coverage_complete_under_study_calendar'])
        self.assertEqual(got['daily_price_basis']['unaggregated_closed_m5'],2)
        self.assertEqual(got['daily_price_basis']['last_close_at'],(self.end-self.p5).isoformat())
        self.assertFalse(got['daily_price_basis']['partial_analysis_bars_created'])
        self.assertIn('103.00',got['profile_reason'])
        self.assertEqual(daily_profile_lifecycle(m15,self.day,self.end)['actual_paths'],[])
        self.assertEqual(self.classify(rows,self.end-self.p5)['actual_paths'],[])

    def test_last_m5_close_can_remove_the_full_day_match(self):
        rows=self.classic();rows[-1]=replace(rows[-1],low=99,close=100)
        got=self.classify(rows)
        self.assertTrue(got['coverage_complete_under_study_calendar'])
        self.assertFalse(self.card(got)['path_matched'])
        self.assertEqual(got['daily_price_basis']['close'],100)

    def test_last_m5_wick_invalidates_an_earlier_extreme(self):
        rows=self.classic();rows[-1]=replace(rows[-1],low=97)
        got=self.classify(rows)
        self.assertEqual(self.card(got)['status'],'invalidated')
        self.assertEqual(got['daily_price_basis']['low'],97)
        self.assertEqual(got['actual_paths'],[])

    def test_m5_gap_or_missing_analysis_bar_still_blocks_confirmation(self):
        rows=self.classic();m15=aggregate_bars(rows,5,15,self.end)
        for missing in (self.start,self.start+timedelta(hours=11),self.end-2*self.p5):
            result=self.classify([b for b in rows if b.time!=missing])
            self.assertFalse(result['coverage_complete_under_study_calendar'])
            self.assertEqual(result['actual_paths'],[])
        incomplete=[b for b in m15 if b.time!=self.start+timedelta(hours=11)]
        got=self.classify(rows,m15=incomplete)
        self.assertTrue(got['daily_price_basis']['source_coverage_complete'])
        self.assertFalse(got['daily_price_basis']['analysis_coverage_complete'])
        self.assertEqual(got['actual_paths'],[])

    def test_conflicting_source_cannot_certify_analysis(self):
        rows=self.classic();m15=aggregate_bars(rows,5,15,self.end)
        at=self.start+timedelta(hours=3)
        m15=[replace(b,high=b.high+1) if b.time==at else b for b in m15]
        got=self.classify(rows,m15=m15)
        self.assertFalse(got['daily_price_basis']['aggregate_matches_source'])
        self.assertEqual(got['actual_paths'],[])
        self.assertIn('不一致',got['profile_reason'])

    def test_a_quote_after_assumed_close_requires_calendar_review(self):
        rows=self.classic();rows.append(replace(rows[-1],time=self.end-self.p5))
        got=self.classify(rows)
        self.assertTrue(got['daily_price_basis']['study_calendar_contradicted'])
        self.assertEqual(got['actual_paths'],[])
        self.assertIn('交易日历',got['profile_reason'])

    def test_future_m5_tail_cannot_rewrite_earlier_hypotheses(self):
        rows=self.classic();m15=aggregate_bars(rows,5,15,self.end)
        for at in (self.start+timedelta(hours=7),self.end-timedelta(minutes=15),self.end-timedelta(minutes=6)):
            got=self.classify(rows,at,m15)
            prefix5=[b for b in rows if b.time+self.p5<=at]
            prefix15=[b for b in m15 if b.time+timedelta(minutes=15)<=at]
            self.assertEqual(got,self.classify(prefix5,at,prefix15))
            poison=[replace(b,high=9999,low=1) if b.time+self.p5>at else b for b in rows]
            self.assertEqual(got,self.classify(poison,at,m15))
        changed=rows[:-1]+[replace(rows[-1],low=1,close=100)]
        self.assertEqual(self.classify(rows)['earlier_hypotheses'],self.classify(changed)['earlier_hypotheses'])

    def test_reclaim_extreme_freezes_at_m15_close_not_first_m5_open(self):
        rows=[]
        for b in self.classic():
            at=b.time
            b=replace(b,open=100,high=101,low=99,close=100)
            if at==self.start+timedelta(hours=7,minutes=10):b=replace(b,low=97)
            if at>=self.start+timedelta(hours=7,minutes=15):b=replace(b,open=103,high=104,low=102,close=103)
            rows.append(b)
        got=self.classify(rows)
        self.assertTrue(self.card(got,'classic_reversal_variant')['path_matched'])

    def mec(self):
        rows=[]
        for b in self.classic():
            b=replace(b,open=100,high=101,low=99,close=100)
            if b.time==self.start+timedelta(hours=2):b=replace(b,low=97)
            if self.start+timedelta(hours=3)<=b.time<self.start+timedelta(hours=5):b=replace(b,open=102,high=110,low=98,close=103)
            rows.append(b)
        return rows

    def test_mec_tail_checks_both_containment_and_final_net_body(self):
        rows=self.mec();ident='manipulation_expansion_consolidation'
        self.assertTrue(self.card(self.classify(rows),ident)['path_matched'])
        for tail in (replace(rows[-1],high=111),replace(rows[-1],high=109,close=108)):
            changed=rows[:-1]+[tail]
            self.assertFalse(self.card(self.classify(changed),ident)['path_matched'])

    def test_friday_close_uses_ny_timezone_after_dst_change(self):
        old=self.start
        self.day=date(2026,11,6)
        self.start=datetime.combine(self.day,time(),NY).astimezone(timezone.utc)
        self.end=self.start+timedelta(hours=17)
        self.assertEqual(self.start.hour,old.hour+1)
        got=self.classify(self.classic())
        self.assertTrue(self.card(got)['path_matched'])
        self.assertEqual(datetime.fromisoformat(got['daily_price_basis']['last_close_at']).astimezone(NY).strftime('%H:%M'),'16:55')


if __name__=='__main__':unittest.main()
