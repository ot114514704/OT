import csv
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from scripts.audit_ict_price_video_replay import run


class PriceReplayClockTests(unittest.TestCase):
    def sources(self,root):
        result=[]
        for symbol in ('XAUUSD','XAGUSD'):
            data=root/(symbol+'.csv')
            with data.open('w',newline='') as f:
                writer=csv.writer(f);writer.writerow(['time','open','high','low','close','spread'])
                for day in ('2026-10-30','2026-11-09'):
                    for minute in range(0,60,5):
                        writer.writerow([f'{day}T12:{minute:02d}:00Z',100,101,99,100,.1])
            meta={'symbol':symbol,'server':'test','synthetic':False,'volatile_live_snapshot':False,
                  'finished_at_utc':'2026-11-10T00:00:00Z','source_clock_offset_hours':2,
                  'source_clock_segments':[
                      {'raw_until':'2026-11-01T00:00:00+00:00','offset_hours':3},
                      {'raw_from':'2026-11-01T00:00:00+00:00','offset_hours':2}],
                  'datasets':[{'timeframe':'M5','data_path':str(data),'data_sha256':hashlib.sha256(data.read_bytes()).hexdigest()}]}
            manifest=root/(symbol+'.json');manifest.write_text(json.dumps(meta))
            result.append(manifest)
        return result

    def test_paired_replay_binds_interval_policy_and_checks_real_inputs(self):
        with TemporaryDirectory() as folder,patch('builtins.print'):
            root=Path(folder);a,b=self.sources(root)
            report=run(a,b,root/'report.json')
            self.assertEqual(report['source_clock_offset_hours'],2)
            self.assertEqual(len(report['source_clock_segments']),2)
            self.assertEqual(report['periods']['5']['closed_primary_bars'],24)
            self.assertEqual(report['prefixes_checked'],34)
            self.assertEqual(report['orders_sent'],0)

    def test_same_latest_offset_does_not_hide_different_historical_mapping(self):
        with TemporaryDirectory() as folder:
            root=Path(folder);a,b=self.sources(root)
            meta=json.loads(b.read_text());meta['source_clock_segments']=[]
            b.write_text(json.dumps(meta))
            with self.assertRaisesRegex(ValueError,'clock mapping mismatch'):
                run(a,b,root/'report.json')
            self.assertFalse((root/'report.json').exists())
