from datetime import datetime, timedelta, timezone
from unittest import TestCase

import numpy as np

from brooks_ai.types import Bar
from scripts.backtest_ict_liquidity_account import M5, observed_reclaim, settle_signal, time_ms


class LiquidityAccountTests(TestCase):
    def setUp(self):
        self.start = datetime(2026, 11, 24, 12, tzinfo=timezone.utc)
        self.end = self.start + 4 * M5

    def candle(self, i, high, low, close):
        return Bar(self.start + i * M5, close, high, low, close, 0)

    def replay(self, side, target, prices, slip=.10, fee=.07, **constraints):
        row = dict(signal_at=(self.start + M5).isoformat(), deadline=(self.start + 3 * M5).isoformat(),
                   direction=side, limit=target, **constraints)
        stamps = np.array([time_ms(self.start) + seconds * 1000 for seconds, _, _ in prices])
        bids = np.array([bid for _, bid, _ in prices])
        asks = np.array([ask for _, _, ask in prices])
        return settle_signal(row, (stamps, bids, asks), self.end, slip, fee, 1)

    def test_sweep_requires_witness_and_reclaim_within_four_candles(self):
        pool = dict(side=1, lo=98, hi=100)
        exact = self.candle(0, 100, 99, 99)
        cross = self.candle(0, 103, 98, 101)
        holds = [self.candle(i, 103, 100, 101) for i in (1, 2, 3)]
        self.assertIsNone(observed_reclaim(pool, [exact]))
        self.assertIsNone(observed_reclaim(pool, [self.candle(0, 103, 101, 102)]))
        self.assertIsNone(observed_reclaim(pool, [cross, *holds, self.candle(4, 101, 99, 99)]))
        self.assertIsNone(observed_reclaim(pool, [cross, self.candle(2, 101, 99, 99)]))
        # The recorded production reclaim crosses the far edge, even inside the zone.
        self.assertEqual(observed_reclaim(pool, [cross, *holds[:2], self.candle(3, 101, 99, 99)]),
                         (self.start + M5, self.start + 4 * M5))

    def test_long_stop_is_set_from_ask_fill_and_gaps_are_charged(self):
        status, (trade, _) = self.replay(1, 115, [(299, 140, 140.2), (300, 100, 100.2), (301, 78, 78.2)])
        self.assertEqual(status, 'settled')
        self.assertEqual((trade['entry'], trade['stop'], trade['exit'], trade['net_usd']), (100.3, 80.3, 77.9, -22.47))
        self.assertEqual(trade['entry_at_ms'], time_ms(self.start + M5))

    def test_short_target_requires_ask_and_books_no_assumed_improvement(self):
        status, (trade, _) = self.replay(-1, 90, [(300, 100, 100.2), (301, 89.9, 90.1), (302, 89.7, 89.9)])
        self.assertEqual(status, 'settled')
        self.assertEqual(trade['exit_at_ms'], time_ms(self.start) + 302000)
        self.assertEqual((trade['exit_reason'], trade['exit'], trade['net_usd']), ('opposite_liquidity', 90, 9.83))

    def test_time_exit_uses_first_quote_at_or_after_deadline(self):
        _, (trade, _) = self.replay(1, 120, [(300, 100, 100.2), (899, 102, 102.2), (901, 103, 103.2)])
        self.assertEqual((trade['exit_reason'], trade['exit_at_ms'], trade['exit']),
                         ('time_exit', time_ms(self.start) + 901000, 102.9))

    def test_execution_is_strictly_inside_window_and_stop_protects_structure(self):
        quotes = [(300, 100, 100.2), (901, 103, 103.2)]
        status, trade = self.replay(1, 115, quotes, entry_before_ms=time_ms(self.start + M5))
        self.assertEqual((status, trade), ('entry_after_time_window', None))
        status, trade = self.replay(1, 115, quotes, protected_extreme=80.30)
        self.assertEqual((status, trade), ('fixed_stop_inside_protected_structure', None))
        status, _ = self.replay(1, 115, quotes, protected_extreme=80.31)
        self.assertEqual(status, 'settled')
