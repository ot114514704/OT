from datetime import date, timedelta
from unittest import TestCase

from brooks_ai.types import Bar
from ict_ai.profile_lifecycle import _day_bounds
from ict_ai.profile_timeline import (
    M5, QuoteSeries, availability, checkpoint_rows, daily_timeline, developments, midweek_range_watch,
)


class ProfileTimelineTests(TestCase):
    def setUp(self):
        self.day = date(2026, 6, 5)
        self.start, self.end = _day_bounds(self.day)

    def test_last_m15_is_used_until_the_friday_clock_reaches_close(self):
        last = self.end-M5
        live = checkpoint_rows([],self.start,self.end,last,last)
        self.assertEqual(live,[(self.end-timedelta(minutes=15),'最新已收 M15')])
        closed = checkpoint_rows([],self.start,self.end,self.end,last)
        self.assertEqual(closed,[(self.end,'收盘核验')])

    def test_missing_first_quote_uses_the_research_calendar(self):
        self.assertEqual(availability([],self.end-3*M5,self.end),
                         {'expected_m5':2,'missing_m5':2,'first_missing_m5':(self.end-3*M5).isoformat()})

    def test_missing_coverage_cannot_remove_a_candidate(self):
        card = dict(id='classic',direction=1,state='active',label='经典反转')
        seen = dict(covered=True,cards=[card])
        incomplete = dict(covered=False,cards=[])
        complete = dict(covered=True,cards=[])
        self.assertEqual(developments(seen,incomplete),[])
        self.assertEqual(developments(seen,complete)[0]['state'],'no_longer_listed')
        retired = dict(covered=True,cards=[dict(card,state='invalidated')])
        self.assertEqual(developments(seen,retired)[0]['state'],'invalidated')

    def test_later_quotes_do_not_change_an_earlier_timeline(self):
        at = self.start+timedelta(hours=5)
        a = Bar(at-3*M5,100,101,99,100,0)
        future = Bar(at,100,115,98,115,0)
        short = daily_timeline(QuoteSeries([a]),QuoteSeries([a]),self.day,at,at)
        full = daily_timeline(QuoteSeries([a,future]),QuoteSeries([a,future]),self.day,at,at)
        self.assertEqual(short,full)
        self.assertEqual(full[-1]['title'],'伦敦窗结束')

    def test_midweek_range_requires_three_complete_days_and_stays_frozen(self):
        days = [self.day-timedelta(days=4-i) for i in range(5)]
        known = _day_bounds(days[2])[1]
        first = [dict(date=day.isoformat(),ended=True,coverage_complete=True,high=105+i,low=100+i)
                 for i,day in enumerate(days[:3])]
        self.assertIsNone(midweek_range_watch(dict(daily=first),days,known-M5))
        self.assertIsNone(midweek_range_watch(dict(daily=first[1:]),days,known))
        self.assertIsNone(midweek_range_watch(dict(daily=[*first[:2],dict(first[2],coverage_complete=False)]),days,known))
        watch = midweek_range_watch(dict(daily=first),days,known)
        later = [*first,dict(date=days[3].isoformat(),high=200,low=50,ended=True,coverage_complete=True)]
        self.assertEqual(watch,midweek_range_watch(dict(daily=later),days,known+timedelta(days=1)))
        self.assertEqual((watch['range_low'],watch['range_high']),(100,107))
