import unittest

from ict_ai.profile_alignment import align_candidates


class ProfileAlignmentTests(unittest.TestCase):
    def test_missing_mixed_and_neutral_directions_remain_explicit(self):
        day = {'candidates':[dict(id='daily-up', label='up', direction=1, observed_sequence=True,status='active'),
                            dict(id='neutral', label='neutral', direction=None, observed_sequence=True,status='active'),
                            dict(id='retired', label='retired', direction=-1, observed_sequence=True,status='invalidated')]}
        for covered,weekly_directions,expected in ((False,[1],'weekly_coverage_unknown'),
                (True,[1],'aligned'),(True,[-1],'opposed'),(True,[1,-1],'mixed_week'),
                (True,[None],'no_directional_week_candidate')):
            week = dict(covered=covered,active=[dict(direction=side) for side in weekly_directions])
            result = align_candidates(day,week)
            self.assertEqual([(c['id'],c['comparison']) for c in result],[('daily-up',expected),('neutral','daily_neutral')])
