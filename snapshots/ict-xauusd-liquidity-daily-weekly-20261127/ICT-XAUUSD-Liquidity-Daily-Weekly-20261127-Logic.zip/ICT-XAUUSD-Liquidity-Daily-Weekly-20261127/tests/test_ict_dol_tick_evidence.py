from datetime import datetime, timedelta, timezone
import unittest

from brooks_ai.types import Bar
from ict_ai.dol_tick_evidence import BidEvidence, M5, utc_ms
from scripts.settle_ict_dol_shadow import bid_results


class DolBidEvidenceTest(unittest.TestCase):
    def setUp(self):
        self.start = datetime(2026, 11, 23, 13, tzinfo=timezone.utc)
        self.end = self.start + M5
        self.stamp = utc_ms(self.start)

    def evidence(self, quote_offsets, bar=None):
        bid = [p for _,p in quote_offsets]
        if bar is None:
            bar = Bar(self.start,bid[0],max(bid),min(bid),bid[-1],0)
        return BidEvidence([bar],[(self.stamp+t,p) for t,p in quote_offsets])

    def record(self, levels, offset=6000, duration=M5):
        return dict(cutoff=self.start.isoformat(), end=(self.start+duration).isoformat(), evidence='test',
                    recorded_at=(self.start+timedelta(milliseconds=offset)).isoformat(),
                    targets=[dict(rank=i,side=1,lo=lo,hi=hi) for i,(lo,hi) in enumerate(levels,1)],
                    selection=dict(chart_rank1=0, nearest_near_edge=1, learned_contact=2))

    def test_does_not_treat_gap_over_point_as_contact_or_retire_late_again(self):
        evidence = self.evidence([(0,100),(5000,102),(10000,100),(12000,104),(20000,102)])
        row = self.record([(102,102),(103,103),(103.5,104.5)])
        outcome = evidence.replay(row,self.end)
        self.assertEqual(outcome['status'],'unique')
        self.assertEqual(outcome['first_ranks'],[3])
        self.assertFalse(outcome['contacts'][1]['eligible'])
        self.assertNotIn(2,outcome['contacts'])
        report = bid_results([row],evidence,self.end)
        self.assertFalse(report['cutoffs'][0]['comparable'])
        self.assertEqual(dict(report['comparisons']),{})

    def test_equal_millisecond_and_shared_boundaries_stay_separate(self):
        evidence = self.evidence([(0,100),(15000,105),(15000,106),(20000,103)])
        row = self.record([(105,105),(105,105),(106,106)])
        self.assertEqual(evidence.replay(row,self.end)['status'],'same_millisecond')
        row['targets'][2].update(lo=110,hi=111)
        self.assertEqual(evidence.replay(row,self.end)['status'],'shared_target')

    def test_requires_market_coverage_and_closed_deadline(self):
        evidence = self.evidence([(0,100),(15000,106),(20000,103)])
        row = self.record([(106,106)], duration=2*M5)
        self.assertEqual(evidence.replay(row,self.end)['status'],'open')
        result = evidence.replay(row,self.end+M5)
        self.assertEqual(result['status'],'unverified_quotes')
        self.assertEqual(result['missing_m5_utc_ms'],[self.stamp+300000])
        mismatch = self.evidence([(0,100),(15000,106),(20000,103)],Bar(self.start,100,107,100,103,0))
        self.assertEqual(mismatch.replay(self.record([(106,106)]),self.end)['status'],'unverified_quotes')

    def test_sub_millisecond_registration_cannot_credit_prior_tick(self):
        evidence = self.evidence([(0,100),(6000,104),(6001,105)])
        outcome = evidence.replay(self.record([(104,104),(105,105)],offset=6000.1),self.end)
        self.assertFalse(outcome['contacts'][1]['eligible'])
        self.assertEqual(outcome['first_ranks'],[2])
