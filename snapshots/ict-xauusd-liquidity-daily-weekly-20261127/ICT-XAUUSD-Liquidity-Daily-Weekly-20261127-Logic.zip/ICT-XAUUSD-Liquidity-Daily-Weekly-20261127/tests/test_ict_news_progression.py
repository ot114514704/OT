from datetime import datetime, timezone
import unittest

from brooks_ai.types import Bar
from scripts.replay_ict_news_progression import STEP, phase_detail, phase_path


class NewsProgressionTests(unittest.TestCase):
    def setUp(self):
        self.start = datetime(2026, 10, 28, 18, tzinfo=timezone.utc)
        self.reference = {
            "low": 100, "high": 110,
            "first_observed_cross_before_release_known_at_ny": {"buy": "before"},
            "before_release_coverage_complete": True,
        }

    def bar(self, i, low, high, close):
        return Bar(self.start + i * STEP, close, high, low, close, 0)

    def test_second_phase_retains_crosses_from_pre_release_and_first_phase(self):
        rows = (self.bar(0, 99, 107, 101), self.bar(1, 98, 111, 108))
        outcome = phase_detail({bar.time: bar for bar in rows}, self.start, {"asia": self.reference}, 1, 1)
        path = outcome["references"]["asia"]
        self.assertEqual(path["first_cross_since_reference_freeze_known_at_ny"], {})
        self.assertEqual(path["repeated_cross_sides"], ["buy", "sell"])
        self.assertTrue(path["first_crosses_same_bar_intrabar_order_unknown"])
        self.assertEqual(set(path["first_close_back_across_crossed_boundary_known_at_ny"]), {"buy", "sell"})

    def test_missing_earlier_bar_does_not_invent_fresh_cross(self):
        bar = self.bar(1, 98, 108, 99)
        outcome = phase_detail({bar.time: bar}, self.start, {"asia": self.reference}, 1, 1)
        path = outcome["references"]["asia"]
        self.assertEqual(set(path["first_cross_in_phase_known_at_ny"]), {"sell"})
        self.assertIsNone(path["first_cross_since_reference_freeze_known_at_ny"])
        self.assertIsNone(path["repeated_cross_sides"])

    def test_extension_requires_two_terminal_closes_beyond_boundary(self):
        bars = (self.bar(0, 98, 108, 99), self.bar(1, 97, 102, 98), self.bar(2, 98, 103, 100))
        self.assertEqual(phase_path(bars[:2], self.reference, set())["terminal_two_closes_outside_side"], "sell")
        outcome = phase_path(bars, self.reference, set())
        self.assertIsNone(outcome["terminal_two_closes_outside_side"])
        self.assertNotIn("sell", outcome["first_close_back_across_crossed_boundary_known_at_ny"])
