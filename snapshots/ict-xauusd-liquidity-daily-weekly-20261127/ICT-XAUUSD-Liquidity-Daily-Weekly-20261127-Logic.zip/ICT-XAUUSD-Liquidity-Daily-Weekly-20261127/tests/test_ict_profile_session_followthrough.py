from datetime import date, timedelta
from unittest import TestCase

from brooks_ai.types import Bar
from ict_ai.profile_session_followthrough import M5, M15, session_followthrough
from ict_ai.timebase import session_windows


class SessionFollowthroughTests(TestCase):
    def setUp(self):
        self.day = date(2026,6,2)
        self.windows = session_windows(self.day)
        self.ny = self.windows['new_york'][0]
        self.late = self.windows['london_close'][0]

    def quarters(self, london_reclaimed, overrides):
        start = self.windows['asia'][0]
        end = self.windows['london_close'][1]
        bars = []
        for i in range((end-start)//M15):
            at = start+i*M15
            if at<self.windows['asia'][1]:
                ohlc = (105,111,100,105)
            elif self.windows['london'][0]<=at<self.windows['london'][1]:
                ohlc = (103,105,97,104) if london_reclaimed else (98,99,95,98)
            else:
                ohlc = (98,99,97,98)
            bars.append(Bar(at,*overrides.get(at,ohlc),0))
        return bars

    def read(self, bars, at, kind, covered=True):
        m5 = [Bar(b.time+i*M5,b.open,b.high,b.low,b.close,0) for b in bars for i in range(3)]
        return next(p for p in session_followthrough(m5,bars,self.day,at,covered)
                    if p['direction']==1 and p['kind']==kind)

    def test_reclaims_before_new_york_are_not_relabelled_as_new_york(self):
        start = self.ny-M15
        overrides = {start:(101,103,98,102),self.ny:(102,104,101,103),self.ny+M15:(103,105,102,104)}
        bars = self.quarters(False,overrides)
        kind = 'london_sweep_later_reclaim'
        between = self.read(bars,self.ny,kind)
        observed = self.read(bars,self.ny+2*M15,kind)
        self.assertEqual(between['reclaim_origin'],'pre_ny')
        self.assertEqual(between['status'],'waiting_for_delivery')
        self.assertEqual(observed['status'],'delivery_observed')
        self.assertEqual(observed['delivery_known_at'],(self.ny+2*M15).isoformat())

    def test_classic_11_uses_closed_late_followthrough_and_actual_invalidating_m5(self):
        bars = self.quarters(True,{self.ny:(98,100,95,98),self.late:(106,110,105,108),
                                   self.late+M15:(108,112,107,111),self.late+2*M15:(109,110,94,100)})
        kind = 'classic_11_london_close_followthrough'
        with self.assertRaises(StopIteration):
            self.read(bars,self.late+M15,kind)
        at = self.late+2*M15
        self.assertEqual(self.read(bars,at,kind)['status'],'delivery_observed')
        self.assertEqual(self.read(bars,at,kind,covered=False)['status'],'insufficient_data')
        invalidated = self.read(bars,at+M5,kind)
        self.assertEqual(invalidated['status'],'invalidated')
        self.assertEqual(invalidated['invalidated_at'],(at+M5).isoformat())

    def test_price_mirror_preserves_delivery_timing(self):
        bars = self.quarters(False,{self.ny:(101,103,98,102),self.ny+M15:(103,105,102,104)})
        mirrored = [Bar(b.time,200-b.open,200-b.low,200-b.high,200-b.close,0) for b in bars]
        m5 = [Bar(b.time+i*M5,b.open,b.high,b.low,b.close,0) for b in mirrored for i in range(3)]
        at = self.ny+2*M15
        rows = session_followthrough(m5,mirrored,self.day,at,True)
        row = next(p for p in rows if p['kind']=='london_sweep_later_reclaim')
        self.assertEqual((row['direction'],row['reclaim_origin'],row['status']),(-1,'new_york','delivery_observed'))
        self.assertEqual(row['delivery_known_at'],at.isoformat())
