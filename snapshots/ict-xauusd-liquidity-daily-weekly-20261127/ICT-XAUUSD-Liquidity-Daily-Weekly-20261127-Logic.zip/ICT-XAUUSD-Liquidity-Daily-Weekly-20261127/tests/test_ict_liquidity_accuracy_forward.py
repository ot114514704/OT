from datetime import datetime, timezone
from unittest import TestCase

from brooks_ai.types import Bar
from scripts.watch_ict_liquidity_filter_accuracy import M5, outcomes


class LiquidityAccuracyForwardTests(TestCase):
    def test_excludes_pre_registration_sweeps_and_preserves_late_window(self):
        start = datetime(2026, 11, 24, 13, tzinfo=timezone.utc)
        bars = [Bar(start + i*M5, *prices, 0) for i,prices in enumerate((
            (100, 102, 100, 101), (101, 101, 100, 100.5), (100.5, 104, 100, 102),
        ))]
        end = start + 3*M5
        registration = dict(cutoff=start.isoformat(), eligible_from=(start + 2*M5).isoformat(), price=100,
                            pools={'quarter/IRL': dict(deadline=end.isoformat(),
                                targets=[dict(side=1, lo=101, hi=101), dict(side=1, lo=103, hi=103)],
                                layers={'current_top10': [0,1], 'distance': [0]})})
        self.assertEqual(outcomes(registration, bars, end-M5)['quarter/IRL']['state'], 'open')
        settled = outcomes(registration, bars, end)['quarter/IRL']
        self.assertEqual(settled['observed_minutes'], 5)
        self.assertEqual([s for s,_ in settled['labels']], ['already_swept', 'sweep'])
        self.assertEqual(settled['layers']['distance']['offers'], 0)
        self.assertEqual(settled['layers']['current_top10']['sweeps'], 1)
        self.assertEqual(outcomes(registration, [bars[0], bars[2]], end)['quarter/IRL']['state'], 'incomplete')

    def test_gap_across_level_remains_an_offer_without_witnessed_sweep(self):
        start = datetime(2026, 11, 24, 13, tzinfo=timezone.utc)
        first, end = start+M5, start+2*M5
        bars = [Bar(start, 100, 100.5, 99.5, 100, 0), Bar(first, 108, 109, 107, 108, 0)]
        registration = dict(cutoff=start.isoformat(), eligible_from=first.isoformat(), price=100,
                            pools={'quarter/IRL': dict(deadline=end.isoformat(), targets=[dict(side=1, lo=105, hi=105)],
                                                       layers={'current_top10': [0]})})
        settled = outcomes(registration, bars, end)['quarter/IRL']
        self.assertEqual(settled['labels'][0][0], 'gap_over')
        self.assertEqual(settled['layers']['current_top10'], dict(offers=1, sweeps=0, nearest_equal_coverage=0))
