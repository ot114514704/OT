import unittest
from datetime import datetime, timedelta, timezone
from scripts.audit_ict_clock import fresh_observation


class ClockAuditTests(unittest.TestCase):
    def setUp(self):
        self.now = datetime(2026, 10, 29, 14, tzinfo=timezone.utc)
        self.quote = {'status':'live', 'bid':4000, 'ask':4000.1,
                      'quote_time':self.now.isoformat(), 'read_at':self.now.isoformat()}

    def test_live_contract_recognized(self):
        observed, fresh = fresh_observation(self.quote, self.now)
        self.assertTrue(fresh)
        self.assertEqual(observed['status'], 'live')

    def test_cached_zero_age_cannot_hide_stale_timestamp(self):
        self.quote['quote_age_seconds'] = 0
        self.quote['quote_time'] = (self.now-timedelta(seconds=31)).isoformat()
        self.assertFalse(fresh_observation(self.quote, self.now)[1])

    def test_future_clock_and_missing_heartbeat_not_accepted(self):
        for field, delta in [('quote_time',3), ('read_at',-11)]:
            q = {**self.quote, field:(self.now+timedelta(seconds=delta)).isoformat()}
            self.assertFalse(fresh_observation(q, self.now)[1])
        self.assertFalse(fresh_observation(None, self.now)[1])


if __name__ == '__main__':
    unittest.main()
