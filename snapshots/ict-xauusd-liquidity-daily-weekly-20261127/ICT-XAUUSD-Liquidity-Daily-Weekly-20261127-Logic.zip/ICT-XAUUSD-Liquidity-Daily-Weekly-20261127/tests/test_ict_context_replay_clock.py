import csv
from datetime import datetime, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from scripts.replay_ict_daily_context import context_rows


class ContextReplayClockTests(unittest.TestCase):
    def test_manifest_and_explicit_counterfactual_stay_distinct(self):
        source={'source_clock_offset_hours':2,'source_clock_segments':[
            {'raw_until':'2026-11-01T00:00:00+00:00','offset_hours':3},
            {'raw_from':'2026-11-01T00:00:00+00:00','offset_hours':2}]}
        with TemporaryDirectory() as folder:
            path=Path(folder)/'bars.csv'
            with path.open('w',newline='') as f:
                w=csv.writer(f);w.writerow(['time','open','high','low','close','spread'])
                w.writerows([[d,100,101,99,100,.1] for d in (
                    '2026-10-30T12:00:00Z','2026-11-09T12:00:00Z')])
            start=datetime(2026,10,1,tzinfo=timezone.utc)
            end=datetime(2026,11,16,tzinfo=timezone.utc)
            real,policy=context_rows(path,source,start,end)
            diagnostic,override=context_rows(path,source,start,end,0)
            self.assertEqual([b.time.hour for b in real],[9,10])
            self.assertEqual([b.time.hour for b in diagnostic],[12,12])
            self.assertEqual(policy['source_clock_segments'],source['source_clock_segments'])
            self.assertEqual(override['source_clock_segments'],[])
            self.assertEqual(source['source_clock_offset_hours'],2)

    def test_cutoff_is_applied_after_clock_conversion(self):
        with TemporaryDirectory() as folder:
            path=Path(folder)/'bars.csv'
            path.write_text('time,open,high,low,close,spread\n2026-11-09T12:00:00Z,100,101,99,100,0.1\n')
            start=datetime(2026,11,9,10,tzinfo=timezone.utc)
            end=datetime(2026,11,9,10,4,tzinfo=timezone.utc)
            rows,_=context_rows(path,{'source_clock_offset_hours':2},start,end)
            self.assertEqual(rows,[])
