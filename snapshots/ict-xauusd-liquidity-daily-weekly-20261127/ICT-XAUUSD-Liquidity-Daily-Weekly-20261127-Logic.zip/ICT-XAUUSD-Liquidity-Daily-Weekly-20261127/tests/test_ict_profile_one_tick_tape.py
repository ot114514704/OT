from dataclasses import replace
from datetime import timedelta
import unittest

from brooks_ai.types import Bar, Instrument
from ict_ai.backtest import LimitStudyOrder
from ict_ai.tick_portfolio import replay_tick_portfolio
from scripts.replay_ict_tmgm_profile_one import EPOCH, STEP, verify_tape


class ProfileOneTickTapeTest(unittest.TestCase):
    def test_later_bad_bar_preserves_completed_trade_and_censors_active_exposure(self):
        start = EPOCH.replace(year=2026, month=10, day=8, hour=14)
        starts = [start+i*STEP for i in range(4)]
        bars = [Bar(t,100,100,100,100,0) for t in starts]
        bars[1] = Bar(starts[1],99.9,102,99.9,101,0)
        rows = [(0,100,100.1), (299,100,100.1), (300,99.9,100), (320,102,102.1)]
        rows += [(t,101,101.1) for t in range(340,600,30)]
        rows += [(600,100,100.1),(899,100,100.1),(900,100,100.1)]
        name = '2026-10-08'
        spans = {name:(start,start+4*STEP)}

        def verify(quotes):
            start_ms = (start-EPOCH)//timedelta(milliseconds=1)
            stored = [[start_ms+t*1000,bid,ask] for t,bid,ask in quotes]
            return verify_tape(bars,spans,{name:{'rows':stored}})

        ticks, audit = verify(rows)
        # Mutate the first Bid of a later M5 so its entire price path is excluded.
        rows[-3] = (600,98,100.1)
        partial, witnesses = verify(rows)
        self.assertEqual(audit[name]['matched_m5'],4)
        self.assertEqual(witnesses[name]['differences'],[starts[2].isoformat()])
        self.assertEqual(witnesses[name]['matched_m5'],3)
        self.assertEqual([q for q in partial if q.time<starts[2]],[q for q in ticks if q.time<starts[2]])

        order = LimitStudyOrder('initial',1,starts[1],start+4*STEP,100,99,102,.01)
        later = replace(order,id='later',available_at=starts[3]+timedelta(seconds=1))
        spec = Instrument('XAUUSD',.01,.01,100,.01,.01,80,commission_round_turn=7,slippage=.05)
        risk = dict(risk_fraction=.0025,daily_loss_limit=.02,max_drawdown=.10,max_consecutive_losses=3)
        cutoff = later.available_at
        complete = replay_tick_portfolio([order],ticks,spec,cutoff,10000,risk)
        observed = replay_tick_portfolio([order],partial,spec,cutoff,10000,risk)
        self.assertEqual(observed,complete)
        self.assertEqual(observed['completed'][0]['outcome']['reason'],'target')

        open_order = replace(order,target=104)
        interrupted = replay_tick_portfolio([open_order,later],partial,spec,cutoff,10000,risk)
        self.assertEqual(interrupted['completed'][0]['outcome']['status'],'censored_quote_gap')
        self.assertEqual(interrupted['decisions'][-1]['status'],'blocked_by_unknown_exposure')
