from datetime import datetime,timezone
import unittest

from brooks_ai.types import Bar
from ict_ai.session_path import STEP,erl_review
from ict_ai.sweep_response import crossing_response,follow_reversal,review_sweep


class SweepResponseTests(unittest.TestCase):
    def setUp(self):
        self.at=datetime(2026,7,7,14,tzinfo=timezone.utc)
        self.prior=[self.bar(i,100,103 if i==-4 else 101,99,100) for i in range(-24,0)]
        self.sweep=self.bar(0,100,100,97,99.4)
        self.left=self.bar(1,99.5,100.5,99,100.2)
        self.impulse=self.bar(2,100.4,105.5,100.3,105.2)
        self.third=self.bar(3,104,105,102,104)

    def bar(self,i,o,h,l,c):
        return Bar(self.at+i*STEP,o,h,l,c,0)

    def test_visible_only_after_third_close(self):
        _,early=review_sweep(-1,98,self.prior,self.sweep,[self.left,self.impulse])
        self.assertIn('first_impulse',early)
        self.assertNotIn('fvg',early)
        _,late=review_sweep(-1,98,self.prior,self.sweep,[self.left,self.impulse,self.third])
        self.assertEqual(late['confirmed'],(self.at+4*STEP).isoformat())
        self.assertTrue(late['active_at_confirmation'])

    def test_gap_in_followup_cannot_be_bridged(self):
        phases,evidence=review_sweep(-1,98,self.prior,self.sweep,[self.left,self.third])
        self.assertIsNone(phases['break_at'])
        self.assertNotIn('fvg',evidence)

    def test_mt5_label_distinguishes_failed_structure_at_confirmation(self):
        failed=self.bar(3,104,105,102,102.1)
        level={'side':'sell_side_proxy','price':98,'sweep_known_at':(self.at+STEP).isoformat()}
        before=[*self.prior,self.sweep]
        after=[self.left,self.impulse,failed]
        early=erl_review(level,before,after,[],self.at+3*STEP)
        self.assertNotIn('证据到齐',early)
        late=erl_review(level,before,after,[],self.at+4*STEP)
        self.assertIn('位移 FVG 100.50–102.00',late)
        self.assertIn('证据到齐',late)
        self.assertIn('收回破位内侧',late)

    def test_first_failure_uses_closed_bar_and_preserves_ties(self):
        _,evidence=review_sweep(-1,98,self.prior,self.sweep,[self.left,self.impulse,self.third])
        breached=self.bar(4,104,105,100,102)
        before_close=follow_reversal(1,103,self.sweep,evidence,[breached],self.at+4*STEP)
        self.assertEqual(before_close['status'],'waiting')
        after_close=follow_reversal(1,103,self.sweep,evidence,[breached],self.at+5*STEP)
        self.assertEqual(after_close['status'],'invalidated')
        self.assertEqual(after_close['reasons'],['structure','fvg_far'])
        self.assertEqual(after_close['at'],(self.at+5*STEP).isoformat())

    def test_missing_bar_blocks_followup_classification(self):
        _,evidence=review_sweep(-1,98,self.prior,self.sweep,[self.left,self.impulse,self.third])
        later=self.bar(5,104,105,99,102)
        result=follow_reversal(1,103,self.sweep,evidence,[later],self.at+6*STEP)
        self.assertEqual(result['status'],'incomplete')
        self.assertEqual(result['reasons'],[])

    def test_wick_and_atr_verdict_become_known_at_separate_closes(self):
        prior=[self.bar(i,100,101,99,100) for i in range(-15,0)]
        crossing=self.bar(0,100,103,99.5,100.8)
        reclaim=self.bar(1,100.8,101,99,99.8)
        before=crossing_response(1,102,prior,crossing,[reclaim],self.at+STEP)
        after=crossing_response(1,102,prior,crossing,[reclaim],self.at+2*STEP)
        self.assertEqual(before['status'],'pending')
        self.assertEqual(before['wick_band'],(102,103))
        self.assertEqual(after['status'],'sweep')
        self.assertEqual(after['known_at'],(self.at+2*STEP).isoformat())
        self.assertEqual(after['prior_atr'],2)

    def test_followed_break_is_causal_and_mirrored(self):
        prior=[self.bar(i,100,101,99,100) for i in range(-15,0)]
        first=self.bar(0,100,100,96,97)
        second=self.bar(1,97,97.2,95.5,96)
        reversal=self.bar(2,96,102,95,101)
        result=crossing_response(-1,98,prior,first,[second,reversal],self.at+3*STEP)
        self.assertEqual(result['status'],'break')
        self.assertIsNone(result['wick_band'])
        self.assertEqual(result['known_at'],(self.at+2*STEP).isoformat())

    def test_quote_gaps_and_zero_atr_do_not_confirm(self):
        prior=[self.bar(i,100,101,99,100) for i in range(-15,0)]
        verdict=crossing_response(-1,98,prior,self.sweep,[self.third],self.at+4*STEP)
        self.assertEqual(verdict['status'],'incomplete')
        self.assertEqual(verdict['wick_band'],(97,98))
        self.assertEqual(crossing_response(-1,98,prior[1:],self.sweep,[],self.at+STEP)['status'],'missing_prior')
        flat=[self.bar(i,100,100,100,100) for i in range(-15,0)]
        self.assertEqual(crossing_response(-1,98,flat,self.sweep,[],self.at+STEP)['status'],'missing_prior')


if __name__=='__main__':
    unittest.main()
