from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from scripts.watch_ict_dol_settlement import GRACE, M5, RETRY, settle_once, verify_saved


class DolAutomaticSettlementTest(unittest.TestCase):
    def test_delayed_bucket_can_be_retried_then_shared_across_windows(self):
        start = datetime(2026, 11, 23, 14, tzinfo=timezone.utc)
        end = start + 2*M5
        row = dict(cutoff=start.isoformat(), end=end.isoformat(), evidence='registration-1',
                   recorded_at=(start+timedelta(seconds=5)).isoformat(),
                   targets=[dict(rank=1, side=1, lo=102, hi=102)], selection=dict(chart_rank1=0))
        overlap = dict(row, cutoff=(start+M5).isoformat(), evidence='registration-2',
                       recorded_at=(start+M5+timedelta(seconds=5)).isoformat())
        calls = []

        def fetch(starts, _):
            calls.append(starts)
            available = starts[:1] if len(calls)==1 else starts
            for instant in available:
                yield instant, dict(open_utc=instant.isoformat(), ohlc=[100,102,100,102],
                                    bid_offsets=[[0,100],[10_000,102]])

        with TemporaryDirectory() as directory:
            folder, retry = Path(directory), {}

            def run(at):
                return settle_once([row,overlap], folder, fetch, at, 'TMGM-test', retry)

            early = run(end)
            self.assertEqual(early['coverage'], {'awaiting_history':2})
            self.assertEqual(calls, [])
            missing = run(end+GRACE)
            self.assertEqual(missing['coverage'], {'unverified_quotes':2})
            self.assertFalse(list((folder/'bid_outcomes').glob('*.json')))
            run(end+GRACE+timedelta(seconds=20))
            self.assertEqual(len(calls),1)
            complete = run(end+GRACE+RETRY)
            self.assertEqual(complete['coverage'], {'unique':2})
            self.assertEqual(complete['comparisons']['chart_rank1']['unique_first'],2)
            self.assertEqual(calls, [[start,start+M5],[start+M5]])
            self.assertEqual(len(list((folder/'bid_buckets').glob('*.gz'))),2)
            self.assertEqual(len(list((folder/'bid_outcomes').glob('*.json'))),2)
            restarted = settle_once([row,overlap], folder, fetch, end+GRACE+2*RETRY, 'TMGM-test', {})
            self.assertEqual(complete,restarted)
            self.assertEqual(len(calls),2)
            self.assertEqual(verify_saved([row,overlap], folder, 'TMGM-test'),2)
            next((folder/'bid_buckets').glob('*.gz')).unlink()
            with self.assertRaisesRegex(ValueError, 'evidence hashes differ'):
                verify_saved([row,overlap], folder, 'TMGM-test')
