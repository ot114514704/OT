import unittest
from datetime import date, datetime, timedelta, timezone

from brooks_ai.types import Bar
from ict_ai.daily_path import candidate_fit, daily_geometry
from ict_ai.profile_lifecycle import _day_bounds


class DailyPathTests(unittest.TestCase):
    step = timedelta(minutes=5)

    def test_zero_open_order_and_cutoff_across_both_offsets(self):
        for month, utc_hour in [(7, 4), (11, 5)]:
            start, _ = _day_bounds(date(2026, month, 10))
            self.assertEqual(start.hour, utc_hour)
            rows = [Bar(start+self.step*i,*v,0) for i,v in enumerate([
                (100,101,98,99),(99,105,99,104),(104,104,101,103),(103,210,50,200)])]
            cutoff = rows[-1].time
            actual = daily_geometry(rows,start,cutoff,self.step)
            self.assertEqual(actual,daily_geometry(rows[:3],start,cutoff,self.step))
            self.assertEqual(actual['crossings'],1)
            self.assertAlmostEqual(actual['offset'],3/7)
            card = dict(id='classic_buy',direction=1,observed_sequence=True,status='active')
            self.assertEqual(candidate_fit(card,actual),1)
            self.assertEqual(candidate_fit(dict(card,status='invalidated'),actual),0)

    def test_missing_open_ambiguous_bar_and_no_gap_bridge(self):
        start=datetime(2026,11,18,5,tzinfo=timezone.utc)
        rows=[Bar(start+self.step*i,100,110,90,101,0) for i in (1,4)]
        path=daily_geometry(rows,start,start+5*self.step,self.step)
        self.assertFalse(path['usable'])
        self.assertIsNone(path['offset'])
        self.assertEqual(path['segments'],[])
