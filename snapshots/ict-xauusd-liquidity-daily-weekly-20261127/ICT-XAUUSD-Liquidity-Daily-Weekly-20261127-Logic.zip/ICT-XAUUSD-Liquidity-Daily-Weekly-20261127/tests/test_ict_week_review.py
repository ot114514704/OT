import unittest
from datetime import datetime,timedelta,timezone,date
from brooks_ai.types import Bar
from scripts.prepare_ict_week import session_summary,review_week,review_day,profile_annotation
from ict_ai.knowledge import load_rules,evaluate


class TestWeekReview(unittest.TestCase):
    def test_london_path_is_a_pending_candidate_before_new_york(self):
        start=datetime(2026,10,13,0,tzinfo=timezone.utc)
        p=timedelta(minutes=15)
        bars=[Bar(start+i*p,105,110,100,105,0) for i in range(24)]
        bars += [Bar(start+i*p,107,111,103,104,0) for i in range(24,36)]
        result=review_day(bars,date(2026,10,13),p,start+timedelta(hours=10))
        self.assertIn('看跌镜像',result['candidates'][0]['profile'])
        self.assertEqual(profile_annotation(result)['profile_status'],'pending')
        self.assertIsNone(result['price_observations']['new_york_lower_sweep_return'])
        ended=review_day(bars,date(2026,10,13),p,start+timedelta(days=2))
        self.assertEqual(ended['sessions']['new_york']['state'],'missing')
        self.assertFalse(any('早期候选' in c['profile'] for c in ended['candidates']))

    def test_unfinished_window_is_not_negative_evidence(self):
        start=datetime(2026,10,12,11,tzinfo=timezone.utc)
        period=timedelta(minutes=15)
        bars=[Bar(start+i*period,100,101,99,100,0) for i in range(9)]
        result=session_summary(bars,start,start+timedelta(hours=3),period,start+timedelta(hours=2,minutes=29))
        self.assertFalse(result['complete'])
        self.assertEqual(result['state'],'in_progress')
        self.assertEqual(result['bars'],9)

    def test_future_weekday_remains_unobserved(self):
        start=datetime(2026,10,12,4,tzinfo=timezone.utc)
        bars=[Bar(start+i*timedelta(minutes=15),100,101,99,100,0) for i in range(40)]
        result=review_week(bars,[date(2026,10,d) for d in range(12,17)],start+timedelta(hours=9))
        self.assertEqual(result['status'],'in_progress')
        self.assertEqual(result['daily'][1]['status'],'not_started')
        self.assertNotIn('close',result['daily'][1])
        self.assertEqual(len(result['bars']),9)

    def test_weekly_profile_does_not_use_future_friday(self):
        rules=load_rules(scope='weekly')
        card=rules['profiles'][1]
        observations=[{'fact':fact,'value':value,'available_at':'2026-10-14T18:00:00Z','source':'synthetic fixture'} for fact,value in card['required_facts'].items()]
        observations[-1]['available_at']='2026-10-16T20:00:00Z'
        result=evaluate(observations,'2026-10-15T12:00:00Z',rules)
        candidate=next(c for c in result['candidates'] if c['id']==card['id'])
        self.assertEqual(candidate['status'],'incomplete')
        self.assertIn('thursday_friday_expansion',candidate['missing'])

    def test_weekly_anchors_and_user_exclusions(self):
        from pathlib import Path
        rules=load_rules(scope='weekly')
        text=(Path(__file__).resolve().parents[1]/'research/ict_weekly_profiles/transcript.txt').read_text(encoding='utf-8')
        for card in rules['profiles']:
            loc=card['doc_location'];self.assertEqual(text[loc['start']:loc['end']],loc['exact_text'])
            self.assertFalse(set(card['slides'])&{23,25,26})

    def test_source_definition_choices_are_not_market_observation_requirements(self):
        rules=load_rules(scope='weekly')
        fourth=next(c for c in rules['profiles'] if c['id']=='weekly_thursday_consolidation_reversal')
        self.assertFalse(fourth['source_constraints']['thursday_same_day_reclaim_required'])
        self.assertNotIn('thursday_same_day_reclaim_required',fourth['required_facts'])
        self.assertNotIn('thursday_reversal_confirmed',fourth['required_facts'])
        # Confirmation arrives Friday. Thursday's outside close does not
        # contradict the source definition or complete the required expansion.
        observations=[{'fact':fact,'value':value,'available_at':'2026-10-15T20:00:00Z','source':'test only'}
                      for fact,value in fourth['required_facts'].items()]
        for item in observations:
            if item['fact'] in ('reversal_after_thursday_extreme_confirmed','friday_expansion'):
                item['available_at']='2026-10-16T20:00:00Z'
        early=evaluate(observations,'2026-10-15T21:00:00Z',rules)
        late=evaluate(observations,'2026-10-16T21:00:00Z',rules)
        get=lambda result:next(c for c in result['candidates'] if c['id']==fourth['id'])
        self.assertEqual(get(early)['status'],'incomplete')
        self.assertEqual(get(late)['status'],'evidence_match')


if __name__=='__main__':unittest.main()
