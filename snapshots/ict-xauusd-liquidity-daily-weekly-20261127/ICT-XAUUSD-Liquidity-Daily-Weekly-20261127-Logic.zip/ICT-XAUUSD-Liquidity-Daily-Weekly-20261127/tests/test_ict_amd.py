import unittest
from dataclasses import replace
from datetime import datetime,timedelta,timezone
from brooks_ai.types import Bar
from ict_ai.amd import amd_events


class AMDTest(unittest.TestCase):
    def fixture(self, direct=False):
        t=datetime(2026,10,13,14,tzinfo=timezone.utc);p=timedelta(minutes=15)
        rows=[Bar(t+i*p,100,102,98,100+(.5 if i%2 else -.5),0) for i in range(8)]
        values=[(101,104,99,103),(103,105,102.5,104)] if direct else [(100,104,99,101),(101,101,96,97),(97,99,95,96)]
        rows += [Bar(t+(8+i)*p,*v,0) for i,v in enumerate(values)]
        return t,p,rows

    def test_price_path_not_tied_to_asia(self):
        t,p,rows=self.fixture();events=amd_events(rows,p,t+11*p)
        self.assertEqual([e['phase'] for e in events],['A','M','D'])
        self.assertEqual(events[-1]['direction'],'bearish')
        self.assertTrue(all(not e['trade_signal'] for e in events))
        self.assertTrue(all(e['context_status']=='pending_prior_dol_htf' for e in events))

    def test_archived_frame_fires_once_and_requires_displacement(self):
        t,p,rows=self.fixture()
        for shape in ('rising_channel','triangle','overlapping'):
            final=amd_events(rows,p,t+11*p,reference_shape=shape)
            self.assertEqual([e['phase'] for e in final],['A','M','D'])
            self.assertEqual(final[:-1],amd_events(rows,p,t+10*p,reference_shape=shape))
            weak=rows[:9]+[replace(b,open=b.close+.1) for b in rows[9:]]
            self.assertEqual([e['phase'] for e in amd_events(weak,p,t+11*p,reference_shape=shape)],['A','M'])
            # Later bars cannot silently replace a gapped reference formation.
            broken=rows[:3]+[replace(b,time=b.time+p) for b in rows[3:]]
            self.assertEqual(amd_events(broken,p,t+12*p,reference_shape=shape),[])

    def test_direct_expansion_does_not_invent_manipulation(self):
        t,p,rows=self.fixture(True);events=amd_events(rows,p,t+10*p)
        self.assertEqual([e['phase'] for e in events],['A','D'])
        self.assertEqual(events[-1]['route'],'AD_no_M')
        self.assertEqual(events[-1]['direction'],'bullish')

    def test_prefix_and_unclosed_bar_cannot_rewrite_stage(self):
        for direct in (False,True):
            t,p,rows=self.fixture(direct);full=amd_events(rows,p,t+len(rows)*p)
            for n in range(1,len(rows)+1):
                expected=[e for e in full if datetime.fromisoformat(e['available_at'])<=t+n*p]
                self.assertEqual(amd_events(rows[:n],p,t+n*p),expected)
                self.assertEqual(amd_events(rows,p,t+n*p),expected)
            self.assertEqual(amd_events(rows,p,t+len(rows)*p-timedelta(microseconds=1))[-1]['phase'],'M' if not direct else 'A')

    def test_double_sweep_and_gap_block_unknown_order(self):
        t,p,rows=self.fixture()
        double=rows.copy();double[8]=replace(double[8],low=97)
        self.assertEqual([e['phase'] for e in amd_events(double,p,t+11*p)],['A'])
        self.assertEqual([e['phase'] for e in amd_events(rows[:9]+rows[10:],p,t+11*p)],['A','M'])

    def test_replay_retires_active_range_at_confirmation_without_rewriting_a_m_d(self):
        t,p,rows=self.fixture()
        both=rows.copy();both[8]=replace(both[8],low=97,open=103)
        repeat=rows.copy();repeat[9]=replace(repeat[9],high=105,low=99,close=103)
        cases = [(both,'both_boundaries_same_bar',9), (rows[:9]+rows[10:],'quote_gap',11),
                 (repeat,'sweep_extreme_extended',10)]
        for candles,reason,n in cases:
            with self.subTest(reason=reason):
                at = t+n*p
                before = amd_events(candles,p,at-timedelta(microseconds=1),include_retirements=True)
                after = amd_events(candles,p,at,include_retirements=True)
                self.assertEqual(after[:-1],before)
                self.assertEqual(after[:-1],amd_events(candles,p,at))
                retirement = after[-1]
                self.assertEqual((retirement['phase'],retirement['route']),('X',reason))
                self.assertEqual((retirement['available_at'],retirement['id']),(at.isoformat(),before[0]['id']))
                self.assertFalse(retirement['candidate'] or retirement['trade_signal'])
                if reason=='both_boundaries_same_bar':
                    self.assertEqual(retirement['bar_open'],103)

    def test_manipulation_extreme_revisit_invalidates_path(self):
        t,p,rows=self.fixture();rows[9]=replace(rows[9],high=105,low=99,close=103)
        self.assertEqual([e['phase'] for e in amd_events(rows,p,t+11*p)],['A','M'])

    def test_one_same_side_resweep_restarts_delivery_evidence(self):
        t,p,rows=self.fixture()
        rows[9:9]=[Bar(t+9*p,101,105,99,100,0)]
        rows[10:]=[replace(b,time=b.time+p) for b in rows[10:]]
        options=dict(require_displacement=True,allow_same_side_resweep=True)
        events=amd_events(rows,p,t+12*p,**options)
        self.assertEqual([e['phase'] for e in events],['A','M','M','D'])
        self.assertTrue(events[2]['same_side_resweep'] and events[3]['same_side_resweep'])
        self.assertEqual(events[2]['start'],(t+9*p).isoformat())
        self.assertEqual((events[2]['range_low'],events[2]['range_high']),(98,102))
        for n in range(8,13):
            self.assertEqual(amd_events(rows,p,t+n*p,**options),
                             [e for e in events if datetime.fromisoformat(e['available_at'])<=t+n*p])
        rows[10]=replace(rows[10],high=106,low=99,close=101)
        self.assertEqual([e['phase'] for e in amd_events(rows,p,t+12*p,**options)],['A','M','M'])

    def test_direct_expansion_requires_directional_body_in_strict_mode(self):
        t,p,rows=self.fixture(True)
        weak=rows[:8]+[replace(b,open=b.close-.1) for b in rows[8:]]
        self.assertEqual([e['phase'] for e in amd_events(weak,p,t+10*p,require_displacement=True)],['A'])
        weak.append(Bar(t+10*p,104,106,103.9,105.5,0))
        events=amd_events(weak,p,t+11*p,require_displacement=True)
        self.assertEqual([e['phase'] for e in events],['A','D'])
        self.assertEqual(events[1]['available_at'],(t+11*p).isoformat())

    def test_contracting_ranges_and_mirror(self):
        t,p,rows=self.fixture()
        rows[:8]=[replace(b,high=104 if i<4 else 102,low=96 if i<4 else 98) for i,b in enumerate(rows[:8])]
        self.assertEqual(amd_events(rows[:8],p,t+8*p)[0]['shape'],'contracting')
        t,p,rows=self.fixture()
        mirrored=[replace(b,open=200-b.open,high=200-b.low,low=200-b.high,close=200-b.close) for b in rows]
        self.assertEqual(amd_events(mirrored,p,t+11*p)[-1]['direction'],'bullish')

    def test_single_direction_trend_is_not_accumulation(self):
        t,p,_=self.fixture()
        rows=[Bar(t+i*p,100+i,102+i,99+i,101+i,0) for i in range(12)]
        self.assertEqual(amd_events(rows,p,t+12*p),[])

    def test_confirmed_pivot_shapes_share_sweep_and_delivery_rules(self):
        t,p,_=self.fixture()
        for name,du,dl in (("triangle",-.12,.12),("ascending_triangle",0,.12),
                           ("descending_triangle",-.12,0),("rising_channel",.1,.1),
                           ("falling_channel",-.1,-.1),("rising_wedge",.07,.18),
                           ("falling_wedge",-.18,-.07)):
            with self.subTest(name=name):
                rows=[]
                for i in range(8):
                    hi=104+i*du-(0 if i in (1,4) else .7)
                    lo=100+i*dl+(0 if i in (2,6) else .7)
                    mid=(hi+lo)/2
                    rows.append(Bar(t+i*p,mid,hi,lo,mid,0))
                lo,hi=rows[6].low,rows[4].high
                mid=(lo+hi)/2
                rows.extend([Bar(t+8*p,mid,hi+.1,mid,mid,0),
                             Bar(t+9*p,mid,mid,lo-1,lo-.3,0),
                             Bar(t+10*p,lo-.3,lo,lo-2,lo-1,0)])
                result=amd_events(rows,p,t+11*p)
                self.assertEqual([e["phase"] for e in result],["A","M","D"])
                self.assertEqual(result[0]["shape"],name)
                self.assertEqual((result[0]["range_low"],result[0]["range_high"]),(lo,hi))
                self.assertEqual(result[-1]["route"],"AMD")
                triangle_result=amd_events(rows,p,t+11*p,triangle_only=True)
                if name in ("triangle","ascending_triangle","descending_triangle"):
                    self.assertEqual(triangle_result,result)
                    for n in range(1,12):
                        known=[e for e in result if datetime.fromisoformat(e["available_at"])<=t+n*p]
                        self.assertEqual(amd_events(rows[:n],p,t+n*p,triangle_only=True),known)
                else:
                    self.assertEqual(amd_events(rows[:8],p,t+8*p,triangle_only=True),[])
                for n in range(1,12):
                    self.assertEqual(amd_events(rows[:n],p,t+n*p),
                                     [e for e in result if datetime.fromisoformat(e["available_at"])<=t+n*p])

    def test_pending_range_expires(self):
        t,p,rows=self.fixture(True)
        idle=[replace(rows[0],time=t+i*p) for i in range(8,11)]
        tail=[replace(b,time=t+(11+j)*p) for j,b in enumerate(rows[8:])]
        events=amd_events(rows[:8]+idle+tail,p,t+13*p,expiry_bars=2)
        self.assertTrue(all(e['phase']=='A' for e in events))

