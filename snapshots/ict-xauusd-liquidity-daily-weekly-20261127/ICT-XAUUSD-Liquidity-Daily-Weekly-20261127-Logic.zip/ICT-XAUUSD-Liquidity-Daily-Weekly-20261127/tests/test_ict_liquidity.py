import unittest
from dataclasses import replace
from datetime import date,datetime,timedelta,time,timezone
from brooks_ai.types import Bar
from ict_ai.timebase import NY
from ict_ai.liquidity import closed_day_references,equal_extreme_references


class LiquidityTest(unittest.TestCase):
    def test_friday_close_hypotheses_do_not_hide_missing_or_unexpected_quotes(self):
        day=date(2026,11,13);p=timedelta(minutes=5)
        start=datetime.combine(day,time(0),NY).astimezone(timezone.utc)
        end=start+timedelta(hours=17)
        bars=[Bar(start+i*p,100,101,99,100,.1) for i in range(203)]
        late=closed_day_references(bars,day,p,end)
        self.assertEqual(late['status'],'missing_quotes')
        self.assertEqual(late['missing_expected_times'],[(end-p).isoformat()])
        early=closed_day_references(bars,day,p,end,16*60+55)
        self.assertEqual(early['status'],'complete')
        self.assertEqual(early['available_at'],(end-p).isoformat())
        self.assertFalse(early['session_calendar_verified'])
        bars.append(Bar(end-p,100,105,98,102,.1))
        contradicted=closed_day_references(bars,day,p,end,16*60+55)
        self.assertEqual(contradicted['status'],'study_calendar_contradicted')
        self.assertEqual(contradicted['levels'],[])
        self.assertEqual(closed_day_references(bars,day,p,end)['status'],'complete')

    def day_fixture(self):
        d=date(2026,10,12);p=timedelta(minutes=15)
        start=datetime.combine(d,time(0),NY).astimezone(timezone.utc)
        bars=[Bar(start+i*p,100,101,99,100,0) for i in range(96) if not 68<=i<72]
        return d,p,start,bars

    def test_daily_extremes_not_available_before_final_close(self):
        d,p,t,bars=self.day_fixture()
        self.assertEqual(closed_day_references(bars,d,p,t+timedelta(days=1)-timedelta(microseconds=1))['status'],'not_closed')
        r=closed_day_references(bars,d,p,t+timedelta(days=1))
        self.assertEqual(r['status'],'complete')
        self.assertEqual(r['bars'],92)
        self.assertFalse(r['levels'][0]['actual_stop_orders_observed'])

    def test_missing_quote_not_treated_as_market_closure(self):
        d,p,t,bars=self.day_fixture()
        r=closed_day_references(bars[:3]+bars[4:],d,p,t+timedelta(days=1))
        self.assertEqual(r['status'],'missing_quotes')
        self.assertEqual(r['levels'],[])

    def test_future_touch_does_not_backfill_reached_status(self):
        d,p,t,bars=self.day_fixture();end=t+timedelta(days=1)
        bars.append(Bar(end,100,102,99,101,0))
        self.assertFalse(closed_day_references(bars,d,p,end)['levels'][0]['price_touched'])
        self.assertEqual(closed_day_references(bars,d,p,end+p)['levels'][0]['first_touch_known_at'],(end+p).isoformat())

    def test_equal_high_waits_for_second_pivot_confirmation(self):
        t=datetime(2026,10,13,tzinfo=timezone.utc);p=timedelta(minutes=5)
        highs=[99,99.5,100,99.5,99,99.5,100.02,99.5,99]
        bars=[Bar(t+i*p,98.5,h,98,98.8,0) for i,h in enumerate(highs)]
        self.assertEqual(equal_extreme_references(bars,p,t+7*p,.01,pivot_radius=1),[])
        e=equal_extreme_references(bars,p,t+8*p,.01,pivot_radius=1)
        self.assertEqual(e[0]['kind'],'EQH')
        self.assertEqual(e[0]['available_at'],(t+8*p).isoformat())
        self.assertEqual(equal_extreme_references(bars[:8],p,t+8*p,.01,pivot_radius=1),e)
        self.assertEqual(equal_extreme_references(bars,p,t+9*p,.01,pivot_radius=1),e)
        self.assertEqual(equal_extreme_references(bars[:4]+bars[5:],p,t+9*p,.01,pivot_radius=1),[])


if __name__=='__main__':unittest.main()
