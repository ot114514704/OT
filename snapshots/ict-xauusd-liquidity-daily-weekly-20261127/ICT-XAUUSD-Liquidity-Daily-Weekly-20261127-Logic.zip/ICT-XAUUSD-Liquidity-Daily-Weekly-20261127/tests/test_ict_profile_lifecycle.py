from dataclasses import replace
from datetime import date, datetime, time, timedelta, timezone
import unittest

from brooks_ai.types import Bar
from ict_ai.profile_lifecycle import daily_profile_lifecycle, profile_hover_detail, weekly_profile_lifecycle, _reclaim
from ict_ai.timebase import NY, session_windows


class ProfileLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.day=date(2026,10,13); self.p=timedelta(minutes=15)
        self.start=datetime.combine(self.day,time(0),NY).astimezone(timezone.utc)
        self.end=datetime.combine(self.day+timedelta(days=1),time(0),NY).astimezone(timezone.utc)
        asia=session_windows(self.day)['asia'][0]
        self.rows=[Bar(asia+i*self.p,100,101,99,100,.2) for i in range(int((self.end-asia)/self.p))]

    def classic(self):
        rows=[]
        for b in self.rows:
            hour=b.time.astimezone(NY).hour
            if b.time.astimezone(NY).date()==self.day and hour==2:
                b=replace(b,low=98)
            if b.time==self.start+timedelta(hours=4,minutes=45):
                b=replace(b,high=102,close=101)
            if self.start+timedelta(hours=7)<=b.time:
                b=replace(b,open=103,high=104,low=102.5,close=103)
            rows.append(b)
        return rows

    def test_live_guess_then_closed_price_confirmation_are_separate(self):
        rows=self.classic(); early=daily_profile_lifecycle(rows,self.day,self.start+timedelta(hours=7))
        final=daily_profile_lifecycle(rows,self.day,self.end)
        self.assertEqual(early['mode'],'intraday_hypothesis')
        self.assertEqual(early['profile_status'],'forecast')
        self.assertEqual(early['actual_paths'],[])
        self.assertIn('经典买入',early['profile_label'])
        self.assertEqual(final['profile_status'],'confirmed_path')
        self.assertEqual(final['actual_paths'][0]['id'],'classic_buy')
        self.assertFalse(final['full_ict_profile_confirmed'])
        self.assertFalse(final['execution_allowed'])
        self.assertIn('视频图例 12:30', profile_hover_detail(final))
        self.assertEqual(profile_hover_detail(final, include_references=False),
                         profile_hover_detail(final).split('｜课件对照')[0])

    def test_every_prefix_ignores_future_quotes_and_week_extremes(self):
        rows=self.classic()
        for n,b in enumerate(rows,1):
            at=b.time+self.p
            self.assertEqual(daily_profile_lifecycle(rows,self.day,at),daily_profile_lifecycle(rows[:n],self.day,at))
        changed=rows+[Bar(self.end,100,100000,1,100,.2)]
        self.assertEqual(daily_profile_lifecycle(rows,self.day,self.end),daily_profile_lifecycle(changed,self.day,self.end))

    def test_early_reconstruction_is_labelled_and_not_rewritten(self):
        rows=self.classic(); final=daily_profile_lifecycle(rows,self.day,self.end)
        for earlier in final['earlier_hypotheses']:
            at=datetime.fromisoformat(earlier['as_of'])
            prefix=daily_profile_lifecycle(rows,self.day,at)
            self.assertEqual(earlier['label'],prefix['profile_label'])
            self.assertIn('not_recorded_live_forecast',earlier['origin'])

    def test_missing_ny_or_midnight_quote_cannot_confirm_full_day_path(self):
        rows=self.classic()
        for missing in (self.start,self.start+timedelta(hours=7,minutes=30),self.end-self.p):
            result=daily_profile_lifecycle([b for b in rows if b.time!=missing],self.day,self.end)
            self.assertNotEqual(result['profile_status'],'confirmed_path')
            self.assertEqual(result['actual_paths'],[])

    def test_friday_ends_at_17_ny_and_period_does_not_guess_recess(self):
        friday=date(2026,10,16); shift=timedelta(days=3)
        rows=[replace(b,time=b.time+shift) for b in self.classic()]
        end=datetime.combine(friday,time(17),NY).astimezone(timezone.utc)
        self.assertEqual(daily_profile_lifecycle(rows,friday,end-self.p)['mode'],'intraday_hypothesis')
        self.assertEqual(daily_profile_lifecycle(rows,friday,end)['mode'],'closed_review')

    def test_weekly_background_excludes_later_days_from_historical_day(self):
        rows=self.classic()
        tomorrow=[replace(b,time=b.time+timedelta(days=1),high=100000,low=1) for b in rows if b.time+timedelta(days=1)>=self.end]
        cutoff=self.start+timedelta(hours=7)
        self.assertEqual(daily_profile_lifecycle(rows,self.day,cutoff),daily_profile_lifecycle(sorted(rows+tomorrow,key=lambda b:b.time),self.day,cutoff))

    def test_no_calendar_does_not_confirm_a_news_profile(self):
        result=daily_profile_lifecycle(self.rows,self.day,self.end)
        self.assertEqual(result['profile_status'],'closed_unclassified')
        self.assertTrue(any(c['id']=='news_manipulation_expansion' for c in result['candidates']))
        self.assertEqual(result['actual_paths'],[])

    def test_unobserved_course_alternatives_do_not_become_selected_live_profiles(self):
        result=daily_profile_lifecycle(self.rows,self.day,self.start+timedelta(hours=7))
        self.assertEqual(result['profile_label'],'概况候选待形成')
        self.assertTrue(all(not c['observed_sequence'] for c in result['candidates']))
        self.assertIn('不足',result['profile_reason'])
        self.assertNotIn('课件对照', profile_hover_detail(result))
        final=daily_profile_lifecycle(self.rows,self.day,self.end)
        self.assertIn('未形成完整匹配',final['profile_reason'])

    def test_brief_reason_follows_observed_match_and_missing_coverage(self):
        result=daily_profile_lifecycle(self.classic(),self.day,self.end)
        self.assertIn('伦敦低点',result['profile_reason'])
        self.assertIn('连续两根收盘',result['profile_reason'])
        checks=result['session_price_checks']
        self.assertIsNotNone(checks['london_sweep_low_reclaim'])
        self.assertIsNotNone(checks['ny_two_closes_above_london'])
        self.assertLessEqual(datetime.fromisoformat(checks['ny_two_closes_above_london']),self.end)
        self.assertTrue(checks['closed_day'])
        self.assertNotIn('后续延续待验证',result['profile_reason'])
        missing=[b for b in self.classic() if b.time!=self.start+timedelta(hours=7,minutes=30)]
        self.assertIn('报价覆盖不完整',daily_profile_lifecycle(missing,self.day,self.end)['profile_reason'])

    def test_live_wednesday_subclass_uses_only_completed_tuesday_path(self):
        monday=date(2026,10,12);days=[monday+timedelta(days=i) for i in range(5)]
        origin=datetime.combine(monday,time(0),NY).astimezone(timezone.utc)
        when=origin+timedelta(days=2,hours=7)
        rows=[]
        for i in range(96*5):
            at=origin+i*self.p
            b=Bar(at,100,102,99,100,.2)
            if origin+timedelta(days=1)<=at<origin+timedelta(days=2):b=replace(b,close=101)
            if at==when:b=replace(b,low=98)
            rows.append(b)
        review={'profile_label':'待确认','candidates':[]}
        cutoff=when+self.p
        result=weekly_profile_lifecycle(rows,days,cutoff,review)
        card=next(c for c in result['candidates'] if c['id']=='weekly_wednesday_double_sweep')
        self.assertIn('周二实体',card['evidence'])
        self.assertFalse(result['prior_bias_verified'])
        self.assertEqual(result,weekly_profile_lifecycle([b for b in rows if b.time+self.p<=cutoff],days,cutoff,review))

    def test_reclaim_cannot_bridge_an_unobserved_interval(self):
        breach=Bar(self.start,100,100,98,98.5,.2)
        after_gap=Bar(self.start+2*self.p,100,101,100,100,.2)
        self.assertIsNone(_reclaim([breach,after_gap],99,-1,self.p))
        continuous=replace(after_gap,time=self.start+self.p)
        self.assertIsNotNone(_reclaim([breach,continuous],99,-1,self.p))

    def test_weekly_guess_uses_completed_range_and_actual_wednesday_reclaim(self):
        monday=date(2026,10,12); days=[monday+timedelta(days=i) for i in range(5)]
        origin=datetime.combine(monday,time(0),NY).astimezone(timezone.utc)
        rows=[Bar(origin+i*self.p,100,101,99,100,.2) for i in range(96*5)]
        when=origin+timedelta(days=2,hours=7)
        rows=[replace(b,low=98) if b.time==when else b for b in rows]
        review={'profile_label':'周待确认','candidates':[]}
        early=weekly_profile_lifecycle(rows,days,when,review)
        known=weekly_profile_lifecycle(rows,days,when+self.p,review)
        self.assertFalse(any(c['id']=='weekly_wednesday_unresolved' for c in early['candidates']))
        card=next(c for c in known['candidates'] if c['id']=='weekly_wednesday_unresolved')
        self.assertEqual(card['direction'],1)
        self.assertFalse(any(c['id']=='weekly_wednesday_extreme' for c in known['candidates']))
        self.assertFalse(known['final_week_extreme_known'])
        self.assertFalse(known['prior_bias_verified'])
        prefix=[b for b in rows if b.time+self.p<=when+self.p]
        self.assertEqual(known,weekly_profile_lifecycle(prefix,days,when+self.p,review))

    def test_london_expansion_then_containment_needs_small_final_net_body(self):
        # Identical session sequence with two different daily bodies: a trend
        # body inside the London range is not the course's doji-like profile.
        rows=[]
        for b in self.rows:
            if b.time==self.start+timedelta(hours=2):b=replace(b,low=97)
            if self.start+timedelta(hours=3)<=b.time<self.start+timedelta(hours=5):
                b=replace(b,open=102,high=110,low=98,close=103)
            if self.start+timedelta(hours=5)<=b.time:
                b=replace(b,open=108,high=109,low=107,close=108)
            rows.append(b)
        result=daily_profile_lifecycle(rows,self.day,self.end)
        card=next(c for c in result['candidates'] if c['id']=='manipulation_expansion_consolidation')
        self.assertFalse(card['path_matched']);self.assertEqual(card['status'],'invalidated')
        rows=[replace(b,open=100,high=101,low=99,close=100)
              if b.time>=self.start+timedelta(hours=5) else b for b in rows]
        result=daily_profile_lifecycle(rows,self.day,self.end)
        card=next(c for c in result['candidates'] if c['id']=='manipulation_expansion_consolidation')
        self.assertTrue(card['path_matched'])
        self.assertEqual(card['status'],'active')

    def test_direct_and_manipulated_consolidation_sequences_do_not_invent_news(self):
        def sequence(manipulation):
            rows=[]
            for b in self.rows:
                if b.time>=self.start:
                    i=int((b.time-self.start)/self.p)
                    if i<8:b=replace(b,close=100.2 if i%2 else 99.8)
                    elif manipulation and i==8:b=replace(b,low=98,close=100)
                    else:b=replace(b,open=102,high=103,low=100,close=102)
                rows.append(b)
            return rows
        for manipulation,ident in [(False,'consolidation_expansion'),(True,'news_manipulation_expansion')]:
            rows=sequence(manipulation)
            result=daily_profile_lifecycle(rows,self.day,self.end)
            card=next(c for c in result['candidates'] if c['id']==ident)
            self.assertTrue(card['path_matched'])
            self.assertFalse(card['calendar_event_verified'])
            self.assertFalse(card['news_causality_verified'])
            self.assertIn('待核实',card['label'])
            detail = profile_hover_detail(result)
            self.assertIn('视频图例 ' + ('17:30' if manipulation else '15:30'), detail)
            self.assertEqual('扫荡后收回' in detail, manipulation)
            self.assertIn('02:00 确认盘整范围', detail)
            at=self.start+12*self.p
            self.assertEqual(daily_profile_lifecycle(rows,self.day,at),daily_profile_lifecycle([b for b in rows if b.time+self.p<=at],self.day,at))
            # A later local range cannot stand for consolidation from midnight.
            rows=[replace(b,high=110) if b.time==self.start else b for b in rows]
            changed=daily_profile_lifecycle(rows,self.day,self.end)
            self.assertFalse(any(c['id']==ident and c['path_matched'] for c in changed['candidates']))

    def test_closed_week_uses_realised_review_without_relabelling_prediction(self):
        monday=date(2026,10,12); days=[monday+timedelta(days=i) for i in range(5)]
        end=datetime.combine(days[-1],time(17),NY).astimezone(timezone.utc)
        review={'profile_label':'实际周三反转路径候选','candidates':[{'profile':'实际路径'}]}
        result=weekly_profile_lifecycle([],days,end,review)
        self.assertEqual(result['mode'],'closed_week_review')
        self.assertEqual(result['realized_candidates'],review['candidates'])
        self.assertEqual(result['candidates'],[])

    def test_closed_week_reason_uses_the_same_m5_coverage_as_its_shape(self):
        monday=date(2026,10,12);days=[monday+timedelta(days=i) for i in range(5)]
        end=datetime.combine(days[-1],time(17),NY).astimezone(timezone.utc)
        review={'profile_label':'周四极点价格路径候选',
                'candidates':[{'profile':'周四极点价格路径候选','reason':'周四范围外收盘；周五反向扩张。'}],
                'daily':[{'date':d.isoformat(),'ended':True,'coverage_complete':True} for d in days]}
        got=weekly_profile_lifecycle([],days,end,review)
        self.assertTrue(got['coverage_complete_under_study_calendar'])
        self.assertFalse(got['m15_coverage_complete_under_study_calendar'])
        self.assertEqual(got['coverage_source_period_minutes'],5)
        self.assertIn('周四范围外收盘',got['profile_reason'])
        review['daily'][2]['coverage_complete']=False
        self.assertIn('报价覆盖不完整',weekly_profile_lifecycle([],days,end,review)['profile_reason'])

    def test_closed_week_status_tracks_the_verified_price_path(self):
        monday=date(2026,10,12)
        days=[monday+timedelta(days=i) for i in range(5)]
        end=datetime.combine(days[-1],time(17),NY)
        card={'id':'weekly_tuesday_extreme','observed_sequence':True,'path_complete':True}
        review={'profile_label':'经典周二极点','candidates':[card],
                'daily':[{'date':d.isoformat(),'ended':True,'coverage_complete':True} for d in days]}
        got=weekly_profile_lifecycle([],days,end,review)
        self.assertEqual(got['profile_status'],'confirmed_path')
        self.assertTrue(got['final_week_extreme_known'])
        self.assertFalse(got['full_ict_profile_confirmed'])
        card.update(id='weekly_wednesday_unresolved',path_complete=False)
        self.assertEqual(weekly_profile_lifecycle([],days,end,review)['profile_status'],'closed_partial')
        review['daily'][1]['coverage_complete']=False
        got=weekly_profile_lifecycle([],days,end,review)
        self.assertEqual(got['profile_status'],'closed_insufficient_data')
        self.assertFalse(got['final_week_extreme_known'])

    def thursday_sequence(self,direct=False):
        monday=date(2026,10,12);days=[monday+timedelta(days=i) for i in range(5)]
        origin=datetime.combine(monday,time(0),NY).astimezone(timezone.utc)
        prices=[(100,105,95,100),(100,104,96,101),(101,104,96,100),
                (100,112,96,110) if direct else (100,103,90,92),(92,115,91,112)]
        rows=[Bar(origin+timedelta(days=i)+n*self.p,*price,.2)
              for i,price in enumerate(prices) for n in range(96)]
        return rows,days,origin

    def test_thursday_outside_close_is_pending_until_friday_not_invalid_by_itself(self):
        rows,days,origin=self.thursday_sequence();review={'profile_label':'待确认','candidates':[]}
        cutoff=origin+timedelta(days=4)
        result=weekly_profile_lifecycle(rows,days,cutoff,review)
        card=next(c for c in result['candidates'] if c['id']=='weekly_thursday_consolidation_reversal')
        self.assertEqual(card['phase'],'range_breach_awaiting_reclaim')
        self.assertEqual(card['status'],'active')
        self.assertFalse(card['thursday_same_day_reclaim_required'])
        after=weekly_profile_lifecycle(rows,days,cutoff+2*self.p,review)
        card=next(c for c in after['candidates'] if c['id']=='weekly_thursday_consolidation_reversal')
        self.assertEqual(card['phase'],'range_reclaimed_awaiting_expansion')
        self.assertFalse(after['final_week_extreme_known'])
        self.assertEqual(after,weekly_profile_lifecycle([b for b in rows if b.time+self.p<=cutoff+2*self.p],days,cutoff+2*self.p,review))

    def test_live_thursday_expansion_needs_frozen_early_consolidation(self):
        rows,days,origin=self.thursday_sequence(True);review={'profile_label':'待确认','candidates':[]}
        cutoff=origin+timedelta(days=3,hours=1)
        result=weekly_profile_lifecycle(rows,days,cutoff,review)
        card=next(c for c in result['candidates'] if c['id']=='weekly_consolidation_expansion')
        self.assertTrue(card['consolidation']['matched'])
        self.assertFalse(card['calendar_event_verified'])
        self.assertFalse(result['prior_bias_verified'])
        # A trend before Thursday is not rebranded as consolidation.
        changed=[]
        for b in rows:
            i=(b.time-origin).days
            if i<3:b=replace(b,open=80+i*10,high=84+i*10,low=76+i*10,close=82+i*10)
            changed.append(b)
        got=weekly_profile_lifecycle(changed,days,cutoff,review)
        self.assertFalse(any(c['id']=='weekly_consolidation_expansion' for c in got['candidates']))


if __name__=='__main__':unittest.main()
