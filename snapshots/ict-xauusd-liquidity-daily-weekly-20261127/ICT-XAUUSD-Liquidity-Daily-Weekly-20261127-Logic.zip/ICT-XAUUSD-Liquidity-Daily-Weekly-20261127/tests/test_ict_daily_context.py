import unittest
from dataclasses import replace
from datetime import date,datetime,time,timedelta,timezone

from brooks_ai.types import Bar
from ict_ai.daily_context import _QuoteIndex, _gap_state, _state, daily_weekly_context, M5
from ict_ai.timebase import NY


def local(day,hour=0,minute=0):
    return datetime.combine(day,time(hour,minute),NY).astimezone(timezone.utc)


def day_rows(day,high=105,low=95):
    count=203 if day.weekday()==4 else 288
    return [Bar(local(day)+i*M5,100,high,low,100,.1)
            for i in range(count) if not 204<=i<216]


def priced_day(day,opening,high,low,close):
    return [Bar(b.time,opening,high,low,close,.1) for b in day_rows(day)]


class DailyContextTests(unittest.TestCase):
    def setUp(self):
        self.monday=date(2026,10,5)
        self.days=[self.monday+timedelta(days=i) for i in range(3)]
        self.rows=sum([day_rows(d,h,l) for d,h,l in zip(self.days,[105,110,106],[95,90,94])],[])
        self.end=local(self.days[-1]+timedelta(days=1))

    def test_wait_for_right_daily_close(self):
        before=daily_weekly_context(self.rows,self.end-M5)
        self.assertEqual(before['frames']['D1']['confirmed_swings'],[])
        self.assertEqual(before['daily_coverage_checks'][-1]['status'],'in_progress')
        self.assertIsNone(before['daily_coverage_checks'][-1]['missing_bars'])
        ready=daily_weekly_context(self.rows,self.end)
        swings=ready['frames']['D1']['confirmed_swings']
        self.assertEqual([p['kind'] for p in swings],['H','L'])
        self.assertTrue(all(p['available_at']==self.end.isoformat() for p in swings))
        self.assertIsNone(ready['bias_value']);self.assertIsNone(ready['dol_value'])
        self.assertFalse(ready['execution_allowed'])
        self.assertEqual({p['price'] for p in ready['frames']['D1']['dol_candidates']},{90,110})
        self.assertTrue(all(not p['selected_as_dol'] and not p['qualified_target']
                            for p in ready['frames']['D1']['dol_candidates']))

    def test_observed_visit_removes_target_from_untouched_shortlist(self):
        future=Bar(self.end,100,112,99,100,.1)
        before=daily_weekly_context(self.rows+[future],self.end)
        after=daily_weekly_context(self.rows+[future],self.end+M5)
        self.assertIn(110,[p['price'] for p in before['frames']['D1']['dol_candidates']])
        self.assertNotIn(110,[p['price'] for p in after['frames']['D1']['dol_candidates']])
        high=next(p for p in after['frames']['D1']['confirmed_swings'] if p['kind']=='H')
        self.assertEqual(high['reclaim_known_at'],(self.end+M5).isoformat())

    def test_missing_slot_excludes_day_and_does_not_bridge_pivot(self):
        rows=[b for b in self.rows if b.time!=local(self.days[1],10)]
        result=daily_weekly_context(rows,self.end)
        self.assertEqual(len(result['frames']['D1']['periods']),2)
        self.assertEqual(result['frames']['D1']['confirmed_swings'],[])
        self.assertEqual(result['daily_coverage_checks'][1]['missing_bars'],1)

    def test_prefix_stability(self):
        for cutoff in [local(self.days[1]),self.end-M5,self.end]:
            prefix=[b for b in self.rows if b.time+M5<=cutoff]
            self.assertEqual(daily_weekly_context(self.rows,cutoff),daily_weekly_context(prefix,cutoff))

    def test_weekly_confirmation_and_missing_week_breaks_sequence(self):
        first=date(2026,9,14);rows=[]
        for week,high in enumerate([105,115,108]):
            for i in range(5):rows+=day_rows(first+timedelta(days=7*week+i),high)
        cutoff=local(first+timedelta(days=18),16,55)
        before=daily_weekly_context(rows,cutoff-M5)
        self.assertEqual(before['frames']['W1']['confirmed_swings'],[])
        result=daily_weekly_context(rows,cutoff)
        self.assertEqual(len(result['frames']['W1']['periods']),3)
        self.assertEqual(result['frames']['W1']['confirmed_swings'][0]['price'],115)
        missing=[b for b in rows if b.time!=local(first+timedelta(days=8),10)]
        self.assertEqual(daily_weekly_context(missing,cutoff)['frames']['W1']['confirmed_swings'],[])

    def test_dst_weekend_preserves_trading_day_adjacency(self):
        dates=[date(2026,10,30),date(2026,11,2),date(2026,11,3)]
        rows=sum([day_rows(d,h) for d,h in zip(dates,[105,110,106])],[])
        result=daily_weekly_context(rows,local(date(2026,11,4)))
        self.assertEqual(len(result['frames']['D1']['confirmed_swings']),1)
        self.assertTrue(result['frames']['D1']['confirmed_swings'][0]['available_at'].endswith('05:00:00+00:00'))

    def test_reclaim_not_invented_across_missing_quote(self):
        known=local(self.monday,10);level={'available_at':known.isoformat(),'kind':'H','price':110}
        rows=[Bar(known,111,112,111,111,.1),Bar(known+2*M5,100,102,99,100,.1)]
        state=_state(level,rows,known+3*M5)
        self.assertIsNotNone(state['excursion_known_at'])
        self.assertIsNone(state['touch_known_at']);self.assertIsNone(state['reclaim_known_at'])
        self.assertIsNone(state['not_revisited']);self.assertEqual(state['missing_expected_m5'],1)
        samebar=[Bar(known,109,112,108,109,.1)]
        self.assertIsNotNone(_state(level,samebar,known+M5)['reclaim_known_at'])

    def test_coverage_still_checks_slots_after_first_complete_sweep(self):
        known = local(self.monday, 10)
        level = {'available_at': known.isoformat(), 'kind': 'H', 'price': 110}
        rows = [Bar(known, 109, 112, 108, 109, .1), Bar(known + 2 * M5, 109, 110, 107, 108, .1)]
        result = _state(level, rows, known + 3 * M5)
        self.assertEqual(result['reclaim_known_at'], (known + M5).isoformat())
        self.assertEqual(result['missing_expected_m5'], 1)
        self.assertFalse(result['closed_slot_coverage_complete'])

    def test_shared_index_respects_an_earlier_partial_bar_cutoff(self):
        known = local(self.monday, 10)
        rows = [Bar(known, 100, 101, 99, 100, .1),
                Bar(known + 2 * M5, 105, 112, 99, 105, .1)]
        index = _QuoteIndex(known, known + 4 * M5, rows)
        earlier = known + 2 * M5 + timedelta(minutes=2)
        level = {'available_at': known.isoformat(), 'kind': 'H', 'price': 110}
        gap = {'available_at': known.isoformat(), 'direction': 'bearish',
               'timeframe': 'D1', 'lower': 108, 'upper': 110}
        for observe in (
            lambda **kwargs: _state(level, rows, earlier, **kwargs),
            lambda **kwargs: _gap_state(gap, rows, [], earlier, **kwargs),
        ):
            with self.subTest(observe=observe):
                result = observe(index=index)
                self.assertEqual(result, observe())
                self.assertIsNone(result['touch_known_at'])
                self.assertEqual(result['missing_expected_m5'], 1)

    def test_reject_unsorted_or_unaligned_input(self):
        with self.assertRaises(ValueError):daily_weekly_context(self.rows[::-1],self.end)
        with self.assertRaises(ValueError):daily_weekly_context([replace(self.rows[0],time=self.rows[0].time+timedelta(minutes=1))],self.end)

    def gap_rows(self):
        return (priced_day(self.days[0],100,105,95,101)
                +priced_day(self.days[1],102,115,95,112)
                +priced_day(self.days[2],110,118,108,112))

    def test_daily_fvg_waits_for_third_period_close(self):
        rows=self.gap_rows()
        self.assertEqual(daily_weekly_context(rows,self.end-M5)['frames']['D1']['fvg_candidates'],[])
        gap=daily_weekly_context(rows,self.end)['frames']['D1']['fvg_candidates'][0]
        self.assertEqual((gap['lower'],gap['upper'],gap['direction']),(105,108,'bullish'))
        self.assertEqual(gap['available_at'],self.end.isoformat());self.assertTrue(gap['untouched'])
        self.assertFalse(gap['trade_signal']);self.assertFalse(gap['qualified_pda'])

    def test_m5_contacts_are_separate_from_daily_close_invalidation(self):
        rows=self.gap_rows()+[Bar(self.end,109,110,107,109,.1),
                              Bar(self.end+M5,108,109,106,107,.1),
                              Bar(self.end+2*M5,107,108,105,106,.1)]
        gap=daily_weekly_context(rows,self.end+3*M5)['frames']['D1']['fvg_candidates'][0]
        self.assertEqual(gap['touch_known_at'],(self.end+M5).isoformat())
        self.assertEqual(gap['ce_known_at'],(self.end+2*M5).isoformat())
        self.assertEqual(gap['full_mitigation_known_at'],(self.end+3*M5).isoformat())
        self.assertIsNone(gap['close_invalidation_known_at'])
        following=priced_day(self.days[-1]+timedelta(days=1),104,110,100,104)
        intraday=daily_weekly_context(self.gap_rows()+following,self.end+M5)['frames']['D1']['fvg_candidates'][0]
        self.assertIsNone(intraday['close_invalidation_known_at'])
        after=daily_weekly_context(self.gap_rows()+following,self.end+timedelta(days=1))['frames']['D1']['fvg_candidates'][0]
        self.assertEqual(after['state'],'close_invalidated')
        self.assertEqual(after['close_invalidation_known_at'],(self.end+timedelta(days=1)).isoformat())

    def test_jump_beyond_gap_does_not_prove_far_edge_contact(self):
        future=Bar(self.end,100,102,99,101,.1)
        gap=daily_weekly_context(self.gap_rows()+[future],self.end+M5)['frames']['D1']['fvg_candidates'][0]
        self.assertIsNone(gap['touch_known_at']);self.assertIsNone(gap['full_mitigation_known_at'])
        self.assertIsNone(gap['untouched']);self.assertEqual(gap['state'],'unknown')

    def test_missing_quote_makes_fvg_untouched_unknown(self):
        rows=self.gap_rows()+[Bar(self.end+M5,112,114,110,113,.1)]
        gap=daily_weekly_context(rows,self.end+2*M5)['frames']['D1']['fvg_candidates'][0]
        self.assertEqual(gap['missing_expected_m5'],1);self.assertIsNone(gap['untouched'])
        missing=[b for b in self.gap_rows() if b.time!=local(self.days[1],10)]
        self.assertEqual(daily_weekly_context(missing,self.end)['frames']['D1']['fvg_candidates'],[])

    def test_fvg_state_prefix_stability(self):
        rows=self.gap_rows()+priced_day(self.days[-1]+timedelta(days=1),104,110,100,104)
        for at in [self.end-M5,self.end,self.end+M5,self.end+timedelta(days=1)]:
            self.assertEqual(daily_weekly_context(rows,at),daily_weekly_context([b for b in rows if b.time+M5<=at],at))

    def test_bearish_weekly_gap_uses_weekly_close(self):
        known=local(self.monday,10)
        gap={'available_at':known.isoformat(),'lower':102,'upper':105,'direction':'bearish','timeframe':'W1'}
        quotes=[Bar(known,100,103,99,102,.1),Bar(known+M5,104,105,103,104,.1)]
        periods=[{'start':known.isoformat(),'available_at':(known+2*M5).isoformat(),'close':104}]
        state=_gap_state(gap,quotes,periods,known+2*M5)
        self.assertEqual(state['full_mitigation_known_at'],(known+2*M5).isoformat())
        self.assertIsNone(state['close_invalidation_known_at'])
        self.assertEqual(state['invalidation_timeframe'],'W1')

    def test_weekly_fvg_requires_three_complete_consecutive_weeks(self):
        first=date(2026,9,14);rows=[]
        for week,prices in enumerate([(100,105,95,101),(102,115,95,112),(110,118,108,112)]):
            for i in range(5):rows+=priced_day(first+timedelta(days=7*week+i),*prices)
        end=local(first+timedelta(days=18),16,55)
        self.assertEqual(daily_weekly_context(rows,end-M5)['frames']['W1']['fvg_candidates'],[])
        gap=daily_weekly_context(rows,end)['frames']['W1']['fvg_candidates'][0]
        self.assertEqual((gap['timeframe'],gap['lower'],gap['upper']),('W1',105,108))
        self.assertEqual(gap['available_at'],end.isoformat())
        missing=[b for b in rows if b.time!=local(first+timedelta(days=8),10)]
        self.assertEqual(daily_weekly_context(missing,end)['frames']['W1']['fvg_candidates'],[])


if __name__=='__main__':unittest.main()
