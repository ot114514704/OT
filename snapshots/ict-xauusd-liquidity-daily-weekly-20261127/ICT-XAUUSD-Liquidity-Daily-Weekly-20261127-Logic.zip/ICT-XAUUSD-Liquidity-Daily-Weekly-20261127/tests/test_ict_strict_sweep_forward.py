import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import patch

from scripts.audit_ict_strict_sweep_forward import compare_pair
from scripts import ict_liquidity_window_preselection as preselection


class StrictSweepForwardTests(TestCase):
    def test_check_hit_and_abstention_only_for_identical_directional_outcomes(self):
        legacy = dict(quotes=[[1, 100]], state2=dict(status='sweep'))
        strict = dict(quotes=[[1, 100]], state2=dict(status='candidate'))
        settled = dict(quotes=[[1, 100], [2, 99]], label='sweep')
        paired = compare_pair((legacy, settled), (strict, settled))
        self.assertEqual(paired['stage'], 'settled_directional')
        self.assertTrue(paired['changed'])
        self.assertTrue(paired['legacy_match'])
        self.assertFalse(paired['strict_match'])

        mixed = dict(settled, label='mixed')
        self.assertNotIn('strict_match', compare_pair((legacy, mixed), (strict, mixed)))

    def test_quote_revisions_are_excluded_at_either_stage(self):
        known = dict(quotes=[[1, 100]], state2=dict(status='break'))
        revised = dict(known, quotes=[[1, 101]])
        settled = dict(quotes=[[1, 100], [2, 102]], label='break')
        changed = dict(settled, quotes=[[1, 100], [2, 103]])
        self.assertEqual(compare_pair((known, None), (revised, None))['stage'], 'different_decision_quotes')
        self.assertEqual(compare_pair((known, settled), (known, changed))['stage'], 'different_settlement_evidence')
        self.assertEqual(compare_pair((known, settled), (known, None))['stage'], 'awaiting_settlement')

    def test_preview_only_exposes_the_version_available_at_the_snapshot(self):
        cutoff = datetime(2026, 11, 26, 15, 40, tzinfo=timezone.utc)
        event_cutoff = (cutoff - timedelta(minutes=20)).isoformat()
        event = dict(cutoff=event_cutoff, scope='IRL', side=1, edge=100)
        policy = dict(frozen_at=event_cutoff)
        with TemporaryDirectory() as tmp:
            old, new = Path(tmp) / 'old', Path(tmp) / 'new'
            for scope, delay in ((old, 2), (new, 10)):
                for path, content in (
                    ('policy.json', policy), ('events/abc.json', event),
                    ('decisions/abc_15.json', dict(cutoff=cutoff.isoformat(), v7b=dict(status='pending'),
                                                   state2=dict(status='candidate'), structure={})),
                    ('receipts/abc_15.json', dict(available_at=(cutoff + timedelta(seconds=delay)).isoformat())),
                ):
                    target = scope / path
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_text(json.dumps(content), encoding='utf-8')
            audit = preselection.sweep_audit
            with patch.multiple(audit, LEGACY=old, STRICT=new), patch.object(audit, 'verify_cohort', return_value=policy):
                at_five = preselection.registered_responses(cutoff + timedelta(seconds=5))
                at_ten = preselection.registered_responses(cutoff + timedelta(seconds=10))
            identity = event_cutoff, 'IRL', 1, 100
            self.assertEqual(at_five[identity]['15']['v7b'], 'pending')
            self.assertNotIn('neutral_edge', at_five[identity]['15'])
            self.assertEqual(at_ten[identity]['15']['neutral_edge']['state'], 'candidate')
