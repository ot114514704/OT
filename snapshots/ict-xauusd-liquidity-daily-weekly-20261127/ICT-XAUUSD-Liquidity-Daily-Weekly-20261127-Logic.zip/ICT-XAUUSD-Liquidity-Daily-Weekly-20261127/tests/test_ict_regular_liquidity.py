import unittest
from dataclasses import replace
from datetime import date,datetime,time,timedelta,timezone
from brooks_ai.types import Bar
from ict_ai.timebase import NY
from ict_ai.regular_liquidity import regular_liquidity,weekly_stage_liquidity,M5,M15


def local(d):return datetime.combine(d,time(0),NY).astimezone(timezone.utc)


def day_rows(d):
    return [Bar(local(d)+i*M5,100,103,97,100,0) for i in range(203 if d.weekday()==4 else 288) if not 204<=i<216]


class RegularLiquidityTests(unittest.TestCase):
    def test_equal_high_low_need_second_confirmed_pivot(self):
        d=date(2026,10,13);start=local(d)
        bars=[Bar(start+i*M15,100,102,98,100,0) for i in range(11)]
        for i,h,l in [(1,105,98),(3,102,95),(5,105.02,98),(7,102,95.01)]:bars[i]=replace(bars[i],high=h,low=l)
        m5=[replace(b,time=b.time+j*M5) for b in bars for j in range(3)]
        ref={'range':{'id':'fixture-range','low':90,'high':110,'available_at':start.isoformat()}}
        early=regular_liquidity(bars,m5,d,start+6*M15,ref)
        self.assertFalse(any(e['kind']=='EQH' for e in early['levels']))
        later=regular_liquidity(bars,m5,d,start+9*M15,ref)
        self.assertTrue({'EQH','EQL'}<={e['kind'] for e in later['levels']})
        self.assertTrue(all(e['classification']=='IRL' for e in later['levels']))
        for at in (start+6*M15,start+9*M15):
            prefix=regular_liquidity([b for b in bars if b.time+M15<=at],[b for b in m5 if b.time+M5<=at],d,at,ref)
            self.assertEqual(prefix,regular_liquidity(bars,m5,d,at,ref))
        self.assertTrue(all(e['nature']=='待判定' for e in later['levels']))

    def test_week_to_date_edges_are_frozen_before_a_later_sweep(self):
        monday=date(2026,10,12);dates=[monday+timedelta(days=i) for i in range(5)]
        tue=local(dates[1]);rows=day_rows(monday)+[Bar(tue,100,105,99,104,0),Bar(tue+M5,104,106,102,103,0)]
        before=weekly_stage_liquidity(rows,dates,tue)
        self.assertEqual(len(before['levels']),2)
        self.assertTrue(all(e['sweep_known_at'] is None for e in before['levels']))
        known=weekly_stage_liquidity(rows,dates,tue+M5)
        high=next(e for e in known['levels'] if e['kind']=='BSL')
        self.assertEqual(high['available_at'],tue.isoformat())
        self.assertEqual(high['sweep_known_at'],(tue+M5).isoformat())
        self.assertEqual(high['source_timeframe'],'W1_stage')
        self.assertEqual(high['crossing_state']['crossed_at'],high['sweep_known_at'])
        self.assertEqual(known,weekly_stage_liquidity(rows[:-1],dates,tue+M5))

    def test_gap_over_week_stage_edge_is_not_an_observed_sweep(self):
        monday=date(2026,10,12);dates=[monday+timedelta(days=i) for i in range(5)];tue=local(dates[1])
        rows=day_rows(monday)+[Bar(tue,104,106,104,105,0)]
        result=weekly_stage_liquidity(rows,dates,tue+M5)
        high=next(e for e in result['levels'] if e['kind']=='BSL')
        self.assertIsNone(high['sweep_known_at'])

    def test_first_reclaim_keeps_later_crossing_state_changes(self):
        monday = date(2026, 10, 12)
        dates = [monday + timedelta(days=i) for i in range(5)]
        cutoff = local(dates[1])
        follow = [Bar(cutoff, 100, 105, 99, 102, 0),
                  Bar(cutoff + M5, 102, 104, 101, 103.5, 0),
                  Bar(cutoff + 2 * M5, 103.5, 105, 103, 104, 0),
                  Bar(cutoff + 3 * M5, 104, 106, 104, 105, 0)]
        result = weekly_stage_liquidity(day_rows(monday) + follow, dates, cutoff + 4 * M5)
        high = next(level for level in result['levels'] if level['kind'] == 'BSL')
        self.assertEqual(high['reclaim_known_at'], (cutoff + M5).isoformat())
        self.assertEqual(high['crossing_state']['status'], 'break')
        self.assertEqual(high['crossing_state']['strength'], 2)

    def test_missing_reference_quote_cannot_freeze_a_week_stage_range(self):
        monday=date(2026,10,12);dates=[monday+timedelta(days=i) for i in range(5)]
        result=weekly_stage_liquidity(day_rows(monday)[1:]+day_rows(dates[1]),dates,local(dates[2]))
        self.assertEqual(result['levels'],[])
        self.assertEqual(result['reference_checks'][0]['missing_bars'],1)


if __name__=='__main__':unittest.main()
