import unittest
from datetime import date,datetime,timezone
from zoneinfo import ZoneInfo
from ict_ai.silver_bullet import silver_bullet_windows,silver_time_filter
from ict_ai.timebase import NY


class SilverBulletTests(unittest.TestCase):
    def test_course_three_windows_and_dst(self):
        summer=silver_bullet_windows(date(2026,10,13))
        winter=silver_bullet_windows(date(2026,12,14))
        self.assertEqual([w['ny_time'] for w in summer],['03:00–04:00','10:00–11:00','14:00–15:00'])
        self.assertEqual(datetime.fromtimestamp(summer[0]['start_ms']/1000,timezone.utc).hour,7)
        self.assertEqual(datetime.fromtimestamp(winter[0]['start_ms']/1000,timezone.utc).hour,8)

    def test_london_window_during_uk_us_clock_change_gap(self):
        london = ZoneInfo("Europe/London")
        beijing = ZoneInfo("Asia/Shanghai")
        cases = [
            (date(2026, 10, 23), 8, 15),
            (date(2026, 10, 26), 7, 15),
            (date(2026, 10, 30), 7, 15),
            (date(2026, 11, 2), 8, 16),
        ]
        for day, london_hour, beijing_hour in cases:
            with self.subTest(day=day):
                window = next(w for w in silver_bullet_windows(day) if w["id"] == "london")
                start = datetime.fromtimestamp(window["start_ms"] / 1000, NY)
                end = datetime.fromtimestamp(window["end_ms"] / 1000, NY)
                self.assertEqual(start, datetime(day.year, day.month, day.day, 3, tzinfo=NY))
                self.assertEqual((end - start).total_seconds(), 3600)
                self.assertEqual(start.astimezone(london).hour, london_hour)
                self.assertEqual(start.astimezone(beijing).hour, beijing_hour)

    def test_trigger_boundary_not_formation_time(self):
        a=datetime(2026,10,13,10,tzinfo=NY)
        end=datetime(2026,10,13,11,tzinfo=NY)
        self.assertTrue(silver_time_filter(a)['is_silver_time'])
        self.assertFalse(silver_time_filter(end)['is_silver_time'])
        self.assertFalse(silver_time_filter(a)['execution_allowed'])
        self.assertEqual(silver_bullet_windows(date(2026,10,17)),[])


if __name__=='__main__':unittest.main()
