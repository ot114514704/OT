from datetime import datetime, timedelta, timezone
import unittest

from scripts.audit_ict_amd_structure import evidence


class AMDStructureContextTests(unittest.TestCase):
    def setUp(self):
        self.sweep = datetime(2026,6,1,13,tzinfo=timezone.utc)
        self.decision = self.sweep+timedelta(minutes=45)
        self.signal = dict(a_known=(self.sweep-timedelta(hours=2)).isoformat(), m_known=self.sweep.isoformat(),
                           d_confirm=self.decision.isoformat(), direction=1)

    def evaluate(self, rows):
        events = [dict(kind=kind,known=(self.sweep+timedelta(minutes=offset)).timestamp(),
                       direction=side,strong=strong,tier=tier) for kind,offset,side,strong,tier in rows]
        return evidence(self.signal,events,[e['known'] for e in events])

    def test_excludes_sweep_bar_and_future_but_includes_decision_bar(self):
        state = self.evaluate([('BOS',0,1,True,'IT'),('CISD',45,1,False,'ST'),('BOS',60,1,True,'IT')])
        self.assertFalse(state['gates']['structure_agrees'])
        self.assertTrue(state['gates']['cisd_agrees'])

    def test_later_opposite_structure_supersedes_earlier_strong_marker(self):
        state = self.evaluate([('BOS',15,1,True,'IT'),('CHoCH',30,-1,False,'ST'),('CISD',45,1,False,'ST')])
        self.assertEqual(state['structure_direction'],-1)
        self.assertFalse(state['gates']['strong_structure_agrees'])
        self.assertTrue(state['gates']['cisd_agrees'])

    def test_simultaneous_conflicting_tiers_stay_unresolved(self):
        state = self.evaluate([('BOS',45,1,True,'ST'),('CHoCH',45,-1,True,'LT')])
        self.assertIsNone(state['structure_direction'])
        self.assertEqual(len(state['latest_breaks']),2)
        self.assertFalse(state['gates']['structure_agrees'])

    def test_same_bar_break_is_not_counted_as_earlier_confirmation(self):
        state = self.evaluate([('BOS',45,1,False,'ST')])
        self.assertTrue(state['gates']['structure_agrees'])
        self.assertFalse(state['gates']['structure_already_aligned'])
        state = self.evaluate([('CHoCH',15,1,True,'ST'),('BOS',45,1,False,'ST')])
        self.assertTrue(state['gates']['structure_already_aligned'])
        self.assertFalse(state['gates']['strong_structure_agrees'])
