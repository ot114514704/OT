from datetime import date, timedelta
import unittest

from brooks_ai.types import Bar
from ict_ai.profile_lifecycle import _day_bounds
from ict_ai.weekly_close_candidates import friday_expansion_watch


class FridayRangeWatchTests(unittest.TestCase):
    def setUp(self):
        self.days = [date(2026, 6, 1)+timedelta(days=i) for i in range(5)]
        self.friday = _day_bounds(self.days[-1])[0]
        self.period = timedelta(minutes=15)
        self.realized = dict(daily=[dict(date=d.isoformat(), ended=True, coverage_complete=True,
                                         high=110, low=90) for d in self.days[:4]])

    def watch(self, values, periods, covered=True):
        bars = [Bar(self.friday+n*self.period, 100, max(price, 101), min(price, 99), price, 0)
                for n, price in values]
        return friday_expansion_watch(self.realized, bars, self.days,
                                      self.friday+periods*self.period, covered)

    def test_requires_two_observed_consecutive_closes_and_drops_direction_inside(self):
        prices = [(0, 112), (1, 113), (2, 108)]
        self.assertEqual(self.watch(prices, 1)['status'], 'awaiting_friday_expansion')
        self.assertEqual(self.watch(prices, 2)['direction'], 1)
        self.assertEqual(self.watch(prices, 3)['status'], 'breakout_back_inside')
        self.assertIsNone(self.watch(prices, 3)['direction'])
        self.assertEqual(self.watch([(0, 112), (2, 113)], 3)['status'], 'awaiting_friday_expansion')

    def test_does_not_supply_a_direction_after_both_sides_broke(self):
        watch = self.watch([(0, 112), (1, 113), (2, 88), (3, 87)], 4)
        self.assertEqual(watch['status'], 'two_sided_breakout')
        self.assertIsNone(watch['direction'])
        self.assertFalse(watch['execution_allowed'])

    def test_needs_full_source_days_and_live_coverage(self):
        self.assertIsNone(self.watch([], 0, covered=False))
        self.realized['daily'][0]['coverage_complete'] = False
        self.assertIsNone(self.watch([], 0))
