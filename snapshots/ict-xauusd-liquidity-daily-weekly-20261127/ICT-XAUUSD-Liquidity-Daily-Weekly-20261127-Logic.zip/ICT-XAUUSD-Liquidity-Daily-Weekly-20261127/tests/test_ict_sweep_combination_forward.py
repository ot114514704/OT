from datetime import datetime, timezone
from unittest import TestCase

from brooks_ai.types import Bar
from scripts import watch_ict_sweep_combination as watch


class SweepCombinationForwardTests(TestCase):
    def setUp(self):
        self.cross = datetime(2026,11,24,16,tzinfo=timezone.utc)
        self.m5 = watch.M5
        self.known = self.cross+self.m5
        self.cutoff = self.known+watch.DECISION
        self.bars = [self.bar(i,100,101,99,100) for i in range(-24,19)]
        self.bars[24] = self.bar(0,100,104,97,99)
        self.times = [b.time for b in self.bars]

    def bar(self,i,open_,high,low,close):
        return Bar(self.cross+i*self.m5,open_,high,low,close,0)

    def test_record_only_between_cutoff_and_first_followup_close(self):
        key = self.known,1,102
        self.assertIsNone(watch.decision(key,self.bars,self.times,self.cutoff-self.m5))
        self.assertIsNone(watch.decision(key,self.bars,self.times,self.cutoff+self.m5))
        first = watch.decision(key,self.bars,self.times,self.cutoff)
        self.assertEqual(first['verdicts']['v7b'],'sweep')
        shortened = watch.decision(key,self.bars[:-6],self.times[:-6],self.cutoff)
        self.assertEqual(first,shortened)
        self.assertEqual(watch.independently_grade(first,self.bars,self.times)[0],'sweep')
        self.assertEqual(watch.independently_grade(first,self.bars[:-1],self.times[:-1])[0],'incomplete')

    def test_receipt_eligibility_controls_live_crossing(self):
        at = self.cross-self.m5
        target = dict(side=1,lo=101,hi=102)
        record = dict(cutoff=at.isoformat(),eligible_from=self.cross.isoformat(),price=100,pools={
            'short/IRL':dict(deadline=self.cutoff.isoformat(),targets=[target],
                             layers={'current_top10':[0],'distance':[0]})})
        hits = watch.crossings(record,self.bars,self.times,self.known)
        self.assertEqual(hits[(self.known,1,102)],{'short/IRL/current_top10','short/IRL/distance'})
        record['eligible_from'] = self.known.isoformat()
        self.assertEqual(watch.crossings(record,self.bars,self.times,self.cutoff),{})
