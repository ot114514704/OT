from datetime import datetime, timedelta, timezone
from unittest import TestCase

from scripts.watch_ict_micro_liquidity_forward import grade


START = datetime(2026, 11, 24, 15, tzinfo=timezone.utc)


def witness(ticks):
    bids = [bid for _, bid in ticks]
    return dict(open_utc=START.isoformat(), ohlc=[bids[0], max(bids), min(bids), bids[-1]], bid_offsets=ticks)


class MicroLiquidityForwardTests(TestCase):
    def setUp(self):
        board = dict(IRL=[dict(side=1, lo=100, hi=101)], ERL=[])
        self.raw = dict(cutoff=START.isoformat(), baseline=board, early=board)

    def status(self, ticks, ready):
        result = grade(self.raw, START + timedelta(milliseconds=ready), [witness(ticks)], 1)
        return result['outcomes']['early']['IRL'][0]['status']

    def test_first_crossing_cannot_count_again_after_registration(self):
        self.assertEqual(self.status([[1, 100], [100, 102], [800, 100], [900, 102]], 200), 'before_board')
        self.assertEqual(self.status([[1, 100], [200, 102], [900, 101]], 200), 'before_board')
        self.assertEqual(self.status([[1, 100], [201, 102], [900, 101]], 200), 'sweep')

    def test_gap_or_absent_post_registration_window_does_not_count(self):
        self.assertEqual(self.status([[201, 102], [900, 103]], 200), 'gap_over')
        result = grade(self.raw, START + timedelta(milliseconds=950), [witness([[1, 100], [900, 101]])], 1)
        self.assertEqual(result['state'], 'no_post_registration_quote')

    def test_missing_data_and_late_registration_stay_unscored(self):
        self.assertEqual(grade(self.raw, START, [], 1)['state'], 'incomplete')
        self.assertEqual(grade(self.raw, START + timedelta(minutes=5), [], 1)['state'], 'too_late')
