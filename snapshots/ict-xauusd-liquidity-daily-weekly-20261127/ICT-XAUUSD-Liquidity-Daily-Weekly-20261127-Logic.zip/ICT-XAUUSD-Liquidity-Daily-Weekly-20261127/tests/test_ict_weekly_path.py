import unittest
from datetime import date, datetime, timedelta, timezone
from brooks_ai.types import Bar
from ict_ai.timebase import NY
from ict_ai.weekly_path import weekly_path, _profile_candidates


class WeeklyPathTests(unittest.TestCase):
    def test_chronology_and_future_extreme_exclusion(self):
        start=datetime(2026,10,12,0,tzinfo=NY).astimezone(timezone.utc)
        p=timedelta(minutes=5)
        bars=[Bar(start,100,101,99,100,0),Bar(start+p,100,105,100,104,0),
              Bar(start+2*p,104,104,90,91,0)]
        days=[date(2026,10,d) for d in range(12,17)]
        before=weekly_path(bars,days,start+2*p)
        truncated=weekly_path(bars[:2],days,start+2*p)
        self.assertEqual(before,truncated)
        self.assertEqual([d['kind'] for d in before['points']],['L','H'])
        self.assertEqual(min(d['price'] for d in before['points']),99)
        self.assertTrue(all(d['provisional'] for d in before['points']))
        self.assertEqual(len(before['daily']),1)

    def test_same_bar_extremes_do_not_invent_order(self):
        start=datetime(2026,10,12,0,tzinfo=NY).astimezone(timezone.utc)
        result=weekly_path([Bar(start,100,110,90,101,0)],
                           [date(2026,10,d) for d in range(12,17)],start+timedelta(minutes=5))
        self.assertEqual(result['points'],[])
        self.assertEqual(result['ambiguous_days'],['2026-10-12'])

    def test_previous_range_return_requires_closed_bar_and_complete_reference(self):
        start=datetime(2026,10,12,0,tzinfo=NY).astimezone(timezone.utc)
        p=timedelta(minutes=5)
        bars=[Bar(start+i*p,100,110,90,100,0) for i in range(288) if not 204<=i<216]
        tue=start+timedelta(days=1)
        bars+=[Bar(tue,100,115,98,112,0),Bar(tue+p,112,113,100,105,0)]
        days=[date(2026,10,d) for d in range(12,17)]
        self.assertEqual(weekly_path(bars,days,tue+p)['sweeps'],[])
        result=weekly_path(bars,days,tue+2*p)
        self.assertEqual(result['sweeps'][0]['kind'],'BSL')
        self.assertEqual(result['sweeps'][0]['reference_price'],110)
        self.assertEqual(result['sweeps'][0]['available_at'],(tue+2*p).isoformat())
        self.assertEqual(weekly_path(bars[1:],days,tue+2*p)['sweeps'],[])

    def test_weekday_alone_cannot_classify_midweek_reversal(self):
        ds=[{'date':f'2026-10-0{i+5}','open':100,'close':100,
             'high':110,'low':90 if i!=2 else 80,'ended':True} for i in range(5)]
        days=[date(2026,10,d) for d in range(5,10)]
        result=_profile_candidates(ds,days,datetime(2026,10,10,tzinfo=timezone.utc))
        # A midweek excursion is now retained as an observed partial path;
        # absence of later follow-through still prevents a six-class label.
        self.assertTrue(any('未归类' in item['profile'] for item in result))
        self.assertTrue(any(item.get('observed_sequence') and item.get('path_complete') is False for item in result))


if __name__=='__main__':unittest.main()
