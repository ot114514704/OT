from datetime import datetime, timezone
from unittest import TestCase

from brooks_ai.types import Bar
from ict_ai.sweep_state_strict import STEP, WINDOW, crossing_state


START = datetime(2026, 11, 20, 15, tzinfo=timezone.utc)


def bars(closes, side):
    previous = -0.2
    result = []
    for offset, close in enumerate(closes):
        opened, closed = 100 + side * previous, 100 + side * close
        result.append(Bar(START + offset * STEP, opened, max(opened, closed) + 0.1,
                          min(opened, closed) - 0.1, closed, 0))
        previous = close
    return result


class SweepStateTests(TestCase):
    def test_close_at_level_is_neutral_on_both_sides(self):
        for side in (1, -1):
            tape = bars([0, 0.4, 0.5, 0, 0.9, -0.4], side)
            early = crossing_state(side, 100, tape[0], tape[1:], START + 5 * STEP, 1)
            self.assertEqual((early['status'], early['changes']), ('candidate', []))
            confirmed = crossing_state(side, 100, tape[0], tape[1:], START + 6 * STEP, 1)
            self.assertEqual(confirmed['status'], 'sweep')
            self.assertEqual(confirmed['changes'][0]['known_at'], (START + 6 * STEP).isoformat())

            tape = bars([0.4, 0.6, 0.7, 0], side)
            held = crossing_state(side, 100, tape[0], tape[1:], START + 4 * STEP, 1)
            self.assertEqual(held['status'], 'break')
            self.assertEqual(len(held['changes']), 1)

    def test_four_outside_can_flip_to_engulf_without_backdating(self):
        for side in (1, -1):
            tape = bars([0.4, 0.6, 0.7, 0.8, -2.01, -3.1, 2.0], side)
            final = crossing_state(side, 100, tape[0], tape[1:], START + 7 * STEP, 1)
            self.assertEqual([(row['status'], row['evidence'], row['known_at']) for row in final['changes']], [
                ('break', 'three_outside', (START + 3 * STEP).isoformat()),
                ('sweep', 'engulf', (START + 5 * STEP).isoformat()),
                ('sweep', 'reclaim', (START + 6 * STEP).isoformat()),
            ])
            self.assertEqual((final['end_reason'], final['ended_at']), ('inside', (START + 6 * STEP).isoformat()))
            for count in range(1, 8):
                at = START + count * STEP
                prefix = crossing_state(side, 100, tape[0], tape[1:count], at, 1)
                self.assertEqual(prefix, crossing_state(side, 100, tape[0], tape[1:], at, 1))
                self.assertEqual(prefix['changes'], [row for row in final['changes'] if row['known_at'] <= at.isoformat()])

    def test_gap_is_neither_a_confirmation_nor_a_window_end(self):
        tape = bars([0.6, 0.7, -3.1], 1)
        result = crossing_state(1, 100, tape[0], tape[2:], START + 3 * STEP, 1)
        self.assertEqual((result['status'], result['end_reason'], result['ended_at']), ('candidate', 'gap', None))
        self.assertEqual(result['changes'], [])
        missing_atr = crossing_state(1, 100, tape[0], tape[1:], START + 3 * STEP, None)
        self.assertEqual(missing_atr['end_reason'], 'missing_prior')

    def test_window_ends_only_after_last_bar_closes(self):
        tape = bars([0.2] * (WINDOW + 1), 1)
        early = crossing_state(1, 100, tape[0], tape[1:], START + WINDOW * STEP, 1)
        done = crossing_state(1, 100, tape[0], tape[1:], START + (WINDOW + 1) * STEP, 1)
        self.assertEqual(early['end_reason'], 'observing')
        self.assertEqual((done['end_reason'], done['ended_at']), ('window', (START + (WINDOW + 1) * STEP).isoformat()))
