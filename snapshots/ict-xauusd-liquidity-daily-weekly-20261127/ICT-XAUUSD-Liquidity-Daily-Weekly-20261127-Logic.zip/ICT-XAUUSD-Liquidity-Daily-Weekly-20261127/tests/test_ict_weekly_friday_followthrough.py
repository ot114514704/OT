from datetime import date, timedelta
from unittest import TestCase

from brooks_ai.types import Bar
from ict_ai.profile_lifecycle import _day_bounds
from ict_ai.weekly_friday_followthrough import CONTINUATION, PERIOD, REVERSAL, friday_followthrough


class WeeklyFridayFollowthroughTests(TestCase):
    def setUp(self):
        self.days = [date(2026, 6, 1) + timedelta(days=index) for index in range(5)]
        self.friday = _day_bounds(self.days[-1])[0]
        self.realized = {"daily": [
            {"date": day.isoformat(), "ended": True, "coverage_complete": True,
             "high": 110, "low": 90, "close": 100}
            for day in self.days[:4]
        ]}

    def check(self, bars, periods):
        tape = [Bar(self.friday + index * PERIOD, close, high, low, close, 0)
                for index, (high, low, close) in enumerate(bars)]
        return friday_followthrough(self.realized, tape, self.days, self.friday + periods * PERIOD, True)

    def test_thursday_breakout_requires_a_new_friday_extreme_and_two_closed_bars(self):
        self.realized["daily"][-1].update(high=120, low=94, close=115)
        bars = [(118, 112, 115), (119, 113, 116), (121, 114, 117)]
        card = next(card for card in self.check(bars, 2) if card["variant"] == CONTINUATION)
        self.assertEqual(card["status"], "awaiting_friday_delivery")
        card = next(card for card in self.check(bars, 3) if card["variant"] == CONTINUATION)
        self.assertEqual(card["status"], "observed_candidate")
        self.assertIsNotNone(card["new_extreme_known_ny"])

    def test_thursday_can_close_outside_and_friday_reversal_can_be_revoked(self):
        self.realized["daily"][-1].update(high=105, low=80, close=84)
        bars = [(114, 82, 112), (116, 97, 114), (115, 79, 110)]
        card = next(card for card in self.check(bars, 2) if card["id"] == REVERSAL)
        self.assertEqual(card["status"], "observed_candidate")
        card = next(card for card in self.check(bars, 3) if card["id"] == REVERSAL)
        self.assertEqual(card["status"], "thursday_extreme_broken")
        self.assertFalse(card["execution_allowed"])
