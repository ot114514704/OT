"""Regression cases independently identified in the profile lifecycle review.

These verify only observed-price hypothesis integrity, not source-theory validity
or trading performance. Weekday fixtures include the permitted NY 17–18 recess.
"""
from dataclasses import replace
from datetime import date, datetime, time, timedelta, timezone
import unittest

from brooks_ai.types import Bar
from ict_ai.profile_lifecycle import daily_profile_lifecycle, weekly_profile_lifecycle
from ict_ai.timebase import NY, session_windows


class ProfileCausalityReviewTests(unittest.TestCase):
    period = timedelta(minutes=15)
    monday = date(2026, 10, 12)
    day = date(2026, 10, 13)

    @staticmethod
    def at(day, hour=0, minute=0):
        return datetime.combine(day, time(hour, minute), NY).astimezone(timezone.utc)

    @staticmethod
    def active(cards):
        # Permit implementation naming while requiring explicit demotion.
        return [c for c in cards if c.get('status', c.get('state', 'active'))
                not in ('invalidated', 'insufficient_data')]

    def daily_rows(self):
        start = self.at(self.day)
        end = self.at(self.day + timedelta(days=1))
        asia = session_windows(self.day)['asia'][0]
        rows = []
        for i in range(int((end - asia) / self.period)):
            stamp = asia + i * self.period
            local = stamp.astimezone(NY)
            if local.date() == self.day and local.hour == 17:
                continue
            bar = Bar(stamp, 100, 101, 99, 100, .2)
            if local.date() == self.day and local.hour == 2:
                bar = replace(bar, low=98)
            if stamp == start + timedelta(hours=4, minutes=45):
                bar = replace(bar, high=102, close=101)
            if stamp >= start + timedelta(hours=7):
                bar = replace(bar, open=103, high=104, low=102.5, close=103)
            rows.append(bar)
        return rows

    def weekly_rows(self):
        origin = self.at(self.monday)
        rows = []
        for i in range(96 * 5):
            stamp = origin + i * self.period
            local = stamp.astimezone(NY)
            if local.hour == 17 or (local.weekday() == 4 and local.hour >= 17):
                continue
            rows.append(Bar(stamp, 100, 101, 99, 100, .2))
        return rows

    def weekly(self, rows, cutoff):
        days = [self.monday + timedelta(days=i) for i in range(5)]
        return weekly_profile_lifecycle(rows, days, cutoff,
                                        {'profile_label': 'closed-review placeholder', 'candidates': []})

    def test_later_new_low_demotes_classic_london_extreme(self):
        """London low 98 is superseded by NY low 90; do not confirm both forms."""
        when = self.at(self.day, 8)
        rows = [replace(b, open=100, low=90, close=100) if b.time == when else b
                for b in self.daily_rows()]
        final = daily_profile_lifecycle(rows, self.day, self.at(self.day + timedelta(days=1)))
        self.assertNotIn('classic_buy', [p['id'] for p in final['actual_paths']])
        intraday = daily_profile_lifecycle(rows, self.day, when + self.period)
        self.assertNotIn('classic_buy', [c['id'] for c in self.active(intraday['candidates'])])

    def test_ny_reclaim_trial_requires_two_closed_bars_and_holding_london_extreme(self):
        london = self.at(self.day, 2)
        london_end = self.at(self.day, 5)
        ny = self.at(self.day, 7)
        end = self.at(self.day + timedelta(days=1))
        rows = [replace(b, open=96, high=98, low=95, close=97) if london <= b.time < ny else b
                for b in self.daily_rows()]
        for side, ident in [(1, 'classic_buy'), (-1, 'classic_sell_mirror')]:
            with self.subTest(side=side):
                bars = rows if side == 1 else [replace(b, open=200-b.open, close=200-b.close,
                                                        high=200-b.low, low=200-b.high) for b in rows]

                def review(cutoff, data=bars):
                    return daily_profile_lifecycle(data, self.day, cutoff, research_ny_reclaim=True)

                watch = review(london_end)['research_ny_reclaim_sequences'][0]
                self.assertIsNone(watch['ny_reclaim_known_at'])
                first = review(ny+self.period)
                self.assertIsNotNone(first['research_ny_reclaim_sequences'][0]['ny_reclaim_known_at'])
                self.assertNotIn(ident, [c['id'] for c in self.active(first['candidates'])])
                confirmed_at = ny+2*self.period
                confirmed = review(confirmed_at)
                self.assertIn(ident, [c['id'] for c in self.active(confirmed['candidates'])])
                self.assertEqual(confirmed, review(confirmed_at, [b for b in bars if b.time < confirmed_at]))
                self.assertIn(ident, [c['id'] for c in review(end)['actual_paths']])
                self.assertNotIn(ident, [c['id'] for c in daily_profile_lifecycle(bars, self.day, end)['actual_paths']])
                broken = [replace(b, **({'low': 94} if side == 1 else {'high': 106}))
                          if b.time == confirmed_at else b for b in bars]
                self.assertNotIn(ident, [c['id'] for c in review(end, broken)['actual_paths']])

    def test_afternoon_data_hole_cannot_confirm_completed_price_path(self):
        """Complete killzones and the final bar do not establish the whole day."""
        end = self.at(self.day + timedelta(days=1))
        rows = [b for b in self.daily_rows()
                if not self.at(self.day, 10) <= b.time < end - self.period]
        result = daily_profile_lifecycle(rows, self.day, end)
        self.assertNotEqual(result['profile_status'], 'confirmed_path')
        self.assertEqual(result['actual_paths'], [])

    def test_thursday_break_without_reclaim_demotes_wednesday_low(self):
        wednesday = self.at(self.monday + timedelta(days=2), 7)
        thursday = self.at(self.monday + timedelta(days=3), 7)
        tuesday_close = self.at(self.monday + timedelta(days=2)) - self.period
        rows = [replace(b,close=99.5) if b.time==tuesday_close else
                replace(b, low=98) if b.time == wednesday else
                replace(b, open=95, high=96, low=90, close=92) if b.time == thursday else b
                for b in self.weekly_rows()]
        before = self.weekly(rows, wednesday + self.period)
        self.assertIn('weekly_wednesday_extreme',
                      [c['id'] for c in self.active(before['candidates'])])
        after = self.weekly(rows, thursday + self.period)
        self.assertNotIn('weekly_wednesday_extreme',
                         [c['id'] for c in self.active(after['candidates'])])

    def test_one_monday_quote_is_not_a_complete_reference_range(self):
        tuesday = self.at(self.monday + timedelta(days=1), 7)
        rows = [Bar(self.at(self.monday), 100, 101, 99, 100, .2),
                Bar(tuesday, 100, 101, 98, 100, .2)]
        result = self.weekly(rows, tuesday + self.period)
        self.assertNotIn('weekly_tuesday_extreme',
                         [c['id'] for c in self.active(result['candidates'])])

    def test_two_tuesday_reclaims_keep_only_the_surviving_extreme(self):
        first = self.at(self.day, 7)
        second = first + self.period
        third = second + self.period
        fourth = third + self.period
        for direction in (-1, 1):
            with self.subTest(direction=direction):
                edge = 'high' if direction == -1 else 'low'
                opposite = 'low' if direction == -1 else 'high'
                edits = {first: {edge: 100-3*direction}, second: {opposite: 100+3*direction},
                         third: {opposite: 100+5*direction, 'close': 100+4*direction},
                         fourth: {edge: 100-5*direction, 'close': 100-4*direction}}
                rows = [replace(b, **edits.get(b.time, {})) for b in self.weekly_rows()]
                def candidates(data, cutoff):
                    return [c for c in self.active(self.weekly(data, cutoff)['candidates'])
                            if c['id'] == 'weekly_tuesday_extreme']
                self.assertEqual([c['direction'] for c in candidates(rows, second)], [direction])
                self.assertEqual(candidates(rows, third), [])
                surviving = candidates(rows, fourth)
                self.assertEqual([c['direction'] for c in surviving], [direction])
                self.assertEqual(surviving[0]['reclaim_known_at'], second.isoformat())
                self.assertTrue(surviving[0]['opposite_reclaim_invalidated'])
                self.assertEqual(surviving, candidates([b for b in rows if b.time < fourth], fourth))
                self.assertEqual([c['direction'] for c in candidates(rows, fourth+self.period)], [-direction])
                self.assertEqual(candidates(rows, fourth+2*self.period), [])

    def test_tuesday_new_high_only_rearms_after_its_own_return(self):
        first = self.at(self.day, 9)
        higher = first+self.period
        returned = higher+self.period
        edits = {first: {'high':103}, higher: {'high':105, 'close':104}}
        rows = [replace(b, **edits.get(b.time, {})) for b in self.weekly_rows()]
        def active_at(at):
            return [c for c in self.active(self.weekly(rows, at)['candidates'])
                    if c['id'] == 'weekly_tuesday_extreme']
        self.assertEqual(active_at(returned), [])
        self.assertEqual(active_at(returned+self.period)[0]['reclaim_known_at'], (returned+self.period).isoformat())

    def test_tuesday_watch_expires_only_when_wednesday_close_fails(self):
        early=self.at(self.day,7)
        close=self.at(self.day+timedelta(days=2))
        rows=[replace(b,low=98) if b.time==early else b for b in self.weekly_rows()]
        def card(at):
            return next(c for c in self.weekly(rows,at)['candidates'] if c['id']=='weekly_tuesday_extreme')
        self.assertEqual(card(close-self.period)['status'],'active')
        self.assertEqual(card(close)['status'],'invalidated')
        self.assertIn('周三日收',card(close)['failed_close_condition'])

    def test_wednesday_new_extreme_requires_new_closed_return(self):
        first=self.at(self.day+timedelta(days=1),7)
        later=first+self.period
        rows=[replace(b,high=103) if b.time==first else
              replace(b,high=105,close=104) if b.time==later else b for b in self.weekly_rows()]
        def cards(at):
            return [c for c in self.active(self.weekly(rows,at)['candidates'])
                    if c['id'].startswith('weekly_wednesday_')]
        self.assertEqual(cards(later)[0]['reclaim_known_at'],later.isoformat())
        self.assertEqual(cards(later+self.period),[])
        self.assertEqual(cards(later+2*self.period)[0]['reclaim_known_at'],(later+2*self.period).isoformat())

    def test_missing_monday_does_not_rename_wednesday_to_tuesday(self):
        wednesday = self.monday + timedelta(days=2)
        thursday = self.monday + timedelta(days=3)
        rows = [b for b in self.weekly_rows() if b.time.astimezone(NY).date() != self.monday]
        rows = [replace(b, low=98) if b.time == self.at(wednesday, 7) else b for b in rows]
        result = daily_profile_lifecycle(rows, thursday, self.at(thursday, 7))
        self.assertNotIn('周二扫低回收', result['weekly_background']['label'])


if __name__ == '__main__':
    unittest.main()
