from datetime import date, time, timedelta
import unittest

from brooks_ai.types import Bar
from ict_ai.profile_delivery_evidence import M15, daily_delivery, weekly_delivery
from ict_ai.profile_lifecycle import _day_bounds
from ict_ai.range_liquidity import M5, _research_open
from ict_ai.timebase import session_windows


def candle(at, bar):
    return Bar(at,*bar,0)


class DeliveryEvidenceTests(unittest.TestCase):
    def test_ny_reclaim_distinguishes_prior_london_drive_from_balance(self):
        day = date(2026,11,23)
        windows = session_windows(day)
        asia,london,ny = (windows[name][0] for name in ('asia','london','new_york'))
        opening = [candle(asia+i*M15,(100,102,98,100)) for i in range(16)]
        for closes,expected,high in ((104,'ny_reversal_after_london_drive',105),(100,'ny_sweep_after_london_balance',101)):
            before = opening+[candle(london+i*M15,(100,high,99,closes)) for i in range(12)]
            new_york = [candle(ny,(100,high+2,99,100)),candle(ny+M15,(100,101,97,98)),
                        candle(ny+2*M15,(98,99,96,97)),candle(ny+3*M15,(97,high+3,96,98))]
            first = daily_delivery(before+new_york,day,ny+M15,True)
            self.assertEqual([(r['kind'],r['status']) for r in first],[(expected,'waiting_for_delivery')])
            delivered = daily_delivery(before+new_york,day,ny+3*M15,True)
            self.assertEqual(delivered[0]['status'],'delivery_observed')
            self.assertEqual(daily_delivery(before+new_york,day,ny+4*M15,True)[0]['status'],'invalidated')
            self.assertEqual(daily_delivery(before[1:]+new_york,day,ny+3*M15,True)[0]['status'],'coverage_unknown')

    def test_thursday_counter_needs_completed_prior_days_and_its_own_followthrough(self):
        week = [date(2026,11,16)+timedelta(days=i) for i in range(5)]
        history = []
        for i,day in enumerate(week[:3]):
            start,end = _day_bounds(day)
            px = 100+3*i
            history.extend(candle(at,(px,px+3,px-1,px+2)) for step in range(int((end-start)/M5))
                           if _research_open(at:=start+step*M5))
        thursday,_ = _day_bounds(week[3])
        rows = [candle(thursday,(108,111,107,108)),candle(thursday+M15,(108,109,104,106)),
                candle(thursday+2*M15,(106,107,102,104))]
        self.assertEqual(weekly_delivery(history,rows,week,thursday),[])
        self.assertEqual(weekly_delivery(history,rows,week,thursday+M15)[0]['status'],'waiting_for_delivery')
        result = weekly_delivery(history,rows,week,thursday+3*M15)[0]
        self.assertEqual((result['status'],result['direction']),('delivery_observed',-1))
        self.assertEqual(result['delivery'],(thursday+3*M15).isoformat())
        self.assertEqual(weekly_delivery(history[1:],rows,week,thursday+3*M15)[0]['status'],'coverage_unknown')
