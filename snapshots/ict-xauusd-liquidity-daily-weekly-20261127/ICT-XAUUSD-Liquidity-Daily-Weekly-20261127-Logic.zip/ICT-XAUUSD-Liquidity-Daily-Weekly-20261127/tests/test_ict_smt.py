import unittest
from dataclasses import replace
from datetime import datetime,timedelta,timezone
from brooks_ai.types import Bar
from ict_ai.smt import smt_divergences,smt_observation


class SMTTest(unittest.TestCase):
    def fixture(self,asynchronous=False):
        t=datetime(2026,10,13,tzinfo=timezone.utc);p=timedelta(minutes=15)
        make=lambda values:[Bar(t+i*p,h-1.5,h,h-2,h-1,0) for i,h in enumerate(values)]
        a=make([100,102,105,102,101,103,106,103,102])
        b=make([20,21,23,21,20,21,21.5,22,20] if asynchronous else [20,21,23,21,20,21,22,21,20])
        return t,p,a,b

    def run_events(self,a,b,p,now):return smt_divergences(a,b,p,now,pivot_radius=1,pair_tolerance_bars=1)

    def test_high_divergence_uses_separate_price_scales(self):
        t,p,a,b=self.fixture()
        e=self.run_events(a,b,p,t+9*p)
        self.assertEqual(len(e),1)
        self.assertEqual((e[0]['direction'],e[0]['primary_pattern'],e[0]['secondary_pattern']),('bearish','HH','LH'))
        self.assertEqual(e[0]['available_at'],(t+8*p).isoformat())
        self.assertFalse(e[0]['trade_signal'])

    def test_async_peer_waits_for_its_right_bar(self):
        t,p,a,b=self.fixture(True)
        self.assertEqual(self.run_events(a,b,p,t+8*p),[])
        self.assertEqual(self.run_events(a,b,p,t+9*p)[0]['available_at'],(t+9*p).isoformat())

    def test_all_prefixes_stable_and_no_unclosed_pivot(self):
        t,p,a,b=self.fixture(True)
        full=self.run_events(a,b,p,t+9*p)
        for n in range(1,10):
            now=t+n*p
            expected=[e for e in full if datetime.fromisoformat(e['available_at'])<=now]
            self.assertEqual(self.run_events(a[:n],b[:n],p,now),expected)
            self.assertEqual(self.run_events(a,b,p,now),expected)
        self.assertEqual(self.run_events(a,b,p,t+9*p-timedelta(microseconds=1)),[])

    def test_missing_peer_and_session_gap_reset_old_anchor(self):
        t,p,a,b=self.fixture()
        self.assertEqual(self.run_events(a,b[:5]+b[6:],p,t+9*p),[])
        self.assertEqual(self.run_events(a[:5]+a[6:],b,p,t+9*p),[])

    def test_equal_peer_high_is_not_lower_high(self):
        t,p,a,b=self.fixture()
        b[6]=replace(b[6],high=23)
        self.assertEqual(self.run_events(a,b,p,t+9*p),[])

    def test_low_mirror(self):
        t,p,a,b=self.fixture()
        mirror=lambda rows:[replace(z,open=500-z.open,high=500-z.low,low=500-z.high,close=500-z.close) for z in rows]
        e=self.run_events(mirror(a),mirror(b),p,t+9*p)
        self.assertEqual((e[0]['direction'],e[0]['primary_pattern'],e[0]['secondary_pattern']),('bullish','LL','HL'))

    def test_later_catchup_is_not_original_trade_confirmation(self):
        t,p,a,b=self.fixture();event=self.run_events(a,b,p,t+9*p)[0]
        before=smt_observation(event,a,b,p,t+9*p)
        self.assertEqual(before['status'],'geometry_only')
        self.assertEqual(before['csd_validation'],'undefined_in_source')
        a.append(replace(a[-1],time=t+9*p));b.append(replace(b[-1],time=t+9*p,high=24))
        after=smt_observation(event,a,b,p,t+10*p)
        self.assertEqual(after['status'],'peer_caught_up')
        self.assertEqual(after['catch_up_at'],(t+10*p).isoformat())
        self.assertFalse(after['trade_signal'])
        self.assertEqual(smt_observation(event,a,b,p,t+9*p),before)

    def test_missing_followup_is_unknown_not_rejected_by_market(self):
        t,p,a,b=self.fixture();event=self.run_events(a,b,p,t+9*p)[0]
        after=smt_observation(event,a,b[:8],p,t+9*p)
        self.assertEqual(after['status'],'followup_gap')


if __name__=='__main__':unittest.main()
