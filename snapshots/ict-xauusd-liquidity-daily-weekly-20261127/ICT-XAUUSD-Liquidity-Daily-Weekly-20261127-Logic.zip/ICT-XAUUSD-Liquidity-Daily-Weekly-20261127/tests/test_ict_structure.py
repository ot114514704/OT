import unittest
from dataclasses import replace
from datetime import datetime,timedelta,timezone
from brooks_ai.types import Bar
from ict_ai.structure import FrozenRange,sweep_structure_events


class StructureTest(unittest.TestCase):
    def fixture(self):
        t=datetime(2026,10,5,tzinfo=timezone.utc);p=timedelta(minutes=15)
        rows=[(100,102,99,100)]*14+[(100,106,99,101),(101,104,99,100),(100,103,99,100),(100,102,99,100),(100,101,96,100),(100,109,98.5,108.5),(108.5,110,104,109.5)]
        bars=[Bar(t+i*p,*r,0) for i,r in enumerate(rows)]
        reference=FrozenRange('test-range',98,108,t+18*p,t+40*p,'synthetic test reference')
        return t,p,bars,reference

    def test_sequence_and_third_bar_availability(self):
        t,p,bars,reference=self.fixture()
        e=sweep_structure_events(bars,reference,p,t+21*p)
        self.assertEqual([x['kind'] for x in e],['liquidity_sweep','mss_candidate','sweep_mss_fvg_candidate'])
        self.assertEqual(e[-1]['fvg']['lower'],101)
        self.assertEqual(e[-1]['fvg']['upper'],104)
        self.assertEqual(e[-1]['available_at'],(t+21*p).isoformat())
        self.assertFalse(e[-1]['execution_allowed'])
        self.assertEqual(e[-1]['frozen_structure']['available_at'],(t+17*p).isoformat())

    def test_every_prefix_matches_full_history_with_same_cutoff(self):
        t,p,bars,reference=self.fixture()
        full=sweep_structure_events(bars,reference,p,t+21*p)
        for n in range(1,len(bars)+1):
            now=t+n*p
            expected=[e for e in full if datetime.fromisoformat(e['available_at'])<=now]
            self.assertEqual(sweep_structure_events(bars[:n],reference,p,now),expected)
            self.assertEqual(sweep_structure_events(bars,reference,p,now),expected)

    def test_unclosed_third_bar_does_not_create_fvg(self):
        t,p,bars,reference=self.fixture()
        events=sweep_structure_events(bars,reference,p,t+21*p-timedelta(microseconds=1))
        self.assertEqual(len(events),2)

    def test_gap_cancels_sequence(self):
        t,p,bars,reference=self.fixture()
        bars[-1]=replace(bars[-1],time=bars[-1].time+p)
        events=sweep_structure_events(bars,reference,p,t+23*p)
        self.assertFalse(any(e['kind']=='sweep_mss_fvg_candidate' for e in events))

    def test_future_reference_and_future_pivot_are_not_used(self):
        t,p,bars,reference=self.fixture()
        self.assertEqual(sweep_structure_events(bars,replace(reference,available_at=t+21*p),p,t+21*p),[])
        # Make the only high a point needing a right-hand bar after the sweep.
        bars[14]=replace(bars[14],high=102)
        bars[17]=replace(bars[17],high=107)
        events=sweep_structure_events(bars,reference,p,t+21*p)
        self.assertFalse(any(e['kind']=='sweep_mss_fvg_candidate' for e in events))

    def test_two_sided_sweep_does_not_invent_order(self):
        t,p,bars,reference=self.fixture()
        bars[18]=replace(bars[18],high=109)
        self.assertEqual(sweep_structure_events(bars,reference,p,t+21*p),[])

    def test_wick_break_without_body_close_is_not_mss(self):
        t,p,bars,reference=self.fixture()
        bars[19]=replace(bars[19],close=104)
        self.assertFalse(any(e['kind']=='mss_candidate' for e in sweep_structure_events(bars,reference,p,t+20*p)))

    def test_bearish_mirror(self):
        t,p,bars,reference=self.fixture()
        mirror=[replace(b,open=250-b.open,high=250-b.low,low=250-b.high,close=250-b.close) for b in bars]
        reference=replace(reference,low=250-reference.high,high=250-reference.low)
        events=sweep_structure_events(mirror,reference,p,t+21*p)
        self.assertEqual(events[-1]['kind'],'sweep_mss_fvg_candidate')
        self.assertEqual(events[-1]['side'],-1)
        self.assertEqual(events[-1]['fvg']['lower'],146)
        self.assertEqual(events[-1]['fvg']['upper'],149)


if __name__=='__main__':unittest.main()
