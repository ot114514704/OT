from datetime import datetime,timezone
from unittest import TestCase

from brooks_ai.types import Bar
from scripts.audit_ict_dol_liquidity_reaction import M5, event


class LiquidityReactionTests(TestCase):
    def setUp(self):
        self.start = datetime(2026,11,24,12,tzinfo=timezone.utc)
        self.target = dict(lo=103,hi=104,side=1)

    def rows(self,*prices):
        return [Bar(self.start+index*M5,o,h,l,c,0) for index,o,h,l,c in prices]

    def test_touch_at_exact_far_edge_does_not_count_as_strict_cross(self):
        touched = event(self.target,self.rows((0,102,104,101,103)),100)
        self.assertEqual(touched['state'],'touch_without_cross')
        self.assertIsNone(touched['cross'])

    def test_same_bar_reclaim_and_two_closes_are_distinct_price_outcomes(self):
        sweep = self.rows((0,102,106,101,102))
        reclaim = event(self.target,sweep,100)
        self.assertEqual(reclaim['state'],'reclaimed')
        self.assertEqual(reclaim['resolved'],reclaim['cross'])
        moves = self.rows((0,102,106,101,105),(1,105,107,104,106),(2,106,107,101,102))
        accepted = event(self.target,moves,100)
        self.assertEqual(accepted['state'],'two_closes_beyond')
        self.assertEqual(accepted,event(self.target,moves[:2],100))
        self.assertEqual(event(self.target,moves[:1],100)['state'],'censored_reaction')

    def test_gap_over_and_gap_after_cross_are_censored_separately(self):
        self.assertEqual(event(self.target,self.rows((0,105,107,105,106)),100)['state'],'unwitnessed_gap_over')
        missing = self.rows((0,102,106,101,105),(2,106,107,101,102))
        self.assertEqual(event(self.target,missing,100)['state'],'censored_reaction')

    def test_short_mirror_has_the_same_reaction_and_availability(self):
        bars = self.rows((0,102,106,101,105),(1,105,107,104,106))
        reverse = [Bar(b.time,200-b.open,200-b.low,200-b.high,200-b.close,0) for b in bars]
        self.assertEqual(event(dict(lo=96,hi=97,side=-1),reverse,100),event(self.target,bars,100))
