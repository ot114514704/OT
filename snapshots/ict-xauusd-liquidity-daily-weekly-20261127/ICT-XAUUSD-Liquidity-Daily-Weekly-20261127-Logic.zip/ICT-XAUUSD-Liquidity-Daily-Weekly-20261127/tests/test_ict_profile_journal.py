from copy import deepcopy
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from ict_ai.profile_journal import _definition_files, record_profiles


class ProfileJournalTests(unittest.TestCase):
    def payload(self,root):
        sources=[]
        for name in ('XAU','XAG'):
            folder=root/name;folder.mkdir()
            data=folder/'quotes.csv';data.write_text('synthetic journal fixture\n',encoding='utf-8')
            sha=hashlib.sha256(data.read_bytes()).hexdigest()
            manifest=folder/'provenance.json'
            # The journal's non-synthetic flag guard is tested here using
            # deliberately stubbed metadata, not a claim of real quotations.
            manifest.write_text(json.dumps({'synthetic':False,'volatile_live_snapshot':True,
                                            'datasets':[{'timeframe':'M5','data_path':str(data),'data_sha256':sha}]}),encoding='utf-8')
            sources.append((manifest,sha,data))
        result={'source_manifest':str(sources[0][0]),'source_sha256':sources[0][1],
                'smt_pair':{'source_manifest':str(sources[1][0]),'comparison_source_sha256':sources[1][1]},
                'snapshot_read_at':'2026-10-14T12:00:00Z','scenarios':[{'id':'broker-plus3','days':[
                    {'date':'2026-10-14','profile_lifecycle':{'mode':'intraday_hypothesis','as_of':'2026-10-14T12:00:00Z',
                                                        'profile_label':'test candidate','candidates':[]}}], 'weeks':[]}]}
        return result,sources

    def test_heartbeat_deduplicates_but_changed_guess_preserves_both(self):
        with TemporaryDirectory(prefix='ict-journal-test-') as folder:
            root=Path(folder);payload,_=self.payload(root);work=root/'journal'
            self.assertEqual(record_profiles(payload,work)['observations_added'],1)
            payload['scenarios'][0]['days'][0]['profile_lifecycle']['as_of']='2026-10-14T12:00:20Z'
            unchanged=record_profiles(payload,work)
            self.assertEqual(unchanged['observations_added'],0)
            self.assertEqual(len(unchanged['history']),1)
            self.assertEqual(unchanged['history'][0]['as_of'],'2026-10-14T12:00:00Z')
            payload['scenarios'][0]['days'][0]['profile_lifecycle']['profile_label']='new candidate'
            self.assertEqual(record_profiles(payload,work)['observations_added'],1)
            records=[json.loads(line) for line in (work/'profile-observations.jsonl').read_text(encoding='utf-8').splitlines()]
            self.assertEqual([r['lifecycle']['profile_label'] for r in records],['test candidate','new candidate'])
            self.assertTrue(all(r['origin']=='recorded_live_hypothesis' for r in records))

    def test_forecast_and_final_review_coexist_with_distinct_origins(self):
        with TemporaryDirectory(prefix='ict-journal-test-') as folder:
            root=Path(folder);payload,_=self.payload(root);work=root/'journal'
            record_profiles(payload,work)
            payload['scenarios'][0]['days'][0]['profile_lifecycle'].update(mode='closed_review',profile_label='actual path')
            record_profiles(payload,work)
            records=[json.loads(line) for line in (work/'profile-observations.jsonl').read_text(encoding='utf-8').splitlines()]
            self.assertEqual(records[0]['mode'],'intraday_hypothesis')
            self.assertEqual(records[1]['mode'],'closed_review')
            self.assertEqual(records[1]['origin'],'closed_review_generated_after_day_or_week_end')
            result=record_profiles(payload,work)
            self.assertEqual([item['mode'] for item in result['history']],['intraday_hypothesis','closed_review'])

    def test_snapshot_archive_remains_hash_verifiable_after_live_file_changes(self):
        with TemporaryDirectory(prefix='ict-journal-test-') as folder:
            root=Path(folder);payload,sources=self.payload(root);work=root/'journal'
            result=record_profiles(payload,work)
            sources[0][2].write_text('later live file',encoding='utf-8')
            meta=json.loads(Path(result['immutable_sources'][0]).read_text(encoding='utf-8'))
            dataset=meta['datasets'][0]
            self.assertFalse(meta['volatile_live_snapshot'])
            self.assertEqual(hashlib.sha256(Path(dataset['data_path']).read_bytes()).hexdigest(),payload['source_sha256'])
            archived={item['source_path']:item for item in result['immutable_definitions']}
            self.assertIn('ict_ai/profile_lifecycle.py',archived)
            for dependency in ('ict_ai/weekly_path.py','ict_ai/profile_sources.py',
                               'ict_ai/timebase.py','ict_ai/range_liquidity.py',
                               'scripts/prepare_ict_week.py','research/ict_time_videos/profile-visual-review.json'):
                self.assertIn(dependency,archived)
            self.assertIn('research/ict_daily_profiles/rules.json',archived)
            self.assertIn('research/ict_weekly_profiles/rules.json',archived)
            self.assertIn('research/ict_weekly_profiles/smc_free_guide/integration.json',archived)
            for item in archived.values():
                self.assertEqual(hashlib.sha256(Path(item['archived_path']).read_bytes()).hexdigest(),item['sha256'])
            record=json.loads((work/'profile-observations.jsonl').read_text(encoding='utf-8').splitlines()[0])
            self.assertEqual(record['profile_code_sha256'],archived['ict_ai/profile_lifecycle.py']['sha256'])
            self.assertEqual(record['profile_definition_sources'],result['immutable_definitions'])

    def test_mismatched_source_never_creates_a_forecast_record(self):
        with TemporaryDirectory(prefix='ict-journal-test-') as folder:
            root=Path(folder);payload,_=self.payload(root);work=root/'journal'
            payload['source_sha256']='bad'
            with self.assertRaisesRegex(ValueError,'published real snapshot'):
                record_profiles(payload,work)
            self.assertFalse((work/'profile-observations.jsonl').exists())

    def test_compact_history_keeps_first_latest_live_and_latest_closed_per_scope_date(self):
        with TemporaryDirectory(prefix='ict-journal-test-') as folder:
            root=Path(folder);payload,_=self.payload(root);work=root/'journal'
            day=payload['scenarios'][0]['days'][0]['profile_lifecycle']
            week=deepcopy(day);week.update(mode='intraweek_hypothesis',profile_label='weekly candidate')
            payload['scenarios'][0]['weeks']=[{'days':['2026-10-12'],'profile_lifecycle':week}]
            for number in range(5):
                day.update(profile_label=f'candidate {number}',as_of=f'2026-10-14T12:0{number}:00Z')
                record_profiles(payload,work)
            for label in ('initial final review','revised final review'):
                day.update(mode='closed_review',profile_label=label)
                result=record_profiles(payload,work)
            daily=[entry for entry in result['history'] if entry['scope']=='day']
            self.assertEqual([entry['label'] for entry in daily],
                             ['candidate 0','candidate 3','candidate 4','revised final review'])
            self.assertEqual([entry['label'] for entry in result['history'] if entry['scope']=='week'],['weekly candidate'])
            allowed={'scope','date','mode','as_of','recorded_at_utc','label','origin'}
            self.assertTrue(all(set(entry)==allowed for entry in result['history']))
            self.assertEqual(len((work/'profile-observations.jsonl').read_text(encoding='utf-8').splitlines()),8)
            self.assertEqual(record_profiles(payload,work)['history'],result['history'])

    def test_history_excludes_reconstructed_and_out_of_view_days(self):
        with TemporaryDirectory(prefix='ict-journal-test-') as folder:
            root=Path(folder);payload,_=self.payload(root);work=root/'journal'
            record_profiles(payload,work)
            journal=work/'profile-observations.jsonl'
            reconstructed=json.loads(journal.read_text(encoding='utf-8').splitlines()[0])
            reconstructed['origin']='historical_prefix_reconstruction_not_recorded_live_forecast'
            reconstructed['lifecycle']['profile_label']='reconstructed guess'
            with journal.open('a',encoding='utf-8') as stream:
                stream.write(json.dumps(reconstructed)+'\n')
            result=record_profiles(payload,work)
            self.assertEqual([entry['label'] for entry in result['history']],['test candidate'])
            payload['scenarios'][0]['days'][0]['date']='2026-10-15'
            result=record_profiles(payload,work)
            self.assertEqual([entry['date'] for entry in result['history']],['2026-10-15'])
            self.assertEqual(len(journal.read_text(encoding='utf-8').splitlines()),3)

    def test_rule_version_change_archives_exact_new_rule_without_rewriting_prior_record(self):
        with TemporaryDirectory(prefix='ict-journal-test-') as folder:
            root=Path(folder);payload,_=self.payload(root);work=root/'journal'
            record_profiles(payload,work)
            journal=work/'profile-observations.jsonl';prior=journal.read_bytes()
            definitions=_definition_files(payload['scenarios'][0])
            changed=[]
            target='research/ict_daily_profiles/rules.json'
            for name,content,sha in definitions:
                if name==target:
                    content=b'{"fixture":"changed source version"}\n'
                    sha=hashlib.sha256(content).hexdigest()
                changed.append((name,content,sha))
            with patch('ict_ai.profile_journal._definition_files',return_value=changed):
                result=record_profiles(payload,work)
                self.assertEqual(record_profiles(payload,work)['observations_added'],0)
            self.assertEqual(result['observations_added'],1)
            self.assertTrue(journal.read_bytes().startswith(prior))
            records=[json.loads(line) for line in journal.read_text(encoding='utf-8').splitlines()]
            self.assertNotEqual(records[0]['profile_definition_sha256'],records[1]['profile_definition_sha256'])
            self.assertEqual(records[0]['profile_code_sha256'],records[1]['profile_code_sha256'])
            archived=next(item for item in result['immutable_definitions'] if item['source_path']==target)
            self.assertEqual(Path(archived['archived_path']).read_bytes(),b'{"fixture":"changed source version"}\n')

    def test_weekly_algorithm_change_creates_distinct_source_version_even_with_same_label(self):
        with TemporaryDirectory(prefix='ict-journal-test-') as folder:
            root=Path(folder);payload,_=self.payload(root);work=root/'journal'
            record_profiles(payload,work)
            journal=work/'profile-observations.jsonl';prior=journal.read_bytes()
            definitions=_definition_files(payload['scenarios'][0]);target='ict_ai/weekly_path.py'
            changed=[]
            for name,content,sha in definitions:
                if name==target:
                    content+=b'\n# distinct research definition version\n'
                    sha=hashlib.sha256(content).hexdigest()
                changed.append((name,content,sha))
            with patch('ict_ai.profile_journal._definition_files',return_value=changed):
                result=record_profiles(payload,work)
            self.assertEqual(result['observations_added'],1)
            self.assertTrue(journal.read_bytes().startswith(prior))
            records=[json.loads(line) for line in journal.read_text(encoding='utf-8').splitlines()]
            self.assertNotEqual(records[0]['profile_definition_sha256'],records[1]['profile_definition_sha256'])
            self.assertEqual(records[0]['lifecycle']['profile_label'],records[1]['lifecycle']['profile_label'])

    def test_running_process_cannot_bind_a_new_disk_algorithm_as_its_loaded_version(self):
        with TemporaryDirectory(prefix='ict-journal-test-') as folder:
            root=Path(folder);payload,_=self.payload(root);work=root/'journal'
            from ict_ai.profile_journal import RUNTIME_CODE_SHA256
            binding=dict(RUNTIME_CODE_SHA256);binding['ict_ai/weekly_path.py']='older-loaded-code'
            with self.assertRaisesRegex(ValueError,'changed after process load'):
                record_profiles(payload,work,runtime_code_shas=binding)
            self.assertFalse((work/'profile-observations.jsonl').exists())


if __name__=='__main__':unittest.main()
