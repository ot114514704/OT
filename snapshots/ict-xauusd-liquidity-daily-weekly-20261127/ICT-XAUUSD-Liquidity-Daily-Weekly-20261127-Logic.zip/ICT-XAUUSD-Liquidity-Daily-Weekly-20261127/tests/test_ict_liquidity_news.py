from datetime import datetime, timezone
import unittest

from brooks_ai.types import Bar
from scripts.replay_ict_liquidity_news import M5, live_comparison, window
from scripts.replay_ict_liquidity_news_m1 import M1, aligned_window, passage, ranked_choices


class NewsLiquidityTests(unittest.TestCase):
    def setUp(self):
        self.at = datetime(2026, 10, 14, 12, 30, tzinfo=timezone.utc)
        self.before = [self.quote(i, 100, 101, 99, 100) for i in range(-12, 0)]
        self.first = [self.quote(0, 100, 104, 99.8, 103.5)]
        self.flat = [self.quote(i, 103.5, 103.9, 103.1, 103.5) for i in range(1, 12)]

    def quote(self, offset, open_, high, low, close):
        return Bar(self.at + offset * M5, open_, high, low, close, 0)

    def target(self, rank, price):
        return dict(rank=rank, side=1, lo=price, hi=price, sources=[], score=50, hourly_range=8)

    def test_decision_depends_on_observed_prefix_and_swept_targets_retire(self):
        targets = [self.target(11, 102), self.target(12, 105)]
        candidates = [(target, {'rank':target['rank']}) for target in targets]
        with_sweep = self.first + self.flat.copy()
        without_sweep = self.first + self.flat
        with_sweep[3] = self.quote(3, 103.5, 105.5, 103, 104.5)
        a = live_comparison(self.before[-6:],with_sweep,1,candidates,8)
        b = live_comparison(self.before[-6:],without_sweep,1,candidates,8)
        for choice in ('nearest','directional'):
            self.assertEqual(a['trial'][choice]['rank'],12)
            self.assertEqual(a['trial'][choice]['rank'],b['trial'][choice]['rank'])
        self.assertEqual(a['trial']['directional']['by30']['sweep'],(self.at+4*M5).isoformat())
        self.assertIsNone(b['trial']['directional']['by30']['sweep'])

    def test_before_release_crossing_is_excluded_and_earlier_touch_only_is_kept(self):
        rows = self.before + self.first + self.flat
        cutoff = self.at-6*M5
        found = dict(at=cutoff.isoformat(),pools={'IRL':[self.target(11,100.5),self.target(12,101)]})
        result = window(self.at,{cutoff:found},{p.time:p for p in rows},{},'IRL')
        retired,watched = result['traces']
        self.assertEqual(retired['excluded_at'],'before_release')
        self.assertTrue(watched['touched_before_release'])
        self.assertEqual(watched['first15']['sweep'],(self.at+M5).isoformat())
        self.assertEqual(result['decisions']['5']['remaining'],0)

    def test_minute_archive_requires_coverage_and_exact_aggregate(self):
        rows = {self.at + i*M1:Bar(self.at + i*M1, 100, 101, 99, 100, 0) for i in range(-30,30)}
        five = {t:b for t,b in rows.items() if t.minute%5==0}
        verified, error = aligned_window(five,rows,self.at)
        self.assertIsNone(error)
        self.assertEqual(len(verified[1]),30)
        incomplete = rows.copy()
        del incomplete[self.at+M1]
        self.assertEqual(aligned_window(five,incomplete,self.at),(None,'missing_m1'))
        rows[self.at+M1] = Bar(self.at+M1,100,102,99,100,0)
        self.assertEqual(aligned_window(five,rows,self.at),(None,'m1_does_not_rebuild_m5'))

    def test_minute_gap_retires_watched_level_before_ranking(self):
        first = Bar(self.at,105,106,104,105,0)
        target = dict(side=1,edge=103,original_rank=11)
        beyond = dict(side=1,edge=107,original_rank=12)
        self.assertEqual(passage([first],1,103),('gap_over',self.at+M1))
        self.assertEqual(ranked_choices([first],[target,beyond],1),(beyond,beyond))
