"""Source-bound D1/W1 evidence replay; no orders or context qualification."""
from pathlib import Path
import argparse,csv,hashlib,json,sys
from datetime import date,datetime,time,timedelta,timezone

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from brooks_ai.types import Bar,utc_time
from ict_ai.timebase import NY,manifest_epoch_to_utc,clock_policy_metadata
from ict_ai.daily_context import daily_weekly_context,M5
from ict_ai.delivery import delivery_hypotheses


def context_rows(data_path, source, floor, cutoff, offset_override=None):
    """Preserve explicit diagnostic overrides without mixing in source segments."""
    policy=clock_policy_metadata(source) if offset_override is None else {
        'source_clock_offset_hours':offset_override,'source_clock_segments':[]}
    rows=[]
    with data_path.open(encoding='utf-8-sig',newline='') as stream:
        for r in csv.DictReader(stream):
            stamp=manifest_epoch_to_utc(utc_time(r['time']),policy)
            if floor<=stamp and stamp+M5<=cutoff:
                rows.append(Bar(stamp,*(float(r[k]) for k in ('open','high','low','close','spread'))))
    return rows,policy


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--manifest',type=Path,required=True)
    ap.add_argument('--from-ny',type=date.fromisoformat,required=True)
    ap.add_argument('--offset-hours',type=float,help='Explicit constant-clock counterfactual; default uses source manifest intervals')
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args()
    source=json.loads(args.manifest.read_text(encoding='utf8'))
    if source.get('synthetic') is not False or source.get('symbol')!='XAUUSD':
        raise ValueError('Real XAUUSD snapshot required')
    if source.get('volatile_live_snapshot'):
        raise ValueError('Archive a frozen snapshot before replaying; live cache is mutable')
    item=next(d for d in source['datasets'] if d['timeframe']=='M5')
    data_path=Path(item['data_path'])
    if hashlib.sha256(data_path.read_bytes()).hexdigest()!=item['data_sha256']:
        raise ValueError('Source CSV checksum mismatch')
    floor=datetime.combine(args.from_ny,time(0),NY).astimezone(timezone.utc)
    cutoff=utc_time(source['finished_at_utc'])
    rows,clock_policy=context_rows(data_path,source,floor,cutoff,args.offset_hours)
    if not rows:raise ValueError('No closed M5 history within requested range')
    current=daily_weekly_context(rows,cutoff)
    current_delivery=delivery_hypotheses(current,rows,cutoff)
    groups={}
    for b in rows:
        local=b.time.astimezone(NY)
        if local.weekday()>4 or (local.weekday()==4 and (local.hour,local.minute)>=(16,55)) or (local.weekday()<4 and local.hour==17):
            continue
        groups.setdefault(local.date().isoformat(),[]).append(b)
    ohlc_checks=0
    for period in current['frames']['D1']['periods']:
        part=groups[period['date']]
        expected=(part[0].open,max(b.high for b in part),min(b.low for b in part),part[-1].close)
        if tuple(period[k] for k in ('open','high','low','close'))!=expected:
            raise AssertionError('Independent daily OHLC audit failed')
        if len(part)!=(203 if date.fromisoformat(period['date']).weekday()==4 else 276):
            raise AssertionError('Independent study-day quote count differs')
        ohlc_checks+=5
    checkpoints={cutoff}
    for audit in current['daily_coverage_checks']:
        end=utc_time(audit['available_at'])
        if rows[0].time<end<=cutoff:
            checkpoints.update([end,end-M5])
    for frame in current['frames'].values():
        for point in frame['confirmed_swings']:
            for field in ('available_at','touch_known_at','excursion_known_at','reclaim_known_at'):
                if point.get(field):checkpoints.add(utc_time(point[field]))
        for gap in frame['fvg_candidates']:
            for field in ('available_at','touch_known_at','ce_known_at','full_mitigation_known_at','close_invalidation_known_at'):
                if gap.get(field):
                    at=utc_time(gap[field]);checkpoints.update([at,at-M5])
    for idea in current_delivery['hypotheses']:
        for value in (idea['origin_known_at'],idea['observation']['target_contact_known_at'],idea['close_invalidation_known_at']):
            if value:
                at=utc_time(value);checkpoints.update([at,at-M5])
    checks=0;identities={};identity_checks=0;gap_identities={};gap_identity_checks=0;route_identities={};route_checks=0
    for end in sorted(checkpoints):
        prefix=[b for b in rows if b.time+M5<=end]
        observed=daily_weekly_context(rows,end)
        if observed!=daily_weekly_context(prefix,end):
            raise AssertionError('Hidden future prices changed snapshot at '+end.isoformat())
        ideas=delivery_hypotheses(observed,rows,end)
        if ideas!=delivery_hypotheses(observed,prefix,end):
            raise AssertionError('Hidden future prices changed delivery paths')
        for idea in ideas['hypotheses']:
            if idea['id'] in route_identities and route_identities[idea['id']]!=idea['frozen_sha256']:
                raise AssertionError('Delivery origin/target specification was rewritten')
            route_identities[idea['id']]=idea['frozen_sha256'];route_checks+=1
        for frame in observed['frames'].values():
            for point in frame['confirmed_swings']:
                identity={k:point[k] for k in ('id','timeframe','kind','price','anchor_period_start','available_at')}
                if point['id'] in identities and identities[point['id']]!=identity:
                    raise AssertionError('Confirmed anchor was rewritten')
                identities[point['id']]=identity;identity_checks+=1
            for gap in frame['fvg_candidates']:
                identity={k:gap[k] for k in ('id','timeframe','direction','lower','upper','formation_period_start','anchor_period_start','available_at')}
                if gap['id'] in gap_identities and gap_identities[gap['id']]!=identity:
                    raise AssertionError('Confirmed FVG geometry was rewritten')
                gap_identities[gap['id']]=identity;gap_identity_checks+=1
        checks+=1
    snapshots=[]
    day=args.from_ny
    while day<=cutoff.astimezone(NY).date():
        at=datetime.combine(day,time(0),NY).astimezone(timezone.utc)
        if day.weekday()<5 and rows[0].time<=at<=cutoff:
            evidence=daily_weekly_context(rows,at)
            snapshots.append({'ny_date':day.isoformat(),'frozen_at':at.isoformat(),
                              'evidence':evidence,'delivery':delivery_hypotheses(evidence,rows,at),
                              'planning_context_qualified':False})
        day+=timedelta(days=1)
    code=['ict_ai/daily_context.py','ict_ai/delivery.py','ict_ai/range_liquidity.py','ict_ai/timebase.py',
          'brooks_ai/types.py','scripts/replay_ict_daily_context.py']
    sources=['research/ict_price_videos/bias_dol/integration.json']
    result={'as_of':cutoff.isoformat(),'source_manifest':str(args.manifest.resolve()),
            'source_manifest_sha256':hashlib.sha256(args.manifest.read_bytes()).hexdigest(),
            'data_sha256':item['data_sha256'],'history_from_ny':args.from_ny.isoformat(),
            **clock_policy,'clock_mapping_origin':'manifest' if args.offset_hours is None else 'explicit_constant_counterfactual',
            'historical_clock_verified':False,
            'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources},
            'code_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in code},
            'prefix_checks':checks,'immutable_anchor_checks':identity_checks,
            'immutable_fvg_checks':gap_identity_checks,
            'immutable_delivery_checks':route_checks,
            'independent_daily_ohlc_and_count_checks':ohlc_checks,
            'prefix_stability_passed':True,'ny_midnight_snapshots':snapshots,'current':current,'current_delivery':current_delivery,
            'limitations':['NY midnight research aggregation differs from native broker D1/W1',
                           'Session hours and historical offset are explicit unverified assumptions',
                           'Incomplete reference periods cannot confirm pivots; missing slots remain unknown',
                           'No autonomous bias, PDA, DOL, complete strategy or execution qualification'],
            'model_trained':False,'execution_allowed':False,'orders_sent':0}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({'report':str(args.out),'prefix_checks':checks,'immutable_anchor_checks':identity_checks,
                      'immutable_fvg_checks':gap_identity_checks,
                      'delivery_hypotheses':len(current_delivery['hypotheses']),'immutable_delivery_checks':route_checks,
                      'frames':{k:{'periods':len(v['periods']),'confirmed_swings':len(v['confirmed_swings']),'fvgs':len(v['fvg_candidates'])}
                                for k,v in current['frames'].items()},'orders_sent':0}))


if __name__=='__main__':main()
