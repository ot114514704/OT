"""Compare single-checkpoint and consecutive-checkpoint daily profile offers."""

from argparse import ArgumentParser
from collections import Counter
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path


DEFAULT = Path("output/research/ict_intraday_abstention_20261126.json")
OUT = Path("output/research/ict_intraday_profile_confirmation_20261126.json")
CUTOFFS = ("07:30", "08:30", "09:30", "10:00")
POLICIES = {
    "first_calibrated_65": ("calibrated_65", False, CUTOFFS),
    "first_consecutive_calibrated_65": ("calibrated_65", True, CUTOFFS),
    "1000_calibrated_65": ("calibrated_65", False, ("10:00",)),
    "1000_calibrated_75": ("calibrated_75", False, ("10:00",)),
    "1000_consecutive_calibrated_65": ("calibrated_65", True, ("10:00",)),
}


def observation_index(report):
    result = {}
    for clock in CUTOFFS:
        for row in report["results"][clock]["forecasts"]:
            day = row["date"]
            cutoff = datetime.fromisoformat(row["cutoff"])
            if (cutoff.date().isoformat() != day or cutoff.strftime("%H:%M") != clock
                    or cutoff >= datetime.fromisoformat(row["ready_at"])):
                raise ValueError(f"Invalid worksheet checkpoint for {day} {clock}")
            history = row["calibration_through"]
            if history and datetime.fromisoformat(history) >= cutoff:
                raise ValueError(f"Calibration was unavailable at {day} {clock}")
            snapshots = result.setdefault(day, {})
            if clock in snapshots:
                raise ValueError(f"Duplicate forecast for {day} {clock}")
            snapshots[clock] = row
    return result


def offers(snapshots):
    """Choose at the first available checkpoint and use no end-of-day fields."""
    selected = {name: None for name in POLICIES}
    previous = None
    for clock in CUTOFFS:
        row = snapshots.get(clock)
        if row is None or not row["calibrated"]:
            previous = None
            continue
        key = tuple(row["key"])
        for name, (threshold, confirmation, allowed) in POLICIES.items():
            if (selected[name] is None and clock in allowed and row["decisions"][threshold]["offer"]
                    and (not confirmation or previous == key)):
                selected[name] = clock
        previous = key
    return selected


def grade(rows, label):
    output = {}
    for policy in POLICIES:
        tally = Counter()
        timing = Counter()
        for row in rows:
            call = row["offers"][policy]
            if call is None:
                tally["abstained"] += 1
                continue
            timing[call["clock"]] += 1
            outcome = call[label]
            tally["unsettled_offer" if outcome is None else "correct" if outcome else "incorrect"] += 1
        scored = tally["correct"] + tally["incorrect"]
        output[policy] = {
            "dates": len(rows), "offered": sum(timing.values()), "correct": tally["correct"],
            "incorrect": tally["incorrect"], "abstained": tally["abstained"],
            "unsettled_offer": tally["unsettled_offer"], "offered_at_ny": dict(sorted(timing.items())),
            "precision": tally["correct"] / scored if scored else None,
        }
    return output


def run(source):
    raw = source.read_bytes()
    report = json.loads(raw)
    by_day = observation_index(report)
    paired = report["paired_rule"]["dates"]
    if set(paired) != {
        day for day, rows in by_day.items()
        if all(clock in rows and rows[clock]["calibrated"] and rows[clock]["top_correct"] is not None
               for clock in CUTOFFS)
    } or len(set(paired)) != len(paired):
        raise ValueError("The common settled forecast cohort does not match the threshold report")

    records = []
    transitions = Counter()
    for day in sorted(paired):
        snapshots = by_day[day]
        selected = offers(snapshots)
        for index, clock in enumerate(CUTOFFS):
            prefix = {key: snapshots[key] for key in CUTOFFS[:index + 1]}
            available = {name: at if at is not None and at <= clock else None for name, at in selected.items()}
            if offers(prefix) != available:
                raise AssertionError(f"An offer changed using a later checkpoint on {day} {clock}")
        for earlier, later in zip(CUTOFFS, CUTOFFS[1:]):
            old, new = snapshots[earlier], snapshots[later]
            if old["key"] == new["key"]:
                if old["top_correct"] != new["top_correct"] or old["manual_correct"] != new["manual_correct"]:
                    raise ValueError(f"Inconsistent close label for the same profile on {day}")
                relation = "same_family_and_direction"
            elif old["key"][0] == new["key"][0]:
                relation = "same_family_changed_direction"
            else:
                relation = "changed_family"
            transitions[earlier, later, relation] += 1
        records.append({
            "date": day, "ny_week": snapshots["10:00"]["ny_week"],
            "manual_label_available": snapshots["10:00"]["manual_correct"] is not None,
            "sequence": [
                {"clock": clock, **{key: snapshots[clock][key] for key in ("key", "confidence", "top_correct")}}
                for clock in CUTOFFS
            ],
            "offers": {
                name: {"clock": at, **{key: snapshots[at][key] for key in ("key", "top_correct", "manual_correct")}}
                if at is not None else None
                for name, at in selected.items()
            },
        })
    metrics = grade(records, "top_correct")
    for policy, reference in (("1000_calibrated_65", "calibrated_65"), ("1000_calibrated_75", "calibrated_75")):
        baseline = report["paired_rule"]["cutoffs"]["10:00"]["results"][reference]
        if any(metrics[policy][key] != baseline[key] for key in ("offered", "correct", "incorrect")):
            raise AssertionError(f"Single-checkpoint baseline changed for {policy}")
    return {
        "source_sha256": sha256(raw).hexdigest(), "case_count": len(records),
        "first_date_ny": min(paired, default=None), "last_date_ny": max(paired, default=None),
        "close_rule": metrics,
        "oct_nov_close_rule": grade([row for row in records if row["date"] >= "2026-10-01"], "top_correct"),
        "manual_review": grade([row for row in records if row["manual_label_available"]], "manual_correct"),
        "adjacent_transitions": [
            {"from_ny": a, "to_ny": b, "change": c, "dates": n}
            for (a, b, c), n in sorted(transitions.items())
        ],
        "dates": records, "prefix_checks": len(records) * len(CUTOFFS),
        "scope": (
            "Common post-warmup NY dates with a scored candidate at all four checkpoints. "
            "Consecutive means the same signed leader at the immediately previous calibrated checkpoint. "
            "Only the current checkpoint must pass the frozen threshold. One first offer per date and policy."
        ),
        "label_basis": "Closed price-path rules from the same lifecycle. This is an exploratory retrospective audit.",
    }


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=DEFAULT)
    parser.add_argument("--out", type=Path, default=OUT)
    args = parser.parse_args()
    results = run(args.source)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(results["close_rule"]))
