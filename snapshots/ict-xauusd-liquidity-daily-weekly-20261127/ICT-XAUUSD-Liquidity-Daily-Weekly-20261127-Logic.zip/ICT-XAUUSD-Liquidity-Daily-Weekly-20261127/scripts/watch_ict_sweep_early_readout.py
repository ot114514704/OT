"""Freeze three-way probabilities after a witnessed live liquidity crossing."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
from time import sleep

import numpy as np

from brooks_ai.types import Bar
from ict_ai.sweep_response import crossing_response
from scripts import audit_ict_sweep_early_readout as study
from scripts import watch_ict_micro_liquidity_all_m5 as source


OUT = study.OUT.with_name('ict_sweep_early_readout_forward_20261125')
POLICY = OUT / 'policy.json'
M5 = source.M5
live, fixed, digest = source.live, source.fixed, source.digest


def load_policy():
    source.load_policy()
    paths = (Path(__file__), Path(study.__file__), study.OUT, source.POLICY,
             live.quotes.ROOT / 'ict_ai/sweep_response.py')
    pins = {p.name: digest(p) for p in paths}
    if not POLICY.exists():
        report = fixed.read(study.OUT)
        if report['inputs'][Path(study.__file__).name] != pins[Path(study.__file__).name]:
            raise ValueError('Probability model differs from the frozen historical evaluation')
        fixed.write_once(POLICY, dict(frozen_at=live.now().isoformat(), pins=pins,
                                      model=report['closed_distance_model'], labels=study.LABELS,
                                      sampling='Five-bar baseline top-ten pools from the all-M5 Bid witness stream.',
                                      orders_sent=0))
    policy = fixed.read(POLICY)
    if policy['pins'] != pins:
        raise ValueError('Prospective model or inputs changed')
    return policy


def event_id(event):
    return sha256(json.dumps([event['crossing_at'], event['side'], event['edge']]).encode()).hexdigest()[:24]


def witnessed(path, policy):
    frozen = datetime.fromisoformat(policy['frozen_at'])
    if datetime.strptime(path.stem, '%Y%m%dT%H%M%SZ').replace(tzinfo=frozen.tzinfo) <= frozen:
        return []
    settlement = fixed.read(path)
    if settlement['state'] != 'scored' or not any(v['baseline_hits'] for v in settlement['paired'].values()):
        return []
    receipt = source.OUT / 'receipts' / path.name
    raw, at, ready = source.load_board(fixed.read(source.POLICY), receipt)
    bid = source.OUT / 'bid' / path.with_suffix('.json.gz').name
    if settlement['receipts_sha256'] != digest(receipt) or settlement['bid_sha256'] != digest(bid):
        raise ValueError(f'Source crossing evidence changed: {path.name}')
    buckets = fixed.board.joint.read_zip(bid)
    grade = fixed.grade(raw, ready, buckets, 1)
    if grade['state'] != 'scored' or source.paired(grade) != settlement['paired']:
        raise ValueError(f'Could not reproduce witnessed crossings: {path.name}')
    events = {}
    for scope, rows in grade['outcomes']['baseline'].items():
        for row in rows:
            if row['status'] != 'sweep':
                continue
            event = dict(crossing_at=(at + M5).isoformat(), side=row['side'], edge=source.expiry.outer(row)[1],
                         first_bid_ms=row['bid_time_ms'], crossing_ohlc=buckets[0]['ohlc'], scopes=[scope],
                         source=path.name, source_sha256=digest(path))
            key = event_id(event)
            if key in events:
                if events[key]['first_bid_ms'] != event['first_bid_ms']:
                    raise ValueError(f'Same outer edge has conflicting Bid timestamps: {key}')
                if scope not in events[key]['scopes']:
                    events[key]['scopes'].append(scope)
            else:
                events[key] = event
    return list(events.values())


def quote_rows(bars):
    return [[bar.time.isoformat(), *live.quotes.ohlc(bar)] for bar in bars]


def bars_from_rows(rows):
    return {datetime.fromisoformat(t): Bar(datetime.fromisoformat(t), *values, 0) for t, *values in rows}


def prediction(event, offset, prices, policy):
    stamp = datetime.fromisoformat(event['crossing_at'])
    opened, at = stamp - M5, stamp + (offset // 5) * M5
    window = [prices.get(opened + i * M5) for i in range(-15, 1 + offset // 5)]
    if not all(window):
        return None
    prior, first, follow = window[:15], window[15], window[16:]
    if list(live.quotes.ohlc(first)) != event['crossing_ohlc']:
        raise ValueError('Prediction candle differs from the reconciled Bid crossing')
    response = crossing_response(event['side'], event['edge'], prior, first, follow, at)
    atr = response['prior_atr']
    if not atr:
        return None
    value = float(np.clip(event['side'] * (window[-1].close - event['edge']) / atr, -10, 10))
    models = [[np.array(part) for part in params] for params in policy['model']['close_by_offset'][str(offset)]]
    p = study.probabilities(models, [{'x': {offset: [value, abs(value)]}}], offset, len(study.BASE))[0]
    return dict(offset=offset, cutoff=at.isoformat(), price=window[-1].close, atr=atr, signed_distance=value,
                probabilities=dict(zip(study.LABELS, map(float, p), strict=True)), quote_prefix=quote_rows(window))


def outcome(event, prices):
    start = datetime.fromisoformat(event['crossing_at']) + 3 * M5
    rows = [prices.get(start + i * M5) for i in range(6)]
    if not all(rows):
        return dict(label='incomplete', quotes=[])
    signs = [event['side'] * (bar.close - event['edge']) for bar in rows]
    label = 'sweep' if all(x < 0 for x in signs) else 'break' if all(x > 0 for x in signs) else 'mixed'
    return dict(label=label, quotes=quote_rows(rows))


def discover(policy, processed):
    for settlement in sorted((source.OUT/'settlements').glob('*.json')):
        if settlement.name in processed:
            continue
        for event in witnessed(settlement, policy):
            path = OUT / 'events' / f'{event_id(event)}.json'
            if not path.exists():
                fixed.write_once(path, event)
        processed.add(settlement.name)


def poll(policy, now, alive, processed):
    discover(policy, processed)
    pending = [(path, fixed.read(path)) for path in (OUT / 'events').glob('*.json')
               if not (OUT / 'outcomes' / path.name).exists()]
    if not pending:
        return
    earliest = min(datetime.fromisoformat(event['crossing_at']) for _, event in pending)
    closed = now.replace(minute=now.minute // 5 * 5, second=0, microsecond=0)
    if not alive():
        return
    with live.terminal() as (api, clock):
        bars = live.quotes.collect_bars(api, earliest - 16 * M5, closed, clock)
    prices = {bar.time: bar for bar in bars}
    for path, event in pending:
        stamp = datetime.fromisoformat(event['crossing_at'])
        for offset in study.OFFSETS:
            cutoff = stamp + (offset // 5) * M5
            ready_now = live.now()
            if not cutoff <= ready_now < cutoff + M5:
                continue
            name = f'{path.stem}_{offset}.json'
            target, receipt = OUT / 'predictions' / name, OUT / 'receipts' / name
            if receipt.exists():
                continue
            if not target.exists():
                data = prediction(event, offset, prices, policy)
                if data is None:
                    continue
                fixed.write_once(target, dict(**data, event_sha256=digest(path), policy_sha256=digest(POLICY), orders_sent=0))
            fixed.write_once(receipt, dict(available_at=live.now().isoformat(), prediction_sha256=digest(target)))
        end = stamp + 9 * M5
        if closed >= end:
            result = outcome(event, prices)
            if result['label'] == 'incomplete' and closed < end + 2 * M5:
                continue
            fixed.write_once(OUT/'outcomes'/path.name, dict(**result, event_sha256=digest(path),
                                                          settled_at=live.now().isoformat(), orders_sent=0))


def status(policy, *, verify=False):
    totals = defaultdict(Counter)
    for path in sorted((OUT/'receipts').glob('*.json')):
        key, horizon = path.stem.rsplit('_', 1)
        target, event_path = OUT/'predictions'/path.name, OUT/'events'/f'{key}.json'
        data, receipt, event = (fixed.read(p) for p in (target, path, event_path))
        if (receipt['prediction_sha256'] != digest(target) or data['event_sha256'] != digest(event_path)
                or data['policy_sha256'] != digest(POLICY)):
            raise ValueError(f'Forecast provenance changed: {path.name}')
        cut = datetime.fromisoformat(data['cutoff'])
        ready = datetime.fromisoformat(receipt['available_at'])
        counter = totals[horizon]
        if not cut <= ready < cut + M5:
            counter['late'] += 1
            continue
        counter['issued'] += 1
        if verify:
            entries = witnessed(source.OUT/'settlements'/event['source'], policy)
            if event not in entries:
                raise ValueError(f'Event no longer matches the Bid witness: {event_path.name}')
            restored = prediction(event, data['offset'], bars_from_rows(data['quote_prefix']), policy)
            if not restored or any(data[k] != v for k, v in restored.items()):
                raise ValueError(f'Probability no longer reproduces: {path.name}')
        rated = OUT/'outcomes'/event_path.name
        if rated.exists():
            result = fixed.read(rated)
            label = result['label']
            if (result['event_sha256'] != digest(event_path) or
                    datetime.fromisoformat(result['settled_at']) < datetime.fromisoformat(event['crossing_at']) + 9 * M5):
                raise ValueError(f'Outcome has invalid event or timing: {rated.name}')
            if verify and outcome(event,bars_from_rows(result['quotes']))['label'] != label:
                raise ValueError(f'Outcome no longer reproduces: {rated.name}')
            counter[label] += 1
            if label in study.LABELS:
                p = [data['probabilities'][v] for v in study.LABELS]
                counter['scored'] += 1
                counter['model_brier_total'] += sum((q - (v == label))**2 for q,v in zip(p,study.LABELS,strict=True))
                counter['prior_brier_total'] += sum((q - (v == label))**2 for q,v in zip(policy['model']['prior'],study.LABELS,strict=True))
    return dict(frozen_at=policy['frozen_at'], observed_at=live.now().isoformat(),
                witnessed_events=len(list((OUT/'events').glob('*.json'))), offsets=totals, orders_sent=0)


def main():
    import msvcrt

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('watch', 'verify'))
    parser.add_argument('--terminal-pid', type=int)
    args = parser.parse_args()
    if args.mode == 'verify':
        if not POLICY.exists():
            raise FileNotFoundError(POLICY)
        print(json.dumps(status(load_policy(), verify=True), ensure_ascii=False))
        return
    if not args.terminal_pid:
        parser.error('--terminal-pid is required for observation')
    for folder in ('events', 'predictions', 'receipts', 'outcomes'):
        (OUT/folder).mkdir(parents=True, exist_ok=True)
    with fixed.open_terminal(args.terminal_pid) as alive, (OUT/'watch.lock').open('a+b') as lock:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        policy = load_policy()
        processed = set()
        while alive():
            try:
                poll(policy, live.now(), alive, processed)
                report = status(policy)
            except (OSError, RuntimeError, sqlite3.OperationalError) as error:
                report = dict(state='awaiting_data', reason=str(error), observed_at=live.now().isoformat(), orders_sent=0)
            live.atomic_json(OUT/'status.json', report)
            sleep(8)


if __name__ == '__main__':
    main()
