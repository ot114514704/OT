"""Register and settle frozen profile forecasts using only the running TMGM terminal."""

from argparse import ArgumentParser
from datetime import datetime, time, timedelta
from hashlib import sha256
import json
from pathlib import Path
from time import sleep

from scripts import settle_ict_daily_learning as settlement
from scripts import watch_ict_daily_learning as daily
from scripts import watch_ict_intraday_learning as early
from scripts.serve_ict_live import atomic_json, checked_account


ROOT = daily.learning.RESEARCH/'daily_profile_feed_20261123'
EARLY = frozenset(early.CHECKPOINTS)
CHECKPOINTS = (*early.CHECKPOINTS,time(10))
M5 = daily.M5
WINDOW = daily.WINDOW
NY = daily.NY
archive = daily.archive
PROTOCOL_FILES = (Path(__file__),Path(settlement.__file__))


def checkpoint(at):
    return at.astimezone(NY).time()


def signature(bar):
    return settlement.encode_bars([bar])[0]


def digest_rows(rows):
    return sha256(json.dumps(rows,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def read_native_m5(api,alive,model,at):
    """Compare range history with the terminal's most recent M5 sequence."""
    if not alive() or not api.initialize(str(daily.TERMINAL),timeout=2500):
        raise RuntimeError('The bound MT5 terminal is unavailable')
    try:
        account = checked_account(api)
        if account.server!=model['server']:
            raise RuntimeError('The quote server no longer matches the model')
        rows = api.copy_rates_from_pos(model['symbol'],api.TIMEFRAME_M5,0,4)
        checked_account(api,(account.login,account.server))
        if rows is None or not alive():
            raise RuntimeError('The native M5 sequence is unavailable')
        for row in rows:
            stamp = daily.manifest_epoch_to_utc(datetime.fromtimestamp(int(row['time']),daily.UTC),model['clock'])
            if stamp+M5==at:
                return [stamp.isoformat(),*(float(row[k]) for k in ('open','high','low','close'))]
        raise RuntimeError('The exact native M5 close is unavailable')
    finally:
        api.shutdown()


def read_protocol():
    return {p.name:archive.digest(p) for p in PROTOCOL_FILES}


def forecast_path(at):
    return ROOT/f'{at.astimezone(NY):%Y-%m-%d_%H%M}.json'


def register(at, now, source, model, protocol, fetch, current_time):
    """Publish a single atomic record only inside the current decision window."""
    path = forecast_path(at)
    if path.exists():
        return 'recorded'
    if at<=datetime.fromisoformat(model['frozen_at']):
        return 'cutoff_precedes_model'
    if now<at:
        return 'waiting_for_cutoff'
    if now>=at+WINDOW:
        return 'recording_window_elapsed'
    bars,tick,native = fetch(model,at)
    if not bars or tick<at or native!=signature(bars[-1]) or bars[-1].time+M5!=at:
        return 'awaiting_matching_post_cutoff_history'
    scores = source.score(model,bars,at)
    rows = settlement.encode_bars(bars)
    digest = digest_rows(rows)
    recorded_at = current_time()
    if not at<=recorded_at<at+WINDOW:
        return 'recording_window_elapsed'
    if tick>recorded_at+timedelta(seconds=3) or recorded_at-tick>timedelta(seconds=90):
        return 'awaiting_fresh_quote'
    atomic_json(path,dict(**scores,cutoff=at.isoformat(),recorded_at=recorded_at.isoformat(),
                         forecast_end=daily.learning._day_bounds(at.astimezone(NY).date())[1].isoformat(),
                         evidence='mt5_m5_range_and_recent_series_agreed',symbol=model['symbol'],server=model['server'],
                         model_sha256=archive.digest(source.MODEL),code=protocol,native_m5=native,
                         quote_utc=tick.isoformat(),closed_m5=rows,m5_sha256=digest,orders_sent=0))
    return 'recorded'


def validate(path, sources, protocol):
    record = settlement.read_json(path)
    at,registered,tick = (datetime.fromisoformat(record[k]) for k in ('cutoff','recorded_at','quote_utc'))
    local = at.astimezone(NY)
    source,model = sources[checkpoint(at)]
    if (path!=forecast_path(at) or local.weekday()>4 or not at<=registered<at+WINDOW
            or not datetime.fromisoformat(model['frozen_at'])<at<=tick<=registered+timedelta(seconds=3)
            or registered-tick>timedelta(seconds=90) or record['code']!=protocol
            or record['model_sha256']!=archive.digest(source.MODEL) or record['server']!=model['server']
            or record['m5_sha256']!=digest_rows(record['closed_m5'])
            or record['symbol']!=model['symbol'] or record['orders_sent']!=0
            or record['forecast_end']!=daily.learning._day_bounds(local.date())[1].isoformat()):
        raise ValueError(f'Invalid forward record: {path.name}')
    bars = settlement.decode_bars(record['closed_m5'])
    if (not bars or record['native_m5']!=signature(bars[-1]) or bars[-1].time+M5!=at
            or any(a.time>=b.time for a,b in zip(bars,bars[1:]))):
        raise ValueError(f'Invalid MT5 M5 witness: {path.name}')
    if any(record[k]!=v for k,v in source.score(model,bars,at).items()):
        raise ValueError(f'Unreproducible scores: {path.name}')
    return record,bars


def settlement_record(path,record,prefix,tail,captured):
    at = datetime.fromisoformat(record['cutoff'])
    key = 'pooled_probability' if checkpoint(at) in EARLY else 'learned_probability'
    results = settlement.evaluate(record,prefix,tail,captured,probability_key=key)
    rows = settlement.encode_bars(tail)
    return dict(**results,date=at.astimezone(NY).date().isoformat(),cutoff=record['cutoff'],
                forecast_sha256=archive.digest(path),captured_at=captured.isoformat(),
                settlement_m5=rows,m5_sha256=digest_rows(rows),orders_sent=0)


def archived(sources,protocol,fetch=None,now=None):
    scores = {t.strftime('%H:%M'):[] for t in CHECKPOINTS}
    pending = {}
    captured_days = {}
    forecasts = sorted(ROOT.glob('????-??-??_????.json'))
    for path in forecasts:
        target = ROOT/'settlements'/path.name
        record,prefix = validate(path,sources,protocol)
        at = datetime.fromisoformat(record['cutoff'])
        end = datetime.fromisoformat(record['forecast_end'])
        if target.exists():
            saved = settlement.read_json(target)
            tail = settlement.decode_bars(saved['settlement_m5'])
            if saved!=settlement_record(path,record,prefix,tail,datetime.fromisoformat(saved['captured_at'])):
                raise ValueError(f'Unreproducible settlement: {target.name}')
        elif now is None or now<end+settlement.SYNC_GRACE or fetch is None:
            pending[path.stem] = 'waiting_for_day_end' if now is None or now<end+settlement.SYNC_GRACE else 'awaiting_read'
            continue
        else:
            try:
                if end not in captured_days:
                    local = at.astimezone(NY)
                    first = datetime.combine(local.date(),CHECKPOINTS[0],NY)-M5
                    captured_days[end] = fetch(first,end)
                market,captured = captured_days[end]
                tail = [b for b in market if b.time>=at-M5]
                saved = settlement_record(path,record,prefix,tail,captured)
                if saved['status']=='insufficient_m5_coverage' and captured<end+settlement.COVERAGE_GRACE:
                    pending[path.stem] = 'waiting_for_m5_sync'
                    continue
                atomic_json(target,saved)
            except (RuntimeError,OSError,ValueError) as exc:
                pending[path.stem] = str(exc)
                continue
        scores[at.astimezone(NY).strftime('%H:%M')].append(saved)
    return dict(registered=len(forecasts),pending=pending,settlement={name:settlement.rebuild_summary(rows)
                for name,rows in scores.items()})


def main():
    parser = ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--verify',action='store_true')
    mode.add_argument('--terminal-pid',type=int)
    args = parser.parse_args()
    models = {source:source.load_model() for source in (early,daily)}
    sources = {t:(early,models[early]) if t in EARLY else (daily,models[daily]) for t in CHECKPOINTS}
    protocol = read_protocol()
    if args.verify:
        print(json.dumps(archived(sources,protocol,now=daily.utc_now()),ensure_ascii=False))
        return

    import msvcrt
    import MetaTrader5 as api

    ROOT.mkdir(parents=True,exist_ok=True)
    with daily.open_terminal(args.terminal_pid) as alive,(ROOT/'watch.lock').open('a+b') as lock:
        msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)

        def feed(model,at):
            bars,tick = daily.capture(api,alive,model,at)
            return bars,tick,read_native_m5(api,alive,model,at)

        def tail(first,end):
            return settlement.capture_tail(api,alive,models[daily],first,end),daily.utc_now()

        started = daily.utc_now()
        previous = None
        last_review = started-timedelta(minutes=5)
        review = None
        while alive():
            now = daily.utc_now()
            day = now.astimezone(NY).date()
            states = {}
            for clock,(source,model) in sources.items():
                at = datetime.combine(day,clock,NY).astimezone(daily.UTC)
                try:
                    result = ('weekend' if day.weekday()>4 else
                              'cutoff_precedes_observer' if at<started and not forecast_path(at).exists() else
                              register(at,now,source,model,protocol,feed,daily.utc_now))
                except (OSError,RuntimeError) as exc:
                    result = str(exc)
                states[clock.strftime('%H:%M')] = dict(cutoff=at.isoformat(),state=result)
            if states!=previous or now-last_review>=M5:
                review = archived(sources,protocol,tail,now)
                last_review = now
            state = dict(terminal_pid=args.terminal_pid,observer_started=started.isoformat(),checkpoints=states,**review,orders_sent=0)
            if states!=previous or now==last_review:
                atomic_json(ROOT/'status.json',dict(**state,checked_at=now.isoformat()))
                print(now.isoformat(),states,'registered',review['registered'],flush=True)
            previous = states
            sleep(5)


if __name__=='__main__':
    main()
