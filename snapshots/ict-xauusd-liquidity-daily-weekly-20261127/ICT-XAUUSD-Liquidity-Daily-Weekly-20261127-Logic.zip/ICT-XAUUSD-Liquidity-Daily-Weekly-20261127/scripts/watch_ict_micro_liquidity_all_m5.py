"""Observe the same four-bar policy at every acknowledged open M5 cutoff."""

from argparse import ArgumentParser
from collections import Counter
from contextlib import closing
from datetime import datetime
import json
from pathlib import Path
import sqlite3
from time import sleep

from ict_ai.dol_history import batch_id
from ict_ai.range_liquidity import _research_open
from scripts import audit_ict_micro_liquidity_expiry as expiry
from scripts import watch_ict_micro_liquidity_forward as fixed


OUT = fixed.OUT.with_name('ict_micro_liquidity_all_m5_20261125')
POLICY = OUT / 'policy.json'
M5 = fixed.M5
live = fixed.forward
digest = fixed.board.joint.digest


def load_policy():
    parent = fixed.freeze_or_load()
    pins = parent['pins'] | {Path(__file__).name: digest(Path(__file__)), expiry.OUT.name: digest(expiry.OUT)}
    if not POLICY.exists():
        fixed.write_once(POLICY, dict(frozen_at=live.now().isoformat(), pins=pins, fixed_policy_sha256=digest(fixed.POLICY),
                                      cadence='Every open M5 with matching acknowledged native chart batch',
                                      outcome='Count the first strict post-registration Bid crossing through the fifth close; same side and edge count once.',
                                      orders_sent=0))
    record = fixed.read(POLICY)
    if (record['pins'] != pins or record['fixed_policy_sha256'] != digest(fixed.POLICY)):
        raise ValueError('Frozen all-M5 inputs differ from the evaluation policy')
    return record


def read_chart(first, observed):
    uri = live.quotes.DATABASE.resolve().as_uri() + '?mode=ro'
    with closing(sqlite3.connect(uri, uri=True, timeout=2)) as db:
        rows = db.execute('SELECT id,cutoff,received,payload FROM chart_batches WHERE received IS NOT NULL '
                          'AND cutoff>? AND cutoff<=? ORDER BY cutoff,received,id',
                          (first.isoformat(), observed.isoformat())).fetchall()
    for key, stamp, receipt, payload in rows:
        at, accepted = datetime.fromisoformat(stamp), datetime.fromisoformat(receipt)
        if not _research_open(at) or not at <= accepted <= observed < at + M5:
            continue
        sample = json.loads(payload)
        if sample['at'] != stamp or batch_id(at, sample['price'], [sample['targets'], sample['pools']]) != key:
            raise ValueError(f'Chart receipt cannot authenticate the board for {stamp}')
        yield at, accepted, key, sample


def register(policy, model, observed):
    first = max(datetime.fromisoformat(policy['frozen_at']), observed - M5)
    for at, accepted, key, sample in read_chart(first, observed):
        stem = f'{at:%Y%m%dT%H%M%SZ}.json'
        path = OUT / 'boards' / stem
        receipt = OUT / 'receipts' / stem
        rejected = OUT / 'rejections' / f'{path.stem}_{key}.json'
        if receipt.exists() or rejected.exists():
            continue
        try:
            if not path.exists():
                data = fixed.build_lists(at, sample, model)
                fixed.write_once(path, dict(**data, cutoff=at.isoformat(), chart_receipt=accepted.isoformat(),
                                            original_batch=key, policy_sha256=digest(POLICY), orders_sent=0))
            fixed.write_once(receipt, dict(available_at=live.now().isoformat(), board_sha256=digest(path)))
        except live.ReferencePriceMismatch as error:
            fixed.write_once(rejected, dict(cutoff=at.isoformat(), chart_batch=key, reason=str(error)))


def load_board(policy, receipt):
    path = OUT / 'boards' / receipt.name
    data, proof = fixed.read(path), fixed.read(receipt)
    cutoff, chart, available = (datetime.fromisoformat(v) for v in
                                (data['cutoff'], data['chart_receipt'], proof['available_at']))
    if (digest(path) != proof['board_sha256'] or data['policy_sha256'] != digest(POLICY)
            or not datetime.fromisoformat(policy['frozen_at']) < cutoff <= chart <= available):
        raise ValueError(f'Invalid live board provenance: {receipt.name}')
    return data, cutoff, available


def paired(result):
    if result['state'] != 'scored':
        return {}
    scores = {}
    for scope in fixed.board.SCOPES:
        books = result['outcomes']
        edges = [{expiry.outer(mark) for mark in books[mode][scope] if mark['status'] == 'sweep'}
                 for mode in ('baseline', 'early')]
        scores[scope] = dict(baseline_hits=len(edges[0]), early_hits=len(edges[1]),
                             added=len(edges[1] - edges[0]), displaced=len(edges[0] - edges[1]),
                             baseline_preexpired=sum(p['status'] == 'before_board' for p in books['baseline'][scope]),
                             early_preexpired=sum(p['status'] == 'before_board' for p in books['early'][scope]))
    return scores


def settle(policy, alive, source, observed):
    for receipt in sorted((OUT / 'receipts').glob('*.json')):
        path = OUT / 'settlements' / receipt.name
        if path.exists():
            continue
        data, at, ready = load_board(policy, receipt)
        end = at + M5
        if observed < end + fixed.SYNC:
            continue
        buckets = [bucket for _, bucket in fixed.capture_buckets(live.feed.mt5, alive, source, [at], observed)] if ready < end else []
        result = fixed.grade(data, ready, buckets, 1)
        if result['state'] == 'incomplete' and observed < end + fixed.FINAL_RETRY:
            continue
        evidence = OUT / 'bid' / path.with_suffix('.json.gz').name
        temp = evidence.with_suffix('.tmp')
        fixed.board.joint.write_zip(temp, buckets)
        live.feed.replace_with_retry(temp, evidence)
        live.atomic_json(path, dict(state=result['state'], paired=paired(result),
                                   receipts_sha256=digest(receipt), bid_sha256=digest(evidence), orders_sent=0))


def status(policy, *, verify=False):
    observed = live.now()
    freeze = datetime.fromisoformat(policy['frozen_at'])
    first = datetime.fromtimestamp((int(freeze.timestamp()) // 300 + 1) * 300, freeze.tzinfo)
    expected = sum(_research_open(first + i * M5) for i in range((observed - first) // M5))
    receipts = sorted((OUT / 'receipts').glob('*.json'))
    completed = Counter()
    scores = {scope: Counter() for scope in fixed.board.SCOPES}
    qualifying = closed_registered = 0
    latest = None
    for receipt in receipts:
        data, at, ready = load_board(policy, receipt)
        closed_registered += at + M5 <= observed
        qualifying += bool(data['potential_sides'])
        latest = dict(cutoff=data['cutoff'], chart_receipt=data['chart_receipt'], available_at=ready.isoformat(),
                      potential_sides=data['potential_sides'], delay_seconds=(ready-at).total_seconds())
        saved = OUT / 'settlements' / receipt.name
        if not saved.exists():
            continue
        report = fixed.read(saved)
        if report['receipts_sha256'] != digest(receipt):
            raise ValueError(f'Settlement has a different receipt: {receipt.name}')
        if verify:
            evidence = OUT / 'bid' / saved.with_suffix('.json.gz').name
            if report['bid_sha256'] != digest(evidence):
                raise ValueError(f'Settlement has different Bid evidence: {receipt.name}')
            result = fixed.grade(data, ready, fixed.board.joint.read_zip(evidence), 1)
            if report['state'] != result['state'] or report['paired'] != paired(result):
                raise ValueError(f'Settled result differs from its Bid evidence: {receipt.name}')
        completed[report['state']] += 1
        for scope, counts in report['paired'].items():
            scores[scope].update(counts)
    return dict(frozen_at=policy['frozen_at'], observed_at=observed.isoformat(),
                expected_closed_m5=expected, closed_without_registration=expected-closed_registered,
                registrations=len(receipts), qualifying_cutoffs=qualifying,
                rejected_batches=len(list((OUT / 'rejections').glob('*.json'))), latest_registration=latest,
                settlements=completed, paired=scores, orders_sent=0)


def main():
    import msvcrt

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('watch', 'verify'))
    parser.add_argument('--terminal-pid', type=int)
    args = parser.parse_args()
    if args.mode == 'verify':
        if not POLICY.exists():
            raise FileNotFoundError(POLICY)
        print(json.dumps(status(load_policy(), verify=True), ensure_ascii=False))
        return
    if not args.terminal_pid:
        parser.error('--terminal-pid is required for observation')
    for directory in ('boards', 'receipts', 'rejections', 'settlements', 'bid'):
        (OUT / directory).mkdir(parents=True, exist_ok=True)
    source = fixed.frozen_feed()
    model = fixed.board.make_shadow_rank()
    with fixed.open_terminal(args.terminal_pid) as alive, (OUT / 'watch.lock').open('a+b') as lock:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        policy = load_policy()
        while alive():
            try:
                observed = live.now()
                register(policy, model, observed)
                settle(policy, alive, source, observed)
                report = status(policy)
            except (OSError, RuntimeError, sqlite3.OperationalError) as error:
                report = dict(state='awaiting_data', reason=str(error), observed_at=live.now().isoformat(), orders_sent=0)
            live.atomic_json(OUT / 'status.json', report)
            sleep(5)


if __name__ == '__main__':
    main()
