"""Replay the local shortlist and repository supplement on identical TMGM Bid evidence."""

from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path
import json

from ict_ai.liquidity_repo_overlay import compare_shortlists, outside
from scripts import audit_ict_repo_vs_local_horizons as shared
from scripts import audit_ict_liquidity_rank_prev_period as prior


DIR = shared.DIR
INPUT = DIR / 'deduplicated_rank.json'
OUT = DIR / 'repo_overlay.json'
H1_GROUPS = ('oct_nov_H1', 'current_week_H1')


def cutoff_prices():
    historical = shared.fixed.read(prior.OUT)
    recent = shared.joint.read_zip(shared.week.INPUT)
    return {row['cutoff']: row['frozen_price'] for row in historical['cases']} | {
        (datetime.fromisoformat(row[0]) + timedelta(minutes=5)).isoformat(): row[4] for row in recent['m5']}


def replay(result, prices, minutes, bid):
    totals = Counter(windows=0, overlay_offered=0, repo_top2=0, local=0, supplement=0, fixed_two=0,
                     supplement_gained=0, fixed_two_gained=0, fixed_two_lost=0)
    added_types, additions, cases = Counter(), [], []
    for case in result['cases']:
        stamp, books = case['cutoff'], case['outcomes']
        at = datetime.fromisoformat(stamp)
        ready = datetime.fromisoformat(case['checked_from'])
        tape = shared.fixed.reconcile([bid[(at + index * shared.M5).isoformat()]
                                      for index in range(int(minutes) // 5)])
        if not tape:
            raise ValueError(f'Missing reconciled Bid tape at {stamp}')
        for arm in ('local', 'repo_unique'):
            for level in books[arm]:
                if shared.fixed.outcome(level, tape, ready) != (level['status'], level['bid_time_ms']):
                    raise ValueError(f'Bid outcome changed at {stamp}, {arm}')
        picks = compare_shortlists(books['local'], books['repo_unique'], prices[stamp])
        wins = {name: any(row['status'] == 'sweep' for row in shortlist)
                for name, shortlist in picks.items() if name != 'extra'}
        extra = picks['extra']
        offered = extra is not None
        totals.update(windows=1, overlay_offered=int(offered), repo_top2=int(any(
            row['status'] == 'sweep' for row in books['repo_unique'])), **{key: int(value) for key, value in wins.items()})
        totals['fixed_two_gained'] += wins['fixed_two'] and not wins['local']
        totals['fixed_two_lost'] += wins['local'] and not wins['fixed_two']
        if wins['supplement'] and not wins['local']:
            totals['supplement_gained'] += 1
            added_types[extra['kind']] += 1
            additions.append(dict(cutoff=stamp, close=prices[stamp], local_edges=[outside(p) for p in picks['local']],
                                  candidate=extra))
        cases.append(dict(cutoff=stamp, checked_from=case['checked_from'], close=prices[stamp], selected=picks, wins=wins))
    expected = result['counts']
    if [totals['windows'], totals['local'], totals['repo_top2']] != [
            expected['windows'], expected['local_top2'], expected['unique_top2']]:
        raise ValueError('Control totals differ from the frozen paired replay')
    return dict(counts=totals, added_types=added_types, additions=additions, cases=cases)


def main():
    dig = shared.joint.digest
    source = shared.fixed.read(INPUT)
    raw = shared.fixed.read(shared.INPUT)
    paths = (shared.INPUT, shared.OUT, shared.BID, shared.week.INPUT)
    if (any(source['inputs'][p.name] != dig(p) for p in paths)
            or raw['inputs'][prior.OUT.name] != dig(prior.OUT)):
        raise ValueError('The archived forecasts, outcomes or closing prices changed')
    prices = cutoff_prices()
    bid = shared.joint.read_zip(shared.BID)['buckets']
    actual = shared.joint.read_zip(shared.week.INPUT)['actual']
    for stamp, entries in actual.items():
        if entries.get('buckets'):
            bid.setdefault(stamp, entries['buckets'][0])
    groups = {name: {minutes: replay(result, prices, minutes, bid) for minutes, result in tests.items()}
              for name, tests in source['results'].items() if name in H1_GROUPS}
    # A horizon changes the outcomes, never the selections at an identical cutoff.
    for group in groups.values():
        selections = {}
        for outcome in group.values():
            for case in outcome['cases']:
                keys = {name: list(map(outside, picks)) for name, picks in case['selected'].items() if name != 'extra'}
                if selections.setdefault(case['cutoff'], keys) != keys:
                    raise ValueError('The shortlist changed across outcome horizons')
    pins = {p.name: dig(p) for p in (INPUT, *paths, prior.OUT, Path(__file__),
                                     shared.joint.ROOT / 'ict_ai/liquidity_repo_overlay.py')}
    shared.live.atomic_json(OUT, dict(results=groups, inputs=pins, orders_sent=0,
        method='Same frozen H1 cutoffs and strict post-availability TMGM Bid outcomes. One distinct upstream level can supplement the two local ERL picks. The two-slot replacement is a separate control. Retrospective evaluation.'))
    print(json.dumps({name: {minutes: result['counts'] for minutes, result in tests.items()}
                      for name, tests in groups.items()}), flush=True)


if __name__ == '__main__':
    main()
