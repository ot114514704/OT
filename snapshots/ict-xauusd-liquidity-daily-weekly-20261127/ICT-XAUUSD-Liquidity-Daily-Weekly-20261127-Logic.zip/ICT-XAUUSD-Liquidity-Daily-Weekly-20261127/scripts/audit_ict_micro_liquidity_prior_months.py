"""Replay the fixed four-bar shadow policy on June–September TMGM boards."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime
import json
from pathlib import Path

from ict_ai.dol_tick_evidence import utc_ms
from scripts import audit_ict_micro_liquidity_board as board
from scripts import audit_ict_micro_liquidity_latency as delay
from scripts.serve_ict_live import atomic_json


OUT = board.joint.RESEARCH / 'ict_micro_liquidity_prior_months_20261125.json'
TIMING = OUT.with_name('ict_micro_liquidity_prior_months_timing_20261125.json')
TICK_ARCHIVE = TIMING.with_suffix('.json.gz')
MONTHS = tuple(f'2026-{i:02}' for i in range(6, 10))
DELAYS = (0, 15, 30, 60, 120, 300)
digest = board.joint.digest


def month(at):
    return datetime.fromisoformat(at).astimezone(board.NY).strftime('%Y-%m')


def replay():
    lock = json.loads(board.LOCK.read_bytes())
    hashes = {name: digest(board.joint.ROOT / name) for name in lock['sources']}
    if hashes != lock['sources'] or digest(board.FROZEN) != lock['candidates']:
        raise ValueError('Baseline input hashes differ from the original freeze')
    recent = json.loads(board.OUT.read_bytes())
    if (recent['baseline_sha256'] != lock['candidates'] or recent['code_sha256'] != digest(Path(board.__file__))
            or recent['micro_study_sha256'] != digest(Path(board.early.__file__))):
        raise ValueError('The previously tested four-bar rule or baseline has changed')
    originals = {row['at']: row for row in board.joint.read_zip(board.INIT)}
    archived = [row for row in board.joint.read_zip(board.FROZEN) if month(row['at']) in MONTHS]
    tasks = [(originals[row['at']], row, i % 25 == 0) for i, row in enumerate(archived)]
    rows = []
    with ProcessPoolExecutor(max_workers=3, initializer=board.initialize) as pool:
        for i, row in enumerate(pool.map(board.replay, tasks, chunksize=4), 1):
            rows.append(row)
            if i % 50 == 0:
                print(f'{i}/{len(tasks)} cutoffs replayed', flush=True)
    results, examples = board.compare_windows(rows)
    by_month = {}
    for period in MONTHS:
        sample = [row for row in rows if month(row['at']) == period]
        grouped, _ = board.compare_windows(sample)
        by_month[period] = dict(cutoffs=len(sample), qualifying=sum(bool(row['potential']) for row in sample),
                                results=grouped)
    for label, stats in results.items():
        for key, expected in stats.items():
            if sum(part['results'][label][key] for part in by_month.values()) != expected:
                raise ValueError(f'Monthly replay does not reconcile: {label}/{key}')
    report = dict(cutoffs=len(rows), qualifying=sum(bool(row['potential']) for row in rows),
                  controls=sum(row['checked'] and not row['potential'] for row in rows),
                  first=rows[0]['at'], last=rows[-1]['at'],
                  with_m1=sum(row['has_m1'] for row in archived), results=results, months=by_month,
                  changed_outcomes=examples, sources=hashes | {board.FROZEN.name: lock['candidates'],
                      board.OUT.name: digest(board.OUT), 'board_code': recent['code_sha256'],
                      'early_code': recent['micro_study_sha256'], Path(__file__).name: digest(Path(__file__))},
                  methodology='Same fixed NY observations, top-ten IRL/ERL, one ATR, four bars with five-bar fallback, strict far-edge crossing.',
                  orders_sent=0)
    atomic_json(OUT, report)
    print(json.dumps({key: dict(value) for key, value in results.items()}, ensure_ascii=False))


def latency(pid):
    archive_hash = digest(OUT)
    report = json.loads(OUT.read_bytes())
    starts = delay.affected_starts(report)
    shadow = delay.shadow
    source = shadow.frozen_feed()
    observed = shadow.forward.now()
    with shadow.open_terminal(pid) as alive:
        ticks = {at.isoformat(): bucket for at, bucket in
                 shadow.capture_buckets(shadow.forward.feed.mt5, alive, source, starts, observed)}
    board.joint.write_zip(TICK_ARCHIVE, dict(replay_sha256=archive_hash, captured_at=observed.isoformat(),
                                            requested_slots=len(starts), slots=ticks, orders_sent=0))
    board.original.initialize()
    five = {bar.time: bar for bar in board.original.bars}
    minutes = {bar.time: bar for bar in board.original.minutes}
    bounds, stats = {}, defaultdict(Counter)
    for row in report['changed_outcomes']:
        cutoff = datetime.fromisoformat(row['at'])
        label = f'{row["horizon"]}/{row["scope"]}'
        for direction in ('gained', 'lost'):
            for hit in row[direction]:
                side, low, high = hit['band']
                edge = high if side == 1 else low
                at = datetime.fromisoformat(hit['swept']) - board.M5
                if at < cutoff:
                    raise ValueError('Recorded crossing precedes the original cutoff')
                if at <= cutoff + board.M5:
                    key = row['at'], at.isoformat(), side, edge
                    if key not in bounds:
                        bounds[key] = delay.crossing_window(at, side, edge, five, minutes, ticks.get(at.isoformat()))
                    timing = bounds[key]
                else:
                    timing = dict(earliest_ms=utc_ms(at), latest_exclusive_ms=utc_ms(at + board.M5))
                for seconds in DELAYS:
                    state = delay.eligible(timing, utc_ms(cutoff) + 1000 * seconds, seconds)
                    stats[label, seconds][f'{direction}_{state}'] += 1
    result = {}
    for name, original in report['results'].items():
        for seconds in DELAYS:
            counts = stats[name, seconds]
            net = counts['gained_eligible'] - counts['lost_eligible']
            low, high = net - counts['lost_ambiguous'], net + counts['gained_ambiguous']
            if seconds == 0 and (low != high or low != original['after_hits'] - original['before_hits']):
                raise ValueError('Zero-delay result does not reconcile with the prior-month replay')
            result[f'{name}/{seconds}'] = dict(counts, net_lower=low, net_upper=high)
    resolutions = Counter(b['resolution'] for b in bounds.values())
    atomic_json(TIMING, dict(replay_sha256=archive_hash, ticks_sha256=digest(TICK_ARCHIVE),
                             requested_tick_slots=len(starts), matched_tick_slots=len(ticks),
                             resolutions=resolutions, delays=DELAYS, results=result,
                             evidence=[dict(cutoff=key[0], opened=key[1], side=key[2], edge=key[3], **value)
                                       for key, value in sorted(bounds.items())],
                             method='Count changed hits after a shared simulated delay. Verified M1/M5 gives bounds if native ticks are unavailable.',
                             orders_sent=0))
    print(dict(resolutions=resolutions, quarter={s: result[f'quarter/IRL/{s}'] for s in DELAYS}))


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--terminal-pid', type=int, help='With a completed replay, collect read-only timing evidence')
    args = parser.parse_args()
    if args.terminal_pid is None:
        replay()
    else:
        latency(args.terminal_pid)


if __name__ == '__main__':
    main()
