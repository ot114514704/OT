"""Compare frozen price-chart reviews with the archived IPDA/time replay."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path


DIRECTIONS = {1: "bullish", -1: "bearish", None: None}


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def normalized(labels, daily):
    return [[code, DIRECTIONS[side]] for code, side in labels] if daily else labels


def result(expected, observed):
    if sorted(expected, key=str) == sorted(observed, key=str):
        return "same_path" if expected else "both_unclassified"
    if not observed:
        return "missed_path"
    if not expected:
        return "extra_path"
    return "different_path"


def compare(chart, key_path, manual_path, replay_path):
    key, manual, replay = [read(path) for path in (key_path, manual_path, replay_path)]
    chart_hash = digest(chart)
    if key["chart_sha256"] != chart_hash or manual["chart_sha256"] != chart_hash:
        raise ValueError("Review, chart and key must all refer to the same frozen sample")
    if key["sampling"] != manual["sampling"] or key["sources"] != replay["quote_sources"]:
        raise ValueError("Sample and archived replay must use the same sources and time settings")
    cases = {row["id"]: row for row in manual["cases"]}
    if set(cases) != set(key["keys"]) or len(cases) != len(manual["cases"]):
        raise ValueError("Every chart requires exactly one review")
    checks = replay["classification_checks"]
    indexed = {"daily": {row["date"]: row for row in checks["daily"]},
               "weekly": {row["monday"]: row for row in checks["weekly"]}}
    rows, summaries = [], {}
    for sample_id, day in key["keys"].items():
        kind = "daily" if " · " in sample_id else "weekly"
        recorded = indexed[kind][day]
        if recorded["result"] == "unscored_incomplete":
            raise ValueError(f"Replay treats {day} as incomplete")
        review = cases[sample_id]
        expected = review["labels"]
        row = {"id": sample_id, "date": day, "period": kind, "reviewed": expected,
               "review_evidence": review["evidence"]}
        for stage in ("forecast", "close_review"):
            observed = normalized(recorded[stage], kind == "daily")
            row[stage] = {"labels": observed, "result": result(expected, observed),
                          "model_reason": recorded[f"{stage}_reason"]}
        rows.append(row)
    for period in indexed:
        subset = [row for row in rows if row["period"] == period]
        def measures(stage):
            outcomes = Counter(row[stage]["result"] for row in subset)
            return {"outcomes": dict(outcomes), "exact": outcomes["same_path"] + outcomes["both_unclassified"],
                    "nonempty_model": sum(bool(row[stage]["labels"]) for row in subset),
                    "positive_with_correct_label": sum(
                        any(label in row[stage]["labels"] for label in row["reviewed"]) for row in subset)}

        summaries[period] = {"cases": len(subset), "reviewed_positive": sum(bool(row["reviewed"]) for row in subset),
                             **{stage: measures(stage)
                                for stage in ("forecast", "close_review")}}
    return {"scope": manual["scope"], "familiarity": manual["familiarity"],
            "sampling": manual["sampling"], "chart_sha256": chart_hash,
            "frozen_review_sha256": digest(manual_path), "replay_sha256": digest(replay_path),
            "forecast_cutoffs": {"daily": checks["daily_cutoff"], "weekly": checks["weekly_cutoff"]},
            "summaries": summaries, "cases": rows}


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    for option in ("chart", "key", "review", "replay", "out"):
        cli.add_argument(f"--{option}", required=True, type=Path)
    args = cli.parse_args()
    comparison = compare(args.chart, args.key, args.review, args.replay)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(comparison, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(comparison["summaries"], indent=2))
