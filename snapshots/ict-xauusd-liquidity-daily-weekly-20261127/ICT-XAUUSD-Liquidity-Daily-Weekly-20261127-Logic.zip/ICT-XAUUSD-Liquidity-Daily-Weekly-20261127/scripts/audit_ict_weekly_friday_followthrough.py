"""Replay the Friday evidence for weekly consolidation variants on frozen TMGM M5."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter
from datetime import date, timedelta
import json
from pathlib import Path

from ict_ai.weekly_friday_followthrough import CONTINUATION, REVERSAL, friday_followthrough
from ict_ai.weekly_path import _profile_candidates, weekly_path
from scripts import audit_ict_weekly_candidates as baseline
from scripts import audit_ict_weekly_midweek as gap_archive
from scripts.serve_ict_live import atomic_json


MARKET = baseline.market
OUT = MARKET.RESEARCH / "ict_weekly_friday_followthrough_20261126.json"


def key(card):
    return card["id"], card["variant"], card["direction"]


def witnessed_weeks(path):
    if path is None:
        return {}
    report = json.loads(path.read_bytes())
    inputs = (gap_archive.OUT, MARKET.ARCH / "XAUUSDM5.npz", MARKET.ARCH / "clock_validation.json")
    for source in inputs:
        if report["sources"][source.name] != MARKET.digest(source):
            raise ValueError(f"The native/tick evidence uses a different input: {source.name}")
    observed = {row["at_ny"] for row in report["cases"]
                if row["status"] == "no_quote_with_matching_tick_bookends"
                and row["native_gap_reproduced"] and row["gap_tick_count"] == 0
                and row["native_gap_bar"] is None and len(row["tick_bookends"]) == 4
                and all(bookend["match"] is True for bookend in row["tick_bookends"])}
    archived = json.loads(gap_archive.OUT.read_bytes())
    restored = {}
    for week in archived["weeks"]:
        coverage = week["coverage"]
        missing = {stamp for day in coverage.values() for stamp in day["missing"]}
        if len(coverage) == 5 and missing and missing <= observed:
            restored[week["week"]] = missing
    return restored


def day_review(bars, days, at, restored):
    review = weekly_path(bars, days, at)
    if restored:
        coverage = gap_archive.day_coverage(bars, days, at)
        for row in review["daily"]:
            if row["ended"] and not row["coverage_complete"]:
                missing = set(coverage[row["date"]]["missing"])
                row["coverage_complete"] = bool(missing) and missing <= restored
    return review


def run(reopen=None):
    old = json.loads(baseline.OUT.read_bytes())
    prices = MARKET.ARCH / "XAUUSDM5.npz"
    clock = MARKET.ARCH / "clock_validation.json"
    for path in (prices, clock, Path("ict_ai/weekly_path.py"), Path("ict_ai/profile_lifecycle.py")):
        if old["source_sha256"][path.name] != MARKET.digest(path):
            raise ValueError(f"Weekly replay input has changed: {path}")
    bars, times = MARKET.read_market()
    restored = witnessed_weeks(reopen)
    rows = []
    for week in old["timeline"]:
        adjusted = restored.get(week["week"])
        if not week["settled"]["covered"] and not adjusted:
            continue
        monday = date.fromisoformat(week["week"])
        days = [monday + timedelta(days=index) for index in range(5)]
        start, end = baseline._day_bounds(days[0])[0], baseline._day_bounds(days[-1])[1]
        friday = baseline._day_bounds(days[-1])[0]
        left = bisect_left(times, start)
        whole = bars[left:bisect_left(times, end)]
        quarters = MARKET.aggregate_bars(whole, 5, 15, end)
        realized = week["settled"]["realized"]
        if adjusted:
            mature = day_review(whole, days, end, adjusted)
            if len(mature["daily"]) != 5 or not all(day["ended"] and day["coverage_complete"] for day in mature["daily"]):
                raise ValueError(f"Missing complete market day in recovered week {monday}")
            realized = [card for card in _profile_candidates(mature["daily"], days, end)
                        if card.get("path_complete") and card.get("observed_sequence")]
        truth = sorted(key(card) for card in realized
                       if card["id"] == REVERSAL or card.get("variant") == CONTINUATION)
        states = {}
        for name, at in {"thursday_close": friday, **{k: friday + v for k, v in baseline.FRIDAY.items()}}.items():
            archive_checkpoint = "thursday" if name == "thursday_close" else name
            historical_coverage = week[archive_checkpoint]["covered"]
            observed = day_review(whole, days, at, adjusted)
            covered = historical_coverage
            if adjusted:
                covered = all(day["coverage_complete"] for day in observed["daily"] if day["ended"])
                # The reopened week was verified in full above. The Friday
                # checkpoint uses only bars whose M15 closes have elapsed.
            state = friday_followthrough(observed, quarters, days, at, covered)
            prefix = bars[left:bisect_left(times, at)]
            prefix_quarters = MARKET.aggregate_bars(prefix, 5, 15, at)
            if state != friday_followthrough(day_review(prefix, days, at, adjusted), prefix_quarters, days, at, covered):
                raise AssertionError(f"Future bars changed the weekly watch at {at.isoformat()}")
            states[name] = {"eligible": covered, "as_of_ny": at.astimezone(baseline.NY).isoformat(), "cards": state}
        rows.append({"week": week["week"], "truth": truth, "checkpoints": states,
                     "coverage_basis": "tick_witnessed_reopening" if adjusted else "original_complete_m5",
                     "verified_no_quote_slots": sorted(adjusted or ())})

    summary = {}
    for name in ("thursday_close", *baseline.FRIDAY):
        counts = Counter()
        by_variant = {}
        for row in rows:
            state = row["checkpoints"][name]
            if not state["eligible"]:
                counts["coverage_missing"] += 1
                continue
            counts["weeks"] += 1
            counts["realized_paths"] += len(row["truth"])
            for _, variant, _ in row["truth"]:
                by_variant.setdefault(variant, Counter())["realized_paths"] += 1
            for card in state["cards"]:
                variant = by_variant.setdefault(card["variant"], Counter())
                counts[card["status"]] += 1
                variant[card["status"]] += 1
                if card["status"] == "observed_candidate":
                    matched = key(card) in row["truth"]
                    counts["matched_exact_path"] += matched
                    variant["matched_exact_path"] += matched
        summary[name] = {**counts, "variants": by_variant}
    return {"weeks": len(rows), "archive_weeks": old["weeks"],
            "tick_witnessed_weeks": sorted(restored),
            "reopen_audit_sha256": MARKET.digest(reopen) if reopen is not None else None,
            "prefix_checks": sum(len(row["checkpoints"]) for row in rows),
            "summary": summary, "rows": rows, "quote_sha256": MARKET.digest(prices),
            "baseline_sha256": MARKET.digest(baseline.OUT),
            "method_sha256": {p.name: MARKET.digest(p) for p in (
                Path(__file__), Path("ict_ai/weekly_friday_followthrough.py"),
                Path("research/ict_time_videos/time3_weekly/integration.json"),
            )},
            "scope": ("Three-day range frozen from complete Monday to Wednesday quotes. "
                      "Thursday must be closed before the experiment enrolls a branch. "
                      "Two closed Friday M15 observations beyond the reference are engineering evidence. "
                      "Truth is the completed price-path rule; bias, PDA and DOL remain separate."), "orders_sent": 0}


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--out", type=Path, default=OUT)
    cli.add_argument("--reopen-audit", type=Path,
                     help="Retrospective coverage sensitivity using exact, tick-witnessed no-quote slots")
    args = cli.parse_args()
    report = run(args.reopen_audit)
    atomic_json(args.out, report)
    print(json.dumps(report["summary"]))
