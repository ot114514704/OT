"""Freeze two liquidity rankings as M5 windows arrive and compare their first Bid sweep."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from datetime import datetime
import json
from pathlib import Path
from time import sleep

from scripts import audit_ict_liquidity_window_rank as ranking
from scripts import watch_ict_micro_liquidity_all_m5 as source


fixed, live, M5 = source.fixed, source.live, source.M5
read, digest = fixed.read, source.digest
OUT = ranking.OUT.with_name('ict_liquidity_window_rank_forward_20261125')
POLICY = OUT / 'policy.json'
METHODS = ('score_1', 'near_1', 'score_2', 'near_2')


def load_policy():
    inputs = (Path(__file__).resolve(), Path(ranking.__file__).resolve(), source.POLICY, ranking.OUT)
    pins = {path.name: digest(path) for path in inputs}
    if not POLICY.is_file():
        live.atomic_json(POLICY, dict(frozen_at=live.now().isoformat(), pins=pins, methods=METHODS,
                                     window='First strict Bid crossing from actual selection availability to M5 close.',
                                     orders_sent=0))
    policy = read(POLICY)
    if policy['pins'] != pins or tuple(policy['methods']) != METHODS:
        raise ValueError('Prospective ranking inputs changed')
    return policy


def picks(raw):
    return {
        scope: {key: [list(edge) for edge in value] for key, value in ranking.picks(
            raw['early'][scope], raw['cutoff_close']).items() if key in METHODS}
        for scope in fixed.board.SCOPES
    }


def register(policy, source_policy):
    now = live.now()
    freeze = datetime.fromisoformat(policy['frozen_at'])
    for native in sorted((source.OUT / 'receipts').glob('*.json')):
        stamp = datetime.strptime(native.stem, '%Y%m%dT%H%M%SZ').replace(tzinfo=freeze.tzinfo)
        if not freeze <= stamp <= now < stamp + M5:
            continue
        proof = OUT / 'receipts' / native.name
        if proof.is_file():
            continue
        raw, cutoff, board_ready = source.load_board(source_policy, native)
        if not freeze <= cutoff <= board_ready <= now:
            continue
        target = OUT / 'windows' / native.name
        record = dict(cutoff=raw['cutoff'], board_available_at=board_ready.isoformat(), price=raw['cutoff_close'],
                      picks=picks(raw), board_receipt_sha256=digest(native), policy_sha256=digest(POLICY))
        if target.is_file():
            if read(target) != record:
                raise ValueError(f'Previously written selection differs at {cutoff}')
        else:
            live.atomic_json(target, record)
        available = live.now()
        if cutoff <= available < cutoff + M5:
            live.atomic_json(proof, dict(available_at=available.isoformat(), selection_sha256=digest(target)))


def validated_selection(policy, source_policy, proof):
    target = OUT / 'windows' / proof.name
    native = source.OUT / 'receipts' / proof.name
    window, receipt = read(target), read(proof)
    raw, cutoff, original = source.load_board(source_policy, native)
    ready = datetime.fromisoformat(receipt['available_at'])
    if (receipt['selection_sha256'] != digest(target) or window['board_receipt_sha256'] != digest(native)
            or not datetime.fromisoformat(policy['frozen_at']) <= cutoff <= original <= ready < cutoff + M5
            or window['policy_sha256'] != digest(POLICY)
            or window['cutoff'] != cutoff.isoformat() or window['board_available_at'] != original.isoformat()
            or window['price'] != raw['cutoff_close'] or picks(raw) != window['picks']):
        raise ValueError(f'The real-time selection is inconsistent at {cutoff}')
    return window, raw, ready, native


def evaluate(window, raw, ready, buckets):
    grade = fixed.grade(raw, ready, buckets, 1)
    results = {}
    if grade['state'] == 'scored':
        for scope, levels in grade['outcomes']['early'].items():
            first, edges = ranking.first_strict(levels)
            results[scope] = dict(first_bid_ms=first, edges=[list(edge) for edge in sorted(edges)],
                 hits={method: bool(edges.intersection(map(tuple, selected)))
                       for method, selected in window['picks'][scope].items()},
                 consumed_before_selection=sum(row['status'] == 'before_board' for row in levels))
    return dict(state=grade['state'], results=results)


def grade_sources(raw, native):
    path = source.OUT / 'settlements' / native.name
    if not path.is_file():
        return None
    data = read(path)
    bid = source.OUT / 'bid' / path.with_suffix('.json.gz').name
    if data['receipts_sha256'] != digest(native) or data['bid_sha256'] != digest(bid):
        raise ValueError(f'Native Bid settlement link changed: {native.name}')
    buckets = fixed.board.joint.read_zip(bid)
    original_ready = datetime.fromisoformat(read(native)['available_at'])
    checked = fixed.grade(raw, original_ready, buckets, 1)
    if checked['state'] != data['state'] or source.paired(checked) != data['paired']:
        raise ValueError(f'Original chart settlement did not reproduce: {native.name}')
    return buckets, digest(path), digest(bid)


def settle(policy, source_policy):
    for proof in sorted((OUT / 'receipts').glob('*.json')):
        settlement = OUT / 'outcomes' / proof.name
        if settlement.is_file():
            continue
        window, raw, ready, native = validated_selection(policy, source_policy, proof)
        evidence = grade_sources(raw, native)
        if evidence is None:
            continue
        buckets, native_sha, bid_sha = evidence
        live.atomic_json(settlement, dict(**evaluate(window, raw, ready, buckets), receipt_sha256=digest(proof),
            native_settlement_sha256=native_sha, bid_sha256=bid_sha, settled_at=live.now().isoformat()))


def status(policy, source_policy, *, verify=False):
    receipts = sorted((OUT / 'receipts').glob('*.json'))
    stages = Counter()
    by_scope = defaultdict(Counter)
    latest = None
    for proof in receipts:
        window, raw, ready, native = validated_selection(policy, source_policy, proof)
        latest = dict(cutoff=window['cutoff'], available_at=ready.isoformat(), picks=window['picks'])
        out = OUT / 'outcomes' / proof.name
        if not out.is_file():
            stages['pending_outcome'] += 1
            continue
        done = read(out)
        if (done['receipt_sha256'] != digest(proof)
                or datetime.fromisoformat(done['settled_at']) < datetime.fromisoformat(window['cutoff']) + M5):
            raise ValueError(f'The settlement receipt is inconsistent: {proof.name}')
        if verify:
            buckets, native_sha, bid_sha = grade_sources(raw, native)
            if any(done[key] != value for key, value in evaluate(window, raw, ready, buckets).items()) or (
                    done['bid_sha256'] != bid_sha or done['native_settlement_sha256'] != native_sha):
                raise ValueError(f'First Bid outcome did not reproduce: {proof.name}')
        stages[done['state']] += 1
        for scope, result in done['results'].items():
            by_scope[scope]['windows'] += 1
            by_scope[scope]['with_first_sweep'] += result['first_bid_ms'] is not None
            by_scope[scope].update({key: int(value) for key, value in result['hits'].items()})
    return dict(frozen_at=policy['frozen_at'], observed_at=live.now().isoformat(), registered=len(receipts),
                stages=stages, scopes=by_scope, latest=latest, orders_sent=0)


def main():
    import msvcrt

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('watch', 'verify'))
    parser.add_argument('--terminal-pid', type=int)
    args = parser.parse_args()
    parent = source.load_policy()
    if args.mode == 'verify':
        if not POLICY.is_file():
            raise FileNotFoundError(POLICY)
        print(json.dumps(status(load_policy(), parent, verify=True), ensure_ascii=False))
        return
    if not args.terminal_pid:
        parser.error('--terminal-pid is required for watch mode')
    for folder in ('windows', 'receipts', 'outcomes'):
        (OUT / folder).mkdir(parents=True, exist_ok=True)
    with fixed.open_terminal(args.terminal_pid) as alive, (OUT / 'watch.lock').open('a+b') as lock:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        policy = load_policy()
        while alive():
            try:
                register(policy, parent)
                settle(policy, parent)
                report = status(policy, parent)
            except (OSError, RuntimeError, ValueError) as error:
                report = dict(observed_at=live.now().isoformat(), error=str(error), orders_sent=0)
            live.atomic_json(OUT / 'status.json', report)
            sleep(4)


if __name__ == '__main__':
    main()
