"""Compare a dated narrative with immutable MT5 evidence; never place orders.

Claims are data, not classification overrides. Price agreement is evaluated only
under an explicitly supplied clock hypothesis. Five-minute candles identify an
event interval, not its exact tick time or the ordering of its high and low.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from dataclasses import replace
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from brooks_ai.types import Bar, utc_time
from ict_ai.profile_lifecycle import daily_profile_lifecycle
from ict_ai.timebase import NY
from scripts.prepare_ict_week import aggregate_bars

PERIOD = timedelta(minutes=5)
BJT = ZoneInfo('Asia/Shanghai')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_snapshot(manifest):
    meta = json.loads(manifest.read_text(encoding='utf-8'))
    if meta.get('synthetic') is not False or meta.get('volatile_live_snapshot') is not False:
        raise ValueError('An immutable, non-synthetic snapshot is required')
    dataset = next(d for d in meta['datasets'] if d['timeframe'] == 'M5')
    path = Path(dataset['data_path'])
    if not path.is_absolute():
        path = ROOT / path
    if sha(path) != dataset['data_sha256']:
        raise ValueError('CSV digest does not match its manifest')
    with path.open(encoding='utf-8-sig', newline='') as stream:
        bars = [Bar(utc_time(r['time']), *(float(r[k]) for k in
                ('open', 'high', 'low', 'close', 'spread'))) for r in csv.DictReader(stream)]
    if not bars or any(a.time >= b.time for a, b in zip(bars, bars[1:])):
        raise ValueError('Unique chronological M5 bars required')
    return meta, bars


def event(bar, price):
    return {'price': price, 'bar_start_utc': bar.time.isoformat(),
            'bar_start_bjt': bar.time.astimezone(BJT).isoformat(),
            'bar_start_ny': bar.time.astimezone(NY).isoformat(),
            'known_at_utc': (bar.time + PERIOD).isoformat()}


def window_facts(bars, start, end, as_of):
    start, end, as_of = map(utc_time, (start, end, as_of))
    if end <= start or (end-start) % PERIOD or start.timestamp() % PERIOD.total_seconds():
        raise ValueError('Positive M5-aligned half-open window required')
    part = [b for b in bars if start <= b.time < end and b.time + PERIOD <= as_of]
    expected = int((end-start)/PERIOD)
    stamps = {b.time for b in part}
    missing = [start+i*PERIOD for i in range(expected) if start+i*PERIOD not in stamps]
    result = {'start_utc': start.isoformat(), 'end_utc': end.isoformat(),
              'bars': len(part), 'expected_grid_bars': expected,
              'complete_wall_clock_grid': not missing, 'window_ended': as_of >= end,
              'missing_grid_bar_starts': [t.isoformat() for t in missing],
              'gap_policy': 'Missing grid bars are not automatically treated as a verified market recess.'}
    if part:
        lo, hi = min(part, key=lambda b: b.low), max(part, key=lambda b: b.high)
        result.update(open=part[0].open, close=part[-1].close,
                      low=event(lo, lo.low), high=event(hi, hi.high),
                      last_close_at=(part[-1].time+PERIOD).isoformat())
    return result


def evaluate_claim(claim, facts):
    """Contradiction needs one observed counterexample; confirmation needs coverage."""
    kind = claim['kind']
    complete = facts['complete_wall_clock_grid'] and facts['window_ended']
    if not facts['bars']:
        return 'insufficient_data'
    if kind == 'contained_range':
        if facts['low']['price'] < claim['lower'] or facts['high']['price'] > claim['upper']:
            return 'contradicted_by_observed_prices'
        return 'supported_under_clock_hypothesis' if complete else 'insufficient_data'
    if kind not in ('low_near', 'high_near'):
        raise ValueError('Unsupported narrative claim kind')
    if not complete:
        return 'insufficient_data'
    value = facts['low' if kind == 'low_near' else 'high']['price']
    return ('supported_under_clock_hypothesis' if abs(value-claim['price']) <= claim['tolerance']
            else 'contradicted_by_observed_prices')


def audit(manifest, claims_path, offset_hours):
    meta, raw = load_snapshot(manifest)
    if abs(offset_hours) > 14:
        raise ValueError('Invalid source clock hypothesis')
    claims = json.loads(claims_path.read_text(encoding='utf-8'))
    day = date.fromisoformat(claims['ny_date'])
    as_of = utc_time(meta['finished_at_utc'])
    bars = [replace(b, time=b.time-timedelta(hours=offset_hours)) for b in raw]
    bars = [b for b in bars if b.time+PERIOD <= as_of]
    start = datetime.combine(day, datetime.min.time(), NY)
    end = datetime.combine(day+timedelta(days=1), datetime.min.time(), NY)
    checked = []
    for claim in claims['claims']:
        facts = window_facts(bars, claim['start'], claim['end'], as_of)
        checked.append({'claim': claim, 'facts': facts, 'verdict': evaluate_claim(claim, facts)})
    checkpoints = []
    for value in claims['replay_cutoffs']:
        cutoff = utc_time(value)
        if cutoff > as_of:
            continue
        full_m15 = aggregate_bars(bars, 5, 15, cutoff)
        full = daily_profile_lifecycle(full_m15, day, cutoff, reference_m5=bars)
        prefix = [b for b in bars if b.time+PERIOD <= cutoff]
        sliced = daily_profile_lifecycle(aggregate_bars(prefix, 5, 15, cutoff), day, cutoff,
                                         reference_m5=prefix)
        if full != sliced:
            raise AssertionError('Future rows changed a historical classification')
        checkpoints.append({'as_of_utc': cutoff.isoformat(),
                            'as_of_bjt': cutoff.astimezone(BJT).isoformat(),
                            'origin': 'historical_reconstruction_not_live_prediction',
                            'prefix_invariant': True, 'classification': full})
    rules_path = ROOT/'research/ict_daily_profiles/rules.json'
    rules = json.loads(rules_path.read_text(encoding='utf-8'))
    keys = {'news_manipulation_expansion', 'double_sweep', 'seek_destroy'}
    return {'schema_version': 1, 'ny_date': day.isoformat(),
            'built_at_utc': datetime.now(timezone.utc).isoformat(),
            'source': {'manifest': str(manifest.resolve()), 'manifest_sha256': sha(manifest),
                       'csv_sha256': next(d['data_sha256'] for d in meta['datasets'] if d['timeframe']=='M5'),
                       'captured_at_utc': as_of.isoformat(), 'symbol': meta['symbol']},
            'claims_path': str(claims_path.resolve()), 'claims_sha256': sha(claims_path),
            'clock': {'source_offset_hours_hypothesis': offset_hours,
                      'historical_alignment_verified': False,
                      'ny_zone': str(NY), 'claim_zone': str(BJT)},
            'ny_day': window_facts(bars, start, end, as_of),
            'claims': checked, 'replay': checkpoints,
            'source_rules': {'path': str(rules_path), 'sha256': sha(rules_path),
                             'profiles': [r for r in rules['profiles'] if r['id'] in keys]},
            'limitations': ['Five-minute extrema are intervals, not precise tick timestamps.',
                'Clock mapping is a hypothesis; current offset observation is not historical calibration.',
                'Price path cannot establish institutional intent, prior directional bias or news causality.',
                'No position or trade outcome was inspected; this audit cannot verify the claimed short or its profit.',
                'Case-specific windows and tolerances audit the supplied narrative, not a fitted strategy.'],
            'classification_override_applied': False, 'execution_allowed': False, 'orders_sent': 0}


def readable_report(result):
    verdicts = {'contradicted_by_observed_prices': '与已观察价格矛盾',
                'supported_under_clock_hypothesis': '在当前时标假设下近似相符',
                'insufficient_data': '数据不足，不能确认'}
    lines = [f"ICT 每日概况复盘核对：{result['ny_date']}",
             '来源：冻结的 TMGM XAUUSD M5；没有改写面板分类，也没有下单。',
             f"原始时标减去 {result['clock']['source_offset_hours_hypothesis']:g} 小时后按真实 UTC 解释；历史校准未完成。",
             '下列事件时间为五分钟 K 线的开始时间，精确触及时间在该五分钟区间内。', '', '用户复盘与价格核对：']
    for item in result['claims']:
        c, f = item['claim'], item['facts']
        lines.append(f"- {c['id']}：{verdicts[item['verdict']]}；窗口 {c['start']} 至 {c['end']}。")
        if f['bars']:
            lines.append(f"  已观察低点 {f['low']['price']:.2f}（北京 {f['low']['bar_start_bjt']}）；高点 {f['high']['price']:.2f}（北京 {f['high']['bar_start_bjt']}）。")
    d = result['ny_day']
    lines += ['', '纽约零点分日：']
    if d['bars']:
        lines += [f"- O/H/L/C：{d['open']:.2f} / {d['high']['price']:.2f} / {d['low']['price']:.2f} / {d['close']:.2f}。",
                  f"- 日低点位于北京时间 {d['low']['bar_start_bjt']} 开始的五分钟棒。",
                  f"- 已观察 {d['bars']} 根；全天连续网格 {d['expected_grid_bars']} 根。缺失格点不会自动证明券商休市。"]
    lines += ['', '按当时已收盘数据重建的分类（并非当时实录预测）：']
    for row in result['replay']:
        c = row['classification']
        lines.append(f"- 北京 {row['as_of_bjt']}：{c['profile_label']}；{c['profile_reason']}")
    lines += ['', '课程定义与解释边界：']
    for p in result['source_rules']['profiles']:
        lines.append(f"- {p['name']}：{p['source_summary']}；PPT 页 {p['slides']}，高清视频抽样图 {p['hd_visual_reference']['frame_seconds']} 秒。")
    lines += ['- 两端越界不自动等于课程的双重扫荡日；需要核对先后顺序与扩张，事前偏见不能由收盘方向倒推。',
              '- CME 和双重扫荡仍是待核对的用户标签；当前脚本不覆盖分类器结果。',
              '- 价格不能证明机构动机、新闻因果或“没有扫荡就不会上涨”；没有读取持仓，无法确认 4148 空单或止盈。',
              '- 已对每个截点比较完整历史输入与截断输入，结果相同；此检查只覆盖本案例的这些截点。',
              '', f"行情 SHA256：{result['source']['csv_sha256']}",
              f"来源：{result['source']['manifest']}",
              f"规则：{result['source_rules']['path']}"]
    return '\n'.join(lines)+'\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--claims', type=Path, required=True)
    parser.add_argument('--offset-hours', type=float, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.manifest, args.claims, args.offset_hours)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    args.out.with_suffix('.txt').write_text(readable_report(result), encoding='utf-8-sig')
    print(json.dumps({'report': str(args.out), 'claims': [c['verdict'] for c in result['claims']],
                      'replay_checkpoints': len(result['replay']), 'orders_sent': 0}))


if __name__ == '__main__':
    main()
