"""Replay structure-first and agreement-only verdicts on locked TMGM tapes."""

from collections import Counter, defaultdict
from datetime import datetime, timedelta
import json
from pathlib import Path
from random import Random

from scripts import audit_sweep_followthrough as follow
from scripts import compare_ict_sweep_structure as structure
from scripts import replay_ict_sweep_verdict as replay


OUT = replay.OUT/'combined_verdict'
METHODS = ('structure','v7b','structure_first','agreement')


def week_of(event):
    local = datetime.fromisoformat(event['crossing_at']).astimezone(replay.study.NY).date()
    return str(local-timedelta(days=local.weekday()))


def comparison(events, bars, times):
    counts = {name:Counter() for name in METHODS}
    weeks = defaultdict(Counter)
    omissions = Counter()
    cases = []
    for event in events:
        sixty = event['decisions']['60']
        future = sixty['later_30m']
        if future == 'incomplete':
            omissions['incomplete_followup'] += 1
            continue
        if sixty['status'] in ('missing_prior','incomplete'):
            omissions[sixty['status']] += 1
            continue
        results = structure.combined_verdicts(event,bars,times)
        cases.append(dict(crossing_at=event['crossing_at'], side=event['side'], edge=event['edge'],
                          later_30m=future, verdicts=results))
        w = weeks[week_of(event)]
        for method, predicted in results.items():
            stats = counts[method]
            stats['eligible'] += 1
            if predicted is None:
                stats['abstained'] += 1
                continue
            stats['called'] += 1
            if future == 'mixed':
                stats['mixed'] += 1
                continue
            stats['directional'] += 1
            stats['matched'] += predicted == future
            stats[predicted+'_calls'] += 1
            stats[predicted+'_matched'] += predicted == future
        v7b = results['v7b']
        if v7b and future != 'mixed':
            w['common'] += 1
            w['difference'] += int(results['structure_first'] == future)-int(v7b == future)
    return dict(counts=counts, omissions=omissions, weekly_paired=weeks,
                common_v7b_difference=week_interval(list(weeks.values()))), cases


def week_interval(blocks):
    comparable = [w for w in blocks if w['common']]
    n = sum(w['common'] for w in comparable)
    if not n:
        return None
    result = dict(weeks=len(comparable), events=n, delta=sum(w['difference'] for w in comparable)/n)
    if len(comparable) < 2:
        return result
    rng = Random(20261124)
    evidence = []
    for _ in range(4000):
        drawn = rng.choices(comparable, k=len(comparable))
        evidence.append(sum(w['difference'] for w in drawn)/sum(w['common'] for w in drawn))
    evidence.sort()
    result['week_bootstrap_95'] = [evidence[100],evidence[3899]]
    return result


def older_events():
    folder = follow.MODEL_GROUPS['development']
    lock = json.loads((folder/'lock.json').read_bytes())
    market = follow.priority.ARCH/'XAUUSDM5.npz'
    if follow.joint.digest(market) != lock['archive'][market.name]:
        raise ValueError('Older TMGM candle archive differs from the frozen input')
    bars,times = follow.priority.read_market()
    episodes = follow.from_frozen(folder,{'archive':(bars,times)})
    seen = set()
    result = []
    for event in episodes['episodes']:
        target = event['target']
        edge = target['hi'] if target['side']==1 else target['lo']
        key = datetime.fromisoformat(event['known_sweep']),target['side'],edge
        if key in seen:
            continue
        seen.add(key)
        result.append(replay.evaluate_crossing(bars,times,*key))
    return result,bars,times,dict(episodes['sources'], market=lock['archive'][market.name])


def render(scores):
    labels = {
        'oct_nov/short/IRL/top10':'10–11 月 IRL 前十',
        'oct_nov/short/ERL/top10':'10–11 月 ERL 前十',
        'oct_nov/short/IRL/final_filter':'10–11 月 IRL 逐层筛选',
        'oct_nov/short/ERL/final_filter':'10–11 月 ERL 逐层筛选',
        'last_week/short/IRL/final_filter':'11 月 16–20 日 IRL 逐层筛选',
        'last_week/short/ERL/final_filter':'11 月 16–20 日 ERL 逐层筛选',
        '2025-09_to_2026-03/nearest_pool':'2025 年 9 月至 2026 年 3 月最近候选',
    }
    lines = [
        '# 流动性越界后结构与 V7B 联合回测', '',
        '所有判别以越界棒收盘后 60 分钟为截点。组合先取旧结构的判词，待定时用 V7B。'
        '两种规则都待定时保留待定。另测两者一致才判的情形。', '',
        '截点之后另取连续 6 根已收 M5，全部同侧才计为方向明确。下表为吻合数／方向明确且已判数。'
        '混合方向、报价缺口和没有判词的案例在明细中单列。近期组按冻结候选回放，较早组采用各检查点的最近候选。', '',
        '|样本|旧结构|V7B|结构优先、V7B 补位|两者一致才判|组合相对 V7B 的同样本差值|',
        '|---|---:|---:|---:|---:|---:|',
    ]
    for key,label in labels.items():
        score = scores[key]
        columns = []
        for method in METHODS:
            stats = score['counts'][method]
            n = stats['directional']
            columns.append(f"{stats['matched']}/{n}（{stats['matched']/n:.1%}）" if n else '—')
        pair = score['common_v7b_difference']
        delta = f"{100*pair['delta']:+.1f} 个百分点" if pair else '—'
        if pair and 'week_bootstrap_95' in pair:
            lo,hi = pair['week_bootstrap_95']
            delta += f'（周重抽区间 {100*lo:.1f} 至 {100*hi:.1f}）'
        lines.append('|'+ '|'.join([label,*columns,delta])+'|')
    lines += ['', '本轮是固定规则的历史比较。增益和区间需要前瞻样本复核。'
              '“组合”在 +60 分钟才取旧结构判词。V7B 较早出现的判词按当时已知信息独立记录。', '',
              '复现命令为 `python -B -m scripts.audit_ict_sweep_combination`。']
    return '\n'.join(lines)+'\n'


def main():
    bars,times,*_ = replay.read_inputs()
    stored = replay.OUT/'events.json.gz'
    source = replay.study.read_zip(stored)
    decisions = {}
    scores = {}
    for cohort in ('oct_nov','last_week'):
        for scope in ('IRL','ERL'):
            for selection in ('top10','final_filter'):
                key=f'{cohort}/short/{scope}/{selection}'
                events=(source['events'][i] for i in source['indices'][key])
                scores[key],decisions[key]=comparison(events,bars,times)
    events,older_bars,older_times,pins=older_events()
    key='2025-09_to_2026-03/nearest_pool'
    scores[key],decisions[key]=comparison(events,older_bars,older_times)
    OUT.mkdir(parents=True,exist_ok=True)
    replay.study.write_zip(OUT/'cases.json.gz',decisions)
    replay.filters.atomic_json(OUT/'report.json',dict(
        results=scores,
        inputs=dict(pins, recent_events=replay.study.digest(stored),
                    code={Path(p).name:replay.study.digest(Path(p)) for p in
                          (__file__,structure.__file__,replay.__file__,follow.__file__)}),
        cutoff='60 minutes after the crossing candle closes for every policy',
        result_label='same-side or opposite-side on all six subsequent closed M5s, otherwise mixed',
        historical_comparison=True, orders_sent=0,
    ))
    (OUT/'联合回测.md').write_text(render(scores),encoding='utf-8')
    for name,result in scores.items():
        print(name,{key:[v['called'],v['matched'],v['directional']] for key,v in result['counts'].items()},
              result['common_v7b_difference'])


if __name__ == '__main__':
    main()
