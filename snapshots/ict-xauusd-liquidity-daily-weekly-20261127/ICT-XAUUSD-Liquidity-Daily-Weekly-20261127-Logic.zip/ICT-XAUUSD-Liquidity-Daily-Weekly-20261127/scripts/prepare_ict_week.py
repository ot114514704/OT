"""Bind an actual MT5 snapshot to a conditional, source-linked week review.

No orders, no synthetic prices, no invented calendar. Until clock calibration,
both time mappings are labelled hypotheses. Does not confer execution approval.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from dataclasses import replace
from datetime import date,datetime,timedelta,timezone
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from brooks_ai.types import Bar,utc_time
from ict_ai.features import geometric_fvgs
from ict_ai.po3 import po3_zones
from ict_ai.po3_planning import po3_research_gate
from ict_ai.smt import smt_divergences, smt_observation
from ict_ai.amd import amd_events
from ict_ai.profile_lifecycle import daily_profile_lifecycle, weekly_profile_lifecycle
from ict_ai.profile_timeline import attach_profile_timeline
from ict_ai.range_liquidity import range_liquidity_map
from ict_ai.regular_liquidity import regular_liquidity,weekly_stage_liquidity
from ict_ai.profile_sources import profile_catalog
from ict_ai.daily_analysis import daily_analysis
from ict_ai.context_summary import daily_open_context
from ict_ai.weekly_path import weekly_path
from ict_ai.silver_bullet import silver_bullet_windows
from ict_ai.timebase import NY,epoch_to_utc,manifest_epoch_to_utc,previous_week,session_windows


def compact_liquidity_for_preview(liquidity, candles=None, weekly=None):
    """Keep exactly the range marks that the chart can draw; full JSON stays intact."""
    if not liquidity:
        return liquidity
    cutoff=utc_time(liquidity['as_of'])
    def drawn_before_cutoff(item, end_fields):
        if not item.get('available_at'):
            return False
        start=utc_time(item['available_at'])
        end=min([cutoff]+[utc_time(item[k]) for k in end_fields if item.get(k)])
        return start<end
    pool_fields={'id','classification','side','price','anchor_time','available_at','semantic_kind',
                 'first_touch_known_at','first_excursion_known_at','reclaim_known_at','untouched'}
    array_fields={'id','classification','direction','lower','upper','available_at',
                  'semantic_kind','full_mitigation_known_at','invalidation_known_at','untouched'}
    liquidity['pools']=[{k:v for k,v in e.items() if k in pool_fields}
                        for e in liquidity.get('pools',[])
                        if drawn_before_cutoff(e,('first_touch_known_at','first_excursion_known_at'))]
    # A weekly display owns only its W1 range edges, not the M15 swings
    # calculated inside that range. Full research JSON is left untouched.
    weekly=len(liquidity.get('view_dates',[]))>1 if weekly is None else weekly
    if weekly:
        liquidity['pools']=[e for e in liquidity['pools']
                            if e['classification']=='ERL' and e.get('semantic_kind')=='range_edge_pool']
        liquidity['arrays']=[]
    if candles:
        low=min(row[3] for row in candles)
        high=max(row[2] for row in candles)
        last=candles[-1][4]
        weekly=len(liquidity.get('view_dates',[]))>1 if weekly is None else weekly
        reach=max((high-low)*.45,45 if weekly else 18)
        near=sorted((e for e in liquidity['pools'] if e['classification']=='ERL'
                     and low-reach<=e['price']<=high+reach),
                    key=lambda e:abs(e['price']-last))
        selected=[]
        sides={'buy_side_proxy':0,'sell_side_proxy':0}
        for e in near:
            side=e['side']
            if sides[side]>=4 or any(p['side']==side and abs(p['price']-e['price'])<.5
                                     for p in selected):
                continue
            selected.append(e)
            sides[side]+=1
        allowed={e['id'] for e in selected}
        internal_limit=24 if weekly else 10
        internal=sorted((e for e in liquidity['pools'] if e['classification']=='IRL'
                         and low-reach<=e['price']<=high+reach),
                        key=lambda e:(abs(e['price']-last),-utc_time(e['anchor_time']).timestamp()))
        internal_allowed=set()
        internal_sides={'buy_side_proxy':0,'sell_side_proxy':0}
        for e in internal:
            side=e['side']
            if internal_sides[side]>=internal_limit:
                continue
            internal_allowed.add(e['id'])
            internal_sides[side]+=1
        liquidity['pools']=[e for e in liquidity['pools']
                            if (e['classification']=='ERL' and e['id'] in allowed)
                            or (e['classification']=='IRL' and e['id'] in internal_allowed)]
    liquidity['arrays']=[{k:v for k,v in e.items() if k in array_fields}
                         for e in liquidity.get('arrays',[])
                         if drawn_before_cutoff(e,('full_mitigation_known_at','invalidation_known_at'))]
    array_limit=32 if (len(liquidity.get('view_dates',[]))>1 if weekly is None else weekly) else 12
    liquidity['arrays']=liquidity['arrays'][-array_limit:]
    for field in list(liquidity):
        if field not in {'range','as_of','pools','arrays'}:
            liquidity.pop(field)
    return liquidity


def compact_regular_liquidity(record):
    for field,limit in [('regular_liquidity',10),('weekly_stage_liquidity',10)]:
        mapping=record.get(field)
        if not mapping:continue
        fields={'id','kind','classification','side','price','anchor_time','available_at','source_scope',
                'first_anchor_time','sweep_known_at','reclaim_known_at','untouched','reference_dates','crossing_state'}
        rows=mapping['levels']
        if field=='regular_liquidity':
            equal=[e for e in rows if e['kind'] in ('EQH','EQL')][-4:]
            ids={e['id'] for e in equal}
            rows=equal+[e for e in rows if e['id'] not in ids][-(limit-len(equal)):]
        record[field]={'as_of':mapping['as_of'],'levels':[{k:v for k,v in e.items() if k in fields} for e in rows]}


def compact_preview_evidence(payload):
    """Preserve displayed marks; keep verbose provenance in the full report.

    Weekly AMD events reference the identical daily event instead of encoding
    it twice. Unmatched events stay inline, with their original ordering.
    """
    def source_notes(value):
        if isinstance(value,dict):
            if isinstance(value.get('hd_source'),dict):
                value['hd_source']={k:v for k,v in value['hd_source'].items()
                                    if k in ('frame_seconds','category','sequence')}
            for child in value.values():source_notes(child)
        elif isinstance(value,list):
            for child in value:source_notes(child)
    source_notes(payload)
    for scenario in payload['scenarios']:
        for record in scenario['days']+scenario['weeks']:
            record.pop('path_facts',None)
            for event in record.get('amd_events',[]):
                for key in ('id','candidate','trade_signal','context_status'):event.pop(key,None)
            if record.get('liquidity',{}).get('range'):record['liquidity']['range'].pop('basis',None)
            if 'silver_windows' in record:
                record['silver_windows']=[{k:v for k,v in w.items() if k in ('id','start_ms','end_ms','label','ny_time')}
                                          for w in record['silver_windows']]
        key=lambda e:json.dumps(e,sort_keys=True,separators=(',',':'))
        index={key(event):[i,j] for i,day in enumerate(scenario['days']) for j,event in enumerate(day.get('amd_events',[]))}
        for week in scenario['weeks']:
            if 'amd_events' in week:
                week['amd_event_refs']=[index.get(key(e),e) for e in week.pop('amd_events')]
    payload['preview_evidence_compacted']=True


def aggregate_bars(bars, source_minutes, target_minutes, as_of, alignment_offset=timedelta(0)):
    """Only complete, contiguous buckets; never invent finer candles or fill gaps."""
    if target_minutes < source_minutes or target_minutes % source_minutes:
        raise ValueError('Target must be an integer multiple of source period')
    seconds=target_minutes*60
    count=target_minutes//source_minutes
    step=timedelta(minutes=source_minutes)
    offset_seconds=alignment_offset.total_seconds()
    groups={}
    for bar in bars:
        if bar.time+step>as_of:
            continue
        shifted=int(bar.time.timestamp()+offset_seconds)
        bucket=shifted//seconds
        groups.setdefault(bucket,[]).append(bar)
    result=[]
    for bucket,part in sorted(groups.items()):
        if len(part)!=count:
            continue
        start=datetime.fromtimestamp(bucket*seconds-offset_seconds,timezone.utc)
        if any(b.time!=start+i*step for i,b in enumerate(part)):
            continue
        result.append(Bar(start,part[0].open,max(b.high for b in part),min(b.low for b in part),part[-1].close,max(b.spread for b in part)))
    return result


def chart_payload(bars,minutes,start,finish,as_of,include_fvgs=True):
    period=timedelta(minutes=minutes)
    selected=[b for b in bars if start<=b.time<finish and b.time+period<=as_of]
    fvgs=[]
    if include_fvgs:
        fvgs=[{k:e[k] for k in ('lower','upper','available_at','direction')} for e in geometric_fvgs(bars,period,min(finish,as_of)) if start<=utc_time(e['formation_bar_open'])<finish]
    return {'bars':[[int(b.time.timestamp()*1000),b.open,b.high,b.low,b.close] for b in selected], 'fvgs':fvgs}


def profile_annotation(day):
    """A retrospective path candidate, not confirmation of an ICT daily profile."""
    if not day:
        return {'profile_label':'尚未发生','profile_status':'not_started'}
    candidate=next((c for c in day['candidates'] if c['profile']!='暂不归类'),None)
    if not candidate:
        return {'profile_label':'暂不归类' if day['day_completed'] else '待确认','profile_status':'unclassified' if day['day_completed'] else 'pending'}
    raw=candidate['profile']
    if '1.1 / 双重' in raw:
        label='经典反转 1.1 / 双重扫荡（待区分）'
    elif '1.1' in raw: label='经典反转 1.1'
    elif '看跌镜像' in raw: label='经典卖出日（镜像）'
    elif '经典买入' in raw: label='经典买入日'
    elif '寻找与毁灭' in raw: label='寻找与毁灭日'
    elif '操纵扩张后盘整' in raw: label='操纵扩张后盘整日'
    else: label=raw
    return {'profile_label':label,'profile_status':'candidate' if day['day_completed'] else 'pending'}


def session_summary(bars,start,end,period,as_of):
    selected=[b for b in bars if start<=b.time and b.time+period<=min(end,as_of)]
    expected=int((end-start)/period)
    available_expected=max(0,int((min(end,as_of)-start)/period))
    complete=len(selected)==expected and all(b.time==start+i*period for i,b in enumerate(selected))
    state='not_started' if as_of<=start else ('in_progress' if as_of<end else ('complete' if complete else 'missing'))
    if not selected:
        return {"complete":False,"bars":0,"expected_bars":expected,"state":state,"available_expected":available_expected}
    return {"complete":complete,"state":state,"available_expected":available_expected,"bars":len(selected),"expected_bars":expected,"open":selected[0].open,"close":selected[-1].close,"high":max(b.high for b in selected),"low":min(b.low for b in selected),"start":start.isoformat(),"end":end.isoformat()}


def sweep(bars,start,end,reference,side):
    selected=[b for b in bars if start<=b.time<end]
    excursion=False
    for b in selected:
        excursion=excursion or (b.high>reference if side==1 else b.low<reference)
        if excursion and (b.close<reference if side==1 else b.close>reference):
            return True
    return False


def review_day(bars,day,period,as_of,daily_reference=None):
    windows=session_windows(day)
    sessions={key:session_summary(bars,start,end,period,as_of) for key,(start,end) in windows.items()}
    start=windows["asia"][0]
    # Research days follow the course's NY-midnight opening reference. This
    # aggregation is explicit and is not the broker's native D1 candle.
    finish=datetime.combine(day,datetime.min.time(),NY)+timedelta(hours=17 if day.weekday()==4 else 24)
    finish=finish.astimezone(timezone.utc)
    selected=[b for b in bars if start<=b.time<finish and b.time+period<=as_of]
    if not selected:
        return None
    a,l,n=(sessions[k] for k in ("asia","london","new_york"))
    facts={}
    for name,target,ref in [("london","london",a),("new_york","new_york",l)]:
        current=sessions[target]
        if ref.get("complete") and current.get("complete"):
            st,en=windows[target]
            facts[name+"_upper_sweep_return"]=sweep(bars,st,en,ref["high"],1)
            facts[name+"_lower_sweep_return"]=sweep(bars,st,en,ref["low"],-1)
        else:
            facts[name+"_upper_sweep_return"]=None
            facts[name+"_lower_sweep_return"]=None
    reasons=[]
    path_facts=[]
    core=[b for b in selected if b.time.astimezone(NY).date()==day]
    day_open=daily_reference['open'] if daily_reference is not None else (core[0].open if core and core[0].time==datetime.combine(day,datetime.min.time(),NY).astimezone(timezone.utc) else None)
    day_close=daily_reference['close'] if daily_reference is not None else (core[-1].close if core else None)
    for key,session in sessions.items():
        if session.get('bars',0):
            path_facts.append(f"{key}：开 {session['open']:.2f}，高 {session['high']:.2f}，低 {session['low']:.2f}，收 {session['close']:.2f}"+('（会话进行中）' if not session['complete'] else ''))
    if a.get("complete") and l.get("complete") and n.get("complete"):
        if l["low"]<a["low"] and n["close"]>l["high"]:
            reasons.append({"profile":"经典买入日价格路径候选","source_slide":16,"reason":"伦敦低点低于亚洲低点，纽约会话收盘高于伦敦高点。","missing":"事先看涨偏见、未完成 DOL、伦敦反转确认及实际新闻；当前路径不能证明事前预测成立。"})
        if l["high"]>a["high"] and n["close"]<l["low"]:
            reasons.append({"profile":"经典买卖日的看跌镜像候选","source_slide":16,"reason":"伦敦高点高于亚洲高点，纽约收盘低于伦敦低点。","missing":"这是方向镜像的研究解释；尚缺事先看跌偏见、目标与反转证据，原课件以买入例图为主。"})
        if n["low"]<l["low"] and n["close"]>l["high"]:
            reasons.append({"profile":"经典反转 1.1 / 双重扫荡，待区分","source_slide":17,"reason":"纽约低点跌破伦敦低点后，会话收盘高于伦敦高点。","missing":"需核实零点后的先后路径、事先偏见及纽约扫荡过程，不能因名称相似合并。"})
        elif n['low']<l['low'] and day_close is not None and day_close>n['open']:
            reasons.append({'profile':'经典反转 1.1 的部分价格证据','source_slide':17,'reason':f"纽约低点 {n['low']:.2f} 低于伦敦低点 {l['low']:.2f}；之后已观察到的日内收盘 {day_close:.2f} 高于纽约开盘 {n['open']:.2f}。",'missing':'该比较只支持先创新低后反弹，尚未核实事先看涨偏见、关键 PDA 和完整交付变化；不能仅据此确认全日最低。'})
        if all(facts.get(k) is True for k in facts):
            reasons.append({"profile":"寻找与毁灭日部分证据","source_slide":22,"reason":"伦敦对亚洲两端、纽约对伦敦两端均出现越界后收盘返回的观察。","missing":"还需验证全日缺乏持续扩张；这四个观察也可能出现在最终恢复趋势的日子。"})
        if n["high"]<=l["high"] and n["low"]>=l["low"]:
            reasons.append({"profile":"操纵扩张后盘整日部分证据","source_slide":21,"reason":"纽约会话高低点均位于伦敦范围内。","missing":"仅包含关系不足以证明盘整，尚需伦敦先操纵后扩张的路径及更晚会话表现。"})
    elif a.get('complete') and l.get('complete') and n.get('state') in ('not_started','in_progress'):
        if facts.get('london_upper_sweep_return') and l['close']<a['high']:
            reasons.append({'profile':'经典卖出日（看跌镜像）早期候选','source_slide':16,
                            'reason':f"伦敦窗口最高 {l['high']:.2f} 高于亚洲高点 {a['high']:.2f}，伦敦收于 {l['close']:.2f}，回到亚洲高点下方；纽约窗口尚未完成。",
                            'missing':f"待纽约窗口在伦敦低点 {l['low']:.2f} 下方形成持续扩张；若重新站回伦敦高点 {l['high']:.2f}，这一延续情景减弱。事先看跌偏见、PDA、DOL 与新闻仍未核实，不能认定全日高点。"})
            reasons.append({'profile':'操纵扩张后盘整日备选（待区分）','source_slide':21,
                            'reason':'它与经典趋势日可共享早期反向运动。若纽约缺乏跟随并持续盘整，才考虑这一备选。',
                            'missing':'还需证明伦敦完成了足够的扩张，并等待完整纽约及更晚路径；当前不能确认已经扩张耗尽。'})
        elif facts.get('london_lower_sweep_return') and l['close']>a['low']:
            reasons.append({'profile':'经典买入日早期候选','source_slide':16,
                            'reason':f"伦敦窗口最低 {l['low']:.2f} 低于亚洲低点 {a['low']:.2f}，随后收于 {l['close']:.2f}，回到亚洲低点上方；纽约窗口尚未完成。",
                            'missing':f"待纽约窗口在伦敦高点 {l['high']:.2f} 上方持续扩张；若重新跌破伦敦低点 {l['low']:.2f}，这一延续情景减弱。事先偏见、PDA、DOL、新闻待核实。"})
    if not reasons:
        observed='；'.join([f"伦敦{'向上' if l.get('close',0)>l.get('open',0) else '向下'}运行",f"纽约{'向上' if n.get('close',0)>n.get('open',0) else '向下'}运行" if n.get('bars') else '纽约尚未开始'])
        reasons.append({"profile":"暂不归类","source_slide":5,"reason":observed+'。方向比较不足以支持典型完整路径，保留未知。',"missing":"事先方向偏见、高周期目标、真实日历及完整后续路径；不因必须归类而套图。"})
    fvgs=[e for e in geometric_fvgs(bars,period,min(finish,as_of)) if start<=utc_time(e["formation_bar_open"])<finish]
    cuts=[{'date':d.isoformat(),'time_ms':datetime.combine(d,datetime.min.time(),NY).timestamp()*1000} for d in [day-timedelta(days=1),day,day+timedelta(days=1)]]
    return {"date":day.isoformat(),"day_completed":as_of>=finish,"daily_open":day_open,"daily_close":day_close,"path_facts":path_facts,"midnights":cuts,"sessions":sessions,"price_observations":facts,"candidates":reasons,"calendar_verified":False,"source_clock_verified":False,"bars":[[b.time.timestamp()*1000,round(b.open,3),round(b.high,3),round(b.low,3),round(b.close,3)] for b in selected],"fvgs":fvgs}


def review_week(bars,days,as_of):
    start=datetime.combine(days[0],datetime.min.time(),NY).astimezone(timezone.utc)
    end=(datetime.combine(days[-1],datetime.min.time(),NY)+timedelta(hours=17)).astimezone(timezone.utc)
    selected=[b for b in bars if start<=b.time<end and b.time+timedelta(minutes=15)<=as_of]
    if not selected:return {'days':[d.isoformat() for d in days],'bars':[],'daily':[],'candidates':[],'status':'not_started'}
    daily=[]
    for day in days:
        part=[b for b in selected if b.time.astimezone(NY).date()==day]
        if not part:daily.append({'date':day.isoformat(),'status':'not_started'});continue
        day_end=(datetime.combine(day,datetime.min.time(),NY)+timedelta(hours=17 if day.weekday()==4 else 24)).astimezone(timezone.utc)
        daily.append({'date':day.isoformat(),'status':'completed' if as_of>=day_end else 'in_progress','open':part[0].open,'high':max(b.high for b in part),'low':min(b.low for b in part),'close':part[-1].close})
    hi=max(selected,key=lambda b:b.high);lo=min(selected,key=lambda b:b.low)
    notes=[]
    for extreme,bar,value in [('高点',hi,hi.high),('低点',lo,lo.low)]:
        wd=bar.time.astimezone(NY).weekday()
        if wd in (1,2,3):
            name={1:'经典周二极点',2:'经典周三 / 双重扫荡周三极点',3:'周四盘整反转'}[wd]
            notes.append({'profile':name+'的极点时间部分相符','reason':f'截至快照已观察到的周{extreme} {value:.2f} 位于 '+bar.time.astimezone(NY).strftime('%m-%d %H:%M')+'。','missing':'极点日期只是一项证据；还需此前路径、事先偏见、PDA、DOL、新闻和后续扩张。未结束周不能确认最终周极点。'})
    if not notes:notes=[{'profile':'周概况待确认','reason':'当前观察到的极点日期不足以支持课程典型候选。','missing':'按完整周初路径、高周期位置和后续扩张继续核对。'}]
    hourly=[]
    groups={}
    for b in selected:groups.setdefault(b.time.replace(minute=0,second=0,microsecond=0),[]).append(b)
    for t,part in groups.items():
        if len(part)==4 and all(b.time==t+i*timedelta(minutes=15) for i,b in enumerate(part)):
            hourly.append([t.timestamp()*1000,part[0].open,max(b.high for b in part),min(b.low for b in part),part[-1].close])
    cuts=[{'date':d.isoformat(),'time_ms':datetime.combine(d,datetime.min.time(),NY).timestamp()*1000} for d in days+[days[-1]+timedelta(days=1)]]
    return {'days':[d.isoformat() for d in days],'status':'completed' if as_of>=end else 'in_progress','bars':hourly,'daily':daily,'midnights':cuts,'observed_high':hi.high,'observed_low':lo.low,'high_time':hi.time.isoformat(),'low_time':lo.time.isoformat(),'candidates':notes,'weekly_open_basis':'纽约周一 00:00 起首个可用报价，工程聚合边界；尚未核对课程真正周开盘定义'}


def month_overview(periods,today,as_of,smts=None,amd=None):
    """Prior-month start through now, with source M5 daily OHLC and overlays."""
    month_start=today.replace(day=1)
    next_month=(month_start+timedelta(days=32)).replace(day=1)
    prior_month=(month_start-timedelta(days=1)).replace(day=1)
    start=datetime.combine(month_start,datetime.min.time(),NY).astimezone(timezone.utc)
    finish=datetime.combine(next_month,datetime.min.time(),NY).astimezone(timezone.utc)
    previous_start=datetime.combine(prior_month,datetime.min.time(),NY).astimezone(timezone.utc)
    month_bars=[b for b in periods[60] if previous_start<=b.time<finish and b.time+timedelta(hours=1)<=as_of]
    previous=[b for b in periods[5] if previous_start<=b.time<start and b.time+timedelta(minutes=5)<=as_of]
    levels=[]
    if previous:
        for side,bar,price in [('buy_side_proxy',max(previous,key=lambda b:b.high),max(b.high for b in previous)),
                               ('sell_side_proxy',min(previous,key=lambda b:b.low),min(b.low for b in previous))]:
            reclaim=next((b for b in periods[5] if start<=b.time<min(finish,as_of)
                          and b.time+timedelta(minutes=5)<=as_of
                          and ((b.high>price and b.close<price) if side=='buy_side_proxy'
                               else (b.low<price and b.close>price))),None)
            levels.append({'id':f'prior-month-{prior_month:%Y-%m}-{side}', 'classification':'ERL',
                           'side':side,'price':price,'anchor_time':bar.time.isoformat(),
                           'available_at':start.isoformat(),'source_scope':'上月观测极值',
                           'source_dates':[prior_month.isoformat(),(month_start-timedelta(days=1)).isoformat()],
                           'historical_coverage_verified':False,'actual_stop_orders_observed':False,
                           'reclaim_known_at':(reclaim.time+timedelta(minutes=5)).isoformat() if reclaim else None})
    segments=[]
    monday=prior_month-timedelta(days=prior_month.weekday())
    while monday<next_month:
        dates=[monday+timedelta(days=i) for i in range(5)]
        seg_start=max(previous_start,datetime.combine(monday,datetime.min.time(),NY).astimezone(timezone.utc))
        seg_end=min(finish,datetime.combine(monday+timedelta(days=7),datetime.min.time(),NY).astimezone(timezone.utc))
        if seg_start<min(seg_end,as_of) and any(seg_start<=b.time<seg_end for b in periods[5]):
            path=weekly_path(periods[5],dates,as_of)
            life=weekly_profile_lifecycle(periods[15],dates,as_of,path)
            candidate=next((c for c in life.get('candidates',[]) if c.get('status')=='active'),None)
            if candidate is None and life['week_ended']:
                candidate=next((c for c in path['candidates'] if c.get('id')),None)
            segments.append({'week_start':monday.isoformat(),'start_ms':int(seg_start.timestamp()*1000),
                             'end_ms':int(seg_end.timestamp()*1000),'label':life['profile_label'],
                             'mode':life['mode'],'reason':candidate.get('evidence',candidate.get('reason','证据不足，暂不归类')) if candidate else '证据不足，暂不归类',
                             'awaiting':candidate.get('awaiting',candidate.get('missing','高周期偏见、PDA 与 DOL 待验证')) if candidate else '高周期偏见、PDA 与 DOL 待验证',
                             'course_slides':candidate.get('course_slides',[candidate['source_slide']] if candidate.get('source_slide') else []) if candidate else [],
                             'guide_pages':candidate.get('guide_pages',[]) if candidate else [],
                             'hd_source':candidate.get('hd_source') if candidate else None,
                             'points':path.get('points',[]),
                             'basis':'时间（三）与 weekly profile 材料的价格路径候选；高周期偏见和 DOL 尚待验证'})
        monday+=timedelta(days=7)
    daily=[];bands=[];silver=[];zones=[]
    day=prior_month
    while day<=today:
        st=datetime.combine(day,datetime.min.time(),NY).astimezone(timezone.utc)
        en=datetime.combine(day+timedelta(days=1),datetime.min.time(),NY).astimezone(timezone.utc)
        part=[b for b in periods[5] if st<=b.time<en and b.time+timedelta(minutes=5)<=as_of]
        if part:
            daily.append({'date':day.isoformat(),'start':int(st.timestamp()*1000),'end':int(en.timestamp()*1000),
                          'observedEnd':int(min(en,as_of,part[-1].time+timedelta(minutes=5)).timestamp()*1000),
                          'o':part[0].open if part[0].time==st else None,'h':max(b.high for b in part),
                          'l':min(b.low for b in part),'c':part[-1].close,'provisional':as_of<en})
        if day.weekday()<5 and st<as_of:
            windows=session_windows(day)
            bands.extend([[key,{'start':a.isoformat(),'end':b.isoformat()}] for key,(a,b) in windows.items() if key in ('asia','london','new_york')])
            silver.extend(silver_bullet_windows(day))
            zones.extend(po3_zones(periods[15],windows['asia'][0],windows['asia'][1],en,as_of).get('zones',[]))
        day+=timedelta(days=1)
    return {'month':f'{prior_month:%Y-%m}—{month_start:%Y-%m}','start_ms':int(previous_start.timestamp()*1000),
            'end_ms':int(min(finish,as_of).timestamp()*1000),
            'bars':[[int(b.time.timestamp()*1000),b.open,b.high,b.low,b.close] for b in month_bars],
            'weeks':segments,'daily':daily,'session_bands':bands,'silver_windows':silver,'po3_zones':zones,
            'fvgs':chart_payload(periods[60],60,previous_start,finish,as_of)['fvgs'],
            'smt':[e for e in (smts or {}).get(60,[]) if previous_start.timestamp()*1000<=e['primary'][0]['time_ms']],
            'amd_events':[e for e in amd or [] if previous_start<=utc_time(e['available_at'])<=as_of],
            'prior_month_levels':levels,'source_period_minutes':60,
            'price_history_from':prior_month.isoformat(),
            'prior_month_coverage_verified':False,'historical_clock_verified':False,
            'actual_stop_orders_observed':False,'execution_allowed':False}


def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument('--manifest',type=Path,default=ROOT/'data/real/TMGM_ICT_XAU_M5_20261013_1220/provenance.json')
    parser.add_argument('--today',type=date.fromisoformat,default=date(2026,10,13))
    parser.add_argument('--comparison-manifest',type=Path,default=ROOT/'data/real/TMGM_ICT_XAG_M5_20261013_1220/provenance.json')
    parser.add_argument('--out-json',type=Path,default=ROOT/'output/research/ict_week_review.json')
    parser.add_argument('--out-fragment',type=Path,default=ROOT/'output/visualizations/ict-week-review.html')
    parser.add_argument('--quiet',action='store_true')
    parser.add_argument('--standalone',action='store_true',help='Local browser page; allow up to 50 MB instead of the inline preview limit')
    args=parser.parse_args(argv)
    fragment_limit=50_000_000 if args.standalone else 1_000_000
    meta=json.loads(args.manifest.read_text(encoding='utf-8'))
    dataset=next(d for d in meta['datasets'] if d['timeframe']=='M5')
    path=Path(dataset['data_path'])
    actual_hash=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual_hash!=dataset['data_sha256'] or meta.get('synthetic') is not False:
        raise ValueError('Actual non-synthetic snapshot and matching hash required')
    with path.open(encoding='utf-8-sig',newline='') as f:
        bars=[Bar(utc_time(r['time']),*(float(r[k]) for k in ('open','high','low','close','spread'))) for r in csv.DictReader(f)]
    if any(a.time>=b.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Nonchronological snapshot')
    week=previous_week(args.today)
    current=[d+timedelta(days=7) for d in week]
    all_days=week+current
    as_of=utc_time(meta['finished_at_utc'])
    other=json.loads(args.comparison_manifest.read_text(encoding='utf-8'))
    peer=next(d for d in other['datasets'] if d['timeframe']=='M5')
    peerpath=Path(peer['data_path'])
    if other.get('synthetic') is not False or hashlib.sha256(peerpath.read_bytes()).hexdigest()!=peer['data_sha256'] or other['server']!=meta['server']:
        raise ValueError('Auditable same-broker non-synthetic comparison required')
    with peerpath.open(encoding='utf-8-sig',newline='') as f:
        peerbars=[Bar(utc_time(r['time']),*(float(r[k]) for k in ('open','high','low','close','spread'))) for r in csv.DictReader(f)]
    as_of=min(as_of,utc_time(other['finished_at_utc']))
    prior_month_start=(args.today.replace(day=1)-timedelta(days=1)).replace(day=1)
    history_floor=datetime.combine(prior_month_start,datetime.min.time(),NY).astimezone(timezone.utc)
    scenarios=[]
    source_hours=meta.get('source_clock_offset_hours',3)
    primary_label=f'当前 UTC+{source_hours:g}；历史分段推定（待校准）'
    for ident,label,hours in [('broker-plus3',primary_label,source_hours),('api-utc','原时标 UTC 对照（与实时观测不符）',0)]:
        def convert(raw,metadata):
            return manifest_epoch_to_utc(raw,metadata) if ident=='broker-plus3' else epoch_to_utc(raw,timedelta(0))
        converted=[v for b in bars if (v:=replace(b,time=convert(b.time,meta))).time>=history_floor]
        periods={n:aggregate_bars(converted,5,n,as_of) for n in (5,15,60)}
        peers=[v for b in peerbars if (v:=replace(b,time=convert(b.time,other))).time>=history_floor]
        peerperiods={n:aggregate_bars(peers,5,n,as_of) for n in (5,15,60)}
        smts={n:smt_divergences(periods[n],peerperiods[n],timedelta(minutes=n),as_of) for n in periods}
        for n, events in smts.items():
            for event in events:
                observed=smt_observation(event,periods[n],peerperiods[n],timedelta(minutes=n),as_of)
                event['observation']={k:v for k,v in observed.items() if k in ('status','catch_up_at','lagging_market')}
        amd=amd_events(periods[15],timedelta(minutes=15),as_of)
        days=[]
        for day in all_days:
            lifecycle=daily_profile_lifecycle(periods[15],day,as_of,reference_m5=periods[5])
            record=review_day(periods[15],day,timedelta(minutes=15),as_of,lifecycle.get('daily_price_basis'))
            if not record: continue
            record.update(profile_annotation(record))
            record['silver_windows']=silver_bullet_windows(day)
            record['reference_levels']=[{'label':label,'price':s[field]} for key,field,label in [('asia','high','亚洲高点'),('asia','low','亚洲低点'),('london','high','伦敦高点'),('london','low','伦敦低点')] if (s:=record['sessions'][key]).get('complete')]
            start=session_windows(day)['asia'][0]
            finish=(datetime.combine(day,datetime.min.time(),NY)+timedelta(hours=17 if day.weekday()==4 else 24)).astimezone(timezone.utc)
            record['charts']={str(n):chart_payload(values,n,start,finish,as_of) for n,values in periods.items()}
            for n,chart in record['charts'].items():
                chart['smt']=[e for e in smts[int(n)] if start.timestamp()*1000<=e['primary'][0]['time_ms']<e['primary'][1]['time_ms']<finish.timestamp()*1000 and utc_time(e['available_at'])<=min(finish,as_of)]
            record['po3']=po3_zones(periods[15],start,session_windows(day)['asia'][1],finish,as_of)
            po3_gate=po3_research_gate(record['po3'],{},as_of)
            record['po3_research_gate']={'status':po3_gate['status'],'missing':po3_gate['missing'],
                                         'contradictions':po3_gate['contradictions'],
                                         'execution_allowed':False,'orders_sent':0}
            record['amd_events']=[e for e in amd if start<=utc_time(e['available_at'])<=min(finish,as_of)]
            record['profile_lifecycle']=lifecycle
            record['htf_open_context']=daily_open_context(periods[5],day,as_of)
            record['liquidity']=range_liquidity_map(periods[15],[day],as_of,reference_bars=periods[5])
            record['regular_liquidity']=regular_liquidity(periods[15],periods[5],day,as_of,record['liquidity'])
            record.update({k:record['profile_lifecycle'][k] for k in ('profile_label','profile_status','profile_reason')})
            days.append(record)
        weeks=[]
        for dates in [week,current]:
            record=review_week(periods[15],dates,as_of)
            record['weekly_path']=weekly_path(periods[5],dates,as_of)
            record['profile_lifecycle']=weekly_profile_lifecycle(periods[15],dates,as_of,record['weekly_path'])
            record['profile_reason']=record['profile_lifecycle']['profile_reason']
            record['liquidity']=range_liquidity_map(periods[15],dates,as_of,reference_bars=periods[5])
            record['weekly_stage_liquidity']=weekly_stage_liquidity(periods[5],dates,as_of)
            record['candidates']=record['weekly_path']['candidates']
            # Keep the lifecycle result as the display authority for both
            # ongoing and closed weeks.  A closed week may now carry an
            # explicit partial-path label (for example, a midweek break that
            # never reclaimed); falling back to the raw path would hide that
            # explanation from the chart.
            record['profile_label']=record['profile_lifecycle'].get('profile_label') or record['weekly_path']['profile_label']
            for candidate in record['candidates']:
                candidate['free_guide_pages']=[7] if '周三' in candidate['profile'] else [2] if '周二' in candidate['profile'] else [2,3,4,5,6,7]
            start=datetime.combine(dates[0],datetime.min.time(),NY).astimezone(timezone.utc)
            finish=(datetime.combine(dates[-1],datetime.min.time(),NY)+timedelta(hours=17)).astimezone(timezone.utc)
            record['charts']={str(n):chart_payload(values,n,start,finish,as_of,False) for n,values in periods.items()}
            for n,chart in record['charts'].items():
                chart['smt']=[e for e in smts[int(n)] if start.timestamp()*1000<=e['primary'][0]['time_ms']<e['primary'][1]['time_ms']<finish.timestamp()*1000 and utc_time(e['available_at'])<=min(finish,as_of)]
            for item in record['daily']:
                daily=next((d for d in days if d['date']==item['date']),None)
                item.update({k:daily[k] for k in ('profile_label','profile_status','profile_reason')} if daily else profile_annotation(None))
                reference=next((d for d in record['weekly_path']['daily'] if d['date']==item['date']),None)
                if reference:
                    item.update({k:reference.get(k) for k in ('open','high','low','close')})
            record['session_bands']=[[key,s] for d in days if d['date'] in record['days'] for key,s in d['sessions'].items() if key in ('asia','london','new_york') and s.get('start')]
            record['po3_zones']=[z for d in days if d['date'] in record['days'] for z in d['po3']['zones']]
            record['amd_events']=[e for e in amd if start<=utc_time(e['available_at'])<=min(finish,as_of)]
            weeks.append(record)
        for day in days:
            previous=next((d for w in weeks for d in w['daily'] if d['date']==(date.fromisoformat(day['date'])-timedelta(days=1)).isoformat() and d.get('status')=='completed'),None)
            peerclosed=(peerperiods[5][-1].time+timedelta(minutes=5)).isoformat() if peerperiods[5] else None
            day['analysis']=daily_analysis(day,as_of,previous,peerclosed)
        scenario = {'id':ident,'label':label,'offset_hours':hours,'verified':False,
                    'days':days,'weeks':weeks,'month':month_overview(periods,args.today,as_of,smts,amd)}
        if args.standalone and ident == 'broker-plus3' and periods[5]:
            attach_profile_timeline(scenario, {key: periods[int(key)] for key in ('5', '15')},
                                    as_of, periods[5][-1].time + timedelta(minutes=5))
        scenarios.append(scenario)
    payload={'symbol':'XAUUSD','broker':meta['company'],'source_manifest':str(args.manifest.resolve()),'source_sha256':actual_hash,'snapshot_read_at':meta['finished_at_utc'],'history_used_from_ny':prior_month_start.isoformat(),'week':[day.isoformat() for day in all_days],'week_groups':[{'label':'上周 · 10 月 5—9 日','days':[d.isoformat() for d in week]},{'label':'本周 · 10 月 12—16 日（进行中）','days':[d.isoformat() for d in current]}],'clock_verified':False,'current_clock_measured_offset_hours':3,'historical_clock_alignment':'inferred_from_current_observation_and_broker_summer_clock','synthetic':False,'source_period_minutes':15,'scenarios':scenarios,'source_slides_path':'D:/BaiduNetdiskDownload/ICT交易核心概念-每日概况日内交易必学-时间（二）_20261011211153(2).pptx','orders_sent':0}
    out=args.out_json
    from ict_ai.review_annotations import weekly_review
    for narrative_path in (ROOT/'research/ict_weekly_profiles').glob('user_review_*.json'):
        narrative=json.loads(narrative_path.read_text(encoding='utf-8'))
        for scenario in scenarios:
            if scenario['id']!='broker-plus3':continue
            for record in scenario['weeks']:
                annotation=weekly_review(record,narrative,as_of.isoformat())
                if annotation:record['user_review']=annotation
    payload.update(current_clock_measured_offset_hours=source_hours,
                   source_clock_segments=meta.get('source_clock_segments',[]),
                   historical_clock_alignment='explicit_interval_hypothesis_unverified')
    payload['week_groups'][0]['label']=f'上周 · {week[0]:%m-%d}–{week[-1]:%m-%d}'
    current_end=(datetime.combine(current[-1],datetime.min.time(),NY)+timedelta(hours=17)).astimezone(timezone.utc)
    payload['week_groups'][1]['label']=f'本周 · {current[0]:%m-%d}–{current[-1]:%m-%d}'+('（已结束）' if as_of>=current_end else '（进行中）')
    latest_visible=max((d['date'] for d in scenarios[0]['days'] if d['date']<=args.today.isoformat()),default=args.today.isoformat())
    payload.update(source_period_minutes=5,display_period_minutes=[5,15,60],analysis_period_minutes=15,
                   smt_pair={'primary':meta['symbol'],'secondary':other['symbol'],'comparison_source_sha256':peer['data_sha256'],'source_manifest':str(args.comparison_manifest.resolve()),'as_of':as_of.isoformat(),'method':'两品种分别确认左右各 2 根的枢轴；最多相差 2 根时序匹配、最多相隔 48 根的锚点比较，缺失共同报价时重置；工程几何候选。','source_pages':[120,124,125],'pair_correlation_validated':False},
                   initial_view={'week':'1','day':latest_visible},calendar_today_ny=args.today.isoformat(),
                   aggregation='M15 and H1 from complete contiguous M5 bars; no interpolation',
                   classification_basis='M15 session price-path candidates; actual M5 daily OHLC and wick invalidation; unchanged by display timeframe')
    payload['price_video_basis']={'amd':'用户 AMD 视频 277–367 秒：先 DOL，再路径；A 可直接扩张。',
        'amd_method':'M15 收盘识别箱形、三角、收敛楔形及密集通道。斜边形态要求已确认摆动和共同区间价格覆盖，以上下最近摆动冻结扫荡边界。单侧越界收回标 M，反向连续两根收出对侧标 D；直接扩张另记 A→D。阈值为研究参数。',
        'smt':'用户 SMT 视频 56–145、219–344 秒：先叙事与位置，背离可选，需验证。',
        'csd':'视频原字幕为 CSD，未提供蜡烛锚点和计算定义；不把枢轴确认或 MSS 自动视作 CSD 验证。',
        'prior_context':'DOL、HTF 关键位置和事前叙事尚未绑定；所有标记均为价格几何候选。',
        'model_trained':False,'orders_sent':0}
    payload['po3_gate_policy']={
        'status_if_context_missing':'pending_context',
        'required_context':['完整 PO3 A/M/D','事前 HTF 偏见','HTF PDA','事前 DOL','已核实纽约时钟','已核实经济日历'],
        'execution_allowed':False,'orders_sent':0
    }
    # Keep the complete source-grounded rules in the research sidecar while
    # exposing a compact, auditable summary to the interactive chart.
    amd_path=ROOT/'research/ict_price_videos/amd/integration.json'
    liq_path=ROOT/'research/ict_price_videos/foundations/integration.json'
    if amd_path.exists():
        amd_source=json.loads(amd_path.read_text(encoding='utf-8'))
        payload['ict_liquidity_amd_basis']={
            'amd_source_path':str(amd_path.relative_to(ROOT).as_posix()),
            'amd_source_sha256':amd_source.get('source_sha256'),
            'amd_source_status':amd_source.get('status'),
            'amd_semantic_review_complete':amd_source.get('semantic_review_complete',False),
            'amd_rule_ids':[r.get('id') for r in amd_source.get('rules',[])],
            'amd_gating_order':amd_source['rules'][3]['implementation']['gating_order'] if len(amd_source.get('rules',[]))>3 else [],
            'liquidity_source_path':str(liq_path.relative_to(ROOT).as_posix()) if liq_path.exists() else None,
            'liquidity_source_sha256':json.loads(liq_path.read_text(encoding='utf-8')).get('source_sha256') if liq_path.exists() else None,
            'authority':'交易员无畏基础教学视频；截图仅参考画法',
            'classification':'范围相对 IRL/ERL；高点潜在 BSL/买方，低点潜在 SSL/卖方；真实订单量未知',
            'chart_behavior':'A 范围、M 越界/收回、D 后续收盘扩张；已清扫线从原点到收回时刻变灰，未完成路径显示部分路径而不晋级完整形态',
            'execution_allowed':False,
            'full_rules_sidecar':str(amd_path.relative_to(ROOT).as_posix())
        }
    po3_path=ROOT/'research/ict_price_videos/po3_integration.json'
    if po3_path.exists():
        po3_source=json.loads(po3_path.read_text(encoding='utf-8'))
        payload['po3_basis']={
            'source_path':str(po3_path.relative_to(ROOT).as_posix()),
            'core_principle':po3_source.get('core_principle'),
            'phase_principles':[{k:p.get(k) for k in ('phase','name','principle','source_seconds')} for p in po3_source.get('phases',[])],
            'allowed_routes':[{'route':r.get('route'),'meaning':r.get('meaning')} for r in po3_source.get('allowed_routes',[])],
            'po3_vs_amd':{'po3':po3_source.get('po3_vs_amd',{}).get('po3'),'amd':po3_source.get('po3_vs_amd',{}).get('amd'),'relationship':po3_source.get('po3_vs_amd',{}).get('relationship')},
            'state_machine':{'states':po3_source.get('state_machine',{}).get('states'),'transition_order':po3_source.get('state_machine',{}).get('transition_order'),'future_data_policy':po3_source.get('state_machine',{}).get('future_data_policy')},
            'execution_allowed':False
        }
    new_guide=ROOT/'research/ict_weekly_profiles/smc_free_guide/manifest.json'
    if new_guide.exists():
        payload['weekly_additional_source']=json.loads(new_guide.read_text(encoding='utf-8'))
    silver_manifest=ROOT/'research/ict_time4_video/manifest.json'
    if silver_manifest.exists():
        silver_meta=json.loads(silver_manifest.read_text(encoding='utf-8'))
        payload['silver_source']={'ppt':silver_meta.get('ppt'),'doc':silver_meta.get('doc'),
                                  'timing_slides':[7,9],'timezone':'America/New_York'}
    payload['weekly_path_basis']='M5 NY-day extremes ordered by actual bar time; retrospective, provisional until day ends; independent of display timeframe'
    catalog=profile_catalog();payload['profile_catalog']={}
    for scope,folder in [('daily','ict_daily_profiles'),('weekly','ict_weekly_profiles')]:
        rules=json.loads((ROOT/'research'/folder/'rules.json').read_text(encoding='utf-8'))
        cards=rules['profiles']+rules.get('variants',[])
        payload['profile_catalog'][scope]=[{'id':c['id'],'name':c['name'],
            **{k:catalog[scope][c['id']][k] for k in ('category','sequence','frame_seconds')}} for c in cards]
    payload['liquidity_basis']={'classification_authority':'交易员无畏视频，仅截图画法参考',
        'source_video':'research/ict_price_videos/foundations/integration.json',
        'source_seconds':[238.84,305],
        'additional_source_video':'research/ict_price_videos/bias_intro/integration.json',
        'additional_source_seconds':[[259.4,308.5],[374.2,394]],
        'reference_images_used_for_classification':False, 'analysis_period_minutes':15,
        'range_choice':'Daily chart: previous complete NY trading day; weekly chart: previous complete NY week',
        'range_choice_engineering':True,'full_dealing_range_qualified':False,
        'semantic_kinds':['swing_stop_pool_proxy','internal_imbalance'],
        'actual_stop_orders_observed':False,'execution_allowed':False}
    calendar_path=ROOT/'research/jin10_calendar/calendar.json'
    if calendar_path.exists():
        payload['calendar']=json.loads(calendar_path.read_text(encoding='utf-8'))
    official_path=ROOT/'research/jin10_calendar/official_schedule.json'
    if official_path.exists():
        official=json.loads(official_path.read_text(encoding='utf-8'))
        official['retrieval_basis']='BLS schedule checked in this session; not a vintage historical feed'
        for event in official['events']:
            t=datetime.fromisoformat(event['ny_date']+'T'+event['ny_time']).replace(tzinfo=NY)
            event.update(time_ms=int(t.timestamp()*1000),source_url=official['source_url'],
                         timing_status='计划' if t.astimezone(timezone.utc)>as_of else '计划时间已过，实际发布未核对')
        payload['official_calendar']=official
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    fragment=args.out_fragment
    text=(ROOT/'scripts/ict_week_fragment.html').read_text(encoding='utf-8')
    if args.standalone:
        d3_tag = '<script src="https://cdn.jsdelivr.net/npm/d3@7.9.0/dist/d3.min.js"></script>'
        d3_source = (ROOT/'vendor/visualize/assets/d3.v7.9.0.min.js').read_text(encoding='utf-8')
        text = text.replace(d3_tag, '<script>'+d3_source.replace('</script', r'<\/script')+'</script>')
    inline=json.loads(json.dumps(payload))
    for scenario in inline['scenarios']:
        for record in scenario['days']+scenario['weeks']:
            record.pop('bars',None);record.pop('fvgs',None)
            if 'days' not in record and '5' in record.get('charts',{}):
                record['charts']['5']['fvgs']=record['charts']['5']['fvgs'][-40:]
            compact_liquidity_for_preview(record.get('liquidity'),record.get('charts',{}).get('15',{}).get('bars'),
                                          weekly='days' in record)
            compact_regular_liquidity(record)
        for record in scenario['weeks']:
            for chart in record.get('charts',{}).values():
                chart.pop('bars',None)
                chart['bars_from_days']=True
        if scenario.get('month'):
            scenario['month']['amd_events']=[{k:v for k,v in e.items()
                if k in ('start','end','lower','upper','phase','route','available_at')}
                for e in scenario['month'].get('amd_events',[])]
    compact_preview_evidence(inline)
    # Full daily gate evidence remains in the research JSON. The self-contained
    # visual shares the policy definition to stay below the 1 MB inline limit.
    for scenario in inline.get('scenarios',[]):
        for record in scenario.get('days',[]):
            record.pop('po3_research_gate',None)
            if isinstance(record.get('po3'),dict):
                p=record['po3'];record['po3']={k:p[k] for k in ('status','zones','direction','reason','basis') if k in p}
    # PO3 research rules remain complete in the research JSON/sidecar. Keep a
    # compact phase trace in the self-contained visual so its 1 MB budget is
    # not consumed by repeated explanatory prose on every daily record.
    if 'po3_basis' in inline:
        inline['po3_basis']={
            'source_path':inline['po3_basis'].get('source_path'),
            'core_principle':inline['po3_basis'].get('core_principle'),
            'po3_vs_amd':{'relationship':inline['po3_basis'].get('po3_vs_amd',{}).get('relationship')},
            'execution_allowed':False
        }
    for scenario in inline.get('scenarios',[]):
        for record in scenario.get('days',[])+scenario.get('weeks',[]):
            evidence=record.get('po3',{}).get('phase_evidence')
            if evidence:
                for item in evidence.values():
                    item.pop('reason',None);item.pop('side',None);item.pop('direction',None)
    encoded=json.dumps(inline,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
    if len(text.replace('__ICT_WEEK_DATA__',encoded).encode('utf-8'))>=fragment_limit:
        # Keep all primary-clock prices/controls rather than truncate the week.
        # The full research JSON above retains the rejected UTC counterexample.
        inline['scenarios']=[s for s in inline['scenarios'] if s['id']=='broker-plus3']
        inline['inline_preview_limitations']=['Raw-UTC counterexample omitted to keep the visual bounded; full research JSON retains both clock hypotheses']
        encoded=json.dumps(inline,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
    if text.count('__ICT_WEEK_DATA__')!=1:
        raise ValueError('Single payload marker required')
    fragment.parent.mkdir(parents=True,exist_ok=True)
    fragment.write_text(text.replace('__ICT_WEEK_DATA__',encoded),encoding='utf-8')
    if fragment.stat().st_size>=fragment_limit:
        raise ValueError(f'Chart fragment exceeds {fragment_limit} bytes')
    if not args.quiet:print(json.dumps({'json':str(out),'fragment':str(fragment),'scenarios':len(scenarios),'days_per_scenario':[len(s['days']) for s in scenarios],'prices_synthetic':False,'clock_verified':False},ensure_ascii=False))
    return inline


if __name__=='__main__':
    main()
