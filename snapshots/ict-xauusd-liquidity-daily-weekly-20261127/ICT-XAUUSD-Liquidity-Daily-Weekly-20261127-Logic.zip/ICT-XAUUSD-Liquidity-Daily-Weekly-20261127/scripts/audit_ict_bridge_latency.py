"""Join actual chart publications to the first MT5 acknowledgement of the same batch."""

from argparse import ArgumentParser
from collections import Counter
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import re
from statistics import median

from ict_ai.dol_history import chart_receipts
from scripts.serve_ict_live import atomic_json


ROOT = Path(__file__).resolve().parents[1]
DIRECTORY = ROOT / 'output/research/ict_bridge_publications_20261125'
COMMON = Path(os.environ['APPDATA']) / 'MetaQuotes/Terminal/Common/Files/ICT_Trader'
FIELDS = ('cutoff', 'quote_read_started', 'quotes_loaded', 'rows_built', 'file_ready')
RECEIPT_PRECISION = timedelta(seconds=1)


def record_publication(batch, cutoff, started, loaded, built, ready, revision, rows):
    if re.fullmatch(r'[a-f0-9]{64}', batch) is None:
        raise ValueError('Unrecognized chart batch')
    path = DIRECTORY / 'batches' / f'{batch}.json'
    if path.exists():
        return
    stages = (cutoff, started, loaded, built, ready)
    if any(b < a for a, b in zip(stages, stages[1:])):
        raise ValueError('Out-of-order bridge publication timestamps')
    atomic_json(path, dict(zip(FIELDS, (at.isoformat() for at in stages)), batch=batch, revision=revision, rows=rows))


def measured(row, received):
    cutoff, started, loaded, built, ready = (datetime.fromisoformat(row[key]) for key in FIELDS)
    if any(b < a for a, b in zip((cutoff, started, loaded, built), (started, loaded, built, ready))):
        raise ValueError(f'Out-of-order bridge timestamps for {row["batch"]}')
    seconds = dict(waiting_for_quote_read=(started-cutoff).total_seconds(), loading_quotes=(loaded-started).total_seconds(),
                   building_marks=(built-loaded).total_seconds(), checking_and_writing_file=(ready-built).total_seconds(),
                   close_to_file=(ready-cutoff).total_seconds())
    state = 'waiting_for_receipt'
    if received is not None:
        if received < ready:
            state = 'earlier_receipt_existing_batch'
        else:
            # The indicator writes TimeGMT() + 1, a conservative upper bound.
            earliest = received - RECEIPT_PRECISION
            state = 'acknowledged'
            seconds.update(file_to_chart_lower=max(0, (earliest-ready).total_seconds()),
                           file_to_chart_upper=(received-ready).total_seconds(),
                           close_to_chart_lower=(max(ready, earliest)-cutoff).total_seconds(),
                           close_to_chart=(received-cutoff).total_seconds())
    return dict(row, state=state, chart_receipt=received.isoformat() if received else None, seconds=seconds)


def first_acknowledged_by_cutoff(rows):
    first = {}
    acknowledged = (row for row in rows if row['state'] == 'acknowledged')
    for row in sorted(acknowledged, key=lambda row: (row['chart_receipt'], row['file_ready'])):
        first.setdefault(row['cutoff'], row)
    return sorted(first.values(), key=lambda row: row['cutoff'])


def median_stages(rows):
    durations = [row['seconds'] for row in rows]
    return {key: median(row[key] for row in durations) for key in durations[0]} if durations else {}


def summarize(receipt_dir, now):
    receipts = chart_receipts(receipt_dir, now)
    rows = []
    for path in sorted((DIRECTORY / 'batches').glob('*.json')):
        row = json.loads(path.read_bytes())
        if path.stem != row['batch']:
            raise ValueError(f'Timing record has a different batch ID: {path.name}')
        rows.append(measured(row, receipts.get(row['batch'])))
    rows.sort(key=lambda row: row['file_ready'])
    acknowledged = [row for row in rows if row['state'] == 'acknowledged']
    first = first_acknowledged_by_cutoff(rows)
    return dict(observed_at=now.isoformat(), counts=Counter(row['state'] for row in rows),
                acknowledged_median_seconds=median_stages(acknowledged),
                first_acknowledged_cutoffs=len(first), later_acknowledged_batches=len(acknowledged)-len(first),
                first_cutoff_median_seconds=median_stages(first), latest_first_cutoffs=first[-24:],
                latest_measurements=rows[-24:],
                timing_basis='Only join identical batch IDs. MT5 logs TimeGMT() + 1 second. The primary median uses the first measured new acknowledgement per M5 cutoff.',
                orders_sent=0)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--receipt-dir', type=Path, default=COMMON / 'DOLReceipts')
    args = parser.parse_args()
    report = summarize(args.receipt_dir, datetime.now(timezone.utc))
    atomic_json(DIRECTORY / 'status.json', report)
    print(json.dumps(dict(counts=report['counts'], cutoffs=report['first_acknowledged_cutoffs'],
                          later_batches=report['later_acknowledged_batches'],
                          seconds=report['first_cutoff_median_seconds']), ensure_ascii=False))
