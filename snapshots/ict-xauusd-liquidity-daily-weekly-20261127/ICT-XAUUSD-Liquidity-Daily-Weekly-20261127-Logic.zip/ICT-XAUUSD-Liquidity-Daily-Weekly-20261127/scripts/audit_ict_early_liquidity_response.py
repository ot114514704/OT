"""Check what follows crossings first caught by four-bar liquidity preselection."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timedelta
import json
from pathlib import Path

from ict_ai.sweep_response import sequence
from ict_ai.sweep_state import crossing_state
from scripts import audit_ict_micro_liquidity_missing_boards as missing
from scripts import audit_ict_micro_liquidity_recent_all_m5 as recent
from scripts import replay_ict_sweep_verdict as replay


fixed, live, M5 = recent.fixed, recent.live, recent.M5
stream = recent.stream
OUT = recent.OUT.with_name('ict_early_liquidity_response_20261125.json')
QUOTES = OUT.with_name(OUT.stem + '_m5.json.gz')
WINDOWS = (15, 60)
REPLAY_DELAY = timedelta(seconds=30)
DIRECTIONAL = ('sweep', 'break')


def checked_inputs():
    archived, study = missing.captured_inputs()
    rebuilt = fixed.read(missing.OUT)
    for path in (recent.INPUT, missing.EVIDENCE, stream.POLICY, Path(missing.__file__)):
        if recent.digest(path) != rebuilt['inputs'][path.name]:
            raise ValueError(f'Reconstructed input changed: {path.name}')
    return archived, study, rebuilt


def capture(pid):
    _, study, _ = checked_inputs()
    now = live.now()
    start = datetime.fromisoformat(study['start']) - 2 * timedelta(hours=1)
    with fixed.open_terminal(pid) as alive, live.terminal() as (api, clock):
        bars = live.feed.history('XAUUSD', api.TIMEFRAME_M5, clock, now)
        if not alive():
            raise RuntimeError('Configured MT5 session closed during capture')
    selected = [b for b in bars if b.time >= start]
    board = recent.board.joint
    board.write_zip(QUOTES, dict(captured_at=now.isoformat(), m5=recent.rows(selected),
                                first_study_sha256=recent.digest(recent.INPUT),
                                reconstructed_sha256=recent.digest(missing.OUT)))


def crossings(data, ready, bucket, oracle):
    graded = fixed.grade(data, ready, [bucket], 1)
    measured = stream.paired(graded)['IRL']
    if any(value != oracle[key] for key, value in measured.items()):
        raise ValueError(f'Early recognition no longer reproduces at {data["cutoff"]}')
    baseline, early = (
        {stream.expiry.outer(p): p for p in graded['outcomes'][arm]['IRL'][::-1] if p['status'] == 'sweep'}
        for arm in ('baseline', 'early'))
    if 'added_edges' in oracle:
        edges = [[*edge, early[edge]['bid_time_ms']] for edge in sorted(early.keys() - baseline.keys())]
        if edges != oracle['added_edges']:
            raise ValueError(f'Previously recorded Bid crossings changed at {data["cutoff"]}')
    return [(kind, book[edge]) for kind, keys, book in (
                ('shared', baseline.keys() & early.keys(), baseline),
                ('incremental', early.keys() - baseline.keys(), early),
                ('displaced', baseline.keys() - early.keys(), baseline))
            for edge in sorted(keys)]


def score_event(bars, times, index, event):
    crossing = bars[index]
    at = crossing.time + M5
    side, edge = stream.expiry.outer(event)
    earlier = bars[max(0, index - 24):index]
    later = bars[index + 1:index + 49]
    decisions = replay.evaluate_crossing(bars, times, at, side, edge)['decisions']
    results = {}
    for minutes in WINDOWS:
        observed = at + timedelta(minutes=minutes)
        decision = decisions[str(minutes)]
        prefix = replay.verify_observation(bars, index, 1 + minutes // 5)
        row = dict(decision, state2=None, close_side=None, structure=None)
        if prefix:
            relative = side * (prefix[-1].close - edge)
            row['close_side'] = 'sweep' if relative < 0 else 'break' if relative > 0 else None
            state = crossing_state(side, edge, crossing, list(prefix[1:]), observed, decision['prior_atr'])
            if state != crossing_state(side, edge, crossing, later, observed, decision['prior_atr']):
                raise ValueError(f'Later quotes changed the decision at {observed}')
            row['state2'] = state
            if replay.verify_observation(bars, index - 24, 25):
                row['structure'] = sequence(event, earlier, prefix, crossing.time)
        results[str(minutes)] = row
    return results


def event_rows(archived, study, rebuilt):
    sources = [
        ('acknowledged', archived, recent.BID, 'slots', recent.initialize),
        ('reconstructed', rebuilt, missing.EVIDENCE, 'bid', missing.initialize),
    ]
    for name, report, path, field, initialize in sources:
        buckets = recent.board.joint.read_zip(path)[field]
        cases = [row for row in report['cases'] if (
            row.get('outcomes', row).get('30', {}).get('IRL', {}).get('baseline_hits', 0)
            or row.get('outcomes', row).get('30', {}).get('IRL', {}).get('added', 0)
        )]
        with ProcessPoolExecutor(max_workers=5, initializer=initialize) as pool:
            if name == 'acknowledged':
                rebuilt_boards = (data for _, _, data in pool.map(
                    recent.identify, [(c['cutoff'], study['boards'][c['cutoff']]) for c in cases], chunksize=3))
            else:
                rebuilt_boards = pool.map(missing.reconstruct, [c['cutoff'] for c in cases], chunksize=3)
            for case, board in zip(cases, rebuilt_boards, strict=True):
                if not board or board['cutoff'] != case['cutoff']:
                    raise ValueError(f'Candidate board did not reproduce: {case["cutoff"]}')
                at = datetime.fromisoformat(case['cutoff'])
                ready = at + REPLAY_DELAY
                if name == 'acknowledged':
                    ready = max(ready, datetime.fromisoformat(case['chart_receipt']))
                expected = case.get('outcomes', case)['30']['IRL']
                bucket = buckets[case['cutoff']]
                yield name, at, ready, bucket['ohlc'], crossings(board, ready, bucket, expected)


def summary(rows):
    totals = defaultdict(lambda: defaultdict(Counter))
    for row in rows:
        for minutes, decision in row['decisions'].items():
            group = totals[row['source'] + '/' + row['origin']][minutes]
            group['strict_crossings'] += 1
            later = decision['later_30m']
            group['later/' + later] += 1
            group['v7b/' + decision['status']] += 1
            if decision['structure']:
                group['shape/' + decision['structure']['shape']] += 1
            if later not in DIRECTIONAL or decision['status'] in ('incomplete', 'missing_prior'):
                continue
            group['directional_with_evidence'] += 1
            state = decision['state2']['status'] if decision['state2'] else None
            for method, pred in (('v7b', decision['status']), ('state2', state),
                                 ('close_side', decision['close_side']), ('all_sweeps', 'sweep')):
                if pred in DIRECTIONAL:
                    group[f'{method}_called'] += 1
                    group[f'{method}_matched'] += pred == later
    return totals


def audit():
    archived, study, rebuilt = checked_inputs()
    tape = recent.board.joint.read_zip(QUOTES)
    if (tape['first_study_sha256'] != recent.digest(recent.INPUT)
            or tape['reconstructed_sha256'] != recent.digest(missing.OUT)):
        raise ValueError('Response prices belong to different frozen inputs')
    bars = missing.unpack(tape['m5'])
    times = [bar.time for bar in bars]
    prior_tape = {row[0]: row[1:] for row in study['m5']}
    excluded = Counter()
    cases = []
    for name, at, ready, crossing_ohlc, hits in event_rows(archived, study, rebuilt):
        start = bisect_left(times, at)
        for origin, event in hits:
            known = event['bid_time_ms']
            if not fixed.utc_ms(ready) < known < fixed.utc_ms(at + M5):
                raise ValueError(f'Crossing falls outside the strict registration interval: {at}')
            if start >= len(times) or times[start] != at or live.quotes.ohlc(bars[start]) != crossing_ohlc:
                excluded[f'{name}/{origin}/changed_crossing_bar'] += 1
                continue
            relevant = bars[max(0, start - 24):start + 19]
            if any(prior_tape[b.time.isoformat()] != live.quotes.ohlc(b) for b in relevant
                   if b.time.isoformat() in prior_tape):
                excluded[f'{name}/{origin}/changed_context'] += 1
                continue
            result = score_event(bars, times, start, event)
            cases.append(dict(source=name, origin=origin, cutoff=at.isoformat(), ready=ready.isoformat(),
                              crossing=event, decisions=result))
    report = dict(captured_at=tape['captured_at'], exclusions=excluded, groups=summary(cases), cases=cases,
                  inputs={path.name: recent.digest(path) for path in (
                      recent.OUT, missing.OUT, QUOTES, Path(__file__), Path(replay.__file__),
                      live.feed.ROOT / 'ict_ai/sweep_response.py', live.feed.ROOT / 'ict_ai/sweep_state.py')},
                  method=('Compare post-registration strict IRL crossings with the same board result. '
                          'Assess response on closed M5 at 15 and 60 minutes after the crossing bar closes. '
                          'The next six closes grade sustained reclaim, sustained break or mixed. '
                          'Coverage gaps abstain. Both studies are retrospective.'), orders_sent=0)
    live.atomic_json(OUT, report)
    print(json.dumps(dict(groups=report['groups'], exclusions=excluded), ensure_ascii=False))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture-terminal-pid', type=int)
    args = parser.parse_args()
    if args.capture_terminal_pid:
        capture(args.capture_terminal_pid)
    audit()
