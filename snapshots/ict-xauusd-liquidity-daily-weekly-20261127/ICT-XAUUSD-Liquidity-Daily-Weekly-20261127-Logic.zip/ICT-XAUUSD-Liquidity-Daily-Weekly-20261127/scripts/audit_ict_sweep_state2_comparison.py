"""Compare the pinned upstream sweep rules on pre-existing XAUUSD tapes."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime
from hashlib import sha1
from pathlib import Path
from runpy import run_path

from scripts import audit_ict_sweep_combination as combination
from scripts import compare_ict_sweep_structure as structure


replay = structure.replay
UPSTREAM_BLOB = '679f9764e1d293edd6e0677399f730380dd59117'
UPSTREAM_SOURCE = ('https://github.com/alexander094683-projects/forex-ai-source/blob/'
                   '6f62516ea220bca8eff3952c119c79c6c2fd2dca/docs_layered/work_backup/sweep_v7.py')
OUT = replay.OUT.parent / 'ict_sweep_state2_comparison_20261125.json'
METHODS = ('v7b', 'structure_first', 'rt', 'e', 'state_v1', 'state2_default', 'state2_1_5',
           'hold_v2_atr_only', 'cutoff_close_side')
WINDOWS = (15, 60)
COHORTS = tuple(f'{period}/short/{scope}/{pick}' for period in ('oct_nov', 'last_week')
                for scope in ('IRL', 'ERL') for pick in ('top10', 'final_filter'))


def predictions(algorithms, event, bars, times, minutes):
    observation = event['decisions'][str(minutes)]
    opened = datetime.fromisoformat(event['crossing_at']) - replay.M5
    index = bisect_left(times, opened)
    prefix = replay.verify_observation(bars, index, 1 + minutes // 5)
    if not prefix or prefix[0].time != opened or not observation['prior_atr']:
        raise ValueError(f'Missing evidence for an eligible event at {opened}')
    args = (prefix, 0, event['side'], event['edge'], observation['prior_atr'])
    last = event['side'] * (prefix[-1].close - event['edge'])
    baseline = observation['status']
    upstream_v7b = algorithms['classify_b'](*args).label
    if upstream_v7b != baseline:
        raise ValueError(f'Archived V7B differs from its upstream reference at {opened}')
    verdicts = {
        'v7b': baseline,
        'rt': algorithms['classify_rt'](*args).label,
        'e': algorithms['classify_e'](*args).label,
        'state_v1': algorithms['classify_state'](*args).label,
        'state2_default': algorithms['classify_state2'](*args).label,
        'state2_1_5': algorithms['classify_state2'](*args, end_atr=1.5).label,
        'hold_v2_atr_only': algorithms['label_hold_v2'](*args).label,
        'cutoff_close_side': 'break' if last > 0 else 'sweep' if last < 0 else None,
    }
    if minutes == 60:
        verdicts['structure_first'] = structure.structure_verdict(event, bars, times) or baseline
    return {name: label if label in ('break', 'sweep') else None for name, label in verdicts.items()}


def compare(algorithms, events, bars, times, minutes):
    counts = {name: Counter() for name in METHODS if name != 'structure_first' or minutes == 60}
    baseline_name = 'structure_first' if minutes == 60 else 'v7b'
    paired = {name: defaultdict(Counter) for name in counts if name != baseline_name}
    state_vs_close = defaultdict(Counter)
    totals = Counter()
    for event in events:
        observation = event['decisions'][str(minutes)]
        outcome = observation['later_30m']
        if observation['status'] in ('missing_prior', 'incomplete') or outcome == 'incomplete':
            totals['unavailable'] += 1
            continue
        totals['eligible'] += 1
        totals[outcome] += 1
        verdicts = predictions(algorithms, event, bars, times, minutes)
        baseline = verdicts[baseline_name]
        if outcome != 'mixed':
            week = state_vs_close[combination.week_of(event)]
            state, side = verdicts['state2_default'], verdicts['cutoff_close_side']
            week['common'] += 1
            week['difference'] += int(state == outcome) - int(side == outcome)
            if state != side:
                totals['state_vs_close_different'] += 1
                totals['state_won'] += state == outcome
                totals['close_won'] += side == outcome
        for name, label in verdicts.items():
            bucket = counts[name]
            if label is not None:
                bucket['called'] += 1
                bucket['directional_called'] += outcome != 'mixed'
                bucket['matched'] += label == outcome
            if outcome == 'mixed' or name == baseline_name:
                continue
            week = paired[name][combination.week_of(event)]
            week['common'] += 1
            week['difference'] += int(label == outcome) - int(baseline == outcome)
            if label is not None and baseline is not None:
                bucket['common_with_baseline'] += 1
                bucket['matched_common'] += label == outcome
                bucket['baseline_matched_common'] += baseline == outcome
    return dict(totals=totals, methods=counts, baseline=baseline_name,
                paired_all_directional={name: combination.week_interval(list(weeks.values()))
                                        for name, weeks in paired.items()},
                state2_vs_cutoff_close=combination.week_interval(list(state_vs_close.values())))


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('upstream', type=Path, help='Exact upstream sweep_v7.py at the pinned GitHub revision')
    args = parser.parse_args()
    raw = args.upstream.read_bytes()
    if sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest() != UPSTREAM_BLOB:
        raise ValueError('Upstream file does not match the pinned Git blob')
    algorithms = run_path(str(args.upstream))
    bars, times, *_, input_hashes = replay.read_inputs()
    stored = replay.OUT / 'events.json.gz'
    source = replay.study.read_zip(stored)
    older, older_bars, older_times, older_hashes = combination.older_events()
    results = {}
    for minutes in WINDOWS:
        groups = {}
        for key in COHORTS:
            events = (source['events'][i] for i in source['indices'][key])
            groups[key] = compare(algorithms, events, bars, times, minutes)
        groups['2025-09_to_2026-03/nearest_pool'] = compare(algorithms, older, older_bars, older_times, minutes)
        results[str(minutes)] = groups
    replay.filters.atomic_json(OUT, dict(upstream=UPSTREAM_SOURCE, git_blob=UPSTREAM_BLOB,
        recent_events_sha256=replay.study.digest(stored), older_inputs=older_hashes,
        comparison_inputs=input_hashes, analysis_sha256=replay.study.digest(Path(__file__).resolve()),
        cutoff='minutes after the crossing bar closes',
        outcome='all six subsequent M5 closes strictly on one side of the edge, otherwise mixed',
        cover='called/eligible, with abstentions retained in the directional denominator for paired differences',
        hold='six bars and frozen 1 ATR, without optional origin_price',
        results=results, orders_sent=0))
    for minutes, groups in results.items():
        for key, grade in groups.items():
            print(minutes, key, dict(grade['totals']),
                  {name: tuple(v[k] for k in ('matched', 'directional_called', 'called'))
                   for name, v in grade['methods'].items()})


if __name__ == '__main__':
    main()
