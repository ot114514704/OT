"""Check the frozen decision candle against later native rates and reconciled Bid."""

from argparse import ArgumentParser
from datetime import datetime
import json
from pathlib import Path

from scripts import watch_ict_micro_liquidity_forward as witness
from scripts import watch_ict_profile_feed as feed


OUT = feed.ROOT / 'decision_revision_audit.json'
archive, daily = feed.archive, feed.daily
FIELDS = ('open', 'high', 'low', 'close')


def audit(pid):
    import MetaTrader5 as mt5

    protocol = feed.read_protocol()
    models = {source: source.load_model() for source in (feed.early, daily)}
    scorable = {clock: (source, models[source]) for clock in feed.CHECKPOINTS
                for source in (feed.early if clock in feed.EARLY else daily,)}
    forecasts = sorted(feed.ROOT.glob('????-??-??_????.json'))
    records = []
    ticks = {}
    observed = daily.utc_now()
    with daily.open_terminal(pid) as alive:
        for path in forecasts:
            record, prefix = feed.validate(path, scorable, protocol)
            end = datetime.fromisoformat(record['forecast_end'])
            at = datetime.fromisoformat(record['cutoff'])
            candle = at - feed.M5
            current = feed.settlement.capture_tail(mt5, alive, models[daily], candle, at)
            original = feed.signature(prefix[-1])
            native = feed.signature(current[0]) if len(current) == 1 and current[0].time == candle else None
            evidence = {}
            if native is not None and native != original:
                evidence = next((row for _, row in witness.capture_buckets(
                    mt5, alive, witness.frozen_feed(), [candle], daily.utc_now())), {})
                if evidence:
                    ticks[record['cutoff']] = evidence
            tape = evidence.get('ohlc')
            changes = {name: [old, new] for name, old, new in zip(FIELDS, original[1:], native[1:] if native else original[1:], strict=True)
                       if old != new}
            state = 'native_unavailable' if native is None else 'native_matches_frozen' if not changes else 'native_changed'
            records.append(dict(cutoff=record['cutoff'], forecast_sha256=archive.digest(path), ready=record['recorded_at'],
                                end=end.isoformat(), mature=observed >= end + feed.settlement.SYNC_GRACE,
                                state=state, frozen=original, latest_native=native, price_changes=changes,
                                bid_reference=tape, bid_ticks=len(evidence.get('bid_offsets', [])),
                                agrees_with_bid='frozen' if tape == original[1:] else
                                'latest_native' if native and tape == native[1:] else 'unverified'))
    tape = OUT.with_suffix('.json.gz')
    archive.write_zip(tape, ticks)
    feed.atomic_json(OUT, dict(observed_at=observed.isoformat(), decision_source=feed.ROOT.name,
                               records=records, inputs={p.name: archive.digest(p) for p in (Path(__file__), tape)}, orders_sent=0))
    print(json.dumps({'records': len(records), 'changes': [row for row in records if row['state'] != 'native_matches_frozen']}))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--terminal-pid', type=int, required=True)
    audit(parser.parse_args().terminal_pid)
