"""Register prospective early-session daily profile scores against native chart receipts."""

from argparse import ArgumentParser
from collections import Counter
from datetime import datetime, timedelta
import json
from pathlib import Path
import sqlite3
import time

import numpy as np

from brooks_ai.types import Bar
from scripts import audit_ict_intraday_learning as study
from scripts import watch_ict_daily_learning as registration


daily = study.daily
archive = registration.archive
FOLDER = daily.RESEARCH/'intraday_learning_shadow_20261123'
MODEL = FOLDER/'model.json'
REPORT = daily.RESEARCH/'ict_intraday_learning_20261123.json'
CHECKPOINTS = study.CHECKPOINTS[:3]
CODE = (*registration.CODE, Path(__file__),Path(study.__file__))


def freeze():
    before = registration.utc_now()
    feed = registration.load_model()
    reference = json.loads(REPORT.read_bytes())
    if MODEL.exists():
        raise FileExistsError(MODEL)
    for path in (daily.ARCH/'XAUUSDM5.npz',daily.ARCH/'clock_validation.json',*daily.MANUAL,*CODE[1:]):
        if path==Path(__file__):
            continue
        if reference['inputs'][path.name]!=archive.digest(path):
            raise ValueError(f'Study input changed: {path}')
    manual = study.read_manual()
    bars,times = daily.read_market()
    checkpoints = study.rebuild_checkpoints(bars,times)
    pooled,_ = study.pooled_matrix(checkpoints,manual)
    training = [r for r in pooled if r['end']<before]
    classes = Counter(hit for group in training for _,hit in set(zip(group['keys'],group['y'],strict=True)))
    if len(training)<35 or min(classes[0],classes[1])<8:
        raise ValueError('Insufficient mature daily labels')
    baselines = {}
    for checkpoint in CHECKPOINTS:
        name = checkpoint.strftime('%H:%M')
        groups = [r for r in checkpoints[name] if r['end']<before and r['keys'] and r['y'] is not None
                  and r['date'].isoformat() not in manual]
        labels = Counter(hit for r in groups for hit in r['y'])
        if len(groups)<35 or min(labels[0],labels[1])<8:
            raise ValueError(f'Insufficient mature labels at {name}')
        baselines[name] = [dict(keys=r['keys'],y=r['y']) for r in groups]
    model = dict(frozen_at=registration.utc_now().isoformat(),training_dates=len(training),
                 label_ready_through=training[-1]['end'].isoformat(),model=[v.tolist() for v in daily.fit_prior_weeks(training)],
                 baselines=baselines,server=feed['server'],symbol=feed['symbol'],clock=feed['clock'],
                 reference_model_sha256=archive.digest(registration.MODEL),report_sha256=archive.digest(REPORT),
                 code={p.name:archive.digest(p) for p in CODE},scope='research_only',orders_sent=0)
    FOLDER.mkdir(parents=True,exist_ok=True)
    registration.write_once(MODEL,model)
    print('Frozen early-session model:',model['training_dates'],'distinct training dates')


def load_model():
    model = json.loads(MODEL.read_bytes())
    if (any(model['code'][p.name]!=archive.digest(p) for p in CODE) or model['report_sha256']!=archive.digest(REPORT)
            or model['reference_model_sha256']!=archive.digest(registration.MODEL)):
        raise ValueError('Early-session model or study provenance changed')
    return model


def score(model,bars,at):
    local = at.astimezone(daily.NY)
    name = local.strftime('%H:%M')
    rows = study.rebuild_checkpoints(bars,[b.time for b in bars])[name]
    row = next((r for r in rows if r['at']==at),None)
    if row is None or not row['prefix_covered']:
        return dict(status='insufficient_m5_coverage',candidates=[])
    if not row['keys']:
        return dict(status='no_candidate',candidates=[])
    elapsed = local.hour*60+local.minute-7*60
    features = [[*x,elapsed] for x in row['x']]
    pm = tuple(np.array(v) for v in model['model'])
    baseline = [dict(keys=[tuple(k) for k in r['keys']],y=r['y']) for r in model['baselines'][name]]
    learned,prior = daily.forecast(dict(keys=row['keys'],x=features),baseline,pm)
    candidates = [dict(profile=key[0],direction=key[1],features=x,pooled_probability=p,signed_family_prior=b)
                  for key,x,p,b in zip(row['keys'],features,learned,prior,strict=True)]
    return dict(status='scores_recorded',candidates=candidates)


def record_paths(at):
    stem = at.astimezone(daily.NY).strftime('%Y-%m-%d_%H%M')
    return FOLDER/f'{stem}.json',FOLDER/f'{stem}-M5.json.gz'


def observe(now,at,model,api,alive):
    path,evidence = record_paths(at)
    if path.exists():
        return 'recorded'
    if at<=datetime.fromisoformat(model['frozen_at']):
        return 'cutoff_precedes_model'
    if now<at:
        return 'waiting_for_cutoff'
    if now>=at+registration.WINDOW:
        return 'recording_window_elapsed'
    receipt = registration.chart_receipt(at,now)
    if not receipt:
        return 'waiting_for_chart_receipt'
    bars,tick = registration.capture(api,alive,model,at)
    if tick<at:
        return 'waiting_for_post_cutoff_quote'
    if abs(bars[-1].close-receipt['closing_price'])>1e-8:
        return 'receipt_price_mismatch'
    result = score(model,bars,at)
    temp = evidence.with_suffix('.tmp')
    archive.write_zip(temp,[[b.time.isoformat(),b.open,b.high,b.low,b.close] for b in bars])
    temp.replace(evidence)
    registered = registration.utc_now()
    if registered>=at+registration.WINDOW:
        return 'recording_window_elapsed'
    registration.atomic_json(path,dict(**result,cutoff=at.isoformat(),recorded_at=registered.isoformat(),
                           forecast_end=daily._day_bounds(at.astimezone(daily.NY).date())[1].isoformat(),
                           forecast_model='pooled_intraday',model_sha256=archive.digest(MODEL),
                           m5_sha256=archive.digest(evidence),chart=receipt,fresh_quote_utc=tick.isoformat(),orders_sent=0))
    return 'recorded'


def verify(model):
    count = 0
    for path in sorted(FOLDER.glob('????-??-??_????.json')):
        record = json.loads(path.read_bytes())
        at,registered,tick = (datetime.fromisoformat(record[k]) for k in ('cutoff','recorded_at','fresh_quote_utc'))
        local = at.astimezone(daily.NY)
        expected,evidence = record_paths(at)
        if (path!=expected or local.weekday()>4 or local.time() not in CHECKPOINTS
                or not datetime.fromisoformat(model['frozen_at'])<at<=tick<=registered+timedelta(seconds=3)
                or not at<=registered<at+registration.WINDOW or registration.chart_receipt(at,registered)!=record['chart']
                or record['model_sha256']!=archive.digest(MODEL) or record['m5_sha256']!=archive.digest(evidence)
                or record['forecast_end']!=daily._day_bounds(local.date())[1].isoformat()):
            raise ValueError(f'Invalid registration: {path}')
        bars = [Bar(datetime.fromisoformat(t),o,h,l,c,0) for t,o,h,l,c in archive.read_zip(evidence)]
        if (not bars or bars[-1].time+daily.M5!=at or any(a.time>=b.time for a,b in zip(bars,bars[1:]))
                or abs(bars[-1].close-record['chart']['closing_price'])>1e-8):
            raise ValueError(f'Invalid chart evidence: {path}')
        if any(record[k]!=v for k,v in score(model,bars,at).items()):
            raise ValueError(f'Unreproducible registration: {path}')
        count+=1
    return count


def main():
    parser = ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--freeze',action='store_true')
    mode.add_argument('--verify',action='store_true')
    mode.add_argument('--terminal-pid',type=int)
    args = parser.parse_args()
    if args.freeze:
        freeze()
        return
    model = load_model()
    if args.verify:
        print('Verified early-session registrations:',verify(model))
        return

    import msvcrt
    import MetaTrader5 as api

    with registration.open_terminal(args.terminal_pid) as alive, (FOLDER/'watch.lock').open('a+b') as lock:
        lock.seek(0)
        msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        previous = None
        while alive():
            now = registration.utc_now()
            day = now.astimezone(daily.NY).date()
            records = {}
            for checkpoint in CHECKPOINTS:
                at = datetime.combine(day,checkpoint,daily.NY).astimezone(registration.UTC)
                try:
                    result = observe(now,at,model,api,alive) if day.weekday()<5 else 'weekend'
                except (RuntimeError,OSError,sqlite3.OperationalError) as exc:
                    result = {'status':'temporarily_unavailable','reason':str(exc)}
                records[checkpoint.strftime('%H:%M')] = dict(cutoff=at.isoformat(),state=result)
            if records!=previous:
                registration.atomic_json(FOLDER/'status.json',dict(ny_date=str(day),checkpoints=records,
                                         checked_at=now.isoformat(),terminal_pid=args.terminal_pid,orders_sent=0))
                print(now.isoformat(),records,flush=True)
                previous = records
            time.sleep(10)


if __name__=='__main__':
    main()
