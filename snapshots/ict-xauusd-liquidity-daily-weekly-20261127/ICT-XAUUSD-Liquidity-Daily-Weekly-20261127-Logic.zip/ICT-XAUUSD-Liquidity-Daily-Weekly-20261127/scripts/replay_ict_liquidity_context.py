"""Measure causal price-path, New York clock and pattern effects on strict sweeps."""
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts import replay_ict_liquidity_rank as ranking
from scripts.check_pool_priority import interval, read_market

study = ranking.study
TIMES = ('00:05', '02:00', '08:00', '10:00', '14:00')
MODELS = {
    'structure': (),
    'trend': ('trend',),
    'clock': ('clock',),
    'pattern': ('pattern',),
    'combined': ('trend', 'clock', 'pattern'),
    'without_trend': ('clock', 'pattern'),
    'without_clock': ('trend', 'pattern'),
    'without_pattern': ('trend', 'clock'),
}


def price_context(bars, times, at, scale):
    end = bisect_left(times, at)
    assert times[end-1] + study.M5 == at
    count = 1
    while count < min(end, 48) and times[end-count-1] == at-(count+1)*study.M5:
        count += 1
    series = bars[end-count:end]
    last = series[-1].close
    trend = []
    for size in (3, 12, 48):
        change = last-series[-size].open if count >= size else 0
        trend.extend((float(np.clip(change/scale, -6, 6)), int(count>=size)))

    # Prior hour defines the range; the last six closed M5s give the reaction.
    # A sweep/reclaim here is an observed setup, independent of any future target label.
    if count < 18:
        return trend, 'missing', 0, 0
    older, recent = series[-18:-6], series[-6:]
    hi, lo = max(b.high for b in older), min(b.low for b in older)
    r_hi, r_lo = max(b.high for b in recent), min(b.low for b in recent)
    up, down = r_hi > hi, r_lo < lo
    if last > hi:
        shape, direction = 'breakout', 1
    elif last < lo:
        shape, direction = 'breakout', -1
    elif up and down:
        shape, direction = 'both_reclaimed', 0
    elif up or down:
        shape, direction = 'reclaimed', -1 if up else 1
    elif r_hi-r_lo <= .65*max(hi-lo, .01):
        shape, direction = 'compression', 0
    else:
        shape, direction = 'range', 0
    return trend, shape, direction, (hi-lo)/scale


def add_context(groups, bars, times):
    for g in groups:
        if g['status'] != 'complete' or not g['targets']:
            continue
        at = g['at']
        local = at.astimezone(study.NY)
        clock = local.strftime('%H:%M')
        assert clock in TIMES
        scale = g['targets'][0]['hourly_range']
        assert bars[bisect_left(times, at)-1].close == g['price']
        trend, shape, direction, prior_width = price_context(bars, times, at, scale)
        g['clock'], g['shape'] = clock, shape
        g['features'] = []
        g['relationship'] = []
        for target, distance, base in zip(g['targets'], g['distance'], g['x'], strict=True):
            side = target['side']
            move = [v*side if i%2==0 else v for i,v in enumerate(trend)]
            clock_flags = [int(clock==point) for point in TIMES]
            duration = (g['end']-at).total_seconds()/3600
            when = [*clock_flags, *(distance*v for v in clock_flags),
                    np.log1p(duration), np.log1p(duration)*np.log1p(distance)]
            pattern = [int(shape==key) for key in
                       ('missing','compression','range','both_reclaimed','breakout','reclaimed')]
            pattern.extend((side*direction*int(shape=='breakout'),
                            side*direction*int(shape=='reclaimed'), np.log1p(prior_width)))
            g['features'].append(dict(base=base, trend=move, clock=when, pattern=pattern))
            g['relationship'].append('aligned' if side*direction>0 else 'opposed' if direction else 'neutral')
        g['x_by_model'] = {name:[row['base']+[value for key in keys for value in row[key]]
                                 for row in g['features']] for name,keys in MODELS.items()}


def fit(groups, name):
    return ranking.fit_prior_weeks([dict(x=g['x_by_model'][name],y=g['y']) for g in groups])


def evaluate(groups, selected=None):
    names = ('current','nearest_far_edge',*MODELS)
    totals = {name:Counter() for name in names}
    windows, examples = Counter(), {}
    contexts = defaultdict(Counter)
    folds = []
    weeks = sorted({g['week'] for g in groups if g['day']>=ranking.FIRST_HOLDOUT})
    for week in weeks:
        test = [g for g in groups if g['week']==week and g['day']>=ranking.FIRST_HOLDOUT]
        train = [g for g in groups if g['week']<week and g['end']<test[0]['at']
                 and g['status']=='complete' and g['targets']]
        models = {name:fit(train,name) for name in MODELS}
        fold = {name:Counter() for name in names}
        for g in test:
            windows[g['status']] += 1
            if g['status']!='complete':
                continue
            count = len(g['targets'])
            orders = dict(current=list(range(count)),
                          nearest_far_edge=sorted(range(count),key=g['distance'].__getitem__))
            for name,(mean,scale,coef) in models.items():
                logits = ((np.array(g['x_by_model'][name])-mean)/scale)@coef[1:] if count else []
                orders[name] = sorted(range(count),key=lambda i:(-logits[i],g['distance'][i],i))
            if selected is not None:
                selected[g['at']] = orders['combined'][:10]
            for name,order in orders.items():
                ranking.record(fold[name],order,g['events'])
                for i in order[:10]:
                    tag = (g['clock'],g['shape'],g['relationship'][i])
                    for key in (g['clock'],g['shape'],'/'.join(tag)):
                        contexts[name,key].update(n=1,sweep=int(g['y'][i]),
                                                  reclaim=int(bool(g['events'][i]['reclaim'])))
            if count:
                before,after = (orders[k][0] for k in ('nearest_far_edge','combined'))
                if g['y'][before]!=g['y'][after]:
                    key = 'recovered' if g['y'][after] else 'lost'
                    examples.setdefault(key,dict(at=g['at'].isoformat(),end=g['end'].isoformat(),
                        price=g['price'],clock=g['clock'],shape=g['shape'],
                        before=g['targets'][before],after=g['targets'][after],
                        before_result=g['events'][before],after_result=g['events'][after]))
        for name in names:
            totals[name].update(fold[name])
        folds.append(dict(week=str(week),train=len(train),first_evaluation=test[0]['at'].isoformat(),
                          latest_training_label=max(g['end'] for g in train).isoformat(),comparisons=fold))
    contrasts = [('combined', name) for name in names if name!='combined']
    paired = {}
    for model,control in contrasts:
        blocks = {}
        for f in folds:
            new,base = (f['comparisons'][k] for k in (model,control))
            assert new['top10_offers']==base['top10_offers']
            if base['top10_offers']:
                blocks[f['week']] = (new['top10_sweep']-base['top10_sweep'],base['top10_offers'])
        qty = sum(n for _,n in blocks.values())
        paired[control] = dict(delta=sum(k for k,_ in blocks.values())/qty,
                               week_block_ci95=interval(blocks),weeks=len(blocks))
    return dict(windows=windows,comparisons=totals,folds=folds,paired_combined=paired,
                conditional={name:{key:v for (m,key),v in contexts.items() if m==name}
                             for name in ('nearest_far_edge','combined')},examples=examples)


def main():
    folder = ranking.ARCHIVE
    lock = json.loads((folder/'round19_liquidity_50_lock.json').read_bytes())
    baseline = json.loads((folder/'round19_liquidity_baseline.json').read_bytes())
    archived = (folder/'round19_liquidity_50_candidates.json.gz',folder/'round19_liquidity_50_outcomes.json.gz')
    manifest = {p.name:study.digest(p) for p in archived}
    assert list(manifest.values()) == [lock['candidates'],baseline['outcomes_sha256']]
    assert baseline['freeze_sha256']==lock['candidates']
    market_path = next(ROOT/path for path in lock['sources'] if path.endswith('/XAUUSDM5.npz'))
    assert study.digest(market_path)==lock['sources'][market_path.relative_to(ROOT).as_posix()]
    bars,times = read_market()
    pairs = list(zip(*(study.read_zip(p) for p in archived),strict=True))
    results = {}
    for horizon in ('short','week'):
        for scope in ('IRL','ERL'):
            groups = list(ranking.build_groups(pairs,horizon,scope))
            add_context(groups,bars,times)
            results[f'{horizon}/{scope}'] = evaluate(groups)
    report = dict(inputs=manifest|{market_path.name:study.digest(market_path)},
                  code_sha256={path:study.digest(ROOT/path) for path in
                               ('scripts/replay_ict_liquidity_context.py','scripts/replay_ict_liquidity_rank.py',
                                'scripts/audit_ict_target_ranking.py','scripts/check_pool_priority.py')},
                  first_holdout=ranking.FIRST_HOLDOUT, checkpoints=TIMES,
                  design='Rolling New York weeks, same frozen candidates, all feature cutoffs use closed M5 data, '
                         'no future bar in features. Previously reviewed dates, not an untouched final validation.',
                  features=dict(trend='Directional net M5 move over 15m, 1h, 4h; continuous coverage flags.',
                                clock='NY checkpoint, distance interactions, remaining horizon.',
                                pattern='Prior 60m range versus latest 30m; closed breakout, reclaimed one '
                                        'or both ends, compression, or range. Direction relative to target.'),
                  results=results)
    path = study.RESEARCH/'ict_liquidity_context_walkforward.json'
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    for name,row in results.items():
        print(name,row['windows'])
        for model,c in row['comparisons'].items():
            print(model,c['top10_sweep'],c['top10_offers'])
        print('Combined vs nearest:',row['paired_combined']['nearest_far_edge'])


if __name__=='__main__':
    main()
