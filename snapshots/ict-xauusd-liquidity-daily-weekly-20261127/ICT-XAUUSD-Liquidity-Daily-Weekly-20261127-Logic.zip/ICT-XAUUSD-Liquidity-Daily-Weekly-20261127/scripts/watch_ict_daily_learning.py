"""Freeze and prospectively register daily-profile research scores without execution."""

from argparse import ArgumentParser
from collections import Counter
from contextlib import closing
from datetime import datetime, time as wall_time, timedelta, timezone
import json
from pathlib import Path
import sqlite3
import time

import numpy as np

from ict_ai.dol_history import batch_id
from ict_ai.timebase import NY, manifest_epoch_to_utc, previous_week
from brooks_ai.types import Bar
from scripts import audit_ict_daily_learning as learning
from scripts.audit_ipda_gap_ticks import raw_epoch, TERMINAL
from scripts.serve_ict_live import atomic_json, checked_account
from scripts.shadow_ict_dol import DATABASE, ROOT, write_once
from scripts.watch_ict_dol_settlement import M5, archive, frozen_feed, open_terminal, utc_now


FOLDER = learning.RESEARCH/'daily_learning_shadow_20261123'
MODEL = FOLDER/'model.json'
STATUS = FOLDER/'status.json'
WINDOW = 2*M5
UTC = timezone.utc
CODE = (Path(__file__),Path(learning.__file__),ROOT/'ict_ai/profile_lifecycle.py',ROOT/'ict_ai/timebase.py',
        ROOT/'scripts/audit_ict_target_ranking.py')


def freeze():
    if MODEL.exists():
        raise FileExistsError(MODEL)
    reference = learning.RESEARCH/'ict_daily_learning_20261123.json'
    report = json.loads(reference.read_bytes())
    if any(archive.digest(p)!=report['inputs'][p.name] for p in CODE[1:]):
        raise ValueError('Research model inputs differ from the validated study')
    if any(archive.digest(path)!=report['inputs'][path.name] for path in learning.MANUAL):
        raise ValueError('Manual study inputs changed')
    if any(archive.digest(learning.ARCH/name)!=report['inputs'][name] for name in ('XAUUSDM5.npz','clock_validation.json')):
        raise ValueError('The validated M5 archive or its clock witness changed')
    held_out = {row['date'] for path in learning.MANUAL for row in json.loads(path.read_bytes())['cases']
                if row['period']=='daily'}
    began = utc_now()
    bars,times = learning.read_market()
    training = [r for r in learning.pack(bars,times) if r['date'].isoformat() not in held_out
                and r['end']<began and r['keys'] and r['y'] is not None]
    counts = Counter(y for row in training for y in row['y'])
    if len(training)<35 or min(counts[0],counts[1])<8:
        raise ValueError('Insufficient mature daily labels')
    mean,scale,coef = learning.fit_prior_weeks(training)
    feed = frozen_feed()
    frozen = dict(frozen_at=utc_now().isoformat(), research_sha256=archive.digest(reference), features=learning.FEATURES,
                  label_ready_through=training[-1]['end'].isoformat(), training_dates=len(training),
                  training=[dict(keys=row['keys'],y=row['y']) for row in training],
                  model=[v.tolist() for v in (mean,scale,coef)],symbol='XAUUSD',server=feed['server'],clock=feed['clock'],
                  source_sha256=archive.digest(archive.QUOTES),
                  code={p.relative_to(ROOT).as_posix():archive.digest(p) for p in CODE},orders_sent=0)
    FOLDER.mkdir(parents=True,exist_ok=True)
    write_once(MODEL,frozen)
    print('Frozen model:',frozen['frozen_at'],'mature training days:',len(training))


def load_model():
    value = json.loads(MODEL.read_bytes())
    for path,checksum in value['code'].items():
        if archive.digest(ROOT/path)!=checksum:
            raise ValueError(f'Prospective model code changed: {path}')
    if value['source_sha256']!=archive.digest(archive.QUOTES) or value['features']!=learning.FEATURES:
        raise ValueError('Model quote basis or features changed')
    return value


def chart_receipt(at, now):
    with closing(sqlite3.connect(DATABASE.resolve().as_uri()+'?mode=ro',uri=True,timeout=2)) as db:
        records = db.execute('SELECT id,received,payload FROM chart_batches WHERE cutoff=? AND received IS NOT NULL '
                             'ORDER BY received,id',(at.isoformat(),)).fetchall()
    for ident,stamp,raw in records:
        received = datetime.fromisoformat(stamp)
        if not at<=received<=now<at+WINDOW:
            continue
        sample = json.loads(raw)
        if sample['at']!=at.isoformat() or ident!=batch_id(at,sample['price'],[sample['targets'],sample['pools']]):
            raise ValueError('The chart receipt failed its content check')
        return dict(batch=ident,received=stamp,closing_price=sample['price'])
    return None


def capture(api, alive, model, at):
    if not alive() or not api.initialize(str(TERMINAL),timeout=2500):
        raise RuntimeError('Could not access the already open MT5 terminal')
    try:
        account = checked_account(api)
        if account.server!=model['server']:
            raise RuntimeError('The terminal uses another quote server')
        clock = model['clock']
        q = api.symbol_info_tick('XAUUSD')
        if q is None or q.bid<=0 or q.time<=0:
            raise RuntimeError('XAUUSD has no current Bid')
        observed_quote = manifest_epoch_to_utc(datetime.fromtimestamp(int(q.time),UTC),clock)
        if not -3<=(utc_now()-observed_quote).total_seconds()<=90:
            raise RuntimeError('Current XAUUSD quote failed broker-clock freshness checks')
        day = at.astimezone(NY).date()
        first = learning.daily_profile_history_start(previous_week(day)[0])
        lo,hi = [datetime.fromtimestamp(raw_epoch(t,clock),UTC) for t in (first,at)]
        raw = api.copy_rates_range('XAUUSD',api.TIMEFRAME_M5,lo,hi)
        if raw is None or not len(raw) or not alive():
            raise RuntimeError('Missing M5 bars from the bound terminal')
        checked_account(api,(account.login,account.server))
        rows = []
        for item in raw:
            stamp = manifest_epoch_to_utc(datetime.fromtimestamp(int(item['time']),UTC),clock)
            if stamp+M5<=at:
                rows.append(Bar(stamp,*(float(item[k]) for k in ('open','high','low','close')),0))
        times = [row.time for row in rows]
        if not times or times[-1]+M5!=at or any(a>=b for a,b in zip(times,times[1:])):
            raise RuntimeError('Exact closed decision bar is unavailable')
        return rows, observed_quote
    finally:
        api.shutdown()


def score(model, bars, at):
    days = learning.pack(bars,[row.time for row in bars])
    selected = next((r for r in days if r['at']==at),None)
    if selected is None or not selected['prefix_covered']:
        return dict(status='insufficient_m5_coverage',candidates=[])
    if not selected['keys']:
        return dict(status='no_candidate',candidates=[])
    training = [dict(keys=[tuple(k) for k in r['keys']],y=r['y']) for r in model['training']]
    learned, prior = learning.forecast(selected,training,tuple(np.array(v) for v in model['model']))
    return dict(status='scores_recorded',candidates=[dict(profile=key[0],direction=key[1],features=x,
                learned_probability=p,signed_family_prior=b) for key,x,p,b in zip(selected['keys'],selected['x'],learned,prior,strict=True)])


def local_cutoff(day):
    return datetime.combine(day,wall_time(10),NY).astimezone(UTC)


def observe(now, model, api, alive):
    local = now.astimezone(NY)
    at = local_cutoff(local.date())
    state = dict(cutoff=at.isoformat(),status='waiting_for_cutoff',orders_sent=0)
    if local.weekday()>4:
        return {**state,'status':'weekend'}
    path = FOLDER/f'{local.date()}.json'
    if path.exists():
        return {**state,'status':'recorded','record':path.name}
    if at<=datetime.fromisoformat(model['frozen_at']):
        return {**state,'status':'cutoff_precedes_model'}
    if now>=at+WINDOW:
        return {**state,'status':'recording_window_elapsed'}
    if now<at:
        return state
    receipt = chart_receipt(at,now)
    if not receipt:
        return {**state,'status':'waiting_for_chart_receipt'}
    bars,tick = capture(api,alive,model,at)
    if tick<at:
        return {**state,'status':'waiting_for_post_cutoff_quote'}
    if abs(bars[-1].close-receipt['closing_price'])>1e-8:
        return {**state,'status':'receipt_price_mismatch'}
    scored = score(model,bars,at)
    if utc_now()>=at+WINDOW:
        return {**state,'status':'recording_window_elapsed'}
    evidence = FOLDER/f'{local.date()}-M5.json.gz'
    temp = evidence.with_suffix('.tmp')
    archive.write_zip(temp, [[b.time.isoformat(),b.open,b.high,b.low,b.close] for b in bars])
    temp.replace(evidence)
    registered = utc_now()
    if registered>=at+WINDOW:
        return {**state,'status':'recording_window_elapsed'}
    write_once(path,dict(**scored,cutoff=at.isoformat(),recorded_at=registered.isoformat(),
                forecast_end=learning._day_bounds(local.date())[1].isoformat(),model_sha256=archive.digest(MODEL),
                m5_sha256=archive.digest(evidence),chart=receipt,fresh_quote_utc=tick.isoformat(),orders_sent=0))
    return {**state,'status':'recorded','record':path.name}


def verify(model):
    total = 0
    for path in sorted(FOLDER.glob('????-??-??.json')):
        record = json.loads(path.read_bytes())
        at,registered,tick = (datetime.fromisoformat(record[k]) for k in ('cutoff','recorded_at','fresh_quote_utc'))
        day = at.astimezone(NY).date()
        prices = FOLDER/f'{day}-M5.json.gz'
        if (record['model_sha256']!=archive.digest(MODEL) or path.stem!=str(day)
                or record['m5_sha256']!=archive.digest(prices) or local_cutoff(day)!=at or day.weekday()>4
                or record['forecast_end']!=learning._day_bounds(day)[1].isoformat()
                or not datetime.fromisoformat(model['frozen_at'])<at<=tick<=registered+timedelta(seconds=3)
                or not at<=registered<at+WINDOW or chart_receipt(at,registered)!=record['chart']):
            raise ValueError(f'Invalid or altered registration: {path.name}')
        bars = [Bar(datetime.fromisoformat(t),o,h,l,c,0) for t,o,h,l,c in archive.read_zip(prices)]
        if not bars or bars[-1].time+M5!=at or abs(bars[-1].close-record['chart']['closing_price'])>1e-8:
            raise ValueError(f'Chart cutoff price does not match: {path.name}')
        expected = score(model,bars,at)
        if {key:record[key] for key in expected}!=expected:
            raise ValueError(f'Prospective scores do not replay: {path.name}')
        total += 1
    return total


def main():
    parser = ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--freeze',action='store_true')
    mode.add_argument('--verify',action='store_true',help='Recompute records against saved M5 and original chart receipts')
    mode.add_argument('--terminal-pid',type=int)
    args = parser.parse_args()
    if args.freeze:
        freeze()
        return
    model = load_model()
    if args.verify:
        print('Verified prospective daily registrations:',verify(model))
        return
    import msvcrt
    import MetaTrader5 as mt5
    with open_terminal(args.terminal_pid) as alive, (FOLDER/'watch.lock').open('a+b') as lock:
        lock.seek(0)
        msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        previous = None
        while alive():
            now = utc_now()
            try:
                state = observe(now,model,mt5,alive)
            except (RuntimeError,OSError,sqlite3.OperationalError) as exc:
                state = dict(status='temporarily_unavailable',reason=str(exc),orders_sent=0)
            if state!=previous:
                atomic_json(STATUS,dict(**state,checked_at=now.isoformat(),terminal_pid=args.terminal_pid))
                print(now.isoformat(),state,flush=True)
                previous = state
            time.sleep(10)


if __name__=='__main__':
    main()
