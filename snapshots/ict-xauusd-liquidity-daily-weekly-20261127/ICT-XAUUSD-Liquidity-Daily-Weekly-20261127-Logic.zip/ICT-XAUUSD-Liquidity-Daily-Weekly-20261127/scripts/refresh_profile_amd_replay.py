"""Rebuild AMD overlays on an existing standalone review's archived M5 candles."""

from argparse import ArgumentParser
from collections import Counter
from datetime import date, timedelta
from hashlib import sha256
import json
from pathlib import Path

from brooks_ai.types import Bar
from ict_ai import amd
from ict_ai.profile_lifecycle import _day_bounds
from scripts.prepare_ict_week import aggregate_bars
from scripts.profile_day_replay import amd_replay_events
from scripts.review_profile_one_history import write_week_table


def refresh(report):
    counts = Counter()
    days = 0
    for week in report['weeks']:
        for day in week['days']:
            start,end = _day_bounds(date.fromisoformat(day['date']))
            replay = day['replay']
            if replay['end'] != (end-start)//timedelta(minutes=1):
                raise ValueError(f"Archived review clock differs for {day['date']}")
            bars = [Bar(start+timedelta(minutes=t-5),o,h,l,c,0) for t,o,h,l,c in replay['bars']]
            quarter = timedelta(minutes=15)
            core = [bar for bar in aggregate_bars(bars,5,15,end) if start<=bar.time]
            events = amd_replay_events(core,quarter,start,end)
            counts.update(row[1].split(' · ')[1] for row in events if len(row)==6 and row[5]=='X')
            events.extend(row for row in replay['events'] if row[2] is None)
            replay['events'] = sorted(events,key=lambda row:row[0])
            days += 1
    return days, dict(counts)


def main():
    parser = ArgumentParser(description=__doc__)
    for argument in ('source','out','html'):
        parser.add_argument('--'+argument,type=Path,required=True)
    args = parser.parse_args()
    if len({path.resolve() for path in (args.source,args.out,args.html)})!=3:
        parser.error('Supply distinct source, report and chart paths')
    raw = args.source.read_bytes()
    report = json.loads(raw)
    days,counts = refresh(report)
    report['amd_replay_refresh'] = dict(source=str(args.source),source_sha256=sha256(raw).hexdigest(),
                                       detector_sha256=sha256(Path(amd.__file__).read_bytes()).hexdigest(),
                                       days=days,retirement_counts=counts)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    write_week_table(report,args.html)
    print(f'AMD replay: {days} dates, {sum(counts.values())} retirements')


if __name__ == '__main__':
    main()
