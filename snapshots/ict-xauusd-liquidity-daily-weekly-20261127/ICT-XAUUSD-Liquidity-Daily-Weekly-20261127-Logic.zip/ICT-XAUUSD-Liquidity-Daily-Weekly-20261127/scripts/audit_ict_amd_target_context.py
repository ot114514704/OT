"""Test whether targets frozen with A improve the existing AMD retest replay."""

from argparse import ArgumentParser
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from dataclasses import replace
from datetime import datetime, time, timedelta
import json
from pathlib import Path
from statistics import mean

import numpy as np

from ict_ai.portfolio import replay_portfolio
from ict_ai.range_liquidity import _Coverage, _m5_reference_day
from ict_ai.timebase import NY, previous_week
from scripts import backtest_ict_native_amd as baseline
from scripts.replay_ict_tmgm_context_execution import target_order
from scripts.serve_ict_live import atomic_json


OUT = baseline.OUT.with_name('ict_native_amd_target_context_20261123.json')
M5 = baseline.M5
ROUTES = ('AMD','AD_no_M')


class TargetHistory:
    def __init__(self,bars,cutoff=None):
        self.bars = bars
        self.times = [b.time for b in bars]
        self.coverage = _Coverage(bars[0].time,cutoff or bars[-1].time+M5,bars,M5)
        self.days = {}

    def between(self,start,end):
        return self.bars[bisect_left(self.times,start):bisect_right(self.times,end-M5)]

    def daily(self,day):
        if day not in self.days:
            midnight = datetime.combine(day,time.min,NY)
            snapshot = _m5_reference_day(self.between(midnight,midnight+timedelta(days=1)),day,midnight+timedelta(days=1))
            bars = snapshot.pop('bars')
            if snapshot['status']=='complete':
                snapshot.update(low=min(b.low for b in bars),high=max(b.high for b in bars))
            self.days[day] = snapshot
        return self.days[day]

    def first_touch(self,level,side,start,end):
        return next(((b.time+M5).isoformat() for b in self.between(start,end)
                     if (side>0 and b.high>=level) or (side<0 and b.low<=level)),None)

    def freeze(self,low,high,at):
        day = at.astimezone(NY).date()
        prior = day-timedelta(days=1)
        while prior.weekday()>4:
            prior-=timedelta(days=1)
        days = [self.daily(d) for d in previous_week(day)]
        sources = [('previous_day',[self.daily(prior)]),('previous_week',days)]
        result = {}
        for side,edge in ((-1,low),(1,high)):
            candidates = []
            for name,reference in sources:
                end = reference[-1]['end']
                row = dict(source=name,reference_dates=[d['date'] for d in reference],available_at=end.isoformat())
                if end>at:
                    row['status']='not_completed'
                elif any(d['status']!='complete' for d in reference):
                    row.update(status='reference_incomplete',missing_bars=sum(d['missing_bars'] for d in reference))
                else:
                    level = max(d['high'] for d in reference) if side>0 else min(d['low'] for d in reference)
                    row['price']=level
                    if side*(level-edge)<=0:
                        row['status']='inside_or_behind_a_edge'
                    else:
                        touched = self.first_touch(level,side,end,at)
                        row.update(status='taken_before_a' if touched else 'pre_a_coverage_unknown' if self.coverage.gap(end,at)
                                   else 'untouched_at_a',first_touch_known_at=touched)
                candidates.append(row)
            valid = [r for r in candidates if r['status']=='untouched_at_a']
            selected = min(valid,key=lambda r:abs(r['price']-edge)) if valid else None
            result[str(side)] = dict(candidates=candidates,selected=selected)
        return result

    def assess(self,signal):
        a = datetime.fromisoformat(signal['a_known'])
        d = datetime.fromisoformat(signal['d_confirm'])
        side = signal['direction']
        if not a<d:
            raise ValueError('The frozen A must precede D')
        frozen = self.freeze(signal['a_low'],signal['a_high'],a)
        selected = frozen[str(side)]['selected']
        result = dict(a_known=a.isoformat(),d_confirm=d.isoformat(),direction=side,frozen=frozen,
                      state_at_d='no_eligible_target_at_a',touch_known_at=None)
        if selected is None:
            return result
        touched = self.first_touch(selected['price'],side,a,d)
        return {**result,'state_at_d':'touched_before_entry' if touched else 'a_to_d_coverage_unknown' if self.coverage.gap(a,d)
                else 'target_open_at_d','touch_known_at':touched}


def interval(records,signals):
    """Resample whole NY weeks to avoid assuming adjacent trades are independent."""
    weeks = defaultdict(list)
    for record in records:
        if record['status']!='closed':
            continue
        day = datetime.fromisoformat(signals[record['order_id']]['d_confirm']).astimezone(NY).date()
        weeks[day-timedelta(days=day.weekday())].append(record['net_r'])
    if len(weeks)<2:
        return dict(weeks=len(weeks),mean_r_interval95=None)
    sums = np.array([sum(week) for week in weeks.values()])
    counts = np.array([len(week) for week in weeks.values()])
    draw = np.random.default_rng(23).integers(len(weeks),size=(4000,len(weeks)))
    return dict(weeks=len(weeks),mean_r_interval95=np.quantile(sums[draw].sum(1)/counts[draw].sum(1),[.025,.975]).tolist())


def grouped_summary(rows,signals):
    by_month = defaultdict(list)
    for row in rows:
        day = datetime.fromisoformat(signals[row['order_id']]['d_confirm']).astimezone(NY)
        by_month[day.strftime('%Y-%m')].append(row)
    return dict(**baseline.settled_summary(rows),**interval(rows,signals),
                months={key:baseline.settled_summary(group) for key,group in sorted(by_month.items())})


def paired_exit_comparison(original,replacements,signals):
    delta = []
    for trial in replacements:
        initial = original[trial['order_id']]
        if trial.get('entry_known_at')!=initial.get('entry_known_at') or trial.get('entry')!=initial.get('entry'):
            raise AssertionError('An exit-only change altered the fill')
        if trial['status']==initial['status']=='closed':
            delta.append(dict(order_id=trial['order_id'],status='closed',net_r=trial['net_r']-initial['net_r']))
    return dict(compared_closed=len(delta),mean_delta_r=mean(row['net_r'] for row in delta) if delta else None,
                improved=sum(row['net_r']>1e-10 for row in delta),worse=sum(row['net_r'] < -1e-10 for row in delta),
                **interval(delta,signals))


def run():
    source = json.loads(baseline.OUT.read_bytes())
    root = baseline.ROOT
    sha = baseline.feed.archive.digest
    if any(sha(root/path)!=checksum for path,checksum in source['inputs'].items()):
        raise ValueError('The frozen AMD replay inputs changed')
    first,last = (datetime.fromisoformat(source[k]).astimezone(NY).date() for k in ('quote_start','quote_end'))
    bars,instrument,server = baseline.read_market(first-timedelta(days=18),last)
    if server!=source['server']:
        raise ValueError('Different TMGM quote server')
    history = TargetHistory(bars)
    cutoff = datetime.fromisoformat(source['quote_end'])
    signals = {s['id']:s for s in source['confirmed'] if s['timeframe']=='M15'}
    orders = [o for s in signals.values() if (o:=baseline.order_for(s,instrument)) is not None]
    contexts = {}
    prefix_checks = 0
    for order in orders:
        signal = signals[order.id]
        target = history.assess(signal)
        a = datetime.fromisoformat(signal['a_known'])
        pre_a = TargetHistory(bars[:bisect_right(history.times,a-M5)],a)
        if pre_a.freeze(signal['a_low'],signal['a_high'],a)!=target['frozen']:
            raise AssertionError(f'Future M5 changed the frozen target: {order.id}')
        prefix_checks+=1
        contexts[order.id]=target

    config = json.loads((root/'config/strategy.json').read_bytes())
    risk = source['risk_limits']
    priced = {}
    for fee in ('base','stress'):
        commission,slippage,spread = baseline.FEES[fee]
        spec = replace(instrument,commission_round_turn=commission,slippage=slippage)
        original = {o['order_id']:o for o in source['scenarios'][fee]['independent_orders']}
        priced[fee] = {}
        for route in ROUTES:
            base = [o for o in orders if signals[o.id]['route']==route]
            open_target = [o for o in base if contexts[o.id]['state_at_d']=='target_open_at_d']
            replacements = []
            target_decisions = {}
            for order in open_target:
                selected = contexts[order.id]['frozen'][str(order.side)]['selected']
                view = {'morning_route':{'selected_route':{'target_reference_price':selected['price']}}}
                replacement,decision = target_order(order,view,spec,config['min_reward_risk'])
                if replacement is not None:
                    replacements.append(replacement)
                target_decisions[order.id]=decision
            fixed_rows = [original[o.id] for o in open_target]
            replacement_rows,checks = baseline.independent(replacements,bars,spec,config['initial_equity'],risk['risk_fraction'],spread)
            account = replay_portfolio(open_target,bars,spec,cutoff,config['initial_equity'],risk,spread_multiplier=spread)
            exit_account = replay_portfolio(replacements,bars,spec,cutoff,config['initial_equity'],risk,spread_multiplier=spread)
            priced[fee][route] = dict(all_2r=grouped_summary([original[o.id] for o in base],signals),
                                    open_target_2r=grouped_summary(fixed_rows,signals),
                                    same_candidates_2r=grouped_summary([original[o.id] for o in replacements],signals),
                                    open_target_exit=grouped_summary(replacement_rows,signals),
                                    paired_exit_delta=paired_exit_comparison(original,replacement_rows,signals),
                                    open_target_count=len(open_target),priced_target_count=len(replacements),
                                    state_counts=dict(Counter(contexts[o.id]['state_at_d'] for o in base)),
                                    gate_decisions=target_decisions,target_exit_orders=replacement_rows,fill_prefix_checks=checks,
                                    continuous_2r=account,continuous_frozen_target=exit_account)

    definitions = (Path(__file__),root/'ict_ai/range_liquidity.py',root/'scripts/replay_ict_tmgm_context_execution.py',
                   root/'research/ict_price_videos/amd/integration.json',root/'research/ict_price_videos/bias_dol/integration.json')
    return dict(prices_through=cutoff.isoformat(),broker_server=server,signal_count=len(orders),prefix_checks=prefix_checks,
                contexts=contexts,results=priced,baseline_sha256=sha(baseline.OUT),
                definition_sha256={p.relative_to(root).as_posix():sha(p) for p in definitions},orders_sent=0,
                policy='At A close freeze a candidate separately for each direction using prior study-day/week extremes. Ignore already touched or unsupported levels. At D require the original target still open, without rolling it.',
                limitations=['Retrospective on the same sample, with 18 days of quote warmup for prior levels.',
                             'The day and week edges are DOL price proxies. No independently qualified HTF bias, news or brokerage fee terms.',
                             'Weekly ranges require complete weekday study slots. Missing quote intervals remain unknown. Assumed fees and quote touches use the original model.'])


if __name__=='__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=OUT)
    args = parser.parse_args()
    report = run()
    atomic_json(args.out,json.loads(json.dumps(report,default=lambda x:x.isoformat(),allow_nan=False)))
    for fee,groups in report['results'].items():
        for route,values in groups.items():
            print(fee,route,values['state_counts'],values['priced_target_count'],
                  [(k,values[k]['closed'],values[k]['mean_r'],values[k]['mean_r_interval95'])
                   for k in ('all_2r','open_target_2r','same_candidates_2r','open_target_exit')],flush=True)
