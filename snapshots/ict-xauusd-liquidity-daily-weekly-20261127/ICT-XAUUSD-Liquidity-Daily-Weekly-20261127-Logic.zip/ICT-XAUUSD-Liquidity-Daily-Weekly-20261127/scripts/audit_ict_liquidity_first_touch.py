"""Compare frozen liquidity ranks with nearest edges on first touch and first sweep."""

from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import json
from pathlib import Path

from ict_ai.dol_history import _deadline
from ict_ai.range_liquidity import M5, _Coverage
from ict_ai.timebase import NY
from scripts.check_pool_priority import read_market
from scripts.replay_ict_liquidity_rank import ARCHIVE
from scripts.replay_pool_and_dol import RESEARCH, contacts, digest, read_zip
from scripts.serve_ict_live import atomic_json


START = datetime(2026, 10, 1, tzinfo=NY)
DEPTHS = (1, 2, 10, 20)
UPSTREAM = '4a85ed219ddb362f890161693f449328f225ded0'
OUT = RESEARCH / 'ict_liquidity_first_touch_20261125.json'


def nearest_order(pools, price, label):
    def distance(index):
        pool = pools[index]
        upper = pool['side'] > 0
        if label == 'sweep':
            edge = pool['hi'] if upper else pool['lo']
        else:
            edge = pool['lo'] if upper else pool['hi']
        return abs(edge - price)

    return sorted(range(len(pools)), key=distance)


def score(stats, pools, observed, price, label):
    stats['complete_checkpoints'] += 1
    if not pools:
        stats['empty_board'] += 1
        return
    events = {index: result[label] for index, result in enumerate(observed) if result[label]}
    if not events:
        stats['no_event'] += 1
        return
    first = min(events.values())
    winners = {index for index, at in events.items() if at == first}
    stats['checkpoints_with_event'] += 1
    stats['same_bar_ties'] += len(winners) > 1
    nearest = nearest_order(pools, price, label)
    for depth in DEPTHS:
        current_hit = any(index < depth for index in winners)
        nearest_hit = bool(winners.intersection(nearest[:depth]))
        stats[f'current_top{depth}'] += current_hit
        stats[f'nearest_top{depth}'] += nearest_hit
        stats[f'current_only_top{depth}'] += current_hit and not nearest_hit
        stats[f'nearest_only_top{depth}'] += nearest_hit and not current_hit


def main():
    archive = ARCHIVE / 'round19_liquidity_50_candidates.json.gz'
    lock = json.loads((ARCHIVE / 'round19_liquidity_50_lock.json').read_bytes())
    quote_path = 'output/research/dol_expansion_20261122/XAUUSDM5.npz'
    quote_file = RESEARCH.parents[1] / quote_path
    inputs = {archive.name: digest(archive), quote_file.name: digest(quote_file)}
    if inputs[archive.name] != lock['candidates'] or inputs[quote_file.name] != lock['sources'][quote_path]:
        raise ValueError('Frozen candidates or M5 quotes have changed')
    bars, times = read_market()
    coverage = _Coverage(times[0], times[-1] + M5, bars, M5)
    results = defaultdict(Counter)
    weeks = defaultdict(lambda: defaultdict(Counter))
    snapshots = [row for row in read_zip(archive) if datetime.fromisoformat(row['at']) >= START]
    for snapshot in snapshots:
        at = datetime.fromisoformat(snapshot['at'])
        begin = bisect_left(times, at)
        if not begin or bars[begin - 1].time + M5 != at or bars[begin - 1].close != snapshot['price']:
            raise ValueError(f'Frozen quote mismatch at {at}')
        local_day = at.astimezone(NY).date()
        week = str(local_day - timedelta(days=local_day.weekday()))
        for period, end in (('15m', at + 3 * M5), ('4h_or_day_end', _deadline(at))):
            complete = end <= coverage.cutoff and not coverage.gap(at, end)
            window = bars[begin:bisect_left(times, end)] if complete else []
            for scope, pools in snapshot['pools'].items():
                observed = [contacts(pool, window, True) for pool in pools]
                for label in ('touch', 'sweep'):
                    key = f'{period}/{scope}/{label}'
                    if complete:
                        score(results[key], pools, observed, snapshot['price'], label)
                        score(weeks[week][key], pools, observed, snapshot['price'], label)
                    else:
                        results[key]['incomplete_checkpoints'] += 1
                        weeks[week][key]['incomplete_checkpoints'] += 1

    atomic_json(OUT, dict(
        upstream=UPSTREAM, inputs=inputs | {Path(__file__).name: digest(Path(__file__))},
        checkpoint_count=len(snapshots), first=snapshots[0]['at'], last=snapshots[-1]['at'],
        universe='Existing frozen IRL and ERL boards, up to 50 candidates each. Existing NYC cutoffs, no upstream 15 ATR or untouched filter.',
        windows='15 minutes and up to 4 hours, truncated at the local research day deadline.',
        touch='First recorded contact with the price band. Multiple first events in one M5 bar are co-winners.',
        sweep='First witnessed strict crossing of a far edge, not any subsequent reclaim or reversal judgment.',
        nearest='Contact ranks by nearest band edge, strict crossing by nearest far edge. Equal distances keep the original order.',
        denominator='Top-K uses complete checkpoints with at least one event. Empty and no-event checkpoints are recorded separately.',
        results=results, ny_weeks=weeks))
    for key, stats in results.items():
        print(key, dict(stats))


if __name__ == '__main__':
    main()
