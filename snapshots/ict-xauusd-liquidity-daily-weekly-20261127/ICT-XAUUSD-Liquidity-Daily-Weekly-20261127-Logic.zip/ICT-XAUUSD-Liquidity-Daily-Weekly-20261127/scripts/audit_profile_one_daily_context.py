"""Offline noon classification audit, with weekly direction and a pre-NY D1/W1 target."""
from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
import csv
from datetime import date, timedelta
from html import escape
import json
from pathlib import Path

from brooks_ai.types import Bar, utc_time
from ict_ai.planning import target_path
from ict_ai.profile_lifecycle import daily_profile_lifecycle, _day_bounds
from ict_ai.timebase import manifest_epoch_to_utc, NY
from scripts.export_mt5_profiles import midnight
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_ipda_profiles import active_profiles, panel_week_at
from scripts.replay_ict_news import ROOT, STEP
from scripts.replay_ict_route_checkpoints import analyze_prior
from scripts.replay_profile_one_histdata import digest, read_month
from scripts.review_profile_one_history import load_closed_history


POLICIES = ("daily", "week_permissive", "week_aligned", "open_target", "week_and_target")


def load_tmgm():
    archive = ROOT/"output/research/ict_profile_one_complete_20261121.json"
    summary = json.loads(archive.read_bytes())
    early, late = [ROOT/s["manifest"] for s in summary["sources"]]
    friday = ROOT/summary["friday_replay"]
    if digest(friday) != summary["friday_replay_sha256"]:
        raise ValueError("Changed Friday extension")
    recent, sources, *_ = load_closed_history(early,late,friday)
    manifest = ROOT/"data/real/TMGM_ICT_D1_basis_20261014_132250/provenance.json"
    meta = json.loads(manifest.read_bytes())
    dataset = next(d for d in meta["datasets"] if d["timeframe"]=="M5")
    path = manifest.parent/Path(dataset["data_path"]).name
    if (meta["symbol"]!="XAUUSD" or meta["status"]!="collected" or meta["synthetic"] is not False
            or meta["server"]!=json.loads(early.read_bytes())["server"] or digest(path)!=dataset["data_sha256"]):
        raise ValueError("Invalid older XAUUSD source")
    older = {}
    cutoff = utc_time(meta["finished_at_utc"])
    with path.open(encoding="utf-8-sig",newline="") as stream:
        for r in csv.DictReader(stream):
            at = manifest_epoch_to_utc(utc_time(r["time"]),meta)
            if at+STEP<=cutoff:
                if at in older:
                    raise ValueError("Duplicate archive bar")
                older[at] = Bar(at,*(float(r[k]) for k in ("open","high","low","close","spread")))
    recent = {b.time:b for b in recent}
    first, last = min(recent), max(older)
    overlap = {t:b for t,b in recent.items() if t<=last}
    if not overlap or overlap!={t:b for t,b in older.items() if t>=first}:
        raise ValueError("Overlapping timestamps or quotes differ")
    result = older | recent
    return [result[t] for t in sorted(result)], {"manifest":str(manifest), "manifest_sha256":digest(manifest),
        "m5_sha256":digest(path),"overlap_equal":len(overlap),"clock_offset_hours_early":meta["source_clock_offset_hours"],
        "recent":sources,"friday_sha256":digest(friday)}


def signed(cards):
    return sorted((c["id"],c["direction"]) for c in cards)


def study_day(task):
    feed, day, bars = task
    start, end = _day_bounds(day)
    noon, morning = start+timedelta(hours=12), start+timedelta(hours=7)
    quarters = aggregate_bars(bars,5,15,end)
    week_start = midnight(day-timedelta(days=day.weekday()+1))
    m5 = [b for b in bars if b.time>=week_start]
    m15 = [b for b in quarters if b.time>=week_start]
    def view(at):
        return daily_profile_lifecycle([b for b in m15 if b.time+3*STEP<=at],day,at,
                    reference_m5=[b for b in m5 if b.time+STEP<=at],include_reconstruction=False)
    forecast, final = view(noon), view(end)
    candidates, truth = signed(active_profiles(forecast)), signed(final["actual_paths"])
    row = {"date":str(day),"feed":feed,"coverage":final["coverage_complete_under_study_calendar"],
           "noon_coverage":forecast.get("coverage_complete_under_study_calendar",False),"forecast":candidates,"close":truth,
           "label":final["profile_label"],"close_reason":final["profile_reason"],"noon_reason":forecast["profile_reason"]}
    week = panel_week_at(m5,m15,noon)
    week_sides = {c["direction"] for c in week["active"] if c["direction"] in (-1,1)}
    route = {"status":"no_directional_daily_candidate"}
    target_side = None
    if any(s in (-1,1) for _,s in candidates):
        frozen, coverage = analyze_prior([b for b in bars if b.time+STEP<=morning],morning)
        selected = frozen["selected_route"]
        route = {"status":frozen["status"],"coverage":coverage}
        if selected:
            side = frozen["direction"]
            price = selected["target_reference_price"]
            path = target_path(bars,morning,noon,STEP,side,price)
            route.update(price=price,side=side,timeframe=selected["timeframe"],route=selected["route"],path=path)
            current, _ = analyze_prior([b for b in bars if b.time+STEP<=noon],noon)
            if path["status"]=="untouched" and (current["selected_route"] or {}).get("id")==selected["id"]:
                target_side = side
                route["status"] = "retained"
            else:
                route["status"] = "touched_or_changed_or_unknown"
    kept = {p:[] for p in POLICIES}
    for key in candidates:
        _,side = key
        # Directional confirmation has no meaning for a directionless profile.
        directional = side in (-1,1)
        matching = week["covered"] and week_sides=={side}
        for policy, condition in zip(POLICIES,(True,week["covered"] and -int(side or 0) not in week_sides,
                                             matching,target_side==side,matching and target_side==side)):
            if not directional or condition:
                kept[policy].append(key)
    return {**row,"week":week,"morning_route":route,"kept":kept}


def summarize(rows):
    out = {}
    for policy in POLICIES:
        overall, by_profile = Counter(), defaultdict(Counter)
        for row in rows:
            if not row["coverage"] or not row["noon_coverage"]:
                overall["excluded"]+=1
                continue
            p, y = set(row["kept"][policy]),set(row["close"])
            overall.update({"days":1,"days_with_candidate":int(bool(p)), "days_with_close_path":int(bool(y)),
                            "no_candidate_no_close":int(not p and not y)})
            for k, keys in (("tp",p&y),("fp",p-y),("fn",y-p)):
                overall[k]+=len(keys)
                for ident,_ in keys:
                    by_profile[ident][k]+=1
        out[policy] = {"totals":dict(overall),"by_profile":dict(by_profile)}
    return out


def frozen_chart_audit(rows):
    by_date = {r["date"]:r for r in rows}
    compared = []
    sources = {}
    for group, link, review in (
            ("review","ict_profile_price_review_comparison_20261121","ict_profile_price_review_20261121"),
            ("validation","ict_profile_validation_baseline_20261121","ict_profile_price_validation_20261121")):
        mapping = ROOT/"output/research"/(link+".json")
        path = ROOT/"research"/(review+".json")
        saved = json.loads(mapping.read_bytes())
        manual = json.loads(path.read_bytes())
        if digest(path)!=saved["frozen_review_sha256"] or manual["chart_sha256"]!=saved["chart_sha256"]:
            raise ValueError("Chart or pre-existing review changed")
        labels = {c["id"]:c for c in manual["cases"]}
        sources[group] = {"review_sha256":digest(path),"date_mapping_sha256":digest(mapping)}
        for case in saved["cases"]:
            if case["period"]!="daily":
                continue
            chart = labels[case["id"]]
            typed = [(id,{"bullish":1,"bearish":-1,None:None}[side]) for id,side in chart["labels"]]
            row = by_date[case["date"]]
            compared.append({**row,"rule_close":row["close"],"close":typed,"review_evidence":chart["evidence"]})
    if len({r["date"] for r in compared})!=len(compared):
        raise ValueError("Duplicate reviewed date")
    return {"sources":sources,"summary":summarize(compared),"cases":[{"date":r["date"],"review":r["close"],
            "rule_close":r["rule_close"],"forecast":r["forecast"],"review_evidence":r["review_evidence"]}
            for r in compared]}


def run(workers):
    archive = ROOT/"output/research/ict_profile_one_histdata_202501_02.json"
    old = json.loads(archive.read_bytes())
    hist = [read_month(Path(old["source_directory"]),s["month"]) for s in old["sources"]]
    if [s for _,s in hist]!=old["sources"]:
        raise ValueError("HistData archive changed")
    tmgm, source = load_tmgm()
    tasks = []
    for feed,bars in (("HistData 2025",[b for group,_ in hist for b in group]),("TMGM",tmgm)):
        stamps = [b.time for b in bars]
        day = stamps[0].astimezone(NY).date()
        while day<=stamps[-1].astimezone(NY).date():
            if day.weekday()<5:
                first = bisect_left(stamps,midnight(day-timedelta(days=42)))
                last = bisect_left(stamps,_day_bounds(day)[1])
                tasks.append((feed,day,bars[first:last]))
            day+=timedelta(days=1)
    with ProcessPoolExecutor(max_workers=workers) as pool:
        rows = list(pool.map(study_day,tasks))
    for r in rows:
        if r["feed"]=="TMGM":
            r["feed"]="TMGM 新增" if r["date"]<"2026-09-01" else "TMGM 原样本"
    groups = {key:summarize([r for r in rows if r["feed"]==key]) for key in dict.fromkeys(r["feed"] for r in rows)}
    return {"sources":{"HistData":old["sources"],"TMGM":source},"study":"Noon NY M15 signed active profile vs same-rule close. All weekdays. 42 prior calendar days for D1/W1, limited by feed inception. Morning route fixed at 07 NY, retained only if untouched and still selected at noon. Neutral daily types pass through. Independently reconstructed feeds. Descriptive label comparison; no orders.",
            "overall":summarize(rows),"per_sample":groups,"frozen_chart_review":frozen_chart_audit(rows),"days":rows}


def write_table(report,path):
    labels = {"classic_buy":"经典买入","classic_sell_mirror":"经典卖出","classic_reversal_variant":"经典反转 1.1",
              "double_sweep":"双重扫荡","consolidation_expansion":"盘整扩张","seek_destroy":"心电图",
              "news_manipulation_expansion":"新闻前盘整、操纵后扩张","manipulation_expansion_consolidation":"操纵扩张后盘整"}
    policies = dict(zip(POLICIES,("仅日概况","周概况未反向且覆盖完整","周概况明确同向","07:00 目标同向且到中午仍有效","周概况与目标同时支持")))
    def types(pairs):
        return "、".join(labels.get(key,key)+{1:"↑",-1:"↓",None:""}[side] for key,side in pairs) or "—"
    def totals(results):
        lines=[]
        for key,stats in results.items():
            t=stats["totals"]
            lines.append(f'<tr><td>{policies[key]}</td><td>{t["days"]}</td><td>{t["days_with_candidate"]}</td>'
                         f'<td>{t["tp"]}</td><td>{t["fp"]}</td><td>{t["fn"]}</td></tr>')
        return '<table><tr><th>筛选条件</th><th>可评分日</th><th>有候选日</th><th>匹配</th><th>多报</th><th>漏报</th></tr>'+''.join(lines)+'</table>'
    sections=['<h2>全部日期</h2>'+totals(report["overall"])]
    for feed,stats in report["per_sample"].items():
        sections.append('<details><summary>'+escape(feed)+'</summary>'+totals(stats)+'</details>')
    sections.append('<h2>对照此前已保存的读图标签</h2>'+totals(report["frozen_chart_review"]["summary"]))
    manual={c["date"]:c for c in report["frozen_chart_review"]["cases"]}
    for row in report["days"]:
        if not row["coverage"] or not row["noon_coverage"]:
            continue
        base, end, both = (set(map(tuple,p)) for p in (row["forecast"],row["close"],row["kept"]["week_and_target"]))
        if base==end==both:
            continue
        evidence = manual.get(row["date"])
        explanation = (f'<p>存档读图 · {types(evidence["review"])}。{escape(evidence["review_evidence"])}</p>' if evidence else "")
        price = row["morning_route"].get("price")
        target = row["morning_route"]["status"]
        target_text = {"no_directional_daily_candidate":"中午无方向性候选，未评估","no_eligible_route":"未找到合格路径",
                       "conflicting_routes":"方向冲突","retained":"早盘目标仍有效","missing_price_at_cutoff":"检查时刻缺报价",
                       "touched_or_changed_or_unknown":"目标已触及、路线变化或报价不足"}.get(target,target)
        sections.append(f'<details><summary>{row["date"]} · {row["feed"]} · 中午 {types(sorted(base))} ｜ 收盘 {types(sorted(end))}</summary>'
                        f'<p>{escape(row["noon_reason"])}</p><p>周概况 · {escape(row["week"]["reason"])}</p>'
                        f'<p>高周期目标 · {target_text}'+(f'，参考价 {price:.2f}' if price is not None else '')+f'。双条件后保留 {types(sorted(both))}。</p>'
                        f'<p>收盘 · {escape(row["close_reason"])}</p>{explanation}</details>')
    path.write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                    '<title>概况一 · 每日识别错漏复核</title><style>body{max-width:960px;margin:3vw auto;padding:1em;font:16px/1.6 system-ui;color:#173640}table{border-collapse:collapse;width:100%}td,th{text-align:left;border-bottom:1px solid #ddd;padding:.4em}summary{cursor:pointer;padding:.45em 0}details{border-bottom:1px solid #ccd7da}</style>'
                    '<h1>概况一 · 每日识别错漏复核</h1><p>在纽约 12:00 冻结候选，按形态和方向逐项与收盘规则对照。一日可有多个候选。'
                    '日、周和高周期路线均只用当时已收盘报价。高周期使用最多 42 个此前自然日，方向中性的日型保留。下方日期可展开查看错漏及筛选依据。</p>'
                    +''.join(sections)+'</html>',encoding="utf-8")


if __name__=="__main__":
    cli=ArgumentParser(description=__doc__)
    cli.add_argument("out",type=Path)
    cli.add_argument("--workers",type=int,default=4)
    cli.add_argument("--html",type=Path)
    args=cli.parse_args()
    report=run(args.workers)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    if args.html:
        write_table(report,args.html)
    print(json.dumps({k:v["totals"] for k,v in report["overall"].items()}))
