"""Attach temporally gated H1 liquidity research to the archived daily chart replay."""

from collections import Counter
from datetime import date, datetime, timedelta
from hashlib import sha256
from math import ceil
from pathlib import Path
import json

from ict_ai.liquidity_repo_overlay import outside
from ict_ai.profile_lifecycle import _day_bounds
from ict_ai.timebase import NY
from scripts import audit_ict_liquidity_repo_overlay as overlay
from scripts.review_profile_one_history import write_week_table


shared = overlay.shared
RESEARCH = shared.joint.RESEARCH
BASE = RESEARCH / 'ict_profile_one_amd_retirements_20261123.json'
EARLY = overlay.OUT.with_name('repo_overlay_holdout.json')
OUT = RESEARCH / 'ict_profile_liquidity_replay_20261126.json'
CHART = shared.joint.ROOT / 'output/visualizations/ict-profile-liquidity-replay.html'
HORIZON = timedelta(minutes=15)


def rows_for_replay():
    early, recent = map(shared.fixed.read, (EARLY, overlay.OUT))
    for case in early['cases']:
        grade = case['results']['15m_30s']
        books = {name: [(row['side'], row['price']) for row in grade['outcomes'][name]]
                 for name in ('local', 'integrated')}
        wins = {key: grade['wins'][key] for key in books}
        yield case['cutoff'], grade['checked_from'], case['price'], books, wins
    for cohort in recent['results'].values():
        for case in cohort['15']['cases']:
            books = {'local': list(map(outside, case['selected']['local'])),
                     'integrated': list(map(outside, case['selected']['fixed_two']))}
            yield case['cutoff'], case['checked_from'], case['close'], books, {
                'local': case['wins']['local'], 'integrated': case['wins']['fixed_two']}


def attach(report):
    days = {date.fromisoformat(day['date']): day['replay'] for week in report['weeks'] for day in week['days']}
    stages = Counter(attached=0, outside_archived_day=0, conflicting_close=0)
    seen = set()
    for stamp, checked_from, price, books, wins in rows_for_replay():
        if stamp in seen:
            raise ValueError(f'Duplicate historical liquidity cutoff {stamp}')
        seen.add(stamp)
        at, ready = map(datetime.fromisoformat, (stamp, checked_from))
        day = at.astimezone(NY).date()
        replay = days.get(day)
        if replay is None:
            stages['outside_archived_day'] += 1
            continue
        start, end = _day_bounds(day)
        if not start <= at <= ready < at + HORIZON <= end:
            stages['outside_archived_day'] += 1
            continue
        cutoff_minute = int((at - start).total_seconds() // 60)
        archived_close = next((bar[4] for bar in replay['bars'] if bar[0] == cutoff_minute), None)
        if archived_close != price:
            stages['conflicting_close'] += 1
            continue
        visible = ceil((ready - start) / timedelta(minutes=5)) * 5
        settled = int((at + HORIZON - start).total_seconds() // 60)
        replay.setdefault('liquidityOverlay', []).append(dict(cutoff=cutoff_minute, visible=visible, settled=settled,
                                                              picks=books, hit=wins))
        stages['attached'] += 1
    for replay in days.values():
        if 'liquidityOverlay' in replay:
            replay['liquidityOverlay'].sort(key=lambda row: row['cutoff'])
    return stages


def main():
    report = shared.fixed.read(BASE)
    stages = attach(report)
    paths = (BASE, EARLY, overlay.OUT, Path(__file__))
    report['liquidity_overlay_replay'] = dict(counts=stages, input_hashes={p.name: sha256(p.read_bytes()).hexdigest()
                                                                         for p in paths}, orders_sent=0)
    shared.live.atomic_json(OUT, report)
    write_week_table(report, CHART)
    print(json.dumps(dict(counts=stages, chart=str(CHART)), ensure_ascii=False))


if __name__ == '__main__':
    main()
