"""Replay v7b and same-bar wick evidence on the frozen liquidity boards."""

from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import json
from pathlib import Path
from statistics import median

from ict_ai.sweep_response import RESPONSE_BARS, crossing_response
from scripts import audit_ict_liquidity_15m as quarter
from scripts import audit_ict_liquidity_filter_layers as filters


study = filters.study
M5 = study.M5
OUT = study.RESEARCH / 'ict_sweep_verdict_20261124'
HORIZONS = ('quarter_hour', 'short', 'week')
WINDOWS = (15, 60, 240)
SOURCE = ('https://github.com/alexander094683-projects/forex-ai-source/blob/'
          'b2e15dfb9734a3587de8e48ee43fe2f56ff934b9/docs_layered/work_backup/sweep_v7.py')


def read_inputs():
    archive = filters.ranking.ARCHIVE
    candidates = archive / 'round19_liquidity_50_candidates.json.gz'
    outcomes = archive / 'round19_liquidity_50_outcomes.json.gz'
    studies = {p: json.loads(p.read_bytes()) for p in (filters.OUT, quarter.OUT)}
    four_hour, quarter_hour = studies[filters.OUT], studies[quarter.OUT]
    for name, expected in four_hour['inputs'].items():
        if study.digest(filters.ROOT / name) != expected:
            raise ValueError(f'Frozen report input changed: {name}')
    for p in (candidates, outcomes, filters.OUT):
        if study.digest(p) != quarter_hour['source'][p.name]:
            raise ValueError(f'Quarter-hour report input changed: {p}')
    bars, times = filters.read_market()
    snapshots, outcomes = map(study.read_zip, (candidates, outcomes))
    short, checked = quarter.short_labels(snapshots, outcomes, bars, times)
    assert checked == quarter_hour['four_hour_prefix_agreements']
    input_hashes = {
        str(p.relative_to(filters.ROOT)): study.digest(p)
        for p in (*studies, Path(__file__).resolve(), filters.ROOT / 'ict_ai/sweep_response.py')
    }
    return bars, times, snapshots, [dict(full, **partial) for full, partial in zip(outcomes, short, strict=True)], studies, input_hashes


def verify_observation(bars, start, count):
    rows = bars[start:start+count]
    if len(rows) != count or any(b.time != rows[0].time+i*M5 for i, b in enumerate(rows)):
        return ()
    return rows


def evaluate_crossing(bars, times, stamp, side, edge):
    opened = stamp - M5
    i = bisect_left(times, opened)
    if i == len(times) or times[i] != opened:
        raise ValueError(f'Archived crossing has no source quote at {opened}')
    prior, first = bars[max(0,i-15):i], bars[i]
    later = bars[i+1:i+1+RESPONSE_BARS]
    decisions = {}
    for minutes in WINDOWS:
        observed = stamp+timedelta(minutes=minutes)
        prefix = later[:minutes//5]
        response = crossing_response(side, edge, prior, first, prefix, observed)
        if response != crossing_response(side, edge, prior, first, later, observed):
            raise AssertionError(f'Future prices changed a response at {stamp}')
        if response['status'] == 'unverified_cross':
            raise AssertionError(f'Archived strict crossing did not cover the edge at {stamp}')
        # Count a directional outcome only if all six later closes agree.
        check = i+1+minutes//5
        independent = verify_observation(bars, check, 6)
        path_complete = independent and independent[0].time == observed and bool(
            verify_observation(bars, i, 1+minutes//5)
        )
        relative = [side*(b.close-edge) for b in independent] if path_complete else []
        future = 'incomplete'
        if relative:
            future = 'sweep' if all(x<0 for x in relative) else 'break' if all(x>0 for x in relative) else 'mixed'
        decisions[str(minutes)] = dict(response, later_30m=future)
    return dict(crossing_at=stamp.isoformat(), side=side, edge=edge, decisions=decisions)


def describe(keys, evidence, minutes):
    outcomes = Counter()
    methods = defaultdict(Counter)
    latencies = []
    paired = Counter()
    for key in keys:
        event = evidence[key]
        obs = event['decisions'][str(minutes)]
        result, future = obs['status'], obs['later_30m']
        outcomes[result] += 1
        evidence_available = result not in ('missing_prior', 'incomplete')
        if not evidence_available or future == 'incomplete':
            continue
        predictions = {'cross_as_sweep':'sweep', 'wick_only':'sweep' if obs['wick_band'] else None,
                       'v7b':result if result in ('sweep','break') else None}
        if predictions['wick_only'] and predictions['v7b'] and future != 'mixed':
            paired['directional'] += 1
            paired['wick_matched'] += future == 'sweep'
            paired['v7b_matched'] += future == result
        for name, pred in predictions.items():
            bucket = methods[name]
            bucket['opportunities'] += 1
            if pred is not None:
                bucket['predictions'] += 1
                bucket[pred] += 1
                bucket['settled_directional'] += future != 'mixed'
                bucket['matched'] += future == pred
                bucket[f'{pred}_directional'] += future != 'mixed'
                bucket[f'{pred}_matched'] += future == pred
                bucket['opposite'] += future in ('sweep','break') and future != pred
                bucket['mixed'] += future == 'mixed'
        if obs['known_at']:
            latencies.append((datetime.fromisoformat(obs['known_at'])-key[0]).total_seconds()/60)
    return dict(statuses=outcomes, comparisons=methods, paired_on_wicks=paired,
                median_minutes_after_cross_close=median(latencies) if latencies else None)


def collect(snapshots, outcomes, studies, bars, times):
    picks = defaultdict(set)
    totals = defaultdict(Counter)
    evidence = {}
    last_week = filters.LAST_WEEK
    four_hour, quarter_hour = studies[filters.OUT], studies[quarter.OUT]
    models = dict(four_hour['results'], **{
        'quarter_hour/'+scope:data['refit_15m'] for scope,data in quarter_hour['results'].items()
    })
    final_ranks = {key:{w['at']: w['kept_ranks'] for w in v['final_windows']} for key,v in models.items()}
    for horizon in HORIZONS:
        for scope in ('IRL','ERL'):
            label = f'{horizon}/{scope}'
            for group in filters.ranking.build_groups(zip(snapshots, outcomes, strict=True), horizon, scope):
                if group['status']!='complete' or group['at'] < filters.OCT:
                    continue
                at = group['at'].isoformat()
                selections = dict(top10=range(min(10,len(group['targets']))),
                                  top20=range(min(20,len(group['targets']))),
                                  final_filter=[rank-1 for rank in final_ranks[label].get(at, ())])
                cohorts = ('oct_nov','last_week') if str(group['week'])==last_week else ('oct_nov',)
                for name, indices in selections.items():
                    for cohort in cohorts:
                        key = f'{cohort}/{label}/{name}'
                        totals[key]['windows'] += 1
                        totals[key]['offers'] += len(indices)
                        for i in indices:
                            target, outcome = group['targets'][i], group['events'][i]
                            if not outcome['sweep']:
                                continue
                            stamp = datetime.fromisoformat(outcome['sweep'])
                            side = target['side']
                            edge = target['hi'] if side==1 else target['lo']
                            event = stamp,side,edge
                            totals[key]['strict_crosses'] += 1
                            if event not in evidence:
                                evidence[event] = evaluate_crossing(bars,times,*event)
                            picks[key].add(event)
    policies = {}
    for key, total in totals.items():
        policies[key] = dict(totals=total, distinct_crosses=len(picks[key]),
                             response={str(n):describe(picks[key],evidence,n) for n in WINDOWS})
    return policies, evidence, picks


def rates(count, total):
    return f'{count}/{total} ({count/total:.1%})' if total else '—'


def render(policies):
    horizons = dict(quarter_hour='15 分钟',short='最长 4 小时',week='周内')
    selections = dict(top10='前十',top20='前二十',final_filter='逐层筛选')
    lines = ['# XAUUSD 流动性逐根回测', '',
             '使用 TMGM XAUUSD 2026 年 10 月以来的冻结榜单与历史报价。「上周」为纽约 11 月 16–20 日。'
             '保留同批前十、前二十和上一轮逐层筛选，逐根核对外沿。', '',
             '排序命中以冻结时点和候选组合为分母。扫后统计按同一根 M5、方向和外沿价格去重。'
             '先冻结越界前连续 14 根真实波幅的均值，再核对收回离位或收外跟随。M5 决策窗口最长为越界当根加后续 48 根。', '',
             '扫后另取每个观察窗结束后的 6 根 M5。全部收在原侧为持续收回，全部收在外侧为持续在外，其余为混合。'
             '表中一致率只以这两类作分母，覆盖率另计；它是后续报价一致率。', '']
    for cohort, title in (('oct_nov','10–11 月'),('last_week','上周 11 月 16–20 日')):
        lines += [f'## {title}', '',
                  '|到达窗口／范围／榜单|严格越界／预选|去重事件|60 分钟 V7B 判出覆盖率|V7B 后续一致率|影线后续一致率|同一可判影线样本 V7B／影线吻合数|',
                  '|---|---:|---:|---:|---:|---:|---:|']
        for key,row in policies.items():
            if not key.startswith(cohort+'/'):
                continue
            base = row['totals']
            comp = row['response']['60']['comparisons']
            v7, wick = comp.get('v7b',{}), comp.get('wick_only',{})
            paired = row['response']['60']['paired_on_wicks']
            n = paired.get('directional',0)
            _, horizon, scope, selection = key.split('/')
            lines.append('|'+ '|'.join([
                f'{horizons[horizon]}／{scope}／{selections[selection]}',
                rates(base['strict_crosses'],base['offers']),str(row['distinct_crosses']),
                rates(v7.get('predictions',0),v7.get('opportunities',0)),
                rates(v7.get('matched',0),v7.get('settled_directional',0)),
                rates(wick.get('matched',0),wick.get('settled_directional',0)),
                f"{paired['v7b_matched']}/{n} · {paired['wick_matched']}/{n}" if n else '—',
            ])+'|')
        lines.append('')
    lines += ['明细保留 15／60／240 分钟、缺失报价、判别延迟、混合走势、越界直接判作收回的对照和逐笔事件索引。'
              '复跑命令为 `python -m scripts.replay_ict_sweep_verdict`。', '', f'[仓库 V7B 原则与实现]({SOURCE})']
    return '\n'.join(lines)+'\n'


def main():
    bars, times, snapshots, outcomes, models, hashes = read_inputs()
    policies, evidence, picks = collect(snapshots, outcomes, models, bars, times)
    OUT.mkdir(exist_ok=True, parents=True)
    event_ids = {key:i for i,key in enumerate(sorted(evidence))}
    report = dict(input_hashes=hashes, source=SOURCE, policies=policies,
                  quote_start=times[0].isoformat(), quote_cutoff=(times[-1]+M5).isoformat(),
                  event_count=len(evidence), prefix_checks=len(evidence)*len(WINDOWS), orders_sent=0)
    study.write_zip(OUT/'events.json.gz', dict(
        events=[evidence[key] for key in event_ids],
        indices={name:sorted(event_ids[key] for key in group) for name,group in picks.items()},
    ))
    filters.atomic_json(OUT/'report.json', report)
    (OUT/'流动性逐根回测.md').write_text(render(policies),encoding='utf-8')
    print(f'{len(evidence):,} distinct crossings, {report["prefix_checks"]:,} causal prefix checks, {len(policies)} cohorts',flush=True)


if __name__ == '__main__':
    main()
