"""Compare score and distance from the same durably registered live liquidity boards."""

from collections import Counter
from datetime import datetime
import json

from scripts import watch_ict_liquidity_window_priority as priority


source, fixed, live = priority.source, priority.fixed, priority.live
OUT = priority.OUT / 'board_rank_audit.json'


def collect(policy, observed):
    boards, buckets = [], {}
    for receipt in sorted((source.OUT / 'receipts').glob('*.json')):
        raw, at, ready = source.load_board(policy, receipt)
        if ready > observed:
            continue
        evidence = priority.grade_sources(raw, receipt)
        boards.append((at, ready, raw, source.digest(receipt)))
        if evidence is None:
            continue
        tape, _, bid_sha = evidence
        if len(tape) == 1 and tape[0]['open_utc'] == at.isoformat():
            buckets[at] = (tape[0], bid_sha)
    return boards, buckets


def audit(boards, buckets, observed, count):
    totals = {scope: Counter(windows=0, first_sweep_windows=0) for scope in fixed.board.SCOPES}
    states, rows = Counter(), []
    for at, ready, raw, receipt_sha in boards:
        if at + count * source.M5 > observed:
            states['still_open'] += 1
            continue
        slots = [buckets.get(at + index * source.M5) for index in range(count)]
        if any(slot is None for slot in slots):
            states['missing_bid_archive'] += 1
            continue
        tape, hashes = zip(*slots, strict=True)
        first = priority.evaluate(dict(picks=priority.picks(raw)), raw, ready, tape) if count == 1 else None
        grade = fixed.grade(raw, ready, list(tape), count)
        states[grade['state']] += 1
        if grade['state'] != 'scored':
            continue
        results = {}
        for scope, marks in grade['outcomes']['early'].items():
            ranked = priority.ranking.picks(raw['early'][scope], raw['cutoff_close'])
            hit_rows = [m for m in marks if m['status'] == 'sweep']
            hit_edges = {source.expiry.outer(m) for m in hit_rows}
            first_bid, first_edges = priority.ranking.first_strict(marks)
            methods = {method: dict(picks=ranked[method], first=bool(first_edges.intersection(ranked[method])),
                                    any_sweep=bool(hit_edges.intersection(ranked[method]))) for method in priority.METHODS}
            if first and {key: row['first'] for key, row in methods.items()} != first['results'][scope]['hits']:
                raise ValueError(f'Independent method totals disagreed at {at}')
            totals[scope].update(windows=1, first_sweep_windows=int(first_bid is not None))
            for method, item in methods.items():
                totals[scope].update({f'{method}_first': int(item['first']), f'{method}_any': int(item['any_sweep'])})
            results[scope] = dict(first_bid_ms=first_bid, first_edges=sorted(first_edges),
                                  confirmed_sweeps=hit_rows, methods=methods)
        rows.append(dict(cutoff=at.isoformat(), available_at=ready.isoformat(), chart_receipt=raw['chart_receipt'],
                         board_receipt_sha256=receipt_sha, bid_sha256=hashes, scopes=results))
    return dict(states=states, totals=totals, cases=rows)


def main():
    observed = live.now()
    policy = source.load_policy()
    published = priority.status(priority.load_policy(), policy, verify=True)
    boards, buckets = collect(policy, observed)
    results = {minutes: audit(boards, buckets, observed, minutes // 5) for minutes in (5, 15)}
    summary = dict(observed_at=observed.isoformat(), native_board_policy_sha256=source.digest(source.POLICY),
                   published=published, registrations=len(boards), results=results, orders_sent=0)
    live.atomic_json(OUT, summary)
    print(json.dumps(dict(observed_at=summary['observed_at'], registrations=len(boards),
                          published={key: published[key] for key in ('registered', 'stages', 'scopes')},
                          results={minutes: {key: item[key] for key in ('states', 'totals')}
                                   for minutes, item in results.items()})), flush=True)


if __name__ == '__main__':
    main()
