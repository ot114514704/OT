"""Replay classic 1.1 tick orders with independently frozen daily and weekly context."""
from argparse import ArgumentParser
from dataclasses import asdict, replace
from datetime import timedelta
import json
from pathlib import Path

from brooks_ai.types import Instrument
from ict_ai.planning import target_path
from ict_ai.profile_lifecycle import daily_profile_lifecycle
from ict_ai.tick_portfolio import replay_tick_portfolio
from ict_ai.timebase import NY, session_windows
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_ipda_profiles import active_profiles, panel_week_at, weekly_order_cohorts
from scripts.replay_ict_news import ROOT, STEP
from scripts.replay_ict_route_checkpoints import freeze_checked
from scripts.replay_profile_one_histdata import digest, read_month
from scripts.replay_profile_one_tick_orders import execution_quotes, freeze_orders


def examine(bars, quarters, order):
    at = order.available_at
    day = at.astimezone(NY).date()
    morning = session_windows(day)["new_york"][0]
    initial, morning_coverage = freeze_checked(bars, morning)
    current, signal_coverage = freeze_checked(bars, at)
    chosen = initial["selected_route"]
    path = None
    state = initial["status"]
    if chosen:
        path = target_path(bars, morning, at, STEP, initial["direction"], chosen["target_reference_price"])
        if initial["direction"] != order.side:
            state = "opposing_morning_direction"
        elif path["status"] != "untouched":
            state = "morning_target_" + path["status"]
        elif not current["selected_route"] or current["selected_route"]["id"] != chosen["id"]:
            state = "morning_route_no_longer_selected"
        else:
            state = "same_direction_same_open_target"
    prefix = [b for b in bars if b.time + STEP <= at]
    quarter_prefix = [b for b in quarters if b.time + 3*STEP <= at]
    week = panel_week_at(bars, quarters, at)
    daily = daily_profile_lifecycle(quarter_prefix, day, at, reference_m5=prefix, include_reconstruction=False)
    return {"signal_id":order.id,"at_ny":at.astimezone(NY),"side":order.side,
            "daily_active":[{"id":c["id"],"direction":c["direction"],"label":c["label"]} for c in active_profiles(daily)],
            "daily_coverage":daily["coverage_complete_under_study_calendar"], "week":week,
            "morning_route":initial,"at_signal_route":current,"morning_coverage":morning_coverage,
            "at_signal_coverage":signal_coverage,"morning_target_path":path,"route_filter":state}


def run(baseline_path):
    original = json.loads(baseline_path.read_bytes())
    directory = Path(original["source_directory"])
    months = [read_month(directory, source["month"]) for source in original["sources"]]
    if [src for _,src in months] != original["sources"]:
        raise ValueError("Raw sources differ from the frozen execution sample")
    bars = [b for rows,_ in months for b in rows]
    cutoff = bars[-1].time + STEP
    quarters = aggregate_bars(bars,5,15,cutoff)
    spec = Instrument(**original["reference_contract"])
    _, orders, checks = freeze_orders(bars, spec)
    if json.loads(json.dumps([asdict(o) for o in orders],default=lambda t:t.isoformat())) != original["templates"]:
        raise ValueError("Orders differ from the original five-signal replay")
    cases = [examine(bars,quarters,o) for o in orders]
    week_views = {o.available_at:c["week"] for o,c in zip(orders,cases)}
    groups = {"all_signals":orders, **weekly_order_cohorts(orders,week_views)}
    supported = {c["signal_id"] for c in cases if c["route_filter"]=="same_direction_same_open_target"}
    groups["morning_route_retained"] = [o for o in orders if o.id in supported]
    groups["matching_week_and_morning_route"] = [o for o in groups["only_matching_week"] if o.id in supported]
    ticks = execution_quotes(directory,original["sources"],orders)
    config = ROOT/"config/strategy.json"
    if digest(config) != original["risk_config_sha256"]:
        raise ValueError("Risk configuration differs from original replay")
    model = original["accounts"]["assumed_base"]
    spec = replace(spec,commission_round_turn=model["commission_per_round_turn_lot"],slippage=model["adverse_market_exit_slippage"])
    accounts = {}
    for name, group in groups.items():
        accounts[name] = replay_tick_portfolio(group,ticks,spec,cutoff,model["initial_equity"],model["risk_limits"])
    unfiltered = json.loads(json.dumps(accounts["all_signals"],default=lambda t:t.isoformat()))
    if any(model[k]!=v for k,v in unfiltered.items()):
        raise AssertionError("Unfiltered continuous account failed to reproduce")
    sources = ["research/ict_price_videos/bias_dol/integration.json",
               "research/ict_time_videos/time2_daily/integration.json","research/ict_time_videos/time3_weekly/integration.json"]
    return {"baseline":str(baseline_path),"baseline_sha256":digest(baseline_path),"signal_prefix_checks":checks,
            "course_source_sha256":{p:digest(ROOT/p) for p in sources},
            "rule":"Freeze D1/W1 route before the NY observation window at 07:00 NY. Require the same directed, untouched route at signal time. Score the weekly candidate separately using only closed bars. Each policy starts a separate continuous account.",
            "scope":"Five archival signals; coverage is under the study calendar. Missing or conflicting route is an abstention. A retained route would still be a research hypothesis. No profit or future return used for admission.",
            "cases":cases,"accounts":accounts,"execution_allowed":False,"orders_sent":0}


if __name__=="__main__":
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("baseline",type=Path)
    parser.add_argument("out",type=Path)
    args=parser.parse_args()
    result=run(args.baseline)
    args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2,default=lambda t:t.isoformat())+"\n",encoding="utf-8")
    for name,account in result["accounts"].items():
        print(name,len(account["decisions"]),len(account["completed"]),account["final_realized_equity"])
