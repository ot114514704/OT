"""Reconstruct every weekday in the prior TMGM archive and replay both models."""
from bisect import bisect_left
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import date, datetime, timedelta
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import replay_june_to_latest as june
from scripts import replay_ten_joint_rounds as rounds
from scripts.replay_ten_joint_rounds import joint, priority, NY
from ict_ai.range_liquidity import M5, _Coverage, _research_open

START=date(2025,9,1)
STOP=date(2026,4,1)
OUT=joint.RESEARCH/'prior_joint_months_20261122'
FOCAL=('dol_short','pools_short','pools_week')


def day_range():
    for days in range((STOP-START).days):
        day=START+timedelta(days=days)
        if day.weekday()<5:
            yield day


def month(at):
    dt=datetime.fromisoformat(at).astimezone(NY)
    return (dt.year-START.year)*12+dt.month-START.month


def month_name(i):
    y,m=divmod(START.year*12+START.month-1+i,12)
    return f'{y}-{m+1:02}'


def setup():
    global worker
    sys.path.insert(0,str(priority.ARCH))
    import run
    run.inputs()
    worker=run


def freeze_day(day):
    observations=worker.freeze(day)
    bars,times=worker.SERIES[0],worker.TIMES[0]
    snapshots=[]
    for q in observations:
        if q['status']=='no_checkpoint_quote':
            snapshots.append(dict(at=q['at'],status=q['status']))
            continue
        at=datetime.fromisoformat(q['at'])
        left=bisect_left(times,at-timedelta(days=63))
        right=bisect_left(times,at)
        dol=joint.archived_dol(q)
        pools=joint.liquidity_ranking(bars[left:right],at,dol)
        row=dict(at=q['at'],price=q['price'],pools=pools,dol=dol,h1=q['median_h1'],source='archive',
                 status=q['status'])
        row['picks']={k:rounds.pick(row,k) for k in ('dol','pools')}
        snapshots.append(row)
    return snapshots


def freeze():
    OUT.mkdir(exist_ok=True,parents=True)
    manifest=json.loads((priority.ARCH/'manifest.json').read_bytes())
    archives=('XAUUSDM5.npz','XAUUSDH1.npz','XAGUSDH1.npz','USIDXH1.npz','run.py')
    for name in archives:
        assert joint.digest(priority.ARCH/name)==manifest[name]
    paths=[joint.MODEL,Path(__file__),Path(rounds.__file__),
           joint.ROOT/'ict_ai/dol_outlook.py',joint.ROOT/'ict_ai/dol_history.py',
           joint.ROOT/'research/jin10_calendar/bls_mt5_schedule.json']
    inputs={p.name:joint.digest(p) for p in paths}
    schedule=json.loads(paths[-1].read_bytes())['events']
    count=sum(START.isoformat()<=r[0]<STOP.isoformat() for r in schedule)
    with ProcessPoolExecutor(max_workers=4,initializer=setup) as pool:
        snapshots=[]
        for i,rows in enumerate(pool.map(freeze_day,day_range(),chunksize=2),1):
            snapshots.extend(rows)
            if i%20==0:print(f'Frozen {i} NY weekdays',flush=True)
    states=Counter(s['status'] for s in snapshots)
    (OUT/'checkpoint_status.json').write_text(json.dumps([{'at':s['at'],'status':s['status']} for s in snapshots]),encoding='utf-8')
    file=OUT/'frozen.json.gz'
    joint.write_zip(file,[s for s in snapshots if 'picks' in s])
    lock=dict(frozen=joint.digest(file),archive={k:manifest[k] for k in archives},inputs=inputs,
              scheduled=len(snapshots),statuses=states,loaded_economic_events_in_range=count)
    (OUT/'lock.json').write_text(json.dumps(lock,indent=2),encoding='utf-8')
    print(lock,flush=True)


def write_report(rows,summaries,ci,lock,combined):
    cols='|纽约月份|DOL 四小时|流动性四小时|流动性至周五|'
    rule='每格依次列出现有评分第一、距离最近、近端双模型共振的命中数／有效窗口。DOL 按期限内触价，流动性按严格越过目标区外沿。短期观察最长四小时，按纽约日界截断。'
    table=['# TMGM XAUUSD 历史扩窗联合回测','',rule,'',
          f'2025 年 9 月至 2026 年 3 月每个工作日固定抽查美东 00:05、02:00、08:00、10:00、14:00。安排 {lock["scheduled"]} 个时点，缺少检查点报价的时点单列。旧区间可用新闻排期 {lock["loaded_economic_events_in_range"]} 条，新闻条件覆盖随排期而变。','',
          cols,'|---|---|---|---|']
    totals=defaultdict(Counter)
    for i,s in enumerate(summaries):
        table.append(f'|{month_name(i)}|'+'|'.join(rounds.format_counts(s[k]) for k in FOCAL)+'|')
        for k,v in s.items():totals[k].update(v)
    table+=['|扩窗合计|'+'|'.join(rounds.format_counts(totals[k]) for k in FOCAL)+'|',
            '|加入 4–11 月统一检查点后|'+'|'.join(rounds.format_counts(combined[k]) for k in FOCAL)+'|','',
            '|项目|扩窗中能唯一确认最先到达（现有／最近／共振）|行情缺失／未到期|',
            '|---|---|---|']
    for key,label in zip(FOCAL,('DOL 四小时','流动性四小时','流动性至周五')):
        c=totals[key]
        first='／'.join(str(c[p+'_first']) for p in rounds.POLICIES)
        table.append(f"|{label}|{first}|{c['missing']}／{c['open']}|")
    table+=['','纽约周按夏令时和冬令时换算。同根 M5 命中多个价位时记为先后不明。历史 DOL 的旧研究曾覆盖本区间部分日期，本轮补全工作日是更宽的历史比较。']
    (OUT/'历史扩窗报告.md').write_text('\n'.join(table)+'\n',encoding='utf-8')
    report=dict(months=summaries,older_totals=totals,combined_fixed_totals=combined,confluence_week_block_ci=ci)
    (OUT/'summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report['older_totals']),flush=True)
    print(json.dumps(report['combined_fixed_totals']),flush=True)


def score():
    lock=json.loads((OUT/'lock.json').read_bytes())
    file=OUT/'frozen.json.gz'
    assert joint.digest(file)==lock['frozen']
    for name,digest in lock['archive'].items():
        assert joint.digest(priority.ARCH/name)==digest
    rows=joint.read_zip(file)
    assert len(rows)==len({r['at'] for r in rows})
    summaries,ci=rounds.evaluate(rows,month,7,OUT)
    # April through November is compared only at the same five NY clock times.
    previous=[s for s in rounds.inputs() if datetime.fromisoformat(s['at']).astimezone(NY).strftime('%H:%M') in june.CHECKPOINTS]
    for s in previous:
        s['picks']={k:rounds.pick(s,k) for k in ('dol','pools')}
    previous_output=OUT/'comparison'
    previous_output.mkdir(exist_ok=True)
    prior_stats,_=rounds.evaluate(previous,lambda at:0,1,previous_output)
    combined=defaultdict(Counter,prior_stats[0])
    for period in summaries:
        for key,stats in period.items():
            combined[key].update(stats)
    write_report(rows,summaries,ci,lock,combined)
    from scripts.plot_joint_round_examples import main as plot
    plot(OUT,month,7,'历史扩窗联合回测 · 每轮三张图例')


def coverage_sensitivity():
    """Leave all frozen predictions fixed while testing the observed reopen gap."""
    bars,times=priority.read_market()
    change=date(2026,2,1)
    def open_candidate(t):
        ny=t.astimezone(NY)
        recurring_open_gap=ny.date()<change and ny.hour==18 and ny.minute==0
        return _research_open(t) and not recurring_open_gap
    def stats(calendar):
        cover=_Coverage(times[0],times[-1]+M5,bars,M5,market_open=calendar)
        counts=Counter()
        for s in rows:
            result=joint.assess(s,bars,times,cover,week=True)
            counts[result['status']]+=1
            if result['status']=='complete' and s['picks']['pools']:
                rounds.record(result['pools'],s['picks']['pools'],'sweep',counts)
        return counts
    first=defaultdict(Counter)
    seen=set()
    for t in times:
        ny=t.astimezone(NY)
        day=ny.date()
        if not START<=day<STOP or ny.weekday()>=4 or ny.hour<18 or day in seen:continue
        seen.add(day)
        first[ny.strftime('%Y-%m')][ny.strftime('%H:%M')]+=1
    rows=joint.read_zip(OUT/'frozen.json.gz')
    strict,alternative=stats(_research_open),stats(open_candidate)
    counts=dict(strict=strict,observed_open_scenario=alternative,first_seen_post_break=first)
    (OUT/'coverage_sensitivity.json').write_text(json.dumps(counts,indent=2),encoding='utf-8')
    label='## 纽约 18:00 开盘缺口的敏感性复核'
    report=OUT/'历史扩窗报告.md'
    content=report.read_text(encoding='utf-8').split(label,1)[0].rstrip()
    end=[
        label,'',
        'TMGM 当前公布的 XAUUSD 开盘为服务器 01:01。本存档从 2025 年 9 月至 2026 年 1 月，纽约周一至周四的首根盘后 M5 通常标为 18:05。2026 年 2–3 月通常标为 18:00。原始档案没有与旧日期一一对应的合约时段设置。',
        '[TMGM 合约交易时间](https://www.tmgm.com/eng/trading/trading-hours)','',
        '固定同一批候选、分数和目标，单独检验一种覆盖假设。把 2026 年 2 月前每天 18:00 这一格视为休市，其余缺失仍排除。此处只调整验收窗口的覆盖判断，历史候选以及正式合计保留原口径。','',
        '|周内覆盖口径|流动性到周五（现有／最近／共振）|仍缺报价的窗口|','|---|---|---:|',
        f"|严格原口径|{rounds.format_counts(strict)}|{strict['missing']}|",
        f"|旧档 18:00 格视为休市|{rounds.format_counts(alternative)}|{alternative['missing']}|",
    ]
    report.write_text(content+'\n\n'+'\n'.join(end)+'\n',encoding='utf-8')
    print(json.dumps(counts),flush=True)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('freeze','score','clock'))
    {'freeze':freeze,'score':score,'clock':coverage_sensitivity}[parser.parse_args().stage]()
