"""Replay prior five-per-day chart boards with a one-bar M5 early option."""

from bisect import bisect_left
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, time, timedelta
from inspect import getsource
import json
from pathlib import Path
from statistics import mean

from ict_ai import structural_liquidity as structural
from ict_ai.dol_history import _deadline
from ict_ai.range_liquidity import _Coverage
from scripts import audit_ict_micro_liquidity_early as early
from scripts import replay_structural_top10 as original
from scripts.replay_ict_liquidity_rank import ARCHIVE
from scripts.serve_ict_live import atomic_json


joint, NY, M5 = original.joint, original.NY, original.M5
LOCK = ARCHIVE / 'round19_liquidity_50_lock.json'
FROZEN = ARCHIVE / 'round19_liquidity_50_candidates.json.gz'
INIT = original.june.OUT / 'frozen.json.gz'
OUT = joint.RESEARCH / 'ict_micro_liquidity_board_20261125.json'
SCOPES = ('IRL', 'ERL')
TAG = '提前一根预选'
ELIGIBILITY = '            if not micro_spans[key]:\n                return\n'
SHADOW_ELIGIBILITY = '''            if not micro_spans[key]:
                if tf != 'M5' or i != len(rows) - 2 or side not in early_sides(rows):
                    return
                tag += ' ' + provisional_tag
'''


def early_sides(rows):
    if len(rows) < early.ATR_PERIOD + 1:
        return set()
    history = rows[-(early.ATR_PERIOD + 1):]
    if any(a.time + M5 != b.time for a, b in zip(history, history[1:])):
        return set()
    atr = mean(max(b.high, a.close) - min(b.low, a.close) for a, b in zip(history, history[1:]))
    return {side for side in (-1, 1) if atr > 0 and early.four_bar_pivot(rows[-4:], side)
            and 0 < early.extreme(rows[-2], side) - side * rows[-1].close <= early.NEAR * atr}


def make_shadow_rank():
    # Clone just the pinned production function for the study so live and
    # previously frozen experiments keep their actual source hashes.
    code = getsource(structural.structural_ranking)
    if code.count(ELIGIBILITY) != 1:
        raise ValueError('Production micro-swing filter diverged from the pinned study')
    namespace = dict(vars(structural), early_sides=early_sides, provisional_tag=TAG)
    changed = code.replace(ELIGIBILITY, SHADOW_ELIGIBILITY)
    exec(compile(changed, '<structural_ranking_micro_shadow>', 'exec'), namespace)
    return namespace['structural_ranking']


def initialize():
    global shadow_rank
    original.initialize()
    shadow_rank = make_shadow_rank()


def top10(pools):
    return {scope: [p for p in pools if p['classification'] == scope][:10] for scope in SCOPES}


def replay(task):
    snapshot, archived, verify_control = task
    at = datetime.fromisoformat(snapshot['at'])
    closed = original.bars[:bisect_left(original.times, at)]
    if closed[-1].time + M5 != at or closed[-1].close != archived['price']:
        raise ValueError(f'M5 cutoff no longer matches the archive: {at}')
    provisionals = early_sides(closed)
    before = {scope: archived['pools'][scope][:10] for scope in SCOPES}
    if not provisionals and not verify_control:
        return dict(at=snapshot['at'], potential=[], checked=False, before=before, after=before)
    minute = original.minutes[:bisect_left(original.minute_times, at)]
    has_m1 = bool(minute and minute[-1].time + timedelta(minutes=1) == at)
    if has_m1 != archived['has_m1'] or snapshot['price'] != archived['price']:
        raise ValueError(f'M1 or price no longer matches the archive: {at}')
    arguments = dict(limit=10, priority_uplift=True, minute_bars=minute if has_m1 else ())
    baseline = top10(structural.structural_ranking(closed, at, snapshot['dol'], **arguments))
    if baseline != before:
        raise ValueError(f'Baseline ranking did not reproduce at {at}')
    after = top10(shadow_rank(closed, at, snapshot['dol'], **arguments))
    if not provisionals and after != before:
        raise ValueError(f'No qualifying early candidate, but ranks changed at {at}')
    for p in after['ERL']:
        if not set(p['timeframes']).intersection(structural.EXTERNAL):
            raise ValueError('An external candidate lost its higher-timeframe source')
    return dict(at=snapshot['at'], potential=sorted(provisionals), checked=True, before=before, after=after)


def identity(pool):
    return pool['side'], pool['lo'], pool['hi']


def compare_windows(rows):
    bars, times = original.priority.read_market()
    coverage = _Coverage(times[0], times[-1] + M5, bars, M5)
    summary = defaultdict(Counter)
    examples = []
    for row in rows:
        at = datetime.fromisoformat(row['at'])
        day = at.astimezone(NY).date()
        limits = dict(quarter=at + 3 * M5, short=_deadline(at),
                      week=datetime.combine(day + timedelta(days=4-day.weekday()), time(16, 55), NY))
        for horizon, end in limits.items():
            for scope in SCOPES:
                stats = summary[f'{horizon}/{scope}']
                if end > coverage.cutoff or coverage.gap(at, end):
                    stats['incomplete'] += 1
                    continue
                stats['checkpoints'] += 1
                old, new = row['before'][scope], row['after'][scope]
                left = {identity(p): p for p in old}
                right = {identity(p): p for p in new}
                window = bars[bisect_left(times, at):bisect_left(times, end)]
                observed = {key: joint.contacts(p, window, True)['sweep']
                            for key, p in (left | right).items()}
                swept_old = {key for key in left if observed[key]}
                swept_new = {key for key in right if observed[key]}
                gain = swept_new - swept_old
                lost = swept_old - swept_new
                provisional = [p for p in new if any(TAG in source for source in p['sources'])]
                stats.update(dict(before=len(old), after=len(new), before_hits=len(swept_old), after_hits=len(swept_new),
                                  changed_top10=int(list(left)!=list(right)),
                                  added_hits=len(gain), displaced_hits=len(lost),
                                  gained_first_m5=sum(observed[key] == (at + M5).isoformat() for key in gain),
                                  provisional_slots=len(provisional),
                                  provisional_hits=sum(bool(observed[identity(pool)]) for pool in provisional)))
                if gain or lost:
                    examples.append(dict(at=row['at'], horizon=horizon, scope=scope,
                                         gained=[dict(band=key, swept=observed[key]) for key in sorted(gain)],
                                         lost=[dict(band=key, swept=observed[key]) for key in sorted(lost)]))
    return summary, examples


def main():
    lock = json.loads(LOCK.read_bytes())
    if lock['candidates'] != joint.digest(FROZEN):
        raise ValueError('Prior ranking archive differs from its lock')
    for name, expected in lock['sources'].items():
        if joint.digest(joint.ROOT / name) != expected:
            raise ValueError(f'Frozen baseline input changed: {name}')
    after_october = [row for row in joint.read_zip(FROZEN) if row['at'].startswith(('2026-10', '2026-11'))]
    historical = {row['at']: row for row in joint.read_zip(INIT)}
    tasks = [(historical[row['at']], row, i % 25 == 0) for i, row in enumerate(after_october)]
    with ProcessPoolExecutor(max_workers=3, initializer=initialize) as pool:
        rows = list(pool.map(replay, tasks, chunksize=4))
    summary, examples = compare_windows(rows)
    atomic_json(OUT, dict(scope='Oct–Nov fixed five-per-NY-day full top-ten boards, frozen historical DOL and M1',
        baseline_sha256=joint.digest(FROZEN), code_sha256=joint.digest(Path(__file__)),
        micro_study_sha256=joint.digest(Path(early.__file__)),
        policies='Same ranking code and grouping. Only the native M5 point one bar back can enter early, after left two '
                 'and right one with distance at most one ATR. A coincident external point keeps its higher-timeframe source.',
        sampling='Fixed original publication cuts. Each horizon starts after its cut. Repeated levels across cuts remain distinct.',
        cutoffs=len(rows), qualifying_cutoffs=sum(bool(row['potential']) for row in rows),
        checked_control=sum(row['checked'] and not row['potential'] for row in rows),
        results=summary, changed_outcomes=examples, orders_sent=0))
    print(json.dumps(dict(cutoffs=len(rows), qualifying=sum(bool(row['potential']) for row in rows),
                          results=summary), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
