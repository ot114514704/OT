"""Independently compare two first-sweep rankings on earlier frozen TMGM boards."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import date, datetime, timedelta
import json
from pathlib import Path

from scripts import audit_ict_liquidity_window_rank as rank
from scripts import audit_ict_micro_liquidity_board as board


fixed, live, joint = rank.fixed, rank.live, board.joint
OUT = joint.RESEARCH / 'ict_liquidity_rank_prev_period_20261125.json'
BID = OUT.with_suffix('.json.gz')
START, LAST_WEEK, END = date(2026, 10, 1), date(2026, 11, 16), date(2026, 11, 21)
DELAYS = (30, 60)


def load_checkpoints():
    lock = fixed.read(board.LOCK)
    if lock['candidates'] != joint.digest(board.FROZEN) or any(
            joint.digest(joint.ROOT / name) != expected for name, expected in lock['sources'].items()):
        raise ValueError('Original price and candidate archive changed')
    snapshots = {row['at']: row for row in joint.read_zip(board.INIT)}
    selected = []
    for recorded in joint.read_zip(board.FROZEN):
        at = datetime.fromisoformat(recorded['at'])
        if START <= at.astimezone(board.NY).date() < END:
            selected.append((snapshots[recorded['at']], recorded, True))
    return selected


def capture(pid, checkpoints):
    now = live.now()
    starts = [datetime.fromisoformat(old['at']) for _, old, _ in checkpoints]
    with fixed.open_terminal(pid) as alive:
        rows = fixed.capture_buckets(live.feed.mt5, alive, fixed.frozen_feed(), starts, now)
        buckets = {at.isoformat(): bucket for at, bucket in rows}
    joint.write_zip(BID, dict(captured_at=now.isoformat(), board_sha256=joint.digest(board.FROZEN), buckets=buckets))
    print(f'Captured {len(buckets)} of {len(checkpoints)} independent Bid windows', flush=True)


def measure_scope(pools, outcome, price):
    first, winners = rank.first_strict(outcome)
    selections = rank.picks(pools, price)
    names = ('score_1', 'near_1', 'score_2', 'near_2')
    return dict(first_bid_ms=first, winners=sorted(winners), picks={k: selections[k] for k in names},
                hits={k: bool(winners.intersection(selections[k])) for k in names})


def audit(checkpoints):
    source = joint.read_zip(BID)
    if source['board_sha256'] != joint.digest(board.FROZEN):
        raise ValueError('The captured quotes do not refer to the expected frozen board')
    prices, times = board.original.priority.read_market()
    matched, excluded = [], {}
    for task in checkpoints:
        _, old, _ = task
        stamp = old['at']
        at = datetime.fromisoformat(stamp)
        position = bisect_left(times, at)
        bucket = source['buckets'].get(stamp)
        if (not bucket or position >= len(times) or times[position] != at
                or list(live.quotes.ohlc(prices[position])) != bucket['ohlc']):
            excluded[stamp] = 'unreconciled_with_frozen_m5'
            continue
        matched.append(task)
    records = []
    with ProcessPoolExecutor(max_workers=5, initializer=board.initialize) as workers:
        for (_, old, _), rebuilt in zip(matched, workers.map(board.replay, matched, chunksize=3), strict=True):
            stamp = rebuilt['at']
            at = datetime.fromisoformat(stamp)
            case = dict(cutoff=stamp, frozen_price=old['price'], ny_date=at.astimezone(board.NY).date().isoformat(), delay={})
            data = dict(cutoff=stamp, baseline=rebuilt['before'], early=rebuilt['after'])
            for seconds in DELAYS:
                ready = at + timedelta(seconds=seconds)
                grade = fixed.grade(data, ready, [source['buckets'][stamp]], 1)
                if grade['state'] != 'scored':
                    raise ValueError(f'Validated Bid window could not be graded: {stamp}')
                case['delay'][str(seconds)] = {scope: measure_scope(data['early'][scope],
                    grade['outcomes']['early'][scope], old['price']) for scope in board.SCOPES}
            records.append(case)
    overall = defaultdict(lambda: defaultdict(lambda: defaultdict(Counter)))
    for case in records:
        for label in ('oct_nov', 'last_week'):
            if label == 'last_week' and date.fromisoformat(case['ny_date']) < LAST_WEEK:
                continue
            for delay, scopes in case['delay'].items():
                for scope, cell in scopes.items():
                    group = overall[label][delay][scope]
                    group['valid_windows'] += 1
                    group['with_first_sweep'] += bool(cell['winners'])
                    group.update({method: int(value) for method, value in cell['hits'].items()})
                    group['only_near_1'] += cell['hits']['near_1'] and not cell['hits']['score_1']
                    group['only_score_1'] += cell['hits']['score_1'] and not cell['hits']['near_1']
    report = dict(start=START.isoformat(), end_exclusive=END.isoformat(), captured_at=source['captured_at'],
        expected=len(checkpoints), valid=len(records), excluded=excluded, results=overall, cases=records,
        inputs={p.name: joint.digest(p) for p in (board.INIT, board.LOCK, board.FROZEN, BID, Path(__file__))},
        method=('Two ranking schemes, structural score and distance to the outer edge, on identical frozen top-ten '
                'boards with four-bar preselection and five-bar fallback. Strict first Bid after cutoff plus the '
                'same assumed delay. Whole M5 tick OHLC must equal the prior frozen candle.'), orders_sent=0)
    live.atomic_json(OUT, report)
    print(json.dumps(dict(expected=len(checkpoints), valid=len(records), results=overall), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture-terminal-pid', type=int)
    args = parser.parse_args()
    checkpoints = load_checkpoints()
    if args.capture_terminal_pid:
        capture(args.capture_terminal_pid, checkpoints)
    audit(checkpoints)
