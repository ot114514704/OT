"""Render three examples per round from the frozen predictions and witnessed bars."""
from bisect import bisect_left
from collections import defaultdict
from datetime import datetime, timedelta
from html import escape
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import replay_ten_joint_rounds as rounds
from scripts.replay_ten_joint_rounds import joint, priority, NY, M5, OUT

sys.path.append(str(joint.ROOT/'tmp/pool-chart-deps'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle
from matplotlib.ticker import MaxNLocator

COLORS={'dol':'#7a4cdf','pools':'#057f96'}
LABELS={'dol':'DOL','pools':'流动性'}
MODES=(('DOL 触价',('dol',)),('流动性扫荡',('pools',)),('同一时点双模型命中',('dol','pools')))


def event(s,e,family):
    idx=s['picks'][family]['nearest']
    return e[family][idx]['touch' if family=='dol' else 'sweep']


def choose(snapshots,outcomes,group_for,group_count):
    groups=defaultdict(list)
    for s,e in zip(snapshots,outcomes,strict=True):
        assert s['at']==e['at']
        if e['short']['status']=='complete' and all(s['picks'][k] for k in LABELS):
            groups[group_for(s['at'])].append((s,e['short']))
    for r in range(group_count):
        used=set()
        for title,families in MODES:
            examples=[(s,e) for s,e in groups[r] if all(event(s,e,k) for k in families)]
            assert examples, (r,title)
            def specificity(se):
                s,e=se
                local=datetime.fromisoformat(s['at']).astimezone(NY)
                return (s['at'] in used,
                        len(families)==1 and bool(event(s,e,'pools' if families[0]=='dol' else 'dol')),
                        len(families)==2 and event(s,e,'dol')==event(s,e,'pools'),
                        local.date() in {datetime.fromisoformat(t).astimezone(NY).date() for t in used},
                        s['at'])
            s,e=min(examples,key=specificity)
            used.add(s['at'])
            yield r+1,title,families,s,e


def render(path, round_id, title, families, snapshot, outcome, data, *, missed=(), release=None,
           review=None, uplift_example=False, comparison_caption=None):
    rows,times=data
    at=datetime.fromisoformat(snapshot['at'])
    p=at.astimezone(NY)
    end=datetime.fromisoformat(outcome['end'])
    confirmed={k:datetime.fromisoformat(event(snapshot,outcome,k)) for k in families}
    chart_end=end if review or uplift_example else min(end,max(confirmed.values())+timedelta(minutes=30))
    chart_start=at-timedelta(minutes=55)
    visible=rows[bisect_left(times,chart_start):bisect_left(times,chart_end)]
    assert visible
    def x(t):
        return (t-at).total_seconds()/60
    fig,ax=plt.subplots(figsize=(9.8,5.45),dpi=135)
    fig.patch.set_facecolor('#f5f8fa');ax.set_facecolor('#ffffff')
    fig.subplots_adjust(left=.09,right=.96,bottom=.18,top=.73)
    ax.set_axisbelow(True);ax.grid(True,color='#e3eaf0',linewidth=.7)
    ax.axvspan(x(chart_start)-3,0,color='#ecf2f6',zorder=0)
    ax.axvline(0,color='#1c2c3a',linewidth=1.2,linestyle=(0,(4,3)),zorder=2)
    if release is not None:
        ax.axvline(x(release),color='#b27727',linewidth=1.3,zorder=3)
    ax.tick_params(axis='both',colors='#405465',length=3,labelsize=8)
    for name in ax.spines: ax.spines[name].set_color('#c5d2dc')
    for bar in visible:
        cx=x(bar.time)+2.5
        ink='#13866d' if bar.close>=bar.open else '#b53b51'
        ax.vlines(cx,bar.low,bar.high,color=ink,linewidth=1.1,zorder=4)
        h=max(.012,abs(bar.close-bar.open))
        ax.add_patch(Rectangle((cx-1.45,min(bar.open,bar.close)),2.9,h,color=ink,zorder=5))
    items=[]
    for k in families:
        i=snapshot['picks'][k]['nearest']
        t=snapshot[k][i];lo,hi=t['lo'],t['hi']
        level=(lo if t['side']>0 else hi) if k=='dol' else (hi if t['side']>0 else lo)
        contact=confirmed[k]
        j=bisect_left(times,contact-M5)
        assert rows[j].time+M5==contact and rows[j].low<=level<=rows[j].high
        color=COLORS[k]
        if hi>lo:ax.fill_between([0,x(chart_end)],lo,hi,color=color,alpha=.11,zorder=1)
        ax.hlines(level,0,x(chart_end),color=color,linewidth=1.4,linestyle='--' if k=='dol' else ':',zorder=3)
        ax.scatter(x(contact)-2.5,level,marker='D' if k=='dol' else 'o',s=75 if k=='dol' else 36,
                   facecolors='none' if k=='dol' else color,edgecolors=color,linewidths=1.55,zorder=7)
        zone=f'{lo:.2f}' if lo==hi else f'{lo:.2f}–{hi:.2f}'
        verify=contact.astimezone(NY).strftime('%m-%d %H:%M')
        score = (f"{t['base_score']} → {t['score']} 分" if uplift_example else
                 f"原榜 #{t.get('rank',i+1)} / {t['score']} 分")
        items.append((color,f"{LABELS[k]}  {zone}  ·  {score}  ·  {verify} 收线核实",t['source']))
    missed_text=[]
    for key,target in missed:
        price=target['lo'] if (target['side']>0)==(key=='dol') else target['hi']
        ax.hlines(price,0,x(chart_end),color='#8b6a61',linewidth=1.3,linestyle='-.',zorder=3)
        missed_text.append(f'{LABELS[key]} {price:.2f}')
    if review:
        if review['reference']:
            ax.hlines(review['reference'][0],0,x(chart_end),color='#7a4cdf',linestyle=(0,(3,3)),zorder=3)
        for field,color in (('reclaim','#b27727'),('break_at','#7a4cdf')):
            if review[field]:
                line=datetime.fromisoformat(review[field])
                ax.axvline(x(line),color=color,linewidth=1.15,zorder=3)
        if review.get('fvg'):
            gap=review['fvg'];available=datetime.fromisoformat(gap['available_at'])
            ax.fill_between([x(available),x(chart_end)],gap['lower'],gap['upper'],
                            color='#b27727',alpha=.22,zorder=2)
            ax.axvline(x(datetime.fromisoformat(review['confirmed'])),color='#a23638',linewidth=1.25,zorder=4)
            later=review.get('post_confirmation')
            if later and later['status']=='invalidated':
                ax.axvline(x(datetime.fromisoformat(later['at'])),color='#152a3a',linestyle=':',linewidth=1.7,zorder=5)
    t0,t1=x(chart_start),x(chart_end)
    step=20 if t1-t0>=145 else 15
    xticks=list(range((int(t0)//step+1)*step,int(t1)+1,step))
    ax.set_xticks(xticks,[(at+timedelta(minutes=t)).astimezone(NY).strftime('%H:%M') for t in xticks])
    ax.set_xlim(t0-3,t1+3);ax.yaxis.set_major_locator(MaxNLocator(nbins=7))
    ax.set_ylabel('XAUUSD 价格',color='#405465',fontsize=9)
    fig.text(.09,.92,f'第 {round_id:02d} 轮  ·  {title}',fontsize=19,fontweight='bold',color='#152a3a')
    fig.text(.09,.855,f'{p:%Y-%m-%d %H:%M} 美东冻结  ·  TMGM XAUUSD M5  ·  参考价 {snapshot["price"]:.2f}',
             fontsize=10,color='#425668')
    for i,(ink,label,source) in enumerate(items):
        fig.text(.09,.804-i*.034,label,color=ink,fontsize=8.8)
        fig.text(.65,.804-i*.034,source if len(source)<34 else source[:31]+'…',color=ink,fontsize=8.1)
    fig.text(.09,.077,'灰底为冻结前行情。竖虚线为预测时刻，标记落在首根满足条件的 K 线上。',
             fontsize=9,color='#425668')
    caption='每张采用当时榜单的最近价位，图例仅用于说明判定。时间轴为纽约时间。'
    if missed:
        caption='灰褐点划线为在完整窗口内未命中的最近边沿  ·  '+'／'.join(missed_text)
    if uplift_example:
        caption='灰褐点划线为窗口内未命中的原榜首边沿  ·  '+'／'.join(missed_text)
    if release is not None:
        caption=f'金色竖线为 {release.astimezone(NY):%H:%M} 美东实际公布时刻。图中标记为公布后首次满足条件。'
    if review:
        caption='金色竖线为首次收回，紫色竖线为随后收破。紫色横虚线是扫荡前已确认的反向摆动。'
        if review.get('fvg'):
            caption='金线为收回，紫线为收破，金色带为 FVG，红线为证据到齐，黑色点线为确认后首度失效。'
    if comparison_caption is not None:
        caption=comparison_caption+' · '+'／'.join(missed_text)
    fig.text(.09,.039,caption,
             fontsize=8.5,color='#526777')
    fig.savefig(path)
    plt.close(fig)


def main(output=OUT,group_for=rounds.bounds,group_count=10,title='TMGM 黄金十轮联合回测图例'):
    figures=output/'examples'
    figures.mkdir(exist_ok=True)
    lock=json.loads((output/'lock.json').read_bytes())
    frozen=output/'frozen.json.gz'
    assert lock['frozen']==joint.digest(frozen)
    font=Path('C:/Windows/Fonts/msyh.ttc')
    bold=font.with_name('msyhbd.ttc')
    for path in (font,bold):
        font_manager.fontManager.addfont(path)
    plt.rcParams['font.family']=font_manager.FontProperties(fname=font).get_name()
    plt.rcParams['axes.unicode_minus']=False
    datasets={'archive':priority.read_market(),'recent':joint.load_bars()}
    manifest=[]
    for i,(r,example,families,s,e) in enumerate(choose(joint.read_zip(frozen),joint.read_zip(output/'outcomes.json.gz'),group_for,group_count)):
        name=f'round-{r:02d}-{i%3+1}.png'
        render(figures/name,r,example,families,s,e,datasets[s['source']])
        manifest.append(dict(round=r,path=name,title=example,freeze=s['at'],verified={k:event(s,e,k) for k in families}))
    (figures/'index.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    sections=[]
    for r in range(1,group_count+1):
        charts=[f'<figure><a href="{m["path"]}"><img loading="lazy" src="{m["path"]}" alt="{escape(m["title"])}"></a><figcaption>{escape(m["title"])}</figcaption></figure>'
                for m in manifest if m['round']==r]
        sections.append(f'<section id="round-{r:02d}"><h2>第 {r} 轮</h2><div>{"".join(charts)}</div></section>')
    nav=' '.join(f'<a href="#round-{r:02d}">第 {r} 轮</a>' for r in range(1,group_count+1))
    html='''<!doctype html><html lang="zh"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>十轮联合回测图例</title><style>body{font:16px/1.55 system-ui,sans-serif;background:#f4f7fa;color:#142b3d;margin:0 auto;max-width:1450px;padding:2rem}nav a{display:inline-block;padding:.5rem;color:#086689}section>div{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,360px),1fr));gap:1rem}figure{margin:0;background:white;border:1px solid #dbe3ec;border-radius:.5rem;overflow:hidden}img{display:block;width:100%;height:auto}figcaption{padding:.7rem}section{margin:2.2rem 0}</style>
<h1>'''+escape(title)+'</h1><p>每轮三张。点击图例放大。</p><nav>'+nav+'</nav>'+''.join(sections)+'</html>'
    (figures/('十轮图例.html' if group_count==10 else '每月图例.html')).write_text(html,encoding='utf-8')
    print(f'{len(manifest)} charts saved',flush=True)


if __name__=='__main__':
    main()
