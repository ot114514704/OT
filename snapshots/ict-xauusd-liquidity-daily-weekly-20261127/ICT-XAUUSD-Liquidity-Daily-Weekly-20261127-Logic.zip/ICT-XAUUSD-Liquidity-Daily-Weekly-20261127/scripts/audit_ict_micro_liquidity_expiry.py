"""Measure what one-bar liquidity preselection adds before the fifth close."""

from bisect import bisect_left
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timedelta
import json
from pathlib import Path

from ict_ai.dol_tick_evidence import utc_ms
from ict_ai.range_liquidity import _Coverage
from scripts import audit_ict_micro_liquidity_board as board
from scripts import audit_ict_micro_liquidity_latency as recent_timing
from scripts import audit_ict_micro_liquidity_prior_months as earlier
from scripts.check_pool_priority import interval
from scripts.serve_ict_live import atomic_json


OUT = board.joint.RESEARCH / 'ict_micro_liquidity_expiry_20261125.json'
DELAYS = (0, 15, 30, 60, 120)
digest = board.joint.digest


def outer(pool):
    return pool['side'], pool['hi'] if pool['side'] == 1 else pool['lo']


def next_board(snapshot, original):
    at = datetime.fromisoformat(snapshot['at'])
    finish = at + board.M5
    source = board.original
    bars = source.bars[:bisect_left(source.times, finish)]
    if not bars or bars[-1].time + board.M5 != finish:
        return None
    minute = source.minutes[:bisect_left(source.minute_times, finish)]
    ranked = board.structural.structural_ranking(
        bars, finish, snapshot['dol'], limit=10, priority_uplift=True,
        minute_bars=minute if original['has_m1'] and minute and minute[-1].time + timedelta(minutes=1) == finish else (),
    )
    return board.top10(ranked)


def rebuild(task):
    snapshot, archived, later_changed = task
    row = board.replay((snapshot, archived, False))
    if later_changed:
        row['next'] = next_board(snapshot, archived)
    return row


def timing_evidence():
    old = json.loads(earlier.TIMING.read_bytes())
    new = json.loads(recent_timing.OUT.read_bytes())
    if (old['replay_sha256'] != digest(earlier.OUT)
            or new['inputs'][board.OUT.name] != digest(board.OUT)):
        raise ValueError('Crossing evidence did not use the archived board')
    evidence = {}
    for key, rows in ((('cutoff', 'opened'), old['evidence']), (('at', 'crossing_bar'), new['delay_boundary_crosses'])):
        for row in rows:
            evidence[row[key[0]], row[key[1]], row['side'], row['edge']] = row
    return evidence


def score(rows, changes, evidence):
    bars, times = board.original.priority.read_market()
    coverage = _Coverage(times[0], times[-1] + board.M5, bars, board.M5)
    totals, months, weeks = defaultdict(Counter), defaultdict(lambda: defaultdict(Counter)), defaultdict(dict)
    details = []
    for row in rows:
        at = datetime.fromisoformat(row['at'])
        finish = at + board.M5
        if finish > coverage.cutoff or coverage.gap(at, finish):
            continue
        slot = bars[bisect_left(times, at):bisect_left(times, finish)]
        if len(slot) != 1:
            raise ValueError(f'Covered first M5 not found at {at}')
        local = at.astimezone(board.NY).date()
        this_month = local.strftime('%Y-%m')
        week = str(local - timedelta(days=local.weekday()))
        for scope in board.SCOPES:
            old, new = (row[policy][scope] for policy in ('before', 'after'))
            by_policy = [dict((outer(target), target) for target in pools) for pools in (old, new)]
            hits = [{key for key, target in book.items() if board.joint.contacts(target, slot, True)['sweep']}
                    for book in by_policy]
            gained, lost = hits[1] - hits[0], hits[0] - hits[1]
            counts = totals[scope]
            daily = months[this_month][scope]
            measured = dict(checkpoints=1, five_hits=len(hits[0]), early_hits=len(hits[1]),
                            gains=len(gained), losses=len(lost))
            counts.update(measured)
            daily.update(measured)
            pair = weeks[scope].setdefault(week, [0, 0])
            pair[0] += len(gained) - len(lost)
            pair[1] += 1
            for direction, changed in (('gain', gained), ('loss', lost)):
                for side, edge in changed:
                    proof = evidence.get((row['at'], row['at'], side, edge))
                    if not proof or proof['resolution'] != 'tick':
                        raise ValueError(f'First-bar change needs exact Bid evidence: {row["at"]}, {side}, {edge}')
                    for seconds in DELAYS:
                        if recent_timing.eligible(proof, utc_ms(at) + 1000 * seconds, seconds) == 'eligible':
                            counts[f'{direction}_{seconds}s'] += 1
            for old_change in changes.get((row['at'], scope), ()):
                for item in old_change['gained']:
                    if datetime.fromisoformat(item['swept']) <= finish:
                        continue
                    band = tuple(item['band'])
                    side, lo, hi = band
                    edge = (side, hi if side == 1 else lo)
                    following = row['next']
                    if following is None:
                        disposition = 'no_fifth_close'
                    elif band in {board.identity(p) for p in following[scope]}:
                        disposition = 'same_band_in_next_baseline'
                    elif edge in {outer(p) for p in following[scope]}:
                        disposition = 'same_edge_in_next_baseline'
                    else:
                        disposition = 'edge_absent_from_next_top10'
                    details.append(dict(at=row['at'], horizon=old_change['horizon'], scope=scope,
                                        band=band, swept=item['swept'], next_board=disposition))
    uncertainty = {scope: interval(blocks) for scope, blocks in weeks.items()}
    return totals, months, uncertainty, details


def main():
    prior, recent = (json.loads(p.read_bytes()) for p in (earlier.OUT, board.OUT))
    code = digest(Path(board.__file__))
    if prior['sources']['board_code'] != code or recent['code_sha256'] != code:
        raise ValueError('The production shadow rule differs from the replay')
    lock = json.loads(board.LOCK.read_bytes())
    if (lock['candidates'] != digest(board.FROZEN)
            or any(digest(board.joint.ROOT / name) != hash_ for name, hash_ in lock['sources'].items())):
        raise ValueError('Frozen board or quote inputs changed')
    changes = defaultdict(list)
    next_needed = set()
    for row in prior['changed_outcomes'] + recent['changed_outcomes']:
        changes[row['at'], row['scope']].append(row)
        finish = datetime.fromisoformat(row['at']) + board.M5
        if any(datetime.fromisoformat(hit['swept']) > finish for hit in row['gained']):
            next_needed.add(row['at'])
    historical = {row['at']: row for row in board.joint.read_zip(board.INIT)}
    archived = board.joint.read_zip(board.FROZEN)
    if len(archived) != prior['cutoffs'] + recent['cutoffs']:
        raise ValueError('Prior and recent tests do not cover the same set of frozen checkpoints')
    tasks = [(historical[row['at']], row, row['at'] in next_needed) for row in archived]
    with ProcessPoolExecutor(max_workers=3, initializer=board.initialize) as pool:
        rows = list(pool.map(rebuild, tasks, chunksize=4))
    totals, months, uncertainty, details = score(rows, changes, timing_evidence())
    if any(stats['early_hits'] - stats['five_hits'] != stats['gains'] - stats['losses']
           for stats in totals.values()):
        raise ValueError('First-bar paired outcomes do not reconcile')
    timing = {scope: {s: counts[f'gain_{s}s'] - counts[f'loss_{s}s'] for s in DELAYS}
              for scope, counts in totals.items()}
    later = defaultdict(Counter)
    for item in details:
        later[f'{item["horizon"]}/{item["scope"]}'][item['next_board']] += 1
    atomic_json(OUT, dict(checkpoints=len(rows), first=rows[0]['at'], last=rows[-1]['at'], totals=totals, months=months,
                          net_by_delay=timing, paired_week_ci95_per_cut=uncertainty,
                          later_gains_by_next_baseline=later, later_details=details,
                          inputs={p.name: digest(p) for p in (earlier.OUT, board.OUT, earlier.TIMING,
                                                             recent_timing.OUT, board.FROZEN, Path(__file__))},
                          method='After one M5 both arms follow the same standard board, so only first M5 differences are attributed to early availability. Count each side/outer edge once per cutoff. Rebuild ordinary next top ten with newer M5 and the original frozen DOL context.',
                          orders_sent=0))
    print(dict(totals=totals, net_by_delay=timing, later=later, ci=uncertainty), flush=True)


if __name__ == '__main__':
    main()
