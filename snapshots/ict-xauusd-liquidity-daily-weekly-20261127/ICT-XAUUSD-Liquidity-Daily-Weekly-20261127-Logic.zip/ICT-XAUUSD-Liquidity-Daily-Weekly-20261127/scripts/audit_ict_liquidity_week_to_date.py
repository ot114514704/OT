"""Verify and complete this week's paired XAUUSD liquidity recognition replay."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timedelta
import json
from pathlib import Path

from ict_ai.range_liquidity import _research_open
from scripts import audit_ict_early_liquidity_response as response
from scripts import audit_ict_micro_liquidity_missing_boards as reconstruct
from scripts import audit_ict_micro_liquidity_recent_all_m5 as recent


stream, fixed, live, M5 = recent.stream, recent.fixed, recent.live, recent.M5
bridge, H1 = reconstruct.bridge, reconstruct.H1
joint = recent.board.joint
REPORT = recent.OUT.with_name('ict_liquidity_week_to_date_20261125.json')
INPUT = REPORT.with_suffix('.json.gz')
DELAYS = (30, 60)


def reused_cases(archived, rebuilt):
    rows = {}
    for source, report in (('verified_original_board', archived), ('reconstructed_prior', rebuilt)):
        for saved in report['cases']:
            stamp = saved['cutoff']
            outcomes = saved.get('outcomes', saved)
            if stamp in rows:
                raise ValueError(f'Duplicate historical evidence at {stamp}')
            if any(str(delay) not in outcomes for delay in DELAYS):
                continue
            rows[stamp] = dict(cutoff=stamp, source=source,
                               qualifying=saved.get('qualified_sides', saved.get('qualifying')),
                               comparisons={str(delay): outcomes[str(delay)] for delay in DELAYS})
    return rows


def actual_receipts(policy, start, end):
    rows = {}
    for receipt in sorted((stream.OUT / 'receipts').glob('*.json')):
        data, cutoff, ready = stream.load_board(policy, receipt)
        if not start <= cutoff < end:
            continue
        path = stream.OUT / 'settlements' / receipt.name
        if not path.is_file():
            rows[cutoff.isoformat()] = dict(data=data, ready=ready.isoformat())
            continue
        result = fixed.read(path)
        bid = stream.OUT / 'bid' / path.with_suffix('.json.gz').name
        if result['receipts_sha256'] != recent.digest(receipt) or result['bid_sha256'] != recent.digest(bid):
            raise ValueError(f'Live evidence failed its digest at {cutoff}')
        buckets = joint.read_zip(bid)
        grade = fixed.grade(data, ready, buckets, 1)
        if grade['state'] != result['state'] or stream.paired(grade) != result['paired']:
            raise ValueError(f'Live outcome did not reproduce at {cutoff}')
        rows[cutoff.isoformat()] = dict(data=data, ready=ready.isoformat(), buckets=buckets,
                                       settlement_sha256=recent.digest(path))
    return rows


def capture(pid, as_of):
    archived, _, rebuilt = response.checked_inputs()
    policy = stream.load_policy()
    now = live.now()
    requested = now if as_of is None else as_of.astimezone(recent.ORIGIN.tzinfo)
    if requested > now:
        raise ValueError('The end of a broker replay must be in the past')
    end = recent.ORIGIN + ((requested - fixed.SYNC - recent.ORIGIN) // M5) * M5
    start = datetime.fromisoformat(archived['start'])
    if end < datetime.fromisoformat(archived['end_before']):
        raise ValueError('This week extension expects a cutoff after the original study')
    starts = [start + i * M5 for i in range((end - start) // M5) if _research_open(start + i * M5)]
    previous = reused_cases(archived, rebuilt)
    actual = actual_receipts(policy, start, end)
    pending = [at for at in starts if at.isoformat() not in previous
               and not actual.get(at.isoformat(), {}).get('buckets')]
    with fixed.open_terminal(pid) as alive:
        with live.terminal() as (api, clock):
            m5 = bridge.history('XAUUSD', api.TIMEFRAME_M5, clock, end)
            m1 = bridge.history('XAUUSD', api.TIMEFRAME_M1, clock, end)
            h1 = {symbol: recent.rows(bridge.history(symbol, api.TIMEFRAME_H1, clock, end))
                  for symbol in ('XAUUSD', 'XAGUSD', 'USIDX')}
        available = {bar.time for bar in m5}
        raw = fixed.capture_buckets(bridge.mt5, alive, fixed.frozen_feed(),
                                    [at for at in pending if at in available], live.now())
        buckets = {at.isoformat(): bucket for at, bucket in raw}
    joint.write_zip(INPUT, dict(start=start.isoformat(), end=end.isoformat(), observed_at=requested.isoformat(),
                                scheduled=[at.isoformat() for at in starts], actual=actual, bid=buckets,
                                m5=recent.rows(m5), m1=recent.rows(m1), h1=h1,
                                calendar=fixed.read(reconstruct.CALENDAR)['events'],
                                source={p.name: recent.digest(p) for p in (recent.OUT, reconstruct.OUT, stream.POLICY)}))


def reconstruct_init():
    evidence = joint.read_zip(INPUT)
    state = reconstruct
    state.m5, state.m1 = (state.unpack(evidence[key]) for key in ('m5', 'm1'))
    state.m5_times, state.m1_times = ([bar.time for bar in bars] for bars in (state.m5, state.m1))
    state.h1 = {name: state.unpack(rows) for name, rows in evidence['h1'].items()}
    state.h1_times = {name: [bar.time for bar in bars] for name, bars in state.h1.items()}
    state.minutes15 = bridge.aggregate_bars(state.m5, 5, 15, datetime.fromisoformat(evidence['end']))
    state.times15 = [bar.time for bar in state.minutes15]
    state.news = [(datetime.fromisoformat(day + 'T' + clock).replace(tzinfo=bridge.NY), name)
                  for day, clock, name in evidence['calendar']]
    state.shadow = recent.board.make_shadow_rank()


def measured(data, scoring_times, buckets, qualifying, source):
    comparisons = {}
    for delay, ready in scoring_times.items():
        grade = fixed.grade(data, ready, buckets, 1)
        if grade['state'] != 'scored':
            return None, grade['state']
        comparisons[str(delay)] = stream.paired(grade)
    return dict(cutoff=data['cutoff'], source=source, qualifying=qualifying,
                comparisons=comparisons), 'scored'


def complete(evidence, previous):
    prices = {stamp: values for stamp, *values in evidence['m5']}
    buckets = evidence['bid']
    configured = set(evidence['scheduled'])
    actual = evidence['actual']
    rows = {stamp: row for stamp, row in previous.items() if stamp in configured}
    excluded = {}
    for stamp, recorded in actual.items():
        ready = datetime.fromisoformat(recorded['ready'])
        bucket = recorded.get('buckets') or ([buckets[stamp]] if stamp in buckets else [])
        data = recorded['data']
        row, state = measured(data, dict.fromkeys(DELAYS, ready), bucket, data['potential_sides'], 'real_time_registered')
        if row:
            rows[stamp] = dict(**row, actual_available_at=recorded['ready'])
        else:
            excluded[stamp] = state
    tasks = []
    for stamp in sorted(configured - rows.keys() - excluded.keys()):
        at = datetime.fromisoformat(stamp)
        if stamp not in prices or (at - M5).isoformat() not in prices:
            excluded[stamp] = 'missing_preceding_or_outcome_bar'
        elif stamp not in buckets or prices[stamp] != buckets[stamp]['ohlc']:
            excluded[stamp] = 'unreconciled_bid'
        else:
            tasks.append(stamp)
    with ProcessPoolExecutor(max_workers=6, initializer=reconstruct_init) as pool:
        for data in pool.map(reconstruct.reconstruct, tasks, chunksize=2):
            stamp = data['cutoff']
            at = datetime.fromisoformat(stamp)
            times = {delay: at + timedelta(seconds=delay) for delay in DELAYS}
            row, state = measured(data, times, [buckets[stamp]], data['qualifying'], 'reconstructed_extension')
            if row:
                rows[stamp] = row
            else:
                excluded[stamp] = state
    if len(rows) + len(excluded) != len(configured):
        raise ValueError('At least one expected window was counted more than once')
    return dict(sorted(rows.items())), excluded


def aggregate(ordered):
    def counts_by_delay():
        return defaultdict(lambda: defaultdict(Counter))
    total = counts_by_delay()
    by_source = defaultdict(counts_by_delay)
    by_day = defaultdict(counts_by_delay)
    for stamp, row in ordered.items():
        day = datetime.fromisoformat(stamp).astimezone(recent.BEIJING).date().isoformat()
        for delay, pools in row['comparisons'].items():
            for scope, values in pools.items():
                selected = {key: values[key] for key in ('baseline_hits', 'early_hits', 'added', 'displaced',
                                                        'baseline_preexpired', 'early_preexpired')}
                selected.update(windows=1, qualifying=int(bool(row['qualifying'])),
                                baseline_hit_windows=int(values['baseline_hits'] > 0),
                                early_hit_windows=int(values['early_hits'] > 0))
                for destination in (total, by_source[row['source']], by_day[day]):
                    destination[delay][scope].update(selected)
    return dict(total=total, by_source=by_source, by_beijing_day=by_day)


def audit():
    archived, _, rebuilt = response.checked_inputs()
    evidence = joint.read_zip(INPUT)
    paths = (recent.OUT, reconstruct.OUT, stream.POLICY)
    if evidence['source'] != {p.name: recent.digest(p) for p in paths}:
        raise ValueError('Week extension does not use the verified earlier samples')
    rows, excluded = complete(evidence, reused_cases(archived, rebuilt))
    report = dict(start=evidence['start'], end=evidence['end'], observed_at=evidence['observed_at'],
                  scheduled=len(evidence['scheduled']), scored=len(rows), **aggregate(rows), cases=list(rows.values()),
                  coverage_exclusions=excluded,
                  method=('One M5 following the candidate cutoff. Real-time cases use their durable receipt. '
                          'Original historical cases use the later of the native chart receipt and delay. '
                          'Reconstructed cases use the specified 30 or 60 seconds after cutoff. '
                          'Compare both boards at the same availability timestamp within each case.'),
                  inputs={p.name: recent.digest(p) for p in (*paths, INPUT, Path(__file__))}, orders_sent=0)
    live.atomic_json(REPORT, report)
    print(json.dumps({k: report[k] for k in ('start', 'end', 'scheduled', 'scored', 'total',
                                             'by_source', 'by_beijing_day', 'coverage_exclusions')}, ensure_ascii=False))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture-terminal-pid', type=int)
    parser.add_argument('--as-of', type=datetime.fromisoformat)
    args = parser.parse_args()
    if args.as_of and args.as_of.utcoffset() is None:
        parser.error('--as-of requires a timezone')
    if args.capture_terminal_pid:
        capture(args.capture_terminal_pid, args.as_of)
    audit()
