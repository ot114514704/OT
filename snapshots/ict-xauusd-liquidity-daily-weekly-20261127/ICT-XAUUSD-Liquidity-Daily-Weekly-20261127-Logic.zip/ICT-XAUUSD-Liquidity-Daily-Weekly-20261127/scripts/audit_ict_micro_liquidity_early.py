"""Test the upstream distance feature on earlier closed-M5 swing candidates."""

from collections import Counter, defaultdict
from datetime import timedelta
import json
from pathlib import Path
from statistics import mean

from ict_ai.structural_liquidity import grouped_extrema, micro_swing_span, swing_points
from ict_ai.timebase import NY
from scripts import check_pool_priority as market
from scripts.serve_ict_live import atomic_json


M5 = market.M5
ATR_PERIOD = 14
NEAR = 1.0
WINDOWS = (15, 60, 240)
OUT = market.joint.RESEARCH / 'ict_micro_liquidity_early_20261125.json'
REF = 'https://github.com/alexander094683-projects/forex-ai-source/blob/4a85ed219ddb362f890161693f449328f225ded0/docs_layered/reference/'
POLICIES = ('five', 'four', 'four_near', 'four_near_then_five')


def extreme(bar, side):
    return bar.high if side == 1 else -bar.low


def four_bar_pivot(window, side):
    older, left, center, right = (extreme(bar, side) for bar in window)
    return left < center and older <= center and right < center


def strict_cross(bar, level, side):
    return bar.low <= level <= bar.high and extreme(bar, side) > side * level


def micro_candidates(bars):
    run_start = 0
    for latest in range(1, len(bars) - 1):
        if bars[latest - 1].time + M5 != bars[latest].time:
            run_start = latest
        if latest - run_start < ATR_PERIOD or bars[latest].time + M5 != bars[latest + 1].time:
            continue
        center = latest - 1
        early_price = bars[latest].close
        tape = bars[center - 2:latest + 1]
        atr_window = bars[latest - ATR_PERIOD:latest + 1]
        atr = mean(max(bar.high, previous.close) - min(bar.low, previous.close)
                   for previous, bar in zip(atr_window, atr_window[1:]))
        if atr <= 0:
            continue
        for side in (-1, 1):
            level = side * extreme(bars[center], side)
            early = four_bar_pivot(tape, side) and side * (level - early_price) > 0
            fifth = bars[latest + 1]
            # The immediately preceding M5 extreme is strict for the native
            # plateau-aware M5 pivot. A right-hand tie requires the next bar.
            five = (extreme(bars[center - 1], side) < side * level
                    and side * (level - fifth.close) > 0
                    and bool(micro_swing_span(bars[center - 2:latest + 2], 2, level, side)))
            if not early and not five:
                continue
            distance = side * (level - early_price) / atr
            yield dict(i=latest, anchor=bars[center].time.isoformat(), cutoff=bars[latest + 1].time.isoformat(),
                       side=side, level=level, early=early, five=five, near=(early and distance <= NEAR),
                       atr=atr, distance_at_four=distance)


def coverage_end(bars):
    ends = [len(bars)] * len(bars)
    for i in range(len(bars) - 2, -1, -1):
        ends[i] = ends[i + 1] if bars[i].time + M5 == bars[i + 1].time else i + 1
    return ends


def judge(row, bars, ends):
    i = row['i']
    level, side = row['level'], row['side']
    first = i + 1
    offers = {'five': first + 1 if row['five'] else None, 'four': first if row['early'] else None,
              'four_near': first if row['near'] else None,
              'four_near_then_five': first if row['near'] else first + 1 if row['five'] else None}
    result = {}
    for minutes in WINDOWS:
        stop = first + minutes // 5
        if stop > ends[first]:
            result[str(minutes)] = None
            continue
        crossed = next((j for j in range(first, stop) if strict_cross(bars[j], level, side)), None)
        statuses = {}
        for rule, start in offers.items():
            # A preselection which fails confirmation lasts only through the
            # fifth bar. A crossing on that bar is still observable in advance.
            hit = (start is not None and crossed is not None and crossed >= start
                   and (row['five'] or crossed == first))
            statuses[rule] = dict(offered=start is not None,
                                  hit=hit,
                                  first_bar_only=start == first and crossed == first,
                                  lead_one_bar=start == first and row['five'],
                                  early_without_five=start == first and not row['five'])
        result[str(minutes)] = statuses
    return dict(row, strict_fifth_cross=strict_cross(bars[first], level, side), outcomes=result)


def cohort(at):
    day = at.astimezone(NY).date().isoformat()
    if day >= '2026-10-01':
        return 'oct_nov'
    if day >= '2026-07-01':
        return 'jul_sep'
    return 'before_jul_2026'


def main():
    source = market.ARCH / 'XAUUSDM5.npz'
    manifest = market.ARCH / 'manifest.json'
    digest = market.joint.digest
    if digest(source) != json.loads(manifest.read_bytes())[source.name]:
        raise ValueError('Golden M5 archive does not match its manifest')
    bars, times = market.read_market()
    periods, coverage = grouped_extrema(bars, M5, times[-1] + M5, ('M5',))['M5']
    native = {side: {bar.time for bar in swing_points(periods, coverage, side)} for side in (-1, 1)}
    ends = coverage_end(bars)
    tables = defaultdict(Counter)
    score = defaultdict(lambda: {name: Counter() for name in POLICIES})
    evidence = []
    for candidate in micro_candidates(bars):
        row = judge(candidate, bars, ends)
        if row['five'] and bars[row['i'] - 1].time not in native[row['side']]:
            raise ValueError(f"Five-bar candidate disagrees with the native M5 pivot at {row['anchor']}")
        period = cohort(bars[row['i']].time + M5)
        counts = tables[period]
        counts['union_candidates'] += 1
        counts['confirmed_five'] += row['five']
        counts['offered_four'] += row['early']
        counts['four_then_five'] += row['early'] and row['five']
        counts['four_crossed_on_fifth'] += row['early'] and row['strict_fifth_cross']
        counts['offered_four_near'] += row['near']
        counts['four_near_then_five'] += row['near'] and row['five']
        counts['four_near_crossed_on_fifth'] += row['near'] and row['strict_fifth_cross']
        for minutes, statuses in row['outcomes'].items():
            if statuses is None:
                counts[f'incomplete_{minutes}'] += 1
                continue
            for rule, outcomes in statuses.items():
                score[f'{period}/{minutes}'][rule].update({label: int(value) for label, value in outcomes.items()})
        if row['near'] and row['strict_fifth_cross']:
            evidence.append({key: row[key] for key in ('anchor', 'cutoff', 'side', 'level', 'atr', 'distance_at_four')})
    report = dict(scope='Native M5 swing anchors, before price clustering or full-board ranking',
                  policies=dict(five='left two + swing + right two', four='left two + swing + right one',
                                four_near='four with distance to the anchor at most one closed-M5 ATR',
                                four_near_then_five='preselect near four-bar anchors, publish other five-bar anchors at confirmation'),
                  upstream=[REF + 'LIQ_RANK_CN.md', REF + 'LIQ_MAP_LEARN_CN.md'], atr_period=ATR_PERIOD,
                  window='Common 15/60/240-minute endpoints from the four-bar cutoff. Exclude any quote gap in the window. '
                         'The five-bar policy can score only after its confirmation closes.',
                  strict='First witnessed M5 range covers and exceeds the price on its original side. '
                         'The four-bar preselection expires at the fifth close unless confirmed.',
                  limits='No whole-board positions, merged price bands or M6/M10/M12 claims. '
                         'One ATR is tested as a fixed translation of the upstream H1/H4 touch-distance grouping. '
                         'Pair comparisons require a continuous fifth bar and ATR warmup.',
                  archive=[times[0].isoformat(), (times[-1] + timedelta(minutes=5)).isoformat()], counts=tables,
                  results=score, first_bar_evidence=evidence,
                  inputs={path.name: digest(path) for path in (source, manifest, Path(__file__),
                                                              Path('ict_ai/structural_liquidity.py'))}, orders_sent=0)
    atomic_json(OUT, report)
    for name, counts in tables.items():
        print(name, dict(counts))
    for name, results in score.items():
        print(name, {method: (values['hit'], values['offered']) for method, values in results.items()})


if __name__ == '__main__':
    main()
