"""Prospective settlement of sweep verdicts on already registered chart candidates."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path
import json
from time import sleep

from scripts import replay_ict_sweep_verdict as replay
from scripts import watch_ict_liquidity_filter_accuracy as forward


OUT = forward.quotes.RESEARCH / 'ict_sweep_verdict_forward_20261124'
POLICY = OUT / 'policy.json'
M5 = forward.M5
FOLLOWUP = timedelta(minutes=max(replay.WINDOWS) + 30)
INPUTS = (Path(__file__).resolve(), Path(replay.__file__).resolve(),
          forward.quotes.ROOT / 'ict_ai/sweep_response.py',
          replay.OUT / 'report.json', forward.POLICY)


def load_policy():
    pins = {p.relative_to(forward.quotes.ROOT).as_posix(): forward.quotes.digest(p) for p in INPUTS}
    if not POLICY.exists():
        forward.atomic_json(POLICY, dict(
            frozen_at=forward.now().isoformat(), inputs=pins, windows_minutes=list(replay.WINDOWS),
            outcome='six contiguous M5 closes after each window, classified by their side of the frozen outer edge',
            sampling='registered chart candidates, with the first eligible M5 open at or after the rules freeze',
            orders_sent=0,
        ))
    policy = json.loads(POLICY.read_bytes())
    if policy['inputs'] != pins:
        raise ValueError('The prospectively frozen sweep-verdict inputs changed')
    return policy


def extract_events(registration, settlement):
    events = defaultdict(set)
    ready = datetime.fromisoformat(registration['eligible_from'])
    for case, measured in settlement['outcomes'].items():
        if measured['state'] != 'complete':
            continue
        model = registration['pools'][case]
        end = datetime.fromisoformat(model['deadline'])
        for stage, indices in model['layers'].items():
            for i in indices:
                label, value = measured['labels'][i]
                if label != 'sweep':
                    continue
                target = model['targets'][i]
                known = datetime.fromisoformat(value)
                if not ready + M5 <= known <= end:
                    raise ValueError(f'Crossing timestamp is outside its registered observation window: {known}')
                events[(known, target['side'], forward.quotes.far(target))].add(f'{case}/{stage}')
    return events


def capture(events, settlement):
    if not events:
        return [], [], []
    first, last = min(events)[0], max(events)[0]
    with forward.terminal() as (api, clock):
        bars = forward.quotes.collect_bars(api, first - 16*M5, last + FOLLOWUP, clock)
    times = [b.time for b in bars]
    original = {datetime.fromisoformat(t): values for t, *values in settlement['quotes']}
    fetched = {b.time: list(forward.quotes.ohlc(b)) for b in bars}
    records, mismatches = [], []
    for (stamp, side, edge), groups in sorted(events.items()):
        opened = stamp-M5
        if opened not in original or original[opened] != fetched.get(opened):
            mismatches.append(dict(crossing_at=stamp.isoformat(), side=side, edge=edge, groups=sorted(groups)))
            continue
        records.append(dict(replay.evaluate_crossing(bars, times, stamp, side, edge), groups=sorted(groups)))
    tape = [[b.time.isoformat(), *forward.quotes.ohlc(b)] for b in bars]
    return records, mismatches, tape


def settle(policy, as_of):
    frozen = datetime.fromisoformat(policy['frozen_at'])
    states = Counter()
    for source in sorted((forward.OUT/'settlements').glob('*.json')):
        output = OUT/'settlements'/source.name
        if output.exists():
            states['settled'] += 1
            continue
        registration_path = forward.OUT/'registrations'/(source.stem.rsplit('_',1)[0]+'.json')
        registration = json.loads(registration_path.read_bytes())
        if datetime.fromisoformat(registration['eligible_from']) < frozen:
            states['before_verdict_freeze'] += 1
            continue
        settlement = json.loads(source.read_bytes())
        if (registration['policy_sha256'] != forward.quotes.digest(forward.POLICY)
                or settlement['registration_sha256'] != forward.quotes.digest(registration_path)):
            raise ValueError(f'Source registration differs from the locked bytes: {source.name}')
        events = extract_events(registration,settlement)
        if events and max(events)[0] + FOLLOWUP > as_of:
            states['waiting_for_followup'] += 1
            continue
        observations, mismatches, tape = capture(events,settlement)
        forward.atomic_json(output, dict(
            policy_sha256=forward.quotes.digest(POLICY), registration_sha256=settlement['registration_sha256'],
            source_settlement_sha256=forward.quotes.digest(source), frozen_cutoff=registration['cutoff'],
            observed_at=as_of.isoformat(), observations=observations, quote_disagreements=mismatches, quotes=tape,
            orders_sent=0,
        ))
        states['settled'] += 1
    return states


def summarize():
    evidence, groups = {}, defaultdict(set)
    conflicts = set()
    mismatches = 0
    for p in sorted((OUT/'settlements').glob('*.json')):
        saved = json.loads(p.read_bytes())
        if saved['policy_sha256'] != forward.quotes.digest(POLICY):
            raise ValueError(f'Sweep verdict settlement was made under a different policy: {p.name}')
        mismatches += len(saved['quote_disagreements'])
        for row in saved['observations']:
            key = datetime.fromisoformat(row['crossing_at']), row['side'], row['edge']
            memberships = row.pop('groups')
            if key in evidence and evidence[key] != row:
                conflicts.add(key)
            evidence[key] = row
            for group in memberships:
                groups[group].add(key)
    return dict(
        distinct_crossings=len(evidence)-len(conflicts), conflicting_captures=len(conflicts),
        source_quote_disagreements=mismatches,
        comparisons={g: {str(n):replay.describe(keys-conflicts,evidence,n) for n in replay.WINDOWS}
                     for g,keys in groups.items()},
    )


def poll(policy):
    observed = forward.now()
    return dict(observed_at=observed.isoformat(), frozen_at=policy['frozen_at'],
                states=settle(policy,observed), **summarize(), orders_sent=0)


def main():
    import msvcrt

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('once','watch'))
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT/'watch.lock').open('a+b') as lock:
        if lock.tell() == 0:
            lock.write(b'0')
            lock.flush()
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        except OSError as exc:
            raise SystemExit('A sweep verdict recorder is already active') from exc
        policy = load_policy()
        while True:
            try:
                status = poll(policy)
            except RuntimeError as exc:
                status = dict(observed_at=forward.now().isoformat(), error=str(exc), orders_sent=0)
            forward.atomic_json(OUT/'status.json',status)
            if args.mode == 'once':
                print(json.dumps(status,ensure_ascii=False))
                break
            sleep(20)


if __name__ == '__main__':
    main()
