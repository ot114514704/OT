"""Produce a portable M15/H1 chart of archived XAUUSD examples, without a terminal."""
from argparse import ArgumentParser
from collections import Counter, defaultdict
from datetime import timedelta
from html import escape
from pathlib import Path

from brooks_ai.types import utc_time
from ict_ai.amd import amd_events
from ict_ai.timebase import NY
from scripts.audit_profile_one_daily_context import load_tmgm
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_news import STEP


def draw(cycle, bars, period):
    a = cycle[0]
    end = utc_time(cycle[-1]["available_at"])
    start = utc_time(a["start"])
    rows = [b for b in bars if start-2*period <= b.time < end]
    low,high = min(b.low for b in rows),max(b.high for b in rows)
    dx = 670 / len(rows)
    x = {b.time:30+(i+.5)*dx for i,b in enumerate(rows)}
    y = lambda p: 199-168*(p-low)/(high-low)
    pieces = ['<svg role="img" aria-label="存档黄金K线和各阶段实际范围" viewBox="0 0 788 225">']
    for e in cycle:
        left = x[utc_time(e["start"])]-dx/2
        right = x[utc_time(e["end"])-period]+dx/2
        color = {"A":"#698fa5","M":"#c05855","D":"#198466"}[e["phase"]]
        top = y(e["upper"])
        pieces.append(f'<rect x="{left}" y="{top}" width="{right-left}" height="{y(e["lower"])-top}" fill="{color}" fill-opacity=".10" stroke="{color}"/>'
                      f'<text x="{left+2}" y="{top-4}" fill="{color}">{e["phase"]}</text>')
    for b in rows:
        ink = "#157b6b" if b.close>=b.open else "#ae474d"
        pieces.append(f'<g><title>{b.time.astimezone(NY):%m-%d %H:%M} NY · O {b.open:.2f} H {b.high:.2f} L {b.low:.2f} C {b.close:.2f}</title>'
                      f'<path stroke="{ink}" d="M{x[b.time]} {y(b.high)}V{y(b.low)}"/>'
                      f'<rect x="{x[b.time]-.27*dx}" y="{y(max(b.open,b.close))}" width="{.54*dx}" height="{max(1,abs(y(b.close)-y(b.open)))}" fill="{ink}"/></g>')
    for edge in (a["range_low"],a["range_high"]):
        left = x[utc_time(a["end"])-period]+dx/2
        pieces.append(f'<path stroke="#687981" stroke-dasharray="3 3" d="M{left} {y(edge)}H706"/><text x="710" y="{y(edge)+4}">{edge:.2f}</text>')
    return ''.join(pieces)+'</svg>'


def run(path):
    archive,_ = load_tmgm()
    cutoff = archive[-1].time+STEP
    counts,examples = [], {}
    for minutes in (15,60):
        period = timedelta(minutes=minutes)
        bars=aggregate_bars(archive,5,minutes,cutoff)
        groups=defaultdict(list)
        for event in amd_events(bars,period,cutoff):
            groups[event["id"]].append(event)
        counts.append(Counter(g[-1]["route"] for g in groups.values()))
        for cycle in groups.values():
            if cycle[-1]["route"]!="AMD":
                continue
            a=cycle[0]
            family=a["shape"].split("_")[-1]
            if family not in ("overlapping","triangle","wedge","channel"):
                continue
            examples[family]=(cycle,bars,period)
    sections=[]
    for cycle,bars,period in examples.values():
        for e in cycle:
            at=utc_time(e["available_at"])
            prefix=[b for b in bars if b.time+period<=at]
            if e not in amd_events(prefix,period,at):
                raise ValueError("Archived stage cannot be reproduced at its time of confirmation")
        d=cycle[-1]
        times="　→　".join(f'{e["phase"]} {utc_time(e["available_at"]).astimezone(NY):%m-%d %H:%M}' for e in cycle)
        sections.append(f'<section><h2>{escape(d["shape_label"])} · {int(period.total_seconds()/60)} 分钟 · '
                        +('向上' if d["direction"]=="bullish" else '向下')+'派发</h2>'+draw(cycle,bars,period)
                        +f'<p>收线确认　{times} NY</p></section>')
    period_text=f'{archive[0].time.astimezone(NY):%Y-%m-%d} 至 {archive[-1].time.astimezone(NY):%Y-%m-%d}'
    path.write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                    '<title>黄金 AMD · 多形态积累</title><style>body{font:16px/1.65 system-ui;max-width:880px;margin:3vw auto;padding:1rem;color:#213b43}h1{font-size:1.75rem}h2{font-size:1.15rem}svg{width:100%;background:#fafbf9}svg text{font:13px system-ui}section{border-top:1px solid #ccd7d8;margin-top:1.7rem}</style>'
                    f'<h1>黄金 AMD · 多形态积累</h1><p>TMGM XAUUSD · {period_text} · 纽约时间。离线识别器在 M15 找到 {counts[0]["AMD"]} 条完整路径，H1 找到 {counts[1]["AMD"]} 条。'
                    '方框表示各阶段覆盖的行情，虚线从 A 确认时开始标出冻结边界。每类展示一个已完成案例，鼠标移到 K 线上可查报价。</p>'
                    +''.join(sections)+'</html>',encoding="utf-8")
    print(counts)


if __name__=="__main__":
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("out",type=Path)
    run(parser.parse_args().out)
