"""Offline sensitivity study of the follow-through deadline for the course's double sweep day."""
from argparse import ArgumentParser
from collections import Counter
from datetime import datetime, time, timedelta
from hashlib import sha256
import json
from pathlib import Path

from brooks_ai.types import utc_time
from ict_ai.profile_lifecycle import _day_bounds, _extension, daily_profile_lifecycle
from ict_ai.timebase import NY
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_news import ROOT, STEP
from scripts.review_profile_one_history import load_closed_history


PERIOD = timedelta(minutes=15)
DEADLINES = (10, 11, 12, 16)


def load_reviews(sources):
    reviews, hashes = {}, {}
    for cohort in ("review","validation"):
        manual_path = ROOT/f"research/ict_profile_price_{cohort}_20261121.json"
        key_path = ROOT/f"tmp/ict_price_{cohort}_key.json"
        chart_path = ROOT/f"output/visualizations/ict-price-{cohort}-cases.html"
        manual = json.loads(manual_path.read_bytes())
        key = json.loads(key_path.read_bytes())
        digest = sha256(chart_path.read_bytes()).hexdigest()
        if (digest != manual["chart_sha256"] or digest != key["chart_sha256"]
                or sources != key["sources"] or key["sampling"] != manual["sampling"]):
            raise ValueError("Chart or quote source differs from frozen review")
        for case in manual["cases"]:
            if " · " in case["id"]:
                day = key["keys"][case["id"]]
                if day in reviews:
                    raise ValueError("Overlapping review dates")
                reviews[day] = {"cohort":cohort,"labels":case["labels"],"evidence":case["evidence"]}
        hashes[cohort] = {"chart_sha256":digest,"review_sha256":sha256(manual_path.read_bytes()).hexdigest()}
    return reviews, hashes


def freeze(rows, quotes, d, at):
    return daily_profile_lifecycle(rows,d,at,PERIOD,False,reference_m5=quotes)


def evaluate(bars, friday, reviews):
    days, excluded = [], []
    counts = {h:Counter() for h in DEADLINES}
    total_checks = 0
    all_quarters = aggregate_bars(bars,5,15,_day_bounds(friday)[1])
    for d in sorted({b.time.astimezone(NY).date() for b in bars if b.time.astimezone(NY).weekday()<5}):
        start, end = _day_bounds(d)
        floor = _day_bounds(d-timedelta(days=d.weekday()+1))[0]
        quotes = [b for b in bars if floor<=b.time<end]
        rows = [b for b in all_quarters if floor<=b.time<end]
        final = freeze(rows,quotes,d,end)
        if not final.get("coverage_complete_under_study_calendar"):
            excluded.append(str(d))
            continue
        at = datetime.combine(d,time(10),NY)
        # Only the extension clock is varied. Both the early trend and the
        # counter-sweep must have qualified by the original NY session end.
        morning = freeze(rows,quotes,d,at)
        cutoff_rows = [b for b in rows if b.time+PERIOD<=at]
        cutoff_quotes = [b for b in quotes if b.time+STEP<=at]
        if morning != freeze(cutoff_rows,cutoff_quotes,d,at):
            raise AssertionError("Lookahead in morning selection")
        total_checks += 1
        result = {"date":str(d),"frozen_chart_review":reviews.get(str(d)),"sides":[]}
        expected = {c["direction"] for c in final["actual_paths"] if c["id"]=="double_sweep"}
        seen = {h:set() for h in DEADLINES}
        for card in morning["candidates"]:
            # A 09:00 candidate can fail before 10:00. Count its live evidence
            # at the follow-through bar and its invalidation independently.
            if card["id"]!="double_sweep" or not card["observed_sequence"]:
                continue
            s = card["direction"]
            checks = morning["session_price_checks"]
            reclaim_at = utc_time(checks["ny_sweep_low_reclaim" if s==1 else "ny_sweep_high_reclaim"])
            edge = checks["london"]["high" if s==1 else "low"]
            day_rows = [b for b in rows if start<=b.time]
            following = _extension(day_rows,edge,s,PERIOD,reclaim_at)
            known = following.time+PERIOD if following else None
            close_card = next(c for c in final["candidates"] if c["id"]=="double_sweep" and c["direction"]==s)
            holds = s*(final["daily_price_basis"]["close"]-edge)>0
            alive_at_follow = False
            if known:
                partial = [b for b in rows if b.time+PERIOD<=known]
                ref = [b for b in quotes if b.time+STEP<=known]
                recovered = _extension(partial,edge,s,PERIOD,reclaim_at)
                if recovered != following or _extension(partial[:-1],edge,s,PERIOD,reclaim_at):
                    raise AssertionError("Incorrect time of first observable extension")
                then = freeze(partial,ref,d,known)
                alive_at_follow = any(c["id"]=="double_sweep" and c["direction"]==s and c["status"]=="active"
                                      for c in then["candidates"])
                total_checks += 1
            result["sides"].append({"direction":s,"reclaim_ny":reclaim_at.astimezone(NY).isoformat(),
                                    "edge":edge,"two_closes_known_ny":known.astimezone(NY).isoformat() if known else None,
                                    "active_at_follow":alive_at_follow,"status_at_day_close":close_card["status"],
                                    "day_close_outside_edge":holds})
            for h in DEADLINES:
                if known and known<=datetime.combine(d,time(h),NY) and alive_at_follow:
                    counts[h]["observed_before_deadline"]+=1
                    if close_card["status"]=="active" and holds:
                        seen[h].add(s)
        if seen[10] != expected:
            raise AssertionError(f"Baseline mismatch on {d}: {seen[10]} vs {expected}")
        for h in DEADLINES:
            counts[h]["matching_day_close"] += len(seen[h])
            if str(d) in reviews:
                chart = {1 if side=="bullish" else -1 for name,side in reviews[str(d)]["labels"] if name=="double_sweep"}
                counts[h]["reviewed_days"]+=1
                counts[h]["review_positive"]+=len(chart)
                counts[h]["review_supported"]+=len(chart & seen[h])
                counts[h]["review_disagreed"]+=len(seen[h]-chart)
                counts[h]["review_missed"]+=len(chart-seen[h])
        result["close_match_directions"] = {h:sorted(sides) for h,sides in seen.items()}
        days.append(result)
    if set(reviews)-{r["date"] for r in days}:
        raise ValueError("Incomplete chart sample")
    return {"coverage_days":len(days),"excluded":excluded,"time_checks":total_checks,"by_deadline":counts,"days":days}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    for name in ("early","late","extension","out"):
        parser.add_argument("--"+name,type=Path,required=True)
    args = parser.parse_args()
    bars,sources,_,friday,_,_ = load_closed_history(args.early,args.late,args.extension)
    reviews, hashes = load_reviews(sources)
    report = evaluate(bars,friday,reviews)
    report.update(quote_sources=sources, friday_replay_sha256=sha256(args.extension.read_bytes()).hexdigest(),
                  frozen_reviews=hashes, clock="New York; M15 closed bars", source_video_seconds=[1095,1190],
                  limits="Same-sample sensitivity; 11/18 motivated the trial. Chart reviews by the same analyst. "
                         "Trade returns, prior bias, and news causality are not measured.")
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report["by_deadline"]))
