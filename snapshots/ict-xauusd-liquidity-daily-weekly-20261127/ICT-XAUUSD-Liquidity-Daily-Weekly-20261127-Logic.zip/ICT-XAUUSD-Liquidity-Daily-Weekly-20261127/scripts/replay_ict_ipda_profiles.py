"""Offline study of the user's course profiles with the IPDA project's closed-bar evidence."""
from argparse import ArgumentParser
from bisect import bisect_right
from collections import Counter
from datetime import date, datetime, time, timedelta
from functools import partial
from hashlib import sha256
import json
from pathlib import Path
import sys

from brooks_ai.types import Instrument, utc_time
from ict_ai.backtest import LimitStudyOrder
from ict_ai.portfolio import replay_portfolio
from ict_ai.profile_lifecycle import _day_bounds, daily_profile_lifecycle, weekly_profile_lifecycle
from ict_ai.profile_sources import WEEKLY
from ict_ai.timebase import NY, session_windows
from ict_ai.weekly_path import weekly_path
from scripts.backtest_ict_motifs import motif_order
from scripts.replay_ict_news import ROOT, STEP, load_history
from scripts.replay_ict_route_checkpoints import merge_history
from scripts.prepare_ict_week import aggregate_bars


def active_profiles(review):
    return [c for c in review["candidates"] if c["status"] == "active" and c["observed_sequence"]]


def freeze_day(bars, day, at, *, research=False, ny_reclaim=False):
    return daily_profile_lifecycle(bars, day, at, STEP, False, reference_m5=bars,
                                   research_late_classic_and_longer_range=research,
                                   research_ny_reclaim=ny_reclaim)


def freeze_week(bars, days, at):
    return weekly_profile_lifecycle(bars, days, at, weekly_path(bars, days, at), STEP)


def match_summary(rows):
    return dict(Counter(row["result"] for row in rows))


def match_row(forecast, outcome, covered):
    result = ("unscored_incomplete" if not covered else "no_candidate_at_cutoff" if not forecast else
              "candidate_matched_close" if forecast & outcome else "candidate_unmatched_at_close")
    return {"forecast": sorted(forecast, key=str), "close_review": sorted(outcome, key=str), "result": result,
            "exact_match_if_candidate": forecast == outcome if covered and forecast else None,
            "missed_class_if_abstained": not forecast and bool(outcome) if covered else None}


def score_weekly_candidates(first, final):
    def keys(cards):
        result = set()
        for card in cards:
            ident = card.get("id")
            if ident not in WEEKLY or not card.get("observed_sequence") or card.get("path_complete") is False:
                continue
            side = card.get("direction")
            if ident != "weekly_seek_destroy" and side not in (-1,1):
                raise ValueError(f"Missing observed direction for weekly shape {ident}")
            result.add((ident,side))
        return result
    proposed = keys(active_profiles(first))
    realized = keys(final.get("realized_candidates",[]))
    covered = final["week_ended"] and final["coverage_complete_under_study_calendar"]
    signed = match_row(proposed,realized,covered)
    shapes = match_row({s for s,_ in proposed},{s for s,_ in realized},covered)
    # The pre-existing lists of shape names are used by archived chart reviews,
    # whose labels carry no direction. Keep these separately from signed scores.
    return {**signed,"directional_forecast":signed["forecast"],"directional_close_review":signed["close_review"],
            "forecast":shapes["forecast"],"close_review":shapes["close_review"],"shape_only_result":shapes["result"]}


def check_reclaim_prefixes(bars, day, day_at, traces):
    points = set()
    for trace in traces:
        for key in ("london_known_at", "ny_reclaim_known_at", "ny_expansion_known_at", "extreme_broken_known_at"):
            if trace[key]:
                stamp = utc_time(trace[key])
                points.update((stamp - STEP, stamp))
    for at in sorted(points):
        full = day_at(bars, day, at)
        if full != day_at([bar for bar in bars if bar.time + STEP <= at], day, at):
            raise AssertionError(f"Future candles changed NY reclaim at {at}")
        for path in full.get("research_ny_reclaim_sequences", []):
            expanding = path["ny_expansion_known_at"]
            if path["active_for_replay"] and (expanding is None or utc_time(expanding) > at):
                raise AssertionError(f"NY reclaim entered replay before confirmation at {at}")
    return len(points)


def profile_checks(bars, cutoff, days, day_at):
    daily, weekly = [], []
    transition_checks = 0
    for day in days:
        at = utc_time(datetime.combine(day, time(10), NY))
        if at > cutoff:
            continue
        first = day_at(bars, day, at)
        if first != day_at([bar for bar in bars if bar.time + STEP <= at], day, at):
            raise AssertionError("Future bars changed the fixed daily classification")
        end = _day_bounds(day)[1]
        final = day_at(bars, day, min(end, cutoff))
        keys = lambda cards: {(c["id"], c["direction"]) for c in cards}
        daily.append({"date": str(day), "forecast_reason": first["profile_reason"],
                      "close_review_reason": final["profile_reason"],
                      **match_row(keys(active_profiles(first)), keys(final["actual_paths"]),
                                  end <= cutoff and final.get("coverage_complete_under_study_calendar"))})
        if "research_ny_reclaim_sequences" in final:
            traces = final["research_ny_reclaim_sequences"]
            transition_checks += check_reclaim_prefixes(bars, day, day_at, traces)
            daily[-1]["ny_reclaim_trial"] = {"forecast": first.get("research_ny_reclaim_sequences", []),
                                             "close_review": traces}
    mondays = sorted({day - timedelta(days=day.weekday()) for day in days})
    for monday in mondays:
        week = [monday + timedelta(days=i) for i in range(5)]
        at, end = _day_bounds(week[2])[1], _day_bounds(week[4])[1]
        if at > cutoff:
            continue
        first = freeze_week(bars, week, at)
        if first != freeze_week([bar for bar in bars if bar.time + STEP <= at], week, at):
            raise AssertionError("Future bars changed the fixed weekly classification")
        final = freeze_week(bars, week, min(cutoff, end))
        weekly.append({"monday": str(monday), "forecast_reason": first["profile_reason"],
                       "close_review_reason": final["profile_reason"], **score_weekly_candidates(first,final)})
    return {"daily_cutoff": "NY 10:00", "weekly_cutoff": "Wednesday NY day close",
            "prefix_checks": len(daily) + len(weekly),
            **({"ny_reclaim_transition_prefix_checks": transition_checks} if transition_checks else {}),
            "daily": daily, "weekly": weekly, "daily_counts": match_summary(daily),
            "weekly_counts": match_summary(weekly)}


def previous_phase(tape, at, seconds):
    times, rows = tape
    index = bisect_right(times, at) - 1
    if index < 0 or at - times[index] >= timedelta(seconds=seconds):
        return None
    p = rows[index]
    return {key: p[key] for key in ("phase", "direction", "known_at", "reference_before",
                                    "pda_contacts", "reason", "source_seconds")}


def phase_evidence(phase, side):
    if phase is None:
        return "missing_recent_closed_bar"
    if phase["phase"] == "retracement":
        origin = phase["reference_before"] or {}
        if origin.get("direction") not in (-1, 1):
            return "retracement_without_directional_reference"
        if origin["direction"] != side:
            return "retracement_of_opposing_reference"
        return "supported" if phase["pda_contacts"] else "retracement_without_pda_contact"
    if phase["phase"] in ("expansion", "reversal"):
        return "supported" if phase["direction"] == side else "opposing_" + phase["phase"]
    return phase["phase"]


def time_filter(day, at):
    windows = session_windows(day)
    return next((key for key in ("london", "new_york") if windows[key][0] < at <= windows[key][1]), None)


def panel_week_at(bars, quarters, at):
    day=at.astimezone(NY).date()
    monday=day-timedelta(days=day.weekday())
    days=[monday+timedelta(days=i) for i in range(5)]
    start, end=_day_bounds(monday)[0], _day_bounds(days[-1])[1]
    week=[bar for bar in bars if start<=bar.time<end]
    m15=[bar for bar in quarters if start<=bar.time<end]

    def state(raw, aggregated):
        return weekly_profile_lifecycle(aggregated,days,at,weekly_path(raw,days,at),timedelta(minutes=15))

    closed=[bar for bar in week if bar.time+STEP<=at]
    frozen=state(closed,aggregate_bars(closed,5,15,at))
    if frozen!=state(week,m15):
        raise AssertionError(f"Future prices altered weekly evidence at {at}")
    if frozen["mode"]!="intraweek_hypothesis":
        raise ValueError("Expected an intraperiod signal")
    active=[{"id":c["id"],"direction":c["direction"]} for c in active_profiles(frozen) if c["id"] in WEEKLY]
    return {"at":at.isoformat(),"covered":frozen["coverage_complete_under_study_calendar"],
            "active":active,"reason":frozen["profile_reason"]}


def weekly_order_cohorts(orders, observations):
    groups={"week_coverage_only":[],"without_opposing_week":[],"only_matching_week":[]}
    for order in orders:
        view=observations[order.available_at]
        if not view["covered"]:
            continue
        groups["week_coverage_only"].append(order)
        sides={c["direction"] for c in view["active"] if c["direction"] is not None}
        if -order.side not in sides:
            groups["without_opposing_week"].append(order)
        if sides=={order.side}:
            groups["only_matching_week"].append(order)
    return groups


def replay_cases(path, source_hashes, all_bars, tapes, spec, day_at):
    raw = path.read_bytes()
    source = json.loads(raw)
    if source["data_sha256"] not in source_hashes or source["period_minutes"] != 5 or not source["prefix_stability_passed"]:
        raise ValueError("Require the prior verified M5 structure universe")
    rows, orders = [], {}
    for day_record in source["days"]:
        day = date.fromisoformat(day_record["date"])
        by_id = {event["id"]: event for event in day_record["events"]}
        for event in by_id.values():
            if event["kind"] != "sweep_mss_fvg_candidate":
                continue
            at = utc_time(event["available_at"])
            sweep = utc_time(by_id[event["sweep_id"]]["sweep_started_at"])
            side = event["side"]
            phase = previous_phase(tapes[15], sweep, 900)
            phase_at_signal = previous_phase(tapes[15], at, 900)
            sweep_evidence = phase_evidence(phase, side)
            signal_evidence = phase_evidence(phase_at_signal, side)
            prior_h1 = previous_phase(tapes[60], sweep, 3600)
            day_view = day_at(all_bars, day, at)
            prefix = [b for b in all_bars if b.time + STEP <= at]
            if day_view != day_at(prefix, day, at):
                raise AssertionError("Future candles changed the signal's profile context")
            cards = active_profiles(day_view)
            paths = {c["direction"] for c in cards if c["direction"] is not None}
            week = day_view["weekly_background"]
            window = time_filter(day, at)
            reasons = []
            if not window:
                reasons.append("outside_course_london_or_ny_window")
            if sweep_evidence != "supported":
                reasons.append("no_same_direction_prior_IPDA_phase_or_pda_retracement")
            if paths and paths != {side}:
                reasons.append("opposite_or_mixed_daily_path")
            if week["scenario_direction"] == -side:
                reasons.append("opposite_weekly_scenario")
            profiles_pass = (not paths or paths == {side}) and week["scenario_direction"] != -side
            orders[event["id"]] = motif_order(event, spec)
            rows.append({"id": event["id"], "ny_day": str(day), "signal_at_ny": at.astimezone(NY).isoformat(),
                         "side": side, "prior_sweep_h1": prior_h1, "prior_sweep_m15": phase,
                         "daily_candidates": [{"id": c["id"], "direction": c["direction"]} for c in cards],
                         "weekly_scenario": week, "course_window": window, "combined_rejections": reasons,
                         "sweep_at": sweep.isoformat(), "at_signal_m15": phase_at_signal,
                         "prior_sweep_phase_evidence": sweep_evidence, "at_signal_phase_evidence": signal_evidence,
                         "daily_and_weekly_nonopposition": profiles_pass})
    return rows, orders, sha256(raw).hexdigest()


def direct_ipda_boxes(model, bars, days, all_bars, spec, day_at):
    sample_days = set(days)
    cases, orders = [], []
    for row in model["rows"]:
        if row["event"] != "breakout_confirmed":
            continue
        at = utc_time(row["known_at"])
        day = at.astimezone(NY).date()
        if day not in sample_days:
            continue
        box = row["ended"]
        # Count any observed prior reclaim separately. A lack of reclaim
        # evidence does not prove that no wick excursion occurred.
        side = box["side"]
        branch = "no_prior_confirmed_reclaim" if box["sweep_count"] == 0 else "earlier_reclaim_observed"
        window = time_filter(day, at)
        day_view = day_at(all_bars, day, at)
        direction = day_view["weekly_background"]["scenario_direction"]
        daily = {card["direction"] for card in active_profiles(day_view) if card["direction"] is not None}
        entry = box["liquidity_hi"] if side == 1 else box["liquidity_lo"]
        stop = (box["liquidity_lo"] if side == 1 else box["liquidity_hi"]) - side * spec.tick_size
        passed = window is not None and direction != -side and (not daily or daily == {side})
        identity = f"IPDA_box_{at.isoformat()}"
        if window is not None:
            orders.append(LimitStudyOrder(identity, side, at, at + 90 * timedelta(minutes=1), entry, stop,
                                          entry + 2 * (entry - stop), spec.volume_min))
        cases.append({"id": identity, "date": str(day), "confirmed_at_ny": at.astimezone(NY).isoformat(),
                      "frozen_range_known_at": bars[box["confirmed"]].closed_at.isoformat(),
                      "wick_low": box["liquidity_lo"], "wick_high": box["liquidity_hi"],
                      "body_low": box["lo"], "body_high": box["hi"], "branch": branch, "side": side,
                      "course_window": window, "weekly_scenario_direction": direction,
                      "daily_scenario_directions": sorted(daily), "included": passed})
    return cases, orders


def run(ipda_project, early, late, source_paths, *, research=False, ny_reclaim=False,
        continuous_account=False):
    sys.path.insert(0, str(ipda_project))
    from ict_trader.core import Bar, aggregate
    from ict_trader.ipda_phases import detect_phases
    from ict_trader.ipda_ranges import observe_ranges

    if ipda_project.resolve() not in Path(detect_phases.__code__.co_filename).resolve().parents:
        raise ValueError("IPDA module did not resolve to the selected project")
    quotes, source_manifest, _, cutoff = merge_history(early, late)
    bars = list(quotes.values())
    meta, _, _ = load_history(late)
    info = meta["current_symbol_observation"]
    spec = Instrument(meta["symbol"], info["point"], info["trade_tick_size"], info["trade_contract_size"],
                      info["volume_min"], info["volume_step"], info["volume_max"],
                      account_currency=meta["account_currency"], profit_currency=info["currency_profit"],
                      commission_round_turn=7, slippage=.05)
    ipda_bars = [Bar(b.time, b.open, b.high, b.low, b.close, b.spread) for b in bars]
    tapes, inputs = {}, {}
    for minutes in (15, 60):
        group = aggregate(ipda_bars, minutes * 60, cutoff)
        data = detect_phases(group, cutoff, timeframe_seconds=minutes * 60)
        dates = [utc_time(row["known_at"]) for row in data]
        tapes[minutes] = (dates, data)
        inputs[minutes] = group
        # Rebuild a predetermined midpoint independently, with and without later bars.
        index = len(group) // 2
        at = dates[index]
        if detect_phases(group[:index + 1], at, timeframe_seconds=minutes * 60) != data[:index + 1]:
            raise AssertionError("Later IPDA bars changed prior phase observations")
    hashes = {row["quote_sha256"] for row in source_manifest}
    day_at = partial(freeze_day, research=research, ny_reclaim=ny_reclaim)
    config = json.loads((ROOT / "config/strategy.json").read_bytes())
    risk = {key: config[key] for key in ("risk_fraction", "daily_loss_limit", "max_drawdown", "max_consecutive_losses")}
    portfolio = lambda orders, end: replay_portfolio(orders, bars, spec, end, config["initial_equity"], risk)
    panel_m15=aggregate_bars(bars,5,15,cutoff)
    phase_data = observe_ranges(inputs[15], cutoff, breakout_basis="liquidity")
    box_index = len(inputs[15]) // 2
    box_at = inputs[15][box_index].closed_at
    if observe_ranges(inputs[15][:box_index + 1], box_at, breakout_basis="liquidity")["rows"] != (
            phase_data["rows"][:box_index + 1]):
        raise AssertionError("Later IPDA bars changed prior box observations")
    experiments, days = [], []
    combined_orders, account_spans = {}, []
    for path in source_paths:
        payload = json.loads(path.read_bytes())
        dates = [date.fromisoformat(d["date"]) for d in payload["days"]]
        if continuous_account:
            first, last = min(dates), max(dates)
            if len(set(dates)) != len(dates) or any(
                    first <= end and start <= last for start, end in account_spans):
                raise ValueError("Continuous replay requires disjoint date ranges without duplicate days")
            account_spans.append((first, last))
        days.extend(dates)
        rows, orders, digest = replay_cases(path, hashes, bars, tapes, spec, day_at)
        bound = min(cutoff, _day_bounds(max(dates))[1])
        boxes, direct = direct_ipda_boxes(phase_data, inputs[15], dates, bars, spec, day_at)
        allowed_boxes = {row["id"] for row in boxes if row["included"]}
        cohorts = {
            "time_window_only": [orders[r["id"]] for r in rows if r["course_window"]],
            "time_ipda_daily_weekly": [orders[r["id"]] for r in rows if not r["combined_rejections"]],
            "structure_time_daily_weekly_only": [orders[r["id"]] for r in rows
                                                 if r["course_window"] and r["daily_and_weekly_nonopposition"]],
            "structure_time_signal_ipda_daily_weekly": [
                orders[r["id"]] for r in rows if r["course_window"] and r["daily_and_weekly_nonopposition"]
                and r["at_signal_phase_evidence"] == "supported"],
            "ipda_boxes_time_only": direct,
            "ipda_boxes_time_and_profiles": [order for order in direct if order.id in allowed_boxes],
        }
        snapshots={at:panel_week_at(bars,panel_m15,at) for at in sorted({
            order.available_at for order in cohorts["time_window_only"]+direct})}
        for family, templates in (("structure",cohorts["time_window_only"]),("ipda_box",direct)):
            for policy, book in weekly_order_cohorts(templates,snapshots).items():
                cohorts[f"{family}_{policy}"]=book
        if continuous_account:
            for name, templates in cohorts.items():
                combined_orders.setdefault(name, []).extend(templates)
        experiments.append({"source_replay": str(path), "sha256": digest, "cases": rows, "box_cases": boxes,
                            "weekly_at_signal":[view for view in snapshots.values()],
                            "weekly_policy_candidates":{k:[o.id for o in book] for k,book in cohorts.items()},
                            "portfolios": {name: portfolio(book, bound) for name, book in cohorts.items()}})
    sources = {
        str(p): sha256(p.read_bytes()).hexdigest() for p in (
            ROOT / "research/ict_time_videos/time2_daily/integration.json",
            ROOT / "research/ict_time_videos/time3_weekly/integration.json",
            ipda_project / "research/price_courses/ipda_phase_rules.json",
            ipda_project / "research/ipda_consolidation_rules.json",
            *(Path(m.__file__) for k, m in sys.modules.items() if k.startswith("ict_trader") and m.__file__),
        )
    }
    paths = (Path(__file__), ROOT / "ict_ai/profile_lifecycle.py", ROOT / "ict_ai/weekly_path.py",
             ROOT / "ict_ai/portfolio.py", ROOT / "ict_ai/backtest.py", ROOT / "config/strategy.json",
             ROOT / "scripts/prepare_ict_week.py",ROOT / "ict_ai/profile_sources.py")
    combined = {}
    if continuous_account:
        end = min(cutoff, _day_bounds(max(days))[1])
        combined["continuous_account"] = {
            "ny_source_date_ranges": sorted(account_spans), "cutoff": end,
            "policy": "One independent account per policy across all supplied date ranges. "
                      "Equity, pending orders, unresolved exposure and loss stops carry forward.",
            "portfolios": {name: portfolio(orders, end) for name, orders in combined_orders.items()}}
    return {"quote_sources": source_manifest, "rules_sha256": sources, "experiments": experiments, **combined,
            "code_sha256": {str(path): sha256(path.read_bytes()).hexdigest() for path in paths},
            "ipda_model_prefix_checks": 3,
            "trade_protocol": {
                "weekly_direction_comparison":"At each time-window-qualified signal freeze the panel's M15 weekly "
                    "candidates. Compare the original eligible orders with excluding any opposing direction "
                    "(allow no directional candidate), and with requiring solely the intended direction. "
                    "Both trials require week-to-date coverage. A coverage-only control isolates the cost "
                    "of discarding incomplete history. Each book is simulated independently.",
                "structure_baseline": "Closed Asia sweep/MSS/FVG motif inside the project's London or NY study window.",
                "structure_ipda_trial": "Prior M15 local phase in the intended direction, or in-range retracement with a PDA contact. Reject contrary or mixed current daily paths or an opposite weekly scenario.",
                "structure_filter_diagnosis": "Use the same M5 signals and independent accounts. Compare daily and "
                    "weekly non-opposition alone, adding the M15 phase at the initial sweep, or adding the M15 "
                    "phase at signal confirmation. Each observation uses the latest completed M15 bar as of "
                    "the indicated timestamp. A matching phase at confirmation can reflect the same move "
                    "as the M5 signal. The daily classifier's weekly scenario and the panel's lifecycle "
                    "candidates are recorded separately.",
                "box_trial": "Native IPDA confirmed M15 wick-range break. An optional daily and weekly non-opposition filter uses only candidates already observable at confirmation.",
                "h1_use": "Recorded before the motif sweep for diagnosis; H1 is not an independent bias assertion.",
            },
            "classification_checks": profile_checks(bars, cutoff, sorted(set(days)), day_at),
            "daily_research_rule": ("Classic 1.1 may extend through the NY 10:00–12:00 London-close window; "
                                    "direct consolidation expansion requires 90 minutes from NY midnight to A confirmation."
                                    if research else None),
            **({"daily_ny_reclaim_research_rule":
                "A London extreme beyond Asia stays observation only. After a NY close crosses the Asia boundary, "
                "count two consecutive NY closes beyond both the Asia boundary and the opposite London edge. "
                "A later breach of the London extreme invalidates the path. Keep both edges at daily close. "
                "The reclaim close may be the first of the two."
                } if ny_reclaim else {}),
            "execution_cost_assumptions": {"commission_round_turn_per_lot": 7, "slippage": .05, "target": "2R"},
            "limits": [
                "Paper mechanics use learning hypotheses. M15/H1 IPDA stages and intraperiod course scenarios do not supply verified D1 bias, HTF PDA, DOL or a vintage calendar.",
                "M5 bid bars with constant spread proxy. Independent quotes and broker fees unavailable for most days.",
                "Predeclared coarse profile cutoffs compare membership against the close rules. Agreement is not independent human-reviewed accuracy.",
                "Direct box test is separate. Uses frozen wick boundary retest, opposite wick stop and 2R as engineering assumptions. Reclaim evidence is recorded without imposing AMD.",
            ],
            "demo_qualified": False, "execution_allowed": False, "orders_sent": 0}


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--ipda-project", type=Path, required=True)
    cli.add_argument("--early", type=Path, required=True)
    cli.add_argument("--late", type=Path, required=True)
    cli.add_argument("--replay", type=Path, action="append", required=True)
    cli.add_argument("--out", type=Path, required=True)
    cli.add_argument("--research-daily", action="store_true")
    cli.add_argument("--research-ny-reclaim", action="store_true")
    cli.add_argument("--continuous-account", action="store_true")
    args = cli.parse_args()
    result = run(args.ipda_project, args.early, args.late, args.replay,
                 research=args.research_daily, ny_reclaim=args.research_ny_reclaim,
                 continuous_account=args.continuous_account)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=lambda x: x.isoformat()) + "\n",
                        encoding="utf-8")
    for experiment in result["experiments"]:
        print(experiment["source_replay"], len(experiment["box_cases"]),
              {name: len([d for d in book["decisions"] if d["status"] == "accepted"])
               for name, book in experiment["portfolios"].items()}, flush=True)
