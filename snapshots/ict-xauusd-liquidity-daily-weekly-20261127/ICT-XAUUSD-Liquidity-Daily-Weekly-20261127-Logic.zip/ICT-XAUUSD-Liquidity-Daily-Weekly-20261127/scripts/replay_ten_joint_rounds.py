"""Replay ten chronological TMGM rounds using identical cutoffs for both models."""
from bisect import bisect_right
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import check_pool_priority as priority
from scripts import replay_pool_and_dol as joint
from ict_ai.range_liquidity import _Coverage, M5
from ict_ai.timebase import NY

OUT=joint.RESEARCH/'ten_joint_rounds_20261122'
START=date(2026,3,30)
END=date(2026,11,23)
BOUNDS=[START+timedelta(weeks=3*i+min(i,4)) for i in range(11)]
assert BOUNDS[-1]==END
POLICIES=('current','nearest','confluence')


def bounds(at):
    day=datetime.fromisoformat(at).astimezone(NY).date()
    return bisect_right(BOUNDS,day)-1


def inputs():
    lock=json.loads((priority.OUT/'lock.json').read_bytes())
    protocol=priority.OUT/'protocol.json'
    assert lock['protocol']==joint.digest(protocol)
    assert lock['candidates']==joint.digest(priority.POOL_FILE)
    original=json.loads(protocol.read_bytes())['inputs']
    for name,digest in original.items():
        assert joint.digest(priority.ARCH/name)==digest
    dols={}
    for name in ('frozen.json.gz','validation_extra_frozen.json.gz'):
        for s in joint.read_zip(priority.ARCH/name):
            if s['status']=='frozen':
                dols[s['at']]=s
    prefix=[]
    for s in joint.read_zip(priority.POOL_FILE):
        if not 0<=bounds(s['at'])<10:
            continue
        d=dols[s['at']]
        assert d['price']==s['price']
        prefix.append(dict(at=s['at'],price=s['price'],pools=s['pools'],dol=joint.archived_dol(d),
                           h1=d['median_h1'],source='archive'))
    lock=json.loads(joint.LOCK.read_bytes())
    for p in (joint.FROZEN,joint.QUOTES):
        assert lock[p.name]==joint.digest(p)
    recent_width={s['at']:s['median_h1'] for s in joint.read_zip(joint.DOLS)}
    suffix=[dict(s,h1=recent_width[s['at']],source='recent') for s in joint.read_zip(joint.FROZEN)]
    rows=sorted(prefix+suffix,key=lambda s:s['at'])
    assert len(rows)==len({s['at'] for s in rows})
    return rows


def matching(pool,dol):
    edge=dol['lo'] if dol['side']>0 else dol['hi']
    return pool['side']==dol['side'] and pool['lo']-.005<=edge<=pool['hi']+.005


def pick(s,family):
    targets=s[family]
    if not targets:
        return {}
    near=min(range(len(targets)),key=lambda i:targets[i]['distance'])
    cutoff=targets[near]['distance']+.25*s['h1']
    if family=='pools':
        agrees=lambda pool:any(matching(pool,d) for d in s['dol'][:3])
    else:
        agrees=lambda dol:any(matching(p,dol) for p in s['pools'][:3])
    aligned=[i for i,t in enumerate(targets) if t['distance']<=cutoff and agrees(t)]
    confluence=min(aligned,key=lambda i:targets[i]['distance'],default=near)
    return dict(current=0,nearest=near,confluence=confluence)


def record(rows,picks,metric,counts):
    earliest=min((row[metric] for row in rows if row[metric]),default=None)
    winners=[i for i,r in enumerate(rows) if earliest and r[metric]==earliest]
    counts['n']+=1
    counts['tie']+=len(winners)>1
    counts['any']+=bool(winners)
    for policy,i in picks.items():
        counts[policy+'_hit']+=bool(rows[i][metric])
        counts[policy+'_first']+=winners==[i]
    nearest=bool(rows[picks['nearest']][metric])
    selected=bool(rows[picks['confluence']][metric])
    counts['confluence_changed']+=picks['confluence']!=picks['nearest']
    counts['confluence_only']+=selected and not nearest
    counts['nearest_only']+=nearest and not selected


def evaluate(rows, group_for=bounds, count=10, output=OUT):
    archive=priority.read_market()
    datasets={'archive':archive,'recent':joint.load_bars()}
    coverage={k:_Coverage(times[0],times[-1]+M5,bars,M5) for k,(bars,times) in datasets.items()}
    summaries=[defaultdict(Counter) for _ in range(count)]
    paired=defaultdict(Counter)
    outcomes=[]
    for s in rows:
        round_id=group_for(s['at'])
        summary=summaries[round_id]
        day=datetime.fromisoformat(s['at']).astimezone(NY).date()
        monday=day-timedelta(days=day.weekday())
        bars,times=datasets[s['source']]
        settled={scope:joint.assess(s,bars,times,coverage[s['source']],week=scope=='week')
                 for scope in ('short','week')}
        outcomes.append(dict(at=s['at'],**settled))
        for scope,family,metric in [('short','dol','touch'),('short','pools','sweep'),('week','pools','sweep')]:
            label=family+'_'+scope
            result=settled[scope]
            summary[label][result['status']]+=1
            picks=s['picks'][family]
            if result['status']!='complete' or not picks:
                continue
            contacts=result[family]
            record(contacts,picks,metric,summary[label])
            c=bool(contacts[picks['confluence']][metric])
            n=bool(contacts[picks['nearest']][metric])
            paired[label][monday,'delta']+=int(c)-int(n)
            paired[label][monday,'n']+=1
    joint.write_zip(output/'outcomes.json.gz',outcomes)
    return summaries,{k:priority.interval({m:(v[m,'delta'],v[m,'n']) for m,t in v if t=='n'})
                      for k,v in paired.items()}


def format_counts(c):
    n=c['n']
    return f"{c['current_hit']}/{n} · {c['nearest_hit']}/{n} · {c['confluence_hit']}/{n}"


def report(summaries,intervals):
    lines=['# TMGM XAUUSD 十轮联合回测','',
           '每轮按纽约交易周划分。表中每格依次为现有评分第一、距离最近、近端有 DOL／流动性共振，数值为命中数／有效窗口。DOL 命中为触价，流动性命中为严格越过外沿。最长四小时，遇纽约日界截断；另统计流动性在周五 16:55 前的结果。','',
           '|轮次|纽约日期|DOL 四小时|流动性四小时|流动性至周五|',
           '|---:|---|---|---|---|']
    totals=defaultdict(Counter)
    for i,s in enumerate(summaries):
        a,b=BOUNDS[i],BOUNDS[i+1]-timedelta(days=3)
        cols=[format_counts(s[k]) for k in ('dol_short','pools_short','pools_week')]
        lines.append(f"|{i+1}|{a} 至 {b}|"+'|'.join(cols)+'|')
        for k,v in s.items():
            totals[k].update(v)
    lines+=['|合计||'+'|'.join(format_counts(totals[k]) for k in ('dol_short','pools_short','pools_week'))+'|',
            '', '现有评分、距离最近、近端共振的候选池一致。共振规则允许在最近目标距离外再加 0.25 倍 H1 波幅中位数，在这段范围内选择有同侧重合且被另一模型列为前三的最近价位。两模型使用相同的已收 M5 时点。日线、周线的流动性来源继续使用 ERL。','',
            '|轮次|DOL 四小时唯一先到|流动性四小时唯一先到|流动性周内唯一先到|四小时缺失／未到期|周内缺失／未到期|',
            '|---:|---|---|---|---|---|']
    for i,s in enumerate(summaries,1):
        short,week=s['pools_short'],s['pools_week']
        first=['／'.join(str(s[k][p+'_first']) for p in POLICIES) for k in ('dol_short','pools_short','pools_week')]
        lines.append(f"|{i}|"+'|'.join(first)+f"|{short['missing']}／{short['open']}|{week['missing']}／{week['open']}|")
    lines+=['',
            '|项目|可唯一确认最先到达（现有／最近／共振）|共振改选|仅共振命中|仅最近命中|共振相对最近差值的 95% 周分块区间|缺失／未到期|',
            '|---|---|---:|---:|---:|---|---|']
    for key,label in [('dol_short','DOL 四小时'),('pools_short','流动性四小时'),('pools_week','流动性至周五')]:
        c=totals[key]
        a,b=intervals[key]
        first='／'.join(str(c[p+'_first']) for p in POLICIES)
        lines.append(f"|{label}|{first}|{c['confluence_changed']}|{c['confluence_only']}|{c['nearest_only']}|{a*100:+.1f} 至 {b*100:+.1f} 个百分点|{c['missing']}／{c['open']}|")
    lines+=['','同根 M5 同时满足多个目标时，先后记为未确定。窗口可重叠，区间按纽约交易周成组抽样。9 月 21 日后的样本已用于前一轮分析，十轮结果是历史比较，保留当前线上评分。']
    (OUT/'十轮联合回测.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    (OUT/'summary.json').write_text(json.dumps(dict(rounds=summaries,totals=totals,intervals=intervals),indent=2),encoding='utf-8')
    print({k:dict(v) for k,v in totals.items()})


if __name__=='__main__':
    OUT.mkdir(exist_ok=True,parents=True)
    snapshots=inputs()
    for row in snapshots:
        row['picks']={name:pick(row,name) for name in ('dol','pools')}
    frozen=OUT/'frozen.json.gz'
    joint.write_zip(frozen,snapshots)
    (OUT/'lock.json').write_text(json.dumps({'frozen':joint.digest(frozen),'script':joint.digest(Path(__file__)),
        'snapshots':len(snapshots),'ny_week_starts':[d.isoformat() for d in BOUNDS]},indent=2),encoding='utf-8')
    report(*evaluate(joint.read_zip(frozen)))
