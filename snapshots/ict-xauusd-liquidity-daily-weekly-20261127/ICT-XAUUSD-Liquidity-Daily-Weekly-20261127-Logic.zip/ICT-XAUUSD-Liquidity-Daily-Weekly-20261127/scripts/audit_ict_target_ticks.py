"""Check first target arrival using recorded Bid changes in reconciled chart bars."""
from collections import Counter
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts import replay_pool_and_dol as replay
from scripts.export_mt5_native import native_time

REPORT = replay.RESEARCH/'ict_priority_uplift.json'
ARCHIVE = replay.RESEARCH/'ict_target_order_bid.json.gz'


def probe_key(case):
    return f'{case["open_at"]}|{case["duration"]}'


def read_probes(results):
    groups = {'DOL':results['validation']['dol'],
              'IRL':results['IRL_full'],'ERL':results['ERL_full']}
    minutes = {}
    for value in groups.values():
        for probe in value['tick_probes']:
            stamp = probe_key(probe)
            if minutes.setdefault(stamp,probe['ohlc']) != probe['ohlc']:
                raise ValueError(f'Conflicting M1 records at {stamp}')
    return groups, minutes


def capture(probes, source):
    import MetaTrader5 as mt5

    terminal = Path('C:/Program Files/MetaTrader 5/terminal64.exe')
    if not mt5.initialize(str(terminal),timeout=10000):
        raise RuntimeError(f'MT5 unavailable: {mt5.last_error()}')
    quotes = {}
    errors = {}
    try:
        account = mt5.account_info()
        terminal_info = mt5.terminal_info()
        if not account or not terminal_info or not terminal_info.connected or account.server!=source['server']:
            raise RuntimeError('Live terminal does not match the quote archive')
        identity = account.login,account.server
        for key in sorted(probes):
            stamp, duration = key.split('|')
            end = (datetime.fromisoformat(stamp)+timedelta(seconds=int(duration))).isoformat()
            start_raw,end_raw = [datetime.strptime(native_time(t,source['clock']),'%Y.%m.%d %H:%M:%S')
                                 .replace(tzinfo=timezone.utc) for t in (stamp,end)]
            start_ms = int(start_raw.timestamp())*1000
            end_ms = int(end_raw.timestamp())*1000
            raw = mt5.copy_ticks_range('XAUUSD',start_raw,end_raw,mt5.COPY_TICKS_INFO)
            if raw is None:
                errors[key] = str(mt5.last_error())
                continue
            rows = [[int(q['time_msc'])-start_ms,float(q['bid'])] for q in raw
                    if start_ms<=int(q['time_msc'])<end_ms and q['bid']>0]
            if any(a[0]>b[0] for a,b in zip(rows,rows[1:])):
                errors[key] = 'Quote sequence is not monotone'
                continue
            quotes[key] = rows
        current = mt5.account_info()
        state = mt5.terminal_info()
        if not current or (current.login,current.server)!=identity or not state or not state.connected:
            raise RuntimeError('Terminal changed during the quote probe')
    finally:
        mt5.shutdown()
    return dict(input_hash=replay.digest(REPORT), source_hash=replay.digest(replay.QUOTES),
                server=source['server'], quotes=quotes, errors=errors)


def boundary_time(quotes, side, edge, sweep):
    previous = quotes[0][1]
    if sweep and side*(previous-edge)>0:
        return None  # First quote is already through the boundary.
    if not sweep and previous==edge:
        return quotes[0][0]
    for stamp,bid in quotes[1:]:
        if sweep:
            if side*(previous-edge)<=0<side*(bid-edge):
                return stamp
        elif min(previous,bid)<=edge<=max(previous,bid):
            return stamp
        previous = bid
    return None


def evaluate(segments, archive):
    summary = {}
    for family, segment in segments.items():
        counts = Counter()
        examples = {}
        for case in segment['tick_probes']:
            quotes = archive['quotes'].get(probe_key(case))
            if not quotes:
                counts['no_quotes'] += 1
                continue
            bid = [q[1] for q in quotes]
            if [bid[0],max(bid),min(bid),bid[-1]] != case['ohlc']:
                counts['ohlc_mismatch'] += 1
                continue
            contacts = [(index,side,edge,boundary_time(quotes,side,edge,family!='DOL'))
                        for index,side,edge in case['boundaries']]
            if any(row[3] is None for row in contacts):
                counts['unwitnessed'] += 1
                continue
            earliest = min(row[3] for row in contacts)
            first = [row for row in contacts if row[3]==earliest]
            if len(first)==1:
                status = 'unique'
            elif len({(row[1],row[2]) for row in first})==1:
                status = 'shared_boundary'
            else:
                status = 'same_millisecond'
            counts[status] += 1
            for label, index in case['picks'].items():
                if any(row[0]==index for row in first):
                    counts[f'{label}_{status}'] += 1
            examples.setdefault(status,dict(case, contacts=contacts))
        coarse = segment['order_at_m1']
        verified = dict(
            checkpoints=segment['counts']['n'],
            unique=coarse.get('m5_unique',0)+coarse.get('m1_unique',0)+counts['unique'],
            shared_boundary=(coarse.get('shared_boundary',0)+coarse.get('m1_shared_boundary',0)
                             +counts['shared_boundary']),
            no_event=coarse.get('no_event',0),
        )
        verified['unresolved']=verified['checkpoints']-sum(
            verified[k] for k in ('unique','shared_boundary','no_event'))
        verified['correct_unique_first']={name:coarse.get(name+'_unique',0)+counts[name+'_unique']
                                          for name in ('original','uplift','nearest')}
        summary[family] = dict(coarse_M1=coarse, additional_tick_resolution=counts,
                               overall=verified, examples=examples)
    return summary


def main():
    results = json.loads(REPORT.read_bytes())['results']
    segments, probes = read_probes(results)
    market = replay.read_zip(replay.QUOTES)
    if '--capture' in sys.argv[1:]:
        if ARCHIVE.exists():
            raise FileExistsError(ARCHIVE)
        data = capture(probes, market)
        replay.write_zip(ARCHIVE, data)
    else:
        data = replay.read_zip(ARCHIVE)
    if data['input_hash'] != replay.digest(REPORT) or data['source_hash'] != replay.digest(replay.QUOTES):
        raise ValueError('Tick capture inputs changed')
    summary = evaluate(segments,data)
    path = replay.RESEARCH/'ict_target_tick_order.json'
    path.write_text(json.dumps(dict(summary=summary,archive_hash=replay.digest(ARCHIVE),
        time_basis='Milliseconds from each checked M1 or M5 bar open',
        method='Exact Bid OHLC match. Observed successive quotes straddle DOL edges; pool edges require '
               'a quote strictly beyond. Distinct boundaries crossed at the same millisecond stay tied.'),
        indent=2),encoding='utf-8')
    print({key:dict(value['additional_tick_resolution']) for key,value in summary.items()})


if __name__ == '__main__':
    main()
