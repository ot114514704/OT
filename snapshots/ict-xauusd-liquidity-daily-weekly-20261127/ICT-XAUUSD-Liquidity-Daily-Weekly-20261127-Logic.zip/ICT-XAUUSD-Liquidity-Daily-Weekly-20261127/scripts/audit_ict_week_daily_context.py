"""Walk forward with frozen intraweek context for the daily ICT price-path model."""

from argparse import ArgumentParser
from bisect import bisect_left, bisect_right
from collections import Counter
from datetime import timedelta
import json
from pathlib import Path

from ict_ai.profile_alignment import observed_context
from scripts import audit_ict_intraday_learning as intraday
from scripts.audit_ict_profile_supplement import paired_models
from scripts.serve_ict_live import atomic_json


daily = intraday.daily
M5 = daily.M5
M15 = daily.M15
CHECKPOINTS = ('08:30','10:00')
WEEK_FEATURES = ('week_coverage','completed_prior_days','prior_range_available','signed_location_in_prior_week_to_date',
                 'last_prior_close_distance','same_side_sweeps','opposing_sweeps','aligned_week_cards',
                 'opposing_week_cards','weekly_early_consolidation','aligned_thursday_counter','opposing_thursday_counter')
OUT = daily.RESEARCH/'ict_week_daily_context_20261123.json'


def features(view,price,side):
    prior = view['prior']
    within,distance = 0.,0.
    if prior:
        width = max(.01,prior['high']-prior['low'])
        within = side*(price-(prior['high']+prior['low'])*.5)/width
        distance = side*(price-prior['close'])/width
    same_side,opposing = ('SSL','BSL') if side>0 else ('BSL','SSL') if side<0 else (None,None)
    active = Counter(c['direction'] for c in view['active'])
    return [int(view['covered']),view['completed_prior_days'],int(prior is not None),within,distance,
            view['sweeps'].get(same_side,0),view['sweeps'].get(opposing,0),active[side],active[-side],
            int(view['consolidation']),view['thursday_counter'].count(side),view['thursday_counter'].count(-side)]


def run():
    bars,times = daily.read_market()
    last = times[-1]+M5
    quarters = daily.aggregate_bars(bars,5,15,last)
    qtimes = [b.time for b in quarters]
    checkpoints = intraday.rebuild_checkpoints(bars,times)
    manual = intraday.read_manual()
    comparison = {}
    timeline = {}
    counts = Counter()
    for name in CHECKPOINTS:
        changed = {'ny_open':[],'current':[]}
        controls = []
        for row in checkpoints[name]:
            day = row['date']
            days = [row['week']+timedelta(days=i) for i in range(5)]
            first = daily._day_bounds(days[0])[0]
            end = daily._day_bounds(days[-1])[1]
            a,z = bisect_left(times,first),bisect_left(times,end)
            a15,z15 = bisect_left(qtimes,first),bisect_left(qtimes,end)
            controls.append(row)
            for key,at in (('ny_open',daily.session_windows(day)['new_york'][0]),('current',row['at'])):
                m5 = bars[a:bisect_right(times,at-M5)]
                m15 = quarters[a15:bisect_right(qtimes,at-M15)]
                view = observed_context(m5,m15,days,at)
                if view!=observed_context(bars[a:z],quarters[a15:z15],days,at):
                    raise AssertionError(f'Later bars changed the weekly context at {at}')
                counts[name,key,'prefix_parity']+=1
                counts[name,key,'complete_week_prefix']+=view['covered']
                counts[name,key,'active_profile']+=bool(view['active'])
                counts[name,key,'prior_range']+=view['prior'] is not None
                if row['keys']:
                    price = m5[-1].close if m5 and m5[-1].time+M5==at else None
                    if price is None:
                        # Missing a checkpoint price cannot stand in for a
                        # neutral location in the higher timeframe range.
                        feature_rows = [[*x,*([0]*len(WEEK_FEATURES)),0] for x in row['x']]
                        counts[name,key,'missing_checkpoint_price']+=1
                    else:
                        feature_rows = [[*x,*features(view,price,side),1]
                                        for (_,side),x in zip(row['keys'],row['x'],strict=True)]
                else:
                    feature_rows = []
                changed[key].append(dict(row,x=feature_rows))
                timeline[row['date'].isoformat(),name,key] = view
        baseline = daily.walk_forward(controls,manual)
        comparison[name] = {}
        for key,test in changed.items():
            revised = daily.walk_forward(test,manual)
            comparison[name][key] = paired_models(baseline,revised)

    files = (Path(__file__),Path('ict_ai/profile_alignment.py'),Path('ict_ai/weekly_path.py'),Path('ict_ai/profile_lifecycle.py'),
             Path('ict_ai/profile_delivery_evidence.py'),Path('scripts/audit_ict_daily_learning.py'),
             Path('scripts/audit_ict_intraday_learning.py'),daily.ARCH/'XAUUSDM5.npz',*daily.MANUAL)
    return dict(cutoffs_ny=CHECKPOINTS,new_features=[*WEEK_FEATURES,'checkpoint_available'],
                checkpoints={'/'.join(key):n for key,n in counts.items()},results=comparison,
                timeline={'/'.join(key):view for key,view in timeline.items()},
                source_sha256={p.name:daily.digest(p) for p in files},
                study_basis='Previous closed NY days, observed weekly sweep/reclaim, and active causal weekly rules. Original held-out date and candidate set unchanged.',
                limitations=['Weekly states and daily labels are research price paths. Independently verified prior bias, calendar, and DOL are not implied.',
                             'Same TMGM retrospective sample; use forward set for promotion.'],orders_sent=0)


if __name__=='__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=OUT)
    args = parser.parse_args()
    result = run()
    atomic_json(args.out,result)
    for name,models in result['results'].items():
        for label,scores in models.items():
            print(name,label,scores['rule_y'],flush=True)
