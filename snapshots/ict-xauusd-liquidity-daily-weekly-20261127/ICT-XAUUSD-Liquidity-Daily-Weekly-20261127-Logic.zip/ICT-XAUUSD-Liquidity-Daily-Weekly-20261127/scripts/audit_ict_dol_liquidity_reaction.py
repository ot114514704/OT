"""Frozen DOL, IRL and ERL target reaction replay on closed TMGM M5."""

from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime, time, timedelta
import json
from pathlib import Path

import numpy as np

from ict_ai.dol_history import _deadline
from ict_ai.range_liquidity import M5, _Coverage
from ict_ai.timebase import NY
from scripts import check_pool_priority as market
from scripts import replay_pool_and_dol as source
from scripts.audit_ict_target_order import MinuteOrder
from scripts.audit_ict_target_ranking import fit_prior_weeks
from scripts.replay_ict_liquidity_rank import ARCHIVE as POOLS, features as pool_features
from scripts.serve_ict_live import atomic_json


OUT = source.RESEARCH/'ict_dol_liquidity_reaction_20261124.json'
HOLDOUT = datetime(2026,10,1,tzinfo=NY)
REACTION = timedelta(minutes=30)
MINUTE_ARCHIVE = source.RESEARCH/'structural_top10_replay_20261122'/'XAUUSD_M1.json.gz'


def far_edge(target):
    return target['hi'] if target['side']==1 else target['lo']


def event(target, bars, freeze_price):
    side = target['side']
    near,far = ((target['lo'],target['hi']) if side==1 else (target['hi'],target['lo']))
    picked = dict(touch=None,cross=None,resolved=None,state='untouched')
    if side*(near-freeze_price)<=0:
        return dict(picked,state='started_at_or_inside_edge')
    crossed = None
    previous = None
    outside = 0
    for bar in bars:
        known = bar.time+M5
        if crossed is not None and (bar.time!=previous or known>crossed+REACTION):
            return dict(picked,state='censored_reaction')
        if picked['touch'] is None and bar.low<=near<=bar.high:
            picked['touch'] = known.isoformat()
            picked['state'] = 'touch_without_cross'
        if crossed is None:
            excursion = bar.high if side==1 else bar.low
            if side*(excursion-far)<=0:
                continue
            if not bar.low<=far<=bar.high:
                return dict(picked,state='unwitnessed_gap_over')
            crossed = known
            picked['cross'] = crossed.isoformat()
        previous = known
        if side*(bar.close-near)<0:
            return dict(picked,state='reclaimed',resolved=known.isoformat())
        outside = outside+1 if side*(bar.close-far)>0 else 0
        if outside==2:
            return dict(picked,state='two_closes_beyond',resolved=known.isoformat())
        if known==crossed+REACTION:
            return dict(picked,state='no_resolution_by_30m',resolved=known.isoformat())
    return dict(picked,state='censored_reaction') if crossed is not None else picked


def frozen_candidates():
    manifest = json.loads((market.ARCH/'manifest.json').read_bytes())
    data = [market.ARCH/name for name in ('frozen.json.gz','validation_extra_frozen.json.gz',
            'recent_frozen.json.gz','XAUUSDM5.npz','clock_validation.json','run.py')]
    if any(source.digest(path)!=manifest[path.name] for path in data):
        raise ValueError('Frozen DOL or market archive changed')
    unique = {}
    for path in data[:3]:
        for record in source.read_zip(path):
            if record['status']!='frozen':
                continue
            at = datetime.fromisoformat(record['at'])
            targets = source.archived_dol(record)
            if at in unique and unique[at]!=dict(record, ranked=targets):
                raise ValueError(f'Conflicting DOL freeze at {at}')
            unique[at] = dict(record,ranked=targets)
    existing = POOLS/'round19_liquidity_50_candidates.json.gz'
    lock = json.loads((POOLS/'round19_liquidity_50_lock.json').read_bytes())
    if source.digest(existing)!=lock['candidates']:
        raise ValueError('Frozen liquidity candidates changed')
    pools = source.read_zip(existing)
    for row in unique.values():
        yield 'dol',row['at'],row['price'],row['ranked'][:10],row['median_h1'],data[:3]
    for row in pools:
        for scope in ('IRL','ERL'):
            candidates = row['pools'][scope][:10]
            if candidates:
                yield scope,row['at'],row['price'],candidates,candidates[0]['hourly_range'],[existing]


def evaluate(groups):
    results = Counter()
    scored = []
    fit_week = None
    fit = None
    train_count = 0
    for g in groups:
        if g['at']<HOLDOUT:
            continue
        week = g['week']
        if week!=fit_week:
            fit_week = week
            freeze = datetime.combine(week,time(0),NY)
            train = [row for row in groups if row['end']<=freeze and row['common_coverage']]
            train_count = len(train)
            labels = [value for row in train for value in row['y']]
            fit = fit_prior_weeks(train) if len(train)>=40 and min(sum(labels),len(labels)-sum(labels))>=15 else None
        results['holdout_seen'] += 1
        if not g['common_coverage']:
            results['excluded_reaction_not_resolved'] += 1
            continue
        distance = g['dist']
        rank = min(range(len(distance)),key=lambda i:(distance[i],i))
        picks = dict(original=0,nearest=rank)
        if fit is not None:
            mean,scale,weights = fit
            scores = ((np.array(g['x'])-mean)/scale)@weights[1:]
            picks['learned_reclaim'] = max(range(len(distance)),key=lambda i:(scores[i],-distance[i],-i))
        else:
            results['model_training_unavailable'] += 1
        results['eligible'] += 1
        results['different_original_and_nearest'] += rank!=0
        outcomes = {name:g['events'][i] for name,i in picks.items()}
        far_outcomes = {name:g['far_events'][i] for name,i in picks.items()}
        for name,obs in outcomes.items():
            results[name+'_selected'] += 1
            results[name+'_touch'] += bool(obs['touch'])
            results[name+'_strict_cross'] += bool(obs['cross'])
            results[name+'_'+obs['state']] += 1
        scored.append(dict(at=g['at'].isoformat(),end=g['end'].isoformat(),week=week.isoformat(),
                           training_windows=train_count,side=g['side'],selections={name:g['targets'][i] for name,i in picks.items()},
                           outcomes=outcomes,far_edge_reclaim=far_outcomes))
    paired = {}
    for method in ('original','learned_reclaim'):
        blocks = defaultdict(list)
        for row in scored:
            if method not in row['outcomes']:
                continue
            state = row['outcomes']
            blocks[row['week']].append(int(state[method]['state']=='reclaimed')-int(state['nearest']['state']=='reclaimed'))
        paired[method+'_minus_nearest'] = market.interval({week:(sum(xs),len(xs)) for week,xs in blocks.items()}) if len(blocks)>1 else None
    return dict(counts=dict(results),paired_ny_week_interval=paired,windows=scored)


def edge_sensitivity(windows):
    tallies = Counter()
    for row in windows:
        edges = row['far_edge_reclaim']
        full = row['outcomes']
        if all(result['state'] not in ('censored_reaction','started_at_or_inside_edge','unwitnessed_gap_over')
               for result in edges.values()):
            tallies['common_coverage'] += 1
            for name,result in edges.items():
                tallies[name+'_far_edge_reclaimed'] += result['state']=='reclaimed'
        if 'learned_reclaim' in full:
            delta = int(full['learned_reclaim']['state']=='reclaimed')-int(full['nearest']['state']=='reclaimed')
            if delta:
                a,b = (far_edge(row['selections'][method]) for method in ('learned_reclaim','nearest'))
                tallies[('same_far_edge' if a==b else 'different_far_edge')+('_learned_only' if delta>0 else '_nearest_only')] += 1
    return dict(tallies)


def minute_witness(bars, windows):
    proof = json.loads((MINUTE_ARCHIVE.parent/'m1-lock.json').read_bytes())
    if source.digest(MINUTE_ARCHIVE)!=proof['digest']:
        raise ValueError('M1 reaction witness archive changed')
    tape = MinuteOrder(source.read_zip(MINUTE_ARCHIVE),bars)
    result = []
    for row in windows:
        original = row['outcomes']
        methods = ('learned_reclaim','nearest')
        if methods[0] not in original or (original[methods[0]]['state']=='reclaimed')==(original[methods[1]]['state']=='reclaimed'):
            continue
        per_method = {}
        for method in methods:
            obs = original[method]
            start = datetime.fromisoformat(row['at'])
            finish = datetime.fromisoformat(obs['resolved'] or row['end'])
            stamps = [start+i*M5 for i in range(1,(finish-start)//M5+1) if start+(i-1)*M5 in tape.five]
            checks = [tape.reconciled_minutes(stamp) for stamp in stamps]
            per_method[method] = dict(expected_m5=len(stamps),matched_m5=sum(c is not None for c in checks),
                                      reaction_bar_reconciled=(tape.reconciled_minutes(finish) is not None) if obs['resolved'] else None)
        result.append(dict(at=row['at'],checks=per_method))
    return result


def outcome_feature(row,price,scale,family,distance):
    if family!='dol':
        return pool_features(row,distance)
    parts = row['score_components']
    return [np.log1p(distance),np.log1p((row['hi']-row['lo'])/scale),row['side'],price/scale,
            *(parts.get(k,0) for k in ('reach','alignment','quality','timing','obstacle','nearby'))]


def run():
    bars,times = market.read_market()
    coverage = _Coverage(times[0],times[-1]+M5,bars,M5)
    groups = defaultdict(list)
    states = defaultdict(Counter)
    inputs = {market.ARCH/'XAUUSDM5.npz',market.ARCH/'clock_validation.json',market.ARCH/'run.py',
              POOLS/'round19_liquidity_50_lock.json',source.ROOT/'ict_ai/range_liquidity.py',
              source.ROOT/'ict_ai/dol_history.py',source.ROOT/'scripts/audit_ict_target_ranking.py'}
    outcomes = defaultdict(set)
    parity = 0
    for family,at_string,price,rows,scale,paths in frozen_candidates():
        inputs.update(paths)
        at = datetime.fromisoformat(at_string)
        end = _deadline(at)
        before = bisect_left(times,at)
        if before==0 or times[before-1]+M5!=at or abs(bars[before-1].close-price)>1e-8:
            states[family]['unmatched_freeze_close'] += 1
            continue
        if coverage.cutoff<end or coverage.gap(at,end) or end<=at:
            states[family]['incomplete_primary_window'] += 1
            continue
        if not rows or not scale:
            continue
        future = bars[before:bisect_left(times,end)]
        observed = [event(target,future,price) for target in rows]
        for target,obs in zip(rows,observed,strict=True):
            states[family][obs['state']] += 1
            if obs['resolved'] and obs['state'] in ('reclaimed','two_closes_beyond'):
                outcomes[family].add((obs['cross'],target['side'],target['lo'],target['hi'],obs['state']))
                at_resolution = datetime.fromisoformat(obs['resolved'])
                clipped = [b for b in future if b.time+M5<=at_resolution]
                if event(target,clipped,price)!=obs:
                    raise AssertionError(f"Future bars changed first reaction at {obs['resolved']}")
                parity += 1
        # Fix direction to the originally highest-ranked row. This isolates the
        # choice of same-side price level from direction forecasting.
        side = rows[0]['side']
        same = [(row,obs) for row,obs in zip(rows,observed,strict=True) if row['side']==side]
        targets,observed = zip(*same,strict=True)
        quote = at.astimezone(NY).date()
        week = quote-timedelta(days=quote.weekday())
        dist = [abs(far_edge(target)-price)/scale for target in targets]
        known = all(r['state'] not in ('censored_reaction','unwitnessed_gap_over','started_at_or_inside_edge') for r in observed)
        groups[family].append(dict(at=at,end=end,week=week,side=side,dist=dist,targets=targets,events=observed,
             far_events=[event(dict(t,lo=far_edge(t),hi=far_edge(t)),future,price) for t in targets],
             common_coverage=known,y=[int(o['state']=='reclaimed') for o in observed],
             x=[outcome_feature(t,price,scale,family,d) for t,d in zip(targets,dist,strict=True)]))
    comparisons = {family:evaluate(sorted(rows,key=lambda r:r['at'])) for family,rows in groups.items()}
    for data in comparisons.values():
        data['uniform_far_edge_sensitivity'] = edge_sensitivity(data['windows'])
    minutes = minute_witness(bars,comparisons['dol']['windows'])
    inputs.update((MINUTE_ARCHIVE,MINUTE_ARCHIVE.parent/'m1-lock.json'))
    return dict(symbol='XAUUSD',out_of_sample_first=HOLDOUT.isoformat(),reaction_window_minutes=30,
                rule='Frozen top ten per family. Direction held equal to original rank 1. Within each frozen four-hour or NY-day-capped window, after a strict witnessed break of the outer edge, the first resolving close either crosses back past the near edge or is the second consecutive close beyond the far edge. Unresolved past 30 minutes is a distinct outcome.',
                target_states={family:dict(c) for family,c in states.items()},
                distinct_resolved_events={family:len(c) for family,c in outcomes.items()},prefix_checks=parity,
                comparisons=comparisons,dol_decisive_windows_m1_witness=minutes,
                sensitivity='Retain the previously picked targets, evaluate a return across the same far edge as the strict cross. Noncomparable windows excluded from this paired count.',
                inputs={str(p.relative_to(source.ROOT)):source.digest(p) for p in sorted(inputs)},
                code_sha256=source.digest(Path(__file__)),orders_sent=0)


if __name__=='__main__':
    report = run()
    atomic_json(OUT,report)
    print('Prefix checks:',report['prefix_checks'])
    for family,data in report['comparisons'].items():
        print(family,data['counts'],data['paired_ny_week_interval'],flush=True)
