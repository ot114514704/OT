"""Freeze and verify a prospective two-checkpoint NY daily profile comparison."""

from argparse import ArgumentParser
from collections import Counter
from datetime import datetime, time, timedelta
from pathlib import Path

from scripts import audit_ict_intraday_profile_confirmation as study
from scripts import verify_ict_daily_abstention_forward as control
from scripts import watch_ict_profile_feed as feed
from scripts.serve_ict_live import atomic_json
from scripts.shadow_ict_dol import write_once


ROOT = control.study.daily.RESEARCH / "ict_daily_confirmation_forward_20261126"
POLICY = ROOT / "policy.json"
CLOCKS = (time(9, 30), time(10))
PINS = (Path(__file__), Path(study.__file__), study.OUT, control.POLICY,
        feed.early.MODEL, feed.daily.MODEL, *feed.PROTOCOL_FILES)


def fingerprints():
    root = Path(__file__).resolve().parents[1]
    return {path.resolve().relative_to(root).as_posix(): feed.archive.digest(path) for path in PINS}


def freeze():
    control_policy = feed.settlement.read_json(control.POLICY)
    if (control_policy["pinned"] != control.fingerprints() or control_policy["threshold"] != control.THRESHOLD
            or control_policy["checkpoint_ny"] != "10:00"):
        raise ValueError("The prospective one-checkpoint control could not be verified")
    for source in (feed.early, feed.daily):
        source.load_model()
    archive = feed.settlement.read_json(study.OUT)
    if archive["source_sha256"] != feed.archive.digest(study.DEFAULT):
        raise ValueError("Historical confirmation audit uses different scores")
    ROOT.mkdir(parents=True, exist_ok=True)
    write_once(POLICY, {
        "frozen_at": feed.daily.utc_now().isoformat(), "checkpoints_ny": ["09:30", "10:00"],
        "threshold_1000": control.THRESHOLD, "pinned": fingerprints(),
        "comparison": "Both arms require the 10:00 top probability to clear the same fixed threshold. "
                      "The comparison arm also requires the same signed leader at 09:30.",
        "orders_sent": 0,
    })


def receipt(at, observed, sources, protocol):
    path = feed.forecast_path(at)
    if not path.exists():
        return {"status": "receipt_missing" if observed >= at + feed.WINDOW else "awaiting_receipt"}, None, []
    record, bars = feed.validate(path, sources, protocol)
    if datetime.fromisoformat(record["recorded_at"]) > observed:
        return {"status": "awaiting_receipt"}, None, []
    probability = "learned_probability" if feed.checkpoint(at) == CLOCKS[-1] else "pooled_probability"
    top = max(record["candidates"], key=lambda row: row[probability], default=None)
    return {"status": record["status"], "cutoff": record["cutoff"], "recorded_at": record["recorded_at"],
            "sha256": feed.archive.digest(path),
            "top": ({"signed_profile": [top["profile"], top["direction"]], "probability": top[probability]}
                    if top is not None else None)}, record, bars


def check_pair(early, late, early_bars, late_bars, threshold):
    leader = late.get("top")
    control_offer = bool(leader and leader["probability"] >= threshold)
    if not early.get("top") or leader is None:
        pair_status = "unavailable"
    else:
        # Both receipts must describe the same OHLC through the earlier close.
        earlier = {bar.time: (bar.open, bar.high, bar.low, bar.close) for bar in early_bars}
        overlap = {bar.time: (bar.open, bar.high, bar.low, bar.close)
                   for bar in late_bars if bar.time in earlier}
        if not earlier or earlier != overlap:
            pair_status = "quote_prefix_differs"
        elif early["top"]["signed_profile"] == leader["signed_profile"]:
            pair_status = "same_signed_profile"
        else:
            pair_status = "changed_signed_profile"
    return {"pair_status": pair_status, "control_offer": control_offer,
            "agreement_offer": control_offer and pair_status == "same_signed_profile"}


def outcome(at, leader, record, prefix, observed):
    path = feed.forecast_path(at)
    result_path = feed.ROOT / "settlements" / path.name
    if record is None or not result_path.exists():
        return {"status": "awaiting_settlement", "correct": None}
    saved = feed.settlement.read_json(result_path)
    captured = datetime.fromisoformat(saved["captured_at"])
    if captured > observed:
        return {"status": "awaiting_settlement", "correct": None}
    tail = feed.settlement.decode_bars(saved["settlement_m5"])
    if saved != feed.settlement_record(path, record, prefix, tail, captured):
        raise ValueError(f"Unreproducible daily outcome: {path.name}")
    correct = (leader["signed_profile"] in saved["actual_paths"] if saved["status"] == "scored" else None)
    return {"status": saved["status"], "correct": correct, "sha256": feed.archive.digest(result_path)}


def verify(*, rehearsal=False):
    policy = feed.settlement.read_json(POLICY)
    if policy["pinned"] != fingerprints() or policy["threshold_1000"] != control.THRESHOLD:
        raise ValueError("The frozen confirmation policy or its inputs changed")
    frozen = datetime.fromisoformat(policy["frozen_at"])
    observed = feed.daily.utc_now()
    sources = {clock: (source, source.load_model()) for clock, source in zip(CLOCKS, (feed.early, feed.daily))}
    protocol = feed.read_protocol()
    dates = set()
    latest = observed.astimezone(feed.NY).date()
    day = frozen.astimezone(feed.NY).date()
    while day <= latest:
        if day.weekday() < 5 and datetime.combine(day, CLOCKS[0], feed.NY) > frozen:
            dates.add(day)
        day += timedelta(days=1)
    if rehearsal:
        files = (path for suffix in ("0930", "1000") for path in feed.ROOT.glob(f"????-??-??_{suffix}.json"))
        dates.update(datetime.strptime(path.stem[:10], "%Y-%m-%d").date() for path in files)

    records = []
    counts = Counter()
    for day in sorted(dates):
        first, final = (datetime.combine(day, clock, feed.NY) for clock in CLOCKS)
        eligible = first > frozen
        early, _, early_bars = receipt(first, observed, sources, protocol)
        late, record, late_bars = receipt(final, observed, sources, protocol)
        pair = check_pair(early, late, early_bars, late_bars, policy["threshold_1000"])
        settlement = outcome(final, late.get("top"), record, late_bars, observed)
        records.append({"date_ny": day.isoformat(), "eligible": eligible, "0930": early, "1000": late,
                        **pair, "settlement": settlement})
        if eligible:
            counts["scheduled_dates"] += 1
            counts[pair["pair_status"]] += 1
            if pair["pair_status"] in ("same_signed_profile", "changed_signed_profile"):
                counts["paired_dates"] += 1
                for arm in ("control", "agreement"):
                    if pair[f"{arm}_offer"]:
                        counts[f"{arm}_offered"] += 1
                        if settlement["correct"] is not None:
                            counts[f"{arm}_scored"] += 1
                            counts[f"{arm}_correct"] += settlement["correct"]
    report = {"policy_sha256": feed.archive.digest(POLICY), "frozen_at": policy["frozen_at"],
              "observed_at": observed.isoformat(), "counts": counts, "records": records, "orders_sent": 0,
              "rehearsal": rehearsal}
    atomic_json(ROOT / ("rehearsal.json" if rehearsal else "status.json"), report)
    return report


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("freeze", "verify", "rehearse"))
    args = parser.parse_args()
    if args.action == "freeze":
        freeze()
    else:
        print(verify(rehearsal=args.action == "rehearse")["counts"])
