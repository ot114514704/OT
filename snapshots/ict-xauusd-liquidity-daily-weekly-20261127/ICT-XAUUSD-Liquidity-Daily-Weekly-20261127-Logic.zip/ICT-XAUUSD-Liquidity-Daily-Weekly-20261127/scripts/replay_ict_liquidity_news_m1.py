"""Audit first-five-minute news decisions against quote-aligned M1 data."""
from collections import Counter, defaultdict
from datetime import timedelta
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from brooks_ai.types import Bar
from scripts import replay_ict_liquidity_news as news

M1 = timedelta(minutes=1)
M5 = news.M5
MINUTES = news.study.RESEARCH/'structural_top10_replay_20261122'
BASE = news.study.RESEARCH/'ict_liquidity_news_omissions_replay.json'


def aligned_window(m5, m1, release):
    """Verify thirty minutes on each side against the original M5 price record."""
    last_before = news.block(m5,release-6*M5,6)
    later = news.block(m5,release,6)
    if last_before is None or later is None:
        return None,'incomplete_m5'
    all_minutes = []
    for five in last_before+later:
        chunk = [m1.get(five.time+i*M1) for i in range(5)]
        if any(row is None for row in chunk):
            return None,'missing_m1'
        observed = (chunk[0].open,max(row.high for row in chunk),
                    min(row.low for row in chunk),chunk[-1].close)
        archived = (five.open,five.high,five.low,five.close)
        if any(abs(a-b)>1e-8 for a,b in zip(observed,archived,strict=True)):
            return None,'m1_does_not_rebuild_m5'
        all_minutes.extend(chunk)
    return (last_before,all_minutes[30:]),None


def passage(rows, side, edge):
    for row in rows:
        extreme = row.high if side>0 else row.low
        if side*(extreme-edge)>0:
            return 'sweep' if row.low<=edge<=row.high else 'gap_over',row.time+M1
    return None,None


def event_dict(p):
    label,at = p
    return dict(label=label,known_at=at.isoformat() if at else None)


def ranked_choices(early, candidates, side):
    if not side:
        return None
    usable = [t for t in candidates if t['side']*(t['edge']-early[-1].close)>0
              and passage(early,t['side'],t['edge'])[0] is None]
    usable.sort(key=lambda t:(abs(t['edge']-early[-1].close),t['original_rank']))
    same_side = next((t for t in usable if t['side']==side),None)
    return (usable[0],same_side) if same_side else None


def replay_window(window, pre, after, scale):
    candidates = []
    old_misses = []
    recorded = set()
    for target in window['traces']+window['previous_miss_followup']:
        key = target['original_rank']
        if key in recorded or target['excluded_at'] is not None:
            continue
        recorded.add(key)
        side = target['side']
        lower,upper = target['zone']
        edge = upper if side>0 else lower
        obs = passage(after,side,edge)
        row = dict(original_rank=key,score=target['score'],side=side,edge=edge,
                   m1=event_dict(obs),original_m5=target['first30']['sweep'])
        if target['previous_round_miss']:
            old_misses.append(row)
        if key>10 and target['score']<=65:
            candidates.append(row)
    decisions = {}
    for delay in range(1,6):
        early = after[:delay]
        reaction,direction = news.confirmed_reaction(pre,early,scale)
        picked = ranked_choices(early,candidates,direction)
        decision = dict(reaction=reaction,direction=direction,
                        cutoff=(early[-1].time+M1).isoformat())
        if picked:
            for name,row in zip(('nearest','directional'),picked,strict=True):
                decision[name] = dict(rank=row['original_rank'],price=row['edge'],
                                      observed=event_dict(passage(after[delay:],row['side'],row['edge'])))
        decisions[str(delay)] = decision
    first_confirmation = next((v['cutoff'] for v in decisions.values() if v['direction']),None)
    totals = Counter(offers=len(candidates),sweep_m1=sum(t['m1']['label']=='sweep' for t in candidates),
                     sweep_m5=sum(bool(t['original_m5']) for t in candidates))
    for row in candidates:
        observed = row['m1']
        if row['original_m5'] and observed['label']!='sweep':
            totals['m5_sweep_without_m1_sweep']+=1
        if observed['label']=='sweep':
            totals['sweep_by_5m']+=news.stamp(observed['known_at'])<=after[0].time+M5
            if first_confirmation:
                totals['sweep_at_or_before_first_confirmation']+=(
                    news.stamp(observed['known_at'])<=news.stamp(first_confirmation))
    return dict(window=window['window'],scope=window['scope'],totals=totals,candidates=candidates,
                previous_omissions=old_misses,first_confirmation=first_confirmation,decisions=decisions)


def summarize(rows):
    totals = Counter(windows=len(rows))
    decisions = defaultdict(Counter)
    for row in rows:
        totals.update(row['totals'])
        totals['directional_evidence_windows'] += bool(row['first_confirmation'])
        for delay,attempt in row['decisions'].items():
            if 'nearest' not in attempt:
                continue
            nearest,directional = attempt['nearest'],attempt['directional']
            decisions[delay].update(tested=1,same=int(nearest['rank']==directional['rank']),
                                    nearest=int(nearest['observed']['label']=='sweep'),
                                    directional=int(directional['observed']['label']=='sweep'))
    return dict(totals=totals,decisions=decisions)


def main():
    digest = news.study.digest
    previous = json.loads(BASE.read_bytes())
    m1path = MINUTES/'XAUUSD_M1.json.gz'
    m1lock = json.loads((MINUTES/'m1-lock.json').read_bytes())
    assert digest(m1path)==m1lock['digest']
    path = news.ranking.ARCHIVE/news.CANDIDATE_FILE
    assert digest(path)==previous['inputs'][path.name]
    market_lock = json.loads((path.parent/'round19_liquidity_50_lock.json').read_bytes())
    archive = next(ROOT/key for key in market_lock['sources'] if key.endswith('/XAUUSDM5.npz'))
    assert digest(archive)==previous['inputs'][archive.name]
    freezes = {news.stamp(r['at']):r for r in news.study.read_zip(path)}
    m1 = {news.stamp(t):Bar(news.stamp(t),o,h,l,c,0)
          for t,o,h,l,c in news.study.read_zip(m1path)}
    coarse = {b.time:b for b in news.context.read_market()[0]}
    seen = set()
    windows = []
    skipped = []
    for release in previous['windows']:
        for cohort in ('release','controls'):
            for scope in news.LEVELS:
                items = (release[cohort][scope],) if cohort=='release' else release[cohort][scope]
                for item in items:
                    if not item or (cohort,item['window'],scope) in seen:
                        continue
                    seen.add((cohort,item['window'],scope))
                    at = news.stamp(item['window'])
                    verified,error = aligned_window(coarse,m1,at)
                    if not verified:
                        skipped.append(dict(group=cohort,scope=scope,window=item['window'],reason=error))
                        continue
                    scale = freezes[news.stamp(item['frozen'])]['pools'][scope][0]['hourly_range']
                    windows.append(dict(group=cohort,**replay_window(item,*verified,scale)))
    summary = {side:{group:summarize([row for row in windows if row['scope']==side and row['group']==group])
                    for group in ('release','controls')} for side in news.LEVELS}
    out = news.study.RESEARCH/'ict_liquidity_news_m1_review.json'
    report = dict(inputs={f.name:digest(f) for f in (BASE,path,m1path,archive,Path(__file__),
                       ROOT/'scripts/replay_ict_liquidity_news.py')},summary=summary,skipped=skipped,windows=windows,
                  method='Only windows whose continuous M1 rows reproduce each pre/post 30-minute M5 OHLC. '
                         'Same frozen rank 11-50, score <=65 candidate set. +1 through +5 closed M1 decisions. '
                         'Same displacement thresholds as M5 using the same 30-minute pre-event M5 baseline. '
                         'First M1 witness labels mark minimum available resolution; no intrabar path inference.')
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(summary=summary,skipped=skipped),ensure_ascii=False))


if __name__=='__main__':
    main()
