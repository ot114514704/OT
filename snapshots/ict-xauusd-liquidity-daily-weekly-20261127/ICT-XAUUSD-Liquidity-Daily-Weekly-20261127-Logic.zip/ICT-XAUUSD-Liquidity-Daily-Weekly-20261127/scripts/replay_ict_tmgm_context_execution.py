"""Test frozen D1/W1 context and target selection on TMGM classic 1.1 tick orders."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter
from dataclasses import asdict, replace
from datetime import date, timedelta
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
import json
from pathlib import Path

from brooks_ai.types import utc_time
from ict_ai.tick_portfolio import replay_tick_portfolio
from ict_ai.timebase import NY, session_windows
from scripts import replay_ict_tmgm_profile_one as baseline
from scripts.audit_profile_one_signal_context import examine
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_ipda_profiles import weekly_order_cohorts
from scripts.serve_ict_live import atomic_json


archive = baseline.archive
ROOT = baseline.ROOT
M5 = baseline.STEP
HISTORY = timedelta(weeks=13)
REFERENCE = archive.RESEARCH / 'ict_classic_reversal_tmgm_bidask_asof_20261123'
SOURCES = (
    (REFERENCE.with_name(REFERENCE.name + '_earlier.json'),
     baseline.ARTIFACT.with_name('ict_classic_reversal_tmgm_bidask_20250701_20260529.json.gz')),
    (REFERENCE.with_name(REFERENCE.name + '_recent.json'), baseline.ARTIFACT),
)


def load_period(source, tape, config, risk):
    report = json.loads(source.read_bytes())
    start, end = (date.fromisoformat(report[k]) for k in ('start', 'end'))
    bars, spec, feed = baseline.reference(start, end)
    quotes = archive.read_zip(tape)
    meta = report['inputs']
    if (quotes['meta'] != meta or archive.digest(tape) != report['raw_tick_archive_sha256']
            or archive.digest(baseline.check_pool_priority.ARCH / 'XAUUSDM5.npz') != meta['bars_sha256']
            or archive.digest(baseline.CONTRACT) != meta['contract_sha256']
            or feed['server'] != meta['server'] or feed['clock'] != meta['clock']
            or archive.digest(ROOT / 'config/strategy.json') != meta['risk_config_sha256']):
        raise ValueError(f'Inputs differ from the frozen TMGM study: {source.name}')
    signals, orders, checks = baseline.freeze_orders(bars, spec)
    serialized = lambda data: json.loads(json.dumps(data, default=lambda t: t.isoformat()))
    if serialized(signals) != report['signals'] or serialized([asdict(o) for o in orders]) != meta['orders']:
        raise ValueError(f'Frozen signal replay changed: {source.name}')
    ticks, witnesses = baseline.verify_tape(bars, baseline.session_spans(orders), quotes['sessions'])
    if serialized(witnesses) != report['witnesses']:
        raise ValueError(f'Tick witness replay changed: {source.name}')
    cutoff = bars[-1].time + M5
    fees = report['books']['base']['costs_assumed']
    priced = replace(spec, commission_round_turn=fees['commission_round_turn_per_lot'],
                     slippage=fees['adverse_slippage'])
    book = serialized(replay_tick_portfolio(orders, ticks, priced, cutoff, config['initial_equity'], risk))
    if any(report['books']['base'][key] != value for key, value in book.items()):
        raise ValueError(f'Unfiltered tick account changed: {source.name}')
    return orders, ticks, spec, cutoff, checks, feed['server']


def target_order(order, view, spec, min_reward_risk):
    """Round a frozen DOL proxy inward and check the planned return net of costs."""
    route = view['morning_route']['selected_route']
    grid = Decimal(str(spec.tick_size))
    rounding = ROUND_FLOOR if order.side == 1 else ROUND_CEILING
    target = (Decimal(str(route['target_reference_price'])) / grid).to_integral_value(rounding) * grid
    reward = order.side * (float(target) - order.entry)
    fee_price = spec.commission_round_turn / spec.contract_size
    risk_price = abs(order.entry - order.stop) + 2 * spec.slippage + fee_price
    net_r = (reward - fee_price) / risk_price
    if net_r < min_reward_risk:
        return None, dict(status='below_costed_reward_risk', target=float(target), planned_net_reward_risk=net_r)
    return replace(order, target=float(target)), dict(status='target_in_range', target=float(target),
                                                       planned_net_reward_risk=net_r)


def permitted_morning(view):
    return (view['morning_route']['selected_route'] is not None and
            view['morning_route']['direction'] == view['side'] and
            view['morning_target_path']['status'] == 'untouched')


def run():
    config = json.loads((ROOT / 'config/strategy.json').read_bytes())
    risk = {k: config[k] for k in ('risk_fraction', 'daily_loss_limit', 'max_drawdown', 'max_consecutive_losses')}
    orders, ticks, signal_prefix_checks, quote_server = [], [], 0, None
    for source, tape in SOURCES:
        period_orders, period_ticks, spec, cutoff, checks, server = load_period(source, tape, config, risk)
        if quote_server is not None and (server != quote_server or spec != instrument):
            raise ValueError('Replay periods use different quote servers or contracts')
        orders.extend(period_orders)
        ticks.extend(period_ticks)
        signal_prefix_checks += checks
        instrument, quote_server = spec, server
    bars, times = baseline.check_pool_priority.read_market()
    cases = {}
    for order in orders:
        at = order.available_at
        morning = session_windows(at.astimezone(NY).date())['new_york'][0]
        first = morning - HISTORY
        start = bisect_left(times, first)
        stop = bisect_left(times, at)
        # Keep the signal session's later bars in the test input. The shared
        # route and weekly helpers compare that input against a closed prefix.
        through = bisect_left(times, at + timedelta(hours=4))
        rows = bars[start:through]
        quarters = aggregate_bars(rows, 5, 15, at + timedelta(hours=4))
        view = examine(rows, quarters, order)
        view.update(history_start=times[start].isoformat(), full_warmup_available=times[0] <= first,
                    signal_m5_count=stop-start)
        cases[order.id] = view
    week = weekly_order_cohorts(orders, {o.available_at: cases[o.id]['week'] for o in orders})
    matching_week = {o.id for o in week['only_matching_week']}
    context = [o for o in orders if permitted_morning(cases[o.id])]
    retained = [o for o in context if cases[o.id]['route_filter'] == 'same_direction_same_open_target']
    books = {}
    target_decisions = {}
    for name, commission, slippage in (('base', 7., .05), ('adverse', 14., .15)):
        cost = replace(instrument, commission_round_turn=commission, slippage=slippage)
        priced_targets = []
        target_decisions[name] = {}
        for order in context:
            template, decision = target_order(order, cases[order.id], cost, config['min_reward_risk'])
            target_decisions[name][order.id] = decision
            if template is not None:
                priced_targets.append(template)
        cohorts = dict(geometry_2r=orders, morning_target_open_2r=context, morning_route_still_selected_2r=retained,
                       morning_target_open_and_matching_week_2r=[o for o in context if o.id in matching_week],
                       morning_target_as_exit=priced_targets)
        books[name] = {}
        for key, templates in cohorts.items():
            result = replay_tick_portfolio(templates, ticks, cost, cutoff, config['initial_equity'], risk)
            books[name][key] = dict(**result, admission_count=len(templates),
                                    decision_status_counts=dict(Counter(d['status'] for d in result['decisions'])),
                                    decision_prefix_checks=baseline.verify_decision_prefixes(
                                        templates, ticks, cost, config['initial_equity'], risk, result['decisions']))

    code = (Path(__file__), ROOT / 'scripts/audit_profile_one_signal_context.py', ROOT / 'scripts/replay_ict_tmgm_profile_one.py',
            ROOT / 'scripts/replay_ict_route_checkpoints.py', ROOT / 'scripts/replay_ict_ipda_profiles.py',
            ROOT / 'ict_ai/daily_context.py', ROOT / 'ict_ai/route_study.py', ROOT / 'ict_ai/delivery.py',
            ROOT / 'ict_ai/tick_portfolio.py', ROOT / 'ict_ai/tick_limit.py', ROOT / 'config/strategy.json',
            ROOT / 'research/ict_price_videos/bias_dol/integration.json',
            ROOT / 'research/ict_time_videos/time2_daily/integration.json', ROOT / 'research/ict_time_videos/time3_weekly/integration.json')
    return dict(server=quote_server, instrument=asdict(instrument), signals=len(orders), verified_quotes=len(ticks),
                signal_prefix_checks=signal_prefix_checks,
                route_status_counts=dict(Counter(case['route_filter'] for case in cases.values())),
                morning_open_count=len(context), retained_route_count=len(retained),
                cases=list(cases.values()), priced_target_decisions=target_decisions, paper_accounts=books,
                inputs={p.relative_to(ROOT).as_posix(): archive.digest(p) for pair in SOURCES for p in pair},
                code_and_course_sources={p.relative_to(ROOT).as_posix(): archive.digest(p) for p in code},
                assumptions=dict(warmup='Up to 13 weeks of earlier M5', morning_ny='07:00', min_planned_net_r=config['min_reward_risk'],
                                 commission_slippage=dict(base=[7., .05], adverse=[14., .15]), outcome_basis='Assumed quote-touch fills',
                                 target_basis='D1/W1 route proxy, same direction and untouched at confirmation'),
                limits=['Retrospective hypothesis check on the existing sample', 'Costs and queue fills unverified',
                        'Study hours and route proxies do not establish full ICT qualification'], orders_sent=0)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=archive.RESEARCH / 'ict_classic_reversal_tmgm_context_execution_20261123.json')
    args = parser.parse_args()
    result = run()
    atomic_json(args.out, json.loads(json.dumps(result, default=lambda t: t.isoformat())))
    print('Signals:', result['signals'], 'morning route decisions:', result['route_status_counts'])
    for name, book in result['paper_accounts'].items():
        for key, account in book.items():
            print(name, key, account['admission_count'], account['decision_status_counts'], account['final_realized_equity'])
