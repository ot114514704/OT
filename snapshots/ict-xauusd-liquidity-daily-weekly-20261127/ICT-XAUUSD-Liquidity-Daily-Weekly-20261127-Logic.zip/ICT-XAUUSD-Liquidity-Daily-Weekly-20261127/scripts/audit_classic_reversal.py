"""Audit the first observed 1.1 candidate on each complete NY day, by direction."""
from argparse import ArgumentParser
from collections import Counter
from datetime import date, datetime, timedelta
from hashlib import sha256
import json
from pathlib import Path

from brooks_ai.types import Bar
from ict_ai.profile_lifecycle import _extension, _reclaim
from ict_ai.timebase import NY, session_windows
from scripts.export_mt5_profiles import midnight
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_news import ROOT, STEP


def replacement_events(quotes, quarters, known, noon, side, swept, opposite, news=()):
    """Only closed M5 bars can break a pivot. Re-qualification needs a new M15 close."""
    def extreme(bar):
        return bar.low if side==1 else bar.high
    previous=[extreme(bar) for bar in quotes if bar.time+STEP<=known]
    record=min(previous) if side==1 else max(previous)
    period=3*STEP
    quarter_ends={bar.time+period:bar for bar in quarters}
    events=[]
    pending=active=previous_outside=None
    followed=False
    for bar in quotes:
        at=bar.time+STEP
        if at<=known:
            continue
        price=extreme(bar)
        if side*(price-record)<0:
            record=price
            if active is not None:
                events.append({"kind":"broken","at":at.isoformat(),"pivot_at":active})
            active=previous_outside=None
            followed=False
            pending=bar if at<=noon and side*(price-swept)<0 else None
        quarter=quarter_ends.get(at)
        if quarter is None or at>noon:
            continue
        if pending is not None and side*(quarter.close-swept)>0:
            active=at.isoformat()
            releases=[r for r in news if r<=pending.time<r+timedelta(minutes=30)]
            events.append({"kind":"reclaim","at":active,"pivot_at":active,"price":record,
                           "extreme_m5_known_at":(pending.time+STEP).isoformat(),
                           "nearby_releases":[r.isoformat() for r in releases]})
            pending=None
            continue
        if active is not None and not followed:
            if side*(quarter.close-opposite)>0:
                if previous_outside==at-period:
                    events.append({"kind":"follow","at":at.isoformat(),"pivot_at":active})
                    followed=True
                previous_outside=at
            else:
                previous_outside=None
    return events


def audit_case(day, replay, side, episode, news=(), *, verify_prefix=False):
    start=midnight(day)
    end=start+timedelta(minutes=replay["end"])
    quotes=[Bar(start+timedelta(minutes=t)-STEP,o,h,l,c,0)
            for t,o,h,l,c in replay["bars"] if 0<t<=replay["end"]]
    period=3*STEP
    quarters=aggregate_bars(quotes,5,15,end)
    windows=session_windows(day)
    def window(name):
        lo,hi=windows[name]
        return [b for b in quarters if lo<=b.time and b.time+period<=hi]
    london=window("london")
    ny=window("new_york")
    swept=min(b.low for b in london) if side==1 else max(b.high for b in london)
    opposite=max(b.high for b in london) if side==1 else min(b.low for b in london)
    reclaim=_reclaim(ny,swept,-side,period)
    if reclaim is None:
        raise ValueError(f"No closed M15 reclaim for archived 1.1 candidate on {day}")
    known=reclaim.time+period
    if known!=start+timedelta(minutes=episode["start"]):
        raise ValueError(f"Archive candidate time disagrees with M15 reclaim on {day}")
    before=[b for b in quotes if b.time+STEP<=known]
    ny_before=[b for b in before if b.time>=windows["new_york"][0]]
    def extreme(bars):
        return min(b.low for b in bars) if side==1 else max(b.high for b in bars)
    price=extreme(ny_before)
    broken=next((b for b in quotes if b.time>=known and
                 (b.low<price if side==1 else b.high>price)),None)
    following=_extension(quarters,opposite,side,period,after=known)
    follow_at=following.time+period if following else None
    holds=side*(quotes[-1].close-opposite)>0
    replacements=replacement_events(quotes,quarters,known,windows["london_close"][1],side,swept,opposite,news)
    checks=0
    if verify_prefix:
        points={known}
        for event in replacements:
            at=datetime.fromisoformat(event["at"])
            points.update((at-STEP,at))
        for at in sorted(points):
            clipped=[b for b in quotes if b.time+STEP<=at]
            current=replacement_events(clipped,aggregate_bars(clipped,5,15,at),known,windows["london_close"][1],
                                       side,swept,opposite,[r for r in news if r<=at])
            if current!=[e for e in replacements if datetime.fromisoformat(e["at"])<=at]:
                raise AssertionError(f"Future bars changed replacement evidence on {day} at {at}")
            checks+=1
    followed={e["pivot_at"] for e in replacements if e["kind"]=="follow"}
    lost={e["pivot_at"] for e in replacements if e["kind"]=="broken"}
    def stamp(value):
        return value.astimezone(NY).isoformat() if value else None
    return {"day":str(day),"direction":side,"candidate_at_ny":stamp(known),
            "london_swept_boundary":swept,"london_opposite_boundary":opposite,
            "frozen_ny_extreme":price,"day_extreme_at_candidate":extreme(before),
            "ny_extreme_was_day_extreme_at_candidate":price==extreme(before),
            "day_extreme_at_close":extreme(quotes),
            "frozen_ny_extreme_remained_day_extreme":price==extreme(quotes),
            "first_break_known_at_ny":stamp(broken.time+STEP if broken else None),
            "first_two_close_followthrough_ny":stamp(follow_at),
            "day_close":quotes[-1].close,"day_close_beyond_opposite_boundary":holds,
            "followthrough_window":("none" if not follow_at else "by_10" if follow_at<=windows["new_york"][1]
                                    else "by_12" if follow_at<=windows["london_close"][1] else "after_12"),
            "matches_by_10":bool(follow_at and follow_at<=windows["new_york"][1] and not broken and holds),
            "matches_by_12":bool(follow_at and follow_at<=windows["london_close"][1] and not broken and holds),
            "replacement_events":replacements,"replacement_prefix_checks":checks,
            "replacement_matches_at_close":sorted(followed-lost) if holds else [],
            "original_episode_end_reason":episode["end_reason"]}


def run(path):
    raw=path.read_bytes()
    review=json.loads(raw)
    cases=[]
    for week in review["weeks"]:
        for day in week["days"]:
            if not day["coverage"]:
                continue
            seen=set()
            for e in day["replay"]["candidate_intervals"]:
                side=e["direction"]
                if e["id"]!="classic_reversal_variant" or side in seen:
                    continue
                seen.add(side)
                news=[datetime.fromisoformat(n["scheduled_ny"]) for n in day["news"]]
                case=audit_case(date.fromisoformat(day["date"]),day["replay"],side,e,news,verify_prefix=True)
                matched=any(c["id"]==e["id"] and c["direction"]==side for c in day["matched"])
                if matched!=case["matches_by_10"] or (
                        case["first_break_known_at_ny"] is not None)!=(e["end_reason"]=="invalidated"):
                    raise ValueError(f"Strict M15 replay disagrees with panel on {day['date']}")
                cases.append(case)
    course=ROOT/"research/ict_time_videos/time2_daily/integration.json"
    return {"input_sha256":sha256(raw).hexdigest(),"source":str(course.relative_to(ROOT)),
            "source_sha256":sha256(course.read_bytes()).hexdigest(),"course_seconds":[780,930],
            "ppt_slide":17,"scope":"First observed 1.1 candidate per signed day. "
            "M15 reclaim and follow-through, M5 extreme and invalidation. A tied extreme counts. "
            "The two-close and end-of-day filters are research proxies. HTF bias is not verified.",
            "replacement_rule":"After the original reclaim, require a strictly new NY-day extreme past the "
                "London edge and a closed M15 back across that edge by noon NY. Count two subsequent "
                "consecutive M15 closes through the opposite edge by noon. A further extreme invalidates "
                "the pivot, and the day must close beyond the opposite edge. News overlap refers to the "
                "extreme M5 bar opening within 30 minutes following a listed release.",
            "counts":{"candidates":len(cases),
                      "cases_with_replacement":sum(bool(c["replacement_events"]) for c in cases),
                      "cases_with_replacement_follow":sum(any(e["kind"]=="follow" for e in c["replacement_events"]) for c in cases),
                      "cases_with_replacement_match":sum(bool(c["replacement_matches_at_close"]) for c in cases),
                      "ny_extreme_at_signal":sum(c["ny_extreme_was_day_extreme_at_candidate"] for c in cases),
                      "frozen_extreme_held_to_close":sum(c["frozen_ny_extreme_remained_day_extreme"] for c in cases),
                      "frozen_extreme_later_broken":sum(c["first_break_known_at_ny"] is not None for c in cases),
                      "followthrough_window":dict(Counter(c["followthrough_window"] for c in cases)),
                      "close_beyond_opposite_boundary":sum(c["day_close_beyond_opposite_boundary"] for c in cases),
                      "matches_by_10":sum(c["matches_by_10"] for c in cases),
                      "matches_by_12":sum(c["matches_by_12"] for c in cases),
                      "matches_by_12_with_ny_day_extreme":sum(
                          c["matches_by_12"] and c["frozen_ny_extreme_remained_day_extreme"] for c in cases)},"cases":cases}


if __name__=="__main__":
    cli=ArgumentParser(description=__doc__)
    cli.add_argument("--review",type=Path,required=True)
    cli.add_argument("--out",type=Path,required=True)
    args=cli.parse_args()
    result=run(args.review)
    args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(result["counts"])
