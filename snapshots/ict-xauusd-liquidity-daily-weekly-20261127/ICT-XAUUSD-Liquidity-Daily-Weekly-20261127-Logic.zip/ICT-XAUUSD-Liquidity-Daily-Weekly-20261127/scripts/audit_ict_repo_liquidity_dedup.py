"""Measure exact-price deduplication without changing the frozen repository ranker."""

from bisect import bisect_left
from collections import Counter
from datetime import datetime
import json
from pathlib import Path

import joblib
import numpy as np
from threadpoolctl import threadpool_limits

from scripts import audit_ict_repo_vs_local_forecast as upstream
from scripts import audit_ict_repo_vs_local_horizons as horizons


fixed, live, joint = upstream.fixed, upstream.live, upstream.joint
OUT = upstream.DIR / 'deduplicated_rank.json'


def unique_two(rows, field):
    unique = {}
    for row in rows:
        unique.setdefault((row['side'], row[field]), row)
        if len(unique) == 2:
            break
    return list(unique.values())


def rank(rows, feature, model):
    probabilities = model.predict_proba(np.array([feature(row) for row in rows]))[:, 1]
    return [dict(rows[i], score=float(probabilities[i])) for i in np.argsort(-probabilities)]


def measure_native(series, chart_rows, feat, model, validated):
    results = {}
    for period, line in series.items():
        anchors = line.levels.identify_levels(line.bars, period, midnight_pause=period == 'H1', atr_values=line.atr)
        counts = Counter(windows=0, original_top1=0, original_top2=0, unique_top2=0, rank2_replaced=0, unique_only=0,
                         original_only=0, first_two_distinct=0)
        for index, rows in chart_rows(line.bars, anchors, line.atr):
            at = datetime.fromtimestamp(line.closes[index], upstream.UTC)
            if not upstream.VALID_START <= at < upstream.VALID_END:
                continue
            ranked = rank(rows, feat, model)
            # Side and ATR distance identify the exact price inside a single native snapshot.
            unique = unique_two(ranked, 'dist')
            old, new = (any(row['hit'] for row in items) for items in (ranked[:2], unique))
            counts.update(windows=1, original_top1=int(ranked[0]['hit']), original_top2=int(old), unique_top2=int(new),
                          rank2_replaced=int(unique != ranked[:2]), unique_only=int(new and not old),
                          original_only=int(old and not new), first_two_distinct=int(len(unique) == 2))
        expected = validated[period]
        if [counts[k] for k in ('windows', 'original_top1', 'original_top2')] != [
                expected[k] for k in ('windows', 'model_first', 'model_first_two')]:
            raise ValueError(f'Frozen native validation did not reproduce: {period}')
        results[period] = counts
    return results


def candidates(cases, line, feat, model):
    result = {}
    for case in cases:
        stamp = case['cutoff']
        index = bisect_left(line.closes, int(datetime.fromisoformat(stamp).timestamp()))
        if line.closes[index] != int(datetime.fromisoformat(stamp).timestamp()):
            raise ValueError(f'No matching native candle: {stamp}')
        rows = line.inputs(index, prefix=True)
        ranked = rank(rows, feat, model)
        if ranked[:2] != case['repo_predictions']:
            raise ValueError(f'Frozen repository ranks did not reproduce: {stamp}')
        result[stamp] = unique_two(ranked, 'price')
    return result


def test_windows(cases, predictions, minutes, buckets, frozen):
    counts = Counter(windows=0, original_top2=0, unique_top2=0, local_top2=0, rank2_replaced=0, distinct_pair=0,
                     unique_only=0, original_only=0, unique_vs_local_only=0, local_vs_unique_only=0)
    rows = []
    for case in cases:
        stamp = case['cutoff']
        if stamp not in frozen:
            continue
        at = datetime.fromisoformat(stamp)
        ready = datetime.fromisoformat(case['checked_from'])
        tape = fixed.reconcile([buckets[(at + i * horizons.M5).isoformat()] for i in range(minutes // 5)])
        previous = frozen[stamp]['outcomes']
        if not tape or horizons.grade(case, tape) != previous:
            raise ValueError(f'Frozen Bid outcomes did not reproduce: {stamp}, {minutes} minutes')
        unique = predictions[stamp]
        outcome = []
        for row in unique:
            target = dict(side=row['side'], lo=row['price'], hi=row['price'])
            status, bid_ms = fixed.outcome(target, tape, ready)
            outcome.append(dict(**target, kind=row['kind'], score=row['score'], status=status, bid_time_ms=bid_ms))
        old, new, local = (any(row['status'] == 'sweep' for row in items)
                           for items in (previous['repo'], outcome, previous['local']))
        if old and not new:
            raise ValueError(f'Deduplication removed a swept price: {stamp}')
        counts.update(windows=1, original_top2=int(old), unique_top2=int(new), local_top2=int(local),
                      rank2_replaced=int(unique != case['repo_predictions']), distinct_pair=int(len(unique) == 2),
                      unique_only=int(new and not old), original_only=int(old and not new),
                      unique_vs_local_only=int(new and not local), local_vs_unique_only=int(local and not new))
        rows.append(dict(cutoff=stamp, checked_from=case['checked_from'],
                         outcomes={**previous, 'repo_unique': outcome}))
    return dict(counts=counts, cases=rows)


def main():
    saved = fixed.read(upstream.REPORT)
    shared = fixed.read(horizons.OUT)
    pins = {path.name: joint.digest(path) for path in (
        upstream.REPORT, upstream.TAPE, upstream.MODEL, horizons.OUT, horizons.BID, horizons.week.INPUT, Path(__file__))}
    if (saved['sklearn'] != upstream.sklearn_version or saved['upstream_blobs'] != upstream.BLOBS
            or saved['model_sha256'] != pins[upstream.MODEL.name]
            or any(saved['inputs'][p.name] != pins[p.name] for p in (upstream.TAPE, horizons.week.INPUT))
            or shared['bid_sha256'] != pins[horizons.BID.name]
            or shared['inputs'][upstream.REPORT.name] != pins[upstream.REPORT.name]):
        raise ValueError('A frozen model, ranking, or quote source changed')
    levels, chart_rows, feat, _ = upstream.load_sources()
    evidence = joint.read_zip(upstream.TAPE)
    model = joblib.load(upstream.MODEL)
    series = upstream.native_series(evidence, levels)
    bid = joint.read_zip(horizons.BID)['buckets']
    week = joint.read_zip(horizons.week.INPUT)
    for stamp, registered in week['actual'].items():
        if stamp not in bid and registered.get('buckets'):
            bid[stamp] = registered['buckets'][0]

    cohort = {'oct_nov_H1': saved['native_common_h1_first_m5'], **{
        'current_week_' + key: value for key, value in saved['current_week']['comparisons'].items()}}
    reports = {}
    with threadpool_limits(limits=4):
        for name, group in cohort.items():
            cases = group['cases']
            predictions = candidates(cases, series[name.rsplit('_', 1)[1]], feat, model)
            frozen = {5: cases, **{int(minutes): cell['cases'] for minutes, cell in shared['results'][name].items()}}
            reports[name] = {minutes: test_windows(cases, predictions, minutes, bid,
                              {case['cutoff']: case for case in settlements}) for minutes, settlements in frozen.items()}
        native = measure_native(series, chart_rows, feat, model, saved['training_and_own_120_bar_validation']['native_120_bar'])
    method = ('Keep all repository scores and candidate types. Select the highest score at each exact side and price, '
              'then fill two slots by score where possible. Local candidate list unchanged. Intraday outcome is '
              'a strict post-availability Bid sweep of at least one level. Native 120-bar outcome follows the repository first-hit candle label.')
    live.atomic_json(OUT, dict(method=method, inputs=pins, results=reports, native_120_bar=native, orders_sent=0))
    print(json.dumps(dict(results={name: {minutes: item['counts'] for minutes, item in report.items()}
                                  for name, report in reports.items()}, native_120_bar=native)), flush=True)


if __name__ == '__main__':
    main()
