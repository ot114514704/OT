"""Build a recent NY-day replay from closed TMGM bars and actual forecast receipts."""

from argparse import ArgumentParser
from datetime import datetime, timedelta
from html import escape
from math import ceil
from pathlib import Path
import json

from ict_ai.liquidity_repo_overlay import outside
from ict_ai.profile_lifecycle import _day_bounds, daily_profile_lifecycle
from ict_ai.profile_score_explanation import explain_profile_score
from ict_ai.profile_sources import DAILY, course_reference
from ict_ai.timebase import NY, daily_profile_history_start
from scripts import audit_ict_daily_quote_revision as revisions
from scripts import audit_ict_intraday_abstention as calibration
from scripts import audit_ict_intraday_profile_confirmation as confirmation
from scripts import profile_day_replay as replay
from scripts import settle_ict_daily_learning as market
from scripts import watch_ict_liquidity_repo_overlay as overlay
from scripts import watch_ict_profile_feed as daily_feed
from scripts import watch_ict_weekly_candidates as weekly_feed
from scripts.prepare_ict_week import aggregate_bars


fixed, joint, live, M5 = overlay.fixed, overlay.joint, overlay.live, overlay.M5
OUT = joint.ROOT / 'output/visualizations/ict-recent-profile-replay.html'
TEMPLATE = joint.ROOT / 'scripts/profile_day_replay.html'


def recent_days(observed):
    today = observed.astimezone(NY).date()
    dates = (today - timedelta(days=index) for index in range(7))
    return sorted([day for day in dates if day.weekday() < 5][:3])


def registered_liquidity(cutoff, history):
    policy, local = overlay.load_policy()
    reference = {bar.time + M5: bar.close for bar in history}
    rows = []
    for receipt, record, at, ready in overlay.registered(policy, local):
        if ready > cutoff or at <= history[0].time:
            continue
        if reference.get(at) != record['close']:
            raise ValueError(f'The chart replay has a different close at the registered H1 cutoff: {at}')
        results = []
        for minutes in overlay.HORIZONS:
            result_file = overlay.OUT / 'settlements' / f'{receipt.stem}_{minutes}.json'
            if not result_file.is_file():
                continue
            result = fixed.read(result_file)
            written = datetime.fromisoformat(result['settled_at'])
            if written > cutoff:
                continue
            bid = overlay.OUT / 'bid' / result_file.with_suffix('.json.gz').name
            starts = [at + i * M5 for i in range(minutes // 5)]
            checked = overlay.grade(record, ready, joint.read_zip(bid), starts)
            if (written < at + timedelta(minutes=minutes) or result['receipt_sha256'] != joint.digest(receipt)
                    or result['bid_sha256'] != joint.digest(bid) or any(result[k] != val for k, val in checked.items())):
                raise ValueError(f'Invalid live sweep settlement: {result_file.name}')
            hits = {name: any(quote['status'] == 'sweep' for quote in marks) for name, marks in result['arms'].items()}
            results.append(dict(minutes=minutes, written=written, state=result['state'], hits=hits))
        rows.append(dict(at=at, ready=ready, settled=results,
                         picks={arm: list(map(outside, record[arm])) for arm in ('local', 'integrated')}))
    return rows


def course_label(ident, weekly=False):
    reference = course_reference(ident, weekly=weekly)
    return dict(label=reference.split(' · PPT', 1)[0] if reference else ident, source=reference)


def daily_revision_evidence(observed):
    if not revisions.OUT.is_file():
        return {}
    audit = fixed.read(revisions.OUT)
    if datetime.fromisoformat(audit['observed_at']) > observed:
        return {}
    tape = revisions.OUT.with_suffix('.json.gz')
    if audit['inputs'][tape.name] != joint.digest(tape):
        raise ValueError('Daily revision evidence no longer matches its Bid archive')
    return {row['forecast_sha256']: row for row in audit['records'] if row['agrees_with_bid'] == 'latest_native'}


def daily_outcome(path, record, prefix, observed, revision_evidence):
    result_path = daily_feed.ROOT / 'settlements' / path.name
    if result_path.is_file():
        result = fixed.read(result_path)
        captured = datetime.fromisoformat(result['captured_at'])
        if captured <= observed:
            tail = market.decode_bars(result['settlement_m5'])
            if daily_feed.settlement_record(path, record, prefix, tail, captured) != result:
                raise ValueError(f'Daily settlement did not reproduce: {path.name}')
            return dict(status=result['status'], captured=result['captured_at'],
                        actual_paths=[dict(**course_label(key), direction=side) for key, side in result['actual_paths'] or []],
                        matched=sum(row['matched'] for row in result['candidate_results']), sha256=joint.digest(result_path))
    revision = revision_evidence.get(joint.digest(path))
    if revision:
        return dict(status='history_changed', price_changes=revision['price_changes'])
    end = datetime.fromisoformat(record['forecast_end'])
    return dict(status='waiting_for_day_end' if observed < end + market.SYNC_GRACE else 'waiting_for_settlement')


def registered_profiles(days, observed):
    models = {source: source.load_model() for source in (daily_feed.early, daily_feed.daily)}
    sources = {clock: (source, models[source]) for clock in daily_feed.CHECKPOINTS
               for source in (daily_feed.early if clock in daily_feed.EARLY else daily_feed.daily,)}
    daily_proofs, weekly_proofs = [], []
    protocol = daily_feed.read_protocol()
    revision_evidence = daily_revision_evidence(observed)
    for day in days:
        for path in sorted(daily_feed.ROOT.glob(f'{day.isoformat()}_????.json')):
            record, prefix = daily_feed.validate(path, sources, protocol)
            at, ready = map(datetime.fromisoformat, (record['cutoff'], record['recorded_at']))
            if ready > observed:
                continue
            early = daily_feed.checkpoint(at) in daily_feed.EARLY
            probability = 'pooled_probability' if early else 'learned_probability'
            weights = models[daily_feed.early if early else daily_feed.daily]['model']
            features = list(daily_feed.daily.learning.FEATURES)
            if early:
                features.append('elapsed_since_ny_0700')
            candidates = [dict(**course_label(row['profile']), direction=row['direction'], probability=row[probability],
                               explanation=explain_profile_score(weights, features, row['features'], row[probability], DAILY))
                          for row in record['candidates']]
            daily_proofs.append(dict(at=at, ready=ready, candidates=candidates, close=record['native_m5'][-1],
                status=record['status'], sha256=joint.digest(path),
                outcome=daily_outcome(path, record, prefix, observed, revision_evidence)))
    protocol = weekly_feed.read_protocol(weekly_feed.CLOCK)
    mondays = sorted({day - timedelta(days=day.weekday()) for day in days})
    for monday in mondays:
        schedule, _, _, times = weekly_feed.schedule(monday)
        for name, at in times.items():
            path = weekly_feed.ARCHIVE / monday.isoformat() / f'{name}.json'
            if not path.is_file():
                continue
            saved = weekly_feed.read_json(path)
            original_protocol = saved['protocol']
            if original_protocol['clock_sha256'] != protocol['clock_sha256']:
                raise ValueError(f'The weekly registration used a different clock: {path.name}')
            # Preserve the stored protocol while requiring today's code to reproduce
            # the entire registered result and provenance from its original bars.
            evidence = weekly_feed.verified_forecast(path, schedule, name, at, original_protocol)
            ready = datetime.fromisoformat(evidence['captured_at'])
            if ready > observed:
                continue
            status = evidence['state']
            watch = status['friday_watch']
            active = weekly_feed.active(status['original'] + ([watch] if watch else []))
            candidates = [dict(**course_label(ident, weekly=True), direction=direction)
                          for ident, direction in sorted(active, key=lambda target: (target[0], target[1] or 0))]
            weekly_proofs.append(dict(at=at, ready=ready, candidates=candidates, covered=status['covered'],
                                      week=monday.isoformat(), sha256=joint.digest(path),
                                      same_protocol=original_protocol == protocol))
    return daily_proofs, weekly_proofs


def make_day(day, observed, history, quarters, boards, profiles):
    start, end = _day_bounds(day)
    through = min(end, start + ((observed - start) // M5) * M5)
    context = daily_profile_lifecycle(quarters, day, through, reference_m5=history, include_reconstruction=False)
    chart = replay.day_replay(history, quarters, day, [], context, as_of=through)
    chart['end'] = int((min(observed, end) - start).total_seconds() // 60)
    chart['scrubStep'] = 1

    def minute_visible(at):
        return ceil((at - start).total_seconds() / 60)

    chart['liquidityOverlay'] = [dict(cutoff=minute_visible(row['at']), visible=minute_visible(row['ready']),
        picks=row['picks'], source='recorded', settlements=[dict(minutes=result['minutes'],
            visible=minute_visible(result['written']), state=result['state'], hits=result['hits'])
            for result in row['settled']]) for row in boards if start <= row['at'] < end]
    daily_proofs, weekly_proofs = profiles
    day_proofs = [row for row in daily_proofs if start <= row['at'] < end]
    chart['dailyRegistered'] = [dict(visible=minute_visible(row['ready']), time=row['ready'].astimezone(NY).strftime('%H:%M:%S'),
        candidates=row['candidates'], close=row['close'], status=row['status'], sha256=row['sha256'])
        for row in day_proofs]
    monday = day - timedelta(days=day.weekday())
    chart['weeklyRegistered'] = [dict(visible=max(0, minute_visible(row['ready'])),
        time=row['ready'].astimezone(NY).strftime('%m-%d %H:%M:%S'), candidates=row['candidates'],
        covered=row['covered'], sha256=row['sha256'], sameProtocol=row['same_protocol']) for row in weekly_proofs
        if row['week'] == monday.isoformat() and row['ready'] < end]
    return dict(date=day.isoformat(), through=through.isoformat(), daily=context['profile_label'],
                weekly=context['weekly_background']['label'], chart=chart,
                daily_outcomes=[dict(checkpoint=row['at'].astimezone(NY).strftime('%H:%M'),
                                     candidates=len(row['candidates']), **row['outcome']) for row in day_proofs])


def render_daily_outcomes(rows):
    if not rows:
        return ''
    rendered = []
    for row in rows:
        state = row['status']
        if state == 'scored':
            paths = '、'.join(mark['label'] for mark in row['actual_paths']) or '当日未形成规则形态'
            captured = datetime.fromisoformat(row['captured']).astimezone(NY).strftime('%m-%d %H:%M')
            result = f'符合日收盘规则 {row["matched"]}/{row["candidates"]}，核实于 {captured} NY。收盘路径 {paths}。'
        elif state == 'history_changed':
            names = {'open': '开盘', 'high': '最高', 'low': '最低', 'close': '收盘'}
            fields = '、'.join(f'{names[key]} {old:.2f} → {new:.2f}' for key, (old, new) in row['price_changes'].items())
            result = f'决策 K 线后来修订（{fields}），单独留档。'
        else:
            result = {'waiting_for_day_end': '待日收盘核对。', 'waiting_for_settlement': '已过日终，待核对报价。',
                      'insufficient_m5_coverage': '收盘报价覆盖不足。', 'no_candidate': '登记时暂无候选。'}.get(state, '暂无可用结算。')
        rendered.append(f'<li><b>{escape(row["checkpoint"])} NY</b>　{escape(result)}</li>')
    return '<details class="daily-outcomes"><summary>日概况收盘结算</summary><ul>' + ''.join(rendered) + '</ul></details>'


def historical_thresholds():
    if not calibration.OUT.is_file():
        return None
    audit = fixed.read(calibration.OUT)
    if (audit['hashes'][calibration.INTRADAY.name] != joint.digest(calibration.INTRADAY)
            or audit['hashes']['audit_ict_intraday_abstention.py'] != joint.digest(Path(calibration.__file__))):
        raise ValueError('The intraday threshold report does not match its archived scores or audit code')
    return dict(**audit['paired_rule'], sha256=joint.digest(calibration.OUT))


def historical_confirmation(thresholds):
    path = joint.ROOT / confirmation.OUT
    if not thresholds or not path.is_file():
        return None
    audit = fixed.read(path)
    if (audit['source_sha256'] != thresholds['sha256']
            or [row['date'] for row in audit['dates']] != thresholds['dates']):
        raise ValueError('The profile confirmation audit refers to a different threshold archive or cohort')
    return audit['close_rule']


def render_confirmation(metrics):
    if not metrics:
        return ''
    labels = (
        ('first_calibrated_65', '最早达标 · 65% 校准档'),
        ('first_consecutive_calibrated_65', '最早达标且连续一致 · 65% 校准档'),
        ('1000_calibrated_65', '10:00 · 65% 校准档'),
        ('1000_consecutive_calibrated_65', '10:00 连续一致 · 65% 校准档'),
        ('1000_calibrated_75', '10:00 · 75% 校准档'),
    )
    rows = []
    for policy, label in labels:
        row = metrics[policy]
        rows.append(f'<tr><th scope="row">{label}</th><td>{row["correct"]}/{row["offered"]}</td>'
                    f'<td>{row["incorrect"]}</td><td>{row["abstained"]}</td></tr>')
    return ('<p>同一批交易日逐日比较给出首选的时机。连续一致指前一时点的首选与当前形态、方向均相同。'
            '门槛只在当前时点检查。</p><div class="threshold-scroll"><table><thead><tr>'
            '<th scope="col">给出首选的条件</th><th scope="col">符合收盘规则 / 给出首选</th>'
            '<th scope="col">首选错误</th><th scope="col">未给出首选</th></tr></thead>'
            f'<tbody>{"".join(rows)}</tbody></table></div>')


def render_historical_thresholds(report, confirmation_metrics=None):
    if not report or not report['dates']:
        return ''
    dates = report['dates']
    rows = []
    for clock, checkpoint in report['cutoffs'].items():
        cells = []
        for policy in ('offer_all', 'fixed_50', *calibration.base.TARGETS):
            row = checkpoint['results'][policy]
            cells.append(f'<td>{row["correct"]}/{row["offered"]}</td>')
        rows.append(f'<tr><th scope="row">{escape(clock)}</th>{"".join(cells)}'
                    f'<td>{checkpoint["reliability_rule"]["brier"]:.3f}</td></tr>')
    return ('<details class="daily-thresholds"><summary>每日候选历史筛选对照</summary>'
            f'<p>{escape(dates[0])} 至 {escape(dates[-1])}，四个时点均有可结算首选的 {len(dates)} 个纽约日。'
            'Brier 越低，首选概率的预测误差越小。</p>'
            '<div class="threshold-scroll"><table><thead><tr><th scope="col">纽约时间</th>'
            '<th scope="col">全部保留</th><th scope="col">固定 0.50</th><th scope="col">历史目标 65%</th>'
            '<th scope="col">历史目标 75%</th><th scope="col">Brier</th></tr></thead>'
            f'<tbody>{"".join(rows)}</tbody></table></div>'
            '<p>格内为符合收盘规则的首选数 / 保留的首选数。0/0 表示这档在该时点未保留任何首选。'
            '历史目标门槛只使用较早纽约周已结算样本校准，结果用于复盘研究。</p>'
            + render_confirmation(confirmation_metrics) + '</details>')


def render(report):
    data = {day['date']: day['chart'] for day in report['days']}
    encoded = json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
    rows = []
    for day in reversed(report['days']):
        name = escape(day['date'])
        stamp = datetime.fromisoformat(day['through']).astimezone(NY).strftime('%H:%M')
        rows.append(f'<section><h2>{name} · {stamp} NY</h2><p>{escape(day["daily"])} · {escape(day["weekly"])}</p>'
                    f'<button class="open-replay" data-open-replay="{name}">K线回放</button>'
                    + render_daily_outcomes(day['daily_outcomes']) + '</section>')
    return ('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
            '<title>XAUUSD 最近交易日复盘</title><style>body{max-width:860px;margin:2rem auto;padding:0 1rem;'
            'color:#173441;font:16px/1.5 system-ui,sans-serif}section{border-top:1px solid #c8d8da;padding:1rem 0}'
            'h2{margin:0;font-size:1.1rem}.daily-outcomes,.daily-thresholds{margin:.65rem 0}summary{cursor:pointer}'
            '.threshold-scroll{overflow:auto}.daily-thresholds table{border-collapse:collapse;font-variant-numeric:tabular-nums}'
            '.daily-thresholds th,.daily-thresholds td{border-bottom:1px solid #c8d8da;text-align:left;padding:.4rem .7rem;white-space:nowrap}'
            '</style><h1>XAUUSD 最近交易日复盘</h1>'
            '<p>纽约时间。日周概况与 AMD 按归档报价逐根回放，流动性候选与结算沿用实际登记时间。</p>'
            + render_historical_thresholds(report.get('historical_thresholds'), report.get('historical_confirmation'))
            + ''.join(rows)
            + TEMPLATE.read_text(encoding='utf-8').replace('__DAY_REPLAY_DATA__', encoded) + '</html>')


def main():
    import MetaTrader5 as mt5

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--terminal-pid', type=int, required=True)
    args = parser.parse_args()
    observed = live.now()
    days = recent_days(observed)
    model = market.registration.load_model()
    with overlay.fixed.open_terminal(args.terminal_pid) as alive:
        history = market.capture_tail(mt5, alive, model, daily_profile_history_start(days[0]), observed)
    if not history:
        raise RuntimeError('No closed native M5 available')
    quarters = aggregate_bars(history, 5, 15, observed)
    boards = registered_liquidity(observed, history)
    profiles = registered_profiles(days, observed)
    thresholds = historical_thresholds()
    report = dict(observed_at=observed.isoformat(), native_m5=market.encode_bars(history),
                  days=[make_day(day, observed, history, quarters, boards, profiles) for day in days],
                  historical_thresholds=thresholds, historical_confirmation=historical_confirmation(thresholds),
                  orders_sent=0)
    live.atomic_json(OUT.with_suffix('.json'), report)
    temp = OUT.with_suffix('.tmp.html')
    temp.write_text(render(report), encoding='utf-8')
    live.feed.replace_with_retry(temp, OUT)
    print(json.dumps(dict(path=str(OUT), days=len(days), registered=len(boards),
                          registered_daily=len(profiles[0]), registered_weekly=len(profiles[1]))))


if __name__ == '__main__':
    main()
