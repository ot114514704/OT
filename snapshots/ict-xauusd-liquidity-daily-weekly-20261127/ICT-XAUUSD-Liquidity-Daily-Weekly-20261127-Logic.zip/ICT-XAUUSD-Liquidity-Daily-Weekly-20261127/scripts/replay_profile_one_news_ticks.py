"""Replay the four Jan/Feb 2025 US payroll and CPI windows against frozen XAUUSD ranges."""
from argparse import ArgumentParser
from datetime import datetime, timedelta
from html import escape
import json
from pathlib import Path
from statistics import median

from ict_ai.profile_lifecycle import daily_profile_lifecycle
from ict_ai.timebase import NY
from scripts.export_mt5_profiles import midnight
from scripts.prepare_ict_week import aggregate_bars
from scripts.profile_day_replay import day_replay
from scripts.replay_ict_news import ROOT, STEP, measure, block
from scripts.replay_ict_news_progression import phase_path
from scripts.replay_profile_one_histdata import read_month, digest
from scripts.replay_profile_one_tick_orders import read_intraday_quotes


RELEASES = {"2025-01-10":"美国非农就业报告", "2025-01-15":"美国 CPI、实际收入",
            "2025-02-07":"美国非农就业报告", "2025-02-12":"美国 CPI、实际收入"}


def observe_ticks(ticks, at, bars):
    last = at + timedelta(minutes=30)
    rows = [q for q in ticks if at - timedelta(minutes=30) <= q.time < last]
    mids = [(q.bid + q.ask)/2 for q in rows]
    for i in range(-6, 6):
        start = at + i*STEP
        values = [mid for q, mid in zip(rows, mids) if start <= q.time < start + STEP]
        bar = bars[start]
        if not values or (values[0], max(values), min(values), values[-1]) != (bar.open, bar.high, bar.low, bar.close):
            raise ValueError(f"Event ticks and archived M5 disagree at {start}")
    pre = [v for q,v in zip(rows,mids) if q.time<at]
    lo, hi = min(pre), max(pre)
    events, crossed, returned = [], set(), set()
    for q, mid in zip(rows, mids):
        if q.time < at:
            continue
        for side, boundary, sign in (("上沿",hi,1),("下沿",lo,-1)):
            distance = (mid - boundary)*sign
            if side not in crossed and distance > 0:
                crossed.add(side)
                label = "首次越过" + side
            elif side in crossed and side not in returned and distance < 0:
                returned.add(side)
                label = "首次穿回" + side
            else:
                continue
            local = q.time.astimezone(NY)
            # Quotes stamped exactly at a bucket boundary are in the next candle.
            known = int((q.time - midnight(at.date())) // STEP + 1)*5
            events.append({"minute":known, "clock":local.strftime("%H:%M:%S.%f")[:-3],
                           "label":label, "mid":mid, "bid":q.bid, "ask":q.ask})
    minutes = []
    for offset in (-1,0):
        start = at + timedelta(minutes=offset)
        spreads = [q.ask-q.bid for q in rows if start <= q.time < start+timedelta(minutes=1)]
        minutes.append({"ticks":len(spreads),"median_spread":median(spreads) if spreads else None})
    return {"low":lo,"high":hi,"events":events,"last_minute_before":minutes[0],"first_minute_after":minutes[1],
            "tick_count":len(rows),"max_interquote_seconds":max((b.time-a.time).total_seconds() for a,b in zip(rows,rows[1:]))}


def run(directory):
    months = [read_month(directory, m) for m in ("202501","202502")]
    sources = [s for _,s in months]
    bars = {b.time:b for rows,_ in months for b in rows}
    clocks = [datetime.fromisoformat(d+"T08:30").replace(tzinfo=NY) for d in RELEASES]
    ticks = read_intraday_quotes(directory, sources, [(at-6*STEP, at+6*STEP) for at in clocks])
    records, charts = [], {}
    for at in clocks:
        day = at.date()
        key = day.isoformat()
        name = RELEASES[key]
        clock = at.isoformat()
        url = f"https://www.bls.gov/schedule/2025/{day:%m}_sched_list.htm"
        obs = observe_ticks(ticks, at, bars)
        metrics = measure(bars, at, minutes=30)
        if not metrics or (metrics["pre_low"],metrics["pre_high"])!=(obs["low"],obs["high"]):
            raise ValueError("Pre-release bounds mismatch")
        post = phase_path(block(bars,at,6),obs,set())
        start = midnight(day-timedelta(days=day.weekday()+1))
        end = midnight(day+timedelta(days=1)) if day.weekday()!=4 else midnight(day)+timedelta(hours=17)
        m5 = [b for t,b in bars.items() if start<=t<end]
        m15 = aggregate_bars(m5,5,15,end)
        final = daily_profile_lifecycle(m15,day,end,reference_m5=m5,include_reconstruction=False)
        chart = day_replay(m5,m15,day,[{"scheduled_ny":clock,"announcements":{name:url}}],final)
        chart["releaseTicks"] = {510:obs["events"]}
        charts[key] = chart
        records.append({"scheduled_ny":clock,"name":name,"official_schedule":url,"quotes":obs,
                        "post_30m":post,"horizons":metrics["horizons"],"day_label":final["profile_label"],
                        "day_reason":final["profile_reason"],"day_coverage":final["coverage_complete_under_study_calendar"],
                        "m15_candidate_intervals_from_ny_midnight":chart["candidate_intervals"]})
    return {"sources":sources, "source_directory":str(directory),"records":records,
            "method":"Freeze 08:00–08:30 NY midpoint range, then timestamp each side's first strict crossing and first later quote back across that boundary. M5 closing reclaim separately reported. First-minute spread is quote-weighted; tick counts are quote updates, not traded volume. CPI and real earnings were simultaneous. Other coincident announcements not comprehensively inventoried.",
            "course_evidence":"research/ict_time_video/news_release_study.json",
            "course_evidence_sha256":digest(ROOT/"research/ict_time_video/news_release_study.json")}, charts


def write_chart(path, report, charts):
    rows = []
    for r in report["records"]:
        key = r["scheduled_ny"][:10]
        first = r["quotes"]["events"]
        crossings = " → ".join(e["clock"]+" "+e["label"][-2:] for e in first if "越过" in e["label"])
        rows.append(f'<tr><td>{key}</td><td><a href="{r["official_schedule"]}">{escape(r["name"])}</a></td>'
                    f'<td>{escape(crossings or "未越界")}</td><td>{escape(r["day_label"])}</td>'
                    f'<td><button class="open-replay" data-open-replay="{key}">K线回放</button></td></tr>')
    chart = (ROOT/"scripts/profile_day_replay.html").read_text(encoding="utf-8").replace(
        "__DAY_REPLAY_DATA__",json.dumps(charts,ensure_ascii=False,separators=(",",":")).replace("<","\\u003c"))
    path.write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                    '<title>黄金非农与 CPI 回放</title><style>body{font:16px/1.6 system-ui;max-width:1100px;margin:3vw auto;padding:1em;color:#18323a}'
                    'table{border-collapse:collapse}th,td{padding:.6em;text-align:left;border-bottom:1px solid #ccd5d6}a{color:#165a68}</style>'
                    '<h1>黄金非农与 CPI 回放</h1><p>2025 年 1–2 月 · HistData XAUUSD · 纽约时间。上下沿取公布前 30 分钟的最高和最低中间价。'
                    '在回放的经济日历中选取公布时刻，可逐根查看报价越界和概况候选。</p>'
                    '<table><thead><tr><th>日期</th><th>08:30 公布</th><th>逐笔首次越界顺序</th><th>收盘日概况</th><th>图表</th></tr></thead><tbody>'
                    +''.join(rows)+'</tbody></table>'+chart+'</html>',encoding="utf-8")


if __name__=="__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("directory",type=Path)
    parser.add_argument("out",type=Path)
    parser.add_argument("chart",type=Path)
    args=parser.parse_args()
    report,charts=run(args.directory)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    write_chart(args.chart,report,charts)
