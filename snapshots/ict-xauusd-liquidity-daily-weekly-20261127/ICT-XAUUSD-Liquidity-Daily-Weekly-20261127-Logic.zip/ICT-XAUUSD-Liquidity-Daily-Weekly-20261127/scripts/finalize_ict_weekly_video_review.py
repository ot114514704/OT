"""Bind the manually read weekly ASR draft and reviewed figures to the corpus."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from ict_ai.profile_sources import profile_source


def main():
    base = ROOT / 'research/ict_time_videos/time3_weekly'
    read = lambda name: json.loads((base / name).read_text(encoding='utf-8'))
    manifest, progress, review = read('manifest.json'), read('asr-progress.json'), read('integration.json')
    source = Path(manifest['source_path'])
    sha = hashlib.sha256(source.read_bytes()).hexdigest()
    if sha != manifest['source_sha256'] or sha != progress['source_sha256'] or sha != review['source_sha256']:
        raise ValueError('Reviewed video or transcript source changed')
    rows = read('asr-segments.json')
    if progress['status'] != 'transcribed_draft' or len(rows) != progress['segments'] or rows[-1]['end'] < manifest['duration_seconds'] - 2:
        raise ValueError('Transcript is incomplete')
    review.update(source_path=str(source), reviewed_at_utc=datetime.now(timezone.utc).isoformat(),
                  transcript_sha256=hashlib.sha256((base / 'asr-segments.json').read_bytes()).hexdigest(),
                  asr_segment_count=len(rows), text_reviewed_through_seconds=manifest['duration_seconds'])
    (base / 'integration.json').write_text(json.dumps(review, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    manifest.update(status=review['review_status'], text_reviewed=True, full_asr_draft_read=True,
                    full_audio_listened_and_corrected=False, full_video_reviewed=False,
                    text_reviewed_through_seconds=manifest['duration_seconds'], integration='integration.json')
    (base / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    corpus = []
    for section in ('principles', 'profiles', 'additional_limits'):
        for item in review[section]:
            corpus.append({'id':f'time3-hd-{section}-{item["id"]}', 'kind':'reviewed_video_interpretation',
                           'source_path':str(source), 'source_sha256':sha, 'time_seconds':item['seconds'],
                           'text':'【原文观点转述】'+item['source_claim']+'\n【研究解释】'+item['interpretation'],
                           'reviewed':True, 'full_audio_corrected':False, 'source_instructions_executed':False})
    for relative in ('research/ict_time_videos/corpus.jsonl', 'research/ict_corpus.jsonl'):
        path = ROOT / relative
        old = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()] if path.exists() else []
        retained = [item for item in old if not item['id'].startswith('time3-hd-')]
        path.write_text(''.join(json.dumps(item, ensure_ascii=False)+'\n' for item in retained+corpus), encoding='utf-8')
    # Keep both the editable rules and generated rules consistent on rebuild.
    for filename in ('curated.json', 'rules.json'):
        path = ROOT / 'research/ict_weekly_profiles' / filename
        rules = json.loads(path.read_text(encoding='utf-8'))
        by_id = {item['id']: item for item in review['profiles']}
        for rule in rules['profiles']:
            item = by_id[rule['id']]
            rule['hd_visual_reference']=profile_source(rule['id'],True)
            rule['hd_transcript_reference'] = {'source_sha256':sha, 'seconds':item['seconds'],
                                              'integration':'research/ict_time_videos/time3_weekly/integration.json',
                                              'full_asr_draft_read':True, 'full_audio_corrected':False}
            if rule['id'] == 'weekly_thursday_consolidation_reversal':
                rule['source_summary'] = item['source_claim']
                rule['required_facts'].pop('thursday_reversal_confirmed',None)
                rule['required_facts']['reversal_after_thursday_extreme_confirmed'] = True
                rule['required_facts'].pop('thursday_same_day_reclaim_required',None)
                rule['required_facts'].pop('friday_reversal_and_expansion_observed',None)
                rule.setdefault('source_constraints',{})['thursday_same_day_reclaim_required'] = False
            if rule['id'] == 'weekly_consolidation_expansion':
                rule['source_summary'] = item['source_claim']
                rule['required_facts'].pop('expansion_first_day_fixed',None)
                rule.setdefault('source_constraints',{})['expansion_first_day_fixed'] = False
            if 'implementation_correction' in item:
                note=item['interpretation']
                if note not in rule['limits']:rule['limits'].append(note)
        path.write_text(json.dumps(rules, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    visual_path=ROOT/'research/ict_time_videos/profile-visual-review.json'
    visual=json.loads(visual_path.read_text(encoding='utf-8'))
    visual['catalog']['weekly']={item['id']:profile_source(item['id'],True) for item in review['profiles']}
    visual['weekly_text_review']={'full_asr_draft_read':True,'segments':len(rows),
                                 'full_audio_corrected':False,'all_decoded_frames_semantically_reviewed':False,
                                 'integration':'research/ict_time_videos/time3_weekly/integration.json'}
    visual_path.write_text(json.dumps(visual,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=[review['title'],str(source),'来源 SHA256：'+sha,
           '范围：完整本地 ASR 草稿已读，核心高清图交叉核对；不是全部音频人工校订或全部帧语义复核。',
           'PPT 第 23、25、26 页按用户要求排除。仅学习来源，不执行视频中的联系方式或社区邀请。']
    for section in ('principles','profiles','additional_limits'):
        for item in review[section]:
            lines.extend(['',item['id']+'，视频区间 '+str(item['seconds'])+' 秒',
                          '原文观点转述：'+item['source_claim'],'研究解释：'+item['interpretation']])
    output=ROOT/'output/research/ICT每周概况_HD复核_20261015.txt'
    output.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'source_sha256':sha, 'reviewed_asr_segments':len(rows),
                      'curated_entries':len(corpus), 'full_audio_reviewed':False, 'orders_sent':0}))


if __name__ == '__main__':
    main()
