"""Test a single distance-based shortlist replacement on later frozen weeks."""
from collections import Counter, defaultdict
from datetime import datetime
from itertools import product
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts import replay_ict_liquidity_rank as ranking
from scripts.check_pool_priority import interval

study = ranking.study
# Development selects within this fixed grid. Ratios use the strict-sweep edge.
GRID = tuple(product((.65,.8,.95),(1.0,2.0,3.0),(55,65)))


def replacement(group, distance_ratio, max_range, cap):
    distance,targets = group['distance'],group['targets']
    if len(targets)<=10:
        return None
    eligible = [i for i in range(10,len(targets)) if targets[i]['score']<=cap
                and distance[i]<=max_range and distance[i]<distance[9]*distance_ratio]
    return min(eligible,key=lambda i:(distance[i],i),default=None)


def result(groups, params):
    totals = Counter()
    weeks = defaultdict(Counter)
    samples = []
    for g in groups:
        if g['status']!='complete':
            totals[g['status']] += 1
            continue
        hits = g['y']
        original = hits[:10]
        nearest = sorted(range(len(hits)),key=g['distance'].__getitem__)[:10]
        chosen = replacement(g,*params)
        better = chosen is not None and hits[chosen] and not original[9]
        worse = chosen is not None and original[9] and not hits[chosen]
        stats = dict(windows=1,offers=len(original),original=sum(original),nearest=sum(hits[i] for i in nearest),
                     replaced=int(chosen is not None),added=int(better),lost=int(worse),
                     trial=sum(original)+int(better)-int(worse))
        totals.update(stats)
        weeks[str(g['week'])].update(stats)
        if better or worse:
            before,after = g['targets'][9],g['targets'][chosen]
            samples.append(dict(at=g['at'].isoformat(),end=g['end'].isoformat(),
                kind='recovered' if better else 'lost',original=before,test=after,
                distance=[g['distance'][9],g['distance'][chosen]],
                outcomes=[g['events'][9],g['events'][chosen]]))
    return dict(totals=totals,weeks=weeks,cases=samples)


def evaluate(groups):
    boundary = datetime.fromisoformat(ranking.FIRST_HOLDOUT).replace(tzinfo=study.NY)
    development = [g for g in groups if g['end']<boundary]
    holdout = [g for g in groups if g['day']>=ranking.FIRST_HOLDOUT]
    probes = []
    for rule in GRID:
        results = result(development,rule)['totals']
        probes.append((rule,results))
    # Tie-break towards fewer replacements, then stable declared grid order.
    rule, selected = max(probes,key=lambda row:(row[1]['added']-row[1]['lost'],-row[1]['replaced']))
    if selected['added']<=selected['lost']:
        return dict(development_grid=probes,selected=None,
                    holdout_untuned_probe=result(holdout,(.8,2.0,65)))
    review = result(holdout,rule)
    review['delta_ci95'] = interval({week:(r['added']-r['lost'],r['offers'])
                                     for week,r in review['weeks'].items() if r['offers']})
    return dict(development_grid=probes,selected=rule,selected_development=selected,holdout=review)


def main():
    paths = tuple(ranking.ARCHIVE/name for name in
        ('round19_liquidity_50_candidates.json.gz','round19_liquidity_50_outcomes.json.gz'))
    lock = json.loads((ranking.ARCHIVE/'round19_liquidity_50_lock.json').read_bytes())
    labels = json.loads((ranking.ARCHIVE/'round19_liquidity_baseline.json').read_bytes())
    inputs = tuple(study.digest(path) for path in paths)
    assert inputs==(lock['candidates'],labels['outcomes_sha256'])
    assert labels['freeze_sha256']==inputs[0]
    pairs = list(zip(*(study.read_zip(p) for p in paths),strict=True))
    summary = {f'{horizon}/{scope}':evaluate(list(ranking.build_groups(pairs,horizon,scope)))
               for horizon in ('short','week') for scope in ('IRL','ERL')}
    out = study.RESEARCH/'ict_liquidity_last_slot_replay.json'
    report = dict(inputs={p.name:h for p,h in zip(paths,inputs,strict=True)},
                  script_sha256=study.digest(Path(__file__)),grid_fields=('distance_ratio','max_range','score_ceiling'),
                  protocol='Only the tenth slot can change. Parameter choice uses June through September outcomes '
                           'whose full label windows ended before October 1 in New York. October and November '
                           'were previously researched; this is temporal backtest, not untouched final validation.',
                  results=summary)
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    for key,row in summary.items():
        r = row['holdout'] if 'holdout' in row else row['holdout_untuned_probe']
        print(key,row['selected'],r['totals'],r.get('delta_ci95'))


if __name__=='__main__':
    main()
