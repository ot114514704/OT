"""Compare clock mappings using archived ticks, candles and published trading hours."""
import argparse
from collections import Counter
import csv
from datetime import date, datetime, time, timedelta, timezone
from hashlib import sha256
import json
from pathlib import Path
from zoneinfo import ZoneInfo

from brooks_ai.types import utc_time
from ict_ai.timebase import NY


ROOT = Path(__file__).resolve().parents[1]
UTC = timezone.utc
M5 = timedelta(minutes=5)
SOURCES = {
    "ny_dst": "https://www.nist.gov/pml/time-and-frequency-division/popular-links/daylight-saving-time-dst",
    "uk_dst": "https://www.gov.uk/when-do-the-clocks-change",
    "tmgm": "https://www.tmgm.com/eng/trading/trading-hours",
    "tmgm_ny_gold_hours": "https://www.tmgm.com/en-in/academy/trading-academy/gold-trading-hours",
    "cme_gold_hours": "https://www.cmegroup.com/markets/metals/precious/gold.timeAndSales.html",
    "us_federal_holidays": "https://www.opm.gov/policy-data-oversight/pay-leave/federal-holidays/",
    "api_clock": "https://www.mql5.com/en/docs/python_metatrader5/mt5copyratesfrom_py",
}


def raw_snapshot(manifest):
    meta = json.loads(manifest.read_bytes())
    if (meta["status"] != "collected" or meta["symbol"] != "XAUUSD" or
            meta["synthetic"] is not False or meta["volatile_live_snapshot"] is not False):
        raise ValueError("Require an immutable real XAUUSD snapshot")
    reference = next(row for row in meta["datasets"] if row["timeframe"] == "M5")
    path = Path(reference["data_path"])
    if not path.is_file():
        path = manifest.parent / path.name
    raw = path.read_bytes()
    content_hash = sha256(raw).hexdigest()
    if content_hash != reference["data_sha256"]:
        raise ValueError(f"Snapshot hash mismatch: {path}")
    stamps = [utc_time(row["time"]) for row in csv.DictReader(raw.decode("utf-8-sig").splitlines())]
    if not stamps or any(a >= b for a, b in zip(stamps, stamps[1:])):
        raise ValueError("Raw bar clocks must be sorted and unique")
    return stamps, {"manifest": str(manifest), "raw_sha256": content_hash,
                    "bar_count": len(stamps), "observation_finished_at_utc": meta["finished_at_utc"]}


def tick_evidence(paths):
    evidence = []
    for path in paths:
        raw = path.read_bytes()
        digest = sha256(raw).hexdigest()
        for line_number, line in enumerate(raw.decode("utf-8-sig").splitlines(), 1):
            row = json.loads(line)
            if row["symbol"] != "XAUUSD":
                continue
            observed = row["observation"]
            if observed["status"] != "stable_current_observation":
                continue
            samples = observed["sample_window"]
            ticks = [datetime.fromtimestamp(row["raw_epoch_seconds"], UTC) for row in samples]
            host = [utc_time(row["host_utc"]) for row in samples]
            monotonic = [row["monotonic_seconds"] for row in samples]
            if (len(ticks) < 3 or any(a >= b for a, b in zip(ticks, ticks[1:])) or
                    any(a >= b for a, b in zip(monotonic, monotonic[1:])) or
                    monotonic[-1] - monotonic[0] < 4):
                continue
            if any(abs((host[i] - host[i-1]).total_seconds() - (monotonic[i] - monotonic[i-1])) > 1
                   for i in range(1, len(host))):
                continue
            evidence.append((path, digest, line_number, ticks, host, observed["observed_offset_hours"]))
    if not evidence:
        raise ValueError("No advancing tick observations found")
    return evidence


def to_utc(raw, switch, summer, winter):
    return raw - timedelta(hours=summer if switch is None or raw < switch else winter)


def examine_policy(policy, raw_gaps, archived_ticks):
    switch, summer, winter = policy
    outcomes = []
    for path, digest, line, ticks, host, measured in archived_ticks:
        ages = [(seen - to_utc(tick, switch, summer, winter)).total_seconds() for tick, seen in zip(ticks, host)]
        outcomes.append({
            "file": str(path), "sha256": digest, "line": line,
            "observed_at_utc": host[-1].isoformat(), "raw_tick": ticks[-1].isoformat(),
            "measured_offset_hours": measured, "age_seconds": [round(age, 3) for age in ages],
            "consistent": all(-2 <= age <= 5 for age in ages),
        })
    boundaries = []
    for last, first in raw_gaps:
        before = to_utc(last, switch, summer, winter).astimezone(NY)
        after = to_utc(first, switch, summer, winter).astimezone(NY)
        weekend = first - last >= timedelta(hours=40)
        if weekend:
            expected = before.weekday() == 4 and after.weekday() == 6 and (
                before.time(), after.time()) == (time(16, 50), time(18))
        else:
            expected = before.weekday() in range(4) and before.date() == after.date() and (
                before.time(), after.time()) == (time(16, 55), time(18))
        boundaries.append({"raw_last_m5_open": last.isoformat(), "raw_next_m5_open": first.isoformat(),
                           "ny_last_m5_open": before.isoformat(), "ny_next_m5_open": after.isoformat(),
                           "weekend": weekend, "matches_regular_reference": expected})
    return {
        "archived_tick_checks": outcomes,
        "matching_tick_checks": sum(row["consistent"] for row in outcomes),
        "boundary_checks": boundaries,
        "matching_boundaries_by_type": dict(Counter("weekend" if row["weekend"] else "daily"
                                                    for row in boundaries if row["matches_regular_reference"])),
        "raw_switch_assumption": switch.isoformat() if switch else None,
        "offset_hours": [summer, winter],
    }


def regional_examples():
    london = ZoneInfo("Europe/London")
    result = {}
    for day in (date(2026, 10, 23), date(2026, 10, 26), date(2026, 11, 2)):
        result[day.isoformat()] = {
            "london_08_local_in_ny": datetime.combine(day, time(8), london).astimezone(NY).isoformat(),
            "silver_bullet_03_ny_in_london": datetime.combine(day, time(3), NY).astimezone(london).isoformat(),
            "ny_midnight_utc": datetime.combine(day, time(0), NY).astimezone(UTC).isoformat(),
        }
    return result


def run(manifests, journals):
    policies = {
        "nov_1_weekend": (datetime(2026, 11, 1, tzinfo=UTC), 3, 2),
        "oct_25_weekend": (datetime(2026, 10, 25, tzinfo=UTC), 3, 2),
        "nov_8_weekend": (datetime(2026, 11, 8, tzinfo=UTC), 3, 2),
        "fixed_utc_plus_3": (None, 3, 3),
        "fixed_utc_plus_2": (None, 2, 2),
        "documented_api_utc": (None, 0, 0),
    }
    sources, raw_gaps, stamps = [], set(), set()
    for manifest in manifests:
        times, source = raw_snapshot(manifest)
        sources.append(source)
        stamps.update(times)
        raw_gaps.update((a, b) for a, b in zip(times, times[1:])
                        if timedelta(hours=1) <= b - a <= timedelta(hours=80))
    # Cross-check overlapping snapshots so a missing-data hole in one file
    # cannot become a trading-hours boundary when the other file has quotes.
    ordered = sorted(stamps)
    union = set(zip(ordered, ordered[1:]))
    raw_gaps = sorted(raw_gaps & union)
    ticks = tick_evidence(journals)
    audits = {name: examine_policy(policy, raw_gaps, ticks) for name, policy in policies.items()}
    cutover = policies["nov_1_weekend"][0]
    if not ordered[0] < cutover <= ordered[-1]:
        raise ValueError("Snapshots must bracket the November 2026 weekend")
    last = max(stamp for stamp in stamps if stamp < cutover)
    first = min(stamp for stamp in stamps if stamp >= cutover)
    return {
        "sources": SOURCES, "snapshots": sources, "tick_window_count": len(ticks),
        "policy_comparison": audits, "regional_examples": regional_examples(),
        "switch_weekend_quote_bracket": {"last_raw_bar_open": last.isoformat(),
                                         "first_raw_bar_open": first.isoformat()},
        "regular_boundary_reference": "NY Mon–Thu 16:55 last M5 open to 18:00; Fri 16:50 to Sun 18:00",
        "calendar_note": "2026-09-07 was U.S. Labor Day. Its earlier quote break remains an exception to the regular-hours comparison; exact historical TMGM holiday hours have not been confirmed.",
        "historical_alignment_verified": False, "policy_changed": False, "orders_sent": 0,
        "limits": [
            "Tick ages are relative to the historical host clock. They are not an independent external quote feed.",
            "Archived ticks validate only the recorded times. The price-data boundary comparison uses public regular hours, not a historical TMGM holiday ledger.",
            "An unquoted interval cannot locate the exact broker clock switch instant.",
            "CME is a separate venue and supplies a corroborating market-hours reference, not equivalent XAUUSD quotes.",
        ],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, action="append", required=True)
    parser.add_argument("--journal", type=Path, action="append", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    report = run(args.manifest, args.journal)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    for name, row in report["policy_comparison"].items():
        print(name, row["matching_tick_checks"], row["matching_boundaries_by_type"])
