"""Measure how much of the early-board gain survives realistic receipt delays."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import json
from pathlib import Path

from ict_ai.dol_tick_evidence import utc_ms
from scripts import audit_ict_micro_liquidity_board as board
from scripts import watch_ict_micro_liquidity_forward as shadow
from scripts.serve_ict_live import atomic_json


OUT = board.joint.RESEARCH / 'ict_micro_liquidity_latency_20261125.json'
TICKS = OUT.with_suffix('.json.gz')
DELAYS = (0, 15, 30, 60, 90, 120, 180, 240, 300)
ONE = timedelta(minutes=1)


def affected_starts(historical):
    starts = set()
    for row in historical['changed_outcomes']:
        at = datetime.fromisoformat(row['at'])
        for field in ('gained', 'lost'):
            for hit in row[field]:
                opened = datetime.fromisoformat(hit['swept']) - shadow.M5
                if at <= opened <= at + shadow.M5:
                    starts.add(opened)
    return sorted(starts)


def capture(historical, pid):
    source = shadow.frozen_feed()
    api = shadow.forward.feed.mt5
    observed = shadow.forward.now()
    starts = affected_starts(historical)
    with shadow.open_terminal(pid) as alive:
        result = dict((at.isoformat(), bucket) for at, bucket in shadow.capture_buckets(api, alive, source, starts, observed))
    board.joint.write_zip(TICKS, dict(archive_sha256=board.joint.digest(board.OUT), collected_at=observed.isoformat(),
                                     slots=result, orders_sent=0))


def ohlc(bar):
    return [bar.open, bar.high, bar.low, bar.close]


def crossing_window(at, side, edge, five, minutes, tick_bucket):
    reference = five[at]
    if tick_bucket and tick_bucket['ohlc'] == ohlc(reference):
        checked = shadow.reconcile([tick_bucket])
        if checked:
            first = next((stamp for stamp, bid in checked[0][1] if side * (bid - edge) > 0), None)
            if first is None:
                raise ValueError('Earlier frozen M5 shows a crossing absent from reconciled Bid ticks')
            return dict(resolution='tick', earliest_ms=first, latest_exclusive_ms=first + 1)
    part = [minutes.get(at + i * ONE) for i in range(5)]
    if all(part):
        rebuilt = [part[0].open, max(bar.high for bar in part), min(bar.low for bar in part), part[-1].close]
        if rebuilt == ohlc(reference):
            for bar in part:
                if side * ((bar.high if side == 1 else bar.low) - edge) > 0:
                    start = utc_ms(bar.time)
                    return dict(resolution='m1', earliest_ms=start, latest_exclusive_ms=start + 60_000)
            raise ValueError('M1 prices do not match a verified M5 crossing')
    return dict(resolution='m5', earliest_ms=utc_ms(at), latest_exclusive_ms=utc_ms(at + shadow.M5))


def eligible(bounds, published_ms, delay):
    if delay == 0 or bounds['earliest_ms'] > published_ms:
        return 'eligible'
    if bounds['latest_exclusive_ms'] <= published_ms + 1:
        return 'too_early'
    return 'ambiguous'


def evaluate(historical):
    lock = json.loads(board.LOCK.read_bytes())
    paths = (board.original.MINUTES, board.original.priority.ARCH/'XAUUSDM5.npz')
    for path in paths:
        key = path.relative_to(board.joint.ROOT).as_posix()
        if board.joint.digest(path) != lock['sources'][key]:
            raise ValueError(f'Archived quote source changed: {path.name}')
    board.original.initialize()
    five = {bar.time: bar for bar in board.original.bars}
    m1 = {bar.time: bar for bar in board.original.minutes}
    if len(m1) != len(board.original.minutes):
        raise ValueError('Minute quote times are not unique')
    archive = board.joint.read_zip(TICKS)
    if archive['archive_sha256'] != board.joint.digest(board.OUT):
        raise ValueError('Bid capture and archived ranking comparison differ')
    ticks = archive['slots']
    results, evidence = defaultdict(Counter), {}
    for outcome in historical['changed_outcomes']:
        at = datetime.fromisoformat(outcome['at'])
        for direction in ('gained', 'lost'):
            for hit in outcome[direction]:
                side, low, high = hit['band']
                edge = high if side == 1 else low
                opened = datetime.fromisoformat(hit['swept']) - shadow.M5
                if opened < at:
                    raise ValueError('Frozen comparison outcome preceded the board')
                if opened <= at + shadow.M5:
                    key = (outcome['at'], opened.isoformat(), side, edge)
                    if key not in evidence:
                        evidence[key] = crossing_window(opened, side, edge, five, m1, ticks.get(opened.isoformat()))
                    bounds = evidence[key]
                else:
                    bounds = dict(earliest_ms=utc_ms(opened), latest_exclusive_ms=utc_ms(opened + shadow.M5))
                for delay in DELAYS:
                    published = utc_ms(at) + delay * 1000
                    label = eligible(bounds, published, delay)
                    results[f'{outcome["horizon"]}/{outcome["scope"]}/{delay}'][f'{direction}_{label}'] += 1
    summary = {}
    for key in historical['results']:
        for delay in DELAYS:
            stats = results[f'{key}/{delay}']
            low = stats['gained_eligible'] - stats['lost_eligible'] - stats['lost_ambiguous']
            high = stats['gained_eligible'] + stats['gained_ambiguous'] - stats['lost_eligible']
            summary[f'{key}/{delay}'] = dict(stats, net_advantage_lower=low, net_advantage_upper=high)
    for name, stats in historical['results'].items():
        if summary[f'{name}/0']['net_advantage_lower'] != stats['after_hits'] - stats['before_hits']:
            raise ValueError(f'Zero-delay accounting changed the historical result: {name}')
    packed = [dict(at=at, crossing_bar=opened, side=side, edge=edge, **bounds)
              for (at, opened, side, edge), bounds in sorted(evidence.items())]
    report = dict(scope='Latency sensitivity on only the changed hit sets from complete frozen IRL/ERL boards',
                  timing='Zero is the ideal original test. Positive offsets require crossing after assumed availability. '
                         'Where exact Bid is unavailable, use a verified M1 envelope and show a range for ambiguous hits.',
                  assumptions='Both boards use the same counterfactual timestamp and remain frozen. '
                              'Events in the next two M5 bars are time checked. This is a hit-count difference.',
                  delays_seconds=DELAYS, tick_m5_buckets=len(ticks), resolution_counts=Counter(row['resolution'] for row in packed),
                  results=summary, delay_boundary_crosses=packed, inputs={p.name:board.joint.digest(p) for p in (
                      board.OUT, TICKS, *paths, Path(__file__))},
                  retrospective_only=True, orders_sent=0)
    atomic_json(OUT, report)
    print(json.dumps(dict(resolutions=report['resolution_counts'], quarter={delay:summary[f'quarter/IRL/{delay}']
                     for delay in DELAYS}), ensure_ascii=False))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture-terminal-pid', type=int)
    args = parser.parse_args()
    historical = json.loads(board.OUT.read_bytes())
    if args.capture_terminal_pid is not None:
        capture(historical, args.capture_terminal_pid)
    evaluate(historical)
