"""Reconcile archived IPDA quote gaps against read-only TMGM Bid and Ask ticks."""
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.audit_ipda_early_close import ARCHIVE, M5, M15, RESEARCH
from scripts.export_mt5_native import native_time
from scripts.replay_pool_and_dol import QUOTES, digest, read_zip, write_zip


EARLY = RESEARCH / 'ict_ipda_early_close_audit.json'
PRICES = ARCHIVE / 'round17_half_year_prices.json.gz'
TERMINAL = Path('C:/Program Files/MetaTrader 5/terminal64.exe')
SYMBOL = 'XAUUSD'


def raw_epoch(stamp, clock):
    native = native_time(stamp.isoformat(), clock)
    return int(datetime.strptime(native, '%Y.%m.%d %H:%M:%S').replace(tzinfo=timezone.utc).timestamp())


def epoch_ny(stamp_ms, raw_anchor, ny_anchor):
    return (ny_anchor + timedelta(milliseconds=stamp_ms-raw_anchor*1000)).isoformat(timespec='milliseconds')


def capture(api, start, end):
    raw = api.copy_ticks_range(SYMBOL, datetime.fromtimestamp(start, timezone.utc),
                               datetime.fromtimestamp(end, timezone.utc), api.COPY_TICKS_INFO)
    if raw is None:
        raise RuntimeError(f'Tick request failed: {api.last_error()}')
    rows = [[int(q['time_msc']), float(q['bid']), float(q['ask'])] for q in raw
            if start*1000 <= int(q['time_msc']) < end*1000 and q['bid'] > 0 and q['ask'] > 0]
    if any(a[0] > b[0] for a, b in zip(rows, rows[1:])):
        raise ValueError('Non-monotone TMGM tick sequence')
    return rows


def verify_bar(rows, opened, reference):
    bids = [bid for stamp, bid, _ in rows if opened*1000 <= stamp < (opened+300)*1000]
    built = [bids[0], max(bids), min(bids), bids[-1]] if bids else None
    match = None if built is None or reference is None else all(
        abs(a-b) < 1e-8 for a, b in zip(built, reference, strict=True))
    return dict(tick_count=len(bids), bid_ohlc=built, archived_ohlc=reference, match=match)


def inspect_case(api, case, clock, m5):
    close = datetime.fromisoformat(case['last_m5_close'])
    reopen = datetime.fromisoformat(case['next_m5_open'])
    start, end = raw_epoch(close, clock), raw_epoch(reopen, clock)
    # Request separate bookends so partial archives or one failed query do not
    # turn into false evidence that no ticks were published in the gap.
    last = capture(api, start-600, start)
    gap = capture(api, start, end)
    first = capture(api, end, end+1200)
    before = verify_bar(last, start-300, m5.get(start-300))
    after = [verify_bar(first, end+300*k, m5.get(end+300*k)) for k in range(4)]
    verified = before['match'] is True and all(x['match'] is True for x in after[:3])
    return dict(date=case['date_ny'], scheduled_missing_close=case['first_unavailable_slot_known_no_earlier_than'],
                last_bar=before, reopening_bars=after, gap_quote_count=len(gap),
                quote_gap_supported=verified and not gap,
                last_quote=epoch_ny(last[-1][0], start, close) if last else None,
                first_quote=epoch_ny(first[0][0], end, reopen) if first else None,
                first_full_m15_close=(reopen+M15).isoformat() if all(x['match'] is True for x in after[:3]) else None,
                expected_gap_minutes=(end-start)//60,
                raw_ticks=dict(before=last, between=gap, after=first))


def main():
    import MetaTrader5 as mt5

    early = json.loads(EARLY.read_bytes())
    if digest(PRICES) != early['inputs'][PRICES.name]:
        raise ValueError('Price archive differs from the audited input')
    m5 = {row[0]: row[1:] for row in read_zip(PRICES)['bars']['M5']}
    quote_source = read_zip(QUOTES)
    if not mt5.initialize(str(TERMINAL), timeout=10000):
        raise RuntimeError(f'MT5 unavailable: {mt5.last_error()}')
    try:
        terminal, account = mt5.terminal_info(), mt5.account_info()
        if not terminal or not terminal.connected or not account or account.server != quote_source['server']:
            raise RuntimeError('Live terminal does not match the TMGM archive')
        identity = account.login, account.server
        cases = [inspect_case(mt5, c, quote_source['clock'], m5) for c in early['cases']]
        terminal, account = mt5.terminal_info(), mt5.account_info()
        if not terminal or not terminal.connected or not account or (account.login, account.server) != identity:
            raise RuntimeError('MT5 connection or account changed while reading ticks')
    finally:
        mt5.shutdown()
    provenance = {p.name: digest(p) for p in (EARLY, PRICES, QUOTES, Path(__file__))}
    raw_path = RESEARCH / 'ict_ipda_early_close_ticks.json.gz'
    write_zip(raw_path, dict(inputs=provenance, symbol=SYMBOL, server=quote_source['server'],
                             quote_kind='COPY_TICKS_INFO, positive Bid and Ask',
                             quotes={c['date']: c.pop('raw_ticks') for c in cases}))
    report = dict(inputs=provenance, tick_sha256=digest(raw_path), cases=cases,
                  scope='Successful history queries only. Quote absence is corroborated by matching M5 OHLC '
                        'on both sides. This does not establish a published broker schedule or service delivery times.')
    (RESEARCH/'ict_ipda_early_close_tick_audit.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    for case in cases:
        print(case['date'], 'supported' if case['quote_gap_supported'] else 'unverified',
              case['last_quote'], case['first_quote'], case['first_full_m15_close'])


if __name__ == '__main__':
    main()
