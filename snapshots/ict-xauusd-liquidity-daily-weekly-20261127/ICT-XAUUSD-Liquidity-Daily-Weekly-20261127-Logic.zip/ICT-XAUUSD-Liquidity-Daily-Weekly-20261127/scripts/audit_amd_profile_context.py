"""Test frozen day/week context against later AMD development on archived XAUUSD."""
import argparse
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
import gzip
import hashlib
from html import escape
import json
from pathlib import Path
from random import Random
from statistics import median
from zipfile import ZipFile, ZIP_DEFLATED

from brooks_ai.types import Bar, utc_time
from ict_ai.amd import amd_events, confirmed_pivots
from ict_ai.timebase import NY
from scripts.audit_profile_one_daily_context import load_tmgm
from scripts.prepare_ict_week import aggregate_bars
from scripts.review_amd_profile_atlas import chart, snapshot
from scripts.replay_ict_news import ROOT, STEP

CAPTURE = ROOT/'output/research/dol_expansion_20261122'
OUT = ROOT/'output/research/amd_profile_context_20261122'
ATLAS = ROOT/'output/visualizations/amd-profile-atlas/batch-02'
PHASES = ('回放开发段','后段检验','近期检验')


def archived_feed():
    import numpy as np

    name = 'XAUUSDM5.npz'
    file = CAPTURE/name
    expected = json.loads((CAPTURE/'manifest.json').read_bytes())[name]
    if hashlib.sha256(file.read_bytes()).hexdigest() != expected:
        raise ValueError('Changed M5 capture')
    with np.load(file,allow_pickle=False) as capture:
        records = capture['rates']
    history = []
    for row in records:
        # Use the broker clock calibrated in the capture, NY wall time plus 7 hours.
        raw = datetime.fromtimestamp(int(row['time']),timezone.utc)
        ny = (raw-timedelta(hours=7)).replace(tzinfo=NY)
        history.append(Bar(ny.astimezone(timezone.utc), *(float(row[k]) for k in ('open','high','low','close')),0))
    if any(a.time>=b.time for a,b in zip(history,history[1:])):
        raise ValueError('Nonchronological capture')
    recent, provenance = load_tmgm()
    return history,recent,dict(m5_sha256=expected,recent=provenance)


def later_path(quotes, at, price, side, distance, hours):
    """Inspect contiguous M5 bars up to the horizon. Record unresolved order explicitly."""
    favorable, adverse = price+side*distance, price-side*distance
    for n in range(hours*12):
        stamp = at+n*STEP
        b = quotes.get(stamp)
        if b is None or stamp.astimezone(NY).hour>=17 or stamp.astimezone(NY).date()!=at.astimezone(NY).date():
            return 'coverage_stop'
        max_favor, max_adverse = (b.high,b.low) if side==1 else (b.low,b.high)
        win = side*(max_favor-favorable)>=0
        loss = side*(adverse-max_adverse)>=0
        if win and loss:
            return 'same_bar'
        if win:
            return 'favorable'
        if loss:
            return 'adverse'
    return 'neither'


def family(shape):
    if shape in ('overlapping','contracting'):
        return '矩形' if shape=='overlapping' else None
    if 'triangle' in shape:
        return '三角'
    if 'channel' in shape:
        return '通道'
    return None


def first_opposite_run(m5quotes, bars, times, j, a, m, side, period):
    """Hold A and M fixed and score the first two opposite closes before any reset."""
    at = utc_time(m['available_at'])
    first = bisect_left(times,at)
    start = bisect_left(times,utc_time(a['start']))
    threshold = max(.01,median(abs(b.close-b.open) for b in bars[start:j]))
    lo,hi = a['range_low'],a['range_high']
    protected = m['lower'] if side>0 else m['upper']
    run = 0
    for k in range(first,min(j+24,len(bars))):
        b = bars[k]
        if times[k]!=times[k-1]+period or (b.high>hi and b.low<lo):
            break
        if (side>0 and b.low<protected) or (side<0 and b.high>protected):
            break
        outside = b.close>hi if side>0 else b.close<lo
        run = run+1 if outside else 0
        if run==2:
            body = max(side*(p.close-p.open) for p in bars[k-1:k+1])
            dt = b.time+period
            result = later_path(m5quotes,dt,b.close,side,(hi-lo)*.5,4)
            return dict(at=dt.isoformat(),displacement=body>=threshold,ratio=body/threshold,
                        outcome=result)
    return None


def replay(m5, recent):
    m5times = [b.time for b in m5]
    m5quotes = {b.time:b for b in m5}
    close = m5[-1].time+STEP
    packed = {minutes:aggregate_bars(m5,5,minutes,close) for minutes in (15,60)}
    quarters = packed[15]
    qtimes = [b.time for b in quarters]
    rows = []
    for minutes,bars in packed.items():
        period = timedelta(minutes=minutes)
        times = [b.time for b in bars]
        groups = defaultdict(list)
        events = amd_events(bars,period,close,require_displacement=True)
        for e in events:
            groups[e['id']].append(e)
        for key,group in groups.items():
            a,*other = group
            kind = family(a['shape'])
            if not kind or not other or other[0]['phase']!='M':
                continue
            m,*complete = other
            at = utc_time(m['available_at'])
            day = at.astimezone(NY).date()
            if day.weekday()>4 or day<date(2025,8,4) or (day>=date(2026,9,21))!=recent:
                continue
            cohort = PHASES[2] if recent else PHASES[0 if day<date(2026,4,1) else 1]
            offset = 8*timedelta(days=1)
            i = bisect_left(times,utc_time(a['start']))
            j = bisect_left(times,utc_time(a['available_at']))
            before = m5[bisect_left(m5times,at-offset):bisect_right(m5times,at-STEP)]
            q = quarters[bisect_left(qtimes,at-offset):bisect_right(qtimes,at-3*STEP)]
            side = 1 if m['lower']<a['range_low'] else -1
            context = snapshot(before,q,at,side)
            resolution = 'pending'
            outcomes = {}
            if complete:
                resolution = 'delivered'
                dt = utc_time(complete[0]['available_at'])
                px = bars[bisect_left(times,dt-period)].close
                width = a['range_high']-a['range_low']
                outcomes = {'primary':later_path(m5quotes,dt,px,side,width*.5,4),
                            'short':later_path(m5quotes,dt,px,side,width*.5,2),
                            'wide':later_path(m5quotes,dt,px,side,width,4)}
            else:
                # Distinguish explicit invalidation/expiry from incomplete coverage.
                first = bisect_left(times,at)
                for k in range(first,j+24):
                    if k>=len(bars) or times[k]!=times[k-1]+period:
                        break
                    b = bars[k]
                    if b.high>a['range_high'] and b.low<a['range_low']:
                        resolution = 'ambiguous_sweep'
                        break
                    if (side>0 and b.low<m['lower']) or (side<0 and b.high>m['upper']):
                        resolution = 'invalidated'
                        break
                else:
                    resolution = 'expired'
            first_run = first_opposite_run(m5quotes,bars,times,j,a,m,side,period)
            if complete and (not first_run or utc_time(first_run['at'])>utc_time(complete[0]['available_at'])):
                raise AssertionError(f'Missing first opposite run for {key}')
            if first_run and first_run['displacement'] and (
                    not complete or first_run['at']!=complete[0]['available_at']):
                raise AssertionError(f'Immediate displacement disagrees with detector for {key}')
            rows.append(dict(key=key,cohort=cohort,family=kind,minutes=minutes,day=str(day),
                             side=side,context=context,events=group,route=group[-1]['route'],
                             i=i,j=j,resolution=resolution,continuation=outcomes,first_run=first_run))
    return rows,packed


def count_rows(rows):
    result = {'m':len(rows),'stage':dict(Counter(r['resolution'] for r in rows))}
    for key in ('primary','short','wide'):
        result[key] = dict(Counter(r['continuation'][key] for r in rows if r['continuation']))
    return result


def summary(rows):
    def group(key):
        groups = defaultdict(list)
        for r in rows:
            groups[key(r)].append(r)
        return {' / '.join(str(v) for v in k):count_rows(g) for k,g in sorted(groups.items())}
    runs = defaultdict(Counter)
    for row in rows:
        if run := row['first_run']:
            strength = '达位移门槛' if run['displacement'] else '未达位移门槛'
            key = f"{row['cohort']} / {row['minutes']} / {strength}"
            runs[key][run['outcome']] += 1
    return dict(by_relation=group(lambda r:(r['cohort'],r['minutes'],r['context']['relation'])),
                by_shape=group(lambda r:(r['cohort'],r['minutes'],r['family'])),
                component=group(lambda r:(r['cohort'],r['minutes'],sign_relation(r,'daily'),
                                          sign_relation(r,'weekly'))),
                first_opposite_runs={k:dict(v) for k,v in sorted(runs.items())})


def sign_relation(row, key):
    vote = row['context'][key+'_side']
    return '待定' if vote is None else '同向' if vote==row['side'] else '逆向'


def weekly_interval(rows, outcome):
    """Resample whole NY weeks, including weeks with just one group."""
    weeks = defaultdict(lambda:[0,0,0,0])
    for r in rows:
        relation = r['context']['relation']
        if relation not in ('同向','逆向'):
            continue
        if outcome=='stage':
            resolved = r['resolution'] in ('delivered','invalidated','expired')
            hit = r['resolution']=='delivered'
        else:
            result = r['continuation'].get(outcome)
            resolved = result in ('favorable','adverse','neither')
            hit = result=='favorable'
        if resolved:
            day = date.fromisoformat(r['day'])
            week = day-timedelta(days=day.weekday())
            i = 0 if relation=='同向' else 2
            weeks[week][i] += int(hit)
            weeks[week][i+1] += 1
    totals = list(map(sum,zip(*weeks.values()))) if weeks else [0,0,0,0]
    if not totals[1] or not totals[3]:
        return dict(counts=totals,weeks=len(weeks),difference=None,interval=None)
    difference=totals[0]/totals[1]-totals[2]/totals[3]
    if min(totals[1],totals[3],len(weeks)) < 10:
        return dict(counts=totals,weeks=len(weeks),difference=difference,interval=None)
    rng = Random(45)
    samples = []
    blocks = list(weeks.values())
    for _ in range(2000):
        a,b,c,d = map(sum,zip(*rng.choices(blocks,k=len(blocks))))
        if b and d:
            samples.append(a/b-c/d)
    samples.sort()
    return dict(counts=totals,weeks=len(weeks),difference=difference,
                interval=[samples[int((len(samples)-1)*q)] for q in (.025,.975)] if samples else None)


def drawing_frame(case, bars):
    a = case['events'][0]
    i,j = case['i'],case['j']
    if case['family']=='矩形':
        t0,t1 = bars[i].time,bars[j-1].time
        lo,hi = a['range_low'],a['range_high']
        return [(t0,hi),(t1,hi),(t1,lo),(t0,lo)]
    h0,h1,l0,l1 = confirmed_pivots(bars[i:j])
    left,right = max(h0,l0),min(h1,l1)
    def interpolate(k,start,end,edge):
        p,q = (getattr(bars[i+n],edge) for n in (start,end))
        return bars[i+k].time, p+(q-p)*(k-start)/(end-start)
    return [interpolate(k,u,v,edge) for k,u,v,edge in (
        (left,h0,h1,'high'),(right,h0,h1,'high'),(right,l0,l1,'low'),(left,l0,l1,'low'))]


def export_atlas(rows, bars, output):
    output.mkdir(exist_ok=True,parents=True)
    sections = []
    manifest = []
    used = set()
    for shape, plan in [
        ('通道',[(True,'同向'),(True,'逆向'),(False,'同向')]),
        ('三角',[(True,'同向'),(True,'逆向'),(True,'待定'),(False,'同向')]),
        ('矩形',[(True,'同向'),(True,'逆向'),(True,'待定')]),
    ]:
        for delivered, relation in plan:
            pool = [r for r in rows if r['family']==shape and r['day'] not in used
                    and (r['resolution']=='delivered')==delivered]
            pool.sort(key=lambda r:(r['context']['relation']!=relation,
                                    r['resolution'] in ('pending','ambiguous_sweep'),
                                    r['cohort']==PHASES[0], r['minutes']!=60, r['day']))
            r = pool[0]
            used.add(r['day'])
            series = bars[r['cohort']==PHASES[2]][r['minutes']]
            period=timedelta(minutes=r['minutes'])
            at=utc_time(r['events'][-1]['available_at'])
            last=bisect_right([b.time for b in series],at-period)
            prefix=amd_events(series[:last],period,at,require_displacement=True)
            assert all(e in prefix for e in r['events'])
            case = dict(r,origin='按盘整规则重建',frame=drawing_frame(r,series))
            n = len(sections)+1
            name = f'{n:02d}.png'
            size = chart(case,series,output/name,n)
            sections.append(f'<a href="{name}"><img loading="lazy" src="{name}" alt="{shape} AMD {n}"></a>')
            manifest.append(dict(file=name,bars=size,**case))
    html = ('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>黄金 AMD · 矩形积累框</title><style>html{background:#10171e;color:#eef4f6;font:16px system-ui}'
            'main{max-width:1280px;margin:auto}img{display:block;width:100%;height:auto;margin:1.4em 0}</style>'
            '<main><h1>黄金 AMD · 矩形积累框</h1><p>上方看宽幅行情，下方查看红框和确认点。A 矩形上下沿标示扫荡判定价。所有时间均为纽约当地时间。</p>'
            +''.join(sections)+'</main></html>')
    (output/'index.html').write_text(html,encoding='utf8')
    (output/'replay.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,default=str),encoding='utf8')
    with ZipFile(output.with_suffix('.zip'),'w',ZIP_DEFLATED) as pack:
        for name in ['index.html','replay.json']+[m['file'] for m in manifest]:
            pack.write(output/name,name)


def report(stats):
    cells=[]
    for item in stats['comparison']:
        row=[item['cohort'],item['minutes'],item['metric']]
        a,b,c,d=item['counts']
        row.extend([f'{a}/{b}',f'{c}/{d}',item['weeks']])
        diff=item['difference']
        row.append(f'{100*diff:+.1f}' if diff is not None else '样本不足')
        ci=item['interval']
        row.append(' 至 '.join(f'{100*v:+.1f}' for v in ci) if ci else '—')
        cells.append('<tr>'+''.join(f'<td>{escape(str(v))}</td>' for v in row)+'</tr>')
    head=('区间','周期（分钟）','结果','同向','逆向','纽约周数','差值（百分点）','95%重采样区间')
    run_cells=[]
    for key,counts in stats['first_opposite_runs'].items():
        resolved=sum(counts.get(k,0) for k in ('favorable','adverse','neither'))
        row=[key,counts.get('favorable',0),resolved,sum(counts.values())-resolved]
        run_cells.append('<tr>'+''.join(f'<td>{escape(str(v))}</td>' for v in row)+'</tr>')
    html = (
        '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>黄金 AMD 与概况一验证</title><style>body{margin:2rem auto;padding:0 1rem;max-width:1040px;color:#1c2831;font:16px/1.65 system-ui}'
        'table{border-collapse:collapse;width:100%}th,td{text-align:left;padding:.5em;border-bottom:1px solid #ccc}</style>'
        '<h1>黄金 AMD 与概况一验证</h1>'
        f'<p>TMGM XAUUSD，共 {stats["sample_size"]} 个 M 样本。M 收盘时冻结当日概况与周背景，两者的可用方向全部支持预期派发时记为同向，全部反对时记为逆向。'
        '候选方向冲突记为分歧，暂无方向记为待定。两根收于对侧边界之外且顺向实体至少达到 A 段实体中位数时确认 D。</p>'
        '<p>开发段为 2025-08-04 至 2026-03-31，后段检验为 2026-04-01 至 2026-09-20，近期检验为 2026-09-21 至 2026-11-20。'
        '前两段使用同一存档，近期使用另一份 TMGM 行情存档的后续日期。样本集中在矩形。'
        'A 的几何和扫荡边界由离线识别器重建。</p>'
        '<p>“完成派发”按 D、失效、到期计算。后续延续以 D 确认价为基准，在纽约当日 17:00 前观察最多四小时，'
        '比较顺向和反向等距价位的首次触达。分母包含完整观察双边均未触达，行情中断与同一根 M5 同时触达单独记录。'
        'M15 和 H1 单独统计。每组至少 10 例且跨至少 10 个纽约周时，给出按纽约周分块的重采样区间。</p>'
        '<table><thead><tr>'+''.join(f'<th>{h}</th>' for h in head)+'</tr></thead><tbody>'
        +''.join(cells)+'</tbody></table>'
        '<h2>首次连续两根收于对侧时的实体位移</h2>'
        '<p>沿用同一次 A 和 M 的边界，按首次满足连续收盘时的实体大小分组。'
        '从该时刻的收盘价开始，同样比较半个 A 区间的对称价位。未达门槛的样本较少。</p>'
        '<table><thead><tr><th>区间与周期</th><th>顺向先到</th><th>可判定</th><th>未判定</th></tr></thead><tbody>'
        +''.join(run_cells)+'</tbody></table>'
        '<p><a href="summary.json">分组计数</a>　<a href="cases.json.gz">逐例数据</a></p>'
        '<p>从项目根目录用已配置 Pillow、NumPy、tzdata 的 Python 环境运行 '
        '<code>python -m scripts.audit_amd_profile_context --atlas</code> 可重建报告和图集。</p></html>')
    (OUT/'报告.html').write_text(html,encoding='utf8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--atlas',action='store_true')
    parser.add_argument('--atlas-dir',type=Path,default=ATLAS)
    args=parser.parse_args()
    OUT.mkdir(exist_ok=True,parents=True)
    history,recent,provenance=archived_feed()
    older,older_bars=replay(history,False)
    newer,newer_bars=replay(recent,True)
    rows=older+newer
    result=summary(rows)
    result.update(provenance=provenance,sample_size=len(rows),comparison=[])
    metrics={'stage':'完成派发','primary':'4h 半区间顺向先到','short':'2h 半区间顺向先到',
             'wide':'4h 全区间顺向先到'}
    for cohort in PHASES:
        for timeframe in (15,60):
            subset=[r for r in rows if r['cohort']==cohort and r['minutes']==timeframe]
            for key,metric in metrics.items():
                values=weekly_interval(subset,key)
                result['comparison'].append(dict(cohort=cohort,minutes=timeframe,metric=metric,**values))
    with gzip.open(OUT/'cases.json.gz','wt',encoding='utf8') as handle:
        json.dump(rows,handle,ensure_ascii=False)
    (OUT/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    report(result)
    if args.atlas:
        export_atlas(rows,{False:older_bars,True:newer_bars},args.atlas_dir)
    print(len(rows),Counter((r['cohort'],r['minutes']) for r in rows))


if __name__=='__main__':
    main()
