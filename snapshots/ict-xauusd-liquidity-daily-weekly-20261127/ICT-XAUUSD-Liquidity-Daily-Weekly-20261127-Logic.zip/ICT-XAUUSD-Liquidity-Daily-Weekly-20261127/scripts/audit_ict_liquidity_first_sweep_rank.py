"""Holdout ranking of the first strict sweep in frozen IRL and ERL boards."""

from collections import Counter, defaultdict
import json
from pathlib import Path

from scripts import audit_ict_liquidity_15m as quarter
from scripts import audit_ict_liquidity_first_touch as previous
from scripts import audit_ict_target_ranking as fitter
from scripts import replay_ict_liquidity_context as context
from scripts import replay_ict_liquidity_rank as ranking
from scripts.audit_ict_liquidity_filter_layers import audit_price_prefix
from scripts.check_pool_priority import interval, read_market
from scripts.serve_ict_live import atomic_json


STUDY = ranking.study
OUT = STUDY.RESEARCH / 'ict_liquidity_first_sweep_rank_20261125.json'
MODELS = ('structure', 'combined', 'nearest_each_side')


def design(group, model):
    features = 'combined' if model == 'nearest_each_side' else model
    order = previous.nearest_order(group['targets'], group['price'], 'sweep')
    if model == 'nearest_each_side':
        # The first barrier on either side is the normal route to deeper
        # liquidity. Still score the chosen pool itself, including gaps.
        by_side = {}
        for index in order:
            by_side.setdefault(group['targets'][index]['side'], index)
        order = list(by_side.values())
    return dict(indices=order, x=[group['x_by_model'][features][i] for i in order],
                y=[group['first'][i] for i in order], dist=[group['distance'][i] for i in order])


def evaluate(groups):
    training, holdout = [], []
    windows = Counter()
    for group in groups:
        at = group['at']
        if at >= previous.START:
            windows['checkpoints'] += 1
            windows[group['status']] += 1
        if group['status'] != 'complete':
            continue
        if not group['targets']:
            if at >= previous.START:
                windows['empty'] += 1
            continue
        first = fitter.first_bar_events([event['sweep'] for event in group['events']])
        group['first'] = first
        if at < previous.START and group['end'] <= previous.START and any(first):
            training.append(group)
        if at >= previous.START:
            holdout.append(group)
            windows['no_cross'] += not any(first)
            windows['with_cross'] += any(first)
            windows['same_bar_tie'] += sum(first) > 1

    models = {}
    for name in MODELS:
        part = [design(group, name) for group in training]
        model = fitter.fit_prior_weeks(part)
        models[name] = (model, sum(any(row['y']) for row in part))
    hits = Counter()
    changes = {name: Counter() for name in MODELS}
    paired = {name: defaultdict(lambda: [0, 0]) for name in MODELS}
    weekly = defaultdict(Counter)
    for group in holdout:
        first = group['first']
        week = str(group['week'])
        nearest = previous.nearest_order(group['targets'], group['price'], 'sweep')
        picks = dict(current=0, nearest=nearest[0])
        for name, (model, _) in models.items():
            row = design(group, name)
            picks[name] = row['indices'][fitter.select_rank(model, row)]
        resolved = {name: first[index] for name, index in picks.items()}
        if any(first):
            weekly[week]['with_cross'] += 1
        for name, hit in resolved.items():
            hits[name] += hit
            weekly[week][name] += hit
        for name in MODELS:
            if not any(first):
                continue
            base, new = resolved['nearest'], resolved[name]
            paired[name][week][0] += int(new) - int(base)
            paired[name][week][1] += 1
            changes[name]['gained'] += new and not base
            changes[name]['lost'] += base and not new
    comparisons = {
        name: dict(counts, net=hits[name] - hits['nearest'],
                   delta_ci95=interval(paired[name]) if len(paired[name]) >= 2 else None)
        for name, counts in changes.items()
    }
    return dict(windows=windows, train_windows=len(training),
                last_training_maturity=max(g['end'] for g in training).isoformat(),
                hits=hits, comparisons=comparisons, weekly=weekly,
                structure_model=dict(zip(('mean', 'scale', 'coefficients'),
                                         (array.tolist() for array in models['structure'][0]), strict=True)),
                first_winner_in_training_shortlist={name: count for name, (_, count) in models.items()})


def main():
    archive = ranking.ARCHIVE
    candidates = archive / 'round19_liquidity_50_candidates.json.gz'
    outcomes = archive / 'round19_liquidity_50_outcomes.json.gz'
    baseline = json.loads((archive / 'round19_liquidity_baseline.json').read_bytes())
    first_touch_report = json.loads(previous.OUT.read_bytes())
    quote_file = STUDY.RESEARCH / 'dol_expansion_20261122' / 'XAUUSDM5.npz'
    inputs = {path.name: STUDY.digest(path) for path in (candidates, outcomes, quote_file)}
    if (inputs[outcomes.name] != baseline['outcomes_sha256']
            or inputs[candidates.name] != baseline['freeze_sha256']
            or any(inputs[p.name] != first_touch_report['inputs'][p.name] for p in (candidates, quote_file))):
        raise ValueError('Candidates, quotes or outcomes differ from the frozen study')
    bars, times = read_market()
    snapshots, four_hour = map(STUDY.read_zip, (candidates, outcomes))
    labels, confirmations = quarter.short_labels(snapshots, four_hour, bars, times)
    results = {}
    for horizon, base_name, event_rows in (('quarter_hour', '15m', labels), ('short', '4h_or_day_end', four_hour)):
        for scope in ('IRL', 'ERL'):
            groups = list(ranking.build_groups(zip(snapshots, event_rows, strict=True), horizon, scope))
            context.add_context(groups, bars, times)
            result = evaluate(groups)
            base = first_touch_report['results'][f'{base_name}/{scope}/sweep']
            if (result['hits']['current'], result['hits']['nearest'], result['windows']['with_cross']) != (
                base['current_top1'], base['nearest_top1'], base['checkpoints_with_event']
            ):
                raise ValueError(f'Original comparison no longer matches {base_name}/{scope}')
            result['verified_cutoff_prefixes'] = audit_price_prefix(groups, bars, times)
            results[f'{base_name}/{scope}'] = result
            print(f'{base_name}/{scope}', dict(result['hits']), result['comparisons'], flush=True)
    source_files = [Path(module.__file__) for module in (quarter, previous, fitter, context, ranking)]
    atomic_json(OUT, dict(
        inputs=inputs | {Path(__file__).name: STUDY.digest(Path(__file__)),
                         previous.OUT.name: STUDY.digest(previous.OUT)},
        implementation={path.name: STUDY.digest(path) for path in source_files},
        first_holdout=previous.START.isoformat(), quarter_hour_outcome_prefix_checks=confirmations,
        methodology='Fit separately by scope and horizon once, using complete pre-October windows with a first strict far-edge crossing and labels matured by October 1. Evaluate on unchanged October-November boards. Same-bar first events are ties. Comparison confidence intervals resample NY weeks.',
        models=dict(structure='Existing distance and structural features',
                    combined='Structure, past price path, New York clock and recent range pattern',
                    nearest_each_side='Combined features, eligible targets restricted to the nearest far edge on each side'),
        results=results))


if __name__ == '__main__':
    main()
