"""Register the frozen IRL first-sweep challenger and grade later TMGM Bid quotes."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import json
from pathlib import Path
import sqlite3
from time import sleep

import numpy as np

from ict_ai.dol_history import _deadline
from ict_ai.range_liquidity import _research_open
from scripts import audit_ict_liquidity_first_sweep_rank as history
from scripts import watch_ict_liquidity_filter_accuracy as forward
from scripts import watch_ict_micro_liquidity_forward as ticks
from scripts.shadow_ict_dol import write_once
from scripts.watch_ict_dol_settlement import capture_buckets, frozen_feed, open_terminal


OUT = history.STUDY.RESEARCH / 'ict_liquidity_first_sweep_forward_20261125'
POLICY = OUT / 'policy.json'
M5 = forward.M5
SCHEMES = ('chart', 'nearest', 'structure')
HORIZONS = ('15m', '4h_or_day_end')
PINS = (Path(__file__), Path(history.__file__), Path(history.fitter.__file__), Path(history.ranking.__file__),
        Path(history.previous.__file__), Path(forward.__file__), Path(ticks.__file__),
        Path(ticks.__file__).with_name('watch_ict_dol_settlement.py'), Path(forward.feed.__file__),
        Path('ict_ai/structural_liquidity.py'), Path('ict_ai/range_liquidity.py'),
        Path('ict_ai/target_priority.py'), Path('ict_ai/dol_tick_evidence.py'), forward.quotes.CLOCK, history.OUT)
digest = history.STUDY.digest


def load_policy(*, persist):
    pinned = {path.name: digest(path) for path in PINS}
    if not POLICY.exists():
        report = ticks.read(history.OUT)
        for name in (Path(history.__file__).name, Path(history.fitter.__file__).name,
                     Path(history.ranking.__file__).name, Path(history.previous.__file__).name):
            if report['inputs'].get(name, report['implementation'].get(name)) != pinned[name]:
                raise ValueError(f'Historical fit code differs from the live scorer: {name}')
        models = {}
        for horizon in HORIZONS:
            fit = report['results'][f'{horizon}/IRL']
            if datetime.fromisoformat(fit['last_training_maturity']) > datetime.fromisoformat(report['first_holdout']):
                raise ValueError('The historical fit includes an immature label')
            models[horizon] = fit['structure_model']
        policy = dict(frozen_at=forward.now().isoformat(), pins=pinned, models=models, scope='IRL',
                      cutoffs=sorted(forward.quotes.CHECKPOINTS), maximum_candidates=50,
                      outcome='Earliest reconciled Bid strict sweep after durable registration; same millisecond ties.',
                      orders_sent=0)
        if persist:
            write_once(POLICY, policy)
        return policy
    policy = ticks.read(POLICY)
    if policy['pins'] != pinned:
        raise ValueError('Frozen forward inputs or code have changed')
    return policy


def prepare(at, sample, policy):
    with forward.terminal() as (api, clock):
        bars = forward.feed.history('XAUUSD', api.TIMEFRAME_M5, clock, at)
        minute = forward.feed.history('XAUUSD', api.TIMEFRAME_M1, clock, at)
    if bars[-1].time + M5 != at or bars[-1].close != sample['price']:
        raise forward.ReferencePriceMismatch('TMGM close differs from the acknowledged chart')
    pools = [pool for pool in forward.structural_ranking(
        bars, at, sample['targets'], minute_bars=minute, limit=policy['maximum_candidates'], priority_uplift=True
    ) if pool['classification'] == 'IRL']
    chart = sorted((p for p in sample['pools'] if p['scope'] == 'irl'), key=lambda p: p['rank'])
    if [forward.identity(p) for p in pools[:10]] != [forward.identity(p) for p in chart]:
        raise forward.ReferencePriceMismatch('Rebuilt IRL top ten differs from the acknowledged chart')
    return dict(cutoff=at.isoformat(), price=sample['price'], pools=pools, horizons=forecast(pools, sample['price'], at, policy))


def forecast(pools, price, at, policy):
    nearest = history.previous.nearest_order(pools, price, 'sweep')
    distances = [abs(forward.quotes.far(p) - price) / p['hourly_range'] for p in pools]
    x = [history.ranking.features(p, d) for p, d in zip(pools, distances, strict=True)]
    deadlines = {'15m': min(at + 3 * M5, _deadline(at)), '4h_or_day_end': _deadline(at)}
    entries = {}
    for name, end in deadlines.items():
        picks = {}
        if pools:
            saved = policy['models'][name]
            model = tuple(np.array(saved[key]) for key in ('mean', 'scale', 'coefficients'))
            pick = history.fitter.select_rank(model, dict(x=x, dist=distances))
            picks = dict(chart=0, nearest=nearest[0], structure=pick)
        entries[name] = dict(end=end.isoformat(), picks=picks)
    return entries


def register(policy, observed):
    first = max(datetime.fromisoformat(policy['frozen_at']), observed - 3 * M5)
    for at, receipt, batch, sample in forward.read_chart(first, observed):
        stem = f'{at:%Y%m%dT%H%M%SZ}.json'
        board = OUT / 'boards' / stem
        accepted = OUT / 'receipts' / stem
        if accepted.exists():
            continue
        rejected = OUT / 'rejections' / f'{at:%Y%m%dT%H%M%SZ}_{batch}.json'
        if rejected.exists():
            continue
        try:
            if not board.exists():
                candidate = prepare(at, sample, policy)
                write_once(board, dict(**candidate, chart_receipt=receipt.isoformat(),
                                       chart_batch=batch, policy_sha256=digest(POLICY), orders_sent=0))
            # The board file has already been flushed and synced.
            ready = forward.now()
            write_once(accepted, dict(available_at=ready.isoformat(), board_sha256=digest(board)))
        except forward.ReferencePriceMismatch as error:
            write_once(rejected, dict(cutoff=at.isoformat(), chart_batch=batch, reason=str(error)))


def starts_for(cutoff, end):
    slots = (cutoff + i * M5 for i in range((end - cutoff) // M5))
    return [stamp for stamp in slots if _research_open(stamp)]


def grade(board, ready, horizon, buckets):
    cutoff = datetime.fromisoformat(board['cutoff'])
    spec = board['horizons'][horizon]
    end = datetime.fromisoformat(spec['end'])
    if ready >= end:
        return dict(state='expired')
    if not spec['picks']:
        return dict(state='empty')
    if [b['open_utc'] for b in buckets] != [t.isoformat() for t in starts_for(cutoff, end)]:
        return dict(state='incomplete')
    tape = ticks.reconcile(buckets)
    if not tape:
        return dict(state='incomplete')
    if tape[-1][1][-1][0] <= ticks.utc_ms(ready):
        return dict(state='no_post_registration_quote')
    events = [ticks.outcome(p, tape, ready) for p in board['pools']]
    first = min((stamp for state, stamp in events if state == 'sweep'), default=None)
    winners = [i for i, (state, stamp) in enumerate(events) if state == 'sweep' and stamp == first]
    return dict(state='scored', first_bid_ms=first, winning_indices=winners,
                candidates_preexpired=sum(state == 'before_board' for state, _ in events),
                predictions={name: dict(index=i, state=events[i][0], crossing_ms=events[i][1], hit=i in winners)
                             for name, i in spec['picks'].items()})


def load_board(receipt_path, policy):
    path = OUT / 'boards' / receipt_path.name
    board, receipt = ticks.read(path), ticks.read(receipt_path)
    cutoff, chart, ready = (datetime.fromisoformat(s) for s in
                            (board['cutoff'], board['chart_receipt'], receipt['available_at']))
    if (board['policy_sha256'] != digest(POLICY) or receipt['board_sha256'] != digest(path)
            or not datetime.fromisoformat(policy['frozen_at']) < cutoff <= chart <= ready):
        raise ValueError(f'Frozen board or timestamp mismatch: {path.name}')
    return board, cutoff, ready


def settle(policy, alive, source, observed):
    for receipt in sorted((OUT / 'receipts').glob('*.json')):
        board, cutoff, ready = load_board(receipt, policy)
        for horizon, spec in board['horizons'].items():
            out = OUT / 'settlements' / f'{receipt.stem}_{horizon}.json'
            end = datetime.fromisoformat(spec['end'])
            if out.exists() or observed < end + ticks.SYNC:
                continue
            starts = starts_for(cutoff, end) if ready < end and spec['picks'] else []
            buckets = [bucket for _, bucket in capture_buckets(forward.feed.mt5, alive, source, starts, observed)]
            result = grade(board, ready, horizon, buckets)
            if result['state'] == 'incomplete' and observed < end + ticks.FINAL_RETRY:
                continue
            forward.atomic_json(out, dict(horizon=horizon, receipts_sha256=digest(receipt),
                                          result=result, market_buckets=buckets, orders_sent=0))


def status(policy, *, verify=False):
    counts = defaultdict(Counter)
    receipts = sorted((OUT / 'receipts').glob('*.json'))
    for path in sorted((OUT / 'settlements').glob('*.json')):
        saved = ticks.read(path)
        receipt = OUT / 'receipts' / f'{path.name.split("_")[0]}.json'
        if saved['receipts_sha256'] != digest(receipt):
            raise ValueError(f'Settlement lost its frozen evidence: {path.name}')
        result, horizon = saved['result'], saved['horizon']
        if verify:
            board, _, ready = load_board(receipt, policy)
            if result != grade(board, ready, horizon, saved['market_buckets']):
                raise ValueError(f'Settlement no longer reproduces: {path.name}')
        counter = counts[horizon]
        counter[result['state']] += 1
        if result['state'] == 'scored':
            counter['with_post_registration_sweep'] += bool(result['winning_indices'])
            for name in SCHEMES:
                hit = result['predictions'][name]
                counter[f'{name}_hits'] += hit['hit']
                counter[f'{name}_preexpired'] += hit['state'] == 'before_board'
    if verify:
        for receipt in receipts:
            board, at, _ = load_board(receipt, policy)
            if board['horizons'] != forecast(board['pools'], board['price'], at, policy):
                raise ValueError(f'Frozen prediction no longer reproduces: {receipt.name}')
    return dict(frozen_at=policy['frozen_at'], observed_at=forward.now().isoformat(), registrations=len(receipts),
                rejections=len(list((OUT / 'rejections').glob('*.json'))), counts=counts, orders_sent=0)


def probe(policy, alive, source):
    now = forward.now()
    for at, received, batch, sample in reversed(list(forward.read_chart(now - timedelta(days=4), now - M5))):
        if _deadline(at) + ticks.SYNC > now:
            continue
        try:
            board = prepare(at, sample, policy)
        except forward.ReferencePriceMismatch:
            continue
        starts = starts_for(at, _deadline(at))
        buckets = [bucket for _, bucket in capture_buckets(forward.feed.mt5, alive, source, starts, now)]
        outcomes = {name: grade(board, received, name, [b for b in buckets if b['open_utc'] < spec['end']])
                    for name, spec in board['horizons'].items()}
        if any(item['state'] == 'scored' for item in outcomes.values()):
            forward.atomic_json(OUT / 'rehearsal.json', dict(**board, chart_batch=batch,
                                chart_receipt=received.isoformat(), outcomes=outcomes, historical_only=True))
            print(at.isoformat(), len(board['pools']), {key: row['state'] for key, row in outcomes.items()})
            return
    raise RuntimeError('No matching acknowledged IRL board and reconciled Bid history to rehearse')


def main():
    import msvcrt

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('probe', 'watch', 'verify'))
    parser.add_argument('--terminal-pid', type=int)
    args = parser.parse_args()
    if args.mode == 'verify':
        if not POLICY.exists():
            raise FileNotFoundError(POLICY)
        print(json.dumps(status(load_policy(persist=False), verify=True)))
        return
    if args.terminal_pid is None:
        parser.error('--terminal-pid is required for a reading session')
    for folder in ('boards', 'receipts', 'settlements', 'rejections'):
        (OUT / folder).mkdir(parents=True, exist_ok=True)
    source = frozen_feed()
    with open_terminal(args.terminal_pid) as alive:
        if args.mode == 'probe':
            probe(load_policy(persist=False), alive, source)
            return
        with (OUT / 'watch.lock').open('a+b') as lock:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            policy = load_policy(persist=True)
            while alive():
                try:
                    observed = forward.now()
                    register(policy, observed)
                    settle(policy, alive, source, observed)
                    report = status(policy)
                except (OSError, RuntimeError, sqlite3.OperationalError) as error:
                    report = dict(state='awaiting_data', reason=str(error), observed_at=forward.now().isoformat())
                forward.atomic_json(OUT / 'status.json', report)
                sleep(10)


if __name__ == '__main__':
    main()
