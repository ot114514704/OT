"""Integrate weekly course and supplied guide with exact source anchors."""
import hashlib,json,zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'research/ict_weekly_profiles'
DOC=Path('D:/BaiduNetdiskDownload/ICT交易核心概念-每周概况这将彻底改变你看图表的方式-时间（三）.doc')


def main():
    with zipfile.ZipFile(DOC) as z:
        root=ET.fromstring(z.read('word/document.xml'))
        chunks=[e.text or '' for e in root.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t')]
    text='\n'.join(chunks)
    (OUT/'transcript.txt').write_text(text,encoding='utf-8')
    manifest=json.loads((OUT/'manifest.json').read_text(encoding='utf-8'))
    manifest['doc']={'path':DOC.as_posix(),'sha256':hashlib.sha256(DOC.read_bytes()).hexdigest(),'actual_format':'docx'}
    manifest['ppt_visual_reviewed']=[n for n in range(1,27) if n not in [23,25,26]]
    manifest['excluded_slides_by_user']=[23,25,26]
    guide=json.loads((OUT/'guide_manifest.json').read_text(encoding='utf-8'))
    guide['reviewed_text_pages']=list(range(1,66))
    guide['reviewed_visual_pages']=[7,8,17,19,22,23,43,44,59,60,61,62,63]
    (OUT/'guide_manifest.json').write_text(json.dumps(guide,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    rules=json.loads((OUT/'curated.json').read_text(encoding='utf-8'))
    for card in rules['profiles']:
        start=text.find(card['doc_anchor'])
        if start<0:raise ValueError(card['doc_anchor'])
        card['doc_location']={'unit':'unicode_codepoint','start':start,'end':start+len(card['doc_anchor']),'exact_text':card['doc_anchor']}
    rules['sources']={'course_ppt':manifest['ppt'],'course_doc':manifest['doc'],'guide':guide}
    (OUT/'rules.json').write_text(json.dumps(rules,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=[rules['title'],'','核对范围：DOC 全文、PPT 核心页、英文指南 65 页正文及 13 页关键图。PPT 第 23、25、26 页按用户要求排除。','']
    for card in rules['profiles']:
        lines += [card['name'],card['source_summary'],'课件页：'+str(card['slides']),'英文指南实际页：'+str(card['guide_physical_pages']),'限制：'+'；'.join(card['limits']),'']
    lines += ['三套英文协议']
    for protocol in rules['guide_protocols']:
        lines += [protocol['id']+'（实际页 '+str(protocol['physical_pages'])+'）']+protocol['steps']+['']
    lines += ['TGIF',rules['tgif']['summary'],rules['tgif']['guide_targets']] + rules['tgif']['limits'] + ['','整合层级'] + rules['hierarchy'] + ['','重要边界'] + rules['important_limits'] + ['','图片质量']
    for q in rules['image_quality']:lines += ['课件第 '+str(q['slides'])+' 页：'+q['status'],q['limits']]
    report=ROOT/'output/research/ICT每日与每周概况_周背景整合.txt'
    report.parent.mkdir(parents=True,exist_ok=True);report.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    entries=[]
    for i,chunk in enumerate(chunks,1):entries.append({'id':f'weekly-doc-{i}','source_path':DOC.as_posix(),'text_chunk':i,'kind':'source_text','text':chunk,'reviewed':True})
    pages=json.loads((OUT/'guide_extracted_pages.json').read_text(encoding='utf-8'))
    for i,page in enumerate(pages,1):entries.append({'id':f'weekly-guide-{i}','source_path':guide['source_path'],'page':i,'kind':'source_text','text':page,'reviewed':True,'visual_reviewed':i in guide['reviewed_visual_pages']})
    for card in rules['profiles']:entries.append({'id':card['id'],'source_path':manifest['ppt']['path'],'pages':card['slides'],'kind':'curated_weekly_card','text':card['name']+'\n'+card['source_summary']+'\n'+'；'.join(card['limits']),'reviewed':True})
    (OUT/'corpus.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in entries),encoding='utf-8')
    objectives=json.loads((ROOT/'research/ict_objectives.json').read_text(encoding='utf-8'))
    objectives['additional_user_materials']=[manifest['ppt']['path'],DOC.as_posix(),guide['source_path']]
    objectives['completed']=sorted(set(objectives['completed']+['weekly_course_core_review','weekly_six_profiles_and_guide_protocols']))
    (ROOT/'research/ict_objectives.json').write_text(json.dumps(objectives,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'profiles':6,'guide_text_pages':65,'excluded_slides':[23,25,26],'report':str(report)},ensure_ascii=False))


if __name__=='__main__':main()
