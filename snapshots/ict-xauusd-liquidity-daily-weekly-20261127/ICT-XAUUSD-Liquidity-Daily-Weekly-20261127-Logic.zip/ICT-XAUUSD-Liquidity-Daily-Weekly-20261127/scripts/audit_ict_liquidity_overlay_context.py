"""Measure liquidity overlay performance by context available at each cutoff."""

from collections import Counter, defaultdict
from datetime import datetime, timedelta
import json
from pathlib import Path

from ict_ai.dol_history import week_start
from ict_ai.structural_liquidity import trade_day
from ict_ai.timebase import NY, session_windows
from scripts import audit_ict_liquidity_repo_overlay as overlay


joint = overlay.shared.joint
DAILY = joint.RESEARCH / 'ict_daily_abstention_20261125.json'
OUT = overlay.OUT.with_name('repo_overlay_context.json')


def session(at):
    day = at.astimezone(NY).date()
    spans = session_windows(day)
    spans['asia'] = session_windows(day + timedelta(days=1))['asia']
    return next((name for name, (start, end) in spans.items() if start <= at < end), 'outside_sessions')


def daily_context(at, forecasts):
    day = trade_day(at).isoformat()
    row = forecasts.get(day)
    if row is None:
        return dict(state='no_archived_forecast')
    cutoff = datetime.fromisoformat(row['cutoff'])
    if cutoff > at:
        return dict(state='before_daily_forecast')
    if row['calibration_through'] and datetime.fromisoformat(row['calibration_through']) > cutoff:
        raise ValueError(f'The daily forecast uses later labels: {day}')
    selected = row['decisions']['calibrated_65']['offer']
    return dict(state='available' if selected else 'abstained', cutoff=cutoff.isoformat(),
                key=row['key'] if selected else None)


def measure(cases, forecasts):
    sessions, daily, weeks = (defaultdict(Counter) for _ in range(3))
    rows = []
    for case in cases:
        at = datetime.fromisoformat(case['cutoff'])
        current = at.astimezone(NY)
        name = session(at)
        profile = daily_context(at, forecasts)
        week = week_start(current.date()).isoformat()
        before, after = (case['wins'][arm] for arm in ('local', 'fixed_two'))
        delta = dict(windows=1, local=int(before), integrated=int(after), gained=int(after and not before),
                     lost=int(before and not after))
        sessions[name].update(delta)
        daily[profile['state']].update(delta)
        weeks[week].update(delta)
        rows.append(dict(cutoff=case['cutoff'], eastern=current.isoformat(), session=name, ny_week=week,
                         daily_profile=profile, local_hit=before, integrated_hit=after))
    return dict(session=sessions, daily=daily, weeks=weeks, cases=rows)


def main():
    saved, daily = map(overlay.shared.fixed.read, (overlay.OUT, DAILY))
    forecasts = {row['date']: row for row in daily['forecasts']}
    if len(forecasts) != len(daily['forecasts']):
        raise ValueError('Multiple daily forecasts for a cutoff date')
    groups = {}
    for name, horizons in saved['results'].items():
        groups[name] = {}
        for minutes, data in horizons.items():
            result = measure(data['cases'], forecasts)
            expected = data['counts']
            totals = {key: expected[value] for key, value in (('windows', 'windows'), ('local', 'local'),
                      ('integrated', 'fixed_two'), ('gained', 'fixed_two_gained'), ('lost', 'fixed_two_lost'))}
            for split in ('session', 'daily', 'weeks'):
                if sum(result[split].values(), Counter()) != Counter({k: n for k, n in totals.items() if n}):
                    raise ValueError(f'Partition does not reconcile: {name}, {minutes}, {split}')
            groups[name][minutes] = result
    overlay.shared.live.atomic_json(OUT, dict(results=groups, inputs={p.name: joint.digest(p) for p in (
        overlay.OUT, DAILY, Path(__file__), *(joint.ROOT / 'ict_ai' / name for name in
            ('timebase.py', 'dol_history.py', 'structural_liquidity.py')))}, orders_sent=0,
        method=('Descriptive only. Use the half-open New York session containing the frozen H1 cutoff. '
                'The local trading-day rule assigns the Sunday reopen to Monday. '
                'Join daily profiles only after their archived cutoff, without reading outcome labels. '
                'The existing calibrated-65 abstention is recorded as context without changing either shortlist.')))
    print(json.dumps({name: {key: value for key, value in study['15'].items() if key != 'cases'}
                      for name, study in groups.items()}))


if __name__ == '__main__':
    main()
