"""Compare the existing structure verdict with V7B on common M5 events."""

from bisect import bisect_left
from collections import Counter
from datetime import datetime
from pathlib import Path
import json

from ict_ai.sweep_response import sequence
from scripts import replay_ict_sweep_verdict as replay


M5 = replay.M5
OLD_RECLAIM = {'reverse_held', 'same_close_held'}
OUT = replay.OUT / 'structure_comparison.json'


def structure_verdict(event, bars, times):
    opened = datetime.fromisoformat(event['crossing_at'])-M5
    i = bisect_left(times,opened)
    if i >= len(times) or times[i] != opened:
        raise ValueError(f'Crossing has no corresponding quote: {opened}')
    target = dict(side=event['side'],lo=event['edge'],hi=event['edge'])
    shape = sequence(target,bars[max(0,i-24):i],bars[i:i+13],opened)['shape']
    if shape in OLD_RECLAIM:
        return 'sweep'
    if shape == 'continued_without_reclaim':
        return 'break'
    return None


def combined_verdicts(event, bars, times):
    old = structure_verdict(event,bars,times)
    status = event['decisions']['60']['status']
    v7b = status if status in ('sweep','break') else None
    return dict(structure=old, v7b=v7b, structure_first=old or v7b,
                agreement=old if old == v7b else None)


def compare(events, bars, times):
    result = Counter()
    for event in events:
        verdict = event['decisions']['60']
        future = verdict['later_30m']
        if future == 'incomplete' or verdict['status'] in ('missing_prior', 'incomplete'):
            continue
        old = structure_verdict(event,bars,times)
        new = verdict['status'] if verdict['status'] in ('sweep','break') else None
        result['opportunities'] += 1
        result['structure_covered'] += old is not None
        result['v7b_covered'] += new is not None
        if future == 'mixed':
            continue
        result['structure_directional'] += old is not None
        result['v7b_directional'] += new is not None
        result['structure_matched'] += old == future
        result['v7b_matched'] += new == future
        if old and new:
            result['common_directional'] += 1
            result['common_structure_matched'] += old == future
            result['common_v7b_matched'] += new == future
        elif new:
            result['new_directional'] += 1
            result['new_matched'] += new == future
    return result


def main():
    bars,times,*_ = replay.read_inputs()
    report = replay.OUT/'report.json'
    records = replay.OUT/'events.json.gz'
    source = json.loads(report.read_bytes())
    tape = replay.study.read_zip(records)
    for rel,digest in source['input_hashes'].items():
        if replay.study.digest(replay.filters.ROOT/rel) != digest:
            raise ValueError(f'Locked evaluation input differs: {rel}')
    if len(tape['events']) != source['event_count']:
        raise ValueError('Event evidence count differs')
    results = {}
    for cohort,selection in (('oct_nov','top10'),('last_week','final_filter')):
        for scope in ('IRL','ERL'):
            key = f'{cohort}/short/{scope}/{selection}'
            events = (tape['events'][i] for i in tape['indices'].get(key,()))
            results[key] = compare(events,bars,times)
    replay.filters.atomic_json(OUT,dict(
        inputs={p.name:replay.study.digest(p) for p in (report,records,Path(__file__).resolve())},
        response_at=60, settlement_minutes=30,
        old_method='Existing sequence mapped to rejection when the reverse swing is broken and held;'
                   ' continuation when no reclaim occurs and the close remains outside; otherwise abstain.',
        results=results, orders_sent=0,
    ))
    print(json.dumps(results,ensure_ascii=False))


if __name__ == '__main__':
    main()
