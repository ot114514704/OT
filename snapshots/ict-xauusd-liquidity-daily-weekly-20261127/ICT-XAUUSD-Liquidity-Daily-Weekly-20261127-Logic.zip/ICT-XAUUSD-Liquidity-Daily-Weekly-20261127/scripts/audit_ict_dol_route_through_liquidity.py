"""Observe frozen DOL delivery after an intervening IRL or ERL boundary."""

from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime, time, timedelta
import json
from pathlib import Path

import numpy as np

from ict_ai.dol_history import _deadline
from ict_ai.range_liquidity import M5, _Coverage
from ict_ai.timebase import NY
from scripts.audit_ict_dol_liquidity_reaction import (
    HOLDOUT, MINUTE_ARCHIVE, POOLS, far_edge, frozen_candidates, market, source,
)
from scripts.audit_ict_target_order import MinuteOrder, first_minute
from scripts.audit_ict_target_ranking import fit_prior_weeks
from scripts.serve_ict_live import atomic_json


OUT = source.RESEARCH/'ict_dol_route_through_liquidity_20261124.json'


def near_edge(target):
    return target['lo'] if target['side']==1 else target['hi']


def freeze_route(dol, pool, price):
    """Choose the highest-ranked route with a whole gate in front."""
    for index,target in enumerate(dol):
        side = target['side']
        edge = near_edge(target)
        gates = [g for g in pool if g['side']==side and side*(near_edge(g)-price)>0
                 and side*(edge-far_edge(g))>0]
        if gates:
            gate = min(gates,key=lambda g:(side*(far_edge(g)-price),g['rank']))
            return dict(target=target, gate=gate, side=side, dol_rank=index + 1)
    return None


def landmark(bars, route):
    """Wait for two complete candles after a witnessed strict boundary crossing."""
    side, gate, destination = route['side'],far_edge(route['gate']),near_edge(route['target'])
    crossed = None
    after = []
    for bar in bars:
        furthest = bar.high if side == 1 else bar.low
        known = bar.time+M5
        if side * (furthest - destination) >= 0:
            return dict(status='dol_reached_or_jumped_before_landmark',available_at=known.isoformat())
        if crossed is None:
            if side * (furthest - gate) <= 0:
                continue
            if not bar.low <= gate <= bar.high:
                return dict(status='gate_gap_over',available_at=known.isoformat())
            crossed = known
            continue
        if bar.time!=crossed+len(after)*M5:
            return dict(status='gap_after_gate_cross',available_at=known.isoformat())
        after.append(side*(bar.close-gate))
        if len(after)==2:
            kind = 'accepted' if min(after)>0 else 'reclaimed' if after[-1]<0 else 'unresolved'
            return dict(status='landmark', available_at=known.isoformat(), gate_cross_known_at=crossed.isoformat(),
                        close=bar.close, reaction=kind, reclaimed_full_zone=side * (bar.close - near_edge(route['gate'])) < 0)
    return dict(status='gate_not_crossed' if crossed is None else 'gate_crossed_without_landmark')


def first_destination(suffix, route):
    """Retain gap-overs separately from a witnessed DOL contact."""
    side = route['side']
    edge = near_edge(route['target'])
    for bar in suffix:
        if bar.low<=edge<=bar.high:
            return 'contact',(bar.time+M5).isoformat()
        if side*((bar.low if side==1 else bar.high)-edge)>0:
            return 'unwitnessed_gap_over',(bar.time+M5).isoformat()
    return 'no_contact',None


def features(row, with_reaction):
    base = [np.log1p(row['distance_h1']),np.log1p(row['minutes_remaining']),row['side'],
            row['dol_score'],np.log1p(row['gate_to_dol_h1'])]
    if with_reaction:
        base += [int(row['reaction']=='accepted'),int(row['reaction']=='reclaimed')]
    return base


def predict(test, train, with_reaction):
    design = [{'x':[features(r,with_reaction)],'y':[int(r['outcome']=='contact')]} for r in train]
    avg,scale,coef = fit_prior_weeks(design)
    observed = np.array([features(row,with_reaction) for row in test])
    logits = coef[0]+((observed-avg)/scale)@coef[1:]
    return (1/(1+np.exp(-np.clip(logits,-40,40)))).tolist()


def rate_summary(rows):
    outcome = Counter()
    for row in rows:
        label = row['reaction']
        outcome[label+'_windows'] += 1
        outcome[label+'_hits'] += row['outcome']=='contact'
    return dict(outcome)


def verify_with_minutes(minute_order, at, target, *, sweep):
    parts = minute_order.reconciled_minutes(datetime.fromisoformat(at))
    if parts is None:
        return 'm1_unavailable_or_mismatch'
    if first_minute(parts, target, sweep) is None:
        return 'm1_boundary_unwitnessed'
    return 'm1_confirmed'


def cell_comparison(rows):
    """Descriptive same-side comparisons at similar distances and time remaining."""
    bins = defaultdict(Counter)
    for r in rows:
        cell = (r['scope'],r['side'],int(r['distance_h1']*2),int(r['minutes_remaining']//30))
        bins[cell][r['reaction']] += 1
        bins[cell][r['reaction']+'_hits'] += r['outcome']=='contact'
    accepted = reclaimed = 0
    total = 0.
    for cell in bins.values():
        if cell['accepted']>=3 and cell['reclaimed']>=3:
            accepted += cell['accepted']
            reclaimed += cell['reclaimed']
            total += cell['accepted_hits']-cell['accepted']*cell['reclaimed_hits']/cell['reclaimed']
    return dict(accepted=accepted,reclaimed_controls=reclaimed,
                weighted_hit_rate_difference=total/accepted if accepted else None)


def walk_forward(rows):
    # Matched quotes can recur under adjacent forecast times or both list scopes.
    # The pooled model weights one path. Scope-specific stats remain separate.
    unique = {}
    for r in rows:
        key = (r['at'],r['side'],r['gate_outer'],r['dol_near'])
        unique.setdefault(key,r)
    rows = list(unique.values())
    forecasts = []
    for wk in sorted({r['week'] for r in rows if r['known']>=HOLDOUT}):
        boundary = datetime.combine(wk,time(0),NY)
        train = [r for r in rows if r['deadline']<=boundary and r['known']<boundary]
        test = [r for r in rows if r['week']==wk and r['known']>=HOLDOUT]
        wins = sum(r['outcome']=='contact' for r in train)
        if len(train)<40 or min(wins,len(train)-wins)<10 or not test:
            continue
        base = predict(test,train,False)
        trial = predict(test,train,True)
        for row,a,b in zip(test,base,trial,strict=True):
            forecasts.append(dict(at=row['at'],week=wk.isoformat(),target=row['dol_near'],gate=row['gate_outer'],
                                  observed=row['reaction'],y=int(row['outcome']=='contact'),prior=wins/len(train),
                                  base=a,with_reaction=b,training=len(train)))
    scores = {k:float(np.mean([(p[k]-p['y'])**2 for p in forecasts])) if forecasts else None
              for k in ('prior','base','with_reaction')}
    paired = defaultdict(list)
    for row in forecasts:
        paired[row['week']].append((row['with_reaction']-row['y'])**2-(row['base']-row['y'])**2)
    interval = market.interval({w:(sum(values),len(values)) for w,values in paired.items()}) if len(paired)>1 else None
    return dict(unique_routes=len(rows),tested=len(forecasts),tested_weeks=len(paired),brier=scores,
                reaction_minus_base_paired_interval95=interval,forecasts=forecasts)


def run():
    bars,times = market.read_market()
    coverage = _Coverage(times[0],times[-1]+M5,bars,M5)
    minute_lock = MINUTE_ARCHIVE.parent / 'm1-lock.json'
    if source.digest(MINUTE_ARCHIVE) != json.loads(minute_lock.read_bytes())['digest']:
        raise ValueError('Frozen M1 archive changed')
    minute_order = MinuteOrder(source.read_zip(MINUTE_ARCHIVE), bars)
    paired = defaultdict(dict)
    sources = {market.ARCH/'XAUUSDM5.npz',market.ARCH/'clock_validation.json',
               Path(__file__).resolve(),source.ROOT/'scripts/audit_ict_dol_liquidity_reaction.py',
               source.ROOT/'scripts/audit_ict_target_ranking.py',source.ROOT/'ict_ai/dol_history.py',
               source.ROOT/'ict_ai/range_liquidity.py',market.ARCH/'run.py',market.ARCH/'manifest.json',
               POOLS/'round19_liquidity_50_lock.json',MINUTE_ARCHIVE,minute_lock,
               source.ROOT/'scripts/audit_ict_target_order.py',source.ROOT/'scripts/check_pool_priority.py'}
    for family,stamp,price,targets,scale,paths in frozen_candidates():
        sources.update(paths)
        paired[datetime.fromisoformat(stamp)][family] = price,targets,scale
    counters = defaultdict(Counter)
    seen = set()
    rows = []
    prefix_checks = 0
    frozen_pairs = Counter()
    minute_checks = defaultdict(Counter)
    contact_prefix_checks = 0
    for at,sample in sorted(paired.items()):
        if 'dol' not in sample:
            continue
        price,dol,scale = sample['dol']
        if not scale or not dol:
            continue
        for scope in ('IRL','ERL'):
            if scope not in sample:
                continue
            frozen_pairs[scope] += 1
            pool_price,pool,_ = sample[scope]
            index = bisect_left(times,at)
            end = _deadline(at)
            if not index or bars[index-1].time+M5!=at or not (abs(pool_price-price)<1e-8 and abs(bars[index-1].close-price)<1e-8):
                counters[scope]['price_freeze_mismatch'] += 1
                continue
            if coverage.cutoff<end or coverage.gap(at,end) or end<=at:
                counters[scope]['incomplete_window'] += 1
                continue
            future = bars[index:bisect_left(times,end)]
            route = freeze_route(dol, pool, price)
            if not route:
                counters[scope]['no_gate_before_dol'] += 1
                continue
            observation = landmark(future,route)
            counters[scope][observation['status']] += 1
            if observation['status']!='landmark':
                continue
            known = datetime.fromisoformat(observation['available_at'])
            early = [b for b in future if b.time+M5<=known]
            if landmark(early,route)!=observation or landmark(early[:-1],route)['status']=='landmark':
                raise AssertionError(f'Future bar changed the gate reaction at {known}')
            prefix_checks += 2
            destination = near_edge(route['target'])
            gate = far_edge(route['gate'])
            key = (scope,known,route['side'],gate,destination)
            if key in seen:
                counters[scope]['same_route_and_landmark'] += 1
                continue
            seen.add(key)
            suffix = [b for b in future if b.time >= known]
            status,contact = first_destination(suffix, route)
            if status=='unwitnessed_gap_over' or known>=end:
                counters[scope]['unscored_suffix'] += 1
                continue
            if contact:
                first_contact = datetime.fromisoformat(contact)
                prefix = [b for b in suffix if b.time + M5 <= first_contact]
                if first_destination(prefix, route) != (status, contact) or first_destination(prefix[:-1], route)[0] != 'no_contact':
                    raise AssertionError(f'Future bar changed DOL contact at {first_contact}')
                contact_prefix_checks += 2
            minute_evidence = {}
            if known >= HOLDOUT:
                minute_evidence['gate'] = verify_with_minutes(minute_order, observation['gate_cross_known_at'], route['gate'], sweep=True)
                if contact:
                    minute_evidence['dol'] = verify_with_minutes(minute_order, contact, route['target'], sweep=False)
                for boundary, result in minute_evidence.items():
                    minute_checks[boundary][result] += 1
            day = known.astimezone(NY).date()
            rows.append(dict(scope=scope,forecast_at=at.isoformat(),at=known.isoformat(),deadline=end,known=known,
                       week=day-timedelta(days=day.weekday()),gate_cross_known_at=observation['gate_cross_known_at'],
                       side=route['side'],reaction=observation['reaction'],outcome=status,dol_contact_known_at=contact,
                       dol_near=destination,gate_outer=gate,dol_score=route['target']['score'],
                       original_dol_leader=route['dol_rank'] == 1,dol_rank=route['dol_rank'],
                       reclaimed_full_zone=observation['reclaimed_full_zone'],minute_evidence=minute_evidence,
                       distance_h1=abs(destination-observation['close'])/scale,gate_to_dol_h1=abs(destination-gate)/scale,
                       minutes_remaining=(end-known).total_seconds()/60,
                       dol_source=route['target']['source'],gate_source=route['gate']['source']))
    holdout = [r for r in rows if r['known']>=HOLDOUT]
    comparisons = {scope:rate_summary([r for r in holdout if r['scope']==scope]) for scope in ('IRL','ERL')}
    full_zone = [r for r in holdout if r['reaction'] == 'reclaimed' and r['reclaimed_full_zone']]
    strict = [r for r in holdout if r['original_dol_leader']]
    return dict(freeze_overlap=dict(frozen_pairs),counts={k:dict(c) for k,c in counters.items()},prefix_checks=prefix_checks,
                contact_prefix_checks=contact_prefix_checks,minute_evidence={k:dict(c) for k,c in minute_checks.items()},
                primary='First original-ranked DOL with an intervening frozen top-ten gate fully between price and the target. Judge two complete candles after the strict gate cross, and forecast only a remaining originally frozen DOL touch.',
                out_of_sample_first=HOLDOUT.isoformat(),holdout_rates=comparisons,
                original_rank1_only=rate_summary(strict),same_side_distance_time_cells=cell_comparison(holdout),
                holdout_full_zone_reclaims={scope:rate_summary([r for r in full_zone if r['scope']==scope]) for scope in ('IRL','ERL')},
                sample_out_model=walk_forward(rows),
                rows=[dict(r,week=r['week'].isoformat(),known=r['known'].isoformat(),deadline=r['deadline'].isoformat()) for r in rows],
                inputs={str(p.relative_to(source.ROOT)):source.digest(p) for p in sorted(sources)},orders_sent=0)


if __name__=='__main__':
    data = run()
    atomic_json(OUT,data)
    print(data['freeze_overlap'],data['counts'],data['prefix_checks'])
    print(data['holdout_rates'],data['same_side_distance_time_cells'])
    fit = data['sample_out_model']
    print(fit['tested'],fit['brier'],fit['reaction_minus_base_paired_interval95'])
