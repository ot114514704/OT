"""Isolate single-sided weekly evidence in the 10:00 New York daily model."""

from bisect import bisect_left, bisect_right
from collections import Counter
from datetime import timedelta
import json
from pathlib import Path

from ict_ai.profile_alignment import align_candidates, observed_context
from scripts import audit_ict_daily_learning as daily
from scripts import audit_ict_week_daily_context as broad
from scripts.audit_ict_daily_sweep_features import reviewed_days
from scripts.serve_ict_live import atomic_json


OUT = daily.RESEARCH / 'ict_week_direction_for_daily_20261125.json'
TIMINGS = ('ny_open', 'current')
SUPPORT = {'aligned': 1, 'opposed': -1}


def augment(days, bars, times):
    quarters = daily.aggregate_bars(bars, 5, 15, times[-1] + daily.M5)
    quarter_times = [bar.time for bar in quarters]
    amended = {tag: [] for tag in TIMINGS}
    evidence = {tag: {} for tag in TIMINGS}
    checks = Counter()
    for row in days:
        if not row['keys']:
            for tag in TIMINGS:
                amended[tag].append(row)
            continue
        dates = [row['week'] + timedelta(days=i) for i in range(5)]
        start = daily._day_bounds(dates[0])[0]
        end = daily._day_bounds(dates[-1])[1]
        windows = (daily.session_windows(row['date'])['new_york'][0], row['at'])
        left, right = bisect_left(times, start), bisect_left(times, end)
        q_left, q_right = bisect_left(quarter_times, start), bisect_left(quarter_times, end)
        cards = [dict(id=name, label=name, direction=side, observed_sequence=True, status='active')
                 for name, side in row['keys']]
        for tag, at in zip(TIMINGS, windows, strict=True):
            if not start <= at <= row['at']:
                raise ValueError(f'Invalid evidence cutoff at {at}')
            m5 = bars[left:bisect_right(times, at - daily.M5)]
            m15 = quarters[q_left:bisect_right(quarter_times, at - daily.M15)]
            week = observed_context(m5, m15, dates, at)
            reference = observed_context(bars[left:right], quarters[q_left:q_right], dates, at)
            if week != reference:
                raise ValueError(f'Later bars changed weekly evidence at {at}')
            checks[tag] += 1
            comparisons = align_candidates({'candidates': cards}, week)
            states = [comparison['comparison'] for comparison in comparisons]
            columns = [[*features, SUPPORT.get(state, 0)] for features, state in zip(row['x'], states, strict=True)]
            amended[tag].append(dict(row, x=columns))
            evidence[tag][row['date'].isoformat()] = dict(at=at.isoformat(), covered=week['covered'],
                                                         candidates=week['active'], states=states)
    return amended, evidence, checks


def summarize(baseline, trial, evidence):
    rows = []
    for old, new in zip(baseline['observations'], trial['observations'], strict=True):
        identity = ('date', 'keys', 'rule_y', 'manual_y', 'trained_through', 'training_dates')
        if any(old[key] != new[key] for key in identity):
            raise ValueError(f'Comparison cohort changed on {old["date"]}')
        states = evidence[new['date']]['states']
        has_signal = any(state in SUPPORT for state in states)
        # Compare a model that can opt out when weekly context supplies no signed evidence.
        scores = new['learned'] if has_signal else old['learned']
        rows.append(dict(new, learned=scores, signed_family_prior=old['learned'],
                         has_week_direction=has_signal, evidence_states=states))
    results = {}
    for name, cohort, truth in (
        ('all_rule', rows, 'rule_y'),
        ('recent_rule', [r for r in rows if r['date'] >= '2026-10-01'], 'rule_y'),
        ('explicit_week_direction', [r for r in rows if r['has_week_direction']], 'rule_y'),
        ('manual', rows, 'manual_y'),
    ):
        metrics = daily.metrics(cohort, truth)
        stratified = {}
        for row in cohort:
            if row[truth] is None:
                continue
            for state, hit in zip(row['evidence_states'], row[truth], strict=True):
                tally = stratified.setdefault(state, Counter())
                tally['offered'] += 1
                tally['matched'] += hit
        results[name] = dict(original=metrics['signed_family_prior'], with_week_direction=metrics['learned'],
                             descriptive_candidates_by_context=stratified)
        if truth == 'rule_y':
            interval = daily.paired_weeks(cohort)
            interval.pop('measure', None)
            results[name]['brier_improvement_week_interval'] = interval
    return results, rows


def main():
    market = daily.ARCH / 'XAUUSDM5.npz'
    lock = daily.ARCH / 'manifest.json'
    if daily.digest(market) != json.loads(lock.read_bytes())[market.name]:
        raise ValueError('TMGM M5 input differs from the frozen archive')
    bars, times = daily.read_market()
    days = daily.pack(bars, times)
    manual = reviewed_days()
    changed, evidence, checks = augment(days, bars, times)
    baseline = daily.walk_forward(days, manual)
    by_date = {str(row['date']): row for row in days}
    ranking_opportunities = Counter()
    omitted_paths = Counter()
    for observation in baseline['observations']:
        row = by_date[observation['date']]
        if row['y'] is None:
            continue
        if not row['actual']:
            ranking_opportunities['no_realized_path'] += 1
        elif any(row['y']):
            ranking_opportunities['at_least_one_matching_candidate'] += 1
        else:
            ranking_opportunities['realized_path_missing_from_candidates'] += 1
            omitted_paths.update(name for name in {name for name, _ in row['actual']})
    previous = json.loads(broad.OUT.read_bytes())
    if baseline['rule_check']['learned'] != previous['results']['10:00']['current']['rule_y']['original']:
        raise ValueError('Daily reference does not match the earlier weekly-context comparison')
    results, predictions = {}, {}
    for tag in TIMINGS:
        results[tag], predictions[tag] = summarize(baseline, daily.walk_forward(changed[tag], manual), evidence[tag])
        for date, view in evidence[tag].items():
            reference = previous['timeline'][f'{date}/10:00/{tag}']
            if view['candidates'] != reference['active'] or view['covered'] != reference['covered']:
                raise ValueError(f'Archived weekly candidates differ on {date}')
    sources = (market, lock, *daily.MANUAL, broad.OUT, Path(__file__), Path(daily.__file__),
               Path('ict_ai/profile_alignment.py'), Path('ict_ai/profile_lifecycle.py'), Path('ict_ai/weekly_path.py'),
               Path('ict_ai/profile_delivery_evidence.py'), Path('ict_ai/timebase.py'), Path('scripts/audit_ict_target_ranking.py'))
    atomic_json(OUT, dict(scope='10:00 New York existing daily candidates, one signed weekly feature',
        methodology='Compute weekly context as of NY open and as of the 10:00 cutoff. Use +1 for aligned, -1 for opposed, '
        'zero otherwise. Only rescore dates with at least one such directional comparison. '
        'Fit only matured earlier weeks with reviewed manual dates excluded.',
        assumptions='Rule scores compare with same-lifecycle paths realized at daily close. Previously seen manual examples '
        'and archived prices are retrospective, and subgroup candidate counts are not independent.',
        checks=checks, results=results, predictions=predictions, evidence=evidence,
        ranking_opportunities=ranking_opportunities, omitted_paths=omitted_paths,
        input_sha256={file.name: daily.digest(file) for file in sources}, shadow_research_only=True, orders_sent=0))
    print(json.dumps(dict(checks=checks, results=results), ensure_ascii=False))


if __name__ == '__main__':
    main()
