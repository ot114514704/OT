"""Rebuild unsaved M5 liquidity boards from closed broker prices and replay Bid."""

from argparse import ArgumentParser
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from contextlib import closing
from datetime import datetime, timedelta
import json
from pathlib import Path
import sqlite3

from brooks_ai.types import Bar
from ict_ai.dol_history import forecast
from ict_ai.range_liquidity import _research_open
from scripts import audit_ict_micro_liquidity_recent_all_m5 as recent


board, fixed, live, M5 = recent.board, recent.fixed, recent.live, recent.M5
bridge = live.feed
OUT = recent.OUT.with_name('ict_micro_liquidity_missing_boards_20261125.json')
EVIDENCE = OUT.with_suffix('.json.gz')
CALENDAR = bridge.ROOT / 'research/jin10_calendar/bls_mt5_schedule.json'
H1 = timedelta(hours=1)
CONTROL_COUNT = 24
REPLAY_DELAYS = (30, 60)


def captured_inputs():
    report = fixed.read(recent.OUT)
    paths = (recent.INPUT, recent.BID, recent.stream.POLICY, Path(recent.__file__))
    if any(recent.digest(path) != report['inputs'][path.name] for path in paths):
        raise ValueError('Original report inputs do not match their saved digests')
    return report, board.joint.read_zip(recent.INPUT)


def coverage(study):
    start, stop = (datetime.fromisoformat(study[k]) for k in ('start', 'until'))
    actual = {row[0] for row in study['m5']}
    uri = live.quotes.DATABASE.resolve().as_uri() + '?mode=ro'
    with closing(sqlite3.connect(uri, uri=True, timeout=5)) as db:
        ledger = {stamp for stamp, in db.execute('SELECT DISTINCT cutoff FROM chart_batches '
                                                'WHERE cutoff>=? AND cutoff<?', (start.isoformat(), stop.isoformat()))}
    groups = defaultdict(list)
    for slot in range((stop - start) // M5 + 1):
        at = start + slot * M5
        stamp = at.isoformat()
        if at >= stop or not _research_open(at):
            continue
        if stamp in study['boards']:
            groups['timely_chart'].append(stamp)
        elif stamp in ledger:
            groups['chart_without_timely_receipt'].append(stamp)
        elif (at - M5).isoformat() not in actual or stamp not in actual:
            groups['missing_m5'].append(stamp)
        else:
            groups['reconstructable'].append(stamp)
    return dict(groups)


def capture(pid):
    _, study = captured_inputs()
    groups = coverage(study)
    starts = [datetime.fromisoformat(stamp) for stamp in groups['reconstructable']]
    until = datetime.fromisoformat(study['until'])
    with fixed.open_terminal(pid) as alive:
        with live.terminal() as (api, clock):
            h1 = {symbol: recent.rows(bridge.history(symbol, api.TIMEFRAME_H1, clock, until))
                  for symbol in ('XAUUSD', 'XAGUSD', 'USIDX')}
        ticks = fixed.capture_buckets(bridge.mt5, alive, fixed.frozen_feed(), starts, live.now())
        buckets = {at.isoformat(): bucket for at, bucket in ticks}
    schedule = fixed.read(CALENDAR)
    evidence = dict(captured_at=live.now().isoformat(), h1=h1, bid=buckets, coverage=groups,
                    calendar=schedule['events'], source_sha256=recent.digest(recent.INPUT),
                    calendar_sha256=recent.digest(CALENDAR))
    board.joint.write_zip(EVIDENCE, evidence)
    print(f'Captured {len(buckets)} of {len(starts)} missing windows', flush=True)


def unpack(rows):
    return [Bar(datetime.fromisoformat(stamp), *ohlc, 0) for stamp, *ohlc in rows]


def initialize():
    global m5, m1, m5_times, m1_times, h1, h1_times, minutes15, times15, news, shadow
    _, study = captured_inputs()
    evidence = board.joint.read_zip(EVIDENCE)
    m5, m1 = (unpack(study[name]) for name in ('m5', 'm1'))
    m5_times, m1_times = ([bar.time for bar in rows] for rows in (m5, m1))
    h1 = {symbol: unpack(rows) for symbol, rows in evidence['h1'].items()}
    h1_times = {symbol: [bar.time for bar in rows] for symbol, rows in h1.items()}
    minutes15 = bridge.aggregate_bars(m5, 5, 15, datetime.fromisoformat(study['until']))
    times15 = [bar.time for bar in minutes15]
    news = [(datetime.fromisoformat(day + 'T' + clock).replace(tzinfo=bridge.NY), value)
            for day, clock, value in evidence['calendar']]
    shadow = board.make_shadow_rank()


def mark(*_):
    pass


def reconstruct(stamp):
    at = datetime.fromisoformat(stamp)
    index = bisect_left(m5_times, at)
    closed = m5[:index]
    if not closed or closed[-1].time + M5 != at:
        raise ValueError(f'Missing preceding M5 close: {stamp}')
    minute = m1[:bisect_left(m1_times, at)]
    hourly = {symbol: rows[:bisect_right(h1_times[symbol], at - H1)] for symbol, rows in h1.items()}
    quarters = minutes15[:bisect_right(times15, at - 3 * M5)]
    primary = hourly['XAUUSD']
    peers = (bridge.add_smt(mark, primary, hourly['XAGUSD'], at, '白银', False)
             + bridge.add_smt(mark, primary, hourly['USIDX'], at, '美元指数', True))
    # Only Judas confirmations within the preceding hour enter DOL. Four days
    # of source bars also keep the prior Friday reference for Monday.
    judas = bridge.judas_history(closed[bisect_left(m5_times, at - timedelta(days=4)):], at, news)
    _, targets = forecast(closed, primary, quarters, at, peers, news, judas,
                          nearby_priority=True, priority_uplift=True)
    args = dict(minute_bars=minute, limit=10, priority_uplift=True)
    baseline = board.top10(board.structural.structural_ranking(closed, at, targets, **args))
    qualified = sorted(board.early_sides(closed))
    early = board.top10(shadow(closed, at, targets, **args)) if qualified else baseline
    return dict(cutoff=stamp, baseline=baseline, early=early, qualifying=qualified)


def compare_control(data, archived):
    observed = {scope: [live.identity(pool) for pool in sorted(archived['pools'], key=lambda row: row['rank'])
                        if pool['scope'] == scope.lower()] for scope in board.SCOPES}
    rebuilt = {scope: [live.identity(pool) for pool in data['baseline'][scope]] for scope in board.SCOPES}
    return dict(cutoff=data['cutoff'], identical={scope: observed[scope] == rebuilt[scope] for scope in board.SCOPES},
                shared={scope: len(set(observed[scope]) & set(rebuilt[scope])) for scope in board.SCOPES})


def audit(*, control_only=False):
    main_report, study = captured_inputs()
    evidence = board.joint.read_zip(EVIDENCE)
    if evidence['source_sha256'] != recent.digest(recent.INPUT):
        raise ValueError('Additional prices came from a different M5 source snapshot')
    controls = [row['cutoff'] for row in main_report['cases']]
    indices = [round(i * (len(controls) - 1) / (CONTROL_COUNT - 1)) for i in range(CONTROL_COUNT)]
    controls = [controls[i] for i in indices]
    prices = {row[0]: row[1:] for row in study['m5']}
    missing = evidence['coverage']['reconstructable']
    buckets = {stamp: bucket for stamp, bucket in evidence['bid'].items() if prices.get(stamp) == bucket['ohlc']}
    by_delay = defaultdict(lambda: defaultdict(Counter))
    cases = []
    with ProcessPoolExecutor(max_workers=6, initializer=initialize) as executor:
        control = [compare_control(data, study['boards'][data['cutoff']]['sample'])
                   for data in executor.map(reconstruct, controls, chunksize=2)]
        counts = {scope: sum(item['identical'][scope] for item in control) for scope in board.SCOPES}
        print(json.dumps(dict(control_count=len(control), exact_top10=counts), ensure_ascii=False), flush=True)
        if not control_only:
            for data in executor.map(reconstruct, sorted(set(missing) & buckets.keys()), chunksize=2):
                stamp = data['cutoff']
                at = datetime.fromisoformat(stamp)
                case = dict(cutoff=stamp, qualifying=data['qualifying'], outcomes={})
                for delay in REPLAY_DELAYS:
                    outcome = fixed.grade(data, at + timedelta(seconds=delay), [buckets[stamp]], 1)
                    result = recent.stream.paired(outcome)
                    case['outcomes'][str(delay)] = result
                    for scope, values in result.items():
                        by_delay[str(delay)][scope].update(values, windows=1, qualifying=int(bool(data['qualifying'])),
                                                          baseline_hit_windows=int(values['baseline_hits'] > 0),
                                                          early_hit_windows=int(values['early_hits'] > 0))
                cases.append(case)
    report = dict(state='control_only' if control_only else 'reconstructed_history',
                  captured_at=evidence['captured_at'], coverage={k: len(v) for k, v in evidence['coverage'].items()},
                  controls=control, exact_top10=counts, cases=cases, results=by_delay,
                  inputs={path.name: recent.digest(path) for path in (recent.INPUT, EVIDENCE, recent.stream.POLICY, Path(__file__))},
                  method=('Candidate lists use only closed quotes available by each M5 cutoff. Scoring applies '
                          'fixed hypothetical delays of 30 and 60 seconds. The original chart did not record '
                          'these lists. Keep these results separate from received or prospectively registered boards.'),
                  orders_sent=0)
    path = OUT.with_name(OUT.stem + '_control.json') if control_only else OUT
    live.atomic_json(path, report)
    print(json.dumps(dict(coverage=report['coverage'], rebuilt=len(cases), results=by_delay), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture-terminal-pid', type=int)
    parser.add_argument('--control-only', action='store_true')
    args = parser.parse_args()
    if args.capture_terminal_pid:
        capture(args.capture_terminal_pid)
    audit(control_only=args.control_only)
