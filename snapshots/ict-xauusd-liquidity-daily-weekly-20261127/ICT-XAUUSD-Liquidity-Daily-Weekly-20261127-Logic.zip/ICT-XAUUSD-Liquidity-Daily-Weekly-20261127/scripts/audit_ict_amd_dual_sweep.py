"""Resolve AMD illustration dual-boundary bars using independently checked TMGM Bid."""

from argparse import ArgumentParser
import csv
from datetime import datetime, timedelta, timezone
import json

from ict_ai.dol_tick_evidence import utc_ms
from ict_ai.timebase import NY
from scripts.serve_ict_live import atomic_json
from scripts.watch_ict_dol_settlement import M5, archive, capture_buckets, frozen_feed, open_terminal, utc_now


EXAMPLES = archive.RESEARCH/'amd_examples_20261123'
EVIDENCE = EXAMPLES/'dual-sweep-bid.json.gz'
RESULT = EXAMPLES/'dual-sweep-review.json'
M15 = 3*M5


def classify(opened, low, high, buckets, m15, m5):
    starts = [opened+i*M5 for i in range(-3,3)]
    checked = []
    quotes = []
    for at in starts:
        key = at.isoformat()
        saved = buckets.get(key)
        if not saved:
            return dict(status='quote_coverage_unverified', missing=key)
        offsets = saved['bid_offsets']
        if not offsets or any(not 0<=ms<300000 or bid<=0 for ms,bid in offsets):
            return dict(status='quote_coverage_unverified', missing=key)
        if any(a[0]>b[0] for a,b in zip(offsets,offsets[1:])):
            raise ValueError(f'Nonmonotone quote timestamps in {key}')
        prices = [bid for _,bid in offsets]
        ohlc = [prices[0],max(prices),min(prices),prices[-1]]
        if saved['open_utc']!=key or ohlc!=saved['ohlc'] or ohlc!=m5.get(key):
            return dict(status='m5_mismatch', missing=key)
        checked.append(ohlc)
        quotes.extend((utc_ms(at)+ms,bid) for ms,bid in offsets)
    target = checked[3:]
    derived = [target[0][0],max(b[1] for b in target),min(b[2] for b in target),target[-1][-1]]
    if derived!=m15 or not derived[2]<low<high<derived[1]:
        return dict(status='m15_mismatch', reconstructed_m15=derived)

    def region(price):
        return 'above' if price>high else 'below' if price<low else 'inside'

    def quote(stamp, bid):
        at = datetime.fromtimestamp(stamp//1000,timezone.utc)+timedelta(milliseconds=stamp%1000)
        return dict(utc=at.isoformat(timespec='milliseconds'),ny=at.astimezone(NY).isoformat(timespec='milliseconds'),bid=bid)

    boundary = utc_ms(opened)
    pre = [q for q in quotes if q[0]<boundary]
    in_bar = [q for q in quotes if q[0]>=boundary]
    previous, prior_region = pre[-1], region(pre[-1][1])
    first_pre_bar_on_prior_side = (next(quote(*q) for q in pre if region(q[1])==prior_region)
                                  if prior_region!='inside' else None)
    # The opening quote can continue an existing excursion. Record a move to
    # the other side only when the observed region actually changes.
    first_in_bar, first_fresh = {}, {}
    for stamp,bid in in_bar:
        area = region(bid)
        if area!='inside':
            first_in_bar.setdefault(area,quote(stamp,bid))
            if area!=prior_region:
                first_fresh.setdefault(area,quote(stamp,bid))
        prior_region = area
    first_times = {side:entry['utc'] for side,entry in first_in_bar.items()}
    fresh_times = {side:entry['utc'] for side,entry in first_fresh.items()}
    observed_order = sorted(first_times,key=first_times.get) if len(set(first_times.values()))==2 else []
    fresh_order = sorted(fresh_times,key=fresh_times.get) if len(set(fresh_times.values()))==2 else []
    return dict(status='reconciled', m5_checked=len(checked), quotes_checked=len(quotes),
                last_before={**quote(*previous),'region':region(previous[1])},
                opening_quote={**quote(*in_bar[0]),'region':region(in_bar[0][1])},
                first_pre_bar_on_prior_side=first_pre_bar_on_prior_side,
                first_in_bar=first_in_bar, fresh_entries=first_fresh, observed_side_order=observed_order,
                fresh_entry_order=fresh_order, reconstructed_m15=derived)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--terminal-pid',type=int,help='Collect from this already open terminal; omit for offline replay')
    args = parser.parse_args()
    structures, cases = EXAMPLES/'structure.json', EXAMPLES/'m15.csv'
    inputs = {p.name:archive.digest(p) for p in (structures,cases,archive.QUOTES)}
    review = json.loads(structures.read_bytes())
    probes = [(day,datetime.fromisoformat(stamp).astimezone(timezone.utc),row['lo'],row['hi'])
              for day,row in sorted(review.items()) for stamp in row['double']]
    if not probes:
        raise ValueError('No double-boundary cases in the example catalog')
    source = frozen_feed()
    if args.terminal_pid:
        if EVIDENCE.exists():
            raise FileExistsError(EVIDENCE)
        import MetaTrader5 as mt5
        starts = sorted({at+i*M5 for _,at,_,_ in probes for i in range(-3,3)})
        with open_terminal(args.terminal_pid) as alive:
            buckets = {at.isoformat():row for at,row in capture_buckets(mt5,alive,source,starts,utc_now())}
        temporary = EVIDENCE.with_suffix('.tmp')
        archive.write_zip(temporary,dict(inputs=inputs,server=source['server'],buckets=buckets))
        temporary.rename(EVIDENCE)
    saved = archive.read_zip(EVIDENCE)
    if saved['inputs']!=inputs or saved['server']!=source['server']:
        raise ValueError('Quote tape and frozen example inputs differ')
    m5 = {t:[o,h,l,c] for t,o,h,l,c in source['series']['XAUUSDM5']}
    with cases.open(newline='',encoding='ascii') as stream:
        m15 = {r['time']:[float(r[k]) for k in ('open','high','low','close')] for r in csv.DictReader(stream)}
    outcomes = [dict(date=day, opened_ny=at.astimezone(NY).isoformat(), low=low, high=high,
                     **classify(at,low,high,saved['buckets'],m15[at.isoformat()],m5)) for day,at,low,high in probes]
    atomic_json(RESULT,dict(server=saved['server'],symbol='XAUUSD',inputs=inputs,evidence_sha256=archive.digest(EVIDENCE),
                          scope='Observed Bid and archive OHLC only. No order-flow intent, broker fill, or AMD confirmation is inferred from quote order.',
                          outcomes=outcomes))
    for row in outcomes:
        print(row['opened_ny'],row['status'],row.get('observed_side_order'),row.get('fresh_entry_order'))


if __name__ == '__main__':
    main()
