"""Record the four-bar shadow board and grade strictly post-registration Bid ticks."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import json
from pathlib import Path
import sqlite3
from time import sleep

from brooks_ai.types import Bar
from ict_ai.dol_tick_evidence import BidEvidence, utc_ms
from scripts import audit_ict_micro_liquidity_board as board
from scripts import watch_ict_liquidity_filter_accuracy as forward
from scripts.shadow_ict_dol import write_once
from scripts.watch_ict_dol_settlement import archive as quote_archive, capture_buckets, frozen_feed, open_terminal


OUT = board.joint.RESEARCH / 'ict_micro_liquidity_forward_20261125'
POLICY = OUT / 'policy.json'
M5 = forward.M5
HORIZONS = {'next_m5': 1, 'quarter_hour': 3}
SYNC = timedelta(seconds=45)
FINAL_RETRY = timedelta(minutes=10)
PINS = (Path(__file__), Path(board.__file__), Path(board.early.__file__), Path(forward.__file__),
        Path('ict_ai/structural_liquidity.py'), Path('ict_ai/range_liquidity.py'), Path('ict_ai/target_priority.py'),
        Path('ict_ai/dol_tick_evidence.py'), Path('scripts/watch_ict_dol_settlement.py'), forward.quotes.CLOCK,
        quote_archive.QUOTES, board.OUT)


def read(path):
    return json.loads(path.read_bytes())


def fingerprint():
    return {path.name: board.joint.digest(path) for path in PINS}


def freeze_or_load():
    pinned = fingerprint()
    if not POLICY.exists():
        backtest = read(board.OUT)
        if backtest['code_sha256'] != pinned[Path(board.__file__).name]:
            raise ValueError('Shadow ranking differs from its frozen historical comparison')
        write_once(POLICY, dict(frozen_at=forward.now().isoformat(), pins=pinned, eligible_checkpoints=sorted(forward.quotes.CHECKPOINTS),
                               rule='Same frozen boards, plus a native M5 candidate after one right bar within one ATR',
                               settlement='First strict Bid crossing must be after the durable registration. Quote tick buckets reconcile with MT5 M5.',
                               orders_sent=0))
    policy = read(POLICY)
    if policy['pins'] != pinned:
        raise ValueError('Current code or prices differ from the prospective policy')
    return policy


def build_lists(at, sample, shadow_rank):
    with forward.terminal() as (api, clock):
        bars = forward.feed.history('XAUUSD', api.TIMEFRAME_M5, clock, at)
        if bars[-1].time + M5 != at or bars[-1].close != sample['price']:
            raise forward.ReferencePriceMismatch('Terminal M5 close does not match chart receipt')
        potential = board.early_sides(bars)
        if potential:
            minutes = forward.feed.history('XAUUSD', api.TIMEFRAME_M1, clock, at)
    chart = {scope: sorted((p for p in sample['pools'] if p['scope'] == scope.lower()), key=lambda p: p['rank'])
             for scope in board.SCOPES}
    if not potential:
        return dict(baseline=chart, early=chart, potential_sides=[], cutoff_close=sample['price'])
    arguments = dict(limit=10, priority_uplift=True, minute_bars=minutes)
    rebuilt = board.top10(board.structural.structural_ranking(bars, at, sample['targets'], **arguments))
    for scope in board.SCOPES:
        if [forward.identity(p) for p in rebuilt[scope]] != [forward.identity(p) for p in chart[scope]]:
            raise forward.ReferencePriceMismatch(f'{scope} terminal ranking does not match acknowledged chart')
    shadow = board.top10(shadow_rank(bars, at, sample['targets'], **arguments))
    return dict(baseline=chart, early=shadow, potential_sides=sorted(potential), cutoff_close=sample['price'])


def register(policy, shadow_rank, observed):
    first = max(datetime.fromisoformat(policy['frozen_at']), observed - 3 * M5)
    for at, receipt, key, sample in forward.read_chart(first, observed):
        stem = at.strftime('%Y%m%dT%H%M%SZ')
        path = OUT / 'boards' / f'{stem}.json'
        stamp = OUT / 'receipts' / path.name
        rejection = OUT / 'rejections' / path.name
        if stamp.exists() or rejection.exists():
            continue
        try:
            if not path.exists():
                lists = build_lists(at, sample, shadow_rank)
                write_once(path, dict(**lists, cutoff=at.isoformat(), chart_receipt=receipt.isoformat(),
                                      original_batch=key, policy_sha256=board.joint.digest(POLICY), orders_sent=0))
            # The timestamp is taken only after the board file was flushed and synced.
            ready = forward.now()
            write_once(stamp, dict(available_at=ready.isoformat(), board_sha256=board.joint.digest(path)))
        except forward.ReferencePriceMismatch as error:
            write_once(rejection, dict(at=at.isoformat(), chart_receipt=receipt.isoformat(), reason=str(error)))


def reconcile(buckets):
    result = []
    for bucket in buckets:
        start = datetime.fromisoformat(bucket['open_utc'])
        if bucket['ohlc'] is None or not bucket['bid_offsets']:
            return None
        reference = Bar(start, *bucket['ohlc'], 0)
        base = utc_ms(start)
        ticks = [(base + offset, bid) for offset, bid in bucket['bid_offsets']]
        if base not in BidEvidence([reference], ticks).reconciled:
            raise ValueError(f'Registered Bid evidence no longer reconciles at {start}')
        result.append((reference, ticks))
    return result


def outcome(target, bars_and_ticks, ready):
    side = target['side']
    edge = forward.quotes.far(target)
    for bar, quotes in bars_and_ticks:
        crossing = next((stamp for stamp, bid in quotes if side * (bid - edge) > 0), None)
        if crossing is None:
            continue
        if crossing <= utc_ms(ready):
            return 'before_board', crossing
        return ('sweep' if bar.low <= edge <= bar.high else 'gap_over'), crossing
    return 'not_swept', None


def grade(raw, ready, buckets, count):
    cutoff = datetime.fromisoformat(raw['cutoff'])
    if ready >= cutoff + count * M5:
        return dict(state='too_late', outcomes={})
    if [bucket['open_utc'] for bucket in buckets] != [(cutoff + i * M5).isoformat() for i in range(count)]:
        return dict(state='incomplete', outcomes={})
    tape = reconcile(buckets)
    if not tape:
        return dict(state='incomplete', outcomes={})
    if tape[-1][1][-1][0] <= utc_ms(ready):
        return dict(state='no_post_registration_quote', outcomes={})
    return dict(state='scored', outcomes={scheme: {scope: [dict(side=p['side'], lo=p['lo'], hi=p['hi'],
                status=label, bid_time_ms=stamp) for p in pools[scope]
                for label, stamp in (outcome(p, tape, ready),)] for scope in board.SCOPES}
                for scheme, pools in (('baseline', raw['baseline']), ('early', raw['early']))})


def settle(alive, source, observed):
    for receipt_path in sorted((OUT / 'receipts').glob('*.json')):
        path = OUT / 'boards' / receipt_path.name
        raw, receipt = read(path), read(receipt_path)
        cutoff, chart_receipt, ready = (datetime.fromisoformat(value) for value in (
            raw['cutoff'], raw['chart_receipt'], receipt['available_at']))
        if not cutoff <= chart_receipt <= ready or receipt['board_sha256'] != board.joint.digest(path):
            raise ValueError(f'Invalid live timing or changed board: {path.name}')
        if raw['policy_sha256'] != board.joint.digest(POLICY):
            raise ValueError(f'Unrecognized board policy: {path.name}')
        for name, count in HORIZONS.items():
            target = OUT / 'settlements' / f'{path.stem}_{name}.json'
            end = cutoff + count * M5
            if target.exists() or observed < end + SYNC:
                continue
            buckets = []
            if ready < end:
                starts = [cutoff + i * M5 for i in range(count)]
                buckets = [bucket for _, bucket in capture_buckets(forward.feed.mt5, alive, source, starts, observed)]
            report = grade(raw, ready, buckets, count)
            if report['state'] == 'incomplete' and observed < end + FINAL_RETRY:
                continue
            forward.atomic_json(target, dict(**report, receipts_sha256=board.joint.digest(receipt_path),
                                             market_buckets=buckets, horizon=name, orders_sent=0))


def status(policy, *, verify=False):
    totals = defaultdict(Counter)
    for file in (OUT / 'settlements').glob('*.json'):
        report = read(file)
        receipt = OUT / 'receipts' / f'{file.name.split("_")[0]}.json'
        if report['receipts_sha256'] != board.joint.digest(receipt):
            raise ValueError(f'Settlement does not match its registration: {file.name}')
        name = report['horizon']
        if verify:
            raw_path = OUT / 'boards' / receipt.name
            raw, timestamp = read(raw_path), read(receipt)
            cutoff, accepted, ready = (datetime.fromisoformat(value) for value in (
                raw['cutoff'], raw['chart_receipt'], timestamp['available_at']))
            if (timestamp['board_sha256'] != board.joint.digest(raw_path)
                    or raw['policy_sha256'] != board.joint.digest(POLICY)
                    or not datetime.fromisoformat(policy['frozen_at']) < cutoff <= accepted <= ready):
                raise ValueError(f'Could not verify frozen timestamps for {file.name}')
            if any(report[key] != value for key, value in grade(raw, ready, report['market_buckets'], HORIZONS[name]).items()):
                raise ValueError(f'Settlement no longer reproduces: {file.name}')
        totals[name][report['state']] += 1
        for scheme, pools in report['outcomes'].items():
            for scope, levels in pools.items():
                counter = totals[f'{name}/{scope}/{scheme}']
                counter.update(item['status'] for item in levels)
                counter['eligible'] += sum(item['status'] != 'before_board' for item in levels)
    return dict(frozen_at=policy['frozen_at'], observed_at=forward.now().isoformat(), counts=totals,
                registrations=len(list((OUT / 'receipts').glob('*.json'))),
                rejections=len(list((OUT / 'rejections').glob('*.json'))), orders_sent=0)


def probe(alive, source, shadow_rank):
    observed = forward.now()
    recent = list(forward.read_chart(observed - timedelta(days=3), observed - 4 * M5))
    verified = None
    for at, received, key, sample in reversed(recent):
        try:
            data = build_lists(at, sample, shadow_rank)
        except forward.ReferencePriceMismatch:
            continue
        if verified is None or data['potential_sides']:
            verified = at, received, key, data
        if data['potential_sides']:
            break
    if verified is None:
        raise RuntimeError('No matching chart board available to rehearse')
    at, received, key, data = verified
    buckets = [record for _, record in capture_buckets(forward.feed.mt5, alive, source, [at], observed)]
    report = grade(dict(**data, cutoff=at.isoformat()), received, buckets, 1)
    forward.atomic_json(OUT / 'rehearsal.json', dict(**report, cutoff=at.isoformat(), chart_batch=key,
                        chart_receipt=received.isoformat(), market_buckets=buckets, potential_sides=data['potential_sides'],
                        historical_only=True, orders_sent=0))
    print(at.isoformat(), report['state'], data['potential_sides'], flush=True)


def main():
    import msvcrt

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('probe', 'once', 'watch', 'verify'))
    parser.add_argument('--terminal-pid', type=int)
    args = parser.parse_args()
    if args.mode == 'verify':
        if not POLICY.exists():
            raise FileNotFoundError(POLICY)
        print(json.dumps(status(freeze_or_load(), verify=True), ensure_ascii=False))
        return
    if args.terminal_pid is None:
        parser.error('--terminal-pid is required for a reading session')
    for directory in ('boards', 'receipts', 'settlements', 'rejections'):
        (OUT / directory).mkdir(parents=True, exist_ok=True)
    source = frozen_feed()
    shadow_rank = board.make_shadow_rank()
    with open_terminal(args.terminal_pid) as alive:
        if args.mode == 'probe':
            probe(alive, source, shadow_rank)
            return
        with (OUT / 'watch.lock').open('a+b') as lock:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            policy = freeze_or_load()
            while alive():
                try:
                    observed = forward.now()
                    register(policy, shadow_rank, observed)
                    settle(alive, source, observed)
                    report = status(policy)
                except (OSError, RuntimeError, sqlite3.OperationalError) as error:
                    report = dict(status='awaiting_data', reason=str(error), observed_at=forward.now().isoformat(), orders_sent=0)
                forward.atomic_json(OUT / 'status.json', report)
                if args.mode == 'once':
                    print(json.dumps(report, ensure_ascii=False))
                    break
                sleep(5)


if __name__ == '__main__':
    main()
