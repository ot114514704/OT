"""Build the portable version of the native XAUUSD chart."""
from hashlib import sha256
import argparse
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile
import json
import re
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output/mt5"
RUNTIME = OUTPUT / "ICT_MT5_H1_20261121/runtime"
INDICATOR = ROOT / "mt5/ICT_H1_Profiles.mq5"

INSTALLER = '''from pathlib import Path
import shutil
import MetaTrader5 as mt5

if not mt5.initialize():
    raise SystemExit("Open your MT5 terminal and retry.")
try:
    destination = Path(mt5.terminal_info().data_path) / "MQL5/Indicators/ICT_Trader"
finally:
    mt5.shutdown()
destination.mkdir(parents=True, exist_ok=True)
for source in (Path(__file__).resolve().parents[2] / "Indicators").iterdir():
    shutil.copy2(source, destination / source.name)
print("Installed ICT_H1_Profiles in", destination)
'''

GUIDE = """MT5 黄金多周期图

在 64 位 Windows 上完整解压，打开自己的 TMGM MT5 并登录。确认有 XAUUSD、XAGUSD 和 USIDX 行情。
运行 INSTALL_MT5.cmd，核对显示的终端目录。在 MT5 导航器刷新技术指标，打开 XAUUSD 图，加载 ICT_Trader 下的 ICT_H1_Profiles。可直接切换标准周期 M1 至 MN1。
运行 START_MT5_PANEL.cmd 并保持窗口打开。程序按已收 M5 读取本机终端行情，报价更新时重排候选距离。发布读取从 2026 年 6 月初开始的历史和此前预热数据。
内部和外部流动性各显示前十，最低周期 M5。内部优先纽约当日及前一交易日的区间摆动，外部按日、周、月 ERL 解释。M6、M12 使用实际分钟报价聚合。
如包中有 CommonFiles/ICT_Trader，可在保留原件后把 H1Profiles.tsv 放入 MT5 公共文件目录下的 ICT_Trader 子目录。
日线按纽约零点分割。周五概况显示 TGIF 回撤状态，悬停可看价位和判断依据。周内越界的 ERL 从原点延伸至首次越界的 K 线，标注买方或卖方。悬停可按收线时间查看收回和后续结构证据。
周五顶部单列日型与 TGIF。SMC 按当前图表周期显示已收盘确认的市场结构，可分别开关突破、等高等低、CISD 和各层摆动。IPDA 显示 M15 阶段与一小时候选评分，H1 提供背景。开启 FVG 后，将鼠标移入缺口框可查看形成和回触证据。
银弹按纽约时间标注，色块可透过日K实体辨认。SMT 比对当前周期的黄金、白银和美元指数；图中标注看涨或看跌，悬停查看比对详情。长周期需要足够已收线的同周期摆动。
周折线相邻同类极点的比较优先，较亮的短弧贴近转折；日极点在当天收完前可以移动。小级别摆动采用左右各四根收线确认。
亚盘东京 09–18、欧盘伦敦 08–17、美盘纽约 08–17 均为当地时间。三盘色框的上下沿取本盘已收 M5 的高低。悬停查看盘内路径、银弹和跨盘 PO3 候选。周一红线显示纽约周内 OHLC，周五零点显示随周高低更新的 TGIF 回撤尺。周高 0、周低 1，下跌周的回升 20% 和 30% 对应固定尺 0.8 和 0.7。点击日、周标题展开逐组新闻的同期位移和扫回；同期发布共用同一黄金路径。派发框显示 A 收线时可知的前日或前周方向目标候选。FVG 开关仅显示当前周期回触有跟随或银弹内越过远端收回的缺口。主图时间轴上方按纽约时间标记美国重大事件，并补充 BLS 排期。默认只写事件名。点击展开公布、预期、前值和黄金 5、15、30 分钟净位移及上下最大偏移（美元/盎司），再点收起。密集时合并显示，用详情下方的翻页文字查看其余记录。公布前后各 30 分钟使用 M5 检查越过前段高低后收回；事件与扫回只作时间关联。
大/小 AMD 开关控制当前周期的结构候选。冻结 A 后观察单侧越界再收回。派发确认前允许一次同侧再越过旧极值并当根收回，仍用原边界核对对侧位移。连续两根收破且至少一根顺向实体达到 A 段实体中位数才确认扩张。直接扩张单列为 A→D。M15 的「AMD图例」开关按历史截图的美东时窗复画参考框。
“三盘”按钮独立控制三盘的色框、简称和悬停详情。盘名以 7 磅缩写标在各盘色框外，TK 为亚盘、EU 为欧盘、NY 为美盘。日、周标题悬停显示新闻组数、强位移和扫回统计；点击可展开事件。悬停派发框边或标题可看 DOL、识别依据和相关事件。日K覆盖用 O、H、L、C 标记开、高、低、收，价位可悬停查看。
程序只读行情。其他电脑的实际报价覆盖、终端登录和品种代码取决于当地 MT5 环境。
"""


def build(indicator_dir=INDICATOR.parent, name=None, chart_feed=None, verified_snapshot=False):
    indicator=indicator_dir/INDICATOR.name
    version = re.search(r'#property version "([\d.]+)"', indicator.read_text(encoding="utf-8-sig"))[1]
    name = name or "ICT_MT5_H1_Profiles_" + version.replace(".", "_")
    archive = OUTPUT / (name + ".zip")
    pending = [indicator]
    entries = {"Indicators/ICT_H1_Profiles.ex5": indicator.with_suffix(".ex5")}
    while pending:
        source = pending.pop()
        key = "Indicators/" + source.relative_to(indicator_dir).as_posix()
        if key in entries:
            continue
        entries[key] = source
        includes = re.findall(r'^\s*#include\s+"([^"]+)"', source.read_text(encoding="utf-8-sig"), re.MULTILINE)
        pending.extend(source.parent / include for include in includes)
    if chart_feed:
        entries["CommonFiles/ICT_Trader/H1Profiles.tsv"]=chart_feed
        for relative in ("output/research/ranked_dol/history.json",
                         "output/research/june_november_joint_20261122/profile_history.json"):
            archived=ROOT/relative
            if archived.is_file():
                entries["project/"+relative]=archived
    for p in RUNTIME.rglob("*"):
        if p.is_file() and "__pycache__" not in p.parts:
            entries["runtime/" + p.relative_to(RUNTIME).as_posix()] = p
    for directory in ("ict_ai", "brooks_ai"):
        for p in (ROOT / directory).rglob("*.py"):
            entries["project/" + p.relative_to(ROOT).as_posix()] = p
    entries["project/ict_ai/dol_contact_calibration.json"] = ROOT / "ict_ai/dol_contact_calibration.json"
    for module in ("export_mt5_profiles", "export_mt5_native", "prepare_ict_week", "serve_ict_live", "live_ict_realized",
                   "audit_ict_bridge_latency", "export_mt5_profiles_fast_receipts"):
        entries[f"project/scripts/{module}.py"] = ROOT / f"scripts/{module}.py"
    for relative in ("research/live_clock_20261116.json", "research/jin10_calendar/bls_mt5_schedule.json", "research/ict_weekly_profiles/rules.json",
                     "research/ict_daily_profiles/rules.json", "research/ict_weekly_profiles/smc_free_guide/integration.json"):
        entries["project/" + relative] = ROOT / relative
    generated = {"project/scripts/install_h1.py": INSTALLER.encode(), "使用说明.txt": GUIDE.encode("utf-8-sig")}
    if verified_snapshot:
        if chart_feed is None:
            raise ValueError("A verified snapshot requires the installed chart feed")
        for filename in ("ICT_Event_Strip.mq5","ICT_Event_Strip.ex5"):
            entries["Indicators/"+filename] = indicator_dir/filename
        receipts = chart_feed.parent/"DOLReceipts"
        for p in receipts.glob("????.??.??.tsv"):
            entries["CommonFiles/ICT_Trader/DOLReceipts/"+p.name] = p
        for relative in (
            "scripts/check_ipda_fvg_contacts.py", "scripts/check_ipda_phase_boundaries.py",
            "scripts/validate_ipda_draft_week.py", "scripts/audit_ipda_frame_agreement.py",
            "output/research/ipda_frame_agreement.json", "output/research/ipda_four_cycle_validation_20261122/reference_labels.py",
            "output/research/dol_expansion_20261122/capture.json",
            "output/research/dol_expansion_20261122/XAUUSDH1.npz", "output/research/dol_expansion_20261122/XAUUSDM5.npz",
            "data/real/TMGM_ICT_D1_basis_20261014_132250/XAUUSD_M5.csv", "data/real/TMGM_XAU_extrema_close_20261121/XAUUSD_M5.csv",
        ):
            entries["project/"+relative] = ROOT/relative
        for p in sorted((ROOT/"output/research/ipda_hourly_holdout").glob("*_逐点核验.json")):
            entries["project/"+p.relative_to(ROOT).as_posix()] = p
        guide = ("本次快照保留黄金图的 IPDA 四周期阶段（H4、H1、M15、M5）、各自收线时间和形态支持分。"
                 "M15 下一小时若跨常规维护或周末收市，显示“跨休市，暂停评分”。"
                 "回调说明按当根收线触及的剩余 FVG 区域更新。\n"
                 "恢复历史标注和回执时，将 CommonFiles 下的 ICT_Trader 文件夹复制到 "
                 "%APPDATA%\\MetaQuotes\\Terminal\\Common\\Files 下，合并前保存原有文件。\n\n")
        generated["使用说明.txt"] = (guide+GUIDE).encode("utf-8-sig")
    for cmd, module in (("INSTALL_MT5", "install_h1"), ("START_MT5_PANEL", "export_mt5_profiles_fast_receipts")):
        launch = f'@echo off\r\ncd /d "%~dp0"\r\n"runtime\\python.exe" -B -u -m scripts.{module}\r\npause\r\n'
        generated[cmd + ".cmd"] = launch.encode("ascii")
    with TemporaryDirectory(dir=OUTPUT) as temp:
        candidate = Path(temp) / archive.name
        if verified_snapshot:
            db = ROOT/"output/research/ranked_dol/live.sqlite3"
            snapshot = Path(temp)/"live.sqlite3"
            with sqlite3.connect(db.as_uri()+"?mode=ro",uri=True) as src, sqlite3.connect(snapshot) as dst:
                src.backup(dst)
                if dst.execute("PRAGMA integrity_check").fetchone()!=("ok",):
                    raise ValueError("Incomplete DOL history database snapshot")
            src.close()
            dst.close()
            entries["project/output/research/ranked_dol/live.sqlite3"] = snapshot
        hashes = {}
        with ZipFile(candidate, "w", ZIP_DEFLATED) as z:
            for key, value in {**entries, **generated}.items():
                content = value.read_bytes() if isinstance(value, Path) else value
                z.writestr(name + "/" + key, content)
                hashes[key] = sha256(content).hexdigest()
            z.writestr(name + "/RELEASE.json", json.dumps({"version": version, "sha256": hashes}, indent=2))
        candidate.replace(archive)
    print(archive)


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--indicator-dir',type=Path,default=INDICATOR.parent)
    parser.add_argument('--name')
    parser.add_argument('--chart-feed',type=Path)
    parser.add_argument('--verified-snapshot',action='store_true')
    args=parser.parse_args()
    build(args.indicator_dir,args.name,args.chart_feed,args.verified_snapshot)
