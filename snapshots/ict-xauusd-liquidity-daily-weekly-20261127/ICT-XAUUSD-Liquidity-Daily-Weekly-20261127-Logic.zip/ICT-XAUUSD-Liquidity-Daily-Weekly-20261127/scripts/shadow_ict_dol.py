"""Freeze and record a prospective DOL comparison from chart-acknowledged XAUUSD batches."""
import argparse
from collections import Counter
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ict_ai.dol_history import _deadline, batch_id
from ict_ai.dol_outlook import M5
from scripts.audit_ict_target_ranking import features, fit_prior_weeks
from scripts import replay_pool_and_dol as archive


FOLDER = archive.RESEARCH / 'dol_shadow_20261123'
LOCK = FOLDER / 'model.json'
DATABASE = archive.RESEARCH / 'ranked_dol/live.sqlite3'
OUTCOMES = archive.OUT / 'outcomes.json.gz'
CODE = (Path(__file__), ROOT/'scripts/audit_ict_target_ranking.py', ROOT/'ict_ai/dol_history.py')


def utc_now():
    return datetime.now(timezone.utc)


def write_once(path, record):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(record, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def freeze():
    if LOCK.exists():
        raise FileExistsError(f'Model already frozen: {LOCK}')
    history_lock = json.loads(archive.LOCK.read_bytes())
    historic_audit = archive.RESEARCH / 'ict_walkforward_ranking.json'
    historic_hashes = json.loads(historic_audit.read_bytes())['inputs']
    for path in (archive.QUOTES, archive.FROZEN, OUTCOMES):
        digest = archive.digest(path)
        if historic_hashes[path.name] != digest or (path.name in history_lock and history_lock[path.name] != digest):
            raise ValueError(f'Historical fixture changed: {path.name}')
    earliest_freeze = utc_now()
    groups = []
    for sample, result in zip(archive.read_zip(archive.FROZEN), archive.read_zip(OUTCOMES), strict=True):
        if sample['at'] != result['at']:
            raise ValueError('Historical labels and features differ in time')
        short = result['short']
        end = datetime.fromisoformat(short['end'])
        if short['status'] != 'complete' or not sample['dol'] or end >= earliest_freeze:
            continue
        labels = [event['touch'] is not None for event in short['dol']]
        matrix = [features(row, sample['price'], 'dol') for row in sample['dol']]
        if len(labels) != len(matrix):
            raise ValueError('Historical label count differs from feature count')
        groups.append(dict(x=matrix, y=labels, end=end))
    if len({y for g in groups for y in g['y']}) != 2:
        raise ValueError('Both labels are required for a research model')
    mean, scale, coef = fit_prior_weeks(groups)
    FOLDER.mkdir(parents=True, exist_ok=True)
    model = dict(frozen_at=utc_now().isoformat(), threshold='none', kind='historical L2 DOL contact',
                 train_cutoffs=len(groups), train_targets=sum(len(g['y']) for g in groups),
                 train_labels_mature_through=max(g['end'] for g in groups).isoformat(),
                 inputs={p.relative_to(ROOT).as_posix():archive.digest(p) for p in
                         (archive.QUOTES, archive.FROZEN, OUTCOMES, archive.LOCK, historic_audit)},
                 code={p.relative_to(ROOT).as_posix():archive.digest(p) for p in CODE},
                 mean=mean.tolist(), scale=scale.tolist(), coef=coef.tolist(),
                 comparison=['chart_rank1','nearest_near_edge','learned_contact'],
                 eligibility='Post-freeze cutoff with MT5 receipt and durable ranking within two M5s. '
                             'Settle only after ranking was recorded, up to four hours and within the New York date. '
                             'No-hit and exact ordering need adequate coverage. No trade execution.')
    write_once(LOCK, model)
    print('Frozen:', model['frozen_at'], 'historical cutoffs:', len(groups), 'model SHA-256:', archive.digest(LOCK))


def choose(model, sample):
    rows = sample['targets']
    price = sample['price']
    distance = [abs((r['lo'] if r['side'] > 0 else r['hi'])-price) for r in rows]
    matrix = np.array([features(r, price, 'dol') for r in rows])
    logits = model['coef'][0] + ((matrix-model['mean'])/model['scale'])@model['coef'][1:]
    if not np.all(np.isfinite(logits)):
        raise ValueError('Non-finite model score')
    original = min(range(len(rows)), key=lambda i: rows[i]['rank'])
    nearest = min(range(len(rows)), key=lambda i: (distance[i], rows[i]['rank']))
    learned = max(range(len(rows)), key=lambda i: (logits[i], -distance[i], -rows[i]['rank']))
    return dict(chart_rank1=original, nearest_near_edge=nearest, learned_contact=learned)


def record():
    raw_model = LOCK.read_bytes()
    model = json.loads(raw_model)
    for path, expected in model['code'].items():
        if archive.digest(ROOT/path) != expected:
            raise ValueError(f'Frozen scoring code differs: {path}')
    earliest = datetime.fromisoformat(model['frozen_at'])
    # Keep the journal separate from both the chart database and the model lock.
    out = FOLDER / 'predictions'
    out.mkdir(exist_ok=True)
    counts = Counter()
    with sqlite3.connect(DATABASE.resolve().as_uri()+'?mode=ro', uri=True) as db:
        rows = db.execute('SELECT id,cutoff,received,payload FROM chart_batches '
                          'WHERE cutoff>? ORDER BY cutoff,received,id', (earliest.isoformat(),)).fetchall()
    for key, cutoff, receipt, raw in rows:
        at = datetime.fromisoformat(cutoff)
        if at <= earliest:
            continue
        if receipt is None:
            counts['awaiting_chart_receipt'] += 1
            continue
        journal = out / at.astimezone(timezone.utc).strftime('%Y%m%dT%H%M%SZ.json')
        if journal.exists():
            counts['already_recorded'] += 1
            continue
        received = datetime.fromisoformat(receipt)
        now = utc_now()
        if not at <= received <= now < min(at+2*M5, _deadline(at)):
            counts['outside_recording_window'] += 1
            continue
        sample = json.loads(raw)
        if sample['at'] != cutoff or key != batch_id(at, sample['price'], [sample['targets'], sample['pools']]):
            raise ValueError(f'Chart batch does not match digest at {cutoff}')
        if not sample['targets']:
            counts['no_candidates'] += 1
            continue
        selection = choose(model, sample)
        registered = utc_now()
        if registered >= min(at+2*M5, _deadline(at)):
            counts['timed_out_while_scoring'] += 1
            continue
        try:
            write_once(journal, dict(chart_batch=key, cutoff=cutoff, chart_received=receipt,
                                    recorded_at=registered.isoformat(), end=_deadline(at).isoformat(),
                                    model_sha256=hashlib.sha256(raw_model).hexdigest(),
                                    price=sample['price'], targets=sample['targets'], selection=selection))
        except FileExistsError:
            counts['already_recorded'] += 1
            continue
        counts['recorded'] += 1
        print(cutoff, {name:sample['targets'][i]['rank'] for name,i in selection.items()})
    print(dict(counts))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('step', choices=('freeze','record'))
    args = parser.parse_args()
    (freeze if args.step == 'freeze' else record)()


if __name__ == '__main__':
    main()
