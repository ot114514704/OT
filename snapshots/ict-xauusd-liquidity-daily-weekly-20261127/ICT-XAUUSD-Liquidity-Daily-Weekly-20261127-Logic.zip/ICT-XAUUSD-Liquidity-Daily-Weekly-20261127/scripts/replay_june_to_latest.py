"""Combine the extended chart history into one monthly DOL and liquidity replay."""
from collections import Counter, defaultdict
from datetime import datetime
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import replay_ten_joint_rounds as rounds

joint,priority,NY=rounds.joint,rounds.priority,rounds.NY
OUT=joint.RESEARCH/'june_november_joint_20261122'
CHECKPOINTS={'00:05','02:00','08:00','10:00','14:00'}


def month_index(at):
    return datetime.fromisoformat(at).astimezone(NY).month-6


def compare_quotes():
    documented,_=priority.read_market()
    recent,_=joint.load_bars()
    def ohlc(b):
        return (b.open,b.high,b.low,b.close)
    quotes={b.time:ohlc(b) for b in documented}
    common=[b for b in recent if b.time in quotes]
    assert common and all(quotes[b.time]==ohlc(b) for b in common)
    return len(common)


def report(rows, outcomes, overlap, schedules):
    keys=('dol_short','pools_short','pools_week')
    modes=(('统一每日五个时点',True),('全部存档时点',False))
    text=['# TMGM XAUUSD 六月至十一月联合回测','',
          f'预测时点覆盖 {rows[0]["at"][:10]} 至 {rows[-1]["at"][:10]}。两份 TMGM 存档有 {overlap:,} 根相同时间的 M5，逐根 OHLC 一致。纽约夏令时和冬令时分别换算。每个时点先冻结两组候选，后续 K 线用于验收。','',
          '每格依次列出现有评分第一、最近目标及近端共振的命中数和分母。DOL 命中用期限内触价，流动性用严格越过区间外沿。短期最长四小时并受纽约日界约束，周内截至周五 16:55。','']
    all_stats={}
    for title,fixed in modes:
        groups=[defaultdict(Counter) for _ in range(6)]
        for s,obs in zip(rows,outcomes,strict=True):
            if fixed and datetime.fromisoformat(s['at']).astimezone(NY).strftime('%H:%M') not in CHECKPOINTS:
                continue
            summary=groups[month_index(s['at'])]
            for k,scope,family,metric in [(keys[0],'short','dol','touch'),(keys[1],'short','pools','sweep'),(keys[2],'week','pools','sweep')]:
                ev=obs[scope]
                summary[k][ev['status']]+=1
                if ev['status']=='complete' and s['picks'][family]:
                    rounds.record(ev[family],s['picks'][family],metric,summary[k])
        totals=defaultdict(Counter)
        text+=['## '+title,'',
               '|月份|DOL 四小时|流动性四小时|流动性至周五|',
               '|---|---|---|---|']
        for month,g in enumerate(groups,6):
            text.append(f'|{month} 月|'+'|'.join(rounds.format_counts(g[k]) for k in keys)+'|')
            for k in keys:totals[k].update(g[k])
        text+=['|合计|'+'|'.join(rounds.format_counts(totals[k]) for k in keys)+'|','']
        all_stats[title]=dict(months=groups,totals=totals)
    fixed='、'.join(sorted(CHECKPOINTS))
    text += [f'统一时点为美东 {fixed}。9 月 21 日起的存档每天另含六个检查点，纳入全部时点表。不同窗口可能观察到同一段行情。','',
             '日线和周线候选以 ERL 为主。周内缺失数据、尚未到期或同根 K 线的顺序未定分别保留，原始结果可逐时点复核。']
    (OUT/'六月至十一月联合回测.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
    (OUT/'summary.json').write_text(json.dumps(dict(by_schedule=all_stats,checkpoints_by_month=schedules,shared_quote_bars=overlap),
        ensure_ascii=False,indent=2),encoding='utf-8')
    for title,data in all_stats.items():
        print(title,{k:dict(data['totals'][k]) for k in keys})


def main():
    OUT.mkdir(exist_ok=True,parents=True)
    overlap=compare_quotes()
    rows=[s for s in rounds.inputs() if 0<=month_index(s['at'])<6]
    schedules=Counter(datetime.fromisoformat(s['at']).astimezone(NY).strftime('%Y-%m') for s in rows)
    for s in rows:
        s['picks']={k:rounds.pick(s,k) for k in ('dol','pools')}
    frozen=OUT/'frozen.json.gz'
    joint.write_zip(frozen,rows)
    (OUT/'lock.json').write_text(json.dumps(dict(frozen=joint.digest(frozen),snapshots=len(rows),
        standard_clocks=sorted(CHECKPOINTS),script=joint.digest(Path(__file__))),indent=2),encoding='utf-8')
    rounds.evaluate(rows,month_index,6,OUT)
    observed=joint.read_zip(OUT/'outcomes.json.gz')
    assert all(a['at']==b['at'] for a,b in zip(rows,observed,strict=True))
    reviews=joint.hover_history(zip(rows,observed,strict=True))
    stage=OUT/'profile_history.tmp'
    stage.write_text(json.dumps(reviews,ensure_ascii=False),encoding='utf-8')
    stage.replace(OUT/'profile_history.json')
    report(rows,observed,overlap,schedules)
    from scripts.plot_joint_round_examples import main as plot
    plot(OUT,month_index,6,'六月至十一月联合回测 · 每月三张图例')


if __name__=='__main__':
    main()
