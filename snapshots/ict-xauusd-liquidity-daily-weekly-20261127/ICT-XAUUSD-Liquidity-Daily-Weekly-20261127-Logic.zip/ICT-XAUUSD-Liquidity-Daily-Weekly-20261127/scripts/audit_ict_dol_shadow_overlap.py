"""Check whether adjacent forward windows share an observed first Bid quote."""

from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json

from ict_ai.timebase import NY
from scripts.serve_ict_live import atomic_json
from scripts.settle_ict_dol_shadow import FOLDER, LOCK, archive, read_registrations


def audit(report, registrations):
    by_cutoff = {row['cutoff']: row for row in registrations}
    quote_groups = defaultdict(list)
    selected_disagreements = Counter()
    independent_days = set()
    for row in report['cutoffs']:
        record = by_cutoff[row['cutoff']]
        if row['registration_sha256'] != record['evidence']:
            raise ValueError(f"Registration hash changed at {row['cutoff']}")
        if row['status'] != 'unique' or not row['comparable']:
            continue
        rank, = row['first_ranks']
        contact = row['contacts'][str(rank)]
        if not contact['eligible']:
            raise ValueError(f"Unique first quote is ineligible at {row['cutoff']}")
        learned = row['selected_ranks']['learned_contact']
        original = row['selected_ranks']['chart_rank1']
        versus = 'learned_only' if rank==learned and rank!=original else (
                 'chart_only' if rank==original and rank!=learned else 'tie')
        if learned != original:
            selected_disagreements[versus] += 1
        when = datetime.fromtimestamp(contact['utc_ms']/1000, timezone.utc)
        independent_days.add(when.astimezone(NY).date().isoformat())
        quote_groups[(contact['utc_ms'],contact['bid'])].append(dict(cutoff=row['cutoff'], first_rank=rank, comparison=versus))

    groups = []
    for (stamp, bid), windows in sorted(quote_groups.items()):
        groups.append(dict(utc_ms=stamp, bid=bid, windows=windows))
    return dict(eligible_unique_windows=sum(len(group['windows']) for group in groups),
                distinct_first_bid_quotes=len(groups), new_york_days=sorted(independent_days),
                learned_vs_chart_when_ranks_differ=dict(selected_disagreements), first_quote_groups=groups,
                scope='Descriptive overlap only. A distinct quote is not evidence of an independent trial.')


def main():
    path = FOLDER/'auto_bid_settlement.json'
    raw = path.read_bytes()
    snapshot = json.loads(raw)
    if snapshot['model_sha256'] != archive.digest(LOCK):
        raise ValueError('Settlement report is for a different frozen model')
    result = audit(snapshot, read_registrations())
    atomic_json(FOLDER/'forward_overlap.json', dict(source_sha256=hashlib.sha256(raw).hexdigest(),
                as_of=snapshot['as_of'], **result))
    print('Unique windows:',result['eligible_unique_windows'],'distinct first Bid quotes:',
          result['distinct_first_bid_quotes'], 'NY days:',len(result['new_york_days']))


if __name__ == '__main__':
    main()
