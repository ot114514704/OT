"""Replay the frozen repository and local rankings over common 15- and 60-minute windows."""

from argparse import ArgumentParser
from collections import Counter
from datetime import datetime
import json
from pathlib import Path

from ict_ai.range_liquidity import _research_open
from scripts import audit_ict_liquidity_week_to_date as week
from scripts import check_pool_priority as archive


fixed, joint, live, M5 = week.fixed, week.joint, week.live, week.M5
DIR = joint.RESEARCH / 'ict_repo_vs_local_forecast_20261125'
INPUT = DIR / 'report.json'
BID = DIR / 'shared_bid_windows.json.gz'
OUT = DIR / 'shared_horizons.json'
HORIZONS = {15: 3, 60: 12}


def load_windows():
    comparison = fixed.read(INPUT)
    for path in (week.INPUT, week.REPORT):
        if comparison['inputs'][path.name] != joint.digest(path):
            raise ValueError(f'Frozen comparison input changed: {path.name}')
    current = joint.read_zip(week.INPUT)
    week_end = datetime.fromisoformat(comparison['current_week']['end'])
    if week_end != datetime.fromisoformat(current['end']):
        raise ValueError('The ranking and M5 archives have different week cutoffs')

    market_manifest = archive.ARCH / 'manifest.json'
    market = archive.ARCH / 'XAUUSDM5.npz'
    manifest = fixed.read(market_manifest)
    if manifest[market.name] != joint.digest(market):
        raise ValueError('Historical M5 archive changed')
    old, _ = archive.read_market()
    earlier_ohlc = {bar.time: [bar.open, bar.high, bar.low, bar.close] for bar in old}
    week_ohlc = {datetime.fromisoformat(row[0]): row[1:5] for row in current['m5']}

    cohorts = {'oct_nov_H1': (comparison['native_common_h1_first_m5']['cases'], earlier_ohlc, None)}
    for period, group in comparison['current_week']['comparisons'].items():
        cohorts[f'current_week_{period}'] = (group['cases'], week_ohlc, week_end)

    windows = {}
    expected = set()
    for name, (cases, reference, end) in cohorts.items():
        for minutes, count in HORIZONS.items():
            accepted, excluded = [], {}
            for case in cases:
                at = datetime.fromisoformat(case['cutoff'])
                starts = [at + index * M5 for index in range(count)]
                if end is not None and at + count * M5 > end:
                    excluded[case['cutoff']] = 'after_frozen_week_end'
                elif not all(_research_open(start) for start in starts):
                    excluded[case['cutoff']] = 'market_break'
                elif any(start not in reference for start in starts):
                    excluded[case['cutoff']] = 'missing_frozen_m5'
                else:
                    accepted.append((case, starts))
                    expected.update(starts)
            windows[name, minutes] = (accepted, excluded, reference)
    pins = {path.name: joint.digest(path) for path in (INPUT, week.INPUT, week.REPORT, market, market_manifest,
                                                      Path(__file__), Path(fixed.__file__))}
    return windows, sorted(expected), pins


def capture(pid, expected, pins):
    captured_at = live.now()
    source = fixed.frozen_feed()
    with fixed.open_terminal(pid) as alive:
        rows = fixed.capture_buckets(live.feed.mt5, alive, source, expected, captured_at)
        buckets = {at.isoformat(): bucket for at, bucket in rows}
    joint.write_zip(BID, dict(captured_at=captured_at.isoformat(), server=source['server'],
                             expected_buckets=len(expected), pins=pins, buckets=buckets))
    print(f'Captured {len(buckets)} of {len(expected)} reconciled TMGM M5 buckets', flush=True)


def grade(case, tape):
    ready = datetime.fromisoformat(case['checked_from'])
    if tape[-1][1][-1][0] <= fixed.utc_ms(ready):
        return None
    books = {}
    for scheme, prior_rows in case['outcomes'].items():
        rows = []
        for prior in prior_rows:
            label, stamp = fixed.outcome(prior, tape[:1], ready)
            if (label, stamp) != (prior['status'], prior['bid_time_ms']):
                raise ValueError(f'First M5 settlement changed at {case["cutoff"]} for {scheme}')
            label, stamp = fixed.outcome(prior, tape, ready)
            rows.append(dict(side=prior['side'], lo=prior['lo'], hi=prior['hi'], status=label, bid_time_ms=stamp))
        books[scheme] = rows
    return books


def stats(cases):
    counts = Counter(windows=len(cases), union_with_sweep=0, repo_only_top2=0, local_only_top2=0)
    for scheme in ('repo', 'local'):
        counts.update({f'{scheme}_{key}': 0 for key in ('top1', 'top2', 'first_or_tied', 'duplicate_price')})
    for case in cases:
        books = case['outcomes']
        first = min((row['bid_time_ms'] for rows in books.values() for row in rows if row['status'] == 'sweep'),
                    default=None)
        counts['union_with_sweep'] += first is not None
        any_swept = {}
        for scheme, rows in books.items():
            swept = [row for row in rows if row['status'] == 'sweep']
            any_swept[scheme] = bool(swept)
            counts[f'{scheme}_top1'] += rows[0]['status'] == 'sweep'
            counts[f'{scheme}_top2'] += bool(swept)
            counts[f'{scheme}_first_or_tied'] += any(row['bid_time_ms'] == first for row in swept)
            counts[f'{scheme}_duplicate_price'] += len({(row['side'], row['lo'], row['hi']) for row in rows}) < len(rows)
        counts['repo_only_top2'] += any_swept['repo'] and not any_swept['local']
        counts['local_only_top2'] += any_swept['local'] and not any_swept['repo']
    return counts


def evaluate(windows, pins):
    evidence = joint.read_zip(BID)
    if evidence['pins'] != pins:
        raise ValueError('Bid archive references different ranking data, prices or code')
    buckets = evidence['buckets']
    results = {}
    for (name, minutes), (accepted, excluded, reference) in windows.items():
        cases = []
        for case, starts in accepted:
            tape = [buckets.get(at.isoformat()) for at in starts]
            if any(bucket is None or bucket['ohlc'] != reference[at] for at, bucket in zip(starts, tape, strict=True)):
                excluded[case['cutoff']] = 'unreconciled_bid_or_frozen_m5'
                continue
            reconciled = fixed.reconcile(tape)
            books = grade(case, reconciled) if reconciled else None
            if not books:
                excluded[case['cutoff']] = 'no_post_registration_quote'
                continue
            cases.append(dict(cutoff=case['cutoff'], checked_from=case['checked_from'],
                              local_source=case['local_source'], outcomes=books))
        results.setdefault(name, {})[minutes] = dict(counts=stats(cases), excluded=excluded, cases=cases)
    method = ('Frozen native repository scores against frozen local M5 ERL scores, measured with the same '
              'post-availability TMGM Bid timestamps for each pair. A strict crossing with OHLC overlapping '
              'the level counts as a sweep. Compare fixed lists, without reranking inside the window.')
    live.atomic_json(OUT, dict(inputs=pins, bid_sha256=joint.digest(BID), captured_at=evidence['captured_at'],
                               method=method, orders_sent=0, results=results))
    print(json.dumps({name: {minutes: dict(counts=cell['counts'], excluded=Counter(cell['excluded'].values()))
                            for minutes, cell in horizons.items()} for name, horizons in results.items()}), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture-terminal-pid', type=int)
    args = parser.parse_args()
    windows, expected, pins = load_windows()
    if args.capture_terminal_pid:
        capture(args.capture_terminal_pid, expected, pins)
    evaluate(windows, pins)
