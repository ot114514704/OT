"""Freeze and independently settle weekly price-path candidates from TMGM M5."""

from argparse import ArgumentParser
from datetime import date, datetime, timedelta
from hashlib import sha256
from pathlib import Path
from time import sleep
import json

from brooks_ai.types import Bar
from ict_ai.profile_journal import RUNTIME_CODE_SHA256
from ict_ai.profile_lifecycle import _day_bounds
from ict_ai.timebase import manifest_epoch_to_utc
from scripts.audit_ict_weekly_candidates import CHECKPOINTS, FRIDAY, active, identity, view
from scripts.prepare_ict_week import aggregate_bars
from scripts.serve_ict_live import atomic_json, checked_account
from scripts.settle_ict_daily_learning import COVERAGE_GRACE, SYNC_GRACE, decode_bars, encode_bars
from scripts.watch_ict_daily_learning import M5, NY, ROOT, TERMINAL, UTC, WINDOW, open_terminal, raw_epoch, utc_now
from scripts.watch_ict_profile_feed import digest_rows


ARCHIVE = ROOT/'output/research/weekly_profile_feed_20261123'
CLOCK = ROOT/'research/live_clock_20261116.json'
SERVER = 'TradeMaxGlobal-Live'
SYMBOL = 'XAUUSD'


def schedule(monday):
    days = [monday+timedelta(days=i) for i in range(5)]
    start, _ = _day_bounds(days[0])
    friday, end = _day_bounds(days[-1])
    times = {name: _day_bounds(days[index])[1] for name, index in CHECKPOINTS.items()}
    times.update({name: friday+offset for name, offset in FRIDAY.items()})
    return days, start, end, times


def read_json(path):
    return json.loads(path.read_bytes())


def now_week(now):
    day = now.astimezone(NY).date()
    return day-timedelta(days=day.weekday())


def read_protocol(clock_path):
    dependencies = ('scripts/watch_ict_weekly_candidates.py', 'scripts/audit_ict_weekly_candidates.py',
                    'ict_ai/weekly_close_candidates.py', 'scripts/watch_ict_daily_learning.py',
                    'scripts/settle_ict_daily_learning.py', 'scripts/watch_ict_profile_feed.py')
    checksums = dict(RUNTIME_CODE_SHA256)
    for name in dependencies:
        checksums[name] = sha256((ROOT/name).read_bytes()).hexdigest()
    return dict(code=checksums, clock_sha256=sha256(clock_path.read_bytes()).hexdigest())


def evaluated(bars, days, at):
    m15 = aggregate_bars(bars, 5, 15, at)
    data = view(bars, m15, days, at)
    return {k: data[k] for k in ('covered', 'original', 'friday_watch', 'realized_status', 'realized')}


def check_bars(bars, start, at):
    if (any(b.time.utcoffset() != timedelta(0) or b.time.minute%5 or b.time.second or b.time.microsecond
            or not start<=b.time<=at-M5 for b in bars)
            or any(a.time>=b.time for a,b in zip(bars,bars[1:]))):
        raise ValueError('Expected unique, closed, time-aligned UTC M5 bars')


def forecast(days, name, bars, native, at, started, captured, quote, protocol):
    start = _day_bounds(days[0])[0]
    check_bars(bars, start, at)
    rows = encode_bars(bars)
    if not bars or bars[-1].time+M5!=at or native!=rows[-1]:
        raise ValueError('The M5 range and recent series disagree at the decision cutoff')
    if (not started<=at<=captured<at+WINDOW or not at<=quote<=captured+timedelta(seconds=3)
            or captured-quote>timedelta(seconds=90)):
        raise ValueError('The snapshot falls outside the forward capture or quote freshness window')
    return dict(kind='forward_checkpoint', week=days[0].isoformat(), name=name, cutoff=at.isoformat(),
                observer_started=started.isoformat(), captured_at=captured.isoformat(), quote_at=quote.isoformat(),
                symbol=SYMBOL, server=SERVER, protocol=protocol, native_m5=native, m5=rows,
                m5_sha256=digest_rows(rows), state=evaluated(bars,days,at), orders_sent=0)


def verified_forecast(path, days, name, at, protocol):
    saved = read_json(path)
    started, captured, quote = (datetime.fromisoformat(saved[key]) for key in ('observer_started','captured_at','quote_at'))
    expected = forecast(days,name,decode_bars(saved['m5']),saved['native_m5'],at,started,captured,quote,protocol)
    if saved!=expected:
        raise ValueError(f'Unreproducible forecast {path}')
    return saved


def settlement(days, end, bars, captured, frozen, protocol):
    start = _day_bounds(days[0])[0]
    if captured<end+SYNC_GRACE:
        raise ValueError('Week has not completed the settlement grace period')
    check_bars(bars,start,end)
    rows = encode_bars(bars)
    truth = evaluated(bars,days,end)
    outcomes = {identity(c) for c in truth['realized']}
    by_checkpoint = {}
    for name, record in frozen.items():
        at = datetime.fromisoformat(record['cutoff'])
        prefix_pairs = [row for bar,row in zip(bars,rows,strict=True) if bar.time+M5<=at]
        state = record['state']
        status = ('history_changed' if prefix_pairs!=record['m5'] else
                  'insufficient_coverage' if not truth['covered'] or not state['covered'] else 'scored')
        watch = state['friday_watch']
        counts = None
        if status=='scored':
            original = active(state['original'])
            with_watch = original | (active([watch]) if watch else set())
            counts = {tag: dict(candidates=len(picks), matched=len(picks & outcomes), missed=len(outcomes-picks))
                      for tag,picks in (('original',original),('with_friday_watch',with_watch))}
            counts['watch_exact_variant'] = (any(identity(c)==identity(watch) and c.get('variant')==watch['variant']
                                                  for c in truth['realized']) if watch and watch['status']=='active' else None)
        by_checkpoint[name] = dict(status=status, counts=counts, frozen_m5_sha256=record['m5_sha256'])
    return dict(kind='closed_week_settlement', week=days[0].isoformat(), cutoff=end.isoformat(),
                captured_at=captured.isoformat(), symbol=SYMBOL, server=SERVER, protocol=protocol,
                m5=rows, m5_sha256=digest_rows(rows), coverage_complete=truth['covered'],
                realized_status=truth['realized_status'], realized=truth['realized'], checkpoints=by_checkpoint, orders_sent=0)


def capture(api, alive, clock, start, at, *, witness=False):
    if not alive() or not api.initialize(str(TERMINAL),timeout=3000):
        raise RuntimeError('Bound TMGM terminal unavailable')
    try:
        account = checked_account(api)
        if account.server!=SERVER:
            raise RuntimeError('Unexpected TMGM quote server')
        lo, hi = [datetime.fromtimestamp(raw_epoch(t,clock),UTC) for t in (start,at)]
        history = api.copy_rates_range(SYMBOL,api.TIMEFRAME_M5,lo,hi)
        recent = api.copy_rates_from_pos(SYMBOL,api.TIMEFRAME_M5,0,4) if witness else None
        quote = api.symbol_info_tick(SYMBOL) if witness else None
        checked_account(api,(account.login,account.server))
        if history is None or not alive():
            raise RuntimeError('Weekly M5 history unavailable')

        def convert(row):
            ts = manifest_epoch_to_utc(datetime.fromtimestamp(int(row['time']),UTC),clock)
            return Bar(ts,*(float(row[k]) for k in ('open','high','low','close')),0)

        bars = [b for b in map(convert,history) if start<=b.time and b.time+M5<=at]
        if not witness:
            return bars
        if recent is None or quote is None or quote.bid<=0:
            raise RuntimeError('Missing recent M5 or current quote')
        native = next((b for b in map(convert,recent) if b.time+M5==at),None)
        if native is None:
            raise RuntimeError('Recent M5 sequence lacks the decision candle')
        tick = manifest_epoch_to_utc(datetime.fromtimestamp(int(quote.time),UTC),clock)
        return bars,encode_bars([native])[0],tick
    finally:
        api.shutdown()


def archive_state(root, protocol, now, fetch=None, settled_weeks=None):
    states = {}
    for folder in sorted(root.glob('????-??-??')):
        if settled_weeks is not None and folder.name in settled_weeks:
            states[folder.name] = settled_weeks[folder.name]
            continue
        monday = date.fromisoformat(folder.name)
        if monday.weekday()!=0:
            raise ValueError(f'Weekly folder is not a NY Monday: {folder}')
        days,start,end,times = schedule(monday)
        frozen = {name: verified_forecast(path,days,name,at,protocol) for name,at in times.items()
                  if (path:=folder/f'{name}.json').is_file()}
        path = folder/'settlement.json'
        status = 'waiting_for_week_end'
        if path.is_file():
            saved = read_json(path)
            if not frozen or saved!=settlement(days,end,decode_bars(saved['m5']),datetime.fromisoformat(saved['captured_at']),frozen,protocol):
                raise ValueError(f'Unreproducible settlement {path}')
            status = 'settled'
        elif fetch and frozen and now>=end+SYNC_GRACE:
            try:
                bars = fetch(start,end)
                captured = utc_now()
                saved = settlement(days,end,bars,captured,frozen,protocol)
                sync_issue = not saved['coverage_complete'] or any(row['status']=='history_changed' for row in saved['checkpoints'].values())
                if sync_issue and captured<end+COVERAGE_GRACE:
                    status = 'waiting_for_history_sync'
                else:
                    atomic_json(path,saved)
                    status = 'settled'
            except (OSError,RuntimeError,ValueError) as exc:
                status = str(exc)
        elif now>=end+SYNC_GRACE:
            status = 'awaiting_settlement'
        states[folder.name] = dict(checkpoints=list(frozen), status=status,
                                   scores=saved['checkpoints'] if status=='settled' else {})
        if settled_weeks is not None and status=='settled':
            settled_weeks[folder.name] = states[folder.name]
    return states


def summary(weeks):
    results = {}
    for name in (*CHECKPOINTS,*FRIDAY):
        records = [week['scores'][name] for week in weeks.values() if name in week['scores']]
        scored = [record['counts'] for record in records if record['status']=='scored']
        statuses = {s: sum(record['status']==s for record in records)
                    for s in ('scored','history_changed','insufficient_coverage')}
        rules = {}
        for rule in ('original','with_friday_watch'):
            rules[rule] = dict(weeks_with_candidate=sum(c[rule]['candidates']>0 for c in scored),
                               weeks_with_match=sum(c[rule]['matched']>0 for c in scored),
                               **{metric:sum(c[rule][metric] for c in scored)
                                  for metric in ('candidates','matched','missed')})
        results[name] = dict(registered_weeks=sum(name in week['checkpoints'] for week in weeks.values()),
                             statuses=statuses,rules=rules,
                             added_variant_observed=sum(c['watch_exact_variant'] is not None for c in scored),
                             added_variant_matches=sum(c['watch_exact_variant'] is True for c in scored))
    return results


def main():
    parser = ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--verify',action='store_true')
    modes.add_argument('--terminal-pid',type=int)
    parser.add_argument('--probe',action='store_true',help='Read current M5 once without archiving a forecast')
    parser.add_argument('--archive',type=Path,default=ARCHIVE)
    parser.add_argument('--clock-policy',type=Path,default=CLOCK)
    args = parser.parse_args()
    now = utc_now()
    protocol = read_protocol(args.clock_policy)
    if args.verify:
        weeks = archive_state(args.archive,protocol,now)
        print(json.dumps(dict(weeks=weeks,summary=summary(weeks),orders_sent=0),ensure_ascii=False))
        return

    import msvcrt
    import MetaTrader5 as api

    clock = read_json(args.clock_policy)
    with open_terminal(args.terminal_pid) as alive:
        if args.probe:
            at = now.replace(minute=now.minute//5*5,second=0,microsecond=0)
            days,start,_,_ = schedule(now_week(at))
            bars,native,tick = capture(api,alive,clock,start,at,witness=True)
            result = forecast(days,'probe',bars,native,at,at,utc_now(),tick,protocol)
            print(json.dumps(dict(cutoff=result['cutoff'], bars=len(bars), coverage=result['state']['covered'],
                                  matched_recent_m5=True, server=SERVER,orders_sent=0)))
            return

        args.archive.mkdir(parents=True,exist_ok=True)
        with (args.archive/'watch.lock').open('a+b') as lock:
            msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
            previous = None
            settled_weeks = {}
            last_review = now-M5
            while alive():
                current = utc_now()
                monday = now_week(current)
                days,start,_,times = schedule(monday)
                stages = {}
                for name,at in times.items():
                    path = args.archive/monday.isoformat()/f'{name}.json'
                    if path.is_file():
                        status = 'recorded'
                    elif at<now:
                        status = 'cutoff_precedes_observer'
                    elif current<at:
                        status = 'waiting_for_cutoff'
                    elif current>=at+WINDOW:
                        status = 'recording_window_elapsed'
                    else:
                        try:
                            bars,native,tick = capture(api,alive,clock,start,at,witness=True)
                            record = forecast(days,name,bars,native,at,now,utc_now(),tick,protocol)
                            atomic_json(path,record)
                            status = 'recorded'
                        except (OSError,RuntimeError,ValueError) as exc:
                            status = str(exc)
                    stages[name] = dict(cutoff_ny=at.astimezone(NY).isoformat(),status=status)
                if stages!=previous or current-last_review>=M5:
                    weeks = archive_state(args.archive,protocol,current,
                                          lambda first,end: capture(api,alive,clock,first,end),settled_weeks)
                    atomic_json(args.archive/'status.json',dict(observer_started=now.isoformat(),checked_at=current.isoformat(),
                                terminal_pid=args.terminal_pid,checkpoints=stages,weeks=weeks,summary=summary(weeks),orders_sent=0))
                    last_review = current
                previous = stages
                sleep(5)


if __name__=='__main__':
    main()
