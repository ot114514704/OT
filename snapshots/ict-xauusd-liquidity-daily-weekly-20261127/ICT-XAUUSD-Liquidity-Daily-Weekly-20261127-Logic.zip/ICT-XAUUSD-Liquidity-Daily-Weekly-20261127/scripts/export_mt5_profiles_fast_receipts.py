"""Run the MT5 profile bridge with immediate, validated chart receipt ingestion."""

from argparse import ArgumentParser
from contextlib import closing
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sqlite3
import sys
from time import sleep


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from ict_ai.dol_history import batch_id, chart_receipts
from scripts import export_mt5_profiles as bridge
from scripts.audit_ict_bridge_latency import COMMON, record_publication
from scripts.serve_ict_live import atomic_json


DATABASE = ROOT / 'output/research/ranked_dol/live.sqlite3'
OUT = ROOT / 'output/research/ict_chart_fast_receipts_20261125'
M5 = timedelta(minutes=5)
ACK_WAIT = timedelta(seconds=8)
POLL = .25


def promote_receipt(database, batch, cutoff, receipt, observed):
    """Acknowledge an already staged and unchanged payload in one transaction."""
    if not cutoff <= receipt <= observed:
        raise ValueError('Receipt is outside the observable interval')
    uri = database.resolve().as_uri() + '?mode=rw'
    with closing(sqlite3.connect(uri, uri=True, timeout=1.0)) as connection, connection:
        row = connection.execute('SELECT cutoff,received,payload FROM chart_batches WHERE id=?', (batch,)).fetchone()
        if row is None:
            return False
        stored_cutoff, stored_receipt, payload_json = row
        payload = json.loads(payload_json)
        if (stored_cutoff != cutoff.isoformat() or payload['at'] != stored_cutoff
                or batch_id(cutoff, payload['price'], [payload['targets'], payload['pools']]) != batch):
            raise ValueError('Native receipt does not match the staged payload')
        stamp = receipt.isoformat()
        if stored_receipt is not None:
            if stored_receipt != stamp:
                raise ValueError('Previously validated receipt disagrees with the native receipt')
            return False
        updated = connection.execute('UPDATE chart_batches SET received=? WHERE id=? AND cutoff=? AND received IS NULL',
                                     (stamp, batch, stored_cutoff)).rowcount
    return updated == 1


def synchronize(batch, cutoff, ready):
    # Perform the copy on the exporter thread after publish, so it cannot affect
    # a forecast that is still being computed with an earlier as-of time.
    next_m5 = cutoff + ((ready - cutoff) // M5 + 1) * M5
    stop = min(ready + ACK_WAIT, next_m5)
    while (seen := datetime.now(timezone.utc)) < stop:
        receipt = chart_receipts(COMMON / 'DOLReceipts', seen).get(batch)
        if receipt is not None:
            if promote_receipt(DATABASE, batch, cutoff, receipt, seen):
                committed = datetime.now(timezone.utc)
                entry = dict(batch=batch, cutoff=cutoff.isoformat(), file_ready=ready.isoformat(),
                             chart_receipt=receipt.isoformat(), observed=seen.isoformat(), committed=committed.isoformat(),
                             chart_upper_to_database_seconds=(committed - receipt).total_seconds(),
                             cutoff_to_database_seconds=(committed - cutoff).total_seconds(), orders_sent=0)
                atomic_json(OUT / 'batches' / f'{batch}.json', entry)
                atomic_json(OUT / 'latest.json', entry)
                print(f'{committed.isoformat()} chart receipt synchronized {batch}', flush=True)
            return
        sleep(POLL)


def on_publication(batch, cutoff, started, loaded, built, ready, revision, rows):
    record_publication(batch, cutoff, started, loaded, built, ready, revision, rows)
    try:
        synchronize(batch, cutoff, ready)
    except (OSError, ValueError, KeyError, sqlite3.Error) as error:
        # The ordinary exporter imports the same native receipt on its next run.
        print(f'Chart receipt synchronization deferred: {error}', file=sys.stderr, flush=True)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--once', action='store_true')
    args = parser.parse_args()
    # The publication seam keeps the exporter module already pinned by the live
    # regression observers intact. Both entrypoints use the same chart output.
    bridge.record_publication = on_publication
    bridge.run(args.once)


if __name__ == '__main__':
    main()
