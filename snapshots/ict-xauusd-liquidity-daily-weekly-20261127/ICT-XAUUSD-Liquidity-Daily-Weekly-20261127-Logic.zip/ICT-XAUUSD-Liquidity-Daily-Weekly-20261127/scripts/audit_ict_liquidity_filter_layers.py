"""Evaluate nested liquidity screens on production ranks and strict sweep labels."""

from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
import json

import numpy as np

from scripts import replay_ict_liquidity_context as context
from scripts import replay_ict_liquidity_rank as ranking
from scripts.check_pool_priority import interval, read_market
from scripts.serve_ict_live import atomic_json


study = ranking.study
ROOT = study.ROOT
OUT = study.RESEARCH / 'ict_liquidity_filter_layers_20261124.json'
SEPT = datetime(2026, 9, 1, tzinfo=study.NY)
OCT = datetime(2026, 10, 1, tzinfo=study.NY)
LAST_WEEK = '2026-11-16'
LAYERS = ('current_top10', 'distance', 'structure', 'price_and_clock')
DISTANCES = (.25, .5, .75, 1., 1.5, 2., 3., 4., 6.)
STRUCTURE = ((1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 3))
PROBABILITY = (.20, .25, .30, .35, .40, .45, .50, .55, .60, .65, .70)


def windows(groups):
    return [(g, tuple(range(min(10, len(g['targets']))))) for g in groups if g['status'] == 'complete']


def counts(window_rows):
    values = Counter()
    unique_events = set()
    for g, keep in window_rows:
        values.update(windows=1, windows_with_offers=bool(keep), offers=len(keep))
        values['hit_windows'] += any(g['y'][i] for i in keep)
        for i in keep:
            target = g['targets'][i]
            rank = i + 1
            values[f'rank_{rank}_offers'] += 1
            values[f'rank_{rank}_hits'] += g['y'][i]
            # A repeated prediction of an unchanged boundary on the same sweep can recur across windows.
            if g['y'][i]:
                sweep = g['events'][i]['sweep']
                outer = target['hi'] if target['side'] == 1 else target['lo']
                unique_events.add((sweep, target['side'], outer))
                values['hits'] += 1
        for rank, i in enumerate(keep, 1):
            values[f'display_{rank}_offers'] += 1
            values[f'display_{rank}_hits'] += g['y'][i]
    values['distinct_swept_outer_edges'] = len(unique_events)
    return values


def restrict(rows, predicate, cutoff):
    return [(g, tuple(i for i in offered if predicate(g, i, cutoff))) for g, offered in rows]


def described(t, base):
    return dict(t, precision=t['hits']/t['offers'] if t['offers'] else None,
                offer_coverage=t['offers']/base['offers'] if base['offers'] else None,
                retained_hits=t['hits']/base['hits'] if base['hits'] else None,
                window_coverage=t['windows_with_offers']/base['windows'] if base['windows'] else None)


def select(rows, variations, predicate, retention):
    baseline = counts(rows)
    options = []
    for value in variations:
        stat = counts(restrict(rows, predicate, value))
        if stat['offers'] < max(60, baseline['offers'] * retention):
            continue
        options.append((value, stat))
    if not options:
        return None, baseline
    cutoff, measured = max(options, key=lambda x: (x[1]['hits']/x[1]['offers'], x[1]['offers']))
    if measured['hits']*baseline['offers'] <= baseline['hits']*measured['offers']:
        return None, baseline
    return cutoff, measured


def features(g, i):
    target, row = g['targets'][i], g['features'][i]
    parts = target['components']
    return [np.log1p(g['distance'][i]), np.log1p((target['hi']-target['lo'])/target['hourly_range']),
            target['side'], parts['structure'], parts['anchors'], parts['frames'], parts['path'],
            *row['trend'], *row['clock'], *row['pattern']]


def predictions(train, rows):
    design = [dict(x=[features(g, i) for i in keep], y=[g['y'][i] for i in keep]) for g, keep in train if keep]
    mean, scale, coef = ranking.fit_prior_weeks(design)
    for g, keep in rows:
        if keep:
            logits = coef[0] + ((np.array([features(g, i) for i in keep])-mean)/scale) @ coef[1:]
            g['layer_probability'] = {i: float(p) for i,p in zip(keep, 1/(1+np.exp(-np.clip(logits,-40,40))), strict=True)}
    return dict(mean=mean.tolist(),scale=scale.tolist(),coefficients=coef.tolist())


def near_control(base, layer):
    return [(g, tuple(sorted(available, key=lambda i: (g['distance'][i], i))[:len(kept)]))
            for (g, available), (_, kept) in zip(base, layer, strict=True)]


def nearest_contrast(base, layer):
    control = near_control(base, layer)
    blocks = defaultdict(lambda: [0, 0])
    for (g, picked), (_, comparator) in zip(layer, control, strict=True):
        if picked:
            row = blocks[str(g['week'])]
            row[0] += sum(g['y'][i] for i in picked) - sum(g['y'][i] for i in comparator)
            row[1] += len(picked)
    same_coverage = counts(control)
    delta = sum(value[0] for value in blocks.values())
    return dict(nearest_offers=same_coverage['offers'], nearest_hits=same_coverage['hits'], incremental_hits=delta,
                delta_rate=delta/same_coverage['offers'] if same_coverage['offers'] else None,
                week_block_ci95=interval(blocks) if len(blocks) > 1 else None)


def run(group_rows):
    all_rows = windows(group_rows)
    train = [(g, r) for g,r in all_rows if g['end'] <= SEPT and g['at'] < SEPT]
    calibration = [(g,r) for g,r in all_rows if SEPT <= g['at'] < OCT and g['end'] <= OCT]
    holdout = [(g,r) for g,r in all_rows if g['at'] >= OCT]
    if not all((train,calibration,holdout)):
        raise ValueError('Missing frozen training, calibration, or evaluation windows')
    price_model = predictions(train, calibration + holdout)
    filters = (
        (DISTANCES, lambda g,i,t: g['distance'][i] <= t, .35),
        (STRUCTURE, lambda g,i,t: g['targets'][i]['origins'] >= t[0] and 4-g['targets'][i]['components']['path'] <= t[1], .55),
        (PROBABILITY, lambda g,i,t: g['layer_probability'][i] >= t, .65),
    )
    calibration_base, holdout_base = counts(calibration), counts(holdout)
    latest = lambda x: [row for row in x if str(row[0]['week']) == LAST_WEEK]
    last_base = counts(latest(holdout))
    stages = {LAYERS[0]:dict(calibration=described(calibration_base,calibration_base),
                             holdout=described(holdout_base,holdout_base), last_week=described(last_base,last_base))}
    fixed_eval = holdout
    for stage, (grid, predicate, retention) in zip(LAYERS[1:], filters, strict=True):
        rule, measured = select(calibration, grid, predicate, retention)
        if rule is not None:
            calibration = restrict(calibration, predicate, rule)
            holdout = restrict(holdout, predicate, rule)
        stages[stage] = dict(rule=rule, allowed_grid=grid, minimum_relative_calibration_coverage=retention,
                             calibration=described(measured,calibration_base), holdout=described(counts(holdout),holdout_base),
                             last_week=described(counts(latest(holdout)),last_base),
                             same_coverage_nearest=nearest_contrast(fixed_eval, holdout))
    return dict(statuses=dict(Counter(g['status'] for g in group_rows if g['at']>=OCT)),
                train_windows=len(train), latest_train_maturity=max(g['end'] for g,_ in train).isoformat(),
                calibration_windows=len(calibration), latest_calibration_maturity=max(g['end'] for g,_ in calibration).isoformat(),
                model=price_model, stages=stages,
                final_windows=[dict(at=g['at'].isoformat(), end=g['end'].isoformat(), kept_ranks=[i+1 for i in keep],
                                    outcomes=[g['events'][i] for i in keep]) for g,keep in holdout])


def audit_price_prefix(groups, bars, times):
    audited = 0
    for g in groups:
        if g['at'] < OCT or g['status'] != 'complete' or not g['targets']:
            continue
        at = g['at']
        scale = g['targets'][0]['hourly_range']
        end = bisect_left(times, at)
        if context.price_context(bars, times, at, scale) != context.price_context(bars[:end], times[:end], at, scale):
            raise AssertionError(f'Future quote changed the feature at {at}')
        audited += 1
    return audited


def main():
    paths = [ranking.ARCHIVE / f'round19_liquidity_{name}' for name in
             ('50_candidates.json.gz', '50_outcomes.json.gz', '50_lock.json', 'baseline.json')]
    frozen, outcomes, lock, labels = paths
    lock_row, label_row = (json.loads(p.read_bytes()) for p in (lock, labels))
    if study.digest(frozen) != lock_row['candidates'] or label_row['freeze_sha256'] != lock_row['candidates']:
        raise ValueError('Candidate archive changed')
    if study.digest(outcomes) != label_row['outcomes_sha256']:
        raise ValueError('Strict sweep labels changed')
    market = next(ROOT/path for path in lock_row['sources'] if path.endswith('/XAUUSDM5.npz'))
    if study.digest(market) != lock_row['sources'][market.relative_to(ROOT).as_posix()]:
        raise ValueError('Historical price archive changed')
    bars, times = read_market()
    pairs = list(zip(study.read_zip(frozen), study.read_zip(outcomes), strict=True))
    results = {}
    for horizon in ('short','week'):
        for scope in ('IRL','ERL'):
            groups = list(ranking.build_groups(pairs,horizon,scope))
            context.add_context(groups,bars,times)
            key = f'{horizon}/{scope}'
            result = run(groups)
            result['price_prefix_checks'] = audit_price_prefix(groups,bars,times)
            results[key] = result
            print(key, [(stage, v.get('rule'), v['holdout']['hits'],v['holdout']['offers'],
                         v['last_week']['hits'],v['last_week']['offers']) for stage,v in result['stages'].items()],flush=True)
    atomic_json(OUT, dict(outcome='Strict witnessed sweep of a frozen outer edge. Quotes and candidate accuracy only.',
                         study='Current production top 10 in original order, then nested distance, structure and price/clock filtering. The last stage may abstain, no ranks are refilled with future knowledge.',
                         fitting='Fit price model on matured June–August. Choose filter grids on matured September. Freeze all parameters before October–November temporal evaluation. Previously reviewed prices, not untouched data.',
                         same_offer_control='Choose the same number of closest far edges per evaluation window from the same original top ten.',
                         first_holdout=OCT.isoformat(), last_week=LAST_WEEK, results=results,
                         inputs={str(p.relative_to(ROOT)):study.digest(p) for p in (*paths,market,Path(__file__),
                                 Path(context.__file__),Path(ranking.__file__),
                                 ROOT/'scripts/audit_ict_target_ranking.py',ROOT/'scripts/check_pool_priority.py')},orders_sent=0))


if __name__ == '__main__':
    main()
