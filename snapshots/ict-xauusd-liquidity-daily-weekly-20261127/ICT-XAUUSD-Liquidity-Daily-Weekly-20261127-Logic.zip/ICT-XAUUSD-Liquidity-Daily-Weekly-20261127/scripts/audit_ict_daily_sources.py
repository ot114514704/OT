"""Verify the course assets and build an auditable daily profile index."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_bytes())


def checksum(path):
    return sha256(path.read_bytes()).hexdigest()


def require(actual, expected, label):
    if actual != expected:
        raise ValueError(f'{label} differs from its source record')


def run():
    course = ROOT/'research/ict_daily_profiles'
    video = ROOT/'research/ict_time_videos/time2_daily'
    foundations = ROOT/'research/ict_foundations'
    manifest = read(course/'manifest.json')
    rules = read(course/'rules.json')
    transcript = (course/'transcript.txt').read_text(encoding='utf-8')
    frames = {item['frame_seconds']:item for item in read(video/'overview/index.json')['records']}
    explanations = {item['id']:item for item in read(video/'integration.json')['profiles']}
    slides = {row['slide']:row['images'] for row in manifest['slide_images']}
    background = read(foundations/'previous_day_liquidity_review.json')
    require(checksum(course/'source.docx'),manifest['sources']['doc']['sha256'],'DOC archive')
    require(checksum(foundations/'extracted_pages.json'),background['extraction_sha256'],'PDF extraction')
    require(background['source_sha256'],manifest['sources']['pdf']['sha256'],'PDF source')
    require(len(rules['profiles']),6,'Number of course profiles')
    require(len(rules['variants']),1,'Number of course variants')

    cards = []
    for entry in rules['profiles']+rules['variants']:
        ident = entry['id']
        locations = entry['doc_location']
        require(transcript[locations['start']:locations['end']],locations['exact_text'],ident+' DOC location')
        pictures = [image for n in entry['slides'] for image in slides.get(n, [])]
        if not pictures:
            raise ValueError(f'No archived slide illustrations for {ident}')
        for image in pictures:
            require(checksum(ROOT/image['local_path']),image['sha256'],image['local_path'])
        seconds = entry['hd_visual_reference']['frame_seconds']
        explanation = explanations[ident]
        require(seconds,explanation['frame_seconds'],ident+' video timestamp')
        frame = video/'overview'/f'{seconds:04}s.jpg'
        require(checksum(frame),frames[seconds]['frame_sha256'],ident+' video illustration')
        cards.append(dict(id=ident,name=entry['name'],course_claim=explanation['source_claim'],
                          ppt_pages=entry['slides'],ppt_images=pictures,doc_location=locations,
                          video_excerpt_seconds=explanation['seconds'],video_frame=frame.relative_to(ROOT).as_posix(),
                          price_evidence_to_check=entry.get('research_sequence',list(entry['required_facts'])),
                          required_facts=entry['required_facts'],
                          interpretation=explanation['interpretation'],limitations=entry['limitations'],
                          pdf_context_pages=background['profile_links'][ident]))

    # The historical archive describes how the same algorithm behaved by cutoff
    # and at close. It is linked separately from the material above.
    classification = ROOT/'output/research/ict_ipda_profile_replay_20261121.json'
    historical = read(classification)['classification_checks']['daily']
    result = Counter(day['result'] for day in historical)
    return dict(cards=cards,background_review=background,source_manifest=manifest['sources'],
                historical_archive=dict(path=classification.relative_to(ROOT).as_posix(),
                    sha256=checksum(classification),sample_size=len(historical),counts=result),
                notes=['The archived PDF text for pages 327–336 was reviewed. Original page images were unavailable.',
                       'PPT images, DOC anchors, and representative video frames have been hash checked locally.',
                       'Historical algorithm comparisons are not independent labels of the course patterns.'])


if __name__=='__main__':
    result = run()
    out = ROOT/'output/research/ict_daily_source_index.json'
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(len(result['cards']),sum(len(row['ppt_images']) for row in result['cards']),
          result['historical_archive']['sample_size'])
