"""Audit every prior shortlist miss, then test two ways to recover it."""
from bisect import bisect_left
from collections import Counter
from datetime import datetime, timedelta
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts import replay_ict_liquidity_context as context

ranking, study = context.ranking, context.study
BANDS = ('<=45', '46-55', '56-65', '>65')


def band(score):
    return BANDS[0 if score<=45 else 1 if score<=55 else 2 if score<=65 else 3]


def edge(row):
    return row['hi'] if row['side']>0 else row['lo']


def case(g, i):
    t = g['targets'][i]
    return dict(rank=t['rank'], score=t['score'], side=t['side'], zone=[t['lo'],t['hi']],
                source=t['sources'], anchors=t['anchor_times'], distance_h1=g['distance'][i],
                **g['events'][i])


def distinguish(g, i, trend, shape, direction):
    side = g['targets'][i]['side']
    if direction!=side:
        return None
    if shape=='breakout' and side*trend[2]>=.35:
        return 'breakout_continuation'
    if shape=='reclaimed' and side*trend[0]>=.20:
        return 'counter_side_reclaim'
    return None


def confirm_ranked_path(g, market, times, prior, omitted, max_after):
    """At first witnessed clearance, compare the next untouched low-score pools."""
    at = g['at']
    stop = min(g['end'],at+timedelta(minutes=90))
    if not omitted or not prior:
        return None
    start_idx, stop_idx = (bisect_left(times,t) for t in (at,stop))
    remaining = set(omitted)
    visited = set()
    watch = remaining|set(prior)
    for bar in market[start_idx:stop_idx]:
        then = bar.time+study.M5
        if then>=g['end']:
            break
        far_crossings = {i for i in watch-visited
                         if (bar.high>edge(g['targets'][i]) if g['targets'][i]['side']>0
                             else bar.low<edge(g['targets'][i]))}
        visited.update(far_crossings)
        remaining.difference_update(far_crossings)
        cleared = [i for i in far_crossings.intersection(prior)
                   if bar.low<=edge(g['targets'][i])<=bar.high
                   and g['targets'][i]['side']*(bar.close-edge(g['targets'][i]))>0]
        if not cleared or len(remaining)<2:
            continue
        dist = lambda i: abs(edge(g['targets'][i])-bar.close)
        control = min(remaining,key=lambda i:(dist(i),i))
        scale = g['targets'][control]['hourly_range']
        trend, shape, direction, _ = context.price_context(market,times,then,scale)
        eligible = [i for i in remaining if dist(i)<=max_after*scale
                    and any(g['targets'][i]['side']==g['targets'][j]['side']
                            and g['targets'][i]['side']*(edge(g['targets'][i])-edge(g['targets'][j]))>0
                            for j in cleared)
                    and distinguish(g,i,trend,shape,direction)]
        if eligible:
            return then, control, min(eligible,key=lambda i:(dist(i),i)), cleared
    return None


def comparable_misses(groups):
    index = {}
    for g in groups:
        if g['status']!='complete' or g['day']<ranking.FIRST_HOLDOUT:
            continue
        for i,t in enumerate(g['targets']):
            if not g['y'][i]:
                # Weekly deadlines and daily closes change how much time a target has.
                hours = round((g['end']-g['at']).total_seconds()/3600,1)
                key = (g['clock'],hours,t['side'],band(t['score']))
                index.setdefault(key,[]).append((g['distance'][i],g,i))
    for rows in index.values():
        rows.sort(key=lambda row:row[0])
    return index


def match_other_day(index, g, i):
    t = g['targets'][i]
    hours = round((g['end']-g['at']).total_seconds()/3600,1)
    distance = g['distance'][i]
    comparable = index.get((g['clock'],hours,t['side'],band(t['score'])),())
    low = bisect_left(comparable,distance-.35,key=lambda row:row[0])
    high = bisect_left(comparable,distance+.35,key=lambda row:row[0])
    options = [row for row in comparable[low:high] if row[1]['day']!=g['day']]
    if not options:
        return None
    _,other,j = min(options,key=lambda row:(abs(row[0]-distance),row[1]['at']))
    return dict(at=other['at'].isoformat(),deadline=other['end'].isoformat(),shape=other['shape'],
                comparison=case(other,j))


def development_cases(groups, market, times):
    results = []
    for g in groups:
        if g['status']!='complete' or g['day']>=ranking.FIRST_HOLDOUT or not g['targets']:
            continue
        trend, shape, direction, _ = context.price_context(
            market,times,g['at'],g['targets'][0]['hourly_range'])
        for i,t in enumerate(g['targets'][10:],10):
            if t['score']<=65 and g['y'][i]:
                results.append(dict(at=g['at'].isoformat(),deadline=g['end'].isoformat(),clock=g['clock'],
                                    shape=shape,hit=case(g,i),
                                    hypothesis_at_snapshot=distinguish(g,i,trend,shape,direction)))
    return results


def review(groups, market, times, selected):
    coverage, methods, blocks = {}, {}, {}
    missed_cases, sample_cases = [], {}
    last = None
    matched_index = comparable_misses(groups)
    for g in groups:
        if g['status']!='complete' or g['day']<ranking.FIRST_HOLDOUT:
            continue
        prior = selected[g['at']]
        previous, current = set(prior), set(range(min(10,len(g['targets']))))
        omitted = [i for i in range(len(g['targets'])) if i not in previous]
        if not g['targets']:
            continue
        trend, shape, direction, _ = context.price_context(
            market,times,g['at'],g['targets'][0]['hourly_range'])
        for i,t in enumerate(g['targets']):
            b = band(t['score'])
            for name,condition in [('all',True),('prior_omitted',i not in previous),
                                   ('current_omitted',i not in current),('both_omitted',
                                                                         i not in previous|current)]:
                if not condition:
                    continue
                c = coverage.setdefault(name+'/'+b,Counter())
                c.update(n=1,sweep=int(g['y'][i]),touch=int(bool(g['events'][i]['touch'])),
                         reclaim=int(bool(g['events'][i]['reclaim'])))
            if not g['y'][i] or i in previous&current:
                continue
            controls = [j for j in omitted if not g['y'][j] and i!=j
                        and g['targets'][j]['side']==t['side'] and band(g['targets'][j]['score'])==b
                        and abs(g['distance'][j]-g['distance'][i])<=.35]
            earlier = sorted({g['events'][j]['sweep'] for j,other in enumerate(g['targets'])
                              if other['side']==t['side'] and g['distance'][j]<g['distance'][i]
                              and g['events'][j]['sweep'] and
                              datetime.fromisoformat(g['events'][j]['sweep'])<
                              datetime.fromisoformat(g['events'][i]['sweep'])})
            missed_cases.append(dict(at=g['at'].isoformat(),deadline=g['end'].isoformat(),
                price=g['price'],clock=g['clock'],shape=shape,same_side_move_15m=trend[0]*t['side'],
                same_side_move_1h=trend[2]*t['side'],earlier_same_side_sweeps=earlier,
                missed_by_previous=i not in previous,missed_by_mt5_order=i not in current,
                hypothesis_at_snapshot=distinguish(g,i,trend,shape,direction),hit=case(g,i),
                same_snapshot_control=case(g,min(controls,key=lambda j:(abs(g['distance'][j]-g['distance'][i]),j)))
                if controls else None,matched_day_control=match_other_day(matched_index,g,i)))

        # Initial challenger swaps one slot and can only select previously omitted targets.
        for b in BANDS:
            if len(prior)<10:
                break
            dropped = prior[-1]
            shortlist = [i for i in omitted if band(g['targets'][i]['score'])==b
                         and g['distance'][i]<=g['distance'][dropped]+.25]
            by_near = lambda i:(g['distance'][i],i)
            challengers = [i for i in shortlist if distinguish(g,i,trend,shape,direction)]
            if not challengers:
                continue
            chosen = min(challengers,key=by_near)
            control = min(shortlist,key=by_near)
            key = 'initial/'+b
            m = methods.setdefault(key,Counter())
            m.update(attempts=1,recovered=int(g['y'][chosen]),
                     nearest_control_swept=int(g['y'][control]),replacement_lost=int(g['y'][dropped]))
            blocks.setdefault(key,{}).setdefault(str(g['week']),Counter()).update(
                n=1,delta=int(g['y'][chosen])-int(g['y'][dropped]))
            if g['y'][chosen]!=g['y'][dropped]:
                key += '/recovered' if g['y'][chosen] else '/lost'
                sample_cases.setdefault(key,dict(at=g['at'].isoformat(),end=g['end'].isoformat(),
                    price=g['price'],before=g['targets'][dropped],after=g['targets'][chosen],
                    before_result=g['events'][dropped],after_result=g['events'][chosen]))

        # The follow-up only predicts after a nearer on-list zone was actually swept and closed beyond.
        small = [i for i in omitted if g['targets'][i]['score']<=65]
        trigger = confirm_ranked_path(g,market,times,prior,small,2)
        if trigger:
            when, control, chosen, cleared = trigger
            m = methods.setdefault('after_clearance/<=65',Counter())
            def hits_after(i):
                stamp = g['events'][i]['sweep']
                return bool(stamp and datetime.fromisoformat(stamp)>when)
            m.update(attempts=1,recovered=int(hits_after(chosen)),
                     nearest_control_swept=int(hits_after(control)),same_pick=int(chosen==control))
            blocks.setdefault('after_clearance/<=65',{}).setdefault(str(g['week']),Counter()).update(
                n=1,delta=int(hits_after(chosen))-int(hits_after(control)))
            last = dict(at=when.isoformat(),checkpoint=g['at'].isoformat(),end=g['end'].isoformat(),
                        cleared=[case(g,j) for j in cleared],
                        chosen=case(g,chosen),nearest_control=case(g,control))
    paired = {rule:{'weeks':len(w),'delta_ci95':context.interval(
                       {week:(c['delta'],c['n']) for week,c in w.items()})}
              for rule,w in blocks.items()}
    return dict(coverage=coverage,methods=methods,paired=paired,examples=sample_cases,
                dynamic_trace=last,misses=missed_cases,
                development_low_score_misses=development_cases(groups,market,times))


def main():
    path = ranking.ARCHIVE
    record = study.RESEARCH/'ict_liquidity_context_walkforward.json'
    expected = json.loads(record.read_bytes())
    inputs = (path/'round19_liquidity_50_candidates.json.gz',path/'round19_liquidity_50_outcomes.json.gz')
    manifest = {p.name:study.digest(p) for p in inputs}
    assert all(expected['inputs'][k]==v for k,v in manifest.items())
    lock = json.loads((path/'round19_liquidity_50_lock.json').read_bytes())
    market_path = next(ROOT/name for name in lock['sources'] if name.endswith('/XAUUSDM5.npz'))
    assert study.digest(market_path)==expected['inputs'][market_path.name]
    pairs = list(zip(*(study.read_zip(p) for p in inputs),strict=True))
    market,times = context.read_market()
    results = {}
    for horizon in ('short','week'):
        for scope in ('IRL','ERL'):
            key = f'{horizon}/{scope}'
            groups = list(ranking.build_groups(pairs,horizon,scope))
            context.add_context(groups,market,times)
            picks = {}
            check = context.evaluate(groups,picks)
            assert check['comparisons']['combined']==expected['results'][key]['comparisons']['combined']
            results[key] = review(groups,market,times,picks)
            r = results[key]
            print(key, 'previous misses',sum(m['missed_by_previous'] for m in r['misses']),
                  'all misses',len(r['misses']),
                  'with controls',sum(bool(m['same_snapshot_control'] or m['matched_day_control'])
                                      for m in r['misses']),
                  'older low-score misses',len(r['development_low_score_misses']),
                  'rules',r['methods'],flush=True)
    out = study.RESEARCH/'ict_liquidity_miss_audit.json'
    decision = dict(inputs=manifest,previous_run_sha256=study.digest(record),
                    code_sha256=study.digest(Path(__file__)),bands=BANDS,
                    coverage='All frozen candidates through rank 50; include all misses for either previous '
                             'combined shortlist or the MT5 order. Counts are checkpoint-target pairs.',
                    validation='Methods fixed for this exploratory replay. Dates previously reviewed. '
                               'Reranking only; no price features from after the decision bar.',
                    results=results)
    out.write_text(json.dumps(decision,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
