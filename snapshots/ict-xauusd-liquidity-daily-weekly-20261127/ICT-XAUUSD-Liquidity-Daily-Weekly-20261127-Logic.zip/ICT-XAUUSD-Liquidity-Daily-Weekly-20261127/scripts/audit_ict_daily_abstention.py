"""Measure whether the 10:00 New York daily learner knows when to abstain."""

from collections import Counter
from datetime import date, datetime
import json
from pathlib import Path

from scripts import audit_ict_daily_learning as daily
from scripts.serve_ict_live import atomic_json


BASELINE = daily.RESEARCH / 'ict_daily_learning_20261123.json'
OUT = daily.RESEARCH / 'ict_daily_abstention_20261125.json'
MIN_CALIBRATION = 20
MIN_ACCEPTED = 8
TARGETS = {'calibrated_65': 0.65, 'calibrated_75': 0.75}
GRID = [step / 20 for step in range(21)]


def top_probability(row):
    index = max(range(len(row['learned'])), key=row['learned'].__getitem__)
    return dict(date=row['date'], ny_week=row['ny_week'], confidence=row['learned'][index], key=row['keys'][index],
                cutoff=row['available_at'], ready_at=row['label_available_at'],
                top_correct=None if row['rule_y'] is None else bool(row['rule_y'][index]),
                any_match=None if row['rule_y'] is None else any(row['rule_y']),
                manual_correct=None if row['manual_y'] is None else bool(row['manual_y'][index]),
                manual_any_match=None if row['manual_y'] is None else any(row['manual_y']))


def pick(history, target):
    """Choose the most inclusive grid level with enough calibrated precision."""
    for threshold in GRID:
        accepted = [r for r in history if r['confidence'] >= threshold]
        correct = sum(row['top_correct'] for row in accepted)
        if len(accepted) >= MIN_ACCEPTED and (correct + 1) / (len(accepted) + 2) >= target:
            return dict(threshold=threshold, calibration_accepted=len(accepted), calibration_correct=correct)
    return dict(threshold=None, calibration_accepted=0, calibration_correct=0)


def walk_forward(rows, exclude):
    observations = []
    for row in rows:
        at = datetime.fromisoformat(row['cutoff'])
        if not datetime.fromisoformat(row['ready_at']) > at:
            raise ValueError(f'Invalid label availability for {row["date"]}')
        prior = [r for r in rows if r['ny_week'] < row['ny_week'] and r['top_correct'] is not None and r['date'] not in exclude
                 and datetime.fromisoformat(r['ready_at']) < at]
        decisions = {'offer_all': dict(threshold=0, offer=True),
                     'fixed_50': dict(threshold=0.5, offer=row['confidence'] >= 0.5)}
        enrolled = len(prior) >= MIN_CALIBRATION
        for name, target in TARGETS.items():
            decision = pick(prior, target) if enrolled else dict(threshold=None)
            threshold = decision['threshold']
            decisions[name] = dict(decision, offer=threshold is not None and row['confidence'] >= threshold)
        observations.append(dict(row, calibration_dates=len(prior), calibrated=enrolled,
                                 calibration_through=prior[-1]['ready_at'] if prior else None,
                                 decisions=decisions))
    return observations


def grade(rows, *, manual=False):
    label = 'manual_correct' if manual else 'top_correct'
    any_match = 'manual_any_match' if manual else 'any_match'
    outcomes = [r for r in rows if r[label] is not None]
    results = {}
    for name in ('offer_all', 'fixed_50', *TARGETS):
        tally = Counter()
        tally['eligible'] = len(outcomes)
        tally['correct_candidate_available'] = sum(r[any_match] for r in outcomes)
        for row in outcomes:
            offered = row['decisions'][name]['offer']
            tally['offered'] += offered
            tally['correct'] += offered and row[label]
            tally['incorrect'] += offered and not row[label]
            tally['abstained'] += not offered
            tally['abstained_correct_top'] += not offered and row[label]
            tally['abstained_with_matching_candidate'] += not offered and row[any_match]
        results[name] = dict(tally, precision=tally['correct'] / tally['offered'] if tally['offered'] else None,
                             coverage=tally['offered'] / len(outcomes) if outcomes else None,
                             correct_over_all=tally['correct'] / len(outcomes) if outcomes else None)
    return results


def run(baseline, manual_days):
    rows = [top_probability(row) for row in baseline['observations']]
    if sorted({row['date'] for row in rows}) != [row['date'] for row in rows]:
        raise ValueError('Expected chronological and unique NY dates')
    for row in rows:
        local = date.fromisoformat(row['date'])
        monday = date.fromisoformat(row['ny_week'])
        if monday.weekday() != 0 or not 0 <= (local - monday).days <= 4:
            raise ValueError(f'Invalid NY week for {local}')
    forecasts = walk_forward(rows, manual_days)
    eligible = [row for row in forecasts if row['calibrated']]
    for row in forecasts:
        prefix = [r for r in rows if r['date'] <= row['date']]
        if walk_forward(prefix, manual_days)[-1] != row:
            raise ValueError(f'Calibration used a future row on {row["date"]}')
    results = dict(all_fixed_policy_comparison=grade(forecasts), after_calibration_warmup=grade(eligible),
                   recent_oct_nov=grade([r for r in eligible if r['date'] >= '2026-10-01']),
                   manual_after_warmup=grade(eligible, manual=True))
    return results, forecasts


def main():
    baseline = json.loads(BASELINE.read_bytes())
    manual_days = set()
    for file in daily.MANUAL:
        if baseline['inputs'][file.name] != daily.digest(file):
            raise ValueError(f'Existing baseline pinned another manual dataset: {file.name}')
        manual_days.update(case['date'] for case in json.loads(file.read_bytes())['cases'] if case['period'] == 'daily')
    results, forecasts = run(baseline, manual_days)
    if results['all_fixed_policy_comparison']['offer_all']['correct'] != baseline['rule_check']['learned']['top1_matches']:
        raise ValueError('Frozen daily top-one counts did not reproduce')
    atomic_json(OUT, dict(scope='Retrospective policy selection on published walk-forward scores, no new fit of daily features',
        settings=dict(min_history=MIN_CALIBRATION, min_accepted=MIN_ACCEPTED, grid=GRID, targets=TARGETS,
                      smoothing='Successful choices plus one and accepted choices plus two'),
        outcome='Top signed family matches a completed same-lifecycle close path. Manual reviewed dates are excluded from '
        'threshold calibration. Offer refers only to a daily profile research classification.',
        results=results, forecasts=forecasts, prefix_checks=len(forecasts),
        hashes={path.name:daily.digest(path) for path in (BASELINE,*daily.MANUAL,Path(__file__))},
        shadow_research_only=True, orders_sent=0))
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
