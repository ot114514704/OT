"""Walk forward on frozen ICT candidates. Labels measure price contact, not P&L."""
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts import replay_pool_and_dol as replay


def features(row, price, family):
    parts = row['score_components'] if family == 'dol' else row['components']
    names = ('reach', 'alignment', 'quality', 'timing', 'obstacle') if family == 'dol' else (
        'structure', 'anchors', 'frames', 'reach', 'dol')
    return [np.log1p(10000 * row['distance'] / price),
            np.log1p(10000 * (row['hi'] - row['lo']) / price),
            row['side'], row['score'], *(parts[k] for k in names)]


def fit_prior_weeks(training, label='y'):
    # Each forecast has unit weight regardless of how many targets it generated.
    x = np.array([v for g in training for v in g['x']])
    y = np.array([v for g in training for v in g[label]], dtype=float)
    weight = np.array([1 / len(g['y']) for g in training for _ in g['y']])
    weight /= weight.sum()
    mean = weight @ x
    scale = np.sqrt(weight @ ((x - mean) ** 2))
    scale[scale < 1e-8] = 1
    design = np.column_stack((np.ones(len(x)), (x - mean) / scale))
    coef = np.zeros(design.shape[1])
    penalty = np.diag([0.] + [.02] * x.shape[1])
    for _ in range(30):
        prob = 1 / (1 + np.exp(-np.clip(design @ coef, -40, 40)))
        grad = design.T @ (weight * (prob - y)) + penalty @ coef
        curvature = design.T @ ((weight * prob * (1-prob))[:, None] * design) + penalty
        step = np.linalg.solve(curvature, grad)
        coef -= step
        if abs(step).max() < 1e-8:
            break
    return mean, scale, coef


def select_rank(model, group):
    mean, scale, coef = model
    logits = coef[0] + ((np.array(group['x']) - mean) / scale) @ coef[1:]
    return max(range(len(logits)), key=lambda i: (logits[i], -group['dist'][i], -i))


def first_bar_events(stamps):
    instants = [datetime.fromisoformat(t) if t else None for t in stamps]
    earliest = min((t for t in instants if t is not None), default=None)
    return [earliest is not None and t == earliest for t in instants]


def evaluate(groups):
    weeks = sorted({g['week'] for g in groups})
    totals = Counter()
    bands = defaultdict(Counter)
    folds = []
    examples = {}
    order_examples = {}
    first_totals = Counter()
    for week in weeks[3:]:
        test = [g for g in groups if g['week'] == week]
        train = [g for g in groups if g['week'] < week and g['end'] < test[0]['at']]
        contact_model = fit_prior_weeks(train)
        resolved = [g for g in train if sum(g['first']) <= 1]
        first_model = fit_prior_weeks(resolved, 'first')
        counts = Counter()
        order = Counter()
        for g in test:
            learned = select_rank(contact_model, g)
            nearest = min(range(len(g['dist'])), key=g['dist'].__getitem__)
            edge = min(range(len(g['edge_dist'])), key=g['edge_dist'].__getitem__)
            first_pick = select_rank(first_model, g)
            first = g['first']
            nfirst = sum(first)
            order.update(dict(no_event=nfirst==0, unique=nfirst==1, tied=nfirst>1))
            for name, i in [('original',0), ('nearest',nearest), ('nearest_edge',edge),
                            ('learned_contact',learned), ('learned_first',first_pick)]:
                if first[i]:
                    order[name + ('_unique' if nfirst==1 else '_tied')] += 1
            if nfirst:
                observed_index = first.index(True)
                ex = dict(at=g['at'].isoformat(),end=g['end'].isoformat(),
                          learned_index=first_pick, observed_index=observed_index)
                if nfirst == 1 and not first[first_pick] and g['y'][first_pick]:
                    order_examples.setdefault('picked_later', ex)
                if nfirst > 1:
                    ex['also_first_index'] = first.index(True, observed_index+1)
                    order_examples.setdefault('tied', ex)
            y = g['y']
            if y[learned] != y[nearest]:
                key = 'learned_only' if y[learned] else 'nearest_only'
                if key not in examples:
                    examples[key] = dict(at=g['at'].isoformat(), end=g['end'].isoformat(),
                                         learned_index=learned, nearest_index=nearest)
            counts.update(dict(n=1, original=y[0], nearest=y[nearest], learned=y[learned],
                               learned_only=y[learned] and not y[nearest],
                               nearest_only=y[nearest] and not y[learned]))
            for score, outcome in zip(g['scores'], y):
                band = int(score) // 10 * 10
                bands[band].update(dict(n=1, hits=outcome))
        totals.update(counts)
        first_totals.update(order)
        folds.append(dict(week=str(week), train=len(train), last_training_label=train[-1]['end'].isoformat(),
                          first_prediction=test[0]['at'].isoformat(), first_train=len(resolved),
                          order=order, **counts))
    return dict(total=totals, folds=folds, original_score_bands=bands, first_disagreements=examples,
                order=first_totals, order_examples=order_examples)


def main():
    lock = json.loads(replay.LOCK.read_bytes())
    for path in (replay.FROZEN, replay.QUOTES, replay.DOLS):
        if replay.digest(path) != lock[path.name]:
            raise ValueError(f'Archived input changed: {path.name}')
    bars, times = replay.load_bars()
    coverage = replay._Coverage(times[0], times[-1] + replay.M5, bars, replay.M5)
    frozen = replay.read_zip(replay.FROZEN)
    outcomes = replay.read_zip(replay.OUT / 'outcomes.json.gz')
    groups = defaultdict(list)
    exclude = Counter()
    previous = None
    for s, stored in zip(frozen, outcomes, strict=True):
        at = datetime.fromisoformat(s['at'])
        if stored['at'] != s['at'] or previous is not None and at <= previous:
            raise ValueError('Misaligned or unordered forecast')
        previous = at
        observed = replay.assess(s, bars, times, coverage)
        if observed != stored['short']:
            raise ValueError(f'Outcome differs from archived quotes at {at}')
        if observed['status'] != 'complete':
            exclude[observed['status']] += 1
            continue
        day = at.astimezone(replay.NY).date()
        for family, event in [('dol', 'touch'), ('pools', 'sweep')]:
            rows = s[family]
            if rows:
                if family == 'pools':
                    edges = [r['hi'] if r['side'] > 0 else r['lo'] for r in rows]
                else:
                    edges = [r['lo'] if r['side'] > 0 else r['hi'] for r in rows]
                groups[family].append(dict(at=at, week=day-timedelta(days=day.weekday()),
                    end=datetime.fromisoformat(observed['end']),
                    x=[features(r, s['price'], family) for r in rows],
                    y=[bool(r[event]) for r in observed[family]], scores=[r['score'] for r in rows],
                    first=first_bar_events([r[event] for r in observed[family]]),
                    edge_dist=[abs(e-s['price']) for e in edges],
                    dist=[r['distance'] for r in rows]))
    report = dict(protocol='Three warm-up weeks, weekly expanding L2 logistic fit, equal forecast weights, '
                  'training deadlines strictly before the test week. Previously researched archive.',
                  horizon='Up to four hours capped at the NY day boundary; DOL near edge, pool strict far edge',
                  first_metric='Across all frozen candidates, earliest M5 confirmation. Unique-first and ambiguous '
                               'same-bar counts separate. First-event fit excludes tied training snapshots; '
                               'no-event windows retained. nearest_edge uses the evaluated target boundary.',
                  excluded=exclude, archived_snapshots=len(frozen),
                  inputs={p.name: replay.digest(p) for p in (replay.QUOTES, replay.FROZEN,replay.OUT/'outcomes.json.gz')},
                  results={family:evaluate(records) for family,records in groups.items()})
    path = replay.RESEARCH / 'ict_walkforward_ranking.json'
    path.write_text(json.dumps(report, indent=2, allow_nan=False), encoding='utf-8')
    for family, result in report['results'].items():
        print(family, result['total'], result['original_score_bands'])


if __name__ == '__main__':
    main()
