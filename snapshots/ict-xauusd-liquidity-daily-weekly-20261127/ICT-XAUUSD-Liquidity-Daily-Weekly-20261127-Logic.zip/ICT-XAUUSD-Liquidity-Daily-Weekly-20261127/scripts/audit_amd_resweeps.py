"""Offline study of one extra same-side sweep after the research model's M."""
import argparse
from collections import Counter
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path

from brooks_ai.types import Bar
from ict_ai.amd import amd_events
from scripts.prepare_ict_week import aggregate_bars


PERIOD = timedelta(minutes=15)
EXPIRY = 24


def ordered_excursion(bar, five_minute, low, high, swept_low):
    """Require distinct closed M5 bars to establish which M15 edge broke first."""
    sides = []
    for minute in (0, 5, 10):
        child = five_minute.get(bar.time + timedelta(minutes=minute))
        if child is None or child.low < low and child.high > high:
            return False
        side = "low" if child.low < low else "high" if child.high > high else None
        if side and (not sides or sides[-1] != side):
            sides.append(side)
    return sides == (["low", "high"] if swept_low else ["high", "low"])


def repeat_after_reclaim(rows, start, deadline, mark, five_minute):
    low, high = mark["range_low"], mark["range_high"]
    swept_low = mark["lower"] < low
    extreme = mark["lower"] if swept_low else mark["upper"]
    repeat = None
    reclaimed = False
    run = 0
    for i in range(start, min(deadline + 1, len(rows))):
        b = rows[i]
        if b.time != rows[i-1].time + PERIOD:
            outcome = "gap"
            break
        if b.low < low and b.high > high:
            if repeat is None or not ordered_excursion(b, five_minute, low, high, swept_low):
                outcome = "unordered_two_sided_bar"
                break
            repeat["ordered_by_m5_at"] = (b.time + PERIOD).isoformat()
        farther = b.low < extreme if swept_low else b.high > extreme
        if farther:
            if repeat and reclaimed:
                outcome = "second_attempt_invalidated"
                break
            extreme = b.low if swept_low else b.high
            if repeat is None:
                repeat = {"first_repeat_known": (b.time + PERIOD).isoformat(),
                          "side": "low" if swept_low else "high"}
            run = 0
        outside = b.close > high if swept_low else b.close < low
        if repeat:
            recovered = b.close >= low if swept_low else b.close <= high
            if recovered and not reclaimed:
                repeat["reclaim_known"] = (b.time + PERIOD).isoformat()
                reclaimed = True
        run = run + 1 if outside else 0
        if run == 2:
            outcome = "two_opposite_closes"
            break
    else:
        outcome = "expired" if deadline < len(rows) else "end_of_data"
    if repeat:
        repeat.update(outcome=outcome, extreme=extreme,
                      observed_through=(rows[i-1 if outcome=="gap" else i].time + PERIOD).isoformat())
    return repeat


def audit(bars, cutoff):
    rows = aggregate_bars(bars, 5, 15, cutoff)
    times = {b.time + PERIOD: i for i,b in enumerate(rows)}
    five_minute = {b.time: b for b in bars if b.time+timedelta(minutes=5)<=cutoff}
    events = amd_events(rows, PERIOD, cutoff, expiry_bars=EXPIRY)
    formed = {m["id"]: m for m in events if m["phase"] == "A"}
    cases = []
    for m in events:
        if m["phase"] != "M":
            continue
        a = formed[m["id"]]
        i = times[datetime.fromisoformat(m["available_at"])]
        deadline = times[datetime.fromisoformat(a["available_at"])] + EXPIRY
        repeat = repeat_after_reclaim(rows, i+1, deadline, m, five_minute)
        if repeat:
            cases.append(dict(range_start=a["start"], range_known=a["available_at"],
                              low=m["range_low"], high=m["range_high"],
                              first_reclaim_known=m["available_at"], **repeat))
    return {"research_ranges":len(formed), "first_reclaims":sum(m["phase"]=="M" for m in events),
            "outcomes":dict(Counter(c["outcome"] for c in cases)), "cases":cases}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("snapshot", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    contents = args.snapshot.read_bytes()
    snapshot = json.loads(contents)
    bars = [Bar(datetime.fromisoformat(t),o,h,l,c,0) for t,o,h,l,c in snapshot["price_rows_utc"]]
    result = audit(bars, bars[-1].time + timedelta(minutes=5))
    result.update(source_file=args.snapshot.name, source_sha256=hashlib.sha256(contents).hexdigest(),
                  timeframe="M15", expiry_from_A_bars=EXPIRY,
                  interpretation="同侧二次越界后，观察对侧连续两次收盘。统计价格路径，不计算交易收益。",
                  course_reference="交易员无畏 AMD 120–229 秒。再次扫荡的观察窗口和收盘次数为研究假设。")
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
