"""Distinguish Wednesday sweep misses from later expansion and calendar coverage."""

from bisect import bisect_left
from collections import Counter
from datetime import date, timedelta
import json
from pathlib import Path

from ict_ai.range_liquidity import _m5_reference_day, _research_open
from ict_ai.weekly_close_candidates import frozen_extreme_candidates
from ict_ai.weekly_path import _profile_candidates, consolidation_evidence, weekly_path
from scripts import audit_ict_weekly_candidates as weekly
from scripts.serve_ict_live import atomic_json


OUT = weekly.market.RESEARCH/'ict_weekly_midweek_20261124.json'
M5 = weekly.market.M5
NY = weekly.NY
CHANGE = date(2026,2,1)
CONSOLIDATION = 'weekly_consolidation_expansion'


def calendar(stamp):
    local = stamp.astimezone(NY)
    archive_open_bucket = local.date()<CHANGE and local.weekday()<4 and (local.hour,local.minute)==(18,0)
    return _research_open(stamp) and not archive_open_bucket


def day_coverage(bars, dates, as_of):
    result = {}
    seen = {b.time for b in bars if b.time+M5 <= as_of}
    for day in dates:
        ref = _m5_reference_day([],day,as_of)
        start,end = ref['start'],ref['end']
        if end>as_of:
            continue
        missing = [(start+i*M5) for i in range((end-start)//M5)
                   if _research_open(start+i*M5) and start+i*M5 not in seen]
        result[day.isoformat()] = dict(
            strict=not missing, alternate=not any(calendar(t) for t in missing),
            missing=[t.astimezone(NY).isoformat() for t in missing],
        )
    return result


def scenarios(bars,days,at):
    clipped = [b for b in bars if b.time+M5<=at]
    raw = weekly_path(clipped,days,at)
    coverage=day_coverage(clipped,days,at)
    days_observed = raw['daily']
    summary = {}
    for mode in ('strict','alternate'):
        daily = []
        for entry in days_observed:
            d = dict(entry,coverage_complete=coverage.get(entry['date'],{}).get(mode,False))
            if mode=='strict' and d['coverage_complete']!=entry['coverage_complete']:
                raise ValueError(f'M5 coverage disagrees with the original at {entry["date"]}')
            daily.append(d)
        actual = {weekly.identity(c):c.get('variant') for c in _profile_candidates(daily,days,at)
                  if c.get('path_complete') and c.get('observed_sequence')}
        covered = bool(coverage) and all(c[mode] for c in coverage.values())
        mature = [r for r in daily if r['ended']]
        range_watch = consolidation_evidence(mature) if len(mature)==3 and covered else None
        cards = frozen_extreme_candidates(dict(daily=daily),days,at,covered)
        summary[mode]=dict(covered=covered,early=sorted(weekly.active(cards)),
                           watch=range_watch,actual=sorted((ident,side,variant) for (ident,side),variant in actual.items()))
    return summary,coverage


def measure(rows,mode):
    stats=Counter()
    documented=[]
    for row in rows:
        early,end=(row[key][mode] for key in ('wednesday','friday'))
        if not early['covered'] or not end['covered']:
            continue
        stats['eligible']+=1
        picked={tuple(key) for key in early['early']}
        truth={(ident,side) for ident,side,_ in end['actual']}
        expansion=any(ident==CONSOLIDATION for ident,_ in truth)
        watch=bool(early['watch'] and early['watch']['matched'])
        stats.update(weeks_with_early_reversal=bool(picked),signed_candidates=len(picked),
                     signed_matches=len(picked&truth),realized_paths=len(truth),
                     missed_paths=len(truth-picked),expansion_weeks=expansion,
                     consolidation_watch=watch,watch_with_later_expansion=watch and expansion)
        for ident,side,variant in end['actual']:
            if (ident,side) in picked:
                continue
            reason = 'late_expansion' if ident==CONSOLIDATION else 'midweek_candidate_absent'
            documented.append(dict(week=row['week'],label=ident,direction=side,variant=variant,
                                   reason=reason,wednesday_watch=watch))
    return dict(counts=stats,misses=documented)


def main():
    baseline=json.loads(weekly.OUT.read_bytes())
    bars,times=weekly.market.read_market()
    tape=weekly.market.ARCH/'XAUUSDM5.npz'
    if weekly.market.digest(tape)!=baseline['source_sha256'][tape.name]:
        raise ValueError('Weekly replay price file changed')
    rows=[]
    for prior in baseline['timeline']:
        monday=date.fromisoformat(prior['week'])
        days=[monday+i*timedelta(days=1) for i in range(5)]
        start=weekly._day_bounds(monday)[0]
        at=weekly._day_bounds(days[2])[1]
        end=weekly._day_bounds(days[-1])[1]
        part=bars[bisect_left(times,start):bisect_left(times,end)]
        early,gaps=scenarios(part,days,at)
        end_states,all_gaps=scenarios(part,days,end)
        prefix=part[:bisect_left([b.time for b in part],at)]
        if (early,gaps)!=scenarios(prefix,days,at):
            raise ValueError(f'Future bars changed Wednesday view {monday}')
        strict=end_states['strict']
        if strict['covered']!=prior['settled']['covered']:
            raise ValueError(f'Close coverage changed, {monday}')
        expected={weekly.identity(c) for c in prior['settled']['realized']}
        if strict['covered'] and {(i,d) for i,d,v in strict['actual']}!=expected:
            raise ValueError(f'Close truth changed, {monday}')
        rows.append(dict(week=prior['week'],wednesday=early,friday=end_states,coverage=all_gaps))
    results={key:measure(rows,key) for key in ('strict','alternate')}
    restored=[r['week'] for r in rows if r['friday']['alternate']['covered'] and not r['friday']['strict']['covered']]
    atomic_json(OUT,dict(
        source_hashes={p.name:weekly.market.digest(p) for p in (tape,weekly.OUT,Path(__file__),
                      Path('ict_ai/weekly_path.py'),Path('ict_ai/weekly_close_candidates.py'),Path('ict_ai/range_liquidity.py'))},
        current_broker_schedule='https://www.tmgm.com/eng/trading/trading-hours',
        policy='Sensitivity only: ignore the NY 18:00 M5 bucket on old Monday–Thursday archive dates '
               'before February 2026. No candles are added. All other gaps are retained.',
        watch='Three completed overlapping daily ranges as of Wednesday close. No direction predicted.',
        restored_weeks=restored,prefix_checks=len(rows),results=results,
        weeks=rows,orders_sent=0,
    ))
    for mode,state in results.items():
        print(mode,state['counts'])
    print('restored weeks',len(restored),'prefix checks',len(rows))


if __name__=='__main__':
    main()
