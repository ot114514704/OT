"""Reproduce immutable liquidity-reference observations; no order APIs."""
import argparse,csv,hashlib,json,sys
from datetime import date,timedelta
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from brooks_ai.types import Bar,utc_time
from ict_ai.timebase import NY,manifest_epoch_to_utc,clock_policy_metadata
from ict_ai.liquidity import closed_day_references,equal_extreme_references


def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,default=ROOT/'data/real/TMGM_ICT_XAU_M5_20261013_1220/provenance.json');p.add_argument('--out',type=Path,default=ROOT/'output/research/ict_liquidity_references_20261013.json')
    p.add_argument('--friday-close',choices=('16:55','17:00'),default='17:00',help='Unverified NY study-calendar hypothesis')
    args=p.parse_args();hour,minute=map(int,args.friday_close.split(':'));close_minutes=hour*60+minute
    meta=json.loads(args.manifest.read_text(encoding='utf-8'));entry=next(d for d in meta['datasets'] if d['timeframe']=='M5');path=Path(entry['data_path'])
    sha=hashlib.sha256(path.read_bytes()).hexdigest()
    if meta.get('synthetic') is not False or sha!=entry['data_sha256']:raise ValueError('Matching non-synthetic source required')
    with path.open(encoding='utf-8-sig',newline='') as f:
        bars=[Bar(manifest_epoch_to_utc(utc_time(r['time']),meta),*(float(r[k]) for k in ['open','high','low','close','spread'])) for r in csv.DictReader(f)]
    cut=utc_time(meta['finished_at_utc']);period=timedelta(minutes=5);tick=meta['current_symbol_observation']['trade_tick_size']
    report={'source_manifest':str(args.manifest.resolve()),'source_sha256':sha,'as_of':cut.isoformat(),
            **clock_policy_metadata(meta),'historical_clock_verified':False,
            'session_calendar_verified':False,'friday_study_close_ny':args.friday_close,
            'days':[closed_day_references(bars,d,period,cut,close_minutes) for d in sorted({b.time.astimezone(NY).date() for b in bars if b.time+period<=cut and b.time.astimezone(NY).weekday()<5})],
            'equal_extreme_candidates':equal_extreme_references(bars,period,cut,tick),
            'parameters':{'tick_size':tick,'tick_size_basis':'current terminal contract; historical continuity unverified','tolerance_ticks':3,'pivot_radius':2,'max_anchor_bars':48},
            'code_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'ict_ai/liquidity.py',ROOT/'ict_ai/timebase.py',Path(__file__)]},'trade_signal':False,'orders_sent':0}
    args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'report':str(args.out),'days':[(d['date'],d['status']) for d in report['days']],'equal_extreme_candidates':len(report['equal_extreme_candidates']),'orders_sent':0},ensure_ascii=False))


if __name__=='__main__':main()
