"""Freeze a 10:00 daily classification threshold and grade verified forward records."""

from argparse import ArgumentParser
from collections import Counter
from datetime import datetime, time
from pathlib import Path

from scripts import audit_ict_daily_abstention as study
from scripts import watch_ict_profile_feed as feed
from scripts.serve_ict_live import atomic_json
from scripts.shadow_ict_dol import write_once


OUT = study.daily.RESEARCH / 'ict_daily_abstention_forward_20261125'
POLICY = OUT / 'policy.json'
CHECKPOINT = time(10)
THRESHOLD = 0.5
PINS = (Path(__file__), Path(study.__file__), study.OUT, feed.daily.MODEL, *feed.PROTOCOL_FILES)


def fingerprints():
    return {path.name: feed.archive.digest(path) for path in PINS}


def freeze():
    feed.daily.load_model()
    report = feed.settlement.read_json(study.OUT)
    fixed = report['results']['all_fixed_policy_comparison']['fixed_50']
    if report['hashes'][Path(study.__file__).name] != feed.archive.digest(Path(study.__file__)) or not fixed['correct']:
        raise ValueError('Frozen historical threshold evidence is unavailable')
    OUT.mkdir(parents=True, exist_ok=True)
    write_once(POLICY, dict(frozen_at=feed.daily.utc_now().isoformat(), threshold=THRESHOLD,
                           checkpoint_ny='10:00', pinned=fingerprints(), orders_sent=0))


def observation(path, sources, protocol, threshold):
    record, bars = feed.validate(path, sources, protocol)
    candidates = record['candidates']
    top = max(candidates, key=lambda c: c['learned_probability'], default=None)
    offered = top is not None and top['learned_probability'] >= threshold
    result = dict(date=path.stem[:10], cutoff=record['cutoff'], recorded_at=record['recorded_at'],
                  source_status=record['status'], top=top, decision='offer' if offered else 'abstain',
                  forecast_sha256=feed.archive.digest(path), settlement_status='awaiting_settlement', correct=None,
                  actual_path_available=None)
    settlement = feed.ROOT / 'settlements' / path.name
    if settlement.exists():
        saved = feed.settlement.read_json(settlement)
        tail = feed.settlement.decode_bars(saved['settlement_m5'])
        captured = datetime.fromisoformat(saved['captured_at'])
        if saved != feed.settlement_record(path, record, bars, tail, captured):
            raise ValueError(f'Forward outcome could not be reproduced: {settlement.name}')
        result.update(settlement_status=saved['status'], settlement_sha256=feed.archive.digest(settlement))
        if saved['actual_paths'] is not None:
            result['actual_path_available'] = bool(saved['actual_paths'])
        if saved['status'] == 'scored':
            selected = max(saved['candidate_results'], key=lambda c: c['learned_probability'])
            result['correct'] = bool(selected['matched'])
    return result


def verify(*, rehearsal=False):
    policy = feed.settlement.read_json(POLICY)
    if policy['pinned'] != fingerprints() or policy['threshold'] != THRESHOLD:
        raise ValueError('The prospective daily threshold or its sources changed')
    model = feed.daily.load_model()
    sources = {CHECKPOINT: (feed.daily, model)}
    protocol = feed.read_protocol()
    frozen = datetime.fromisoformat(policy['frozen_at'])
    rows = []
    older = 0
    for path in sorted(feed.ROOT.glob('????-??-??_1000.json')):
        cutoff = datetime.fromisoformat(feed.settlement.read_json(path)['cutoff'])
        if cutoff <= frozen:
            older += 1
            if not rehearsal:
                continue
        row = observation(path, sources, protocol, policy['threshold'])
        row['eligible'] = cutoff > frozen
        rows.append(row)
    counts = Counter()
    for row in rows:
        if not row['eligible']:
            continue
        counts['registered'] += 1
        counts[row['settlement_status']] += 1
        if row['correct'] is not None:
            offered = row['decision'] == 'offer'
            counts['baseline_correct'] += row['correct']
            counts['offered'] += offered
            counts['offered_correct'] += offered and row['correct']
            counts['abstained_correct'] += not offered and row['correct']
        elif row['actual_path_available'] and row['source_status'] == 'no_candidate':
            counts['completed_path_without_candidate'] += 1
    result = dict(policy_sha256=feed.archive.digest(POLICY), frozen_at=policy['frozen_at'],
                  threshold=policy['threshold'], previous_records=older, counts=counts, records=rows,
                  rehearsal=rehearsal, orders_sent=0)
    atomic_json(OUT / ('rehearsal.json' if rehearsal else 'status.json'), result)
    return result


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('freeze', 'verify', 'rehearse'))
    args = parser.parse_args()
    if args.action == 'freeze':
        freeze()
    else:
        result = verify(rehearsal=args.action == 'rehearse')
        print(f"Frozen {result['frozen_at']}; prior records {result['previous_records']}; "
              f"eligible {result['counts']['registered']}; checked {len(result['records'])}")
