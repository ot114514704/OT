"""Compare M5 AMD simulations with a deterministic sample of real TMGM ticks."""

from argparse import ArgumentParser
from collections import Counter
from dataclasses import replace
from datetime import date, datetime
import json
from pathlib import Path

from brooks_ai.risk import size_volume
from ict_ai.tick_limit import simulate_tick_limit
from ict_ai.timebase import NY
from scripts import backtest_ict_native_amd as study
from scripts import replay_ict_tmgm_profile_one as feed
from scripts.serve_ict_live import atomic_json


ARCHIVE = study.OUT.with_name('ict_native_amd_tick_witness_20261123.json.gz')
REPORT = study.OUT.with_name('ict_native_amd_tick_check_20261123.json')


def run(capture):
    original = json.loads(study.OUT.read_bytes())
    for path,checksum in original['inputs'].items():
        if feed.archive.digest(study.ROOT/path)!=checksum:
            raise ValueError(f'Frozen baseline input differs: {path}')
    bars,spec,server = study.read_market(date(2026,10,1),date(2026,11,20))
    spec = replace(spec,commission_round_turn=7.,slippage=.05)
    budget = 10000*original['risk_limits']['risk_fraction']
    period = 'M15'
    groups = {'AMD':[],'AD_no_M':[]}
    for signal in sorted(original['confirmed'],key=lambda s:(s['d_confirm'],s['id']),reverse=True):
        if signal['timeframe']!=period or len(groups[signal['route']])==10:
            continue
        order = study.order_for(signal,spec)
        if order is None or order.available_at<bars[0].time:
            continue
        stop_risk = (abs(order.entry-order.stop)+2*spec.slippage)*spec.contract_size+spec.commission_round_turn
        volume = size_volume(budget,stop_risk,spec)
        if volume:
            groups[signal['route']].append((replace(order,volume=volume),stop_risk*volume))
    orders = [order for group in groups.values() for order,_ in group]
    if not all(groups.values()):
        raise ValueError('A drawn route has no recent signals within the risk limit')
    spans = feed.session_spans(orders)
    source = feed.archive.read_zip(feed.archive.QUOTES)
    if server!=source['server'] or server!=original['server']:
        raise ValueError('Different quote source')
    inputs = dict(baseline_sha256=feed.archive.digest(study.OUT),script_sha256=feed.archive.digest(Path(__file__)),
                  clock=source['clock'],server=server,signal_ids=[o.id for o in orders])
    if capture:
        if ARCHIVE.exists():
            raise FileExistsError(ARCHIVE)
        sessions = feed.capture_quotes(spans,source)
        feed.archive.write_zip(ARCHIVE,dict(inputs=inputs,sessions=sessions))
    data = feed.archive.read_zip(ARCHIVE)
    if data['inputs']!=inputs:
        raise ValueError('Tick sample differs from frozen selection')
    ticks,witnesses = feed.verify_tape(bars,spans,data['sessions'])
    by_day = {d:[] for d in spans}
    for tick in ticks:
        by_day[tick.time.astimezone(NY).date().isoformat()].append(tick)
    base = {r['order_id']:r for r in original['scenarios']['base']['independent_orders']}
    output = {}
    for route,group in groups.items():
        comparison = []
        for order,risk in group:
            day = order.available_at.astimezone(NY).date().isoformat()
            outcome = simulate_tick_limit(order,by_day[day],spec,spans[day][1])
            pnl = outcome['pnl_net']
            if pnl is not None:
                outcome['net_r'] = pnl/risk
            bar = base[order.id]
            comparison.append(dict(id=order.id,date_ny=day,tick=outcome,m5=bar,
                                   same_exit=outcome.get('reason')==bar.get('reason') and outcome['status']==bar['status']))
        output[route] = dict(cases=comparison,tick=study.settled_summary([p['tick'] for p in comparison]),
                             m5=study.settled_summary([p['m5'] for p in comparison]),
                             same_exit_count=sum(p['same_exit'] for p in comparison))
    return dict(sample='Up to the ten latest risk-sized signals per M15 route since Oct 1 by D timestamp, without selecting on outcomes.',
                notes='Actual Bid/Ask path with modeled touch fills and assumed fees. Missing M5 reconciliation stays censored.',
                inputs=inputs,tick_archive_sha256=feed.archive.digest(ARCHIVE),coverage=witnesses,
                usable_ticks=len(ticks),coverage_counts=dict(Counter('complete' if w['reconciled'] else 'incomplete' for w in witnesses.values())),
                results=output,orders_sent=0)


if __name__=='__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture',action='store_true')
    args = parser.parse_args()
    result = run(args.capture)
    atomic_json(REPORT,result)
    for name,group in result['results'].items():
        print(name,'same',group['same_exit_count'],'ticks',group['tick'],'bars',group['m5'])
