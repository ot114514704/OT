"""Record prospective DOL choices continuously from the existing chart journal."""

import contextlib
import io
import sqlite3
import sys
import time

from scripts.shadow_ict_dol import DATABASE, FOLDER, M5, record, utc_now


def recent_receipts():
    lower = (utc_now() - 2 * M5).isoformat()
    with contextlib.closing(sqlite3.connect(DATABASE.resolve().as_uri()+'?mode=ro', uri=True, timeout=2)) as db:
        return tuple(db.execute('SELECT id,received FROM chart_batches '
                                'WHERE cutoff>? AND received IS NOT NULL ORDER BY cutoff,id', (lower,)))


def watch():
    checked = None
    last_status = None
    while True:
        status = None
        try:
            receipts = recent_receipts()
            if receipts != checked:
                output = io.StringIO()
                with contextlib.redirect_stdout(output):
                    record()
                checked = receipts
                status = output.getvalue().strip()
            error = False
        except sqlite3.OperationalError as exc:
            # Database startup/locking can be retried. A hash or model failure
            # propagates and stops the recorder instead of accepting new data.
            status = f'Chart journal unavailable: {exc}'
            error = True
        if status and status != last_status:
            print(status, file=sys.stderr if error else sys.stdout, flush=True)
            last_status = status
        time.sleep(2)


def main():
    import msvcrt

    with (FOLDER / 'watch.lock').open('a+b') as lock:
        if lock.tell() == 0:
            lock.write(b'0')
            lock.flush()
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as exc:
            raise SystemExit('The DOL shadow recorder is already running') from exc
        watch()


if __name__ == '__main__':
    main()
