"""Replay what happens after the first witnessed sweep of the nearest pool."""
from bisect import bisect_left
from collections import Counter
from datetime import datetime,timedelta
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ict_ai.sweep_response import sequence
from scripts import replay_prior_joint_months as prior
from scripts import replay_june_to_latest as june
from scripts.replay_ten_joint_rounds import joint,priority,NY,M5

OUT=joint.RESEARCH/'sweep_followthrough_20261122'
HORIZON=timedelta(hours=1)
MODEL_GROUPS={'development':prior.OUT,'validation':june.OUT}


def stamp(value):
    return datetime.fromisoformat(value)


def from_frozen(folder, datasets):
    frozen=folder/'frozen.json.gz';results=folder/'outcomes.json.gz'
    assert joint.digest(frozen)==json.loads((folder/'lock.json').read_bytes())['frozen']
    pairs=zip(joint.read_zip(frozen),joint.read_zip(results),strict=True)
    counts=Counter();episodes=[];seen=set()
    for snapshot,observed in pairs:
        at=stamp(snapshot['at'])
        assert snapshot['at']==observed['at']
        if at.astimezone(NY).strftime('%H:%M') not in june.CHECKPOINTS:continue
        if observed['short']['status']!='complete' or not snapshot['pools']:continue
        idx=snapshot['picks']['pools']['nearest']
        finish=observed['short']['pools'][idx]['sweep']
        if not finish:continue
        target=snapshot['pools'][idx]
        anchor=stamp(finish)-M5
        identity=(anchor,target['side'],target['lo'],target['hi'])
        counts['witnessed']+=1
        if identity in seen:
            counts['duplicate']+=1
            continue
        seen.add(identity)
        bars,times=datasets[snapshot['source']]
        left=bisect_left(times,anchor)
        horizon=anchor+M5+HORIZON
        later=bars[left:bisect_left(times,horizon)]
        if len(later)!=13 or any(b.time!=anchor+j*M5 for j,b in enumerate(later)):
            counts['insufficient_followup']+=1
            continue
        observation=sequence(target,bars[max(0,left-24):left],later,anchor)
        counts[observation['shape']]+=1
        counts['verified']+=1
        episodes.append(dict(known_sweep=finish,freeze=snapshot['at'],price=snapshot['price'],
                             target=target,expiry=horizon.isoformat(),source=snapshot['source'],**observation))
    return dict(counts=counts,episodes=episodes,
        sources={'forecasts':joint.digest(frozen),'observed':joint.digest(results)})


def summarize(results):
    header=['# 最近流动性目标的扫荡后结构回放','',
            '选取每个纽约检查点当时最近的流动性候选。先核实同根 M5 覆盖远端并严格越过目标，再观察后续一小时。重复的相同价区与首次越界 K 线只计一次。扫荡棒开盘前冻结最近已确认且未被收破的反向摆动，之后核对收回区间、收破摆动和一小时末保持。','',
            '|结构结果|2025-09 至 2026-03|2026-06 至 2026-11|','|---|---:|---:|']
    labels={'verified':'有效事件','reverse_held':'先收回，后反向收破，期末仍在破位一侧','reverse_failed':'先收回，后反向收破，期末撤回',
            'same_close_held':'同根收回并反向收破，期末保持','same_close_failed':'同根收回并反向收破，期末撤回',
            'reclaim_only':'收回但未反向收破','reclaim_without_reference':'收回，缺可核实的反向摆动',
            'continued_without_reclaim':'未收回，期末在远边以外','no_reclaim_flat':'未收回，期末未持续收在远边以外',
            'insufficient_followup':'后续报价不足'}
    for key,label in labels.items():
        header.append(f"|{label}|"+'|'.join(str(v['counts'][key]) for v in results.values())+'|')
    header+=['','保持按一小时末收盘核对。明细另记收破后是否曾收回，以区分期末仍在破位侧和一路站稳。同根收回和收破单列。反向摆动沿用两侧各两根确认。',
             '强位移和 FVG 仍需独立核实。该结果用于解释市场结构，未统计成交或交易收益。']
    (OUT/'扫荡后结构复盘.md').write_text('\n'.join(header)+'\n',encoding='utf-8')


def main():
    OUT.mkdir(exist_ok=True,parents=True)
    datasets={'archive':priority.read_market(),'recent':joint.load_bars()}
    results={k:from_frozen(folder,datasets) for k,folder in MODEL_GROUPS.items()}
    summarize(results)
    joint.write_zip(OUT/'events.json.gz',results)
    for key,value in results.items():
        print(key,dict(value['counts']),flush=True)
    draw_examples(results['validation']['episodes'],datasets)


def draw_examples(episodes,datasets):
    from scripts.plot_joint_round_examples import plt,font_manager,render
    font=Path('C:/Windows/Fonts/msyh.ttc')
    for f in (font,font.with_name('msyhbd.ttc')):
        font_manager.fontManager.addfont(f)
    plt.rcParams['font.family']=font_manager.FontProperties(fname=font).get_name()
    plt.rcParams['axes.unicode_minus']=False
    groups=(('reverse_held','收回后反向收破'),('reclaim_only','收回但未反向收破'),
            ('continued_without_reclaim','越过远端后延续'))
    for number,(key,label) in enumerate(groups,1):
        e=next(e for e in episodes if e['shape']==key and e['reference']
               and not e['closed_back_after_break'])
        snapshot=dict(at=e['freeze'],price=e['price'],pools=[e['target']],picks={'pools':{'nearest':0}})
        outcome=dict(end=e['expiry'],pools=[{'sweep':e['known_sweep']}])
        render(OUT/f'case-{number}.png',number,label,('pools',),snapshot,outcome,datasets[e['source']],review=e)


if __name__=='__main__':
    main()
