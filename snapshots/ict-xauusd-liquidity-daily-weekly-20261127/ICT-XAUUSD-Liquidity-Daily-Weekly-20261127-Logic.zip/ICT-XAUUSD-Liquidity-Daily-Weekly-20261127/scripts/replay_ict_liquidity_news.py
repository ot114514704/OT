"""Replay frozen liquidity omissions around observed macro release times."""
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
from statistics import median
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ict_ai.structural_liquidity import structural_ranking
from scripts import replay_ict_liquidity_misses as misses
from scripts.replay_ict_news import block, extent

context, ranking, study = misses.context, misses.ranking, misses.study
M5 = study.M5
REPORTS = ('ict_news_replay_september_20261121.json','ict_news_replay_oct_nov_20261121.json')
LEVELS = ('IRL','ERL')
CANDIDATE_FILE = 'round19_liquidity_50_candidates.json.gz'
OUTCOME_FILE = 'round19_liquidity_50_outcomes.json.gz'
VINTAGE = study.RESEARCH/'vintage_news_targets_20261122'
RECENT_DOL = study.RESEARCH/'june_november_joint_20261122'


def stamp(value):
    return datetime.fromisoformat(value).astimezone(timezone.utc)


def case_key(at, target):
    lo,hi = target['zone'] if 'zone' in target else (target['lo'],target['hi'])
    return (stamp(at),target['side'],lo,hi)


def confirmed_reaction(pre, early, scale):
    lo,hi = extent(pre)
    low,high = extent(early)
    last = early[-1].close
    change = last-pre[-1].close
    typical = median(abs(r.close-r.open) for r in pre)
    outside = 1 if last>hi else -1 if last<lo else 0
    both = high>hi and low<lo
    def strong(side):
        return any(side*(r.close-r.open)>=max(1.5*typical,.12*scale)
                   and abs(r.close-r.open)>=.60*(r.high-r.low) for r in early)
    if outside and outside*change>=.35*scale and strong(outside):
        return 'closed_directional_breakout',outside
    if both:
        return 'both_edges',0
    if lo<=last<=hi and (low<lo or high>hi):
        direction = 1 if low<lo else -1
        if direction*change>=.20*scale and strong(direction):
            return 'opposite_edge_reclaim',direction
        return 'one_edge_reclaimed',0
    return 'no_qualifying_reaction',0


def distance_bucket(value):
    return next((tag for edge,tag in ((.5,'<=0.5R'),(1,'0.5-1R'),(2,'1-2R')) if value<=edge),'>2R')


def observed_touch(prefix, target):
    return any(b.low<=target['hi'] and b.high>=target['lo'] for b in prefix)


def prior_exit(prefix, target):
    return any(target['side']*(p-misses.edge(target))>0
               for p in (b.high if target['side']>0 else b.low for b in prefix))


def live_comparison(pre, after, closed, candidates, scale):
    early = after[:closed]
    reaction,direction = confirmed_reaction(pre,early,scale)
    remaining = []
    for target,states in candidates:
        distance = target['side']*(misses.edge(target)-early[-1].close)/scale
        if distance>0 and not prior_exit(early,target):
            remaining.append((distance,target,states))
    remaining.sort(key=lambda row:(row[0],row[1]['rank']))
    aligned = next((row for row in remaining if row[1]['side']==direction),None)
    trial = None
    if aligned is not None:
        def label(row):
            distance,target,states = row
            return dict(states,decision_distance_h1=distance,
                        by30=study.contacts(target,after[closed:6],True),
                        by60=study.contacts(target,after[closed:],True))
        trial = dict(nearest=label(remaining[0]),directional=label(aligned),
                     same=remaining[0] is aligned)
    return dict(reaction=reaction,direction=direction,remaining=len(remaining),trial=trial)


def pre_release_watch(traces):
    low = [x for x in traces if x['excluded_at'] is None and x['score']<=65]
    by_distance = lambda row:(row['at_release_distance_h1'],row['original_rank'])
    nearest = sorted(low,key=by_distance)
    two_sided = []
    for side in (-1,1):
        two_sided += [x for x in nearest if x['side']==side][:2]
    two_sided.extend(x for x in nearest if x not in two_sided)
    return {name:[t['original_rank'] for t in group[:4]]
            for name,group in (('rank',low),('nearest',nearest),('two_sided',two_sided))}


def window(at, snapshots, market, prior_audit, scope, *, checkpoint=None):
    local = at.astimezone(study.NY)
    checkpoint = checkpoint or local.replace(minute=0).astimezone(timezone.utc)
    pre = block(market,at-6*M5,6)
    older = block(market,at-12*M5,6)
    later = block(market,at,12)
    before = block(market,checkpoint,(at-checkpoint)//M5)
    found = snapshots.get(checkpoint)
    if found is None or any(part is None for part in (pre,older,later,before)):
        return None
    targets = found['pools'][scope]
    if not targets:
        return None
    scale = targets[0]['hourly_range']
    pre_lo,pre_hi = extent(pre)
    old_lo,old_hi = extent(older)
    early = later[:3]
    counts = Counter()
    traces = []
    prior_followup = []
    candidates = []
    for target in targets:
        score = target['score']
        prior_key = case_key(found['at'],target)
        known_miss = prior_audit.get(prior_key)
        if target['rank']<=10 and not known_miss:
            continue
        states = {'original_rank':target['rank'],'score':score,'band':misses.band(score),
                  'side':target['side'],'zone':[target['lo'],target['hi']],'sources':target['sources'],
                  'previous_round_miss':known_miss,'excluded_at':None}
        if known_miss:
            prior_followup.append(states)
        prospective = target['rank']>10
        if prior_exit(before,target):
            states['excluded_at'] = 'before_release'
            if prospective:
                counts['removed_before_release'] += 1
                traces.append(states)
            continue
        distance = abs(misses.edge(target)-pre[-1].close)/scale
        full = study.contacts(target,later,True)
        half = study.contacts(target,later[:6],True)
        first = study.contacts(target,early,True)
        states.update(at_release_distance_h1=distance,distance_bucket=distance_bucket(distance),
                      touched_before_release=observed_touch(before,target),first15=first,first30=half,
                      first60=full)
        if not prospective:
            continue
        traces.append(states)
        if prior_exit(early,target):
            counts['removed_by_15m'] += 1
        if score<=65:
            candidates.append((target,states))
    decisions = {str(5*n):live_comparison(pre,later,n,candidates,scale) for n in (1,2,3)}
    return dict(window=local.isoformat(),frozen=checkpoint.isoformat(),scope=scope,
                observed_through_30=(at+6*M5).isoformat(),
                pre_range=[pre_lo,pre_hi],pre_range_compressed=(pre_hi-pre_lo)<=.65*(old_hi-old_lo),
                counts=counts,traces=traces,decisions=decisions,previous_miss_followup=prior_followup,
                pre_release_watch=pre_release_watch(traces))


def describe(rows):
    totals, by_score, trials = Counter(), defaultdict(Counter), defaultdict(Counter)
    watch = defaultdict(Counter)
    seen = set()
    for row in rows:
        key = (row['window'],row['scope'])
        if key in seen:
            continue
        seen.add(key)
        totals.update(windows=1,compressed=int(row['pre_range_compressed']),
                      scoped_directional=int(bool(row['decisions']['15']['direction'])),**row['counts'])
        totals['windows_with_low_score_sweep30'] += any(
            t['excluded_at'] is None and t['score']<=65 and t['first30']['sweep'] for t in row['traces'])
        totals['previously_omitted_cases'] += len(row['previous_miss_followup'])
        totals['previously_omitted_cases_swept30'] += sum(
            bool(t.get('first30',{}).get('sweep')) for t in row['previous_miss_followup'])
        for trace in row['traces']:
            if trace['excluded_at'] is not None or trace['score']>65:
                continue
            for name in (trace['band'],'all_low','distance/'+trace['distance_bucket']):
                by_score[name].update(n=1,touched30=int(bool(trace['first30']['touch'])),
                                      cleared15=int(bool(trace['first15']['sweep'])),
                                      cleared30=int(bool(trace['first30']['sweep'])),
                                      cleared60=int(bool(trace['first60']['sweep'])))
        by_rank = {t['original_rank']:t for t in row['traces']}
        for name,picks in row['pre_release_watch'].items():
            observations = [by_rank[i] for i in picks]
            watch[name].update(offers=len(picks),any30=int(any(t['first30']['sweep'] for t in observations)))
            for n in (15,30,60):
                watch[name][f'sweep{n}'] += sum(bool(t[f'first{n}']['sweep']) for t in observations)
        for delay,decision in row['decisions'].items():
            trial = decision['trial']
            if not trial:
                continue
            tally = trials[delay]
            tally.update(tested=1,same_pick=int(trial['same']))
            for choice in ('nearest','directional'):
                tally[choice+'_30'] += bool(trial[choice]['by30']['sweep'])
                tally[choice+'_60'] += bool(trial[choice]['by60']['sweep'])
    return dict(totals=totals,bands=dict(by_score),trial=trials['15'],pre_release_watch=watch,
                trials_by_minutes={key:trials[key] for key in ('5','10','15')})


def refreeze(at, bars, times, dol):
    cutoff = at-M5
    prefix = bars[bisect_left(times,cutoff-timedelta(days=63)):bisect_left(times,cutoff)]
    if not prefix or prefix[-1].time+M5!=cutoff:
        return None
    candidates = structural_ranking(prefix,cutoff,dol,limit=50,priority_uplift=True)
    return dict(at=cutoff.isoformat(),
                pools={scope:[t for t in candidates if t['classification']==scope] for scope in LEVELS})


def refrozen_windows(at, found, market):
    if found is None:
        return {scope:None for scope in LEVELS}
    return {scope:window(at,{at-M5:found},market,{},scope,checkpoint=at-M5) for scope in LEVELS}


def recent_refreeze(rows, bars, times, market, lock):
    path = RECENT_DOL/'frozen.json.gz'
    assert study.digest(path)==lock['sources'][path.relative_to(ROOT).as_posix()]
    source = [(stamp(r['at']),r['dol']) for r in study.read_zip(path)]
    assert all(a[0]<b[0] for a,b in zip(source,source[1:]))
    clocks = [s[0] for s in source]
    inputs = {}
    for row in rows:
        for at in {stamp(row['at']),*(stamp(item['window']) for listings in row['controls'].values()
                                    for item in listings)}:
            if at in inputs:
                continue
            i = bisect_right(clocks,at-M5)-1
            if i<0 or at-clocks[i]>timedelta(hours=5):
                inputs[at]=(None,{scope:None for scope in LEVELS})
                continue
            found = refreeze(at,bars,times,source[i][1])
            inputs[at]=(clocks[i].isoformat(),refrozen_windows(at,found,market))
    results = []
    for row in rows:
        ref, event = inputs[stamp(row['at'])]
        controls = {scope:[o for c in row['controls'][scope]
                    if (o:=inputs[stamp(c['window'])][1][scope])] for scope in LEVELS}
        results.append(dict(at=row['at'],event=row['event'],dol_cutoff=ref,release=event,controls=controls))
    summary = {}
    for scope in LEVELS:
        matched = [e for e in results if e['release'][scope] and e['controls'][scope]]
        summary[scope] = dict(all_releases=describe([e['release'][scope] for e in results if e['release'][scope]]),
                              matched_releases=describe([e['release'][scope] for e in matched]),
                              same_clock_controls=describe([c for e in matched for c in e['controls'][scope]]))
    return dict(source_sha256=study.digest(path),summary=summary,windows=results,
                method='M5-only fresh candidate list five minutes before release, with most recent prior DOL '
                       'context, same rule applied to event and matched controls.')


def vintage_replay(bars, times, market, market_path):
    provenance = json.loads((VINTAGE/'provenance.json').read_bytes())
    path = VINTAGE/'event_replay.json.gz'
    assert study.digest(path)==provenance['details']
    assert study.digest(market_path)==provenance['archive'][market_path.name]
    windows = []
    for release in study.read_zip(path):
        at = stamp(release['released'])
        archived = release['forecasts'].get('-5')
        if archived is None:
            continue
        found = refreeze(at,bars,times,archived['dol'])
        windows.append(dict(event=release['kind'],at=release['released'],source=release['source'],
                            known_before_cutoff=bool(release['advance_source']) and stamp(
                                release['known_from'])<=at-M5,
                            release=refrozen_windows(at,found,market)))
    summary = {scope:describe([row['release'][scope] for row in windows if row['release'][scope]])
               for scope in LEVELS}
    return dict(frozen_clock='release minus five minutes',source_sha256=study.digest(path),
                history='63-day M5 only; use contemporaneous archived DOL from the pre-release freeze.',
                summary=summary,dated_advance_subset={scope:describe(
                    [row['release'][scope] for row in windows if row['known_before_cutoff']
                     and row['release'][scope]]) for scope in LEVELS},windows=windows)


def main():
    source = study.RESEARCH
    lock_path = ranking.ARCHIVE/'round19_liquidity_50_lock.json'
    baseline_path = ranking.ARCHIVE/'round19_liquidity_baseline.json'
    lock = json.loads(lock_path.read_bytes())
    baseline = json.loads(baseline_path.read_bytes())
    cpath,opath = (ranking.ARCHIVE/p for p in (CANDIDATE_FILE,OUTCOME_FILE))
    assert study.digest(cpath)==lock['candidates']==baseline['freeze_sha256']
    assert study.digest(opath)==baseline['outcomes_sha256']
    audit_path = source/'ict_liquidity_miss_audit.json'
    audit = json.loads(audit_path.read_bytes())
    assert audit['inputs']=={CANDIDATE_FILE:lock['candidates'],OUTCOME_FILE:baseline['outcomes_sha256']}
    previous = {}
    for scope in LEVELS:
        old_rows = audit['results']['short/'+scope]['misses']
        previous[scope] = {case_key(r['at'],r['hit']):r['hit']['sweep'] for r in old_rows
                           if r['missed_by_previous']}
    market_path = next(ROOT/path for path in lock['sources'] if path.endswith('/XAUUSDM5.npz'))
    assert study.digest(market_path)==lock['sources'][market_path.relative_to(ROOT).as_posix()]
    snapshots = {stamp(row['at']):row for row in study.read_zip(cpath)}
    bars,times = context.read_market()
    market = {b.time:b for b in bars}
    rows = []
    for name in REPORTS:
        prior = json.loads((source/name).read_bytes())
        for release in prior['comparisons']:
            at = stamp(release['news']['at_ny'])
            item = dict(event=release['event'],source=release['source'],
                        at=release['news']['at_ny'],coevents=release['known_announcements_in_window'],
                        release={},controls={})
            for scope in LEVELS:
                item['release'][scope]=window(at,snapshots,market,previous[scope],scope)
                item['controls'][scope]=[result for c in release['same_clock_comparison']
                    if (result:=window(stamp(c['at_ny']),snapshots,market,previous[scope],scope))]
            rows.append(item)
    summary = {}
    for scope in LEVELS:
        released = [r['release'][scope] for r in rows if r['release'][scope]]
        matched = [r for r in rows if r['release'][scope] and r['controls'][scope]]
        controls = [c for r in matched for c in r['controls'][scope]]
        summary[scope] = dict(all_releases=describe(released),matched_releases=describe(
            [r['release'][scope] for r in matched]),same_clock_controls=describe(controls))
        print(scope,{name:(results['totals'],results['bands'].get('all_low'),results['trial'])
                     for name,results in summary[scope].items()},flush=True)
    earlier = vintage_replay(bars,times,market,market_path)
    print('Vintage:',{scope:(r['totals'],r['bands'].get('all_low'),r['trial'])
                      for scope,r in earlier['summary'].items()},flush=True)
    sensitivity = recent_refreeze(rows,bars,times,market,lock)
    print('Recent -5 minutes:',{scope:{kind:(r['totals'],r['bands'].get('all_low'),r['trial'])
                                      for kind,r in s.items()}
                                for scope,s in sensitivity['summary'].items()},flush=True)
    report = dict(inputs={p.name:study.digest(p) for p in (cpath,opath,audit_path,market_path,
                        *(source/name for name in REPORTS),Path(__file__),
                        ROOT/'ict_ai/structural_liquidity.py',ROOT/'scripts/replay_ict_news.py')},
                  protocol='Use existing official-release reports and matched weekday/NY time/offset '
                           'windows screened for known announcements. At both release and control use '
                           'the same frozen 08:00 or 14:00 list and retain original ranks 11–50. '
                           'Post-release +5/+10/+15 minutes classify already-closed reaction; later bars '
                           'through +30m or exploratory +60m determine strict sweeps. '
                           'Pre-release research watch compares equal-sized groups of up to four candidates: '
                           'original ordering, nearest outer edge, two per side with nearest fill. '
                           'Repeat controls deduplicated in summary. Event-time association only.',
                  score_cutoff=65,summary=summary,windows=rows,vintage_replication=earlier,
                  recent_checkpoint_sensitivity=sensitivity)
    (source/'ict_liquidity_news_omissions_replay.json').write_text(
        json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
