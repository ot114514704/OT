"""Attribute missing real-time M5 candidate boards to the stage with no evidence."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from contextlib import closing
from datetime import datetime
import json
from pathlib import Path
import sqlite3
import subprocess

from ict_ai.range_liquidity import _research_open
from scripts import audit_ict_bridge_latency as bridge
from scripts import watch_ict_micro_liquidity_all_m5 as source


fixed, live, M5 = source.fixed, source.live, source.M5
joint = fixed.board.joint
OUT = source.OUT / 'coverage_audit.json'
TAPE = OUT.with_suffix('.json.gz')


def power_intervals(start, end):
    # System audit data is limited to timestamps and event IDs.
    cmd = f"""
$q = @{{LogName='System';StartTime=([DateTimeOffset]'{start.isoformat()}').LocalDateTime;
EndTime=([DateTimeOffset]'{end.isoformat()}').LocalDateTime;
ProviderName=@('Microsoft-Windows-Kernel-Power','Microsoft-Windows-Power-Troubleshooter');Id=@(1,506,507)}}
$rows = @(Get-WinEvent -FilterHashtable $q -ErrorAction SilentlyContinue | Sort-Object RecordId | ForEach-Object {{
    $event = [xml]$_.ToXml()
    $data = @{{}}; foreach ($field in $event.Event.EventData.Data) {{ if ($field.Name) {{ $data[$field.Name] = $field.'#text' }} }}
    [pscustomobject]@{{id=$_.Id; at=$_.TimeCreated.ToUniversalTime().ToString('o');
                     sleep=$data['SleepTime']; wake=$data['WakeTime']}}
}})
ConvertTo-Json -InputObject $rows -Compress
"""
    result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', cmd],
                            capture_output=True, text=True, check=True, timeout=20)
    events = json.loads(result.stdout)
    intervals = []
    standby = None
    for row in events:
        if row['id'] == 506 and standby is None:
            standby = row['at']
        elif row['id'] == 507 and standby is not None:
            intervals.append(dict(kind='modern_standby', start=standby, end=row['at']))
            standby = None
        elif row['id'] == 1 and row['sleep'] and row['wake']:
            intervals.append(dict(kind='system_sleep', start=row['sleep'], end=row['wake']))
    if standby is not None:
        intervals.append(dict(kind='modern_standby_open', start=standby, end=end.isoformat()))
    return intervals


def boards(start, observed):
    uri = live.quotes.DATABASE.resolve().as_uri() + '?mode=ro'
    result = defaultdict(list)
    with closing(sqlite3.connect(uri, uri=True, timeout=4)) as db:
        for key, at, receipt in db.execute('SELECT id,cutoff,received FROM chart_batches WHERE cutoff>? AND cutoff<=?',
                                           (start.isoformat(), observed.isoformat())):
            result[at].append(dict(batch=key, received=receipt))
    return result


def stages(policy, observed, intervals):
    freeze = datetime.fromisoformat(policy['frozen_at'])
    first = datetime.fromtimestamp((int(freeze.timestamp()) // 300 + 1) * 300, freeze.tzinfo)
    batches = boards(freeze, observed)
    published = defaultdict(list)
    for path in (bridge.DIRECTORY / 'batches').glob('*.json'):
        row = fixed.read(path)
        if datetime.fromisoformat(row['file_ready']) <= observed:
            published[row['cutoff']].append(row['file_ready'])
    rows = []
    for at in (first + i * M5 for i in range((observed - first) // M5)):
        if not _research_open(at):
            continue
        end = at + M5
        stamp = at.isoformat()
        stem = f'{at:%Y%m%dT%H%M%SZ}'
        receipt = source.OUT / 'receipts' / f'{stem}.json'
        rejections = [fixed.read(path)['reason'] for path in (source.OUT / 'rejections').glob(f'{stem}_*.json')]
        eligible = [row for row in batches[stamp] if row['received'] and datetime.fromisoformat(row['received']) <= observed]
        if receipt.is_file():
            _, _, ready = source.load_board(policy, receipt)
            if ready <= observed:
                state = 'registered' if ready < end else 'registered_late'
            elif not batches[stamp]:
                state = 'no_batch'
            else:
                state = 'awaiting_receipt'
        elif not batches[stamp]:
            state = 'no_batch'
        elif not eligible:
            state = 'awaiting_receipt'
        elif all(datetime.fromisoformat(row['received']) >= end for row in eligible):
            state = 'late_chart_receipt'
        else:
            state = 'rejected' if rejections else 'acknowledged_without_local_registration'
        overlaps = set()
        for event in intervals:
            began, ended = (datetime.fromisoformat(event[k]) for k in ('start', 'end'))
            if began < end and ended > at:
                overlaps.add(event['kind'])
        rows.append(dict(cutoff=stamp, state=state, staged_batches=len(batches[stamp]), acknowledged=len(eligible),
                         publications=sorted(published[stamp]), rejections=rejections, power_overlap=sorted(overlaps)))
    return rows


def run(pid):
    policy = source.load_policy()
    observed = live.now()
    intervals = power_intervals(datetime.fromisoformat(policy['frozen_at']), observed)
    rows = stages(policy, observed, intervals)
    missing = [datetime.fromisoformat(row['cutoff']) for row in rows if row['state'] != 'registered']
    buckets = {}
    if missing:
        with fixed.open_terminal(pid) as alive:
            buckets = {at.isoformat(): bucket for at, bucket in fixed.capture_buckets(
                live.feed.mt5, alive, fixed.frozen_feed(), missing, observed)}
    counts = Counter()
    for row in rows:
        if row['state'] != 'registered':
            bucket = buckets.get(row['cutoff'])
            row['reconciled_market_bid'] = bool(bucket and bucket['ohlc'] and bucket['bid_offsets'])
            counts['missing_with_market_bid'] += row['reconciled_market_bid']
            counts['missing_overlapping_system_power_transition'] += bool(row['power_overlap'])
        counts[row['state']] += 1
    tmp = TAPE.with_suffix('.tmp')
    joint.write_zip(tmp, buckets)
    live.feed.replace_with_retry(tmp, TAPE)
    h1 = [row for row in rows if datetime.fromisoformat(row['cutoff']).minute == 0]
    report = dict(frozen_at=policy['frozen_at'], observed_at=observed.isoformat(), counts=counts, windows=len(rows),
                  h1_cutoffs=len(h1), h1_counts=Counter(row['state'] for row in h1), power_intervals=intervals,
                  input_hashes={source.POLICY.name: source.digest(source.POLICY), TAPE.name: source.digest(TAPE),
                                Path(__file__).name: source.digest(Path(__file__))}, cases=rows, orders_sent=0)
    live.atomic_json(OUT, report)
    print(json.dumps({k: report[k] for k in ('observed_at', 'windows', 'counts', 'h1_counts')}, ensure_ascii=False))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--terminal-pid', type=int, required=True)
    run(parser.parse_args().terminal_pid)
