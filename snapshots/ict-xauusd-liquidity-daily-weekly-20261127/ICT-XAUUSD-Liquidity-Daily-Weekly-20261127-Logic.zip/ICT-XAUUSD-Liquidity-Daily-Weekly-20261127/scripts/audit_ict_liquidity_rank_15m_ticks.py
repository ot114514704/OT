"""Compare score, distance and a mixed shortlist on an independently archived period."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timedelta
import json
from pathlib import Path

from scripts import audit_ict_liquidity_rank_prev_period as prior
from scripts import audit_ict_repo_vs_local_horizons as shared


fixed, live, joint, board, rank = prior.fixed, prior.live, prior.joint, prior.board, prior.rank
OUT = prior.OUT.with_name('ict_liquidity_rank_15m_ticks_20261125.json')
TAPE = OUT.with_suffix('.json.gz')
M5 = fixed.M5
DELAYS = (30, 60)


def starts_at(at):
    return [at + index * M5 for index in range(3)]


def evidence_for(tasks, pid):
    before = fixed.read(prior.OUT)
    shared_results = fixed.read(shared.OUT)
    pins = {p.name: joint.digest(p) for p in (prior.OUT, prior.BID, shared.OUT, shared.BID,
                                             Path(board.__file__), Path(rank.__file__), Path(__file__))}
    if (before['inputs'][prior.BID.name] != pins[prior.BID.name]
            or shared_results['bid_sha256'] != pins[shared.BID.name]):
        raise ValueError('Historical quotation archives changed')
    if pid is None:
        data = joint.read_zip(TAPE)
        if data['pins'] != pins:
            raise ValueError('The saved evidence references different inputs')
        return data

    known = joint.read_zip(prior.BID)['buckets']
    supplemental = joint.read_zip(shared.BID)['buckets']
    wanted = {at.isoformat() for _, row, _ in tasks for at in starts_at(datetime.fromisoformat(row['at']))}
    buckets = {stamp: known.get(stamp, supplemental.get(stamp)) for stamp in sorted(wanted)}
    needed = [datetime.fromisoformat(stamp) for stamp, quote in buckets.items() if quote is None]
    captured = live.now()
    if needed:
        with fixed.open_terminal(pid) as alive:
            buckets.update({at.isoformat(): quote for at, quote in fixed.capture_buckets(
                live.feed.mt5, alive, fixed.frozen_feed(), needed, captured)})
    data = dict(captured_at=captured.isoformat(), pins=pins, sources=dict(previous=sum(t in known for t in wanted),
                matched_window_archive=sum(t not in known and t in supplemental for t in wanted),
                newly_captured=sum(buckets[t.isoformat()] is not None for t in needed)), buckets=buckets)
    staging = TAPE.with_suffix('.tmp')
    joint.write_zip(staging, data)
    live.feed.replace_with_retry(staging, TAPE)
    print(f'Found {sum(value is not None for value in buckets.values())}/{len(buckets)} historical M5 Bid buckets', flush=True)
    return data


def compare(rebuilt, historical, tape):
    at = datetime.fromisoformat(rebuilt['at'])
    raw = dict(cutoff=rebuilt['at'], early=rebuilt['after'], baseline=rebuilt['before'])
    result = dict(cutoff=rebuilt['at'], ny_date=historical['ny_date'], delays={})
    for seconds in DELAYS:
        ready = at + timedelta(seconds=seconds)
        first = fixed.grade(raw, ready, tape[:1], 1)
        quarter = fixed.grade(raw, ready, tape, 3)
        if first['state'] != 'scored' or quarter['state'] != 'scored':
            raise ValueError(f'Reconciled window did not score: {at}')
        markets = {}
        for scope in board.SCOPES:
            price = historical['frozen_price']
            actual = prior.measure_scope(raw['early'][scope], first['outcomes']['early'][scope], price)
            for field in ('first_bid_ms', 'picks', 'hits', 'winners'):
                if json.dumps(actual[field]) != json.dumps(historical['delay'][str(seconds)][scope][field]):
                    raise ValueError(f'Original first M5 did not reproduce at {at}, {scope}')
            marks = quarter['outcomes']['early'][scope]
            first_ms, winners = rank.first_strict(marks)
            picked = rank.picks(raw['early'][scope], price)
            markets[scope] = dict(first_bid_ms=first_ms, winners=sorted(winners), picks=picked,
                                  hits={key: bool(winners.intersection(value)) for key, value in picked.items()})
        result['delays'][str(seconds)] = markets
    return result


def summarize(cases):
    result = {}
    for seconds in map(str, DELAYS):
        by_scope = {}
        for scope in board.SCOPES:
            rows = [case['delays'][seconds][scope] for case in cases]
            totals = rank.summarize([{**row, 'winning_edges': row['winners']} for row in rows if row['winners']], len(rows))
            weeks = defaultdict(Counter)
            for case, row in zip(cases, rows, strict=True):
                day = datetime.fromisoformat(case['ny_date']).date()
                week = (day - timedelta(days=day.weekday())).isoformat()
                weeks[week].update(windows=1, with_first_crossing=int(bool(row['winners'])))
                weeks[week].update({method: int(hit) for method, hit in row['hits'].items()})
            by_scope[scope] = dict(**totals, ny_weeks=weeks)
        result[seconds] = by_scope
    return result


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture-terminal-pid', type=int)
    args = parser.parse_args()
    tasks = prior.load_checkpoints()
    archive = evidence_for(tasks, args.capture_terminal_pid)
    original = fixed.read(prior.OUT)
    by_cutoff = {case['cutoff']: case for case in original['cases']}
    prices, _ = board.original.priority.read_market()
    ohlc = {bar.time: list(live.quotes.ohlc(bar)) for bar in prices}
    included, excluded = [], {}
    tapes = {}
    for i, (snapshot, saved, _) in enumerate(tasks):
        stamp = saved['at']
        starts = starts_at(datetime.fromisoformat(stamp))
        tape = [archive['buckets'].get(at.isoformat()) for at in starts]
        if (stamp not in by_cutoff or any(at not in ohlc or item is None or item['ohlc'] != ohlc[at]
                                        for at, item in zip(starts, tape, strict=True))):
            excluded[stamp] = 'unverified_ohlc_or_bid'
            continue
        included.append((snapshot, saved, i % 25 == 0))
        tapes[stamp] = tape
    cases = []
    with ProcessPoolExecutor(max_workers=4, initializer=board.initialize) as pool:
        for item in pool.map(board.replay, included, chunksize=4):
            stamp = item['at']
            cases.append(compare(item, by_cutoff[stamp], tapes[stamp]))
    totals = summarize(cases)
    report = dict(start=original['start'], end_exclusive=original['end_exclusive'], sources=archive['sources'],
                  inputs=archive['pins'] | {TAPE.name: joint.digest(TAPE)}, results=totals, excluded=excluded, cases=cases,
                  method='Same archived top-ten candidate board per scope; earliest strict post-delay Bid sweep in three consecutive M5 candles.',
                  orders_sent=0)
    live.atomic_json(OUT, report)
    print(json.dumps(dict(results={lag: {scope: {k: v for k, v in cell.items() if k != 'ny_weeks'}
                                        for scope, cell in scopes.items()} for lag, scopes in totals.items()},
                          excluded=excluded)), flush=True)


if __name__ == '__main__':
    main()
