"""Read-only two-month TMGM replay for the production 1.34 liquidity lists."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter, defaultdict
from contextlib import closing
from datetime import datetime, time, timedelta, timezone
from pathlib import Path
import json
import math
import sqlite3

import numpy as np

from brooks_ai.types import Bar
from ict_ai.range_liquidity import M5, _Coverage
from ict_ai.timebase import NY, manifest_epoch_to_utc
from scripts.audit_ipda_gap_ticks import TERMINAL, raw_epoch
from scripts import check_pool_priority as market
from scripts.replay_ict_liquidity_rank import ARCHIVE
from scripts.replay_pool_and_dol import ROOT, RESEARCH, digest, read_zip, write_zip
from scripts.serve_ict_live import atomic_json


OUT = RESEARCH / 'ict_liquidity_account_20261124'
CANDIDATES = ARCHIVE / 'round19_liquidity_50_candidates.json.gz'
CANDIDATE_LOCK = ARCHIVE / 'round19_liquidity_50_lock.json'
CLOCK = ROOT / 'research/live_clock_20261116.json'
DATABASE = RESEARCH / 'ranked_dol/live.sqlite3'
CHECKPOINTS = {'00:05', '02:00', '08:00', '10:00', '14:00'}
UTC = timezone.utc
INITIAL_BALANCE = 1000.0
VOLUME = 0.01
STOP = 20.0
COSTS = {'no_fee_no_slip': (0., 0.), 'baseline': (7., .10), 'stress': (7., .25)}


def ohlc(bar):
    return [bar.open, bar.high, bar.low, bar.close]


def near(pool):
    return pool['lo'] if pool['side'] == 1 else pool['hi']


def far(pool):
    return pool['hi'] if pool['side'] == 1 else pool['lo']


def excursion(bar, side):
    return bar.high if side == 1 else bar.low


def observed_reclaim(pool, bars):
    """Round 19 first strict witnessed excursion, then outer-edge reclaim."""
    edge, side = far(pool), pool['side']
    for index, bar in enumerate(bars):
        if side * (excursion(bar, side) - edge) <= 0:
            continue
        if not bar.low <= edge <= bar.high:
            return None
        for offset, reaction in enumerate(bars[index:index + 4]):
            if reaction.time != bar.time + offset * M5:
                break
            if side * (reaction.close - edge) < 0:
                return bar.time + M5, reaction.time + M5
        break
    return None


def close_boundary(stamp):
    local = stamp.astimezone(NY)
    # Exit before the daily pause. Friday uses the earlier quote archive boundary.
    return datetime.combine(local.date(), time(16, 45), NY).astimezone(UTC)


def planned_checkpoints(start, end):
    day = start.astimezone(NY).date()
    while day <= end.astimezone(NY).date():
        if day.weekday() < 5:
            for clock in sorted(CHECKPOINTS):
                stamp = datetime.combine(day, time.fromisoformat(clock), NY)
                if start <= stamp < end:
                    yield stamp
        day += timedelta(days=1)


def verify_sources():
    lock = json.loads(CANDIDATE_LOCK.read_bytes())
    keys = ('ict_ai/structural_liquidity.py', 'ict_ai/target_priority.py', 'ict_ai/range_liquidity.py')
    for path, expected in [(CANDIDATES, lock['candidates']), *((ROOT / k, lock['sources'][k]) for k in keys)]:
        if digest(path) != expected:
            raise ValueError(f'Liquidity version or archive changed: {path}')


def freezes(start, end, old_end):
    verify_sources()
    frozen = []
    for row in read_zip(CANDIDATES):
        at = datetime.fromisoformat(row['at'])
        if start <= at < end and at.astimezone(NY).strftime('%H:%M') in CHECKPOINTS:
            pools = [dict(p, scope=scope) for scope, ranked in row['pools'].items() for p in ranked[:10]]
            frozen.append(dict(at=row['at'], ready=(at + M5).isoformat(), price=row['price'], pools=pools,
                               source='round19_production_134'))
    with closing(sqlite3.connect(DATABASE.resolve().as_uri() + '?mode=ro', uri=True)) as db:
        for batch, stamp, received, payload in db.execute(
                'SELECT id,cutoff,received,payload FROM chart_batches WHERE received IS NOT NULL ORDER BY cutoff'):
            at, seen = map(datetime.fromisoformat, (stamp, received))
            if not old_end < at < end or not at <= seen < end:
                continue
            if at.astimezone(NY).strftime('%H:%M') not in CHECKPOINTS:
                continue
            row = json.loads(payload)
            if row['at'] != stamp or seen >= at + 2 * M5:
                continue
            ready = at + (M5 if seen <= at + M5 else 2 * M5)
            pools = [dict(p, scope=p['scope'].upper()) for p in row['pools']]
            frozen.append(dict(at=stamp, ready=ready.isoformat(), received=received, price=row['price'],
                               pools=pools, source='production_chart_receipt', batch=batch))
    return sorted(frozen, key=lambda row: row['at'])


def signals(frozen, bars, start, end, *, entry_scope=None):
    times = [bar.time for bar in bars]
    coverage = _Coverage(times[0], end, bars, M5)
    findings = defaultdict(list)
    counts = Counter()
    audited = 0
    for row in frozen:
        at, ready = map(datetime.fromisoformat, (row['at'], row['ready']))
        index = bisect_left(times, at)
        if not index or bars[index - 1].time + M5 != at or abs(bars[index - 1].close - row['price']) > 1e-8:
            raise ValueError(f'Freeze/publication disagrees with broker chart at {at}')
        deadline = min(at + timedelta(hours=4), close_boundary(at))
        if not start <= at < ready < min(deadline, end):
            counts['unavailable_window'] += 1
            continue
        future = bars[index:bisect_left(times, min(deadline, end))]
        prior = [bar for bar in future if bar.time < ready]
        trade_window = [bar for bar in future if bar.time >= ready]
        for pool in row['pools']:
            if entry_scope is not None and pool['scope'] != entry_scope:
                continue
            side = pool['side']
            if any(side * (excursion(b, side) - far(pool)) > 0 for b in prior):
                counts['swept_before_publication'] += 1
                continue
            evidence = observed_reclaim(pool, trade_window)
            if evidence is None:
                continue
            sweep_at, known = evidence
            if coverage.gap(at, known) or known >= min(deadline, end):
                counts['incomplete_or_expired_at_signal'] += 1
                continue
            visible = [bar for bar in future if bar.time + M5 <= known]
            prefix = [bar for bar in visible if bar.time >= ready]
            if observed_reclaim(pool, prefix) != evidence or observed_reclaim(pool, prefix[:-1]) is not None:
                raise AssertionError(f'Unstable liquidity signal at {known}')
            audited += 2
            direction = -side
            price = visible[-1].close
            opposing = [p for p in row['pools'] if p['side'] == direction and direction * (near(p) - price) > 0
                        and all(direction * (excursion(b, direction) - near(p)) < 0 for b in visible)]
            if not opposing:
                counts['no_untouched_opposite_liquidity'] += 1
                continue
            target = min(opposing, key=lambda p: (direction * (near(p) - price), p['rank'], p['scope']))
            findings[known].append(dict(signal_at=known.isoformat(), sweep_at=sweep_at.isoformat(), cutoff=row['at'],
                                        deadline=deadline.isoformat(), direction=direction, signal_close=price,
                                        pool=pool, target=target, limit=near(target), source=row['source']))
    selected = []
    for at, candidates in sorted(findings.items()):
        if len({c['direction'] for c in candidates}) > 1:
            counts['opposite_signals_same_close'] += 1
            continue
        key = lambda c: (c['pool']['rank'], -c['pool']['score'], c['pool']['scope'], -datetime.fromisoformat(c['cutoff']).timestamp())
        selected.append(min(candidates, key=key))
        counts['extra_candidates_same_close'] += len(candidates) - 1
    return selected, dict(counts), audited


def checked_terminal(api, identity=None):
    account, terminal = api.account_info(), api.terminal_info()
    if account is None or terminal is None or not terminal.connected or account.server != 'TradeMaxGlobal-Live':
        raise RuntimeError('Connected TMGM historical archive server is required')
    if identity is not None and (account.login, account.server) != identity:
        raise RuntimeError('MT5 account or connection changed during capture')
    return account


def collect_bars(api, start, cutoff, clock):
    raw_start, raw_end = (datetime.fromtimestamp(raw_epoch(t, clock), UTC) for t in (start - M5, cutoff))
    rates = api.copy_rates_range('XAUUSD', api.TIMEFRAME_M5, raw_start, raw_end)
    if rates is None or not len(rates):
        raise RuntimeError(f'Missing TMGM M5: {api.last_error()}')
    bars = []
    for row in rates:
        at = manifest_epoch_to_utc(datetime.fromtimestamp(int(row['time']), UTC), clock)
        if at + M5 <= cutoff:
            bars.append(Bar(at, *(float(row[k]) for k in ('open', 'high', 'low', 'close')), 0))
    times = [bar.time for bar in bars]
    if not times or times != sorted(set(times)):
        raise ValueError('Empty or non-monotone MT5 M5')
    return bars


def execution_spans(trade_signals, cutoff):
    spans = []
    for row in trade_signals:
        start = datetime.fromisoformat(row['signal_at'])
        end = min(cutoff, datetime.fromisoformat(row['deadline']) + M5)
        # Include the deadline bar so the market exit quote can be verified.
        if spans and start <= spans[-1][1]:
            spans[-1] = spans[-1][0], max(spans[-1][1], end)
        else:
            spans.append((start, end))
    return spans


def capture_ticks(api, start, end, clock):
    chunks = []
    cursor = start
    while cursor < end:
        until = min(end, cursor + timedelta(hours=1))
        a, b = raw_epoch(cursor, clock), raw_epoch(until, clock)
        if b - a != (until - cursor).total_seconds():
            raise ValueError('Tick span crosses a broker offset boundary')
        raw = api.copy_ticks_range('XAUUSD', datetime.fromtimestamp(a, UTC),
                                   datetime.fromtimestamp(b, UTC), api.COPY_TICKS_INFO)
        if raw is None:
            raise RuntimeError(f'Missing quote span at {cursor}: {api.last_error()}')
        valid = (raw['time_msc'] >= a * 1000) & (raw['time_msc'] < b * 1000)
        ticks = raw[valid]
        actual = ticks['time_msc'] - (a - int(cursor.timestamp())) * 1000
        chunks.append((actual, ticks['bid'], ticks['ask']))
        cursor = until
    stamps, bids, asks = (np.concatenate(parts) for parts in zip(*chunks, strict=True))
    if np.any(stamps[1:] < stamps[:-1]) or not np.isfinite(bids).all() or not np.isfinite(asks).all():
        raise ValueError(f'Invalid quote history at {start}')
    # Preserve original ordinal inside the same millisecond.
    available = (bids > 0) & (asks >= bids)
    return stamps[available], bids[available], asks[available]


def capture():
    import MetaTrader5 as api

    if (OUT / 'capture.json').exists():
        raise ValueError('This study capture already exists')
    OUT.mkdir(parents=True, exist_ok=True)
    policy = json.loads(CLOCK.read_bytes())
    if not api.initialize(str(TERMINAL), timeout=10000):
        raise RuntimeError(f'TMGM MT5 unavailable: {api.last_error()}')
    try:
        account = checked_terminal(api)
        identity = account.login, account.server
        info = api.symbol_info('XAUUSD')
        meta = {key: getattr(info, key) for key in ('trade_contract_size', 'trade_tick_size', 'volume_min',
                'volume_step', 'currency_profit', 'trade_stops_level')}
        tick = api.symbol_info_tick('XAUUSD')
        if (account.currency, meta['currency_profit']) != ('USD', 'USD') or info.trade_contract_size != 100:
            raise ValueError('USD account and 100 oz XAUUSD contract required for this study')
        if info.volume_min > VOLUME or not math.isclose(VOLUME / info.volume_step, round(VOLUME / info.volume_step)):
            raise ValueError('Requested fixed volume is not admissible on the current contract')
        now = datetime.now(UTC)
        latest = manifest_epoch_to_utc(datetime.fromtimestamp(tick.time, UTC), policy)
        if not timedelta(seconds=-1) <= now - latest <= timedelta(minutes=1):
            raise ValueError('Current quote is stale under the archived TMGM clock mapping')
        end = datetime.fromtimestamp(int(latest.timestamp()) // 300 * 300, UTC)
        cst = timezone(timedelta(hours=8))
        local_end = end.astimezone(cst)
        start = local_end.replace(year=2026, month=9, day=24).astimezone(UTC)
        bars = collect_bars(api, start, end, policy)
        if bars[-1].time + M5 != end:
            raise RuntimeError('Latest closed M5 unavailable')
        old, _ = market.read_market()
        chart = {b.time: ohlc(b) for b in bars}
        overlap = [b for b in old if bars[0].time <= b.time <= old[-1].time]
        if not overlap or any(chart.get(b.time) != ohlc(b) for b in overlap):
            raise ValueError('TMGM M5 overlap does not reproduce the historical archive')
        frozen = freezes(start, end, old[-1].time + M5)
        picked, excluded, checks = signals(frozen, bars, start, end)
        bar_file, pool_file = OUT / 'm5.json.gz', OUT / 'pools.json.gz'
        write_zip(bar_file, [[b.time.isoformat(), *ohlc(b)] for b in bars])
        write_zip(pool_file, frozen)
        plan = dict(server=account.server, leverage=account.leverage, account_currency=account.currency,
                    observed_contract=meta, start=start.isoformat(), cutoff=end.isoformat(),
                    market_bars=len(bars), verified_m5_overlap=len(overlap), freeze_sources=dict(Counter(s['source'] for s in frozen)),
                    captures={}, inputs={p.name: digest(p) for p in (bar_file, pool_file, CANDIDATE_LOCK, CLOCK)},
                    audit=dict(signal_exclusions=excluded, prefix_checks=checks), orders_sent=0)
        print(f'{len(frozen)} snapshots and {len(picked)} quote windows to settle from {start} to {end}', flush=True)
        for idx, (a, b) in enumerate(execution_spans(picked, end), 1):
            checked_terminal(api, identity)
            path = OUT / f'quotes_{idx:03}.npz'
            stamps, bids, asks = capture_ticks(api, a, b, policy)
            np.savez_compressed(path, stamp=stamps, bid=bids, ask=asks)
            plan['captures'][path.name] = dict(start=a.isoformat(), end=b.isoformat(), ticks=len(stamps), sha256=digest(path))
            if idx % 10 == 0:
                print(f'{idx} quote spans saved, last {b}', flush=True)
        checked_terminal(api, identity)
        atomic_json(OUT / 'capture.json', plan)
    finally:
        api.shutdown()


def time_ms(stamp):
    return round(stamp.timestamp() * 1000)


def verify_quote_bars(stamps, bids, chart, start, end):
    """Identify open M5s with missing or disagreeing ticks against chart Bid."""
    first, last = time_ms(start), time_ms(end)
    boundaries = np.arange(first, last + 1, 300000)
    cuts = np.searchsorted(stamps, boundaries)
    gaps = set()
    matched = 0
    for opened, lo, hi in zip(boundaries[:-1], cuts[:-1], cuts[1:], strict=True):
        reference = chart.get(int(opened))
        if reference is None and lo == hi:
            continue
        if reference is not None and lo < hi:
            quotes = bids[lo:hi]
            observed = [quotes[0], quotes.max(), quotes.min(), quotes[-1]]
            if np.allclose(observed, reference, rtol=0, atol=1e-8):
                matched += 1
                continue
        gaps.add(int(opened))
    return matched, gaps


def settle_signal(row, tape, cutoff, slippage, fee, units, *, stop_distance=STOP):
    stamps, bids, asks = tape
    start = time_ms(datetime.fromisoformat(row['signal_at']))
    deadline = time_ms(datetime.fromisoformat(row['deadline']))
    closing = min(deadline, time_ms(cutoff))
    entry = int(np.searchsorted(stamps, start))
    closing_index = int(np.searchsorted(stamps, closing))
    if entry == len(stamps) or stamps[entry] >= min(closing, start + 300000):
        return 'unavailable_entry_quote', None
    if 'entry_before_ms' in row and stamps[entry] >= row['entry_before_ms']:
        return 'entry_after_time_window', None
    side, target = row['direction'], row['limit']
    quoted_entry = (asks if side == 1 else bids)[entry]
    price = round(float(quoted_entry) + side * slippage, 2)
    exit_quotes = bids if side == 1 else asks
    if side * (target - price) <= 0 or side * (target - exit_quotes[entry]) <= 0:
        return 'target_already_at_or_past_entry', None
    stop = round(price - side * stop_distance, 2)
    if 'protected_extreme' in row and side * (row['protected_extreme'] - stop) < .01 - 1e-8:
        return 'fixed_stop_inside_protected_structure', None
    active = exit_quotes[entry:closing_index]
    distance = side * (active - stop)
    hits = np.flatnonzero((distance <= 1e-8) | (side * (active - target) >= -1e-8))
    if hits.size:
        index = entry + int(hits[0])
        hit_stop = distance[hits[0]] <= 1e-8
        reason = 'stop' if hit_stop else row.get('target_kind', 'opposite_liquidity')
        fill = round(float(exit_quotes[index]) - side * slippage, 2) if hit_stop else target
    elif closing < time_ms(cutoff):
        index = closing_index
        if index == len(stamps) or stamps[index] >= closing + 300000:
            return 'unavailable_deadline_quote', None
        reason = 'time_exit'
        fill = round(float(exit_quotes[index]) - side * slippage, 2)
    else:
        index = closing_index - 1
        reason = 'sample_end_mark'
        fill = round(float(exit_quotes[index]) - side * slippage, 2)
    gross = round(side * (fill - price) * units, 8)
    net = round(gross - fee, 8)
    marked = side * (exit_quotes[entry:index] - price) * units - fee
    entry_at, exit_at = (datetime.fromtimestamp(int(stamps[i]) / 1000, UTC).isoformat(timespec='milliseconds')
                         for i in (entry, index))
    return 'settled', (dict(row, entry_at=entry_at, exit_at=exit_at,
                            entry_at_ms=int(stamps[entry]), exit_at_ms=int(stamps[index]), entry=price,
                            entry_spread=round(float(asks[entry] - bids[entry]), 4), stop=stop, exit=fill,
                            exit_reason=reason, gross_usd=gross, commission_usd=fee, net_usd=net), marked)


def summarize(trades, max_drawdown, max_drawdown_pct, counts, *, initial_balance=INITIAL_BALANCE):
    profits = [row['net_usd'] for row in trades]
    wins = sum(p > 0 for p in profits)
    losses = sum(p < 0 for p in profits)
    winning = sum(p for p in profits if p > 0)
    losing = -sum(p for p in profits if p < 0)
    streak = longest = 0
    breakdown = defaultdict(lambda: dict(trades=0, wins=0, net_usd=0.))
    for row, value in zip(trades, profits, strict=True):
        streak = streak + 1 if value < 0 else 0
        longest = max(longest, streak)
        month = datetime.fromisoformat(row['signal_at']).astimezone(NY).strftime('%Y-%m')
        for key in (row['pool']['scope'], month, 'long' if row['direction'] == 1 else 'short'):
            item = breakdown[key]
            item['trades'] += 1
            item['wins'] += value > 0
            item['net_usd'] = round(item['net_usd'] + value, 2)
    return dict(start_usd=initial_balance, end_usd=round(initial_balance + sum(profits), 2), net_usd=round(sum(profits), 2),
                return_pct=round(100 * sum(profits) / initial_balance, 2), trades=len(trades), wins=wins, losses=losses,
                win_rate_pct=round(100 * wins / len(trades), 2) if trades else None,
                profit_factor=round(winning / losing, 4) if losing else None,
                max_drawdown_usd=round(max_drawdown, 2), max_drawdown_pct=round(max_drawdown_pct, 2), longest_loss_streak=longest,
                largest_loss_usd=round(min(profits), 2) if profits else None,
                exits=dict(Counter(t['exit_reason'] for t in trades)), skipped=dict(counts), breakdown=dict(breakdown), ledger=trades)


def locked_capture():
    plan_path = OUT / 'capture.json'
    plan = json.loads(plan_path.read_bytes())
    for path in (OUT / 'pools.json.gz', OUT / 'm5.json.gz', CLOCK, CANDIDATE_LOCK):
        if digest(path) != plan['inputs'][path.name]:
            raise ValueError(f'Study input changed: {path}')
    verify_sources()
    start, end = (datetime.fromisoformat(plan[k]) for k in ('start', 'cutoff'))
    bars = [Bar(datetime.fromisoformat(t), o, h, l, c, 0) for t, o, h, l, c in read_zip(OUT / 'm5.json.gz')]
    frozen = read_zip(OUT / 'pools.json.gz')
    return plan_path, plan, bars, frozen, start, end


def simulate_accounts(picked, bars, plan, end, *, initial_balance=INITIAL_BALANCE, stop_distance=STOP,
                      trace=False, quote_dir=OUT):
    if initial_balance <= 0 or stop_distance <= 0:
        raise ValueError('Initial balance and stop distance must be positive')
    chart = {time_ms(bar.time): ohlc(bar) for bar in bars}
    units = plan['observed_contract']['trade_contract_size'] * VOLUME
    states = {scenario:dict(balance=initial_balance, peak=initial_balance, dd=0., dd_pct=0., occupied=-1,
                            trades=[], counts=Counter()) for scenario in COSTS}
    quote_audit = Counter()
    coverage = _Coverage(bars[0].time, end, bars, M5)
    times = [datetime.fromisoformat(s['signal_at']) for s in picked]
    classified = defaultdict(list)
    decisions = defaultdict(list)
    matched_signals = 0
    last_quotes = {}
    previous_end = None
    for name, item in plan['captures'].items():
        a, b = map(datetime.fromisoformat, (item['start'], item['end']))
        if a >= b or (previous_end is not None and a < previous_end):
            raise ValueError('Tick spans must be non-overlapping and chronological')
        previous_end = b
        batch = picked[bisect_left(times, a):bisect_left(times, b)]
        if not batch:
            continue
        latest_deadline = max(datetime.fromisoformat(row['deadline']) for row in batch)
        if min(end, latest_deadline + M5) > b:
            raise ValueError(f'Tick span misses the settlement horizon at {latest_deadline}')
        path = quote_dir / name
        if digest(path) != item['sha256']:
            raise ValueError(f'Tick archive changed: {path}')
        with np.load(path) as q:
            tape = q['stamp'], q['bid'], q['ask']
        quote_audit['quotes'] += len(tape[0])
        matched, gaps = verify_quote_bars(tape[0], tape[1], chart, a, b)
        quote_audit.update(m5_matched=matched, m5_missing_or_disagrees=len(gaps))
        if trace and len(tape[0]):
            buckets = tape[0] // 300000 * 300000
            last_tick = np.r_[np.flatnonzero(buckets[1:] != buckets[:-1]), len(buckets) - 1]
            last_quotes.update({int(buckets[i]): (float(tape[1][i]), float(tape[2][i]))
                                for i in last_tick if int(buckets[i]) not in gaps})
        matched_signals += len(batch)
        for row in batch:
            stamp = datetime.fromisoformat(row['signal_at'])
            at_ms = time_ms(stamp)
            for scenario, (commission, slippage) in COSTS.items():
                state = states[scenario]
                decision = dict(signal_at=row['signal_at'], cash_usd=round(state['balance'], 2))
                if trace:
                    decisions[scenario].append(decision)
                if at_ms <= state['occupied']:
                    state['counts']['one_position_limit'] += 1
                    decision['status'] = 'one_position_limit'
                    continue
                mark = row['signal_close'] * units / plan['leverage']
                decision['minimum_equity_usd'] = round(max(mark, stop_distance + commission * VOLUME), 8)
                if state['balance'] < decision['minimum_equity_usd']:
                    state['counts']['insufficient_modeled_equity'] += 1
                    decision['status'] = 'insufficient_modeled_equity'
                    continue
                status, result = settle_signal(row, tape, end, slippage, commission * VOLUME, units,
                                               stop_distance=stop_distance)
                if result is None:
                    state['counts'][status] += 1
                    decision['status'] = status
                    if status == 'unavailable_deadline_quote':
                        state['occupied'] = min(time_ms(end), time_ms(datetime.fromisoformat(row['deadline'])) + 300000)
                        classified[scenario].append(dict(signal_at=row['signal_at'], status=status))
                    continue
                trade, marked = result
                needed_end_ms = (trade['exit_at_ms'] // 300000 + 1) * 300000
                needed_end = datetime.fromtimestamp(needed_end_ms / 1000, UTC)
                state['occupied'] = trade['exit_at_ms']
                if coverage.gap(stamp, needed_end) or any(at_ms <= t < needed_end_ms for t in gaps):
                    state['counts']['unverified_execution_path'] += 1
                    decision['status'] = 'unverified_execution_path'
                    classified[scenario].append(dict(signal_at=row['signal_at'], through=needed_end.isoformat(),
                                                     status='unverified_execution_path'))
                    continue
                pnl = trade['net_usd']
                equity = np.r_[state['peak'], state['balance'] + marked, state['balance'] + pnl]
                peak = np.maximum.accumulate(equity)
                state['dd'] = max(state['dd'], float(np.max(peak - equity)))
                state['dd_pct'] = max(state['dd_pct'], float(np.max(100 * (peak - equity) / peak)))
                state['peak'] = float(peak[-1])
                state['balance'] = round(state['balance'] + pnl, 8)
                state['trades'].append(dict(trade, balance_usd=round(state['balance'], 2)))
                decision.update(status='executed', trade=len(state['trades']))
    if matched_signals != len(picked):
        raise ValueError('Captured Bid/Ask tape does not cover each replay signal exactly once')
    results = {k:summarize(s['trades'], s['dd'], s['dd_pct'], s['counts'], initial_balance=initial_balance)
               for k, s in states.items()}
    for name, result in results.items():
        result['execution_coverage_exclusions'] = classified[name]
        result['commission_round_turn_per_lot'], result['slippage_per_market_side'] = COSTS[name]
        if trace:
            result['decisions'] = decisions[name]
    return results, dict(quote_audit), last_quotes


def replay():
    plan_path, plan, bars, frozen, start, end = locked_capture()
    picked, excluded, checks = signals(frozen, bars, start, end)
    if dict(signal_exclusions=excluded, prefix_checks=checks) != plan['audit']:
        raise ValueError('Frozen quote windows did not reproduce the original signals')
    expected_spans = execution_spans(picked, end)
    actual_spans = [tuple(datetime.fromisoformat(x[k]) for k in ('start', 'end')) for x in plan['captures'].values()]
    if actual_spans != expected_spans:
        raise ValueError('Captured quote spans differ from the frozen baseline')
    results, quote_audit, _ = simulate_accounts(picked, bars, plan, end)
    coverage = _Coverage(bars[0].time, end, bars, M5)
    expected = set(planned_checkpoints(start, end))
    have = {datetime.fromisoformat(row['at']) for row in frozen}
    if have - expected or len(have) != len(frozen):
        raise ValueError('Unexpected or duplicate liquidity snapshot')
    report = dict(period=dict(start=plan['start'], cutoff=plan['cutoff']), version='MT5 liquidity 1.34 / archived Round 19',
                  checkpoints=dict(scheduled=len(expected), available=len(have),
                                   missing_ny=[s.isoformat() for s in sorted(expected - have)]),
                  methodology=dict(signal='Round 19: witnessed strict Bid breach of frozen IRL/ERL top ten far edge, then outer-edge reclaim on the sweep M5 or next three contiguous M5 closes.',
                                   research_execution='Reverse after reclaim at the first subsequent executable quote; nearest previously untouched opposite liquidity near edge, 20 USD/oz fixed stop, at most one position. Exit by the earlier of four hours from freeze and NY 16:45.',
                                   dependencies='The production liquidity ranking retains its existing internal score components. No DOL entry condition, DOL target or pullback trigger is used.',
                                   timing='Five fixed NY checkpoints per day. Prior snapshots use a five-minute publication allowance; later snapshots use original receipts rounded to an M5 opening.',
                                   costs='Observed Bid/Ask; scenario commission and adverse slippage per market side; no overnight exposure. Current margin leverage used as an approximation.'),
                  contract=plan['observed_contract'], leverage=plan['leverage'], initial_balance_usd=INITIAL_BALANCE,
                  volume=VOLUME, stop_from_fill=STOP, signals=len(picked), signal_exclusions=excluded, prefix_checks=checks,
                  freeze_sources=plan['freeze_sources'], covered_candidate_dates=len({s['at'][:10] for s in frozen}),
                  quote_audit=dict(quote_audit), chart_bars=len(bars), chart_missing_expected_m5=coverage.missing[-1],
                  verified_m5_overlap=plan['verified_m5_overlap'], scenarios=results,
                  capture_sha256=digest(plan_path), code_sha256=digest(Path(__file__)), orders_sent=0)
    atomic_json(OUT / 'report.json', report)
    for name, row in results.items():
        print(name, {k:v for k,v in row.items() if k not in ('ledger', 'execution_coverage_exclusions')}, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('capture', 'replay'))
    args = parser.parse_args()
    if args.stage == 'capture':
        capture()
    else:
        replay()
