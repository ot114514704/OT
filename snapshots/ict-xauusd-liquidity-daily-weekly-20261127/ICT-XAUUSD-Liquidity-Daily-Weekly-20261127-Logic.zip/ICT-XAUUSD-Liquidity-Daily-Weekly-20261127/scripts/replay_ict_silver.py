"""Reproduce Silver time/PDA visits on an immutable MT5 snapshot; no orders."""
from collections import Counter
from datetime import timedelta
from pathlib import Path
import argparse, csv, hashlib, json, sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from brooks_ai.types import Bar, utc_time
from ict_ai.silver_execution import silver_fvg_visits
from ict_ai.timebase import manifest_epoch_to_utc,clock_policy_metadata
from scripts.prepare_ict_week import aggregate_bars


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--manifest',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args()
    meta=json.loads(args.manifest.read_text(encoding='utf-8'))
    dataset=next(d for d in meta['datasets'] if d['timeframe']=='M5')
    path=Path(dataset['data_path']);sha=hashlib.sha256(path.read_bytes()).hexdigest()
    if meta.get('synthetic') is not False or meta.get('status')!='collected' or meta.get('volatile_live_snapshot') or sha!=dataset['data_sha256']:
        raise ValueError('Matching immutable, non-synthetic captured history required')
    if meta['symbol']!='XAUUSD':raise ValueError('XAUUSD required')
    as_of=utc_time(meta['finished_at_utc'])
    with path.open(encoding='utf-8-sig',newline='') as f:
        bars=[Bar(manifest_epoch_to_utc(utc_time(r['time']),meta),*(float(r[k]) for k in ('open','high','low','close','spread'))) for r in csv.DictReader(f)]
    periods=[];total_checks=0
    for minutes in [5,15,60]:
        p=timedelta(minutes=minutes)
        series=aggregate_bars(bars,5,minutes,as_of)
        events=silver_fvg_visits(series,p,as_of)
        for n,b in enumerate(series,1):
            cutoff=b.time+p
            expected=[e for e in events if utc_time(e['available_at'])<=cutoff]
            if silver_fvg_visits(series[:n],p,cutoff)!=expected or silver_fvg_visits(series,p,cutoff)!=expected:
                raise AssertionError(f'Hidden future altered Silver events at {cutoff}')
        checks=len(series);total_checks+=checks
        counts={'visits':len(events),
                'pda_known_before_window':sum(e['pda_confirmed_before_window'] for e in events),
                'pda_known_at_or_after_window_open':sum(not e['pda_confirmed_before_window'] for e in events),
                'previously_touched':sum(e['prior_observed_touch_bars']>0 for e in events),
                'missing_continuity':sum(not e['continuous_quotes_since_confirmation'] for e in events),
                'far_edge_close_on_visit_bar':sum(e['far_edge_close_on_visit_bar'] for e in events)}
        grouped=[]
        for day,window in sorted({(e['ny_date'],e['window']['id']) for e in events}):
            local=[e for e in events if (e['ny_date'],e['window']['id'])==(day,window)]
            grouped.append({'ny_date':day,'window_id':window,'visits':len(local),
                            'bullish':sum(e['side']==1 for e in local),'bearish':sum(e['side']==-1 for e in local),
                            'first_visit_known_at':min(e['available_at'] for e in local)})
        periods.append({'period_minutes':minutes,'bars':len(series),'counts':counts,
                        'by_window':dict(Counter(e['window']['id'] for e in events)),
                        'days_and_windows':grouped,'events':events,'causal_prefix_checks':checks})
        print(json.dumps({'period_minutes':minutes,'counts':counts,'prefix_checks':checks}),flush=True)
    code=['ict_ai/silver_bullet.py','ict_ai/silver_execution.py','ict_ai/backtest.py',
          'ict_ai/features.py','ict_ai/timebase.py','scripts/prepare_ict_week.py','scripts/replay_ict_silver.py']
    rules=ROOT/'research/ict_time4_video/rules.json';manifest=ROOT/'research/ict_time4_video/manifest.json'
    report={'as_of':as_of.isoformat(),'symbol':'XAUUSD','source_manifest':str(args.manifest.resolve()),
            'source_manifest_sha256':hashlib.sha256(args.manifest.read_bytes()).hexdigest(),
            'data_sha256':sha,**clock_policy_metadata(meta),
            'historical_clock_verified':False,'periods':periods,'causal_prefix_checks':total_checks,
            'prefix_stability_passed':True,'qualified_signal_count':0,'orders_sent':0,
            'cost_backtest_run_on_these_visits':False,'model_trained':False,'execution_allowed':False,
            'source_rules':str(rules),'source_rules_sha256':hashlib.sha256(rules.read_bytes()).hexdigest(),
            'lesson_source_manifest':str(manifest),'lesson_source_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),
            'code_sha256':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in code},
            'engineering_choices':['48-hour FVG retention, not a lesson-derived expiry',
                                   'First geometric visit per FVG/window; repeated prior use is retained',
                                   'A far-edge close invalidates later visits; simultaneous touch/close is flagged',
                                   'M15/H1 use only complete contiguous M5 buckets'],
            'limitations':['Price-range intersections are not orders or recorded bid/ask fills',
                           'Overlapping and nested zones produce dependent visits; do not sum into trade counts',
                           'A historical visit must not be used to backdate order preparation',
                           'HTF bias, qualified PDA, DOL, daily/weekly narrative and calendar remain unverified',
                           'A visit known at 11:00 can belong to 10:55–11:00; it cannot authorize a retroactive entry',
                           'Quotes and spread do not reconstruct exact trigger time or limit queue',
                           'Times use source manifest interval hypotheses, not independently calibrated broker history']}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'report':str(args.out.resolve()),'causal_prefix_checks':total_checks,'qualified_signals':0,'orders_sent':0}),flush=True)


if __name__=='__main__':main()
