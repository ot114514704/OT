"""Audit a collected snapshot and optionally export causal candidate features.

No outcome labels, cost substitutions, model fitting, or orders are produced.
"""
import argparse
from collections import Counter, defaultdict
from dataclasses import asdict
from datetime import datetime, timezone
import csv
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from brooks_ai.types import Bar,utc_time
from brooks_ai.strategy import detect,FEATURES
from brooks_ai.model import policy_fingerprint


def read_bars(path):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:
        bars=[Bar(utc_time(r['time']),*(float(r[k]) for k in ('open','high','low','close','spread')))
              for r in csv.DictReader(f)]
    if not bars or any(b.time<=a.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Empty, duplicate or unordered bars')
    return bars


def cross_timeframe(base,higher,seconds,tick_size):
    """Only compare complete M15 buckets; missing prices are never filled."""
    if seconds<900 or seconds%900 or tick_size<=0:
        raise ValueError('Invalid aggregation interval or tick')
    grouped=defaultdict(list)
    for b in base:
        grouped[int(b.time.timestamp())//seconds*seconds].append(b)
    checked=0; partial=0; mismatches=[]
    for b in higher:
        stamp=int(b.time.timestamp());rows=grouped.get(stamp,[])
        if not rows:
            continue
        if len(rows)!=seconds//900 or any(int(r.time.timestamp())!=stamp+i*900 for i,r in enumerate(rows)):
            partial+=1
            continue
        expected={'open':rows[0].open,'high':max(r.high for r in rows),
                  'low':min(r.low for r in rows),'close':rows[-1].close}
        checked+=1
        if any(abs(getattr(b,k)-v)>tick_size/2+1e-8 for k,v in expected.items()):
            mismatches.append({'time':b.time.isoformat(),'expected':expected,
                               'actual':{k:getattr(b,k) for k in expected}})
    return dict(complete_buckets_compared=checked,partial_buckets_excluded=partial,
                mismatch_count=len(mismatches),mismatches=mismatches)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--snapshot',required=True)
    parser.add_argument('--out-dir',required=True)
    parser.add_argument('--catalog',action='store_true')
    args=parser.parse_args()
    root=Path(args.snapshot);out=Path(args.out_dir);out.mkdir(parents=True,exist_ok=True)
    manifest=root/'provenance.json';meta=json.loads(manifest.read_text(encoding='utf-8'))
    if meta.get('synthetic') is not False or meta.get('status')!='collected':
        raise ValueError('Expected completed real-source collection')
    datasets={d['timeframe']:d for d in meta['datasets'] if 'data_path' in d}
    bars={}
    for tf,d in datasets.items():
        path=Path(d['data_path'])
        if hashlib.sha256(path.read_bytes()).hexdigest()!=d['data_sha256']:
            raise ValueError('Snapshot hash mismatch: '+tf)
        bars[tf]=read_bars(path)
    base=bars['M15'];point=meta['current_symbol_observation']['trade_tick_size']
    cross={tf:cross_timeframe(base,bars[tf],seconds,point)
           for tf,seconds in [('H1',3600),('H4',14400)] if tf in bars}
    old=read_bars(ROOT/'data/chart/TMGM_XAUUSD_M15_recent.csv')
    by_time={b.time:b for b in base}
    old_matches=sum(b==by_time.get(b.time) for b in old)
    report=dict(at_utc=datetime.now(timezone.utc).isoformat(),
                source_manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
                period={'from':base[0].time.isoformat(),'to':base[-1].time.isoformat()},
                bar_count=len(base),prior_chart_overlap_bars=len(old),prior_chart_exact_matches=old_matches,
                cross_timeframe=cross,zero_spread_by_month=dict(Counter(b.time.strftime('%Y-%m') for b in base if b.spread==0)),
                ready_for_price_structure_research=old_matches==len(old) and len(cross)==2
                    and all(v['complete_buckets_compared']>0 and v['mismatch_count']==0 for v in cross.values()),
                ready_for_verified_cost_training=False,
                unresolved=['Historical commission, slippage and swap cash unknown',
                            'Zero spread bar fields do not prove zero execution cost',
                            'Session calendar and exceptional gaps unverified',
                            'Current symbol metadata does not verify historical contract specifications'])
    if args.catalog:
        if not report['ready_for_price_structure_research']:
            raise ValueError('Source comparison failed; no candidate catalog generated')
        cfg=json.loads((ROOT/'config/strategy.json').read_text(encoding='utf-8-sig'))
        start_policy=policy_fingerprint(cfg)
        counts=Counter();months=Counter();quality=Counter();total=0
        path=out/'candidates.jsonl'
        with path.open('w',encoding='utf-8') as f:
            for i in range(59,len(base)):
                window=base[max(0,i-119):i+1]
                for s in detect(window,cfg,point):
                    flags=[]
                    if s.time!=base[i].time:
                        raise AssertionError('Candidate is not on current closed bar')
                    if base[i].spread==0:flags.append('signal_bar_zero_reported_spread')
                    if any((b.time-a.time).total_seconds()!=900 for a,b in zip(window,window[1:])):
                        flags.append('clock_gap_in_context')
                    if i==len(base)-1 or (base[i+1].time-base[i].time).total_seconds()!=900:
                        flags.append('no_contiguous_next_bar_for_replay')
                    row=asdict(s)
                    row.update(bar_index=i,quality_flags=flags,net_outcome_label=None,
                               outcome_label_status='Not generated: historical execution costs unverified')
                    f.write(json.dumps(row,ensure_ascii=False,default=lambda x:x.isoformat())+'\n')
                    counts[s.setup]+=1;months[base[i].time.strftime('%Y-%m')]+=1
                    quality.update(flags);total+=1
                if (i+1)%10000==0:
                    print(json.dumps({'scanned_bars':i+1,'raw_candidates':total}),flush=True)
        if policy_fingerprint(cfg)!=start_policy:
            raise ValueError('Source changed during replay; no authoritative audit report written')
        report['catalog']=dict(path=str(path.resolve()),data_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                               raw_candidate_count=total,by_setup=dict(counts),by_month=dict(months),
                               quality_flag_counts=dict(quality),features=FEATURES,
                               policy_fingerprint=start_policy,outcome_labels_generated=0,
                               context_gap_note='120 M15 bars exceed a typical trading day; a daily closure can flag every context. This is a descriptive flag, not automatic rejection or proof of missing data.',
                               note='Raw bar-level candidates may overlap across families and repeat across bars; counts are not executable trades or independent samples.')
    report['completed_at_utc']=datetime.now(timezone.utc).isoformat()
    (out/'history_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
