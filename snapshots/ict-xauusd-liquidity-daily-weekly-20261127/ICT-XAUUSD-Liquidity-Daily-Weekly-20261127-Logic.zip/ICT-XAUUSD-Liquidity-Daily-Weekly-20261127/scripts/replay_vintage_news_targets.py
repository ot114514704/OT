"""Audit older official USD releases without exposing future calendar revisions."""
from bisect import bisect_left
from collections import Counter
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
from statistics import median
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ict_ai.dol_history import forecast
from ict_ai.judas import judas_history
from ict_ai.timebase import NY
from scripts import replay_prior_joint_months as prior
from scripts.replay_ict_news import block, measure

joint,priority=prior.joint,prior.priority
SOURCE=joint.ROOT/'research/jin10_calendar/us_release_vintage_202509_202603.json'
OUT=joint.RESEARCH/'vintage_news_targets_20261122'
H=timedelta(hours=1)
M=timedelta(minutes=5)


def local(value):
    return datetime.fromisoformat(value).replace(tzinfo=NY).astimezone(timezone.utc)


def load_events():
    payload=json.loads(SOURCE.read_bytes())
    assert payload['timezone']=='America/New_York'
    events=[]
    for released,family,official,usable_from,advance in payload['events']:
        at=local(released)
        eligible=local(usable_from) if usable_from else at
        assert bool(advance)==bool(usable_from) and eligible<=at
        assert not events or at>events[-1]['release']
        events.append(dict(release=at,kind=family,source=official,known_from=eligible,advance_source=advance))
    return events


def calendar_at(events,cutoff):
    return [(e['release'],e['kind']) for e in events if e['known_from']<=cutoff]


def signature(ranked):
    return [(t['side'],t['lo'],t['hi'],t['score']) for t in ranked]


def replay(clocks,events,r):
    gold,times=r.SERIES[0],r.TIMES[0]
    snapshots={}
    for at in clocks:
        five=gold[bisect_left(times,at-timedelta(days=42)):bisect_left(times,at)]
        if not five or five[-1].time+M!=at:continue
        def closed_hours(i):
            end=bisect_left(r.TIMES[i],at-H+timedelta(microseconds=1))
            start=bisect_left(r.TIMES[i],at-timedelta(days=42 if i==1 else 12))
            return r.SERIES[i][start:end]
        one=closed_hours(1)
        end=bisect_left(r.QTIME,at-3*M+timedelta(microseconds=1))
        fifteen=r.QUARTERS[bisect_left(r.QTIME,at-timedelta(days=42)):end]
        peers=[]
        for i,name,inverse in ((2,'白银',False),(3,'美元指数',True)):
            peers+=r.exporter.add_smt(lambda *args:None,[b for b in one if b.time>=at-timedelta(days=12)],
                                      closed_hours(i),at,name,inverse)
        js_input=[b for b in five if b.time>=at-timedelta(days=5)]
        cal=calendar_at(events,at)
        with_news=judas_history(js_input,at,cal)
        without=judas_history(js_input,at,[])
        _,ranked=forecast(five,one,fifteen,at,peers,cal,with_news,nearby_priority=True)
        _,baseline=forecast(five,one,fifteen,at,peers,(),without,nearby_priority=True)
        pool_bars=gold[bisect_left(times,at-timedelta(days=63)):bisect_left(times,at)]
        pool=joint.liquidity_ranking(pool_bars,at,ranked)
        old_pool=pool if signature(ranked)==signature(baseline) else joint.liquidity_ranking(pool_bars,at,baseline)
        snapshots[at]=dict(dol=ranked,pools=pool,calendar=[(t.isoformat(),name) for t,name in cal if at<=t<=at+4*H],
                           dol_changed=signature(ranked)!=signature(baseline),pool_changed=signature(pool)!=signature(old_pool),
                           judas_changed=with_news!=without)
    return snapshots


def analyze(events,source):
    archive={b.time:b for b in source.SERIES[0]}
    phases=(-5,0,15,30,60)
    snapshots=replay(sorted({e['release']+timedelta(minutes=f) for e in events for f in phases}),events,source)
    result=[]
    for e in events:
        release=e['release']
        by_phase={}
        for offset in phases:
            cut=release+timedelta(minutes=offset)
            if cut in snapshots:by_phase[str(offset)]=snapshots[cut]
        frame=measure(archive,release)
        future=block(archive,release,12)
        watch={}
        if future and '-5' in by_phase:
            for model in ('dol','pools'):
                candidates=by_phase['-5'][model]
                if candidates:
                    nearest=min(candidates,key=lambda t:t['distance'])
                    watch[model]=dict(target=nearest,observed=joint.contacts(nearest,future,model=='pools'))
        result.append(dict(released=release.astimezone(NY).isoformat(),kind=e['kind'],source=e['source'],
                           known_from=e['known_from'].astimezone(NY).isoformat(),advance_source=e['advance_source'],
                           price_path=frame,forecasts=by_phase,pre_release_targets=watch))
    return result


def report(rows):
    cohorts=sorted({e['kind'] for e in rows})
    mode_count=Counter()
    lines=['# 历史美元新闻与黄金价位回放','',
           '以美东实际发布时间为中心，对照公布前 30 分钟与公布后 30 分钟，并追踪首小时 DOL 触价和流动性外沿越过。榜单分别在公布前 5 分钟、公布时刻、公布后 15／30／60 分钟冻结。每次仅用已收 K 线。','',
           '|事件|有提前排期证据|可复盘事件数／事件数|公布后／前 30 分钟波幅中位比|首小时 DOL 最近目标触达|首小时流动性最近外沿越过|',
           '|---|---:|---:|---:|---:|---:|']
    for kind in cohorts:
        group=[e for e in rows if e['kind']==kind]
        paths=[e['price_path']['horizons']['30']['range_vs_pre_30m'] for e in group if e['price_path']]
        outcomes=[]
        for model,field in [('dol','touch'),('pools','sweep')]:
            usable=[e['pre_release_targets'][model]['observed'] for e in group if model in e['pre_release_targets']]
            outcomes.append(f'{sum(bool(x[field]) for x in usable)}/{len(usable)}')
        ratio=f'{median(paths):.2f}×' if paths else '—'
        lines.append(f"|{kind}|{sum(bool(e['advance_source']) for e in group)}|{len(paths)}/{len(group)}|{ratio}|"+'|'.join(outcomes)+'|')
    lines+=['','|美东实际公布|类别|公布前可见|价格路径（首 30 分钟）|官方来源|','|---|---|---|---|---|']
    paths_zh={'both_sides_exceeded':'越过前区两侧','one_side_reclaimed':'越过一侧后收回',
              'one_side_unreclaimed':'越过一侧，窗口内未收回','inside':'保持在前区'}
    for e in rows:
        path=e['price_path']['horizons']['30']['path'] if e['price_path'] else ''
        flag='[排期]('+e['advance_source']+')' if e['advance_source'] else '用实际公布核对'
        lines.append(f"|{e['released']}|{e['kind']}|{flag}|{paths_zh.get(path,'行情不足')}|[官方](<{e['source']}>)|")
        for s in e['forecasts'].values():
            mode_count['snapshots']+=1
            for key in ('dol_changed','pool_changed','judas_changed'):mode_count[key]+=s[key]
    lines+=['',f"同一报价分别带入已知排期和空排期，共比较 {mode_count['snapshots']} 个时点。DOL 榜单变化 {mode_count['dol_changed']} 次，流动性榜单变化 {mode_count['pool_changed']} 次，犹大信号集变化 {mode_count['judas_changed']} 次。",
            '', '波幅比较是同一日期的前后观察。样本涵盖四类事件，未做全市场日历或行情归因，也未复原公布前共识与数据意外。']
    (OUT/'官方新闻回放.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(mode_count),flush=True)


def main():
    OUT.mkdir(exist_ok=True,parents=True)
    manifest=json.loads((priority.ARCH/'manifest.json').read_bytes())
    for name in ('XAUUSDM5.npz','XAUUSDH1.npz','XAGUSDH1.npz','USIDXH1.npz','run.py'):
        assert joint.digest(priority.ARCH/name)==manifest[name]
    prior.setup()
    events=load_events()
    for e in events:
        pair=(e['release'],e['kind'])
        assert pair not in calendar_at(events,e['known_from']-timedelta(microseconds=1))
        assert pair in calendar_at(events,e['known_from'])
    rows=analyze(events,prior.worker)
    joint.write_zip(OUT/'event_replay.json.gz',rows)
    (OUT/'provenance.json').write_text(json.dumps(dict(calendar=joint.digest(SOURCE),details=joint.digest(OUT/'event_replay.json.gz'),
        archive={k:v for k,v in manifest.items() if k.endswith('.npz')},scope=len(rows)),indent=2),encoding='utf-8')
    report(rows)
    charts(rows,(prior.worker.SERIES[0],prior.worker.TIMES[0]))


def charts(rows,data):
    from scripts.plot_joint_round_examples import plt,font_manager,render
    font=Path('C:/Windows/Fonts/msyh.ttc')
    for f in (font,font.with_name('msyhbd.ttc')):
        font_manager.fontManager.addfont(f)
    plt.rcParams['font.family']=font_manager.FontProperties(fname=font).get_name()
    plt.rcParams['axes.unicode_minus']=False
    for number,kind in enumerate(('CPI','NFP','FOMC'),1):
        selected=None
        for e in rows:
            if e['kind']!=kind or not e['price_path']:continue
            entries={k:v for k,v in e['pre_release_targets'].items()
                     if v['observed']['touch' if k=='dol' else 'sweep']}
            if entries and (selected is None or len(entries)>len(selected[1])):
                selected=e,entries
        if selected is None:continue
        e,entries=selected
        release=datetime.fromisoformat(e['released'])
        at=release-M
        reference=data[0][bisect_left(data[1],at)-1]
        assert reference.time+M==at
        snapshot=dict(at=at.isoformat(),price=reference.close,picks={})
        outcome=dict(end=(release+H).isoformat())
        for key,v in entries.items():
            snapshot[key]=e['forecasts']['-5'][key]
            idx=snapshot[key].index(v['target'])
            snapshot['picks'][key]={'nearest':idx}
            observations=[{} for _ in snapshot[key]]
            observations[idx]=v['observed']
            outcome[key]=observations
        render(OUT/f'{kind}.png',number,f'{kind} 公布后的黄金价位回放',tuple(entries),
               snapshot,outcome,data,release=release)


if __name__=='__main__':
    main()
