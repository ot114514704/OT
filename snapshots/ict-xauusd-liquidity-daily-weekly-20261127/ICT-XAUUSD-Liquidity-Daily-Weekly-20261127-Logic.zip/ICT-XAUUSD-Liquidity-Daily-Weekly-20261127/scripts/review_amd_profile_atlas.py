"""Replay archived consolidation frames and export ten wide XAUUSD case charts."""
import argparse
import csv
import hashlib
import json
from functools import lru_cache
from html import escape
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

from brooks_ai.types import utc_time
from ict_ai.amd import amd_events, confirmed_pivots
from ict_ai.profile_lifecycle import daily_profile_lifecycle
from ict_ai.timebase import NY, manifest_epoch_to_utc
from scripts.audit_profile_one_daily_context import load_tmgm
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_ipda_profiles import active_profiles
from scripts.replay_ict_news import ROOT, STEP


FAMILIES = ('通道', '三角', '矩形')
DEFAULT_SOURCE = Path('D:/盘整研究资料/运行数据/MT5/IPDA_Consolidation/shapes.tsv')


def classify(row):
    geometry = row[2]
    a, b, c, d = (float(row[k]) for k in (14, 16, 18, 20))
    if min(a-d, b-c) <= 0:
        return None
    if geometry == 'rectangle' and a == b and c == d:
        return '矩形', 'overlapping'
    du, dl = b-a, c-d
    if geometry == 'channel' and du*dl > 0:
        return '通道', 'rising_channel' if du > 0 else 'falling_channel'
    if geometry == 'converging' and b-c < a-d:
        flat = .05*(a-d)
        if abs(du) <= flat and dl > flat:
            return '三角', 'ascending_triangle'
        if abs(dl) <= flat and du < -flat:
            return '三角', 'descending_triangle'
        if du < 0 < dl:
            return '三角', 'triangle'
    return None


def snapshot(closed_m5, quarters, at, side):
    day = at.astimezone(NY).date()
    if day.weekday() > 4:
        return dict(day='周末', week='待定', relation='待定')
    view = daily_profile_lifecycle(quarters, day, at, reference_m5=closed_m5,
                                   include_reconstruction=False)
    active = active_profiles(view) if view.get('coverage_complete_under_study_calendar') else []
    votes = {c['direction'] for c in active if c['direction'] in (-1, 1)}
    daily = next(iter(votes)) if len(votes) == 1 else None
    weekly = view['weekly_background']['scenario_direction']
    known = [v for v in (daily, weekly) if v in (1, -1)]
    relation = ('日型分歧' if len(votes) > 1 else '待定' if not known else '日周分歧' if len(set(known)) > 1
                else '同向' if known[0] == side else '逆向')
    return dict(day='、'.join(dict.fromkeys(c['label'] for c in active)) or '候选待定',
                week=view['weekly_background']['label'], daily_side=daily, weekly_side=weekly,
                relation=relation, at=at.isoformat())


def scan(source):
    archive, provenance = load_tmgm()
    cutoff = archive[-1].time + STEP
    bars = {m: aggregate_bars(archive, 5, m, cutoff) for m in (15, 60)}
    times = {m: [b.time for b in rows] for m, rows in bars.items()}
    m5_times = [b.time for b in archive]
    meta = json.loads((ROOT/'output/research/ict_profile_one_complete_20261121.json').read_bytes())['sources'][-1]
    def clock(epoch):
        return manifest_epoch_to_utc(datetime.fromtimestamp(int(epoch), timezone.utc), meta)
    with source.open(encoding='utf-8-sig', newline='') as stream:
        head, *records, end = csv.reader(stream, delimiter='\t')
    if head[:2] != ['IPDA_SHAPES', '2'] or head[3] != 'XAUUSD' or end != ['END',head[2]] or len(records) != int(head[4]):
        raise ValueError('Incomplete shape archive')
    cases = []
    for ref in records:
        kind = classify(ref)
        minutes = int(ref[0])//60
        if not kind or minutes not in bars or ref[3] == 'intraday':
            continue
        period = timedelta(minutes=minutes)
        points = [(clock(ref[k]),float(ref[k+1])) for k in (13,15,17,19)]
        # An archive may contain a later extension of an earlier provisional frame.
        # Freeze after its recorded end AND after all four anchor candles have closed.
        freeze = max(clock(ref[5]), clock(ref[6]), max(t for t,p in points)+period)
        t0 = clock(ref[4])
        rows, stamps = bars[minutes], times[minutes]
        i, j = bisect_left(stamps,t0), bisect_left(stamps,freeze)
        if j-i < 6 or i == len(rows) or stamps[i] != t0 or stamps[j-1]+period != freeze or freeze-t0 != (j-i)*period:
            continue
        segment = rows[i:j+24]
        events = amd_events(segment,period,cutoff,window=j-i,reference_shape=kind[1])
        if not events:
            continue
        m = next((e for e in events if e['phase']=='M'),None)
        last = events[-1]
        route = last['route']
        ctx = None
        if m:
            at = utc_time(m['available_at'])
            start = at-timedelta(days=8)
            closed = archive[bisect_left(m5_times,start):bisect_right(m5_times,at-STEP)]
            quarters = bars[15][bisect_left(times[15],start):bisect_right(times[15],at-3*STEP)]
            side = 1 if m['lower'] < m['range_low'] else -1
            ctx = snapshot(closed,quarters,at,side)
        cases.append(dict(key=ref[1],family=kind[0],origin='盘整研究原框',minutes=minutes, i=i,j=j,frame=points,
                          events=events,route=route,context=ctx))
    # The terminal also has a native confirmed-swing triangle mode. Keep its
    # cases separately attributed instead of treating them as archive frames.
    for minutes, rows in bars.items():
        period = timedelta(minutes=minutes)
        groups = defaultdict(list)
        for event in amd_events(rows,period,cutoff,triangle_only=True):
            groups[event['id']].append(event)
        stamps = times[minutes]
        for key, events in groups.items():
            if events[-1]['route'] != 'AMD':
                continue
            a,m,d = events
            i = bisect_left(stamps,utc_time(a['start']))
            j = bisect_left(stamps,utc_time(a['available_at']))
            h0,h1,l0,l1 = confirmed_pivots(rows[i:j])
            left,right = max(h0,l0),min(h1,l1)
            def point(k,start,end,attr):
                p,q = (getattr(rows[i+n],attr) for n in (start,end))
                return stamps[i+k], p+(q-p)*(k-start)/(end-start)
            frame = [point(k,u,v,attr) for k,u,v,attr in (
                (left,h0,h1,'high'),(right,h0,h1,'high'),(right,l0,l1,'low'),(left,l0,l1,'low'))]
            at = utc_time(m['available_at'])
            start = at-timedelta(days=8)
            ctx = snapshot(archive[bisect_left(m5_times,start):bisect_right(m5_times,at-STEP)],
                           bars[15][bisect_left(times[15],start):bisect_right(times[15],at-3*STEP)],
                           at,1 if m['lower'] < a['range_low'] else -1)
            cases.append(dict(key=key,family='三角',origin='已确认摆点重建',minutes=minutes,i=i,j=j,
                              frame=frame,events=events,route='AMD',context=ctx))
    return cases,bars,provenance


def select(cases, batch):
    selected = []
    used_dates = set()
    for family, route, count in [('通道','AMD',2),('通道','AM',1),('三角','AMD',3),
                                 ('三角','AM',1),('矩形','AMD',3)]:
        pool = [r for r in cases if r['family']==family and r['context'] and r['route']==route
                and r['events'][0]['start'] >= '2026-09-01']
        if family=='三角':
            # Chart sampling only: choose visually legible convergence.
            def visibly_converges(case):
                upper0,upper1,lower1,lower0 = [p for _,p in case['frame']]
                return upper1-lower1 <= .77*(upper0-lower0)
            pool = [r for r in pool if visibly_converges(r)]
        pool.sort(key=lambda r:r['events'][-1]['available_at'])
        shown_directions=set()
        for n in range(count):
            if not pool:
                raise ValueError(f'Insufficient independent {family} cases')
            offset = (round(n*len(pool)/count)+batch-1)%len(pool)
            ordering = pool[offset:]+pool[:offset]
            prefer_h1 = n==0 and (family=='三角' or route=='AM')
            for candidate in sorted(ordering,key=lambda r: (
                    r['events'][-1]['direction'] in shown_directions,
                    prefer_h1 and r['minutes']!=60)):
                date = utc_time(candidate['events'][0]['available_at']).astimezone(NY).date()
                if date not in used_dates:
                    break
            else:
                raise ValueError('Not enough distinct dates')
            selected.append(candidate)
            shown_directions.add(candidate['events'][-1]['direction'])
            used_dates.add(date)
            pool.remove(candidate)
    return selected


def review_case(case, rows):
    period = timedelta(minutes=case['minutes'])
    a,m,*rest = case['events']
    stamps = [b.time for b in rows]
    mi = bisect_left(stamps,utc_time(m['available_at'])-period)
    side = 1 if m['lower'] < a['range_low'] else -1
    if rest:
        return bisect_left(stamps,utc_time(rest[0]['available_at'])-period), '反向越过对侧边界，连续两根收于界外，出现顺向位移。'
    expiry = case['j']-1+24
    for k in range(mi+1,min(len(rows),expiry+1)):
        b = rows[k]
        if b.time != rows[k-1].time+period:
            return k-1,'后续报价出现间隔，连续观察在此停止。'
        if b.high > a['range_high'] and b.low < a['range_low']:
            return k,'同根 K 线越过两侧边界，先后次序无法确定。'
        if (side>0 and b.low<m['lower']) or (side<0 and b.high>m['upper']):
            return k,'价格再破 M 极值，原派发候选失效。'
    return min(expiry,len(rows)-1),('A 确认后 24 根 K 线内，派发未确认。' if expiry<len(rows) else '存档结束，派发仍待观察。')


@lru_cache(maxsize=32)
def font(size,bold=False):
    from PIL import ImageFont
    return ImageFont.truetype('C:/Windows/Fonts/msyh'+('bd' if bold else '')+'.ttc',size)


def chart_phase_spans(case, rows, stamps):
    """Return inclusive bar ranges for painting, separate from stage confirmation."""
    a,m,*rest = case['events']
    period = timedelta(minutes=case['minutes'])
    m_first = bisect_left(stamps,utc_time(m['start']))
    m_last = bisect_left(stamps,utc_time(m['available_at'])-period)
    # A reaches the first sweep. Share that candle when the sweep immediately reclaims.
    a_last = m_first if m_first==m_last else m_first-1
    spans = {'A':(case['i'],a_last),'M':(m_first,m_last)}
    if rest:
        d = rest[0]
        side = 1 if d['direction']=='bullish' else -1
        edge = a['range_high'] if side>0 else a['range_low']
        end = bisect_left(stamps,utc_time(d['available_at'])-period)
        while end+1<len(rows) and stamps[end+1]==stamps[end]+period and side*(rows[end+1].close-edge)>0:
            end += 1
        spans['D'] = (m_last,end)
    return spans


def chart(case, rows, path, number):
    from PIL import Image, ImageDraw
    a,m,*rest = case['events']
    i = case['i']
    at, explanation = review_case(case,rows)
    stamps=[b.time for b in rows]
    period=timedelta(minutes=case['minutes'])
    spans=chart_phase_spans(case,rows,stamps)
    phase_end=max(at,spans.get('D',spans['M'])[1])
    first,last = max(0,i-64),min(len(rows)-1,max(at+56,phase_end+5))
    chart_image = Image.new('RGB',(1720,1050),'#10171e')
    pen = ImageDraw.Draw(chart_image)
    white,muted,red,gold = '#f0f4f7','#b1c1c9','#ff605b','#ffd16c'
    def text(x,y,value,size=19,color=white,bold=False,anchor='la'):
        pen.text((x,y),value,font=font(size,bold),fill=color,anchor=anchor)
    direction = '扫下沿' if m['lower'] < a['range_low'] else '扫上沿'
    outcome = ('向上派发' if rest[0]['direction']=='bullish' else '向下派发') if rest else '派发未确认'
    ny = utc_time(m['available_at']).astimezone(NY)
    text(44,20,f"{case['family']}积累　/　{direction} · {outcome}",35,bold=True)
    text(1674,30,f'{number:02d} / 10',23,muted,anchor='ra')
    text(46,80,f"TMGM  XAUUSD     {case['minutes']} 分钟     {ny:%Y-%m-%d}（M 收盘日，美东）     {case['origin']}",20,muted)
    def panel(left,right,top,bottom):
        x0,x1=55,1592
        step=(x1-x0)/(right-left+1)
        def x(k): return x0+(k-left+.5)*step
        def index(t): return bisect_left(stamps,t)
        low=min(b.low for b in rows[left:right+1])
        high=max(b.high for b in rows[left:right+1])
        p0=min(low,a['range_low'])
        p1=max(high,a['range_high'])
        span=max(.1,p1-p0)
        low,high=p0-.10*span,p1+.12*span
        def y(v): return bottom-(v-low)*(bottom-top)/(high-low)
        pen.rectangle((x0,top,x1,bottom),fill='#080e13')
        for n in range(5):
            val=low+(high-low)*(n+.4)/5
            pen.line((x0,y(val),x1,y(val)),fill='#202d37')
            text(x1+12,y(val),f'{val:.2f}',17,muted,anchor='lm')
        for k in range(left,right+1):
            b=rows[k]
            if k>left and b.time!=rows[k-1].time+period:
                for yy in range(top,bottom,10):
                    pen.line((x(k)-step/2,yy,x(k)-step/2,yy+3), fill='#737780')
            color='#48dba9' if b.close>=b.open else '#ab8e9d'
            hw=min(9,max(1,step*.31))
            pen.line((x(k),y(b.high),x(k),y(b.low)),fill=color,width=1)
            yt,yb=sorted((y(b.close),y(b.open)))
            pen.rectangle((x(k)-hw,yt,x(k)+hw,max(yb,yt+1)),fill=color)
        pen.rectangle((x(i)-.5*step,y(a['range_high']),x(spans['A'][1])+.5*step,y(a['range_low'])),
                      outline=red,width=3)
        for e in [m]+rest:
            begin,end=spans[e['phase']]
            if e is m:
                p=rows[end].close
                q=e['lower'] if direction=='扫下沿' else e['upper']
            else:
                p=rows[begin].close
                q=(max(b.high for b in rows[begin:end+1]) if e['direction']=='bullish'
                   else min(b.low for b in rows[begin:end+1]))
            yt,yb=sorted((y(p),y(q)))
            pen.rectangle((x(begin)-.5*step,yt,x(end)+.5*step,max(yb,yt+2)),outline=red,width=3)
            if e is not m:
                confirmed=index(utc_time(e['available_at'])-period)
                px,py=x(confirmed),y(rows[confirmed].close)
                pen.ellipse((px-4,py-4,px+4,py+4),fill=gold)
        for n in range(6):
            k=left+round((right-left)*n/5)
            text(x(k),bottom+6,rows[k].time.astimezone(NY).strftime('%m/%d %H:%M'),16,muted,
                 anchor=('la' if n==0 else 'ra' if n==5 else 'ma'))
    text(54,121,f'全景行情　{last-first+1} 根 K 线',20,bold=True)
    text(1589,122,'虚线为行情间隔',17,muted,anchor='ra')
    panel(first,last,160,466)
    text(54,518,'局部放大　/　A 矩形上下沿为扫荡判定价',20,bold=True)
    text(1589,521,'金点为 D 确认收盘',17,gold,anchor='ra')
    panel(max(first,i-4),min(last,phase_end+5),558,805)
    def stamp(e): return utc_time(e['available_at']).astimezone(NY).strftime('%m/%d %H:%M')
    text(54,866,'确认收盘　 A  '+stamp(a)+'　　M  '+stamp(m)+'　　D  '+(stamp(rest[0]) if rest else '未确认'),22,bold=True)
    text(54,917,explanation,21)
    ctx=case['context']
    text(54,971,'M 收盘时的概况一　｜　日　'+ctx['day']+'　　周　'+ctx['week']+'　　方向关系　'+ctx['relation'],19,muted)
    chart_image.save(path)
    return last-first+1


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--shapes',type=Path,default=DEFAULT_SOURCE)
    parser.add_argument('--batch',type=int,default=1)
    parser.add_argument('--out',type=Path,default=ROOT/'output/visualizations/amd-profile-atlas')
    args=parser.parse_args()
    if args.batch<1:
        parser.error('batch must be positive')
    out=args.out/f'batch-{args.batch:02d}'
    out.mkdir(exist_ok=True,parents=True)
    cases,bars,sources=scan(args.shapes)
    selected=select(cases,args.batch)
    sections=[]
    samples=[]
    for num,case in enumerate(selected,1):
        rows=bars[case['minutes']]
        period=timedelta(minutes=case['minutes'])
        is_ref=case['origin']=='盘整研究原框'
        opts=({'window':case['j']-case['i'],'reference_shape':case['events'][0]['shape']}
              if is_ref else {'triangle_only':True})
        start=case['i'] if is_ref else 0
        for e in case['events']:
            at=utc_time(e['available_at'])
            prefix=amd_events([b for b in rows[start:] if b.time+period<=at],period,at,**opts)
            if e not in prefix:
                raise AssertionError(f'Failed closed-prefix replay for {case["key"]}')
        name=f'{num:02d}.png'
        size=chart(case,rows,out/name,num)
        sections.append(f'<a href="{name}"><img loading="lazy" src="{name}" alt="{escape(case["family"])} AMD {num}"></a>')
        samples.append(dict(**case,file=name,view_bars=size))
    (out/'index.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>黄金 AMD · 十例</title><style>html{background:#10171e;color:#eef4f6;font:16px system-ui}main{max-width:1280px;margin:auto}img{display:block;width:100%;height:auto;margin:1.4em 0;border:1px solid #33414a}</style><main><h1>黄金 AMD · 十例</h1><p>每张上方为宽幅行情，下方放大同一形态。点击查看原图。时间均为纽约当地时间。</p>'+''.join(sections)+'</main></html>',encoding='utf8')
    tally=Counter((c['origin'],c['family'],c['route']) for c in cases)
    (out/'replay.json').write_text(json.dumps(dict(source_sha256=hashlib.sha256(args.shapes.read_bytes()).hexdigest(),
        archive=sources, counts=[[*k,v] for k,v in sorted(tally.items())], samples=samples),
        ensure_ascii=False,indent=2,default=str),encoding='utf8')
    with ZipFile(out.with_suffix('.zip'),'w',ZIP_DEFLATED) as pack:
        for name in ['index.html','replay.json']+[s['file'] for s in samples]:
            pack.write(out/name,name)
    print([(s['file'],s['family'],s['route'],s['view_bars']) for s in samples])

if __name__=='__main__':
    main()
