"""Compare nearest outer edges with the structural ranking on the same weekly boards."""

from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timedelta
import json
from pathlib import Path

from scripts import audit_ict_liquidity_week_to_date as week


recent, reconstructed = week.recent, week.reconstruct
stream, fixed, live, M5 = week.stream, week.fixed, week.live, week.M5
OUT = week.REPORT.with_name('ict_liquidity_window_rank_20261125.json')
SCOPES = fixed.board.SCOPES
DELAY = '30'
METHODS = ('score_1', 'near_1', 'score_2', 'near_2', 'near_plus_score')


def previous_boards(name, cases, first_study):
    work = [case['cutoff'] for case in cases]
    initializer = recent.initialize if name == 'verified_original_board' else (
        reconstructed.initialize if name == 'reconstructed_prior' else week.reconstruct_init)
    with ProcessPoolExecutor(max_workers=5, initializer=initializer) as executor:
        if name == 'verified_original_board':
            tasks = [(stamp, first_study['boards'][stamp]) for stamp in work]
            yield from (data for _, _, data in executor.map(recent.identify, tasks, chunksize=3))
        else:
            yield from executor.map(reconstructed.reconstruct, work, chunksize=3)


def boards_for(cases, first_study, week_study):
    prior_bid = week.joint.read_zip(recent.BID)['slots']
    rebuilt_bid = week.joint.read_zip(reconstructed.EVIDENCE)['bid']
    by_source = defaultdict(list)
    for case in cases:
        by_source[case['source']].append(case)
    for name, origins in by_source.items():
        if name == 'real_time_registered':
            for case in origins:
                stamp = case['cutoff']
                native = week_study['actual'][stamp]
                buckets = native.get('buckets') or [week_study['bid'][stamp]]
                yield case, native['data'], datetime.fromisoformat(native['ready']), buckets
            continue
        quotes = {'verified_original_board': prior_bid, 'reconstructed_prior': rebuilt_bid,
                  'reconstructed_extension': week_study['bid']}[name]
        for case, board in zip(origins, previous_boards(name, origins, first_study), strict=True):
            stamp = case['cutoff']
            ready = datetime.fromisoformat(stamp) + timedelta(seconds=int(DELAY))
            if name == 'verified_original_board':
                ready = max(ready, datetime.fromisoformat(first_study['boards'][stamp]['receipt']))
            if board is None or board['cutoff'] != stamp:
                raise ValueError(f'Rebuilt board differs at {stamp}')
            yield case, board, ready, [quotes[stamp]]


def picks(levels, price):
    ranked = list(dict.fromkeys(stream.expiry.outer(level) for level in levels))
    nearest = sorted(ranked, key=lambda key: abs(key[1] - price))
    hybrid = list(dict.fromkeys(nearest[:1] + ranked))[:2]
    return dict(score_1=ranked[:1], near_1=nearest[:1], score_2=ranked[:2],
                near_2=nearest[:2], near_plus_score=hybrid)


def first_strict(rows):
    hits = [(row['bid_time_ms'], stream.expiry.outer(row)) for row in rows if row['status'] == 'sweep']
    if not hits:
        return None, set()
    first = min(stamp for stamp, _ in hits)
    return first, {edge for stamp, edge in hits if stamp == first}


def recording(case, board, price, ready, buckets):
    graded = fixed.grade(board, ready, buckets, 1)
    if graded['state'] != 'scored':
        raise ValueError(f'Missing archived settlement at {case["cutoff"]}')
    pairs = stream.paired(graded)
    for scope, pair in pairs.items():
        if any(case['comparisons'][DELAY][scope][key] != value for key, value in pair.items()):
            raise ValueError(f'Weekly paired outcomes did not reproduce at {case["cutoff"]}')
    rows = []
    for scope in SCOPES:
        crossed, winners = first_strict(graded['outcomes']['early'][scope])
        if not winners:
            continue
        selected = picks(board['early'][scope], price)
        hits = {name: bool(winners.intersection(levels)) for name, levels in selected.items()}
        rows.append(dict(cutoff=case['cutoff'], source=case['source'], scope=scope, ready=ready.isoformat(),
                         price=price, crossing_bid_ms=crossed, winning_edges=sorted(winners),
                         picked_edges=selected, hits=hits))
    return rows


def count_outcomes(report, cases):
    overall = {}
    by_source = defaultdict(dict)
    for scope in SCOPES:
        expected = report['total'][DELAY][scope]['early_hit_windows']
        eligible = [row for row in cases if row['scope'] == scope]
        if len(eligible) != expected:
            raise ValueError(f'First-crossing cases do not cover all winning {scope} windows')
        overall[scope] = summarize(eligible, report['total'][DELAY][scope]['windows'])
        for name, group in report['by_source'].items():
            cohort = [row for row in eligible if row['source'] == name]
            by_source[name][scope] = summarize(cohort, group[DELAY][scope]['windows'])
    return overall, by_source


def summarize(eligible, windows):
    wins = {mode: sum(row['hits'][mode] for row in eligible) for mode in METHODS}
    paired = defaultdict(Counter)
    for row in eligible:
        for a, b in (('near_1', 'score_1'), ('near_2', 'score_2'), ('near_plus_score', 'score_2')):
            left, right = row['hits'][a], row['hits'][b]
            paired[f'{a}_vs_{b}']['both' if left and right else 'first_only' if left else
                                 'second_only' if right else 'neither'] += 1
    return dict(windows=windows, with_first_crossing=len(eligible), tied=sum(len(row['winning_edges']) > 1
                   for row in eligible), wins=wins, paired=paired)


def main():
    report = fixed.read(week.REPORT)
    if report['inputs'][week.INPUT.name] != week.recent.digest(week.INPUT):
        raise ValueError('The week report does not match its price and board inputs')
    _, first_study, _ = week.response.checked_inputs()
    week_study = week.joint.read_zip(week.INPUT)
    paths = (recent.OUT, reconstructed.OUT, stream.POLICY)
    if week_study['source'] != {path.name: recent.digest(path) for path in paths}:
        raise ValueError('The underlying board reports changed')
    price = {datetime.fromisoformat(row[0]): row[4] for row in week_study['m5']}
    archived_prices = {datetime.fromisoformat(row[0]): row[4] for row in first_study['m5']}
    active = [case for case in report['cases'] if any(x['early_hits'] or x['baseline_hits']
              for x in case['comparisons'][DELAY].values())]
    first_hits = []
    for case, board, ready, buckets in boards_for(active, first_study, week_study):
        stamp = datetime.fromisoformat(case['cutoff']) - M5
        if case['source'] == 'real_time_registered':
            closing_price = board['cutoff_close']
        else:
            tape = price if case['source'] == 'reconstructed_extension' else archived_prices
            closing_price = tape[stamp]
        first_hits.extend(recording(case, board, closing_price, ready, buckets))
    all_counts, by_source = count_outcomes(report, first_hits)
    live.atomic_json(OUT, dict(start=report['start'], end=report['end'], overall=all_counts, by_source=by_source,
        cases=sorted(first_hits, key=lambda row: (row['cutoff'], row['scope'])),
        inputs={path.name: recent.digest(path) for path in (*paths, week.REPORT, week.INPUT, Path(__file__))},
        method=('Pick from the same optimised top-ten board per scope. First means earliest strict Bid crossing '
                'after availability in the next M5. Equal timestamps are co-winners. Rank distance by the outer '
                'edge from the frozen close, score by the original priority, and order the two hybrid picks '
                'by nearest then highest-ranking different edge. All windows are retained in the denominator.'),
        orders_sent=0))
    print(json.dumps(dict(end=report['end'], overall=all_counts, live=by_source['real_time_registered']), ensure_ascii=False))


if __name__ == '__main__':
    main()
