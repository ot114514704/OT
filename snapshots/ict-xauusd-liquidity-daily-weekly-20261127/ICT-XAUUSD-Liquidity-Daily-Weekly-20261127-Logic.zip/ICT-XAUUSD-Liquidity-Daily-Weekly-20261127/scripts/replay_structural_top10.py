"""Replay the new internal and external structural lists against the prior chart."""
from bisect import bisect_left
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime,timedelta,timezone
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from brooks_ai.types import Bar
from ict_ai.structural_liquidity import structural_ranking
from scripts import replay_june_to_latest as june
from scripts import replay_ten_joint_rounds as rounds
from scripts.replay_ten_joint_rounds import joint,priority,M5,NY

BASELINE=joint.RESEARCH/'structural_top10_replay_20261122'
OUT=BASELINE
MINUTES=BASELINE/'XAUUSD_M1.json.gz'
MODEL=joint.ROOT/'ict_ai/structural_liquidity.py'


def capture():
    from scripts import export_mt5_profiles as feed

    policy=json.loads((feed.ROOT/'research/live_clock_20261116.json').read_bytes())
    if not feed.mt5.initialize():
        raise RuntimeError(feed.mt5.last_error())
    try:
        account=feed.checked_account(feed.mt5,None)
        now=datetime.now(timezone.utc)
        rows=feed.history('XAUUSD',feed.mt5.TIMEFRAME_M1,policy,now)
        feed.checked_account(feed.mt5,(account.login,account.server))
    finally:
        feed.mt5.shutdown()
    OUT.mkdir(exist_ok=True,parents=True)
    assert rows and all(a.time<b.time for a,b in zip(rows,rows[1:]))
    joint.write_zip(MINUTES,[(b.time.isoformat(),b.open,b.high,b.low,b.close) for b in rows])
    seed=dict(digest=joint.digest(MINUTES),start=rows[0].time.isoformat(),
              end=rows[-1].time.isoformat(),count=len(rows),cutoff=now.isoformat())
    (BASELINE/'m1-lock.json').write_text(json.dumps(seed,indent=2),encoding='utf-8')
    print(seed,flush=True)


def initialize():
    global bars,times,minutes,minute_times
    bars,times=priority.read_market()
    left=bisect_left(times,datetime(2026,5,24,0,tzinfo=NY))
    bars,times=bars[left:],times[left:]
    minutes=[Bar(datetime.fromisoformat(t),o,h,l,c,0) for t,o,h,l,c in joint.read_zip(MINUTES)]
    minute_times=[b.time for b in minutes]


def checkpoint(s):
    at=datetime.fromisoformat(s['at'])
    five=bars[:bisect_left(times,at)]
    assert five and five[-1].time+M5==at and five[-1].close==s['price']
    one=minutes[:bisect_left(minute_times,at)]
    has_m1=bool(one and one[-1].time+timedelta(minutes=1)==at)
    targets=structural_ranking(five,at,s['dol'],minute_bars=one if has_m1 else ())
    internal=[p for p in targets if p['classification']=='IRL']
    external=[p for p in targets if p['classification']=='ERL']
    row=dict(s,pools=internal,external=external,old_pools=s['pools'],minute_at_cutoff=has_m1)
    row['picks']={k:rounds.pick(row,k) for k in ('dol','pools')}
    return row


def freeze():
    lock=json.loads((BASELINE/'m1-lock.json').read_bytes())
    assert lock['digest']==joint.digest(MINUTES)
    old=june.OUT/'frozen.json.gz'
    assert joint.digest(old)==json.loads((june.OUT/'lock.json').read_bytes())['frozen']
    inputs=[s for s in joint.read_zip(old)
            if datetime.fromisoformat(s['at']).astimezone(NY).strftime('%H:%M') in june.CHECKPOINTS]
    rows=[]
    with ProcessPoolExecutor(max_workers=5,initializer=initialize) as pool:
        for i,row in enumerate(pool.map(checkpoint,inputs,chunksize=4),1):
            rows.append(row)
            if i%75==0:print(i,'checkpoints frozen',flush=True)
    path=OUT/'frozen.json.gz'
    OUT.mkdir(exist_ok=True,parents=True)
    joint.write_zip(path,rows)
    (OUT/'lock.json').write_text(json.dumps(dict(frozen=joint.digest(path),previous=joint.digest(old),
        minute=lock,model=joint.digest(MODEL),cutoffs=len(rows)),indent=2),encoding='utf-8')
    print(len(rows),'checkpoints frozen',flush=True)


def score():
    p=OUT/'frozen.json.gz'
    lock=json.loads((OUT/'lock.json').read_bytes())
    assert joint.digest(p)==lock['frozen']
    rows=joint.read_zip(p)
    summaries,_=rounds.evaluate(rows,june.month_index,6,OUT)
    def alternative(name,key):
        directory=OUT/name
        directory.mkdir(exist_ok=True)
        variant=[]
        for s in rows:
            item=dict(s,pools=s[key])
            item['picks']={k:rounds.pick(item,k) for k in ('dol','pools')}
            variant.append(item)
        return rounds.evaluate(variant,june.month_index,6,directory)[0]
    old_summaries=alternative('previous','old_pools')
    external_summaries=alternative('erl','external')
    if OUT!=BASELINE:
        unfiltered=json.loads((BASELINE/'summary.json').read_bytes())
    else:
        unfiltered=None
    text=['# 黄金内部与外部流动性前十联合回测','',
          '同一批纽约检查点比较旧五周期总榜与新的 IRL 和 ERL 分榜。DOL 候选沿用冻结记录。DOL 按触价核对，流动性按严格越过外沿核对。','',
          '|月份|带 M1 截点／全部截点|旧榜首四小时|IRL 榜首四小时|IRL 前十任一命中|ERL 榜首四小时|ERL 榜首周内|DOL 首名触价|',
          '|---|---:|---:|---:|---:|---:|---:|---:|']
    counts_by_month=[Counter() for _ in range(6)]
    for s in rows:
        m=counts_by_month[june.month_index(s['at'])]
        m['total']+=1
        m['m1']+=s['minute_at_cutoff']
    totals={k:Counter() for k in ('before','irl','erl','erl_week','dol')}
    for i,(a,b,c,n) in enumerate(zip(old_summaries,summaries,external_summaries,counts_by_month,strict=True),6):
        prev=a['pools_short'];current=b['pools_short'];dol=b['dol_short']
        extern=c['pools_short'];week=c['pools_week']
        text.append(f"|{i} 月|{n['m1']}/{n['total']}|{prev['current_hit']}/{prev['n']}|{current['current_hit']}/{current['n']}|"
                    f"{current['any']}/{current['n']}|{extern['current_hit']}/{extern['n']}|{week['current_hit']}/{week['n']}|{dol['current_hit']}/{dol['n']}|")
        for name,v in [('before',prev),('irl',current),('erl',extern),('erl_week',week),('dol',dol)]:totals[name].update(v)
    text+=['','M1 只用于真实聚合 M6 和 M12，榜单最低周期为 M5。M1 列按截点是否有最后一根已收分钟 K 线计。IRL 优先纽约当日及前一交易日的摆动，ERL 只认日、周、月边界。数值按窗口计，窗口可能重叠。','']
    if unfiltered:
        text+=['## 与上一版 IRL／ERL 分榜比较','',
               '新版对 M5–M12 摆动要求至少 5 根已收 M5，最多记录 10 根。每个 IRL 区域须在现价同属的纽约日、周或月区间内部。路径按更近的同侧流动性层数排序，并保留待回补 FVG 说明。新增分值为结构研究参数。','',
               '|项目|上一版榜首|新版榜首|上一版最近|新版最近|','|---|---:|---:|---:|---:|']
        for k,name in [('irl','IRL 四小时'),('erl','ERL 四小时'),('erl_week','ERL 周内'),('dol','DOL 四小时')]:
            before,after=unfiltered['totals'][k],totals[k]
            values=[f"{s.get(policy,0)}/{s['n']}" for policy in ('current_hit','nearest_hit') for s in (before,after)]
            text.append(f'|{name}|'+'|'.join(values)+'|')
        paired=Counter()
        older=joint.read_zip(BASELINE/'outcomes.json.gz')
        newer=joint.read_zip(OUT/'outcomes.json.gz')
        for old,new in zip(older,newer,strict=True):
            assert old['at']==new['at']
            a,b=old['short'],new['short']
            if a['status']==b['status']=='complete' and a['pools'] and b['pools']:
                paired['n']+=1
                paired['before']+=bool(a['pools'][0]['sweep'])
                paired['after']+=bool(b['pools'][0]['sweep'])
        text+=['',f"只比较两版都给出 IRL 的 {paired['n']} 个完整窗口，榜首越界由 "
               f"{paired['before']} 次变为 {paired['after']} 次。"
               f"新版共有 {totals['irl']['complete']-totals['irl']['n']} 个完整窗口未给出 IRL。",
               '', '这批数据已用于结构对照。结果属于历史验证，窗口可重叠，分值未经概率校准。']
    (OUT/'全周期结构联合回测.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
    (OUT/'summary.json').write_text(json.dumps(dict(irl=summaries,erl=external_summaries,previous=old_summaries,totals=totals,
        minute_coverage=counts_by_month),indent=2),encoding='utf-8')
    from scripts.plot_joint_round_examples import main as plot
    plot(OUT,june.month_index,6,'DOL 与日内内部流动性联合回测 · 每轮三张图例')
    print(dict(totals),flush=True)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('capture','freeze','score'))
    parser.add_argument('--refined',action='store_true',help='write the five-to-ten M5 swing results separately')
    args=parser.parse_args()
    if args.refined:
        OUT=joint.RESEARCH/'structural_m5_swing_replay_20261122'
    {'capture':capture,'freeze':freeze,'score':score}[args.stage]()
