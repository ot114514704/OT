"""Tie incomplete IPDA forecasts to archived TMGM quote gaps and their observable times."""
from bisect import bisect_left
from datetime import datetime, timedelta
import csv
import json
from pathlib import Path
from collections import defaultdict
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from ict_ai.h4_review import expected_gold_bar
from ict_ai.timebase import NY
from scripts.replay_pool_and_dol import digest, read_zip, RESEARCH

ARCHIVE = RESEARCH/'ipda_four_cycle_validation_20261122'
SOURCES = {
    'broker_regular_hours': 'https://www.tmgm.com/eng/trading/trading-hours',
    'exchange_holiday_calendar': 'https://www.cmegroup.com/trading-hours.html',
}
M5 = timedelta(minutes=5)
M15 = 3*M5


def after_cutoff(cutoff, m5, m15):
    times = [cutoff+i*M15 for i in range(4)]
    return [[t.astimezone(NY).isoformat(),sum(t+i*M5 in m5 for i in range(3)),t in m15]
            for t in times]


def boundary_check(day, cutoffs, m5, m15, h1, times):
    reported = datetime.fromisoformat(cutoffs[0]['other_broker_close'])
    i = bisect_left(times,reported)
    before, after = times[i-1],times[i]
    last_closed = before+M5
    earlier_candidates = [datetime.fromisoformat(r['cutoff']) for r in cutoffs]
    assert before.date()==reported.date() and expected_gold_bar(last_closed)
    boundary = before.replace(hour=before.hour-before.hour%4,minute=0)+timedelta(hours=4)
    native_bucket = before.replace(minute=0)
    h1_window = [native_bucket+i*M5 for i in range(12) if native_bucket+i*M5 in m5]
    native = h1.get(native_bucket)
    compare = None
    if h1_window and native:
        rows = [m5[t] for t in h1_window]
        reconstructed = [rows[0][0],max(r[1] for r in rows),min(r[2] for r in rows),rows[-1][3]]
        compare = all(abs(a-b)<=1e-8 for a,b in zip(native,reconstructed,strict=True))
    return dict(date_ny=day,other_broker_close=reported.isoformat(),other_broker_source=cutoffs[0]['source'],
                last_m5_open=before.astimezone(NY).isoformat(),last_m5_close=last_closed.astimezone(NY).isoformat(),
                next_m5_open=after.astimezone(NY).isoformat(),nominal_h4_close=boundary.isoformat(),
                gap_minutes=int((after-last_closed)/timedelta(minutes=1)),
                native_h1_partial_slots=len(h1_window),native_h1_prices_match=compare,
                first_unavailable_slot_known_no_earlier_than=(last_closed+M5).astimezone(NY).isoformat(),
                cutoff_count=len(earlier_candidates),details=[
                    dict(cutoff=at.isoformat(),m15_slots=after_cutoff(at,m5,m15),
                         broker_open_without_holiday=all(expected_gold_bar(at+i*M5) for i in range(12)),
                         first_missing_original=r['first_missing'],
                         can_infer_gap_by_this_cutoff=at>=last_closed+M5)
                    for at,r in zip(earlier_candidates,cutoffs,strict=True)])


def main():
    path = ARCHIVE/'round17_half_year_prices.json.gz'
    lock = json.loads((ARCHIVE/'round17_half_year_lock.json').read_bytes())
    assert digest(path)==lock['price_sha256']
    forecast = ARCHIVE/'第十七轮近半年M15下一小时逐根.csv'
    summary = json.loads((ARCHIVE/'round17_half_year_forecast.json').read_bytes())
    assert digest(forecast)==summary['csv_sha256'] and summary['price_sha256']==lock['price_sha256']
    source = ARCHIVE/'round17_forecast_checks.json'
    reported = json.loads(source.read_bytes())['incomplete_forecasts']
    data = read_zip(path)
    through = datetime.fromisoformat(data['archives_through_ny'])

    def prices(frame):
        # Archived seconds represent MT5 wall fields. Its lock fixes +7h versus NY.
        return {(datetime(1970,1,1)+timedelta(seconds=raw,hours=-7)).replace(tzinfo=NY):quotes
                for raw,*quotes in data['bars'][frame]}

    m5,m15,h1 = (prices(f) for f in ('M5','M15_complete','H1'))
    times = sorted(m5)
    grouped = defaultdict(list)
    for row in reported:
        grouped[row['cutoff'][:10]].append(row)
    checks = [boundary_check(day,cases,m5,m15,h1,times) for day,cases in grouped.items()]
    for check in checks:
        assert all(not r['can_infer_gap_by_this_cutoff'] for r in check['details'])
        for result in check['details']:
            assert result['broker_open_without_holiday']
            archived_missing = next((datetime.fromisoformat(row[0])+M15 for row in result['m15_slots']
                                     if not row[2]),None)
            assert archived_missing==datetime.fromisoformat(result['first_missing_original'])
    with forecast.open(encoding='utf-8-sig',newline='') as stream:
        ranked = [datetime.fromisoformat(row['M15收盘美东']) for row in csv.DictReader(stream)
                  if row['原指标状态']=='ranked']
    mature = [at for at in ranked if at+4*M15<=through]
    unavailable = [at for at in mature if any(not s[2] for s in after_cutoff(at,m5,m15))]
    assert {at.isoformat() for at in unavailable}=={r['cutoff'] for r in reported}
    out = RESEARCH/'ict_ipda_early_close_audit.json'
    output = dict(inputs={p.name:digest(p) for p in (path,forecast,source,Path(__file__))},
        public_sources=SOURCES,mature_ranked=len(mature),incomplete=len(unavailable),cases=checks,
        declaration='The four observed closures are locked-price evidence. Dated TMGM XAUUSD notices were '
                    'not located in the public sources. Other-broker times are sensitivity references only. '
                    'Historical gap recognition becomes available only when an expected bar fails to close.')
    out.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Mature ranked:',len(mature),'incomplete:',len(unavailable))
    for x in checks:
        print(x['date_ny'],x['last_m5_close'],x['next_m5_open'],x['native_h1_prices_match'])


if __name__=='__main__':
    main()
