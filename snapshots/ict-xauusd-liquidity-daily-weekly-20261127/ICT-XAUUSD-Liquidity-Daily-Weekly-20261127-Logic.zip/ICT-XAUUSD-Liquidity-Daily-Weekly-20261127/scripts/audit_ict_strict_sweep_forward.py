"""Compare the two pre-registered sweep states using identical live price evidence."""

from collections import Counter
from datetime import datetime, timedelta

from scripts import watch_ict_early_liquidity_response as response


LEGACY = response.OUT
STRICT = response.STRICT_OUT
REPORT = STRICT / 'paired_audit.json'
DIRECTIONAL = ('sweep', 'break')


def verify_cohort(folder, *, strict):
    policy_path = folder / 'policy.json'
    if not policy_path.is_file():
        raise FileNotFoundError(policy_path)
    previous = response.OUT, response.POLICY
    response.OUT, response.POLICY = folder, policy_path
    try:
        policy = response.load_policy(strict_state=strict)
        response.verify_summary(policy, verify=True)
        return policy
    finally:
        response.OUT, response.POLICY = previous


def registered(folder, name, cutoff, observed):
    path = folder / 'receipts' / name
    if not path.is_file():
        return None
    receipt = response.read(path)
    stamp = datetime.fromisoformat(receipt['available_at'])
    if not cutoff <= stamp < cutoff + response.M5 or stamp > observed:
        return None
    decision = response.read(folder / 'decisions' / name)
    path = folder / 'outcomes' / name
    outcome = response.read(path) if path.is_file() else None
    if outcome and datetime.fromisoformat(outcome['settled_at']) > observed:
        outcome = None
    return decision, outcome


def compare_pair(legacy, strict):
    if not legacy or not strict:
        if not legacy and not strict:
            return dict(stage='both_unregistered')
        return dict(stage='strict_unregistered' if legacy else 'legacy_unregistered')
    old_decision, old_outcome = legacy
    new_decision, new_outcome = strict
    if old_decision['quotes'] != new_decision['quotes']:
        return dict(stage='different_decision_quotes')
    statuses = {name: (decision['state2'] or {}).get('status')
                for name, decision in (('legacy', old_decision), ('strict', new_decision))}
    row = dict(legacy_state=statuses['legacy'], strict_state=statuses['strict'],
               changed=statuses['legacy'] != statuses['strict'])
    if not old_outcome or not new_outcome:
        return dict(row, stage='awaiting_settlement')
    if old_outcome['quotes'] != new_outcome['quotes'] or old_outcome['label'] != new_outcome['label']:
        return dict(row, stage='different_settlement_evidence')
    label = old_outcome['label']
    if label in DIRECTIONAL:
        return dict(row, stage='settled_directional', outcome=label,
                    legacy_match=row['legacy_state'] == label, strict_match=row['strict_state'] == label)
    return dict(row, stage='settled_' + label)


def compare(observed):
    legacy = verify_cohort(LEGACY, strict=False)
    strict = verify_cohort(STRICT, strict=True)
    freeze = max(datetime.fromisoformat(policy['frozen_at']) for policy in (legacy, strict))
    rows = []
    counts = {str(minutes): Counter() for minutes in response.WINDOWS}
    for name in sorted({p.name for folder in (LEGACY, STRICT) for p in (folder / 'events').glob('*.json')}):
        old_path, new_path = LEGACY / 'events' / name, STRICT / 'events' / name
        old = response.read(old_path) if old_path.is_file() else None
        new = response.read(new_path) if new_path.is_file() else None
        event = new or old
        crossing_close = datetime.fromisoformat(event['crossing_close'])
        if crossing_close > observed:
            continue
        for minutes in response.WINDOWS:
            cutoff = crossing_close + timedelta(minutes=minutes)
            if cutoff < freeze:
                continue
            key = f'{old_path.stem}_{minutes}.json'
            if observed < cutoff:
                result = dict(stage='awaiting_cutoff')
            elif old and new and old != new:
                result = dict(stage='different_crossing_evidence')
            else:
                result = compare_pair(registered(LEGACY, key, cutoff, observed) if old else None,
                                      registered(STRICT, key, cutoff, observed) if new else None)
                if observed < cutoff + response.M5 and result['stage'].endswith('_unregistered'):
                    result['stage'] = 'awaiting_registration'
            row = dict(event_id=old_path.stem, crossing_close=event['crossing_close'],
                       minutes=minutes, cutoff=cutoff.isoformat(), scope=event['scope'],
                       side=event['side'], edge=event['edge'], **result)
            rows.append(row)
            summary = counts[str(minutes)]
            summary[row['stage']] += 1
            if row['stage'] == 'settled_directional':
                for rule in ('legacy', 'strict'):
                    summary[f'{rule}_directional_calls'] += row[f'{rule}_state'] in DIRECTIONAL
                    summary[f'{rule}_matched'] += row[f'{rule}_match']
                summary['changed_directional'] += row['changed']
    return dict(observed_at=observed.isoformat(), common_freeze=freeze.isoformat(),
                legacy_policy_sha256=response.digest(LEGACY / 'policy.json'),
                strict_policy_sha256=response.digest(STRICT / 'policy.json'),
                outcome='Six later M5 closes all on the same side of the witnessed level',
                counts=counts, cases=rows, orders_sent=0)


def main():
    report = compare(response.live.now())
    response.live.atomic_json(REPORT, report)
    print(REPORT)
    print(report['counts'])


if __name__ == '__main__':
    main()
