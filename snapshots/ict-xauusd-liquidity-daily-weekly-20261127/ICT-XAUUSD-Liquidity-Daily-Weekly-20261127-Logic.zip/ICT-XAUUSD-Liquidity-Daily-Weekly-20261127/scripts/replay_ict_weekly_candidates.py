"""Replay the MT5 weekly classifier and compare its pre-close calls with the closed week."""
import argparse
from collections import Counter
from datetime import date, datetime, timedelta
import json
from pathlib import Path

from ict_ai.profile_lifecycle import _day_bounds, weekly_profile_lifecycle
from ict_ai.profile_sources import WEEKLY
from ict_ai.weekly_path import weekly_path
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_news import load_history


def identity(card):
    # Thursday-reversal has only one course variant, unlike consolidation-expansion.
    variant = card.get('variant') if card['id']=='weekly_consolidation_expansion' else None
    return card['id'], card.get('direction'), variant


def replay_week(bars, days, observation):
    start, end = _day_bounds(days[0])[0], _day_bounds(days[-1])[1]
    m5 = timedelta(minutes=5)
    period = 3*m5
    bars = [b for b in bars if start<=b.time<end and b.time+m5<=observation]
    if not bars:
        raise ValueError(f'No closed quotes for {days[0]}')
    m15 = aggregate_bars(bars,5,15,min(observation,end))
    live, episodes = {}, []
    errors = []
    checks = 0
    for b in m15:
        at = b.time+period
        if at>=end:
            continue
        past = [x for x in bars if x.time+m5<=at]
        past15 = aggregate_bars(past,5,15,at)
        frozen_review = weekly_path(past,days,at)
        result = weekly_profile_lifecycle(past15,days,at,frozen_review)
        batch_review = weekly_path(bars,days,at)
        if frozen_review!=batch_review or result!=weekly_profile_lifecycle(m15,days,at,batch_review):
            errors.append([at.isoformat(),'future-sensitive result'])
        if result['final_week_extreme_known'] or result['week_ended']:
            errors.append([at.isoformat(),'early finalization'])
        checks += 1
        cards = {identity(c):c for c in result['candidates'] if c['id'] in WEEKLY and c['observed_sequence']}
        for key in list(live):
            card = cards.get(key,{})
            # A fresh reclaim at a different extreme is a new hypothesis.
            same_anchor = card.get('reclaim_known_at')==live[key]['reclaim_known_at']
            if card.get('status')=='active' and same_anchor:
                continue
            reason = card.get('status','withdrawn')
            if reason=='active':
                reason='new_reclaim'
            live.pop(key).update(end=at.isoformat(),outcome=reason)
        for key,c in cards.items():
            if c['status']=='active' and key not in live:
                episode = dict(id=key[0],direction=key[1],variant=key[2],label=c['label'],
                               start=at.isoformat(),reclaim_known_at=c.get('reclaim_known_at'))
                live[key]=episode
                episodes.append(episode)
    closed = observation>=end
    cutoff = min(end,observation)
    final = weekly_profile_lifecycle(m15,days,cutoff,weekly_path(bars,days,cutoff))
    realized = {identity(c) for c in final.get('realized_candidates',[]) if c.get('id') in WEEKLY and c.get('path_complete')}
    covered = final['coverage_complete_under_study_calendar']
    comparison = closed and covered
    for key,episode in live.items():
        outcome = ('matched_at_close' if key in realized else 'unmatched_at_close') if comparison else (
            'week_in_progress' if not closed else 'insufficient_coverage')
        episode.update(end=cutoff.isoformat(),outcome=outcome)
    return dict(monday=str(days[0]),closed=closed,coverage=covered,m15_checkpoints=checks,
                close_label=final['profile_label'],episodes=episodes,errors=errors,
                close_matches_without_active_candidate=[list(k) for k in realized if k not in live] if comparison else [])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive',type=Path)
    parser.add_argument('--monday',type=date.fromisoformat,required=True)
    parser.add_argument('--weeks',type=int,default=1)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    if args.monday.weekday() or args.weeks<1:
        parser.error('Supply a Monday and a positive week count')
    meta,digest,bars=load_history(args.archive)
    observation=datetime.fromisoformat(meta['finished_at_utc'])
    weeks=[replay_week(bars.values(),[args.monday+timedelta(days=i*7+j) for j in range(5)],observation)
           for i in range(args.weeks)]
    totals=Counter(e['outcome'] for w in weeks for e in w['episodes'])
    report=dict(source_m5_sha256=digest,source_manifest=str(args.archive),observed_at=observation.isoformat(),
                episode_outcomes=dict(totals),weeks=weeks)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print([(w['monday'],w['m15_checkpoints'],len(w['errors']),w['close_matches_without_active_candidate']) for w in weeks],dict(totals))
    return int(any(w['errors'] for w in weeks))


if __name__=='__main__':
    raise SystemExit(main())
