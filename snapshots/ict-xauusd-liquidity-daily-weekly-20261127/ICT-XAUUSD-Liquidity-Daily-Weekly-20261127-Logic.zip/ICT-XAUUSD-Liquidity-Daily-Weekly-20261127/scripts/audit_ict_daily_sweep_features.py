"""Compare daily candidate scoring with causal M5 session-sweep evidence."""

from bisect import bisect_right
from collections import Counter
import json
from pathlib import Path

from ict_ai import profile_sweep_evidence as sweep
from scripts import audit_ict_daily_learning as daily
from scripts.serve_ict_live import atomic_json


OUT = daily.RESEARCH/'ict_daily_sweep_features_20261124.json'


def reviewed_days():
    manual = {}
    for path in daily.MANUAL:
        for case in json.loads(path.read_bytes())['cases']:
            if case['period'] != 'daily':
                continue
            labels = {(name,{'bullish':1,'bearish':-1,None:0}[side]) for name,side in case['reviewed']}
            if manual.setdefault(case['date'],labels)!=labels:
                raise ValueError(f"Manual review disagrees on {case['date']}")
    return manual


def annotate(days,bars,times):
    augmented = []
    checks = 0
    states = Counter()
    evidence = {}
    for row in days:
        at = row['at']
        closed = bisect_right(times,at-daily.M5)
        x = []
        events = []
        for key,values in zip(row['keys'],row['x'],strict=True):
            observed = sweep.candidate_sweep(bars,times,row['date'],at,key)
            if key[0] in sweep.SESSIONS:
                prefix = sweep.candidate_sweep(bars[:closed],times[:closed],row['date'],at,key)
                if prefix!=observed:
                    raise ValueError(f'Future candles changed session evidence at {at}: {key}')
                checks+=1
            states[observed['state']]+=1
            x.append([*values,*observed['features']])
            events.append(dict(candidate=key,**observed))
        if events:
            evidence[str(row['date'])]=events
        augmented.append(dict(row,x=x))
    return augmented,checks,states,evidence


def paired(base,trial):
    rows = []
    for old,new in zip(base['observations'],trial['observations'],strict=True):
        for key in ('date','keys','rule_y','manual_y','trained_through','training_dates'):
            if old[key]!=new[key]:
                raise ValueError(f'Cohort differs for {key} at {old["date"]}')
        rows.append(dict(new,signed_family_prior=old['learned']))
    cohorts = {'full_rule':rows, 'recent_rule':[r for r in rows if r['date'] >= '2026-10-01']}
    result = {}
    for name,part in cohorts.items():
        metrics=daily.metrics(part,'rule_y')
        interval=daily.paired_weeks(part)
        interval.pop('measure',None)
        result[name]=dict(baseline=metrics['signed_family_prior'],with_sweeps=metrics['learned'],
                          brier_improvement=interval)
    metrics=daily.metrics(rows,'manual_y')
    result['manual']=dict(baseline=metrics['signed_family_prior'],with_sweeps=metrics['learned'])
    return result


def main():
    market=daily.ARCH/'XAUUSDM5.npz'
    manifest=daily.ARCH/'manifest.json'
    expected=json.loads(manifest.read_bytes())[market.name]
    if daily.digest(market)!=expected:
        raise ValueError('TMGM archive differs from its manifest')
    bars,times=daily.read_market()
    days = daily.pack(bars,times)
    manual=reviewed_days()
    annotated,checks,states,evidence=annotate(days,bars,times)
    baseline=daily.walk_forward(days,manual)
    trial=daily.walk_forward(annotated,manual)
    comparison=paired(baseline,trial)
    atomic_json(OUT,dict(
        scope='10:00 New York ranking of existing daily-profile candidates. '
              'Only prior-week matured dates are used for fitting, excluding manual dates.',
        base_features=daily.FEATURES,added_features=sweep.FEATURES,reference_sessions=sweep.SESSIONS,
        as_of_checks=checks,evidence_states=states,comparison=comparison,evidence=evidence,
        baseline=baseline['observations'],enriched=trial['observations'],
        rule_truth='Same lifecycle reviewed at session close. Manual reviews are previously inspected.',
        inputs={p.name:daily.digest(p) for p in (market,manifest,*daily.MANUAL,Path(__file__),
                                                Path(daily.__file__),Path(sweep.__file__),
                                                Path('ict_ai/sweep_response.py'))},
        shadow_research_only=True,orders_sent=0,
    ))
    print(json.dumps(dict(checks=checks,states=states,comparison=comparison),ensure_ascii=False))


if __name__=='__main__':
    main()
