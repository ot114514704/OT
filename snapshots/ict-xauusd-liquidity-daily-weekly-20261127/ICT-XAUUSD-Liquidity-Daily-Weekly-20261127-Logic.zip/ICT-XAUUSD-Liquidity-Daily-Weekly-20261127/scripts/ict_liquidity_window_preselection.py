"""Read the actual four-bar candidate board and its subsequent evidence per M5."""

from datetime import datetime, timezone

from scripts import audit_ict_strict_sweep_forward as sweep_audit
from scripts import watch_ict_early_liquidity_response as response
from scripts import watch_ict_liquidity_window_priority as priority


source, fixed, live = response.source, response.fixed, response.live
read, digest = response.read, response.digest
OUT = live.quotes.ROOT / 'output/visualizations/ict-liquidity-window-preselection.html'
DUAL = live.quotes.ROOT / 'output/research/ict_repo_vs_local_forecast_20261125/report.json'
DEDUPLICATED = DUAL.with_name('deduplicated_rank.json')
OVERLAY = DUAL.with_name('repo_overlay.json')
OVERLAY_CONTEXT = DUAL.with_name('repo_overlay_context.json')
OVERLAY_HOLDOUT = DUAL.with_name('repo_overlay_holdout.json')
OVERLAY_STABILITY = DUAL.with_name('repo_overlay_stability.json')
OVERLAY_SOURCES = DUAL.with_name('repo_overlay_source_ablation.json')
OVERLAY_CHANGE_GATE = DUAL.with_name('repo_overlay_change_gate.json')
OVERLAY_FORWARD = DUAL.parent.with_name('ict_liquidity_repo_overlay_forward_20261125')
HISTORICAL_RANKS = DUAL.parent.parent / 'ict_liquidity_rank_15m_ticks_20261125.json'
LIVE_RANKS = priority.OUT / 'board_rank_audit.json'
LIVE_COVERAGE = source.OUT / 'coverage_audit.json'
COMPARE_ARMS = {'repo': 'original_top2', 'repo_unique': 'unique_top2', 'local': 'local_top2'}


def registered_responses(observed):
    by_edge = {}
    for strict, folder in ((False, sweep_audit.LEGACY), (True, sweep_audit.STRICT)):
        if not (folder / 'policy.json').is_file():
            continue
        policy = sweep_audit.verify_cohort(folder, strict=strict)
        frozen_at = datetime.fromisoformat(policy['frozen_at'])
        for link in sorted((folder / 'receipts').glob('*.json')):
            key, minutes = link.stem.rsplit('_', 1)
            receipt = read(link)
            ready = datetime.fromisoformat(receipt['available_at'])
            if ready > observed:
                continue
            decision = read(folder / 'decisions' / link.name)
            cutoff = datetime.fromisoformat(decision['cutoff'])
            if cutoff < frozen_at or not cutoff <= ready < cutoff + source.M5:
                continue
            event = read(folder / 'events' / f'{key}.json')
            identity = event['cutoff'], event['scope'], event['side'], event['edge']
            evidence = by_edge.setdefault(identity, {}).setdefault(minutes, {})
            state = (decision['state2'] or {}).get('status')
            if strict:
                evidence['neutral_edge'] = dict(available_at=receipt['available_at'], state=state)
            else:
                evidence.update(available_at=receipt['available_at'], v7b=decision['v7b']['status'],
                                state2=state, structure=decision['structure'])
    return by_edge


def window_rows(raw, cutoff, ready, grade, responses):
    rows = []
    for scope, pools in raw['early'].items():
        baseline = {(p['side'], p['lo'], p['hi']): p for p in raw['baseline'][scope]}
        current = float(raw['cutoff_close'])
        ordered = sorted(pools, key=lambda p: (abs(source.expiry.outer(p)[1] - current), p['rank']))
        nearest_ranks = {p['rank']: rank for rank, p in enumerate(ordered, 1)}
        outcomes = grade['outcomes']['early'][scope] if grade and grade['state'] == 'scored' else [None] * len(pools)
        for pool, outcome in zip(pools, outcomes, strict=True):
            side, edge = source.expiry.outer(pool)
            old = baseline.get((side, pool['lo'], pool['hi']))
            source_notes = pool.get('sources', ())
            early = any(f' {fixed.board.TAG}' in note for note in source_notes)
            row = dict(pool, cutoff=cutoff.isoformat(), available_at=ready.isoformat(), outer=edge,
                       scope=scope, distance_rank=nearest_ranks[pool['rank']], four_bar_anchor=early,
                       former_rank=old['rank'] if old else None, former_score=old['score'] if old else None,
                       first_m5=outcome['status'] if outcome else grade['state'] if grade else 'pending',
                       crossed_ms=outcome['bid_time_ms'] if outcome else None)
            if outcome and outcome['status'] == 'sweep':
                row['after_crossing'] = responses.get((cutoff.isoformat(), scope, side, edge), {})
            rows.append(row)
    return rows


def collect(observed):
    policy = source.load_policy()
    responses = registered_responses(observed)
    windows = []
    for receipt in sorted((source.OUT / 'receipts').glob('*.json')):
        raw, cutoff, ready = source.load_board(policy, receipt)
        if ready > observed:
            continue
        settlement = source.OUT / 'settlements' / receipt.name
        grade = None
        if cutoff + source.M5 <= observed and settlement.is_file():
            stored = read(settlement)
            bid = source.OUT / 'bid' / settlement.with_suffix('.json.gz').name
            if stored['receipts_sha256'] != digest(receipt) or stored['bid_sha256'] != digest(bid):
                raise ValueError(f'Liquid level settlement provenance changed at {cutoff}')
            grade = fixed.grade(raw, ready, fixed.board.joint.read_zip(bid), 1)
            if source.paired(grade) != stored['paired'] or grade['state'] != stored['state']:
                raise ValueError(f'Could not reproduce the first M5 settlement at {cutoff}')
        windows.append(dict(cutoff=cutoff.isoformat(), price=raw['cutoff_close'], available_at=ready.isoformat(),
                            chart_receipt=raw['chart_receipt'], candidates=window_rows(raw, cutoff, ready, grade, responses),
                            qualified_sides=raw['potential_sides']))
    return windows


def overlay_source_summary(stability):
    audit = read(OVERLAY_SOURCES)
    if any(audit['inputs'][path.name] != digest(path) for path in (OVERLAY_STABILITY, OVERLAY, OVERLAY_HOLDOUT, DEDUPLICATED)):
        raise ValueError('The source comparison references different H1 windows')
    totals = audit['pooled']
    baseline = stability['results']['15']['pooled']['counts']
    if (totals['windows'], totals['local'], totals['variants']['full']['hits']) != (
            baseline['windows'], baseline['local'], baseline['combined']):
        raise ValueError('The source comparison does not reproduce the reference totals')
    examples = []
    for windows in audit['windows'].values():
        for window in windows:
            if any(state == 'sweep' for _, state, _ in window['variants']['without_wave']):
                continue
            hits = [dict(side=side, edge=edge, at=datetime.fromtimestamp(stamp / 1000, timezone.utc).isoformat())
                    for (side, edge), state, stamp in window['variants']['full'] if state == 'sweep']
            if hits:
                examples.append(dict(cutoff=window['cutoff'], hits=hits,
                                     alternative=[edge for edge, _, _ in window['variants']['without_wave']]))
    if len(examples) != totals['variants']['without_wave']['full_lost']:
        raise ValueError('The wave-dependent cases do not reproduce the summary')
    return dict(totals=totals, wave_examples=examples)


def comparison_summary(observed):
    summaries = {}
    if sweep_audit.REPORT.is_file():
        audit = read(sweep_audit.REPORT)
        for rule, folder in (('legacy', sweep_audit.LEGACY), ('strict', sweep_audit.STRICT)):
            if audit[f'{rule}_policy_sha256'] != digest(folder / 'policy.json'):
                raise ValueError('The sweep comparison references a different registration policy')
        if datetime.fromisoformat(audit['observed_at']) <= observed:
            summaries['sweep_forward'] = {key: audit[key] for key in ('observed_at', 'common_freeze', 'counts')}
    if DEDUPLICATED.is_file() and DUAL.is_file():
        audit = read(DEDUPLICATED)
        if audit['inputs'][DUAL.name] != digest(DUAL):
            raise ValueError('The comparison references different frozen forecasts')
        for horizons in audit['results'].values():
            for result in horizons.values():
                cases, counts = result['cases'], result['counts']
                if len({case['cutoff'] for case in cases}) != len(cases) or len(cases) != counts['windows']:
                    raise ValueError('Replay windows do not match the comparison totals')
                for arm, key in COMPARE_ARMS.items():
                    hits = sum(any(mark['status'] == 'sweep' for mark in case['outcomes'][arm]) for case in cases)
                    if hits != counts[key]:
                        raise ValueError(f'Replay hits do not match the comparison totals: {arm}')
        comparison = read(DUAL)
        summaries['dual'] = dict(week_end=comparison['current_week']['end'], results=audit['results'],
                                 native=audit['native_120_bar'], audit_sha256=digest(DEDUPLICATED))
        if OVERLAY.is_file():
            blend = read(OVERLAY)
            if blend['inputs'][DEDUPLICATED.name] != summaries['dual']['audit_sha256']:
                raise ValueError('The supplemental comparison references a different replay')
            summaries['overlay'] = {group: {minutes: result['counts'] for minutes, result in horizons.items()}
                                    for group, horizons in blend['results'].items()}
            if OVERLAY_HOLDOUT.is_file():
                holdout = read(OVERLAY_HOLDOUT)
                if holdout['inputs'][DUAL.name] != digest(DUAL):
                    raise ValueError('The earlier-sample comparison references a different model')
                summaries['overlay_holdout'] = {key: holdout[key] for key in ('start', 'end_exclusive', 'results')}
                if OVERLAY_STABILITY.is_file():
                    stability = read(OVERLAY_STABILITY)
                    if any(stability['inputs'][path.name] != digest(path) for path in (OVERLAY, OVERLAY_HOLDOUT)):
                        raise ValueError('The pooled comparison references different cohorts')
                    summaries['overlay_stability'] = {minutes: {key: val for key, val in row['pooled'].items()
                                                               if key != 'weeks'}
                                                    for minutes, row in stability['results'].items()}
                    if OVERLAY_SOURCES.is_file():
                        summaries['overlay_sources'] = overlay_source_summary(stability)
                    if OVERLAY_CHANGE_GATE.is_file():
                        gate = read(OVERLAY_CHANGE_GATE)
                        if gate['inputs'][OVERLAY_STABILITY.name] != digest(OVERLAY_STABILITY):
                            raise ValueError('The replacement-gate comparison references different evidence')
                        summaries['overlay_change_gate'] = dict(gate=gate['gate'], groups={group: {
                            key: cell[key] for key in ('original', 'filtered')} for group, cell in gate['results'].items()})
            if OVERLAY_CONTEXT.is_file():
                context = read(OVERLAY_CONTEXT)
                if context['inputs'][OVERLAY.name] != digest(OVERLAY):
                    raise ValueError('The session comparison references a different replay')
                summaries['overlay_context'] = {group: {key: study['15'][key] for key in ('session', 'daily')}
                                                for group, study in context['results'].items()}
            state_file = OVERLAY_FORWARD / 'status.json'
            if state_file.is_file():
                policy_path = OVERLAY_FORWARD / 'policy.json'
                policy = read(policy_path)
                if policy['pins'][OVERLAY.name] != digest(OVERLAY):
                    raise ValueError('The prospective comparison references different replay rules')
                state = read(state_file)
                if datetime.fromisoformat(state['observed_at']) <= observed:
                    summaries['overlay_forward'] = state
                source_file = OVERLAY_FORWARD / 'source_audit.json'
                if source_file.is_file():
                    evidence = read(source_file)
                    if evidence['policy_sha256'] != digest(policy_path):
                        raise ValueError('The prospective source comparison refers to a different policy')
                    if datetime.fromisoformat(evidence['observed_at']) <= observed:
                        summaries['overlay_forward_sources'] = {key: evidence[key] for key in ('observed_at', 'counts', 'windows')}
    if HISTORICAL_RANKS.is_file():
        audit = read(HISTORICAL_RANKS)
        previous = HISTORICAL_RANKS.with_name('ict_liquidity_rank_prev_period_20261125.json')
        if audit['inputs'][previous.name] != digest(previous):
            raise ValueError('The rank replay references a different historical baseline')
        summaries['historical'] = dict(start=audit['start'], end_exclusive=audit['end_exclusive'], ranks={
            delay: {scope: {key: row[key] for key in ('windows', 'with_first_crossing', 'wins')}
                    for scope, row in scopes.items()} for delay, scopes in audit['results'].items()})
    if LIVE_RANKS.is_file():
        audit = read(LIVE_RANKS)
        if audit['native_board_policy_sha256'] != digest(source.POLICY):
            raise ValueError('The live rank comparison references a different registration policy')
        if datetime.fromisoformat(audit['observed_at']) <= observed:
            summaries['live'] = dict(observed_at=audit['observed_at'], ranks={
                minutes: result['totals'] for minutes, result in audit['results'].items()})
    if LIVE_COVERAGE.is_file():
        audit = read(LIVE_COVERAGE)
        if audit['input_hashes'][source.POLICY.name] != digest(source.POLICY):
            raise ValueError('The coverage audit references a different registration policy')
        if datetime.fromisoformat(audit['observed_at']) <= observed:
            summaries['coverage'] = {key: audit[key] for key in ('observed_at', 'counts', 'windows', 'h1_cutoffs', 'h1_counts')}
    return summaries


def write_report(render):
    if not source.POLICY.is_file():
        raise FileNotFoundError(source.POLICY)
    now = datetime.now(timezone.utc)
    windows = collect(now)
    published = None
    if priority.POLICY.is_file():
        verification = priority.status(priority.load_policy(), source.load_policy(), verify=True)
        latest = verification['latest']
        if latest and datetime.fromisoformat(latest['available_at']) <= now:
            published = latest
    dual = None
    if DUAL.is_file():
        comparison = read(DUAL)
        tape = DUAL.with_name('tm_gm_native_high_periods.json.gz')
        if comparison['inputs'][tape.name] != digest(tape):
            raise ValueError('The dual forecast points to a different native quote snapshot')
        if datetime.fromisoformat(comparison['observed_at']) <= now:
            dual = dict(observed_at=comparison['observed_at'], current=comparison['current'],
                        upstream_commit=comparison['upstream_commit'])
        latest_path = DUAL.with_name('latest_forecast.json')
        if latest_path.is_file():
            latest = read(latest_path)
            latest_tape = DUAL.with_name('latest_native_quotes.json.gz')
            if latest['tape_sha256'] != digest(latest_tape) or latest['model_sha256'] != comparison['model_sha256']:
                raise ValueError('The refreshed forecasts use different quotes or model weights')
            if datetime.fromisoformat(latest['observed_at']) <= now:
                dual = {key: latest[key] for key in ('observed_at', 'current', 'upstream_commit')}
    summary = dict(observed_at=now.isoformat(), windows=windows, published_priority=published,
                   comparisons=comparison_summary(now), dual_forecast=dual, orders_sent=0)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    live.atomic_json(OUT.with_suffix('.json'), summary)
    temporary = OUT.with_suffix('.tmp.html')
    temporary.write_text(render(summary), encoding='utf-8')
    live.feed.replace_with_retry(temporary, OUT)
    print(f'{len(windows)} verified window boards. {OUT}')
