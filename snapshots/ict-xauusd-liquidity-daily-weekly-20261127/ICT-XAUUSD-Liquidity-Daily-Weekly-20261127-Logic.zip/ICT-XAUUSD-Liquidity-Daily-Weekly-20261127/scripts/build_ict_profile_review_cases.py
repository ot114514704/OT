"""Select fixed complete weeks and expose archived candles for blind price review."""
from argparse import ArgumentParser
from datetime import datetime, time, timedelta
from hashlib import sha256
import json
from pathlib import Path

from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_news import NY, ROOT, STEP
from scripts.replay_ict_route_checkpoints import merge_history


SELECTION = "ipda-time-price-review-v1-20261121"
VALIDATION_SELECTION = "ipda-time-price-review-v2-20261121"


def complete_weeks(quotes):
    dates = sorted({at.astimezone(NY).date() for at in quotes if at.astimezone(NY).weekday() == 0})
    complete = []
    for monday in dates:
        acceptable = True
        for n in range(5):
            day = monday + timedelta(days=n)
            start = datetime.combine(day, time.min, NY)
            end = (datetime.combine(day, time(16, 55), NY) if n == 4
                   else datetime.combine(day + timedelta(days=1), time.min, NY))
            times = [start + i * STEP for i in range((end - start) // STEP)]
            if not all(at.hour == 17 or at in quotes for at in times):
                acceptable = False
                break
        if acceptable:
            complete.append(monday)
    return complete


def choose_weeks(complete):
    # One completed week per side of the November clock change; selection
    # uses the date and coverage only, without reading any classifier output.
    cutoff = datetime(2026, 11, 1).date()
    return [min((day for day in complete if predicate(day)), key=lambda day: sha256(
        f"{SELECTION}|{day.isoformat()}".encode()).hexdigest())
        for predicate in (lambda d: d < cutoff, lambda d: d > cutoff)]


def validation_days(quotes, week):
    days = [week + timedelta(days=i) for i in range(5)]

    def opening_width_ratio(day):
        start = datetime.combine(day, time.min, NY)
        bars = [quotes[start + i * STEP] for i in range(18)]

        def width(rows):
            return max(bar.high for bar in rows) - min(bar.low for bar in rows)

        return width(bars[:8]) / max(width(bars), 1e-9)

    compact = min(days, key=opening_width_ratio)
    control = min((day for day in days if day != compact), key=lambda day: sha256(
        f"{VALIDATION_SELECTION}|{day.isoformat()}".encode()).hexdigest())
    return {compact, control}


def points(series, origin):
    return [[(b.time - origin).total_seconds() / 3600, b.open, b.high, b.low, b.close] for b in series]


def build(early, late, output, key_path, *, validation=False):
    quotes, sources, _, cutoff = merge_history(early, late)
    raw = list(quotes.values())
    quarter = aggregate_bars(raw, 5, 15, cutoff)
    hour = aggregate_bars(raw, 5, 60, cutoff)
    figures, keys = [], {}
    complete = complete_weeks(quotes)
    original = choose_weeks(complete)
    weeks = [week for week in complete if week not in original] if validation else original
    for i, week in enumerate(weeks, 1):
        identifier = f"{'V' if validation else 'W'}{i}"
        keys[identifier] = week.isoformat()
        start = datetime.combine(week, time.min, NY)
        end = datetime.combine(week + timedelta(days=4), time(16, 55), NY)
        figures.append({"id": identifier, "kind": "week", "points": points(
            [b for b in hour if start <= b.time and b.time + timedelta(hours=1) <= end] +
            [b for b in raw if end - timedelta(minutes=55) <= b.time < end], start),
            "axis_end": 4 * 24 + 16 + 55/60})
        selected_days = validation_days(quotes, week) if validation else None
        for n in range(5):
            day = week + timedelta(days=n)
            if selected_days is not None and day not in selected_days:
                continue
            name = f"{identifier} · D{n+1}"
            start = datetime.combine(day, time.min, NY)
            end = (datetime.combine(day, time(16, 55), NY) if n == 4
                   else datetime.combine(day + timedelta(days=1), time.min, NY))
            subset = [b for b in quarter if start - timedelta(hours=4) <= b.time
                      and b.time + timedelta(minutes=15) <= end]
            if n == 4:
                subset.extend(b for b in raw if end - 2 * STEP <= b.time < end)
            figures.append({"id": name, "kind": "day", "points": points(subset, start),
                            "axis_end": (end - start).total_seconds() / 3600})
            keys[name] = day.isoformat()
    html = (ROOT / "scripts/ict_price_review_cases.html").read_text(encoding="utf-8")
    payload = json.dumps(figures, separators=(",", ":")).replace("<", "\\u003c")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html.replace("/*__CASES__*/", payload, 1), encoding="utf-8")
    key_path.parent.mkdir(parents=True, exist_ok=True)
    key_path.write_text(json.dumps({"sampling": VALIDATION_SELECTION if validation else SELECTION,
                                    "keys": keys, "sources": sources,
                                    "chart_sha256": sha256(output.read_bytes()).hexdigest()}, indent=2) + "\n",
                        encoding="utf-8")


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--early", type=Path, required=True)
    cli.add_argument("--late", type=Path, required=True)
    cli.add_argument("--out", type=Path, required=True)
    cli.add_argument("--key", type=Path, required=True)
    cli.add_argument("--validation", action="store_true")
    args = cli.parse_args()
    build(args.early, args.late, args.out, args.key, validation=args.validation)
