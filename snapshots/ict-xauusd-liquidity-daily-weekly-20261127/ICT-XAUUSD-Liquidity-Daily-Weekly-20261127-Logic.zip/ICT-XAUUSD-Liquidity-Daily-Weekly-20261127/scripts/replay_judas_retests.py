"""Replay XAU Judas recognition and subsequent price structure on recorded Bid quotes."""
import argparse
from datetime import datetime, timedelta, timezone
import gzip
import hashlib
import json
from pathlib import Path

from brooks_ai.tickbacktest import aggregate_ticks
from brooks_ai.types import Bar, Tick
from ict_ai.judas import STEP, judas_history
from ict_ai.timebase import NY, manifest_epoch_to_utc
from scripts.audit_mt5_ticks import fetch_period
from scripts.export_mt5_native import native_time


def quote_contact(ticks,low,high,start,end):
    for tick in ticks:
        if start<=tick.time<end and low<=tick.bid<=high:
            return dict(utc=tick.time.isoformat(),bid=tick.bid,ask=tick.ask,
                        spread=round(tick.ask-tick.bid,8))
    return None


def collect(cases, path, source, digest, terminal):
    import MetaTrader5 as mt5
    if not mt5.initialize(str(terminal),timeout=10000):
        raise RuntimeError(str(mt5.last_error()))
    try:
        account=mt5.account_info()
        if account is None or account.server!=source['server']:
            raise RuntimeError('Expected the server recorded in the XAU archive')
        identity=(account.login,account.server)
        grid=mt5.symbol_info('XAUUSD').trade_tick_size
        probes={}
        for event in cases:
            t=event['known']
            # Buffer both ends so all twelve interior M5 bars can be reconciled.
            bounds=[datetime.strptime(native_time(v.isoformat(),source['clock']),'%Y.%m.%d %H:%M:%S')
                    .replace(tzinfo=timezone.utc) for v in (t-STEP,t+13*STEP)]
            raw,_=fetch_period(mt5,'XAUUSD',*bounds,identity,maximum=300000)
            probes[t.isoformat()]=[[q.time.isoformat(),q.bid,q.ask] for q in raw]
        payload=dict(source_sha256=digest,server=account.server,grid=grid,
                     captured=datetime.now(timezone.utc).isoformat(),probes=probes)
        packed=gzip.compress(json.dumps(payload,separators=(',',':')).encode())
        with path.open('xb') as out:
            out.write(packed)
    finally:
        mt5.shutdown()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive',type=Path,required=True)
    p.add_argument('--news',type=Path,required=True)
    p.add_argument('--quotes',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--collect-from',type=Path,help='Existing MT5 terminal for a new read-only archive')
    args=p.parse_args()
    raw=args.archive.read_bytes()
    digest=hashlib.sha256(raw).hexdigest()
    source=json.loads(gzip.decompress(raw))
    news_raw=args.news.read_bytes()
    releases=[(datetime.fromisoformat(d+'T'+t).replace(tzinfo=NY),tag)
              for d,t,tag in json.loads(news_raw)['events']]
    bars=[Bar(datetime.fromisoformat(t),o,h,l,c,0) for t,o,h,l,c in source['series']['XAUUSDM5']]
    as_of=datetime.fromisoformat(source['at'])
    cases=judas_history(bars,as_of,releases)
    if not args.quotes.exists():
        if not args.collect_from:p.error('Provide an existing tick archive or --collect-from')
        args.quotes.parent.mkdir(parents=True,exist_ok=True)
        collect(cases,args.quotes,source,digest,args.collect_from)
    quote_raw=args.quotes.read_bytes()
    data=json.loads(gzip.decompress(quote_raw))
    if data['source_sha256']!=digest or data['server']!=source['server']:
        raise ValueError('Tick archive and bar archive differ')
    report=dict(symbol='XAUUSD',server=data['server'],source_sha256=digest,
                ticks_sha256=hashlib.sha256(quote_raw).hexdigest(),news_sha256=hashlib.sha256(news_raw).hexdigest(),
                scope='All recognized cases in supplied M5 history; 60 minutes starting at confirmation close',
                clock_policy=source['clock'],
                coverage_note='OHLC reconciliation checks available Bid ticks; broker execution and queue not observed.',
                first_bar_utc=bars[0].time.isoformat(),as_of=as_of.isoformat(),cases=[])
    for e in cases:
        at=e['known'];end=at+12*STEP
        prefix=[b for b in bars if b.time+STEP<=at]
        if e not in judas_history(prefix,at,releases):
            raise AssertionError('Signal changed when future prices were hidden')
        observed=data['probes'][at.isoformat()]
        ticks=[Tick(manifest_epoch_to_utc(datetime.fromisoformat(t),source['clock']),bid,ask)
               for t,bid,ask in observed]
        expected={b.time:(b.open,b.high,b.low,b.close) for b in bars if at<=b.time<end}
        reconstructed,_=aggregate_ticks(ticks,300)
        matches=sum(expected.get(b.time)==(b.open,b.high,b.low,b.close) for b in reconstructed if at<=b.time<end)
        window=[b for b in bars if at<=b.time<end]
        touch=next((b for b in window if b.high>=e['lo'] and b.low<=e['hi']),None)
        broken=next((b for b in window if e['side']*(b.close-e['edge'])<0),None)
        follow=next((b for b in window if e['side']*(b.close-e['confirm'])>0),None)
        report['cases'].append(dict(confirmed_ny=at.astimezone(NY).isoformat(),direction=e['side'],
            sweep_price=e['edge'],gap=[e['lo'],e['hi']],prefix_verified=True,
            observed_quotes=sum(at<=q.time<end for q in ticks),matching_m5=matches,expected_m5=12,
            first_bid_bar_overlap_close_utc=(touch.time+STEP).isoformat() if touch else None,
            price_basis='Bid (same as XAU chart candles)',
            first_observed_zone_quote=quote_contact(ticks,e['lo'],e['hi'],at,end) if matches==12 else None,
            quote_outcome='aligned' if matches==12 else 'insufficient_quote_evidence',
            close_beyond_sweep_utc=(broken.time+STEP).isoformat() if broken else None,
            first_followthrough_close_utc=(follow.time+STEP).isoformat() if follow else None,
            end_close=window[-1].close if window else None))
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for row in report['cases']:
        print(row['confirmed_ny'],row['quote_outcome'],row['matching_m5'])


if __name__=='__main__':
    main()
