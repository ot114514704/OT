"""Compare bar-spread and recorded Bid/Ask simulations on frozen Silver windows."""
from argparse import ArgumentParser
from bisect import bisect_left, bisect_right
from dataclasses import asdict, replace
from datetime import datetime, time, timedelta
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from hashlib import sha256
import json
from pathlib import Path

from brooks_ai.data import load_ticks
from brooks_ai.tickbacktest import aggregate_ticks
from brooks_ai.types import Instrument, utc_time
from ict_ai.backtest import LimitStudyOrder
from ict_ai.features import geometric_fvgs
from ict_ai.silver_bullet import silver_bullet_windows
from ict_ai.silver_execution import simulate_silver_limit
from ict_ai.tick_limit import simulate_tick_limit
from ict_ai.timebase import manifest_epoch_to_utc
from scripts.replay_ict_news import NY, ROOT, STEP, load_history


def prices(bar):
    return bar.open, bar.high, bar.low, bar.close


def aligned_ticks(path, spec, meta, quotes):
    provenance = json.loads(path.with_suffix(path.suffix + ".provenance.json").read_bytes())
    digest = sha256(path.read_bytes()).hexdigest()
    if (provenance["symbol"] != spec.symbol or provenance["server"] != meta["server"]
            or provenance["synthetic"] is not False or digest != provenance["data_sha256"]):
        raise ValueError("Require the original archived TMGM tick data")
    ticks = load_ticks(path, spec)
    if len(ticks) != provenance["ticks"]:
        raise ValueError("Tick count differs from provenance")
    buckets, _ = aggregate_ticks(ticks, 300)
    offset = meta["source_clock_offset_hours"]
    comparisons = {}
    for hours in sorted({0, 2, 3, offset}):
        shift = timedelta(hours=hours)
        aligned = {bar.time - shift: prices(bar) for bar in buckets}
        compared = set(aligned) & set(quotes)
        matching = {stamp for stamp in compared if prices(quotes[stamp]) == aligned[stamp]}
        comparisons[str(hours)] = {"compared": len(compared), "exact_ohlc_matches": len(matching)}
    # Apply the archive's own clock policy before grouping ticks. Preserve
    # original order, including equal millisecond timestamps across a fill.
    normalized = [replace(q,time=manifest_epoch_to_utc(q.time,meta)) for q in ticks]
    corrected, _ = aggregate_ticks(normalized, 300)
    compared = [b for b in corrected if b.time in quotes]
    aligned_buckets = {b.time for b in compared if prices(quotes[b.time])==prices(b)}
    if meta.get("source_clock_segments"):
        comparisons["manifest_segments"] = {"compared":len(compared),"exact_ohlc_matches":len(aligned_buckets)}
    if not aligned_buckets:
        raise ValueError("Recorded tick clock does not reproduce archive candles")
    return normalized, aligned_buckets, comparisons, digest


def study_order(gap, end, spec, identifier):
    side = 1 if gap["direction"] == "bullish" else -1
    low, high = map(lambda price: Decimal(str(price)), (gap["lower"], gap["upper"]))
    grid = Decimal(str(spec.tick_size))
    rounding = ROUND_FLOOR if side == 1 else ROUND_CEILING
    entry = ((low + high) / (2 * grid)).to_integral_value(rounding) * grid
    stop = low - grid if side == 1 else high + grid
    target = entry + 2 * (entry - stop)
    return LimitStudyOrder(identifier, side, utc_time(gap["available_at"]), end,
                           float(entry), float(stop), float(target), spec.volume_min)


def run(manifest, tick_path):
    meta, bar_sha, quotes = load_history(manifest)
    contract = meta["current_symbol_observation"]
    spec = Instrument(meta["symbol"], contract["point"], contract["trade_tick_size"], contract["trade_contract_size"],
                      contract["volume_min"], contract["volume_step"], contract["volume_max"],
                      account_currency=meta["account_currency"], profit_currency=contract["currency_profit"],
                      commission_round_turn=7.0, slippage=.05)
    ticks, matching, clocks, tick_sha = aligned_ticks(tick_path, spec, meta, quotes)
    times = [tick.time for tick in ticks]
    first, last = times[0], times[-1]
    last_day = last.astimezone(NY).date()
    days = [first.astimezone(NY).date() + timedelta(days=i)
            for i in range((last_day - first.astimezone(NY).date()).days + 1)]
    bars = [bar for stamp, bar in quotes.items() if first - 3 * STEP <= stamp <= last]
    gaps = geometric_fvgs(bars, STEP, last)
    cases, exclusions = [], []
    prefix_checks = 0
    for day in days:
        flat = utc_time(datetime.combine(day, time(16, 50), NY))
        after_flat = flat + STEP
        for window in silver_bullet_windows(day):
            start = utc_time(window["start_ms"] / 1000)
            end = utc_time(window["end_ms"] / 1000)
            label = {"date_ny": day.isoformat(), "window": window["id"]}
            if start < first or flat > last:
                exclusions.append({**label, "reason": "archive does not cover window through intraday flatten"})
                continue
            required = {start + i * STEP for i in range((flat - start) // STEP)}
            if not required <= matching:
                exclusions.append({**label, "reason": "expected quote buckets and recorded M5 did not reconcile",
                                   "unmatched_m5": len(required - matching)})
                continue
            available = [gap for gap in gaps if start <= utc_time(gap["available_at"]) < end]
            if not available:
                exclusions.append({**label, "reason": "no geometric FVG confirmed within the window"})
                continue
            gap = available[0]
            identifier = f"{day}-{window['id']}-first-confirmed"
            order = study_order(gap, end, spec, identifier)
            prefix = [bar for bar in bars if bar.time + STEP <= order.available_at]
            seen = geometric_fvgs(prefix, STEP, order.available_at)
            if next(item for item in seen if utc_time(item["available_at"]) >= start) != gap:
                raise AssertionError("Future prices changed FVG selection")
            tick_cutoff = min(last, after_flat)
            samples = ticks[bisect_left(times, order.available_at):bisect_right(times, tick_cutoff)]
            tick_result = simulate_tick_limit(order, samples, spec, tick_cutoff)
            bar_result = simulate_silver_limit(order, gap["available_at"], bars, spec, after_flat, day, window["id"])
            cutoffs = {order.available_at, end, tick_cutoff}
            for field in ("entry_known_at", "outcome_available_at"):
                if tick_result.get(field):
                    moment = utc_time(tick_result[field])
                    cutoffs.update((moment, moment - timedelta(microseconds=1)))
            for cutoff in cutoffs:
                prior_samples = [tick for tick in samples if tick.time <= cutoff]
                if simulate_tick_limit(order, samples, spec, cutoff) != simulate_tick_limit(
                        order, prior_samples, spec, cutoff):
                    raise AssertionError("Quote replay read beyond its cutoff")
                prefix_checks += 1
            cases.append({**label, "fvg": gap, "matched_m5_in_window": len(required),
                          "order": asdict(order), "m5_simulation": bar_result, "tick_simulation": tick_result})
    paths = ("ict_ai/tick_limit.py", "ict_ai/backtest.py", "ict_ai/silver_execution.py", "ict_ai/features.py",
             "ict_ai/silver_bullet.py", "ict_ai/timebase.py", "brooks_ai/tickbacktest.py", "scripts/replay_ict_silver_tick_fills.py")
    return {"manifest": str(manifest), "m5_sha256": bar_sha, "tick_data": str(tick_path), "tick_sha256": tick_sha,
            "code_sha256": {path: sha256((ROOT / path).read_bytes()).hexdigest() for path in paths},
            "clock_comparison_by_subtracted_hours": clocks, "recorded_ticks": len(ticks), "spec_assumptions": asdict(spec),
            "selections": cases, "excluded": exclusions, "quote_prefix_checks": prefix_checks,
            "limits": [
                "Fixed protocol: earliest closed M5 geometric FVG per Silver window, midpoint rounded away from market, "
                "one tick past far edge, 2R, minimum lot, limit expires at window end.",
                "Recorded Ask/Bid replaces the constant bar-spread proxy. Tick entry uses executable quote on the first touch. "
                "Limit queues, depth and execution are not observed.",
                "Commission, slippage and historical contract conditions remain assumptions. Same day duplicates "
                "are not an independent sample. No ICT bias/DOL strategy or performance inference.",
            ],
            "model_trained": False, "execution_allowed": False, "orders_sent": 0}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--ticks", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    report = run(args.manifest, args.ticks)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=lambda t: t.isoformat()) + "\n",
                        encoding="utf-8")
    print(len(report["selections"]), report["clock_comparison_by_subtracted_hours"])
