"""Replay the frozen two-slot H1 overlay on earlier real TMGM quotations."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import date, datetime, timedelta
import json
from pathlib import Path

import joblib
from threadpoolctl import threadpool_limits

from ict_ai.dol_history import week_start
from ict_ai.liquidity_repo_overlay import compare_shortlists, outside
from ict_ai.range_liquidity import _research_open
from scripts import audit_ict_liquidity_repo_overlay as overlay
from scripts import audit_ict_repo_liquidity_dedup as score


upstream, prior = score.upstream, overlay.prior
joint, board, fixed, live = prior.joint, prior.board, prior.fixed, prior.live
OUT = overlay.OUT.with_name('repo_overlay_holdout.json')
BID = OUT.with_suffix('.json.gz')
START, END = date(2026, 6, 1), date(2026, 10, 1)
M5 = fixed.M5


def aligned_checkpoints(line):
    lock = fixed.read(board.LOCK)
    if lock['candidates'] != joint.digest(board.FROZEN) or any(
            joint.digest(joint.ROOT / name) != expected for name, expected in lock['sources'].items()):
        raise ValueError('Original price and candidate archive changed')
    snapshots = {row['at']: row for row in joint.read_zip(board.INIT)}
    checks, excluded = [], {}
    for row in joint.read_zip(board.FROZEN):
        stamp = row['at']
        at = datetime.fromisoformat(stamp)
        if not START <= at.astimezone(board.NY).date() < END:
            continue
        target = int(at.timestamp())
        n = bisect_left(line.closes, target)
        if n == len(line.closes) or line.closes[n] != target:
            excluded[stamp] = 'non_aligned_h1'
        elif line.close[n] != row['price']:
            excluded[stamp] = 'different_frozen_close'
        elif not all(_research_open(at + i * M5) for i in range(3)):
            excluded[stamp] = 'market_break'
        else:
            checks.append((n, (snapshots[stamp], row, len(checks) % 25 == 0)))
    return checks, excluded


def tape_for(checks, pid, pins):
    expected = sorted({at + i * M5 for _, (_, row, _) in checks
                       for at in (datetime.fromisoformat(row['at']),) for i in range(3)})
    if pid:
        with fixed.open_terminal(pid) as alive:
            captured = {at.isoformat(): bucket for at, bucket in fixed.capture_buckets(
                live.feed.mt5, alive, fixed.frozen_feed(), expected, live.now())}
        staging = BID.with_suffix('.tmp')
        joint.write_zip(staging, dict(pins=pins, buckets=captured, requested=len(expected)))
        live.feed.replace_with_retry(staging, BID)
        print(f'Captured {len(captured)}/{len(expected)} requested timestamped Bid buckets', flush=True)
    proof = joint.read_zip(BID)
    if proof['pins'] != pins or proof['requested'] != len(expected):
        raise ValueError('Bid tape references a different study')
    return proof['buckets']


def evaluate(rebuilt, upstream_targets, close, tape, delay, count):
    at = datetime.fromisoformat(rebuilt['at'])
    ready = at + timedelta(seconds=delay)
    buckets = tape[:count]
    local = rebuilt['after']['ERL']
    choices = prior.rank.picks(local, close)
    base = [dict(side=side, lo=edge, hi=edge) for side, edge in choices['score_2']]
    picks = compare_shortlists(base, upstream_targets, close)
    nearest = [dict(side=side, lo=edge, hi=edge) for side, edge in choices['near_plus_score']]
    arms = dict(repo=upstream_targets, local=picks['local'], integrated=picks['fixed_two'],
                supplement=picks['supplement'], local_mixed=nearest)
    outcomes = {}
    for name, candidates in arms.items():
        outcomes[name] = [dict(side=side, price=edge, state=state, bid_time_ms=ms) for candidate in candidates
                          for side, edge in (outside(candidate),) for state, ms in (fixed.outcome(candidate, buckets, ready),)]
    wins = {name: any(mark['state'] == 'sweep' for mark in rows) for name, rows in outcomes.items()}
    return dict(checked_from=ready.isoformat(), wins=wins, outcomes=outcomes)


def summarize(cases):
    result, weeks = defaultdict(Counter), defaultdict(lambda: defaultdict(Counter))
    for case in cases:
        for label, observation in case['results'].items():
            wins = observation['wins']
            delta = {key: int(value) for key, value in wins.items()}
            delta.update(windows=1, gained=int(wins['integrated'] and not wins['local']),
                         lost=int(wins['local'] and not wins['integrated']))
            result[label].update(delta)
            week = week_start(datetime.fromisoformat(case['cutoff']).astimezone(board.NY).date()).isoformat()
            weeks[label][week].update(delta)
    return result, weeks


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture-terminal-pid', type=int)
    args = parser.parse_args()
    report = fixed.read(upstream.REPORT)
    paths = (upstream.MODEL, upstream.TAPE, upstream.REPORT, board.FROZEN, board.LOCK, board.INIT,
             Path(board.__file__), Path(upstream.__file__), Path(__file__), joint.ROOT / 'ict_ai/liquidity_repo_overlay.py')
    pins = {p.name: joint.digest(p) for p in paths}
    if (report['model_sha256'] != pins[upstream.MODEL.name] or report['sklearn'] != upstream.sklearn_version
            or report['inputs'][upstream.TAPE.name] != pins[upstream.TAPE.name]):
        raise ValueError('The repository training and market snapshots changed')
    levels, _, feat, _ = upstream.load_sources()
    native = joint.read_zip(upstream.TAPE)
    line = upstream.native_series(native, levels)['H1']
    checks, exclusions = aligned_checkpoints(line)
    packets = tape_for(checks, args.capture_terminal_pid, pins)
    archive, _ = board.original.priority.read_market()
    ohlc = {bar.time: list(live.quotes.ohlc(bar)) for bar in archive}
    eligible, tape = [], {}
    for index, task in checks:
        stamp = task[1]['at']
        at = datetime.fromisoformat(stamp)
        starts = [at + k * M5 for k in range(3)]
        buckets = [packets.get(t.isoformat()) for t in starts]
        if any(bucket is None or bucket['ohlc'] != ohlc.get(t) for t, bucket in zip(starts, buckets, strict=True)):
            exclusions[stamp] = 'unreconciled_m5_or_bid'
            continue
        eligible.append((index, task))
        tape[stamp] = fixed.reconcile(buckets)

    model = joblib.load(upstream.MODEL)
    cases = []
    with ProcessPoolExecutor(max_workers=4, initializer=board.initialize) as pool, threadpool_limits(limits=4):
        rebuilt = pool.map(board.replay, [task for _, task in eligible], chunksize=4)
        for sequence, ((index, task), local) in enumerate(zip(eligible, rebuilt, strict=True), 1):
            stamp, close = local['at'], task[1]['price']
            # Compute these candidates strictly from closed H1s through the current cutoff.
            rows = line.inputs(index, prefix=True)
            if not rows or not local['after']['ERL']:
                exclusions[stamp] = 'missing_candidates'
                continue
            upstream_rows = score.unique_two(score.rank(rows, feat, model), 'price')
            if any(row['known_at'] > line.closes[index] for row in upstream_rows):
                raise ValueError(f'Unconfirmed upstream candidate at {stamp}')
            repo = [dict(row, lo=row['price'], hi=row['price']) for row in upstream_rows]
            tests = {f'{n * 5}m_{s}s': evaluate(local, repo, close, tape[stamp], s, n)
                     for n in (1, 3) for s in (30, 60)}
            cases.append(dict(cutoff=stamp, price=close, repo=repo, results=tests))
            if sequence % 50 == 0:
                print(f'{sequence}/{len(eligible)} frozen forecasts evaluated', flush=True)
    totals, weeks = summarize(cases)
    live.atomic_json(OUT, dict(start=START.isoformat(), end_exclusive=END.isoformat(), results=totals, weekly=weeks,
        excluded=exclusions, cases=cases, inputs=pins | {BID.name: joint.digest(BID)}, orders_sent=0,
        method=('Earlier matched H1 closures in the frozen local archive. Replay from the same strict Bid tape '
                'with the same assumed availability delays. Compare unchanged local, integrated two slots, '
                'two local plus one repository supplement, and mixed distance/score using local candidates only.')))
    print(json.dumps(dict(results=totals, excluded=Counter(exclusions.values())), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
