"""Audit MT5/source-clock evidence without changing terminal state."""
import argparse
import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.serve_ict_live import assessed_quote


def fresh_observation(quote, now):
    """Recheck timestamps, prices and reader heartbeat; a cached label is insufficient."""
    observed = assessed_quote(quote, now)
    return observed, bool(observed and observed['analysis_eligible'])


def local_api(endpoint):
    try:
        with urllib.request.urlopen('http://127.0.0.1:9887/api/' + endpoint, timeout=10) as response:
            return json.load(response), None
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as exc:
        return None, f'{type(exc).__name__}: {exc}'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--manifest', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    meta = json.loads(args.manifest.read_text(encoding='utf-8'))
    status, status_error = local_api('status')
    quote, quote_error = local_api('quote')
    now = datetime.now(timezone.utc)
    observed, fresh = fresh_observation(quote, now)
    ny_offsets = {}
    for stamp in ('2026-09-15T12:00:00+00:00', '2026-10-17T12:00:00+00:00', '2026-11-15T12:00:00+00:00'):
        dt = datetime.fromisoformat(stamp).astimezone(ZoneInfo('America/New_York'))
        ny_offsets[stamp[:10]] = dt.utcoffset().total_seconds() / 3600
    report = {
        'status': 'current_offset_observed' if fresh else 'stale_quote_unverified',
        'checked_at_utc': now.isoformat(),
        'manifest': str(args.manifest.resolve()),
        'source_clock_offset_hours': meta.get('source_clock_offset_hours'),
        'source_clock_historical_alignment_verified': meta.get('source_clock_historical_alignment_verified', False),
        'timestamp_basis': meta.get('timestamp_basis'),
        'possible_server_offsets_considered_hours': [0, 2, 3],
        'ny_zone': 'America/New_York',
        'ny_expected_offsets_hours': ny_offsets,
        'api_status': status,
        'api_status_error': status_error,
        'api_quote': quote,
        'reassessed_quote': observed,
        'api_quote_error': quote_error,
        'fresh_quote_under_30_seconds': fresh,
        'analysis_eligible': bool(fresh and meta.get('source_clock_historical_alignment_verified')),
        'historical_calibration_passed': False,
        'orders_sent': 0,
        'execution_allowed': False,
        'conclusion': ('当前报价在服务所选偏移下及时；这不构成历史时标的独立校准，不用于授权交易。' if fresh else
                       '当前报价未通过及时性检查；历史时标仍待独立核验，不用于授权交易。')
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'report': str(args.out), 'status': report['status'],
                      'analysis_eligible': report['analysis_eligible'], 'orders_sent': 0}, ensure_ascii=False))


if __name__ == '__main__':
    main()
