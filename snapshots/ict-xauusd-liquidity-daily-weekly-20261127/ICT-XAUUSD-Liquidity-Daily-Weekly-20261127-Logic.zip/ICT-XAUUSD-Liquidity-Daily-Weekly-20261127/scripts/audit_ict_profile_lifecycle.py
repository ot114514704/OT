"""Real-source daily/weekly hypothesis prefix checks; no prediction scoring."""
from datetime import date, datetime, time, timedelta, timezone
import hashlib
import json
import argparse
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from dataclasses import replace
from scripts.audit_ict_price_video_replay import load_snapshot
from scripts.prepare_ict_week import aggregate_bars
from ict_ai.profile_lifecycle import daily_profile_lifecycle,weekly_profile_lifecycle
from ict_ai.timebase import NY,previous_week,manifest_epoch_to_utc,clock_policy_metadata
from ict_ai.weekly_path import weekly_path


def compare(full, prefix, cutoff, component):
    if full != prefix:
        fields = [key for key in full.keys() | prefix.keys() if full.get(key) != prefix.get(key)]
        raise ValueError(f'{cutoff.isoformat()} {component} differs with future bars present: {fields}')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--manifest',type=Path,default=ROOT/'data/real/TMGM_ICT_live_start_20261014_120046/XAU/provenance.json')
    parser.add_argument('--today',type=date.fromisoformat)
    parser.add_argument('--out',type=Path,default=ROOT/'output/research/ict_profile_lifecycle_replay_20261014.json')
    args=parser.parse_args()
    manifest=args.manifest
    meta,dataset,raw=load_snapshot(manifest)
    from brooks_ai.types import utc_time
    at=utc_time(meta['finished_at_utc']); period=timedelta(minutes=15)
    m5=[replace(b,time=manifest_epoch_to_utc(b.time,meta)) for b in raw]
    monday=previous_week(args.today or at.astimezone(NY).date())
    checked=0; weeks_checked=0; reviews=[]; week_reviews=[]
    step=timedelta(minutes=5)
    for dates in (monday,[d+timedelta(days=7) for d in monday]):
        # Same Sunday-to-Saturday input as the MT5 exporter, including pre-Monday Tokyo bars.
        lo=datetime.combine(dates[0]-timedelta(days=1),time.min,NY)
        hi=datetime.combine(dates[-1]+timedelta(days=1),time.min,NY)
        week=[b for b in m5 if lo<=b.time<hi]
        bars=aggregate_bars(week,5,15,at)
        for day in dates:
            start=datetime.combine(day,time.min,NY)
            finish=datetime.combine(day,time(17),NY) if day.weekday()==4 else datetime.combine(day+timedelta(days=1),time.min,NY)
            cuts={b.time+step for b in week if start<=b.time<finish and b.time+step<=at}
            if not cuts:
                continue
            if finish<=at:
                cuts.add(finish.astimezone(timezone.utc))
            for cutoff in sorted(cuts):
                prefix_m5=[b for b in week if b.time+step<=cutoff]
                prefix=aggregate_bars(prefix_m5,5,15,cutoff)
                daily=daily_profile_lifecycle(bars,day,cutoff,include_reconstruction=False,reference_m5=week)
                compare(daily,daily_profile_lifecycle(prefix,day,cutoff,include_reconstruction=False,reference_m5=prefix_m5),
                        cutoff,'daily')
                path=weekly_path(week,dates,cutoff)
                prefix_path=weekly_path(prefix_m5,dates,cutoff)
                compare(path,prefix_path,cutoff,'weekly M5 path')
                weekly=weekly_profile_lifecycle(bars,dates,cutoff,path)
                compare(weekly,weekly_profile_lifecycle(prefix,dates,cutoff,prefix_path),cutoff,'weekly M15 classification')
                checked+=1; weeks_checked+=1
            reviews.append({'date':day.isoformat(),'as_of':daily['as_of'],'cutoffs':len(cuts),
                            'mode':daily['mode'],'profile_label':daily['profile_label'],
                            'profile_status':daily['profile_status'],'weekly_background':daily['weekly_background']['label'],
                            'actual_paths':daily['actual_paths'],'reason':daily['profile_reason'],
                            'session_price_checks':daily.get('session_price_checks')})
            if day.weekday()==4:
                week_reviews.append({'monday':dates[0].isoformat(),'as_of':weekly['as_of'],
                                     'status':weekly['profile_status'],'label':weekly['profile_label']})
    if not checked:
        raise ValueError('No observed M5 closes in the requested weeks')
    code=['ict_ai/profile_lifecycle.py','ict_ai/weekly_path.py','ict_ai/liquidity.py','ict_ai/range_liquidity.py','ict_ai/timebase.py','scripts/prepare_ict_week.py',
          'scripts/ict_week_fragment.html','scripts/audit_ict_profile_lifecycle.py']
    result={'status':'passed','scope':'conditional daily/weekly price hypotheses and cutoff isolation',
            'source_manifest':str(manifest),'source_data_sha256':dataset['data_sha256'],'as_of':at.isoformat(),
            'daily_prefixes_checked':checked,'weekly_prefixes_checked':weeks_checked,'reviews':reviews,'fridays':week_reviews,
            'cutoff_policy':'Every available M5 close plus NY day close. Rebuild M15 and weekly M5 path independently from the prefix.',
            'code_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in code},
            **clock_policy_metadata(meta),'historical_clock_verified':False,'prediction_performance_measured':False,
            'prior_bias_pda_dol_verified':False,'full_ict_profile_confirmed':False,'orders_sent':0,'model_trained':False,
            'browser_runtime_verified':False}
    path=args.out
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'report':str(path),'daily_prefixes':checked,'weekly_prefixes':weeks_checked,'status':'passed'}),flush=True)


if __name__=='__main__':main()
