"""Run separate IRL and ERL accounts on the frozen 1.34 liquidity inputs."""

from collections import Counter
from datetime import datetime
from pathlib import Path
import json

from scripts import backtest_ict_liquidity_account as replay
from scripts.replay_ict_liquidity_small_account import END, START, scenario_directory


OUT = replay.OUT / '100usd_stop20_irl_erl_accounts.json'
PRINCIPAL = 100.
STOP = 20.
LEVERAGE = 1000


def audit_scope(frozen, bars, plan, start, end, scope):
    signals, excluded, checks = replay.signals(frozen, bars, start, end, entry_scope=scope)
    runs, quotes, _ = replay.simulate_accounts(signals, bars, plan, end, initial_balance=PRINCIPAL,
                                              stop_distance=STOP, trace=True)
    for case in runs.values():
        if case['execution_coverage_exclusions']:
            raise ValueError(f'Unverified quote path for {scope}')
        if scope and any(row['pool']['scope'] != scope for row in case['ledger']):
            raise AssertionError('Cross-scope entry in an isolated account')
        case['first_funding_rejection'] = next((d for d in case['decisions']
            if d['status'] == 'insufficient_modeled_equity'), None)
        case['target_scopes'] = dict(Counter(row['target']['scope'] for row in case['ledger']))
    return dict(signals=len(signals), signal_exclusions=excluded, prefix_checks=checks, quotes=quotes, scenarios=runs)


def verify_baseline(observed, reference):
    for name, scenario in observed['scenarios'].items():
        expected = reference[name]
        for key in ('ledger', 'max_drawdown_pct', 'end_usd', 'skipped'):
            if scenario[key] != expected[key]:
                raise AssertionError(f'Combined baseline changed in {name}/{key}')


def main():
    capture, plan, bars, frozen, start, end = replay.locked_capture()
    plan = dict(plan, leverage=LEVERAGE)
    expected_full = replay.OUT / '100usd_stop20_account_survival.json'
    expected_week = scenario_directory(PRINCIPAL, STOP) / 'report.json'
    reference = {'two_months': json.loads(expected_full.read_bytes())['continuous'],
                 'last_week': json.loads(expected_week.read_bytes())['scenarios']}
    results = {}
    for name, a, b in (('two_months', start, end), ('last_week', START, END)):
        checkpoints = [row for row in frozen if a <= datetime.fromisoformat(row['at']) < b]
        variants = {scope: audit_scope(checkpoints, bars, plan, a, b, None if scope=='combined' else scope)
                    for scope in ('combined', 'IRL', 'ERL')}
        verify_baseline(variants['combined'], reference[name])
        results[name] = dict(period=dict(start=a.isoformat(), end=b.isoformat()), checkpoints=len(checkpoints), variants=variants)
        for scope, variant in variants.items():
            print(name, scope, variant['signals'], {k:(v['trades'], v['end_usd'], v['max_drawdown_pct'], v['first_funding_rejection'])
                                                    for k,v in variant['scenarios'].items()}, flush=True)
    report = dict(principal_usd=PRINCIPAL, volume_lots=replay.VOLUME, stop_distance_usd=STOP, leverage=LEVERAGE,
                  rule='1.34 sweep and reclaim. Only entry scope changes before same-close collision handling. For every account, target remains nearest untouched opposing liquidity from either scope.',
                  account='Each variant starts independently, one position at a time, using the same Bid/Ask and cost assumptions.',
                  inputs={str(p.relative_to(replay.ROOT)):replay.digest(p) for p in (capture, expected_full, expected_week,
                           Path(replay.__file__), Path(__file__))}, results=results, orders_sent=0)
    replay.atomic_json(OUT, report)


if __name__ == '__main__':
    main()
