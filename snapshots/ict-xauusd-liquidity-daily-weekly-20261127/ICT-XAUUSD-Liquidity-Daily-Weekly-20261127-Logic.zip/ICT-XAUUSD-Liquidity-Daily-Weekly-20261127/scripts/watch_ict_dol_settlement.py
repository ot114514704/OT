"""Automatically settle expired shadow windows on the already open TMGM terminal."""

import argparse
from collections import defaultdict
from contextlib import contextmanager
import ctypes
from ctypes import wintypes
from datetime import datetime, timedelta, timezone
from itertools import groupby, islice
import json
from pathlib import Path
import sqlite3
import time

from brooks_ai.types import Bar
from ict_ai.dol_tick_evidence import BidEvidence, utc_ms
from ict_ai.range_liquidity import _research_open
from ict_ai.timebase import manifest_epoch_to_utc
from scripts.audit_ipda_gap_ticks import raw_epoch, TERMINAL
from scripts.serve_ict_live import atomic_json, checked_account, replace_with_retry
from scripts.settle_ict_dol_shadow import FOLDER, LOCK, M5, archive, frozen_feed, read_registrations, summarize_bid, utc_now


UTC = timezone.utc
GRACE = timedelta(seconds=60)
RETRY = timedelta(minutes=5)
BUCKET_MS = 300_000


@contextmanager
def open_terminal(pid):
    """Keep an OS handle to the specific running terminal instance."""
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.QueryFullProcessImageNameW.argtypes = (wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR,
                                                 ctypes.POINTER(wintypes.DWORD))
    kernel.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
    kernel.WaitForSingleObject.restype = wintypes.DWORD
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    handle = kernel.OpenProcess(0x101000, False, pid)  # Synchronize and query limited information.
    if not handle:
        raise SystemExit(f'MT5 process {pid} is unavailable')
    try:
        path = ctypes.create_unicode_buffer(32768)
        size = wintypes.DWORD(len(path))
        if not kernel.QueryFullProcessImageNameW(handle, 0, path, ctypes.byref(size)) or Path(path.value) != TERMINAL:
            raise SystemExit(f'Process {pid} is not the configured MT5 terminal')
        yield lambda: kernel.WaitForSingleObject(handle, 0) == 258
    finally:
        kernel.CloseHandle(handle)


def capture_buckets(api, alive, source, starts, now):
    """Fetch independent M5 references and Bid history on the same broker clock."""
    if not starts or not alive():
        return
    if not api.initialize(str(TERMINAL), timeout=3000):
        raise RuntimeError(f'MT5 connection unavailable: {api.last_error()}')
    try:
        account = checked_account(api)
        if not alive() or account.server != source['server']:
            raise RuntimeError('MT5 instance or frozen quote server changed')
        identity = account.login, account.server
        clock = source['clock']
        tick = api.symbol_info_tick('XAUUSD')
        if _research_open(now):
            if not tick or tick.time <= 0 or tick.bid <= 0:
                raise RuntimeError('Waiting for a current XAUUSD quote')
            tick_time = manifest_epoch_to_utc(datetime.fromtimestamp(int(tick.time), UTC), clock)
            if not -3 <= (utc_now() - tick_time).total_seconds() <= 120:
                raise RuntimeError('XAUUSD terminal quote clock is stale or out of alignment')

        groups = groupby(enumerate(starts), key=lambda item: utc_ms(item[1]) - item[0] * BUCKET_MS)
        for _, contiguous in groups:
            while chunk := [start for _, start in islice(contiguous, 12)]:
                raw_starts = {raw_epoch(start, clock): start for start in chunk}
                if len(raw_starts) != len(chunk):
                    raise ValueError('Multiple M5 timestamps map to the same broker clock slot')
                raw_from = datetime.fromtimestamp(min(raw_starts), UTC)
                raw_until = datetime.fromtimestamp(max(raw_starts) + 300, UTC)
                bars = api.copy_rates_range('XAUUSD', api.TIMEFRAME_M5, raw_from, raw_until)
                quotes = api.copy_ticks_range('XAUUSD', raw_from, raw_until, api.COPY_TICKS_INFO)
                if bars is None or quotes is None:
                    raise RuntimeError(f'MT5 M5 or Bid history unavailable: {api.last_error()}')
                checked_account(api, identity)
                if not alive():
                    raise RuntimeError('Configured MT5 process closed during the quote query')
                m5 = {int(q['time']): [float(q[k]) for k in ('open', 'high', 'low', 'close')] for q in bars}
                by_slot = defaultdict(list)
                for quote in quotes:
                    raw, bid = int(quote['time_msc']), float(quote['bid'])
                    bucket, offset = divmod(raw, BUCKET_MS)
                    raw_start = bucket * 300
                    if raw_start in raw_starts and bid > 0:
                        by_slot[raw_start].append([offset, bid])
                for raw_start, start in raw_starts.items():
                    reference, offsets = m5.get(raw_start), by_slot[raw_start]
                    if reference is None and not offsets and not _research_open(start):
                        yield start, dict(open_utc=start.isoformat(), ohlc=None, bid_offsets=[])
                    if reference is not None and offsets:
                        opened_ms = utc_ms(start)
                        evidence = BidEvidence([Bar(start, *reference, 0)], [(opened_ms+t, p) for t, p in offsets])
                        if opened_ms in evidence.reconciled:
                            yield start, dict(open_utc=start.isoformat(), ohlc=reference, bid_offsets=offsets)
    finally:
        api.shutdown()


def slot_path(folder, start):
    return folder / f'{start:%Y%m%dT%H%M%SZ}.json.gz'


def replay_saved(row, starts, folder, now, server):
    bars, quotes, checksums, missing = [], [], {}, []
    for start in starts:
        path = slot_path(folder, start)
        if not path.is_file():
            missing.append(utc_ms(start))
            continue
        bucket = archive.read_zip(path)
        if bucket['open_utc'] != start.isoformat() or bucket['server'] != server:
            raise ValueError(f'Broker or timestamp mismatch in {path.name}')
        checksums[path.name] = archive.digest(path)
        if bucket['ohlc'] is not None:
            bars.append(Bar(start, *bucket['ohlc'], 0))
        quotes.extend((utc_ms(start)+offset, bid) for offset, bid in bucket['bid_offsets'])
    if missing:
        return dict(status='unverified_quotes', contacts={}, first_ranks=[], missing_m5_utc_ms=missing)
    return dict(BidEvidence(bars, quotes).replay(row, now), bucket_sha256=checksums)


def settle_once(records, folder, fetch, now, server, retry):
    """Retain reconciled M5 evidence once and freeze each conclusive result once."""
    buckets, outcomes = folder/'bid_buckets', folder/'bid_outcomes'
    buckets.mkdir(exist_ok=True)
    outcomes.mkdir(exist_ok=True)
    settled, mature = [], []
    needed = set()
    for row in records:
        start, end = (datetime.fromisoformat(row[k]).astimezone(UTC) for k in ('cutoff', 'end'))
        path = outcomes / f'{start:%Y%m%dT%H%M%SZ}.json'
        if path.is_file():
            result = json.loads(path.read_bytes())
            if result['registration_sha256'] != row['evidence']:
                raise ValueError(f'Outcome no longer matches registration: {path.name}')
            # JSON reads object keys as strings. The comparison uses numeric ranks.
            result['outcome']['contacts'] = {int(k): v for k, v in result['outcome']['contacts'].items()}
            settled.append((row, result['outcome']))
        elif end + GRACE <= now:
            starts = [start+i*M5 for i in range((end-start)//M5)]
            mature.append((row, path, starts))
            needed.update(t for t in starts if not slot_path(buckets, t).is_file())
        else:
            settled.append((row, dict(status='open' if now < end else 'awaiting_history', contacts={}, first_ranks=[])))
    due = sorted(t for t in needed if retry.get(t, now) <= now)
    if due:
        for start, payload in fetch(due, now):
            path = slot_path(buckets, start)
            temporary = path.with_suffix('.tmp')
            archive.write_zip(temporary, dict(payload, server=server, captured_at=now.isoformat()))
            replace_with_retry(temporary, path)
        retry.update({t: now+RETRY for t in due})
    for stale in retry.keys()-needed:
        del retry[stale]
    for row, path, starts in mature:
        outcome = replay_saved(row, starts, buckets, now, server)
        settled.append((row, outcome))
        if outcome['status'] != 'unverified_quotes':
            atomic_json(path, dict(registration_sha256=row['evidence'], settled_at=now.isoformat(), outcome=outcome))
    return summarize_bid(sorted(settled, key=lambda pair: pair[0]['cutoff']))


def verify_saved(records, folder, server):
    by_hash = {row['evidence']:row for row in records}
    verified = 0
    for path in sorted((folder/'bid_outcomes').glob('*.json')):
        saved = json.loads(path.read_bytes())
        row = by_hash[saved['registration_sha256']]
        start, end = (datetime.fromisoformat(row[k]).astimezone(UTC) for k in ('cutoff', 'end'))
        starts = [start+i*M5 for i in range((end-start)//M5)]
        recheck = replay_saved(row, starts, folder/'bid_buckets', datetime.fromisoformat(saved['settled_at']), server)
        if json.loads(json.dumps(recheck)) != saved['outcome']:
            raise ValueError(f'Saved outcome or evidence hashes differ on replay: {path.name}')
        verified += 1
    return verified


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--terminal-pid', type=int, help='Bind to the currently open TMGM terminal process')
    mode.add_argument('--verify-archive', action='store_true', help='Recompute saved decisions from evidence without MT5')
    args = parser.parse_args()
    source = frozen_feed()
    if args.verify_archive:
        print('Verified saved DOL Bid outcomes:', verify_saved(read_registrations(), FOLDER, source['server']))
        return
    import msvcrt
    import MetaTrader5 as mt5

    with open_terminal(args.terminal_pid) as alive, (FOLDER/'bid_watch.lock').open('a+b') as lock:
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as exc:
            raise SystemExit('The DOL Bid settlement watcher is already running') from exc
        print(f'Watching expired DOL windows on pre-existing MT5 PID {args.terminal_pid}', flush=True)
        retry = {}
        previous = None
        while alive():
            now = utc_now()
            try:
                report = settle_once(read_registrations(), FOLDER,
                                     lambda starts, at: capture_buckets(mt5, alive, source, starts, at),
                                     now, source['server'], retry)
                if report != previous:
                    atomic_json(FOLDER/'auto_bid_settlement.json', dict(model_sha256=archive.digest(LOCK),
                                as_of=now.isoformat(), terminal_pid=args.terminal_pid, **report))
                    print(now.isoformat(), dict(report['coverage']), flush=True)
                    previous = report
            except (OSError, RuntimeError, sqlite3.OperationalError, json.JSONDecodeError) as exc:
                print(f'{now.isoformat()} DOL evidence deferred: {exc}', flush=True)
            time.sleep(20)
        print('Bound MT5 terminal exited. Bid settlement collector stopped.', flush=True)


if __name__ == '__main__':
    main()
