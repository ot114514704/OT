"""Check strict contact replay on saved TMGM Bid and independently archived M5 bars."""

from collections import Counter
from datetime import datetime, timedelta
import json

from brooks_ai.types import Bar
from ict_ai.dol_tick_evidence import BidEvidence, M5, utc_ms
from scripts.audit_ipda_gap_ticks import PRICES, raw_epoch
from scripts.replay_pool_and_dol import QUOTES, RESEARCH, digest, read_zip


def main():
    ticks_path = RESEARCH / 'ict_target_order_bid.json.gz'
    ipda_audit_path = RESEARCH / 'ict_ipda_early_close_tick_audit.json'
    ticks = read_zip(ticks_path)
    prices = read_zip(QUOTES)
    ipda_audit = json.loads(ipda_audit_path.read_bytes())
    price_sha = digest(PRICES)
    clock_sha = digest(QUOTES)
    if (ticks['source_hash'] != clock_sha or ticks['server'] != prices['server']
            or ipda_audit['inputs'][QUOTES.name] != clock_sha
            or ipda_audit['inputs'][PRICES.name] != price_sha):
        raise ValueError('Historical tick, clock and independent M5 archives do not match')

    m5 = {row[0]: row[1:] for row in read_zip(PRICES)['bars']['M5']}
    counts = Counter()
    coverage = Counter()
    checked = []
    for key, quotes in sorted(ticks['quotes'].items()):
        stamp, _, seconds = key.partition('|')
        if seconds != '300':
            continue
        coverage['archived_full_m5_requests'] += 1
        start = datetime.fromisoformat(stamp)
        opened_ms = utc_ms(start)
        reference = m5.get(raw_epoch(start, prices['clock']))
        if not quotes or reference is None:
            coverage['missing_quotes_or_m5'] += 1
            continue
        if any(not 0 <= offset < 300_000 for offset, _ in quotes):
            raise ValueError(f'Archived quote outside its M5 bucket: {stamp}')
        bar = Bar(start, *reference, 0)
        evidence = BidEvidence([bar], [(opened_ms + offset, bid) for offset, bid in quotes])
        if opened_ms not in evidence.reconciled:
            coverage['quote_ohlc_mismatch'] += 1
            continue

        checked.append(stamp)
        coverage['reconciled_m5'] += 1
        coverage['quote_rows'] += len(quotes)
        end = start + M5
        for delay in (0, 3000):
            low, high = bar.low, bar.high
            middle = round((low + high) / 2, 2)
            levels = [(low, low), (high, high), (middle, middle), (middle, min(middle + 0.01, high))]
            row = dict(cutoff=stamp, end=end.isoformat(),
                       recorded_at=(start + timedelta(milliseconds=delay)).isoformat(),
                       targets=[dict(rank=i, side=1, lo=lo, hi=hi) for i, (lo, hi) in enumerate(levels, 1)])
            outcome = evidence.replay(row, end)

            # Walk raw offsets in quote order independently of replay's per-target scan.
            expected = {}
            for offset, bid in quotes:
                for rank, (lo, hi) in enumerate(levels, 1):
                    if lo <= bid <= hi:
                        expected.setdefault(rank, dict(utc_ms=opened_ms + offset, bid=bid, eligible=offset >= delay))
            ranks_by_time = sorted((event['utc_ms'], rank) for rank, event in expected.items() if event['eligible'])
            first = [rank for when, rank in ranks_by_time if when == ranks_by_time[0][0]]
            if outcome['contacts'] != expected or outcome['first_ranks'] != first:
                raise ValueError(f'Quote replay differs from independent scan: {stamp}, delay={delay}')
            counts[outcome['status']] += 1
            counts['retired_before_registration'] += sum(not event['eligible'] for event in expected.values())
            counts['missing_midpoint_despite_m5_range'] += int(3 not in expected)

    if not checked or len(checked) != coverage['archived_full_m5_requests']:
        raise ValueError(f'Historical M5 coverage failed: {dict(coverage)}')
    report = dict(server=ticks['server'], symbol='XAUUSD', first_open_utc=checked[0], last_open_utc=checked[-1],
                  coverage=coverage, diagnostic_windows=2 * len(checked), outcomes=counts,
                  scope='Archived quotes, checked against independent M5 OHLC. Diagnostic prices use known M5 OHLC '
                        'to test replay mechanics and are not prospective target selections or performance estimates.',
                  inputs={ticks_path.name: digest(ticks_path), PRICES.name: price_sha, QUOTES.name: clock_sha,
                          ipda_audit_path.name: digest(ipda_audit_path)})
    output = RESEARCH / 'dol_shadow_20261123' / 'historical_bid_verification.json'
    output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(dict(coverage), dict(counts))


if __name__ == '__main__':
    main()
