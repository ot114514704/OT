"""Record the combined verdict before its independent M5 outcome can be known."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
from time import sleep

from ict_ai.sweep_response import crossing_response
from scripts import compare_ict_sweep_structure as structure
from scripts import watch_ict_liquidity_filter_accuracy as forward


OUT = forward.quotes.RESEARCH/'ict_sweep_combination_forward_20261124'
POLICY = OUT/'policy.json'
M5 = forward.M5
DECISION = 12*M5
OUTCOME = 6*M5
INPUTS = (Path(__file__).resolve(), Path(structure.__file__).resolve(), Path(forward.__file__).resolve(),
          forward.quotes.ROOT/'ict_ai/sweep_response.py', forward.quotes.ROOT/'ict_ai/session_path.py',
          forward.POLICY)


def load_policy():
    pins = {p.relative_to(forward.quotes.ROOT).as_posix():forward.quotes.digest(p) for p in INPUTS}
    if not POLICY.exists():
        forward.atomic_json(POLICY,dict(
            frozen_at=forward.now().isoformat(), inputs=pins,
            rule='At +60m use the eligible old structure verdict, else V7B. Archive before the first follow-up close.',
            outcome='next six consecutive closed M5s all strictly on the same side of the recorded outer edge',
            orders_sent=0,
        ))
    policy = json.loads(POLICY.read_bytes())
    if pins != policy['inputs']:
        raise ValueError('Frozen combined sweep-verdict inputs changed')
    return policy


def crossings(record, bars, times, as_of):
    at, ready = (datetime.fromisoformat(record[k]) for k in ('cutoff','eligible_from'))
    index = bisect_left(times,at)
    if not index or bars[index-1].time+M5 != at or bars[index-1].close != record['price']:
        return {}
    coverage = forward._Coverage(at,as_of,bars,M5)
    end_before = bisect_left(times,ready)
    before = bars[index:end_before]
    groups = defaultdict(set)
    for case, model in record['pools'].items():
        stop = min(datetime.fromisoformat(model['deadline']),as_of)
        if stop <= ready:
            continue
        after = bars[end_before:bisect_left(times,stop)]
        for i,target in enumerate(model['targets']):
            if forward.detect(target,before)[0]!='none':
                continue
            tag,stamp = forward.detect(target,after)
            if tag != 'sweep':
                continue
            known = datetime.fromisoformat(stamp)
            if coverage.gap(at,known):
                continue
            membership = [f'{case}/{stage}' for stage,selected in model['layers'].items() if i in selected]
            if membership:
                groups[(known,target['side'],forward.quotes.far(target))].update(membership)
    return groups


def decision(key,bars,times,recorded):
    known,side,edge = key
    cutoff = known+DECISION
    if not cutoff <= recorded < cutoff+M5:
        return None
    start = bisect_left(times,known-M5)
    end = bisect_left(times,cutoff)
    after = bars[start:end]
    if len(after)!=13 or any(b.time != known+(i-1)*M5 for i,b in enumerate(after)):
        return None
    prior = bars[max(0,start-24):start]
    response = crossing_response(side,edge,prior,after[0],after[1:],cutoff)
    if response['status'] in ('incomplete','missing_prior','unverified_cross'):
        return None
    event = dict(crossing_at=known.isoformat(),side=side,edge=edge,decisions={'60':response})
    verdicts = structure.combined_verdicts(event,bars[:end],times[:end])
    return dict(crossing_at=event['crossing_at'],side=side,edge=edge,cutoff=cutoff.isoformat(),
                recorded_at=recorded.isoformat(),verdicts=verdicts,
                quotes=[[b.time.isoformat(),*forward.quotes.ohlc(b)] for b in (*prior,*after)])


def independently_grade(record,bars,times):
    cutoff = datetime.fromisoformat(record['cutoff'])
    start = bisect_left(times,cutoff)
    rows = bars[start:start+6]
    if len(rows)!=6 or any(b.time!=cutoff+i*M5 for i,b in enumerate(rows)):
        return 'incomplete', []
    signs = [record['side']*(b.close-record['edge']) for b in rows]
    state = 'sweep' if all(s<0 for s in signs) else 'break' if all(s>0 for s in signs) else 'mixed'
    return state, [[b.time.isoformat(),*forward.quotes.ohlc(b)] for b in rows]


def sources(policy,as_of):
    frozen = datetime.fromisoformat(policy['frozen_at'])
    for path in sorted((forward.OUT/'registrations').glob('*.json')):
        r = json.loads(path.read_bytes())
        if r['policy_sha256'] != policy['inputs'][forward.POLICY.relative_to(forward.quotes.ROOT).as_posix()]:
            raise ValueError(f'Registration belongs to another upstream policy: {path.name}')
        first = datetime.fromisoformat(r['eligible_from'])
        last = max(datetime.fromisoformat(m['deadline']) for m in r['pools'].values())
        if frozen <= first < as_of <= last+DECISION+M5:
            yield path,r


def summarize():
    seen = {}
    conflicts = set()
    totals = defaultdict(lambda: defaultdict(Counter))
    n = 0
    policy_digest = forward.quotes.digest(POLICY)
    for p in sorted((OUT/'outcomes').glob('*.json')):
        path = OUT/'decisions'/p.name
        rated, record = (json.loads(q.read_bytes()) for q in (p,path))
        if rated['decision_sha256'] != forward.quotes.digest(path):
            raise ValueError(f'Outcome refers to a changed decision: {p.name}')
        if record['policy_sha256'] != policy_digest:
            raise ValueError(f'Decision belongs to another policy: {p.name}')
        key = record['crossing_at'],record['side'],record['edge']
        value = record['verdicts'],rated['state']
        if key not in seen:
            seen[key]=(value,set())
        elif seen[key][0] != value:
            conflicts.add(key)
        seen[key][1].update(record['groups'])
    for key, ((calls,actual),memberships) in seen.items():
        if key in conflicts:
            continue
        n+=1
        for group in memberships:
            for method,guess in calls.items():
                counts=totals[group][method]
                counts['events']+=1
                counts['issued']+=guess is not None
                counts['outcome_'+actual]+=1
                if guess is None or actual not in ('sweep','break'):
                    continue
                counts['directional']+=1
                counts['matched']+=guess==actual
    return dict(graded_distinct=n,conflicting_captures=len(conflicts),comparisons=totals)


def poll(policy):
    observed = forward.now()
    as_of = observed.replace(minute=observed.minute//5*5,second=0,microsecond=0)
    registrations = list(sources(policy,as_of))
    due = []
    for path in sorted((OUT/'decisions').glob('*.json')):
        if (OUT/'outcomes'/path.name).exists():
            continue
        record = json.loads(path.read_bytes())
        if datetime.fromisoformat(record['cutoff'])+OUTCOME <= as_of:
            due.append((path,record))
    begins = [datetime.fromisoformat(r['cutoff'])-24*M5 for _,r in registrations]
    begins.extend(datetime.fromisoformat(r['cutoff']) for _,r in due)
    if begins:
        with forward.terminal() as (api,clock):
            bars = forward.quotes.collect_bars(api,min(begins),as_of,clock)
        times = [b.time for b in bars]
        for path,record in due:
            state,tape = independently_grade(record,bars,times)
            if state=='incomplete' and as_of < datetime.fromisoformat(record['cutoff'])+OUTCOME+2*M5:
                continue
            forward.atomic_json(OUT/'outcomes'/path.name,dict(
                decision_sha256=forward.quotes.digest(path),state=state,quotes=tape,
                graded_at=forward.now().isoformat(),orders_sent=0))
        for path,record in registrations:
            for key,memberships in crossings(record,bars,times,as_of).items():
                captured = decision(key,bars,times,forward.now())
                if captured is None:
                    continue
                event_id = sha256(repr(key).encode()).hexdigest()[:24]
                file = OUT/'decisions'/f'{path.stem}_{event_id}.json'
                if file.exists():
                    continue
                if forward.now() >= datetime.fromisoformat(captured['cutoff'])+M5:
                    continue
                forward.atomic_json(file,dict(captured,groups=sorted(memberships),
                                             registration_sha256=forward.quotes.digest(path),
                                             policy_sha256=forward.quotes.digest(POLICY),orders_sent=0))
    return dict(observed_at=observed.isoformat(),frozen_at=policy['frozen_at'],
                active_registrations=len(registrations),
                decisions=len(list((OUT/'decisions').glob('*.json'))),**summarize(),orders_sent=0)


def main():
    import msvcrt

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('once','watch'))
    args = parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/'watch.lock').open('a+b') as lock:
        if lock.tell()==0:
            lock.write(b'0')
            lock.flush()
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        except OSError as error:
            raise SystemExit('The combined verdict recorder is already active') from error
        policy=load_policy()
        while True:
            try:
                status = poll(policy)
            except RuntimeError as error:
                status = dict(observed_at=forward.now().isoformat(),error=str(error),orders_sent=0)
            forward.atomic_json(OUT/'status.json',status)
            if args.mode=='once':
                print(json.dumps(status,ensure_ascii=False))
                return
            sleep(20)


if __name__=='__main__':
    main()
