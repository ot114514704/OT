"""Audit first-target misses and test one evidence-based override on frozen rows."""
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import replay_prior_joint_months as prior
from scripts import replay_june_to_latest as june
from scripts.replay_ten_joint_rounds import joint, priority, NY

OUT=joint.RESEARCH/'nearest_target_audit_20261122'
RULE={'max_extra_h1_fraction':.25,'minimum_alignment_advantage':6,
      'development':'2025-09-01..2026-03-31','validation':'2026-06-01..2026-11-20',
      'primary':'unique first goal reached within the existing NY intraday deadline'}
METRICS={'dol':'touch','pools':'sweep'}


def datasets():
    for label,folder in (('development',prior.OUT),('validation',june.OUT)):
        snap=folder/'frozen.json.gz'
        outcome=folder/'outcomes.json.gz'
        assert joint.digest(snap)==json.loads((folder/'lock.json').read_bytes())['frozen']
        yield label,dict(forecast=joint.digest(snap),outcomes=joint.digest(outcome)),list(
            zip(joint.read_zip(snap),joint.read_zip(outcome),strict=True))


def stable_order(targets):
    return sorted(range(len(targets)),key=lambda i:(targets[i]['distance'],i))


def select(s,family):
    targets=s[family]
    order=stable_order(targets)
    near=order[0]
    opposite=next((i for i in order if targets[i]['side']!=targets[near]['side']),None)
    paired=order[:2]
    balanced=[near,opposite] if opposite is not None and len(order)>1 else paired
    align={t['side']:t['score_components']['alignment'] for t in s['dol']}
    other=opposite if opposite is not None else near
    a,b=targets[near],targets[other]
    override=(other!=near and a['side'] in align and b['side'] in align
              and b['distance']-a['distance']<=RULE['max_extra_h1_fraction']*s['h1']
              and align[b['side']]-align[a['side']]>=RULE['minimum_alignment_advantage'])
    return near,other if override else near,paired,balanced


def record(pairs,family):
    counts=Counter()
    groups=defaultdict(lambda:[0,0])
    episodes=[]
    for s,obs in pairs:
        assert s['at']==obs['at']
        if obs['short']['status']!='complete' or not s[family]:
            continue
        targets=s[family]
        at=datetime.fromisoformat(s['at']).astimezone(NY)
        if at.strftime('%H:%M') not in june.CHECKPOINTS:continue
        near,adaptive,paired,balanced=select(s,family)
        results=[e[METRICS[family]] for e in obs['short'][family]]
        hits={i for i,r in enumerate(results) if r}
        first=min((results[i] for i in hits),default=None)
        leaders=[i for i in sorted(hits) if results[i]==first]
        counts['n']+=1
        counts['nearest_hit']+=near in hits
        counts['nearest_unique_first']+=leaders==[near]
        counts['adaptive_hit']+=adaptive in hits
        counts['adaptive_unique_first']+=leaders==[adaptive]
        counts['override']+=adaptive!=near
        if adaptive!=near:
            counts['only_override_hit']+=adaptive in hits and near not in hits
            counts['only_nearest_hit']+=near in hits and adaptive not in hits
        if len(paired)==len(balanced)==2:
            counts['paired_n']+=1
            counts['closest_two_hit']+=bool(hits.intersection(paired))
            counts['opposite_side_two_hit']+=bool(hits.intersection(balanced))
        week=at.date()-timedelta(days=at.weekday())
        groups[week][0]+=int(leaders==[adaptive])-int(leaders==[near])
        groups[week][1]+=1
        if near in hits:continue
        same=any(targets[i]['side']==targets[near]['side'] for i in hits)
        opposite=any(targets[i]['side']!=targets[near]['side'] for i in hits)
        reason='both_sides' if same and opposite else 'opposite_only' if opposite else 'same_side_only' if same else 'all_missed'
        counts[reason]+=1
        if hits:
            episodes.append(dict(at=s['at'],nearest=targets[near],first_goals=[targets[i] for i in leaders],
                                 first_observed=first,reason=reason))
    return dict(counts=counts,first_delta_week_ci=priority.interval(groups),examples=episodes)


def main():
    OUT.mkdir(exist_ok=True,parents=True)
    loaded=list(datasets())
    lock=dict(rule=RULE,evidence={name:ids for name,ids,_ in loaded},script=joint.digest(Path(__file__)))
    (OUT/'protocol.json').write_text(json.dumps(lock,indent=2),encoding='utf-8')
    findings={name:{family:record(pairs,family) for family in METRICS} for name,_,pairs in loaded}
    episodes={name:{k:v.pop('examples') for k,v in families.items()} for name,families in findings.items()}
    joint.write_zip(OUT/'misses.json.gz',episodes)
    (OUT/'findings.json').write_text(json.dumps(findings,indent=2),encoding='utf-8')
    for name,families in findings.items():
        for family,r in families.items():print(name,family,dict(r['counts']),r['first_delta_week_ci'])
    report(findings)
    draw_examples(loaded[-1][2])


def report(findings):
    def row(c,fields):
        return '|'.join(str(c[f]) for f in fields)
    text=['# 最近目标失效复盘','',
          '统一使用纽约每日五个检查点。先记录原候选，按既定的四小时期限分别验证 DOL 触价和流动性严格越过外沿。同根 K 线命中多个目标时保留先后未知。','',
          '|样本|模型|有效窗口|最近命中|仅另一侧命中|全部候选都未命中|',
          '|---|---|---:|---:|---:|---:|']
    samples={'development':'2025-09 至 2026-03','validation':'2026-06 至 2026-11'}
    models={'dol':'DOL','pools':'流动性'}
    for label,stats in findings.items():
        for family,r in stats.items():
            c=r['counts']
            text.append(f'|{samples[label]}|{models[family]}|'+row(c,('n','nearest_hit','opposite_only','all_missed'))+'|')
            assert c['n']-c['nearest_hit']==sum(c[k] for k in ('opposite_only','all_missed','same_side_only','both_sides'))
    text+=['','结构改判试验限定另一侧目标准许多出四分之一个 H1 波幅中位数，同时 DOL 同向证据至少高 6 分。先登记规则，再对两个时间段独立计数。输入为已经回放过的历史，验证针对这一道改判规则。','',
           '|验证段|最近价位唯一先到|结构改判后唯一先到|直接取最近两个至少命中一个|上下各取最近一个至少命中一个|',
           '|---|---:|---:|---:|---:|']
    for family,r in findings['validation'].items():
        c=r['counts'];n=c['n'];paired=c['paired_n']
        text.append(f"|{models[family]}|{c['nearest_unique_first']}/{n}|{c['adaptive_unique_first']}/{n}|{c['closest_two_hit']}/{paired}|{c['opposite_side_two_hit']}/{paired}|")
    text+=['','保留第二个价位时，上下各留一个在两段样本里均提升覆盖。日线与周线仍从 ERL 取结构来源。此处统计的是价位触达，尚未进入进出场和成本回测。']
    (OUT/'最近目标失效复盘.md').write_text('\n'.join(text)+'\n',encoding='utf-8')


def draw_examples(pairs):
    from scripts.plot_joint_round_examples import plt, font_manager, render
    font=Path('C:/Windows/Fonts/msyh.ttc')
    for path in (font,font.with_name('msyhbd.ttc')):
        font_manager.fontManager.addfont(path)
    plt.rcParams['font.family']=font_manager.FontProperties(fname=font).get_name()
    plt.rcParams['axes.unicode_minus']=False
    datasets_by_name={'archive':priority.read_market(),'recent':joint.load_bars()}
    used=set()
    titles={('dol',):'DOL 先触及另一侧',('pools',):'流动性先扫荡另一侧',('dol','pools'):'两个模型都转向另一侧'}
    for number,(families,title) in enumerate(titles.items(),1):
        for s,ev in pairs:
            if ev['short']['status']!='complete' or s['at'] in used or not all(s[k] for k in families):continue
            changed={};missed=[]
            for k in families:
                targets=s[k];idx=stable_order(targets)[0]
                contacts=[o[METRICS[k]] for o in ev['short'][k]]
                if contacts[idx]:break
                opposite=[i for i,t in enumerate(targets) if t['side']!=targets[idx]['side'] and contacts[i]]
                if not opposite:break
                changed[k]={'nearest':min(opposite,key=lambda i:contacts[i])}
                missed.append((k,targets[idx]))
            if len(changed)!=len(families):continue
            used.add(s['at'])
            sample=dict(s,picks=changed)
            render(OUT/f'case-{number}.png',number,title,families,sample,ev['short'],datasets_by_name[s['source']],missed=missed)
            break
        else:raise ValueError(f'No example for {families}')


if __name__=='__main__':
    main()
