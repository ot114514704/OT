"""Run the pinned upstream ranker and local liquidity rules on real TMGM prices."""

from argparse import ArgumentParser
import ast
from bisect import bisect_left, bisect_right
from collections import Counter
from datetime import datetime, timedelta, timezone
from hashlib import sha1
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

import joblib
import numpy as np
from sklearn import __version__ as sklearn_version
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits

from scripts import audit_ict_liquidity_rank_prev_period as prior


fixed, live, joint = prior.fixed, prior.live, prior.joint
stream = prior.rank.stream
REVISION = '7a5e44156397a45d102d54db86f7ec140b1b123a'
BLOBS = {
    'liq_rank.py': '2b850b0cc8d32326779d5e59e8095e684f42ed5e',
    'liquidity_levels.py': 'b48552dbfc82646f6387d66093a0c8ddeff2a6fd',
}
DIR = joint.RESEARCH / 'ict_repo_vs_local_forecast_20261125'
TAPE = DIR / 'tm_gm_native_high_periods.json.gz'
REPORT = DIR / 'report.json'
MODEL = DIR / 'trained_model.joblib'
LATEST_TAPE = DIR / 'latest_native_quotes.json.gz'
LATEST_FORECAST = DIR / 'latest_forecast.json'
UTC = timezone.utc
TRAIN_END = datetime(2025, 5, 2, tzinfo=UTC)
VALID_START = datetime(2026, 6, 1, tzinfo=UTC)
VALID_END = datetime(2026, 10, 1, tzinfo=UTC)
LAG = 30
SEED = 0


def git_blob(raw):
    return sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()


def stage_sources(repo):
    for name, expected in BLOBS.items():
        raw = subprocess.check_output(['git', '-C', str(repo), 'show',
                                       f'{REVISION}:docs_layered/work_backup/{name}'])
        if git_blob(raw) != expected:
            raise ValueError(f'Upstream blob did not match: {name}')
        (DIR / name).write_bytes(raw)


def load_sources():
    for name, expected in BLOBS.items():
        if git_blob((DIR / name).read_bytes()) != expected:
            raise ValueError(f'Expected frozen Git blob: {name}')
    spec = importlib.util.spec_from_file_location('pinned_forex_liquidity_levels', DIR / 'liquidity_levels.py')
    levels = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = levels
    spec.loader.exec_module(levels)

    tree = ast.parse((DIR / 'liq_rank.py').read_text(encoding='utf-8'))
    allowed = {'chart_rows', 'feat', 'H', 'STEP', 'KINDS'}
    functions = [node for node in tree.body if (
        isinstance(node, ast.FunctionDef) and node.name in allowed
        or isinstance(node, ast.Assign) and all(isinstance(n, ast.Name) and n.id in allowed for n in node.targets)
    )]
    namespace = {'np': np, 'bisect_left': bisect_left}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(DIR / 'liq_rank.py'), 'exec'), namespace)
    classifier = next(node for node in ast.walk(tree) if isinstance(node, ast.Call)
                      and isinstance(node.func, ast.Name) and node.func.id == 'HistGradientBoostingClassifier')
    settings = {item.arg: ast.literal_eval(item.value) for item in classifier.keywords}
    return levels, namespace['chart_rows'], namespace['feat'], settings


def latest_local(as_of):
    policy = stream.load_policy()
    for receipt in sorted((stream.OUT / 'receipts').glob('*.json'), reverse=True):
        raw, at, ready = stream.load_board(policy, receipt)
        if ready <= as_of:
            return dict(cutoff=at.isoformat(), available_at=ready.isoformat(), price=raw['cutoff_close'],
                        baseline=raw['baseline'], early=raw['early'], receipt_sha256=joint.digest(receipt))
    return None


def capture(pid, target=TAPE):
    now = live.now()
    with fixed.open_terminal(pid) as alive, live.terminal() as (api, _):
        account = live.quotes.checked_terminal(api)
        raw = {}
        for key, period in (('H1', api.TIMEFRAME_H1), ('H4', api.TIMEFRAME_H4)):
            rates = api.copy_rates_range('XAUUSD', period, datetime(2024, 1, 1, tzinfo=UTC), now + timedelta(hours=4))
            if rates is None or not len(rates):
                raise RuntimeError(f'Native {key} unavailable: {api.last_error()}')
            raw[key] = [[int(row['time']), *[float(row[k]) for k in ('open', 'high', 'low', 'close')]]
                        for row in rates]
        if not alive():
            raise RuntimeError('MT5 closed during research capture')
    joint.write_zip(target, dict(observed_at=now.isoformat(), server=account.server, native=raw, local=latest_local(now)))


class NativeSeries:
    def __init__(self, levels, period, bars):
        self.levels = levels
        self.bars = bars
        self.timeframe = period
        self.seconds = levels.PERIOD_SECONDS[period]
        self.opens = [b.opened for b in bars]
        if self.opens != sorted(set(self.opens)):
            raise ValueError(f'{period} clock mapping is not strictly increasing')
        self.closes = [stamp + self.seconds for stamp in self.opens]
        self.high, self.low, self.close = (np.array([getattr(b, name) for b in bars])
                                          for name in ('high', 'low', 'close'))
        self.atr = levels.atr_history(bars)
        anchors = levels.identify_levels(bars, period, midnight_pause=period == 'H1', atr_values=self.atr)
        self.anchors = self.index(anchors)

    def index(self, anchors):
        rows = []
        for level in anchors:
            start = bisect_left(self.opens, level.starts_at)
            end = bisect_left(self.opens, level.expires_at) - 1 if level.expires_at is not None else len(self.opens) - 1
            if start > end:
                continue
            spread = self.high[start:end + 1] > level.price if level.side == 1 else self.low[start:end + 1] < level.price
            crossed = start + int(np.argmax(spread)) if spread.any() else len(self.opens)
            rows.append((level, start, end, crossed))
        return rows

    def inputs(self, idx, *, prefix=False):
        if idx < 300 or not self.atr[idx]:
            return []
        atr, mid = self.atr[idx], self.close[idx]
        drift12, drift120 = ((mid - self.close[idx - n]) / atr for n in (12, 120))
        rows = []
        if prefix:
            anchors = self.levels.identify_levels(self.bars[:idx+1], self.timeframe,
                        midnight_pause=self.timeframe == 'H1', atr_values=self.atr[:idx+1])
            indexed = self.index(anchors)
        else:
            indexed = self.anchors
        for level, start, _, crossed in indexed:
            # The original code checks t < end for finite-lived levels. At the
            # latest candle maturity is known from its actual closing time.
            if start > idx or crossed <= idx or (level.expires_at is not None and self.closes[idx] >= level.expires_at):
                continue
            side = level.side
            distance = side * (level.price - mid) / atr
            if distance > 15:
                continue
            left = max(level.start, idx - 300)
            side_prices = self.high if side == 1 else self.low
            touches = int(np.sum(np.abs(side * (side_prices[left:idx + 1] - level.price) / atr) <= .15))
            rows.append(dict(dist=distance, side=side, toward12=side*drift12, toward120=side*drift120,
                             touches=touches, age=idx-level.end, form=level.end-level.start, npts=len(level.points or ()),
                             kind=level.kind, price=level.price, known_at=level.known_at))
        all_dist = sorted(row['dist'] for row in rows)
        side_dist = {side: sorted(row['dist'] for row in rows if row['side'] == side) for side in (1, -1)}
        for row in rows:
            group = side_dist[row['side']]
            row.update(rank_all=bisect_left(all_dist, row['dist']), rank_side=bisect_left(group,row['dist']), n_side=len(group))
        return rows if len(rows) >= 2 else []


def forecast(series, index, feature, model, *, verify=True):
    rows = series.inputs(index)
    if verify and rows != series.inputs(index, prefix=True):
        raise ValueError('Future candles changed the upstream candidate features')
    if not rows:
        return []
    probabilities = model.predict_proba(np.array([feature(row) for row in rows]))[:, 1]
    return [dict(rows[i], score=float(probabilities[i])) for i in np.argsort(-probabilities)[:2]]


def train_and_validate(series, chart_rows, feat, params):
    samples = []
    for line in series.values():
        n = bisect_right(line.closes, int(TRAIN_END.timestamp()))
        pool = line.levels.identify_levels(line.bars[:n], line.timeframe,
                   midnight_pause=line.timeframe == 'H1', atr_values=line.atr[:n])
        samples.extend((line.timeframe, rows) for _, rows in chart_rows(line.bars[:n], pool, line.atr[:n]))
    x = np.array([feat(row) for _, rows in samples for row in rows])
    y = np.array([row['hit'] for _, rows in samples for row in rows])
    if len(set(y)) != 2:
        raise ValueError('Native upstream training labels are unavailable')
    model = HistGradientBoostingClassifier(**params, random_state=SEED).fit(x, y)
    validation, parity = {}, {}
    for key, line in series.items():
        anchors = line.levels.identify_levels(line.bars, key, midnight_pause=key == 'H1', atr_values=line.atr)
        test = chart_rows(line.bars, anchors, line.atr)
        counts = Counter()
        checked = Counter()
        for idx, rows in test:
            stamp = datetime.fromtimestamp(line.closes[idx], UTC)
            if [feat(row) for row in line.inputs(idx)] == [feat(row) for row in rows]:
                checked['equal'] += 1
            else:
                checked['different'] += 1
                if VALID_START <= stamp < VALID_END:
                    raise ValueError(f'Upstream feature replay differs in the validation period: {key} {stamp}')
            if not VALID_START <= stamp < VALID_END:
                continue
            order = np.argsort(-model.predict_proba(np.array([feat(row) for row in rows]))[:, 1])
            counts.update(windows=1, model_first=int(rows[order[0]]['hit']),
                          model_first_two=int(any(rows[i]['hit'] for i in order[:2])),
                          nearest_first=int(min(rows, key=lambda r: r['dist'])['hit']))
        validation[key] = counts
        parity[key] = checked
    return model, dict(moment_counts=Counter(key for key, _ in samples), candidates=len(y),
                       native_120_bar=validation, causal_feature_parity=parity)


def common_comparison(line, feature, model, windows):
    counts = Counter()
    cases = []
    for entry in windows:
        at = entry['at']
        anchor = int(at.timestamp())
        index = bisect_left(line.closes, anchor)
        if index >= len(line.closes) or line.closes[index] != anchor:
            counts['non_aligned_close'] += 1
            continue
        if line.close[index] != entry['frozen_price']:
            counts['different_close'] += 1
            continue
        repo = forecast(line, index, feature, model)
        local = entry['picks']
        if not repo or not local:
            counts['missing_candidates'] += 1
            continue
        selected = {
            'repo': [dict(side=row['side'], lo=row['price'], hi=row['price']) for row in repo],
            'local': [dict(side=side, lo=edge, hi=edge) for side, edge in local],
        }
        raw = dict(cutoff=at.isoformat(), baseline={'ERL': selected['local'], 'IRL': []},
                   early={'ERL': selected['repo'], 'IRL': []})
        ready = entry['ready']
        outcome = fixed.grade(raw, ready, entry['buckets'], 1)
        if outcome['state'] != 'scored':
            counts[outcome['state']] += 1
            continue
        books = {key: outcome['outcomes'][arm]['ERL'] for key, arm in (('repo', 'early'), ('local', 'baseline'))}
        pool = books['repo'] + books['local']
        first, edges = prior.rank.first_strict(pool)
        counts.update(windows=1, union_with_sweep=int(first is not None))
        for side, rows in books.items():
            counts[side+'_top1_swept'] += rows[0]['status'] == 'sweep'
            counts[side+'_top2_swept'] += any(row['status'] == 'sweep' for row in rows)
            counts[side+'_top1_won_first'] += prior.rank.stream.expiry.outer(rows[0]) in edges
        cases.append(dict(cutoff=at.isoformat(), checked_from=ready.isoformat(), local_source=entry['source'], repo_predictions=repo,
                          local_erl_top_two=local, outcomes=books, earliest_union_bid_ms=first))
    return dict(counts=counts, cases=cases)


def weekly_windows(series):
    week = prior.rank.week
    report, evidence = fixed.read(week.REPORT), joint.read_zip(week.INPUT)
    if report['inputs'][week.INPUT.name] != joint.digest(week.INPUT):
        raise ValueError('The recent local board report and source evidence disagree')
    _, archived, _ = week.response.checked_inputs()
    common_closes = {stamp for line in series.values() for stamp in line.closes}
    selected = [row for row in report['cases'] if int(datetime.fromisoformat(row['cutoff']).timestamp()) in common_closes]
    retained = {row[0]: row[4] for row in archived['m5']}
    current = {row[0]: row[4] for row in evidence['m5']}
    windows = []
    for case, board, ready, buckets in prior.rank.boards_for(selected, archived, evidence):
        at = datetime.fromisoformat(case['cutoff'])
        previous = (at - fixed.M5).isoformat()
        if case['source'] == 'real_time_registered':
            close = board['cutoff_close']
        elif case['source'] == 'reconstructed_extension':
            close = current[previous]
        else:
            close = retained[previous]
        outcomes = fixed.grade(board, ready, buckets, 1)
        pairs = stream.paired(outcomes)
        if (not pairs or any(case['comparisons'][str(LAG)][scope][key] != value
                             for scope, item in pairs.items() for key, value in item.items())):
            raise ValueError(f'Local weekly score differs from original at {at}')
        windows.append(dict(at=at, ready=ready, frozen_price=close, source=case['source'],
                            picks=prior.rank.picks(board['early']['ERL'], close)['score_2'], buckets=buckets))
    return report, windows


def native_series(evidence, levels):
    as_of = datetime.fromisoformat(evidence['observed_at'])
    series = {}
    for period, raw in evidence['native'].items():
        bars = [levels.Bar(levels.server_to_utc(stamp), *ohlc) for stamp, *ohlc in raw]
        series[period] = NativeSeries(levels, period, [bar for bar in bars
                       if bar.opened + levels.PERIOD_SECONDS[period] <= as_of.timestamp()])
    return series


def current_forecast(series, feat, model, evidence):
    repo = {key: dict(closed_at=datetime.fromtimestamp(line.closes[-1], UTC).isoformat(), price=line.close[-1],
                      ranked=forecast(line, len(line.bars)-1, feat, model)) for key, line in series.items()}
    return dict(repo_tm_gm_refit=repo, local=evidence['local'])


def predict(pid):
    report = fixed.read(REPORT)
    if (report['model_sha256'] != joint.digest(MODEL) or report['sklearn'] != sklearn_version
            or report['upstream_blobs'] != BLOBS):
        raise ValueError('Trained model metadata differs from the saved validation')
    levels, _, feat, _ = load_sources()
    capture(pid, LATEST_TAPE)
    evidence = joint.read_zip(LATEST_TAPE)
    with threadpool_limits(limits=4):
        current = current_forecast(native_series(evidence, levels), feat, joblib.load(MODEL), evidence)
    live.atomic_json(LATEST_FORECAST, dict(observed_at=evidence['observed_at'], current=current,
                         upstream_commit=REVISION, tape_sha256=joint.digest(LATEST_TAPE),
                         model_sha256=report['model_sha256'], orders_sent=0))
    print(f'Both forecasts captured at {evidence["observed_at"]}. {LATEST_FORECAST}')


def run():
    levels, chart_rows, feat, settings = load_sources()
    evidence = joint.read_zip(TAPE)
    series = native_series(evidence, levels)
    local_study = fixed.read(prior.OUT)
    if local_study['inputs'][prior.BID.name] != joint.digest(prior.BID):
        raise ValueError('The independent local replay and Bid tape differ')
    bid = joint.read_zip(prior.BID)['buckets']
    previous = [dict(at=datetime.fromisoformat(entry['cutoff']), frozen_price=entry['frozen_price'],
                     ready=datetime.fromisoformat(entry['cutoff']) + timedelta(seconds=LAG),
                     picks=entry['delay'][str(LAG)]['ERL']['picks']['score_2'],
                     buckets=[bid[entry['cutoff']]], source='archived_tm_gm')
                for entry in local_study['cases']]
    this_week, recent = weekly_windows(series)
    with threadpool_limits(limits=4):
        model, validation = train_and_validate(series, chart_rows, feat, settings)
        print('trained', validation, flush=True)
        current = current_forecast(series, feat, model, evidence)
        common = common_comparison(series['H1'], feat, model, previous)
        per_period = {key: common_comparison(line, feat, model, recent) for key, line in series.items()}
    week = prior.rank.week
    temporary = MODEL.with_suffix('.tmp.joblib')
    joblib.dump(model, temporary)
    live.feed.replace_with_retry(temporary, MODEL)
    proof = dict(observed_at=evidence['observed_at'], upstream_commit=REVISION, upstream_blobs=BLOBS,
                 training_end=TRAIN_END.isoformat(), params=settings, sklearn=sklearn_version, random_state=SEED,
                 model_sha256=joint.digest(MODEL),
                 training_and_own_120_bar_validation=validation, native_common_h1_first_m5=common,
                 current_week=dict(end=this_week['end'], source_windows=len(this_week['cases']), comparisons=per_period),
                 current=current,
                 inputs={p.name: joint.digest(p) for p in (TAPE, prior.OUT, prior.BID, week.REPORT, week.INPUT, Path(__file__))},
                 orders_sent=0)
    live.atomic_json(REPORT, proof)
    print(json.dumps(dict(as_of=proof['observed_at'], common=common['counts'], current_week={
        key: result['counts'] for key, result in per_period.items()}, repo_current=current['repo_tm_gm_refit']), ensure_ascii=False))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--upstream-git', type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--capture-terminal-pid', type=int)
    mode.add_argument('--predict-terminal-pid', type=int)
    args = parser.parse_args()
    DIR.mkdir(parents=True, exist_ok=True)
    if args.upstream_git:
        stage_sources(args.upstream_git)
    if args.predict_terminal_pid:
        predict(args.predict_terminal_pid)
        sys.exit(0)
    if args.capture_terminal_pid:
        capture(args.capture_terminal_pid)
    run()
