"""Compare published sweep rules on identical TMGM XAUUSD crossing prefixes."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter
from datetime import datetime
from hashlib import sha1
from pathlib import Path
from runpy import run_path
import sys
from types import SimpleNamespace

from ict_ai import sweep_state_strict
from scripts import audit_ict_sweep_combination as combination


replay = combination.replay
REVISION = 'b96a63a2f1cdb323a4d26bb6a5c7fcdf646cca8f'
BLOBS = {'sweep_v5.py': '800d07d2a7502ed8b52fc298f4f7c30a8715a500',
         'sweep_v7.py': '3f173dec4929418b48e2197c0fd4e5b7c8fc5fd4',
         'liquidity_levels.py': 'b48552dbfc82646f6387d66093a0c8ddeff2a6fd'}
STATE3 = dict(end_atr=1.5, out_end=1.5, strong_n=4, engulf_atr=0.8, grace=3, window=48)
OUT = replay.OUT.parent / 'ict_sweep_state3_tmgm_20261126.json'
LABELS = ('sweep', 'break')


def load_algorithms(folder):
    for name, expected in BLOBS.items():
        data = (folder / name).read_bytes()
        actual = sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        if actual != expected:
            raise ValueError(f'{name} does not match {REVISION}')
    sys.path.insert(0, str(folder.resolve()))
    try:
        return run_path(str(folder / 'sweep_v5.py')), run_path(str(folder / 'sweep_v7.py'))
    finally:
        sys.path.pop(0)


def replay_event(event, bars, times, minutes, v5, v7):
    obs = event['decisions'][str(minutes)]
    outcome = obs['later_30m']
    if outcome == 'incomplete' or obs['status'] in ('missing_prior', 'incomplete'):
        return None
    at = datetime.fromisoformat(event['crossing_at'])
    opened = at - replay.M5
    index = bisect_left(times, opened)
    prefix = replay.verify_observation(bars, index, 1 + minutes // 5)
    if not prefix or prefix[0].time != opened or not obs['prior_atr']:
        raise ValueError(f'Incomplete quote prefix at {at}')
    side, edge, atr = event['side'], event['edge'], obs['prior_atr']
    args = prefix, 0, side, edge, atr
    local = sweep_state_strict.crossing_state(side, edge, prefix[0], prefix[1:], prefix[-1].time + replay.M5, atr)
    upstream_v7b = v7['classify_b'](*args).label
    if (upstream_v7b in LABELS or obs['status'] in LABELS) and upstream_v7b != obs['status']:
        raise ValueError(f'Latest upstream V7B differs from the archived baseline at {at}')
    state3, trace = v7['classify_state3'](*args, **STATE3, trace=True)
    signed_close = side * (prefix[-1].close - edge)
    verdicts = dict(v7b=upstream_v7b, local_state2=local['status'],
                    repo_state2=v7['classify_state2'](*args, end_atr=1.5, out_end=1.5).label,
                    repo_state3=state3.label,
                    close_side='break' if signed_close > 0 else 'sweep' if signed_close < 0 else 'pending')
    if minutes == 60:
        verdicts['local_structure_first'] = combination.structure.structure_verdict(event, bars, times) or upstream_v7b
    if minutes == 240:
        verdicts['repo_v5'] = v5['classify'](prefix, 0, SimpleNamespace(side=side, price=edge), atr).label
    return dict(crossing_at=event['crossing_at'], side=side, edge=edge, outcome=outcome,
                verdicts={name: label if label in LABELS else 'pending' for name, label in verdicts.items()},
                state3_through=state3.through, state3_changes=trace)


def grade(rows):
    observed = Counter(row['outcome'] for row in rows)
    methods = {}
    if not rows:
        return dict(outcomes=observed, methods=methods)
    for name in rows[0]['verdicts']:
        matrix = {label: Counter() for label in (*LABELS, 'pending')}
        for row in rows:
            matrix[row['verdicts'][name]][row['outcome']] += 1
        methods[name] = dict(matrix=matrix, calls=sum(sum(matrix[label].values()) for label in LABELS),
                             matched=sum(matrix[label][label] for label in LABELS),
                             sweep_recall_n=matrix['sweep']['sweep'], break_recall_n=matrix['break']['break'])
    flips = [r for r in rows if r['verdicts']['local_state2'] != r['verdicts']['repo_state3']]
    return dict(outcomes=observed, methods=methods, local_vs_state3=dict(changed=len(flips),
                state3_fixed=sum(r['verdicts']['repo_state3'] == r['outcome'] for r in flips),
                local_state2_right=sum(r['verdicts']['local_state2'] == r['outcome'] for r in flips)))


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('upstream_dir', type=Path, help='Directory with the three pinned GitHub source files')
    parser.add_argument('--out', type=Path, default=OUT, help='Save a comparison without replacing the archived report')
    args = parser.parse_args()
    v5, v7 = load_algorithms(args.upstream_dir)
    bars, times, *_, inputs = replay.read_inputs()
    events_file = replay.OUT / 'events.json.gz'
    events = replay.study.read_zip(events_file)
    for event in events['events']:
        stamp = datetime.fromisoformat(event['crossing_at'])
        proof = replay.evaluate_crossing(bars, times, stamp, event['side'], event['edge'])
        for cutoff, result in proof['decisions'].items():
            archived = event['decisions'][cutoff]
            if any(result[key] != archived[key] for key in ('status', 'prior_atr', 'known_at', 'later_30m')):
                raise ValueError(f'Archived verdict or follow-up differs from the quote tape at {stamp}, {cutoff}m')
    older, older_bars, older_times, older_inputs = combination.older_events()
    results = {}
    evidence = {}
    for minutes in replay.WINDOWS:
        recent = [replay_event(event, bars, times, minutes, v5, v7) for event in events['events']]
        earlier = [replay_event(event, older_bars, older_times, minutes, v5, v7) for event in older]
        samples = {'recent_unique': recent, 'older_nearest': earlier}
        for scope in ('IRL', 'ERL'):
            key = f'oct_nov/short/{scope}/top10'
            samples[key] = [recent[i] for i in events['indices'][key]]
        results[minutes] = {name: dict(unavailable=sample.count(None), **grade([row for row in sample if row]))
                            for name, sample in samples.items()}
        evidence[minutes] = dict(recent=recent, older=earlier)
        print(f'{minutes}m', {name: (sum(group['outcomes'].values()),
              {method: row['matched'] for method, row in group['methods'].items()})
              for name, group in results[minutes].items() if name in ('recent_unique', 'older_nearest')}, flush=True)
    replay.filters.atomic_json(args.out, dict(revision=REVISION, source_blobs=BLOBS, state3_parameters=STATE3,
        cutoff='Minutes after first strict in-range crossing bar closes; each method sees only that prefix',
        outcome='All six following M5 closes strictly on the same side; otherwise mixed',
        notes='Price-path proxy. V5 requires all 48 following bars. Candidate levels are unchanged across methods.',
        recent_events_sha256=replay.study.digest(events_file), older_inputs=older_inputs, recent_inputs=inputs,
        local_state_sha256=replay.study.digest(Path(sweep_state_strict.__file__)),
        script_sha256=replay.study.digest(Path(__file__).resolve()), counts=results, evidence=evidence, orders_sent=0))


if __name__ == '__main__':
    main()
