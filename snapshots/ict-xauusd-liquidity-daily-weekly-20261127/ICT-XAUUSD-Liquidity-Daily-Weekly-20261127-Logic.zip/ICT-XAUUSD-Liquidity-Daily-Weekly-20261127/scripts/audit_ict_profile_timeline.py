"""Verify the daily/weekly chart timelines against clipped TMGM M5 archives."""

from argparse import ArgumentParser
from collections import Counter
from datetime import date, datetime, timedelta
from pathlib import Path

from ict_ai.profile_lifecycle import _day_bounds
from ict_ai.profile_timeline import M5, M15, QuoteSeries, daily_timeline, weekly_timeline
from scripts.audit_ict_daily_learning import ARCH, RESEARCH, aggregate_bars, digest, read_market
from scripts.serve_ict_live import atomic_json


WEEKS = tuple(date.fromisoformat(d) for d in (
    '2025-06-23','2026-02-09','2026-02-23','2026-03-09','2026-05-11','2026-06-01',
    '2026-08-24','2026-09-14','2026-10-19','2026-10-26','2026-11-02','2026-11-09'))
OUT = RESEARCH/'ict_profile_timeline_20261124.json'


def clipped(series, start, at):
    return [QuoteSeries(quotes.closed(start,at,period)) for quotes,period in zip(series,(M5,M15),strict=True)]


def run():
    bars,times = read_market()
    m5 = QuoteSeries(bars)
    m15 = QuoteSeries(aggregate_bars(bars,5,15,times[-1]+M5))
    series = (m5,m15)
    verified = Counter()
    grouped = {scope:Counter() for scope in ('daily','weekly')}
    timeline = {}
    for monday in WEEKS:
        days = [monday+timedelta(days=i) for i in range(5)]
        start = _day_bounds(monday)[0]-timedelta(days=1)
        end = _day_bounds(days[-1])[1]
        week = weekly_timeline(*series,days,end,end)
        daily = {day.isoformat():daily_timeline(*series,day,end,end) for day in days}
        for scope,arg,rows in [('weekly',days,week),*(( 'daily',day,daily[day.isoformat()]) for day in days)]:
            build = weekly_timeline if scope=='weekly' else daily_timeline
            for i,row in enumerate(rows):
                at = datetime.fromisoformat(row['as_of'])
                if build(*clipped(series,start,at),arg,at,at)!=rows[:i+1]:
                    raise AssertionError(f'{scope} future information at {at}')
                verified[scope] += 1
                grouped[scope]['coverage_insufficient'] += not row['covered']
                grouped[scope]['any_candidates'] += bool(row['cards'])
                grouped[scope].update(change['state'] for change in row['changes'])
                grouped[scope].update(f'friday/{card["status"]}' for card in row.get('friday_followthrough', ()))
        timeline[monday.isoformat()] = dict(weekly=week,daily=daily)
    inputs = (ARCH/'XAUUSDM5.npz',ARCH/'clock_validation.json',Path(__file__),Path('ict_ai/profile_timeline.py'),
              Path('ict_ai/profile_lifecycle.py'),Path('ict_ai/profile_session_followthrough.py'),
              Path('ict_ai/weekly_path.py'),Path('ict_ai/weekly_close_candidates.py'),
              Path('ict_ai/weekly_friday_followthrough.py'))
    return dict(weeks=len(WEEKS),daily_dates=len(WEEKS)*5,prefix_checks=dict(verified),
                counts={scope:dict(totals) for scope,totals in grouped.items()},timeline=timeline,
                source_sha256={p.name:digest(p) for p in inputs},orders_sent=0)


if __name__=='__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=OUT)
    args = parser.parse_args()
    result = run()
    atomic_json(args.out,result)
    print(result['prefix_checks'],result['counts'])
