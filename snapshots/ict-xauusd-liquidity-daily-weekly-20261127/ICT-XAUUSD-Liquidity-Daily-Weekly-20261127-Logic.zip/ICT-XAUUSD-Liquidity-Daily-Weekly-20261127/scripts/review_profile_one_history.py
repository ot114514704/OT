"""Reclassify archived XAUUSD history with the native panel rules and the closed Friday tape."""
import argparse
from datetime import date, timedelta
from hashlib import sha256
from html import escape
import json
from pathlib import Path
from statistics import mean

from brooks_ai.types import Bar, utc_time
from ict_ai.profile_lifecycle import daily_profile_lifecycle, weekly_profile_lifecycle
from ict_ai.timebase import NY
from ict_ai.weekly_path import weekly_path
from scripts.export_mt5_profiles import midnight, tgif_ruler
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_news import ROOT, RULES, SCHEDULE, STEP, block, calendar_index, controls_for, extent
from scripts.replay_ict_news_progression import phase_path
from scripts.replay_ict_ipda_profiles import score_weekly_candidates
from scripts.replay_ict_route_checkpoints import freeze_checked, merge_history, observe_pair
from scripts.profile_day_replay import day_replay, midnight_target_replay
from scripts.audit_classic_reversal import audit_case


def load_closed_history(early, late, extension):
    quotes, sources, _, before = merge_history(early, late)
    tape = json.loads(extension.read_bytes())
    if tape["symbol"] != "XAUUSD" or tape["columns"] != ["opened_at","open","high","low","close"]:
        raise ValueError("Expected an archived XAUUSD OHLC replay")
    friday = date.fromisoformat(tape["new_york_date"])
    monday = friday - timedelta(days=4)
    end = midnight(friday) + timedelta(hours=17)
    if friday.weekday()!=4 or not midnight(monday) < before < end:
        raise ValueError("Archive dates do not extend the selected week")
    new = [Bar(utc_time(t), *ohlc, 0) for t,*ohlc in tape["price_rows_utc"]]
    if any(a.time >= b.time for a,b in zip(new,new[1:])) or not new or not (
            midnight(monday) <= new[0].time <= new[-1].time < end):
        raise ValueError("Invalid weekly quote times")
    original = {at for at in quotes if midnight(monday)<=at<before}
    common = {b.time for b in new if b.time<before}
    if not common or original != common:
        raise ValueError("Archive timestamp overlap differs")
    for b in new:
        if b.time in common:
            old = quotes[b.time]
            if (b.open,b.high,b.low,b.close) != (old.open,old.high,old.low,old.close):
                raise ValueError(f"Archive price conflict at {b.time}")
        else:
            quotes[b.time] = b
    return list(quotes.values()), sources, tape, friday, len(common), len(new)-len(common)


def news_timing(stamp, sequence):
    if utc_time(sequence["expansion_available_at"]) <= stamp:
        return "日型扩张在公布前已确认"
    if utc_time(sequence["expansion_start"]) < stamp:
        return "公布落在日型扩张确认的K线内"
    reclaimed = sequence["sweep_reclaim_available_at"]
    if reclaimed and utc_time(reclaimed) <= stamp:
        return "公布前已扫荡回收，扩张随后确认"
    if utc_time(sequence["range_available_at"]) <= stamp:
        return "公布前区间已形成，扩张随后确认"
    return "日型区间在公布后才确认"


def prior_news_controls(at, quotes, calendar, holidays, first_day):
    matches, rejected = controls_for(at,quotes,calendar,holidays,first_day,at.date(),prior_only=True)
    windows=[]
    for match in matches:
        post=match["horizons"]["30"]
        windows.append({"at_ny":match["at_ny"],"both_sides":post["path"]=="both_sides_exceeded",
                        "any_cross":bool(post["break_known_at_ny"]),
                        "first_m5_range":match["horizons"]["5"]["range"]})
    return {"windows":windows,"excluded":[{"at_ny":r["at_ny"],"reason":r["reason"]} for r in rejected]}


def prior_control_summary(weeks):
    releases=[n for week in weeks for day in week["days"] for n in day["news"]]
    pairs=[(n["post30"],n["prior_controls"]["windows"]) for n in releases
           if n["post30"] and n["prior_controls"]["windows"]]
    metrics={}
    for metric,field in (("any_cross","first_cross_in_phase_known_at_ny"),("both_sides","both_sides_crossed")):
        metrics[metric]={"matched_release_count":sum(bool(path[field]) for path,_ in pairs),
                         "mean_within_release_control_fraction":
                             mean(mean(c[metric] for c in controls) for _,controls in pairs) if pairs else None}
    return {"release_windows":len(releases),"matched_release_windows":len(pairs),
            "unique_control_windows":len({c["at_ny"] for _,controls in pairs for c in controls}),
            "weighting":"Each matched release time has equal weight; average its controls first.",
            "metrics":metrics}


def news_observations(quotes, calendar, day, daily, midnight_context=None, *, control_start=None, holidays=()):
    result = []
    for at, events in sorted(calendar.items()):
        if at.date()!=day:
            continue
        prior = block(quotes,at-6*STEP,6)
        after = block(quotes,at,6)
        record = {"scheduled_ny":at.isoformat(),"announcements":events,"post30":None,
                  "daily_routes":[]}
        if control_start is not None:
            record["prior_controls"]=prior_news_controls(at,quotes,calendar,holidays,control_start)
        if prior and after:
            low,high = extent(prior)
            record["post30"] = {
                "pre_low":low,"pre_high":high,
                **phase_path(after,{"low":low,"high":high},set())}
        if midnight_context and midnight_context["outcome"]:
            route=midnight_context["frozen"]
            selected=route["selected_route"]
            price=selected["target_reference_price"]
            until=at+6*STEP
            window=observe_pair(quotes,utc_time(route["frozen_at"]),until,until,route["price"],price)
            contact=window["contact_known_at_ny"].get("route_target")
            if contact and utc_time(contact)<=at:
                state="公布前已触及"
            elif window["missing_m5_slots"]:
                state="报价覆盖不足，先后待核"
            elif contact and utc_time(contact)<=at+6*STEP:
                state="公布后30分钟内首次触及"
            else:
                state="截至公布后30分钟未触及"
            record["midnight_target"]={"price":price,"state":state}
        for card in daily["candidates"]:
            sequence=card.get("price_sequence")
            if sequence and card["path_matched"]:
                record["daily_routes"].append({"id":card["id"],"direction":card["direction"],
                    "timing":news_timing(at,sequence),"sequence":sequence})
        result.append(record)
    return result


def midnight_archive(path, sources):
    if path is None or not path.is_file():
        return {}
    archive=json.loads(path.read_bytes())
    if archive["sources"]!=sources or any(sha256((ROOT/name).read_bytes()).hexdigest()!=expected
                                           for name,expected in archive["source_sha256"].items()):
        return {}
    return {row["day"]:row for row in archive["frozen_checkpoints"] if row["clock_ny"]=="00:00"
            and utc_time(row["available_at_ny"])<=utc_time(archive["history_until_ny"])}


def midnight_review(bars, quotes, day, history_end, cached):
    at=midnight(day)
    if cached:
        route,coverage=cached["frozen"],cached["htf_coverage"]
    else:
        route,coverage=freeze_checked(bars,at)
    if utc_time(route["frozen_at"])!=at:
        raise ValueError("Midnight hypothesis has a different cutoff")
    selected=route["selected_route"]
    result={"frozen":route,"htf_coverage":coverage,"outcome":None}
    if selected:
        if max(utc_time(selected["origin_known_at"]),utc_time(selected["target"]["available_at"]))>at:
            raise ValueError("Target was not available at midnight")
        end=midnight(day+timedelta(days=1)) if day.weekday()!=4 else at+timedelta(hours=16,minutes=55)
        result["outcome"]=observe_pair(quotes,at,end,history_end,route["price"],selected["target_reference_price"])
    return result


def review(early, late, extension, routes=None):
    bars, sources, tape, friday, common_count, added = load_closed_history(early, late, extension)
    monday = friday-timedelta(days=4)
    end = midnight(friday)+timedelta(hours=17)
    first = bars[0].time.astimezone(NY).date()
    rules = json.loads(RULES.read_bytes())
    calendar = calendar_index(rules,json.loads(SCHEDULE.read_bytes())["events"])
    quotes = {b.time:b for b in bars}
    cache=midnight_archive(routes,sources)
    origin = first - timedelta(days=first.weekday())
    weeks = []
    while origin<=monday:
        dates = [origin+timedelta(days=i) for i in range(5)]
        finish = midnight(dates[-1])+timedelta(hours=17)
        m5 = [b for b in bars if midnight(origin-timedelta(days=1))<=b.time<finish]
        m15 = aggregate_bars(m5,5,15,finish)
        path = weekly_path(m5,dates,finish)
        week = weekly_profile_lifecycle(m15,dates,finish,path)
        checkpoints=[]
        for i in (1,2,3):
            cutoff=midnight(dates[i+1])
            closed=[b for b in m5 if b.time+STEP<=cutoff]
            history=aggregate_bars(closed,5,15,cutoff)
            frozen=weekly_profile_lifecycle(history,dates,cutoff,weekly_path(closed,dates,cutoff))
            if frozen!=weekly_profile_lifecycle(m15,dates,cutoff,weekly_path(m5,dates,cutoff)):
                raise AssertionError(f"Subsequent bars altered weekly checkpoint at {cutoff}")
            score=score_weekly_candidates(frozen,week)
            active=[c for c in frozen["candidates"] if c["status"]=="active" and c.get("observed_sequence")]
            failed=[{"label":c["label"],"reason":c["failed_close_condition"]} for c in frozen["candidates"]
                    if c["status"]=="invalidated" and c.get("failed_close_condition")]
            checkpoints.append({"at_ny":cutoff.astimezone(NY).isoformat(),"day":str(dates[i]),
                                "active_labels":[c["label"] for c in active],"failed_close_conditions":failed,**score})
        days = []
        for d in dates:
            if d<first:
                continue
            daily = daily_profile_lifecycle(m15,d,finish,reference_m5=m5,include_reconstruction=False)
            prior=midnight_review(bars,quotes,d,bars[-1].time+STEP,cache.get(str(d)))
            news=news_observations(quotes,calendar,d,daily,prior,control_start=first,
                                   holidays=rules["holiday_exclusions"])
            days.append({"date":str(d),"status":daily["profile_status"],"label":daily["profile_label"],
                         "reason":daily["profile_reason"],"coverage":daily.get("coverage_complete_under_study_calendar"),
                         "matched":daily["actual_paths"],"candidates":daily["candidates"],
                         "session_checks":daily.get("session_price_checks"),
                         "midnight_route":prior,"news":news,"replay":day_replay(m5,m15,d,news,daily)})
        state, detail, _ = tgif_ruler(m5,dates[-1],finish)
        if origin == monday and (not week["coverage_complete_under_study_calendar"]
                or (state,detail) != (tape["checkpoints"][-1]["state"],tape["checkpoints"][-1]["detail"])):
            raise ValueError("Full-week recomputation differs from the archived Friday checkpoint")
        weeks.append({"start":str(origin),"status":week["profile_status"],"label":week["profile_label"],
                      "reason":week["profile_reason"],"geometry":path["daily"],"days":days,"checkpoints":checkpoints,
                      "tgif":state,"tgif_reason":detail})
        origin+=timedelta(days=7)
    return {"source_project_thread":"每周每日概况1","ny_close":end.isoformat(),"sources":sources,
            "friday_replay":str(extension),"friday_replay_sha256":sha256(extension.read_bytes()).hexdigest(),
            "verified_overlapping_m5":common_count,"added_closed_m5":added,
            "calendar_sha256":{p.name:sha256(p.read_bytes()).hexdigest() for p in (RULES,SCHEDULE)},
            "midnight_route_archive_sha256":sha256(routes.read_bytes()).hexdigest() if cache else None,
            "scope":"M15 path and M5 OHLC only; Friday extension has no spread; no execution study. "
                    "Selected scheduled US releases; fixed-time alignment, no order-flow or causality inference.",
            "prior_news_control_summary":prior_control_summary(weeks),"weeks":weeks}


def event_details(observations):
    side_names = {"buy":"上沿","sell":"下沿"}
    items = []
    def clock(stamp):
        return utc_time(stamp).astimezone(NY).strftime("%H:%M")
    for record in observations:
        names = "、".join(f'<a href="{escape(url,quote=True)}">{escape(name)}</a>'
                         for name,url in record["announcements"].items())
        notes = []
        for route in record["daily_routes"]:
            seq = route["sequence"]
            stages = ["区间确认 "+clock(seq["range_available_at"])]
            if seq["sweep_reclaim_available_at"]:
                stages.append("扫荡回收 "+clock(seq["sweep_reclaim_available_at"]))
            stages.append("扩张确认 "+clock(seq["expansion_available_at"]))
            notes.append(route["timing"]+"（"+"，".join(stages)+"）。")
        obs = record["post30"]
        if obs:
            notes.append(f'公布前30分钟区间 {obs["pre_low"]:.2f}–{obs["pre_high"]:.2f}。')
            for side, stamp in sorted(obs["first_cross_in_phase_known_at_ny"].items(),key=lambda kv:kv[1]):
                reclaimed = obs["first_close_back_across_crossed_boundary_known_at_ny"].get(side)
                detail = f'{clock(stamp)} 越过{side_names[side]}'
                notes.append(detail+(f'，{clock(reclaimed)} 收回该边界。' if reclaimed else '。'))
            if not obs["first_cross_in_phase_known_at_ny"]:
                notes.append('公布后30分钟内未越过该区间。')
            if obs["first_crosses_same_bar_intrabar_order_unknown"]:
                notes.append('同根 M5 首次越过两侧，先后待核。')
            held = obs["terminal_two_closes_outside_side"]
            if held:
                notes.append("窗口末两根 M5 均收在"+side_names[held]+"外。")
        else:
            notes.append('前后30分钟报价不足。')
        target=record.get("midnight_target")
        if target:
            notes.append(f'零点候选目标 {target["price"]:.2f}，{target["state"]}。')
        items.append(f'<p><b>{clock(record["scheduled_ny"])} NY</b>　{names}<br>{escape(" ".join(notes))}</p>')
    return ('<details class="news"><summary>经济日历与价格反应</summary>'+"".join(items)+'</details>') if items else ''


def route_details(review,matched):
    route=review["frozen"]
    selected=route["selected_route"]
    if selected:
        target=selected["target"]
        price=selected["target_reference_price"]
        area=(f'FVG {target["lower"]:.2f}–{target["upper"]:.2f}，近端 {price:.2f}'
              if "lower" in target else f'摆动{"高" if target["kind"]=="H" else "低"}点 {price:.2f}')
        side="向上" if route["direction"]==1 else "向下"
        frame="日线" if selected["timeframe"]=="D1" else "周线"
        path="内部到外部" if selected["route"]=="IRL_to_ERL" else "外部到内部"
        text=f'零点前最后收价 {route["price"]:.2f}，{frame}{path}候选{side}，目标为{area}。'
        observed=review["outcome"]
        contact=observed["contact_known_at_ny"].get("route_target")
        if contact:
            text+=f'当日纽约 {utc_time(contact).astimezone(NY):%H:%M} 的 M5 收盘可见触价。'
        elif observed["missing_m5_slots"] or observed["through_ny"]!=observed["horizon_ny"]:
            text+='已观察区间未触及，报价覆盖不足。'
        else:
            text+='当日截至收盘未触及。'
        sides={card["direction"] for card in matched if card["direction"] is not None}
        if sides:
            comparison=("方向一致" if sides=={route["direction"]} else
                        "方向相反" if route["direction"] not in sides else "出现多方向匹配")
            text+=f'收盘后复核，已匹配的每日形态与零点候选{comparison}。'
    else:
        text={"missing_price_at_cutoff":"零点缺少截至当时的收盘报价。",
              "no_eligible_route":"零点时没有满足现行起点、目标和未触及条件的路径。",
              "conflicting_routes":"零点时上、下方向都有候选，方向待定。"}[route["status"]]
    frames=review["htf_coverage"]
    return ('<details class="news"><summary>零点的高周期目标</summary><p>'+escape(text)+
            f' 当时可用完整日线 {frames["D1"]["closed_periods"]} 根、周线 {frames["W1"]["closed_periods"]} 根。</p></details>')


def structure_replay(report, evidence_path):
    evidence = json.loads(evidence_path.read_bytes())
    if report["sources"] != evidence["quote_sources"]:
        raise ValueError("Structure signals and chart must share the same archived quotes and clock")
    result = {}
    phase_labels = {
        "supported":"与候选方向一致", "missing_recent_closed_bar":"缺少近期已收盘 M15",
        "retracement_without_directional_reference":"回调的参考方向不足",
        "retracement_of_opposing_reference":"处于反向参考走势的回调中",
        "retracement_without_pda_contact":"回调尚未触及参考方向的 PDA",
        "opposing_expansion":"反向扩张", "opposing_reversal":"反向反转",
        "consolidation":"盘整，方向待定", "undetermined":"阶段待定"}
    for experiment in evidence["experiments"]:
        source = Path(experiment["source_replay"])
        raw = (ROOT/source).read_bytes()
        if sha256(raw).hexdigest() != experiment["sha256"]:
            raise ValueError(f"Structure event archive changed: {source}")
        archive = json.loads(raw)
        cases = {row["id"]:row for row in experiment["cases"]}
        for day in archive["days"]:
            key = day["date"]
            if key in result:
                raise ValueError(f"Duplicate structure day {key}")
            start = midnight(date.fromisoformat(key))
            through = min(1440, int((utc_time(archive["as_of"])-start).total_seconds()//60))
            frames = []
            for event in day["events"]:
                known = utc_time(event["available_at"])
                minute = int((known-start).total_seconds()//60)
                if not 0 <= minute <= through:
                    raise ValueError(f"Event outside review day {key}")
                side = "看涨" if event["side"] == 1 else "看跌"
                kind = event["kind"]
                if kind == "liquidity_sweep":
                    edge = "低点" if event["side"] == 1 else "高点"
                    detail = f'扫过亚洲{edge}后收回，扫荡极值 {event["sweep_extreme"]:.2f}。'
                    label = "扫亚洲"+edge
                elif kind == "mss_candidate":
                    label = side+"结构转移候选"
                    detail = f'收盘越过先前确定的结构价 {event["frozen_structure"]["price"]:.2f}。'
                elif kind == "sweep_mss_fvg_candidate":
                    case = cases[event["id"]]
                    if utc_time(case["signal_at_ny"]) != known or case["side"] != event["side"]:
                        raise ValueError(f"Inconsistent confirmation {event['id']}")
                    label = side+"结构与 FVG 候选"
                    stamp = utc_time(case["sweep_at"]).astimezone(NY)
                    daily = {c["direction"] for c in case["daily_candidates"] if c["direction"] in (-1,1)}
                    daily_text = ("方向待定" if not daily else "多空并存" if len(daily)>1 else
                                  "看涨" if 1 in daily else "看跌")
                    week = {1:"看涨",-1:"看跌",None:"方向待定"}[case["weekly_scenario"]["scenario_direction"]]
                    detail = (f'FVG {event["fvg"]["lower"]:.2f}–{event["fvg"]["upper"]:.2f}。'
                              f'{stamp:%H:%M} 扫荡开始时的 M15 {phase_labels[case["prior_sweep_phase_evidence"]]}；'
                              f'此刻 M15 {phase_labels[case["at_signal_phase_evidence"]]}。'
                              f'此刻日概况{daily_text}，日模型使用的周背景{week}。')
                else:
                    raise ValueError(f"Unexpected structure event {kind}")
                frames.append([minute,label,detail,kind])
            result[key] = {"through":through,"reference":day["status"]!="missing_reference",
                           "frames":sorted(frames,key=lambda row:row[0])}
    return result


def episode_details(day):
    replay=day["replay"]
    intervals=replay.get("candidate_intervals",[])
    if not intervals:
        return ""
    endings={"insufficient_coverage":"报价覆盖不足","invalidated":"规则判定失效",
             "matched_at_close":"收盘路径匹配","unmatched_at_close":"收盘条件未齐",
             "no_longer_active":"退出候选"}
    def clock(minutes):
        return "次日 00:00" if minutes==1440 else f"{minutes//60:02d}:{minutes%60:02d}"
    rows=[]
    review_notes=[]
    checked=set()
    for e in intervals:
        direction={1:" · 看涨",-1:" · 看跌",None:""}[e["direction"]]
        rows.append(f'<tr><td>{clock(e["start"])}–{clock(e["end"])}</td>'
                    f'<td>{escape(e["label"]+direction)}</td><td>{endings[e["end_reason"]]}</td></tr>')
        if day["coverage"] and e["id"]=="classic_reversal_variant" and e["direction"] not in checked:
            checked.add(e["direction"])
            audit=audit_case(date.fromisoformat(day["date"]),replay,e["direction"],e,
                             [utc_time(n["scheduled_ny"]).astimezone(NY) for n in day["news"]])
            price=audit["frozen_ny_extreme"]
            adjective="低点" if e["direction"]==1 else "高点"
            relation="也是" if audit["ny_extreme_was_day_extreme_at_candidate"] else "尚未达到"
            note=f'{clock(e["start"])} 纽约候选{adjective} {price:.2f}，{relation}零点以来的{adjective}。'
            broken=audit["first_break_known_at_ny"]
            note+=(f'{broken[11:16]} 的 M5 收线显示该点已被突破。' if broken else '该点保持至日收盘。')
            follow=audit["first_two_close_followthrough_ny"]
            edge=audit["london_opposite_boundary"]
            note+=(f'{follow[11:16]} 才完成两根 M15 连续收在伦敦另一端 {edge:.2f} 外。' if follow
                   else f'截至日收盘，仍缺两根 M15 连续收在伦敦另一端 {edge:.2f} 外。')
            if audit["matches_by_12"] and not audit["matches_by_10"]:
                note+='将观察窗延至纽约 12:00 后，这条价格路径匹配 1.1 研究规则。'
            if audit["replacement_events"]:
                steps=[]
                for event in audit["replacement_events"]:
                    when=utc_time(event["at"]).astimezone(NY).strftime("%H:%M")
                    if event["kind"]=="reclaim":
                        detail=f'新{adjective} {event["price"]:.2f} 形成后，M15 收回伦敦边界'
                        if event["nearby_releases"]:
                            detail+='（极点出现在已列公布后 30 分钟内）'
                    else:
                        detail={"follow":"两根 M15 完成跟随","broken":"新极点被突破"}[event["kind"]]
                    steps.append(when+" "+detail)
                note+=' 重新检验新极点。'+"，".join(steps)+'。'
                note+=('日收盘满足试验条件。' if audit["replacement_matches_at_close"] else '日收盘未满足试验条件。')
            review_notes.append('<p><b>1.1 收盘复核</b>　'+escape(note)+'</p>')
    return ('<details class="news"><summary>盘中候选何时出现、何时结束</summary>'
            '<table><thead><tr><th>纽约时间 · M15</th><th>观察到的候选</th><th>结束原因</th>'
            '</tr></thead><tbody>'+"".join(rows)+'</tbody></table>'+"".join(review_notes)+'</details>')


def episode_summary(weeks):
    totals={}
    covered=0
    for week in weeks:
        for day in week["days"]:
            if not day["coverage"] or "candidate_intervals" not in day["replay"]:
                continue
            covered+=1
            key=lambda c:(c["id"],c["direction"])
            intraday={key(c):c for c in day["replay"]["candidate_intervals"]}
            matched={key(c):c for c in day["matched"]}
            for ident,card in (intraday|matched).items():
                label=card["label"]+{1:" · 看涨",-1:" · 看跌",None:""}[ident[1]]
                counts=totals.setdefault(label,[0,0,0])
                counts[0]+=ident in intraday
                counts[1]+=ident in intraday and ident in matched
                counts[2]+=ident not in intraday and ident in matched
    if not totals:
        return ""
    rows="".join(f"<tr><td>{escape(label)}</td><td>{seen}</td><td>{both}</td><td>{only}</td></tr>"
                 for label,(seen,both,only) in sorted(totals.items()))
    return (f'<details><summary>盘中候选与收盘路径 · {covered} 个完整交易日</summary>'
            '<p>同一天、同一形态和方向只计一次。收盘按相同课程规则复核。</p>'
            '<table><thead><tr><th>概况与方向</th><th>盘中出现</th><th>其中收盘匹配</th>'
            '<th>仅收盘匹配</th></tr></thead><tbody>'+rows+'</tbody></table></details>')


def write_week_table(report, path, evidence_path=None):
    weeks = []
    chart_data={}
    structures = structure_replay(report,evidence_path) if evidence_path else {}
    for week in reversed(report["weeks"]):
        rows = []
        for day in week["days"]:
            chart_data[day["date"]]={**day["replay"],"structure":structures.get(day["date"]),
                "midnightTarget":midnight_target_replay(date.fromisoformat(day["date"]),day["replay"]["bars"],
                                                        day["midnight_route"]),
                "newsControls":{int((utc_time(n["scheduled_ny"])-midnight(date.fromisoformat(day["date"]))).total_seconds()//60):
                               n["prior_controls"]["windows"] for n in day["news"] if "prior_controls" in n}}
            direction = {1:" · 看涨",-1:" · 看跌",None:""}
            label = " / ".join(m["label"]+direction[m["direction"]] for m in day["matched"]) or day["label"]
            date_text=escape(day["date"])
            rows.append(f'<tr><td>{date_text}<button type="button" class="open-replay" data-open-replay="{date_text}">K线回放</button></td><td>{escape(label)}</td>'
                        f'<td>{escape(day["reason"])}{episode_details(day)}'
                        f'{route_details(day["midnight_route"],day["matched"])}{event_details(day["news"])}</td></tr>')
        weeks.append(f'<details {"open" if not weeks else ""}><summary>{escape(week["start"])} 当周　'
                     f'{escape(week["label"])}</summary><p>{escape(week["reason"])}</p>'
                     +week_checkpoint_table(week["checkpoints"])+'<table>'
                     '<thead><tr><th>纽约日期</th><th>日概况</th><th>收盘依据</th></tr></thead><tbody>'
                     +"".join(rows)+'</tbody></table><p><b>'+escape(week["tgif"])+'</b>　'
                     +escape(week["tgif_reason"])+'</p></details>')
    chart_template=(ROOT/"scripts/profile_day_replay.html").read_text(encoding="utf-8")
    chart=chart_template.replace("__DAY_REPLAY_DATA__",json.dumps(chart_data,ensure_ascii=False,separators=(",",":")).replace("<","\\u003c"))
    path.write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" '
                    'content="width=device-width, initial-scale=1"><title>黄金日周概况复核</title>'
                    '<style>body{font:16px/1.6 system-ui,sans-serif;max-width:1080px;margin:3vw auto;padding:1em;color:#172f3c}'
                    'details{border-top:1px solid #aaa;padding:1em 0}summary{font-weight:650;cursor:pointer}'
                    'table{border-collapse:collapse;width:100%}td,th{padding:.6em;text-align:left;border-bottom:1px solid #ddd}'
                    'td:first-child{white-space:nowrap}th{background:#edf3f4}.news{border:0;padding:.4em 0 0}'
                    '.news summary{font-weight:500;color:#285a68}</style>'
                    '<h1>XAUUSD 每日与每周概况</h1><p>纽约日界 · '
                    'M15 识别，M5 核对价格。点击各周查看逐日理由与周五 TGIF。</p>'
                    +episode_summary(report["weeks"])+"".join(weeks)+chart+'</html>',encoding="utf-8")


def week_checkpoint_table(checkpoints):
    rows=[]
    for c in checkpoints:
        outcome={"candidate_matched_close":("候选形态与方向全部匹配" if c["exact_match_if_candidate"]
                                              else "部分候选匹配，仍有分歧"),
                 "candidate_unmatched_at_close":"周收盘未匹配候选",
                 "no_candidate_at_cutoff":"无可评分的具体形态",
                 "unscored_incomplete":"报价不足，跳过评分"}[c["result"]]
        candidates=" / ".join(c["active_labels"]) or "暂无已观察到的候选"
        expired="".join('<br>'+escape(x["label"]+"已失效。"+x["reason"]) for x in c.get("failed_close_conditions",[]))
        rows.append(f'<tr><td>{escape(c["day"])}</td><td>{escape(candidates)}{expired}</td><td>{outcome}</td></tr>')
    return ('<details class="news"><summary>周二至周四收盘时能看出什么</summary><table>'
            '<thead><tr><th>纽约日收盘</th><th>当时的候选</th><th>与周收盘对照</th></tr></thead>'
            '<tbody>'+"".join(rows)+'</tbody></table></details>')


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--html",type=Path)
    parser.add_argument("--structure-evidence",type=Path)
    parser.add_argument("--routes",type=Path,default=ROOT/"output/research/ict_route_checkpoints_20261121.json")
    for name in ("early","late","extension","out"):
        parser.add_argument("--"+name,type=Path,required=True)
    args = parser.parse_args()
    result = review(args.early,args.late,args.extension,args.routes)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    if args.html:
        args.html.parent.mkdir(parents=True,exist_ok=True)
        write_week_table(result,args.html,args.structure_evidence)
