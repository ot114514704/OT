"""Register and settle quote-only forward tests of the frozen liquidity filters."""

from argparse import ArgumentParser
from collections import Counter
from contextlib import closing, contextmanager
from datetime import datetime, time, timedelta
from pathlib import Path
import json
import sqlite3
from statistics import median
from time import sleep

import numpy as np

from ict_ai.dol_history import _deadline, batch_id
from ict_ai.range_liquidity import _Coverage
from ict_ai.structural_liquidity import grouped_extrema, structural_ranking
from scripts import audit_ict_liquidity_15m as quarter
from scripts import audit_ict_liquidity_filter_layers as filters
from scripts import backtest_ict_liquidity_account as quotes
from scripts import export_mt5_profiles as feed
from scripts.serve_ict_live import atomic_json


OUT = quotes.RESEARCH / 'ict_liquidity_filter_forward_20261124'
POLICY = OUT / 'policy.json'
M5 = quotes.M5
HORIZONS = ('quarter', 'short', 'week')
FORWARD_CODE = (Path(__file__), Path(filters.__file__), Path(quarter.__file__), quotes.ROOT / 'ict_ai/structural_liquidity.py',
                quotes.ROOT / 'ict_ai/target_priority.py', quotes.ROOT / 'ict_ai/range_liquidity.py', quotes.CLOCK)


def now():
    return datetime.now(quotes.UTC)


def load_policy(*, persist=True):
    report = json.loads(filters.OUT.read_bytes())
    report15 = json.loads(quarter.OUT.read_bytes())
    for name, expected in report['inputs'].items():
        if quotes.digest(quotes.ROOT / name) != expected:
            raise ValueError(f'Frozen fit source changed: {name}')
    code = {str(p.relative_to(quotes.ROOT)): quotes.digest(p) for p in FORWARD_CODE}
    digests = {p.name: quotes.digest(p) for p in (filters.OUT, quarter.OUT)}
    if report15['source'][filters.OUT.name] != digests[filters.OUT.name]:
        raise ValueError('Quarter-hour fit did not use the pinned four-hour research')
    if not POLICY.exists() or not persist:
        data_by_horizon = dict(report['results'], **{f'quarter/{scope}': value['refit_15m']
                                for scope, value in report15['results'].items()})
        model = {key: dict(model=data['model'], rules={stage: record.get('rule')
                  for stage, record in data['stages'].items()}) for key, data in data_by_horizon.items()}
        policy = dict(frozen_at=now().isoformat(), historical_fit=digests, code=code,
                      models=model, recorded_checkpoints=sorted(quotes.CHECKPOINTS), orders_sent=0)
        if not persist:
            return policy
        atomic_json(POLICY, policy)
    policy = json.loads(POLICY.read_bytes())
    if policy['code'] != code or policy['historical_fit'] != digests:
        raise ValueError('Current code or thresholds differ from the prospectively frozen policy')
    return policy


def read_chart(after, before):
    with closing(sqlite3.connect(quotes.DATABASE.resolve().as_uri()+'?mode=ro', uri=True, timeout=2)) as db:
        rows = db.execute('SELECT id,cutoff,received,payload FROM chart_batches WHERE received IS NOT NULL '
                          'AND cutoff>? AND cutoff<=? ORDER BY cutoff,received,id', (after.isoformat(), before.isoformat())).fetchall()
    for key, cutoff, accepted, raw in rows:
        at, receipt = map(datetime.fromisoformat, (cutoff, accepted))
        if not at <= receipt <= before or at.astimezone(quotes.NY).strftime('%H:%M') not in quotes.CHECKPOINTS:
            continue
        sample = json.loads(raw)
        if sample['at'] != cutoff or batch_id(at, sample['price'], [sample['targets'], sample['pools']]) != key:
            raise ValueError(f'Chart batch differs from its published receipt at {at}')
        yield at, receipt, key, sample


def h1_range(bars, at):
    parts, _ = grouped_extrema(bars, M5, at, ['H1'])['H1']
    ranges = [p[2].high-p[3].low for p in parts if p and p[2].high > p[3].low][-24:]
    if len(ranges) != 24:
        raise ValueError('Closed H1 ranges are incomplete')
    return median(ranges)


def identity(target):
    return target['side'], target['lo'], target['hi'], target['score']


def layer_indices(targets, price, scale, at, end, model, bars, metadata_verified):
    size = len(targets)
    distances = [abs(quotes.far(target) - price) / scale for target in targets]
    rules = model['rules']
    take = list(range(size))
    by_stage = dict(current_top10=take)
    if rules['distance'] is not None:
        take = [i for i in take if distances[i] <= rules['distance']]
    by_stage['distance'] = take
    if not metadata_verified:
        return by_stage
    if rules['structure'] is not None:
        origins, obstacles = rules['structure']
        take = [i for i in take if targets[i]['origins'] >= origins and 4-targets[i]['components']['path'] <= obstacles]
    by_stage['structure'] = take
    if rules['price_and_clock'] is not None and take:
        group = dict(at=at, end=end, status='complete', targets=targets, price=price, distance=distances,
                     x=[filters.ranking.features(t, d) for t,d in zip(targets,distances,strict=True)])
        filters.context.add_context([group], bars, [b.time for b in bars])
        x = np.array([filters.features(group, i) for i in take])
        params = model['model']
        weights = np.array(params['coefficients'])
        logits = weights[0]+((x-params['mean'])/params['scale'])@weights[1:]
        threshold = rules['price_and_clock']
        take = [i for i,p in zip(take, 1/(1+np.exp(-np.clip(logits,-40,40))), strict=True) if p>=threshold]
    by_stage['price_and_clock'] = take
    return by_stage


class ReferencePriceMismatch(ValueError):
    pass


def qualify(at, sample, bars, minutes, policy):
    if not bars or bars[-1].time+M5 != at or bars[-1].close != sample['price']:
        terminal_price = bars[-1].close if bars else None
        raise ReferencePriceMismatch(f'At {at}, chart reference {sample["price"]} differs from closed M5 {terminal_price}')
    scale = h1_range(bars, at)
    verified = structural_ranking(bars, at, sample['targets'], minute_bars=minutes, limit=10, priority_uplift=True)
    result = {}
    local_day = at.astimezone(quotes.NY).date()
    friday = local_day+timedelta(days=4-local_day.weekday())
    deadlines = {'quarter': min(at+3*M5,_deadline(at)), 'short': _deadline(at),
                 'week': datetime.combine(friday,time(16,55),quotes.NY)}
    for scope in ('IRL','ERL'):
        chart = sorted([p for p in sample['pools'] if p['scope'] == scope.lower()], key=lambda p:p['rank'])
        rebuilt = [p for p in verified if p['classification'] == scope]
        consistent = [identity(p) for p in chart] == [identity(p) for p in rebuilt]
        for horizon, end in deadlines.items():
            key = horizon+'/'+scope
            result[key] = dict(targets=chart, deadline=end.isoformat(), metadata_verified=consistent,
                               layers=layer_indices(rebuilt if consistent else chart, sample['price'], scale, at, end,
                                                    policy['models'][key], bars, consistent))
    return result, scale


def detect(target, candles):
    side, level = target['side'], quotes.far(target)
    for b in candles:
        if side*(quotes.excursion(b,side)-level) > 0:
            return ('sweep' if b.low<=level<=b.high else 'gap_over'), (b.time+M5).isoformat()
    return 'none', None


def outcomes(registration, bars, asof):
    at = datetime.fromisoformat(registration['cutoff'])
    ready = datetime.fromisoformat(registration['eligible_from'])
    coverage = _Coverage(at, asof, bars, M5)
    stats = {}
    for key, model in registration['pools'].items():
        end = datetime.fromisoformat(model['deadline'])
        observed_minutes = max(0, (end-ready).total_seconds()/60)
        if end > asof or end <= ready:
            stats[key] = dict(state='open' if end > asof else 'expired_on_registration', observed_minutes=observed_minutes)
            continue
        if coverage.gap(at,end):
            stats[key] = dict(state='incomplete')
            continue
        before = [b for b in bars if at <= b.time < ready]
        after = [b for b in bars if ready <= b.time and b.time+M5 <= end]
        targets = model['targets']
        labels = [('already_swept',None) if detect(t,before)[0] != 'none' else detect(t,after) for t in targets]
        retained = [i for i,v in enumerate(labels) if v[0] != 'already_swept']
        nearest = sorted(retained,key=lambda i: (abs(quotes.far(targets[i])-registration['price']),i))
        layers = {}
        for name, take in model['layers'].items():
            kept = [i for i in take if i in retained]
            layers[name] = dict(offers=len(kept), sweeps=sum(labels[i][0]=='sweep' for i in kept),
                                nearest_equal_coverage=sum(labels[i][0]=='sweep' for i in nearest[:len(kept)]))
        stats[key] = dict(state='complete', layers=layers, labels=labels, excluded=len(targets)-len(retained),
                          observed_minutes=observed_minutes)
    return stats


@contextmanager
def terminal():
    api = feed.mt5
    clock = json.loads(quotes.CLOCK.read_bytes())
    if not api.initialize(str(quotes.TERMINAL), timeout=10000):
        raise RuntimeError(f'TMGM unavailable: {api.last_error()}')
    try:
        account = quotes.checked_terminal(api)
        yield api, clock
        quotes.checked_terminal(api, (account.login, account.server))
    finally:
        api.shutdown()


def get_forecast(at, sample, policy):
    with terminal() as (api, clock):
        bars = feed.history('XAUUSD', api.TIMEFRAME_M5, clock, at)
        minutes = feed.history('XAUUSD', api.TIMEFRAME_M1, clock, at)
    return qualify(at, sample, bars, minutes, policy)


def probe():
    policy = load_policy(persist=False)
    observed = now()
    candidates = list(read_chart(observed-timedelta(days=4), observed))
    if not candidates:
        raise RuntimeError('No acknowledged production liquidity list to verify')
    at, receipt, key, sample = next((v for v in reversed(candidates) if _deadline(v[0]) <= observed), candidates[-1])
    pools, scale = get_forecast(at, sample, policy)
    estimate_ready = receipt.replace(minute=receipt.minute//5*5,second=0,microsecond=0)+M5
    cutoff = observed.replace(minute=observed.minute//5*5,second=0,microsecond=0)
    with terminal() as (api, clock):
        bars = quotes.collect_bars(api,at,cutoff,clock)
    shell = dict(cutoff=at.isoformat(), eligible_from=estimate_ready.isoformat(), pools=pools, price=sample['price'])
    evidence = dict(mode='rehearsal_only', cutoff=at.isoformat(), receipt=receipt.isoformat(), chart_batch=key,
                    closed_h1_range_median=scale, pools=pools, hypothetical_eligibility=estimate_ready.isoformat(),
                    outcomes=outcomes(shell,bars,cutoff), counted_for_forward_accuracy=False)
    atomic_json(OUT / 'probe.json', evidence)
    print(at.isoformat(), {k:(v['metadata_verified'], {s:len(x) for s,x in v['layers'].items()})
                           for k,v in pools.items()}, flush=True)


def register(policy, observed):
    counts = Counter()
    first = max(datetime.fromisoformat(policy['frozen_at']), observed-2*M5)
    for at, receipt, key, sample in read_chart(first, observed):
        path = OUT/'registrations'/at.strftime('%Y%m%dT%H%M%SZ.json')
        rejected = OUT/'rejections'/path.name
        if path.exists():
            counts['already_recorded'] += 1
            continue
        if rejected.exists():
            counts['previously_rejected'] += 1
            continue
        try:
            pools, scale = get_forecast(at, sample, policy)
        except ReferencePriceMismatch as exc:
            counts['reference_disagreement'] += 1
            atomic_json(rejected,
                        dict(at=at.isoformat(), receipt=receipt.isoformat(), chart_batch=key, error=str(exc)))
            continue
        registered = now()
        if not receipt <= registered < at+2*M5:
            counts['late_receipt_or_verification'] += 1
            continue
        floor = registered.replace(minute=registered.minute//5*5,second=0,microsecond=0)
        eligible = floor + M5
        atomic_json(path, dict(cutoff=at.isoformat(), receipt=receipt.isoformat(), registered_at=registered.isoformat(),
                               chart_batch=key, eligible_from=eligible.isoformat(), price=sample['price'],
                               range_h1=scale, pools=pools, policy_sha256=quotes.digest(POLICY)))
        counts['registered'] += 1
    return dict(counts)


def settle(observed):
    totals = Counter()
    for path in sorted((OUT/'registrations').glob('*.json')):
        row = json.loads(path.read_bytes())
        if row['policy_sha256'] != quotes.digest(POLICY):
            raise ValueError('Registered candidates were produced by another frozen policy')
        at = datetime.fromisoformat(row['cutoff'])
        for horizon in HORIZONS:
            models = {k: m for k,m in row['pools'].items() if k.startswith(horizon+'/')}
            end = max(datetime.fromisoformat(m['deadline']) for m in models.values())
            output = OUT/'settlements'/f'{path.stem}_{horizon}.json'
            if output.exists():
                totals[horizon+'_settled'] += 1
                continue
            if end > observed:
                totals[horizon+'_pending'] += 1
                continue
            with terminal() as (api, clock):
                bars = quotes.collect_bars(api, at, end, clock)
            prior = next((b for b in bars if b.time + M5 == at), None)
            if prior is None or prior.close != row['price']:
                stats = {key:dict(state='published_reference_disagreement') for key in models}
            else:
                stats = outcomes(dict(row,pools=models), bars, end)
            atomic_json(output, dict(registration_sha256=quotes.digest(path), observed_at=observed.isoformat(),
                                     quotes=[[b.time.isoformat(),*quotes.ohlc(b)] for b in bars], outcomes=stats))
            totals[horizon+'_settled'] += 1
    return dict(totals)


def poll(policy):
    observed = now()
    registrations = register(policy, observed)
    settlements = settle(observed)
    return dict(observed_at=observed.isoformat(), frozen_at=policy['frozen_at'], registrations=registrations,
                settled=settlements, journal_count=len(list((OUT/'registrations').glob('*.json'))),
                accuracy=accuracy_summary(),
                next_checkpoints=[x.isoformat() for x in list(quotes.planned_checkpoints(observed,observed+timedelta(days=2)))[:3]],
                orders_sent=0)


def accuracy_summary():
    totals = {}
    for path in sorted((OUT/'settlements').glob('*.json')):
        file = json.loads(path.read_bytes())
        for case, measured in file['outcomes'].items():
            if measured['state'] != 'complete':
                continue
            exposure = 'less_than_15m' if case.startswith('quarter/') and measured['observed_minutes'] < 15 else 'planned_horizon'
            group = totals.setdefault(f'{case}/{exposure}',{})
            for stage, outcome in measured['layers'].items():
                group.setdefault(stage,Counter()).update(outcome)
                group[stage]['settled_windows'] += 1
    return totals


def main():
    import msvcrt

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('probe','once','watch'))
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT/'watch.lock').open('a+b') as lock:
        if lock.tell() == 0:
            lock.write(b'0')
            lock.flush()
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        except OSError as exc:
            raise SystemExit('The liquidity accuracy recorder is already active') from exc
        if args.mode == 'probe':
            probe()
            return
        policy = load_policy()
        while True:
            try:
                status = poll(policy)
            except (sqlite3.OperationalError,RuntimeError) as exc:
                status = dict(observed_at=now().isoformat(), error=str(exc), orders_sent=0)
            atomic_json(OUT/'status.json',status)
            if args.mode == 'once':
                print(status)
                break
            sleep(20)


if __name__ == '__main__':
    main()
