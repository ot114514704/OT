"""Persist the completed manual reading of the daily ASR draft and figures.

This does not assert that all audio or all decoded frames were manually read.
"""
import hashlib,json,sys
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]


def main():
    base=ROOT/'research/ict_time_videos/time2_daily'
    manifest=json.loads((base/'manifest.json').read_text(encoding='utf-8'))
    progress=json.loads((base/'asr-progress.json').read_text(encoding='utf-8'))
    source=Path(manifest['source_path']);sha=hashlib.sha256(source.read_bytes()).hexdigest()
    if sha!=manifest['source_sha256'] or sha!=progress['source_sha256'] or progress['status']!='transcribed_draft':
        raise ValueError('Reviewed transcript is incomplete or bound to another source')
    rows=json.loads((base/'asr-segments.json').read_text(encoding='utf-8'))
    if len(rows)!=progress['segments']:raise ValueError('Transcript segment count changed')
    review_path=base/'integration.json';review=json.loads(review_path.read_text(encoding='utf-8'))
    if review['source_sha256']!=sha:raise ValueError('Review source differs')
    review['source_path']=str(source)
    review['transcript_sha256']=hashlib.sha256((base/'asr-segments.json').read_bytes()).hexdigest()
    review['asr_segment_count']=len(rows)
    review['text_reviewed_through_seconds']=manifest['duration_seconds']
    review['reviewed_at_utc']=datetime.now(timezone.utc).isoformat()
    review_path.write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
    manifest.update(status=review['review_status'],text_reviewed=True,full_asr_draft_read=True,
                    full_audio_listened_and_corrected=False,full_video_reviewed=False,
                    text_reviewed_through_seconds=manifest['duration_seconds'],integration='integration.json')
    (base/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    corpus=[]
    for section in ('principles','profiles','additional_limits'):
        for i,item in enumerate(review[section]):
            corpus.append({'id':f'time2-hd-{section}-{item.get("id",i)}','kind':'reviewed_video_interpretation',
                'source_path':str(source),'source_sha256':sha,'time_seconds':item['seconds'],
                'text':'【原文观点转述】'+item['source_claim']+'\n【研究解释】'+item['interpretation'],
                'reviewed':True,'full_audio_corrected':False,'source_instructions_executed':False})
    destination=ROOT/'research/ict_time_videos/corpus.jsonl'
    old=[json.loads(line) for line in destination.read_text(encoding='utf-8').splitlines()] if destination.exists() else []
    keep=[item for item in old if not item['id'].startswith('time2-hd-')]
    destination.write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in keep+corpus),encoding='utf-8')
    main=ROOT/'research/ict_corpus.jsonl'
    existing=[json.loads(line) for line in main.read_text(encoding='utf-8').splitlines()]
    existing=[item for item in existing if not item['id'].startswith('time2-hd-')]
    main.write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in existing+corpus),encoding='utf-8')
    print(json.dumps({'reviewed_asr_segments':len(rows),'curated_corpus_entries':len(corpus),'all_audio_verified':False,'orders_sent':0}))


if __name__=='__main__':main()
