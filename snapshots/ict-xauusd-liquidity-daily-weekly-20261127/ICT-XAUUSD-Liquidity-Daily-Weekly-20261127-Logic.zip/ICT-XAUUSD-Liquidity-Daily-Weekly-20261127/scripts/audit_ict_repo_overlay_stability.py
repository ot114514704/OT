"""Combine frozen pairwise overlay results and measure variation across NY weeks."""

from collections import Counter, defaultdict
from datetime import datetime
import json
from pathlib import Path

from ict_ai.dol_history import week_start
from ict_ai.liquidity_repo_overlay import outside
from ict_ai.timebase import NY
from scripts import audit_ict_liquidity_repo_overlay as later
from scripts.check_pool_priority import interval


shared = later.shared
EARLY = later.OUT.with_name('repo_overlay_holdout.json')
OUT = later.OUT.with_name('repo_overlay_stability.json')


def earlier_cases(saved, minutes):
    for case in saved['cases']:
        grade = case['results'][f'{minutes}m_30s']
        arms = grade['outcomes']
        yield dict(cutoff=case['cutoff'], local=grade['wins']['local'], combined=grade['wins']['integrated'],
                   repo=grade['wins']['repo'], baseline_edges=[(row['side'], row['price']) for row in arms['local']],
                   combined_edges=[(row['side'], row['price']) for row in arms['integrated']])


def later_cases(saved, deduplicated, group, minutes):
    data = saved['results'][group][str(minutes)]['cases']
    repo = {row['cutoff']: row['outcomes']['repo_unique'] for row in deduplicated['results'][group][str(minutes)]['cases']}
    for case in data:
        selected = case['selected']
        yield dict(cutoff=case['cutoff'], local=case['wins']['local'], combined=case['wins']['fixed_two'],
                   repo=any(row['status'] == 'sweep' for row in repo[case['cutoff']]),
                   baseline_edges=list(map(outside, selected['local'])), combined_edges=list(map(outside, selected['fixed_two'])))


def summarize(cases):
    totals = Counter(windows=0, local=0, combined=0, repo=0, gained=0, lost=0, changed=0, changed_side=0)
    weeks = defaultdict(lambda: Counter(windows=0, gained=0, lost=0, net=0))
    for row in cases:
        at = datetime.fromisoformat(row['cutoff'])
        week = week_start(at.astimezone(NY).date()).isoformat()
        old, new = row['local'], row['combined']
        changed = row['baseline_edges'] != row['combined_edges']
        if row['baseline_edges'] and row['baseline_edges'][0] != row['combined_edges'][0]:
            raise ValueError(f'First-ranked local candidate was replaced: {at}')
        side_changed = changed and {side for side, _ in row['baseline_edges']} != {side for side, _ in row['combined_edges']}
        if not changed and old != new:
            raise ValueError(f'Identical edges led to different outcomes: {at}')
        totals.update(windows=1, local=int(old), combined=int(new), repo=int(row['repo']), gained=int(new and not old),
                      lost=int(old and not new), changed=int(changed), changed_side=int(side_changed))
        weeks[week].update(windows=1, gained=int(new and not old), lost=int(old and not new), net=int(new) - int(old))
    return dict(counts=totals, weeks=weeks,
                weeks_improved=sum(row['net'] > 0 for row in weeks.values()),
                weeks_flat=sum(row['net'] == 0 for row in weeks.values()),
                weeks_worse=sum(row['net'] < 0 for row in weeks.values()),
                weekly_block_interval=interval({key: (row['net'], row['windows']) for key, row in weeks.items()}))


def main():
    early, recent, repo = map(shared.fixed.read, (EARLY, later.OUT, later.INPUT))
    dig = shared.joint.digest
    if (recent['inputs'][later.INPUT.name] != dig(later.INPUT)
            or early['inputs'][shared.INPUT.name] != dig(shared.INPUT)):
        raise ValueError('The comparison refers to different repository snapshots')
    results = {}
    for minutes in (5, 15):
        groups = {'jun_sep_H1': list(earlier_cases(early, minutes))}
        for group in later.H1_GROUPS:
            groups[group] = list(later_cases(recent, repo, group, minutes))
        all_cases = [row for batch in groups.values() for row in batch]
        if len({row['cutoff'] for row in all_cases}) != len(all_cases):
            raise ValueError('One H1 cutoff occurs in multiple cohorts')
        summaries = {name: summarize(cases) for name, cases in groups.items()}
        for group, item in summaries.items():
            if group == 'jun_sep_H1':
                check = early['results'][f'{minutes}m_30s']
                expected = [check[key] for key in ('windows', 'repo', 'local', 'integrated', 'gained', 'lost')]
            else:
                check = recent['results'][group][str(minutes)]['counts']
                expected = [check[key] for key in ('windows', 'repo_top2', 'local', 'fixed_two', 'fixed_two_gained', 'fixed_two_lost')]
            if expected != [item['counts'][key] for key in ('windows', 'repo', 'local', 'combined', 'gained', 'lost')]:
                raise ValueError(f'Prior cohort results did not reproduce: {group}')
        results[minutes] = dict(pooled=summarize(all_cases), cohorts=summaries)
    paths = (EARLY, later.OUT, later.INPUT, shared.INPUT, Path(__file__))
    shared.live.atomic_json(OUT, dict(results=results, inputs={p.name: dig(p) for p in paths}, orders_sent=0,
         method=('Pool disjoint H1 cohorts using the same earlier-window, nominal 30-second availability convention '
                 'with later actual chart registration lag retained where available. Resample paired New York weeks '
                 'as blocks (5000 draws) for a descriptive hit-rate difference interval.')))
    print(json.dumps({minutes: {key: value for key, value in result['pooled'].items() if key != 'weeks'}
                      for minutes, result in results.items()}))


if __name__ == '__main__':
    main()
