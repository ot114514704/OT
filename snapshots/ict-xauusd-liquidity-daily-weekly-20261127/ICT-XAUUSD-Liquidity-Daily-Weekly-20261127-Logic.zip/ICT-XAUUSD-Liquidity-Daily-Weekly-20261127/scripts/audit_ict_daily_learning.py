"""Walk forward on 10:00 New York ICT daily price-path candidates."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter
from datetime import datetime, time, timedelta
import json
from pathlib import Path
from statistics import mean

import numpy as np

from ict_ai.profile_lifecycle import _day_bounds, daily_profile_lifecycle
from ict_ai.profile_sources import DAILY
from ict_ai.timebase import NY, daily_profile_history_start, previous_week, session_windows
from scripts.audit_ict_target_ranking import fit_prior_weeks
from scripts.check_pool_priority import ARCH, read_market
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_pool_and_dol import RESEARCH, digest


M5 = timedelta(minutes=5)
M15 = 3*M5
MANUAL = [RESEARCH/name for name in ('ict_profile_price_review_comparison_20261121.json',
                                    'ict_profile_validation_baseline_20261121.json')]
FEATURES = [*DAILY, 'side', 'net_today', 'from_london_close', 'beyond_london_side',
            'day_close_location', 'ny_width', 'asia_width_relative_to_london',
            'prior_day_available', 'prior_day_range_position', 'prior_week_available', 'prior_week_range_position']


def candidate_key(card):
    return card['id'],card['direction'] or 0


def inputs(view, closed, start, prior, week):
    context = view.get('session_price_checks')
    if not context or not view.get('coverage_complete_under_study_calendar'):
        return []
    today = [bar for bar in closed if bar.time>=start]
    last = today[-1].close
    lo,hi = min(b.low for b in today),max(b.high for b in today)
    london,asia = (context[key] for key in ('london','asia'))
    upper,lower = london['high'],london['low']
    width = max(upper-lower,.01)
    local_day = start.astimezone(NY).date()
    # The lifecycle has already verified complete London bars before these prices are used.
    windows = session_windows(local_day)
    ny_start = windows['new_york'][0]
    ny = [b for b in today if b.time>=ny_start]
    london_close = next(b.close for b in today if b.time+M5==windows['london'][1])
    def position(bounds,side):
        return 0. if bounds is None else side*(last-(bounds[0]+bounds[1])/2)/max(.01,bounds[1]-bounds[0])
    rows = []
    for card in view['candidates']:
        if card['status']!='active' or not card['observed_sequence']:
            continue
        ident,side = candidate_key(card)
        if ident not in DAILY:
            raise ValueError(f'Unknown daily candidate: {ident}')
        values = [*(int(ident==name) for name in DAILY), side,
                  side*(last-today[0].open)/width,side*(last-london_close)/width,
                  side*(last-(upper if side>0 else lower))/width,
                  side*((last-lo)/max(.01,hi-lo)-.5),
                  (max(b.high for b in ny)-min(b.low for b in ny))/width,(asia['high']-asia['low'])/width,
                  int(prior is not None),position(prior,side),int(week is not None),position(week,side)]
        rows.append((candidate_key(card),values))
    if len({key for key,_ in rows})!=len(rows):
        raise ValueError('Duplicate candidate in the daily lifecycle')
    return rows


def pack(bars,times):
    known_ranges = {}
    day_records = []
    days=sorted({bar.time.astimezone(NY).date() for bar in bars if bar.time.astimezone(NY).weekday()<5})
    completed_at = times[-1]+M5
    for day in days:
        start,end = _day_bounds(day)
        at = datetime.combine(day,time(10),NY)
        start_history = daily_profile_history_start(day)
        first = bisect_left(times,start_history)
        tail = bars[first:bisect_left(times,end)]
        if at > completed_at:
            continue
        history = [bar for bar in tail if bar.time+M5<=at]
        m15 = aggregate_bars(tail,5,15,end)
        prefix = aggregate_bars(history,5,15,at)
        early = daily_profile_lifecycle(prefix,day,at,include_reconstruction=False,reference_m5=history)
        replay = daily_profile_lifecycle(m15,day,at,include_reconstruction=False,reference_m5=tail)
        if early!=replay:
            raise ValueError(f'Future bars changed the daily candidate at {at}')
        prior_day = day-timedelta(days=3 if day.weekday()==0 else 1)
        prior = known_ranges.get(prior_day)
        week = [known_ranges.get(d) for d in previous_week(day)]
        prior_week = (min(r[0] for r in week),max(r[1] for r in week)) if all(week) else None
        choices = inputs(early,history,start,prior,prior_week)
        eligible = end<=completed_at
        finish = daily_profile_lifecycle(m15,day,min(end,completed_at),include_reconstruction=False,reference_m5=tail)
        eligible = eligible and finish.get('coverage_complete_under_study_calendar',False)
        if eligible:
            today = [bar for bar in tail if start<=bar.time]
            known_ranges[day] = min(b.low for b in today),max(b.high for b in today)
        truth = {candidate_key(c) for c in finish['actual_paths']} if eligible else None
        day_records.append(dict(date=day,at=at,end=end,week=day-timedelta(days=day.weekday()),
                                keys=[key for key,_ in choices],x=[x for _,x in choices],
                                y=[int(key in truth) for key,_ in choices] if truth is not None else None,
                                actual=sorted(truth) if truth is not None else None,
                                prefix_covered=early.get('coverage_complete_under_study_calendar',False)))
    return day_records


def forecast(day, training, model):
    mu,scale,coef = model
    logits = coef[0]+((np.array(day['x'])-mu)/scale)@coef[1:]
    historical = Counter()
    successes = Counter()
    for row in training:
        historical.update(row['keys'])
        successes.update(k for k,hit in zip(row['keys'],row['y']) if hit)
    rate = (sum(successes.values())+1)/(sum(historical.values())+2)
    baseline = [(successes[k]+8*rate)/(historical[k]+8) for k in day['keys']]
    return (1/(1+np.exp(-np.clip(logits,-40,40)))).tolist(), baseline


def metrics(rows, truth_key):
    samples = {name:[] for name in ('learned','signed_family_prior')}
    eligible = [row for row in rows if row[truth_key] is not None]
    for row in eligible:
        y = row[truth_key]
        for name,values in samples.items():
            p = row[name]
            top = max(range(len(p)),key=p.__getitem__)
            values.append((mean((a-b)**2 for a,b in zip(p,y)),y[top]))
    return {name:dict(dates=len(values),candidate_rows=sum(len(r[truth_key]) for r in eligible),
                      dates_with_any_matching_candidate=sum(any(r[truth_key]) for r in eligible),
                      brier=mean(brier for brier,_ in values) if values else None,
                      top1_matches=sum(hit for _,hit in values)) for name,values in samples.items()}


def paired_weeks(rows):
    """Quantify paired Brier improvement without counting nearby dates as independent."""
    weeks = {}
    for row in rows:
        if row['rule_y'] is None:
            continue
        y = np.array(row['rule_y'])
        delta = np.mean((np.array(row['signed_family_prior'])-y)**2-(np.array(row['learned'])-y)**2)
        weeks.setdefault(row['ny_week'],[]).append(delta)
    totals = np.array([sum(values) for values in weeks.values()])
    counts = np.array([len(values) for values in weeks.values()])
    if len(weeks)<2:
        return dict(weeks=len(weeks),interval95=None)
    indices = np.random.default_rng(23).integers(len(weeks),size=(2000,len(weeks)))
    resampled = totals[indices].sum(axis=1)/counts[indices].sum(axis=1)
    return dict(weeks=len(weeks),interval95=np.quantile(resampled,[.025,.975]).tolist(),
                measure='signed_family_prior Brier minus learned Brier; positive favors learned')


def walk_forward(days, manual):
    observations = []
    counts = Counter()
    for day in days:
        counts['dates'] += 1
        counts['prefix_covered'] += day['prefix_covered']
        if day['prefix_covered'] and not day['keys']:
            counts['no_candidate'] += 1
            counts['no_candidate_but_rule_path_at_close'] += bool(day['actual'])
        if not day['keys']:
            continue
        counts['candidate_dates'] += 1
        training = [prior for prior in days if prior['date'].isoformat() not in manual and prior['week']<day['week']
                    and prior['end']<day['at'] and prior['keys'] and prior['y'] is not None]
        labels = Counter(y for prior in training for y in prior['y'])
        if len(training)<35 or min(labels[0],labels[1])<8:
            counts['insufficient_training'] += 1
            continue
        estimated, prior = forecast(day,training,fit_prior_weeks(training))
        local = day['date'].isoformat()
        manual_y = [int(key in manual[local]) for key in day['keys']] if local in manual else None
        observations.append(dict(date=local,available_at=day['at'].isoformat(),label_available_at=day['end'].isoformat(),
                                 ny_week=day['week'].isoformat(),
                                 trained_through=training[-1]['end'].isoformat(),training_dates=len(training),
                                 keys=day['keys'],learned=estimated,signed_family_prior=prior,rule_y=day['y'],manual_y=manual_y))
    return dict(counts=counts, rule_check=metrics(observations,'rule_y'), manual_check=metrics(observations,'manual_y'),
                paired_rule_weeks=paired_weeks(observations),
                manual_dates=len(manual),manual_days_with_path=sum(bool(v) for v in manual.values()), observations=observations)


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=RESEARCH/'ict_daily_learning_20261123.json')
    args=parser.parse_args()
    manual={}
    for path in MANUAL:
        for case in json.loads(path.read_bytes())['cases']:
            if case['period']!='daily':
                continue
            labels={(ident,{'bullish':1,'bearish':-1,None:0}[side]) for ident,side in case['reviewed']}
            if manual.setdefault(case['date'],labels)!=labels:
                raise ValueError(f"Manual review disagrees on {case['date']}")
    bars,times = read_market()
    days = pack(bars,times)
    results = walk_forward(days,manual)
    payload = dict(scope='Local XAUUSD empirical price-path study. Only existing 10:00 New York candidates are scored. '
                   'Rule labels are outcomes of the same course-derived lifecycle at day close. Manual dates are excluded '
                   'from all fitting. The manual reviews informed earlier rule work and are not blind research evidence.',
                   decision=dict(shadow_research_only=True, automated_entry_eligible=False,
                                 abstain_when='Missing closed-bar coverage, no observed candidate, or too few mature prior-week labels.'),
                   protocol=dict(cutoff_ny='10:00', min_training_dates=35, min_candidates_per_binary_class=8,
                                 prior_pseudocount=8, evaluation_unit='NY date with equal candidate weights'),
                   broker_archive=[times[0].isoformat(),times[-1].isoformat()],features=FEATURES,
                   inputs={p.name:digest(p) for p in [ARCH/'XAUUSDM5.npz',*MANUAL,Path(__file__),
                                ARCH/'clock_validation.json',Path('ict_ai/profile_lifecycle.py'),
                                Path('ict_ai/timebase.py'),Path('scripts/audit_ict_target_ranking.py')]}, **results)
    args.out.write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({k:results[k] for k in ('counts','rule_check','manual_check')},indent=2))


if __name__=='__main__':
    main()
