"""Evaluate supplemental screenshots on closed TMGM price paths and rolling probabilities."""

from argparse import ArgumentParser
from bisect import bisect_left, bisect_right
from collections import Counter
from datetime import datetime, time, timedelta
import json
from pathlib import Path

import numpy as np

from ict_ai.profile_delivery_evidence import SOURCE, daily_delivery, weekly_delivery
from scripts import audit_ict_intraday_learning as intraday
from scripts.serve_ict_live import atomic_json


daily = intraday.daily
M5 = daily.M5
M15 = 3*M5
KINDS = ('london_reversal_ny_continuation','ny_reversal_after_london_drive',
         'ny_sweep_after_london_balance','ny_sweep_context_unresolved','seek_destroy_risk')


def vectors(row,evidence):
    tracked = {'delivery_observed','waiting_for_delivery','two_sessions_reclaimed','london_double_reclaim_warning'}
    return [[*vector,*(int(any(e['kind']==kind and e['status'] in tracked and e.get('direction',0) in (0,side)
                               for e in evidence)) for kind in KINDS)]
            for (_,side),vector in zip(row['keys'],row['x'],strict=True)]


def paired_models(control,source):
    augmented = {r['date']:r for r in source['observations']}
    common = [(r,augmented[r['date']]) for r in control['observations'] if r['date'] in augmented]
    report = {}
    for label in ('rule_y','manual_y'):
        comparison = []
        for old,new in common:
            if old['keys']!=new['keys'] or old[label]!=new[label] or old['signed_family_prior']!=new['signed_family_prior']:
                raise ValueError('The two models did not score the same candidates')
            comparison.append(dict(ny_week=old['ny_week'],rule_y=old[label],learned=new['learned'],signed_family_prior=old['learned']))
        scores = daily.metrics(comparison,'rule_y')
        paired = daily.paired_weeks(comparison) if label=='rule_y' else None
        if paired:
            paired['measure']='Original linear model Brier minus revised model Brier'
        report[label] = dict(with_evidence=scores['learned'],original=scores['signed_family_prior'],
                             brier_delta_original_minus_new=paired)
    return report


def fit_network(training):
    """Small, fixed two-layer network for the exploratory probability check."""
    x = np.asarray([v for d in training for v in d['x']],dtype=float)
    y = np.asarray([v for d in training for v in d['y']],dtype=float)
    sample = np.asarray([1/len(d['y']) for d in training for _ in d['y']])
    sample /= sample.sum()
    center = sample @ x
    scale = np.sqrt(sample @ (x-center)**2)
    scale[scale<1e-8] = 1
    x = np.clip((x-center)/scale,-6,6)
    random = np.random.default_rng(23)
    a = random.normal(0,.12,(x.shape[1],12))
    b = random.normal(0,.15,(12,6))
    c = random.normal(0,.20,6)
    bias_a,bias_b,bias_c = np.zeros(12),np.zeros(6),0.

    def sigmoid(z):
        return 1/(1+np.exp(-np.clip(z,-40,40)))

    for _ in range(260):
        h = np.tanh(x@a+bias_a)
        g = np.tanh(h@b+bias_b)
        residual = sample*(sigmoid(g@c+bias_c)-y)
        grad_g = (residual[:,None]*c)*(1-g*g)
        grad_h = (grad_g@b.T)*(1-h*h)
        a -= .18*(x.T@grad_h+.015*a)
        b -= .18*(h.T@grad_g+.015*b)
        c -= .18*(g.T@residual+.015*c)
        bias_a -= .18*grad_h.sum(0)
        bias_b -= .18*grad_g.sum(0)
        bias_c -= .18*residual.sum()

    def predict(vector):
        z = np.clip((np.asarray(vector)-center)/scale,-6,6)
        return sigmoid(np.tanh(np.tanh(z@a+bias_a)@b+bias_b)@c+bias_c).tolist()

    return predict


def network_results(revised, linear, manual):
    by_date = {r['date'].isoformat():r for r in revised}
    fits = {}
    observations = []
    for row in linear['observations']:
        decision = by_date[row['date']]
        week = decision['week']
        if week not in fits:
            training = [d for d in revised if d['week']<week and d['end']<decision['at']
                        and d['date'].isoformat() not in manual and d['keys'] and d['y'] is not None]
            if len(training)!=row['training_dates'] or training[-1]['end'].isoformat()!=row['trained_through']:
                raise AssertionError('Network and linear model use different training windows')
            fits[week] = fit_network(training)
        predictions = fits[week](decision['x'])
        observations.append(dict(row,learned=predictions))
    return dict(observations=observations)


def run():
    bars,times = daily.read_market()
    cutoff = times[-1]+M5
    quarters = daily.aggregate_bars(bars,5,15,cutoff)
    qtimes = [b.time for b in quarters]
    checkpoints = intraday.rebuild_checkpoints(bars,times)
    manual = intraday.read_manual()
    before = {}
    after = {}
    networks = {}
    counts = {}
    prefix_checks = 0
    for name in ('08:30','10:00'):
        rows = checkpoints[name]
        revised = []
        counts[name] = Counter()
        for row in rows:
            at,day = row['at'],row['date']
            first = daily.session_windows(day)['asia'][0]
            span = quarters[bisect_left(qtimes,first):bisect_left(qtimes,row['end'])]
            prefix = quarters[bisect_left(qtimes,first):bisect_right(qtimes,at-M15)]
            evidence = daily_delivery(span,day,at,row['prefix_covered'])
            if evidence!=daily_delivery(prefix,day,at,row['prefix_covered']):
                raise AssertionError(f'Daily supplement changed with later bars: {at}')
            counts[name].update((e['kind'],e['status']) for e in evidence)
            revised.append(dict(row,x=vectors(row,evidence)))
            prefix_checks+=1
        before[name] = daily.walk_forward(rows,manual)
        after[name] = daily.walk_forward(revised,manual)
        networks[name] = network_results(revised,after[name],manual)

    weeks = sorted({b.time.astimezone(daily.NY).date()-timedelta(days=b.time.astimezone(daily.NY).weekday()) for b in bars})
    weekly_counts = Counter()
    weekly_cases = []
    weekly_checks = 0
    for monday in weeks:
        dates = [monday+timedelta(days=i) for i in range(5)]
        start = daily._day_bounds(monday)[0]
        end = daily._day_bounds(dates[-1])[1]
        if end>cutoff:
            continue
        m5 = bars[bisect_left(times,start):bisect_left(times,end)]
        m15 = quarters[bisect_left(qtimes,start):bisect_left(qtimes,end)]
        for at in (datetime.combine(dates[3],time(12),daily.NY),daily._day_bounds(dates[3])[1],end):
            read = weekly_delivery(m5,m15,dates,at)
            if read != weekly_delivery([b for b in m5 if b.time+M5<=at],[b for b in m15 if b.time+M15<=at],dates,at):
                raise AssertionError(f'Weekly supplement changed with later bars: {at}')
            weekly_checks+=1
            if at==end:
                weekly_counts[read[0]['status'] if read else 'no_supplemental_pattern']+=1
                if read and read[0]['status']!='coverage_unknown':
                    weekly_cases.append(dict(monday=monday.isoformat(),**read[0]))
    return dict(daily_prefix_checks=prefix_checks,weekly_prefix_checks=weekly_checks,
                daily_counts={name:{'/'.join(key):n for key,n in v.items()} for name,v in counts.items()},
                daily_probabilities={name:paired_models(before[name],after[name]) for name in before},
                neural_network_vs_original={name:paired_models(before[name],networks[name]) for name in before},
                neural_network_spec='Two tanh hidden layers (12 and 6), seeded initialization, fixed regularization, 260 steps, equal date weights.',
                weekly_counts=weekly_counts,weekly_cases=weekly_cases,
                weekly_training='Supplemental pattern has no independently labeled weekly training cohort.',
                source_screenshots_sha256=daily.digest(Path(SOURCE)),
                code_sha256={name:daily.digest(Path(name)) for name in (Path(__file__).as_posix(),
                    'ict_ai/profile_delivery_evidence.py','scripts/audit_ict_intraday_learning.py',
                    'scripts/audit_ict_daily_learning.py')},
                m5_sha256=daily.digest(daily.ARCH/'XAUUSDM5.npz'),
                limitations=['Exploratory comparison against original closed-day course rule paths.',
                             'Walk-forward models train only on mature earlier weeks; manual dates excluded from fitting.',
                             'Weekly counts describe the new evidence sequence, not predictive accuracy.'],orders_sent=0)


if __name__=='__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=daily.RESEARCH/'ict_profile_supplement_20261123.json')
    args = parser.parse_args()
    report = run()
    atomic_json(args.out,report)
    print(report['daily_prefix_checks'],report['weekly_prefix_checks'],dict(report['weekly_counts']))
    for name,data in report['daily_probabilities'].items():
        print(name,'linear',data,'network',report['neural_network_vs_original'][name]['rule_y'])
