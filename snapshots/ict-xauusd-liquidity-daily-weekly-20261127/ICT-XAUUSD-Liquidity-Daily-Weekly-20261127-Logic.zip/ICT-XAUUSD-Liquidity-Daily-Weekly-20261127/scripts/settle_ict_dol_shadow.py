"""Resolve frozen DOL shadow registrations against closed TMGM XAUUSD M5s."""
import argparse
from collections import Counter, defaultdict
import contextlib
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from brooks_ai.types import Bar
from ict_ai.dol_history import _deadline, batch_id, settle
from ict_ai.dol_tick_evidence import BidEvidence, utc_ms
from ict_ai.timebase import NY, manifest_epoch_to_utc
from scripts.audit_ipda_gap_ticks import raw_epoch, TERMINAL
from scripts.shadow_ict_dol import DATABASE, FOLDER, LOCK, archive, choose, utc_now, M5


def read_registrations():
    model = json.loads(LOCK.read_bytes())
    checksum = archive.digest(LOCK)
    for path, expected in model['code'].items():
        if archive.digest(ROOT / path) != expected:
            raise ValueError(f'Frozen scoring code differs: {path}')
    records = []
    observed_cutoffs = set()
    with contextlib.closing(sqlite3.connect(DATABASE.resolve().as_uri()+'?mode=ro', uri=True)) as db:
        for p in sorted((FOLDER/'predictions').glob('*.json')):
            row = json.loads(p.read_bytes())
            frozen, at, receipt, registered, end = (datetime.fromisoformat(v) for v in
                    (model['frozen_at'], row['cutoff'], row['chart_received'], row['recorded_at'], row['end']))
            if (row['model_sha256'] != checksum or not frozen < at <= receipt <= registered < min(end, at+2*M5)
                    or end != _deadline(at) or at in observed_cutoffs or row['selection'] != choose(model, row)):
                raise ValueError(f'Invalid or altered registration: {p}')
            packet = db.execute('SELECT cutoff,received,payload FROM chart_batches WHERE id=?',
                                (row['chart_batch'],)).fetchone()
            if packet is None or packet[:2] != (row['cutoff'],row['chart_received']):
                raise ValueError(f'Missing original chart receipt: {p}')
            sample = json.loads(packet[2])
            if (sample['at'] != row['cutoff'] or row['price'] != sample['price'] or row['targets'] != sample['targets']
                    or row['chart_batch'] != batch_id(at, sample['price'], [sample['targets'], sample['pools']])):
                raise ValueError(f'Registration and chart candidates differ: {p}')
            observed_cutoffs.add(at)
            records.append(dict(row, at=row['cutoff'], published_at=row['recorded_at'], evidence=archive.digest(p)))
    return records


def read_market(start, end, observed_at):
    import MetaTrader5 as mt5

    source = archive.read_zip(archive.QUOTES)
    clock = source['clock']
    if not mt5.initialize(str(TERMINAL), timeout=10000):
        raise RuntimeError(f'MT5 unavailable: {mt5.last_error()}')
    try:
        account, terminal = mt5.account_info(), mt5.terminal_info()
        if not account or not terminal or not terminal.connected or account.server != source['server']:
            raise RuntimeError('Terminal does not match the frozen TMGM archive')
        identity = account.login, account.server
        raw_start, raw_end = (datetime.fromtimestamp(raw_epoch(t, clock), timezone.utc) for t in (start, end))
        quotes = mt5.copy_rates_range('XAUUSD', mt5.TIMEFRAME_M5, raw_start, raw_end)
        account, terminal = mt5.account_info(), mt5.terminal_info()
        if not account or not terminal or not terminal.connected or (account.login, account.server) != identity:
            raise RuntimeError('Terminal switched while retrieving M5')
        if quotes is None:
            raise RuntimeError(f'MT5 history unavailable: {mt5.last_error()}')
        bars = []
        for q in quotes:
            at = manifest_epoch_to_utc(datetime.fromtimestamp(int(q['time']), timezone.utc), clock)
            if start <= at and at+M5 <= min(end, observed_at):
                bars.append(Bar(at, *(float(q[k]) for k in ('open','high','low','close')), 0))
        if any(a.time >= b.time for a, b in zip(bars, bars[1:])):
            raise ValueError('M5 prices are not strictly increasing in time')
    finally:
        mt5.shutdown()
    return bars


def results(records, bars, observed_at):
    settle(records, bars, observed_at)
    coverage = Counter()
    comparisons = defaultdict(Counter)
    cutoffs = []
    for row in records:
        status = row['first_touch_status']
        coverage[status] += 1
        valid = status in ('unique','same_level','same_m5_bar','no_hit')
        selections = {}
        for name, index in row['selection'].items():
            target = row['targets'][index]
            event = target['horizon_status']
            first = target['rank'] in row['first_ranks']
            selections[name] = dict(rank=target['rank'], first=first if valid else None, outcome=event,
                                    first_near_edge_touch=target['touches'][0])
            if valid:
                comparisons[name].update(windows=1, hit=int(event=='observed_hit'),
                                         unique_first=int(first and status=='unique'),
                                         same_level_first=int(first and status=='same_level'),
                                         ambiguous_first=int(first and status=='same_m5_bar'))
        cutoffs.append(dict(cutoff=row['cutoff'], day=str(datetime.fromisoformat(row['cutoff']).astimezone(NY).date()),
                            recorded_at=row['recorded_at'], end=row['end'], status=status,
                            evidence=row['evidence'], selections=selections))
    return dict(registrations=len(records), coverage=coverage, comparisons=comparisons, cutoffs=cutoffs)


def bid_results(records, evidence, observed_at):
    return summarize_bid((row, evidence.replay(row, observed_at)) for row in records)


def summarize_bid(settled):
    coverage = Counter()
    comparisons = defaultdict(Counter)
    cutoffs = []
    for row, outcome in settled:
        status, contacts, leaders = (outcome[k] for k in ('status','contacts','first_ranks'))
        ranks = {name: row['targets'][index]['rank'] for name,index in row['selection'].items()}
        expired = sorted(name for name,rank in ranks.items() if rank in contacts and not contacts[rank]['eligible'])
        comparable = not expired and status in ('unique','shared_target','same_millisecond','no_hit')
        coverage[status] += 1
        if expired:
            coverage['with_preregistration_contact_for_a_selected_target'] += 1
        if comparable:
            for name,rank in ranks.items():
                comparisons[name].update(windows=1, hit=int(rank in contacts),
                                         unique_first=int(rank in leaders and status=='unique'),
                                         shared_first=int(rank in leaders and status=='shared_target'),
                                         ambiguous_first=int(rank in leaders and status=='same_millisecond'))
        cutoffs.append(dict(cutoff=row['cutoff'], registration_sha256=row['evidence'],
                            selected_ranks=ranks, expired_selections=expired, comparable=comparable, **outcome))
    return dict(registrations=len(cutoffs), coverage=coverage, comparisons=comparisons, cutoffs=cutoffs)


def frozen_feed():
    frozen = json.loads(LOCK.read_bytes())
    expected = frozen['inputs'][archive.QUOTES.relative_to(ROOT).as_posix()]
    if archive.digest(archive.QUOTES) != expected:
        raise ValueError('Frozen TMGM source archive changed')
    return archive.read_zip(archive.QUOTES)


def load_bid_evidence(path):
    payload = archive.read_zip(path)
    source = frozen_feed()
    if (payload['symbol'],payload['server'],payload['time_basis']) != ('XAUUSD',source['server'],'utc_ms'):
        raise ValueError('Bid evidence is not on the expected TMGM XAUUSD clock and feed')
    observed_at = datetime.fromisoformat(payload['as_of'])
    if observed_at.utcoffset() is None or observed_at>utc_now():
        raise ValueError('Invalid evidence observation time')
    bars = [Bar(datetime.fromisoformat(t),o,h,l,c,0) for t,o,h,l,c in payload['closed_m5']]
    if any(bar.time+M5>observed_at for bar in bars):
        raise ValueError('Bid evidence contains an unclosed M5')
    if any(stamp>utc_ms(observed_at) for stamp,_ in payload['bid_utc_ms']):
        raise ValueError('Bid evidence contains a quote after observation time')
    return BidEvidence(bars,payload['bid_utc_ms']), observed_at


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--receipts-only', action='store_true',
                      help='Validate registrations in SQLite and report maturity without accessing MT5')
    mode.add_argument('--bid-evidence', type=Path,
                      help='Validate frozen outcomes from a saved gzip JSON of UTC Bid and independent M5 evidence')
    args = parser.parse_args()
    observed_at = utc_now()
    records = read_registrations()
    if args.receipts_only:
        pending = [row['end'] for row in records if datetime.fromisoformat(row['end']) > observed_at]
        report = dict(model_sha256=archive.digest(LOCK), as_of=observed_at.isoformat(),
                      registrations=len(records), mature=len(records)-len(pending),
                      next_maturity=min(pending, default=None),
                      evidence=[{key:row[key] for key in ('cutoff','chart_received','recorded_at','end','evidence')}
                                for row in records])
        (FOLDER/'receipt_validation.json').write_text(json.dumps(report, indent=2)+'\n',encoding='utf-8')
        print('Registrations:',len(records),'mature:',report['mature'],'next maturity:',report['next_maturity'])
        return
    if args.bid_evidence:
        evidence, observed_at = load_bid_evidence(args.bid_evidence)
        records = [row for row in records if datetime.fromisoformat(row['recorded_at'])<=observed_at]
        report = dict(model_sha256=archive.digest(LOCK), evidence_sha256=archive.digest(args.bid_evidence),
                      as_of=observed_at.isoformat(), basis='recorded_bid_reconciled_to_closed_m5',
                      **bid_results(records,evidence,observed_at))
        (FOLDER/'latest_bid_settlement.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        print('Registrations:',len(records),'coverage:',dict(report['coverage']))
        return
    bars = []
    if records:
        start = min(datetime.fromisoformat(s['cutoff']) for s in records)
        end = min(observed_at, max(datetime.fromisoformat(s['end']) for s in records))
        bars = read_market(start, end, observed_at)
    report = dict(model_sha256=archive.digest(LOCK), as_of=observed_at.isoformat(), closed_m5=len(bars),
                  **results(records, bars, observed_at))
    if records:
        archive.write_zip(FOLDER/'latest_market.json.gz', [[b.time.isoformat(),b.open,b.high,b.low,b.close] for b in bars])
        report['market_sha256'] = archive.digest(FOLDER/'latest_market.json.gz')
    (FOLDER/'latest_settlement.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print('Registrations:', len(records), 'closed M5:', len(bars), 'coverage:', dict(report['coverage']))


if __name__ == '__main__':
    main()
