"""Walk-forward comparison of strict liquidity sweep rankings on frozen MT5 candidates."""
from collections import Counter
from datetime import datetime, timedelta
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts import replay_pool_and_dol as study
from scripts.audit_ict_target_ranking import fit_prior_weeks

ARCHIVE = study.RESEARCH/'ipda_four_cycle_validation_20261122'
LIMITS = (10,20,30,50)
FIRST_HOLDOUT = '2026-10-01'


def features(row, distance):
    p = row['components']
    width = (row['hi']-row['lo'])/row['hourly_range']
    return [np.log1p(distance),np.log1p(width),row['side'],
            *(p[key] for key in ('structure','anchors','frames','dol','path','context')),
            p.get('priority_uplift',0)]


def build_groups(pairs, horizon, scope):
    for sample, outcome in pairs:
        if sample['at']!=outcome['at']:
            raise ValueError('Candidate and result times differ')
        at = datetime.fromisoformat(sample['at'])
        local = at.astimezone(study.NY).date()
        end = datetime.fromisoformat(outcome[horizon]['end'])
        targets = sample['pools'][scope]
        status = outcome[horizon]['status']
        group = dict(at=at,end=end,day=str(local),week=local-timedelta(days=local.weekday()),
                     status=status, targets=targets, price=sample['price'])
        if status=='complete':
            rows = outcome[horizon][scope]
            if len(rows)!=len(targets):
                raise ValueError('Candidate count differs')
            group['events'] = rows
            group['distance'] = [abs((t['hi'] if t['side']>0 else t['lo'])-sample['price'])/t['hourly_range']
                                 for t in targets]
            group['x'] = [features(t,d) for t,d in zip(targets,group['distance'],strict=True)]
            group['y'] = [event['sweep'] is not None for event in rows]
        yield group


def record(stats, order, events):
    for rank in range(1,11):
        if rank>len(order):
            stats[f'r{rank}_unavailable'] += 1
            continue
        event = events[order[rank-1]]
        stats[f'r{rank}_n'] += 1
        for key in ('touch','sweep','reclaim','gap_over'):
            stats[f'r{rank}_{key}'] += bool(event[key])
    for k in LIMITS:
        selected = [events[i] for i in order[:k]]
        stats[f'top{k}_full'] += len(selected)==k
        stats[f'top{k}_offers'] += len(selected)
        for key in ('touch','sweep','reclaim','gap_over'):
            stats[f'top{k}_{key}'] += sum(bool(event[key]) for event in selected)
        stats[f'top{k}_any_sweep'] += any(event['sweep'] for event in selected)


def evaluate(groups):
    windows = Counter()
    comparisons = {name:Counter() for name in ('current','nearest_far_edge','learned')}
    folds = []
    examples = {}
    weeks = sorted({g['week'] for g in groups if g['day']>=FIRST_HOLDOUT})
    for week in weeks:
        test = [g for g in groups if g['week']==week and g['day']>=FIRST_HOLDOUT]
        train = [g for g in groups if g['end']<test[0]['at'] and g['week']<week
                 and g['status']=='complete' and g['targets']]
        mean, scale, coef = fit_prior_weeks(train)
        fold = {name:Counter() for name in comparisons}
        counts = Counter()
        for g in test:
            counts[g['status']] += 1
            if g['status']!='complete':
                continue
            count = len(g['targets'])
            counts['available_candidates'] += count
            hits = sum(g['y'])
            counts['all_candidate_sweeps'] += hits
            counts['top10_oracle_sweeps'] += min(10,hits)
            if count:
                logits = coef[0]+((np.array(g['x'])-mean)/scale)@coef[1:]
            else:
                logits = []
            orders = dict(current=list(range(count)),
                          nearest_far_edge=sorted(range(count),key=g['distance'].__getitem__),
                          learned=sorted(range(count),key=lambda i:(-logits[i],g['distance'][i],i)))
            for name, order in orders.items():
                record(fold[name],order,g['events'])
            if count:
                before,after = (orders[k][0] for k in ('current','learned'))
                obs = g['events']
                if bool(obs[before]['sweep'])!=bool(obs[after]['sweep']):
                    status = 'recovered' if obs[after]['sweep'] else 'lost'
                    examples.setdefault(status,dict(at=g['at'].isoformat(),end=g['end'].isoformat(),
                        price=g['price'],before=g['targets'][before],after=g['targets'][after],
                        before_result=obs[before],after_result=obs[after]))
        windows.update(counts)
        for name in comparisons:
            comparisons[name].update(fold[name])
        folds.append(dict(week=str(week),train=len(train),first_evaluation=test[0]['at'].isoformat(),
                          latest_training_label=max(g['end'] for g in train).isoformat(),
                          windows=counts,comparisons=fold))
    return dict(windows=windows,comparisons=comparisons,folds=folds,examples=examples)


def plot_examples(results):
    from scripts.check_pool_priority import read_market
    from scripts.plot_joint_round_examples import render, plt, font_manager

    plt.rcParams['font.family'] = font_manager.FontProperties(fname='C:/Windows/Fonts/msyh.ttc').get_name()
    plt.rcParams['axes.unicode_minus'] = False
    data = read_market()
    folder = study.RESEARCH/'ict_liquidity_rank_examples'
    folder.mkdir(exist_ok=True)
    specs = [
        ('short/IRL','recovered','IRL · 学习排序补回清扫','irl_recovered'),
        ('short/IRL','lost','IRL · 原榜首清扫，学习排序漏选','irl_lost'),
        ('week/ERL','recovered','ERL · 周内清扫候选提前','erl_week'),
    ]
    for scope,key,title,filename in specs:
        case = results[scope]['examples'][key]
        hit,miss = ('after','before') if key=='recovered' else ('before','after')
        snapshot = dict(at=case['at'],price=case['price'],pools=[case[hit]],picks={'pools':{'nearest':0}})
        outcome = dict(end=case['end'],pools=[case[hit+'_result']])
        caption = '棕色线为学习榜首，窗口内未被清扫' if key=='lost' else '棕色线为现版榜首，窗口内未被清扫'
        render(folder/f'{filename}.png',2,title,('pools',),snapshot,outcome,data,
               missed=[('pools',case[miss])],comparison_caption=caption)


def main():
    lock = json.loads((ARCHIVE/'round19_liquidity_50_lock.json').read_bytes())
    baseline = json.loads((ARCHIVE/'round19_liquidity_baseline.json').read_bytes())
    candidates = ARCHIVE/'round19_liquidity_50_candidates.json.gz'
    outcomes = ARCHIVE/'round19_liquidity_50_outcomes.json.gz'
    inputs = {p.name:study.digest(p) for p in (candidates,outcomes)}
    if inputs!={candidates.name:lock['candidates'],outcomes.name:baseline['outcomes_sha256']}:
        raise ValueError('Frozen liquidity research inputs changed')
    if baseline['freeze_sha256']!=lock['candidates']:
        raise ValueError('Outcomes reference another candidate freeze')
    pairs = list(zip(study.read_zip(candidates),study.read_zip(outcomes),strict=True))
    results = {f'{horizon}/{scope}':evaluate(list(build_groups(pairs,horizon,scope)))
               for horizon in ('short','week') for scope in ('IRL','ERL')}
    data = dict(inputs=inputs,script_sha256=study.digest(Path(__file__)),
                fit_code_sha256=study.digest(ROOT/'scripts/audit_ict_target_ranking.py'),
                first_holdout=FIRST_HOLDOUT,protocol='Fixed L2 logistic model; training labels mature before '
                'each evaluation week; positive means strict far-edge sweep within the applicable horizon.',
                frozen_candidates_per_list=50,results=results)
    out = study.RESEARCH/'ict_liquidity_rank_walkforward.json'
    out.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    if '--plot' in sys.argv[1:]:
        plot_examples(results)
    for name, row in results.items():
        print(name,row['windows'])
        for model, c in row['comparisons'].items():
            print(model, c['top10_sweep'],c['top10_offers'],
                  [round(100*c[f'r{i}_sweep']/max(1,c[f'r{i}_n']),1) for i in range(1,11)])


if __name__=='__main__':
    main()
