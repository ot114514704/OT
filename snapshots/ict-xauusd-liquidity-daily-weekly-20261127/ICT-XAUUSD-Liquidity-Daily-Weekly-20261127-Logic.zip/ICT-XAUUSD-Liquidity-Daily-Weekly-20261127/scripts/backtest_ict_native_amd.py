"""Causal TMGM AMD replay of the native local scanner, with cost sensitivity."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter, defaultdict
from dataclasses import asdict, replace
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from hashlib import sha256
import json
from pathlib import Path
from statistics import mean
import subprocess

import numpy as np

from brooks_ai.risk import size_volume
from brooks_ai.types import Bar
from ict_ai.backtest import LimitStudyOrder, simulate_limit
from ict_ai.portfolio import replay_portfolio
from ict_ai.timebase import NY
from scripts import replay_ict_tmgm_profile_one as feed
from scripts.prepare_ict_week import aggregate_bars
from scripts.serve_ict_live import atomic_json


ROOT = feed.ROOT
ARCH = feed.check_pool_priority.ARCH
OUT = feed.archive.RESEARCH/'ict_native_amd_backtest_20261123.json'
NATIVE = ROOT/'mt5/ICT_AMD.mqh'
HARNESS = ROOT/'scripts/replay_native_amd.cjs'
M5 = timedelta(minutes=5)
UTC = timezone.utc
FEES = {'spread_only':(0.,0.,1.),'base':(7.,.05,1.),'stress':(14.,.15,2.)}


def native_time(utc):
    wall = utc.astimezone(NY).replace(tzinfo=UTC) + timedelta(hours=7)
    return int(wall.timestamp())


def utc_time(raw):
    return (datetime.fromtimestamp(int(raw),UTC)-timedelta(hours=7)).replace(tzinfo=NY).astimezone(UTC)


def read_market(start,end):
    manifest = json.loads((ARCH/'manifest.json').read_bytes())
    name = 'XAUUSDM5.npz'
    capture = ARCH/name
    if feed.archive.digest(capture)!=manifest[name]:
        raise ValueError('Frozen TMGM M5 digest mismatch')
    _,spec,source = feed.reference(start,end)
    with np.load(capture,allow_pickle=False) as file:
        rows = [Bar(stamp,*(float(row[k]) for k in ('open','high','low','close')),float(row['spread'])*spec.point)
                for row in file['rates'] if start<= (stamp:=utc_time(row['time'])).astimezone(NY).date()<=end]
    if any(a.time>=b.time for a,b in zip(rows,rows[1:])):
        raise ValueError('M5 history must be chronological')
    return rows,spec,source['server']


def scan(m5,minutes,point):
    last = m5[-1].time+M5
    period = timedelta(minutes=minutes)
    bars = aggregate_bars(m5,5,minutes,last)
    payload = dict(r=[dict(time=native_time(b.time),open=b.open,high=b.high,low=b.low,close=b.close) for b in bars],
                   now=native_time(last),seconds=int(period.total_seconds()),point=point,
                   splitTimes=[native_time(b.time+period) for b in bars[100::93]])
    def replay():
        result = subprocess.run(['node',str(HARNESS),str(NATIVE)],input=json.dumps(payload),encoding='utf-8',
                                stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
        if result.returncode:
            raise RuntimeError(result.stderr)
        return json.loads(result.stdout)

    all_events = replay()[-1]['events']
    payload['splitTimes'] = sorted(set(payload['splitTimes']) | {e['d_confirm'] for e in all_events})
    outputs = replay()
    all_events = outputs[-1]['events']
    for prefix in outputs[:-1]:
        if prefix['events']!=[e for e in all_events if e['d_confirm']<=prefix['cutoff']]:
            raise AssertionError(f'Later bars changed signals at {utc_time(prefix["cutoff"])}')
    for event in all_events:
        event['timeframe'] = f'M{minutes}' if minutes<60 else 'H1'
        event['id'] = f"{event['timeframe']}/{event['size']}/{event['d_confirm']}/{event['a_known']}"
        for key in ('a_start','a_known','m_known','d_confirm'):
            if event[key] is not None:
                event[key] = utc_time(event[key]).isoformat()
    return all_events,outputs[-1]['phaseCounts'],len(outputs)-1


def order_for(signal,spec):
    at = datetime.fromisoformat(signal['d_confirm'])
    local = at.astimezone(NY)
    if local.weekday()>4 or local.time()>=time(16,50):
        return None
    side = signal['direction']
    rounding = ROUND_FLOOR if side==1 else ROUND_CEILING
    tick = Decimal(str(spec.tick_size))

    def grid(price):
        return (Decimal(str(price))/tick).to_integral_value(rounding)*tick

    entry = grid(signal['edge'])
    protected = signal['m_extreme'] if signal['m_extreme'] is not None else signal['a_low' if side==1 else 'a_high']
    stop = grid(protected)-side*tick
    target = entry+2*(entry-stop)
    if side*(entry-stop)<=0:
        raise ValueError(f'Invalid protective boundary: {signal["id"]}')
    expires = min(at+timedelta(minutes=90),datetime.combine(local.date(),time(16,50),NY))
    return LimitStudyOrder(signal['id'],side,at,expires,float(entry),float(stop),float(target),spec.volume_min)


def settled_summary(records):
    booked = [row for row in records if row['status']=='closed']
    pnls = [r['pnl_net'] for r in booked]
    wins, losses = [v for v in pnls if v>0],[v for v in pnls if v<0]
    return dict(outcomes=dict(Counter(row['status'] for row in records)),closed=len(booked),wins=len(wins),losses=len(losses),
                win_rate=len(wins)/len(booked) if booked else None,net_pnl=sum(pnls),
                mean_r=mean(r['net_r'] for r in booked) if booked else None,
                profit_factor=sum(wins)/-sum(losses) if losses else None,
                ambiguous_closed=sum(r.get('ambiguous',False) for r in booked),
                exits=dict(Counter(r['reason'] for r in booked)))


def independent(orders,quotes,spec,equity,fraction,spread_multiple):
    times = [b.time for b in quotes]
    rows = []
    checks = 0
    for order in orders:
        budget = equity*fraction
        loss = (abs(order.entry-order.stop)+2*spec.slippage)*spec.contract_size+spec.commission_round_turn
        volume = size_volume(budget,loss,spec)
        if not volume:
            rows.append(dict(order_id=order.id,status='minimum_size_exceeds_budget',minimum_risk=loss*spec.volume_min))
            continue
        local = order.available_at.astimezone(NY)
        finish = min(quotes[-1].time+M5,datetime.combine(local.date(),time(16,55),NY))
        history = quotes[bisect_left(times,order.available_at):bisect_left(times,finish)]
        sized = replace(order,volume=volume)
        outcome = simulate_limit(sized,history,spec,finish,spread_multiplier=spread_multiple)
        witness = outcome.get('entry_known_at') or outcome.get('outcome_available_at')
        if witness:
            bound = datetime.fromisoformat(witness)
            prefix = [b for b in history if b.time+M5<=bound]
            if simulate_limit(sized,prefix,spec,bound,spread_multiplier=spread_multiple)!=simulate_limit(sized,history,spec,bound,spread_multiplier=spread_multiple):
                raise AssertionError(f'Future quotes changed an outcome: {order.id}')
            checks+=1
        pnl = outcome['pnl_net']
        rows.append(dict(**outcome,volume=volume,estimated_stop_risk=volume*loss,
                         net_r=pnl/(volume*loss) if pnl is not None else None))
    return rows,checks


def run(start,end):
    bars,instrument,server = read_market(start,end)
    config_path = ROOT/'config/strategy.json'
    config = json.loads(config_path.read_bytes())
    risk = {k:config[k] for k in ('risk_fraction','daily_loss_limit','max_drawdown','max_consecutive_losses')}
    events = []
    detection = {}
    for minutes in (15,60):
        confirmed,phases,checks = scan(bars,minutes,instrument.point)
        events.extend(confirmed)
        detection[confirmed[0]['timeframe'] if confirmed else f'{minutes}min']=dict(stage_counts=phases,signal_prefix_checks=checks)
    signals = {event['id']:event for event in events}
    if len(signals)!=len(events):
        raise ValueError('Duplicate signal ID')
    templates = [order for signal in events if (order:=order_for(signal,instrument)) is not None]
    scenarios = {}
    for name,(commission,slippage,spread) in FEES.items():
        spec = replace(instrument,commission_round_turn=commission,slippage=slippage)
        rows,checks = independent(templates,bars,spec,config['initial_equity'],risk['risk_fraction'],spread)
        groups = defaultdict(list)
        for row in rows:
            signal = signals[row['order_id']]
            groups[(signal['timeframe'],signal['size'],signal['route'])].append(row)
            groups[(signal['timeframe'],'all',signal['route'])].append(row)
        accounts = {}
        for frame in ('M15','H1'):
            for route in (None,'AMD','AD_no_M'):
                scoped = [order for order in templates if signals[order.id]['timeframe']==frame
                          and (route is None or signals[order.id]['route']==route)]
                account = replay_portfolio(scoped,bars,spec,bars[-1].time+M5,config['initial_equity'],risk,spread_multiplier=spread)
                key = frame if route is None else f'{frame}/{route}'
                accounts[key] = dict(account, decision_counts=dict(Counter(d['status'] for d in account['decisions'])))
        scenarios[name]=dict(commission_round_turn_per_lot=commission,slippage_price=slippage,spread_multiple=spread,
                             grouped={ '/'.join(key):settled_summary(group) for key,group in sorted(groups.items())},
                             signal_fill_prefix_checks=checks,independent_orders=rows,continuous_accounts=accounts)
    paths = (Path(__file__),NATIVE,HARNESS,ARCH/'XAUUSDM5.npz',ARCH/'clock_validation.json',feed.CONTRACT,
             config_path,ROOT/'ict_ai/backtest.py',ROOT/'ict_ai/portfolio.py',
             ROOT/'research/ict_price_videos/amd/integration.json')
    return dict(symbol=instrument.symbol,server=server,quote_start=bars[0].time.isoformat(),quote_end=(bars[-1].time+M5).isoformat(),
                m5_bars=len(bars),native_scanner='scanLiveAmdRanges with confirmed D marker and native box/triangle recognition',
                scope='Native local M15/H1 detection; excludes replay-only reference boxes and external IPDA seed feed',
                protocol='Direction at D confirmation; retest limit at frozen A edge, max 90 minutes. Stop 1 tick beyond M extreme or opposite A edge for direct D. Target 2R. NY 16:50 flatten.',
                assumptions=['Recorded TMGM M5 spreads applied as constant per bar; touches approximate fills.',
                             'Fee series and 2R used for sensitivity. They do not establish observed fill quality or actual historical account costs.',
                             'Independent trials start from the same equity and can overlap. Only account results apply sequence-level protections.',
                             'Position eligibility does not use hindsight-adjusted D box ends, example timestamps, or future DOL. No ICT HTF/news qualification.'],
                instrument=asdict(instrument),risk_limits=risk,detection=detection,confirmed=events,
                templates=[asdict(o) for o in templates],scenarios=scenarios,
                inputs={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in paths},orders_sent=0)


if __name__=='__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--start',type=date.fromisoformat,default=date(2026,6,1))
    parser.add_argument('--end',type=date.fromisoformat,default=date(2026,11,20))
    parser.add_argument('--out',type=Path,default=OUT)
    args = parser.parse_args()
    report = run(args.start,args.end)
    atomic_json(args.out,json.loads(json.dumps(report,default=lambda x:x.isoformat(),allow_nan=False)))
    print('Native signals:',len(report['confirmed']),report['detection'])
    for name,result in report['scenarios'].items():
        print(name,{k:(g['closed'],g['wins'],g['mean_r']) for k,g in result['grouped'].items() if '/all/' in k})
