"""Replay HD-linked daily/weekly classifiers on immutable M5 history.

Tests information cutoffs and report reproducibility, not prediction accuracy.
"""
import argparse,hashlib,json,sys
from dataclasses import replace
from datetime import date,datetime,time,timedelta,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.audit_ict_price_video_replay import load_snapshot
from scripts.prepare_ict_week import aggregate_bars
from brooks_ai.types import utc_time
from ict_ai.timebase import NY,epoch_to_utc
from ict_ai.profile_lifecycle import daily_profile_lifecycle,weekly_profile_lifecycle
from ict_ai.weekly_path import weekly_path


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--manifest',type=Path,required=True)
    ap.add_argument('--offset-hours',type=float,required=True)
    ap.add_argument('--from-ny',type=date.fromisoformat,required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();meta,dataset,raw=load_snapshot(args.manifest)
    if meta.get('symbol')!='XAUUSD':raise ValueError('XAUUSD history required')
    end=utc_time(meta['finished_at_utc']);offset=timedelta(hours=args.offset_hours)
    floor=datetime.combine(args.from_ny,time(0),NY).astimezone(timezone.utc)
    m5=[replace(b,time=epoch_to_utc(b.time,offset)) for b in raw]
    m5=[b for b in m5 if b.time>=floor and b.time+timedelta(minutes=5)<=end]
    if not m5:raise ValueError('No closed history in requested interval')
    p=timedelta(minutes=15);m15=aggregate_bars(m5,5,15,end)
    checks={'daily_prefixes':0,'daily_m5_ohlc_checks':0,'weekly_m5_geometry_prefixes':0,'weekly_m15_hypothesis_prefixes':0}
    daily=[];weekly=[];week_cuts={}
    day=args.from_ny
    while day<=end.astimezone(NY).date():
        if day.weekday()<5:
            start=datetime.combine(day,time(0),NY).astimezone(timezone.utc)
            finish=datetime.combine(day,time(17),NY).astimezone(timezone.utc) if day.weekday()==4 else datetime.combine(day+timedelta(days=1),time(0),NY).astimezone(timezone.utc)
            cuts={start+timedelta(hours=h) for h in (0,2,5,7,10,12,16)}|{finish-p,finish,finish+timedelta(minutes=5),end}
            cuts=sorted(at for at in cuts if start<=at<=min(finish+timedelta(minutes=5),end) and m5[0].time<at)
            for at in cuts:
                prefix=[b for b in m15 if b.time+p<=at]
                prefix5=[b for b in m5 if b.time+timedelta(minutes=5)<=at]
                got=daily_profile_lifecycle(m15,day,at,include_reconstruction=False,reference_m5=m5)
                assert got==daily_profile_lifecycle(prefix,day,at,include_reconstruction=False,reference_m5=prefix5),(day,at,'future daily prices changed the result')
                basis=got.get('daily_price_basis')
                if basis and basis['last_close_at']:
                    last=utc_time(basis['last_close_at']);known=[b for b in prefix5 if start<=b.time and b.time+timedelta(minutes=5)<=last]
                    expected=(known[0].open if known[0].time==start else None,max(b.high for b in known),min(b.low for b in known),known[-1].close)
                    assert tuple(basis[k] for k in ('open','high','low','close'))==expected,(day,at,'daily OHLC differs from observed M5')
                    checks['daily_m5_ohlc_checks']+=1
                checks['daily_prefixes']+=1
                monday=day-timedelta(days=day.weekday());week_cuts.setdefault(monday,set()).add(at)
            got=daily_profile_lifecycle(m15,day,end,include_reconstruction=False,reference_m5=m5)
            daily.append({k:got[k] for k in ('mode','as_of','profile_label','profile_status','profile_reason','actual_paths','daily_price_basis','coverage_complete_under_study_calendar') if k in got}|{'date':day.isoformat()})
        day+=timedelta(days=1)
    for monday,cuts in sorted(week_cuts.items()):
        dates=[monday+timedelta(days=i) for i in range(5)]
        for at in sorted(cuts):
            prefix5=[b for b in m5 if b.time+timedelta(minutes=5)<=at]
            got=weekly_path(m5,dates,at)
            assert got==weekly_path(prefix5,dates,at),(monday,at,'future M5 changed weekly geometry or final category')
            checks['weekly_m5_geometry_prefixes']+=1
            prefix15=[b for b in m15 if b.time+p<=at]
            life=weekly_profile_lifecycle(m15,dates,at,got)
            assert life==weekly_profile_lifecycle(prefix15,dates,at,got),(monday,at,'future M15 changed weekly hypothesis')
            checks['weekly_m15_hypothesis_prefixes']+=1
        review=weekly_path(m5,dates,end)
        weekly.append({'week_start':monday.isoformat(),'profile_label':review['profile_label'],
                       'candidates':review['candidates'],'coverage':[{k:d[k] for k in ('date','ended','coverage_complete')} for d in review['daily']]})
    definitions=['ict_ai/profile_lifecycle.py','ict_ai/weekly_path.py','ict_ai/profile_sources.py','ict_ai/amd.py',
                 'ict_ai/timebase.py','ict_ai/range_liquidity.py','ict_ai/liquidity.py',
                 'ict_ai/features.py','brooks_ai/types.py','scripts/prepare_ict_week.py',
                 'scripts/replay_ict_profile_shapes.py','research/ict_time_videos/profile-visual-review.json',
                 'research/ict_daily_profiles/rules.json','research/ict_weekly_profiles/rules.json',
                 'research/ict_time_videos/time2_daily/integration.json',
                 'research/ict_time_videos/time3_weekly/integration.json']
    report={'status':'passed','scope':'fixed checkpoint prefix isolation, M5 weekly geometry and closed price-shape classification',
            'source_manifest':str(args.manifest.resolve()),'source_manifest_sha256':hashlib.sha256(args.manifest.read_bytes()).hexdigest(),
            'data_sha256':dataset['data_sha256'],'as_of':end.isoformat(),'source_clock_offset_hours':args.offset_hours,
            'history_from_ny':args.from_ny.isoformat(),'closed_m5':len(m5),'closed_m15':len(m15),'checks':checks,
            'daily':daily,'weekly':weekly,'definition_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in definitions},
            'historical_clock_verified':False,'historical_session_calendar_verified':False,
            'prediction_accuracy_measured':False,'prior_bias_pda_dol_verified':False,'model_trained':False,'execution_allowed':False,'orders_sent':0}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'report':str(args.out),'checks':checks,'daily_records':len(daily),'weekly_records':len(weekly),'orders_sent':0}))


if __name__=='__main__':main()
