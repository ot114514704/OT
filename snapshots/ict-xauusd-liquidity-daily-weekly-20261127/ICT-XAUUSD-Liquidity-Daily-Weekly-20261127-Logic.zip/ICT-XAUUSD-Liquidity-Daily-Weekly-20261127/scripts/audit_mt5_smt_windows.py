"""Recount native H1 SMT candidates at 1, 3 and 6 hours after confirmation.

Run with the panel's Python runtime. --as-of accepts an ISO timestamp with an
explicit UTC offset. The two input digests identify broker history revisions.
"""
import argparse
import hashlib
import json
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import MetaTrader5 as mt5

from ict_ai.smt import smt_divergences, smt_observation
from scripts.export_mt5_profiles import H1, START, history, midnight
from scripts.serve_ict_live import checked_account


def series_digest(bars):
    values = [(b.time.isoformat(), b.open, b.high, b.low, b.close) for b in bars]
    return hashlib.sha256(json.dumps(values, separators=(",", ":")).encode()).hexdigest()


def report(gold, silver, cutoff):
    start_ms = int(midnight(START).timestamp() * 1000)
    events = [e for e in smt_divergences(gold, silver, H1, cutoff)
              if e["primary"][0]["time_ms"] >= start_ms]
    windows = {}
    for hours in (1, 3, 6):
        counts = Counter(caught=0, observed_without_catch=0, gap=0, pending=0)
        for event in events:
            end = datetime.fromisoformat(event["available_at"]) + hours * H1
            observation = smt_observation(event, gold, silver, H1, min(end, cutoff))
            status = observation["status"]
            if status == "peer_caught_up":
                counts["caught"] += 1
            elif status == "followup_gap":
                counts["gap"] += 1
            elif end > cutoff:
                counts["pending"] += 1
            else:
                counts["observed_without_catch"] += 1
        windows[hours] = dict(counts)
    return {"from_ny": START.isoformat(), "as_of": cutoff.isoformat(),
            "pair": ["XAUUSD", "XAGUSD"], "period": "H1",
            "source_sha256": {"XAUUSD": series_digest(gold), "XAGUSD": series_digest(silver)},
            "candidates": len(events), "counts_by_hours_after_confirmation": windows}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--as-of", type=datetime.fromisoformat)
    args = parser.parse_args()
    now = datetime.now(timezone.utc)
    cutoff = args.as_of or now
    if cutoff.utcoffset() is None or not midnight(START) <= cutoff <= now:
        parser.error("Use an offset-aware cutoff between the September start and the present.")
    policy = json.loads((ROOT / "research/live_clock_20261116.json").read_text(encoding="utf-8"))
    if not mt5.initialize():
        raise RuntimeError(f"MT5 unavailable: {mt5.last_error()}")
    try:
        account = checked_account(mt5)
        gold = history("XAUUSD", mt5.TIMEFRAME_H1, policy, cutoff)
        silver = history("XAGUSD", mt5.TIMEFRAME_H1, policy, cutoff)
        checked_account(mt5, (account.login, account.server))
    finally:
        mt5.shutdown()
    result = report(gold, silver, cutoff)
    result["clock_policy"] = policy
    print(json.dumps(result, indent=2, ensure_ascii=False))
