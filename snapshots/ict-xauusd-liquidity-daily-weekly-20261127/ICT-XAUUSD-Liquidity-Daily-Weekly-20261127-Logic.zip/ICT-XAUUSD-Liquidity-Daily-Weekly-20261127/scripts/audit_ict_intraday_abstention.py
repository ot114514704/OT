"""Audit score calibration and abstention at each live daily-profile cutoff."""

from datetime import datetime
from math import fsum
from pathlib import Path
import json

from scripts import audit_ict_daily_abstention as base
from scripts import audit_ict_intraday_learning as study


INTRADAY = base.daily.RESEARCH / 'ict_intraday_learning_20261123.json'
OUT = base.daily.RESEARCH / 'ict_intraday_abstention_20261126.json'
CUTOFFS = ('07:30', '08:30', '09:30', '10:00')
BIN_EDGES = (0.0, 0.2, 0.4, 0.6, 0.8, 1.0)


def reliability(forecasts, label):
    rows = [r for r in forecasts if r[label] is not None]
    bins = []
    for low, high in zip(BIN_EDGES, BIN_EDGES[1:]):
        sample = [r for r in rows if low <= r['confidence'] < high or high == 1 and r['confidence'] == 1]
        n = len(sample)
        bins.append(dict(low=low, high=high, windows=n,
                         predicted=fsum(r['confidence'] for r in sample) / n if n else None,
                         observed=sum(r[label] for r in sample) / n if n else None))
    n = len(rows)
    if sum(item['windows'] for item in bins) != n:
        raise ValueError('Some probabilities fell outside the calibration bins')
    return dict(windows=n, bins=bins, brier=fsum((r['confidence'] - r[label]) ** 2 for r in rows) / n if n else None,
                empirical=fsum(r[label] for r in rows) / n if n else None,
                predicted=fsum(r['confidence'] for r in rows) / n if n else None)


def model_rows(source, name):
    output = []
    score_key = 'learned' if name == '10:00' else 'pooled_learned'
    trained_key = 'trained_through' if name == '10:00' else 'pooled_trained_through'
    for row in source['observations']:
        if score_key not in row:
            continue
        trained, cutoff, mature = (datetime.fromisoformat(row[k]) for k in (trained_key, 'available_at', 'label_available_at'))
        if not trained < cutoff < mature:
            raise ValueError(f'Bad forecast maturity at {name} {row["date"]}')
        output.append(dict(row, learned=row[score_key]))
    return output


def paired_rule_results(results):
    """Use the same settled, post-warmup NY dates at every cutoff."""
    by_cutoff = {name: {row['date']: row for row in checkpoint['forecasts']
                        if row['calibrated'] and row['top_correct'] is not None}
                 for name, checkpoint in results.items()}
    dates = sorted(set.intersection(*(set(rows) for rows in by_cutoff.values())))
    policies = {}
    for name, rows in by_cutoff.items():
        sample = [rows[day] for day in dates]
        policies[name] = dict(results=base.grade(sample), reliability_rule=reliability(sample, 'top_correct'))
    return dict(dates=dates, cutoffs=policies)


def main():
    published, old_10 = (json.loads(path.read_bytes()) for path in (INTRADAY, base.OUT))
    paths = (INTRADAY, base.BASELINE, base.OUT, *base.daily.MANUAL, Path(__file__))
    hashes = {path.name: base.daily.digest(path) for path in paths}
    if any(published['inputs'][path.name] != hashes[path.name] for path in (base.BASELINE, *base.daily.MANUAL)):
        raise ValueError('The archived intraday scores reference different market or reviewed labels')
    manual_days = set(study.read_manual())
    results = {}
    for name in CUTOFFS:
        archived = published['checkpoints'][name]
        rows = model_rows(archived, name)
        policies, forecasts = base.run(dict(observations=rows), manual_days)
        if name == '10:00' and (policies != old_10['results'] or forecasts != old_10['forecasts']):
            raise ValueError('The previously verified 10:00 result changed')
        results[name] = dict(results=policies, all_mature_days=archived['coverage']['mature_dates'],
                            reliability_rule=reliability(forecasts, 'top_correct'),
                            reliability_manual=reliability(forecasts, 'manual_correct'),
                            forecasts=forecasts, frozen_source='daily' if name == '10:00' else 'pooled_intraday')
    paired = paired_rule_results(results)
    base.atomic_json(OUT, dict(results=results, paired_rule=paired, hashes=hashes, orders_sent=0, scope=(
        'Top signed candidate per NY day and cutoff. Use already generated walk-forward scores. '
        'Fit the abstention threshold using only previous, fully matured NY weeks with manual dates excluded. '
        'The primary label is the completed same-lifecycle price path, not trade results or independent labels.')))
    print(f'{OUT.name}: {len(paired["dates"])} shared settled dates after warmup')
    for name, checkpoint in paired['cutoffs'].items():
        counts = ' | '.join(f'{policy}: {row["correct"]}/{row["offered"]}' for policy, row in checkpoint['results'].items())
        print(f'{name} NY | {counts}')


if __name__ == '__main__':
    main()
