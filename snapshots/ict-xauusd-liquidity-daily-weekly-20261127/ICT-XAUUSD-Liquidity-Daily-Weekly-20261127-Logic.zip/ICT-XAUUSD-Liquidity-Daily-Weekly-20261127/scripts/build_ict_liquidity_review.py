"""Build an offline, read-only XAUUSD replay from the archived MT5 evidence."""

from argparse import ArgumentParser
from bisect import bisect_left
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path

from ict_ai.dol_tick_evidence import utc_ms
from scripts import audit_ict_early_liquidity_response as response
from scripts import audit_ict_micro_liquidity_recent_all_m5 as recent


stream, fixed = recent.stream, recent.fixed
SCOPES = fixed.board.SCOPES
ROOT = Path(__file__).resolve().parent


def review_case(data, ready, bucket_rows, settlement):
    cutoff = datetime.fromisoformat(data['cutoff'])
    if not cutoff <= ready:
        raise ValueError(f'Registration precedes the cutoff: {cutoff}')
    marks = {}
    tape = [quote for bucket in bucket_rows for quote in bucket['bid_offsets']]
    for mode in ('baseline', 'early'):
        marks[mode] = {}
        for scope in SCOPES:
            placed = data[mode][scope]
            results = settlement['outcomes'].get(mode, {}).get(scope, []) if settlement else []
            candidates = []
            for index, pool in enumerate(placed):
                row = {key: pool[key] for key in ('side', 'lo', 'hi', 'rank', 'score')}
                row['name'] = pool.get('name', '')
                if results:
                    outcome = results[index]
                    stamp = outcome['bid_time_ms']
                    row.update(result=outcome['status'], crossed_ms=None if stamp is None else stamp - utc_ms(cutoff))
                candidates.append(row)
            marks[mode][scope] = candidates
    return dict(cutoff=data['cutoff'], ready_ms=utc_ms(ready) - utc_ms(cutoff), candidates=marks,
                tape=tape, state=settlement['state'] if settlement else 'pending')


def historical_cases(report):
    inputs = (recent.INPUT, recent.BID, stream.POLICY, Path(recent.__file__))
    if any(recent.digest(path) != report['inputs'][path.name] for path in inputs):
        raise ValueError('The study and its archived inputs disagree')
    quotes = fixed.board.joint.read_zip(recent.BID)['slots']
    study = fixed.board.joint.read_zip(recent.INPUT)
    rows = study['m5']
    stamps = [row[0] for row in rows]
    entries = [(c['cutoff'], study['boards'][c['cutoff']]) for c in report['cases']]
    history = []
    with ProcessPoolExecutor(max_workers=3, initializer=recent.initialize) as executor:
        replayed = executor.map(recent.identify, entries, chunksize=4)
        for case, (stamp, _, data) in zip(report['cases'], replayed, strict=True):
            if case['cutoff'] != stamp or data is None:
                raise ValueError(f'Archived candidate board did not reproduce: {stamp}')
            bucket = quotes[stamp]
            cutoff = datetime.fromisoformat(stamp)
            ready = max(datetime.fromisoformat(case['chart_receipt']), cutoff + timedelta(seconds=30))
            result = fixed.grade(data, ready, [bucket], 1)
            paired = stream.paired(result)
            if any(value != case['30'][scope][key] for scope, counts in paired.items()
                   for key, value in counts.items()) or not paired:
                raise ValueError(f'Archived score did not reproduce: {stamp}')
            prefix = rows[bisect_left(stamps, (cutoff - 8 * fixed.M5).isoformat()):bisect_left(stamps, stamp)]
            history.append(dict(**review_case(data, ready, [bucket], result), kind='historical',
                                history=[[(utc_ms(datetime.fromisoformat(t)) - utc_ms(cutoff)) // 1000, *ohlc]
                                         for t, *ohlc in prefix],
                                price=study['boards'][stamp]['sample']['price'],
                                chart_receipt=case['chart_receipt'], qualified=data['qualifying'],
                                added=paired['IRL']['added'], displaced=paired['IRL']['displaced']))
    return history


def live_cases(policy, observed):
    observed_cases = []
    for receipt in sorted((stream.OUT / 'receipts').glob('*.json')):
        data, cutoff, ready = stream.load_board(policy, receipt)
        if ready > observed:
            continue
        archive = stream.OUT / 'settlements' / receipt.name
        buckets = []
        result = None
        if cutoff + fixed.M5 <= observed and archive.exists():
            saved = fixed.read(archive)
            evidence = stream.OUT / 'bid' / archive.with_suffix('.json.gz').name
            if saved['receipts_sha256'] != recent.digest(receipt) or saved['bid_sha256'] != recent.digest(evidence):
                raise ValueError(f'Real-time settlement provenance failed: {receipt.name}')
            buckets = fixed.board.joint.read_zip(evidence)
            result = fixed.grade(data, ready, buckets, 1)
            if result['state'] != saved['state'] or stream.paired(result) != saved['paired']:
                raise ValueError(f'Real-time settlement did not reproduce: {receipt.name}')
        irl = stream.paired(result).get('IRL', {}) if result else {}
        observed_cases.append(dict(**review_case(data, ready, buckets, result), kind='observed',
                                   history=[], price=data['cutoff_close'],
                                   chart_receipt=data['chart_receipt'], qualified=data['potential_sides'],
                                   added=irl.get('added', 0), displaced=irl.get('displaced', 0)))
    return observed_cases


def response_cases():
    if not response.OUT.is_file():
        return []
    report = fixed.read(response.OUT)
    archives = (response.QUOTES, recent.OUT, response.missing.OUT)
    if any(recent.digest(path) != report['inputs'][path.name] for path in archives):
        raise ValueError('Sweep response and its quote evidence disagree')
    prices = fixed.board.joint.read_zip(response.QUOTES)['m5']
    stamps = [datetime.fromisoformat(row[0]) for row in prices]
    reviews = []
    for event in report['cases']:
        at = datetime.fromisoformat(event['cutoff'])
        bar_close = at + fixed.M5
        start = bisect_left(stamps, at - 6 * fixed.M5)
        end = bisect_left(stamps, bar_close + timedelta(minutes=90))
        candles = [[int((stamp + fixed.M5 - bar_close).total_seconds() // 60), *row[1:]]
                   for stamp, row in zip(stamps[start:end], prices[start:end], strict=True)]
        reviews.append(dict(**event, crossing_close=bar_close.isoformat(), m5=candles))
    return sorted(reviews, key=lambda item: (item['cutoff'], item['crossing']['bid_time_ms']))


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT.parent / 'output/visualizations/ict-liquidity-review.html')
    args = parser.parse_args()
    if not stream.POLICY.exists():
        raise FileNotFoundError(stream.POLICY)
    policy = stream.load_policy()
    report = fixed.read(recent.OUT)
    historical = historical_cases(report)
    observed_at = datetime.now(timezone.utc)
    live = live_cases(policy, observed_at)
    responses = response_cases()
    bundle = dict(captured_at=observed_at.isoformat(), historical=historical, observed=live,
                  summary=report['results']['30'], observed_since=policy['frozen_at'], responses=responses)
    payload = json.dumps(bundle, ensure_ascii=False, separators=(',', ':'), allow_nan=False).replace('<', '\\u003c')
    template = (ROOT / 'ict_liquidity_review.html').read_text(encoding='utf-8')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.out.with_suffix('.tmp.html')
    temporary.write_text(template.replace('__REPLAY_BUNDLE__', payload, 1), encoding='utf-8')
    recent.live.feed.replace_with_retry(temporary, args.out)
    print(f'{len(historical)} retrospective, {len(live)} prospective, {len(responses)} responses. {args.out}')


if __name__ == '__main__':
    main()
