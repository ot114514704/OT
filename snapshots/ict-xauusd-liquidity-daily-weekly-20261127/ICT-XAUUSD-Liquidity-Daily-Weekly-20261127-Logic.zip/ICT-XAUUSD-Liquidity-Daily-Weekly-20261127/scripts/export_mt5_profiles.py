"""Publish TMGM chart annotations from the June 2026 NY session onward."""
import argparse
import csv
import hashlib
import io
import json
import os
import subprocess
import sys
import time
from datetime import date, datetime, time as walltime, timedelta, timezone
from functools import lru_cache
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import MetaTrader5 as mt5
from brooks_ai.types import Bar
from ict_ai.profile_lifecycle import daily_profile_lifecycle, profile_hover_detail, weekly_profile_lifecycle
from ict_ai.range_liquidity import _m5_reference_day
from ict_ai.regular_liquidity import regular_liquidity, weekly_stage_liquidity
from ict_ai.liquidity_accumulation import chart_marks
from ict_ai.structural_liquidity import structural_ranking
from ict_ai.sweep_response import crossing_caption
from ict_ai.sweep_state_strict import state_caption
from ict_ai.ipda_outlook import phase_frame_marks, phase_note
from ict_ai.silver_trigger import assess as assess_silver
from ict_ai.silver_bullet import silver_bullet_windows
from ict_ai.po3 import po3_zones
from ict_ai.session_review import window_summary
from ict_ai.session_path import VENUES, hours, previous_session, local_structure, displacement, covered, et_clock_text, erl_review, price_purposes
from ict_ai.dol_outlook import PeerEvidence, peer_evidence
from ict_ai.dol_history import batch_id, chart_receipts, forecast, live_reviews, settled_summaries
from ict_ai.h4_review import h4_reviews
from ict_ai.judas import chart_label, judas_history
from ict_ai.profile_extrema import extreme_reviews
from ict_ai.timebase import session_windows, daily_profile_history_start
from bisect import bisect_left
from ict_ai.smt import smt_divergences, smt_observation
from ict_ai.timebase import NY, eastern_clock_spans, manifest_epoch_to_utc
from ict_ai.weekly_path import weekly_path
from ict_ai.daily_path import daily_geometry
from scripts.export_mt5_native import native_time
from scripts.prepare_ict_week import aggregate_bars
from scripts.serve_ict_live import checked_account, replace_with_retry
from scripts.audit_ict_bridge_latency import record_publication

START = date(2026, 6, 1)
DAY = timedelta(days=1)
M5 = timedelta(minutes=5)
H1 = timedelta(hours=1)
UTC = timezone.utc
TARGET = Path(os.environ["APPDATA"]) / "MetaQuotes/Terminal/Common/Files/ICT_Trader/H1Profiles.tsv"


def midnight(day):
    return datetime.combine(day, walltime(), NY).astimezone(UTC)


def touch_on_bar(bar, index, hi, lo, up, price):
    anchor = max(hi, lo)
    if index < anchor or not bar.low <= price <= bar.high:
        return "未见触价"
    if index == anchor:
        # The opposite extreme can move the ruler after a touching wick.
        if (hi <= lo if up else lo <= hi):
            return "已触" if bar.close == price else "顺序待核"
        ordered = bar.open == (bar.high if up else bar.low) or (bar.close <= price if up else bar.close >= price)
    else:
        ordered = (bar.open >= price if up else bar.open <= price) or (bar.close <= price if up else bar.close >= price)
    return "已触" if ordered else "顺序待核"


def ruler_touch(bars, hi, lo, up, price, first):
    uncertain = False
    for i in range(max(first,hi,lo),len(bars)):
        status = touch_on_bar(bars[i],i,hi,lo,up,price)
        if status == "已触":
            return status, bars[i].time + M5
        uncertain |= status == "顺序待核"
    return ("顺序待核" if uncertain else "未见触价"), None


def tgif_ruler(week, friday, now):
    """Closed M5 view of the live ruler. Course time (5), 157–183 s."""
    start = midnight(friday)
    audits = [_m5_reference_day(week, friday-offset*DAY, now) for offset in (4,3,2,1,0)]
    if now < start or any(a["status"] != "complete" for a in audits[:4]):
        return "TGIF待定", "周一至周四报价不全", []
    days = [a["bars"] for a in audits]
    prior = [b for day in days[:4] for b in day]
    change = prior[-1].close-prior[0].open
    if change == 0:
        return "TGIF待定", "周四收盘时周方向不明", []
    up = change > 0

    def extremes(rows):
        return (max(range(len(rows)), key=lambda i: rows[i].high),
                min(range(len(rows)), key=lambda i: rows[i].low))

    def target(high, low, fraction):
        return high-fraction*(high-low) if up else low+fraction*(high-low)

    ph, pl = extremes(prior)
    pre_high, pre_low = prior[ph].high, prior[pl].low
    early = prior[pl if up else ph].time < midnight(friday-2*DAY)
    expands = all((d[-1].close-d[0].open)*change > 0 and
                  (d[-1].close-days[i-1][-1].close)*change > 0 for i,d in enumerate(days[1:4],1))
    before = []
    for fraction in (.2,.3):
        price = target(pre_high,pre_low,fraction)
        state, at = ruler_touch(prior,ph,pl,up,price,0)
        before.append((state,at,fraction,price))
    prior_hit = min(((at,fraction,price) for _,at,fraction,price in before if at is not None), default=None)
    rows = prior+days[-1]
    hi, lo = extremes(rows)
    high, low = rows[hi].high, rows[lo].low
    levels = []
    for f in (.2,.3):
        price = target(high,low,f)
        seen, _ = ruler_touch(rows,hi,lo,up,price,len(prior))
        levels.append((round(f if up else 1-f,1),price,seen))
    # A missing elapsed research bar makes the path inconclusive, even when
    # a later quote appears to satisfy the model. Future bars are not gaps.
    observed_until = min(now,audits[-1]["end"])
    expected = int((observed_until-start)//M5)
    # Keep the first ordered touch of a level that existed at the time.
    # A later extreme updates the displayed ruler but cannot erase the earlier path.
    first_hit = None
    uncertain = False
    running_hi, running_lo = ph, pl
    for idx in range(len(prior),len(rows)):
        bar = rows[idx]
        if bar.high > rows[running_hi].high:
            running_hi = idx
        if bar.low < rows[running_lo].low:
            running_lo = idx
        for fraction in (.2,.3):
            price = target(rows[running_hi].high,rows[running_lo].low,fraction)
            touch = touch_on_bar(bar,idx,running_hi,running_lo,up,price)
            if touch == "已触":
                first_hit = (bar.time+M5,fraction,price)
                break
            uncertain |= touch == "顺序待核"
        if first_hit:
            break
    closed = now >= midnight(friday)+timedelta(hours=17)
    why = ""
    if len(days[-1]) != expected:
        state = "TGIF 报价待核"
    elif prior_hit is not None:
        state = "TGIF 未成立" if closed else "TGIF 目标已提前触及"
        why = "周五开盘前已触目标"
    elif not early or not expands:
        state = "TGIF 未成立" if closed else "TGIF 前提不足"
        why = "周初对侧极点或周二至四同向扩张不符"
    elif any(status=="顺序待核" for status,_,_,_ in before):
        state = "TGIF 周五前触价顺序待核"
    elif first_hit:
        state = "TGIF 已确认" if closed else "TGIF 回撤候选"
        at,fraction,price = first_hit
        why = f"首次可确认的 M5 收线 {at.astimezone(NY):%H:%M} NY · 当时 {fraction:.0%} 位 {price:.2f}"
    elif uncertain:
        state = "TGIF 触价顺序待核"
    else:
        state = "TGIF 未成立" if closed else "TGIF 回撤待观察"
        why = "未观察到顺向回撤触带"
    detail = f"当前刻度 · 周高 {high:.2f} · 周低 {low:.2f}｜" + "｜".join(
        f"{pct:.0%} · {entry[1]:.2f} · {entry[2]}" for pct,entry in zip((.2,.3),levels))
    if prior_hit is not None and why:
        at, fraction, price = prior_hit
        detail += f"｜周五开盘刻度 · {fraction:.0%} 位 {price:.2f} · 首次可核 M5 收线 {at.astimezone(NY):%m-%d %H:%M} NY"
    if why:
        detail += "｜"+why
    return state,detail,[(0,high,"周高"),*levels,(1,low,"周低")]


def friday_tgif(week, friday, now):
    state,detail,_ = tgif_ruler(week,friday,now)
    return state,detail


def history(symbol, period, policy, now):
    # Fetch the preceding week for swing anchors at the start of the chart.
    start = midnight(START - 8 * DAY)
    raw_end = datetime.strptime(native_time(now.isoformat(), policy), "%Y.%m.%d %H:%M:%S").replace(tzinfo=UTC)
    rates = mt5.copy_rates_range(symbol, period, start, raw_end)
    if period==mt5.TIMEFRAME_M1 and (rates is None or not len(rates)):
        capacity=min(110000,mt5.terminal_info().maxbars)
        rates=mt5.copy_rates_from_pos(symbol,period,0,max(1,capacity-1))
        if rates is None or not len(rates):return []
    if rates is None or not len(rates):
        raise RuntimeError(f"{symbol} history unavailable: {mt5.last_error()}")
    step = timedelta(minutes=1) if period==mt5.TIMEFRAME_M1 else M5 if period == mt5.TIMEFRAME_M5 else H1
    bars = []
    for r in rates:
        stamp = manifest_epoch_to_utc(datetime.fromtimestamp(int(r["time"]), UTC), policy)
        if stamp + step <= now:
            bars.append(Bar(stamp, *[float(r[k]) for k in ("open","high","low","close")], 0))
    if not bars or (period!=mt5.TIMEFRAME_M1 and bars[0].time > midnight(START)):
        raise RuntimeError(f"{symbol} lacks requested NY history from {START.isoformat()}")
    return bars


def pool_annotations(m5, minute_bars, cutoff, ranked, frozen=None):
    pools=structural_ranking(m5,cutoff,ranked,minute_bars=minute_bars,limit=None,priority_uplift=True)
    coverage_label=('小范围 IRL 需 5–10 根 M5 · M6/M12 自 '+minute_bars[0].time.astimezone(NY).strftime('%m-%d %H:%M')
                    if minute_bars else '小范围 IRL 需 5–10 根 M5 · M6/M12 待分钟报价')
    marks=iter(chart_marks(pools,cutoff,m5[-1].close))
    _,start,finish,_,first,last=next(marks)
    yield 'pool_context',start,finish,coverage_label,first,last
    for p,(_,start,finish,label,first,last) in zip(pools,marks,strict=True):
        side='buy' if p['side']==1 else 'sell'
        if frozen is not None and p['rank']<=10:
            frozen.append(dict(scope=p['classification'].lower(),side=p['side'],lo=first,hi=last,rank=p['rank'],
                               score=p['score'],name=label.split('｜')[1]))
        yield f'pool_{p["classification"].lower()}_{side}',start,finish,label,first,last


@lru_cache(maxsize=4096)
def session_profile_context(day, at, quarters, reference):
    """Keep only labels, keyed by the immutable candle inputs and supplied cutoff."""
    profile = daily_profile_lifecycle(quarters, day, at, include_reconstruction=False, reference_m5=reference)
    return profile['profile_label'], profile['profile_reason'], profile['weekly_background']['label']


@lru_cache(maxsize=1536)
def h4_profile_context(day, observed, prefix):
    asia_start, asia_end = session_windows(day)['asia']
    quarters = aggregate_bars(prefix, 5, 15, observed)
    label, reason, weekly = session_profile_context(day, observed, tuple(quarters), prefix)
    phases = po3_zones(quarters, asia_start, asia_end, midnight(day + DAY), observed)
    return (f'当时日型 · {label} · {reason}', f'当时周型 · {weekly}', f'当时 AMD · {phases["reason"]}')


def annotations(m5, gold_h1, silver_h1, policy, now, dollar_h1, minute_bars=()):
    rows = []
    minutes = [b.time for b in minute_bars]
    times = [b.time for b in m5]
    def span(start, end):
        return m5[bisect_left(times,start):bisect_left(times,end)]
    # MT5 returns historical calendar values in the current server offset.
    # Publish the raw clock bounds already used for historical OHLC conversion.
    raw_start = datetime.combine(START, walltime(), UTC)
    raw_end = datetime.combine(now.date(), walltime(), UTC) + 9 * DAY
    for segment in policy.get("source_clock_segments") or [dict(offset_hours=policy["source_clock_offset_hours"])]:
        start = max(raw_start, datetime.fromisoformat(segment["raw_from"])) if segment.get("raw_from") else raw_start
        end = min(raw_end, datetime.fromisoformat(segment["raw_until"])) if segment.get("raw_until") else raw_end
        if start < end:
            rows.append(("news_clock", start.strftime("%Y.%m.%d %H:%M:%S"), end.strftime("%Y.%m.%d %H:%M:%S"),
                         int(segment["offset_hours"] * 3600), 0, "MT5 历史服务器时差"))
            server=timedelta(hours=segment["offset_hours"])
            for cursor,finish,offset in eastern_clock_spans(start,end,server):
                rows.append(("et_clock",cursor.strftime("%Y.%m.%d %H:%M:%S"),finish.strftime("%Y.%m.%d %H:%M:%S"),
                             offset,0,"America/New_York"))
    def add(kind, start, end, label="", first=0, last=0):
        def stamp(value):
            return native_time(value.isoformat() if isinstance(value, datetime) else value, policy)
        rows.append((kind, stamp(start), stamp(end), first, last, label))

    wick_marks=set()

    def annotate_crossing(level, known, cutoff):
        response=level.get('crossing_response')
        if not response:
            return ''
        caption=crossing_caption(response)
        timeline=state_caption(level.get('crossing_state'),
                               lambda at: et_clock_text(datetime.fromisoformat(at)))
        detail='｜'.join(part for part in (caption,timeline) if part)
        if response['wick_band']:
            side='buy' if level['kind']=='BSL' else 'sell'
            low,high=response['wick_band']
            key=side,known,low,high
            if key not in wick_marks:
                add('wick_sweep_'+side,known-M5,min(cutoff,known+12*M5),detail,low,high)
                wick_marks.add(key)
        return '｜'+detail

    cutoff=m5[-1].time+M5
    quarters=aggregate_bars(m5[-2600:],5,15,cutoff)
    smt_context = add_smt(add,gold_h1,silver_h1,now,"白银",False) + add_smt(add,gold_h1,dollar_h1,now,"美元指数",True)
    erl_events=[]
    monday = START - START.weekday() * DAY
    last_day = m5[-1].time.astimezone(NY).date()
    while monday <= last_day:
        days = [monday + i * DAY for i in range(5)]
        lo, hi = midnight(monday - DAY), midnight(monday + 6 * DAY)
        week = [b for b in m5 if lo <= b.time < hi]
        m15 = aggregate_bars(week, 5, 15, now)
        path = weekly_path(week, days, now)
        if path["daily"]:
            study = span(midnight(monday-8*DAY),hi)
            for record in extreme_reviews(study,aggregate_bars(study,5,15,now),days,now):
                if record[1]>=midnight(START):add(*record)
            profile = weekly_profile_lifecycle(m15, days, now, path)
            add("week", midnight(max(monday, START)), midnight(days[-1]+DAY),
                f"{profile['profile_label']}｜{profile_hover_detail(profile, include_references=False)}")
            level_stage=weekly_stage_liquidity(week, days, now)
            for level in level_stage["levels"]:
                known = level["sweep_known_at"]
                if not known or datetime.fromisoformat(known) < midnight(START):
                    continue
                side = "买方" if level["kind"] == "BSL" else "卖方"
                origin = datetime.fromisoformat(level["anchor_time"]).astimezone(NY)
                swept = datetime.fromisoformat(known).astimezone(NY)
                caption = f"ERL（{side}）首次越界｜{level['source_scope']} {level['price']:.2f} · 原点 {origin:%m-%d %H:%M} · M5 收线 {swept:%m-%d %H:%M} NY"
                caption+='｜'+erl_review(level,span(swept-3*H1,swept),
                                         span(swept,swept+H1+6*M5),gold_h1,now)
                caption+=annotate_crossing(level,swept,datetime.fromisoformat(level_stage['as_of']))
                erl_events.append((swept,f'{side} ERL {level["price"]:.2f} 首次越界'))
                add("week_sweep", origin, swept, caption, level["price"], level["price"])
            points = [p for p in path["points"] if p["date"] >= START.isoformat()]
            complete = {d["date"] for d in path["daily"] if d["coverage_complete"]}
            for p in points:
                if p["date"] in complete or p["provisional"]:
                    add("week_high" if p["kind"] == "H" else "week_low", p["time_ms"], p["available_at"],
                        "形成中" if p["provisional"] else "复盘", p["price"], p["price"])
            for a, b in zip(points, points[1:]):
                add("path", a["time_ms"], b["time_ms"], "", a["price"], b["price"])
        for day in days:
            start, end = midnight(day), midnight(day + DAY)
            if day < START or not any(start <= b.time < end for b in week):
                continue
            profile = daily_profile_lifecycle(m15, day, now, include_reconstruction=False, reference_m5=week)
            status = "复盘" if profile["mode"] == "closed_review" else "进行中"
            label = f"周{'一二三四五'[day.weekday()]} {day:%m-%d} {status} · {profile['profile_label']}"
            if day.weekday() == 4:
                tgif, reason, levels = tgif_ruler(week, day, now)
                label = f"周五 {tgif} · {day:%m-%d} {status} · {profile['profile_label']}"
                closed_m5 = datetime.fromtimestamp(int(now.timestamp())//300*300, UTC)
                checked = min(closed_m5, start+timedelta(hours=17))
                high, low = (levels[0][1],levels[-1][1]) if levels else (0,0)
                add("fri_check", start, checked, f"{tgif}｜{reason}", low, high)
                for ratio, price, touched in levels:
                    add("fri_fib", start, end, touched, price, ratio)
            add("day", start, end, f"{label}｜日型依据　{profile_hover_detail(profile, include_references=False)}")
            limit=min(now,start+17*H1 if day.weekday()==4 else end)
            geometry=daily_geometry(span(start,limit),start,limit,M5)
            for a,p,z,q in geometry['segments']:
                add('day_path',a,z,'日概况折线',p,q)
            levels=regular_liquidity(m15,span(start-DAY,limit),day,limit)['levels']
            prior=day-DAY*(3 if day.weekday()==0 else 1)
            ref=_m5_reference_day(span(midnight(prior),start),prior,start)
            bounds=None
            if ref['status']=='complete':
                bounds=min(b.low for b in ref['bars']),max(b.high for b in ref['bars'])
            for level in levels:
                if not level['sweep_known_at'] or level['kind'] not in ('BSL','SSL'):continue
                a=datetime.fromisoformat(level['anchor_time'])
                if a<start:continue
                known=datetime.fromisoformat(level['sweep_known_at'])
                p=level['price']
                scope=('irl' if bounds[0]<p<bounds[1] else 'erl') if bounds else 'unknown'
                side='买方' if level['kind']=='BSL' else '卖方'
                reclaimed=level['reclaim_known_at']
                outcome=f'{et_clock_text(datetime.fromisoformat(reclaimed))} 首次收回' if reclaimed else '截至观察末端尚未收回'
                label=(f'{level["source_scope"]}（{side}）首次越界｜{p:.2f} · {et_clock_text(a)} 原点，'
                       f'{et_clock_text(known)} M5 确认越界，{outcome}。')
                if bounds:label+=f' 参照前一完整纽约交易日 {bounds[0]:.2f}–{bounds[1]:.2f}。'
                label+=annotate_crossing(level,known,limit)
                add('day_sweep_'+scope,a,known,label,p,p)
        monday += 7 * DAY

    # Prior-week references are frozen before the new week, including the next scheduled week.
    monday = START - START.weekday()*DAY
    while monday <= now.astimezone(NY).date()+7*DAY:
        last = monday-7*DAY
        prices = span(midnight(last),midnight(last+5*DAY))
        if prices and now>=midnight(last+4*DAY)+timedelta(hours=17):
            hi,lo=max(b.high for b in prices),min(b.low for b in prices)
            trend='上涨' if prices[-1].close>prices[0].open else '下跌' if prices[-1].close<prices[0].open else '持平'
            add('week_ref',midnight(monday),midnight(monday+7*DAY),
                f'上周已观察 O {prices[0].open:.2f} H {hi:.2f} L {lo:.2f} C {prices[-1].close:.2f}（{trend}）',lo,hi)
        monday+=7*DAY
    day = START
    while day <= now.astimezone(ZoneInfo("Asia/Tokyo")).date():
        if day.weekday() < 5:
            asia_start, asia_end = session_windows(day)["asia"]
            finish = midnight(day + DAY)
            m15 = aggregate_bars(span(asia_start, finish), 5, 15, now)
            day_end=midnight(day)+timedelta(hours=17) if day.weekday()==4 else midnight(day+DAY)
            week_m5=tuple(span(daily_profile_history_start(day),finish))
            week_m15=tuple(aggregate_bars(week_m5,5,15,now))
            def context_at(a,z):
                at=min(now,z)
                label, reason, weekly = session_profile_context(day, at, week_m15, week_m5)
                peers,_=peer_evidence(smt_context,a,at)
                return (f'截至美东 {et_clock_text(at)} · {label} · {reason}｜'
                        f'周背景 · {weekly}｜'
                        +'H1 SMT · '+('、'.join(dict.fromkeys(peers)) if peers else '本段无新确认记录'))
            slots = [(a,z,tag) for venue in VENUES for a,z in [hours(day,venue)] for tag in [venue[1]]]
            for window in silver_bullet_windows(day):
                a, z = (datetime.fromtimestamp(window[k]/1000, UTC) for k in ("start_ms","end_ms"))
                label, low, high = window_summary(window["label"], a, z, span(a,z), span(a-H1,a), now, {}, silver=True,
                    warm=span(a-2*H1,a),later=span(z,z+H1))
                at=min(z,now)
                tests=[]
                checked_frames=[]
                minute_body=[]
                if at>a:
                    for source, stamps, step in ((minute_bars,minutes,M5/5),(m5,times,M5)):
                        start_ix=bisect_left(stamps,a)
                        before=source[bisect_left(stamps,a-2*H1):start_ix]
                        body=source[start_ix:bisect_left(stamps,at-step+timedelta(microseconds=1))]
                        if step==M5/5:
                            minute_body=body
                        evidence=assess_silver(before,body,a,at,step)
                        if evidence:
                            tests.append(evidence)
                            checked_frames.append("M1" if step==M5/5 else "M5")
                triggered=sorted((item for item in tests if item[1]),key=lambda item:item[1])
                state="已触发killzone" if triggered else "未触发killzone" if tests else "待核"
                evidence=triggered[0] if triggered else max(tests,key=lambda item:item[0],default=None)
                active="、".join(tag for begin,finish,tag in slots[:3] if begin<z and a<finish)
                if not high and minute_body and minute_body[0].time==a:
                    low=min(b.low for b in minute_body); high=max(b.high for b in minute_body)
                label="｜".join([state,window["label"]+" · "+(active or "盘间")+" · "+("已结束" if now>=z else "观察中"),
                               evidence[2] if evidence else "连续报价不足",label])
                for other in tests:
                    if other is not evidence:
                        label+="｜另一周期独立核对 · "+other[2]
                if at>a:
                    missing=[frame for frame in ("M1","M5") if frame not in checked_frames]
                    label+="｜截至美东 "+et_clock_text(at)+"，"+("可核周期 "+"、".join(checked_frames) if checked_frames else "尚无可核周期")
                    if missing:label+="；"+"、".join(missing)+" 的连续收线不足"
                if high:
                    label+="｜"+context_at(a,z)
                    for idx,venue in enumerate(VENUES):
                        if venue[1] not in active: continue
                        prev=VENUES[idx-1]
                        prev_day=day if idx else day-DAY*(3 if day.weekday()==0 else 1)
                        begin,finish=hours(prev_day,prev)
                        label+="｜"+previous_session([b for b in span(a,at) if b.time+M5<=at],a,at,span(begin,finish),begin,finish,prev[1])
                add("silver", a, z, label, low, high)
                slots.append((a,z,window["label"]))
            for i,(key,city,*_) in enumerate(VENUES):
                a,z=hours(day,VENUES[i])
                at=min(now,z)
                route=po3_zones(m15,asia_start,asia_end,finish,at)
                label, low, high = window_summary(city, a, z, span(a,z), [], now, route,warm=span(a-2*H1,a))
                if high:
                    prev_day=day if i else day-DAY*(3 if day.weekday()==0 else 1)
                    p,q=hours(prev_day,VENUES[i-1])
                    session_bars=[b for b in span(a,z) if b.time+M5<=at]
                    label+='｜'+previous_session(session_bars,a,at,span(p,q),p,q,VENUES[i-1][1])
                    label+='｜'+local_structure(session_bars,span(a-2*H1,a))+'｜'+context_at(a,z)
                add(key, a, z, label, low, high)
            # Partition the NY day once, including overlap and outside-session hours.
            start=midnight(day)
            next_tokyo=hours(day+DAY,VENUES[0])
            if day.weekday()<4:slots.append((*next_tokyo,'TK'))
            bounds=sorted({start,day_end,*[v for a,z,_ in slots for v in (a,z) if start<v<day_end]})
            for a,z in zip(bounds,bounds[1:]):
                at=min(z,now)
                if at<=a:break
                body=[b for b in span(a,z) if b.time+M5<=at]
                tags=' / '.join(tag for l,r,tag in slots if l<=a<r) or '盘间'
                if not body:
                    add('day_leg',a,z,tags+' · 无已收 M5 报价')
                    continue
                hi=max(body,key=lambda b:b.high);lo=min(body,key=lambda b:b.low)
                warm=span(a-2*H1,a)
                strength,_=displacement(body,warm)
                extremes=sorted([(hi.time,f'高 {hi.high:.2f}'),(lo.time,f'低 {lo.low:.2f}')])
                path='、'.join(et_clock_text(t)+' '+v for t,v in extremes)
                if hi.time==lo.time:path+='（同棒先后待核）'
                note=f'{tags} · 开 {body[0].open:.2f}，{path}，末 {body[-1].close:.2f}（{body[-1].close-body[0].open:+.2f}）'
                phases=po3_zones(m15,asia_start,asia_end,finish,at)
                roles=[s['phase'] for s in phases['zones'] if a<datetime.fromisoformat(s['available_at'])<=at]
                levels=[et_clock_text(t)+' '+v for t,v in erl_events if a<t<=at]
                add('day_leg',a,z,'｜'.join([note,price_purposes(body,warm),strength,local_structure(body,warm),
                    'PO3 · '+(' → '.join(roles)+' 新确认候选' if roles else '本段无新增阶段'),
                    context_at(a,z)]+levels+([] if covered(body,a,at) else ['报价覆盖不全，路径限于已观察部分'])))
        day += DAY
    schedule = json.loads((ROOT / "research/jin10_calendar/bls_mt5_schedule.json").read_text(encoding="utf-8"))
    news = []
    for day, clock, event in schedule["events"]:
        at = datetime.fromisoformat(day + "T" + clock).replace(tzinfo=NY)
        news.append((at,event))
        add("calendar", at, at, event)
    def h4_context(day, close, observed):
        session_day = observed.astimezone(NY).date()
        if session_day.weekday()==6:
            session_day+=DAY
        if session_day.weekday()==5:
            return []
        prefix = tuple(span(daily_profile_history_start(session_day),observed))
        return h4_profile_context(session_day, observed, prefix)
    for review in h4_reviews(m5,midnight(START),now,smt_context,news,erl_events,h4_context):
        add(*review)
    pending = []
    judas = judas_history(m5, now, news, pending)
    minute_events=judas_history(minute_bars,now,news,pending,step=timedelta(minutes=1),reference_m5=m5)
    chart_events=sorted(judas+minute_events,key=lambda signal:signal['known'])
    for e in pending:
        if now-e['sweep']<6*(e['known']-e['sweep']):
            add('judas_watch_up' if e['side']==1 else 'judas_watch_down', e['sweep'], e['known'],
                f"犹大待确认｜{e['window']} · {e['timeframe']} 扫{e['refs']}并收回｜反向位移、MSS、CISD、FVG 尚未全部确认",e['edge'],e['edge'])
    for e in chart_events:
        if e['sweep'] >= midnight(START):
            add('judas_up' if e['side']==1 else 'judas_down', e['sweep'], e['known'],
                chart_label(e), e['edge'], e['confirm'])
    latest=chart_events[-1] if chart_events else None
    message='最近确认 · '+latest['known'].astimezone(NY).strftime('%m-%d %H:%M ET')+' '+latest['timeframe'] if latest else '载入区间尚无确认'
    add('judas_status',m5[-1].time,m5[-1].time,message+
        ('｜M1 覆盖从 '+minute_bars[0].time.astimezone(NY).strftime('%m-%d %H:%M ET') if minute_bars else '｜M1 仍待同步'))
    review_file = ROOT / 'output/research/ranked_dol/history.json'
    review_groups = {}
    if review_file.is_file():
        review = json.loads(review_file.read_text(encoding='utf-8'))
        if 'snapshots' in review:
            review_groups.update(settled_summaries(review['snapshots']))
        else:
            for scope in ('day','week'):
                for stamp,entries in review[scope].items():
                    review_groups[scope,stamp]=['旧归档（预测期限待核实） '+e for e in entries]
    d=m5[-1].time.astimezone(NY).date()
    narrative=[]
    if d.weekday()!=5:
        m15=aggregate_bars(m5,5,15,cutoff)
        records,ranked=forecast(m5,gold_h1,m15,cutoff,smt_context,news,judas,
                                nearby_priority=True,priority_uplift=True)
        for record in records:add(*record)
        frozen=[]
        pools=list(pool_annotations(m5,minute_bars,cutoff,ranked,frozen))
        batch=batch_id(cutoff,m5[-1].close,[ranked,frozen])
        add('dol_batch',cutoff,cutoff,batch)
        for entry in pools:add(*entry)
        comparison=next((r[3] for r in records if r[0]=='dol_context'),'')
        recent=span(cutoff-H1,cutoff)
        warm=span(cutoff-3*H1,cutoff-H1)
        narrative.append(f'截至美东 {cutoff.astimezone(NY):%m-%d %H:%M}，末根 M5 收 {m5[-1].close:.2f}')
        if recent and warm:
            narrative.extend([price_purposes(recent,warm),local_structure(recent,warm)])
        narrative.extend(s for s in comparison.split('｜') if s and not s.startswith('时间过滤'))
        for side in (1,-1):
            target=next((p for p in ranked if p['side']==side),None)
            if not target:continue
            lo,hi=target['lo'],target['hi']
            zone=f'{lo:.2f}' if lo==hi else f'{lo:.2f}–{hi:.2f}'
            same_side='buy' if side==1 else 'sell'
            layers=sorted({k.split('_')[1].upper() for k,_,_,_,a,b in pools
                           if k.endswith('_'+same_side) and a<=hi and b>=lo})
            pool='，重叠 '+' / '.join(layers) if layers else ''
            narrative.append(f'{"上" if side==1 else "下"}方路径 · {target["trigger"]}，观察 {target["source"]} {zone}{pool}。'
                             f' #{target["rank"]} · {target["score"]}/100 · {target["reason"]}')
        if now-cutoff>H1:
            narrative.append('距末次收线已超过一小时，此处保留当时的目标与排序，等待新报价重新评估')
        live=live_reviews(review_file.with_name('live.sqlite3'),cutoff,now,m5[-1].close,ranked,m5,
                          chart_receipts(TARGET.parent/'DOLReceipts',now),pools=frozen,batch=batch)
        for key,entries in live.items():
            review_groups.setdefault(key,[]).extend(entries)
    for (scope,stamp),entries in review_groups.items():
        start=midnight(date.fromisoformat(stamp))
        entries=list(dict.fromkeys(entries))
        for offset in range(0,len(entries),5):
            add('dol_review_'+scope,start,start,'｜'.join(entries[offset:offset+5]))
    paired = ROOT/'output/research/june_november_joint_20261122/profile_history.json'
    if not paired.is_file():
        paired = ROOT/'output/research/pool_dol_20261122/profile_history.json'
    if paired.is_file():
        for group in json.loads(paired.read_bytes()):
            through=datetime.fromisoformat(group['through'])
            if through>cutoff:continue
            start=midnight(date.fromisoformat(group['day']))
            entries=[f'历史重建 · {group["count"]} 个时点 · {len(group["rows"])} 处目标已核实',*group['rows']]
            for offset in range(0,len(entries),5):
                add(group['kind'],start,through,'｜'.join(entries[offset:offset+5]))
    for record in phase_frame_marks(m5,gold_h1,cutoff):
        add(*record)
    if quarters:
        phase_close=quarters[-1].time+3*M5
        add('ipda_phase',phase_close,phase_close,phase_note(quarters,phase_close,gold_h1[-252:]))
        if narrative:
            add('ipda_context',phase_close,cutoff,'｜'.join(narrative))
    return rows


def add_smt(add, gold_h1, comparison, now, peer_name, inverse):
    confirmations=[]
    # Reciprocals swap highs and lows while preserving every swing time.
    # This lets both pivot detection and later catch-up use the same orientation.
    if inverse:
        comparison = [Bar(b.time, 1/b.open, 1/b.low, 1/b.high, 1/b.close, 0) for b in comparison]
    for event in smt_divergences(gold_h1, comparison, H1, now):
        a, b = event["primary"]
        if a["time_ms"] < midnight(START).timestamp() * 1000:
            continue
        bull = event["direction"] == "bullish"
        kind = "smt_up" if bull else "smt_down"
        info = smt_observation(event, gold_h1, comparison, H1, now)
        ext = "低" if bull else "高"
        gold_led = event["primary_pattern"] in ("LL", "HH")
        peer_ext = ("高" if bull else "低") if inverse else ext
        leader, laggard = ("黄金",peer_name) if gold_led else (peer_name,"黄金")
        lead_ext, lag_ext = (ext,peer_ext) if gold_led else (peer_ext,ext)
        title = ("↑ 看涨" if bull else "↓ 看跌") + " SMT · " + peer_name
        ended = info.get("catch_up_at") or info.get("gap_known_at")
        confirmations.append(PeerEvidence(datetime.fromisoformat(event["available_at"]),title,
            1 if bull else -1,datetime.fromisoformat(ended) if ended else None,
            "已补破" if info["status"]=="peer_caught_up" else "后续报价不连续"))
        label = f"{title}｜{leader}破前{lead_ext}，{laggard}未破前{lag_ext}"
        if info["status"] == "followup_gap":
            label += "｜后续报价有缺口"
        elif info["status"] == "geometry_only":
            label += "｜待验"
        add(kind, a["time_ms"], b["time_ms"], label, a["price"], b["price"])
        if info["status"] == "peer_caught_up":
            known = datetime.fromisoformat(info["catch_up_at"])
            candle = next(bar for bar in gold_h1 if bar.time == known - H1)
            price = candle.low if bull else candle.high
            add("catch_up" if bull else "catch_down", candle.time, known,
                f"{title} · {laggard}补破前{lag_ext} · {known.astimezone(NY):%m-%d %H:%M} NY 收线", price, price)
    return confirmations


def publish(rows, target):
    body = io.StringIO(newline="")
    csv.writer(body, delimiter="\t").writerows(rows)
    content = body.getvalue()
    revision = hashlib.sha256(content.encode()).hexdigest()
    data = (f"{revision}\t{len(rows)}\r\n" + content).encode("utf-16")
    if target.exists() and target.read_bytes() == data:
        return None
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_bytes(data)
    replace_with_retry(tmp, target)
    return revision


def run(once):
    policy = json.loads((ROOT/"research/live_clock_20261116.json").read_text(encoding="utf-8"))
    if not once:
        subprocess.Popen([sys.executable,'-B','-u',str(ROOT/'scripts/live_ict_realized.py'),'--watch'],
                         creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    previous = binding = revision = None
    while True:
        try:
            if not mt5.initialize():
                raise RuntimeError(f"MT5 unavailable: {mt5.last_error()}")
            account = checked_account(mt5, binding)
            binding = (account.login, account.server)
            now = datetime.now(UTC)
            # Retry as soon as a delayed or revised closed candle arrives from the terminal.
            signature=[]
            for symbol,period,step in [('XAUUSD',mt5.TIMEFRAME_M1,timedelta(minutes=1)),('XAUUSD',mt5.TIMEFRAME_M5,M5),('XAUUSD',mt5.TIMEFRAME_H1,H1),
                                        ('XAGUSD',mt5.TIMEFRAME_H1,H1),('USIDX',mt5.TIMEFRAME_H1,H1)]:
                last=mt5.copy_rates_from_pos(symbol,period,0,3)
                if last is None or not len(last):
                    if period==mt5.TIMEFRAME_M1:continue
                    raise RuntimeError(f'{symbol} waiting for recent quotes')
                for r in reversed(last):
                    stamp=manifest_epoch_to_utc(datetime.fromtimestamp(int(r['time']),UTC),policy)
                    if stamp+step<=now:
                        signature.append((symbol,int(r['time']),*(float(r[k]) for k in ('open','high','low','close'))))
                        break
            revision=(int(now.timestamp())//300,tuple(signature))
            if revision != previous:
                quote_read_started = datetime.now(UTC)
                m5 = history("XAUUSD", mt5.TIMEFRAME_M5, policy, now)
                gold = history("XAUUSD", mt5.TIMEFRAME_H1, policy, now)
                silver = history("XAGUSD", mt5.TIMEFRAME_H1, policy, now)
                dollar = history("USIDX", mt5.TIMEFRAME_H1, policy, now)
                minute_bars=history("XAUUSD", mt5.TIMEFRAME_M1, policy, now)
                quotes_loaded = datetime.now(UTC)
                rows = annotations(m5, gold, silver, policy, now, dollar, minute_bars)
                rows_built = datetime.now(UTC)
                checked_account(mt5, binding)
                published = publish(rows, TARGET)
                file_ready = datetime.now(UTC)
                batch = next((row[-1] for row in rows if row[0] == 'dol_batch'), None)
                cutoff = m5[-1].time + M5
                if published and batch and cutoff <= quote_read_started < cutoff + 2 * M5:
                    try:
                        record_publication(batch, cutoff, quote_read_started, quotes_loaded,
                                           rows_built, file_ready, published, len(rows))
                    except (OSError, ValueError) as error:
                        print(f'Could not record bridge publication timing: {error}', file=sys.stderr, flush=True)
                previous = revision
                if once:
                    print(f"{len(rows)} marks; XAU H1: {sum(b.time >= midnight(START) for b in gold)}; "
                          f"last native H1 {native_time(gold[-1].time.isoformat(), policy)}")
        except (OSError, ValueError, RuntimeError) as exc:
            if once:
                raise
            print(exc, file=sys.stderr, flush=True)
        finally:
            mt5.shutdown()
        if once:
            break
        time.sleep(5)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true")
    run(parser.parse_args().once)
