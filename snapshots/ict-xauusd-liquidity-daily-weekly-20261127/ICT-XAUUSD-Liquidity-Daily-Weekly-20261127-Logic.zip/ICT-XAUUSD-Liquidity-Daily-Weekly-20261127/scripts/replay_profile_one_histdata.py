"""Replay the existing profile rules on archived HistData XAUUSD ticks, offline."""
import argparse
import csv
import hashlib
import json
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zipfile import ZipFile

from brooks_ai.types import Bar, utc_time
from ict_ai.profile_lifecycle import daily_profile_lifecycle, weekly_profile_lifecycle
from ict_ai.timebase import NY
from ict_ai.weekly_path import weekly_path
from scripts.export_mt5_profiles import midnight
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_ipda_profiles import active_profiles, match_row, score_weekly_candidates


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_month(directory, month):
    base = directory / f"XAUUSD-M15-{month}"
    manifest = json.loads(base.with_suffix(".manifest.json").read_bytes())
    ticks = directory / "raw" / f"XAUUSD-ticks-{month}.zip"
    reference = base.with_suffix(".csv")
    if (digest(ticks) != manifest["source_sha256"] or digest(reference) != manifest["output_sha256"]
            or (manifest["price_basis"], manifest["source_timezone"]) != ("mid", "fixed UTC-05:00")):
        raise ValueError("Unexpected archive or quote basis")
    bars = []
    prior = bucket = b""
    count = 0
    fixed = timezone(timedelta(hours=-5))
    with ZipFile(ticks) as archive, archive.open(manifest["source_member"]) as quotes:
        for line in quotes:
            stamp, bid_text, ask_text, _ = line.split(b",")
            bid, ask = float(bid_text), float(ask_text)
            if stamp < prior or ask < bid or bid <= 0:
                raise ValueError(f"Invalid quote at {stamp!r}")
            prior = stamp
            count += 1
            mid, spread = (bid + ask) / 2, ask - bid
            minute = stamp[:13]
            if minute != bucket:
                minute = minute[:12] + (b"0" if minute[-1:] < b"5" else b"5")
                if minute != bucket:
                    if bucket:
                        bars.append(Bar(start, op, hi, lo, close, widest))
                    bucket = minute
                    start = datetime.strptime(bucket.decode(), "%Y%m%d %H%M").replace(tzinfo=fixed).astimezone(timezone.utc)
                    op = hi = lo = close = mid
                    widest = spread
                    continue
            hi, lo, close = max(hi, mid), min(lo, mid), mid
            widest = max(widest, spread)
    # As in the original archive, discard the final unclosed bucket.
    if count != manifest["ticks"] or not bars:
        raise ValueError("Tick count mismatch")
    end = utc_time(manifest["final_bucket_dropped"])
    checks = aggregate_bars(bars, 5, 15, end)
    with reference.open(encoding="utf-8-sig", newline="") as stream:
        published = {utc_time(r["timestamp"]): r for r in csv.DictReader(stream)}
    for bar in checks:
        row = published[bar.time]
        if any(abs(getattr(bar, field) - float(row[field])) > 1e-8 for field in ("open","high","low","close","spread")):
            raise ValueError(f"M15 disagreement at {bar.time}")
    if not checks or len(published) != manifest["completed_bars"]:
        raise ValueError("Invalid M15 reference")
    return bars, {"month":month, "ticks":count, "raw_sha256":manifest["source_sha256"],
                  "m15_sha256":manifest["output_sha256"], "source_url":manifest["source_download_page"],
                  "m5_rows":len(bars), "m15_matched":len(checks),
                  "published_m15_without_three_closed_m5":len(published)-len(checks)}


def replay(bars):
    weeks = []
    start = bars[0].time.astimezone(NY).date()
    last = bars[-1].time.astimezone(NY).date()
    monday = start - timedelta(days=start.weekday())
    while monday <= last:
        dates = [monday + timedelta(days=i) for i in range(5)]
        end = midnight(dates[-1]) + timedelta(hours=17)
        m5 = [b for b in bars if midnight(monday - timedelta(days=1)) <= b.time < end]
        m15 = aggregate_bars(m5, 5, 15, end)
        def week_at(at):
            prefix = [b for b in m5 if b.time + timedelta(minutes=5) <= at]
            closed = [b for b in m15 if b.time + timedelta(minutes=15) <= at]
            return weekly_profile_lifecycle(closed, dates, at, weekly_path(prefix, dates, at))

        final = week_at(end)
        checkpoints = [score_weekly_candidates(week_at(midnight(dates[i])), final) for i in (2, 3, 4)]
        days = []
        for d in dates:
            if not start <= d <= last:
                continue
            def day_at(at):
                return daily_profile_lifecycle(
                    [b for b in m15 if b.time + timedelta(minutes=15) <= at], d, at,
                    reference_m5=[b for b in m5 if b.time + timedelta(minutes=5) <= at],
                    include_reconstruction=False)
            closed = day_at(min(end, midnight(d + timedelta(days=1))))
            noon = day_at(midnight(d) + timedelta(hours=12))
            def keys(cards):
                return {(c["id"], c["direction"]) for c in cards}
            coverage = closed["coverage_complete_under_study_calendar"]
            days.append({"date":d.isoformat(), "label":closed["profile_label"], "reason":closed["profile_reason"],
                         "coverage":coverage, "noon":match_row(keys(active_profiles(noon)), keys(closed["actual_paths"]), coverage)})
        weeks.append({"monday":monday.isoformat(), "label":final["profile_label"], "reason":final["profile_reason"],
                      "coverage":final["coverage_complete_under_study_calendar"], "tue_wed_thu_close":checkpoints, "days":days})
        monday += timedelta(days=7)
    return weeks


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    months = [read_month(args.directory, month) for month in ("202501", "202502")]
    weeks = replay([b for bars, _ in months for b in bars])
    summary = {"daily_ny_noon":dict(Counter(d["noon"]["result"] for w in weeks for d in w["days"])),
               "weekly_tue_wed_thu":dict(Counter(c["result"] for w in weeks for c in w["tue_wed_thu_close"]))}
    report = {"provider":"HistData.com", "symbol":"XAUUSD", "price_basis":"mid",
              "scope":"Historical cross-feed replay. Frozen candidates vs same-rule close review. No independent labels, news, orders or P&L. Coverage uses existing study hours.",
              "source_directory":str(args.directory), "sources":[source for _, source in months], "summary":summary, "weeks":weeks}
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary))
