"""Offline HistData tick execution of the profile-one classic reversal 1.1 protocol."""
from argparse import ArgumentParser
from collections import Counter
from dataclasses import asdict, replace
from datetime import datetime, time, timedelta, timezone
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
import json
from pathlib import Path
from zipfile import ZipFile

from brooks_ai.types import Instrument, Tick
from ict_ai.backtest import LimitStudyOrder
from ict_ai.tick_portfolio import replay_tick_portfolio
from ict_ai.timebase import NY, session_windows
from scripts.replay_classic_reversal_orders import day_signals
from scripts.replay_ict_news import ROOT, STEP
from scripts.replay_profile_one_histdata import digest, read_month


def freeze_orders(bars, spec):
    days = sorted({b.time.astimezone(NY).date() for b in bars if b.time.astimezone(NY).weekday() < 5})
    grid = Decimal(str(spec.tick_size))
    signals, orders = [], []
    checks = 0
    for day in days:
        windows = session_windows(day)
        end = min(windows["london_close"][1], bars[-1].time + STEP)
        context = [b for b in bars if windows["asia"][0] <= b.time < end]
        current = day_signals(day, context, end)
        at = windows["new_york"][0]
        while at <= end:
            observed = day_signals(day, [b for b in context if b.time + STEP <= at], at)
            if observed != [s for s in current if s["at"] <= at]:
                raise AssertionError(f"Later quotes changed a signal at {at}")
            checks += 1
            at += 3 * STEP
        for s in current:
            side = s["side"]
            rounding = ROUND_FLOOR if side == 1 else ROUND_CEILING
            entry = (Decimal(str(s["entry"]))/grid).to_integral_value(rounding) * grid
            pivot = (Decimal(str(s["pivot"]))/grid).to_integral_value(rounding) * grid
            stop = pivot - side * grid
            target = entry + 2 * (entry - stop)
            orders.append(LimitStudyOrder(s["id"], side, s["at"], s["at"]+timedelta(minutes=90),
                                          float(entry), float(stop), float(target), spec.volume_min))
            signals.append(s)
    return signals, orders, checks


def execution_quotes(directory, sources, orders):
    # Scope the second tick pass to each activation day, from preflight to the flatten.
    spans = []
    for order in orders:
        day = order.available_at.astimezone(NY).date()
        spans.append((order.available_at - timedelta(seconds=11), datetime.combine(day, time(16, 52), NY)))
    return read_intraday_quotes(directory, sources, spans)


def read_intraday_quotes(directory, sources, spans):
    """Read the enclosing quote window per source date, preserving equal-timestamp order."""
    source_zone = timezone(timedelta(hours=-5))
    def stamp(at):
        return at.astimezone(source_zone).strftime("%Y%m%d %H%M%S%f")[:-3].encode()
    windows = {}
    for start, end in spans:
        lo, hi = stamp(start), stamp(end)
        key = lo[:8]
        if hi[:8] != key or lo > hi:
            raise ValueError("Expected an ordered intraday source window")
        old_lo, old_hi = windows.get(key, (lo, hi))
        windows[key] = (min(lo, old_lo), max(hi, old_hi))
    ticks = []
    for src in sources:
        month = src["month"]
        path = directory / "raw" / f"XAUUSD-ticks-{month}.zip"
        if digest(path) != src["raw_sha256"]:
            raise ValueError("Raw execution stream changed after M5 reconstruction")
        if not any(key.startswith(month.encode()) for key in windows):
            continue
        with ZipFile(path) as archive, archive.open(f"DAT_ASCII_XAUUSD_T_{month}.csv") as stream:
            prior_minute = None
            for row in stream:
                window = windows.get(row[:8])
                if window is None or not window[0] <= row[:18] <= window[1]:
                    continue
                timestamp, bid, ask, _ = row.split(b",")
                minute = timestamp[:13]
                if minute != prior_minute:
                    base = datetime.strptime(minute.decode(), "%Y%m%d %H%M").replace(tzinfo=source_zone)
                    base = base.astimezone(timezone.utc)
                    prior_minute = minute
                at = base + timedelta(milliseconds=int(timestamp[13:]))
                ticks.append(Tick(at, float(bid), float(ask)))
    return ticks


def run(directory, manifest):
    months = [read_month(directory, m) for m in ("202501", "202502")]
    bars = [b for rows, _ in months for b in rows]
    sources = [source for _, source in months]
    meta = json.loads(manifest.read_bytes())
    info = meta["current_symbol_observation"]
    if meta["symbol"] != "XAUUSD":
        raise ValueError("Expected the project's XAUUSD reference contract")
    spec = Instrument(meta["symbol"], info["point"], info["trade_tick_size"], info["trade_contract_size"],
                      info["volume_min"], info["volume_step"], info["volume_max"],
                      account_currency=meta["account_currency"], profit_currency=info["currency_profit"])
    config_path = ROOT / "config/strategy.json"
    config = json.loads(config_path.read_bytes())
    risk = {k:config[k] for k in ("risk_fraction","daily_loss_limit","max_drawdown","max_consecutive_losses")}
    signals, orders, checks = freeze_orders(bars, spec)
    ticks = execution_quotes(directory, sources, orders)
    accounts = {}
    for name, commission, slippage in (("observed_spread_only",0.,0.), ("assumed_base",7.,.05)):
        model = replace(spec, commission_round_turn=commission, slippage=slippage)
        result = replay_tick_portfolio(orders, ticks, model, bars[-1].time + STEP,
                                       config["initial_equity"], risk)
        for row in result["completed"]:
            out = row["outcome"]
            if out["status"] == "closed":
                costs = out["cost_breakdown"]
                net = costs["midpoint_move_pnl"] - sum(v for k,v in costs.items() if k != "midpoint_move_pnl")
                if abs(net - out["pnl_net"]) > 1e-7:
                    raise AssertionError("Tick trade P&L does not reconcile")
        counts = Counter(d["status"] for d in result["decisions"])
        outcomes = Counter(d["outcome"].get("reason", d["outcome"]["status"]) for d in result["completed"])
        accounts[name] = {"commission_per_round_turn_lot":commission,"adverse_market_exit_slippage":slippage,
                          "decision_counts":dict(counts), "outcome_counts":dict(outcomes), **result}
    return {"source_directory":str(directory), "sources":sources, "signal_prefix_checks":checks,
            "signals":signals, "templates":[asdict(o) for o in orders], "execution_ticks":len(ticks),
            "reference_contract":asdict(spec), "contract_source":str(manifest), "contract_sha256":digest(manifest),
            "risk_config_sha256":digest(config_path), "accounts":accounts, "orders_sent":0,
            "method":"Classic reversal 1.1, initial and replacement, mid-price candles. Round buy limits down and sell limits up to reference tick grid. 90-minute limit, one tick outside rounded pivot, 2R target, 16:50 NY flatten. Only recorded Bid/Ask after activation. A quote gap over 60 seconds censors the path.",
            "limits":"Historical non-broker feed. Current TMGM reference lot and contract assumptions. Queue position, historical fees, depth and fill quality unknown. Isolated model, no HTF bias or news filter."}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--contract", type=Path, default=ROOT/"data/real/TMGM_ICT_live_start_20261120_174514/XAU/provenance.json")
    args = parser.parse_args()
    report = run(args.directory, args.contract)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=lambda t:t.isoformat())+"\n", encoding="utf-8")
    for name, account in report["accounts"].items():
        print(name, account["decision_counts"], account["outcome_counts"], account["final_realized_equity"])
