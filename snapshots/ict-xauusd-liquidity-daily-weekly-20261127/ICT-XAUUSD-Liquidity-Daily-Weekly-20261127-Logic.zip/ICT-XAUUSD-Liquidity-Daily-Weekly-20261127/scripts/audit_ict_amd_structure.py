"""Compare native AMD entries with independently timed BOS, CHoCH and CISD evidence."""

from argparse import ArgumentParser
from bisect import bisect_right
from collections import Counter
from dataclasses import asdict, replace
from datetime import date, datetime
from pathlib import Path
import json
import subprocess

from ict_ai.portfolio import replay_portfolio
from ict_ai.timebase import NY
from scripts import backtest_ict_native_amd as baseline
from scripts.audit_ict_amd_target_context import interval
from scripts.serve_ict_live import atomic_json


ROOT = baseline.ROOT
OUT = baseline.OUT.with_name('ict_native_amd_structure_context_20261123.json')
SMC = ROOT/'mt5/ICT_SMC_View.mqh'
HARNESS = ROOT/'scripts/replay_native_smc.cjs'
SPLIT = date(2026,9,1)
RULES = ('baseline','structure_agrees','structure_already_aligned','strong_structure_agrees','cisd_agrees')


def native_structure(bars, minutes, point, ends):
    now = bars[-1].time+baseline.M5
    source = baseline.aggregate_bars(bars,5,minutes,now)
    candles = [dict(time=b.time.timestamp(),open=b.open,high=b.high,low=b.low,close=b.close) for b in source]
    checkpoints = sorted({stamp.timestamp() for stamp in ends} |
                         {stamp.timestamp()-minutes*60 for stamp in ends})
    result = subprocess.run(['node',str(HARNESS),str(SMC)],
                            input=json.dumps(dict(r=candles,now=now.timestamp(),period=minutes*60,
                                                   point=point,checkpoints=checkpoints)),
                            encoding='utf-8',capture_output=True,check=False)
    if result.returncode:
        raise RuntimeError(result.stderr)
    data = json.loads(result.stdout)
    return data['events'],data['prefixChecks']


def evidence(signal, events, times):
    anchor = datetime.fromisoformat(signal['m_known'] or signal['a_known'])
    decision = datetime.fromisoformat(signal['d_confirm'])
    left = bisect_right(times,anchor.timestamp())
    right = bisect_right(times,decision.timestamp())
    seen = events[left:right]
    structure = [e for e in seen if e['kind'] in ('BOS','CHoCH')]
    shifts = [e for e in seen if e['kind']=='CISD']

    def latest(rows):
        return [e for e in rows if e['known']==rows[-1]['known']] if rows else []

    def direction(rows):
        votes = {e['direction'] for e in rows}
        return next(iter(votes)) if len(votes)==1 else None

    breaks, cisd = latest(structure), latest(shifts)
    aligns = direction(breaks)==signal['direction']
    earlier_breaks = latest([e for e in structure if e['known']<decision.timestamp()])
    gates = dict(baseline=True,structure_agrees=aligns,
                 structure_already_aligned=aligns and direction(earlier_breaks)==signal['direction'],
                 strong_structure_agrees=aligns and any(b['strong'] for b in breaks),
                 cisd_agrees=direction(cisd)==signal['direction'])
    return dict(from_exclusive=anchor.isoformat(),known_through=decision.isoformat(),
                structure_direction=direction(breaks),earlier_structure_direction=direction(earlier_breaks),
                cisd_direction=direction(cisd),latest_breaks=breaks,earlier_breaks=earlier_breaks,
                latest_cisd=cisd,gates=gates)


def evaluate_cohort(rows, ids, signals):
    kept = [r for r in rows if r['order_id'] in ids]
    removed = [r for r in rows if r['order_id'] not in ids]
    return dict(selected=dict(**baseline.settled_summary(kept),**interval(kept,signals)),
                excluded=baseline.settled_summary(removed))


def compact_account(account):
    blocked = next((row for row in account['decisions']
                    if row['status'] in ('blocked_by_risk_limit','blocked_by_unknown_exposure')),None)
    return dict(final_realized_equity=account['final_realized_equity'],
                max_realized_drawdown_fraction=account['max_realized_drawdown_fraction'],
                unknown_exposure_order=account['unknown_exposure_order'],
                first_account_block=blocked,
                decisions=dict(Counter(row['status'] for row in account['decisions'])),
                exits=dict(Counter(row['outcome']['status'] for row in account['completed'])))


def iso_json(value):
    return json.loads(json.dumps(value,default=lambda item:item.isoformat(),allow_nan=False))


def run():
    source = json.loads(baseline.OUT.read_bytes())
    digest = baseline.feed.archive.digest
    if any(digest(ROOT/path)!=checksum for path,checksum in source['inputs'].items()):
        raise ValueError('Frozen AMD, execution or market inputs changed')
    first,last = (datetime.fromisoformat(source[k]).astimezone(NY).date() for k in ('quote_start','quote_end'))
    bars,instrument,server = baseline.read_market(first,last)
    if server!=source['server'] or len(bars)!=source['m5_bars']:
        raise ValueError('TMGM baseline series differs')
    signals = {s['id']:s for s in source['confirmed']}
    orders = [o for s in signals.values() if (o:=baseline.order_for(s,instrument)) is not None]
    if {o.id:iso_json(asdict(o)) for o in orders}!={o['id']:o for o in source['templates']}:
        raise ValueError('Baseline order template sets differ')
    end = bars[-1].time+baseline.M5
    contexts = {}
    structure_summary = {}
    for frame,minutes in (('M15',15),('H1',60)):
        native_signals = [s for s in signals.values() if s['timeframe']==frame]
        ends = {datetime.fromisoformat(s['d_confirm']) for s in native_signals}
        events,checks = native_structure(bars,minutes,instrument.point,ends)
        times = [e['known'] for e in events]
        structure_summary[frame] = dict(events=dict(Counter(e['kind'] for e in events)),prefix_checks=checks)
        for signal in native_signals:
            state = evidence(signal,events,times)
            cut = bisect_right(times,datetime.fromisoformat(signal['d_confirm']).timestamp())
            if state!=evidence(signal,events[:cut],times[:cut]):
                raise AssertionError(f"Future structure markers changed {signal['id']}")
            contexts[signal['id']] = state

    split_dates = {s['id']:datetime.fromisoformat(s['d_confirm']).astimezone(NY).date() for s in signals.values()}
    config = json.loads((ROOT/'config/strategy.json').read_bytes())
    risk = source['risk_limits']
    comparisons = {}
    for fees in ('base','stress'):
        commission,slippage,spread = baseline.FEES[fees]
        spec = replace(instrument,commission_round_turn=commission,slippage=slippage)
        original = source['scenarios'][fees]['independent_orders']
        cohorts = {}
        for frame in ('M15','H1'):
            for route in ('AMD','AD_no_M'):
                scope = [row for row in original if signals[row['order_id']]['timeframe']==frame
                         and signals[row['order_id']]['route']==route]
                if not scope:
                    continue
                by_cut = dict(all=scope, before_september=[r for r in scope if split_dates[r['order_id']]<SPLIT],
                              september_onward=[r for r in scope if split_dates[r['order_id']]>=SPLIT])
                ids = {r['order_id'] for r in scope}
                cohorts[f'{frame}/{route}'] = {}
                for rule in RULES:
                    allowed = {ident for ident in ids if contexts[ident]['gates'][rule]}
                    portfolio = [o for o in orders if o.id in allowed]
                    result = replay_portfolio(portfolio,bars,spec,end,config['initial_equity'],risk,spread_multiplier=spread)
                    if rule=='baseline':
                        expected = source['scenarios'][fees]['continuous_accounts'][f'{frame}/{route}']
                        if iso_json(result)!={k:v for k,v in expected.items() if k!='decision_counts'}:
                            raise AssertionError(f'Frozen account replay differs: {fees}/{frame}/{route}')
                    cohorts[f'{frame}/{route}'][rule] = dict(signal_count=len(allowed),
                        independent={cut:evaluate_cohort(rows,allowed,signals) for cut,rows in by_cut.items()},
                        continuous=compact_account(result))
        comparisons[fees] = cohorts
    sources = (Path(__file__).resolve(), SMC, HARNESS, baseline.OUT,
               ROOT/'research/ict_price_videos/amd/integration.json')
    return dict(symbol=instrument.symbol,server=server,from_ny=first.isoformat(),until_ny=last.isoformat(),
                chronological_split=SPLIT.isoformat(),orders_considered=len(orders),structure=structure_summary,
                causal_context_checks=len(contexts),comparisons=comparisons,context_by_signal=contexts,
                rules=dict(window='After known M reclaim for AMD or A freeze for direct AD, through D confirmation.',
                           continuation_or_flip='Same-frame latest native BOS/CHoCH. Opposed simultaneous tiers mean unresolved.',
                           earlier_structure='Latest BOS/CHoCH strictly before the D confirmation agrees and is still aligned at D.',
                           strong='Native displacement flag on at least one of the latest aligned breaks.',
                           cisd='Direction of the latest native CISD in the same interval.'),
                limitations=['Retrospective cost sensitivity on the same TMGM archive; earlier and later blocks are calendar partitions.',
                             'Settlement reuses frozen M5 spread and execution assumptions. Structure is native indicator geometry.',
                             'No rule promotion, live trade instruction, or new HTF qualification.'],
                inputs={p.relative_to(ROOT).as_posix():digest(p) for p in sources},orders_sent=0)


if __name__=='__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=OUT)
    args = parser.parse_args()
    result = run()
    atomic_json(args.out,result)
    print(result['structure'],result['causal_context_checks'])
    for fees, cohorts in result['comparisons'].items():
        for cohort, rules in cohorts.items():
            print(fees,cohort,{k:(v['signal_count'],v['independent']['all']['selected']['closed'],
                                  v['independent']['all']['selected']['mean_r'],v['continuous']['final_realized_equity'])
                               for k,v in rules.items()})
