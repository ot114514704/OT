"""Collect fixed read-only quote probes and compare them with saved chart bars.

No account orders/history, cost estimation, outcome labels or trade execution.
Equal millisecond timestamps retain their broker-provided sequence.
"""
import argparse
from collections import defaultdict
import csv
from datetime import datetime,timedelta,timezone
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from brooks_ai.types import Tick,utc_time
from brooks_ai.tickbacktest import aggregate_ticks
from scripts.audit_research_history import read_bars


def compare_quotes(ticks,chart,start,end,tick_size):
    """Compare interior engine buckets and retain evidence on spreads/gaps."""
    bars,spans=aggregate_ticks(ticks,900)
    source={b.time:b for b in chart}
    compared=0;mismatches=[];spread_rows=[]
    for b,(lo,hi) in zip(bars,spans):
        saved=source.get(b.time)
        if saved is None:
            continue
        compared+=1
        different=[k for k in ('open','high','low','close') if abs(getattr(b,k)-getattr(saved,k))>tick_size/2+1e-8]
        if different:
            mismatches.append(dict(time=b.time.isoformat(),different_fields=different,
                                   chart={k:getattr(saved,k) for k in ('open','high','low','close')},
                                   ticks={k:getattr(b,k) for k in ('open','high','low','close')}))
        values=sorted(round(t.ask-t.bid,10) for t in ticks[lo:hi])
        spread_rows.append(dict(time=b.time.isoformat(),chart_spread=saved.spread,
                                tick_spread_min=values[0],tick_spread_median=values[len(values)//2],
                                tick_spread_max=values[-1],tick_spread_last=round(ticks[hi-1].ask-ticks[hi-1].bid,10),
                                quotes=hi-lo,zero_spread_quotes=sum(v==0 for v in values)))
    groups=defaultdict(int)
    for t in ticks:
        groups[int(t.time.timestamp())//900*900]+=1
    chart_missing_quotes=[b.time.isoformat() for b in chart if start<=b.time and b.time+timedelta(minutes=15)<=end
                          and int(b.time.timestamp()) not in groups]
    tick_buckets_missing_chart=[datetime.fromtimestamp(k,timezone.utc).isoformat() for k in groups
                                if datetime.fromtimestamp(k,timezone.utc) not in source]
    gaps=[dict(after=a.time.isoformat(),before=b.time.isoformat(),seconds=(b.time-a.time).total_seconds())
          for a,b in zip(ticks,ticks[1:]) if (b.time-a.time).total_seconds()>60]
    all_spreads=sorted(round(t.ask-t.bid,10) for t in ticks)
    return dict(ticks=len(ticks),first_tick=ticks[0].time.isoformat(),last_tick=ticks[-1].time.isoformat(),
                equal_timestamp_pairs=sum(a.time==b.time for a,b in zip(ticks,ticks[1:])),
                interior_m15_buckets=len(bars),ohlc_compared=compared,ohlc_mismatches=mismatches,
                ohlc_matches=compared-len(mismatches),chart_buckets_without_quotes=chart_missing_quotes,
                tick_buckets_without_chart=tick_buckets_missing_chart,quote_gaps_over_60_seconds=gaps,
                spread_summary={'min':all_spreads[0],'median':all_spreads[len(all_spreads)//2],
                                'max':all_spreads[-1],'zero_quotes':sum(v==0 for v in all_spreads)},
                bar_spread_comparison=spread_rows,
                exact_path_complete=False,
                limitation='Matching OHLC only validates extrema/endpoints; it does not prove every original quote, historical execution or session-calendar completeness.')


def fetch_period(api,symbol,start,end,identity,maximum):
    ticks=[];chunks=[];cursor=start
    epoch=datetime(1970,1,1,tzinfo=timezone.utc)
    while cursor<end:
        account=api.account_info();terminal=api.terminal_info()
        if account is None or terminal is None or not terminal.connected or (account.login,account.server)!=identity:
            raise RuntimeError('Account/server changed or disconnected')
        until=min(end,cursor+timedelta(hours=6))
        raw=api.copy_ticks_range(symbol,cursor,until,api.COPY_TICKS_INFO)
        if raw is None:
            raise RuntimeError('Tick request failed: '+str(api.last_error()))
        count=0
        for row in raw:
            timestamp=epoch+timedelta(milliseconds=int(row['time_msc']))
            if not cursor<=timestamp<until:
                continue
            quote=Tick(timestamp,float(row['bid']),float(row['ask']))
            if ticks and quote.time<ticks[-1].time:
                raise ValueError('Broker quote order decreased; data not sorted or repaired')
            ticks.append(quote);count+=1
            if len(ticks)>maximum:
                raise ValueError('Probe exceeds predeclared quote limit; no partial file committed')
        chunks.append(dict(start=cursor.isoformat(),end_exclusive=until.isoformat(),ticks=count))
        print(json.dumps({'chunk_end':until.isoformat(),'ticks':count,'total_ticks':len(ticks)}),flush=True)
        cursor=until
    account=api.account_info();terminal=api.terminal_info()
    if account is None or terminal is None or not terminal.connected or (account.login,account.server)!=identity:
        raise RuntimeError('Account/server changed before quote commit')
    return ticks,chunks


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--plan',default='research/tick_audit_plan.json')
    p.add_argument('--out-dir',required=True)
    p.add_argument('--terminal',default='C:/Program Files/MetaTrader 5/terminal64.exe')
    args=p.parse_args()
    plan_path=Path(args.plan);plan=json.loads(plan_path.read_text(encoding='utf-8'))
    root=ROOT/plan['bar_snapshot'];meta=json.loads((root/'provenance.json').read_text(encoding='utf-8'))
    dataset=next(d for d in meta['datasets'] if d['timeframe']=='M15')
    data=Path(dataset['data_path'])
    if hashlib.sha256(data.read_bytes()).hexdigest()!=dataset['data_sha256']:
        raise ValueError('Chart snapshot changed')
    chart=read_bars(data);point=meta['current_symbol_observation']['trade_tick_size']
    out=Path(args.out_dir)
    if out.exists():raise ValueError('Use a new output directory')
    now=datetime.now(timezone.utc)
    seen=set()
    for period in plan['periods']:
        start,end=utc_time(period['from']),utc_time(period['to'])
        if not re.fullmatch('[a-z][a-z0-9_]*',period['id']) or period['id'] in seen or not start<end<=now:
            raise ValueError('Invalid fixed probe period')
        seen.add(period['id'])
    report=dict(started_at_utc=now.isoformat(),plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),
                bar_data_sha256=dataset['data_sha256'],symbol=plan['symbol'],synthetic=False,
                orders_sent=0,research_only=True,costs_verified=False,periods=[],
                api_documentation='https://www.mql5.com/en/docs/python_metatrader5/mt5copyticksrange_py')
    out.mkdir(parents=True)
    import MetaTrader5 as api
    try:
        if not api.initialize(args.terminal,timeout=10000):raise RuntimeError(str(api.last_error()))
        account,terminal=api.account_info(),api.terminal_info()
        if account is None or terminal is None or not terminal.connected or account.server!=meta['server']:
            raise RuntimeError('Connected broker server must match chart snapshot')
        identity=(account.login,account.server)
        report.update(server=account.server,company=account.company,trade_mode=account.trade_mode,api_version=api.__version__)
        for period in plan['periods']:
            start,end=utc_time(period['from']),utc_time(period['to'])
            entry={**period,'status':'pending'}
            try:
                ticks,chunks=fetch_period(api,plan['symbol'],start,end,identity,plan['max_ticks_per_period'])
                entry['chunks']=chunks
                if not ticks:
                    entry.update(status='no_quotes',ticks=0,
                                 interpretation='Empty response does not establish that the market was closed')
                else:
                    analysis=compare_quotes(ticks,chart,start,end,point)
                    target=out/(period['id']+'.csv')
                    with target.open('w',encoding='utf-8',newline='') as f:
                        w=csv.writer(f);w.writerow(['time','bid','ask'])
                        w.writerows((t.time.isoformat(),t.bid,t.ask) for t in ticks)
                    sidecar=dict(synthetic=False,provider='MT5 COPY_TICKS_INFO',server=account.server,
                                 symbol=plan['symbol'],requested_from_utc=start.isoformat(),
                                 requested_to_exclusive_utc=end.isoformat(),ticks=len(ticks),chunks=chunks,
                                 data_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                                 downloaded_at_utc=datetime.now(timezone.utc).isoformat(),
                                 costs_verified=False,coverage_verified=False,
                                 equal_timestamps='Retained in broker response order; no sorting or deduplication')
                    Path(str(target)+'.provenance.json').write_text(json.dumps(sidecar,ensure_ascii=False,indent=2),encoding='utf-8')
                    entry.update(status='collected',data_path=str(target.resolve()),
                                 data_sha256=sidecar['data_sha256'],analysis=analysis)
                print(json.dumps({'period':period['id'],'status':entry['status'],
                                  'ticks':len(ticks),'ohlc_compared':entry.get('analysis',{}).get('ohlc_compared'),
                                  'ohlc_mismatches':len(entry.get('analysis',{}).get('ohlc_mismatches',[]))}),flush=True)
            except Exception as exc:
                entry.update(status='failed',error=f'{type(exc).__name__}: {exc}')
                print(json.dumps({'period':period['id'],'error':entry['error']}),flush=True)
            report['periods'].append(entry)
        report['status']='finished'
    except Exception as exc:
        report.update(status='failed',error=f'{type(exc).__name__}: {exc}')
    finally:
        api.shutdown()
        report['finished_at_utc']=datetime.now(timezone.utc).isoformat()
        (out/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'audit':str((out/'audit.json').resolve()),'status':report['status']}))
    return 0 if report['status']=='finished' else 1


if __name__=='__main__':raise SystemExit(main())
