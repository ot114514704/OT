"""Refine same-M5 target outcomes with independently archived M1 candles."""
from bisect import bisect_left
from datetime import datetime, timedelta

from brooks_ai.types import Bar

M1 = timedelta(minutes=1)
M5 = 5 * M1


def edge(target, sweep):
    if sweep:
        return target['hi'] if target['side'] > 0 else target['lo']
    return target['lo'] if target['side'] > 0 else target['hi']


class MinuteOrder:
    def __init__(self, minute_records, five_minute_bars):
        self.minutes = [Bar(datetime.fromisoformat(t), o, h, l, c, 0)
                        for t,o,h,l,c in minute_records]
        self.minute_times = [b.time for b in self.minutes]
        if self.minute_times != sorted(set(self.minute_times)):
            raise ValueError('M1 archive contains unordered or duplicate bar times')
        self.five = {b.time:b for b in five_minute_bars}

    def reconciled_minutes(self, end):
        start = end-M5
        five = self.five.get(start)
        index = bisect_left(self.minute_times,start)
        parts = self.minutes[index:index+5]
        if five is None or [b.time for b in parts] != [start+i*M1 for i in range(5)]:
            return None
        minute_candle = (parts[0].open,max(b.high for b in parts),
                         min(b.low for b in parts),parts[-1].close)
        five_candle = (five.open,five.high,five.low,five.close)
        if minute_candle != five_candle:
            return None
        return parts

    def refine(self, targets, events, first, *, sweep, unresolved=None):
        indexes = [i for i, hit in enumerate(first) if hit]
        if len(indexes)<=1:
            return indexes,'m5_unique' if indexes else 'no_event'
        if len({(targets[i]['side'],edge(targets[i],sweep)) for i in indexes}) == 1:
            return indexes,'shared_boundary'
        end = datetime.fromisoformat(events[indexes[0]])
        parts = self.reconciled_minutes(end)
        if parts is None:
            five = self.five.get(end-M5)
            if unresolved is not None and five is not None:
                record_probe(unresolved,five,targets,indexes,sweep,300)
            return indexes,'unreconciled_m1'
        times = {i: first_minute(parts,targets[i],sweep) for i in indexes}
        if None in times.values():
            if unresolved is not None:
                record_probe(unresolved,self.five[end-M5],targets,indexes,sweep,300)
            return indexes,'unwitnessed_boundary'
        earliest = min(times.values())
        leaders = [i for i in indexes if times[i]==earliest]
        if len(leaders)==1:
            return leaders,'m1_unique'
        if len({(targets[i]['side'],edge(targets[i],sweep)) for i in leaders})==1:
            return leaders,'m1_shared_boundary'
        if unresolved is not None:
            bar = next(b for b in parts if b.time==earliest)
            record_probe(unresolved,bar,targets,leaders,sweep,60)
        return leaders,'m1_tied'


def record_probe(result,bar,targets,indexes,sweep,seconds):
    result.update(open_at=bar.time.isoformat(),duration=seconds,ohlc=[bar.open,bar.high,bar.low,bar.close],
                  boundaries=[(i,targets[i]['side'],edge(targets[i],sweep)) for i in indexes])


def first_minute(parts,target,sweep):
    level = edge(target,sweep)
    for bar in parts:
        if sweep:
            crossed = bar.high > level if target['side'] > 0 else bar.low < level
            if not crossed:
                continue
            # A gap past the far edge cannot establish a witnessed sweep.
            return bar.time if bar.low <= level <= bar.high else None
        if bar.low <= level <= bar.high:
            return bar.time
    return None
