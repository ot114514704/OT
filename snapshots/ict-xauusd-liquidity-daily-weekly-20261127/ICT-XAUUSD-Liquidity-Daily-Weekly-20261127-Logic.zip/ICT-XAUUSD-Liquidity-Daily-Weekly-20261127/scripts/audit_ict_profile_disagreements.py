"""Explain positive-label disagreements using raw, closed M5 candles."""
from argparse import ArgumentParser
from datetime import date, datetime, time, timedelta
import json
from pathlib import Path

from ict_ai.profile_lifecycle import _day_bounds, _extension, _reclaim
from ict_ai.timebase import NY, session_windows
from ict_ai.weekly_path import consolidation_evidence
from scripts.replay_ict_news import STEP
from scripts.replay_ict_route_checkpoints import merge_history


def section(quotes, start, end):
    return [bar for stamp, bar in quotes.items() if start <= stamp and stamp + STEP <= end]


def ohlc(bars):
    return {"open": bars[0].open, "high": max(bar.high for bar in bars),
            "low": min(bar.low for bar in bars), "close": bars[-1].close}


def known_at(bar):
    return (bar.time + STEP).astimezone(NY).isoformat() if bar else None


def classical(quotes, day, direction):
    windows = session_windows(day)
    asia, london, ny = [section(quotes, *windows[name]) for name in ("asia", "london", "new_york")]
    bullish = direction == "bullish"
    side = 1 if bullish else -1
    swept, opposite = ("low", "high") if bullish else ("high", "low")
    a, l = ohlc(asia), ohlc(london)
    take = side * (a[swept] - l[swept]) > 0
    london_reclaim = _reclaim(london, a[swept], -side, STEP)
    ny_reclaim = next((bar for bar in ny if take and side * (bar.close - a[swept]) > 0), None)
    ny_extension = (_extension(ny, l[opposite], side, STEP, ny_reclaim.time)
                    if ny_reclaim is not None else None)
    _, end = _day_bounds(day)
    if day.weekday() == 4:
        end = datetime.combine(day, time(16, 55), NY)
    rest = section(quotes, windows["london"][1], end)
    london_extreme_held = all(side * (getattr(bar, swept) - l[swept]) >= 0 for bar in rest)
    final_close = rest[-1].close
    return {"asia": a, "london": l, "london_swept_asia": take,
            "london_reclaim_known_at": known_at(london_reclaim),
            "ny_reclaim_known_at": known_at(ny_reclaim),
            "ny_two_close_extension_known_at": known_at(ny_extension),
            "london_extreme_held_after_london": london_extreme_held, "day_close": final_close,
            "late_reclaim_trial_price_criteria": take and london_reclaim is None and ny_extension is not None
            and london_extreme_held and side * (final_close - l[opposite]) > 0}


def weekly(quotes, monday):
    days = []
    for i in range(5):
        day = monday + timedelta(days=i)
        start, end = _day_bounds(day)
        if i == 4:
            end = datetime.combine(day, time(16, 55), NY)
        days.append(ohlc(section(quotes, start, end)))
    return {"ny_mon_to_fri": days, "first_three_days_overlap": consolidation_evidence(days[:3]),
            "first_four_days_overlap": consolidation_evidence(days[:4])}


def create(comparison, key, early, late):
    quotes, sources, _, _ = merge_history(early, late)
    if sources != key["sources"] or comparison["chart_sha256"] != key["chart_sha256"]:
        raise ValueError("Review must refer to the same charts and source candles")
    cases = []
    for row in comparison["cases"]:
        missing = [label for label in row["reviewed"] if label not in row["close_review"]["labels"]]
        day = date.fromisoformat(row["date"])
        for label in missing:
            if row["period"] == "weekly":
                evidence = weekly(quotes, day)
            elif label[0] in ("classic_buy", "classic_sell_mirror"):
                evidence = classical(quotes, day, label[1])
            else:
                continue
            cases.append({"date": row["date"], "period": row["period"], "label_in_review": label,
                          "close_model": row["close_review"], "price_evidence": evidence})
    return {"scope": "Disputed positive path diagnoses with closed raw candles. A trial criterion is descriptive, "
                     "not a validated pattern or an entry setup.", "sources": sources, "cases": cases}


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    for option in ("comparison", "key", "early", "late", "out"):
        cli.add_argument(f"--{option}", type=Path, required=True)
    args = cli.parse_args()
    comparison = json.loads(args.comparison.read_bytes())
    key = json.loads(args.key.read_bytes())
    report = create(comparison, key, args.early, args.late)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
