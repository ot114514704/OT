"""Follow frozen ICT price references through sequential NY news windows."""
import argparse
from collections import Counter
from datetime import timedelta
from hashlib import sha256
import json
from pathlib import Path

from brooks_ai.types import utc_time
from ict_ai.timebase import NY, require_replay_clock, session_windows
from scripts.replay_ict_news import ROOT, RULES, STEP, block, extent, load_history


PHASES = (("release_0_to_30m", 0, 6), ("follow_up_30_to_60m", 6, 6))


def freeze_references(bars, at):
    midnight = at.astimezone(NY).replace(hour=0, minute=0)
    asia_start, asia_end = session_windows(midnight.date())["asia"]
    candidates = {
        "last_30m": (at - 6 * STEP, at),
        "ict_asia": (asia_start, asia_end),
        "since_ny_midnight": (midnight, at),
    }
    references = {}
    for label, (start, end) in candidates.items():
        if not start < end <= at:
            continue
        source = block(bars, start, (end - start) // STEP)
        if source is None:
            continue
        low, high = extent(source)
        if high <= low:
            continue
        intervening = block(bars, end, (at - end) // STEP)
        first_seen = {}
        for bar in intervening or ():
            for side in crossed_sides((bar,), low, high):
                first_seen.setdefault(side, (bar.time + STEP).astimezone(NY).isoformat())
        references[label] = {
            "low": low, "high": high, "range_start_ny": start.astimezone(NY).isoformat(),
            "range_known_at_ny": end.astimezone(NY).isoformat(),
            "first_observed_cross_before_release_known_at_ny": dict(sorted(first_seen.items())),
            "before_release_coverage_complete": intervening is not None,
            "last_pre_close": bars[at - STEP].close,
        }
    return references


def crossed_sides(rows, low, high):
    return {side for bar in rows for side, crossed in (
        ("buy", bar.high > high), ("sell", bar.low < low)) if crossed}


def phase_path(rows, reference, prior_sides):
    low, high = reference["low"], reference["high"]
    breaks, reclaims = {}, {}
    outside_closes = []
    for bar in rows:
        known = (bar.time + STEP).astimezone(NY).isoformat()
        for side in crossed_sides((bar,), low, high):
            breaks.setdefault(side, known)
        if "buy" in breaks and bar.close < high:
            reclaims.setdefault("buy", known)
        if "sell" in breaks and bar.close > low:
            reclaims.setdefault("sell", known)
        outside_closes.append("buy" if bar.close > high else "sell" if bar.close < low else None)
    # Sort explicitly for deterministic output if a candle exceeds both sides.
    breaks = dict(sorted(breaks.items()))
    terminal = outside_closes[-1]
    held = terminal if outside_closes[-2:] == [terminal, terminal] else None
    return {
        "first_cross_in_phase_known_at_ny": breaks,
        "first_cross_since_reference_freeze_known_at_ny": (
            {side: known for side, known in breaks.items() if side not in prior_sides}
            if prior_sides is not None else None
        ),
        "repeated_cross_sides": sorted(set(breaks).intersection(prior_sides)) if prior_sides is not None else None,
        "first_close_back_across_crossed_boundary_known_at_ny": reclaims,
        "both_sides_crossed": len(breaks) == 2,
        "first_crosses_same_bar_intrabar_order_unknown": len(breaks) == 2 and len(set(breaks.values())) == 1,
        "terminal_close_outside_side": terminal,
        "terminal_two_closes_outside_side": held,
        "phase_close_price": rows[-1].close,
    }


def phase_detail(bars, at, references, offset, count):
    start, end = at + offset * STEP, at + (offset + count) * STEP
    rows = block(bars, start, count)
    if rows is None:
        return None
    intervening = block(bars, at, offset)
    observations = {}
    for label, reference in references.items():
        before = reference["first_observed_cross_before_release_known_at_ny"]
        prior = (set(before) | crossed_sides(intervening, reference["low"], reference["high"])
                 if reference["before_release_coverage_complete"] and intervening is not None else None)
        observations[label] = phase_path(rows, reference, prior)
    floor, ceiling = extent(rows)
    return {
        "start_ny": start.astimezone(NY).isoformat(), "known_at_ny": end.astimezone(NY).isoformat(),
        "high_minus_low": round(ceiling - floor, 8), "references": observations,
    }


def window(bars, original, announcements):
    at = utc_time(original["at_utc"]).astimezone(NY)
    references = freeze_references(bars, at)
    short = references.get("last_30m")
    if short is None or (short["low"], short["high"]) != (original["pre_low"], original["pre_high"]):
        raise ValueError(f"Frozen pre-release range mismatch at {at}")
    pre = {t: b for t, b in bars.items() if t < at and t >= at - timedelta(days=1)}
    if freeze_references(pre, at) != references:
        raise AssertionError(f"Future candles changed frozen references at {at}")
    checks = 1
    phases = {}
    for phase, offset, count in PHASES:
        detail = phase_detail(bars, at, references, offset, count)
        if detail is None:
            raise ValueError(f"Missing bars in source report's complete news window at {at}")
        start = offset * 5
        phase_announcements = [item for item in announcements if start <= item["minute_offset"] < start + count * 5]
        phases[phase] = {**detail, "recorded_announcements": phase_announcements}
        for early_count in range(1, count + 1):
            end = at + (offset + early_count) * STEP
            clipped = {t: b for t, b in bars.items() if at <= t < end}
            if phase_detail(bars, at, references, offset, early_count) != phase_detail(
                    clipped, at, references, offset, early_count):
                raise AssertionError(f"Future candles changed phase detail at {end}")
            checks += 1
    return {"at_ny": at.isoformat(), "references": references, "phases": phases, "prefix_checks": checks}


def summarize(windows):
    result = {}
    for name, *_ in PHASES:
        paths = [row["phases"][name]["references"] for row in windows]
        counts = {}
        for label in ("last_30m", "ict_asia", "since_ny_midnight"):
            observed = [path[label] for path in paths if label in path]
            counts[label] = {
                "covered": len(observed),
                "unknown_prior_coverage": sum(x["repeated_cross_sides"] is None for x in observed),
                "with_first_cross_since_freeze": sum(bool(x["first_cross_since_reference_freeze_known_at_ny"]) for x in observed),
                "with_repeated_cross": sum(bool(x["repeated_cross_sides"]) for x in observed),
                "both_sides_crossed": sum(x["both_sides_crossed"] for x in observed),
                "terminal_two_closes_outside_side": dict(Counter(
                    x["terminal_two_closes_outside_side"] or "neither" for x in observed)),
            }
        result[name] = counts
    return result


def study(path):
    raw = path.read_bytes()
    source = json.loads(raw)
    meta, digest, bars = load_history(Path(source["source_manifest"]))
    require_replay_clock(meta, source)
    if digest != source["source_m5_sha256"]:
        raise ValueError("M5 snapshot differs from the original news study")
    releases, controls = [], {}
    for episode in source["comparisons"]:
        release = window(bars, episode["news"], episode["known_announcements_in_window"])
        matched = []
        for original in episode["same_clock_comparison"]:
            stamp = original["at_ny"]
            if stamp not in controls:
                controls[stamp] = window(bars, original, [])
            matched.append(stamp)
        releases.append({**release, "event": episode["event"], "source": episode["source"],
                         "matched_control_times_ny": matched})
    return {
        "news_report": str(path), "news_report_sha256": sha256(raw).hexdigest(),
        "m5_sha256": digest, "summary": {
            "all_releases": summarize(releases),
            "matched_releases": summarize([r for r in releases if r["matched_control_times_ny"]]),
            "unique_controls": summarize(controls.values()),
        },
        "prefix_checks": sum(row["prefix_checks"] for row in [*releases, *controls.values()]),
        "releases": releases, "controls": list(controls.values()),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, action="append", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    studies = [study(path) for path in args.report]
    report = {
        "lesson": json.loads(RULES.read_bytes())["source_chain"][:3],
        "reference_rule": "Asia is NY 20:00–00:00. Each range and crossed sides up to the release are frozen.",
        "confirmation_rule": "Strict wick cross; close back across that boundary; separately, two terminal closes beyond one boundary.",
        "phase_rule": "Use half-open intervals of bar opens. FOMC 14:30 press conference begins in the second phase.",
        "limits": [
            "Terminal two-close proxy is geometric follow-through, not a trade or a proven expansion day.",
            "A wick crossing is a Bid price observation. Actual stop orders, depth and causal announcements are unverified.",
            "Calendar and clock limitations and matching decisions are inherited from each input news report.",
            "Original 30-minute boundaries stay fixed in the second phase. First means first observed after range completion.",
        ],
        "script_sha256": {p.relative_to(ROOT).as_posix(): sha256(p.read_bytes()).hexdigest()
                          for p in (Path(__file__).resolve(), ROOT / "scripts/replay_ict_news.py", RULES)},
        "studies": studies, "execution_allowed": False, "orders_sent": 0,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for item in studies:
        print(item["news_report"], len(item["releases"]), len(item["controls"]), item["prefix_checks"])
