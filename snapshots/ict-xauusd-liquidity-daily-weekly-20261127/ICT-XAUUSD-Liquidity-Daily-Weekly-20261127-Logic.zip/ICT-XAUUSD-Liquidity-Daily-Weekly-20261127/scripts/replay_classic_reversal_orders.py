"""Continuous, offline paper execution of initial and replacement 1.1 price setups."""
from argparse import ArgumentParser
from collections import Counter
from dataclasses import asdict, replace
from datetime import timedelta
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path

from brooks_ai.types import Instrument, utc_time
from ict_ai.backtest import LimitStudyOrder
from ict_ai.portfolio import replay_portfolio
from ict_ai.profile_lifecycle import _reclaim, _extension, daily_profile_lifecycle
from ict_ai.timebase import NY, session_windows
from scripts.audit_classic_reversal import replacement_events
from scripts.backtest_ict_motifs import COST_SCENARIOS
from scripts.export_mt5_profiles import midnight
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_news import ROOT, STEP
from scripts.replay_ict_route_checkpoints import merge_history


def day_signals(day, context, cutoff):
    start=midnight(day)
    windows=session_windows(day)
    noon=windows["london_close"][1]
    through=min(cutoff,noon)
    available=[b for b in context if b.time+STEP<=through]
    today=[b for b in available if b.time>=start]
    # A later gap cannot undo a signal already known; stop advancing at the first gap.
    for i,b in enumerate(today):
        if b.time!=start+i*STEP:
            today=today[:i]
            break
    if not today:
        return []
    through=today[-1].time+STEP
    quarters=aggregate_bars(available,5,15,through)
    def session(key):
        lo,hi=windows[key]
        return [b for b in quarters if lo<=b.time and b.time+3*STEP<=hi]
    london,ny=session("london"),session("new_york")
    if not london or not ny:
        return []
    low,high=min(b.low for b in london),max(b.high for b in london)
    signals=[]
    def add(kind,side,at,origin,entry,pivot):
        signals.append({"id":f"1.1/{kind}/{side}/{at.isoformat()}","kind":kind,"side":side,
                        "at":at,"reclaim":origin,"entry":entry,"pivot":pivot})
    for side,swept,opposite in ((1,low,high),(-1,high,low)):
        reclaim=_reclaim(ny,swept,-side,3*STEP)
        if reclaim is None:
            continue
        known=reclaim.time+3*STEP
        frozen=daily_profile_lifecycle(quarters,day,known,include_reconstruction=False,reference_m5=available)
        if not any(c["id"]=="classic_reversal_variant" and c["direction"]==side and
                   c["status"]=="active" and c["observed_sequence"] for c in frozen["candidates"]):
            continue
        def extreme(rows):
            return min(b.low for b in rows) if side==1 else max(b.high for b in rows)
        prefix=[b for b in today if b.time+STEP<=known]
        pivot=extreme([b for b in prefix if b.time>=windows["new_york"][0]])
        follow=_extension(quarters,opposite,side,3*STEP,after=known)
        if follow and pivot==extreme(prefix):
            at=follow.time+3*STEP
            if extreme([b for b in today if b.time+STEP<=at])==pivot:
                add("initial",side,at,known,opposite,pivot)
        pivots={}
        for e in replacement_events(today,quarters,known,noon,side,swept,opposite):
            if e["kind"]=="reclaim":
                pivots[e["pivot_at"]]=e["price"]
            elif e["kind"]=="follow":
                add("replacement",side,utc_time(e["at"]),utc_time(e["pivot_at"]),opposite,pivots[e["pivot_at"]])
    return sorted(signals,key=lambda s:(s["at"],s["id"]))


def run(early,late):
    quotes,sources,_,cutoff=merge_history(early,late)
    bars=list(quotes.values())
    meta=json.loads(late.read_bytes())
    info=meta["current_symbol_observation"]
    spec=Instrument(meta["symbol"],info["point"],info["trade_tick_size"],info["trade_contract_size"],
                    info["volume_min"],info["volume_step"],info["volume_max"],
                    account_currency=meta["account_currency"],profit_currency=info["currency_profit"])
    config_path=ROOT/"config/strategy.json"
    config=json.loads(config_path.read_bytes())
    risk={k:config[k] for k in ("risk_fraction","daily_loss_limit","max_drawdown","max_consecutive_losses")}
    days=sorted({b.time.astimezone(NY).date() for b in bars if b.time.astimezone(NY).weekday()<5})
    signals=[]
    checks=0
    for day in days:
        window=session_windows(day)
        context=[b for b in bars if window["asia"][0]<=b.time<window["london_close"][1]]
        observed=day_signals(day,context,cutoff)
        # Independently clip history on every decision bar, including days with no signal.
        at=window["new_york"][0]
        while at<=min(cutoff,window["london_close"][1]):
            prefix=[b for b in context if b.time+STEP<=at]
            if day_signals(day,prefix,at)!=[s for s in observed if s["at"]<=at]:
                raise AssertionError(f"Signal changed after {at}")
            checks+=1
            at+=3*STEP
        signals.extend(observed)
    orders=[]
    tick=Decimal(str(spec.tick_size))
    for s in signals:
        entry,side=Decimal(str(s["entry"])),s["side"]
        stop=(round(Decimal(str(s["pivot"]))/tick)-side)*tick
        target=round((entry+2*(entry-stop))/tick)*tick
        orders.append(LimitStudyOrder(s["id"],side,s["at"],s["at"]+timedelta(minutes=90),
                                      float(entry),float(stop),float(target),spec.volume_min))
    templates={o.id:o for o in orders}
    portfolios={}
    for name,commission,slippage,multiplier in COST_SCENARIOS:
        cost=replace(spec,commission_round_turn=commission,slippage=slippage)
        portfolios[name]=replay_portfolio(orders,bars,cost,cutoff,config["initial_equity"],risk,
                                          spread_multiplier=multiplier)
        for decision in portfolios[name]["decisions"]:
            order=templates[decision["id"]]
            decision["minimum_volume_stop_risk"]=(cost.contract_size*(abs(order.entry-order.stop)+2*slippage)
                                                 +commission)*cost.volume_min
    return {"quote_sources":sources,"through":cutoff,"observed_trading_dates":len(days),
            "prefix_checks":checks,"signal_counts":dict(Counter(s["kind"] for s in signals)),
            "signals":signals,"orders":[asdict(o) for o in orders],"instrument":asdict(spec),
            "risk_config_sha256":sha256(config_path.read_bytes()).hexdigest(),
            "code_sha256":{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in (
                Path(__file__).resolve(),ROOT/"scripts/audit_classic_reversal.py",ROOT/"ict_ai/profile_lifecycle.py",
                ROOT/"ict_ai/portfolio.py",ROOT/"ict_ai/backtest.py",ROOT/"brooks_ai/risk.py")},
            "cost_scenarios":COST_SCENARIOS,"portfolios":portfolios,
            "rules":"Initial/replacement day extreme, two later M15 closes beyond the opposite London edge "
                    "by noon NY while the extreme holds. Bid-price edge retest limit for 90 minutes, "
                    "one tick beyond pivot stop, 2R target, 16:50 NY flatten. Risk resized per scenario.",
            "limits":"Post-hoc research on existing sample. As-of course price path only; HTF bias, queue, "
                     "historical fees and executable ticks unverified. No daily close used for admission.",
            "execution_allowed":False,"orders_sent":0}


if __name__=="__main__":
    cli=ArgumentParser(description=__doc__)
    for name in ("early","late","out"):
        cli.add_argument("--"+name,type=Path,required=True)
    args=cli.parse_args()
    report=run(args.early,args.late)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2,default=lambda t:t.isoformat())+"\n",
                        encoding="utf-8")
    print(report["observed_trading_dates"],report["signal_counts"],report["prefix_checks"])
