"""Audit live liquidity registration delays against immutable chart receipts and Bid tapes."""

from argparse import ArgumentParser
from collections import Counter
from contextlib import closing
from datetime import datetime, timedelta
import json
import sqlite3
from statistics import median
from time import monotonic, sleep

from ict_ai.dol_history import batch_id, chart_receipts
from scripts import watch_ict_liquidity_filter_accuracy as live
from scripts import watch_ict_liquidity_first_sweep as rank
from scripts import watch_ict_micro_liquidity_forward as micro
from scripts import watch_ict_micro_liquidity_all_m5 as all_m5
from scripts.audit_ict_bridge_latency import COMMON, DIRECTORY, RECEIPT_PRECISION, measured


OUT = rank.history.STUDY.RESEARCH / 'ict_liquidity_registration_audit_20261125.json'
INGESTION = OUT.with_name('ict_liquidity_receipt_ingestion_20261125.json')


def phases(targets, tape, cutoff, acknowledged, ready):
    result = Counter()
    events = []
    start = micro.utc_ms(cutoff)
    chart_min = micro.utc_ms(acknowledged - RECEIPT_PRECISION)
    chart_max = micro.utc_ms(acknowledged)
    available = micro.utc_ms(ready)
    for target in targets:
        kind, stamp = micro.outcome(target, tape, cutoff - timedelta(milliseconds=1))
        if stamp is None:
            result['not_crossed'] += 1
            continue
        if stamp <= start:
            phase = 'at_cutoff'
        elif stamp < chart_min:
            phase = 'before_chart'
        elif stamp <= chart_max:
            phase = 'chart_second_uncertain'
        elif stamp <= available:
            phase = 'after_chart_before_registration'
        else:
            phase = 'after_registration'
        result[f'{phase}/{kind}'] += 1
        events.append(dict(side=target['side'], edge=live.quotes.far(target), kind=kind, phase=phase, bid_ms=stamp))
    return dict(targets=len(targets), counts=result, events=events)


def audit_family(watcher):
    is_ranking = watcher is rank
    policy = rank.load_policy(persist=False) if is_ranking else micro.freeze_or_load()
    official = watcher.status(policy, verify=True)
    rows, tapes = [], {}
    for path in sorted((watcher.OUT / 'settlements').glob('*.json')):
        saved = micro.read(path)
        grade = saved['result'] if is_ranking else saved
        if grade['state'] != 'scored':
            continue
        receipt_path = watcher.OUT / 'receipts' / f'{path.stem.split("_", 1)[0]}.json'
        board_path = watcher.OUT / 'boards' / receipt_path.name
        raw, receipt = micro.read(board_path), micro.read(receipt_path)
        cutoff, chart, ready = (datetime.fromisoformat(value) for value in
                                (raw['cutoff'], raw['chart_receipt'], receipt['available_at']))
        buckets = saved['market_buckets']
        tape = micro.reconcile(buckets)
        if not tape:
            raise ValueError(f'Published score lacks reconciled Bid evidence: {path}')
        if is_ranking:
            pools = raw['pools']
            picks = raw['horizons'][saved['horizon']]['picks']
            groups = {'IRL': pools, **{f'pick/{name}': [pools[i]] for name, i in picks.items()}}
        else:
            groups = {f'{scheme}/{scope}': pools for scheme in ('baseline', 'early')
                      for scope, pools in raw[scheme].items()}
        rows.append(dict(cutoff=raw['cutoff'], chart_receipt=raw['chart_receipt'], registered=ready.isoformat(),
                         horizon=saved['horizon'], board_ready_seconds=(ready-cutoff).total_seconds(),
                         chart_upper_to_ready_seconds=(ready-chart).total_seconds(),
                         raw_ticks=sum(len(ticks) for _, ticks in tape), settlement_sha256=rank.digest(path),
                         groups={name: phases(targets, tape, cutoff, chart, ready) for name, targets in groups.items()}))
        tapes[raw['cutoff'], saved['horizon']] = buckets
    return dict(status=official, scored=rows), tapes


def audit_every_m5():
    policy = all_m5.load_policy()
    official = all_m5.status(policy, verify=True)
    observed = datetime.fromisoformat(official['observed_at'])
    rows = []
    totals = {f'{scheme}/{scope}': Counter() for scheme in ('baseline', 'early') for scope in micro.board.SCOPES}
    for receipt in sorted((all_m5.OUT / 'receipts').glob('*.json')):
        raw, cutoff, ready = all_m5.load_board(policy, receipt)
        if ready > observed:
            continue
        chart = datetime.fromisoformat(raw['chart_receipt'])
        row = dict(cutoff=cutoff.isoformat(), chart_receipt=chart.isoformat(), registered=ready.isoformat(),
                   close_to_receipt=(chart-cutoff).total_seconds(), receipt_to_registered=(ready-chart).total_seconds(),
                   close_to_registered=(ready-cutoff).total_seconds(), qualifying=raw['potential_sides'])
        publication = DIRECTORY / 'batches' / f'{raw["original_batch"]}.json'
        if publication.exists():
            timing = micro.read(publication)
            if timing['batch'] != raw['original_batch'] or timing['cutoff'] != raw['cutoff']:
                raise ValueError(f'Publication has a different chart batch: {publication.name}')
            record = measured(timing, chart)
            if record['state'] == 'acknowledged':
                row['publication_seconds'] = record['seconds']
        saved = all_m5.OUT / 'settlements' / receipt.name
        row['state'] = 'pending'
        if cutoff + all_m5.M5 <= observed and saved.exists():
            settled = micro.read(saved)
            row['state'] = settled['state']
            if row['state'] == 'scored':
                evidence = all_m5.OUT / 'bid' / receipt.with_suffix('.json.gz').name
                if settled['receipts_sha256'] != rank.digest(receipt) or settled['bid_sha256'] != rank.digest(evidence):
                    raise ValueError(f'Settlement has different timing evidence: {receipt.name}')
                tape = micro.reconcile(micro.board.joint.read_zip(evidence))
                if not tape:
                    raise ValueError(f'Settlement has no reconciled Bid evidence: {receipt.name}')
                groups = {}
                for scheme in ('baseline', 'early'):
                    for scope, pools in raw[scheme].items():
                        name = f'{scheme}/{scope}'
                        unique = {all_m5.expiry.outer(pool): pool for pool in pools}
                        groups[name] = phases(unique.values(), tape, cutoff, chart, ready)
                        totals[name].update(groups[name]['counts'])
                row['groups'] = groups
        rows.append(row)
    latencies = ('close_to_receipt', 'receipt_to_registered', 'close_to_registered')
    stages = {k: median(row[k] for row in rows) for k in latencies} if rows else {}
    published = [row['publication_seconds'] for row in rows if 'publication_seconds' in row]
    return dict(status=official, registrations=rows, median_seconds=stages,
                publication_samples=len(published),
                median_publication_seconds={key: median(item[key] for item in published) for key in published[0]}
                if published else {}, first_crossing_phases=totals)


def audit():
    ranking, rank_tapes = audit_family(rank)
    four_bar, micro_tapes = audit_family(micro)
    rank_quarters = {at: tape for (at, hz), tape in rank_tapes.items() if hz == '15m'}
    micro_quarters = {at: tape for (at, hz), tape in micro_tapes.items() if hz == 'quarter_hour'}
    common = sorted(rank_quarters.keys() & micro_quarters.keys())
    agreements = {at: rank_quarters[at] == micro_quarters[at] for at in common}
    if not all(agreements.values()):
        raise ValueError('The same cutoff has inconsistent reconciled Bid tapes')
    every_m5 = audit_every_m5()
    report = dict(observed_at=live.now().isoformat(), ranking=ranking, four_bar=four_bar, all_m5=every_m5,
                  matching_quarter_hour_tapes=agreements,
                  method='The chart receipt is an upper second boundary. Sweeps between receipt and durable board availability are diagnostic only.',
                  orders_sent=0)
    live.atomic_json(OUT, report)
    print(json.dumps({key: every_m5[key] for key in ('status', 'median_seconds', 'publication_samples',
                                                   'median_publication_seconds', 'first_crossing_phases')},
                     ensure_ascii=False))
    for label, family in (('ranking', ranking), ('four_bar', four_bar)):
        for row in family['scored']:
            print(label, row['cutoff'], row['horizon'], row['chart_upper_to_ready_seconds'],
                  {name: dict(data['counts']) for name, data in row['groups'].items()})


def receipt_rows(cutoff_iso):
    db = live.quotes.DATABASE.resolve().as_uri() + '?mode=ro'
    with closing(sqlite3.connect(db, uri=True, timeout=2)) as connection:
        return connection.execute('SELECT id,received,payload FROM chart_batches WHERE cutoff=? ORDER BY id',
                                  (cutoff_iso,)).fetchall()


def observe_ingestion(cutoff, timeout):
    """Compare the durable native acknowledgement to its copy in the forecast database."""
    due = monotonic() + timeout
    seen = {}
    while monotonic() < due:
        now = live.now()
        native = chart_receipts(COMMON / 'DOLReceipts', now)
        for key, received, raw in receipt_rows(cutoff.isoformat()):
            ack = native.get(key)
            if ack is None or not cutoff <= ack <= now:
                continue
            payload = json.loads(raw)
            if payload['at'] != cutoff.isoformat() or batch_id(
                cutoff, payload['price'], [payload['targets'], payload['pools']]
            ) != key:
                raise ValueError('Native acknowledgement and staged forecast do not bind to the same batch')
            cell = seen.setdefault(key, dict(batch=key, receipt=ack.isoformat(), first_direct_observation=now.isoformat(),
                                             available_before_database=received is None))
            if received is None:
                continue
            if datetime.fromisoformat(received) != ack:
                raise ValueError('Database copied a different receipt time')
            cell['first_database_copy_observation'] = now.isoformat()
            cell['seconds_between_observations'] = (now-datetime.fromisoformat(cell['first_direct_observation'])).total_seconds()
            return dict(cutoff=cutoff.isoformat(), observations=list(seen.values()), orders_sent=0)
        sleep(1)
    return dict(cutoff=cutoff.isoformat(), observations=list(seen.values()), expired=True, orders_sent=0)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--observe-cutoff', type=datetime.fromisoformat)
    parser.add_argument('--timeout', type=int, default=55)
    args = parser.parse_args()
    if args.observe_cutoff is None:
        audit()
    else:
        cutoff = args.observe_cutoff
        if cutoff.tzinfo is None or cutoff.minute % 5 or cutoff.second or cutoff.microsecond:
            parser.error('Use an aware five-minute cutoff')
        instant = cutoff.astimezone(live.quotes.UTC)
        report = observe_ingestion(instant, args.timeout)
        live.atomic_json(INGESTION, report)
        print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
