"""Freeze the liquidity panel and the archived DOL study on identical closed M5s."""
import argparse
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime, time, timedelta
import gzip
from hashlib import sha256
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from brooks_ai.types import Bar
from ict_ai.dol_history import _deadline
from ict_ai.liquidity_accumulation import liquidity_ranking
from ict_ai.range_liquidity import _Coverage, M5
from ict_ai.timebase import NY

RESEARCH = ROOT / 'output/research'
QUOTES = RESEARCH / 'ranked_dol/TMGM_20261122.json.gz'
DOLS = RESEARCH / 'dol_expansion_20261122/recent_frozen.json.gz'
OUT = RESEARCH / 'pool_dol_20261122'
FROZEN = OUT / 'frozen.json.gz'
LOCK = OUT / 'inputs.json'
MODEL = ROOT / 'ict_ai/liquidity_accumulation.py'


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def read_zip(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def write_zip(path, data):
    raw = json.dumps(data, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
    path.write_bytes(gzip.compress(raw, mtime=0))


def load_bars():
    records = read_zip(QUOTES)['series']['XAUUSDM5']
    bars = [Bar(datetime.fromisoformat(t), o, h, l, c, 0) for t, o, h, l, c in records]
    times = [b.time for b in bars]
    assert times == sorted(set(times))
    return bars, times


def archived_dol(snapshot):
    # Rebuild the locked near12 ordering from the archived components and H1 width.
    rows = [dict(row) for row in snapshot['targets']]
    for side in (-1, 1):
        same_side = [r for r in rows if r['side'] == side]
        nearest = min((r['distance'] for r in same_side), default=None)
        for r in same_side:
            assert 'nearby' not in r['score_components']
            bonus = 12 if r['distance'] == nearest and nearest <= snapshot['median_h1'] / 4 else 0
            r['score'] = min(100, r['score'] + bonus)
    rows.sort(key=lambda r: (-r['score'], r['distance'], r['lo'], r['hi']))
    for rank, row in enumerate(rows, 1):
        row['rank'] = rank
    return rows


def freeze():
    bars, times = load_bars()
    assert digest(QUOTES) == json.loads((QUOTES.parent/'history.json').read_bytes())['archive_sha256']
    snapshots = []
    for s in read_zip(DOLS):
        at = datetime.fromisoformat(s['at'])
        prefix = bars[:bisect_left(times, at)]
        assert prefix[-1].time + M5 == at and prefix[-1].close == s['price']
        dol = archived_dol(s)
        pools = liquidity_ranking(prefix, at, dol)
        snapshots.append(dict(at=s['at'], price=s['price'], pools=pools, dol=dol))
    OUT.mkdir(exist_ok=True, parents=True)
    write_zip(FROZEN, snapshots)
    lock = {p.name: digest(p) for p in (QUOTES, DOLS, MODEL, FROZEN)}
    LOCK.write_text(json.dumps(lock, indent=2), encoding='utf-8')
    print('Frozen:', len(snapshots), flush=True)


def contacts(target, bars, pool):
    lo, hi, side = target['lo'], target['hi'], target['side']
    edge = lo if side > 0 else hi
    entered = swept = None
    for bar in bars:
        touch = bar.low <= hi and bar.high >= lo if pool else bar.low <= edge <= bar.high
        if entered is None and touch:
            entered = (bar.time + M5).isoformat()
        # A gap over the entire zone retires the prediction without a witnessed sweep.
        crossed = bar.high > hi if side > 0 else bar.low < lo
        if pool and crossed:
            far = hi if side > 0 else lo
            if bar.low <= far <= bar.high:
                swept = (bar.time + M5).isoformat()
            break
        if entered and not pool:
            break
    return dict(touch=entered, sweep=swept)


def assess(snapshot, bars, times, coverage, week=False):
    at = datetime.fromisoformat(snapshot['at'])
    day = at.astimezone(NY).date()
    end = datetime.combine(day + timedelta(days=4-day.weekday()), time(16,55), NY) if week else _deadline(at)
    status = 'open' if end > coverage.cutoff else 'missing' if coverage.gap(at, end) else 'complete'
    result = dict(status=status, end=end.isoformat())
    if status != 'complete':
        return result
    future = bars[bisect_left(times, at):bisect_left(times, end)]
    for name in (('pools',) if week else ('pools', 'dol')):
        result[name] = [contacts(t, future, name == 'pools') for t in snapshot[name]]
    return result


def summarize(pairs, scope, family):
    counts = Counter()
    for s, evaluation in pairs:
        ev = evaluation[scope]
        counts[ev['status']] += 1
        if ev['status'] != 'complete' or not s[family]:
            continue
        counts['eligible'] += 1
        rows = ev[family]
        near = min(range(len(rows)), key=lambda i: s[family][i]['distance'])
        for field in ('touch', 'sweep') if family == 'pools' else ('touch',):
            counts[field+'_top'] += bool(rows[0][field])
            counts[field+'_nearest'] += bool(rows[near][field])
            counts[field+'_any'] += any(r[field] for r in rows)
            first = min((r[field] for r in rows if r[field]), default=None)
            if first:
                leaders = [i for i,r in enumerate(rows) if r[field] == first]
                counts[field+'_tie'] += len(leaders)>1
                counts[field+'_unique_first'] += leaders == [0]
    return dict(counts)


def hover_history(pairs):
    """Attribute a witnessed result to the NY day/week of its frozen prediction."""
    groups = {}
    for s, ev in pairs:
        start = datetime.fromisoformat(s['at']).astimezone(NY)
        for period, day in [('day', start.date()), ('week', start.date()-timedelta(days=start.weekday()))]:
            for family in ('dol','pools'):
                window = ev['week' if family=='pools' and period=='week' else 'short']
                if window['status']!='complete':
                    continue
                key = (period, day.isoformat(), family)
                group = groups.setdefault(key,dict(count=0,seen={},through=start))
                group['count'] += 1
                group['through'] = max(group['through'],datetime.fromisoformat(window['end']))
                for target, observation in zip(s[family],window[family]):
                    hit = observation['sweep' if family=='pools' else 'touch']
                    if not hit:
                        continue
                    identity = (target['side'],target['lo'],target['hi'])
                    if identity in group['seen']:
                        continue
                    direction = '买方' if target['side']>0 else '卖方'
                    zone = f'{target["lo"]:.2f}' if target['lo']==target['hi'] else f'{target["lo"]:.2f}–{target["hi"]:.2f}'
                    when = datetime.fromisoformat(hit).astimezone(NY)
                    verb = '越过外沿' if family=='pools' else '触及'
                    evidence = '、'.join(target['sources']) if family=='pools' else target['source']
                    if family=='pools':
                        evidence+=f' · {target["origins"]} 个独立极点'
                    group['seen'][identity] = (f'{start:%m-%d %H:%M} #{target["rank"]} · {target["score"]}分 · '
                        f'{direction} {zone} · {when:%m-%d %H:%M} {verb} · {evidence}')
    return [dict(kind=('pool' if family=='pools' else 'dol')+'_study_'+scope,day=day,
                 through=g['through'].isoformat(),count=g['count'],rows=list(g['seen'].values()))
            for (scope,day,family),g in groups.items()]


def report():
    lock = json.loads(LOCK.read_bytes())
    assert all(lock[p.name] == digest(p) for p in (QUOTES, DOLS, MODEL, FROZEN))
    bars, times = load_bars()
    coverage = _Coverage(times[0], times[-1]+M5, bars, M5)
    frozen = read_zip(FROZEN)
    evaluations = [dict(at=s['at'], short=assess(s,bars,times,coverage), week=assess(s,bars,times,coverage,True)) for s in frozen]
    write_zip(OUT/'outcomes.json.gz', evaluations)
    pairs = list(zip(frozen, evaluations))
    (OUT/'profile_history.json').write_text(json.dumps(hover_history(pairs),ensure_ascii=False),encoding='utf-8')
    table = []
    stats = {}
    for name, scope, family in [('流动性积累 · 四小时内','short','pools'),('DOL · 四小时内','short','dol'),('流动性积累 · 至本周收盘','week','pools')]:
        v = summarize(pairs,scope,family)
        stats[name] = v
        def cell(k):
            return str(v.get(k,0)) if k in v else '—'
        table.append('<tr>'+''.join('<td>'+x+'</td>' for x in [name,cell('eligible'),cell('touch_top'),cell('touch_nearest'),cell('sweep_top'),cell('sweep_nearest'),cell('open'),cell('missing')])+'</tr>')
    (OUT/'summary.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
    groups = defaultdict(list)
    for s,e in pairs:
        local = datetime.fromisoformat(s['at']).astimezone(NY)
        groups[local.date()].append((s,e,local))
    sections = []
    for day, snapshots in groups.items():
        samples = []
        for s,e,local in snapshots:
            items=[]
            for family,title in [('pools','积累'),('dol','DOL')]:
                for idx,t in enumerate(s[family]):
                    result=e['short']
                    values=result[family][idx] if result['status']=='complete' else {}
                    def clock(stamp):
                        return datetime.fromisoformat(stamp).astimezone(NY).strftime('%m-%d %H:%M') if stamp else '—'
                    items.append('<tr>'+''.join('<td>'+escape(str(x))+'</td>' for x in
                        [title,idx+1,t['score'],'买方' if t['side']==1 else '卖方',f"{t['lo']:.2f}–{t['hi']:.2f}",t['source'],clock(values.get('touch')),clock(values.get('sweep')),clock(e['week']['pools'][idx]['sweep']) if family=='pools' and e['week']['status']=='complete' else '—'])+'</tr>')
            samples.append(f'<details><summary>{local:%H:%M} ET · {s["price"]:.2f} · 短期窗口 {e["short"]["status"]}</summary><table><tr><th>模型<th>名次<th>分数<th>方向<th>区间<th>来源<th>首次触及<th>严格越过<th>周内严格越过</tr>'+''.join(items)+'</table></details>')
        sections.append(f'<details><summary>{day} · {len(snapshots)} 个时点</summary>'+''.join(samples)+'</details>')
    html = '''<!doctype html><html lang="zh"><meta charset="utf-8"><title>黄金流动性积累与 DOL 联合复核</title>
<style>body{font:16px/1.7 system-ui,sans-serif;max-width:1180px;margin:3em auto;padding:0 1em;color:#1c303b}table{border-collapse:collapse;font-size:14px}td,th{border-bottom:1px solid #ccd5d8;padding:.3em .75em;text-align:left}summary{cursor:pointer;color:#105d6e;padding:.35em}details details{margin-left:1.5em}</style>
<h1>黄金流动性积累与 DOL 联合复核</h1><p>TMGM XAUUSD · 纽约时间 · 2026 年 9 月 21 日至 11 月 20 日。每次先冻结两个模型，再读取后续 M5。表中数值按预测时点计数，同一行情可被多个重叠窗口观察。</p>
<table><tr><th>窗口<th>有效时点<th>榜首触及<th>最近目标触及<th>榜首越过<th>最近目标越过<th>未到期<th>行情缺失</tr>'''+''.join(table)+'''</table><p>短期窗口最长四小时，并在纽约日界截断。每周观察截至周五 16:55 ET。积累的“触及”指 K 线进入目标区，“越过”要求在同根 K 线覆盖远端价格并严格越界。DOL 沿用原目标近端触价规则。最近目标从各模型当时显示的候选中选取。触及时刻记为首次满足条件的 M5 收盘时间。同根 K 线内多个目标的先后不能确定。</p>
<p>本表回放历史已收 K 线，分数是研究排序。每次快照的五周期结构只读取当时可用数据，实际暖机长度受存档起点限制。周内与短期分别评估；空白表示该项没有观测到、窗口不完整或不适用。</p><h2>逐日核对</h2>'''+''.join(sections)+'</html>'
    (OUT/'联合复核.html').write_text(html,encoding='utf-8')
    print(json.dumps(stats,ensure_ascii=True))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('freeze','report'))
    args=parser.parse_args()
    (freeze if args.stage=='freeze' else report)()
