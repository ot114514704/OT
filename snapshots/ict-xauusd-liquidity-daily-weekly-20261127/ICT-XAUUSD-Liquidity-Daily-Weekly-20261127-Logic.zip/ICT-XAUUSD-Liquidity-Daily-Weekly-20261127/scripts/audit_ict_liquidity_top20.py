"""Compare depth 10 and 20 with the same liquidity filters and timestamps."""

from datetime import datetime
from pathlib import Path
import json

import numpy as np

from ict_ai.dol_history import _deadline
from scripts import audit_ict_liquidity_15m as quarter
from scripts import audit_ict_liquidity_filter_layers as layers


study = layers.study
OUT = study.RESEARCH / 'ict_liquidity_top20_20261124.json'


def describe(rows):
    stats = layers.counts(rows)
    summary = {k:stats[k] for k in ('offers','hits','hit_windows','windows_with_offers','distinct_swept_outer_edges')}
    return dict(summary, precision=stats['hits']/stats['offers'] if stats['offers'] else None,
                ranks=[dict(rank=i,offers=stats[f'rank_{i}_offers'],hits=stats[f'rank_{i}_hits']) for i in range(1,21)])


def summarize(rows):
    top10 = [(g,tuple(i for i in keep if i < 10)) for g,keep in rows]
    added = [(g,tuple(i for i in keep if i >= 10)) for g,keep in rows]
    original, extended = describe(top10), describe(rows)
    return dict(top10=original, top20=extended, ranks_11_20=describe(added),
                additional_windows_with_hit=extended['hit_windows']-original['hit_windows'],
                additional_distinct_swept_outer_edges=extended['distinct_swept_outer_edges']-original['distinct_swept_outer_edges'])


def compare(groups, fitted, bars, times, *, inherited_horizon=None):
    rows = [(g,tuple(range(min(20,len(g['targets']))))) for g in groups
            if g['status']=='complete' and g['at'] >= layers.OCT]
    if inherited_horizon is not None:
        feature_groups = [dict(g,end=inherited_horizon(g['at'])) for g,_ in rows]
    else:
        feature_groups = [g for g,_ in rows]
    layers.context.add_context(feature_groups,bars,times)
    params = fitted['model']
    mean, scale, coef = (np.array(params[key]) for key in ('mean','scale','coefficients'))
    models = fitted['stages']
    probability = models['price_and_clock']['rule']
    distance_rule = models['distance']['rule']
    structure = models['structure']['rule']
    distance, screened = [], []
    for (g, indices), features_group in zip(rows,feature_groups,strict=True):
        active = [i for i in indices if distance_rule is None or g['distance'][i] <= distance_rule]
        distance.append((g,list(active)))
        if structure is not None:
            min_origins, max_obstacles = structure
            active = [i for i in active if g['targets'][i]['origins'] >= min_origins
                      and 4-g['targets'][i]['components']['path'] <= max_obstacles]
        if probability is not None and active:
            x = np.array([layers.features(features_group,i) for i in active])
            logit = coef[0]+((x-mean)/scale)@coef[1:]
            active = [i for i,p in zip(active,1/(1+np.exp(-np.clip(logit,-40,40))),strict=True) if p>=probability]
        screened.append((g,active))
    latest = lambda rows: [row for row in rows if str(row[0]['week']) == layers.LAST_WEEK]
    return dict(original_rank_order=summarize(rows), distance_only=summarize(distance), kept_after_layers=summarize(screened),
                last_week=dict(original_rank_order=summarize(latest(rows)), kept_after_layers=summarize(latest(screened))),
                nearest_same_coverage=layers.nearest_contrast(rows,screened),
                checkpoints=[dict(at=g['at'].isoformat(), final_ranks=[i+1 for i in keep],
                                  new_hits=[i+1 for i in keep if i >= 10 and g['y'][i]]) for g,keep in screened])


def verify(section, original):
    for key, old in original.items():
        actual = section[key]['top10']
        if (actual['hits'],actual['offers']) != (old['hits'],old['offers']):
            raise AssertionError(f'Original top-ten benchmark changed for {key}')


def main():
    archive = layers.ranking.ARCHIVE
    cand = archive/'round19_liquidity_50_candidates.json.gz'
    events = archive/'round19_liquidity_50_outcomes.json.gz'
    original = json.loads(layers.OUT.read_bytes())
    fifteen = json.loads(quarter.OUT.read_bytes())
    for name, digest in original['inputs'].items():
        if study.digest(layers.ROOT/name) != digest:
            raise ValueError(f'Published inputs changed: {name}')
    for path in (cand,events,layers.OUT,Path(quarter.__file__)):
        if study.digest(path) != fifteen['source'][path.name]:
            raise ValueError(f'Quarter-hour report input changed: {path}')
    bars, times = layers.read_market()
    snapshots, old_events = map(study.read_zip,(cand,events))
    short_events, quote_checks = quarter.short_labels(snapshots,old_events,bars,times)
    results = {}
    for scope in ('IRL','ERL'):
        groups = list(layers.ranking.build_groups(zip(snapshots,short_events,strict=True),'quarter_hour',scope))
        fitted15 = fifteen['results'][scope]['refit_15m']
        four = original['results']['short/'+scope]
        inherited = compare(groups,four,bars,times,inherited_horizon=_deadline)
        verify(inherited, dict(original_rank_order=fitted15['stages']['current_top10']['holdout'],
                               kept_after_layers=fifteen['results'][scope]['existing_four_hour_filters']['holdout']))
        results[f'{scope}/15m_existing_filters'] = inherited
        results[f'{scope}/15m_recalibrated_filters'] = compare(groups,fitted15,bars,times)
        verify(results[f'{scope}/15m_recalibrated_filters'],
               dict(kept_after_layers=fitted15['stages']['price_and_clock']['holdout']))
        for horizon in ('short','week'):
            raw = list(layers.ranking.build_groups(zip(snapshots,old_events,strict=True),horizon,scope))
            fitted = original['results'][f'{horizon}/{scope}']
            result = compare(raw,fitted,bars,times)
            verify(result, {k:fitted['stages'][v]['holdout'] for k,v in (
                ('original_rank_order','current_top10'),('distance_only','distance'),('kept_after_layers','price_and_clock'))})
            results[f'{scope}/{horizon}'] = result
    layers.atomic_json(OUT,dict(methodology='Keep the preexisting ranking and every filter threshold fixed. Add frozen production ranks 11–20, then count strict witnessed sweeps among newly offered or retained candidates. A matched nearest-edge comparator uses the same number of retained targets per checkpoint from the same top 20.',
                                first_holdout=layers.OCT.isoformat(),verified_quarter_hour_labels=quote_checks,
                                cases=results, inputs={p.name:study.digest(p) for p in (layers.OUT,quarter.OUT,cand,events,Path(__file__))},orders_sent=0))
    for key, result in results.items():
        print(key, {stage:([block['top10'][k] for k in ('hits','offers')],[block['top20'][k] for k in ('hits','offers')],
                           block['additional_windows_with_hit']) for stage,block in result.items()
                    if stage in ('original_rank_order','distance_only','kept_after_layers')},flush=True)


if __name__ == '__main__':
    main()
