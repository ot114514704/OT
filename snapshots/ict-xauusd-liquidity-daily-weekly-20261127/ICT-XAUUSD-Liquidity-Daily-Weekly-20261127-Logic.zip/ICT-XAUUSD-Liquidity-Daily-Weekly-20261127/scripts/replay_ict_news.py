"""Compare official release windows with matched NY clock windows on frozen M5 data."""
import argparse
from collections import Counter
from datetime import date, datetime, time, timedelta, timezone
import csv
import hashlib
import json
from pathlib import Path
from statistics import median

from brooks_ai.types import Bar, utc_time
from ict_ai.daily_context import daily_weekly_context
from ict_ai.profile_lifecycle import daily_profile_lifecycle
from ict_ai.timebase import NY, clock_policy_metadata, manifest_epoch_to_utc, session_windows


ROOT = Path(__file__).resolve().parents[1]
STEP = timedelta(minutes=5)
RULES = ROOT / "research/ict_time_video/news_release_study.json"
SCHEDULE = ROOT / "research/jin10_calendar/bls_mt5_schedule.json"


def load_history(manifest_path, symbol="XAUUSD", *, allow_legacy=False):
    meta = json.loads(manifest_path.read_bytes())
    legacy_research = (
        allow_legacy and "volatile_live_snapshot" not in meta
        and meta.get("source") == "MetaTrader5 terminal API"
        and meta.get("research_only") is True and meta.get("orders_sent") == 0
    )
    if (meta["symbol"] != symbol or meta.get("synthetic") is not False
            or meta["status"] != "collected"
            or (meta.get("volatile_live_snapshot") is not False and not legacy_research)):
        raise ValueError(f"Immutable non-synthetic {symbol} snapshot required")
    dataset = next(d for d in meta["datasets"] if d["timeframe"] == "M5")
    path = Path(dataset["data_path"])
    if not path.is_file():
        path = manifest_path.parent / path.name
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != dataset["data_sha256"]:
        raise ValueError("M5 data hash mismatch")
    cutoff = utc_time(meta["finished_at_utc"])
    bars = {}
    last = None
    for row in csv.DictReader(raw.decode("utf-8-sig").splitlines()):
        at = manifest_epoch_to_utc(utc_time(row["time"]), meta)
        if last is not None and at <= last:
            raise ValueError("History needs unique, chronological timestamps")
        last = at
        if at + STEP <= cutoff:
            bars[at] = Bar(at, *(float(row[k]) for k in ("open", "high", "low", "close", "spread")))
    return meta, dataset["data_sha256"], bars


def block(bars, start, count):
    rows = [bars.get(start + i * STEP) for i in range(count)]
    return None if any(b is None for b in rows) else rows


def extent(rows):
    return min(b.low for b in rows), max(b.high for b in rows)


def path_observations(rows, lower, upper):
    breaks, reclaims = {}, {}
    for bar in rows:
        close_at = (bar.time + STEP).astimezone(NY).isoformat()
        if bar.high > upper:
            breaks.setdefault("buy", close_at)
        if bar.low < lower:
            breaks.setdefault("sell", close_at)
        if lower < bar.close < upper:
            for side in breaks:
                reclaims.setdefault(side, close_at)
    if len(breaks) == 2:
        path = "both_sides_exceeded"
    elif reclaims:
        path = "one_side_reclaimed"
    elif breaks:
        path = "one_side_unreclaimed"
    else:
        path = "inside"
    return {
        "path": path, "break_known_at_ny": breaks, "reclaim_known_at_ny": reclaims,
        "both_sides_first_seen_in_same_bar": len(breaks) == 2 and len(set(breaks.values())) == 1,
        "terminal_close_relative_to_range": ("above" if rows[-1].close > upper else
                                              "below" if rows[-1].close < lower else "inside"),
    }


def measure(bars, at, minutes=60):
    before = block(bars, at - 6 * STEP, 6)
    baseline = block(bars, at - 12 * STEP, 6)
    after = block(bars, at, minutes // 5)
    if before is None or baseline is None or after is None:
        return None
    lower, upper = extent(before)
    base_lower, base_upper = extent(baseline)
    if upper <= lower or base_upper <= base_lower:
        return None
    midnight = at.astimezone(NY).replace(hour=0, minute=0)
    elapsed = (at - midnight) // STEP
    day_rows = block(bars, midnight, elapsed) if elapsed else None
    day_range = extent(day_rows) if day_rows else None
    result = {
        "at_ny": at.astimezone(NY).isoformat(), "at_utc": at.astimezone(timezone.utc).isoformat(),
        "pre_low": lower, "pre_high": upper,
        "pre_range_vs_prior_30m": (upper - lower) / (base_upper - base_lower),
        "ny_open": day_rows[0].open if day_rows else None,
        "intraday_pre_range": day_range, "horizons": {},
    }
    for horizon in (5, 30, 60):
        if horizon > minutes:
            break
        rows = after[:horizon // 5]
        low, high = extent(rows)
        result["horizons"][str(horizon)] = {
            **path_observations(rows, lower, upper),
            "range": high - low,
            "range_vs_pre_30m": (high - low) / (upper - lower),
            "net_from_last_pre_close": rows[-1].close - before[-1].close,
            "ny_open_to_close": rows[-1].close - day_rows[0].open if day_rows else None,
            "intraday_level_path": path_observations(rows, *day_range) if day_range else None,
        }
    return result


def at_ny(day, clock):
    return datetime.fromisoformat(day + "T" + clock).replace(tzinfo=NY)


def calendar_index(rules, bls):
    index = {}
    rows = [(day, clock, "NFP" if tag.endswith(" NFP") else tag,
             f"https://www.bls.gov/schedule/{day[:4]}/{day[5:7]}_sched.htm") for day, clock, tag in bls]
    rows.extend(rules["other_known_release_times"])
    rows.extend(rules["releases"])
    claim = rules["claims_schedule"]
    day, end = date.fromisoformat(claim["start"]), date.fromisoformat(claim["end"])
    if day.weekday() != 3 or end.weekday() != 3:
        raise ValueError("Checked claims interval begins and ends on published Thursdays")
    while day <= end:
        rows.append((day.isoformat(), claim["local_time"], "Initial Jobless Claims", claim["source"]))
        day += timedelta(days=7)
    for day, clock, tag, source in rows:
        # Upgrade a schedule-only entry with the linked release if both list it.
        index.setdefault(at_ny(day, clock), {})[tag] = source
    return index


def nearby_announcements(at, index):
    return [
        {"at_ny": stamp.isoformat(), "minute_offset": int((stamp - at).total_seconds() / 60),
         "event": tag, "url": url}
        for stamp, events in sorted(index.items())
        if -timedelta(hours=1) <= stamp - at < timedelta(hours=1)
        for tag, url in events.items()
    ]


def outside_study(day, from_ny, through_ny):
    return (from_ny is not None and day < from_ny) or (through_ny is not None and day > through_ny)


def controls_for(at, bars, calendar, holidays, from_ny, through_ny, *, prior_only=False):
    # Nearest weekday/date, within the same NY offset regime. No price-based selection.
    selected, rejected = [], []
    for week in (1, 2, 3):
        for direction in ((-1,) if prior_only else (-1, 1)):
            candidate = at + timedelta(days=7 * week * direction)
            diagnostics = {"at_ny": candidate.isoformat()}
            if outside_study(candidate.date(), from_ny, through_ny):
                diagnostics["reason"] = "outside_study_dates"
            elif candidate.utcoffset() != at.utcoffset():
                diagnostics["reason"] = "different_ny_utc_offset"
            elif candidate.date().isoformat() in holidays:
                diagnostics["reason"] = "excluded_holiday"
            else:
                nearby = nearby_announcements(candidate, calendar)
                if nearby:
                    diagnostics.update(reason="known_release_in_window", announcements=nearby)
                else:
                    observed = measure(bars, candidate)
                    if observed is None:
                        diagnostics["reason"] = "missing_or_degenerate_m5_window"
                    elif len(selected) >= 3:
                        diagnostics["reason"] = "three_closer_controls_already_selected"
                    else:
                        selected.append(observed)
                        continue
            rejected.append(diagnostics)
    return selected, rejected


def summarize(rows):
    return {
        "n": len(rows),
        "median_pre_range_vs_prior_30m": median(r["pre_range_vs_prior_30m"] for r in rows) if rows else None,
        "median_5m_range": median(r["horizons"]["5"]["range"] for r in rows) if rows else None,
        "median_30m_range_vs_pre_30m": median(r["horizons"]["30"]["range_vs_pre_30m"] for r in rows) if rows else None,
        "paths_at_30m": dict(Counter(r["horizons"]["30"]["path"] for r in rows)),
    }


def one_hour_timing_check(bars, at):
    """Show how an hour of clock error would change the observed first bar."""
    ranges = {}
    for hours in (-1, 0, 1):
        bar = bars.get(at + timedelta(hours=hours))
        ranges[str(hours)] = bar.high - bar.low if bar else None
    return ranges


def market_context(bars, at, cutoff):
    day = at.date()
    context = daily_weekly_context(bars, at)
    frames = {}
    for timeframe, frame in context["frames"].items():
        levels = frame["dol_candidates"]
        frames[timeframe] = {
            "last_completed_range": frame["periods"][-1] if frame["periods"] else None,
            "nearest_observed_unvisited_buy_side": next((x for x in levels if x["kind"] == "H"), None),
            "nearest_observed_unvisited_sell_side": next((x for x in levels if x["kind"] == "L"), None),
        }
    day_close = (datetime.combine(day, time(17), NY) if day.weekday() == 4 else
                 datetime.combine(day + timedelta(days=1), time.min, NY))
    profiles = {}
    for label, now in (("before_release", at), ("after_30m", at + timedelta(minutes=30)),
                       ("closed_review", day_close)):
        if now > cutoff:
            continue
        profile = daily_profile_lifecycle(bars, day, now, STEP, include_reconstruction=False, reference_m5=bars)
        profiles[label] = {key: profile[key] for key in
                           ("as_of", "mode", "profile_label", "profile_reason", "weekly_background")}
    return {
        "release_window": [key for key, (start, end) in session_windows(day).items()
                           if start <= at < end],
        "before_release_htf": frames, "profiles": profiles,
        "bias_selected": None, "dol_selected": None,
    }


def inspect_prior_bounds(news, context, bars, at, minutes=60):
    """Track already-known levels without relabeling a repeat test as a fresh breach."""
    daily = context["before_release_htf"]["D1"]["last_completed_range"]
    weekly = context["profiles"]["before_release"]["weekly_background"].get("prior_range")
    prior_ranges = {"latest_completed_ny_day": daily, "earlier_completed_days_this_week": weekly}
    before = news["intraday_pre_range"]
    result = {}
    for label, reference in prior_ranges.items():
        if reference is None:
            continue
        low, high = reference["low"], reference["high"]
        breached_before = None if before is None else {"buy": before[1] > high, "sell": before[0] < low}
        horizons = {}
        for horizon in (5, 30, 60):
            if horizon > minutes:
                break
            observed = path_observations(block(bars, at, horizon // 5), low, high)
            observed["first_breach_since_midnight_known_at_ny"] = (
                {side: known for side, known in observed["break_known_at_ny"].items()
                 if not breached_before[side]} if breached_before is not None else None)
            horizons[str(horizon)] = observed
        result[label] = {"low": low, "high": high, "breached_before_release_since_midnight": breached_before,
                         "horizons": horizons}
    return result


def run(manifest_path, output, from_ny=None, through_ny=None):
    if from_ny and through_ny and from_ny > through_ny:
        raise ValueError("Study start must be on or before study end")
    rules = json.loads(RULES.read_bytes())
    known = json.loads(SCHEDULE.read_bytes())["events"]
    releases = rules["releases"]
    calendar = calendar_index(rules, known)
    meta, data_hash, bars = load_history(manifest_path)
    cutoff = utc_time(meta["finished_at_utc"])
    rows = list(bars.values())
    comparisons, excluded = [], []
    prefix_checks = 0
    context_prefix_checks = 0
    for day, clock, tag, source in releases:
        at = at_ny(day, clock)
        if outside_study(at.date(), from_ny, through_ny):
            continue
        news = measure(bars, at)
        if news is None:
            excluded.append({"day": day, "event": tag, "reason": "incomplete M5 reference or response"})
            continue
        context = market_context(rows, at, cutoff)
        previous_boundaries = inspect_prior_bounds(news, context, bars, at)
        for minutes in (5, 30, 60):
            prefix = {stamp: b for stamp, b in bars.items() if stamp < at + timedelta(minutes=minutes)}
            result = measure(prefix, at, minutes)
            if (result["pre_low"], result["pre_high"], result["horizons"][str(minutes)]) != (
                    news["pre_low"], news["pre_high"], news["horizons"][str(minutes)]):
                raise AssertionError(f"Later data changed {day} +{minutes}m replay")
            for reference, observed in inspect_prior_bounds(result, context, prefix, at, minutes).items():
                if observed["horizons"][str(minutes)] != previous_boundaries[reference]["horizons"][str(minutes)]:
                    raise AssertionError(f"Later data changed {day} {reference} +{minutes}m replay")
            prefix_checks += 1
        comparison, rejected = controls_for(at, bars, calendar, set(rules["holiday_exclusions"]),
                                             from_ny, through_ny)
        summary = summarize(comparison)
        clipped = market_context([b for b in rows if b.time + STEP <= at], at, at)
        if (context["before_release_htf"] != clipped["before_release_htf"]
                or context["profiles"]["before_release"] != clipped["profiles"]["before_release"]):
            raise AssertionError(f"Later data changed pre-release context {day}")
        context_prefix_checks += 1
        comparisons.append({
            "event": tag, "source": source, "news": news,
            "known_announcements_in_window": nearby_announcements(at, calendar),
            "first_5m_range_with_hour_shift": one_hour_timing_check(bars, at),
            "same_clock_comparison": comparison, "comparison_summary": summary,
            "control_exclusions": rejected,
            "market_context": context,
            "prior_range_reactions": previous_boundaries,
            "first_5m_range_exceeds_control_median": (
                news["horizons"]["5"]["range"] > summary["median_5m_range"] if comparison else None),
        })
    unique_controls = {row["at_ny"]: row for item in comparisons for row in item["same_clock_comparison"]}
    matched = [item for item in comparisons if item["same_clock_comparison"]]
    dependencies = (RULES, SCHEDULE, Path(__file__).resolve(), ROOT / "ict_ai/timebase.py",
                    ROOT / "ict_ai/daily_context.py", ROOT / "ict_ai/profile_lifecycle.py")
    base = {
        "source_manifest": str(manifest_path), "source_m5_sha256": data_hash,
        "from_ny": from_ny.isoformat() if from_ny else None,
        "through_ny": through_ny.isoformat() if through_ny else None,
        "study_inputs_sha256": {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in dependencies},
        "source_chain": rules["source_chain"],
        "interpretation_rules": rules["interpretation_rules"],
        **clock_policy_metadata(meta),
        "all_releases": summarize([item["news"] for item in comparisons]),
        "matched_releases": summarize([item["news"] for item in matched]),
        "unique_controls": summarize(list(unique_controls.values())),
        "release_range_exceeds_own_control_median_count": sum(
            item["first_5m_range_exceeds_control_median"] for item in matched),
        "prefix_checks": prefix_checks, "context_prefix_checks": context_prefix_checks,
        "excluded": excluded, "comparisons": comparisons,
        "limits": rules["limits"], "orders_sent": 0,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(base, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return base


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--from-ny", type=date.fromisoformat)
    parser.add_argument("--through-ny", type=date.fromisoformat)
    args = parser.parse_args()
    result = run(args.manifest, args.out, args.from_ny, args.through_ny)
    print(json.dumps({key: result[key] for key in
                      ("all_releases", "matched_releases", "unique_controls", "prefix_checks")}, indent=2))
