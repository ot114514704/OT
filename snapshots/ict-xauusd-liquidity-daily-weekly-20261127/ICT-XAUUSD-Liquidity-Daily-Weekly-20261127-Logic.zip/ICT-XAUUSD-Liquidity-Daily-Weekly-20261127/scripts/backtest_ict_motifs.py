"""Reproducible ICT plan gating + separate motif-only cost sensitivity.

This does NOT invent missing HTF bias/PDA/DOL or qualify demo execution.
Independent trials are the default. The optional portfolio uses separate risk state.
"""
from pathlib import Path
import argparse, csv, hashlib, json, math, sys
from dataclasses import asdict, replace
from datetime import timedelta
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from brooks_ai.types import Bar,Instrument,utc_time
from brooks_ai.risk import size_volume
from brooks_ai.data import load_spec
from ict_ai.timebase import manifest_epoch_to_utc,require_replay_clock,clock_policy_metadata
from ict_ai.planning import research_plan
from ict_ai.backtest import LimitStudyOrder,simulate_limit
from ict_ai.event_context import event_context
from ict_ai.portfolio import replay_portfolio
from ict_ai.route_study import assess_route, freeze_route

COST_SCENARIOS=(('assumed_base',7,.05,1),('double_cost',14,.10,2),('wider_spread',14,.20,3))


def motif_order(event, spec):
    side, tick = event['side'], spec.tick_size
    entry = round((event['fvg']['lower'] + event['fvg']['upper']) / 2 / tick) * tick
    raw_stop = event['sweep_extreme'] - side * tick
    stop = (math.floor(raw_stop / tick) if side == 1 else math.ceil(raw_stop / tick)) * tick
    distance = side * (entry - stop)
    target = round((entry + side * 2 * distance) / tick) * tick
    known = utc_time(event['available_at'])
    return LimitStudyOrder(event['id'], side, known, known + timedelta(minutes=90),
                           entry, stop, target, spec.volume_min)


def paired_fixed_size_study(order,bars,experimental_spec,as_of,period=timedelta(minutes=5),risk_budget=25,
                            *, cancel_pending_on_target=False):
    """Freeze prices, size and availability across costs; this is not a risk-approved order."""
    result=[]
    for name,commission,slip,spread_factor in COST_SCENARIOS:
        spec=replace(experimental_spec,commission_round_turn=commission,slippage=slip)
        risk=order.volume*((order.side*(order.entry-order.stop)+2*slip)*spec.contract_size+commission)
        outcome=simulate_limit(order,bars,spec,as_of,period,spread_factor,
                               cancel_pending_on_target=cancel_pending_on_target)
        result.append({'name':name,'fixed_volume':order.volume,
                       'estimated_risk_cash':risk,'reference_risk_budget_cash':risk_budget,
                       'exceeds_reference_risk_budget':risk>risk_budget+1e-9,
                       'costs':{'commission_round_turn_usd_per_lot':commission,
                                'market_exit_slippage_price':slip,'bar_spread_multiplier':spread_factor,
                                'verified':False},'outcome':outcome})
    return {'event_id':order.id,'frozen_base_order':asdict(order),'scenarios':result,
            'interpretation':'Same order and size; costs can change fills/exits. A smaller loss after resizing is not a cost benefit.',
            'execution_allowed':False,'orders_sent':0}


def release_cohort_summary(days, event_windows, scenarios):
    result = {}
    for group in ('release', 'same_clock_control'):
        windows = [day for day in days if day['release_window']['cohort']==group]
        case_ids = {event_id for event_id, window in event_windows.items() if window['cohort']==group}
        result[group] = {
            'window_count': len(windows),
            'windows_with_candidates': sum(day['counts'].get('sweep_mss_fvg_candidate',0)>0 for day in windows),
            'candidate_count': len(case_ids),
            'bars_breaching_both_sides': sum(day['dual_side_breach_bars'] for day in windows),
            'outcomes_by_scenario': {
                scenario['name']: dict(Counter(c.get('outcome',c)['status'] for c in scenario['trials']
                                                if c['event_id'] in case_ids))
                for scenario in scenarios},
        }
    return result


def readable_summary(result):
    lines=['ICT 几何候选与成本诊断（不是完整策略的盈利验证）',
           f"行情读取截止 UTC：{result['as_of']}",
           f"具备完整背景的观察计划：{result['full_context_watch_count']}",
           f"各次独立试验假定资金：{result['independent_fixed_equity_per_trial']:.2f} USD；不是读取的账户余额。",
           '手续费、滑点为假设情景，历史合约有效性与时标仍待验证；没有发送订单。',
           '', '同一订单、同一手数的成本配对：']
    for trial in result['paired_fixed_size_cost_trials']:
        order=trial['frozen_base_order']
        lines.append(f"- {order['available_at']}，方向 {order['side']}，固定 {order['volume']} 手：")
        for case in trial['scenarios']:
            o=case['outcome'];net='未形成已关闭收益' if o['pnl_net'] is None else f"{o['pnl_net']:.2f} USD"
            lines.append(f"  {case['name']}：{o['status']}；净结果 {net}；估算风险 {case['estimated_risk_cash']:.2f} USD"+
                         ('（超过参考风险预算；仅用于压力诊断）' if case['exceeds_reference_risk_budget'] else ''))
    missing=Counter(v for row in result['full_context_plans'] for v in row['plan']['missing'])
    lines+=['', '扫荡前冻结的高周期背景（历史重建，不是当时实录偏见）：']
    for row in result['full_context_plans']:
        background=row.get('pre_sweep_background')
        if background:
            lines.append(f"- 候选 {row['event_id']}；背景截点 UTC {background['context_cutoff_utc']}：")
            lines.extend('  '+reason for reason in background['brief_reasons'])
    lines+=['背景来源：如何寻找偏见和 DOL 视频 267–404、629–794、932–1058 秒；背景参数与原文解释边界见 JSON。',
            '相对最近完整周期的位置不是已选择的 ICT 交易范围；未自动选取偏见、PDA 或 DOL。']
    lines+=['', '尚缺背景证据：'+', '.join(missing),
            '另保留按成本重新计算手数的情景。不能把减仓后的较小亏损解释为成本增加改善了策略。',
            '试验相互独立，未形成组合权益曲线；不能从少量样本推断胜率、未来收益或模拟交易资格。',
            f"成交路径的未来数据隔离检查次数：{result['fill_prefix_checks']}（价格形态另见源回放）。",
            f"行情来源：{result['source_manifest']}", f"CSV SHA256：{result['data_sha256']}",
            f"源回放：{result['source_replay']}"]
    if result['portfolio_backtest']:
        lines += ['', '单仓组合研究，按各笔确认时已实现资金计算手数']
        for item in result['portfolio_scenarios']:
            lines += [f"{item['name']}  ·  已实现权益 {item['final_realized_equity']:.2f} USD",
                      f"最大已实现回撤 {item['max_realized_drawdown_fraction']:.2%}  ·  决策 {item['decision_counts']}"]
    return '\n'.join(lines)+'\n'


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--replay',type=Path,default=ROOT/'output/research/ict_structure_replay_M5_20261013_1220.json')
    ap.add_argument('--contexts',type=Path,help='Mapping from event ID to timestamped, sourced context fields')
    ap.add_argument('--spec',type=Path,help='Instrument JSON, verified contract/costs required for full-context watches')
    ap.add_argument('--equity',type=float,default=10000)
    ap.add_argument('--route-study',action='store_true',help='Compare a frozen research route target to the diagnostic 2R target')
    ap.add_argument('--portfolio',action='store_true',help='Run an additional single-order portfolio with historical research risk limits')
    ap.add_argument('--out',type=Path,default=ROOT/'output/research/ict_motif_cost_study_20261013.json')
    args=ap.parse_args()
    if not math.isfinite(args.equity) or args.equity<=0:raise ValueError('Positive equity required')
    replay=json.loads(args.replay.read_text(encoding='utf-8'))
    if not replay.get('prefix_stability_passed') or replay['period_minutes']!=5:raise ValueError('Causally checked M5 replay required')
    for path,sha in replay['code_sha256'].items():
        if hashlib.sha256((ROOT/path).read_bytes()).hexdigest()!=sha:raise ValueError('Replay source changed: '+path)
    manifest_path=Path(replay['source_manifest'])
    meta=json.loads(manifest_path.read_text(encoding='utf-8'))
    data=next(d for d in meta['datasets'] if d['timeframe']=='M5')
    raw_path=Path(data['data_path'])
    if not raw_path.is_file():
        raw_path=manifest_path.parent/raw_path.name
    if meta.get('synthetic') is not False or hashlib.sha256(raw_path.read_bytes()).hexdigest()!=replay['data_sha256'] or data['data_sha256']!=replay['data_sha256']:
        raise ValueError('Matching non-synthetic source required')
    as_of=utc_time(replay['as_of']);p=timedelta(minutes=5)
    if as_of>utc_time(meta['finished_at_utc']):raise ValueError('Replay exceeds recorded read cutoff')
    require_replay_clock(meta,replay)
    with raw_path.open(encoding='utf-8-sig',newline='') as f:
        bars=[Bar(manifest_epoch_to_utc(utc_time(r['time']),meta),*(float(r[k]) for k in ('open','high','low','close','spread'))) for r in csv.DictReader(f)]
    contexts=json.loads(args.contexts.read_text(encoding='utf-8')) if args.contexts else {}
    verified_spec=load_spec(args.spec) if args.spec else None
    if verified_spec and verified_spec.symbol!=meta['symbol']:raise ValueError('Spec symbol mismatch')
    info=meta.get('current_symbol_observation')
    if not info:
        raise ValueError('Snapshot lacks the recorded instrument specification; collect a new immutable snapshot rather than guess contract size or lot limits')
    experimental_spec=Instrument(meta['symbol'],info['point'],info['trade_tick_size'],info['trade_contract_size'],
                                 info['volume_min'],info['volume_step'],info['volume_max'],
                                 account_currency=meta['account_currency'],profit_currency=info['currency_profit'],
                                 verified=False,costs_verified=False)
    release_study=replay.get('release_study')
    if release_study and hashlib.sha256(Path(release_study['path']).read_bytes()).hexdigest()!=release_study['sha256']:
        raise ValueError('Release-study input changed; regenerate structural replay')
    motifs=[];full=[];event_windows={};route_cases={}
    for day in replay['days']:
        event_by_id={e['id']:e for e in day['events']}
        for event in day['events']:
            if event['kind']!='sweep_mss_fvg_candidate':continue
            event={**event,'sweep_started_at':event_by_id[event['sweep_id']]['sweep_started_at']}
            motifs.append(event)
            if release_study:
                event_windows[event['id']]=day['release_window']
            plan=research_plan(event,contexts.get(event['id'],{}),bars,event['available_at'],
                               spec=verified_spec,equity=args.equity,period=p)
            row={'event_id':event['id'],'plan':plan,'simulation':None,
                 'pre_sweep_background':event_context(event,bars,event['available_at'])}
            before_sweep=[b for b in bars if b.time+p<=utc_time(event['sweep_started_at'])]
            if row['pre_sweep_background']!=event_context(event,before_sweep,event['available_at']):
                raise AssertionError('Future prices changed frozen HTF background: '+event['id'])
            if args.route_study:
                watch=freeze_route(row['pre_sweep_background']['frozen_evidence'])
                assessment=assess_route(watch,event,bars,p)
                route_cases[event['id']]={'pre_sweep_watch':watch,'confirmation_assessment':assessment,
                                          'within_course_session':not any('outside selected' in s for s in plan['contradictions']),
                                          'simulation_status':'not_eligible_for_target_comparison'}
            if plan['status']=='watch_for_mitigation':
                watch=plan['watch'];known=utc_time(event['available_at'])
                order=LimitStudyOrder(event['id'],event['side'],known,known+timedelta(minutes=90),
                                      watch['entry_midpoint'],watch['stop'],watch['target'],watch['volume'])
                row['simulation']=simulate_limit(order,bars,verified_spec,as_of,p)
            full.append(row)
    scenarios=[];prefixes=0;paired=[]
    templates={event['id']:motif_order(event,experimental_spec) for event in motifs}
    # These are assumed research costs, NOT verified TMGM commissions/slippage.
    for name,commission,slip,spread_factor in COST_SCENARIOS:
        spec=replace(experimental_spec,commission_round_turn=commission,slippage=slip)
        cases=[]
        for event in motifs:
            template=templates[event['id']]
            side,entry,tick=template.side,template.entry,spec.tick_size
            distance=abs(entry-template.stop)
            loss_per_lot=(distance+2*slip)*spec.contract_size+commission
            volume=size_volume(args.equity*.0025,loss_per_lot,spec)
            if not volume:
                cases.append({'event_id':event['id'],'status':'minimum_size_exceeds_budget'});continue
            known=template.available_at
            order=replace(template,volume=volume)
            if name=='assumed_base':
                diagnostic=paired_fixed_size_study(order,bars,experimental_spec,as_of,p,args.equity*.0025)
                paired.append(diagnostic)
                if args.route_study:
                    route_case=route_cases[event['id']]
                    assessment=route_case['confirmation_assessment']
                    if assessment['status']=='target_open_at_confirmation':
                        route_target=assessment['target_reference_price']
                        if side*(route_target-entry)>0 and math.isclose(route_target/tick,round(route_target/tick),abs_tol=1e-7,rel_tol=0):
                            route_order=replace(order,target=route_target)
                            route_case['fixed_size_route_trial']=paired_fixed_size_study(
                                route_order,bars,experimental_spec,as_of,p,args.equity*.0025,
                                cancel_pending_on_target=True)
                            route_case['matched_2r_trial']=paired_fixed_size_study(
                                order,bars,experimental_spec,as_of,p,args.equity*.0025,
                                cancel_pending_on_target=True)
                            route_case['simulation_status']='paired_target_diagnostic'
                        else:
                            route_case['simulation_status']='route_target_outside_entry_geometry_or_grid'
            outcome=simulate_limit(order,bars,spec,as_of,p,spread_factor)
            # No future bars may change an earlier observable result.
            for n,b in enumerate(bars,1):
                now=b.time+p
                if now<known or now>min(as_of,known+timedelta(hours=15)):continue
                if simulate_limit(order,bars,spec,now,p,spread_factor)!=simulate_limit(order,bars[:n],spec,now,p,spread_factor):
                    raise AssertionError('Fill prefix changed: '+event['id'])
                prefixes+=1
            cases.append({'event_id':event['id'],'source_physical_pages':event['source_physical_pages'],
                          'order':asdict(order),'estimated_risk_cash':volume*loss_per_lot,'outcome':outcome})
        scenarios.append({'name':name,'sizing_policy':'Recompute size under each cost scenario; cash PnL is not a same-size cost comparison',
                          'costs':{'commission_round_turn_usd_per_lot':commission,
                                              'market_exit_slippage_price':slip,'bar_spread_multiplier':spread_factor,
                                              'verified':False},'trials':cases,
                          'status_counts':dict(Counter(c.get('outcome',c)['status'] for c in cases))})
    code=['ict_ai/backtest.py','ict_ai/planning.py','ict_ai/event_context.py','ict_ai/timebase.py',
          'ict_ai/daily_context.py','ict_ai/delivery.py','scripts/backtest_ict_motifs.py']
    result={'as_of':as_of.isoformat(),'source_manifest':str(manifest_path),'data_sha256':replay['data_sha256'],
            **clock_policy_metadata(meta),'historical_clock_verified':False,
            'source_replay':str(args.replay.resolve()),'source_replay_sha256':hashlib.sha256(args.replay.read_bytes()).hexdigest(),
            'context_sha256':hashlib.sha256(args.contexts.read_bytes()).hexdigest() if args.contexts else None,
            'spec_sha256':hashlib.sha256(args.spec.read_bytes()).hexdigest() if args.spec else None,
            'background_source_sha256':hashlib.sha256((ROOT/'research/ict_price_videos/bias_dol/integration.json').read_bytes()).hexdigest(),
            'code_sha256':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in code},
            'full_context_plans':full,'full_context_watch_count':sum(r['plan']['status']=='watch_for_mitigation' for r in full),
            'diagnostic_motif_trials':scenarios,'fill_prefix_checks':prefixes,'prefix_stability_passed':True,
            'paired_fixed_size_cost_trials':paired,
            'background_prefix_checks':len(full),'background_prefix_stability_passed':True,
            'independent_fixed_equity_per_trial':args.equity,'portfolio_backtest':False,
            'engineering_choices':['FVG midpoint on tick grid','One-tick stop buffer','2R hypothetical target, not DOL',
                                   '90-minute pending expiry','Fixed 0.25% risk per independent trial',
                                   'NY 16:50 forced intraday flatten','Stop first when OHLC ordering ambiguous'],
            'limitations':['Motif trial omits HTF bias/PDA/DOL and calendar; cannot validate complete ICT strategy',
                           'Current contract specification is assumed stable historically',
                           'Commission and slippage scenarios are assumptions, not verified broker costs',
                           'Intrabar Ask reconstructed from constant bar spread; tick path and queue unknown',
                           'Entry-bar targets may be deferred; quote gaps, including pending-order paths, are censored',
                           'Marketable limit at an open beyond stop is filled then stopped; broker-specific handling unverified',
                           f'{len(motifs)} motifs in this sample; no statistical or profitability qualification',
                           'Historical source clock mapping (including any recorded intervals) remains inferred'],
            'model_trained':False,'demo_qualified':False,'orders_sent':0,'execution_allowed':False,
            'execution_reference':'https://www.metatrader5.com/en/terminal/help/trading/general_concept'}
    if release_study:
        result['release_study']=release_study
        result['event_windows']=event_windows
        result['release_cohorts']=release_cohort_summary(replay['days'],event_windows,scenarios)
        result['limitations'].append(
            'Calendar is retrospective cohort metadata only; no point-in-time news signal or event-specific execution is validated.')
    if args.route_study:
        result['code_sha256']['ict_ai/route_study.py']=hashlib.sha256((ROOT/'ict_ai/route_study.py').read_bytes()).hexdigest()
        result['experimental_route_study']={
            'selection':'Before sweep: pending D1/W1 routes must agree on direction; prefer W1 then closest open target within frame.',
            'comparison':'At later confirmation: target still untouched, same direction, same diagnostic order except target. Once pending, cancel when its target is reached before entry; censor indeterminate intrabar ordering. Market context and costs are unverified.',
            'confirmation_counts':dict(Counter(r['confirmation_assessment']['status'] for r in route_cases.values())),
            'simulation_counts':dict(Counter(r['simulation_status'] for r in route_cases.values())),
            'cases':route_cases,
            'execution_allowed':False,
        }
    if args.portfolio:
        config_path=ROOT/'config/strategy.json'
        raw_config=config_path.read_bytes()
        config=json.loads(raw_config)
        risk={key:config[key] for key in ('risk_fraction','daily_loss_limit','max_drawdown','max_consecutive_losses')}
        portfolio=[]
        orders=tuple(templates.values())
        cutoffs=sorted({order.available_at for order in orders})
        for name,commission,slip,spread_factor in COST_SCENARIOS:
            spec=replace(experimental_spec,commission_round_turn=commission,slippage=slip)
            def run(book,quotes,cutoff):
                return replay_portfolio(book,quotes,spec,cutoff,args.equity,risk,period=p,spread_multiplier=spread_factor)
            report=run(orders,bars,as_of)
            for cutoff in cutoffs:
                past_orders=[order for order in orders if order.available_at<=cutoff]
                past_bars=[bar for bar in bars if bar.time+p<=cutoff]
                earlier=run(past_orders,past_bars,cutoff)
                if earlier!=run(orders,bars,cutoff) or earlier['decisions']!=[
                    decision for decision in report['decisions'] if utc_time(decision['available_at'])<=cutoff
                ]:
                    raise AssertionError(f'Future data changed portfolio decisions at {cutoff}')
            portfolio.append({'name':name,**report,
                              'decision_counts':dict(Counter(row['status'] for row in report['decisions'])),
                              'outcome_counts':dict(Counter(row['outcome']['status'] for row in report['completed'])),
                              'prefix_checks':len(cutoffs)})
        for path in ('ict_ai/portfolio.py','brooks_ai/risk.py'):
            result['code_sha256'][path]=hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
        result.update(portfolio_backtest=True,portfolio_scenarios=portfolio,
                      portfolio_risk_config_sha256=hashlib.sha256(raw_config).hexdigest())
        result['limitations'].append('Portfolio equity and drawdown are realized only; intrabar equity, margin and execution are unverified.')
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2,default=lambda x:x.isoformat()),encoding='utf-8')
    args.out.with_suffix('.txt').write_text(readable_summary(result),encoding='utf-8-sig')
    print(json.dumps({'report':str(args.out),'full_context_watch_count':result['full_context_watch_count'],
                      'motifs':len(motifs),'scenarios':[{'name':s['name'],'status_counts':s['status_counts']} for s in scenarios],
                      'fill_prefix_checks':prefixes,'orders_sent':0},ensure_ascii=False))


if __name__=='__main__':main()
