"""Read the existing TMGM terminal, archive inputs, rank first, then evaluate outcomes."""
import argparse
import csv
import gzip
import hashlib
import io
import json
from bisect import bisect_left
from calendar import monthrange
from datetime import datetime,timedelta,timezone
from pathlib import Path

from brooks_ai.types import Bar
from ict_ai.dol_history import forecast, settle
from ict_ai.judas import judas_history
from ict_ai.timebase import NY
from scripts.export_mt5_profiles import (ROOT, M5, H1, checked_account, history, mt5, add_smt,
                                         midnight, aggregate_bars)

DEST=ROOT/'output/research/ranked_dol'


def schedule():
    rows=json.loads((ROOT/'research/jin10_calendar/bls_mt5_schedule.json').read_text(encoding='utf-8'))['events']
    return [(datetime.fromisoformat(d+'T'+t).replace(tzinfo=NY),name) for d,t,name in rows]


def archive(path):
    policy=json.loads((ROOT/'research/live_clock_20261116.json').read_text(encoding='utf-8'))
    if not mt5.initialize():raise RuntimeError(mt5.last_error())
    try:
        account=checked_account(mt5,None)
        now=datetime.now(timezone.utc)
        payload={}
        for sym,period in [('XAUUSD','M5'),('XAUUSD','H1'),('XAGUSD','H1'),('USIDX','H1')]:
            prices=history(sym,getattr(mt5,'TIMEFRAME_'+period),policy,now)
            payload[sym+period]=[[b.time.isoformat(),b.open,b.high,b.low,b.close] for b in prices]
        checked_account(mt5,(account.login,account.server))
        packed=gzip.compress(json.dumps(dict(server=account.server,at=now.isoformat(),clock=policy,series=payload)).encode())
        with path.open('xb') as f:f.write(packed)
    finally:mt5.shutdown()


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--archive',type=Path,required=True)
    args=ap.parse_args()
    DEST.mkdir(parents=True,exist_ok=True)
    if not args.archive.exists():archive(args.archive)
    raw=args.archive.read_bytes()
    payload=json.loads(gzip.decompress(raw))
    now=datetime.fromisoformat(payload['at'])
    bars,h1,silver,dollar=([Bar(datetime.fromisoformat(t),o,h,l,c,0) for t,o,h,l,c in payload['series'][k]]
                          for k in ('XAUUSDM5','XAUUSDH1','XAGUSDH1','USIDXH1'))
    end=now.astimezone(NY).date()
    month=(end.year*12+end.month-1)-2
    start=end.replace(year=month//12,month=month%12+1,day=min(end.day,monthrange(month//12,month%12+1)[1]))
    m15=aggregate_bars(bars,5,15,now)
    peers=add_smt(lambda *a:None,h1,silver,now,'白银',False)+add_smt(lambda *a:None,h1,dollar,now,'美元指数',True)
    news=schedule()
    judas=judas_history(bars,now,news)
    checkpoints={e['known'] for e in judas}
    snapshots=[]
    for i,b in enumerate(bars):
        at=b.time+M5
        clock=at.astimezone(NY)
        if clock.date()<start or clock.weekday()>4 or clock.date()!=b.time.astimezone(NY).date():continue
        if clock.hour==0 and clock.minute==5 or clock.minute==0 and clock.hour in (2,3,4,8,9,10,11,14,15,16) or at in checkpoints:
            _,targets=forecast(bars[:i+1],h1,m15,at,peers,news,judas,nearby_priority=True)
            snapshots.append(dict(at=at.isoformat(),price=b.close,targets=targets))
    summaries,stats=settle(snapshots,bars,now)
    report=dict(archive_sha256=hashlib.sha256(raw).hexdigest(),start_ny=str(start),through_ny=str(end),
                last_close=(bars[-1].time+M5).isoformat(),score_bands=stats,snapshots=snapshots,
                day={str(d):v for (k,d),v in summaries.items() if k=='day'},
                week={str(d):v for (k,d),v in summaries.items() if k=='week'})
    target=DEST/'history.json'
    tmp=target.with_suffix('.tmp')
    tmp.write_text(json.dumps(report,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(target)
    print(len(snapshots),sum(len(s['targets']) for s in snapshots),len(judas),stats,flush=True)


if __name__=='__main__':main()
