"""Settle frozen daily-profile forecasts using the same closed-day rule as training."""

from argparse import ArgumentParser
from collections import Counter
from datetime import datetime, timedelta
from hashlib import sha256
import json
import time

from brooks_ai.types import Bar
from ict_ai.timebase import NY, manifest_epoch_to_utc
from scripts import watch_ict_daily_learning as registration
from scripts import watch_ict_intraday_learning as intraday
from scripts.serve_ict_live import atomic_json, checked_account


learning = registration.learning
archive = registration.archive
M5 = registration.M5
FOLDER = registration.FOLDER / 'settlements'
SYNC_GRACE = timedelta(minutes=1)
COVERAGE_GRACE = timedelta(minutes=30)


def read_json(path):
    return json.loads(path.read_bytes())


def decode_bars(rows):
    return [Bar(datetime.fromisoformat(stamp), *prices, 0) for stamp, *prices in rows]


def encode_bars(bars):
    return [[b.time.isoformat(), b.open, b.high, b.low, b.close] for b in bars]


def capture_tail(api, alive, model, start, end):
    """Include the frozen decision candle as an independent feed alignment check."""
    if not alive() or not api.initialize(str(registration.TERMINAL), timeout=3000):
        raise RuntimeError('Could not access the bound MT5 terminal')
    try:
        account = checked_account(api)
        if account.server != model['server']:
            raise RuntimeError('The terminal uses another quote server')
        clock = model['clock']
        lo, hi = [datetime.fromtimestamp(registration.raw_epoch(stamp, clock), registration.UTC)
                  for stamp in (start, end)]
        rates = api.copy_rates_range(model['symbol'], api.TIMEFRAME_M5, lo, hi)
        checked_account(api, (account.login, account.server))
        if rates is None or not alive():
            raise RuntimeError('M5 history unavailable from the bound terminal')
        bars = []
        for item in rates:
            stamp = manifest_epoch_to_utc(datetime.fromtimestamp(int(item['time']), registration.UTC), clock)
            if start <= stamp and stamp + M5 <= end:
                bars.append(Bar(stamp, *(float(item[k]) for k in ('open', 'high', 'low', 'close')), 0))
        return bars
    finally:
        api.shutdown()


def evaluate(record, prefix, tail, captured_at, *, probability_key='learned_probability'):
    at = datetime.fromisoformat(record['cutoff'])
    day = at.astimezone(NY).date()
    _, end = learning._day_bounds(day)
    if captured_at < end + SYNC_GRACE:
        raise ValueError('Closed-day outcome requested before the end of the study day')
    if (not prefix or prefix[-1].time + M5 != at or not tail or tail[0] != prefix[-1]):
        raise ValueError('The settlement feed does not match the frozen decision candle')
    if any(a.time >= b.time for a, b in zip(tail, tail[1:])) or tail[-1].time + M5 > end:
        raise ValueError('Settlement M5 must be ordered, unique and closed within the study day')
    start_history = learning.daily_profile_history_start(day)
    bars = [b for b in prefix if b.time >= start_history] + tail[1:]
    m15 = learning.aggregate_bars(bars, 5, 15, end)
    finish = learning.daily_profile_lifecycle(m15, day, end, include_reconstruction=False, reference_m5=bars)
    actual = sorted({learning.candidate_key(c) for c in finish['actual_paths']})
    result = dict(coverage=finish.get('daily_price_basis'), forecast_status=record['status'],
                  closed_day_status=finish['profile_status'], actual_paths=None, candidate_results=[], scores=None)
    if not finish['coverage_complete_under_study_calendar']:
        return dict(**result, status='insufficient_m5_coverage')
    result['actual_paths'] = [list(key) for key in actual]
    if record['status'] != 'scores_recorded':
        return dict(**result, status=record['status'])
    candidates = record['candidates']
    y = [int((c['profile'], c['direction']) in actual) for c in candidates]
    result['candidate_results'] = [dict(profile=c['profile'], direction=c['direction'], matched=hit,
                                      learned_probability=c[probability_key], signed_family_prior=c['signed_family_prior'])
                                   for c, hit in zip(candidates, y, strict=True)]
    result['scores'] = learning.metrics([dict(y=y, learned=[c[probability_key] for c in candidates],
                                             signed_family_prior=[c['signed_family_prior'] for c in candidates])], 'y')
    return dict(**result, status='scored')


def settle(path, record, tail, captured_at, server, *, early=False):
    prefix = decode_bars(archive.read_zip(path.with_name(f'{path.stem}-M5.json.gz')))
    rows = encode_bars(tail)
    checksum = sha256(json.dumps(rows, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    identity = {}
    if early:
        at = datetime.fromisoformat(record['cutoff']).astimezone(NY)
        identity = dict(checkpoint_ny=at.strftime('%H:%M'),cutoff=record['cutoff'])
    return dict(date=path.stem[:10], **identity,forecast_sha256=archive.digest(path), captured_at=captured_at.isoformat(),
                server=server, settlement_m5=rows, settlement_m5_sha256=checksum, orders_sent=0,
                **evaluate(record, prefix, tail, captured_at,
                           probability_key='pooled_probability' if early else 'learned_probability'))


def rebuild_summary(settled):
    rows = []
    for item in settled:
        if item['status'] != 'scored':
            continue
        candidates = item['candidate_results']
        day = datetime.fromisoformat(item['date']).date()
        rows.append(dict(ny_week=(day - timedelta(days=day.weekday())).isoformat(),
                         rule_y=[c['matched'] for c in candidates], learned=[c['learned_probability'] for c in candidates],
                         signed_family_prior=[c['signed_family_prior'] for c in candidates]))
    abstentions = [r for r in settled if r['actual_paths'] is not None and r['forecast_status'] == 'no_candidate']
    return dict(settled=len(settled), status_counts=dict(Counter(r['status'] for r in settled)),
                no_candidate_days_with_closed_rule_path=sum(bool(r['actual_paths']) for r in abstentions),
                rule_check=learning.metrics(rows, 'rule_y'), paired_rule_weeks=learning.paired_weeks(rows),
                outcome_basis='Closed-day price-path rules under the study calendar', orders_sent=0)


def verify(model, *, early=False):
    source = intraday if early else registration
    pattern = '????-??-??_????.json' if early else '????-??-??.json'
    destination = source.FOLDER/'settlements' if early else FOLDER
    registered = source.verify(model)
    settled = []
    for path in sorted(destination.glob(pattern)):
        saved = read_json(path)
        forecast = source.FOLDER / path.name
        tail = decode_bars(saved['settlement_m5'])
        capture = datetime.fromisoformat(saved['captured_at'])
        if saved != settle(forecast, read_json(forecast), tail, capture, model['server'],early=early):
            raise ValueError(f'Settlement does not replay: {path.name}')
        settled.append(saved)
    return registered, settled


def settle_due(model, fetch, now, settled, retry, *, early=False):
    source = intraday if early else registration
    pattern = '????-??-??_????.json' if early else '????-??-??.json'
    destination = source.FOLDER/'settlements' if early else FOLDER
    names = {r['date']+'_'+r['checkpoint_ny'].replace(':','') if early else r['date'] for r in settled}
    pending = {}
    due = []
    for path in sorted(source.FOLDER.glob(pattern)):
        if path.stem in names:
            continue
        record = read_json(path)
        end = datetime.fromisoformat(record['forecast_end'])
        if now < end + SYNC_GRACE:
            pending[path.stem] = 'waiting_for_day_end'
        elif path.stem in retry and now < retry[path.stem][0]:
            pending[path.stem] = retry[path.stem][1]
        else:
            due.append((path, record, end))
    if due:
        source.verify(model)
    for path, record, end in due:
        try:
            start = datetime.fromisoformat(record['cutoff']) - M5
            tail, captured_at = fetch(start, end)
            saved = settle(path, record, tail, captured_at, model['server'],early=early)
            if (saved['status'] == 'insufficient_m5_coverage' and captured_at < end + COVERAGE_GRACE
                    and record['status'] != 'insufficient_m5_coverage'):
                pending[path.stem] = 'waiting_for_m5_sync'
            else:
                atomic_json(destination / path.name, saved)
                settled.append(saved)
                retry.pop(path.stem, None)
                continue
        except (OSError, RuntimeError, ValueError) as exc:
            pending[path.stem] = str(exc)
        retry[path.stem] = now + M5, pending[path.stem]
    return pending


def summary(settled, early):
    if not early:
        return rebuild_summary(settled)
    checkpoints = [t.strftime('%H:%M') for t in intraday.CHECKPOINTS]
    return dict(settled=len(settled),orders_sent=0,score_source='pooled_intraday',
                checkpoints={name:rebuild_summary([r for r in settled if r['checkpoint_ny']==name])
                             for name in checkpoints})


def main():
    parser = ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--verify', action='store_true')
    mode.add_argument('--terminal-pid', type=int)
    parser.add_argument('--intraday',action='store_true',help='Settle early-session checkpoints in their separate archive')
    args = parser.parse_args()
    source = intraday if args.intraday else registration
    destination = source.FOLDER/'settlements' if args.intraday else FOLDER
    model = source.load_model()
    if args.verify:
        registered, settled = verify(model,early=args.intraday)
        print(json.dumps(dict(registered=registered, **summary(settled,args.intraday)), ensure_ascii=False))
        return

    import msvcrt
    import MetaTrader5 as mt5

    destination.mkdir(parents=True, exist_ok=True)
    with registration.open_terminal(args.terminal_pid) as alive, (destination / 'watch.lock').open('a+b') as lock:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        _, settled = verify(model,early=args.intraday)
        retry = {}
        previous = None

        def fetch(start, end):
            bars = capture_tail(mt5, alive, model, start, end)
            return bars, registration.utc_now()

        while alive():
            now = registration.utc_now()
            try:
                pending = settle_due(model, fetch, now, settled, retry,early=args.intraday)
            except (OSError, json.JSONDecodeError) as exc:
                pending = {'archive': str(exc)}
            state = dict(terminal_pid=args.terminal_pid, pending=pending, **summary(settled,args.intraday))
            if state != previous:
                atomic_json(destination / 'summary.json', dict(**state, checked_at=now.isoformat()))
                print(now.isoformat(), state, flush=True)
                previous = state
            time.sleep(30)


if __name__ == '__main__':
    main()
