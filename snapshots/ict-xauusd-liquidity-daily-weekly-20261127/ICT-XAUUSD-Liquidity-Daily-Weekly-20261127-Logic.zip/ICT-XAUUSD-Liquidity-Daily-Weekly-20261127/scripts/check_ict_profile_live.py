"""Verify source-bound live profile publication, without browser assertions."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from urllib.request import urlopen

ROOT=Path(__file__).resolve().parents[1]


def main():
    with urlopen('http://127.0.0.1:9887/api/status',timeout=15) as response:
        status=json.load(response)
    with urlopen('http://127.0.0.1:9887/api/live',timeout=15) as response:
        payload=json.load(response)
    assert status['ready'] and status['analysis_fresh'] and status['error'] is None
    assert payload['analysis_fresh'] and payload['orders_sent']==status['orders_sent']==0
    scenario=next(s for s in payload['scenarios'] if s['id']=='broker-plus3')
    today=next(d for d in scenario['days'] if d['date']==payload['initial_view']['day'])
    week=scenario['weeks'][1]
    assert today['profile_lifecycle']['mode']=='intraday_hypothesis'
    assert today['profile_lifecycle']['actual_paths']==[]
    assert week['profile_lifecycle']['mode']=='intraweek_hypothesis'
    assert not week['profile_lifecycle']['full_ict_profile_confirmed']
    journal=payload['profile_journal']
    assert any(h['scope']=='day' and h['date']==today['date'] and h['origin']=='recorded_live_hypothesis' for h in journal['history'])
    assert any(h['scope']=='week' and h['date']==week['days'][0] and h['origin']=='recorded_live_hypothesis' for h in journal['history'])
    records=[json.loads(line) for line in Path(journal['journal']).read_text(encoding='utf-8').splitlines()]
    latest=records[-1]
    assert latest['profile_code_sha256']==hashlib.sha256((ROOT/'ict_ai/profile_lifecycle.py').read_bytes()).hexdigest()
    for path in latest['source_manifests']:
        meta=json.loads(Path(path).read_text(encoding='utf-8'))
        assert meta['synthetic'] is False and meta['volatile_live_snapshot'] is False
        for dataset in meta['datasets']:
            assert hashlib.sha256(Path(dataset['data_path']).read_bytes()).hexdigest()==dataset['data_sha256']
    for item in latest['profile_definition_sources']:
        assert hashlib.sha256(Path(item['archived_path']).read_bytes()).hexdigest()==item['sha256']
    path=ROOT/'output/visualizations/ict-week-review.html'
    fragment=path.read_text(encoding='utf-8')
    assert path.stat().st_size<1_000_000
    for marker in ('data-week-profile-history','data-profile-history','data-week-profile-stage','candidateState','font-size:11px'):
        assert marker in fragment
    initial=json.loads(re.search(r'<script type="application/json" data-payload>(.*?)</script>',fragment,re.S).group(1))
    assert initial['profile_journal']['history']
    report={'status':'passed','checked_at_utc':datetime.now(timezone.utc).isoformat(),'pid':status['pid'],
            'live_revision':payload['live_revision'],'quote_time':payload['live']['quote_time'],
            'daily_label':today['profile_label'],'weekly_label':week['profile_label'],
            'history_records':len(records),'compact_history_records':len(journal['history']),
            'fragment_bytes':path.stat().st_size,'fragment_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'source_manifest':initial['source_manifest'],'source_sha256':initial['source_sha256'],
            'browser_runtime_verified':False,'historical_clock_verified':False,'orders_sent':0}
    output=ROOT/'output/research/ict_profile_live_check_20261014.json'
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))


if __name__=='__main__':main()
