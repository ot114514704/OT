"""Replay weekly hypotheses at the close of the NY Tuesday, Wednesday and Thursday study days."""

from argparse import ArgumentParser
from bisect import bisect_left, bisect_right
from collections import Counter
from datetime import timedelta
from pathlib import Path

from ict_ai.profile_lifecycle import _day_bounds, weekly_profile_lifecycle
from ict_ai.profile_sources import WEEKLY
from ict_ai.timebase import NY
from ict_ai.weekly_close_candidates import EARLY_EXTREMES, friday_expansion_watch, frozen_extreme_candidates
from ict_ai.weekly_path import weekly_path
from scripts import audit_ict_daily_learning as market
from scripts.serve_ict_live import atomic_json


OUT = market.RESEARCH / 'ict_weekly_candidates_20261123.json'
CHECKPOINTS = dict(tuesday=1, wednesday=2, thursday=3)
FRIDAY = dict(friday_1000=timedelta(hours=10), friday_1300=timedelta(hours=13),
              friday_1500=timedelta(hours=15), friday_1645=timedelta(hours=16, minutes=45))


def identity(card):
    return card.get('id'), card.get('direction')


def view(m5, m15, days, at):
    realized = weekly_path(m5, days, at)
    live = weekly_profile_lifecycle(m15, days, at, realized)
    covered = live['coverage_complete_under_study_calendar']
    old = [c for c in live['candidates'] if c['id'] in WEEKLY and c['observed_sequence']]
    frozen = frozen_extreme_candidates(realized, days, at, covered)
    new = [c for c in old if c['id'] not in EARLY_EXTREMES] + frozen
    watch = friday_expansion_watch(realized, m15, days, at, covered)
    # Only stable candidate state and observed evidence are written to this audit.
    old = [{k: c[k] for k in ('id', 'direction', 'status', 'phase', 'reclaim_known_at') if k in c} for c in old]
    return dict(covered=covered, original=old, frozen=new, friday_watch=watch,
                with_friday_watch=old+([watch] if watch else []),
                realized_status=live['profile_status'], closed_week=live['week_ended'],
                realized=[c for c in live.get('realized_candidates', [])
                          if c.get('id') in WEEKLY and c.get('observed_sequence') and c.get('path_complete')])


def active(cards):
    return {identity(c) for c in cards if c['status'] == 'active' and c['id'] in WEEKLY}


def measure(timeline, checkpoint, rule):
    mature = [row for row in timeline if row['settled']['covered']]
    eligible = [row for row in mature if row[checkpoint]['covered']]
    stats = Counter()
    families = {name: Counter() for name in WEEKLY}
    mismatch = []
    for row in eligible:
        picked = active(row[checkpoint][rule])
        truth = {identity(c) for c in row['settled']['realized']}
        stats.update(eligible=1, weeks_with_candidates=bool(picked), signed_candidates=len(picked),
                     weeks_with_match=bool(picked & truth), signed_matches=len(picked & truth),
                     settled_paths=len(truth), missed_paths=len(truth-picked),
                     mixed_directions={side for _, side in picked} == {-1, 1})
        for ident, side in picked | truth:
            key = (ident, side)
            families[ident].update(candidates=key in picked, matches=key in picked & truth,
                                   realized=key in truth, missed=key in truth-picked)
        if truth-picked:
            mismatch.append(row['week'])
    total = stats['signed_candidates']
    denomin = stats['settled_paths']
    return dict(stats, coverage_missing=len(timeline)-len(mature),
                matched_fraction=stats['signed_matches']/total if total else None,
                realized_path_recall=stats['signed_matches']/denomin if denomin else None,
                families={k: dict(v) for k, v in families.items()}, weeks_with_missed_paths=mismatch)


def transitions(timeline, rule):
    counts = Counter()
    for row in timeline:
        for start, end in (('tuesday', 'wednesday'), ('wednesday', 'thursday')):
            prefix = f'{start}_to_{end}'
            if not row[start]['covered'] or not row[end]['covered']:
                counts[prefix, 'coverage_missing'] += 1
                continue
            later = {identity(c): c['status'] for c in row[end][rule]}
            for key in active(row[start][rule]):
                counts[prefix, later.get(key, 'disappeared')] += 1
    return {'/'.join(key): value for key, value in counts.items()}


def calibration_sample(timeline, checkpoint, rule):
    folds = [row for row in timeline if row[checkpoint]['covered'] and row['settled']['covered']]
    sizes = Counter()
    for row in folds:
        picked = active(row[checkpoint][rule])
        truth = {identity(c) for c in row['settled']['realized']}
        sizes.update(with_candidates=bool(picked), with_positive=bool(picked & truth),
                     with_negative=bool(picked-truth))
    gates = dict(with_candidates=40, with_positive=10, with_negative=10)
    return dict(counts=dict(sizes), research_gate_minimum_distinct_weeks=gates,
                meets_initial_sample_floor=all(sizes[k] >= v for k, v in gates.items()),
                model_fitted=False)


def friday_watch_metrics(timeline, checkpoint):
    counts = Counter()
    confirmed = []
    for row in timeline:
        state, settled = row[checkpoint], row['settled']
        if not state['covered'] or not settled['covered']:
            continue
        watch = state['friday_watch']
        if not watch:
            continue
        counts[watch['status']] += 1
        if watch['status'] != 'active':
            continue
        matched = any(identity(c) == identity(watch) and c.get('variant') == watch['variant']
                      for c in settled['realized'])
        counts['matched_exact_variant'] += matched
        if matched:
            confirmed.append({'week': row['week'], 'direction': watch['direction'], 'breaches': watch['breaches']})
    return dict(status_counts=dict(counts), exact_variant_matches=confirmed)


def run():
    bars, times = market.read_market()
    last = times[-1]+market.M5
    quarters = market.aggregate_bars(bars, 5, 15, last)
    qtimes = [b.time for b in quarters]
    first_day = times[0].astimezone(NY).date()
    monday = first_day-timedelta(days=first_day.weekday())
    timeline = []
    prefix_checks = 0
    while True:
        days = [monday+timedelta(days=i) for i in range(5)]
        first = _day_bounds(monday)[0]
        end = _day_bounds(days[-1])[1]
        if end > last:
            break
        a, z = bisect_left(times, first), bisect_left(times, end)
        aq, zq = bisect_left(qtimes, first), bisect_left(qtimes, end)
        whole, whole_q = bars[a:z], quarters[aq:zq]
        row = dict(week=monday.isoformat(), settled=view(whole, whole_q, days, end))
        schedule = {name: _day_bounds(days[index])[1] for name, index in CHECKPOINTS.items()}
        friday = _day_bounds(days[-1])[0]
        schedule.update({name: friday+offset for name, offset in FRIDAY.items()})
        for name, at in schedule.items():
            m5 = bars[a:bisect_right(times, at-market.M5)]
            m15 = quarters[aq:bisect_right(qtimes, at-market.M15)]
            checkpoint_view = view(m5, m15, days, at)
            if checkpoint_view != view(whole, whole_q, days, at):
                raise AssertionError(f'Future bars changed {monday} at {at}')
            row[name] = dict(checkpoint_view, as_of_ny=at.astimezone(NY).isoformat())
            prefix_checks += 1
        timeline.append(row)
        monday += timedelta(days=7)
    comparison = {name: {rule: measure(timeline, name, rule) for rule in ('original', 'frozen')}
                  for name in CHECKPOINTS}
    friday_watch = {name: dict(friday_watch_metrics(timeline, name),
                     comparison={rule: measure(timeline, name, rule) for rule in ('original', 'with_friday_watch')})
                    for name in ('thursday', *FRIDAY)}
    files = (Path(__file__), Path('ict_ai/profile_lifecycle.py'), Path('ict_ai/weekly_path.py'),
             Path('ict_ai/weekly_close_candidates.py'), market.ARCH/'XAUUSDM5.npz',
             market.ARCH/'clock_validation.json')
    return dict(coverage_policy='Require complete study-calendar quote windows and elapsed Friday 17:00 NY.',
                outcome='Existing Friday review, keyed by family and direction. Price path only.',
                weeks=len(timeline), prefix_checks=prefix_checks, final_data_close=last.isoformat(),
                settled_status=dict(Counter(row['settled']['realized_status'] for row in timeline)),
                comparison=comparison, friday_watch=friday_watch,
                transitions={rule: transitions(timeline, rule) for rule in ('original', 'frozen')},
                calibration={name: {rule: calibration_sample(timeline, name, rule) for rule in ('original', 'frozen')}
                             for name in CHECKPOINTS},
                timeline=timeline, source_sha256={p.name: market.digest(p) for p in files}, orders_sent=0)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=OUT)
    args = parser.parse_args()
    result = run()
    atomic_json(args.out, result)
    print(f"weeks={result['weeks']} prefix_checks={result['prefix_checks']} settled={result['settled_status']}")
    for name, rules in result['comparison'].items():
        for rule, metrics in rules.items():
            print(name, rule, metrics['signed_matches'], '/', metrics['signed_candidates'],
                  'realized=', metrics['settled_paths'], 'eligible=', metrics['eligible'])
