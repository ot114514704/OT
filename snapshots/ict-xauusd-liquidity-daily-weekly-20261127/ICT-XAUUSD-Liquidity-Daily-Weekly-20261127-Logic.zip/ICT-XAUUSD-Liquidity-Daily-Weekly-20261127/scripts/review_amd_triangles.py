"""Draw triangle-only AMD case studies from the project's archived TMGM quotes."""
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from brooks_ai.types import utc_time
from ict_ai.amd import amd_events, confirmed_pivots
from ict_ai.timebase import NY
from scripts.audit_profile_one_daily_context import load_tmgm
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_news import STEP

OUT = Path(__file__).resolve().parents[1] / 'output/visualizations/amd-triangles-1.31'
CASES = [
    (15, '2026-11-03T07:00', '01-bullish'),
    (15, '2026-10-26T12:15', '02-bearish'),
    (15, '2026-10-02T11:15', '03-descending'),
    (60, '2026-11-18T23:00', '04-hourly'),
]
BG, PANEL, TEXT, MUTED = '#101a26', '#142232', '#e9f1f6', '#a0b1c1'
BLUE, PINK, GOLD = '#77c8ff', '#efa3d8', '#ffda81'


def font(size, bold=False):
    return ImageFont.truetype('C:/Windows/Fonts/msyh'+('bd' if bold else '')+'.ttc', size)


def draw(bars, period, events, file):
    a, d = events[0], events[-1]
    m = next((e for e in events if e['phase']=='M'), None)
    pos = {b.time:i for i,b in enumerate(bars)}
    first = pos[utc_time(a['start'])]
    confirmed = pos[utc_time(a['available_at'])-period]
    last = pos[utc_time(d['available_at'])-period]
    left = first
    while left>max(0,first-2) and bars[left].time==bars[left-1].time+period:
        left-=1
    rows=bars[left:last+1]
    image=Image.new('RGB',(1400,790),BG)
    pen=ImageDraw.Draw(image)
    def label(x,y,st,size=19,color=TEXT,bold=False,anchor='la'):
        pen.text((x,y),st,font=font(size,bold),fill=color,anchor=anchor)
    def stamp(instant, fmt='%m/%d %H:%M'):
        return utc_time(instant).astimezone(NY).strftime(fmt)
    up = d['direction']=='bullish'
    direction = '向上' if up else '向下'
    title=a['shape_label']+'  /  '+('扫下沿后向上派发' if up and m else '扫上沿后向下派发' if m else direction+'直接扩张')
    label(48,22,title,37,TEXT,True)
    tf=f'{int(period.total_seconds()/60)} 分钟'
    label(50,83,f'TMGM  ·  XAUUSD     {tf}     {stamp(a["start"],"%Y-%m-%d")}     纽约时间',20,MUTED)
    label(1350,37,'历史行情回放',20,BLUE,anchor='ra')
    x0,y0,x1,y1=55,147,1274,548
    pen.rectangle((x0,y0,x1,y1),fill=PANEL)
    pmin=min(b.low for b in rows);pmax=max(b.high for b in rows)
    span=pmax-pmin
    pmin-=span*.12;pmax+=span*.12
    step=(x1-x0)/len(rows)
    def x(i): return x0+(i-left+.5)*step
    def y(p): return y1-(p-pmin)/(pmax-pmin)*(y1-y0)
    for i in range(5):
        v=pmin+(pmax-pmin)*i/4
        pen.line((x0,y(v),x1,y(v)),fill='#2b4052')
        label(x1+12,y(v),f'{v:.2f}',17,MUTED,anchor='lm')
    for i in sorted(set(round(left+(last-left)*j/5) for j in range(6))):
        label(x(i),y1+14,bars[i].time.astimezone(NY).strftime('%H:%M'),16,MUTED,anchor='ma')
    for value in (a['range_low'],a['range_high']):
        for px in range(round(x(confirmed)+step*.48),x1,11):
            pen.line((px,y(value),min(x1,px+4),y(value)),fill='#7990a4',width=1)
    for i,b in enumerate(rows,left):
        c='#59cbb4' if b.close>=b.open else '#f58c84'
        hw=min(12,max(2,step*.27))
        top,bt=sorted((y(b.open),y(b.close)))
        pen.line((x(i),y(b.high),x(i),y(b.low)),fill=c,width=2)
        pen.rectangle((x(i)-hw,top,x(i)+hw,max(top+2,bt)),fill=c)
    h0,h1,l0,l1=confirmed_pivots(bars[first:confirmed+1])
    for start,end,attr in [(h0,h1,'high'),(l0,l1,'low')]:
        i,j=first+start,first+end
        p,q=getattr(bars[i],attr),getattr(bars[j],attr)
        pen.line((x(i),y(p),x(j),y(q)),fill=BLUE,width=4)
        for col,row in [(x(i),y(p)),(x(j),y(q))]:
            pen.ellipse((col-4,row-4,col+4,row+4),fill=BLUE)
    for event,letter,color in [(a,'A',BLUE),(m,'M',PINK),(d,'D',GOLD)]:
        if event is None: continue
        i=pos[utc_time(event['available_at'])-period]
        col,row=x(i),y(bars[i].close)
        above = row>y0+65
        other=row-36 if above else row+36
        pen.ellipse((col-5,row-5,col+5,row+5),fill=BG,outline=color,width=2)
        pen.line((col,row-6 if above else row+6,col,other),fill=color,width=2)
        pen.rounded_rectangle((col-14,other-12,col+14,other+12),radius=6,fill=BG,outline=color,width=1)
        label(col,other,letter,16,color,True,anchor='mm')
    label(55,598,'阶段确认',22,TEXT,True)
    cols=(55,510,958)
    for col,e,phase,c in zip(cols,(a,m,d),('A  积累','M  操纵','D  '+('派发' if m else '直接扩张')),(BLUE,PINK,GOLD)):
        label(col,646,phase,23,c,True)
        label(col,687,stamp(e['available_at'])+' 收盘' if e else '未观察到扫边收回',21)
    label(55,748,f'蓝线连接已确认摆动点　·　虚线为冻结边界 {a["range_low"]:.2f} / {a["range_high"]:.2f}　·　字母标在确认 K 线上',17,MUTED)
    image.save(file)


def main():
    archive,_=load_tmgm()
    cutoff=archive[-1].time+STEP
    OUT.mkdir(parents=True,exist_ok=True)
    for minutes in sorted({c[0] for c in CASES}):
        period=timedelta(minutes=minutes)
        bars=[b for b in aggregate_bars(archive,5,minutes,cutoff) if b.time>=utc_time('2026-09-01T00:00:00Z')]
        groups=defaultdict(list)
        for event in amd_events(bars,period,cutoff,triangle_only=True):
            groups[event['id']].append(event)
        for tf,start,name in CASES:
            if tf!=minutes: continue
            cycle=next(g for g in groups.values() if g[0]['start'].startswith(start) and g[-1]['phase']=='D')
            for event in cycle:
                at=utc_time(event['available_at'])
                if event not in amd_events([b for b in bars if b.time<at],period,at,triangle_only=True):
                    raise ValueError(f'Unreproducible stage: {event}')
            draw(bars,period,cycle,OUT/(name+'.png'))
            print(name, [(e['phase'],utc_time(e['available_at']).astimezone(NY).strftime('%m-%d %H:%M')) for e in cycle])


if __name__=='__main__':
    main()
