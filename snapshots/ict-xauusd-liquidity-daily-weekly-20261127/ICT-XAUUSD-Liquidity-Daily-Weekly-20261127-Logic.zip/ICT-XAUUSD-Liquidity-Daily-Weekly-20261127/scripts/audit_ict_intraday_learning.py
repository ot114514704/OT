"""Compare daily profile forecasts at five closed M15 checkpoints in New York."""

from argparse import ArgumentParser
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from datetime import datetime, time, timedelta
import json
from pathlib import Path

from scripts import audit_ict_daily_learning as daily
from scripts.serve_ict_live import atomic_json


CHECKPOINTS = (time(7, 30), time(8, 30), time(9, 30), time(10), time(11))
CHECKPOINT_NAMES = [checkpoint.strftime('%H:%M') for checkpoint in CHECKPOINTS]
REFERENCE = daily.RESEARCH/'ict_daily_learning_20261123.json'


def read_manual():
    labels = {}
    for path in daily.MANUAL:
        for case in json.loads(path.read_bytes())['cases']:
            if case['period'] != 'daily':
                continue
            known = {(ident, {'bullish':1, 'bearish':-1, None:0}[side]) for ident,side in case['reviewed']}
            if labels.setdefault(case['date'], known) != known:
                raise ValueError(f"Manual reviews disagree on {case['date']}")
    return labels


def rebuild_checkpoints(bars, times):
    checkpoints = {name:[] for name in CHECKPOINT_NAMES}
    known_ranges = {}
    days = sorted({bar.time.astimezone(daily.NY).date() for bar in bars if bar.time.astimezone(daily.NY).weekday()<5})
    completed_at = times[-1]+daily.M5
    for day in days:
        start, end = daily._day_bounds(day)
        first = bisect_left(times, daily.daily_profile_history_start(day))
        tail = bars[first:bisect_left(times,end)]
        m15 = daily.aggregate_bars(tail,5,15,end)
        finish = daily.daily_profile_lifecycle(m15,day,min(end,completed_at),include_reconstruction=False,reference_m5=tail)
        eligible = end<=completed_at and finish.get('coverage_complete_under_study_calendar',False)
        actual = sorted({daily.candidate_key(c) for c in finish['actual_paths']}) if eligible else None
        prior_day = day-timedelta(days=3 if day.weekday()==0 else 1)
        prior = known_ranges.get(prior_day)
        ranges = [known_ranges.get(d) for d in daily.previous_week(day)]
        week = (min(r[0] for r in ranges),max(r[1] for r in ranges)) if all(ranges) else None
        for name, checkpoint in zip(CHECKPOINT_NAMES,CHECKPOINTS,strict=True):
            at = datetime.combine(day,checkpoint,daily.NY)
            if at > completed_at:
                continue
            history = bars[first:bisect_right(times,at-daily.M5)]
            prefix = daily.aggregate_bars(history,5,15,at)
            frozen = daily.daily_profile_lifecycle(prefix,day,at,include_reconstruction=False,reference_m5=history)
            full = daily.daily_profile_lifecycle(m15,day,at,include_reconstruction=False,reference_m5=tail)
            if frozen != full:
                raise AssertionError(f'Causal reconstruction changed at {at.isoformat()}')
            choices = daily.inputs(frozen,history,start,prior,week)
            keys = [key for key,_ in choices]
            checkpoints[name].append(dict(date=day,at=at,end=end,week=day-timedelta(days=day.weekday()),
                                          keys=keys,x=[x for _,x in choices],actual=actual,
                                          y=[int(key in actual) for key in keys] if actual is not None else None,
                                          prefix_covered=frozen.get('coverage_complete_under_study_calendar',False)))
        if eligible:
            today = [bar for bar in tail if start<=bar.time]
            known_ranges[day] = min(b.low for b in today),max(b.high for b in today)
    return checkpoints


def pooled_matrix(checkpoints, manual):
    days = {}
    features = {}
    for name, rows in checkpoints.items():
        hour, minute = (int(part) for part in name.split(':'))
        elapsed = hour*60+minute-7*60
        for row in rows:
            if not row['keys']:
                continue
            vectors = [[*x,elapsed] for x in row['x']]
            features[name,row['date'].isoformat()] = dict(keys=row['keys'],x=vectors)
            if row['y'] is not None and row['date'].isoformat() not in manual:
                group = days.setdefault(row['date'],dict(date=row['date'],week=row['week'],end=row['end'],x=[],y=[],keys=[]))
                for key, values in (('x',vectors),('y',row['y']),('keys',row['keys'])):
                    group[key].extend(values)
    return sorted(days.values(),key=lambda row: row['date']),features


def add_pooled_scores(results, pooled, features):
    folds = {}
    for name,result in results.items():
        for row in result['observations']:
            week = datetime.fromisoformat(row['ny_week']).date()
            if week not in folds:
                earlier = [g for g in pooled if g['week']<week]
                classes = Counter(hit for g in earlier for _,hit in set(zip(g['keys'],g['y'],strict=True)))
                folds[week] = (earlier,daily.fit_prior_weeks(earlier)) if len(earlier)>=35 and min(classes[0],classes[1])>=8 else (earlier,None)
            training, model = folds[week]
            if model is None:
                continue
            if training[-1]['end']>=datetime.fromisoformat(row['available_at']):
                raise AssertionError('Pooled training labels were unavailable before the decision')
            row['pooled_learned'] = daily.forecast(features[name,row['date']],training,model)[0]
            row['pooled_training_dates'] = len(training)
            row['pooled_trained_through'] = training[-1]['end'].isoformat()


def coverage(rows):
    mature = [r for r in rows if r['actual'] is not None]
    path_days = [r for r in mature if r['actual']]
    return dict(mature_dates=len(mature),mature_rule_path_dates=len(path_days),
                mature_matching_candidate_dates=sum(any(r['y']) for r in path_days),
                mature_missed_rule_path_dates=sum(not any(r['y']) for r in path_days))


def pooled_comparison(rows, label):
    shared = [r for r in rows if 'pooled_learned' in r and r[label] is not None]
    local = daily.metrics(shared,label)
    pooled = [dict(r,learned=r['pooled_learned']) for r in shared]
    value = daily.metrics(pooled,label)['learned']
    return dict(same_cutoff_learned=local['learned'],pooled_learned=value,signed_family_prior=local['signed_family_prior'],
                pooled_vs_prior_by_ny_week=daily.paired_weeks(pooled) if label=='rule_y' else None)


def joined_with_reference(rows, reference):
    """Compare the same signed rule candidate on the same date at both cutoffs."""
    paired = []
    for row in rows:
        earlier = reference.get(row['date'])
        if earlier is None or row['rule_y'] is None or earlier['rule_y'] is None:
            continue
        lookup = {tuple(key):i for i,key in enumerate(earlier['keys'])}
        y,checkpoint,control = [],[],[]
        for ix,key in enumerate(row['keys']):
            match = lookup.get(tuple(key))
            if match is None:
                continue
            if row['rule_y'][ix]!=earlier['rule_y'][match]:
                raise AssertionError('The same candidate has two end-of-day outcomes')
            y.append(row['rule_y'][ix]);checkpoint.append(row['learned'][ix]);control.append(earlier['learned'][match])
        if y:
            paired.append(dict(ny_week=row['ny_week'],rule_y=y,learned=checkpoint,signed_family_prior=control))
    scores = daily.metrics(paired,'rule_y')
    return dict(checkpoint=scores['learned'],reference_1000=scores['signed_family_prior'])


def run():
    sources = [daily.ARCH/'XAUUSDM5.npz',daily.ARCH/'clock_validation.json',*daily.MANUAL, Path(daily.__file__),
               Path('ict_ai/profile_lifecycle.py'),Path('ict_ai/timebase.py'),Path('scripts/audit_ict_target_ranking.py')]
    reference = json.loads(REFERENCE.read_bytes())
    hashes = {p.name:daily.digest(p) for p in sources}
    if hashes != reference['inputs']:
        raise ValueError('The validated 10:00 study inputs changed')
    manual = read_manual()
    bars,times = daily.read_market()
    checkpoints = rebuild_checkpoints(bars,times)
    results = {name:daily.walk_forward(rows,manual) for name,rows in checkpoints.items()}
    # Run the old protocol on the new reconstruction before adding experiments.
    if any(json.loads(json.dumps(value))!=reference[key] for key,value in results['10:00'].items()):
        raise AssertionError('The 10:00 checkpoint does not reproduce the frozen study')
    reference_observations = {r['date']:r for r in results['10:00']['observations']}
    pooled, features = pooled_matrix(checkpoints,manual)
    add_pooled_scores(results,pooled,features)
    for name,result in results.items():
        rows = result['observations']
        result.update(coverage=coverage(checkpoints[name]),same_candidate_with_1000=joined_with_reference(rows,reference_observations),
                      pooled_rule_check=pooled_comparison(rows,'rule_y'),pooled_manual_check=pooled_comparison(rows,'manual_y'))
    return dict(checkpoints=results,prefix_checks=sum(len(rows) for rows in checkpoints.values()),
                frozen_1000_reproduced=True,inputs={**hashes,REFERENCE.name:daily.digest(REFERENCE),
                                                     Path(__file__).name:daily.digest(Path(__file__))},
                broker_archive_start=times[0].isoformat(),broker_archive_end=times[-1].isoformat(),
                pool_features=[*daily.FEATURES,'minutes_since_ny_window_open'],
                protocol=dict(cutoffs_ny=CHECKPOINT_NAMES,training_unit='NY date',
                              minimum_training_days=35,minimum_distinct_date_candidate_labels_per_class=8,
                              training_cutoff='Earlier NY weeks only, with closed-day labels',
                              pooled_rows='Equally weighted dates, candidates and cutoffs within a date share its weight',
                              reference='Same-cutoff smoothed signed-family prior'),
                limitations=['Extends retrospective study on the same archive; checkpoints are exploratory.',
                             'Manual dates excluded from all fitting and previously used to develop rules.',
                             'Rules label signed price paths at close. No probable profitability or forward accuracy established.'],
                execution_allowed=False, orders_sent=0)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=daily.RESEARCH/'ict_intraday_learning_20261123.json')
    args=parser.parse_args()
    report=run()
    atomic_json(args.out, report)
    for name,result in report['checkpoints'].items():
        print(name,result['coverage'],result['pooled_rule_check'],flush=True)
