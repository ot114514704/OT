"""Expand four-bar validation to the recorded pre-pilot MT5 chart batches."""

from argparse import ArgumentParser
from bisect import bisect_left
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from contextlib import closing
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sqlite3

from brooks_ai.types import Bar
from ict_ai.dol_history import batch_id
from ict_ai.range_liquidity import _research_open
from scripts import watch_ict_micro_liquidity_all_m5 as stream


fixed, live = stream.fixed, stream.live
board, M5 = fixed.board, fixed.M5
OUT = board.joint.RESEARCH / 'ict_micro_liquidity_recent_all_m5_20261125.json'
INPUT = OUT.with_name('ict_micro_liquidity_recent_all_m5_inputs_20261125.json.gz')
BID = OUT.with_name('ict_micro_liquidity_recent_all_m5_bid_20261125.json.gz')
ORIGIN = datetime.fromisoformat('2026-11-22T23:00:00+00:00')
DELAYS = (0, 30, 60)
BEIJING = timezone(timedelta(hours=8))
digest = board.joint.digest


def rows(bars):
    return [[bar.time.isoformat(), *live.quotes.ohlc(bar)] for bar in bars]


def capture(pid):
    contract = stream.load_policy()
    until = datetime.fromisoformat(contract['frozen_at'])
    pending = defaultdict(list)
    uri = live.quotes.DATABASE.resolve().as_uri() + '?mode=ro'
    with closing(sqlite3.connect(uri, uri=True, timeout=5)) as db:
        for key, stamp, receipt, payload in db.execute(
                'SELECT id,cutoff,received,payload FROM chart_batches WHERE cutoff>=? AND cutoff<? '
                'AND received IS NOT NULL ORDER BY cutoff,received,id', (ORIGIN.isoformat(), until.isoformat())):
            at, received = datetime.fromisoformat(stamp), datetime.fromisoformat(receipt)
            if not _research_open(at) or not at <= received < at + M5:
                continue
            sample = json.loads(payload)
            if sample['at'] != stamp or batch_id(at, sample['price'], [sample['targets'], sample['pools']]) != key:
                raise ValueError(f'Cannot authenticate the original MT5 batch at {stamp}')
            pending[stamp].append(dict(batch=key, receipt=receipt, sample=sample))
    if not pending:
        raise ValueError('No pre-pilot MT5 receipts were found')
    with fixed.open_terminal(pid) as alive:
        now = live.now()
        with live.terminal() as (api, clock):
            m5 = live.feed.history('XAUUSD', api.TIMEFRAME_M5, clock, until + M5)
            m1 = live.feed.history('XAUUSD', api.TIMEFRAME_M1, clock, until)
        matched = {at.isoformat(): bucket for at, bucket in fixed.capture_buckets(
            live.feed.mt5, alive, fixed.frozen_feed(), [datetime.fromisoformat(k) for k in pending], now)}
    closes = {(bar.time + M5).isoformat(): bar.close for bar in m5}
    selected = {}
    for stamp, revisions in pending.items():
        record = next((r for r in revisions if r['sample']['price'] == closes.get(stamp)), revisions[0])
        selected[stamp] = dict(**record, first_receipt=revisions[0]['receipt'])
    board.joint.write_zip(INPUT, dict(frozen_at=now.isoformat(), policy_sha256=digest(stream.POLICY),
                                      start=ORIGIN.isoformat(), until=until.isoformat(), boards=selected,
                                      m5=rows(m5), m1=rows(m1)))
    board.joint.write_zip(BID, dict(input_sha256=digest(INPUT), slots=matched))


def initialize():
    global m5, m1, five_times, minute_times, shadow
    source = board.joint.read_zip(INPUT)
    m5, m1 = ([Bar(datetime.fromisoformat(t), *values, 0) for t, *values in source[key]] for key in ('m5', 'm1'))
    five_times, minute_times = [bar.time for bar in m5], [bar.time for bar in m1]
    shadow = board.make_shadow_rank()


def identify(task):
    stamp, record = task
    at = datetime.fromisoformat(stamp)
    end = bisect_left(five_times, at)
    chart = record['sample']
    if not end or m5[end-1].time + M5 != at or m5[end-1].close != chart['price']:
        return stamp, 'original_close_mismatch', None
    eligible = board.early_sides(m5[max(0, end-15):end])
    old = {scope: sorted((p for p in chart['pools'] if p['scope'] == scope.lower()), key=lambda p: p['rank'])
           for scope in board.SCOPES}
    if not eligible:
        return stamp, 'no_qualifying_pivot', dict(cutoff=stamp, baseline=old, early=old, qualifying=[])
    minutes = m1[:bisect_left(minute_times, at)]
    args = dict(limit=10, priority_uplift=True, minute_bars=minutes)
    new_baseline = board.top10(board.structural.structural_ranking(m5[:end], at, chart['targets'], **args))
    if any([live.identity(p) for p in old[scope]] != [live.identity(p) for p in new_baseline[scope]]
           for scope in board.SCOPES):
        return stamp, 'qualified_baseline_not_reproduced', None
    new = board.top10(shadow(m5[:end], at, chart['targets'], **args))
    return stamp, 'qualifying_verified', dict(cutoff=stamp, baseline=old, early=new, qualifying=sorted(eligible))


def evaluate():
    stream.load_policy()
    source = board.joint.read_zip(INPUT)
    raw_bid = board.joint.read_zip(BID)
    if raw_bid['input_sha256'] != digest(INPUT) or source['policy_sha256'] != digest(stream.POLICY):
        raise ValueError('Replayed chart and Bid evidence use different frozen inputs')
    tasks = sorted(source['boards'].items())
    with ProcessPoolExecutor(max_workers=3, initializer=initialize) as pool:
        identified = list(pool.map(identify, tasks, chunksize=4))
    results = defaultdict(lambda: defaultdict(Counter))
    by_day = defaultdict(lambda: defaultdict(lambda: defaultdict(Counter)))
    states = Counter()
    cases = []
    exclusions = {}
    quotes = {t: values for t, *values in source['m5']}
    for stamp, state, data in identified:
        states[state] += 1
        bucket = raw_bid['slots'].get(stamp)
        if data is None or not bucket or bucket['ohlc'] != quotes.get(stamp):
            if data is not None:
                state = 'unreconciled_bid'
                states[state] += 1
            exclusions[stamp] = state
            continue
        at = datetime.fromisoformat(stamp)
        local_day = at.astimezone(BEIJING).date().isoformat()
        record = source['boards'][stamp]
        acknowledged = datetime.fromisoformat(record['receipt'])
        revised_receipt = record['receipt'] != record['first_receipt']
        case = dict(cutoff=stamp, chart_receipt=record['receipt'], chart_batch=record['batch'],
                    revised_receipt=revised_receipt, qualified_sides=data['qualifying'])
        for delay in DELAYS:
            ready = max(acknowledged, at + timedelta(seconds=delay))
            measured = fixed.grade(data, ready, [bucket], 1)
            if measured['state'] != 'scored':
                states[f'{delay}s/{measured["state"]}'] += 1
                continue
            paired = stream.paired(measured)
            case[str(delay)] = paired
            for scope, values in paired.items():
                baseline, early = (measured['outcomes'][mode][scope] for mode in ('baseline', 'early'))
                for mode, levels in (('baseline', baseline), ('early', early)):
                    edges = {stream.expiry.outer(p) for p in levels if p['status'] != 'before_board'}
                    values[f'{mode}_eligible_edges'] = len(edges)
                counts = dict(**values, samples=1, qualifying=int(bool(data['qualifying'])),
                              revised_receipts=int(revised_receipt),
                              baseline_hit_windows=int(values['baseline_hits'] > 0),
                              early_hit_windows=int(values['early_hits'] > 0))
                results[str(delay)][scope].update(counts)
                by_day[local_day][str(delay)][scope].update(counts)
                if values['added'] or values['displaced']:
                    baseline_crosses, early_crosses = (
                        {stream.expiry.outer(p): p['bid_time_ms'] for p in levels if p['status'] == 'sweep'}
                        for levels in (baseline, early))
                    values['added_edges'] = [[*key, early_crosses[key]]
                                             for key in sorted(early_crosses.keys() - baseline_crosses.keys())]
                    values['displaced_edges'] = [[*key, baseline_crosses[key]]
                                                 for key in sorted(baseline_crosses.keys() - early_crosses.keys())]
        cases.append(case)
    start, until = (datetime.fromisoformat(source[k]) for k in ('start', 'until'))
    expected = sum(_research_open(start + i * M5) for i in range(((until - start) // M5) + 1)
                   if start + i * M5 < until)
    report = dict(start=source['start'], end_before=source['until'], expected_market_m5=expected,
                  chart_cutoffs=len(tasks), reconciled_bid_slots=len(raw_bid['slots']), states=states,
                  results=results, by_beijing_day=by_day, cases=cases, exclusions=exclusions,
                  inputs={p.name: digest(p) for p in (INPUT, BID, stream.POLICY, Path(__file__))},
                  method=('Separate out-of-time retrospective sample. Use the earliest native receipt with the '
                          'verified close still within its M5 window. Both boards share the later of that receipt '
                          'and the assumed delay. Only the M5 before fifth close counts.'),
                  orders_sent=0)
    live.atomic_json(OUT, report)
    print(json.dumps(dict(states=states, chart_cutoffs=len(tasks), results=results), ensure_ascii=False))


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--capture-terminal-pid', type=int)
    args = parser.parse_args()
    if args.capture_terminal_pid:
        capture(args.capture_terminal_pid)
    evaluate()


if __name__ == '__main__':
    main()
