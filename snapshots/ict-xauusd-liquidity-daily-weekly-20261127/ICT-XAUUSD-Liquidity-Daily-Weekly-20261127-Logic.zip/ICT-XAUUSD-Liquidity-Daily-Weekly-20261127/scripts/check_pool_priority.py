"""Test one distance-sensitive ordering on the same ten structural candidates.

Run with the panel interpreter, first "freeze" then "evaluate". Neither stage
connects to MT5. Frozen historical DOL inputs and price archive are hash checked.
"""
from bisect import bisect_left
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import date, datetime, timedelta
import json
from pathlib import Path
import random
from statistics import median
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts import replay_pool_and_dol as joint
from ict_ai.range_liquidity import _Coverage, M5
from ict_ai.timebase import NY

ARCH = joint.RESEARCH/'dol_expansion_20261122'
OUT = joint.RESEARCH/'pool_priority_check'
POOL_FILE = OUT/'historical_candidates.json.gz'
RULE = dict(shortlist='existing structural top ten', score='score / (1 + distance / median H1 range)',
            ties='distance, lower edge, upper edge', primary='strict sweep by original DOL deadline',
            validation='2026-04-01..2026-09-18', comparison=['current','closest in shortlist'],
            uncertainty='paired resampling of NY weeks, 5000 replicates',
            decision='promote only if lower 95% bound above zero vs both controls; inspect week-end sweeps separately')


def read_market():
    sys.path.insert(0,str(ARCH))
    from run import load
    bars = load('XAUUSDM5')
    return bars,[b.time for b in bars]


def init_worker():
    global bars, times
    bars,times = read_market()


def build(s):
    at=datetime.fromisoformat(s['at'])
    lo=bisect_left(times,at-timedelta(days=63))
    prefix=bars[lo:bisect_left(times,at)]
    assert prefix[-1].time+M5==at and prefix[-1].close==s['price']
    pools=joint.liquidity_ranking(prefix,at,joint.archived_dol(s))
    def order(i):
        t=pools[i]
        return (-t['score']/(1+t['distance']/t['hourly_range']),t['distance'],t['lo'],t['hi'])
    indices=sorted(range(len(pools)),key=order)
    return dict(at=s['at'],price=s['price'],pools=pools,dol=[],priority=indices)


def freeze():
    OUT.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((ARCH/'manifest.json').read_bytes())
    names=('XAUUSDM5.npz','frozen.json.gz','validation_extra_frozen.json.gz','run.py')
    for name in names:
        assert joint.digest(ARCH/name)==manifest[name]
    contract=dict(rule=RULE,inputs={k:manifest[k] for k in names},model=joint.digest(joint.MODEL))
    (OUT/'protocol.json').write_text(json.dumps(contract,indent=2),encoding='utf-8')
    merged={}
    for name in names[1:3]:
        for s in joint.read_zip(ARCH/name):
            if s['at'] in merged:
                assert merged[s['at']]==s
            merged[s['at']]=s
    sample=[s for _,s in sorted(merged.items()) if s['status']=='frozen']
    with ProcessPoolExecutor(max_workers=3,initializer=init_worker) as workers:
        forecasts=list(workers.map(build,sample,chunksize=6))
    joint.write_zip(POOL_FILE,forecasts)
    lock=dict(protocol=joint.digest(OUT/'protocol.json'),candidates=joint.digest(POOL_FILE),
              scheduled=len(merged),eligible_input=len(sample),counts=dict(Counter(s['status'] for s in merged.values())))
    (OUT/'lock.json').write_text(json.dumps(lock,indent=2),encoding='utf-8')
    print(lock,flush=True)


def interval(weeks):
    rng=random.Random(5272501)
    blocks=list(weeks.values())
    samples=[]
    for _ in range(5000):
        sample=rng.choices(blocks,k=len(blocks))
        samples.append(sum(s for s,n in sample)/sum(n for s,n in sample))
    samples.sort()
    return [samples[int((len(samples)-1)*q)] for q in (.025,.975)]


def distance_order(pools):
    def key(i):
        target=pools[i]
        discounted=target['score']/(1+target['distance']/target['hourly_range'])
        return (-discounted,target['distance'],target['lo'],target['hi'])
    return sorted(range(len(pools)),key=key)


def summary(pairs,scope):
    evidence=Counter()
    weeks=defaultdict(lambda:defaultdict(lambda:[0,0]))
    distances=defaultdict(list)
    disagreements=defaultdict(Counter)
    high_frame=defaultdict(Counter)
    examples=[]
    for s,e in pairs:
        status=e[scope]['status']
        evidence['window_'+status]+=1
        if status!='complete' or not s['pools']:continue
        pools=s['pools']
        near=min(range(len(pools)),key=lambda i:pools[i]['distance'])
        picks=dict(current=0,discount=s['priority'][0],nearest=near)
        dst=e[scope]['pools']
        week=datetime.fromisoformat(s['at']).astimezone(NY).date()
        week-=timedelta(days=week.weekday())
        evidence['n']+=1
        for name,i in picks.items():
            evidence[name]+=bool(dst[i]['sweep'])
            if {'D1','W1'}.intersection(pools[i]['source'].split('/')):
                high_frame[name]['selected']+=1
                high_frame[name]['swept']+=bool(dst[i]['sweep'])
            first=min((v['sweep'] for v in dst if v['sweep']),default=None)
            if first and sum(v['sweep']==first for v in dst)==1 and dst[i]['sweep']==first:evidence[name+'_sole_first']+=1
        for control in ('current','nearest'):
            delta=int(bool(dst[picks['discount']]['sweep']))-int(bool(dst[picks[control]]['sweep']))
            pair=weeks[control][week];pair[0]+=delta;pair[1]+=1
            evidence[control+'_wins_over_control']+=delta==1
            evidence[control+'_losses_to_control']+=delta==-1
            j=picks[control]
            i=picks['discount']
            if i!=j:
                case='same_side' if pools[i]['side']==pools[j]['side'] else 'opposite_sides'
                row=disagreements[control,case]
                row['changed']+=1
                row['discount_only']+=delta==1
                row['control_only']+=delta==-1
        if not dst[0]['sweep'] and dst[near]['sweep']:
            for name,i in [('current',0),('nearest',near)]:
                distances[name].append(pools[i]['distance']/pools[i]['hourly_range'])
            if len(examples)<5:examples.append(dict(at=s['at'],current=pools[0],closer=pools[near],first_sweep=dst[near]['sweep']))
    return dict(counts=dict(evidence),weeks=len(weeks['current']),
                delta_interval={k:interval(v) for k,v in weeks.items() if v},
                nearest_wins_median_h1={k:median(v) for k,v in distances.items()},
                high_frame={k:dict(v) for k,v in high_frame.items()},
                disagreements={'/'.join(k):dict(v) for k,v in disagreements.items()},examples=examples)


def evaluate():
    lock=json.loads((OUT/'lock.json').read_bytes())
    assert lock['candidates']==joint.digest(POOL_FILE) and lock['protocol']==joint.digest(OUT/'protocol.json')
    protocol=json.loads((OUT/'protocol.json').read_bytes())
    assert protocol['rule']==RULE and joint.digest(ARCH/'XAUUSDM5.npz')==protocol['inputs']['XAUUSDM5.npz']
    market,stamps=read_market()
    coverage=_Coverage(stamps[0],stamps[-1]+M5,market,M5)
    groups=defaultdict(list)
    for s in joint.read_zip(POOL_FILE):
        day=datetime.fromisoformat(s['at']).astimezone(NY).date()
        assert s['priority']==distance_order(s['pools'])
        ev={h:joint.assess(s,market,stamps,coverage,week=h=='week') for h in ('short','week')}
        groups['validation' if day>=date(2026,4,1) else 'early'].append((s,ev))
    # Previously reported 9–11 month cohort was seen before proposing the rule.
    recent_lock=json.loads(joint.LOCK.read_bytes())
    assert recent_lock[joint.FROZEN.name]==joint.digest(joint.FROZEN)
    assert recent_lock[joint.QUOTES.name]==joint.digest(joint.QUOTES)
    recent_market,recent_stamps=joint.load_bars()
    recent_coverage=_Coverage(recent_stamps[0],recent_stamps[-1]+M5,recent_market,M5)
    for s in joint.read_zip(joint.FROZEN):
        s['priority']=distance_order(s['pools'])
        ev={h:joint.assess(s,recent_market,recent_stamps,recent_coverage,week=h=='week') for h in ('short','week')}
        groups['recent_context'].append((s,ev))
    data={k:{h:summary(g,h) for h in ('short','week')} for k,g in groups.items()}
    (OUT/'evaluation.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    for k,v in data.items():
        for h,r in v.items():print(k,h,r['counts'],r['delta_interval'],r['nearest_wins_median_h1'])


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('freeze','evaluate'))
    (freeze if parser.parse_args().stage=='freeze' else evaluate)()
