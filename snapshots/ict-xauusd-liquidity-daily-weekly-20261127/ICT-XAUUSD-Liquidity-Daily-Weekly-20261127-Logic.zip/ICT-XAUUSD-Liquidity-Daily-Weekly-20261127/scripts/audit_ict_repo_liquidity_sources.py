"""Measure the incremental sweep coverage of the upstream wave and range sources."""

from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

import joblib
from threadpoolctl import threadpool_limits

from ict_ai.liquidity_repo_overlay import compare_shortlists, outside
from scripts import audit_ict_liquidity_repo_overlay_holdout as early
from scripts import audit_ict_repo_overlay_stability as stability


ranker, upstream = early.score, early.upstream
fixed, joint, live = upstream.fixed, upstream.joint, upstream.live
recent, shared = stability.later, stability.shared
OUT = recent.OUT.with_name('repo_overlay_source_ablation.json')
FOCUS = frozenset(('wave', 'session_range'))


def edge_book(rows):
    return [dict(**row, lo=row['price'], hi=row['price']) for row in rows]


def saved_edges(marks, status_key):
    return [(outside(row) if 'hi' in row else (row['side'], row['price']), row[status_key], row['bid_time_ms'])
            for row in marks]


def cohorts(older, later, deduplicated):
    earlier_tape = joint.read_zip(early.BID)['buckets']
    later_tape = joint.read_zip(shared.BID)['buckets']
    for stamp, entries in joint.read_zip(shared.week.INPUT)['actual'].items():
        if entries.get('buckets'):
            later_tape.setdefault(stamp, entries['buckets'][0])
    for row in older['cases']:
        grade = row['results']['15m_30s']
        arms = grade['outcomes']
        yield dict(group='jun_sep_H1', stamp=row['cutoff'], ready=grade['checked_from'], close=row['price'],
                   pool=saved_edges(arms['repo'], 'state'), local=saved_edges(arms['local'], 'state'),
                   integrated=saved_edges(arms['integrated'], 'state')), earlier_tape
    for group in recent.H1_GROUPS:
        cases = later['results'][group]['15']['cases']
        pools = {row['cutoff']: row['outcomes']['repo_unique'] for row in deduplicated['results'][group]['15']['cases']}
        for row in cases:
            marks = row['selected']
            yield dict(group=group, stamp=row['cutoff'], ready=row['checked_from'], close=row['close'],
                       pool=saved_edges(pools[row['cutoff']], 'status'), local=saved_edges(marks['local'], 'status'),
                       integrated=saved_edges(marks['fixed_two'], 'status')), later_tape


def evaluate(window, packets, line, feature, model):
    stamp = window['stamp']
    at, ready = (datetime.fromisoformat(window[key]) for key in ('stamp', 'ready'))
    seconds = int(at.timestamp())
    index = bisect_left(line.closes, seconds)
    if index == len(line.closes) or line.closes[index] != seconds or line.close[index] != window['close']:
        raise ValueError(f'Frozen native H1 and local cutoff do not match: {stamp}')
    visible = line.inputs(index, prefix=True)
    if not visible or any(row['known_at'] > seconds for row in visible):
        raise ValueError(f'Invalid upstream candidates at {stamp}')
    ranked = edge_book(ranker.rank(visible, feature, model))
    sources = defaultdict(set)
    for row in ranked:
        sources[outside(row)].add(row['kind'])
    local = [dict(side=side, lo=price, hi=price) for (side, price), _, _ in window['local']]
    local_edges = set(map(outside, local))
    starts = [at + offset * early.M5 for offset in range(3)]
    tape = fixed.reconcile([packets[t.isoformat()] for t in starts])
    if not tape or [bar.time for bar, _ in tape] != starts:
        raise ValueError(f'Missing contiguous Bid evidence at {stamp}')
    cache = {}

    def marks(picks):
        result = []
        for pick in picks:
            edge = outside(pick)
            if edge not in cache:
                cache[edge] = fixed.outcome(pick, tape, ready)
            result.append((edge, *cache[edge]))
        return result

    policies = dict(full=ranked, wave_only=[r for r in ranked if r['kind'] == 'wave'],
                    range_only=[r for r in ranked if r['kind'] == 'session_range'],
                    wave_and_range=[r for r in ranked if r['kind'] in FOCUS],
                    without_wave=[r for r in ranked if r['kind'] != 'wave'],
                    without_range=[r for r in ranked if r['kind'] != 'session_range'],
                    without_both=[r for r in ranked if r['kind'] not in FOCUS])
    results = {}
    for name, rows in policies.items():
        pick = ranker.unique_two(rows, 'price')
        replaced = compare_shortlists(local, pick, window['close'])['fixed_two']
        results[name] = marks(replaced)
        if name == 'full' and (marks(pick) != window['pool'] or results[name] != window['integrated']):
            raise ValueError(f'Full model and overlay do not reproduce: {stamp}')
    if marks(local) != window['local']:
        raise ValueError(f'Local Bid results do not reproduce: {stamp}')
    coverage = {}
    for kind in sorted(FOCUS):
        prices = {outside(row): row for row in policies['wave_only' if kind == 'wave' else 'range_only']}
        different = {key: value for key, value in prices.items() if key not in local_edges}
        exclusive = [value for key, value in different.items() if sources[key] == {kind}]
        coverage[kind] = dict(prices=len(prices), outside_local_two=len(different), exclusive_repo_source=len(exclusive),
                              exclusive_swept=sum(state == 'sweep' for _, state, _ in marks(exclusive)))
    return dict(cutoff=stamp, ready=window['ready'], local=window['local'], variants=results, coverage=coverage)


def summarize(rows):
    methods, types = defaultdict(Counter), defaultdict(Counter)
    for row in rows:
        baseline = any(state == 'sweep' for _, state, _ in row['local'])
        full = any(state == 'sweep' for _, state, _ in row['variants']['full'])
        for name, picks in row['variants'].items():
            hit = any(state == 'sweep' for _, state, _ in picks)
            methods[name].update(hits=int(hit), gained=int(hit and not baseline), lost=int(baseline and not hit),
                                 replaces=int(picks != row['local']), full_lost=int(full and not hit),
                                 full_gained=int(hit and not full))
        for name, evidence in row['coverage'].items():
            types[name].update(evidence)
            types[name]['available_windows'] += bool(evidence['prices'])
            types[name]['exclusive_swept_windows'] += bool(evidence['exclusive_swept'])
    return dict(windows=len(rows), local=sum(any(state == 'sweep' for _, state, _ in r['local']) for r in rows),
                variants=methods, source_coverage=types)


def main():
    pinned = (stability.EARLY, recent.OUT, recent.INPUT, stability.OUT, upstream.REPORT, upstream.MODEL,
              upstream.TAPE, early.BID, shared.BID, shared.week.INPUT, Path(__file__))
    pins = {path.name: joint.digest(path) for path in pinned}
    older, later, deduplicated, prior, report = map(fixed.read, pinned[:5])
    expected_inputs = ((older, upstream.MODEL, upstream.TAPE, early.BID), (later, recent.INPUT, shared.BID, shared.week.INPUT),
                       (prior, stability.EARLY, recent.OUT, recent.INPUT, upstream.REPORT))
    if any(record['inputs'][path.name] != pins[path.name] for record, *paths in expected_inputs for path in paths):
        raise ValueError('Upstream model, forecast or Bid archive no longer matches its prior result')
    if report['model_sha256'] != pins[upstream.MODEL.name] or report['sklearn'] != upstream.sklearn_version:
        raise ValueError('Unexpected upstream model or scikit-learn version')
    levels, _, feature, _ = upstream.load_sources()
    line = upstream.native_series(joint.read_zip(upstream.TAPE), levels)['H1']
    model = joblib.load(upstream.MODEL)
    results = defaultdict(list)
    seen = set()
    with threadpool_limits(limits=1):
        for window, tape in cohorts(older, later, deduplicated):
            if window['stamp'] in seen:
                raise ValueError(f'Repeated common H1 cutoff: {window["stamp"]}')
            seen.add(window['stamp'])
            results[window['group']].append(evaluate(window, tape, line, feature, model))
            if len(seen) % 100 == 0:
                print(f'{len(seen)} shared windows verified', flush=True)
    groups = {name: summarize(rows) for name, rows in results.items()}
    pooled = summarize([row for rows in results.values() for row in rows])
    expected = prior['results']['15']['pooled']['counts']
    if (pooled['windows'], pooled['local'], pooled['variants']['full']['hits']) != (
            expected['windows'], expected['local'], expected['combined']):
        raise ValueError('The locked baseline totals changed')
    live.atomic_json(OUT, dict(results=groups, pooled=pooled, windows=results, inputs=pins,
        level_blob=upstream.BLOBS['liquidity_levels.py'], orders_sent=0,
        method='Replay one fixed supplemental slot with unchanged model probabilities and strict TMGM Bid sweeps. '
               'Remove or isolate level sources before exact-price deduplication on the same H1 prefix. '
               'An exclusive price means no other upstream kind shares its exact side and price; novelty is against the two displayed local picks.'))
    print(dict(windows=pooled['windows'], local=pooled['local'], variants=pooled['variants'],
               source_coverage=pooled['source_coverage']), flush=True)


if __name__ == '__main__':
    main()
