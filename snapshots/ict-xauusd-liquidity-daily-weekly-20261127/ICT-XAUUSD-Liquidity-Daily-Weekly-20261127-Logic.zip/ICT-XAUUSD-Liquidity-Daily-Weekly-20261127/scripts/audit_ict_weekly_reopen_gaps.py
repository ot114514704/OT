"""Requery the old XAUUSD NY 18:00 M5 gaps against native bars and Bid ticks."""

from collections import Counter
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path

from scripts import audit_ict_daily_learning as market
from scripts import audit_ict_weekly_midweek as midweek
from scripts.audit_ipda_gap_ticks import TERMINAL, capture, verify_bar
from scripts.serve_ict_live import atomic_json


OUT = market.RESEARCH / "ict_weekly_reopen_gaps_20261126.json"
SYMBOL = "XAUUSD"
M5 = timedelta(minutes=5)
UTC = timezone.utc
FIELDS = ("open", "high", "low", "close")


def native_epoch(ny):
    # This is the wall-clock mapping in the frozen archive's clock witness.
    return int((ny.replace(tzinfo=UTC) + timedelta(hours=7)).timestamp())


def ohlc(bar):
    return [getattr(bar, field) for field in FIELDS] if bar else None


def range_rows(api, start, end):
    rows = api.copy_rates_range(SYMBOL, api.TIMEFRAME_M5, datetime.fromtimestamp(start, UTC),
                                datetime.fromtimestamp(end, UTC))
    if rows is None:
        raise RuntimeError(f"Native bar query failed: {api.last_error()}")
    return {int(row["time"]): [float(row[field]) for field in FIELDS] for row in rows}


def inspect(api, at, archive):
    stamp = native_epoch(at)
    prior = at - timedelta(minutes=65)
    local_starts = [prior, at + M5, at + 2 * M5, at + 3 * M5]
    raw_starts = [native_epoch(t) for t in local_starts]
    expected = [ohlc(archive.get(t)) for t in local_starts]
    native = range_rows(api, raw_starts[0], raw_starts[-1])
    native_absent_supported = (
        all(ref is not None and native.get(key) == ref for key, ref in zip(raw_starts, expected, strict=True))
        and not any(raw_starts[0] < key < raw_starts[1] for key in native)
    )
    recent = capture(api, stamp, stamp + 1200)
    prior_ticks = capture(api, raw_starts[0], raw_starts[0] + 300)
    witnesses = [verify_bar(prior_ticks if index == 0 else recent, key, ref)
                 for index, (key, ref) in enumerate(zip(raw_starts, expected, strict=True))]
    gap_ticks = sum(stamp * 1000 <= row[0] < (stamp + 300) * 1000 for row in recent)
    supported = native_absent_supported and all(row["match"] is True for row in witnesses) and gap_ticks == 0
    if supported:
        status = "no_quote_with_matching_tick_bookends"
    elif gap_ticks:
        status = "bid_quote_found_in_gap"
    elif native_absent_supported:
        status = "native_absence_reproduced_tick_bookends_incomplete"
    else:
        status = "unresolved"
    return {"at_ny": at.isoformat(), "status": status, "native_gap_reproduced": native_absent_supported,
            "gap_tick_count": gap_ticks, "native_gap_bar": native.get(stamp), "tick_bookends": witnesses,
            "native_bookends": [native.get(key) for key in raw_starts]}


def run(api):
    old = json.loads(midweek.OUT.read_bytes())
    prices = market.ARCH / "XAUUSDM5.npz"
    clock = market.ARCH / "clock_validation.json"
    archive_manifest = market.ARCH / "manifest.json"
    source_capture = market.ARCH / "capture.json"
    if old["source_hashes"][prices.name] != market.digest(prices):
        raise ValueError("Market quotes differ from the archived weekly gap audit")
    stamps = {
        datetime.fromisoformat(stamp)
        for week in old["weeks"] for day in week["coverage"].values() for stamp in day["missing"]
        if not midweek.calendar(datetime.fromisoformat(stamp))
    }
    clock_witness = json.loads(clock.read_bytes())
    if "minus seven hours" not in clock_witness["conversion"]:
        raise ValueError("Unexpected frozen archive clock mapping")
    bars, _ = market.read_market()
    archive = {bar.time: bar for bar in bars}
    if json.loads(archive_manifest.read_bytes())[source_capture.name] != market.digest(source_capture):
        raise ValueError("The archived terminal capture no longer matches its manifest")
    expected_server = json.loads(source_capture.read_bytes())["server"]
    if not api.initialize(str(TERMINAL), timeout=7000):
        raise RuntimeError(f"MT5 unavailable: {api.last_error()}")
    try:
        before = api.account_info()
        if before is None or before.server != expected_server or not api.terminal_info().connected:
            raise RuntimeError("Need a connected terminal on the archived TMGM server")
        cases = []
        for at in sorted(stamps):
            try:
                cases.append(inspect(api, at, archive))
            except RuntimeError as error:
                cases.append({"at_ny": at.isoformat(), "status": "read_error", "error": str(error)})
        after = api.account_info()
        if after is None or (after.login, after.server) != (before.login, before.server):
            raise RuntimeError("Terminal account changed during the read-only audit")
    finally:
        api.shutdown()
    return {
        "cases": cases, "counts": dict(Counter(row["status"] for row in cases)),
        "server": expected_server, "checked_at_utc": datetime.now(UTC).isoformat(),
        "sources": {p.name: market.digest(p) for p in (
            midweek.OUT, prices, clock, archive_manifest, source_capture, Path(__file__),
        )},
        "scope": ("Strict support requires native M5 absence, no Bid/Ask ticks inside the missing slot, "
                  "and matching reconstructed tick OHLC at 16:55 and 18:05–18:15 NY."),
        "orders_sent": 0,
    }


if __name__ == "__main__":
    import MetaTrader5 as mt5

    report = run(mt5)
    atomic_json(OUT, report)
    print(json.dumps(report["counts"]))
