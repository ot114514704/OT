"""Bar-by-bar liquidity account replay for Nov 16–20, 2026."""

from argparse import ArgumentParser
from collections import defaultdict
from datetime import datetime
from html import escape
import math
from pathlib import Path

from ict_ai.range_liquidity import _Coverage
from scripts import backtest_ict_liquidity_account as replay


INITIAL_BALANCE = 34.0
STOP_DISTANCE = 10.0
LEVERAGE = 1000
START = datetime(2026, 11, 16, tzinfo=replay.NY)
END = datetime(2026, 11, 20, 16, 55, tzinfo=replay.NY)
OUT = replay.OUT / 'week_20261116_34usd_stop10'


def bar_timeline(bars, snapshots, signals, scenario, last_quotes, units):
    by_signal = {s['signal_at']: s for s in signals}
    decisions = {datetime.fromisoformat(d['signal_at']): d for d in scenario['decisions']}
    by_snapshot = {datetime.fromisoformat(s['at']): s for s in snapshots}
    executions = defaultdict(list)
    for i, trade in enumerate(scenario['ledger'], 1):
        for event in ('entry', 'exit'):
            bucket = trade[f'{event}_at_ms'] // 300000 * 300000
            executions[bucket].append(dict(kind=event, trade=i, time=trade[f'{event}_at'],
                                         price=trade[event], direction=trade['direction']))
    active = None
    cash = scenario['start_usd']
    ledger = scenario['ledger']
    rows = []
    for bar in bars:
        opened = replay.time_ms(bar.time)
        closed = bar.time + replay.M5
        events = executions.get(opened, [])
        for event in events:
            if event['kind'] == 'entry':
                if active is not None:
                    raise ValueError('Sequential account holds overlapping positions')
                active = event['trade']
            else:
                if active != event['trade']:
                    raise ValueError('Exit lacks a matching active trade')
                cash = ledger[active - 1]['balance_usd']
                active = None
        equity = cash
        if active is not None:
            trade = ledger[active - 1]
            if opened not in last_quotes:
                raise ValueError(f'Missing verified mark for open trade on {bar.time}')
            bid, ask = last_quotes[opened]
            side = trade['direction']
            liquidation = bid if side == 1 else ask
            equity += side * (liquidation - trade['entry']) * units - trade['commission_usd']
        decision = decisions.get(closed)
        snapshot = by_snapshot.get(closed)
        hhmm = bar.time.astimezone(replay.NY).isoformat(timespec='minutes')
        rows.append(dict(open_ny=hhmm, close_utc=closed.isoformat(), ohlc=replay.ohlc(bar),
                         frozen_snapshot=(dict(ready=snapshot['ready'], source=snapshot['source'],
                                               pools=snapshot['pools']) if snapshot else None),
                         decision=decision, signal=by_signal[decision['signal_at']] if decision else None,
                         events=events, active_trade=active, cash_usd=cash, equity_usd=round(equity, 2)))
    if active is not None or cash != scenario['end_usd']:
        raise AssertionError('M5 timeline does not reconcile to the account')
    return rows


def day_totals(rows, scenarios):
    trade_days = defaultdict(list)
    for trade in scenarios['baseline']['ledger']:
        day = datetime.fromisoformat(trade['exit_at']).astimezone(replay.NY).date().isoformat()
        trade_days[day].append(trade)
    daily = {}
    for row in rows:
        day = row['open_ny'][:10]
        daily.setdefault(day, dict(bars=0, trades=len(trade_days[day]),
                                   net_usd=round(sum(t['net_usd'] for t in trade_days[day]), 2)))
        daily[day]['bars'] += 1
        daily[day]['cash_usd'] = row['cash_usd']
    return daily


def render_html(report):
    labels = dict(executed='成交', one_position_limit='已有持仓', insufficient_modeled_equity='资金不足',
                  target_already_at_or_past_entry='目标已越过', unavailable_entry_quote='缺入场报价',
                  unavailable_deadline_quote='缺退出报价', unverified_execution_path='成交路径未核验',
                  fixed_stop_inside_protected_structure='固定止损位于结构内', entry_after_time_window='成交报价已过时窗')
    by_day = defaultdict(list)
    for row in report['bars']:
        by_day[row['open_ny'][:10]].append(row)
    base = report['scenarios']['baseline']
    title = escape(report.get('title', '黄金流动性逐根回测'))
    parts = ['<!doctype html><html lang="zh-CN"><meta charset="utf-8">',
             '<meta name="viewport" content="width=device-width, initial-scale=1">',
             f'<title>{title}</title>',
             '''<style>
body{font:15px system-ui,sans-serif;color:#162831;background:#f5f7f8;max-width:1120px;margin:30px auto;padding:0 18px}
header,details{background:white;border:1px solid #cdd8dd;border-radius:8px;padding:14px 18px;margin:12px 0}
h1{font-size:24px;margin:.2em 0}p{line-height:1.55}summary{cursor:pointer;font-weight:650;padding:5px 0}
table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums;font-size:13px}
th,td{padding:5px 9px;border-bottom:1px solid #e4eaed;white-space:nowrap;text-align:right}
th:first-child,td:first-child,td:nth-child(6),th:nth-child(6){text-align:left}
.scroll{overflow:auto}.event{background:#e7f4f2}
</style>''', f'<body><header><h1>{title}</h1>',
             f'<p>纽约时间 2026 年 11 月 16 日至 20 日。起始 ${report["principal_usd"]:g}，'
             f'{report["volume_lots"]:g} 手，${report["stop_distance_usd"]:g} 止损，1:{report["leverage"]} 杠杆。每 5 分钟一行。</p>',
             f'<p>基础费用 <strong>{base["trades"]} 笔 · 期末 ${base["end_usd"]:.2f} · 最大权益回撤 {base["max_drawdown_pct"]:.2f}%</strong></p>',
             '<p>收线列显示本根确认的信号与资金结果，开平仓按实际报价所属 K 线登记。权益为收线计价。</p></header>']
    for day, rows in by_day.items():
        daily = report['daily'][day]
        parts.append(f'<details><summary>{day} · {daily["bars"]} 根 · 平仓 {daily["trades"]} 笔 · {daily["net_usd"]:+.2f} USD</summary>')
        parts.append('<div class="scroll"><table><thead><tr><th>纽约开盘</th><th>开</th><th>高</th><th>低</th><th>收</th>'
                     '<th>事件</th><th>余额 USD</th><th>权益 USD</th></tr></thead><tbody>')
        for row in rows:
            event_text = []
            if row['frozen_snapshot']:
                event_text.append('冻结候选')
            if row['decision']:
                status = row['decision']['status']
                pool = row['signal']['pool']['scope']
                direction = '多' if row['signal']['direction'] == 1 else '空'
                setup = row['signal'].get('setup', f'{pool} 扫回')
                event_text.append(f'{setup} → {direction} · {labels.get(status, status)}')
            for event in row['events']:
                kind = '入场' if event['kind'] == 'entry' else '平仓'
                event_text.append(f'#{event["trade"]} {kind} {event["price"]:.2f}')
            prices = ''.join(f'<td>{x:.2f}</td>' for x in row['ohlc'])
            cls = ' class="event"' if event_text else ''
            explain = escape(' ｜ '.join(event_text))
            parts.append(f'<tr{cls}><td>{row["open_ny"][11:16]}</td>{prices}<td>{explain}</td>'
                         f'<td>{row["cash_usd"]:.2f}</td><td>{row["equity_usd"]:.2f}</td></tr>')
        parts.append('</tbody></table></div></details>')
    return '\n'.join(parts + ['</body></html>'])


def scenario_directory(initial_balance, stop_distance):
    if any(not math.isfinite(x) or x <= 0 or round(x, 2) != x for x in (initial_balance, stop_distance)):
        raise ValueError('Balance and stop must be positive dollar amounts with up to two decimals')
    balance_text = f'{initial_balance:.2f}'.rstrip('0').rstrip('.')
    stop_text = f'{stop_distance:.2f}'.rstrip('0').rstrip('.')
    return OUT.with_name(f'week_20261116_{balance_text}usd_stop{stop_text}')


def main(initial_balance=INITIAL_BALANCE, stop_distance=STOP_DISTANCE):
    destination = scenario_directory(initial_balance, stop_distance)
    capture_path, plan, all_bars, all_snapshots, _, _ = replay.locked_capture()
    snapshots = [row for row in all_snapshots if START <= datetime.fromisoformat(row['at']) < END]
    expected = set(replay.planned_checkpoints(START, END))
    if {datetime.fromisoformat(s['at']) for s in snapshots} != expected or len(snapshots) != len(expected):
        raise ValueError('Missing or duplicate weekly checkpoint')
    bars = [bar for bar in all_bars if START <= bar.time < END]
    if bars[0].time != START or bars[-1].time + replay.M5 != END or _Coverage(START, END, bars, replay.M5).missing[-1]:
        raise ValueError('Weekly M5 coverage is incomplete')
    signals, exclusions, parity = replay.signals(snapshots, all_bars, START, END)
    scenarios, quotes, last_quotes = replay.simulate_accounts(
        signals, all_bars, dict(plan, leverage=LEVERAGE), END,
        initial_balance=initial_balance, stop_distance=stop_distance, trace=True)
    units = plan['observed_contract']['trade_contract_size'] * replay.VOLUME
    timeline = bar_timeline(bars, snapshots, signals, scenarios['baseline'], last_quotes, units)
    report = dict(period_ny=dict(start=START.isoformat(), end=END.isoformat()), version='1.34',
                  principal_usd=initial_balance, volume_lots=replay.VOLUME, stop_distance_usd=stop_distance,
                  leverage=LEVERAGE, margin_basis=f'Entry quote × {units:g} oz / {LEVERAGE} estimate. '
                  f'Original account gate requires max(margin, {stop_distance * units:g} USD plus commission).',
                  snapshots=len(snapshots), signals=len(signals), signal_prefix_checks=parity, signal_exclusions=exclusions,
                  chart_bars=len(bars), quote_audit=quotes, scenarios=scenarios, daily=day_totals(timeline, scenarios),
                  lowest_m5_close_equity=min(timeline, key=lambda row: row['equity_usd'])['equity_usd'],
                  bars=timeline, capture_sha256=replay.digest(capture_path),
                  replay_engine_sha256=replay.digest(Path(replay.__file__)), orders_sent=0)
    replay.atomic_json(destination / 'report.json', report)
    (destination / 'replay.html').write_text(render_html(report), encoding='utf-8')
    for name, result in scenarios.items():
        print(name, {k:v for k,v in result.items() if k not in ('decisions', 'ledger', 'execution_coverage_exclusions')})
    print(report['daily'], report['quote_audit'])


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--initial-balance', type=float, default=INITIAL_BALANCE)
    parser.add_argument('--stop-distance', type=float, default=STOP_DISTANCE)
    args = parser.parse_args()
    main(args.initial_balance, args.stop_distance)
