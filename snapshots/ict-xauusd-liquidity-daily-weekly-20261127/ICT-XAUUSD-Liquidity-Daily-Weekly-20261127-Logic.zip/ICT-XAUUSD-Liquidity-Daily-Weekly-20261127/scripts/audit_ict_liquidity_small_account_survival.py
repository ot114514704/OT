"""Replay one previously tested account continuously and from each frozen NY week."""

from argparse import ArgumentParser
from collections import defaultdict
from datetime import datetime, time, timedelta
import json
from pathlib import Path

from scripts import backtest_ict_liquidity_account as replay
from scripts import replay_ict_liquidity_small_account as weekly_reference


def ny_week(stamp):
    day = datetime.fromisoformat(stamp).astimezone(replay.NY).date()
    return day - timedelta(days=day.weekday())


def first_funding_rejection(scenario):
    return next((d for d in scenario['decisions'] if d['status'] == 'insufficient_modeled_equity'), None)


def compact(scenario):
    return dict({k: v for k, v in scenario.items() if k not in ('decisions', 'ledger')},
                first_funding_rejection=first_funding_rejection(scenario))


def main(initial_balance, stop_distance):
    reference_report = weekly_reference.scenario_directory(initial_balance, stop_distance) / 'report.json'
    past = json.loads(reference_report.read_bytes())
    if (past['principal_usd'], past['stop_distance_usd'], past['leverage']) != (
            initial_balance, stop_distance, weekly_reference.LEVERAGE):
        raise ValueError('Weekly replay reference uses different account terms')
    capture, market, bars, snapshots, start, end = replay.locked_capture()
    picked, excluded, parity = replay.signals(snapshots, bars, start, end)
    if dict(signal_exclusions=excluded, prefix_checks=parity) != market['audit']:
        raise ValueError('Two-month frozen liquidity signal audit changed')
    account_spec = dict(market, leverage=weekly_reference.LEVERAGE)
    terms = dict(initial_balance=initial_balance, stop_distance=stop_distance, trace=True)
    continuous, quote_audit, _ = replay.simulate_accounts(picked, bars, account_spec, end, **terms)
    if any(run['execution_coverage_exclusions'] for run in continuous.values()):
        raise ValueError('Continuous account has unverified quote paths')
    signals_by_week = defaultdict(list)
    snapshots_by_week = defaultdict(list)
    for signal in picked:
        signals_by_week[ny_week(signal['signal_at'])].append(signal)
    for snapshot in snapshots:
        snapshots_by_week[ny_week(snapshot['at'])].append(snapshot)

    weeks = []
    for monday, candidates in sorted(snapshots_by_week.items()):
        week_start = datetime.combine(monday, time(0), replay.NY)
        week_end = datetime.combine(monday + timedelta(days=4), time(16, 55), replay.NY)
        eligible = signals_by_week[monday]
        planned = set(replay.planned_checkpoints(week_start, week_end))
        available = {datetime.fromisoformat(s['at']) for s in candidates}
        full = start <= week_start and week_end <= end and available == planned
        # Positions already close on their own NY trading days. The full study
        # cutoff stays in force so moving the initial deposit cannot move exits.
        round_results, _, _ = replay.simulate_accounts(eligible, bars, account_spec, end, **terms)
        if any(run['execution_coverage_exclusions'] for run in round_results.values()):
            raise ValueError(f'Unverified execution in the week of {monday}')
        row = dict(week_ny=monday.isoformat(), complete=full, checkpoints=len(candidates), signals=len(eligible),
                   scenarios={k: compact(v) for k, v in round_results.items()})
        if monday == weekly_reference.START.date():
            for scenario, run in round_results.items():
                if run['ledger'] != past['scenarios'][scenario]['ledger'] or run['decisions'] != past['scenarios'][scenario]['decisions']:
                    raise ValueError('Prior weekly replay did not reproduce at the same start')
            row['matches_prior_weekly_ledger'] = True
        weeks.append(row)

    complete = [w for w in weeks if w['complete']]
    frequencies = {}
    for name in replay.COSTS:
        results = [w['scenarios'][name] for w in complete]
        frequencies[name] = dict(complete_weeks=len(results), profitable=sum(r['net_usd'] > 0 for r in results),
                                 funding_rejected=sum(r['first_funding_rejection'] is not None for r in results),
                                 ended_below_risk_gate=sum(r['end_usd'] < stop_distance + r['commission_round_turn_per_lot'] * replay.VOLUME
                                                           for r in results),
                                 smallest_end_usd=min((r['end_usd'] for r in results), default=None),
                                 largest_end_usd=max((r['end_usd'] for r in results), default=None))
    report = dict(period=dict(start=start.isoformat(), end=end.isoformat()), initial_balance_usd=terms['initial_balance'],
                  stop_distance_usd=terms['stop_distance'], leverage=weekly_reference.LEVERAGE, volume_lots=replay.VOLUME,
                  contract='Same 1.34 pool freezes, sweep/reclaim and execution as the previous bar-by-bar study.',
                  methodology='Weekly scenarios start with the same initial deposit on the same frozen signals. A full week needs all 25 checkpoints from NY Monday to Friday. No replenishment in any individual replay.',
                  continuous={k: dict(v, first_funding_rejection=first_funding_rejection(v)) for k, v in continuous.items()},
                  complete_week_frequencies=frequencies, weekly_independent=weeks, quote_audit=quote_audit,
                  signal_prefix_checks=parity, provenance={'capture': replay.digest(capture),
                  'weekly_report': replay.digest(reference_report),
                  'engine': replay.digest(Path(replay.__file__)), 'script': replay.digest(Path(__file__))}, orders_sent=0)
    name = reference_report.parent.name.removeprefix('week_20261116_')
    replay.atomic_json(replay.OUT / f'{name}_account_survival.json', report)
    print('Continuous:', {k: [v['end_usd'], v['trades'], v['max_drawdown_pct'], first_funding_rejection(v)]
                         for k, v in continuous.items()})
    print('Weekly:', [(w['week_ny'], w['complete'], w['scenarios']['baseline']['end_usd'],
                      w['scenarios']['baseline']['first_funding_rejection'] is not None) for w in weeks])
    print('Complete:', frequencies)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--initial-balance', type=float, required=True)
    parser.add_argument('--stop-distance', type=float, required=True)
    args = parser.parse_args()
    main(args.initial_balance, args.stop_distance)
