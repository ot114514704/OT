"""Predict the same 30-minute post-crossing outcome from early closed-M5 prefixes."""

from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import json
from pathlib import Path

import numpy as np

from ict_ai.sweep_response import crossing_response
from ict_ai.sweep_state import crossing_state
from scripts import audit_ict_sweep_combination as older
from scripts import replay_ict_sweep_verdict as replay
from scripts.audit_ict_target_ranking import fit_prior_weeks
from scripts.check_pool_priority import interval


OUT = replay.study.RESEARCH / 'ict_sweep_early_readout_20261125.json'
OFFSETS = (0, 5, 10, 15)
LABELS = ('sweep', 'break', 'mixed')
HOLDOUT = replay.filters.OCT
MIDYEAR = datetime(2026, 6, 1, tzinfo=replay.study.NY)
M5 = replay.M5
BASE = ('signed_close_distance', 'absolute_close_distance')
EXTRA = ('cross_open', 'cross_close', 'outer_excursion', 'inside_excursion', 'latest_body',
         'mean_close_distance', 'fraction_outside', 'v7b_sweep', 'v7b_break', 'state2_sweep',
         'state2_break', 'state2_strength')


def unique_crossings(snapshots, outcomes):
    events = defaultdict(set)
    for board, result in zip(snapshots, outcomes, strict=True):
        if board['at'] != result['at']:
            raise ValueError('Frozen board and outcomes differ in cutoff')
        short = result['short']
        if short['status'] != 'complete':
            continue
        for scope in ('IRL', 'ERL'):
            for pool, observed in list(zip(board['pools'][scope], short[scope], strict=True))[:10]:
                if observed['sweep']:
                    side = pool['side']
                    edge = pool['hi'] if side == 1 else pool['lo']
                    stamp = datetime.fromisoformat(observed['sweep'])
                    if datetime.fromisoformat(board['at']) > stamp - M5:
                        raise ValueError('Frozen pool was staged after its crossing candle opened')
                    events[stamp, side, edge].add(scope)
    return events


def features(side, edge, before, first, follow, observed):
    verdict = crossing_response(side, edge, before, first, follow, observed)
    atr = verdict['prior_atr']
    if not atr or verdict['status'] in ('incomplete', 'unverified_cross'):
        return None
    prefix = [first, *(bar for bar in follow if bar.time + M5 <= observed)]

    def scaled(value):
        return float(np.clip(side * (value - edge) / atr, -10, 10))

    prices = [scaled(bar.close) for bar in prefix]
    last = prefix[-1]
    state = crossing_state(side, edge, first, follow, observed, atr)
    upper = first.high if side == 1 else first.low
    lower = first.low if side == 1 else first.high
    return [prices[-1], abs(prices[-1]), scaled(first.open), prices[0], scaled(upper), scaled(lower),
            float(np.clip(side * (last.close - last.open) / atr, -10, 10)), sum(prices) / len(prices),
            sum(price > 0 for price in prices) / len(prices), int(verdict['status'] == 'sweep'),
            int(verdict['status'] == 'break'), int(state['status'] == 'sweep'), int(state['status'] == 'break'),
            state['strength']]


def dataset(events, bars, times):
    admitted, omitted = [], Counter()
    for (stamp, side, edge), scopes in sorted(events.items()):
        opened = stamp - M5
        i = bisect_left(times, opened)
        path = replay.verify_observation(bars, i, 10)
        if not path or path[0].time != opened:
            omitted['missing_response_or_outcome'] += 1
            continue
        first, *follow = path
        before = bars[max(0, i - 15):i]
        if not features(side, edge, before, first, [], stamp):
            omitted['missing_cross_or_prior_atr'] += 1
            continue
        y = [side * (b.close - edge) for b in path[4:]]
        outcome = 'sweep' if all(x < 0 for x in y) else 'break' if all(x > 0 for x in y) else 'mixed'
        values = {}
        for offset in OFFSETS:
            at = stamp + timedelta(minutes=offset)
            x = features(side, edge, before, first, follow[:offset // 5], at)
            if not x or x != features(side, edge, before, first, follow, at):
                raise ValueError(f'Future candles changed an apparent observation at {at}')
            values[offset] = x
        local = stamp.astimezone(replay.study.NY).date()
        admitted.append(dict(stamp=stamp, end=path[-1].time + M5, scopes=sorted(scopes),
                             side=side, edge=edge, week=str(local - timedelta(days=local.weekday())),
                             y=LABELS.index(outcome), x=values))
    return admitted, omitted


def fit(train, offset, width):
    candles = defaultdict(list)
    for row in train:
        candles[row['stamp']].append(row)
    return [fit_prior_weeks([dict(x=[r['x'][offset][:width] for r in rows],
                                  y=[r['y'] == label for r in rows]) for rows in candles.values()])
            for label in range(len(LABELS))]


def probabilities(models, rows, offset, width):
    x = np.array([r['x'][offset][:width] for r in rows])
    vectors = []
    for mean, scale, coef in models:
        logits = coef[0] + ((x - mean) / scale) @ coef[1:]
        vectors.append(1 / (1 + np.exp(-np.clip(logits, -40, 40))))
    p = np.column_stack(vectors)
    return p / p.sum(axis=1, keepdims=True)


def report(rows, forecasts, offset):
    actual = np.array([r['y'] for r in rows])
    truth = np.eye(len(LABELS))[actual]
    metrics = {}
    for name, p in forecasts.items():
        prediction = p.argmax(axis=1)
        squares = ((p - truth) ** 2).sum(axis=1)
        metrics[name] = dict(brier=float(squares.mean()), log_loss=float(-np.log(p[range(len(rows)), actual]).mean()),
                             correct=int((prediction == actual).sum()),
                             calls=dict(zip(LABELS, map(int, np.bincount(prediction, minlength=len(LABELS))), strict=True)),
                             brier_cases=squares)
    blocks = defaultdict(lambda: [0, 0])
    close_loss = metrics['close_only'].pop('brier_cases')
    full_loss = metrics['with_response'].pop('brier_cases')
    metrics['event_frequency'].pop('brier_cases')
    for r, v in zip(rows, close_loss - full_loss, strict=True):
        entry = blocks[r['week']]
        entry[0] += float(v)
        entry[1] += 1
    close = np.array([r['x'][offset][0] for r in rows])
    signed = np.where(close < 0, 0, np.where(close > 0, 1, 2))
    return dict(events=len(rows), outcomes=Counter(LABELS[n] for n in actual),
                signed_close_correct=int((signed == actual).sum()), models=metrics,
                paired_brier_gain=float((close_loss - full_loss).mean()),
                paired_brier_week_ci95=interval(blocks) if len(blocks) > 1 else None)


def evaluate(train, holdout):
    n = len(holdout)
    prior = np.bincount([r['y'] for r in train], minlength=len(LABELS)) + 1
    results = {}
    close_models = {}
    for offset in OFFSETS:
        forecasts = {'event_frequency': np.tile(prior / prior.sum(), (n, 1))}
        for name, width in (('close_only', len(BASE)), ('with_response', len(BASE) + len(EXTRA))):
            estimates = fit(train, offset, width)
            forecasts[name] = probabilities(estimates, holdout, offset, width)
            if name == 'close_only':
                close_models[str(offset)] = [[part.tolist() for part in row] for row in estimates]
        slices = {'all': list(range(n))}
        slices.update({scope: [i for i, row in enumerate(holdout) if scope in row['scopes']] for scope in ('IRL', 'ERL')})
        results[str(offset)] = {scope: report([holdout[i] for i in indices],
                                             {name: p[indices] for name, p in forecasts.items()}, offset)
                                for scope, indices in slices.items() if indices}
    return results, dict(close_by_offset=close_models, prior=(prior / prior.sum()).tolist())


def main():
    bars, times, snapshots, outcomes, _, sources = replay.read_inputs()
    archive = replay.filters.ranking.ARCHIVE
    for path in (archive / 'round19_liquidity_50_candidates.json.gz', archive / 'round19_liquidity_50_outcomes.json.gz'):
        sources[path.name] = replay.study.digest(path)
    rows, omitted = dataset(unique_crossings(snapshots, outcomes), bars, times)
    train = [r for r in rows if r['stamp'] < HOLDOUT and r['end'] <= HOLDOUT]
    holdout = [r for r in rows if r['stamp'] >= HOLDOUT]
    previous, prior_bars, prior_times, prior_sources = older.older_events()
    prior_events = {(datetime.fromisoformat(r['crossing_at']), r['side'], r['edge']): {'nearest'}
                    for r in previous}
    prior, prior_omitted = dataset(prior_events, prior_bars, prior_times)
    earlier_train = [r for r in prior if r['stamp'] < MIDYEAR and r['end'] <= MIDYEAR]
    results, closed_distance_model = evaluate(train, holdout)
    replication, _ = evaluate(earlier_train, train)
    for cohort, scores in (('primary', results), ('earlier', replication)):
        for offset, outcomes in scores.items():
            print(cohort, offset, {scope: (s['events'], s['signed_close_correct'], s['paired_brier_gain'],
                                         s['paired_brier_week_ci95']) for scope, s in outcomes.items()}, flush=True)
    replay.filters.atomic_json(OUT, dict(training_cases=len(train), test_cases=len(holdout), omissions=omitted,
        holdout_start=HOLDOUT.isoformat(), latest_training_maturity=max(r['end'] for r in train).isoformat(),
        prefix_checks=(len(rows)+len(prior)) * len(OFFSETS), features={'close': BASE, 'extra': EXTRA},
        rule='Six M5s open from +15 through +40 and settle by +45 after the crossing close. All inside, all outside, or mixed.',
        sampling='Frozen top 10 pools by scope; unique crossing close, side and edge. Training gives each crossing candle unit total weight.',
        inputs=sources | {Path(__file__).name: replay.study.digest(Path(__file__)),
                          'sweep_state': replay.study.digest(replay.filters.ROOT / 'ict_ai/sweep_state.py')},
        closed_distance_model=closed_distance_model,
        earlier_replication=dict(training_cases=len(earlier_train), test_cases=len(train), omissions=prior_omitted,
                                 latest_training_maturity=max(r['end'] for r in earlier_train).isoformat(),
                                 inputs=prior_sources, test_start=MIDYEAR.isoformat(),
                                 training_scope='Nearest pool in the older TMGM archive', results=replication),
        retrospective_only=True, results=results, orders_sent=0))


if __name__ == '__main__':
    main()
