"""Replay the MT5 DOL feed at each closed M5 timestamp in a frozen archive."""
import argparse
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from ict_ai.dol_outlook import outlook, H1, M5
from ict_ai.po3 import po3_zones
from ict_ai.profile_lifecycle import daily_profile_lifecycle
from ict_ai.timebase import NY, session_windows
from scripts.export_mt5_profiles import add_smt, midnight
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ict_news import load_history


def replay(archive, start, end, dollar_manifest=None):
    if start.utcoffset() is None or end.utcoffset() is None or start > end:
        raise ValueError("Ordered timezone-aware checkpoints required")
    gold_meta, gold_hash, quotes = load_history(archive / "XAU/provenance.json")
    silver_meta, silver_hash, silver = load_history(archive / "XAG/provenance.json", "XAGUSD")
    rows = list(quotes.values())
    last = rows[-1].time + M5
    if start < rows[0].time + M5 or end > last or any(t.timestamp() % 300 for t in (start,end)):
        raise ValueError("Checkpoints must be within the archive and aligned to M5 closes")
    m15 = aggregate_bars(rows, 5, 15, last)
    h1 = aggregate_bars(rows, 5, 60, last)
    peer_series = [("XAGUSD", "白银", False, silver_meta, silver)]
    dollar_hash = dollar_captured = None
    if dollar_manifest:
        meta, dollar_hash, bars = load_history(dollar_manifest, "USIDX")
        dollar_captured = meta["finished_at_utc"]
        peer_series.append(("USIDX", "美元指数", True, meta, bars))
    peer_hours = {}
    for symbol, label, inverse, meta, bars in peer_series:
        if meta["server"] != gold_meta["server"]:
            raise ValueError(f"{symbol}: different broker server")
        if (meta.get("source_clock_segments") or meta.get("source_clock_offset_hours")) != (
            gold_meta.get("source_clock_segments") or gold_meta.get("source_clock_offset_hours")
        ):
            raise ValueError(f"{symbol}: incompatible historical clock mapping")
        hourly = aggregate_bars(list(bars.values()), 5, 60, last)
        if not any(start-H1 <= b.time+H1 <= end for b in hourly):
            raise ValueError(f"{symbol}: no complete H1 bars overlapping the replay window")
        peer_hours[symbol] = (label, inverse, hourly)
    def peers(gold, at):
        result = []
        for label, inverse, hourly in peer_hours.values():
            visible = [b for b in hourly if b.time+H1<=at]
            result.extend(add_smt(lambda *args: None, gold, visible, at, label, inverse))
        return result
    all_peers = peers(h1,last)
    records = []
    at = start
    while at <= end:
        if at-M5 not in quotes:
            records.append({"close_ny":at.astimezone(NY).isoformat(),"status":"no_closed_bar"})
            at += M5
            continue
        day = (at-M5).astimezone(NY).date()
        if day.weekday() >= 5:
            raise ValueError("The live DOL feed is published for NY weekdays")
        a,z = session_windows(day)["asia"]
        begin = min(a,midnight(day-timedelta(days=day.weekday())))
        def calculate(source, gold_hourly, quarters, observations):
            recent = [b for b in quarters if b.time >= begin]
            context = daily_profile_lifecycle(recent,day,at,include_reconstruction=False,
                                              reference_m5=[b for b in source if b.time>=begin])
            phases = po3_zones(recent,a,z,midnight(day+timedelta(days=1)),at)
            return outlook(source,gold_hourly,recent,at,context,phases,observations,nearby_priority=True)
        closed = [b for b in rows if b.time+M5<=at]
        gold_hours = [b for b in h1 if b.time+H1<=at]
        frozen = calculate(closed,gold_hours,[b for b in m15 if b.time+3*M5<=at],
                           peers(gold_hours,at))
        if calculate(rows,h1,m15,all_peers) != frozen:
            raise AssertionError(f"Later data changed the forecast at {at.isoformat()}")
        following = quotes.get(at)
        targets = []
        for kind,_,_,label,lo,hi in frozen[1:]:
            touch = None if following is None else following.low<=hi and following.high>=lo
            targets.append({"side":kind,"low":lo,"high":hi,"evidence":label,"next_m5_overlap":touch})
        peer_close = {symbol: max((b.time+H1 for b in data[2] if b.time+H1<=at),default=None)
                      for symbol,data in peer_hours.items()}
        records.append({"close_ny":at.astimezone(NY).isoformat(),"price":closed[-1].close,
                        "last_peer_h1_close_ny":{s:t.astimezone(NY).isoformat() if t else None
                                                 for s,t in peer_close.items()},
                        "context":frozen[0][3],"targets":targets})
        at += M5
    return {"gold_sha256":gold_hash,"silver_sha256":silver_hash,"usidx_sha256":dollar_hash,
            "coverage":"Frozen XAUUSD, "+", ".join(peer_hours)+" M5; H1/M15 from complete buckets. Live news excluded.",
            "usidx_captured_utc":dollar_captured,
            "next_m5_overlap":"Observed bar range intersects target. Null when unavailable; no ordering or fill inferred.",
            "records":records}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive",type=Path)
    parser.add_argument("start",type=datetime.fromisoformat)
    parser.add_argument("end",type=datetime.fromisoformat)
    parser.add_argument("output",type=Path)
    parser.add_argument("--usidx-manifest",type=Path)
    args=parser.parse_args()
    report=replay(args.archive,args.start,args.end,args.usidx_manifest)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"{sum('targets' in row for row in report['records'])} verified checkpoints")
