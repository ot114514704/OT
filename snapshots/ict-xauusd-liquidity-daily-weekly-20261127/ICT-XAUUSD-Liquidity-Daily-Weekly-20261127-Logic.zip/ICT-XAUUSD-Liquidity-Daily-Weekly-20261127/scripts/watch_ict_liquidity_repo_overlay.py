"""Record live H1 liquidity comparisons before measuring either shortlist."""

from argparse import ArgumentParser
from collections import Counter
from datetime import datetime, timedelta
import json
from pathlib import Path
from time import sleep

import joblib
from threadpoolctl import threadpool_limits

from ict_ai.liquidity_repo_overlay import compare_shortlists, outside
from ict_ai.range_liquidity import _research_open
from scripts import audit_ict_repo_liquidity_dedup as dedup
from scripts import audit_ict_liquidity_repo_overlay as replay


upstream = dedup.upstream
fixed, live, joint = upstream.fixed, upstream.live, upstream.joint
source, M5 = upstream.stream, fixed.M5
OUT = upstream.DIR.with_name('ict_liquidity_repo_overlay_forward_20261125')
POLICY = OUT / 'policy.json'
HORIZONS = (5, 15, 60)


def load_policy():
    local = source.load_policy()
    report = fixed.read(upstream.REPORT)
    study = fixed.read(replay.OUT)
    paths = (Path(__file__), Path(replay.__file__), Path(upstream.__file__), Path(dedup.__file__),
             Path(fixed.__file__), Path(fixed.capture_buckets.__code__.co_filename), live.quotes.CLOCK,
             source.POLICY, upstream.MODEL, upstream.REPORT, replay.OUT,
             joint.ROOT / 'ict_ai/liquidity_repo_overlay.py')
    pins = {path.name: joint.digest(path) for path in paths}
    if (report['model_sha256'] != pins[upstream.MODEL.name] or report['sklearn'] != upstream.sklearn_version
            or report['upstream_blobs'] != upstream.BLOBS
            or any(study['inputs'][p.name] != pins[p.name] for p in (Path(replay.__file__), paths[-1]))):
        raise ValueError('Research rules or trained weights changed')
    if not POLICY.is_file():
        fixed.write_once(POLICY, dict(frozen_at=live.now().isoformat(), pins=pins, horizons=HORIZONS,
                                     upstream_blobs=upstream.BLOBS, orders_sent=0))
    policy = fixed.read(POLICY)
    if policy['pins'] != pins or tuple(policy['horizons']) != HORIZONS:
        raise ValueError('Prospective comparison policy changed')
    return policy, local


def native_history(at, levels, terminal_feed):
    earlier = datetime(2024, 1, 1, tzinfo=upstream.UTC)
    with live.terminal() as (api, _):
        expected = live.quotes.checked_terminal(api)
        if expected.server != terminal_feed['server']:
            raise ValueError('The forecast and settlement broker differ')
        rates = api.copy_rates_range('XAUUSD', api.TIMEFRAME_H1, earlier, at + timedelta(hours=4))
        if rates is None or not len(rates):
            raise RuntimeError(f'Native H1 unavailable: {api.last_error()}')
    records = [levels.Bar(stamp, *(float(row[k]) for k in ('open', 'high', 'low', 'close'))) for row in rates
               if (stamp := levels.server_to_utc(int(row['time']))) + 3600 <= at.timestamp()]
    if not records or records[-1].opened + 3600 != int(at.timestamp()):
        raise RuntimeError('Waiting for the native H1 close')
    return [list(bar) for bar in records]


def rank_native(native_rows, levels, feat, model):
    records = [levels.Bar(*row) for row in native_rows]
    series = upstream.NativeSeries(levels, 'H1', records)
    rows = series.inputs(len(records) - 1)
    with threadpool_limits(limits=4):
        ranked = dedup.unique_two(dedup.rank(rows, feat, model), 'price') if rows else []
    return records[-1].close, [dict(side=r['side'], lo=r['price'], hi=r['price'], kind=r['kind'],
                                    known_at=r['known_at'], score=r['score']) for r in ranked]


def register(policy, local, terminal_feed, scorer, observed):
    at = observed.replace(minute=0, second=0, microsecond=0)
    if not datetime.fromisoformat(policy['frozen_at']) < at <= observed < at + M5 or not _research_open(at):
        return
    name = f'{at:%Y%m%dT%H%M%SZ}.json'
    native = source.OUT / 'receipts' / name
    receipt = OUT / 'receipts' / name
    if receipt.is_file() or not native.is_file():
        return
    raw, cutoff, board_ready = source.load_board(local, native)
    if at != cutoff or board_ready < at:
        raise ValueError('The local publication does not match the H1 cutoff')
    if board_ready > observed:
        # A receipt can arrive while this observation cycle is reading the file.
        return
    target = OUT / 'boards' / name
    if not target.is_file():
        native_rows = native_history(at, scorer[0], terminal_feed)
        if native_rows[-1][-1] != raw['cutoff_close']:
            raise RuntimeError('Waiting for the native H1 and registered M5 close to agree')
        close, ranked = rank_native(native_rows, *scorer)
        if close != raw['cutoff_close']:
            raise ValueError('Native H1 and the registered local close differ')
        local_rows = [dict(side=side, lo=edge, hi=edge) for side, edge in dedup.upstream.prior.rank.picks(
            raw['early']['ERL'], raw['cutoff_close'])['score_2']]
        if any(r['known_at'] > at.timestamp() for r in ranked):
            raise ValueError('A repository candidate was still unknown at cutoff')
        picks = compare_shortlists(local_rows, ranked, close)
        candle_file = (OUT / 'native' / name).with_suffix('.json.gz')
        staging = candle_file.with_suffix('.tmp')
        joint.write_zip(staging, native_rows)
        live.feed.replace_with_retry(staging, candle_file)
        fixed.write_once(target, dict(cutoff=at.isoformat(), close=close, local_available_at=board_ready.isoformat(),
                                     local_receipt_sha256=joint.digest(native), policy_sha256=joint.digest(POLICY),
                                     candles_sha256=joint.digest(candle_file), upstream=ranked,
                                     local=picks['local'], integrated=picks['fixed_two'], orders_sent=0))
    ready = live.now()
    if ready < at + M5:
        fixed.write_once(receipt, dict(available_at=ready.isoformat(), board_sha256=joint.digest(target)))


def registered(policy, local):
    for receipt in sorted((OUT / 'receipts').glob('*.json')):
        path = OUT / 'boards' / receipt.name
        record, proof = fixed.read(path), fixed.read(receipt)
        native = source.OUT / 'receipts' / receipt.name
        raw, at, board_ready = source.load_board(local, native)
        ready = datetime.fromisoformat(proof['available_at'])
        picks = compare_shortlists(record['local'], record['upstream'], record['close'])
        original = dedup.upstream.prior.rank.picks(raw['early']['ERL'], raw['cutoff_close'])['score_2']
        if (not datetime.fromisoformat(policy['frozen_at']) < at <= board_ready <= ready < at + M5
                or record['cutoff'] != at.isoformat() or record['local_available_at'] != board_ready.isoformat()
                or record['close'] != raw['cutoff_close'] or proof['board_sha256'] != joint.digest(path)
                or record['policy_sha256'] != joint.digest(POLICY) or record['local_receipt_sha256'] != joint.digest(native)
                or list(map(outside, record['local'])) != original or picks['fixed_two'] != record['integrated']):
            raise ValueError(f'Invalid durable comparison record: {receipt.name}')
        yield receipt, record, at, ready


def grade(record, ready, buckets, starts):
    if not all(_research_open(at) for at in starts):
        return dict(state='market_break', arms={})
    if [bucket['open_utc'] for bucket in buckets] != [at.isoformat() for at in starts]:
        return dict(state='incomplete', arms={})
    tape = fixed.reconcile(buckets)
    if not tape or tape[-1][1][-1][0] <= fixed.utc_ms(ready):
        return dict(state='incomplete', arms={})
    arms = {}
    for name in ('local', 'integrated'):
        arms[name] = [dict(side=side, edge=edge, status=status, bid_time_ms=ms) for row in record[name]
                      for side, edge in (outside(row),) for status, ms in (fixed.outcome(row, tape, ready),)]
    return dict(state='scored', arms=arms)


def settle(receipt, record, at, ready, alive, terminal_feed, now):
    for minutes in HORIZONS:
        end = at + timedelta(minutes=minutes)
        if now < end + fixed.SYNC:
            continue
        name = f'{receipt.stem}_{minutes}'
        path = OUT / 'settlements' / f'{name}.json'
        if path.is_file():
            continue
        starts = [at + i * M5 for i in range(minutes // 5)]
        buckets = []
        if all(_research_open(stamp) for stamp in starts):
            buckets = [bucket for _, bucket in fixed.capture_buckets(live.feed.mt5, alive, terminal_feed, starts, now)]
        result = grade(record, ready, buckets, starts)
        if result['state'] == 'incomplete' and now < end + fixed.FINAL_RETRY:
            continue
        bid = OUT / 'bid' / f'{name}.json.gz'
        temp = bid.with_suffix('.tmp')
        joint.write_zip(temp, buckets)
        live.feed.replace_with_retry(temp, bid)
        fixed.write_once(path, dict(**result, receipt_sha256=joint.digest(receipt), bid_sha256=joint.digest(bid),
                                    settled_at=live.now().isoformat(), orders_sent=0))


def status(policy, local, scorer=None):
    totals = {minutes: Counter(scored=0, local_hits=0, integrated_hits=0, gained=0, lost=0) for minutes in HORIZONS}
    cutoffs, latest = set(), None
    for receipt, record, at, ready in registered(policy, local):
        cutoffs.add(at)
        latest = dict(cutoff=at.isoformat(), available_at=ready.isoformat(),
                      local=record['local'], integrated=record['integrated'])
        if scorer is not None:
            candle_file = (OUT / 'native' / receipt.name).with_suffix('.json.gz')
            if joint.digest(candle_file) != record['candles_sha256'] or rank_native(
                    joint.read_zip(candle_file), *scorer) != (record['close'], record['upstream']):
                raise ValueError(f'Native H1 forecast did not reproduce: {receipt.name}')
        for minutes, cells in totals.items():
            path = OUT / 'settlements' / f'{receipt.stem}_{minutes}.json'
            if not path.is_file():
                cells['pending'] += 1
                continue
            item = fixed.read(path)
            if (datetime.fromisoformat(item['settled_at']) < at + timedelta(minutes=minutes)
                    or item['receipt_sha256'] != joint.digest(receipt)):
                raise ValueError(f'Invalid settlement receipt: {path.name}')
            if scorer is not None:
                bid = OUT / 'bid' / path.with_suffix('.json.gz').name
                starts = [at + i * M5 for i in range(minutes // 5)]
                if (item['bid_sha256'] != joint.digest(bid)
                        or any(item[k] != v for k, v in grade(record, ready, joint.read_zip(bid), starts).items())):
                    raise ValueError(f'Bid evidence did not reproduce: {path.name}')
            cells[item['state']] += 1
            if item['state'] == 'scored':
                old, new = (any(row['status'] == 'sweep' for row in item['arms'][key]) for key in ('local', 'integrated'))
                cells.update(local_hits=int(old), integrated_hits=int(new), gained=int(new and not old), lost=int(old and not new))
    now = live.now()
    frozen = datetime.fromisoformat(policy['frozen_at'])
    hour = timedelta(hours=1)
    first = frozen.replace(minute=0, second=0, microsecond=0) + hour
    expected = Counter()
    for index in range(max(0, (now - M5 - first) // hour + 1)):
        at = first + index * hour
        if not _research_open(at):
            continue
        name = f'{at:%Y%m%dT%H%M%SZ}.json'
        if at in cutoffs:
            expected['paired'] += 1
        elif (source.OUT / 'receipts' / name).is_file():
            expected['local_only'] += 1
        else:
            expected['without_local_board'] += 1
    return dict(frozen_at=policy['frozen_at'], observed_at=now.isoformat(), registered=len(cutoffs),
                latest=latest, results=totals, closed_registration_windows=expected, orders_sent=0)


def main():
    import msvcrt

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('watch', 'probe', 'verify'))
    parser.add_argument('--terminal-pid', type=int)
    args = parser.parse_args()
    levels, _, feat, _ = upstream.load_sources()
    if joint.digest(upstream.MODEL) != fixed.read(upstream.REPORT)['model_sha256']:
        raise ValueError('Fitted model hash changed')
    scorer = (levels, feat, joblib.load(upstream.MODEL))
    if args.mode == 'verify':
        if not POLICY.is_file():
            raise FileNotFoundError(POLICY)
        print(json.dumps(status(*load_policy(), scorer=scorer), ensure_ascii=False))
        return
    if not args.terminal_pid:
        parser.error('--terminal-pid is required for watch and probe')
    feed = fixed.frozen_feed()
    with fixed.open_terminal(args.terminal_pid) as alive:
        if args.mode == 'probe':
            at = live.now().replace(minute=0, second=0, microsecond=0)
            close, ranked = rank_native(native_history(at, levels, feed), *scorer)
            print(json.dumps(dict(cutoff=at.isoformat(), close=close, candidates=ranked, orders_sent=0)))
            return
        for folder in ('boards', 'receipts', 'settlements', 'bid', 'native'):
            (OUT / folder).mkdir(parents=True, exist_ok=True)
        with (OUT / 'watch.lock').open('a+b') as lock:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            policy, local = load_policy()
            while alive():
                now = live.now()
                try:
                    register(policy, local, feed, scorer, now)
                    for receipt, record, at, ready in registered(policy, local):
                        settle(receipt, record, at, ready, alive, feed, now)
                    report = status(policy, local)
                except (OSError, RuntimeError) as error:
                    report = dict(**status(policy, local), awaiting=str(error))
                live.atomic_json(OUT / 'status.json', report)
                sleep(5)


if __name__ == '__main__':
    main()
