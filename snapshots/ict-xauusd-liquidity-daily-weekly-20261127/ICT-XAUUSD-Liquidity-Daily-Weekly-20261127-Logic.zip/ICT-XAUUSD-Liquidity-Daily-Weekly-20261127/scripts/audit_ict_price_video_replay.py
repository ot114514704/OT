"""Replay the chart's AMD/SMT geometry against immutable MT5 snapshots.

This checks information availability, not trade performance or a trained model.
All timestamps are conditional on the explicit, historically inferred offset.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import replace
from datetime import date,datetime,time,timedelta,timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from brooks_ai.types import Bar, utc_time
from ict_ai.amd import amd_events
from ict_ai.smt import smt_divergences, smt_observation
from ict_ai.timebase import NY,manifest_epoch_to_utc,clock_policy_metadata,require_replay_clock
from scripts.prepare_ict_week import aggregate_bars


def load_snapshot(manifest_path):
    meta = json.loads(manifest_path.read_text(encoding='utf-8'))
    dataset = next(d for d in meta['datasets'] if d['timeframe'] == 'M5')
    path = Path(dataset['data_path'])
    if meta.get('synthetic') is not False or meta.get('volatile_live_snapshot') is not False:
        raise ValueError('An immutable non-synthetic snapshot is required')
    if hashlib.sha256(path.read_bytes()).hexdigest() != dataset['data_sha256']:
        raise ValueError('Snapshot hash mismatch')
    with path.open(encoding='utf-8-sig', newline='') as stream:
        rows = [Bar(utc_time(r['time']), *(float(r[k]) for k in ('open', 'high', 'low', 'close', 'spread')))
                for r in csv.DictReader(stream)]
    return meta, dataset, rows


def run(primary_manifest, secondary_manifest, output, from_ny=None):
    a_meta, a_source, raw_a = load_snapshot(primary_manifest)
    b_meta, b_source, raw_b = load_snapshot(secondary_manifest)
    if a_meta['server'] != b_meta['server']:
        raise ValueError('Same-broker comparison required')
    require_replay_clock(a_meta,b_meta)
    cutoff = min(utc_time(a_meta['finished_at_utc']), utc_time(b_meta['finished_at_utc']))
    primary = [replace(b, time=manifest_epoch_to_utc(b.time,a_meta)) for b in raw_a]
    secondary = [replace(b, time=manifest_epoch_to_utc(b.time,b_meta)) for b in raw_b]
    if from_ny:
        floor=datetime.combine(from_ny,time(0),NY).astimezone(timezone.utc)
        primary=[b for b in primary if b.time>=floor]
        secondary=[b for b in secondary if b.time>=floor]
    if not primary or not secondary:raise ValueError('No paired history in requested interval')
    periods = {}; total_prefixes = 0; followup_checks = 0
    for minutes in (5, 15, 60):
        period = timedelta(minutes=minutes)
        a = aggregate_bars(primary, 5, minutes, cutoff)
        b = aggregate_bars(secondary, 5, minutes, cutoff)
        final_smt = smt_divergences(a, b, period, cutoff)
        final_amd = amd_events(a, period, cutoff) if minutes == 15 else []
        for n in range(1, len(a)+1):
            at = a[n-1].time+period
            peers = [bar for bar in b if bar.time+period <= at]
            smt = smt_divergences(a, b, period, at)
            expected = [e for e in final_smt if utc_time(e['available_at']) <= at]
            assert smt == expected, (minutes, n, 'SMT event rewritten')
            assert smt == smt_divergences(a[:n], peers, period, at), (minutes, n, 'SMT future input')
            if minutes == 15:
                amd = amd_events(a, period, at)
                expected_amd = [e for e in final_amd if utc_time(e['available_at']) <= at]
                assert amd == expected_amd, (minutes, n, 'AMD event rewritten')
                assert amd == amd_events(a[:n], period, at), (minutes, n, 'AMD future input')
            total_prefixes += 1
        statuses = {}
        for event in final_smt:
            known = utc_time(event['available_at'])
            final = smt_observation(event, a, b, period, cutoff)
            statuses[final['status']] = statuses.get(final['status'], 0)+1
            checkpoints = {known, cutoff}
            if final.get('catch_up_at'):
                catch_up = utc_time(final['catch_up_at'])
                checkpoints.update((catch_up-period, catch_up))
            # Gap availability, and every intervening bar closure, are also
            # audited: a missing peer must not be hidden by its later return.
            checkpoints.update(bar.time+period for bar in a if known <= bar.time+period <= cutoff)
            for at in sorted(checkpoints):
                if at < known:
                    continue
                observed = smt_observation(event, a, b, period, at)
                truncated = smt_observation(event, [bar for bar in a if bar.time+period <= at],
                                            [bar for bar in b if bar.time+period <= at], period, at)
                assert observed == truncated, (event['id'], at, 'SMT follow-up future input')
                if observed.get('catch_up_at'):
                    assert utc_time(observed['catch_up_at']) <= at
                assert observed['trade_signal'] is False
                followup_checks += 1
        phases = {}
        for event in final_amd:
            phases[event['phase']] = phases.get(event['phase'], 0)+1
            assert event['trade_signal'] is False
        periods[str(minutes)] = {'closed_primary_bars': len(a), 'closed_secondary_bars': len(b),
                                 'prefixes_checked': len(a), 'smt_candidates': len(final_smt),
                                 'smt_followup_statuses': statuses, 'amd_phase_events': phases}
        print(json.dumps({'period': minutes, 'prefixes': len(a), 'followup_checks_so_far': followup_checks}), flush=True)
    files = ['ict_ai/amd.py', 'ict_ai/smt.py','ict_ai/timebase.py', 'scripts/prepare_ict_week.py',
             'scripts/ict_week_fragment.html', 'scripts/audit_ict_price_video_replay.py']
    report = {'status': 'passed', 'scope': 'closed-bar geometry and later follow-up availability',
              'as_of_utc': cutoff.isoformat(), 'source_manifests': [str(primary_manifest), str(secondary_manifest)],
              'source_sha256': {'primary': a_source['data_sha256'], 'secondary': b_source['data_sha256']},
              'code_sha256': {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in files},
              'periods': periods, 'prefixes_checked': total_prefixes, 'smt_followup_checks': followup_checks,
              **clock_policy_metadata(a_meta),'history_from_ny':from_ny.isoformat() if from_ny else None,
              'history_floor_policy':'No pre-floor warmup; audit covers only events discoverable within the retained interval',
              'historical_clock_verified': False,
              'parameters_retuned': False, 'model_trained': False, 'orders_sent': 0,
              'trade_performance_evaluated': False, 'browser_runtime_verified': False,
              'limitations': ['Source manifest clock intervals remain hypotheses, not independent historical calibration',
                              'Prior DOL, HTF location, intermarket suitability and source CSD are not validated',
                              'AMD recognises balance, contracting ranges, pivot triangles, wedges and tight channels; these are price-path candidates',
                              'No execution, costs, predictive success or institutional order-flow inference']}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'report': str(output), 'prefixes_checked': total_prefixes, 'followup_checks': followup_checks}), flush=True)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    folder = ROOT/'data/real/TMGM_ICT_live_start_20261014_044312'
    parser.add_argument('--primary-manifest', type=Path, default=folder/'XAU/provenance.json')
    parser.add_argument('--secondary-manifest', type=Path, default=folder/'XAG/provenance.json')
    parser.add_argument('--out', type=Path, default=ROOT/'output/research/ict_price_video_replay_20261014.json')
    parser.add_argument('--from-ny',type=date.fromisoformat)
    args = parser.parse_args()
    run(args.primary_manifest.resolve(), args.secondary_manifest.resolve(), args.out.resolve(),args.from_ny)
