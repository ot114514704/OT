"""Loopback-only MT5 chart service. Read APIs only, no trading commands.

Quotes/forming candles refresh every 2s; closed-bar analysis every 20s.
runtime/current snapshots are volatile, independent of immutable research data.
"""
from pathlib import Path
from datetime import datetime,timedelta,timezone
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from dataclasses import asdict
from concurrent.futures import ThreadPoolExecutor
import argparse,contextlib,csv,hashlib,io,json,math,os,re,shutil,subprocess,sys,threading,time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from brooks_ai.types import utc_time
from ict_ai.timebase import NY,epoch_to_utc,manifest_epoch_to_utc
from ict_ai.clock_observation import SourceClockObserver
from ict_ai.range_liquidity import M5, _research_open
from scripts.prepare_ict_week import main as build_chart
from ict_ai.profile_journal import record_profiles,RUNTIME_CODE_SHA256
from ict_ai.profile_delivery_evidence import attach_chart_evidence
from ict_ai.profile_alignment import attach_profile_alignment


def assessed_quote(quote,now=None):
    """Reassess cached data even if the MT5 worker has hung or stopped.

    A stale tick cannot distinguish a broker clock change from missing quotes.
    Never infer a new offset from it, or publish new analysis under that guess.
    """
    if quote is None:return None
    now=now or datetime.now(timezone.utc)
    result=dict(quote)
    try:
        age=(now-utc_time(quote['quote_time'])).total_seconds()
        read_age=(now-utc_time(quote['read_at'])).total_seconds()
        result.update(quote_age_seconds=age,read_age_seconds=read_age,assessed_at=now.isoformat())
        prices=[float(quote[k]) for k in ('bid','ask')]
        if not all(math.isfinite(v) and v>0 for v in prices) or prices[1]<prices[0]:
            raise ValueError('Invalid Bid/Ask')
        if quote.get('status')=='disconnected':
            result['status']='disconnected'
        elif quote.get('clock_observation',{}).get('status') in ('host_clock_discontinuity','offset_mismatch'):
            result.update(status='clock_unverified',reason='Observed source offset or host clock changed; historical alignment must be reviewed before new analysis')
        elif age < -2 or read_age < -2:
            result.update(status='clock_unverified',reason='Quote or read time is ahead of the host clock; offset requires verification')
        elif age>30:
            result.update(status='stale',reason='No recent quote under the documented offset; stale data or a clock change requires verification')
        elif read_age>10:
            result.update(status='stale',reason='MT5 reader heartbeat expired')
        elif 'clock_observation' in quote and quote['clock_observation'].get('status')!='stable_current_observation':
            result.update(status='clock_unverified',reason='Waiting for advancing quotes to confirm the configured offset')
        else:
            result.update(status='live',reason=None)
    except (KeyError,TypeError,ValueError,OverflowError):
        result.update(status='invalid',reason='Invalid quote price or timestamp')
    result['analysis_eligible']=result['status']=='live'
    if not result['analysis_eligible']:result['pending']={}
    return result


def expected_m5_close(quoted_at):
    """Last expected study close once a quote reaches the next M5 bucket."""
    at=utc_time(quoted_at)
    close=at.replace(minute=at.minute-at.minute%5,second=0,microsecond=0)
    while not _research_open(close-M5):
        close-=M5
    return close


def assessed_analysis(payload, quote, error, now):
    closes=(payload or {}).get('closed_m5_through',{})
    result={'analysis_fresh':False,'analysis_status':'awaiting_snapshot',
            'expected_m5_close':None,'closed_m5_through':closes,'comparison_fresh':False}
    if error:
        return {**result,'analysis_status':'analysis_error'}
    if not quote or not quote['analysis_eligible']:
        return {**result,'analysis_status':'quote_unavailable'}
    quoted=min(utc_time(quote['quote_time']),now)
    expected=expected_m5_close(quoted)
    result['expected_m5_close']=expected.isoformat()
    if not payload or not closes.get('XAUUSD'):
        return result
    if payload.get('calendar_today_ny')!=now.astimezone(NY).date().isoformat():
        return {**result,'analysis_status':'awaiting_ny_day'}
    gold=utc_time(closes['XAUUSD'])
    silver=utc_time(closes['XAGUSD']) if closes.get('XAGUSD') else None
    if gold!=expected:
        return {**result,'analysis_status':'awaiting_closed_m5' if gold<expected else 'awaiting_quote_alignment'}
    return {**result,'analysis_status':'current','analysis_fresh':True,'comparison_fresh':silver==expected}


def checked_account(api,binding=None):
    account=api.account_info();terminal=api.terminal_info()
    if account is None or terminal is None or not terminal.connected or 'TradeMax' not in account.company:
        raise RuntimeError('Connected TMGM terminal required')
    if binding is not None and (account.login,account.server)!=binding:
        raise RuntimeError('Account/server changed; no new data published')
    return account


def replace_with_retry(temporary,path):
    # Windows readers may briefly deny replacement despite a fully written
    # temporary file. Never delete the good prior snapshot to work around it.
    for attempt in range(9):
        try:
            temporary.replace(path);return
        except PermissionError:
            if attempt==8:raise
            time.sleep(min(.01*(2**attempt),.08))


def atomic_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    replace_with_retry(temporary,path)


def write_status(path,value):
    # The status file is diagnostic. Its reader/ACL must not kill the MT5 loop;
    # HTTP responses recheck quote freshness independently of this file.
    try:atomic_json(path,value)
    except OSError as error:print('Status file unavailable: '+str(error),flush=True)


def capture(api,symbol,directory,offset,clock_policy=None):
    info=api.symbol_info(symbol)
    if info is None:raise RuntimeError('Symbol unavailable: '+symbol)
    if not info.visible and not api.symbol_select(symbol,True):raise RuntimeError('History symbol unavailable')
    # Prior full week is needed even for the older review week. Keep the
    # extra reference history in provenance, not in visible chart candles.
    rates=api.copy_rates_from_pos(symbol,api.TIMEFRAME_M5,1,18000)
    if rates is None or len(rates)<200:raise RuntimeError('Insufficient closed M5 history: '+symbol)
    today_ny=datetime.now(NY).date()
    prior_month_last=today_ny.replace(day=1)-timedelta(days=1)
    prior_month_start=prior_month_last.replace(day=1)
    lower_bound=datetime.combine(prior_month_start,datetime.min.time(),NY).astimezone(timezone.utc)
    clock_meta={'source_clock_offset_hours':offset.total_seconds()/3600,**(clock_policy or {})}
    def converted(r):return manifest_epoch_to_utc(datetime.fromtimestamp(int(r['time']),timezone.utc),clock_meta)
    rates=[r for r in rates if converted(r)>=lower_bound]
    if len(rates)<200:raise RuntimeError('Insufficient M5 history from prior month start: '+symbol)
    directory.mkdir(parents=True,exist_ok=True)
    path=directory/(symbol+'_M5.csv');temp=path.with_suffix('.tmp')
    now=datetime.now(timezone.utc)
    if any(converted(r)+timedelta(minutes=5)>now for r in rates):
        raise RuntimeError('Historical series contains a forming/future bar')
    with temp.open('w',encoding='utf-8',newline='') as f:
        writer=csv.writer(f);writer.writerow(['time','open','high','low','close','spread'])
        for r in rates:writer.writerow([datetime.fromtimestamp(int(r['time']),timezone.utc).isoformat(),
                                       *[float(r[k]) for k in ('open','high','low','close')],float(r['spread'])*info.point])
    replace_with_retry(temp,path)
    account=api.account_info()
    meta={'symbol':symbol,'company':account.company,'server':account.server,'status':'collected',
          'account_currency':account.currency,'finished_at_utc':now.isoformat(),'synthetic':False,
          'source':'MT5 read-only chart worker',**clock_meta,
          'current_symbol_observation':{key:getattr(info,key) for key in
              ('point','trade_tick_size','trade_contract_size','volume_min','volume_step','volume_max','currency_profit')},
          'symbol_observation_historical_validity_verified':False,
          'commission_and_slippage_verified':False,
          'history_requested_from_ny':prior_month_start.isoformat(),
          'source_clock_historical_alignment_verified':False,'volatile_live_snapshot':True,'orders_sent':0,
          'datasets':[{'timeframe':'M5','data_path':str(path.resolve()),'data_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}]}
    manifest=directory/'provenance.json';atomic_json(manifest,meta)
    return manifest


def closed_through(manifest_path, cutoff):
    """Read the latest complete M5 in the exact source used by the chart."""
    manifest=json.loads(manifest_path.read_bytes())
    candles=next(d for d in manifest['datasets'] if d['timeframe']=='M5')
    for line in reversed(Path(candles['data_path']).read_bytes().splitlines()[1:]):
        raw=utc_time(line.split(b',',1)[0].decode('ascii'))
        close=manifest_epoch_to_utc(raw,manifest)+M5
        if close<=cutoff:
            return close.isoformat()
    return None


class LiveState:
    def __init__(self,workspace,terminal,source_offset_hours=3,clock_policy=None,*,isolated=False):
        self.workspace=workspace;self.terminal=terminal;self.lock=threading.Lock();self.stop=threading.Event()
        self.source_offset_hours=source_offset_hours;self.clock_policy=clock_policy
        self.payload=None;self.quote=None;self.error=None;self.revision=0;self.initial_saved=False
        self.ready=threading.Event()
        self.archive_root = workspace/'initial-snapshots' if isolated else ROOT/'data/real'
        self.initial_html = workspace/'ict-week-review.html' if isolated else ROOT/'output/visualizations/ict-week-review.html'
        self.preview = workspace/'preview/index.html' if isolated else ROOT/'output/chart-preview/index.html'

    def build_snapshot(self,xau,xag,ny_date):
        # No MT5 calls here: its single reader thread remains the only API
        # owner. Current history files stay frozen until this job is done.
        payload=build_chart(['--manifest',str(xau),'--comparison-manifest',str(xag),
                             '--today',ny_date,'--out-json',str(self.workspace/'current/analysis.json'),
                             '--out-fragment',str(self.workspace/'current/fragment.html'),'--quiet','--standalone'])
        cutoff=utc_time(payload['smt_pair']['as_of'])
        payload['closed_m5_through']={symbol:closed_through(manifest,cutoff)
                                      for symbol,manifest in (('XAUUSD',xau),('XAGUSD',xag))}
        attach_chart_evidence(payload)
        attach_profile_alignment(payload)
        for scenario in payload['scenarios']:
            for day in scenario['days']:
                if day.get('analysis'):
                    day['analysis']['limitations']=['会话形态使用已收盘 M15，日末价格和失效由 M5 核对；未收盘 K 线单独显示','历史时钟偏移为推定','经济日历不是完整历史版本']
        payload['profile_journal']=record_profiles(payload,self.workspace,runtime_code_shas=RUNTIME_CODE_SHA256)
        return payload

    def response(self,kind,now=None):
        """Pure read snapshot; do not trust a cached 'live' flag."""
        now=now or datetime.now(timezone.utc)
        with self.lock:
            quote=assessed_quote(self.quote,now)
            analysis=assessed_analysis(self.payload,quote,self.error,now)
            if kind=='status':
                return {'ready':self.payload is not None,**analysis,
                        'quote_status':quote['status'] if quote else 'unavailable',
                        'clock_observation':quote.get('clock_observation') if quote else None,
                        'revision':self.revision,'error':self.error,'pid':os.getpid(),'orders_sent':0}
            live_quote={**quote,**analysis,'live_revision':self.revision} if quote else None
            if kind=='quote':return live_quote
            if kind=='live' and self.payload is not None:
                return {**self.payload,**analysis,'live':live_quote,'live_revision':self.revision}
            return None

    def worker(self):
        import MetaTrader5 as api
        offset=timedelta(hours=self.source_offset_hours);binding=None;last_history=0;job=None
        requested_close=None
        clock_observer=SourceClockObserver(applied_hours=self.source_offset_hours)
        last_clock_signature=None
        executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='ict-analysis')
        try:
            if not api.initialize(path=self.terminal,timeout=10000):raise RuntimeError('MT5 initialization failed')
            account=checked_account(api)
            binding=(account.login,account.server)
            while not self.stop.is_set():
                try:
                    checked_account(api,binding)
                    tick=api.symbol_info_tick('XAUUSD')
                    if tick is None:raise RuntimeError('Gold quote unavailable')
                    now=datetime.now(timezone.utc)
                    clock_observation=clock_observer.observe(tick.time_msc/1000,now,time.monotonic())
                    signature=(clock_observation['status'],clock_observation['observed_offset_hours'])
                    if signature!=last_clock_signature and clock_observation['status'] in ('stable_current_observation','offset_mismatch','host_clock_discontinuity'):
                        try:
                            with (self.workspace/'clock-observations.jsonl').open('a',encoding='utf-8') as f:
                                f.write(json.dumps({'symbol':'XAUUSD','company':account.company,'server':account.server,
                                                    'observation':clock_observation,'orders_sent':0},ensure_ascii=False)+'\n')
                        except OSError as error:
                            print('Clock observation log unavailable: '+str(error),flush=True)
                        last_clock_signature=signature
                    quoted=datetime.fromtimestamp(tick.time_msc/1000,timezone.utc)-offset
                    age=(now-quoted).total_seconds()
                    pending={}
                    for name,constant,minutes in [('5',api.TIMEFRAME_M5,5),('15',api.TIMEFRAME_M15,15),('60',api.TIMEFRAME_H1,60)]:
                        rates=api.copy_rates_from_pos('XAUUSD',constant,0,1)
                        if rates is None or not len(rates):continue
                        r=rates[0];start=datetime.fromtimestamp(int(r['time']),timezone.utc)-offset
                        if start<=now<start+timedelta(minutes=minutes):
                            pending[name]=[int(start.timestamp()*1000),*[float(r[k]) for k in ('open','high','low','close')]]
                    quote={'status':'live','bid':float(tick.bid),'ask':float(tick.ask),
                           'quote_time':quoted.isoformat(),'read_at':now.isoformat(),'quote_age_seconds':age,
                           'ny_date':now.astimezone(NY).date().isoformat(),'pending':pending,
                           'historical_clock_verified':False,'current_offset_hours':self.source_offset_hours,'orders_sent':0,
                           'clock_observation':clock_observation}
                    quote=assessed_quote(quote,now)
                    if job is None and quote['analysis_eligible']:
                        expected=expected_m5_close(min(quoted,now))
                    else:
                        expected=None
                    if expected is not None and (expected!=requested_close or time.monotonic()-last_history>=20):
                        xau=capture(api,'XAUUSD',self.workspace/'current/XAU',offset,self.clock_policy)
                        xag=capture(api,'XAGUSD',self.workspace/'current/XAG',offset,self.clock_policy)
                        job=executor.submit(self.build_snapshot,xau,xag,quote['ny_date'])
                        requested_close=expected
                        last_history=time.monotonic()
                    payload=None
                    if job is not None and job.done():
                        completed=job;job=None
                        payload=completed.result()
                    checked_account(api,binding)
                    # Reading/building may take long enough to invalidate the initial
                    # quote. Retain the last known analysis until a fresh pass completes.
                    quote=assessed_quote(quote)
                    if not quote['analysis_eligible']:payload=None
                    if payload is not None:payload['live']=quote
                    with self.lock:
                        if payload is not None:
                            self.payload=payload;self.revision+=1
                        self.quote=quote;self.error=None
                        self.ready.set()
                    if not self.initial_saved and self.payload is not None:
                        archived=self.archive_root/('TMGM_ICT_live_start_'+now.strftime('%Y%m%d_%H%M%S'))
                        for symbol in ['XAU','XAG']:
                            source=self.workspace/'current'/symbol
                            target=archived/symbol;target.mkdir(parents=True,exist_ok=True)
                            manifest=json.loads((source/'provenance.json').read_text(encoding='utf-8'))
                            for dataset in manifest['datasets']:
                                name=Path(dataset['data_path']).name
                                shutil.copy2(dataset['data_path'],target/name)
                                dataset['data_path']=str((target/name).resolve())
                            manifest['volatile_live_snapshot']=False
                            atomic_json(target/'provenance.json',manifest)
                        initial=json.loads(json.dumps(self.payload))
                        initial['source_manifest']=str(archived/'XAU/provenance.json')
                        initial['smt_pair']['source_manifest']=str(archived/'XAG/provenance.json')
                        fragment=(ROOT/'scripts/ict_week_fragment.html').read_text(encoding='utf-8')
                        encoded=json.dumps(initial,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
                        if len((fragment.replace('__ICT_WEEK_DATA__',encoded)).encode())>=50_000_000:raise RuntimeError('Chart fragment exceeds 50 MB')
                        snapshot=self.initial_html
                        snapshot.write_text(fragment.replace('__ICT_WEEK_DATA__',encoded),encoding='utf-8')
                        renderer=ROOT/'vendor/visualize/scripts/render.py'
                        page=self.preview;page.parent.mkdir(parents=True,exist_ok=True)
                        subprocess.run([sys.executable,str(renderer),str(snapshot),str(page),'--force'],check=True,capture_output=True)
                        html=page.read_text(encoding='utf-8')
                        old="connect-src blob: data:; frame-src 'self'"
                        if html.count(old)!=1:raise RuntimeError('Unexpected standalone shell CSP')
                        html=html.replace(old,"connect-src 'self' blob: data:; frame-src 'self'",1)
                        bridge=(ROOT/'scripts/ict_live_bridge.js').read_text(encoding='utf-8')
                        html=html.replace('</body>','<script>'+bridge+'</script>\n</body>')
                        page.write_text(html,encoding='utf-8');self.initial_saved=True
                    health=self.response('status')
                    write_status(self.workspace/'status.json',{'status':'running',**health,
                                                              'updated_at':now.isoformat(),'quote_time':quote['quote_time'],
                                                              'account_bound':True})
                except Exception as error:
                    with self.lock:
                        self.error=str(error)
                        if self.quote:self.quote={**self.quote,'status':'disconnected'}
                    write_status(self.workspace/'status.json',{'pid':os.getpid(),'status':'data_error','error':str(error),
                                                              'updated_at':datetime.now(timezone.utc).isoformat(),'orders_sent':0})
                    print('Data error: '+str(error),flush=True)
                    if 'Connected TMGM terminal required' in str(error):
                        api.shutdown()
                        if api.initialize(path=self.terminal,timeout=10000):
                            # Never adopt a different login/server after reconnecting.
                            try:checked_account(api,binding)
                            except Exception:api.shutdown()
                self.stop.wait(2)
        except Exception as error:
            with self.lock:self.error=str(error)
            write_status(self.workspace/'status.json',{'pid':os.getpid(),'status':'failed','error':str(error),'orders_sent':0})
        finally:
            executor.shutdown(wait=False,cancel_futures=True)
            api.shutdown()


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--port',type=int,default=9887)
    ap.add_argument('--terminal',default='C:/Program Files/MetaTrader 5/terminal64.exe')
    ap.add_argument('--source-offset-hours',type=int,choices=(0,2,3),default=3)
    ap.add_argument('--clock-policy',type=Path)
    ap.add_argument('--isolated-workspace',type=Path,help='Write the snapshots, journal and browser preview to a separate directory')
    args=ap.parse_args()
    default_workspace=ROOT/'runtime/ict-live'
    workspace=args.isolated_workspace.resolve() if args.isolated_workspace else default_workspace
    if args.isolated_workspace and workspace==default_workspace.resolve():
        ap.error('An isolated workspace must use a separate directory')
    workspace.mkdir(parents=True,exist_ok=True)
    policy=json.loads(args.clock_policy.read_text(encoding='utf-8')) if args.clock_policy else None
    state=LiveState(workspace,args.terminal,args.source_offset_hours,policy,isolated=args.isolated_workspace is not None)
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            path=self.path.split('?',1)[0]
            if self.headers.get('Host','').split(':')[0] not in ('127.0.0.1','localhost'):
                self.send_error(403);return
            if path in ('/api/live','/api/quote','/api/status'):
                value=state.response(path.removeprefix('/api/'))
                if value is None:self.send_error(503,'Waiting for MT5 data');return
                blob=json.dumps(value,ensure_ascii=False,separators=(',',':')).encode()
                self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8')
            elif path in ('/','/index.html'):
                # Keep an explicitly dated saved review accessible on restart,
                # including weekends with no fresh tick. This does not seed
                # live analysis or change quote freshness/account checks.
                if not state.preview.is_file():self.send_error(503,'Chart is preparing');return
                blob=state.preview.read_bytes();self.send_response(200)
                self.send_header('Content-Type','text/html; charset=utf-8')
            else:self.send_error(404);return
            self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(blob)));self.end_headers()
            try:self.wfile.write(blob)
            except (BrokenPipeError,ConnectionResetError):pass
        def log_message(self,*args):pass
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
    thread=threading.Thread(target=state.worker,daemon=True);thread.start()
    print('MT5 read-only chart listening on 127.0.0.1:'+str(args.port),flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:state.stop.set();server.server_close();thread.join(timeout=10)


if __name__=='__main__':main()
