"""Measure strict sweeping within 15 minutes at the same frozen liquidity cutoffs."""

from bisect import bisect_left
from datetime import datetime, timedelta
from pathlib import Path
import json

import numpy as np

from ict_ai.dol_history import _deadline
from ict_ai.range_liquidity import _Coverage
from scripts import audit_ict_liquidity_filter_layers as layers


study = layers.study
OUT = study.RESEARCH / 'ict_liquidity_15m_20261124.json'


def short_labels(snapshots, four_hour, bars, times):
    coverage = _Coverage(times[0], times[-1]+study.M5, bars, study.M5)
    result = []
    checked = 0
    for row, past in zip(snapshots, four_hour, strict=True):
        at = datetime.fromisoformat(row['at'])
        end = min(at+timedelta(minutes=15), _deadline(at))
        index = bisect_left(times, at)
        if not index or bars[index-1].time+study.M5 != at or bars[index-1].close != row['price']:
            raise ValueError(f'Frozen reference price does not match the TMGM chart at {at}')
        future = bars[index:bisect_left(times, end)]
        state = 'open' if coverage.cutoff < end else 'missing' if coverage.gap(at,end) else 'complete'
        if state == 'complete' and len(future) != 3:
            state = 'fewer_than_three_complete_M5'
        cell = dict(end=end.isoformat(), status=state)
        if state == 'complete':
            for scope in ('IRL','ERL'):
                events = [study.contacts(target, future, True) for target in row['pools'][scope]]
                if past['short']['status'] == 'complete':
                    for fresh, prior in zip(events, past['short'][scope], strict=True):
                        expected = prior['sweep']
                        if expected and datetime.fromisoformat(expected) > end:
                            expected = None
                        if fresh['sweep'] != expected:
                            raise AssertionError(f'15m result disagrees with the 4h tape prefix at {at}')
                        checked += 1
                cell[scope] = events
        result.append(dict(at=row['at'],quarter_hour=cell))
    return result, checked


def apply_four_hour(groups, model, bars, times):
    # Use the same remaining four-hour horizon in features as the original model.
    structure = model['stages']['structure']['rule']
    distance = model['stages']['distance']['rule']
    threshold = model['stages']['price_and_clock']['rule']
    saved = model['model']
    mean, scale, coef = (np.array(saved[k]) for k in ('mean','scale','coefficients'))
    approved = []
    for g, choices in groups:
        keep = [i for i in choices if distance is None or g['distance'][i] <= distance]
        if structure is not None:
            origins, obstacles = structure
            keep = [i for i in keep if g['targets'][i]['origins'] >= origins
                    and 4-g['targets'][i]['components']['path'] <= obstacles]
        if threshold is not None and keep:
            framed = dict(g, end=_deadline(g['at']))
            layers.context.add_context([framed],bars,times)
            x = np.array([layers.features(framed,i) for i in keep])
            logits = coef[0]+((x-mean)/scale)@coef[1:]
            probability = 1/(1+np.exp(-np.clip(logits,-40,40)))
            keep = [i for i,p in zip(keep,probability,strict=True) if p >= threshold]
        approved.append((g, keep))
    return approved


def m15_origin(rows):
    return [(group, tuple(i for i in kept if 'M15' in group['targets'][i]['timeframes'])) for group,kept in rows]


def main():
    directory = layers.ranking.ARCHIVE
    candidates = directory/'round19_liquidity_50_candidates.json.gz'
    outcomes = directory/'round19_liquidity_50_outcomes.json.gz'
    original = json.loads(layers.OUT.read_bytes())
    for name, claimed in original['inputs'].items():
        if study.digest(layers.ROOT/name) != claimed:
            raise ValueError(f'Frozen research input changed: {name}')
    bars, times = layers.read_market()
    snapshots, four_hour = map(study.read_zip,(candidates,outcomes))
    labels, verified = short_labels(snapshots,four_hour,bars,times)
    pairs = list(zip(snapshots,labels,strict=True))
    results = {}
    for scope in ('IRL','ERL'):
        groups = list(layers.ranking.build_groups(pairs,'quarter_hour',scope))
        layers.context.add_context(groups,bars,times)
        fitted = layers.run(groups)
        holdout = [(g,r) for g,r in layers.windows(groups) if g['at'] >= layers.OCT]
        inherited = apply_four_hour(holdout,original['results']['short/'+scope],bars,times)
        first = layers.counts(holdout)
        selected_map = {r['at']:r['kept_ranks'] for r in fitted['final_windows']}
        selected = [(g, tuple(i-1 for i in selected_map[g['at'].isoformat()])) for g,_ in holdout]
        origin = m15_origin(holdout)
        origin_base = layers.counts(origin)
        old_groups = layers.ranking.build_groups(zip(snapshots,four_hour,strict=True),'short',scope)
        old_origin = layers.counts(m15_origin([(g,r) for g,r in layers.windows(old_groups) if g['at'] >= layers.OCT]))
        m15 = {'original_top10_subset':layers.described(origin_base,origin_base),
               'after_15m_filters':layers.described(layers.counts(m15_origin(selected)),origin_base),
               'original_subset_4h':layers.described(old_origin,old_origin)}
        last = [(g,r) for g,r in inherited if str(g['week'])==layers.LAST_WEEK]
        last_base = layers.counts([(g,r) for g,r in holdout if str(g['week'])==layers.LAST_WEEK])
        results[scope] = dict(refit_15m=fitted, existing_four_hour_filters=dict(
            holdout=layers.described(layers.counts(inherited),first), last_week=layers.described(layers.counts(last),last_base),
            same_coverage_nearest=layers.nearest_contrast(holdout,inherited)), m15_origin=m15)
        print(scope, [(name, x.get('rule'), x['holdout']['hits'], x['holdout']['offers'],
                      x['last_week']['hits'],x['last_week']['offers']) for name,x in fitted['stages'].items()], flush=True)
        print('original 4h rules', {k:results[scope]['existing_four_hour_filters']['holdout'][k] for k in ('hits','offers')},
              'M15 origin', {k:(v['hits'],v['offers']) for k,v in m15.items()}, flush=True)
    layers.atomic_json(OUT,dict(window_minutes=15,M5_bars_per_window=3, strict_sweep_only=True,
                               four_hour_prefix_agreements=verified, first_holdout=layers.OCT.isoformat(),
                               results=results, threshold_method='15m models fit using June–August matured labels, '
                               'hard gates chosen on the September slice. Same frozen candidates as 4h.',
                               origin_definition='M15 occurs in the archived candidate source timeframe set. Other timeframes may contribute.',
                               source={p.name:study.digest(p) for p in (candidates,outcomes,layers.OUT,Path(__file__))},orders_sent=0))


if __name__=='__main__':
    main()
