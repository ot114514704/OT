"""Persist the manually reviewed HD profile figures and their rule bindings."""
import hashlib,json,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from ict_ai.profile_sources import profile_catalog,SOURCE_HASHES


def main():
    catalog=profile_catalog()
    for kind,key,folder in [('daily','time2_daily','ict_daily_profiles'),('weekly','time3_weekly','ict_weekly_profiles')]:
        base=ROOT/'research/ict_time_videos'/key
        manifest=json.loads((base/'manifest.json').read_text(encoding='utf-8'))
        if manifest['source_sha256']!=SOURCE_HASHES[kind]:raise ValueError('Source hash changed')
        index=json.loads((base/'overview/index.json').read_text(encoding='utf-8'))
        for record in index['records']:
            record.update(reviewed=True,review_scope='contact_sheet_visible_diagram_and_text')
            record['frame_sha256']=hashlib.sha256(Path(record['path']).read_bytes()).hexdigest()
        index.update(full_video_review=False,full_audio_review_complete=False)
        (base/'overview/index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
        for filename in ('curated.json','rules.json'):
            rulepath=ROOT/'research'/folder/filename
            rules=json.loads(rulepath.read_text(encoding='utf-8'))
            for rule in rules['profiles']+rules.get('variants',[]):
                if rule['id'] in catalog[kind]:rule['hd_visual_reference']=catalog[kind][rule['id']]
                if rule['id']=='manipulation_expansion_consolidation':
                    rule['required_facts']['daily_small_net_body']=True
                    rule['source_summary']='伦敦完成反向运动后的明显扩张，纽约没有跟随而转为盘整，最终日线净实体很小、接近十字形。'
                    note='净实体 / 日振幅不超过 0.25 是本项目研究阈值，课程没有给出该数值。'
                    if note not in rule['limitations']:rule['limitations'].append(note)
            rules['hd_review_scope']='Timed illustration samples cross-checked with existing PPT/DOC; new audio review scope recorded separately in ict_time_videos/*/integration.json'
            rulepath.write_text(json.dumps(rules,ensure_ascii=False,indent=2),encoding='utf-8')
    result={'reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
            'scope':'HD visual profile definitions, not full-frame/audio semantic review',
            'catalog':catalog,'daily_six_families_plus_classic_reversal_variant':True,
            'weekly_six_families':True,'excluded_weekly_ppt_slides':[23,25,26],
            'clarifications':[
                '经典买入日：伦敦候选反转，纽约扩张；1.1 经典反转：极点推迟到纽约。',
                '双重扫荡：早期先顺事前偏见运行，之后反向扫荡；不是简单的任意两次破高低。',
                '周三极点子类要看周二路径；仅凭周三最低不足以归类。',
                '周四外部范围反转和盘整后的直接扩张分别保留。',
                '操纵扩张后盘整与经典日的区别是纽约缺少持续跟随。',
                '心电图须有反复双向运动、小净位移；银行假期或无新闻不能单独决定形态。',
                '来源中的高概率表述不是本项目验证的统计胜率。'],
            'liquidity_classification_authority':{
                'author':'交易员无畏','video_sources':['foundations','bias_intro'],
                'reference_images':'drawing_style_only','pdf_used_for_classification':False,
                'range_and_swing_parameters':'explicit_unvalidated_engineering_choices'},
            'semantic_review_complete':False,'model_trained':False,'orders_sent':0}
    target=ROOT/'research/ict_time_videos/profile-visual-review.json'
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'review':str(target),'families':[6,6],'full_audio_review_complete':False}))


if __name__=='__main__':main()
