"""Render the audited news replay with embedded prices for offline review."""
import argparse
from datetime import timedelta
import json
from pathlib import Path

from brooks_ai.types import utc_time
from ict_ai.timebase import NY, require_replay_clock
from scripts.replay_ict_news import ROOT, STEP, block, extent, load_history
from scripts.replay_ict_news_progression import PHASES, freeze_references, phase_detail


def build_steps(bars, at, after, event):
    frozen = freeze_references(bars, at)
    for name, reference in event["prior_range_reactions"].items():
        breached = reference["breached_before_release_since_midnight"]
        frozen[name] = {
            "low": reference["low"], "high": reference["high"],
            "first_observed_cross_before_release_known_at_ny": {
                side: None for side, was_breached in (breached or {}).items() if was_breached
            },
            "before_release_coverage_complete": breached is not None,
        }
    steps = {}
    for count in range(1, len(after) + 1):
        clipped = {bar.time: bar for bar in after[:count]}
        steps[count * 5] = [
            {**phase_detail(clipped, at, frozen, offset, min(limit, count - offset)),
             "complete": count - offset >= limit}
            for _, offset, limit in PHASES if count > offset
        ]
    return frozen, steps


def load_releases(path):
    report = json.loads(path.read_bytes())
    meta, digest, bars = load_history(Path(report["source_manifest"]))
    if digest != report["source_m5_sha256"]:
        raise ValueError("Price snapshot differs from the audited report")
    require_replay_clock(meta, report)
    for event in report["comparisons"]:
        at = utc_time(event["news"]["at_utc"])
        context = event["market_context"]
        before = block(bars, at - 6 * STEP, 6)
        after = block(bars, at, 12)
        if before is None or after is None or extent(before) != (event["news"]["pre_low"], event["news"]["pre_high"]):
            raise ValueError(f"Chart window differs from the audit at {at}")
        local = at.astimezone(NY)
        start = local.replace(hour=0, minute=0, second=0)
        closed = context["profiles"].get("closed_review")
        end = utc_time(closed["as_of"]) if closed else at + timedelta(minutes=60)
        prices = [[int(stamp.timestamp()), bar.open, bar.high, bar.low, bar.close]
                  for stamp, bar in bars.items() if start <= stamp and stamp + STEP <= end]
        references, steps = build_steps(bars, at, after, event)
        yield {"event": event["event"], "source": event["source"], "at": int(at.timestamp()),
               "at_ny": event["news"]["at_ny"], "date": local.date().isoformat(),
               "coverage": report["source_m5_sha256"], "quotes": prices,
               "review_end": int(end.timestamp()) if closed else None,
               "profiles": context["profiles"], "news": event["news"],
               "references": references, "steps": steps, "releases": event["known_announcements_in_window"],
               "controls": [{"at_ny": c["at_ny"], "range_5m": c["horizons"]["5"]["range"]}
                            for c in event["same_clock_comparison"]]}


def build(reports, output):
    cases = sorted((e for report in reports for e in load_releases(report)), key=lambda e: e["at"])
    if not cases or len({e["at"] for e in cases}) != len(cases):
        raise ValueError("Require distinct release windows")
    payload = json.dumps(cases, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    template = (ROOT / "scripts/ict_news_review.html").read_text(encoding="utf-8")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(template.replace("/*__CASES__*/", payload, 1), encoding="utf-8")
    return len(cases)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, action="append", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(f"{build(args.report, args.out)} audited release windows → {args.out}")
