"""Causal price-path observations, not inferred institutional orders.

Source: user AMD video 277–367 s. DOL must precede a trade narrative;
an A→D expansion need not contain M. Swing geometry follows the consolidation
project's shape_geometry.py. Its last confirmed swing levels freeze before M.
Immutable stage events become available only at closed-bar timestamps.
"""
from datetime import timedelta
import hashlib
from statistics import median


SHAPE_LABELS = {"overlapping":"箱形重叠整理","contracting":"收敛整理","triangle":"对称三角",
                "ascending_triangle":"上升三角","descending_triangle":"下降三角",
                "rising_wedge":"上升楔形","falling_wedge":"下降楔形",
                "rising_channel":"上行密集通道","falling_channel":"下行密集通道"}


def confirmed_pivots(part):
    """Adapt the two confirmed swings on each side; compare only their common span."""
    highs, lows = [], []
    for i in range(1,len(part)-1):
        a,b,c = part[i-1:i+2]
        if b.high>a.high and b.high>=c.high:
            highs.append(i)
        if b.low<a.low and b.low<=c.low:
            lows.append(i)
    if len(highs)<2 or len(lows)<2:
        return None
    h0,h1 = highs[-2:]
    l0,l1 = lows[-2:]
    return h0,h1,l0,l1


def swing_shape(part):
    pivots = confirmed_pivots(part)
    if pivots is None:
        return None
    h0,h1,l0,l1 = pivots
    left,right = max(h0,l0),min(h1,l1)
    if right-left<2 or len({h0,h1,l0,l1})!=4 or len(part)-1-max(h1,l1)>3 or min(h0,l0)>len(part)//3:
        return None
    hi_edge,lo_edge=part[h1].high,part[l1].low
    if (lo_edge>=hi_edge or any(b.high>hi_edge for b in part[h1+1:])
            or any(b.low<lo_edge for b in part[l1+1:])):
        return None
    upper_slope = (part[h1].high-part[h0].high)/(h1-h0)
    lower_slope = (part[l1].low-part[l0].low)/(l1-l0)
    def rails(i):
        return part[h0].high+(i-h0)*upper_slope,part[l0].low+(i-l0)*lower_slope
    upper,lower = rails(left)
    top,bottom = rails(right)
    width,last_width = upper-lower,top-bottom
    scale = median(b.high-b.low for b in part)
    if min(width,last_width,scale)<=0:
        return None
    du,dl = upper_slope*(right-left),lower_slope*(right-left)
    motion = max(abs(du),abs(dl))
    tolerance = .15*scale
    flat = min(tolerance,.05*motion)
    wick = closes = 0
    for i in range(left,right+1):
        hi,lo = rails(i)
        b = part[i]
        wick += b.high<=hi+tolerance and b.low>=lo-tolerance
        closes += lo-tolerance<=b.close<=hi+tolerance
    if wick<.8*(right-left+1) or closes<.9*(right-left+1):
        return None
    narrowing = last_width < width*(1-1e-10)
    if narrowing and abs(du)<=flat and dl>0:
        return "ascending_triangle",lo_edge,hi_edge
    if narrowing and abs(dl)<=flat and du<0:
        return "descending_triangle",lo_edge,hi_edge
    if du<0<dl:
        return "triangle",lo_edge,hi_edge
    parallel = du*dl>0 and abs(du-dl)<=.20*motion and abs(last_width-width)<=.10*width
    if parallel:
        if max(width,last_width)<=3*scale:
            return ("rising_channel" if du>0 else "falling_channel"),lo_edge,hi_edge
        return None
    if narrowing and du*dl>0:
        return ("rising_wedge" if du>0 else "falling_wedge"),lo_edge,hi_edge
    return None


def amd_events(bars, period, as_of, window=8, expiry_bars=24, *, triangle_only=False,
               reference_shape=None, require_displacement=False, allow_same_side_resweep=False,
               include_retirements=False):
    """With a reference shape, evaluate only the first contiguous window supplied.

    The caller supplies a shape already observed by the consolidation study.
    Its frozen OHLC range and displacement threshold are measured here.
    Replay callers can opt in to closed-bar candidate retirement observations.
    """
    if reference_shape is not None and (triangle_only or reference_shape not in SHAPE_LABELS):
        raise ValueError('A single known reference shape is required')
    if period <= timedelta(0) or as_of.tzinfo is None or window < 6 or expiry_bars < 2:
        raise ValueError('Aware cutoff, positive period and valid windows required')
    if any(a.time >= b.time for a, b in zip(bars, bars[1:])):
        raise ValueError('Unique chronological bars required')
    rows = [b for b in bars if b.time + period <= as_of]
    events = []; active = None; segment = 0

    def emit(phase, part, known, route, direction=None):
        events.append({'id': active['id'], 'phase': phase,
                       'start': part[0].time.isoformat(),
                       'end': (part[-1].time + period).isoformat(),
                       'lower': min(b.low for b in part), 'upper': max(b.high for b in part),
                       'available_at': known.isoformat(), 'route': route,
                       'shape': active['shape'], 'shape_label':SHAPE_LABELS[active['shape']], 'direction': direction,
                       'range_low': active['low'], 'range_high': active['high'],
                       'candidate': True, 'trade_signal': False,
                       'context_status': 'pending_prior_dol_htf'})
        if phase in ('M', 'D') and active.get('repeat'):
            events[-1]['same_side_resweep'] = True

    def retire(bar, reason):
        if not include_retirements:
            return
        emit('X', [bar], bar.time + period, reason)
        events[-1].update(candidate=False, context_status='retired', bar_open=bar.open, bar_close=bar.close)

    for i, b in enumerate(rows):
        if i and b.time != rows[i-1].time + period:
            if active:
                retire(b, 'quote_gap')
            active = None; segment = i
        if active and i - active['formed'] > expiry_bars:
            retire(b, 'expired')
            active = None; segment = i
        if active:
            low, high = active['low'], active['high']
            # OHLC cannot order a candle crossing both frozen boundaries.
            if b.low < low and b.high > high:
                retire(b, 'both_boundaries_same_bar')
                active = None; segment = i + 1; continue
            if active['reclaim'] is not None:
                farther = b.high > active['extreme'] if active['side'] == 1 else b.low < active['extreme']
                if farther and (not allow_same_side_resweep or active.get('repeat') or not low <= b.close <= high):
                    retire(b, 'sweep_extreme_extended')
                    active = None; segment = i + 1; continue
                if farther:
                    active.update(excursion=i, reclaim=None, run=[], repeat=True)
            if active['reclaim'] is not None:
                outside = b.close < low if active['side'] == 1 else b.close > high
                active['run'] = active['run'] + [b] if outside else []
                if len(active['run']) >= 2:
                    recent = active['run'][-2:]
                    if 'body' in active and max(-active['side']*(c.close-c.open) for c in recent) < active['body']:
                        continue
                    emit('D', recent, b.time + period, 'AMD', 'bearish' if active['side'] == 1 else 'bullish')
                    active = None; segment = i + 1
                continue
            side = 1 if b.high > high else -1 if b.low < low else None
            if active['side'] is None and side is not None:
                active['side'] = side; active['excursion'] = i
            if active['side'] is not None:
                if side is not None and side != active['side']:
                    retire(b, 'other_boundary_before_reclaim')
                    active = None; segment = i + 1; continue
                part = rows[active['excursion']:i+1]
                if low <= b.close <= high:
                    active['reclaim'] = i; active['run'] = []
                    active['extreme'] = max(c.high for c in part) if active['side'] == 1 else min(c.low for c in part)
                    emit('M', part, b.time + period, 'AM')
                else:
                    outside = b.close > high if active['side'] == 1 else b.close < low
                    active['run'] = active['run'] + [b] if outside else []
                    if len(active['run']) >= 2:
                        recent = active['run'][-2:]
                        if 'body' in active and max(active['side']*(c.close-c.open) for c in recent) < active['body']:
                            continue
                        emit('D', recent, b.time + period, 'AD_no_M', 'bullish' if active['side'] == 1 else 'bearish')
                        active = None; segment = i + 1
            continue
        if i - segment + 1 < window:
            continue
        if reference_shape is not None:
            if i != window-1 or segment:
                continue
            part = rows[:window]
            shape = reference_shape
            low, high = min(c.low for c in part), max(c.high for c in part)
            if high <= low:
                continue
        elif triangle_only:
            for size in (24,16,12,8):
                if size > i-segment+1:
                    continue
                part = rows[i-size+1:i+1]
                geometry = swing_shape(part)
                if geometry and geometry[0] in ("triangle","ascending_triangle","descending_triangle"):
                    shape,low,high = geometry
                    break
            else:
                continue
        else:
            part = rows[i-window+1:i+1]
            low = min(c.low for c in part); high = max(c.high for c in part)
            if high <= low:
                continue
            changes = [c.close-a.close for a, c in zip(part, part[1:]) if c.close != a.close]
            turns = sum(a*c < 0 for a, c in zip(changes, changes[1:]))
            overlap = sum(max(0, min(a.high,c.high)-max(a.low,c.low)) / max(a.high-a.low,c.high-c.low,1e-12)
                          for a,c in zip(part,part[1:])) / (window-1)
            efficiency = abs(part[-1].close-part[0].open)/(high-low)
            first, last = part[:window//2], part[window//2:]
            contraction = max(c.high for c in last) < max(c.high for c in first) and min(c.low for c in last) > min(c.low for c in first)
            geometry = swing_shape(part)
            if geometry:
                shape,low,high=geometry
            elif turns>=3 and overlap>=.45 and efficiency<=.35:
                shape = 'contracting' if contraction else 'overlapping'
            elif i-segment+1>=2*window:
                part=rows[i-2*window+1:i+1]
                geometry=swing_shape(part)
                if not geometry:continue
                shape,low,high=geometry
            else:
                continue
        active = {'id': hashlib.sha256((part[0].time.isoformat()+str(period)).encode()).hexdigest()[:16],
                  'low':low,'high':high,'formed':i,'side':None,'reclaim':None,'run':[],
                  'shape':shape}
        if require_displacement or triangle_only or reference_shape is not None:
            active['body'] = max(.01,median(abs(c.close-c.open) for c in part))
        emit('A', part, b.time + period, 'A')
    return events
