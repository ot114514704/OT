"""Give nearby first-in-path targets a bounded, evidence-based priority uplift."""


def promote_nearby(targets, price, hourly_range, *, sweep=False):
    """Update a fresh candidate list before ranks are assigned or frozen."""
    if not targets or hourly_range <= 0:
        return

    def edge_distance(row):
        if sweep:
            edge = row['hi'] if row['side'] > 0 else row['lo']
        else:
            edge = row['lo'] if row['side'] > 0 else row['hi']
        return abs(edge - price)

    nearest = {}
    for row in targets:
        side = row['side']
        distance = edge_distance(row)
        nearest[side] = min(nearest.get(side, distance), distance)
    for row in targets:
        distance = edge_distance(row)
        fraction = distance / hourly_range
        if distance != nearest[row['side']] or fraction > 1:
            continue
        parts_key = 'components' if sweep else 'score_components'
        parts = row.get(parts_key, {})
        bonus = 6
        if fraction <= .5:
            bonus += 6
        if fraction <= .25:
            bonus += 6
        if sweep:
            corroborated = (row.get('origins', 0) >= 2 and parts.get('dol', 0) > 0)
        else:
            corroborated = (parts.get('alignment', 0) >= 21 and parts.get('timing', 0) > 0)
        if corroborated and fraction <= .5:
            bonus += 4
        applied = min(bonus, 100 - row['score'])
        if applied <= 0:
            continue
        row['base_score'] = row['score']
        row['score'] += applied
        row.setdefault(parts_key, {})['priority_uplift'] = applied
        boundary = '扫荡外沿' if sweep else '触价近端'
        detail = f'同侧最近{boundary}距现价 {fraction:.2f} 倍 H1 波幅中位数，优先级 +{applied}（原 {row["base_score"]}）'
        if corroborated and fraction <= .5:
            detail += '，含独立锚点与 DOL 重叠' if sweep else '，含同向证据与活跃时段'
        if sweep:
            row['sources'].append(detail)
        else:
            row['reason'] += '；'+detail
