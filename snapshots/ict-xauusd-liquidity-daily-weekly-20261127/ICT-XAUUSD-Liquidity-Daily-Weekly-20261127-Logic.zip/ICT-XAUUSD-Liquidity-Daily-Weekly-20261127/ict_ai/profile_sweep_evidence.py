"""As-of M5 reactions to session extremes used by daily-profile candidates."""

from bisect import bisect_left, bisect_right

from .range_liquidity import M5
from .sweep_response import RESPONSE_BARS, crossing_response
from .timebase import session_windows


SESSIONS = {
    'classic_buy': ('asia','london'),
    'classic_sell_mirror': ('asia','london'),
    'classic_reversal_variant': ('london','new_york'),
    'double_sweep': ('london','new_york'),
}
FEATURES = ('session_cross_witnessed','session_cross_wick','session_cross_reclaim','session_cross_follow',
            'session_cross_unresolved')


def candidate_sweep(bars, times, day, as_of, candidate):
    """Use the first strict excursion after the reference session is complete."""
    family,direction = candidate
    sessions = SESSIONS.get(family)
    if sessions is None:
        return dict(state='not_applicable',features=[0]*len(FEATURES))
    windows = session_windows(day)
    reference, observation = (windows[key] for key in sessions)
    left,right = reference
    side = -direction
    closed = bisect_right(times,as_of-M5)

    def gap(state):
        return dict(state=state,features=[0]*len(FEATURES),reference_session=sessions[0],
                    observation_session=sessions[1])

    if right > as_of:
        return gap('reference_open')
    history = bars[bisect_left(times,left):bisect_left(times,right)]
    if len(history) != (right-left)//M5 or any(b.time != left+i*M5 for i,b in enumerate(history)):
        return gap('reference_missing')
    edge = max(b.high for b in history) if side>0 else min(b.low for b in history)
    first,last = observation
    start = bisect_left(times,first)
    stop = min(closed,bisect_left(times,last))
    for i,bar in enumerate(bars[start:stop],start):
        if bar.time != first+(i-start)*M5:
            return gap('observation_missing')
        extreme = bar.high if side>0 else bar.low
        if side*(extreme-edge)<=0:
            continue
        if not bar.low<=edge<=bar.high:
            return gap('outside_without_witnessed_cross')
        response = crossing_response(side,edge,bars[max(0,i-15):i],bar,
                                     bars[i+1:min(closed,i+1+RESPONSE_BARS)],as_of)
        status = response['status']
        return dict(state=status,edge=edge,side=side,crossing_known_at=(bar.time+M5).isoformat(),
                    verdict_known_at=response['known_at'],prior_atr=response['prior_atr'],
                    reference_session=sessions[0],observation_session=sessions[1],
                    features=[1,int(bool(response['wick_band'])),int(status=='sweep'),
                              int(status=='break'),int(status not in ('sweep','break'))])
    if stop-start != max(0,(min(last,as_of)-first)//M5):
        return gap('observation_missing')
    return dict(gap('no_strict_cross'),edge=edge,side=side)
