"""As-of, same-frame local pullback evidence for the read-only XAUUSD chart."""

from bisect import bisect_right
from datetime import timedelta

from .ipda_outlook import ny_four_hour_bars
from .ipda_reference.core import Bar, aggregate, instant
from .ipda_reference.ipda_phases import detect_phases
from .pullback_observations import pullback_observations


FRAMES = (('M5',300),('M15',900),('H1',3600),('H4 NY',14400))
DETAIL_FIELDS = ('id','direction','origin','expansion_end','expansion_end_available_at','first_observed_at',
                 'deepest_price','deepest_available_at','depth_ratio','time_ratio','area_ratio',
                 'relative_adverse_speed','mean_body_overlap','origin_wick_crossed','as_of')


class FramePullbacks:
    def __init__(self, candles, cutoff, seconds):
        self.period = timedelta(seconds=seconds)
        phases = detect_phases(candles,cutoff,timeframe_seconds=seconds)
        self.times = [instant(row['known_at']) for row in phases]
        self.phases = [(r['phase'],r['direction'],r['metrics']['atr14_prior'] is not None) for r in phases]
        self.observations = {instant(row['as_of']):row for row in pullback_observations(candles,phases,cutoff)}

    def at(self, cutoff):
        index = bisect_right(self.times,cutoff)-1
        if index<0:
            return dict(status='missing_history',as_of=None,phase=None,phase_direction=None)
        known = self.times[index]
        phase,direction,warm = self.phases[index]
        basis = dict(as_of=known.isoformat(),phase=phase,phase_direction=direction)
        if cutoff-known>=self.period:
            return dict(basis,status='no_recent_complete_bar')
        actual = self.observations.get(known)
        if actual is None:
            return dict(basis,status='no_local_pullback' if warm else 'insufficient_phase_history')
        if actual['status']=='data_discontinuity':
            return dict(basis,status='data_discontinuity',last_continuous_close=actual['last_continuous_close'])
        details = {key:actual[key] for key in DETAIL_FIELDS}
        return dict(basis,status=actual['status'],measurement=details)


def attach_pullback_context(primary, raw_m5, as_of):
    """Attach all frames only to the broker-clock series and its existing checkpoints."""
    points = [point for d in primary['days'] for point in d.get('profile_timeline',[])]
    if not points or not raw_m5:
        return
    first = min(instant(p['as_of']) for p in points)-timedelta(days=9)
    m5 = [b for b in raw_m5 if first<=b.closed_at<=as_of]
    rows = {'M5':m5,'M15':aggregate(m5,900,as_of),'H1':aggregate(m5,3600,as_of),
            'H4 NY':ny_four_hour_bars(m5,as_of)}
    observers = {name:FramePullbacks(rows[name],as_of,seconds) for name,seconds in FRAMES}
    for point in points:
        at = instant(point['as_of'])
        point['pullback_frames'] = {name:observers[name].at(at) for name,_ in FRAMES}
