"""Evaluate an ERL-origin invalidation hypothesis using completed bars."""
from brooks_ai.types import utc_time

from .daily_context import M5, _open


def external_origin_filter(review):
    """Apply the origin-close hypothesis to a route selected before the check."""
    return {
        "adverse_source_close_first": "withdrawn",
        "order_unknown_due_to_gap": "unresolved",
        "target_and_source_close_same_confirmation": "unresolved",
        "no_prior_route": "no_prior_route",
        "still_pending": "retained",
        "target_contact_first": "retained",
        "not_applicable_to_internal_origin": "retained",
    }[review["status"]]


def external_route_state(watch, bars, frame, as_of):
    """Match a frozen route to its confirmed origin and observe its two endpoints.

    A source-timeframe close back across the reclaimed level is a research
    invalidation rule. An earlier M5 cross is evidence of adverse movement.
    """
    route = watch["selected_route"]
    if route is None:
        return {"status": "no_prior_route"}
    if route["route"] != "ERL_to_IRL":
        return {"status": "not_applicable_to_internal_origin", "route_id": route["id"]}
    now = utc_time(as_of)
    origin = utc_time(route["origin_known_at"])
    if origin > utc_time(watch["frozen_at"]) or utc_time(watch["frozen_at"]) > now:
        raise ValueError("Route selection must be available at the review cutoff")
    point = next((p for p in frame["confirmed_swings"] if p["id"] == route["source_id"]), None)
    side = route["direction"]
    if (point is None or point["timeframe"] != route["timeframe"] or utc_time(point["available_at"]) > origin
            or (point["kind"], side) not in (("H", -1), ("L", 1))):
        raise ValueError("Require the original confirmed external level")
    level = point["price"]
    target = route["target"]
    adverse = min(
        (utc_time(period["available_at"]) for period in frame["periods"]
         if origin < utc_time(period["available_at"]) <= now and side * (period["close"] - level) < 0),
        default=None,
    )
    first_gap = m5_wick = m5_close = touch = None
    gaps = 0
    stamp = origin
    while stamp + M5 <= now:
        known = stamp + M5
        if _open(stamp):
            bar = bars.get(stamp)
            if bar is None:
                gaps += 1
                first_gap = first_gap or known
            else:
                edge = bar.low if side == 1 else bar.high
                if side * (edge - level) < 0:
                    m5_wick = m5_wick or known
                if side * (bar.close - level) < 0:
                    m5_close = m5_close or known
                if bar.low <= target["upper"] and bar.high >= target["lower"]:
                    touch = touch or known
        stamp = known
    decisive = min((instant for instant in (adverse, touch) if instant is not None), default=None)
    if first_gap and (decisive is None or first_gap <= decisive):
        status = "order_unknown_due_to_gap"
    elif decisive is None:
        status = "still_pending"
    elif adverse == touch:
        status = "target_and_source_close_same_confirmation"
    elif decisive == adverse:
        status = "adverse_source_close_first"
    else:
        status = "target_contact_first"
    times = {
        "adverse_m5_wick_known_at": m5_wick, "adverse_m5_close_known_at": m5_close,
        "adverse_source_timeframe_close_known_at": adverse, "target_contact_known_at": touch,
        "first_expected_gap_known_at": first_gap,
    }
    return {"status": status, "route_id": route["id"], "origin_level": level,
            "origin_timeframe": route["timeframe"], "origin_known_at": origin.isoformat(),
            "evaluated_at": now.isoformat(), "missing_expected_m5": gaps,
            **{key: value.isoformat() if value is not None else None for key, value in times.items()}}
