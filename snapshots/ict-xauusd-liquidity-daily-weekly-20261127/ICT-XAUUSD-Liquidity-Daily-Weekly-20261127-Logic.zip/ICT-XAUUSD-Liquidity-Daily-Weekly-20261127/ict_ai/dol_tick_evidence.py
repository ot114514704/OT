"""Strict witnessed Bid contacts for frozen DOL rankings."""

from collections import defaultdict
from datetime import datetime, timezone
import math

from .dol_outlook import M5
from .range_liquidity import _research_open


def utc_ms(stamp):
    if stamp.utcoffset() is None:
        raise ValueError('Bid evidence timestamps require a timezone')
    delta = stamp.astimezone(timezone.utc) - datetime(1970, 1, 1, tzinfo=timezone.utc)
    return (delta.days * 86400 + delta.seconds) * 1000 + delta.microseconds // 1000


class BidEvidence:
    """Convert supplied UTC quotes into five-minute buckets before replaying windows."""

    def __init__(self, bars, quotes):
        self.bars = {utc_ms(bar.time): bar for bar in bars}
        if len(self.bars) != len(bars) or any(stamp % 300000 for stamp in self.bars):
            raise ValueError('Closed M5 references must be unique and aligned')
        self.quotes = defaultdict(list)
        last = -1
        for stamp, bid in quotes:
            if type(stamp) is not int or stamp < 0 or stamp < last or not math.isfinite(bid) or bid <= 0:
                raise ValueError('Bid evidence must be positive and ordered by UTC millisecond')
            self.quotes[stamp - stamp % 300000].append((stamp, bid))
            last = stamp
        self.reconciled = {stamp for stamp in self.bars if self.reconcile(stamp)}

    def reconcile(self, stamp):
        """Require an independent M5 reference with the same four prices."""
        group = self.quotes.get(stamp, ())
        bar = self.bars.get(stamp)
        if not group or bar is None:
            return False
        bids = [bid for _, bid in group]
        rebuilt = bids[0], max(bids), min(bids), bids[-1]
        return all(abs(a-b) < 1e-8 for a, b in zip(rebuilt, (bar.open, bar.high, bar.low, bar.close)))

    def replay(self, row, as_of):
        start, registered, end = (datetime.fromisoformat(row[k]) for k in ('cutoff','recorded_at','end'))
        if not start <= registered < end or utc_ms(start)%300000 or utc_ms(end)%300000:
            raise ValueError('Invalid frozen evidence window')
        if as_of < end:
            return dict(status='open', contacts={}, first_ranks=[])
        checked = []
        for i in range((end-start)//M5):
            opened = start + i * M5
            stamp = utc_ms(opened)
            if _research_open(opened) or stamp in self.bars or stamp in self.quotes:
                checked.append(stamp)
        missing = [stamp for stamp in checked if stamp not in self.reconciled]
        if missing:
            return dict(status='unverified_quotes', missing_m5_utc_ms=missing, contacts={}, first_ranks=[])
        registered_ms = utc_ms(registered) + int(registered.microsecond%1000 != 0)
        post = False
        contacts = {}
        pending = {p['rank']: p for p in row['targets']}
        if len(pending) != len(row['targets']):
            raise ValueError('Duplicate frozen candidate rank')
        for bucket in checked:
            group = self.quotes[bucket]
            bar = self.bars[bucket]
            post |= group[-1][0] >= registered_ms
            for rank, target in list(pending.items()):
                lo, hi = target['lo'],target['hi']
                if bar.high < lo or bar.low > hi:
                    continue
                hit = next(((stamp,bid) for stamp,bid in group if lo <= bid <= hi), None)
                if hit is not None:
                    stamp, bid = hit
                    contacts[rank] = dict(utc_ms=stamp, bid=bid, eligible=stamp>=registered_ms)
                    del pending[rank]
            if post and not pending:
                break
        if not post:
            return dict(status='no_observation_window', contacts=contacts, first_ranks=[])
        observed = {rank: entry['utc_ms'] for rank, entry in contacts.items() if entry['eligible']}
        first = min(observed.values(), default=None)
        first_ranks = sorted(rank for rank, stamp in observed.items() if stamp == first)
        bounds = {(p['side'],p['lo'],p['hi']) for p in row['targets'] if p['rank'] in first_ranks}
        status = ('no_hit' if not first_ranks else 'unique' if len(first_ranks)==1 else
                  'shared_target' if len(bounds)==1 else 'same_millisecond')
        return dict(status=status, checked_m5=len(checked), contacts=contacts, first_ranks=first_ranks)
