"""Compare an independent higher-timeframe candidate against the local ERL shortlist."""

from collections.abc import Mapping, Sequence


def outside(candidate: Mapping) -> tuple[int, float]:
    side = candidate['side']
    if side not in (-1, 1):
        raise ValueError('A liquidity side must be +1 or -1')
    return side, candidate['hi' if side == 1 else 'lo']


def compare_shortlists(local: Sequence[Mapping], upstream: Sequence[Mapping], close: float) -> dict:
    """Both ordered inputs must be from the same closed-bar cutoff.

    Keep local priority for the main shortlist. The first upstream price that
    lies between price and a same-side local outer edge, or fills an uncovered
    side, may occupy one supplemental slot. A two-slot challenger is returned
    separately for evaluating the cost of replacing local rank two.
    """
    baseline = list(local[:2])
    local_edges = [outside(candidate) for candidate in baseline]
    extra = None
    for candidate in upstream[:2]:
        side, edge = outside(candidate)
        distance = side * (edge - close)
        same_side = [side * (local_edge - close) for local_side, local_edge in local_edges if local_side == side]
        if ((side, edge) not in local_edges and distance > 0
                and (not same_side or 0 < distance < max(same_side))):
            extra = candidate
            break
    supplemental = baseline + [extra] if extra is not None else baseline
    challenger = baseline
    if extra is not None:
        if len(baseline) < 2 or abs(outside(extra)[1] - close) < abs(local_edges[1][1] - close):
            challenger = baseline[:1] + [extra]
    return dict(local=baseline, supplement=supplemental, fixed_two=challenger, extra=extra)
