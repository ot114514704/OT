"""Intraday analogue of the weekly extreme path, anchored at NY midnight."""
from bisect import bisect_right
from itertools import groupby

from .timebase import NY, session_windows


def daily_geometry(bars, start, cutoff, period):
    """Connect ordered window extremes; leave ambiguous or unquoted spans open."""
    rows = [b for b in bars if start <= b.time and b.time + period <= cutoff]
    windows = session_windows(start.astimezone(NY).date())
    bounds = sorted({t for interval in windows.values() for t in interval if start < t < cutoff})
    segments = []
    opening = rows[0].open if rows and rows[0].time == start else None
    endpoint = None
    last_side = crossings = ambiguities = 0
    gap = False

    def vertex(stamp, price):
        nonlocal endpoint, crossings, last_side
        if endpoint and endpoint != (stamp, price):
            segments.append((endpoint[0], endpoint[1], stamp, price))
        endpoint = stamp, price
        if opening is not None and price != opening:
            side = 1 if price > opening else -1
            crossings += int(last_side == -side)
            last_side = side

    previous = None
    continuous = []
    for bar in rows:
        if previous is None or previous.time + period != bar.time:
            continuous.append([])
            if previous is not None:
                gap |= any((previous.time + period*i).astimezone(NY).hour != 17
                           for i in range(1, int((bar.time-previous.time)/period)))
        continuous[-1].append(bar)
        previous = bar
    for run in continuous:
        endpoint, last_side = None, 0
        vertex(run[0].time, run[0].open)
        for _, group in groupby(run, key=lambda b: bisect_right(bounds, b.time)):
            part = list(group)
            hi = max(part, key=lambda b: b.high)
            lo = min(part, key=lambda b: b.low)
            if hi.time == lo.time and hi.high != lo.low:
                ambiguities += 1
                endpoint, last_side = None, 0
                vertex(hi.time + period, hi.close)
            else:
                for t, p in sorted({(hi.time, hi.high), (lo.time, lo.low)}):
                    vertex(t, p)
        vertex(run[-1].time + period, run[-1].close)
    width = max(b.high for b in rows)-min(b.low for b in rows) if rows else 0
    offset = (rows[-1].close-opening)/width if width and opening is not None else None
    usable = offset is not None and not gap and not ambiguities and len(segments)>=2
    if opening is None:
        note = '缺少纽约零点开盘价，折线暂缓参与排序。'
    else:
        note = f'纽约开 {opening:.2f}，折线穿越开盘线 {crossings} 次，末收 {rows[-1].close:.2f}'
        if offset is not None:
            note += f'，距开盘 {abs(offset):.0%} 日内已见振幅（{"上方" if offset>0 else "下方" if offset<0 else "持平"}）'
        if ambiguities: note += '；同棒高低先后待核'
        if gap: note += '；盘中报价中断'
        note += '。'
    return dict(segments=segments, crossings=crossings, offset=offset, usable=usable, reason=note)


def candidate_fit(card, path):
    """Secondary ordering only; original confirmation and invalidation still apply."""
    if not path['usable'] or not card['observed_sequence'] or card['status']!='active':
        return 0
    if card['id']=='seek_destroy':
        return int(path['crossings']>=2 and abs(path['offset'])<=.25)
    if card['direction'] in (-1,1):
        aligned = card['direction'] * path['offset']
        return 1 if aligned>=.25 else -1 if aligned<=-.25 else 0
    return 0
