"""Research-only Friday follow-through after a frozen three-day NY range."""

from datetime import timedelta

from .profile_lifecycle import _day_bounds, _extension
from .profile_sources import profile_source
from .timebase import NY
from .weekly_path import consolidation_evidence


REVERSAL = "weekly_thursday_consolidation_reversal"
EXPANSION = "weekly_consolidation_expansion"
CONTINUATION = "thursday_expansion_friday_followthrough"
PERIOD = timedelta(minutes=15)


def friday_followthrough(realized, quarters, days, at, covered):
    """Keep separate Friday evidence for Thursday's breakout and opposite reversal."""
    start, end = _day_bounds(days[-1])
    if at < start:
        return []
    complete = {row["date"]: row for row in realized["daily"]
                if row["ended"] and row["coverage_complete"]}
    first_four = [complete.get(day.isoformat()) for day in days[:4]]
    if any(row is None for row in first_four):
        return []
    consolidation = consolidation_evidence(first_four[:3])
    if not consolidation["matched"]:
        return []

    thursday = first_four[-1]
    upper, lower = consolidation["high"], consolidation["low"]
    bars = [bar for bar in quarters if start <= bar.time and bar.time + PERIOD <= min(end, at)]
    result = []
    for side, delivery, opposite, extreme, inverse in (
        (1, upper, lower, "high", "low"), (-1, lower, upper, "low", "high"),
    ):
        swept = side * (thursday[inverse] - opposite) < 0
        breakout = side * (thursday["close"] - delivery) > 0
        if swept:
            level = max(delivery, thursday["close"]) if side == 1 else min(delivery, thursday["close"])
            failure = next((bar for bar in bars if side * (getattr(bar, inverse) - thursday[inverse]) < 0), None)
            result.append(_card(REVERSAL, "thursday_extreme_friday_reversal", side, level,
                                bars, start, covered, failure=failure))
        elif breakout:
            advanced = next((bar for bar in bars if side * (getattr(bar, extreme) - thursday[extreme]) > 0), None)
            result.append(_card(EXPANSION, CONTINUATION, side, delivery, bars, start, covered,
                                advanced=advanced, needs_new_extreme=True))
    for row in result:
        row.update(range_low=lower, range_high=upper, thursday_high=thursday["high"],
                   thursday_low=thursday["low"], thursday_close=thursday["close"])
    return result


def _known_ny(bar):
    return (bar.time + PERIOD).astimezone(NY).isoformat() if bar else None


def _card(ident, variant, side, level, bars, known, covered, *, failure=None,
          advanced=None, needs_new_extreme=False):
    closes = _extension(bars, level, side, PERIOD)
    status = "awaiting_friday_delivery"
    if not covered:
        status = "insufficient_data"
    elif failure is not None:
        status = "thursday_extreme_broken"
    elif closes is not None and (advanced is not None or not needs_new_extreme):
        status = "observed_candidate" if side * (bars[-1].close - level) > 0 else "back_inside"
    return {
        "id": ident, "variant": variant, "direction": side, "status": status,
        "frozen_at_ny": known.astimezone(NY).isoformat(), "close_reference": level,
        "last_friday_m15_close_ny": _known_ny(bars[-1]) if bars else None,
        "two_closes_known_ny": _known_ny(closes), "new_extreme_known_ny": _known_ny(advanced),
        "thursday_extreme_broken_known_ny": _known_ny(failure),
        "source": profile_source(ident, True), "execution_allowed": False,
    }
