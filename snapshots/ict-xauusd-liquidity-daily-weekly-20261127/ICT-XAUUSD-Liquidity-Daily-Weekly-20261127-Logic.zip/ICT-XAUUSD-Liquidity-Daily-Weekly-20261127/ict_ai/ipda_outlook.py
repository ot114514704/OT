"""M15 IPDA observations and an as-of, one-hour next-phase ranking."""
from bisect import bisect_right
from collections import Counter
from datetime import datetime, timedelta, timezone

from .ipda_reference.core import Bar
from .ipda_reference.ipda_phases import detect_phases
from .h4_review import expected_gold_bar
from .pullback_observations import pullback_observations, pullback_note
from .timebase import NY

NAMES = dict(expansion="扩张", retracement="回调", reversal="反转", consolidation="盘整", undetermined="待定")


# Union of the direct edges in the two user-supplied diagrams, read at one scale.
DIRECT = {
    "consolidation": ("expansion",),
    "expansion": ("retracement", "reversal", "consolidation"),
    "retracement": ("expansion",),
    "reversal": ("expansion", "consolidation"),
}
PATH_REASON = {
    "consolidation": "盘整离开区间先观察扩张；直接回调、反转均缺少前一段已确认扩张。突破方向待收盘越界及跟随。",
    "expansion": "扩张可转回调、反转或盘整。留在原推动范围内看回调；反向位移收破保护位看反转；双边重叠并形成平衡区看盘整。",
    "retracement": "回调后直接观察扩张。直接反转、盘整均跳过两图中的扩张节点；若保护位失守，重新核对原回调判断及新位移。",
    "reversal": "反转后可沿新方向扩张，也可直接转入盘整。直接回调缺少可供回撤的新方向扩张段。",
}


def phase_support_counts(rows):
    """Compare independent historical observations using price features alone."""
    def features(row):
        m=row['metrics']
        atr=m['atr14_prior']
        if not atr or atr<=0:
            return None
        return (min(3,abs(m['net3'])/atr)/3, m['efficiency3'], m['efficiency8'], m['overlap8'])

    current=rows[-1]
    if current['phase']=='undetermined':
        return 0,0
    target=features(current)
    neighbors=[]
    if target:
        for i in range(len(rows)-9,-1,-8):
            candidate=features(rows[i])
            if candidate is None:
                continue
            distance=sum(abs(x-y) for x,y in zip(candidate,target))/len(target)
            if distance<=.15:
                neighbors.append((distance,rows[i]['phase']))
    closest=sorted(neighbors,key=lambda item:item[0])[:20]
    counts=Counter(p for _,p in closest)
    return counts[current['phase']],len(closest)


def current_phase_support(rows):
    hits,total=phase_support_counts(rows)
    if rows[-1]['phase']=='undetermined':
        return '当前阶段支持度待核。结构证据不足。'
    if total<5:
        return f'当前阶段支持度待核。相近历史形态仅 {total} 段。'
    return (f'当前阶段形态支持度 {hits}/{total}（{100*hits/total:.0f}/100）。'
            '按归一化位移、方向效率和重叠度比较历史 K 线；分数表示同类标签占比，未经概率校准。')


def ny_four_hour_bars(five, cutoff):
    step=timedelta(minutes=5)
    groups={}
    for bar in five:
        if bar.time+step>cutoff:
            continue
        et=bar.time.astimezone(NY)
        start=et.replace(hour=4*(et.hour//4),minute=0,second=0,microsecond=0)
        groups.setdefault(start,[]).append(bar)
    bars=[]
    for wall,items in groups.items():
        start=wall.astimezone(timezone.utc)
        end=(wall+timedelta(hours=4)).astimezone(timezone.utc)
        if end>cutoff or end-start!=timedelta(hours=4):
            continue
        expected=[start+i*step for i in range(48) if expected_gold_bar(start+i*step)]
        if [b.time for b in items]!=expected:
            continue
        bars.append(Bar(start,items[0].open,max(b.high for b in items),min(b.low for b in items),
                        items[-1].close,seconds=14400))
    return bars


def phase_frame_marks(five,hourly,cutoff):
    frames=[('H4',14400,ny_four_hour_bars(five[-40000:],cutoff)),('H1',3600,hourly),('M5',300,five)]
    for frame,seconds,source in frames:
        candles=[Bar(b.time,b.open,b.high,b.low,b.close,seconds=seconds) for b in source[-802:]]
        rows=detect_phases(candles,cutoff,timeframe_seconds=seconds)
        pullbacks={r['as_of']:r for r in pullback_observations(candles,rows,cutoff)}
        # Keep the previous observation when the newest published close is ahead of the last tick.
        for i in range(max(0,len(rows)-2),len(rows)):
            r=rows[i]
            hits,total=phase_support_counts(rows[:i+1])
            score=round(100*hits/total) if total>=5 else -1
            direction={1:'↑',-1:'↓',0:''}[r['direction']]
            at=datetime.fromisoformat(r['known_at'])
            label=NAMES[r['phase']]+direction+'｜'+r['reason']
            if r['known_at'] in pullbacks:
                label+='｜'+pullback_note([pullbacks[r['known_at']]],cutoff,at)
            if r['phase']=='undetermined':
                previous=next((p for p in reversed(rows[:i]) if p['run_start']==r['run_start']
                               and p['phase']!='undetermined'),None)
                if previous:
                    prior_time=datetime.fromisoformat(previous['known_at']).astimezone(NY)
                    label+=f" 最近已识别为{NAMES[previous['phase']]}（美东 {prior_time:%m-%d %H:%M}）。"
                elif r['metrics']['atr14_prior'] is None:
                    label+=" 当前连续行情未满 14 根前置 K 线。"
            yield 'ipda_frame_'+frame,at,at,label,score,r['direction']


def phase_note(bars, asof, hourly=()):
    candles=[Bar(b.time,b.open,b.high,b.low,b.close,seconds=900) for b in bars if b.time+timedelta(minutes=15)<=asof][-800:]
    rows=detect_phases(candles,asof)
    if not rows:
        return "IPDA M15 待定｜缺已收 M15"
    current=rows[-1]
    phase=current["phase"]
    closed_hours=[Bar(b.time,b.open,b.high,b.low,b.close,seconds=3600) for b in hourly if b.time+timedelta(hours=1)<=asof][-250:]
    h1=detect_phases(closed_hours,asof,timeframe_seconds=3600) if closed_hours else []
    known=[r["known_at"] for r in h1]
    def background(row):
        ix=bisect_right(known,row["known_at"])-1
        if ix<0 or datetime.fromisoformat(row["known_at"])-datetime.fromisoformat(known[ix])>=timedelta(hours=1):
            return None
        return h1[ix]["phase"],h1[ix]["direction"]
    backdrop=background(current)
    votes=Counter()
    samples=0
    # Non-overlapping one-hour observation windows. Include continued and unknown outcomes.
    for i in range(len(rows)-5,-1,-4):
        past=rows[i]
        future=rows[i+1:i+5]
        if past["phase"]!=phase or future[-1]["run_start"]!=past["run_start"]:
            continue
        weight=1+int(past["direction"]==current["direction"])+int(bool(past["pda_contacts"])==bool(current["pda_contacts"]))
        if backdrop and backdrop[0]!="undetermined" and background(past)==backdrop:
            weight+=1
        nxt=next((r["phase"] for r in future if r["phase"] not in (phase,"undetermined")),None)
        outcome=nxt or (phase if future[-1]["phase"]==phase else "undetermined")
        votes[outcome]+=weight
        samples+=1
    name=NAMES[phase]
    side={1:"↑",-1:"↓",0:""}[current["direction"]]
    previous=next((row for row in reversed(rows[:-1]) if row['run_start']==current['run_start']
                   and row['phase'] not in (phase,'undetermined')),None)
    title=f"IPDA M15 {name}{side}"
    previous_note='上一可识别阶段待定，本段连续报价内尚无其他已识别阶段。'
    if previous:
        stamp=datetime.fromisoformat(previous['known_at']).astimezone(NY)
        previous_note=f"上一可识别阶段为{NAMES[previous['phase']]}（美东 {stamp:%m-%d %H:%M} 收线）。{previous['reason']}"
    details=[datetime.fromisoformat(current["known_at"]).astimezone(NY).strftime("截至美东 %m-%d %H:%M"),
             previous_note, f'当前{name}。'+current["reason"],current_phase_support(rows)]
    pullback = pullback_note(pullback_observations(candles,rows,asof),asof,current['known_at'])
    if pullback:
        details.append(pullback)
    if backdrop:
        details.append("同期 H1 "+NAMES[backdrop[0]]+{1:"↑",-1:"↓",0:""}[backdrop[1]])
    anchor=current.get("reference_after")
    if anchor and anchor.get("direction"):
        protected=anchor["low"] if anchor["direction"]==1 else anchor["high"]
        details.append(f"结构参考起点 {protected:.2f}，若反向位移收破此处，重新评估反转")
    if phase in DIRECT:
        details.append("同级直接路径 · "+PATH_REASON[phase])
    close=datetime.fromisoformat(current["known_at"])
    pause=next((close+timedelta(minutes=m) for m in range(0,60,5)
                if not expected_gold_bar(close+timedelta(minutes=m))),None)
    if pause is not None:
        reason=(f"按黄金常规研究时段，美东 {pause.astimezone(NY):%m-%d %H:%M} 进入休市。"
                "这一小时缺少连续四根 M15，下一阶段暂停评分。节假日时段需另核。")
        return "｜".join([title+" · 一小时候选 跨休市，暂停评分",*details,reason])
    if phase=="undetermined" or samples<5:
        return "｜".join([title+" · 下阶段待定",*details,f"历史同阶段完整一小时 {samples} 段；证据不足"])
    total = sum(votes.values())
    def score(key):
        return round(100*votes[key]/total)
    allowed = DIRECT[phase]
    order = sorted(allowed,key=lambda key:-votes[key])
    direct = [key for key in order if votes[key]]
    # Keep the original denominator. Skipped labels are observable uncertainty.
    skipped = sum(n for key,n in votes.items() if key not in (*allowed,phase,"undetermined"))
    eligible = [key for key in (phase,*allowed) if votes[key]]
    if eligible:
        first = max(eligible,key=lambda key:votes[key])
        best = ("维持" if first==phase else "")+NAMES[first]
        title+=f" · 一小时候选 {best} {score(first)}/100"
    else:
        title+=" · 下阶段待定"
    details += [f"当前阶段维持 {score(phase)}/100",
                "若发生直接转换 · "+" / ".join(f"{NAMES[key]} {score(key)}/100" for key in direct) if direct else "直接转换 · 缺匹配样本",
                f"最近 {len(rows)} 根 M15，同阶段 {samples} 个互不重叠的一小时窗口；同方向、PDA 接触及已确认 H1 背景相符提高权重",
                f"待定证据 {score('undetermined')}/100；观测跳段 {round(100*skipped/total)}/100，保留原分母。分数未经概率校准"]
    return "｜".join([title,*details])
