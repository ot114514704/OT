"""NY Silver Bullet reversal observations. Each status is known only at a bar close."""
from datetime import timedelta
from statistics import median

from .session_path import PARAMS, et_clock_text


def assess(before, bars, start, cutoff, step, *, trigger_evidence=None):
    frame = f"M{int(step.total_seconds() // 60)}"
    if not before or not bars or before[-1].time+step!=start:
        return None
    # Only the contiguous suffix supplies the swing and true-range baselines.
    # A gap earlier than both references does not invalidate a complete window.
    first=len(before)-1
    while first>0 and before[first].time-before[first-1].time==step:
        first-=1
    before=before[first:]
    if len(before)<max(PARAMS.prior_range_bars+1,timedelta(hours=1)//step):
        return None
    expected = (cutoff-start)//step
    prefix = []
    for i, bar in enumerate(bars):
        if i >= expected or bar.time != start + i*step:
            break
        prefix.append(bar)
    if not prefix:
        return None
    rows = list(before) + prefix
    best = (0, None, f"{frame} 未见越过已知高低并收回")
    confirmed = []
    for i in range(len(before), len(rows)):
        sweep = rows[i]
        prior = rows[i - timedelta(hours=1)//step:i]
        for side in (1, -1):
            extreme = (lambda b: -b.low) if side == 1 else (lambda b: b.high)
            swing = next((extreme(prior[k]) for k in range(len(prior)-3, 1, -1)
                          if all(extreme(prior[k]) > extreme(prior[k+j]) for j in (-2,-1,1,2))
                          and max(map(extreme, prior[k+1:])) <= extreme(prior[k])), None)
            levels = [max(map(extreme, before[-(timedelta(hours=1)//step):]))]
            if swing is not None:
                levels.append(swing)
            crossed = [v for v in levels if extreme(sweep)>v and -side*sweep.close<v
                       and extreme(rows[i-1])<=v]
            if not crossed:
                continue
            level = -side * max(crossed)
            source="窗前一小时" if max(crossed)==levels[0] else "已确认局部"
            note = (f"美东 {et_clock_text(sweep.time+step)}，{frame} 刺穿{source}"
                    f"{'低' if side==1 else '高'}点 {level:.2f} 至 {-side*extreme(sweep):.2f}，收在 {sweep.close:.2f}，扫后收回")
            if best[0] < 1:
                best = (1,None,note+"，待反向位移及 CISD")
            # Opening price of the last uninterrupted leg into the raid.
            k = i if side*(sweep.close-sweep.open)<0 else i-1
            if side*(rows[k].close-rows[k].open)>=0:
                continue
            while k>0 and side*(rows[k-1].close-rows[k-1].open)<0:
                k-=1
            anchor = rows[k].open
            gaps = []
            last_impulse = None
            for j in range(i+1,len(rows)):
                b = rows[j]
                if extreme(b) > extreme(sweep) and -side*b.close > extreme(sweep):
                    if best[2].startswith(note):
                        path=best[2].split("，待反向位移")[0].split("，缺新生 FVG")[0].split("，尚缺窗内")[0]
                        best=(best[0],None,path+f"；{et_clock_text(b.time+step)} 收于 {b.close:.2f}，候选失效，实体收破扫荡极值")
                    break
                matched=False
                for lo, hi, detail, fvg_at in gaps:
                    if b.low<=hi and b.high>=lo and side*(b.close-(lo if side==1 else hi))>=0:
                        matched=True
                        message=detail+f"。{et_clock_text(b.time+step)} 回踩缺口，收于 {b.close:.2f}，保住{'下' if side==1 else '上'}沿，{'看涨' if side==1 else '看跌'}路径触发"
                        failed=next((r for r in rows[j+1:] if -side*r.close>extreme(sweep)),None)
                        if failed:
                            message+=f"；其后 {et_clock_text(failed.time+step)} 收破扫荡极值，模型失效"
                        evidence = dict(direction=side, sweep_open=sweep.time, sweep_known=sweep.time+step,
                                        sweep_level=level, protected_extreme=-side*extreme(sweep),
                                        fvg_at=fvg_at, fvg_low=lo, fvg_high=hi, at=b.time+step)
                        confirmed.append(((4,b.time+step,message),evidence))
                        break
                if matched:
                    break
                valid=[]
                for lo,hi,detail,fvg_at in gaps:
                    far=lo if side==1 else hi
                    if side*(b.close-far)>=0:
                        valid.append((lo,hi,detail,fvg_at))
                    elif best[2]==detail+"，尚缺窗内回踩确认":
                        best=(3,None,detail+f"；{et_clock_text(b.time+step)} 收于 {b.close:.2f}，穿过缺口远沿 {far:.2f}，该 FVG 回踩失效")
                gaps=valid
                # Only a displacement already known at the preceding close can form this FVG.
                if last_impulse and last_impulse[0]==j-1:
                    first=rows[j-2]
                    lo,hi=(first.high,b.low) if side==1 else (b.high,first.low)
                    if lo<hi:
                        detail=last_impulse[1]+f"；{et_clock_text(b.time+step)} 三根K线确认{'看涨' if side==1 else '看跌'} FVG {lo:.2f}–{hi:.2f}"
                        gaps.append((lo,hi,detail,b.time+step))
                        if best[0]<3 or (best[0]==3 and "失效" in best[2]):
                            best=(3,None,detail+"，尚缺窗内回踩确认")
                # Report the displacement immediately, even if the third candle is still open.
                n = PARAMS.prior_range_bars
                baseline = rows[j-n-1:j]
                tr = median(max(q.high-q.low,abs(q.high-r.close),abs(q.low-r.close)) for r,q in zip(baseline,baseline[1:]))
                p=rows[j-1]
                width=b.high-b.low
                if (width<=0 or tr<=0 or width<PARAMS.displacement_range_ratio*tr
                    or side*(b.close-b.open)<PARAMS.minimum_body_fraction*width
                    or side*(b.close-(p.high if side==1 else p.low))<=0 or side*(b.close-anchor)<=0):
                    continue
                detail=(note+f"。{et_clock_text(b.time+step)} 反向实体位移 {b.close-b.open:+.2f}，全幅为此前中位真波幅的 {width/tr:.1f} 倍，"
                        f"收盘{'上破' if side==1 else '下破'}扫荡前连续走势的起始开盘价 {anchor:.2f}，确认 CISD")
                last_impulse=(j,detail)
                if best[0]<2:
                    best=(2,None,detail+"，缺新生 FVG")
    if confirmed:
        (rank, known, detail), evidence = min(confirmed,key=lambda item:item[0][1])
        if trigger_evidence is not None:
            trigger_evidence.update(evidence)
        if len(prefix) < expected:
            detail += f"；{et_clock_text(prefix[-1].time+step)} 起缺报价，后续状态待核"
        return rank, known, detail
    return best if len(prefix) == expected else None
