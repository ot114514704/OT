"""Causal M5 response after an already witnessed liquidity sweep."""
from datetime import datetime,timedelta
from statistics import mean

from .features import geometric_fvgs
from .session_path import STEP, confirmed_local_swings, displacement_bars, et_clock_text


RESPONSE_BARS = 48
CROSSING_LABELS = {
    'sweep': '收回离位',
    'break': '收外跟随',
    'pending': '待后续收线',
    'unresolved': '窗口内未分出',
    'missing_prior': '越界前波幅不足',
    'incomplete': '后续报价不全',
    'unverified_cross': '越界报价待核',
}


def crossing_response(side, edge, prior, crossing, follow, as_of):
    """Classify a witnessed outer-edge crossing on contiguous closed M5s.

    Apply forex-ai-source's v7b decision rules to this project's frozen level.
    The crossing candle and the 48 later candles form the response window.
    """
    extreme = crossing.high if side == 1 else crossing.low
    if crossing.time + STEP > as_of or not crossing.low <= edge <= crossing.high or side * (extreme - edge) <= 0:
        return dict(status='unverified_cross', known_at=None, prior_atr=None, wick_band=None)

    wick_band = (min(edge, extreme), max(edge, extreme)) if (
        side * (crossing.open - edge) <= 0 and side * (crossing.close - edge) < 0
    ) else None
    history = prior[-15:]
    complete_prior = len(history) == 15 and all(
        bar.time == crossing.time - (15 - i) * STEP for i, bar in enumerate(history)
    )
    atr = mean(
        max(b.high, a.close) - min(b.low, a.close)
        for a, b in zip(history, history[1:])
    ) if complete_prior else None
    if not atr:
        return dict(status='missing_prior', known_at=None, prior_atr=atr, wick_band=wick_band)

    previous_close = None
    expected = crossing.time
    deadline = expected + (RESPONSE_BARS + 1) * STEP
    for bar in (crossing, *follow[:RESPONSE_BARS]):
        if bar.time != expected or bar.time + STEP > as_of:
            break
        expected += STEP
        close = side * (bar.close - edge)
        if close <= -atr:
            return dict(status='sweep', known_at=expected.isoformat(), prior_atr=atr, wick_band=wick_band)
        if previous_close is not None and previous_close > 0 and close >= atr:
            return dict(status='break', known_at=expected.isoformat(), prior_atr=atr, wick_band=wick_band)
        previous_close = close
    if expected == deadline:
        status = 'unresolved'
    elif expected + STEP <= as_of:
        status = 'incomplete'
    else:
        status = 'pending'
    return dict(status=status, known_at=None, prior_atr=atr, wick_band=wick_band)


def crossing_caption(response):
    state = CROSSING_LABELS[response['status']]
    if response['known_at']:
        state += ' · ' + et_clock_text(datetime.fromisoformat(response['known_at']))
    return 'M5 扫荡／真破 · ' + state


def sequence(target, before, after, at):
    side=target['side']
    near=target['lo'] if side==1 else target['hi']
    far=target['hi'] if side==1 else target['lo']
    reference=confirmed_local_swings(before,at,STEP).get(-side)
    if reference and side*(reference[0]-near)>=0:
        reference=None
    reclaim=break_at=same_close=None
    for bar in after:
        known=bar.time+STEP
        if reclaim is None and side*(bar.close-near)<0:
            reclaim=known
            if reference and side*(bar.close-reference[0])<0:
                same_close=known
            continue
        if reclaim and not same_close and reference and side*(bar.close-reference[0])<0:
            break_at=known
            break
    final=after[-1].close
    if break_at:
        shape='reverse_held' if side*(final-reference[0])<0 else 'reverse_failed'
    elif same_close:
        shape='same_close_held' if side*(final-reference[0])<0 else 'same_close_failed'
    elif reclaim:
        shape='reclaim_only' if reference else 'reclaim_without_reference'
    else:
        shape='continued_without_reclaim' if side*(final-far)>0 else 'no_reclaim_flat'
    first_break=break_at or same_close
    closed_back=bool(first_break and any(b.time>=first_break and side*(b.close-reference[0])>=0 for b in after))
    return dict(shape=shape,reclaim=reclaim.isoformat() if reclaim else None,
                break_at=break_at.isoformat() if break_at else None,
                same_close=same_close.isoformat() if same_close else None,
                reference=[reference[0],reference[1].isoformat(),reference[2].isoformat()] if reference else None,
                final_close=final,closed_back_after_break=closed_back,
                minutes_to_reclaim=(reclaim-at).total_seconds()/60 if reclaim else None)


def reversal_evidence(target, prior, follow, phases, cutoff):
    """Use the earliest qualifying gap and test invalidation at confirmation."""
    reverse=-target['side']
    reclaim=datetime.fromisoformat(phases['reclaim']) if phases['reclaim'] else None
    break_time=datetime.fromisoformat(phases['break_at']) if phases['break_at'] else None
    if not reclaim or reclaim>cutoff:
        return {}
    impulses,_=displacement_bars(follow,prior)
    eligible={b.time:(b,ratio,body,edge) for b,side,ratio,body,edge in impulses
              if b.time>=reclaim and b.time+STEP<=cutoff and side==reverse}
    evidence={'reclaim':reclaim.isoformat()}
    if not eligible:
        return evidence
    evidence['first_impulse']=(min(eligible)+STEP).isoformat()
    direction='bullish' if reverse==1 else 'bearish'
    for gap in geometric_fvgs(prior[-2:]+follow,STEP,cutoff):
        middle=datetime.fromisoformat(gap['formation_bar_open'])-STEP
        if gap['direction']!=direction or middle not in eligible:
            continue
        b,ratio,body,edge=eligible[middle]
        evidence.update(fvg=gap,middle_close=(b.time+STEP).isoformat(),impulse_ratio=ratio,
                        body_fraction=body,impulse_break_price=edge)
        break
    if 'fvg' not in evidence or not break_time or break_time>cutoff:
        return evidence

    fvg=evidence['fvg']
    available=datetime.fromisoformat(fvg['available_at'])
    confirmed=max(break_time,available)
    through=[b for b in follow if b.time+STEP<=confirmed]
    sweep_extreme=through[0].low if reverse==1 else through[0].high
    far_edge=fvg['lower'] if reverse==1 else fvg['upper']
    structure=phases['reference'][0]
    def invalidation(rows):
        return dict(extreme=any(b.low<sweep_extreme if reverse==1 else b.high>sweep_extreme for b in rows[1:]),
                    fvg_far=any((b.low<=far_edge if reverse==1 else b.high>=far_edge)
                                for b in rows if b.time>=available),
                    structure=reverse*(rows[-1].close-structure)<=0)
    reasons=invalidation(through)
    evidence.update(structure_break=break_time.isoformat(),confirmed=confirmed.isoformat(),
                    active_at_confirmation=not any(reasons.values()),invalidation=reasons)
    return evidence


def review_sweep(side, price, previous, sweep, observed):
    """Return only conclusions that can be drawn from the contiguous closed prefix."""
    covered=[]
    for i,bar in enumerate([sweep,*observed]):
        if bar.time!=sweep.time+i*STEP:
            break
        covered.append(bar)
    target=dict(side=side,lo=price,hi=price)
    previous=previous[-24:]
    phases=sequence(target,previous,covered,sweep.time)
    evidence=reversal_evidence(target,previous,covered,phases,covered[-1].time+STEP)
    return phases,evidence


def follow_reversal(direction, structure, sweep, evidence, observed, as_of):
    """Find the first observed post-confirmation invalidation on a closed M5."""
    if not evidence.get('active_at_confirmation'):
        return None
    at=datetime.fromisoformat(evidence['confirmed'])
    end=min(as_of,at+timedelta(minutes=30))
    extreme=sweep.low if direction==1 else sweep.high
    gap=evidence['fvg']
    far=gap['lower'] if direction==1 else gap['upper']
    expected=at
    for b in observed:
        if b.time<at:
            continue
        if b.time+STEP>end:
            break
        if b.time!=expected:
            break
        expected=b.time+STEP
        failures=[]
        if direction*(b.close-structure)<=0:
            failures.append('structure')
        if (b.low<extreme if direction==1 else b.high>extreme):
            failures.append('extreme')
        if (b.low<=far if direction==1 else b.high>=far):
            failures.append('fvg_far' if b.low<=far<=b.high else 'fvg_bypassed')
        if failures:
            return dict(status='invalidated',at=expected.isoformat(),reasons=failures)
    if expected==at+timedelta(minutes=30):
        status='held'
    elif expected+STEP<=end:
        status='incomplete'
    elif expected==at:
        status='waiting'
    else:
        status='tracking'
    return dict(status=status,at=expected.isoformat(),reasons=[])
