"""Rank unswept gold levels from closed M5 evidence. Scores are study weights.

Sources: Wuwei time/bias 381–391s (adjacent equal extremes); resistance/liquidity
94–227s and foundations 238–305s; project weekly_stage_liquidity NY range basis.
"""
from collections import defaultdict
from datetime import datetime, time, timedelta, timezone
from statistics import median

from .range_liquidity import _Coverage
from .timebase import NY

M5=timedelta(minutes=5)
WEIGHT={'M30':7,'H1':11,'H4':17,'D1':23,'W1':29}


def liquidity_ranking(bars,at,dol=(),*,limit=10):
    floor=at-timedelta(days=63)
    rows=[b for b in bars if floor<=b.time and b.time+M5<=at]
    if not rows or rows[-1].time+M5!=at:return []
    stamps=[b.time for b in rows]
    price=rows[-1].close
    coverage=_Coverage(stamps[0],at,rows,M5)
    buckets=defaultdict(lambda:defaultdict(list))
    for i,b in enumerate(rows):
        local=b.time.astimezone(NY)
        for tf,minutes in [('M30',30),('H1',60),('H4',240)]:
            m=(local.hour*60+local.minute)//minutes*minutes
            start=local.replace(hour=m//60,minute=m%60,second=0,microsecond=0).astimezone(timezone.utc)
            buckets[tf][(start,start+timedelta(minutes=minutes))].append(i)
        if local.weekday()<5:
            start=datetime.combine(local.date(),time(),NY)
            end=start+timedelta(days=1) if local.weekday()!=4 else start.replace(hour=16,minute=55)
            buckets['D1'][start,end].append(i)
            week=start-timedelta(days=local.weekday())
            buckets['W1'][week,week+timedelta(days=4,hours=16,minutes=55)].append(i)
    # Suffix extremes retire swept levels in constant time, including price gaps.
    upper=[float('-inf')]*(len(rows)+1);lower=[float('inf')]*(len(rows)+1)
    for i in reversed(range(len(rows))):
        upper[i]=max(upper[i+1],rows[i].high);lower[i]=min(lower[i+1],rows[i].low)
    anchors=defaultdict(lambda:defaultdict(set))
    widths=[]
    local=at.astimezone(NY)
    current_week=local.date()-timedelta(days=local.weekday())
    def add(i,side,tf,tag):
        level=rows[i].high if side==1 else rows[i].low
        if side*(level-price)<=0 or (upper[i+1]>level if side==1 else lower[i+1]<level):return
        if coverage.gap(stamps[i],at):return
        anchors[side,level][i].add((tf,tag))
    for tf,groups in buckets.items():
        periods=[]
        for (a,z),indices in groups.items():
            running=tf=='W1' and a.date()==current_week and z>at
            end=min(z,at) if running else z
            if end>at or a<stamps[0] or coverage.gap(a,end):
                periods.append(None);continue
            hi=max(indices,key=lambda i:rows[i].high)
            lo=min(indices,key=lambda i:rows[i].low)
            periods.append((a,end,hi,lo))
            if tf=='H1':widths.append(rows[hi].high-rows[lo].low)
            if tf in ('D1','W1'):
                label=('纽约日高低 ERL' if tf=='D1' else '本周外沿 ERL' if a.date()==current_week else '历史周高低 ERL')+' '+a.strftime('%m-%d')
                add(hi,1,tf,label);add(lo,-1,tf,label)
        if tf in ('D1','W1'):continue
        for side,k in [(1,2),(-1,3)]:
            def extreme(p):
                return rows[p[k]].high if side==1 else -rows[p[k]].low
            i=1
            while i<len(periods)-1:
                p=periods[i]
                if p is None:i+=1;continue
                j=i
                while j+1<len(periods) and periods[j+1] and extreme(periods[j+1])==extreme(p):
                    j+=1
                left=periods[i-1];right=periods[j+1] if j+1<len(periods) else None
                if left and right and extreme(p)>max(extreme(left),extreme(right)) and not coverage.gap(left[0],right[1]):
                    add(p[k],side,tf,'摆动高' if side==1 else '摆动低')
                i=j+1
    hourly=[w for w in widths[-24:] if w>0]
    if not hourly:return []
    typical=median(hourly);tolerance=max(.01,.08*typical)
    ranked=[]
    for side in (1,-1):
        clusters=[]
        for level in sorted(p for s,p in anchors if s==side):
            if not clusters or level-clusters[-1][0]>tolerance:clusters.append([])
            clusters[-1].append(level)
        for levels in clusters:
            lo,hi=levels[0],levels[-1]
            origins=defaultdict(set)
            for level in levels:
                for i,tags in anchors[side,level].items():origins[i].update(tags)
            frames=sorted({tf for tags in origins.values() for tf,_ in tags},key=WEIGHT.get)
            edge=lo if side==1 else hi
            dist=abs(edge-price);count=len(origins)
            votes=[p for p in dol if p['side']==side and lo-.005<=(p['lo'] if side==1 else p['hi'])<=hi+.005]
            parts=dict(structure=WEIGHT[frames[-1]],anchors=min(25,7+6*(count-1)),
                       frames=min(12,4*(len(frames)-1)),reach=int(.5+27/(1+dist/(3*typical))),
                       dol=7 if votes else 0)
            sources=sorted({tf+' '+tag for tags in origins.values() for tf,tag in tags})
            ranked.append(dict(side=side,lo=lo,hi=hi,score=sum(parts.values()),distance=dist,
                source='/'.join(frames),sources=sources,origins=count,hourly_range=typical,
                anchor_times=[stamps[i].isoformat() for i in sorted(origins)],components=parts,
                dol_rank=min((p['rank'] for p in votes),default=None)))
    ranked.sort(key=lambda p:(-p['score'],p['distance'],p['lo'],p['hi']))
    selected=ranked[:limit]
    for i,p in enumerate(selected,1):p['rank']=i
    return selected


def chart_marks(ranked,at,price):
    typical=ranked[0]['hourly_range'] if ranked else 0
    yield 'pool_context',at,at,'流动性积累',price,typical
    for p in ranked:
        name='买方' if p['side']==1 else '卖方'
        zone=f'{p["lo"]:.2f}' if p['lo']==p['hi'] else f'{p["lo"]:.2f}–{p["hi"]:.2f}'
        parts=p['components']
        source='、'.join(p['sources'])
        evidence='、'.join(datetime.fromisoformat(t).astimezone(NY).strftime('%m-%d %H:%M') for t in p['anchor_times'])
        base=p['score']-parts['reach']
        route=(f'、路径 {parts["path"]}、结构方向 {parts["context"]}' if 'path' in parts else '')
        label=(f'{base}｜{name} {zone}  {p["source"]}｜'
               f'{source} · {p["origins"]} 个独立极点 · 美东 {evidence}｜'
               f'周期 {parts["structure"]}、极点 {parts["anchors"]}、周期重合 {parts["frames"]}、'
               f'DOL 共振 {parts["dol"]}'+(f'（#{p["dol_rank"]}）' if p['dol_rank'] else '')+route)
        yield ('pool_buy' if p['side']==1 else 'pool_sell'),at,at,label,p['lo'],p['hi']
