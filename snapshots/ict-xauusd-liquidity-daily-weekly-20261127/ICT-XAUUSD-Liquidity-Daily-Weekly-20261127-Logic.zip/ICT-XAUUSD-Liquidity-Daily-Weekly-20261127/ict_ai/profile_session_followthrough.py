"""Closed-price facts for the handoff between London and New York."""

from datetime import timedelta

from .profile_lifecycle import _complete, _day_bounds, _extension, _reclaim
from .range_liquidity import M5
from .timebase import session_windows


M15 = timedelta(minutes=15)


def _closed(rows, start, end, at, period=M15):
    return [b for b in rows if start<=b.time<end and b.time+period<=at]


def session_followthrough(m5, m15, day, as_of, covered):
    """Report evidence available then, including which window actually reclaimed."""
    start,end = _day_bounds(day)
    at = min(as_of,end)
    windows = session_windows(day)
    asia,london,ny,late = [windows[name] for name in ('asia','london','new_york','london_close')]
    a,l,n,after = [_closed(m15,*window,at) for window in (asia,london,ny,late)]
    if at<london[1] or not _complete(a,*asia,M15) or not _complete(l,*london,M15):
        return []
    bridge = _closed(m15,london[1],ny[0],at)
    bridge_complete = at>=ny[0] and _complete(bridge,london[1],ny[0],M15)
    later_m5 = _closed(m5,london[1],end,at,M5)
    midnight = next((b for b in m5 if b.time==start and b.time+M5<=at),None)
    results = []

    def status(direction, delivery, broken, edge, *, returned=True):
        if not covered:
            return 'insufficient_data'
        if broken:
            return 'invalidated'
        if as_of>=end:
            held = later_m5 and direction*(later_m5[-1].close-edge)>0
            return 'closed_price_path' if delivery and held else 'closed_partial'
        return 'delivery_observed' if delivery else 'waiting_for_delivery' if returned else 'waiting_for_reclaim'

    for direction, swept, opposite in ((1,'low','high'),(-1,'high','low')):
        extreme = min if direction==1 else max
        opposite_extreme = max if direction==1 else min
        asia_level = extreme(getattr(b,swept) for b in a)
        london_edge = opposite_extreme(getattr(b,opposite) for b in l)
        london_extreme = extreme(getattr(b,swept) for b in l)
        london_return = _reclaim(l,asia_level,-direction,M15)
        if not london_return and direction*(asia_level-london_extreme)>0 and bridge_complete:
            returned = next((b for b in bridge+n if direction*(b.close-asia_level)>0),None)
            origin = ('pre_ny' if returned in bridge else 'new_york') if returned is not None else None
            confirm_edge = opposite_extreme((asia_level,london_edge))
            delivery = _extension(n,confirm_edge,direction,M15,returned.time) if returned else None
            broken = next((b for b in later_m5 if direction*(getattr(b,swept)-london_extreme)<0),None)
            results.append(dict(kind='london_sweep_later_reclaim',direction=direction,
                                status=status(direction,delivery,broken,confirm_edge,returned=returned is not None), reclaim_origin=origin,
                                reclaim_known_at=(returned.time+M15).isoformat() if returned else None,
                                delivery_known_at=(delivery.time+M15).isoformat() if delivery else None,
                                invalidated_at=(broken.time+M5).isoformat() if broken else None,
                                reference_edge=asia_level, delivery_edge=confirm_edge, protected_extreme=london_extreme,
                                source_slides=[16],source_seconds=[700,790]))

        ny_return = _reclaim(n,london_extreme,-direction,M15)
        early = midnight and direction*(l[-1].close-midnight.open)>0 and not london_return
        if ny_return is None or early:
            continue
        earliest_delivery = _extension(n+after,london_edge,direction,M15,ny_return.time+M15)
        if earliest_delivery is None or earliest_delivery.time+M15<=ny[1]:
            continue
        known_reclaim = ny_return.time+M15
        ny_path = [b for b in later_m5 if ny[0]<=b.time and b.time+M5<=known_reclaim]
        if not ny_path:
            continue
        ny_extreme = extreme(getattr(b,swept) for b in ny_path)
        broken = next((b for b in later_m5 if b.time>=known_reclaim and direction*(getattr(b,swept)-ny_extreme)<0),None)
        results.append(dict(kind='classic_11_london_close_followthrough',direction=direction,
                            status=status(direction,earliest_delivery,broken,london_edge), reclaim_origin='new_york',
                            reclaim_known_at=known_reclaim.isoformat(),delivery_known_at=(earliest_delivery.time+M15).isoformat(),
                            invalidated_at=(broken.time+M5).isoformat() if broken else None,
                            reference_edge=london_extreme, delivery_edge=london_edge, protected_extreme=ny_extreme,
                            source_slides=[17],source_seconds=[780,930]))
    return results
