"""Price evidence for the MT5 session review. All inputs are closed M5 bars."""
from datetime import datetime, time, timedelta
from statistics import median
from zoneinfo import ZoneInfo

from .structure import StructureParameters
from .features import geometric_fvgs

STEP = timedelta(minutes=5)
from .timebase import NY
VENUES = (('tokyo', 'TK', 'Asia/Tokyo', 9, 18),
          ('london', 'EU', 'Europe/London', 8, 17),
          ('newyork', 'NY', 'America/New_York', 8, 17))
PARAMS = StructureParameters()


def hours(day, venue):
    _, _, zone, start, end = venue
    return tuple(datetime.combine(day, time(hour), ZoneInfo(zone)) for hour in (start, end))


def et_clock_text(stamp):
    return stamp.astimezone(NY).strftime('%H:%M')


def covered(rows, start, end):
    return len(rows) == (end-start)//STEP and all(b.time == start+i*STEP for i,b in enumerate(rows))


def sweep_text(rows, high, low):
    sides = []
    for sign, price, name in ((1, high, '前高'), (-1, low, '前低')):
        breach = next((i for i,b in enumerate(rows) if (b.high>price if sign==1 else b.low<price)), None)
        if breach is None:
            sides.append(f'{name} {price:.2f} 未越过')
            continue
        back = next((b for b in rows[breach:] if sign*(b.close-price)<0), None)
        tail = f'{et_clock_text(back.time+STEP)} 收回' if back else '尚未收回'
        sides.append(f'{et_clock_text(rows[breach].time)} 越{name} {price:.2f}，{tail}')
    return '；'.join(sides)


def price_purposes(rows,warm):
    """Compare only with liquidity and outstanding M5 gaps known before this segment."""
    if not rows:return '流动性与不平衡待报价'
    start=rows[0].time
    if not covered(warm,start-24*STEP,start):
        return '获取流动性 / 平衡不平衡 · 前两小时 M5 不连续，冻结参照待核'
    high=max(b.high for b in warm[-12:]);low=min(b.low for b in warm[-12:])
    liquidity='获取流动性 · 参照前一小时，'+sweep_text(rows,high,low)
    if not covered(rows,start,rows[-1].time+STEP):
        return '获取流动性 / 平衡不平衡 · 段内报价中断，完整路径待核'
    zones=[]
    for g in geometric_fvgs(warm,STEP,start):
        known=datetime.fromisoformat(g['available_at'])
        lo,hi=g['lower'],g['upper']
        past=[b for b in warm if b.time>=known]
        bull=g['direction']=='bullish'
        if bull:hi=min([hi]+[b.low for b in past])
        else:lo=max([lo]+[b.high for b in past])
        if lo>=hi:continue
        seen=[b for b in rows if b.low<=hi and b.high>=lo]
        edge=lo if bull else hi
        far=any(b.low<=edge<=b.high for b in seen)
        zones.append((not bool(seen),min(abs(warm[-1].close-lo),abs(warm[-1].close-hi)),
                      f'{lo:.2f}–{hi:.2f} · '+('已触远沿' if far else '部分回补' if seen else '本段未回触')))
    return liquidity+'｜平衡不平衡 · '+('窗前 M5 FVG '+min(zones)[2] if zones else '前两小时无可核实的剩余 M5 缺口')


def previous_session(rows, start, end, ref, a, z, tag):
    if end <= z:
        return f'与 {tag} 重叠，前盘仍在交易，最终高低待定'
    if not covered(ref,a,z):
        return f'{tag} 报价不完整，前盘高低及方向待核'
    known = max(start,z)
    path = [b for b in rows if b.time>=known]
    if not path or not covered(path,known,end):
        return f'{tag} 已收，后续连续报价不足'
    high, low = max(b.high for b in ref), min(b.low for b in ref)
    close, opening = path[-1].close, ref[0].open
    prior = ref[-1].close-opening
    move = close-path[0].open
    if not prior or not move:
        label = '净方向未定'
    elif prior*move>0:
        beyond = close>high if move>0 else close<low
        label = '顺向延续并收出前盘区间' if beyond else '同向推进，尚未收出前盘区间'
    else:
        through = close<low if move<0 else close>high
        label = '反转候选，反向收出前盘区间' if through else '反向回撤，反转待确认'
    return (f'对 {tag} · {et_clock_text(known)} 起比较，前盘净移 {prior:+.2f}，本段 {move:+.2f} · {label}｜'
            +sweep_text(path,high,low))


def displacement_bars(body, warm):
    """Return every strong M5 impulse and the count with a complete baseline."""
    bars = list(warm)+list(body)
    found = []
    evaluated = 0
    count = PARAMS.prior_range_bars
    for i in range(len(warm),len(bars)):
        prior = bars[max(0,i-count-1):i]
        b = bars[i]
        if len(prior)!=count+1 or not covered(prior,b.time-(count+1)*STEP,b.time):
            continue
        typical = median(max(q.high-q.low,abs(q.high-p.close),abs(q.low-p.close))
                         for p,q in zip(prior,prior[1:]))
        width = b.high-b.low
        if typical<=0:continue
        evaluated += 1
        side = 1 if b.close>b.open else -1
        edge = prior[-1].high if side==1 else prior[-1].low
        if (width>=PARAMS.displacement_range_ratio*typical and abs(b.close-b.open)>=PARAMS.minimum_body_fraction*width
                and side*(b.close-edge)>0):
            found.append((b,side,width/typical,abs(b.close-b.open)/width,edge))
    return found,evaluated


def displacement(body, warm):
    """Strong M5 impulse must close beyond the previous bar in its direction."""
    found,evaluated=displacement_bars(body,warm)
    count=PARAMS.prior_range_bars
    if not found:
        return ('未见符合判据的强位移' if evaluated==len(body) else '基准报价不足，强位移待核'), None
    b,side,ratio,body_ratio,edge = max(found,key=lambda x:x[2])
    direction = '上' if side==1 else '下'
    both = '双向均有，最强一棒' if len({x[1] for x in found})>1 else f'向{direction}强位移'
    return (f'{both} · {et_clock_text(b.time+STEP)} 收 {b.close:.2f}，向{direction}收破前棒 {edge:.2f}；'
            f'振幅为前 {count} 棒典型波幅 {ratio:.1f} 倍，实体占 {body_ratio:.0%}'), side


def after_window(body, end, later, now, side):
    if now<=end:return '窗后走势待观察'
    cutoff = min(now,end+12*STEP)
    rows = [b for b in later if end<=b.time and b.time+STEP<=cutoff]
    if not rows or not covered(rows,end,cutoff):
        return '窗后连续 M5 不足，跟随待核'
    base, last = body[-1].close, rows[-1].close
    delta = last-base
    direction = side or (1 if base>body[0].open else -1 if base<body[0].open else 0)
    state = '末价延续' if direction*delta>0 else '末价反向回撤' if direction*delta<0 else '净方向待定'
    return (f'窗后 {len(rows)*5} 分钟 · 相对窗收 {base:.2f}，上探 {max(0,max(b.high for b in rows)-base):.2f} / '
            f'下探 {max(0,base-min(b.low for b in rows)):.2f}，末收 {last:.2f}（{delta:+.2f}）'
            f' · 相对{"最强位移棒" if side else "窗口净方向"}{state}')


def confirmed_local_swings(warm, at, period=STEP):
    """Freeze the last intact confirmed swing on each side at the cutoff."""
    prior = list(warm)
    for i in range(len(prior)-1,-1,-1):
        if prior[i].time+period!=(prior[i+1].time if i+1<len(prior) else at):
            prior=prior[i+1:]
            break
    swings = {}
    for field,side in (('high',1),('low',-1)):
        for i in range(len(prior)-3,1,-1):
            p = side*getattr(prior[i],field)
            if (all(p>side*getattr(prior[k],field) for k in (i-2,i-1,i+1,i+2))
                    and all(side*b.close<=p for b in prior[i+3:])):
                swings[side]=(side*p,prior[i].time,prior[i+2].time+period)
                break
    return swings


def local_structure(body, warm, period=STEP, frame='M5'):
    """Describe how the leg interacts with the confirmed swings at its start."""
    if not body:return '无已收报价'
    notes = []
    for side,(anchor,_,_) in confirmed_local_swings(warm,body[0].time,period).items():
        name='高' if side==1 else '低'
        beyond = [b for b in body if side*(b.close-anchor)>0]
        state = '收破后保持' if beyond and side*(body[-1].close-anchor)>0 else '收破后撤回' if beyond else '未收破'
        when = et_clock_text(beyond[0].time+period)+' ' if beyond else ''
        notes.append(f'摆动{name} {anchor:.2f} {when}{state}')
    return frame+' 结构 · '+('；'.join(notes) if notes else '窗前连续报价中缺少已确认摆动')


def erl_review(level, before, after, hourly, now):
    at=datetime.fromisoformat(level['sweep_known_at'])
    price=level['price']
    reclaim=level.get('reclaim_known_at')
    lines=[]
    if reclaim and datetime.fromisoformat(reclaim)<=now:
        lines.append('首次收回 · 美东 '+datetime.fromisoformat(reclaim).astimezone(NY).strftime('%m-%d %H:%M'))
    else:lines.append('尚无已确认收回')
    if not before or before[-1].time+STEP!=at:return '｜'.join(lines+['越界棒报价待核'])
    base=before[-1].close
    lines.append(f'越界棒收 {base:.2f}，较原位 {price:.2f} 偏移 {base-price:+.2f}')
    end=min(now,at+12*STEP)
    observed=[b for b in after if at<=b.time and b.time+STEP<=end]
    side=1 if level['side']=='buy_side_proxy' else -1
    sweep=before[-1]
    if sweep.low<=price<=sweep.high and (sweep.high>price if side==1 else sweep.low<price):
        lines.extend(sweep_response_lines(side,price,before[:-1],sweep,observed,after,now))
    for n in (1,3,12):
        end=at+n*STEP
        if end>now:break
        bars=[b for b in after if at<=b.time and b.time+STEP<=end]
        if not covered(bars,at,end):
            lines.append(f'+{n*5}分钟报价不全');break
        lines.append(f'+{n*5}分钟 · 收 {bars[-1].close:.2f}（{bars[-1].close-base:+.2f}），'
                     f'自确认价上探 {max(0,max(b.high for b in bars)-base):.2f} / 下探 {max(0,base-min(b.low for b in bars)):.2f}')
    if observed and covered(observed,at,end):
        # Include the sweep candle in the response, never in the pre-event swing anchors.
        lines.append(local_structure([before[-1],*observed],before[:-1]))
        lines.append(displacement(observed,before)[0])
        lines.append(price_purposes([before[-1],*observed],before[:-1][-24:]))
    hour=timedelta(hours=1)
    start=at-STEP
    pre=[b for b in hourly if b.time+hour<=start][-48:]
    post=[b for b in hourly if b.time>=start and b.time+hour<=min(now,at+4*hour)]
    if pre and post and pre[-1].time+hour<=post[0].time<=pre[-1].time+2*hour and all(
            a.time+hour==b.time for a,b in zip(post,post[1:])):
        # The mixed H1 containing the sweep may close afterwards. Its close confirms
        # structure only after the event; its high/low are never attributed to it.
        first=pre[-1].time+hour
        response=[b for b in hourly if first<=b.time<=post[-1].time]
        if len(response)==(post[-1].time-first)//hour+1:
            lines.append(local_structure(response,pre,hour,'后续最多4小时 H1'))
    if not any(' H1 结构' in line for line in lines):lines.append('H1 结构待完整收线核对')
    return '｜'.join(lines)


def sweep_response_lines(side, price, prior, sweep, observed, followup, now):
    from .sweep_response import follow_reversal,review_sweep

    phases,evidence=review_sweep(side,price,prior,sweep,observed)
    closing=datetime.fromisoformat
    output=[]
    if phases['same_close']:
        output.append('收回与反向收破在同根确认 · '+et_clock_text(closing(phases['same_close'])))
    elif phases['break_at']:
        state='其后曾收回破位内侧' if phases['closed_back_after_break'] else '已收报价仍守破位'
        output.append(f'反向收破 {phases["reference"][0]:.2f} · {et_clock_text(closing(phases["break_at"]))} · {state}')
    elif phases['reclaim']:
        output.append('已收回 · 尚未核实反向收破' if phases['reference'] else '已收回 · 缺可核实的反向摆动')
    if evidence.get('first_impulse'):
        output.append('收回后反向强位移 · '+et_clock_text(closing(evidence['first_impulse'])))
    gap=evidence.get('fvg')
    if gap:
        output.append(f'位移 FVG {gap["lower"]:.2f}–{gap["upper"]:.2f} · {et_clock_text(closing(gap["available_at"]))}')
    if evidence.get('confirmed'):
        at=et_clock_text(closing(evidence['confirmed']))
        reasons={'extreme':'扫荡极值已再破','structure':'收回破位内侧','fvg_far':'FVG 远沿已到',
                 'fvg_bypassed':'报价跳过 FVG 远沿'}
        detail='确认当时证据仍有效' if evidence['active_at_confirmation'] else '、'.join(
            label for key,label in reasons.items() if evidence['invalidation'].get(key))
        output.append(f'收破与 FVG 证据到齐 · {at} · {detail}')
        follow=follow_reversal(-side,phases['reference'][0],sweep,evidence,followup,now)
        if follow:
            at=et_clock_text(closing(follow['at']))
            if follow['status']=='invalidated':
                seen='、'.join(reasons[k] for k in follow['reasons'])
                tail=' · 同根核实' if len(follow['reasons'])>1 else ''
                output.append(f'确认后首次失效 · {at} · {seen}{tail}')
            else:
                status={'held':'确认后 30 分钟未触发失效',
                        'tracking':'已收报价仍有效',
                        'waiting':'待首根后续 M5 收盘',
                        'incomplete':'后续报价不全'}[follow['status']]
                output.append(f'确认后 · {status} · 截至 {at}')
    return output
