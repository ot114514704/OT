"""Weekly hypotheses from frozen NY sessions and subsequent closed M5s."""

from datetime import timedelta

from .profile_lifecycle import _day_bounds, _extension
from .timebase import NY
from .weekly_path import consolidation_evidence


EARLY_EXTREMES = frozenset({
    'weekly_tuesday_extreme', 'weekly_wednesday_extreme', 'weekly_wednesday_double_sweep',
})


def frozen_extreme_candidates(realized, days, at, covered):
    """Replace early intraday sweeps with day-close evidence once available.

    Keep alternatives when both sides were swept. The first intraday reclaim
    cannot define the day's extreme, and one daily close cannot order OHLC.
    """
    reports = {r['date']: r for r in realized['daily']}
    ordered = [reports.get(d.isoformat()) for d in days]
    cards = []
    for event_day in (1, 2):
        _, known_at = _day_bounds(days[event_day])
        if at < known_at:
            break
        if any(r is None or not r['coverage_complete'] for r in ordered[:event_day+1]):
            break
        prior, event = ordered[:event_day], ordered[event_day]
        later = [r for r in ordered[event_day+1:] if r]
        upper, lower = max(r['high'] for r in prior), min(r['low'] for r in prior)
        close = event['close']
        for side, edge, field in ((1, lower, 'low'), (-1, upper, 'high')):
            extreme = event[field]
            if side * (extreme-edge) >= 0 or side * (close-edge) <= 0:
                continue
            ident = 'weekly_tuesday_extreme'
            if event_day == 2:
                monday, tuesday = prior
                body = side * (tuesday['close']-tuesday['open'])
                advance = side * (tuesday['close']-monday['close'])
                if body > 0 and advance > 0:
                    ident = 'weekly_wednesday_double_sweep'
                elif body < 0 and advance < 0:
                    ident = 'weekly_wednesday_extreme'
                else:
                    ident = 'weekly_wednesday_unresolved'
            holds = 0
            failed = next((r['date'] for r in later if side * (r[field]-extreme) < 0), None)
            failure = 'extreme_broken' if failed else None
            # Thursday's close is the last intermediate continuation for these
            # paths. Friday's settlement is handled by the week-end reviewer.
            follow = [r for r in later if r['ended'] and r is not ordered[4]]
            for previous, day in zip([event, *follow], follow):
                if side * (day['close']-previous['close']) <= 0:
                    if failed is None or day['date'] <= failed:
                        failed, failure = day['date'], 'close_did_not_extend'
                    break
                holds += 1
            status = 'insufficient_data' if not covered else 'invalidated' if failed else 'active'
            cards.append(dict(id=ident, direction=side, status=status, observed_sequence=True,
                              known_at=known_at.isoformat(), reference=edge, extreme=extreme,
                              following_closes=holds, failure=failure, failure_day=failed))
    return cards


def friday_expansion_watch(realized, quarters, days, at, covered):
    """Monitor a frozen four-day range for Friday closed-M15 delivery."""
    start, end = _day_bounds(days[-1])
    if not covered or not start <= at < end:
        return None
    reports = [d for d in realized['daily'] if d['ended']]
    if [d['date'] for d in reports] != [d.isoformat() for d in days[:4]] or not all(d['coverage_complete'] for d in reports):
        return None
    consolidation = consolidation_evidence(reports)
    if not consolidation['matched']:
        return None
    period = timedelta(minutes=15)
    bars = [b for b in quarters if start <= b.time and b.time+period <= at]
    upper, lower = consolidation['high'], consolidation['low']
    available = [(side, _extension(bars, edge, side, period)) for side, edge in ((1, upper), (-1, lower))]
    breaches = [dict(direction=side, known_at=(bar.time+period).astimezone(NY).isoformat())
                for side, bar in available if bar]
    direction = None
    status = 'awaiting_friday_expansion'
    if len(breaches) == 2:
        status = 'two_sided_breakout'
    elif breaches:
        side = breaches[0]['direction']
        if side * (bars[-1].close-(upper if side==1 else lower)) > 0:
            status, direction = 'active', side
        else:
            status = 'breakout_back_inside'
    return dict(id='weekly_consolidation_expansion', variant='friday_expansion_after_four_day_range',
                direction=direction, status=status, observed_sequence=bool(breaches),
                range_high=upper, range_low=lower, range_known_at=start.isoformat(), breaches=breaches,
                probability=None, execution_allowed=False)
