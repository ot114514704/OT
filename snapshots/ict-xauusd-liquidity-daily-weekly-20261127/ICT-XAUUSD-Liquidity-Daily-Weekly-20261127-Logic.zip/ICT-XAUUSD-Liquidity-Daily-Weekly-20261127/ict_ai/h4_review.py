"""Review price delivery after a New York H4 segment closes."""
from bisect import bisect_left
from datetime import datetime, time, timedelta, timezone

from .dol_outlook import peer_evidence
from .features import geometric_fvgs
from .session_path import (
    STEP, VENUES, confirmed_local_swings, covered, displacement, et_clock_text,
    hours, local_structure, price_purposes, sweep_text,
)
from .silver_bullet import silver_bullet_windows
from .timebase import NY

HOUR = timedelta(hours=1)
DAY = timedelta(days=1)


def expected_gold_bar(at):
    local = at.astimezone(NY)
    if local.weekday() == 5:
        return False
    if local.weekday() == 6:
        return local.hour >= 18
    if local.weekday() == 4:
        return local.hour < 17 and (local.hour, local.minute) != (16, 55)
    return local.hour != 17


def h4_response(body, warm, after, close, at, ranges):
    base = body[-1].close
    trend = base - body[0].open
    high, low = max(b.high for b in body), min(b.low for b in body)
    notes = [f'H4 收 {base:.2f} · 实体 {trend:+.2f} · 区间 {low:.2f}–{high:.2f}']
    if not after:
        reason = '休市或维护，观察下一次开市' if not expected_gold_bar(close) else '等待下一段首根 M5 收盘'
        return notes + [reason]
    new_open = after[0].open
    last = after[-1].close
    delta = last - base
    state = ('同向延续' if trend*delta > 0 else '逆向回撤' if trend*delta < 0 else '净方向待定')
    notes.append(f'下一段开 {new_open:.2f} · 较前收 {new_open-base:+.2f} · 截至 {et_clock_text(at)} 观察 {len(after)*5} 分钟')
    notes.append(f'上探 {max(0,max(b.high for b in after)-base):.2f} / 下探 {max(0,base-min(b.low for b in after)):.2f} · 末收 {last:.2f}（{delta:+.2f}）· {state}')
    milestones = '、'.join(f'+{n*5} 分钟 {after[n-1].close-base:+.2f}' for n in (1,3,6,12) if n<=len(after))
    notes.append(milestones)
    first_touch = next((b for b in after if b.low<=base<=b.high), None)
    if first_touch:
        notes.append(f'{et_clock_text(first_touch.time+STEP)} 首次 M5 覆盖前收价。扫荡另以结构高低点核对。')
    first_leg = after[:3]
    notes.append(f'初段相对新开盘 · 上探 {max(b.high for b in first_leg)-new_open:.2f} / '
                 f'下探 {new_open-min(b.low for b in first_leg):.2f} · 末收 {first_leg[-1].close-new_open:+.2f}')
    for label,high,low in ranges:
        notes.append(f'{label} · '+sweep_text(after,high,low))
    impulse, side = displacement(after,warm)
    notes.extend((impulse,local_structure(after,warm),price_purposes(after,warm)))
    post_gaps = [g for g in geometric_fvgs(warm[-2:]+after,STEP,at)
                 if datetime.fromisoformat(g['available_at'])>close]
    if post_gaps:
        gap = post_gaps[0]
        direction = '看涨' if gap['direction']=='bullish' else '看跌'
        notes.append(f'窗后首个 {direction} M5 FVG {gap["lower"]:.2f}–{gap["upper"]:.2f}'
                     f' · {et_clock_text(datetime.fromisoformat(gap["available_at"]))} 收线形成')
    swings = confirmed_local_swings(warm,close)
    anchor = swings.get(side)
    held = anchor and len(after)>=2 and all(side*(b.close-anchor[0])>0 for b in after[-2:])
    swept_reclaimed = False
    for sign,edge in ((1,high),(-1,low)):
        breach = next((i for i,b in enumerate(after) if sign*((b.high if sign==1 else b.low)-edge)>0),None)
        if breach is not None and any(sign*(b.close-edge)<0 for b in after[breach:]):
            swept_reclaimed = True
    if held and side*delta>0:
        conclusion = f'有向{"上" if side==1 else "下"}推动迹象 · 强位移、连续收在原摆动外、净位移同向'
    elif side:
        conclusion = '有强位移，持续收破与跟随尚未同时成立'
    else:
        conclusion = '已收报价尚未出现符合判据的推动'
    if swept_reclaimed:
        conclusion += ' · 观察到 H4 边界越界后收回'
    notes.append(conclusion+'。参与者身份无法由 K 线核实。')
    return notes


def h4_reviews(bars, start, now, peers, news, erl_events, context):
    bars = [b for b in bars if b.time+STEP<=now]
    if not bars:
        return
    stamps = [b.time for b in bars]
    def span(a,z):
        return bars[bisect_left(stamps,a):bisect_left(stamps,z)]

    cutoff = bars[-1].time+STEP
    segments = {}
    for b in bars:
        local = b.time.astimezone(NY)
        point = local.replace(hour=4*(local.hour//4),minute=0,second=0,microsecond=0)
        segments.setdefault(point,[]).append(b)
    for point,body in segments.items():
        opened = point.astimezone(timezone.utc)
        if opened<start:
            continue
        nominal = (point+4*HOUR).astimezone(timezone.utc)
        weekly_close = point.weekday()==4 and point.hour==16
        close = (point+55*timedelta(minutes=1)).astimezone(timezone.utc) if weekly_close else nominal
        if close>cutoff:
            continue
        available = [b.time for b in body if b.time<close]
        expected = [opened+i*STEP for i in range((close-opened)//STEP) if expected_gold_bar(opened+i*STEP)]
        if not available or available!=expected:
            continue
        body = body[:len(available)]
        after_end = min(cutoff,close+HOUR)
        after = span(close,after_end)
        if not covered(after,close,after_end):
            # Report only the observed contiguous path from the close.
            valid = next((i for i,b in enumerate(after) if b.time!=close+i*STEP),len(after))
            after = after[:valid]
        observed = after[-1].time+STEP if after else close
        day = point.date()
        day_start = datetime.combine(day,time(),NY).astimezone(timezone.utc)
        week_start = datetime.combine(day-timedelta(days=day.weekday()),time(),NY).astimezone(timezone.utc)
        ranges = [('该 H4 高低',max(b.high for b in body),min(b.low for b in body))]
        for title,a in (('早先纽约日内高低',day_start),('早先周内高低',week_start)):
            basis = span(a,opened)
            if basis:
                item = (title,max(b.high for b in basis),min(b.low for b in basis))
                if not any(r[1:]==item[1:] for r in ranges):
                    ranges.append(item)
        note = h4_response(body,span(close-2*HOUR,close),after,close,observed,ranges)
        if observed<after_end and expected_gold_bar(observed):
            note.append('报价中断，变化以已连续的收线为准')
        days = {day, observed.astimezone(NY).date(), day+DAY}
        sessions = [v[1] for v in VENUES if any(a<observed and close<z for a,z in (hours(d,v) for d in days))]
        silver = [w['label'] for d in sorted(days) if d.weekday()<5 for w in silver_bullet_windows(d)
                  if w['start_ms']<observed.timestamp()*1000 and close.timestamp()*1000<w['end_ms']]
        if sessions or silver:
            note.append('窗后重叠时段 · '+' / '.join(sessions+silver))
        smt,_ = peer_evidence(peers,close,observed)
        if smt:
            note.append('同期 SMT · '+'、'.join(dict.fromkeys(smt)))
        swept = [label for stamp,label in erl_events if close<stamp<=observed]
        if swept:
            note.append('同期已核实 · '+'、'.join(dict.fromkeys(swept)))
        news_in = [f'{et_clock_text(stamp)} {title}' for stamp,title in news if close<=stamp<observed]
        if news_in:
            note.append('同期日历 · '+'、'.join(news_in)+' · 对照上面的实际位移和扫荡')
        note.extend(context(day,close,observed))
        yield 'h4_review',close,observed,'｜'.join(note),body[-1].close,body[0].open
