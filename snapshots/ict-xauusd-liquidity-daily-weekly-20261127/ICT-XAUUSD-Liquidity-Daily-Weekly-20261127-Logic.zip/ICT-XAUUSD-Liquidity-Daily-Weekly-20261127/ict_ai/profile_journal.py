"""Append source-bound forecast/review observations; never submit orders."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil


_RULE_FILES = (
    'research/ict_daily_profiles/rules.json',
    'research/ict_weekly_profiles/rules.json',
    'research/ict_weekly_profiles/smc_free_guide/integration.json',
    'research/ict_time_videos/profile-visual-review.json',
    'research/ict_time_videos/time2_daily/manifest.json',
    'research/ict_time_videos/time3_weekly/manifest.json',
    'research/ict_price_videos/bias_dol/integration.json',
)
_CODE_FILES = (
    'ict_ai/profile_lifecycle.py', 'ict_ai/weekly_path.py', 'ict_ai/profile_sources.py',
    'ict_ai/timebase.py', 'ict_ai/range_liquidity.py', 'ict_ai/liquidity.py',
    'ict_ai/regular_liquidity.py', 'ict_ai/sweep_state.py', 'ict_ai/amd.py',
    'ict_ai/features.py', 'brooks_ai/types.py', 'scripts/prepare_ict_week.py',
    'ict_ai/profile_journal.py',
    'ict_ai/context_summary.py', 'ict_ai/daily_context.py', 'ict_ai/delivery.py',
)
_ROOT=Path(__file__).resolve().parents[1]
# Capture versions when this process loads, rather than claiming later-edited
# disk files produced computations already running in memory.
RUNTIME_CODE_SHA256={name:hashlib.sha256((_ROOT/name).read_bytes()).hexdigest() for name in _CODE_FILES}


def _semantic(value):
    if isinstance(value,dict):
        return {k:_semantic(v) for k,v in value.items() if k!='as_of'}
    if isinstance(value,list):
        return [_semantic(v) for v in value]
    return value


def _compact_history(records, visible_keys):
    """Keep real first/latest observations, never reconstructed forecasts."""
    grouped={}
    for index,record in enumerate(records):
        key=(record['scope'],record['date'])
        if key not in visible_keys:
            continue
        group=grouped.setdefault(key,{'live':[],'closed':[]})
        origin=record.get('origin')
        if origin=='recorded_live_hypothesis':
            group['live'].append(index)
        elif origin=='closed_review_generated_after_day_or_week_end':
            group['closed'].append(index)
    selected=set()
    for group in grouped.values():
        if group['live']:
            selected.add(group['live'][0])
            selected.update(group['live'][-2:])
        selected.update(group['closed'][-1:])
    result=[]
    for index in sorted(selected):
        record=records[index]
        lifecycle=record['lifecycle']
        result.append({
            'scope':record['scope'],'date':record['date'],'mode':record['mode'],
            'as_of':lifecycle.get('as_of'),'recorded_at_utc':record['recorded_at_utc'],
            'label':str(lifecycle.get('profile_label',''))[:240],'origin':record['origin'],
        })
    return result


def _definition_files(scenario):
    """Read exact version bytes once so archived content and hashes agree."""
    root=Path(__file__).resolve().parents[1]
    names={*_CODE_FILES,*_RULE_FILES}
    names.update(p.relative_to(root).as_posix() for p in (root/'research/ict_time_videos').glob('*/integration.json'))
    for item in scenario['days']+scenario['weeks']:
        names.update(item.get('profile_lifecycle',{}).get('source_rule_files',[]))
    result=[]
    for name in sorted(names):
        source=(root/name).resolve()
        if not source.is_relative_to(root):
            raise ValueError('Profile definition source must stay inside the project')
        content=source.read_bytes()
        result.append((source.relative_to(root).as_posix(),content,hashlib.sha256(content).hexdigest()))
    return result


def record_profiles(payload, workspace, runtime_code_shas=None):
    """Archive the exact source files before recording new hypothesis content.

    Repeated heartbeats with unchanged content do not create new observations.
    All records are append-only; earlier forecasts and closed reviews coexist.
    """
    workspace=Path(workspace); workspace.mkdir(parents=True,exist_ok=True)
    journal=workspace/'profile-observations.jsonl'
    previous={}; observations=[]
    if journal.exists():
        for line in journal.read_text(encoding='utf-8').splitlines():
            record=json.loads(line); previous[record['key']]=record['semantic_sha256']
            observations.append(record)
    scenario=next((s for s in payload['scenarios'] if s['id']=='broker-plus3'),None)
    if scenario is None:
        return {'observations_added':0,'history':[],
                'reason':'No currently measured clock scenario'}
    definitions=_definition_files(scenario)
    definition_shas={name:sha for name,_,sha in definitions}
    if runtime_code_shas is not None:
        if set(runtime_code_shas)!=set(_CODE_FILES) or any(definition_shas.get(name)!=sha for name,sha in runtime_code_shas.items()):
            raise ValueError('Profile code changed after process load; restart the chart before publishing new analysis')
    code_sha=definition_shas['ict_ai/profile_lifecycle.py']
    definition_sha=hashlib.sha256(json.dumps(definition_shas,sort_keys=True).encode()).hexdigest()
    proposed=[]; visible_keys=set()
    for scope,records in [('day',scenario['days']),('week',scenario['weeks'])]:
        for item in records:
            lifecycle=item.get('profile_lifecycle')
            if not lifecycle:
                continue
            date=item.get('date') or item['days'][0]
            visible_keys.add((scope,date))
            key='|'.join((scope,date,lifecycle['mode'],scenario['id'],definition_sha))
            canonical=json.dumps(_semantic(lifecycle),ensure_ascii=False,sort_keys=True,separators=(',',':'))
            signature=hashlib.sha256(canonical.encode()).hexdigest()
            if previous.get(key)!=signature:
                proposed.append({'key':key,'scope':scope,'date':date,'mode':lifecycle['mode'],
                                 'semantic_sha256':signature,'lifecycle':lifecycle})
    if not proposed:
        return {'observations_added':0,'journal':str(journal),
                'history':_compact_history(observations,visible_keys)}
    # The live worker is the sole writer of its current snapshot directory.
    # A captured immutable copy must match the published payload hashes.
    stamp=datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    archive=workspace/'profile-snapshots'/stamp
    sources=[]
    for name,source,expected in [('XAU',payload['source_manifest'],payload['source_sha256']),
                                 ('XAG',payload['smt_pair']['source_manifest'],payload['smt_pair']['comparison_source_sha256'])]:
        meta=json.loads(Path(source).read_text(encoding='utf-8'))
        dataset=next(d for d in meta['datasets'] if d['timeframe']=='M5')
        if meta.get('synthetic') is not False or dataset['data_sha256']!=expected:
            raise ValueError('Profile evidence must match the published real snapshot')
        data=Path(dataset['data_path'])
        if hashlib.sha256(data.read_bytes()).hexdigest()!=expected:
            raise ValueError('Profile evidence source changed before archival')
        target=archive/name; target.mkdir(parents=True,exist_ok=True)
        copied=target/data.name; shutil.copy2(data,copied)
        if hashlib.sha256(copied.read_bytes()).hexdigest()!=expected:
            raise ValueError('Profile archive hash mismatch')
        dataset['data_path']=str(copied.resolve());meta['volatile_live_snapshot']=False
        saved=target/'provenance.json'
        saved.write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        sources.append(str(saved.resolve()))
    definition_sources=[]
    for relative,content,sha in definitions:
        target=archive/'definitions'/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(content)
        if hashlib.sha256(target.read_bytes()).hexdigest()!=sha:
            raise ValueError('Profile definition archive hash mismatch')
        definition_sources.append({'source_path':relative,'archived_path':str(target.resolve()),'sha256':sha})
    recorded=datetime.now(timezone.utc).isoformat()
    with journal.open('a',encoding='utf-8',newline='\n') as stream:
        for record in proposed:
            record.update(recorded_at_utc=recorded,source_snapshot_read_at=payload['snapshot_read_at'],
                          source_manifests=sources,profile_code_sha256=code_sha,
                          profile_definition_sha256=definition_sha,profile_definition_sources=definition_sources,
                          runtime_code_verified=runtime_code_shas is not None,
                          historical_clock_verified=False,orders_sent=0)
            record['origin']='recorded_live_hypothesis' if record['mode'] in ('intraday_hypothesis','intraweek_hypothesis') else 'closed_review_generated_after_day_or_week_end'
            stream.write(json.dumps(record,ensure_ascii=False,separators=(',',':'))+'\n')
    return {'observations_added':len(proposed),'journal':str(journal),'immutable_sources':sources,
            'immutable_definitions':definition_sources,
            'history':_compact_history(observations+proposed,visible_keys)}
