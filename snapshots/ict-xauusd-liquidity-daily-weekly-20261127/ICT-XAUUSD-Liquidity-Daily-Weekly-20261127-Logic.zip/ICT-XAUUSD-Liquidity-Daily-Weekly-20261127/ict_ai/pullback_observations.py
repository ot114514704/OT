"""Measure a local IPDA pullback against the expansion known when it starts."""

from statistics import mean

from .ipda_reference.core import instant, visible


def _body_overlap(first, second):
    lo1, hi1 = sorted((first.open,first.close))
    lo2, hi2 = sorted((second.open,second.close))
    width = min(hi1-lo1,hi2-lo2)
    return max(0.,min(hi1,hi2)-max(lo1,lo2))/width if width>0 else None


def _measure(bars, episode, i):
    side = episode['direction']
    start, end = episode['origin_index'], episode['end_index']
    path = bars[end+1:i+1]
    edge = episode['expansion_end']
    width = side*(edge-episode['origin'])
    basis = (lambda bar:bar.low) if side==1 else (lambda bar:bar.high)
    deepest = min(path,key=lambda bar:side*basis(bar))
    depth = max(0.,side*(edge-basis(deepest)))
    time_ratio = len(path)/(end-start+1)
    overlaps = [overlap for a,b in zip(path,path[1:]) if (overlap:=_body_overlap(a,b)) is not None]
    return dict(main_bars=end-start+1,observed_retracement_bars=len(path),depth_ratio=depth/width,
                time_ratio=time_ratio,area_ratio=(depth/width)*time_ratio,
                relative_adverse_speed=(depth/width)/time_ratio,
                mean_body_overlap=mean(overlaps) if overlaps else None,
                deepest_price=basis(deepest),deepest_bar_open=deepest.time.isoformat(),
                deepest_available_at=deepest.closed_at.isoformat())


def pullback_observations(candles, phases, cutoff):
    """Freeze the pre-pullback leg; publish each result only at its observation close.

    The price-depth extreme, its available time and the later terminal close
    are separate. Crossing the opposite boundary by wick records a sweep proxy.
    Only a close through an edge resolves the local observation.
    """
    cutoff = instant(cutoff)
    bars = visible(candles,cutoff)
    phase_rows = [r for r in phases if instant(r['known_at'])<=cutoff]
    if len(phase_rows)!=len(bars):
        raise ValueError('Phase rows must correspond to each closed candle')
    opened = {}
    observations = []
    episode = None
    run = 0
    for i,(bar,row) in enumerate(zip(bars,phase_rows,strict=True)):
        if instant(row['known_at'])!=bar.closed_at:
            raise ValueError('Phase row and candle closes differ')
        if i and bars[i-1].closed_at!=bar.time:
            if episode:
                observations.append(dict(observations[-1],status='data_discontinuity',as_of=bar.closed_at.isoformat(),
                                         last_continuous_close=bars[i-1].closed_at.isoformat()))
            episode = None
            run = i
        reference = row['reference_before']
        if episode is None and row['phase']=='retracement' and reference:
            origin_index = opened.get(instant(reference['origin_at']),-1)
            side = reference['direction']
            origin, end = (reference['low'],reference['high']) if side==1 else (reference['high'],reference['low'])
            if side in (-1,1) and run<=origin_index<i and side*(end-origin)>0 and instant(reference['known_at'])<=bar.time:
                matching = (j for j in range(i-1,origin_index-1,-1)
                            if (bars[j].high if side==1 else bars[j].low)==end)
                end_index = next(matching,None)
                if end_index is not None:
                    episode = dict(id=bar.closed_at.isoformat(),direction=side,origin=origin,expansion_end=end,
                                   origin_index=origin_index,end_index=end_index,
                                   origin_bar_open=bars[origin_index].time.isoformat(),
                                   expansion_end_bar_open=bars[end_index].time.isoformat(),
                                   expansion_end_available_at=bars[end_index].closed_at.isoformat(),
                                   first_observed_at=bar.closed_at.isoformat(),
                                   reference_available_at=reference['known_at'],
                                   anchor_definition=reference['qualification'])
        opened[instant(bar.time)] = i
        if episode is None:
            continue
        side = episode['direction']
        metrics = _measure(bars,episode,i)
        state = 'observing'
        if side*(bar.close-episode['origin'])<0:
            state = 'origin_close_crossed'
        elif side*(bar.close-episode['expansion_end'])>0:
            state = 'expansion_end_close_crossed'
        record = {key:value for key,value in episode.items() if key not in ('origin_index','end_index')}
        observations.append(dict(record,as_of=bar.closed_at.isoformat(),status=state,**metrics,
                                 origin_wick_crossed=side*(metrics['deepest_price']-episode['origin'])<0))
        if state!='observing':
            episode = None
    return observations


def pullback_note(path, as_of, current_closed_at):
    if not path or instant(path[-1]['as_of'])!=instant(current_closed_at) or instant(current_closed_at)>instant(as_of):
        return None
    last = path[-1]
    if last['status']=='data_discontinuity':
        return '局部回调报价中断 · 等待新的连续行情。'
    labels = {'observing':'跟踪中','origin_close_crossed':'收盘越过推动起点',
              'expansion_end_close_crossed':'已收盘越过推动终点'}
    return (f"局部回调 {labels[last['status']]} · 深度 {last['depth_ratio']:.0%} · "
            f"时间比 {last['time_ratio']:.2f} · 面积比 {last['area_ratio']:.2f} · "
            f"反向速度比 {last['relative_adverse_speed']:.2f} · 推动终点 {last['expansion_end']:.2f} · "
            f"已见最深价 {last['deepest_price']:.2f}。")
