"""Explicit, auditable clock assumptions for ICT session research."""
from __future__ import annotations
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

NY = ZoneInfo("America/New_York")


def eastern_clock_spans(raw_start: datetime, raw_end: datetime, server_offset: timedelta):
    """Half-open raw MT5 intervals and offsets to New York for modern chart dates.

    Raw wall fields are tagged as UTC to match MT5's date representation.
    New York changes offset on a UTC hour boundary, even when the broker
    policy itself starts between hours.
    """
    if raw_start.utcoffset() != timedelta(0) or raw_end.utcoffset() != timedelta(0):
        raise ValueError('MT5 raw wall fields must be tagged as UTC')
    start = cursor = raw_start
    while cursor < raw_end:
        utc = cursor - server_offset
        offset = utc.astimezone(NY).utcoffset() - server_offset
        next_hour = utc.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
        cursor = min(raw_end, next_hour + server_offset)
        if cursor == raw_end or (cursor-server_offset).astimezone(NY).utcoffset()-server_offset != offset:
            yield start, cursor, int(offset.total_seconds())
            start = cursor


def clock_policy_metadata(manifest: dict) -> dict:
    """Serializable clock assumptions bound to a replay, apart from price hashes."""
    return {'source_clock_offset_hours':manifest.get('source_clock_offset_hours',3),
            'source_clock_segments':manifest.get('source_clock_segments') or []}


def require_replay_clock(manifest: dict, replay: dict) -> None:
    if clock_policy_metadata(manifest) != clock_policy_metadata(replay):
        raise ValueError('Replay/source clock mapping mismatch; regenerate the replay')


def manifest_epoch_to_utc(raw: datetime, manifest: dict) -> datetime:
    """Apply explicit raw-clock intervals; never infer historical DST from a tick."""
    segments = manifest.get('source_clock_segments')
    if not segments:
        return epoch_to_utc(raw, timedelta(hours=manifest.get('source_clock_offset_hours', 3)))
    matches = [s for s in segments
               if (not s.get('raw_from') or raw >= datetime.fromisoformat(s['raw_from']))
               and (not s.get('raw_until') or raw < datetime.fromisoformat(s['raw_until']))]
    if len(matches) != 1:
        raise ValueError('Source clock intervals must cover each bar exactly once')
    return epoch_to_utc(raw, timedelta(hours=matches[0]['offset_hours']))


def epoch_to_utc(raw: datetime, source_clock_offset: timedelta) -> datetime:
    """Treat raw's displayed UTC fields as the uncalibrated source clock.

    Offset zero is the API-UTC hypothesis. Offset +3h is the broker-wall-clock
    hypothesis for a specifically documented interval, never a universal DST
    rule. Caller must separately record whether evidence verifies the offset.
    """
    if raw.tzinfo is None or raw.utcoffset() is None:
        raise ValueError("Timezone-aware raw epoch decoding required")
    if abs(source_clock_offset) > timedelta(hours=14):
        raise ValueError("Invalid clock offset")
    return raw.astimezone(timezone.utc) - source_clock_offset


def session_windows(day: date) -> dict[str, tuple[datetime, datetime]]:
    """UTC intervals based on each boundary's actual New York UTC offset."""
    def local(d, hour):
        return datetime.combine(d,time(hour),NY).astimezone(timezone.utc)
    return {
        "asia": (local(day-timedelta(days=1),20),local(day,0)),
        "london": (local(day,2),local(day,5)),
        "new_york": (local(day,7),local(day,10)),
        "london_close": (local(day,10),local(day,12)),
    }


def daily_profile_history_start(day: date) -> datetime:
    """Include previous NY weekdays for weekly context and the day's pre-midnight Asia range."""
    monday = day - timedelta(days=day.weekday())
    week_open = datetime.combine(monday,time.min,NY).astimezone(timezone.utc)
    return min(week_open, session_windows(day)['asia'][0])


def previous_week(today: date) -> list[date]:
    monday = today-timedelta(days=today.weekday()+7)
    return [monday+timedelta(days=i) for i in range(5)]
