"""Compare daily and weekly candidate directions at one auditable cutoff."""

from datetime import date, datetime, timedelta, timezone

from brooks_ai.types import Bar, utc_time
from .profile_delivery_evidence import M15, weekly_delivery
from .profile_lifecycle import _day_bounds, daily_profile_lifecycle, weekly_profile_lifecycle
from .profile_sources import WEEKLY
from .profile_timeline import attach_profile_timeline
from .range_liquidity import M5
from .timebase import NY, session_windows
from .weekly_close_candidates import friday_expansion_watch
from .weekly_path import weekly_path


def observed_context(m5,m15,days,at,*,include_friday_watch=False):
    realized = weekly_path(m5,days,at)
    lifecycle = weekly_profile_lifecycle(m15,days,at,realized)
    earlier = [d for d in realized['daily'] if d['ended']]
    covered = lifecycle['coverage_complete_under_study_calendar']
    day = at.astimezone(NY).date()
    prior_complete = len(earlier)==day.weekday() and all(d['coverage_complete'] for d in earlier)
    prior = None
    if earlier and prior_complete:
        prior = dict(low=min(d['low'] for d in earlier),high=max(d['high'] for d in earlier),close=earlier[-1]['close'])
    cards = [c for c in lifecycle['candidates'] if c['id'] in WEEKLY and c['observed_sequence'] and c['status']=='active']
    supplement = weekly_delivery(m5,m15,days,at)
    sweeps = {}
    if covered:
        for event in realized['sweeps']:
            side = event['kind']
            sweeps[side] = sweeps.get(side,0)+1
    result = dict(as_of=at.isoformat(),covered=covered,completed_prior_days=sum(d['coverage_complete'] for d in earlier),
                prior=prior,sweeps=sweeps,active=[dict(id=c['id'],direction=c.get('direction')) for c in cards],
                consolidation=lifecycle.get('early_week_consolidation',{}).get('matched',False),
                thursday_counter=[r['direction'] for r in supplement if r['status']=='delivery_observed' and covered])
    if include_friday_watch and (watch := friday_expansion_watch(realized,m15,days,at,covered)):
        result['friday_range_watch'] = watch
    return result


def align_candidates(day,week):
    cards = [c for c in day['candidates'] if c['observed_sequence'] and c['status']=='active']
    directions = {c['direction'] for c in week['active'] if c['direction'] in (-1,1)}
    supported = {
        side: ('mixed_week' if len(directions)==2 else 'aligned' if side in directions else
               'opposed' if -side in directions else 'no_directional_week_candidate')
        for side in (-1,1)
    }
    return [dict(id=c['id'],label=c['label'],direction=c['direction'],
                 comparison=('daily_neutral' if c['direction'] not in (-1,1) else
                             supported[c['direction']] if week['covered'] else 'weekly_coverage_unknown'))
            for c in cards]


def attach_profile_alignment(payload):
    """Attach aligned historical or current cutoffs to the measured chart branch."""
    as_of = utc_time(payload['smt_pair']['as_of'])
    close = payload.get('closed_m5_through',{}).get('XAUUSD')
    if not close:
        return
    close = min(as_of,utc_time(close))
    primary = next(s for s in payload['scenarios'] if s['id']=='broker-plus3')
    series = {period:{} for period in ('5','15')}
    for day in primary['days']:
        for period,by_time in series.items():
            for stamp,*ohlc in day['charts'][period]['bars']:
                at = datetime.fromtimestamp(stamp/1000,timezone.utc)
                by_time[at] = Bar(at,*ohlc,0)
    series = {k:[rows[t] for t in sorted(rows)] for k,rows in series.items()}
    attach_profile_timeline(primary,series,as_of,close)
    weeks = {w['days'][0]:w for w in primary.get('weeks',[]) if w.get('days')}
    for record in primary['days']:
        day = date.fromisoformat(record['date'])
        start,end = _day_bounds(day)
        monday = day-timedelta(days=day.weekday())
        week = [monday+timedelta(days=i) for i in range(5)]
        first = _day_bounds(monday)[0]
        historical = close>=end
        at = session_windows(day)['new_york'][1] if historical else close.replace(minute=close.minute//15*15,second=0,microsecond=0)
        if at<=start:
            continue
        day_floor = min(first,session_windows(day)['asia'][0])
        m5 = [b for b in series['5'] if day_floor<=b.time and b.time+M5<=at]
        m15 = [b for b in series['15'] if day_floor<=b.time and b.time+M15<=at]
        day_view = daily_profile_lifecycle(m15,day,at,include_reconstruction=False,reference_m5=m5)
        week_view = observed_context([b for b in m5 if b.time>=first],[b for b in m15 if b.time>=first],week,at,
                                     include_friday_watch=day.weekday()==4)
        record['profile_alignment'] = dict(as_of=at.isoformat(),historical=historical,
            daily_covered=day_view.get('coverage_complete_under_study_calendar',False),weekly=week_view,
            comparisons=align_candidates(day_view,week_view),execution_allowed=False)
        if 'friday_range_watch' in week_view and monday.isoformat() in weeks:
            weeks[monday.isoformat()]['friday_range_watch'] = dict(week_view['friday_range_watch'],
                                                                  as_of=at.isoformat(),historical=historical)
