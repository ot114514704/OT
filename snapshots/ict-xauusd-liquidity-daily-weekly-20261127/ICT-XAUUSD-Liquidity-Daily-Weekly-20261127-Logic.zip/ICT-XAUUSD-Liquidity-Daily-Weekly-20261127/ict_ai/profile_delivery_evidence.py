"""Closed-bar evidence for the supplementary daily and weekly profile diagrams."""

from datetime import date, datetime, timedelta, timezone

from brooks_ai.types import Bar, utc_time

from .profile_lifecycle import _day_bounds
from .range_liquidity import _m5_reference_day, _research_open
from .timebase import session_windows


M15 = timedelta(minutes=15)
SOURCE = 'research/ict_profile_supplement_20261123.json'


def _level_events(rows, level, outward, *, allow_recess=False):
    """Track wick excursions, close reclaims and two consecutive closes outside."""
    sweep = reclaimed = extended = None
    previous = None
    for bar in rows:
        if previous is not None and bar.time != previous.time+M15:
            if not allow_recess:
                break
            previous = None
        extreme = bar.high if outward>0 else bar.low
        if sweep is None and outward*(extreme-level)>0:
            sweep = bar.time+M15
        outside = outward*(bar.close-level)>0
        if sweep and reclaimed is None and outward*(bar.close-level)<0:
            reclaimed = bar.time+M15
        if extended is None and outside and previous is not None and outward*(previous.close-level)>0:
            extended = bar.time+M15
        previous = bar
    return dict(level=level,sweep=sweep,reclaimed=reclaimed,extension=extended)


def _record(kind,status,as_of,figures,**evidence):
    return dict(kind=kind,status=status,as_of=as_of.isoformat(),source=SOURCE,figures=figures,
                scope='closed_price_path',htf_context_verified=False,execution_allowed=False,**evidence)


def daily_delivery(rows, day, as_of, covered):
    """Distinguish initial London delivery from the first NY sweep of a range."""
    windows = session_windows(day)
    cutoff = min(as_of,_day_bounds(day)[1])
    asia,london,ny = ([b for b in rows if a<=b.time and b.time+M15<=min(z,cutoff)]
                      for a,z in (windows[k] for k in ('asia','london','new_york')))
    for part,key in ((asia,'asia'),(london,'london')):
        start,end = windows[key]
        if cutoff<end:
            return [_record('daily_session_distinction','awaiting_london_close',cutoff,[163,166,169])]
        if len(part)!=int((end-start)/M15) or any(b.time!=start+i*M15 for i,b in enumerate(part)):
            return [_record('daily_session_distinction','coverage_unknown',cutoff,[163,166,169])]
    if not covered:
        return [_record('daily_session_distinction','coverage_unknown',cutoff,[163,166,169])]
    ranges = [(min(b.low for b in part),max(b.high for b in part)) for part in (asia,london)]
    (al,ah),(ll,lh) = ranges
    in_london = {-1:_level_events(london,al,-1),1:_level_events(london,ah,1)}
    in_ny = {-1:_level_events(ny,ll,-1),1:_level_events(ny,lh,1)}
    london_held = [side for side in (-1,1) if in_london[side]['extension'] and
                   side*(london[-1].close-in_london[side]['level'])>0]
    records = []
    for side in (-1,1):
        opposing_london = in_london[-side]['reclaimed']
        london_follow = in_london[side]['extension']
        if opposing_london:
            later_london = [b for b in london if b.time>=opposing_london]
            london_follow = _level_events(later_london,ah if side>0 else al,side)['extension']
        ny_opposing = in_ny[-side]
        ny_reclaim = ny_opposing['reclaimed']
        later_ny = [b for b in ny if ny_reclaim is not None and b.time>=ny_reclaim]
        edge = lh if side>0 else ll
        if opposing_london and london_follow:
            follow = _level_events(ny,edge,side)['extension']
            adverse_level = ll if side>0 else lh
            broken = ny_opposing['sweep'] is not None
            records.append(_record('london_reversal_ny_continuation',
                'invalidated' if broken else 'delivery_observed' if follow else 'waiting_for_delivery',
                cutoff,[163,164,165,181,182],direction=side,first_reclaim=opposing_london.isoformat(),
                london_delivery=london_follow.isoformat(),delivery=follow.isoformat() if follow else None,protected_edge=adverse_level))
        if ny_reclaim:
            follow = _level_events(later_ny,edge,side)['extension']
            kind = ('ny_reversal_after_london_drive' if london_held==[-side] else
                    'ny_sweep_after_london_balance' if not london_held and not any(e['extension'] for e in in_london.values()) else
                    'ny_sweep_context_unresolved')
            figures = [166,167,168,175,176] if kind=='ny_reversal_after_london_drive' else [169,170,171,177,178,179,180]
            through_reclaim = [b for b in ny if b.time+M15<=ny_reclaim]
            protected = (min(b.low for b in through_reclaim) if side>0 else max(b.high for b in through_reclaim))
            broken = any((b.low<protected if side>0 else b.high>protected) for b in later_ny)
            records.append(_record(kind,'invalidated' if broken else 'delivery_observed' if follow else 'waiting_for_delivery',
                cutoff,figures,direction=side,first_reclaim=ny_reclaim.isoformat(),
                delivery=follow.isoformat() if follow else None,protected_edge=protected,
                frozen_london_low=ll,frozen_london_high=lh))
    if all(in_london[side]['reclaimed'] for side in (-1,1)):
        dates = [in_london[side]['reclaimed'] for side in (-1,1)]
        last_reclaim = max(dates)
        after_london_reclaim = [b for b in london if b.time>=last_reclaim]
        expanding = any(_level_events(after_london_reclaim,edge,side)['extension'] for side,edge in ((-1,al),(1,ah)))
        expanding |= any(e['extension'] is not None for e in in_ny.values())
        # An NY return after a failed break supports the warning. A further
        # pair of directional closes supersedes it in the same observation.
        returned = any(e['reclaimed'] for e in in_ny.values())
        records.append(_record('seek_destroy_risk','invalidated' if expanding else
                       'two_sessions_reclaimed' if returned else 'london_double_reclaim_warning',cutoff,[172,173,174],
                       first_reclaim=last_reclaim.isoformat(),asia_equilibrium=(al+ah)/2))
    return records


def weekly_delivery(m5, rows, week, as_of):
    """Detect Thursday counter-delivery only after three closed trend days."""
    cutoff = min(as_of,_day_bounds(week[-1])[1])
    thursday = week[3]
    start,end = _day_bounds(thursday)
    if cutoff<=start:
        return []
    source = [_m5_reference_day(m5,d,cutoff) for d in week[:3]]
    if any(d['status']!='complete' for d in source):
        return [_record('weekly_thursday_counter','coverage_unknown',cutoff,[159,160])]
    mon,tue,wed = [value['bars'] for value in source]
    changes = (mon[-1].close-mon[0].open,tue[-1].close-mon[-1].close,wed[-1].close-tue[-1].close)
    side = 1 if all(c>0 for c in changes) else -1 if all(c<0 for c in changes) else 0
    if not side:
        return []
    week_edge = (max(b.high for b in mon+tue+wed) if side>0 else min(b.low for b in mon+tue+wed))
    parts = [b for b in rows if start<=b.time and b.time+M15<=min(cutoff,end)]
    stop = min(cutoff,end)
    expected = [at for i in range(int((stop-start)/M15)) if _research_open(at:=start+i*M15)]
    if [b.time for b in parts] != expected:
        return [_record('weekly_thursday_counter','coverage_unknown',cutoff,[159,160])]
    occurrence = _level_events(parts,week_edge,side,allow_recess=True)
    reclaim = occurrence['reclaimed']
    if not reclaim:
        return []
    after = [b for b in parts if b.time>=reclaim]
    opposing = _level_events(after,wed[-1].close,-side,allow_recess=True)['extension']
    before = [b for b in parts if b.time<reclaim]
    protected = max(b.high for b in before) if side>0 else min(b.low for b in before)
    friday,_ = _day_bounds(week[4])
    later = after+[b for b in rows if friday<=b.time and b.time+M15<=cutoff]
    broken = any((b.high>protected if side>0 else b.low<protected) for b in later)
    return [_record('weekly_thursday_counter',
            'invalidated' if broken else 'delivery_observed' if opposing else 'waiting_for_delivery',
            cutoff,[159,160],direction=-side,first_reclaim=reclaim.isoformat(),week_edge=week_edge,
            protected_edge=protected,confirmation_line=wed[-1].close,delivery=opposing.isoformat() if opposing else None)]


def attach_chart_evidence(payload):
    """Add directly observable cases to the measured-clock chart scenario."""
    cutoff = utc_time(payload['smt_pair']['as_of'])
    primary = next(s for s in payload['scenarios'] if s['id']=='broker-plus3')

    def bars(record,period):
        chart = record['charts'][period]
        source = chart.get('bars')
        if source is None and chart.get('bars_from_days'):
            by_time = {}
            for day in primary['days']:
                if day['date'] in record['days']:
                    by_time.update((row[0],row) for row in day['charts'][period]['bars'])
            source = [by_time[key] for key in sorted(by_time)]
        return [Bar(datetime.fromtimestamp(stamp/1000,timezone.utc),*ohlc,0) for stamp,*ohlc in source]

    for day in primary['days']:
        life = day['profile_lifecycle']
        day['supplemental_delivery'] = daily_delivery(bars(day,'15'),date.fromisoformat(day['date']),cutoff,
                                                        life.get('coverage_complete_under_study_calendar',False))
    for week in primary['weeks']:
        dates = [date.fromisoformat(day) for day in week['days']]
        week['supplemental_delivery'] = weekly_delivery(bars(week,'5'),bars(week,'15'),dates,cutoff)
