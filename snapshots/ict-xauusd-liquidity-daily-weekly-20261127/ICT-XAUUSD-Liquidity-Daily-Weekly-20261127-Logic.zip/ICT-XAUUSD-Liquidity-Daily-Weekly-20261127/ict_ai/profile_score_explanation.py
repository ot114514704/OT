"""Explain an archived linear daily-profile score using its frozen weights."""

from math import exp, fsum, isclose


LABELS = {
    'side': '候选方向', 'net_today': '当日开盘以来的顺向位移',
    'from_london_close': '伦敦收盘以来的顺向位移', 'beyond_london_side': '位置相对伦敦同侧外沿',
    'day_close_location': '位置在当日范围中的分位', 'ny_width': '纽约波幅相对伦敦波幅',
    'asia_width_relative_to_london': '亚洲波幅相对伦敦波幅',
    'prior_day_available': '前日范围可用状态', 'prior_day_range_position': '位置相对前日范围',
    'prior_week_available': '前周范围可用状态', 'prior_week_range_position': '位置相对前周范围',
    'elapsed_since_ny_0700': '纽约 07:00 后经过时间',
}


def sigmoid(logit):
    return 1 / (1 + exp(-min(40, max(-40, logit))))


def explain_profile_score(model, names, values, recorded, profile_names):
    mean, scale, coefficients = model
    total = [weight * (value - average) / spread for weight, value, average, spread in
             zip(coefficients[1:], values, mean, scale, strict=True)]
    logit = coefficients[0] + fsum(total)
    probability = sigmoid(logit)
    if not isclose(probability, recorded, rel_tol=1e-12, abs_tol=1e-14):
        raise ValueError('Frozen profile probability does not reproduce from its contributions')
    profile = fsum(term for name, term in zip(names, total, strict=True) if name in profile_names)
    terms = [dict(label='候选形态类别', contribution=profile)]
    terms.extend(dict(label=LABELS[name], contribution=value) for name, value in zip(names, total, strict=True)
                 if name not in profile_names)
    terms.sort(key=lambda item: abs(item['contribution']), reverse=True)
    return dict(mean_input_probability=sigmoid(coefficients[0]), probability=probability,
                intercept=coefficients[0], terms=terms)
