"""Closed-M5 state2 sweep annotations, based on upstream GitHub 6f62516."""

from .session_path import STEP


END_ATR = 3.0
WINDOW = 48
STATE_NAMES = {'candidate': '待定', 'sweep': '偏扫荡', 'break': '偏真破'}
END_NAMES = {'inside': '原侧离位 3 ATR', 'outside': '外侧离位 3 ATR',
             'window': '48 根窗口结束', 'gap': '报价有缺口', 'observing': '截至观察末端',
             'missing_prior': '前置波幅不足'}


def crossing_state(side, edge, crossing, follow, as_of, prior_atr):
    """Record changes on their own closes and keep the event endpoint distinct."""
    extreme = crossing.high if side == 1 else crossing.low
    if crossing.time + STEP > as_of or not crossing.low <= edge <= crossing.high or side * (extreme - edge) <= 0:
        return None
    crossed_at = (crossing.time + STEP).isoformat()
    status, strength, changes = 'candidate', 0, []
    reason, ended_at = 'missing_prior', None
    if prior_atr and prior_atr > 0:
        outside_count = 0
        outside_body_inner = None
        expected = crossing.time
        for offset, bar in enumerate((crossing, *follow[:WINDOW])):
            if bar.time != expected or bar.time + STEP > as_of:
                break
            expected += STEP
            opened, closed = side * (bar.open - edge), side * (bar.close - edge)
            if closed > 0:
                outside_count += 1
                body_inner = min(opened, closed)
                outside_body_inner = body_inner if outside_body_inner is None else min(outside_body_inner, body_inner)
                if outside_count >= 3 or (outside_count >= 2 and closed >= prior_atr) or status == 'sweep':
                    next_status, next_strength = 'break', 2 if outside_count >= 3 else 1
                    evidence = 'three_outside' if outside_count >= 3 else (
                        'follow' if outside_count >= 2 and closed >= prior_atr else 'back_outside')
                else:
                    next_status, next_strength, evidence = status, strength, None
            else:
                engulf = outside_count and closed < opened and closed < outside_body_inner
                next_status, next_strength = 'sweep', 2 if engulf else 1
                evidence = 'engulf' if engulf else 'reclaim'
                outside_count, outside_body_inner = 0, None
            if (next_status, next_strength) != (status, strength):
                status, strength = next_status, next_strength
                changes.append(dict(status=status, strength=strength, evidence=evidence, known_at=expected.isoformat()))
            if offset and abs(closed) >= END_ATR * prior_atr:
                reason, ended_at = ('outside' if closed > 0 else 'inside'), expected.isoformat()
                break
            if offset == WINDOW:
                reason, ended_at = 'window', expected.isoformat()
                break
        if ended_at is None:
            reason = 'gap' if expected + STEP <= as_of else 'observing'
    return dict(crossed_at=crossed_at, status=status, strength=strength,
                changes=changes, end_reason=reason, ended_at=ended_at)


def state_caption(state, format_time):
    if not state:
        return ''
    history = ' → '.join(f'{format_time(row["known_at"])} {STATE_NAMES[row["status"]]}'
                         f'{"（整块吞回）" if row["evidence"] == "engulf" else "（强）" if row["strength"] == 2 else ""}'
                         for row in state['changes'])
    ending = END_NAMES[state['end_reason']]
    if state['ended_at']:
        ending = f'{format_time(state["ended_at"])} 结束 · {ending}'
    return f'扫后状态 {history or STATE_NAMES[state["status"]]} · {ending}'
