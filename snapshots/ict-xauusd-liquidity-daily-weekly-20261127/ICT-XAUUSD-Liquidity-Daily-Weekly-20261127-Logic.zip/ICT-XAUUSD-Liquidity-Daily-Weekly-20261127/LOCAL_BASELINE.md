# XAUUSD 流动性逻辑备份 · 2026-11-25

当前 MT5 XAUUSD 1.34 源码、已安装编译件、行情桥、逐层筛选、逐根回测及冻结报价。项目历史窗口按纽约时间。

- [识别、排序与交接](research/ict_liquidity_logic_handoff.md)
- [V7B 逐根回测](output/research/ict_sweep_verdict_20261124/流动性逐根回测.md)
- [旧结构与 V7B 联合回测](output/research/ict_sweep_verdict_20261124/combined_verdict/联合回测.md)
- [每个文件的 SHA-256](MANIFEST.json)

已部署的规则分别记录候选的严格越界和 V7B 扫后判词。联合判词与逐层筛选的前瞻验证归档为研究证据。BOS／CHoCH 使用独立的标注。归档中的前瞻 JSON 为打包时已写入磁盘的记录。

在解压根目录用 Windows x64 Python 3.11+ 复跑。命令会在解压副本中写入报告。

```powershell
python -m pip install numpy tzdata MetaTrader5
python -m unittest discover -s tests -p "test_ict_*liquidity*.py" -q
python -m unittest discover -s tests -p "test_ict_sweep*.py" -q
python -B -m scripts.replay_ict_sweep_verdict
python -B -m scripts.audit_ict_sweep_combination
```
