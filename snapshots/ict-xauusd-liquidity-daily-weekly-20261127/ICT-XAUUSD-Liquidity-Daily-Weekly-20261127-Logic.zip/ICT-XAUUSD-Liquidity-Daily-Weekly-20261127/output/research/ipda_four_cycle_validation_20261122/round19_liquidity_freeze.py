"""Freeze up to fifty current structural pools per list and score actual quotes."""
from bisect import bisect_left
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, time, timedelta
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
from brooks_ai.types import Bar
from ict_ai.dol_history import _deadline
from ict_ai.range_liquidity import _Coverage
from ict_ai.structural_liquidity import structural_ranking
from scripts import replay_structural_top10 as existing


joint, NY, M5 = existing.joint, existing.NY, existing.M5
INIT = existing.june.OUT / 'frozen.json.gz'
M1 = existing.MINUTES
MODEL = ROOT/'ict_ai/structural_liquidity.py'
FROZEN = HERE/'round19_liquidity_50_candidates.json.gz'
LOCK = HERE/'round19_liquidity_50_lock.json'
OUTCOMES = HERE/'round19_liquidity_50_outcomes.json.gz'
HISTORY = existing.priority.ARCH/'XAUUSDM5.npz'
FRAMES = ('IRL','ERL')
COUNTS = (10,20,30,50)


def build(snapshot):
    at = datetime.fromisoformat(snapshot['at'])
    market = existing.bars[:bisect_left(existing.times,at)]
    assert market[-1].time+M5==at and market[-1].close==snapshot['price']
    minutes = existing.minutes[:bisect_left(existing.minute_times,at)]
    has_m1 = bool(minutes and minutes[-1].time+timedelta(minutes=1)==at)
    chosen = structural_ranking(market,at,snapshot['dol'],limit=50,priority_uplift=True,
                                minute_bars=minutes if has_m1 else ())
    by_class = {key:[p for p in chosen if p['classification']==key] for key in FRAMES}
    for key,pools in by_class.items():
        assert len(pools)<=50 and all(p['rank']==i for i,p in enumerate(pools,1))
        assert len({(p['side'],p['lo'],p['hi']) for p in pools})==len(pools)
        assert all(sum(p['components'].values())==p['score'] for p in pools)
        assert all(datetime.fromisoformat(t)<at for p in pools for t in p['anchor_times'])
    if at.astimezone(NY).day in (1,16) and at.astimezone(NY).hour==8:
        limited = structural_ranking(market,at,snapshot['dol'],limit=10,priority_uplift=True,
                                     minute_bars=minutes if has_m1 else ())
        assert limited==[p for key in FRAMES for p in by_class[key][:10]]
        checked = True
    else:
        checked = False
    return {'at':snapshot['at'],'price':snapshot['price'],'has_m1':has_m1,'top10_parity_checked':checked,'pools':by_class}


def paths():
    return (INIT,M1,HISTORY,MODEL,ROOT/'ict_ai/range_liquidity.py',ROOT/'ict_ai/target_priority.py',
            ROOT/'scripts/replay_structural_top10.py',Path(__file__).resolve())


def freeze():
    assert joint.digest(INIT)==json.loads((INIT.parent/'lock.json').read_bytes())['frozen']
    assert joint.digest(M1)==json.loads((M1.parent/'m1-lock.json').read_bytes())['digest']
    assert joint.digest(HISTORY)==json.loads((HISTORY.parent/'capture.json').read_bytes())['series']['XAUUSDM5']['sha256']
    source = {p.relative_to(ROOT).as_posix():joint.digest(p) for p in paths()}
    inputs = [s for s in joint.read_zip(INIT) if datetime.fromisoformat(s['at']).astimezone(NY).strftime('%H:%M')
              in existing.june.CHECKPOINTS]
    rows = []
    with ProcessPoolExecutor(max_workers=6,initializer=existing.initialize) as workers:
        for i,s in enumerate(workers.map(build,inputs,chunksize=3),1):
            rows.append(s)
            if i%80==0:
                print('Frozen',i,'of',len(inputs),flush=True)
    assert source=={p.relative_to(ROOT).as_posix():joint.digest(p) for p in paths()}
    joint.write_zip(FROZEN,rows)
    report = {'sources':source,'candidates':joint.digest(FROZEN),'checkpoints':len(rows),
              'top10_parity_checks':sum(s['top10_parity_checked'] for s in rows),
              'cutoff_with_m1':sum(s['has_m1'] for s in rows),'shape':'IRL/ERL lists independent, 50 each maximum'}
    LOCK.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report),flush=True)


def price_result(pool,bars):
    lo,hi,side = (pool[k] for k in ('lo','hi','side'))
    away = hi if side==1 else lo
    touch = sweep = reclaim = gap_over = None
    for i,b in enumerate(bars):
        if touch is None and b.low<=hi and b.high>=lo:
            touch = (b.time+M5).isoformat()
        if not (b.high>away if side==1 else b.low<away):
            continue
        if not b.low<=away<=b.high:
            gap_over = (b.time+M5).isoformat()
            break
        sweep = (b.time+M5).isoformat()
        j = i
        for reaction in bars[i:i+4]:
            if reaction.time != b.time+(j-i)*M5:
                break
            if side*(reaction.close-away)<0:
                reclaim = (reaction.time+M5).isoformat()
                break
            j += 1
        break
    original = joint.contacts(pool,bars,True)
    assert (touch,sweep)==(original['touch'],original['sweep'])
    return {'touch':touch,'sweep':sweep,'reclaim':reclaim,'gap_over':gap_over}


def score():
    lock = json.loads(LOCK.read_bytes())
    assert joint.digest(FROZEN)==lock['candidates']
    market,times = existing.priority.read_market()
    coverage = _Coverage(times[0],times[-1]+M5,market,M5)
    rows = joint.read_zip(FROZEN)
    evidence = []
    stats = defaultdict(Counter)
    for s in rows:
        at = datetime.fromisoformat(s['at'])
        day = at.astimezone(NY).date()
        month = day.isoformat()[:7]
        deadline = {'short':_deadline(at),'week':datetime.combine(day+timedelta(days=4-day.weekday()),time(16,55),NY)}
        results = {}
        for horizon,end in deadline.items():
            flag = 'open' if end>coverage.cutoff else 'missing' if coverage.gap(at,end) else 'complete'
            out = {'status':flag,'end':end.isoformat()}
            if flag=='complete':
                window = market[bisect_left(times,at):bisect_left(times,end)]
                for label,pools in s['pools'].items():
                    out[label] = [price_result(p,window) for p in pools]
            for label,pools in s['pools'].items():
                for group in (month,'all'):
                    values = stats[group,horizon,label]
                    values[flag] += 1
                    values['pools_nominal'] += len(pools)
                    for n in COUNTS:
                        values[f'windows_have_{n}'] += len(pools)>=n
                    if flag!='complete':
                        continue
                    for n in COUNTS:
                        obs = out[label][:n]
                        values[f'nonempty_top{n}'] += bool(obs)
                        values[f'top{n}_offers'] += len(obs)
                        values[f'top{n}_touch'] += sum(r['touch'] is not None for r in obs)
                        values[f'top{n}_sweeps'] += sum(r['sweep'] is not None for r in obs)
                        values[f'top{n}_reclaims'] += sum(r['reclaim'] is not None for r in obs)
                        values[f'top{n}_any_sweep'] += any(r['sweep'] is not None for r in obs)
                    for rank,item in enumerate(out[label][:10],1):
                        values[f'r{rank}_n'] += 1
                        values[f'r{rank}_sweep'] += item['sweep'] is not None
                    values['no_top10_but_11_50_strict_sweep'] += not any(r['sweep'] for r in out[label][:10]) and any(r['sweep'] for r in out[label][10:])
            results[horizon] = out
        evidence.append({'at':s['at'],**results})
    joint.write_zip(OUTCOMES,evidence)
    output = {'freeze_sha256':lock['candidates'],'outcomes_sha256':joint.digest(OUTCOMES),
              'all':{f'{horizon}/{label}':stats['all',horizon,label] for horizon in ('short','week') for label in FRAMES},
              'by_month':{'/'.join(k):v for k,v in stats.items() if k[0]!='all'}}
    (HERE/'round19_liquidity_baseline.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:{m:v[m] for m in ('complete','top10_offers','top10_sweeps','top50_offers','top50_sweeps')}
                      for k,v in output['all'].items()}),flush=True)


if __name__=='__main__':
    if sys.argv[1]=='freeze':
        freeze()
    elif sys.argv[1]=='score':
        score()
    else:
        raise SystemExit('Choose freeze or score.')
