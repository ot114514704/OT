"""Additional chronological holdout coverage after the discovery rule has been locked."""
from run import *
import random
def main():
    lock=HERE/'discovery_lock.json'
    pinned=json.loads(lock.read_bytes())['challenger']
    locked_hash=hashlib.sha256(lock.read_bytes()).hexdigest()
    sampled=set(tasks())
    dates=[]
    d=date(2026,4,1)
    while d<=date(2026,9,18):
        if d.weekday()<5 and d not in sampled:dates.append(d)
        d+=timedelta(days=1)
    with ProcessPoolExecutor(max_workers=8,initializer=inputs) as pool:
        extra=[s for group in pool.map(freeze,dates,chunksize=1) for s in group]
    dumpgzip(HERE/'validation_extra_frozen.json.gz',extra)
    assert hashlib.sha256(lock.read_bytes()).hexdigest()==locked_hash
    inputs()
    initial=[s for s in json.loads(gzip.decompress((HERE/'frozen.json.gz').read_bytes())) if assign(si(s['ny']).date())=='validation']
    full=sorted(extra+initial,key=lambda s:s['at'])
    assert len(full)==len({s['at'] for s in full})
    report={'discovery_lock_sha256':locked_hash,'challenger':pinned}
    cache={s['at']:outcome(s) if s['status']=='frozen' else None for s in full}
    for title,records in [('extra_only',extra),('all_days',full)]:
        r=[(s,cache[s['at']]) for s in records]
        report[title]={}
        for k,group in [('all',r)]+[(k,[(s,o) for s,o in r if s['segment']==k]) for k in sorted({s['segment'] for s in records})]:
            report[title][k]={rule:metrics(group,rule) for rule in ('baseline',pinned)}
        pairs=Counter();by_week=defaultdict(lambda:[0,0,0,0]);losses=[]
        for s,o in r:
            if not o or o['category'] in ('missing','open'):continue
            i,bonus=ordering(s,pinned);day=si(s['ny']).date();wk=day-timedelta(days=day.weekday())
            b=by_week[wk];b[2]+=int(bool(o['touch_closes'][i]))-int(bool(o['touch_closes'][0]));b[3]+=1
            if o['category'] in ('same_bar','same_edge'):continue
            diff=int(o['first_ranks']==[i+1])-int(o['first_ranks']==[1]);b[0]+=diff;b[1]+=1
            if i:pairs['win' if diff>0 else 'loss' if diff<0 else 'neutral']+=1
            if diff<0:losses.append(dict(at=s['ny'],baseline=s['targets'][0],challenger=s['targets'][i],deadline=o['deadline']))
        rng=random.Random(20261122);weeks=list(by_week.values());dist=[[],[]]
        for _ in range(5000):
            totals=[sum(batch) for batch in zip(*rng.choices(weeks,k=len(weeks)))]
            for j in (0,1):
                if totals[j*2+1]:dist[j].append(totals[j*2]/totals[j*2+1])
        report[title]['cluster_week_intervals']=[np.percentile(ds,[2.5,97.5]).tolist() for ds in dist]
        report[title]['paired_top_changes']=pairs
        report[title]['first_failure_examples']=losses[:4]
    dumpgzip(HERE/'validation_outcomes.json.gz',[dict(at=s['at'],status=s['status'],outcome=cache[s['at']],chosen_rank=ordering(s,pinned)[0]+1 if cache[s['at']] else None) for s in full])
    write('validation_all_days.json',report)
if __name__=='__main__':main()
