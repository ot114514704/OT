"""Standalone read-only reconstruction. Run with --freeze then --score against the adjacent capture."""
import csv,gzip,hashlib,json,os,statistics,sqlite3,sys
from pathlib import Path
from collections import Counter,defaultdict
from concurrent.futures import ProcessPoolExecutor
from bisect import bisect_left
from datetime import datetime,date,time,timedelta,timezone
from zoneinfo import ZoneInfo
import numpy as np
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT))
from brooks_ai.types import Bar
from ict_ai.dol_history import forecast
from ict_ai.judas import judas_history
from ict_ai.timebase import NY
from ict_ai.range_liquidity import _research_open
from scripts import export_mt5_profiles as exporter
from scripts.prepare_ict_week import aggregate_bars
from scripts.replay_ranked_dol import schedule
M=timedelta(minutes=5); H=timedelta(hours=1); UTC=timezone.utc
def write(name,data): (HERE/name).write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
def iso(t):return t.isoformat()
def ny(d,h,m=0):return datetime.combine(d,time(h,m),NY).astimezone(UTC)
def si(at):return datetime.fromisoformat(at)
def dt(raw):
    # Observed broker session clock equals NY wall clock +7h for this study.
    wall=datetime.fromtimestamp(int(raw),UTC).replace(tzinfo=None)-7*H
    return wall.replace(tzinfo=NY).astimezone(UTC)
def load(key):
    a=np.load(HERE/(key+'.npz'))['rates']
    result=[Bar(dt(r['time']),*[float(r[k]) for k in ('open','high','low','close')],0) for r in a if int(r['time'])>=1750723200]
    assert all(x.time<y.time for x,y in zip(result,result[1:]))
    return result
def inputs():
    global SERIES,TIMES,QUARTERS,QTIME,CALENDAR
    SERIES=[load(k) for k in ('XAUUSDM5','XAUUSDH1','XAGUSDH1','USIDXH1')]
    TIMES=[[b.time for b in rows] for rows in SERIES]
    QUARTERS=aggregate_bars(SERIES[0],5,15,SERIES[0][-1].time+M)
    QTIME=[b.time for b in QUARTERS]
    CALENDAR=schedule()
def slice_at(rows,ts,lo,hi):
    return rows[bisect_left(ts,lo):bisect_left(ts,hi)]
def tasks():
    # A rotating weekday per ISO week covers all trading weekdays independent of outcomes.
    monday=date(2025,8,4); end=date(2026,9,18);i=0
    while monday<=end:
        d=monday+timedelta(days=i%5);yield d
        monday+=timedelta(days=7);i+=1
def freeze(day):
    monday=day-timedelta(days=day.weekday())
    warm=ny(monday-timedelta(days=42),0)
    daycut=ny(day,17)
    x,h,a,d=[slice_at(s,t,warm,daycut) for s,t in zip(SERIES,TIMES)]
    q=slice_at(QUARTERS,QTIME,warm,daycut)
    clocks=[(0,5),(2,0),(8,0),(10,0),(14,0)]
    out=[]
    # START is the export wrapper's plotting floor, not a scoring parameter.
    exporter.START=(warm-H).astimezone(NY).date()
    for hour,minute in clocks:
        at=ny(day,hour,minute)
        xs=[b for b in x if b.time+M<=at]; hrs=[b for b in h if b.time+H<=at]
        stamp=dict(at=iso(at),ny=iso(at.astimezone(NY)),warmup=iso(warm),segment='%02d:%02d'%(hour,minute))
        if not xs or xs[-1].time+M!=at:
            out.append(dict(**stamp,status='no_checkpoint_quote'));continue
        # Each call receives closed prefixes, including for peer follow-through and Judas evidence.
        comp=[[b for b in series if b.time+H<=at] for series in (a,d)]
        anchor=at-timedelta(days=12)
        hp=[b for b in hrs if b.time>=anchor]
        peers=[]
        for rows,title,inverse in zip(comp,('白银','美元指数'),(False,True)):
            peers+=exporter.add_smt(lambda *a:None,hp,[b for b in rows if b.time>=anchor],at,title,inverse)
        js=judas_history([b for b in xs if b.time>=at-timedelta(days=5)],at,CALENDAR)
        _,c=forecast(xs,hrs,[b for b in q if b.time+3*M<=at],at,peers,CALENDAR,js)
        ranges=[b.high-b.low for b in hrs[-24:] if b.high>b.low]
        stamp.update(status='frozen' if c else 'no_targets',price=xs[-1].close,targets=c,median_h1=statistics.median(ranges) if ranges else 0,
                     peer_last=[iso(rows[-1].time+H) if rows else None for rows in comp])
        out.append(stamp)
    return out
def dumpgzip(path,data):
    path.write_bytes(gzip.compress(json.dumps(data,ensure_ascii=False,separators=(',',':')).encode(),mtime=0))
def assign(d):return 'discovery' if d<date(2026,4,1) else 'validation'
RULES=['baseline','near4','near8','near12','aligned4','aligned8']
def ordering(s,rule):
    rows=s['targets']
    dist=[t['distance'] for t in rows]
    near={side:min((t['distance'] for t in rows if t['side']==side),default=float('inf')) for side in (-1,1)}
    def bonus(t):
        if rule=='baseline':return 0
        if rule.startswith('near'):
            return int(rule[4:]) if t['distance']==near[t['side']] and t['distance']<=.25*s['median_h1'] else 0
        match=t['reason'].split('；同向 ',1)[-1].split('；')[0].split('、')
        return int(rule[7:]) if '位移' in match and ('有效 D' in match or '盘间收破' in match) else 0
    order=sorted(range(len(rows)),key=lambda i:(-min(100,rows[i]['score']+bonus(rows[i])),dist[i],rows[i]['lo'],rows[i]['hi']))
    return order[0],bonus(rows[order[0]])
def outcome(s):
    at=si(s['at']);day=at.astimezone(NY).date()
    bound=ny(day,17) if day.weekday()==4 else ny(day+timedelta(days=1),0)
    deadline=min(at+4*H,bound);asof=SERIES[0][-1].time+M
    first=bisect_left(TIMES[0],at);last=bisect_left(TIMES[0],min(asof,deadline))
    rows=SERIES[0][first:last];ticks={b.time for b in rows}
    absent=[];stamp=at
    while stamp+M<=min(deadline,asof):
        if _research_open(stamp) and stamp not in ticks:absent.append(iso(stamp))
        stamp+=M
    levels=[t['lo'] if t['side']==1 else t['hi'] for t in s['targets']]
    hits=[next((b.time for b in rows if b.low<=v<=b.high),None) for v in levels]
    earliest=min((t for t in hits if t is not None),default=None)
    cand=[i for i,h in enumerate(hits) if h is not None and h==earliest]
    if len(cand)>1:
        op=next(b.open for b in rows if b.time==earliest)
        on_open=[i for i in cand if abs(op-levels[i])<1e-8]
        if on_open:cand=on_open
    category='open' if deadline>asof else 'missing' if absent else 'same_bar' if len(set(levels[i] for i in cand))>1 else 'same_edge' if len(cand)>1 else 'none_hit' if not cand else 'unique'
    return dict(deadline=iso(deadline),category=category,missing_slots=absent,first_ranks=[i+1 for i in cand],touch_closes=[iso(h+M) if h else None for h in hits])
def metrics(rows,rule):
    z=Counter(windows=len(rows))
    for s,o in rows:
        z[s['status']]+=1
        if not o:continue
        typ=o['category'];z[typ]+=1
        if typ in ('open','missing'):continue
        i,bonus=ordering(s,rule)
        z['changed_top']+=i!=0;z['bonus_top']+=bonus>0
        z['hit_n']+=1;z['hit']+=bool(o['touch_closes'][i])
        if typ in ('same_bar','same_edge'):continue
        z['order_n']+=1;z['first']+=o['first_ranks']==[i+1]
    return dict(z,first_rate=z['first']/z['order_n'] if z['order_n'] else None,hit_rate=z['hit']/z['hit_n'] if z['hit_n'] else None)
def score():
    inputs();frozen=json.loads(gzip.decompress((HERE/'frozen.json.gz').read_bytes()))
    report={};ledger=[]
    for sample in ('discovery','validation'):
        group=[s for s in frozen if assign(si(s['ny']).date())==sample]
        r=[(s,outcome(s) if s['status']=='frozen' else None) for s in group]
        if sample=='discovery':
            grid={k:metrics(r,k) for k in RULES}
            winner=max(RULES[1:],key=lambda k:(grid[k]['first_rate'],grid[k]['hit_rate'],-RULES.index(k)))
            write('discovery_lock.json',dict(rules=RULES,selection='first_rate, then hit_rate, then list order. Best challenger compared with unchanged baseline.',grid=grid,challenger=winner))
        else:winner=json.loads((HERE/'discovery_lock.json').read_bytes())['challenger']
        report[sample]={}
        for groupkey,rr in [('all',r)]+[(s,[(a,b) for a,b in r if a['segment']==s]) for s in sorted({a['segment'] for a,b in r})]:
            report[sample][groupkey]={k:metrics(rr,k) for k in ['baseline',winner]}
        pairs=Counter()
        for s,o in r:
            row=dict(at=s['at'],sample=sample,outcome=o)
            if o:
                i,add=ordering(s,winner);row.update(challenger_rank=i+1,bonus=add)
                if i and o['category'] not in ('open','missing','same_edge','same_bar'):
                    before=o['first_ranks']==[1];after=o['first_ranks']==[i+1]
                    pairs['win' if after and not before else 'loss' if before and not after else 'neutral']+=1
            ledger.append(row)
        report[sample]['paired_top_changes']=pairs
    dumpgzip(HERE/'outcomes.json.gz',ledger);write('summary.json',report)
if __name__=='__main__':
    if '--freeze' in sys.argv:
        with ProcessPoolExecutor(max_workers=8,initializer=inputs) as pool:
            groups=list(pool.map(freeze,tasks(),chunksize=1))
        dumpgzip(HERE/'frozen.json.gz',[s for grp in groups for s in grp])
    if '--score' in sys.argv:score()
