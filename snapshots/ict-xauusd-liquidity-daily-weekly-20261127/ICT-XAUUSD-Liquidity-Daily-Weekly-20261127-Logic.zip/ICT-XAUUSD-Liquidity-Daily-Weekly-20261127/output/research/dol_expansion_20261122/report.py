"""Summarize the frozen ledgers without changing the selected rule."""
from run import *
from html import escape
def gz(n):return json.loads(gzip.decompress((HERE/(n+'.json.gz')).read_bytes()))
def read(n):return json.loads((HERE/(n+'.json')).read_bytes())
rule=read('discovery_lock')['challenger']
ds=read('summary');vs=read('validation_all_days');rs=read('recent_summary')
raw={s['at']:s for n in ['frozen','validation_extra_frozen','recent_frozen'] for s in gz(n)}
ledger={s['at']:s for n in ['outcomes','validation_outcomes','recent_outcomes'] for s in gz(n)}
assert raw.keys()==ledger.keys()
sources={};table=[];after=[];segments=[];fails=[];same=[];decomp=0
def ratio(a,b):return f'{a}/{b}（{a/b:.1%}）' if b else '—'
def row(x):return '<tr>'+''.join('<td>'+escape(str(v))+'</td>' for v in x)+'</tr>'
def grid(cols,rows):return '<table><thead>'+row(cols)+'</thead><tbody>'+''.join(map(row,rows))+'</tbody></table>'
for title,low,high in [('发现期','2025-08-01','2026-04-01'),('独立验证','2026-04-01','2026-09-19'),('旧窗时间外复核','2026-09-21','2026-11-21'),('其中最近两周','2026-11-09','2026-11-21')]:
 data=[(s,ledger[k]['outcome']) for k,s in sorted(raw.items()) if low<=s['ny'][:10]<high]
 b=metrics(data,'baseline');c=metrics(data,rule)
 table.append([title,len(data),ratio(b.get('first',0),b['order_n']),ratio(c.get('first',0),c['order_n']),ratio(b.get('hit',0),b['hit_n']),ratio(c.get('hit',0),c['hit_n'])])
 after.append([title,b.get('no_checkpoint_quote',0),b.get('no_targets',0),b.get('missing',0),b.get('same_bar',0),b.get('same_edge',0),b.get('none_hit',0),b.get('open',0),c.get('changed_top',0)])
 counts=Counter()
 for s,o in data:
    if not o or o['category'] in ('missing','open'):continue
    i,add=ordering(s,rule);bt,ct=s['targets'][0],s['targets'][i]
    before=bool(o['touch_closes'][0]);afterhit=bool(o['touch_closes'][i])
    counts['hit_gain']+=afterhit and not before;counts['hit_loss']+=before and not afterhit
    if o['category']!='same_bar':
      counts['edge_n']+=1;counts['base_edge_first']+=1 in o['first_ranks'];counts['alt_edge_first']+=i+1 in o['first_ranks']
    if o['category'] in ('same_edge','same_bar'):continue
    change=int(i+1 in o['first_ranks'])-int(1 in o['first_ranks'])
    if i:counts['first_gain' if change>0 else 'first_loss' if change<0 else 'first_flat']+=1
    if change<0 and title in ('独立验证','旧窗时间外复核'):
      fails.append(dict(sample=title,at=s['ny'],original=bt,alternative=ct,added=add,first=o['first_ranks'],touches=o['touch_closes'],deadline=o['deadline']))
 sources[title]=dict(counts)
 same.append([title,counts['first_gain'],counts['first_loss'],counts['hit_gain'],counts['hit_loss'],ratio(counts['base_edge_first'],counts['edge_n']),ratio(counts['alt_edge_first'],counts['edge_n'])])
 if title!='其中最近两周':
  for hh in sorted({s['segment'] for s,o in data}):
    z=[(s,o) for s,o in data if s['segment']==hh];bb=metrics(z,'baseline');cc=metrics(z,rule)
    segments.append([title,hh,len(z),ratio(bb.get('first',0),bb.get('order_n',0)),ratio(cc.get('first',0),cc.get('order_n',0)),ratio(bb.get('hit',0),bb.get('hit_n',0)),ratio(cc.get('hit',0),cc.get('hit_n',0))])
write('paired_and_edge_sensitivity.json',sources);dumpgzip(HERE/'loss_cases.json.gz',fails)
issues=[]
for s in raw.values():
 for t in s.get('targets',[]):
  if min(100,max(0,sum(t['score_components'].values())))!=t['score']:issues.append(s['at'])
  decomp+=1
assert not issues
def link(f,label):return f'<a href="{f}">{label}</a>'
recent=rs['all']['week_block_delta_intervals'];va=vs['all_days']['cluster_week_intervals']
ci=lambda x:' 至 '.join(f'{v*100:+.1f}' for v in x)
html='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>XAUUSD 流动性目标扩窗验证</title><style>body{font:16px/1.65 system-ui,sans-serif;color:#173036;background:#f8faf9;max-width:1100px;margin:36px auto;padding:0 22px}h1,h2{line-height:1.35;color:#113b42}table{border-collapse:collapse;background:white;width:100%;margin:14px 0}td{border-bottom:1px solid #d9e3e2;padding:8px;text-align:left}thead{font-weight:650;background:#e4efec}a{color:#006f73}details{margin:12px 0}section{overflow:auto}</style><h1>XAUUSD 流动性目标扩窗验证</h1>
<p>2026 年 11 月 22 日完成。目标与评分在各纽约截点收线时冻结。基线调用当前发布器的 forecast / outlook，替代规则只对相同候选重新排序。线上评分与终端图表均保持原样。</p>
<h2>首选目标的结果</h2>
<p>近端加分规则在发现期的五个备选中选出。某方向的目标近端是该侧距离现价最近的一层，且距离不超过过去 24 根已收 H1 高低波幅中位数的 25% 时，加 12 分，总分封顶 100。同分沿用线上距离、上下界排序。上下两侧均可满足，同一近端的不同区间也可同时满足。</p>'''
heads=['样本','截点','原首选先到','加分首选先到','原首选期限内到','加分首选期限内到']
html+='<section>'+grid(heads,table)+'</section>'
html+=f'<p>每一预测最长四小时，按纽约当日截止，周五最迟 17:00。计近端实际落进 M5 高低区间，单纯越过价位不算。首达率分母包含有完整覆盖而所有目标均未到的失败，排除同根顺序不明和同价并列。期限内命中允许同根和同价。独立验证按纽约周进行 5,000 次配对区组重采样，两个提升的 95% 描述性区间分别是 {ci(va[0])}、{ci(va[1])} 个百分点。旧窗分别为 {ci(recent[0])}、{ci(recent[1])} 个百分点，同周截点相互关联。</p>'
html+='<h2>失败、同根和覆盖</h2>'+grid(['样本','截点缺报价','无候选','观察期缺棒','不同价同根','同价并列','全部未到','归档末未到期','更换首选'],after)
html+=grid(['样本','首达改对','首达改错','限期改对','限期改错','合并同价后原首达','合并同价后加分首达'],same)
html+='<p>同根有多个不同价位时，只在开盘报价恰好等于其中一个目标时确认开盘先触，其余保留为顺序不明。完整报价覆盖按项目研究钟表检查，节假日与特殊停市可能列作缺口。未到期以归档最后已收 M5 截断。每一条结果都保留实际到价时间、候选排名和缺失时刻。</p>'
html+='<h2>分时段结果</h2><details open><summary>纽约时间和每段分母</summary><section>'+grid(['样本','纽约时间']+heads[1:],segments)+'</section></details>'
html+='''<h2>日期与独立性</h2><p>发现期按每周轮换一个交易日回放，2025-08-04 至 2026-03-26 共 170 个截点。设定固定 00:05、02:00、08:00、10:00、14:00 五次冻结，预先比较不加分、近端加 4/8/12 分以及位移与有效 D 或盘间收破同向加 4/8 分。先用首达率、再次用期限内命中率选择规则。独立段 2026-04-01 至 09-18 先用轮换日验证，再用锁定规则复核其余工作日，合计 123 个工作日、615 个预定截点。没有在独立段或旧窗调整参数。早期滚动每周带入 42 天预热和当周可见历史，每个截点截断黄金及对照品种。提前移除旧发布器 9 月以前的 SMT 绘图日期限制，只在离线进程中生效。12 天 H1 对照资料生成 SMT，取最近五天 M5 计算犹大背景。早期新闻日历不完整；新闻没有额外方向加分。</p>
<p>旧报告标题截止 11-21，实际 495 个截点为 09-21 00:05 至 11-20 16:00，旧表列出 9,048 个目标。时间外复核严格复用这 495 个时间和同份原始行情，针对现行评分重新生成候选。495 组完整旧名单与现行重建没有一组逐项相同，468 个截点的首选方向及价位相同。截点选取密度及新闻/犹大时刻与早期固定时刻不同。最终发布文件的 52 个目标及整批哈希与当前评分在最后一次收盘的重建完全一致。</p>'''
html+=f'<p>三个不重叠样本合计 {len(raw):,} 个预定截点、{decomp:,} 条冻结候选。逐条核对了 reach、alignment、quality、timing、obstacle 五项与基线总分。图表回执数据库可配对的及时前瞻批次为 0，上述结果都是历史重建。</p>'
html+='''<h2>报价范围与冬夏令时</h2><p>项目保存的 HistData 报价最早到 2025-01-01 18:00:00.455 纽约时间，属不同报价源。项目 data/real 里现存 TMGM M5 导出最早为 2026-05-14 01:40 纽约。当前 TMGM 终端 100,000 根限制下，按位置实测能取得的最早有效黄金 M5 开盘为 2025-06-25 04:15 纽约，最后收盘为 2026-11-20 16:55。批量压缩文件从 04:20 开盘开始，前一根另存。向更早日期的查询仅返边界外的第一根，没有计入更早历史。很早的 H1 文件有按日稀疏记录，不能代替 M5。</p>
<p>按研究时段逐根核对，批量 M5 整段应有 101,370 根，覆盖 99,998 根，缺 1,372 根；另外有 1 根落在研究时段定义以外。最长连续有效报价段为 2026-09-07 18:00 至 11-20 16:50（开盘时间，14,893 根，按预期交易时段跳过休市）。旧归档的 17,861 根黄金 M5、1,490 根黄金 H1、1,490 根白银 H1 和 1,364 根美元指数 H1，在时间和 OHLC 上与新归档逐根一致。</p>
<p>冬夏令时按 America/New_York 换算，研究期间服务器钟相对纽约墙钟快 7 小时。覆盖 2025-11-02、2026-03-08、2026-11-01 三次换时。核对了三次转换前后并含美欧不同步周的 9 个交易日，同终端美股 CFD 的盘前复盘位置与纽约 04:00 一致。与 2026 年 10 月、11 月归档时钟观测相符。历史黄金的独立 UTC 分钟源连接失败，无法逐分钟独立认证。</p>
<p><a href="https://www.tmgm.com/eng/trading/trading-hours">TMGM 服务器与黄金交易时间</a> · <a href="https://www.nist.gov/pml/time-and-frequency-division/popular-links/daylight-saving-time-dst">NIST 美国冬夏令时</a> · <a href="https://www.nasdaq.com/market-activity">Nasdaq 盘前交易时间</a></p>
<h2>反例与复核文件</h2>'''
for t in ('独立验证','旧窗时间外复核'):
 f=next(f for f in fails if f['sample']==t);b=f['original'];c=f['alternative']
 html+=f'<p>{t}，{f["at"]}。原首选 {escape(b["source"])} {b["lo"]:.2f}–{b["hi"]:.2f}，{b["score"]} 分；新首选 {escape(c["source"])} {c["lo"]:.2f}–{c["hi"]:.2f}，{c["score"]} 分加 {f["added"]}。这次原首选先触达。</p>'
html+='<p>'+' · '.join(link(f,t) for f,t in [('discovery_lock.json','发现期锁定规则'),('validation_all_days.json','独立段配对结果'),('recent_summary.json','近期复核'),('coverage_audit.json','覆盖审计'),('clock_validation.json','冬夏令时核对'),('loss_cases.json.gz','改错样本'),('model_sources.zip','评分源码快照')])+'</p>'
html+='<p>重跑顺序为 run.py --freeze --score、validate_days.py、recent.py、report.py。前三者在本目录保存冻结清单与结算明细，近期复核还需原 ranked_dol 归档。模型分数衡量规则匹配度，本次没有计算收益或止损。</p></html>'
(HERE/'DOL扩窗验证.html').write_text(html,encoding='utf8')
