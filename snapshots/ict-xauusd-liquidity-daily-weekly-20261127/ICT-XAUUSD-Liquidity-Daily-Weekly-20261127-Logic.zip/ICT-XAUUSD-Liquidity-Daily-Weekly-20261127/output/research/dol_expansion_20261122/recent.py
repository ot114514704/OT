"""Locked near12 replay at the 495 original cutoff times on their original input archive."""
from run import *
from validate_days import random
from ict_ai.dol_history import batch_id
def init_recent():
    global block,series,quarters,calendar
    old=ROOT/'output/research/ranked_dol'
    archive=old/'TMGM_20261122.json.gz'
    report=json.loads((old/'history.json').read_bytes())
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==report['archive_sha256']
    data=json.loads(gzip.decompress(archive.read_bytes()))
    series=[[Bar(si(t),o,h,l,c,0) for t,o,h,l,c in data['series'][k]] for k in ('XAUUSDM5','XAUUSDH1','XAGUSDH1','USIDXH1')]
    quarters=aggregate_bars(series[0],5,15,si(data['at']))
    calendar=schedule();block=defaultdict(list)
    for snap in report['snapshots']:block[si(snap['at']).astimezone(NY).date()].append(snap)
def freeze_recent(d):
    output=[]
    for old in block[d]:
        at=si(old['at']);bars=[b for b in series[0] if b.time+M<=at];hours=[b for b in series[1] if b.time+H<=at]
        assert bars[-1].time+M==at and bars[-1].close==old['price']
        hp=[b for b in hours if b.time>=at-timedelta(days=12)]
        peers=[]
        for peer,tag,inverse in zip(series[2:],('白银','美元指数'),(False,True)):
            other=[b for b in peer if at-timedelta(days=12)<=b.time and b.time+H<=at]
            peers+=exporter.add_smt(lambda *a:None,hp,other,at,tag,inverse)
        judas=judas_history([b for b in bars if b.time>=at-timedelta(days=5)],at,calendar)
        _,c=forecast(bars,hours,[b for b in quarters if b.time+3*M<=at],at,peers,calendar,judas)
        out=dict(at=old['at'],ny=iso(at.astimezone(NY)),segment=at.astimezone(NY).strftime('%H:%M'),status='frozen' if c else 'no_targets',price=old['price'],
            targets=c,median_h1=statistics.median(b.high-b.low for b in hours[-24:] if b.high>b.low))
        def sig(rows):return [(t['rank'],t['score'],t['side'],t['lo'],t['hi']) for t in rows]
        out['same_as_old_archive']=sig(c)==sig(old['targets'])
        output.append(out)
    return output
def main():
    lock=HERE/'discovery_lock.json';key=hashlib.sha256(lock.read_bytes()).hexdigest()
    rule=json.loads(lock.read_bytes())['challenger'];assert rule=='near12'
    init_recent()
    with ProcessPoolExecutor(max_workers=8,initializer=init_recent) as pool:
        frozen=[s for g in pool.map(freeze_recent,sorted(block)) for s in g]
    dumpgzip(HERE/'recent_frozen.json.gz',frozen)
    import run
    run.SERIES=series;run.TIMES=[[b.time for b in rows] for rows in series]
    r=[(s,outcome(s) if s['targets'] else None) for s in frozen]
    sections={'all':r,'last_2_weeks':[(s,o) for s,o in r if s['ny'][:10]>='2026-11-09']}
    sections.update({m:[(s,o) for s,o in r if s['ny'].startswith(m)] for m in ('2026-09','2026-10','2026-11')})
    report={'locked_challenger':rule,'lock_sha256':key,'old_archive_exact_lists':sum(s['same_as_old_archive'] for s in frozen),'cutoffs':len(frozen)}
    for name,data in sections.items():
        counts=Counter();delta=defaultdict(lambda:[0,0,0,0])
        for s,o in data:
            if o is None or o['category'] in ('open','missing'):continue
            i=ordering(s,rule)[0]
            day=si(s['ny']).date();wk=day-timedelta(days=day.weekday())
            v=delta[wk];v[2]+=bool(o['touch_closes'][i])-bool(o['touch_closes'][0]);v[3]+=1
            if o['category'] in ('same_edge','same_bar'):continue
            diff=int(o['first_ranks']==[i+1])-int(o['first_ranks']==[1]);v[0]+=diff;v[1]+=1
            if i:counts['win' if diff>0 else 'loss' if diff<0 else 'neutral']+=1
        rng=random.Random(20261122);weeks=list(delta.values());dist=[[],[]]
        for _ in range(5000):
            t=[sum(v) for v in zip(*rng.choices(weeks,k=len(weeks)))]
            for j in (0,1):
                if t[2*j+1]:dist[j].append(t[2*j]/t[2*j+1])
        report[name]={k:metrics(data,k) for k in ('baseline',rule)}
        report[name]['paired']=counts
        report[name]['week_block_delta_intervals']=[np.percentile(x,[2.5,97.5]).tolist() if len(weeks)>2 else None for x in dist]
    assert key==hashlib.sha256(lock.read_bytes()).hexdigest()
    write('recent_summary.json',report)
    dumpgzip(HERE/'recent_outcomes.json.gz',[dict(at=s['at'],status=s['status'],outcome=o,chosen_rank=ordering(s,rule)[0]+1 if o else None) for s,o in r])
if __name__=='__main__':main()
