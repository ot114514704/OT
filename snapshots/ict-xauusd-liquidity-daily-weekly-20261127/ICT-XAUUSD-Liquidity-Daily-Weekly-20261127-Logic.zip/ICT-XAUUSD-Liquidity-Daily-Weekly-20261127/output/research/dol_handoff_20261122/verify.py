"""Re-settle the transferred DOL forecasts against closed gold candles."""
import gzip
import hashlib
import json
import sys
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from statistics import median

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCE = HERE.parent / 'dol_expansion_20261122'
sys.path.insert(0, str(ROOT))
from brooks_ai.types import Bar
from ict_ai.dol_history import settle
from ict_ai.timebase import NY

M5 = timedelta(minutes=5)
H1 = timedelta(hours=1)


def packed(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def terminal_bars(key):
    rates = np.load(SOURCE / (key + '.npz'))['rates']
    result = []
    for row in rates:
        wall = datetime.fromtimestamp(int(row['time']), timezone.utc).replace(tzinfo=None)
        stamp = (wall - 7*H1).replace(tzinfo=NY).astimezone(timezone.utc)
        result.append(Bar(stamp, *(float(row[k]) for k in ('open','high','low','close')), 0))
    return result


def verify(records, m5, hourly, originals):
    counts = Counter(checkpoints=len(records))
    weeks = defaultdict(list)
    times = [b.time for b in m5]
    hours = [b.time for b in hourly]
    for s in records:
        if s['status'] == 'frozen':
            weeks[s['ny'][:10]].append(s)
        else:
            counts[s['status']] += 1
    mismatches = []
    for group in weeks.values():
        start = datetime.fromisoformat(group[0]['at'])
        end = datetime.fromisoformat(group[-1]['at']) + 4*H1
        bars = m5[bisect_left(times,start):bisect_left(times,end)]
        settle(group, bars, times[-1] + M5)
        for s in group:
            state = s['first_touch_status']
            counts[state] += 1
            old = originals[s['at']]
            states = dict(missing='insufficient_coverage', same_bar='same_m5_bar',
                          same_edge='same_level', none_hit='no_hit')
            if state != states.get(old['category'], old['category']):
                mismatches.append((s['at'],'outcome classification'))
            if state in ('open','insufficient_coverage','no_observation_window','expired_before_observation'):
                continue
            if old['first_ranks'] != s['first_ranks']:
                mismatches.append((s['at'],'first contact'))
            at = datetime.fromisoformat(s['at'])
            last = bisect_right(hours,at-H1)
            widths = [b.high-b.low for b in hourly[max(0,last-24):last] if b.high>b.low]
            threshold = median(widths)/4 if widths else 0
            if abs(threshold-s['median_h1']/4)>1e-8:
                mismatches.append((s['at'],'H1 cutoff'))
            targets = s['targets']
            nearest = {side:min((p['distance'] for p in targets if p['side']==side),default=None)
                       for side in (-1,1)}
            def priority(p):
                bonus = 12 if p['distance']==nearest[p['side']] and p['distance']<=threshold else 0
                return (-min(100,p['score']+bonus),p['distance'],p['lo'],p['hi'])
            selected = min(targets,key=priority)
            hits = [p['horizon_status']=='observed_hit' for p in targets]
            if hits != [bool(t) for t in old['touch_closes']]:
                mismatches.append((s['at'],'target contact within horizon'))
            counts['hit_denominator'] += 1
            counts['original_hit'] += hits[0]
            counts['near12_hit'] += hits[selected['rank']-1]
            if state not in ('same_m5_bar','same_level'):
                counts['first_denominator'] += 1
                before = s['first_ranks']==[1]
                after = s['first_ranks']==[selected['rank']]
                counts['original_first'] += before
                counts['near12_first'] += after
                counts['paired_gain'] += after and not before
                counts['paired_loss'] += before and not after
    return dict(counts=counts,mismatches=mismatches)


def main():
    manifest = json.loads((SOURCE/'manifest.json').read_bytes())
    for name, expected in manifest.items():
        assert hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()==expected, name
    early = packed(SOURCE/'frozen.json.gz')
    recent = packed(SOURCE/'recent_frozen.json.gz')
    validated = [s for s in early if s['ny'][:10]>='2026-04-01']
    validated += packed(SOURCE/'validation_extra_frozen.json.gz')
    discovery = [s for s in early if s['ny'][:10]<'2026-04-01']
    previous = SOURCE.parent/'ranked_dol'
    archive = previous/'TMGM_20261122.json.gz'
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==json.loads((previous/'history.json').read_bytes())['archive_sha256']
    series = packed(archive)['series']
    def bars(key):
        return [Bar(datetime.fromisoformat(t),o,h,l,c,0) for t,o,h,l,c in series[key]]
    def outcomes(name):
        return {r['at']:r['outcome'] for r in packed(SOURCE/name)}
    gold, hours = terminal_bars('XAUUSDM5'), terminal_bars('XAUUSDH1')
    report = dict(source_sha256_verified=len(manifest),
                  discovery=verify(discovery,gold,hours,outcomes('outcomes.json.gz')),
                  validation=verify(validated,gold,hours,outcomes('validation_outcomes.json.gz')),
                  recent=verify(recent,bars('XAUUSDM5'),bars('XAUUSDH1'),outcomes('recent_outcomes.json.gz')))
    print(json.dumps(report,indent=2))
    assert not any(v['mismatches'] for v in (report['discovery'],report['validation'],report['recent']))
    (HERE/'summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')


if __name__=='__main__':
    main()
