"""Freeze conditional contact frequencies and verify them at unused checkpoint times."""
import hashlib
import json
import random
import sys
from collections import Counter,defaultdict
from datetime import date,timedelta
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from low_scores import features,records
from verify import packed

LOCK=HERE/'low_calibration_lock.json'


def keys(p):
    band=str(p['base']//10*10)
    cell=next((str(n) for n in (1,2,4) if p['reach']<=n),'far')
    return band,band+'/'+cell


def paired(path):
    name='low_extra' if path=='early' else 'calibration'
    lookup={r['at']:r['outcome'] for r in packed(HERE/(name+'_outcomes.json.gz'))}
    for s in packed(HERE/(name+'_frozen.json.gz')):
        o=lookup[s['at']]
        if o and o['category'] not in ('open','missing'):yield s,o


def train():
    bins=defaultdict(Counter);weeks=defaultdict(set)
    for s,o in [*records('discovery'),*paired('early')]:
        d=date.fromisoformat(s['ny'][:10]);wk=str(d-timedelta(days=d.weekday()))
        for p in features(s,o):
            for k in keys(p):
                bins[k]['n']+=1;bins[k]['h']+=int(p['hit']);weeks[k].add(wk)
    rows={k:dict(n=v['n'],hits=v['h'],weeks=len(weeks[k])) for k,v in bins.items()}
    with LOCK.open('x',encoding='utf8') as f:
        json.dump(dict(cells=rows,available_from_ny='2026-04-01',smoothing=30,
                       minimum_targets=30,minimum_weeks=5,bonus_cap=8,priority_ceiling=49,
                       script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),f,indent=2)


def validate():
    model=json.loads(LOCK.read_bytes());assert model['script_sha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    data=model['cells']
    def probability(p):
        a,b=keys(p)
        group=data.get(a)
        if group is None:return None
        base=(group['hits']+1)/(group['n']+2)
        cell=data.get(b)
        if not cell or cell['weeks']<5 or cell['n']<30:return base,base
        return base,(cell['hits']+30*base)/(cell['n']+30)
    result={}
    for part in ('april_september','september_november'):
        c=Counter();by_week=defaultdict(Counter);raised=Counter()
        for s,o in paired('test'):
            if (s['ny'][:10]<'2026-09-21')!=(part=='april_september'):continue
            c['settled_checkpoints']+=1
            ps=features(s,o)
            if not ps:continue
            d=date.fromisoformat(s['ny'][:10]);week=str(d-timedelta(days=d.weekday()))
            w=by_week[week]
            for p in ps:
                probs=probability(p);p['new']=p['base']
                if not probs:continue
                a,b=probs;y=int(p['hit']);c['n']+=1;c['hit']+=y
                c['loss_base']+=(a-y)**2;c['loss_cell']+=(b-y)**2
                w['n']+=1;w['gain']+=(a-y)**2-(b-y)**2
                p['new']=min(49,p['base']+min(8,max(0,round(100*(b-a)))))
                if p['new']>p['base']:raised['count']+=1;raised['hits']+=y
            def choose(key):return min(ps,key=lambda p:(-p[key],p['distance'],p['lo'],p['hi']))
            top,new=choose('base'),choose('new')
            c['low_issuances']+=1;c['top_base']+=top['hit'];c['top_new']+=new['hit']
            w['cuts']+=1;w['top_gain']+=int(new['hit'])-int(top['hit'])
            if top['rank']!=new['rank']:c['top_changed']+=1
        rng=random.Random(12035)
        ws=list(by_week.values());boot=[[],[]]
        for _ in range(3000):
            sample=rng.choices(ws,k=len(ws))
            for j,(field,den) in enumerate([('gain','n'),('top_gain','cuts')]):
                boot[j].append(sum(w[field] for w in sample)/sum(w[den] for w in sample))
        intervals=[]
        for vals in boot:
            vals.sort();intervals.append([vals[74],vals[2924]])
        result[part]=dict(counts=c,raised=raised,brier_base=c['loss_base']/c['n'],brier_cell=c['loss_cell']/c['n'],
                          intervals=intervals)
    calibration_pass=all(r['intervals'][0][0]>0 for r in result.values())
    rank_pass=calibration_pass and all(r['counts']['top_new']>r['counts']['top_base'] and r['intervals'][1][0]>=0 for r in result.values())
    result.update(calibration_pass=calibration_pass,rank_pass=rank_pass)
    (HERE/'low_calibration_validation.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps(result))


if __name__=='__main__':
    if sys.argv[1]=='lock':train()
    elif sys.argv[1]=='validate':validate()
    else:raise ValueError(sys.argv[1])
