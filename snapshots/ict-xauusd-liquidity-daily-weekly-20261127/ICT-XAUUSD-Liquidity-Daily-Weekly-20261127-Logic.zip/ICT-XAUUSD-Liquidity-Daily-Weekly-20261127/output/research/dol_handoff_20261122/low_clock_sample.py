"""Freeze three unused NY cutoffs per weekday for the locked low-score calibration."""
from concurrent.futures import ProcessPoolExecutor
from datetime import date,timedelta
import sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from low_score_extra import run


def freeze(day):
    monday=day-timedelta(days=day.weekday())
    warm=run.ny(monday-timedelta(days=42),0)
    x,h,a,d=[run.slice_at(s,t,warm,run.ny(day,17)) for s,t in zip(run.SERIES,run.TIMES)]
    q=run.slice_at(run.QUARTERS,run.QTIME,warm,run.ny(day,17))
    run.exporter.START=(warm-run.H).astimezone(run.NY).date()
    result=[]
    for hh in (6,12,15):
        at=run.ny(day,hh,35)
        xs=[b for b in x if b.time+run.M<=at]
        s=dict(at=run.iso(at),ny=run.iso(at.astimezone(run.NY)),status='no_checkpoint_quote')
        result.append(s)
        if not xs or xs[-1].time+run.M!=at:continue
        hrs=[b for b in h if b.time+run.H<=at]
        peers=[]
        lookback=at-timedelta(days=12)
        for peer,tag,inv in [(a,'白银',False),(d,'美元指数',True)]:
            peers+=run.exporter.add_smt(lambda *args:None,[b for b in hrs if b.time>=lookback],
                [b for b in peer if lookback<=b.time and b.time+run.H<=at],at,tag,inv)
        judas=run.judas_history([b for b in xs if b.time>=at-timedelta(days=5)],at,run.CALENDAR)
        _,targets=run.forecast(xs,hrs,[b for b in q if b.time+3*run.M<=at],at,peers,run.CALENDAR,judas)
        s.update(status='frozen' if targets else 'no_targets',targets=targets,price=xs[-1].close,
                 median_h1=run.statistics.median(b.high-b.low for b in hrs[-24:] if b.high>b.low))
    return result


if __name__=='__main__':
    if not (HERE/'low_calibration_lock.json').exists():raise RuntimeError('Freeze calibration before holdout')
    days=[];d=date(2026,4,1)
    while d<=date(2026,11,20):
        if d.weekday()<5:days.append(d)
        d+=timedelta(days=1)
    with ProcessPoolExecutor(max_workers=5,initializer=run.inputs) as pool:
        frozen=[s for group in pool.map(freeze,days) for s in group]
    run.dumpgzip(HERE/'calibration_frozen.json.gz',frozen)
    run.inputs()
    run.dumpgzip(HERE/'calibration_outcomes.json.gz',
                 [dict(at=s['at'],outcome=run.outcome(s) if s['status']=='frozen' else None) for s in frozen])
    print(len(days),len(frozen))
