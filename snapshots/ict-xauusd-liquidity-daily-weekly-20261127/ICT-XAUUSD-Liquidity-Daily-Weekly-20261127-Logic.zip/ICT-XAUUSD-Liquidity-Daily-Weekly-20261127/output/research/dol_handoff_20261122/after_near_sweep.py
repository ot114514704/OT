"""Check whether two closes beyond a swept nearer target justify a DOL upgrade."""
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import gzip
import hashlib
import json
from pathlib import Path
import random
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from verify import SOURCE,M5,NY,packed,terminal_bars
from ict_ai.dol_history import _deadline
from ict_ai.range_liquidity import _research_open


def candidates(s):
    """Find the immediately preceding distinct entry edge in each direction."""
    for side in (-1,1):
        levels=defaultdict(list)
        for p in s['targets']:
            if p['side']==side:
                levels[p['lo'] if side==1 else p['hi']].append(p)
        ordered=sorted(levels,reverse=side<0)
        for gate,edge in zip(ordered,ordered[1:]):
            # An edge is a single price even when several named targets share it.
            # The closest edge has a separate near12 rule and has no inner gate.
            score=max(p['score'] for p in levels[edge])
            if score<50:
                yield side,gate,edge,score


def landmark(prices,side,gate,edge):
    cross=None
    for i,b in enumerate(prices):
        # A jump past the far target can already invalidate the original target.
        if (b.high>=edge if side==1 else b.low<=edge):return None
        if cross is None:
            if (b.low<=gate<b.high if side==1 else b.low<gate<=b.high):cross=i
            elif (b.low>gate if side==1 else b.high<gate):return None
        elif i==cross+2:
            if prices[i-1].time!=prices[cross].time+M5 or b.time!=prices[i-1].time+M5:return None
            return i,all(side*(c.close-gate)>0 for c in prices[i-1:i+1])
    return None


def collect(snaps,bars):
    times=[b.time for b in bars]
    observations={}
    coverage=Counter();last=times[-1]+M5
    for s in sorted(snaps,key=lambda s:s['at']):
        if s['status']!='frozen':continue
        at=datetime.fromisoformat(s['at']);end=_deadline(at)
        if last<end:
            coverage['unfinished']+=1;continue
        prices=bars[bisect_left(times,at):bisect_left(times,end)]
        stamps={b.time for b in prices}
        expected=at
        while expected<end:
            if _research_open(expected) and expected not in stamps:break
            expected+=M5
        if expected<end:
            coverage['gap']+=1;continue
        width=s['median_h1']
        if width<=0:continue
        coverage['complete']+=1
        for side,gate,edge,score in candidates(s):
            checkpoint=landmark(prices,side,gate,edge)
            if checkpoint is None:continue
            i,held=checkpoint
            if i+1>=len(prices):continue
            known=prices[i].time+M5
            key=(known,side,gate,edge)
            if key in observations:continue
            suffix=prices[i+1:]
            touch=next((b.time+M5 for b in suffix if b.low<=edge<=b.high),None)
            remaining=(end-known).total_seconds()/3600
            distance=abs(edge-prices[i].close)/width
            wk=known.astimezone(NY).date()
            wk-=timedelta(days=wk.weekday())
            observations[key]=dict(issued=s['ny'],known=known.astimezone(NY).isoformat(),
                gate=gate,edge=edge,side=side,score=score,held=held,hit=bool(touch),week=str(wk),
                close=prices[i].close,distance_h1=distance,remaining_hours=remaining,
                hit_at=touch.astimezone(NY).isoformat() if touch else None)
    return list(observations.values()),dict(coverage)


def summarize(rows):
    weekly=defaultdict(Counter);counts=Counter()
    for r in rows:
        status='held' if r['held'] else 'other'
        counts[status]+=1;counts[status+'_hits']+=r['hit']
        cell=(r['side'],r['score']//10,int(r['distance_h1']*2),int(r['remaining_hours']*2))
        tally=weekly[r['week']]
        tally[(cell,status)]+=1;tally[(cell,status+'_hits')]+=r['hit']
    def standardized(pool):
        gains=total=0
        for cell in {key[0] for key in pool}:
            a,b=pool[cell,'held'],pool[cell,'other']
            if min(a,b)<5:continue
            gains+=pool[cell,'held_hits']-a*pool[cell,'other_hits']/b
            total+=a
        return (gains/total if total else None),total
    pooled=Counter()
    for w in weekly.values():pooled.update(w)
    gain,n=standardized(pooled)
    boot=[]
    rng=random.Random(221126)
    for _ in range(800 if n else 0):
        pool=Counter()
        for w in rng.choices(list(weekly.values()),k=len(weekly)):pool.update(w)
        diff,_=standardized(pool)
        if diff is not None:boot.append(diff)
    boot.sort()
    return dict(counts=counts,weeks=len(weekly),matched_held=n,
                matched_lift=gain,weekly_interval=[boot[int(.025*len(boot))],boot[int(.975*len(boot))]] if boot else None)


if __name__=='__main__':
    original=packed(SOURCE/'frozen.json.gz')
    groups=dict(discovery=[s for s in original if s['ny'][:10]<'2026-04-01']+packed(HERE/'low_extra_frozen.json.gz'),
                validation=[s for s in original if s['ny'][:10]>='2026-04-01']+packed(SOURCE/'validation_extra_frozen.json.gz'),
                recent=packed(SOURCE/'recent_frozen.json.gz'))
    bars=terminal_bars('XAUUSDM5')
    report={};ledger=[]
    for k,group in groups.items():
        rows,cov=collect(group,bars)
        report[k]=summarize(rows);report[k]['coverage']=cov
        ledger.extend(dict(sample=k,**r) for r in rows)
    report['allow_uplift']=all(report[k]['matched_held']>=30 and report[k]['weekly_interval']
                              and report[k]['weekly_interval'][0]>0 for k in ('validation','recent'))
    report['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (HERE/'near_sweep_summary.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    (HERE/'near_sweep_events.json.gz').write_bytes(gzip.compress(json.dumps(ledger,separators=(',',':')).encode(),mtime=0))
    print(json.dumps(report))
