"""Select a low-score adjustment in discovery, then evaluate the frozen choice."""
import argparse
import hashlib
import json
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path
from datetime import date,timedelta
sys.path.insert(0,str(Path(__file__).resolve().parent))
from verify import HERE,SOURCE,packed

RULES=('baseline','near_half','near_one','cluster_quarter','cluster_half')
LOCK=HERE/'low_score_lock.json'


def records(part):
    if part=='recent':
        snaps=packed(SOURCE/'recent_frozen.json.gz')
        outcomes='recent_outcomes.json.gz'
    else:
        early=packed(SOURCE/'frozen.json.gz')
        snaps=[s for s in early if (s['ny'][:10]<'2026-04-01')==(part=='discovery')]
        if part=='validation':
            snaps+=packed(SOURCE/'validation_extra_frozen.json.gz')
        outcomes='outcomes.json.gz' if part=='discovery' else 'validation_outcomes.json.gz'
    events={r['at']:r['outcome'] for r in packed(SOURCE/outcomes)}
    for s in sorted(snaps,key=lambda x:x['at']):
        o=events[s['at']]
        if o and o['category'] not in ('open','missing'):
            yield s,o


def features(s,o):
    levels={side:sorted({t['distance'] for t in s['targets'] if t['side']==side}) for side in (-1,1)}
    width=s['median_h1']
    results=[]
    for p,touch in zip(s['targets'],o['touch_closes']):
        dist=p['distance']
        edges=levels[p['side']]
        base=min(100,p['score']+12*(dist==edges[0] and dist<=width/4))
        if base>=50:
            continue
        reach=dist/width if width>0 else float('inf')
        comps=p['score_components']
        case=dict(base=base,hit=bool(touch),reach=reach,distance=dist,lo=p['lo'],hi=p['hi'],
                  side=p['side'],source=p['source'],rank=p['rank'],touch=touch,
                  alignment=comps['alignment'],discount=11-comps['obstacle'])
        # Cap at 49 to preserve the priority of independently validated higher bands.
        bumps=dict(baseline=0,near_half=8*(reach<=.5),near_one=8*(reach<=1))
        for rule,size in [('cluster_quarter',.25),('cluster_half',.5)]:
            previous=None
            groups=0
            for edge in edges:
                if previous is None or edge-previous>size*width:
                    previous=edge
                    groups+=1
                if edge==dist:break
            bumps[rule]=max(0,case['discount']-min(11,2*(groups-1))) if reach<=2 else 0
        case['scores']={k:min(49,base+v) for k,v in bumps.items()}
        results.append(case)
    return results


def evaluate(part,rules):
    factors=defaultdict(Counter)
    metrics={k:Counter() for k in rules}
    weeks=defaultdict(Counter)
    examples={}
    for s,o in records(part):
        low=features(s,o)
        if not low:continue
        day=date.fromisoformat(s['ny'][:10]);week=day-timedelta(days=day.weekday())
        for p in low:
            distance=p['reach']
            group='within_half' if distance<=.5 else 'half_to_one' if distance<=1 else 'one_to_two' if distance<=2 else 'over_two'
            tags=['all',group,'net_opposition' if p['alignment']<18 else 'neutral_or_aligned',
                  'three_plus_layers' if p['discount']>=6 else 'under_three_layers']
            for key in tags:
                factors[key]['count']+=1
                factors[key]['hits']+=p['hit']
            if p['hit']:
                earlier=any(t and t<p['touch'] and q['side']==p['side'] and q['distance']<p['distance']
                            for t,q in zip(o['touch_closes'],s['targets']))
                factors['all']['closer_same_side_hit_on_earlier_bar']+=earlier
        gains=[]
        winners=[p for p in low if p['hit']]
        losers=[p for p in low if not p['hit']]
        for k in rules:
            m=metrics[k];m['snapshots']+=1
            chosen=min(low,key=lambda p:(-p['scores'][k],p['distance'],p['lo'],p['hi']))
            m['top_low_hit']+=chosen['hit']
            if winners and losers:
                agreements=sum((a['scores'][k]>b['scores'][k])+0.5*(a['scores'][k]==b['scores'][k])
                               for a in winners for b in losers)
                m['auc_sum']+=agreements/(len(winners)*len(losers))
                m['mixed_snapshots']+=1
            for p in low:
                if p['scores'][k]>p['base']:
                    m['raised']+=1;m['raised_hit']+=p['hit']
            gains.append(chosen)
        if len(rules)==2:
            old,new=gains
            weeks[str(week)]['n']+=1
            weeks[str(week)]['delta']+=int(new['hit'])-int(old['hit'])
            if old['rank']!=new['rank']:
                case='improved' if new['hit'] and not old['hit'] else 'worsened' if old['hit'] and not new['hit'] else 'neutral'
                metrics[rules[-1]][case]+=1
                if case not in examples:
                    examples[case]=dict(ny=s['ny'],price=s['price'],original=old,challenger=new)
    for m in metrics.values():
        m['top_low_rate']=m['top_low_hit']/m['snapshots']
        m['within_snapshot_auc']=m['auc_sum']/m['mixed_snapshots']
        del m['auc_sum']
    ci=None
    if weeks:
        values=list(weeks.values());rng=random.Random(20261122)
        boot=[]
        for _ in range(2000):
            sample=rng.choices(values,k=len(values))
            boot.append(sum(x['delta'] for x in sample)/sum(x['n'] for x in sample))
        boot.sort();ci=[boot[49],boot[1949]]
    return dict(metrics=metrics,factors=factors,examples=examples,weekly_bootstrap_delta=ci)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('phase',choices=['discover','validate'])
    phase=parser.parse_args().phase
    if phase=='discover':
        result=evaluate('discovery',RULES)
        ranked=result['metrics']
        best=max(RULES,key=lambda k:(ranked[k]['top_low_rate'],ranked[k]['within_snapshot_auc']))
        lock=dict(rule=best,discovery=result,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
        with LOCK.open('x',encoding='utf-8') as f:json.dump(lock,f,ensure_ascii=False,indent=2)
        print(best,ranked)
    else:
        lock=json.loads(LOCK.read_bytes())
        assert lock['script_sha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        rules=['baseline',lock['rule']] if lock['rule']!='baseline' else ['baseline']
        report={p:evaluate(p,rules) for p in ('validation','recent')}
        (HERE/'low_score_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        for p,v in report.items():print(p,v['metrics'],v['weekly_bootstrap_delta'])


if __name__=='__main__': main()
