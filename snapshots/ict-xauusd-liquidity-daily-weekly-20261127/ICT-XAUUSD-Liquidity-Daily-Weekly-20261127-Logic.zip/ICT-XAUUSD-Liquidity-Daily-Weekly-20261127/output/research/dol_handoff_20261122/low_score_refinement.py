"""Lock one second-round rule before inspecting the unsampled winter holdout."""
import hashlib
import json
from pathlib import Path
import random
import sys
from collections import Counter,defaultdict
from datetime import date,timedelta

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from low_scores import features
from verify import packed

RULES=['baseline','distance_floor3','distance_floor5','break4','break8']
LOCK=HERE/'refinement_lock.json'


def score(rule,p,break_side):
    base=p['base']
    if rule.startswith('distance_floor'):
        slope=int(rule[-1])
        return max(base,min(49,49-round(slope*p['reach']))) if p['reach']<=2 else base
    if rule.startswith('break') and p['side']==break_side and p['reach']<=2:
        return min(49,base+int(rule[-1]))
    return base


def evaluate(group,outcomes,rule):
    counts=Counter()
    bins=defaultdict(lambda:defaultdict(Counter))
    weekly=defaultdict(Counter)
    examples={}
    for s in group:
        o=outcomes[s['at']]
        if not o or o['category'] in ('missing','open'):continue
        low=features(s,o)
        if not low:continue
        day=date.fromisoformat(s['ny'][:10])
        week=str(day-timedelta(days=day.weekday()))
        for p in low:
            p['new']=score(rule,p,s['recent_break'])
            raised=p['new']>p['base']
            cell=bins[p['base']//2][int(raised)]
            cell['n']+=1;cell['hits']+=p['hit']
            counts['low_targets']+=1;counts['low_hits']+=p['hit']
            if raised:
                counts['raised']+=1;counts['raised_hit']+=p['hit']
                tag='hit' if p['hit'] else 'miss'
                if tag not in examples:examples[tag]=dict(ny=s['ny'],price=s['price'],target=p)
        before=min(low,key=lambda p:(-p['base'],p['distance'],p['lo'],p['hi']))
        after=min(low,key=lambda p:(-p['new'],p['distance'],p['lo'],p['hi']))
        counts['n']+=1;counts['top_before']+=before['hit'];counts['top_after']+=after['hit']
        win=[p for p in low if p['hit']];loss=[p for p in low if not p['hit']]
        if not win or not loss:continue
        def auc(key):
            return sum((a[key]>b[key])+.5*(a[key]==b[key]) for a in win for b in loss)/(len(win)*len(loss))
        diff=auc('new')-auc('base')
        counts['mixed']+=1;counts['auc_delta_sum']+=diff
        weekly[week]['mixed']+=1;weekly[week]['delta']+=diff
    weighted=n=0
    for sides in bins.values():
        up,unchanged=sides[1],sides[0]
        if min(up['n'],unchanged['n'])<5:continue
        weighted+=up['hits']-up['n']*unchanged['hits']/unchanged['n']
        n+=up['n']
    rng=random.Random(221126)
    blocks=list(weekly.values());boot=[]
    for _ in range(2000):
        sample=rng.choices(blocks,k=len(blocks))
        boot.append(sum(s['delta'] for s in sample)/sum(s['mixed'] for s in sample))
    boot.sort()
    return dict(counts=counts,auc_delta=counts['auc_delta_sum']/counts['mixed'],
                auc_week_interval=[boot[49],boot[1949]],matched_n=n,
                matched_hit_lift=weighted/n if n else 0,examples=examples)


def main():
    frozen=packed(HERE/'low_extra_frozen.json.gz')
    outcomes={r['at']:r['outcome'] for r in packed(HERE/'low_extra_outcomes.json.gz')}
    hashes={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in
            ['low_score_refinement.py','low_extra_frozen.json.gz','low_extra_outcomes.json.gz']}
    phase=sys.argv[1]
    if phase=='discover':
        group=[s for s in frozen if s['ny'][:10]<'2025-12-01']
        results={r:evaluate(group,outcomes,r) for r in RULES}
        def qualifies(r):
            c=r['counts']
            return c['top_after']>=c['top_before'] and r['auc_delta']>=0 and r['matched_n']>=30 and r['matched_hit_lift']>0
        choices=[k for k in RULES[1:] if qualifies(results[k])]
        best=max(choices,key=lambda k:(results[k]['auc_delta'],results[k]['matched_hit_lift'])) if choices else 'baseline'
        with LOCK.open('x',encoding='utf8') as f:
            json.dump(dict(rule=best,hashes=hashes,discovery=results,first=group[0]['ny'],last=group[-1]['ny']),f,ensure_ascii=False,indent=2)
        print(best,[(k,v['auc_delta'],v['matched_hit_lift'],v['counts']['top_after']) for k,v in results.items()])
    elif phase=='validate':
        lock=json.loads(LOCK.read_bytes());assert lock['hashes']==hashes
        group=[s for s in frozen if s['ny'][:10]>='2025-12-01']
        result=evaluate(group,outcomes,lock['rule'])
        c=result['counts']
        passes=(lock['rule']!='baseline' and result['matched_n']>=30 and result['matched_hit_lift']>0 and
                c['top_after']>=c['top_before'] and result['auc_delta']>0 and result['auc_week_interval'][0]>=0)
        report=dict(rule=lock['rule'],passes=passes,first=group[0]['ny'],last=group[-1]['ny'],checkpoints=len(group),result=result)
        (HERE/'refinement_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        print(lock['rule'],passes,result['counts'],result['auc_week_interval'],result['matched_hit_lift'])
    else:raise ValueError(phase)


if __name__=='__main__':main()
