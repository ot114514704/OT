"""New chronological discovery and holdout on previously unsampled NY trading dates."""
from concurrent.futures import ProcessPoolExecutor
from datetime import date,timedelta
import gzip
import json
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from verify import SOURCE,packed
sys.path.insert(0,str(SOURCE))
import run


def freeze(d):
    rows=run.freeze(d)
    for s in rows:
        if s['status']!='frozen':
            continue
        end=run.si(s['at'])
        bars=run.slice_at(run.SERIES[0],run.TIMES[0],end-18*run.M,end)
        s['recent_break']=0
        if len(bars)==18 and s['median_h1']>0:
            ref=bars[:12]
            change=bars[-1].close-bars[12].open
            if abs(change)>=s['median_h1']/4:
                if change>0 and bars[-1].close>max(b.high for b in ref):s['recent_break']=1
                if change<0 and bars[-1].close<min(b.low for b in ref):s['recent_break']=-1
    return rows


if __name__=='__main__':
    observed={s['ny'][:10] for s in packed(SOURCE/'frozen.json.gz')}
    d=date(2025,8,4);days=[]
    while d<=date(2026,3,31):
        if d.weekday()<5 and d.isoformat() not in observed:days.append(d)
        d+=timedelta(days=1)
    with ProcessPoolExecutor(max_workers=5,initializer=run.inputs) as pool:
        rows=[s for ss in pool.map(freeze,days) for s in ss]
    run.inputs()
    events=[dict(at=s['at'],outcome=run.outcome(s) if s['status']=='frozen' else None) for s in rows]
    def save(name,data):
        (HERE/name).write_bytes(gzip.compress(json.dumps(data,ensure_ascii=False,separators=(',',':')).encode(),mtime=0))
    save('low_extra_frozen.json.gz',rows)
    save('low_extra_outcomes.json.gz',events)
    print(len(days),len(rows),rows[0]['ny'],rows[-1]['ny'])
