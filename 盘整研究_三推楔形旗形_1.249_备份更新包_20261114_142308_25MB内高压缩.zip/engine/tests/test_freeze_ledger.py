import json
from copy import deepcopy
from dataclasses import replace
from datetime import timedelta,timezone
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
import app
from ict_trader.freeze_ledger import FreezeLedger
from ict_trader.ipda_ranges import observe_ranges,phase_evidence
from tests.test_consolidation import fixture,append
from tests.test_consolidation_invariants import transformed


def sample(bars):
    observed=observe_ranges(bars,bars[-1].closed_at);boxes={};rows=[]
    for b,r in zip(bars,observed['rows']):
        e=phase_evidence(r,bars);box=e['range'] or e['ended']
        if box:boxes[box['id']]=box
        rows.append(dict(known_at=b.closed_at.isoformat(),consolidation_evidence=e))
    charts={'M15':dict(closed_end=bars[-1].closed_at.isoformat(),consolidations=list(boxes.values()),phase_rows=rows)}
    return charts,{'M15':[app.row(b) for b in bars]}


class FreezeLedgerTests(unittest.TestCase):
    def test_same_window_geometric_observers_keep_independent_active_identities(self):
        from ict_trader.freeze_ledger import active_ranges
        base=dict(window=8,observed_from='2026-01-01T00:00:00+00:00',geometry={},frozen_atr=1,side=0,streak=0)
        charts={'H1':dict(closed_end='2026-01-01T08:00:00+00:00',geometric_current=[
            dict(base,id='long_converging_candidate_v1:8:normal'),dict(base,id='long_converging_candidate_v1:edge:8:boundary')])}
        active=active_ranges(charts,{'H1':[]})
        self.assertEqual(set(active),{'H1:geometric:8','H1:geometric:8:edge'})
        self.assertNotEqual(active['H1:geometric:8']['range_id'],active['H1:geometric:8:edge']['range_id'])

    def setUp(self):
        self.directory=TemporaryDirectory();self.addCleanup(self.directory.cleanup)
        self.path=Path(self.directory.name)/'ledger.json'
        base=fixture();self.bars=[replace(base[i%12],time=base[0].time+timedelta(minutes=15*i)) for i in range(32)]
        self.charts,self.raw=sample(self.bars)
        self.ledger=FreezeLedger(self.path,'rules-a')

    def test_restart_reuses_frozen_facts_and_persistence_is_separate_from_prices(self):
        self.ledger.persist(self.charts,self.raw)
        restarted=FreezeLedger(self.path,'rules-a');report=restarted.inspect(self.charts,self.raw)
        self.assertTrue(report['passed']);self.assertEqual(report['previously_recorded'],1)
        self.assertTrue(restarted.active);self.assertEqual(report['source_revisions'],[])
        saved=json.loads(self.path.read_text(encoding='utf-8'))
        self.assertNotIn('raw',saved);self.assertNotIn('open',json.dumps(saved['entries']))

    def test_unchanged_source_cannot_explain_boundary_or_first_confirmation_drift(self):
        self.ledger.persist(self.charts,self.raw);before=self.path.read_bytes()
        for field,value in [('low',98),('known_at','2026-01-01T03:15:00+00:00')]:
            changed=deepcopy(self.charts);changed['M15']['consolidations'][0][field]=value
            r=self.ledger.inspect(changed,self.raw)
            self.assertFalse(r['passed']);self.assertEqual(r['issues'][0]['code'],'unexplained_frozen_change')
            with self.assertRaises(ValueError):self.ledger.persist(changed,self.raw)
            self.assertEqual(self.path.read_bytes(),before)

    def test_actual_formation_revision_is_explicit_and_survives_restart(self):
        self.ledger.persist(self.charts,self.raw)
        charts,raw=sample(transformed(self.bars,1,10))
        r=self.ledger.inspect(charts,raw)
        self.assertTrue(r['passed']);self.assertEqual(r['source_revisions'][0]['reason'],'formation_source_changed')
        self.assertNotEqual(r['source_revisions'][0]['previous_bounds'],r['source_revisions'][0]['updated_bounds'])
        self.ledger.persist(charts,raw)
        restarted=FreezeLedger(self.path,'rules-a')
        self.assertTrue(restarted.revision_log);self.assertEqual(restarted.inspect(charts,raw)['source_revisions'],[])

    def test_truncated_source_preserves_proof_but_cannot_explain_a_changed_bound(self):
        self.ledger.persist(self.charts,self.raw);truncated={'M15':self.raw['M15'][4:]}
        self.assertTrue(self.ledger.inspect(self.charts,truncated)['passed'])
        self.ledger.persist(self.charts,truncated)
        changed=deepcopy(self.charts);changed['M15']['consolidations'][0]['low']-=.1
        r=self.ledger.inspect(changed,truncated)
        self.assertFalse(r['passed']);self.assertFalse(r['issues'][0]['source_coverage_complete'])

    def test_spread_change_cannot_explain_a_physical_boundary_change(self):
        self.ledger.persist(self.charts,self.raw);raw=deepcopy(self.raw);raw['M15'][0]['spread']+=1
        changed=deepcopy(self.charts);changed['M15']['consolidations'][0]['high']+=.1
        self.assertFalse(self.ledger.inspect(changed,raw)['passed'])

    def test_equivalent_time_labels_or_extra_prior_context_cannot_explain_price_drift(self):
        self.ledger.persist(self.charts,self.raw)
        equivalent=deepcopy(self.raw)
        from ict_trader.core import instant
        for r in equivalent['M15']:
            for k in ('time','closed_at'):r[k]=instant(r[k]).astimezone(timezone(timedelta(hours=1))).isoformat()
        changed=deepcopy(self.charts);changed['M15']['consolidations'][0]['low']-=.1
        self.assertFalse(self.ledger.inspect(changed,equivalent)['passed'])
        prior=[app.row(replace(b,time=b.time-timedelta(hours=3))) for b in self.bars[:12]]
        expanded={'M15':prior+self.raw['M15']}
        self.assertFalse(self.ledger.inspect(changed,expanded)['passed'])

    def test_reconstructed_identity_cannot_silently_replace_still_active_range(self):
        self.ledger.persist(self.charts,self.raw)
        charts,raw=sample(self.bars[1:])
        self.assertNotEqual(charts['M15']['consolidations'][0]['id'],self.charts['M15']['consolidations'][0]['id'])
        r=self.ledger.inspect(charts,raw)
        self.assertFalse(r['passed']);self.assertIn('unexplained_active_identity_change',[i['code'] for i in r['issues']])

    def test_confirmed_breakout_or_gap_can_end_previous_identity(self):
        for bars in (append(append(self.bars,100,103,99,102),102,105,101.5,104),
                     append(self.bars,100,101,99,100,gap=15)):
            self.ledger=FreezeLedger(self.path,'rules-a');self.ledger.persist(self.charts,self.raw)
            charts,raw=sample(bars)
            r=self.ledger.inspect(charts,raw)
            self.assertTrue(r['passed'],r['issues'])

    def test_invalid_persistent_record_is_not_silently_reset(self):
        self.path.write_text('{"entries":',encoding='utf-8')
        broken=FreezeLedger(self.path,'rules-a');r=broken.inspect(self.charts,self.raw)
        self.assertFalse(r['passed']);self.assertEqual(r['issues'][0]['code'],'ledger_unreadable')
        with self.assertRaises(ValueError):broken.persist(self.charts,self.raw)
        self.assertEqual(self.path.read_text(encoding='utf-8'),'{"entries":')

    def test_failed_atomic_replace_keeps_last_record_and_can_be_retried(self):
        self.ledger.persist(self.charts,self.raw);before=self.path.read_bytes();entries=deepcopy(self.ledger.entries)
        charts,raw=sample(transformed(self.bars,1,10))
        with patch('pathlib.Path.replace',side_effect=OSError('disk unavailable')):
            with self.assertRaises(OSError):self.ledger.persist(charts,raw)
        self.assertEqual(self.path.read_bytes(),before);self.assertEqual(self.ledger.entries,entries)
        self.ledger.persist(charts,raw)
        self.assertTrue(FreezeLedger(self.path,'rules-a').inspect(charts,raw)['passed'])
