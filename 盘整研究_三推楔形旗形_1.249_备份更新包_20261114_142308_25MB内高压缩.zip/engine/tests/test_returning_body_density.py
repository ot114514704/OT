import hashlib
import json
import unittest
from dataclasses import replace
from datetime import timedelta
from pathlib import Path

from ict_trader.core import Bar, instant
from ict_trader.dense_pauses import observe_dense_pauses, returning_body_density, PARAMETERS
from ict_trader.ipda_ranges import _candidate
from ict_trader.viewport_history import recognize
from ict_trader.display_selection import select_balance_first
from ict_trader.mt5_bridge import shape_record
from tests.test_consolidation_invariants import transformed


class ReturningBodyDensityTests(unittest.TestCase):
    def bars(self, name='h1_nov9_returning_pause.json'):
        raw=json.loads((Path(__file__).parent/'fixtures'/name).read_text('utf8'))
        if isinstance(raw,dict):raw=raw['bars']
        return [Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in raw]

    def test_native_red_box_is_causal_symmetric_and_a_candidate_only(self):
        original=self.bars();known=instant('2026-11-09T08:00:00+00:00')
        for scale,offset in ((1,0),(-1,9000),(10,300)):
            with self.subTest(scale=scale):
                b=transformed(original,scale,offset)
                out=observe_dense_pauses(b,b[-1].closed_at)
                target=next(x for x in out if x['metrics'].get('returning_body_density')
                            and x['observed_from']=='2026-11-09T04:00:00+00:00')
                self.assertEqual(target['known_at'],known.isoformat())
                self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
                self.assertFalse(target['metrics']['oscillation']['qualified'])
                self.assertEqual(target['metrics']['oscillation']['completed_legs'],2)
                self.assertFalse(any(x['id']==target['id'] for x in observe_dense_pauses(b,known-timedelta(seconds=1))))
                prefix=observe_dense_pauses(b,known)
                changed=[replace(x,open=x.open+500,high=x.high+500,low=x.low+500,close=x.close+500)
                         if x.closed_at>known else x for x in b]
                self.assertEqual(prefix,observe_dense_pauses(changed,known))
                frozen=next(x for x in prefix if x['id']==target['id'])
                for k in ('high','low','metrics','checks','known_at'):
                    self.assertEqual(frozen[k],target[k])
                self.assertEqual(target['display_end_at'],'2026-11-09T08:00:00+00:00')
                self.assertIn('四根回访密集候选',shape_record('H1','structural',target))
                selected=select_balance_first(recognize({'bars':b,'period':'H1'})['records'])
                self.assertTrue(any(target['id'] in x for x in selected))

    def test_directional_displacement_no_return_no_common_band_and_gaps_rejected(self):
        b=self.bars();s=next(i for i,x in enumerate(b) if x.time==instant('2026-11-09T04:00:00+00:00'))
        w=b[s:s+4]
        cases={
            'one_way':[replace(x,open=4120+i*.5,close=4120+(i+.6)*.5,high=4130,low=4114) for i,x in enumerate(w)],
            'large_bodies':[replace(x,open=x.low,close=x.high) for x in w],
            'no_return':w[:-1]+[replace(w[-1],close=4116,low=4114)],
            'unfinished_second_reversal':w[:-1]+[replace(w[-1],close=4123.9)],
            'no_common_band':w[:-1]+[replace(w[-1],open=4125.2,close=4126,low=4125,high=4126.3)],
            'one_sided_wicks':[replace(x,high=max(x.open,x.close)+.01) for x in w],
            'missing_bar':[replace(x,time=x.time+timedelta(hours=1)) if i>=2 else x for i,x in enumerate(w)],
        }
        for name,tail in cases.items():
            with self.subTest(case=name):
                z=b[:s]+tail
                self.assertFalse(returning_body_density(z,s,len(z)-1,_candidate(z,s,len(z)-1,PARAMETERS)))
        self.assertFalse(returning_body_density(w,0,3,_candidate(w,0,3,PARAMETERS)))
        quiet=[replace(x,open=4120,close=4120,high=4120.1,low=4119.9) for x in b[:s]]+w
        self.assertFalse(returning_body_density(quiet,s,len(quiet)-1,_candidate(quiet,s,len(quiet)-1,PARAMETERS)))

    def test_previous_mixed_history_observations_are_unchanged(self):
        b=self.bars('h1_july_adjacent_stages.json')
        previous=json.loads((Path(__file__).parent/'fixtures/v18_july_dense_record_hashes.json').read_text('utf8'))
        current={x['id']:x for x in observe_dense_pauses(b,b[-1].closed_at)}
        for key,digest in previous.items():
            with self.subTest(record=key):
                self.assertIn(key,current)
                actual=hashlib.sha256(json.dumps(current[key],sort_keys=True,separators=(',',':')).encode()).hexdigest()
                self.assertEqual(digest,actual)
