import unittest
import json
from pathlib import Path
from dataclasses import replace
from datetime import datetime,timedelta,timezone
from ict_trader.core import Bar
from ict_trader.dense_pauses import observe_dense_pauses,displacement_before,_observe_dense_pauses,PARAMETERS
from ict_trader.structural_ranges import observe_structures
from ict_trader.long_geometry import observe_long_geometry
from ict_trader.display_selection import select_balance_first
from tests.test_consolidation_invariants import transformed


def bars_fixture():
    start=datetime(2026,1,1,tzinfo=timezone.utc)
    vals=[0,1,2,1,0,-1,-2,-1]*8
    return [Bar(start+timedelta(hours=i),100+v-.15,101.25+v,98.75+v,100+v,0,3600) for i,v in enumerate(vals)]


class DensePauseTests(unittest.TestCase):
    def test_four_closed_bar_relay_preserves_old_identities_and_rejects_one_way_pause(self):
        start=datetime(2026,1,1,tzinfo=timezone.utc)
        prior=[Bar(start+timedelta(hours=i),82+3*i,85.2+3*i,81.8+3*i,85+3*i,0,3600) for i in range(6)]
        pause=[Bar(start+timedelta(hours=6+i),100+v-.3,103+v,97+v,100+v,0,3600) for i,v in enumerate((-1,1,-1,.7))]
        for scale,offset in ((1,0),(-1,300)):
            b=transformed(prior+pause,scale,offset)
            out=observe_dense_pauses(b,b[-1].closed_at)
            short=[x for x in out if x['window']==4]
            self.assertEqual(len(short),1)
            self.assertEqual(short[0]['preceding_direction'],scale)
            self.assertEqual(short[0]['metrics']['oscillation']['completed_legs'],2)
            self.assertFalse(short[0]['confirmed']);self.assertFalse(short[0]['score_included'])
            # Independent three-bar density candidates may already exist;
            # this four-bar formation must still wait for its own final close.
            self.assertFalse(any(x['id']==short[0]['id'] for x in observe_dense_pauses(b,b[-2].closed_at)))
            changed=b[:-1]+[replace(b[-1],high=500,close=400)]
            self.assertEqual(observe_dense_pauses(changed,b[-2].closed_at),observe_dense_pauses(b,b[-2].closed_at))
        self.assertFalse(observe_dense_pauses(pause,pause[-1].closed_at))
        one_way=[replace(x,open=99+i*.3,close=99.2+i*.3,high=102+i*.3,low=97+i*.3) for i,x in enumerate(pause)]
        self.assertFalse(observe_dense_pauses(prior+one_way,one_way[-1].closed_at))
        b=bars_fixture()
        old=_observe_dense_pauses(b,b[-1].closed_at,PARAMETERS['windows'])
        new=observe_dense_pauses(b,b[-1].closed_at)
        self.assertTrue(old)
        self.assertTrue(all(x in new for x in old))

    def test_five_bar_relay_needs_prior_impulse_and_completed_reversals(self):
        start=datetime(2026,1,1,tzinfo=timezone.utc)
        prior=[Bar(start+timedelta(hours=i),82+3*i,85.2+3*i,81.8+3*i,85+3*i,0,3600) for i in range(6)]
        pause=[Bar(start+timedelta(hours=6+i),100+v-.3,103+v,97+v,100+v,0,3600) for i,v in enumerate((-1,1,-1,1,-1))]
        for scale,offset in ((1,0),(-1,300)):
            b=transformed(prior+pause,scale,offset)
            out=observe_dense_pauses(b,b[-1].closed_at)
            self.assertTrue(any(x['window']==5 and x['preceding_direction']==scale for x in out))
            targets={x['id'] for x in out if x['window']==5}
            self.assertFalse(any(x['id'] in targets for x in observe_dense_pauses(b,b[-2].closed_at)))
        self.assertFalse(observe_dense_pauses(pause,pause[-1].closed_at))

    def test_native_adjacent_hourly_pauses_survive_exit_overlap_and_mirror(self):
        from ict_trader.mt5_bridge import shape_record
        raw=json.loads((Path(__file__).parent/'fixtures/h1_adjacent_continuation_pauses.json').read_text('utf-8'))['bars']
        bars=[Bar(datetime.fromisoformat(x['time']),*(x[k] for k in ('open','high','low','close')),0,3600) for x in raw]
        for scale,offset in ((1,0),(-1,9000)):
            b=transformed(bars,scale,offset);ranges=observe_dense_pauses(b,b[-1].closed_at)
            pauses=[x for x in ranges if x['metrics'].get('compact_relay') and x['window']>=5]
            self.assertEqual(len(pauses),2)
            self.assertEqual([x['observed_from'] for x in pauses],['2026-11-04T11:00:00+00:00','2026-11-04T19:00:00+00:00'])
            self.assertTrue(all(x['preceding_direction']==scale for x in pauses))
            self.assertTrue(all(x['display_end_at']<x['end_at'] for x in pauses))
            records=[shape_record('H1','structural',x) for x in pauses]
            self.assertEqual(len(select_balance_first(records)),2)
            prefix=observe_dense_pauses(b,b[16].closed_at)
            self.assertTrue(prefix)
            for x in prefix:
                full=next(y for y in ranges if x['id']==y['id'])
                self.assertEqual(x['metrics'],full['metrics'])
                self.assertEqual(x['high'],full['high'])
                self.assertFalse(x['confirmed'])
    def test_dense_pause_is_causal_and_does_not_confirm(self):
        b=bars_fixture();r=observe_dense_pauses(b,b[-1].closed_at)
        self.assertTrue(r)
        for end in (24,32,48):
            p=observe_dense_pauses(b[:end],b[end-1].closed_at)
            self.assertTrue(p)
            for x in p:
                later=next(y for y in r if y['id']==x['id'])
                for k in ('high','low','metrics','known_at'):self.assertEqual(x[k],later[k])
                self.assertFalse(x['confirmed']);self.assertFalse(x['score_included'])
        changed=b[:-1]+[replace(b[-1],high=500,close=400)]
        self.assertEqual(observe_dense_pauses(changed,b[-2].closed_at),observe_dense_pauses(b[:-1],b[-2].closed_at))
        from ict_trader.freeze_ledger import observations
        raw=[dict(time=x.time.isoformat(),closed_at=x.closed_at.isoformat(),open=x.open,high=x.high,low=x.low,close=x.close) for x in b]
        self.assertTrue(observations({'H1':{'structural_ranges':r}},{'H1':raw}))

    def test_trend_rejected_and_mirror_preserved(self):
        b=bars_fixture()
        trend=[replace(x,open=100+i,close=101+i,high=101.2+i,low=99.8+i) for i,x in enumerate(b)]
        self.assertFalse(observe_dense_pauses(trend,trend[-1].closed_at))
        a=observe_dense_pauses(b,b[-1].closed_at)
        mirror=observe_dense_pauses(transformed(b,-1,300),b[-1].closed_at)
        self.assertEqual([x['known_at'] for x in a],[x['known_at'] for x in mirror])

    def test_preceding_impulse_is_symmetric_and_exit_requires_followthrough(self):
        b=bars_fixture()
        impulse=[replace(x,open=70+3*i,close=73+3*i,high=73.2+3*i,low=69.8+3*i) for i,x in enumerate(b[:10])]
        self.assertEqual(displacement_before(impulse,10,2)['direction'],1)
        self.assertEqual(displacement_before(transformed(impulse,-1,300),10,2)['direction'],-1)
        p=observe_dense_pauses(b,b[-1].closed_at)[0]
        tail=[Bar(b[-1].closed_at+timedelta(hours=i),110+i,112+i,109+i,111+i,0,3600) for i in range(2)]
        self.assertTrue(observe_dense_pauses(b+tail[:1],tail[0].closed_at)[0]['active'])
        self.assertFalse(observe_dense_pauses(b+tail,tail[-1].closed_at)[0]['active'])
        self.assertEqual(p['high'],observe_dense_pauses(b+tail,tail[-1].closed_at)[0]['high'])

    def test_compact_scales_preserve_existing_records(self):
        from tests.test_structural_ranges import fixture
        b=fixture(100,.2)
        old=observe_structures(b,b[-1].closed_at)['ranges']
        new=observe_structures(b,b[-1].closed_at,short_channels=True)['ranges']
        self.assertTrue(all(x in new for x in old))
        self.assertTrue(any(x['window']<24 for x in new))
        from tests.test_long_geometry import LongGeometryTests
        LongGeometryTests.setUpClass();b=LongGeometryTests.bars
        old=observe_long_geometry(b,b[-1].closed_at)['ranges']
        new=observe_long_geometry(b,b[-1].closed_at,compact_scales=True)['ranges']
        self.assertTrue(all(x in new for x in old))


def row(key,shape,left,right,period='3600',kind='structural',dense=False):
    a=['0']*24;a[0]=period;a[1]=key;a[2]=shape;a[3]=kind;a[5]='10'
    a[12]=('dense_horizontal_pause_v1:' if dense else '')+key
    a[13]=str(left);a[15]=str(right);a[23]='观察 24 根'
    return '\t'.join(a)


class DisplaySelectionTests(unittest.TestCase):
    def test_same_hour_parent_retains_distinct_inner_shapes(self):
        outer=row('outer','rectangle',0,100).split('\t')
        outer[14]=outer[16]='120';outer[18]=outer[20]='90'
        rows=['\t'.join(outer)]
        for key,shape,left,right in [('triangle','converging',10,30),('channel','channel',35,50),('relay','rectangle',60,80)]:
            a=row(key,shape,left,right,dense=key=='relay').split('\t')
            a[14]=a[16]='115';a[18]=a[20]='95';rows.append('\t'.join(a))
        self.assertEqual(len(select_balance_first(rows)),4)
        # A crossing alternative cannot masquerade as an inner formation.
        cross=row('cross','channel',40,120).split('\t')
        cross[14]=cross[16]='115';cross[18]=cross[20]='95'
        self.assertEqual(select_balance_first(rows+['\t'.join(cross)]),select_balance_first(rows))
    def test_local_shapes_win_over_fitted_channel_without_erasing_input(self):
        rows=[row('channel','tilted',0,100),row('triangle','converging',0,40),
              row('pause','rectangle',50,80,dense=True),row('next','tilted',100,150)]
        original=list(rows);out=select_balance_first(rows)
        self.assertEqual([r.split('\t')[1] for r in out],['next','pause','triangle'])
        self.assertEqual(rows,original)
    def test_periods_are_independent_and_confirmed_balance_wins(self):
        rows=[row('a','rectangle',0,50,kind='local'),row('b','converging',0,50),
              row('c','converging',0,50,period='900')]
        self.assertEqual(len(select_balance_first(rows)),2)


if __name__=='__main__':unittest.main()
