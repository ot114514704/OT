import json,unittest
from pathlib import Path
from dataclasses import replace
from datetime import timedelta
from ict_trader.core import Bar,instant
from ict_trader.structural_ranges import observe_structures
from ict_trader.long_geometry import line_value
from ict_trader.mt5_bridge import shape_record
from tests.test_consolidation_invariants import transformed

class CompactChannelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw=json.loads((Path(__file__).parent/'fixtures/h1_july_compact_channel.json').read_text('utf8'))
        cls.bars=[Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in raw]

    def test_native_short_gap_uses_actual_time_and_frozen_causal_rails(self):
        for scale,offset in ((1,0),(-1,9000)):
            b=transformed(self.bars,scale,offset)
            out=observe_structures(b,b[-1].closed_at,short_channels=True)
            target=next(x for x in out['ranges'] if ':compact:6:' in x['id'])
            self.assertEqual(target['observed_from'],'2026-07-14T19:00:00+00:00')
            self.assertEqual(target['known_at'],'2026-07-15T02:00:00+00:00')
            self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
            g=target['geometry'];end=g['frame'][1]['time']
            self.assertAlmostEqual(g['frame'][1]['price'],line_value(g['upper'],end))
            self.assertAlmostEqual(g['frame'][2]['price'],line_value(g['lower'],end))
            known=instant(target['known_at'])
            at=observe_structures(b,known,short_channels=True)
            before=next(x for x in at['ranges'] if x['id']==target['id'])
            self.assertEqual(before['geometry'],g)
            self.assertEqual(before['last_upper'],g['frame'][1]['price'])
            self.assertEqual(before['last_lower'],g['frame'][2]['price'])
            self.assertIn('原始收盘完成折返',shape_record('H1','structural',target))
            changed=[replace(x,open=x.open+100,high=x.high+100,low=x.low+100,close=x.close+100) if x.closed_at>known else x for x in b]
            self.assertEqual(at,observe_structures(changed,known,short_channels=True))

    def test_one_way_leg_or_no_prior_impulse_is_rejected_and_long_gap_ends(self):
        b=self.bars
        trend=[replace(x,open=4000-i,close=3999.5-i,high=4001-i,low=3999-i) for i,x in enumerate(b)]
        self.assertFalse(any(':compact:' in x['id'] for x in observe_structures(trend,trend[-1].closed_at,short_channels=True)['ranges']))
        quiet=[replace(x,open=x.close,high=x.close+.1,low=x.close-.1) if x.time<instant('2026-07-14T19:00:00+00:00') else x for x in b]
        self.assertFalse(any(':compact:' in x['id'] for x in observe_structures(quiet,quiet[-1].closed_at,short_channels=True)['ranges']))
        prefix=[x for x in b if x.closed_at<=instant('2026-07-15T02:00:00+00:00')]
        gap=replace(b[len(prefix)],time=b[len(prefix)].time+timedelta(days=1))
        out=observe_structures(prefix+[gap],gap.closed_at,short_channels=True)
        target=next(x for x in out['ranges'] if ':compact:6:' in x['id'])
        self.assertFalse(target['active']);self.assertIn('数据间隔',target['status'])
