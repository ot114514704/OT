"""Historical indexes survive packaging without replacing existing evidence."""
from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from ict_trader.history_archive import HistoryArchive
from ict_trader.history_backup import snapshot_archives,restore_missing,_inspect,_digest
from ict_trader.viewport_history import VERSION


SOURCE='TradeMax Global Limited | TradeMaxGlobal-Live'


class HistoryBackupTests(unittest.TestCase):
    def archive(self,root,period='H1',source=SOURCE):
        archive=HistoryArchive(root,VERSION,source,period)
        with archive.connect() as db:
            db.execute('INSERT INTO scans VALUES (?,?,?,?)',('one','digest',1,100))
            db.execute('INSERT INTO records VALUES (?,?,?,?,?,?,?,?)',('one','id',1,100,10,100,99,'frozen original'))
        return archive.path

    def test_consistent_source_scoped_snapshot_and_restore_missing_only(self):
        with TemporaryDirectory() as directory:
            root=Path(directory);original=self.archive(root/'source');other=self.archive(root/'source',source='Other Broker')
            before=_digest(original)
            report=snapshot_archives(root/'source',root/'backup',SOURCE,VERSION)
            self.assertEqual([x['period'] for x in report['files']],['H1'])
            self.assertEqual(_digest(original),before);self.assertTrue(other.exists())
            result=restore_missing(root/'backup',root/'destination',SOURCE,VERSION)
            self.assertEqual(result['restored'],['H1']);self.assertFalse(result['existing_indexes_overwritten'])
            target=root/'destination'/original.name
            self.assertEqual(_digest(target),report['files'][0]['sha256'])
            self.assertEqual(_inspect(target),dict(scans=1,records=1))
            existing=_digest(target)
            second=restore_missing(root/'backup',root/'destination',SOURCE,VERSION)
            self.assertEqual(second['preserved_existing'],['H1']);self.assertEqual(_digest(target),existing)
            self.assertFalse(list((root/'destination').glob('*.pending')))
            with self.assertRaises(FileExistsError):snapshot_archives(root/'source',root/'backup',SOURCE,VERSION)

    def test_bad_digest_source_generation_and_filename_do_not_write_destination(self):
        with TemporaryDirectory() as directory:
            root=Path(directory);self.archive(root/'source');snapshot_archives(root/'source',root/'backup',SOURCE,VERSION)
            manifest=root/'backup/manifest.json';good=json.loads(manifest.read_text('utf-8'))
            for field,value in [('source','Other Broker'),('calculation_version','other-engine')]:
                bad=deepcopy(good);bad[field]=value;manifest.write_text(json.dumps(bad),encoding='utf-8')
                with self.assertRaises(ValueError):restore_missing(root/'backup',root/'destination',SOURCE,VERSION)
                self.assertFalse((root/'destination').exists())
            for field,value in [('sha256','bad'),('file','../outside.sqlite3')]:
                bad=deepcopy(good);bad['files'][0][field]=value;manifest.write_text(json.dumps(bad),encoding='utf-8')
                with self.assertRaises(ValueError):restore_missing(root/'backup',root/'destination',SOURCE,VERSION)
                self.assertFalse((root/'destination').exists())

    def test_existing_db_with_more_recent_observations_is_kept_verbatim(self):
        with TemporaryDirectory() as directory:
            root=Path(directory);self.archive(root/'source');snapshot_archives(root/'source',root/'backup',SOURCE,VERSION)
            current=self.archive(root/'destination')
            archive=HistoryArchive(root/'destination',VERSION,SOURCE,'H1')
            with archive.connect() as db:db.execute('UPDATE records SET line=?',('new source revision',))
            before=current.read_bytes()
            result=restore_missing(root/'backup',root/'destination',SOURCE,VERSION)
            self.assertEqual(result['preserved_existing'],['H1']);self.assertEqual(current.read_bytes(),before)


if __name__=='__main__':unittest.main()
