import json,unittest
from pathlib import Path
from dataclasses import replace
from datetime import timedelta
from ict_trader.core import Bar,instant
from ict_trader.dense_pauses import observe_dense_pauses
from ict_trader.mt5_bridge import shape_record
from ict_trader.display_selection import select_balance_first
from tests.test_consolidation_invariants import transformed

class ThreeBarStallTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw=json.loads((Path(__file__).parent/'fixtures/h1_october_bottom_stall.json').read_text('utf8'))
        cls.bars=[Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in raw]

    def test_native_bottom_stall_is_causal_symmetric_and_never_confirms_reversal(self):
        for scale,offset in ((1,0),(-1,9000)):
            b=transformed(self.bars,scale,offset)
            out=observe_dense_pauses(b,b[-1].closed_at)
            target=next(r for r in out if r['metrics'].get('three_bar_stall'))
            self.assertEqual(target['observed_from'],'2026-10-30T21:00:00+00:00')
            self.assertEqual(target['known_at'],'2026-10-31T00:00:00+00:00')
            self.assertEqual(target['metrics']['oscillation']['completed_legs'],1)
            self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
            self.assertFalse(target['continuation_observed'])
            self.assertEqual(target['preceding_direction'],-scale)
            known=instant(target['known_at'])
            self.assertFalse(any(r['metrics'].get('three_bar_stall') for r in observe_dense_pauses(b,known-timedelta(seconds=1))))
            changed=[replace(x,open=x.open+100,high=x.high+100,low=x.low+100,close=x.close+100) if x.closed_at>known else x for x in b]
            self.assertEqual(observe_dense_pauses(b,known),observe_dense_pauses(changed,known))
            rows=select_balance_first([shape_record('H1','structural',r) for r in out])
            self.assertTrue(any(target['id'] in row for row in rows))
            self.assertIn('仅一段',shape_record('H1','structural',target))

    def test_no_impulse_one_way_displacement_or_missing_bar_are_not_short_stalls(self):
        b=self.bars;s=next(i for i,x in enumerate(b) if x.time.isoformat().startswith('2026-10-30T21'))
        pause=b[s:s+3]
        self.assertFalse(observe_dense_pauses(pause,pause[-1].closed_at))
        one_way=[replace(x,open=3881-i*2,close=3880-i*2,high=3885-i*2,low=3875-i*2) for i,x in enumerate(pause)]
        for tail in (one_way,[replace(x,time=x.time+timedelta(hours=2)) if i else x for i,x in enumerate(pause)],
                     [replace(x,open=x.low,close=x.high) for x in pause]):
            z=b[:s]+tail
            self.assertFalse(any(r['metrics'].get('three_bar_stall') for r in observe_dense_pauses(z,z[-1].closed_at)))
