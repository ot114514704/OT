"""Restart recovery is history-only even when fresh quote timestamps align."""
from copy import deepcopy
from datetime import datetime,timedelta
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import Mock,patch

import app
from ict_trader.accepted_model import AcceptedModelStore
from ict_trader.current_consolidation import live_reports
from tests.executor_helpers import InlineExecutor
from tests.test_current_consolidation import chart,native_metadata
from tests.test_model_pipeline import DeferredExecutor
from tests.test_runtime_contract import LoopComplete


SOURCE=dict(status='verified',company='TradeMax Global Limited',server='TradeMaxGlobal-Live',symbol='XAUUSD')


def accepted():
    charts={}
    for period,seconds in [('H1',3600),('M15',900)]:
        c=chart();end=datetime.fromisoformat(c['closed_end'])
        c.update(period=period,bars=[dict(time=(end-timedelta(seconds=seconds)).isoformat(),
                    closed_at=end.isoformat(),open=100,high=102,low=98,close=101,spread=.1)])
        charts[period]=c
    return dict(charts=charts,status='connected',model_origin='native',model_revision='123',
                model_updated_at=100,market_source=deepcopy(SOURCE),
                latest_closed_end={p:c['closed_end'] for p,c in charts.items()},
                freeze_integrity=dict(passed=True,engine='engine',issues=[]))


class AcceptedModelTests(unittest.TestCase):
    def test_complete_roundtrip_and_atomic_failure_preserves_last_good_drawing(self):
        with TemporaryDirectory() as d:
            store=AcceptedModelStore(Path(d)/'model.json','engine','generation')
            first=accepted();store.save(first);saved=store.load()
            self.assertEqual(saved['charts'],first['charts'])
            self.assertEqual(set(saved['source']),{'company','server','symbol'})
            invalid=deepcopy(first);invalid['charts']['M15']['bars'][-1]['forming']=True
            with self.assertRaises(ValueError):store.save(invalid)
            self.assertEqual(store.load(),saved)
            doc=json.loads(store.path.read_text('utf-8'));doc['payload']['charts']['M15']['bars'][0]['close']=99
            store.path.write_text(json.dumps(doc),encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'完整性'):store.load()

    def test_engine_generation_and_source_mismatch_cannot_restore_as_this_model(self):
        with TemporaryDirectory() as d:
            path=Path(d)/'model.json';store=AcceptedModelStore(path,'engine','generation');store.save(accepted())
            for engine,generation in [('other','generation'),('engine','other')]:
                with self.subTest(engine=engine,generation=generation),self.assertRaises(ValueError):
                    AcceptedModelStore(path,engine,generation).load()
            for mutation in [lambda s:s.update(model_origin='snapshot'),lambda s:s.update(status='disconnected'),
                             lambda s:s.update(data_revision_pending=True),
                             lambda s:s['market_source'].update(server='OtherBroker'),
                             lambda s:s['freeze_integrity'].update(passed=False),
                             lambda s:s['latest_closed_end'].update(M15='2026-01-01T01:15:00+00:00'),
                             lambda s:s['charts']['M15']['phase_rows'][-1].update(known_at='2026-01-01T01:15:00+00:00')]:
                sample=accepted();mutation(sample)
                with self.subTest(sample=str(sample)[:100]),self.assertRaises(ValueError):store.save(sample)
            self.assertEqual(store.load()['model_revision'],'123')

    def test_fresh_aligned_quote_cannot_promote_restored_history_or_forming_signals(self):
        sample=native_metadata(dict(charts={'M15':chart()},quote={'bid':100},status='connected',polled_at=100,last_tick_change_at=100))
        sample['model_origin']='cached_history';sample['latest_closed_end']={'M15':chart()['closed_end']}
        sample['data_revision_pending']=False
        report=live_reports(sample,101)['M15']
        self.assertEqual(report['availability'],'history_recalculating')
        self.assertTrue(report['analysis_pending']);self.assertFalse(report['actionable_current'])
        self.assertIsNone(report['forming_observation']);self.assertEqual(report['candidate_observations'],[])
        sample['model_origin']='native'
        self.assertEqual(live_reports(sample,101)['M15']['availability'],'live')
        sample['model_origin']='cached_history';sample['status']='disconnected'
        self.assertEqual(live_reports(sample,101)['M15']['availability'],'disconnected')
        sample['status']='connected';sample['polled_at']=10
        self.assertEqual(live_reports(sample,101)['M15']['availability'],'stale')

    def exercise(self,*,corrupt=False,save_failure=False):
        original=deepcopy(app.STATE);seen=[];executor=DeferredExecutor()
        sample=native_metadata(dict(charts={'M15':chart()},quote={'bid':100}))
        raw={'M15':[dict(closed_at=chart()['closed_end'],close=100)]}
        cache=Mock();cache.load.return_value=dict(charts={'M15':{**chart(),'marker':'old'}},
                        model_revision='123',model_updated_at=100,saved_at=101)
        if corrupt:cache.load.side_effect=ValueError('broken file')
        if save_failure:cache.save.side_effect=OSError('disk full')
        def step(_):
            seen.append(deepcopy(app.STATE))
            if len(seen)==2:executor.complete(0)
            if len(seen)==4:raise LoopComplete()
        counter=0
        def native():
            nonlocal counter
            counter+=1
            return raw,deepcopy(sample['forming']),{**sample['quote'],'bid':100+counter}
        try:
            app.STATE.clear();app.STATE.update(status='starting',charts={})
            with patch.object(app,'load_seed',return_value=raw) as seed,patch.object(app,'calculate',return_value={'M15':{**chart(),'marker':'new'}}),patch.object(app,'native',side_effect=native),patch.object(app,'save_snapshot'),patch.object(app.time,'sleep',side_effect=step):
                with self.assertRaises(LoopComplete):app.worker(executor=executor,publication_executor=InlineExecutor(),freeze_store=False,history_store=False,model_store=cache)
            self.assertEqual([s['quote']['bid'] for s in seen],[101,102,103,104])
            if not corrupt:
                seed.assert_not_called()
                self.assertEqual([s['charts']['M15']['marker'] for s in seen],['old','old','new','new'])
                self.assertEqual([s['model_origin'] for s in seen],['cached_history','cached_history','native','native'])
                self.assertTrue(all(s['analysis_running'] for s in seen[:2]));self.assertEqual(len(executor.calls),1)
                cache.save.assert_called()
                self.assertEqual(cache.save.call_args.args[0]['model_origin'],'native')
                if save_failure:self.assertIn('disk full',seen[-1]['cache_error'])
            else:
                seed.assert_called_once();self.assertEqual(seen[0]['model_cache']['status'],'rejected')
                self.assertEqual(seen[-1]['model_origin'],'native')
        finally:app.STATE.clear();app.STATE.update(original)

    def test_blocked_fresh_recalculation_keeps_drawings_and_current_quotes(self):self.exercise()
    def test_cache_write_failure_does_not_disconnect_quotes_or_erase_accepted_model(self):self.exercise(save_failure=True)
    def test_corrupt_cache_falls_back_to_normal_calculation(self):self.exercise(corrupt=True)


if __name__=='__main__':unittest.main()
