import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from ict_trader.history_archive import HistoryArchive, merge_visible
from ict_trader.viewport_history import parse_request, process_request, VERSION
from tests.test_viewport_history import snapshot


def native_request(token='one', source='fixture broker'):
    lines=snapshot(token=token).splitlines();h=lines[0].split('\t')
    h[1]='2';h.append(source);lines[0]='\t'.join(h)
    return '\n'.join(lines)+'\n'


def record(request, identity='triangle', start=None, active=False, kind='converging'):
    a=int(request['bars'][0].time.timestamp()) if start is None else start
    z=int(request['bars'][-1].closed_at.timestamp())
    return '\t'.join(map(str,[3600,identity,kind,'geometric',a,a+3600,z,98,102,
        '三角收敛',int(active),'H1',identity,a,102,z,101,z,99,a,98,
        '形态候选·三角收敛','完成摆动 5 段','首次可知；候选未确认']))


def result(request, records):
    return dict(records=records,state='未满足盘整条件',count=len(request['bars']),
        start=int(request['bars'][0].time.timestamp()),end=int(request['bars'][-1].closed_at.timestamp()))


class HistoryArchiveTests(unittest.TestCase):
    def test_reopen_retains_all_geometry_and_details_without_stretching(self):
        r=parse_request(native_request())
        lines=[record(r,kind=k,identity=k) for k in ('rectangle','converging','channel')]
        with TemporaryDirectory() as d:
            HistoryArchive(d,VERSION,r['source'],'H1').remember(r,result(r,lines),'evidence')
            reopened=HistoryArchive(d,VERSION,r['source'],'H1')
            self.assertEqual(set(x[0] for x in reopened.visible(r['left'],r['right'],r['forming']).values()),set(lines))
            for source,period,version in [('other','H1',VERSION),(r['source'],'M15',VERSION),(r['source'],'H1','old')]:
                self.assertFalse(HistoryArchive(d,version,source,period).visible(r['left'],r['right'],r['forming']))

    def test_corrected_same_window_replaces_old_records(self):
        r=parse_request(native_request())
        with TemporaryDirectory() as d:
            archive=HistoryArchive(d,VERSION,r['source'],'H1')
            archive.remember(r,result(r,[record(r)]),'old')
            archive.remember(r,result(r,[]),'corrected')
            self.assertFalse(archive.visible(r['left'],r['right'],r['forming']))

    def test_finite_view_does_not_erase_complete_cross_boundary_formation(self):
        r=parse_request(native_request());line=record(r)
        with TemporaryDirectory() as d:
            archive=HistoryArchive(d,VERSION,r['source'],'H1');archive.remember(r,result(r,[line]),'old')
            new=result(r,[]);new['start']+=7200
            self.assertEqual(merge_visible(archive,r,new),[line])
            # Merely covering a formation does not invalidate a saved record.
            self.assertEqual(merge_visible(archive,r,result(r,[])),[line])

    def test_changed_view_context_keeps_finished_record_without_new_confirmation(self):
        r=parse_request(native_request());line=record(r)
        with TemporaryDirectory() as d:
            archive=HistoryArchive(d,VERSION,r['source'],'H1')
            archive.remember(r,result(r,[line]),'first-window')
            wider=result(r,[]);wider['start']-=86400;wider['end']+=86400
            changed={**r,'forming':r['forming']+86400}
            self.assertEqual(merge_visible(archive,changed,wider),[line])
            # An explicit correction of the actual saved window still removes it.
            archive.remember(r,result(r,[]),'corrected-window')
            self.assertEqual(merge_visible(archive,changed,wider),[])

    def test_current_identity_updates_saved_record_without_duplicate(self):
        r=parse_request(native_request());line=record(r,active=True)
        with TemporaryDirectory() as d:
            archive=HistoryArchive(d,VERSION,r['source'],'H1')
            archive.remember(r,result(r,[line]),'old')
            updated=record(r,active=False)
            self.assertEqual(merge_visible(archive,r,result(r,[updated])),[updated])

    def test_old_active_record_cannot_claim_current_state(self):
        r=parse_request(native_request());line=record(r,active=True)
        with TemporaryDirectory() as d:
            archive=HistoryArchive(d,VERSION,r['source'],'H1');archive.remember(r,result(r,[line]),'old')
            new=result(r,[]);new['start']+=7200;new['end']+=86400
            merged=merge_visible(archive,{**r,'forming':r['forming']+86400},new)[0].split('\t')
            self.assertEqual(merged[10],'0');self.assertIn('历史片段末观察',merged[21])
            self.assertIn('不代表现阶段',merged[23])
            self.assertEqual(merged[13:21],line.split('\t')[13:21])

    def test_future_cutoff_and_period_mismatch_are_not_accepted(self):
        r=parse_request(native_request());line=record(r)
        with TemporaryDirectory() as d:
            archive=HistoryArchive(d,VERSION,r['source'],'H1');archive.remember(r,result(r,[line]),'old')
            self.assertFalse(archive.visible(r['left'],r['right'],r['forming']-1))
            fields=line.split('\t');fields[5]=str(r['forming']+1)
            with self.assertRaises(ValueError):archive.remember(r,result(r,['\t'.join(fields)]),'future')
            fields=line.split('\t');fields[0]='900'
            with self.assertRaises(ValueError):archive.remember(r,result(r,['\t'.join(fields)]),'wrong')

    def test_background_page_survives_restart_and_is_available_to_view(self):
        r=parse_request(native_request());line=record(r)
        with TemporaryDirectory() as d:
            page=Path(d)/'backfill_test.request.tsv';page.write_text(native_request(),encoding='utf-8')
            with patch('ict_trader.viewport_history.recognize',return_value=result(r,[line])):
                self.assertTrue(process_request(page,Path(d)/'cache'))
            archive=HistoryArchive(Path(d)/'cache/archive',VERSION,r['source'],'H1')
            self.assertEqual(list(archive.visible(r['left'],r['right'],r['forming']).values())[0][0],line)
            view=Path(d)/'viewport_test.request.tsv';view.write_text(native_request(token='view'),encoding='utf-8')
            with patch('ict_trader.viewport_history.recognize',side_effect=AssertionError('Must reuse cache')):
                self.assertTrue(process_request(view,Path(d)/'cache'))
            reply=view.with_name('viewport_test.reply.tsv').read_text('utf-8')
            self.assertIn(line,reply);self.assertTrue(reply.endswith('END\tview\t1\n'))


if __name__=='__main__':unittest.main()
