"""Skipping unused diagnostics must preserve every dense-pause fact and gate."""
import unittest
from unittest.mock import patch
from dataclasses import replace
from ict_trader import dense_pauses, ipda_ranges
from tests.test_dense_pauses import bars_fixture
from tests.test_consolidation_invariants import transformed


class DenseProfileCostTests(unittest.TestCase):
    def test_candidate_default_keeps_diagnostics_and_all_other_fields_equal(self):
        bars=bars_fixture()
        with patch.object(ipda_ranges,'profile',wraps=ipda_ranges.profile) as build:
            full=ipda_ranges._candidate(bars,10,25,dense_pauses.PARAMETERS)
            self.assertEqual(build.call_count,1)
            light=ipda_ranges._candidate(bars,10,25,dense_pauses.PARAMETERS,include_profile=False)
            self.assertEqual(build.call_count,1)
        self.assertTrue(full['profile']);self.assertIsNone(light['profile'])
        self.assertEqual({k:v for k,v in full.items() if k!='profile'},
                         {k:v for k,v in light.items() if k!='profile'})

    def test_full_scanner_matches_diagnostic_path_for_mirrors_gaps_and_cutoffs(self):
        bars=bars_fixture();candidate=ipda_ranges._candidate
        for scale,offset in ((1,0),(-1,300)):
            b=transformed(bars,scale,offset)
            for cutoff in (b[23].closed_at,b[-1].closed_at):
                with patch.object(ipda_ranges,'profile',wraps=ipda_ranges.profile) as build:
                    actual=dense_pauses.observe_dense_pauses(b,cutoff)
                    self.assertEqual(build.call_count,0)
                def complete(*args,**kwargs):
                    return candidate(*args,**{**kwargs,'include_profile':True})
                with patch.object(dense_pauses,'_candidate',side_effect=complete):
                    expected=dense_pauses.observe_dense_pauses(b,cutoff)
                self.assertEqual(actual,expected)
                changed=b[:-1]+[replace(b[-1],high=max(500,b[-1].high),close=400)]
                self.assertEqual(dense_pauses.observe_dense_pauses(changed,b[-2].closed_at),
                                 dense_pauses.observe_dense_pauses(b[:-1],b[-2].closed_at))
        gap=bars[:32]+bars[40:]
        actual=dense_pauses.observe_dense_pauses(gap,gap[-1].closed_at)
        with patch.object(dense_pauses,'_candidate',side_effect=complete):
            self.assertEqual(actual,dense_pauses.observe_dense_pauses(gap,gap[-1].closed_at))


if __name__=='__main__':unittest.main()
