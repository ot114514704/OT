import json
import unittest
from pathlib import Path
from dataclasses import replace
from datetime import timedelta
from ict_trader.core import Bar,instant
from ict_trader.dense_pauses import observe_dense_pauses,impulse_density,PARAMETERS
from ict_trader.ipda_ranges import _candidate
from ict_trader.display_selection import select_balance_first
from ict_trader.mt5_bridge import shape_record
from tests.test_consolidation_invariants import transformed


class ImpulseDensityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        rows=json.loads((Path(__file__).parent/'fixtures/h1_july_impulse_density.json').read_text('utf8'))
        cls.cases=[[Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in r] for r in rows]
        cls.starts=['2026-07-13T21:00:00+00:00','2026-07-14T16:00:00+00:00',
                    '2026-07-22T17:00:00+00:00','2026-07-24T06:00:00+00:00']

    def test_four_native_red_mark_densities_are_causal_symmetric_and_candidates_only(self):
        for original,start in zip(self.cases,self.starts):
            for scale,offset in ((1,0),(-1,9000)):
                bars=transformed(original,scale,offset)
                ranges=observe_dense_pauses(bars,bars[-1].closed_at)
                target=next(x for x in ranges if x['metrics'].get('impulse_density') and x['observed_from']==start)
                self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
                known=instant(target['known_at'])
                before=observe_dense_pauses(bars,known-timedelta(seconds=1))
                self.assertFalse(any(x['id']==target['id'] for x in before))
                prefix=observe_dense_pauses(bars,known)
                self.assertTrue(any(x['id']==target['id'] for x in prefix))
                changed=[replace(b,open=b.open+500,high=b.high+500,low=b.low+500,close=b.close+500) if b.closed_at>known else b for b in bars]
                self.assertEqual(prefix,observe_dense_pauses(changed,known))
                selected=select_balance_first([shape_record('H1','structural',x) for x in ranges])
                self.assertTrue(any(target['id'] in x for x in selected),start)
                detail=shape_record('H1','structural',target)
                self.assertIn('密集停顿候选',detail);self.assertIn('不等于成熟双边盘整',detail)
                if start==self.starts[0]:
                    self.assertEqual(target['metrics']['oscillation']['completed_legs'],0)
                    self.assertFalse(target['metrics']['oscillation']['qualified'])
                    self.assertIn('尚无幅度合格',detail)

    def test_no_preceding_displacement_monotone_large_bodies_and_gap_are_rejected(self):
        for bars,start in zip(self.cases,self.starts):
            full=observe_dense_pauses(bars,bars[-1].closed_at)
            target=next(x for x in full if x['metrics'].get('impulse_density') and x['observed_from']==start)
            s=next(i for i,b in enumerate(bars) if b.time==instant(start));n=target['window'];w=bars[s:s+n]
            self.assertFalse(any(x['metrics'].get('impulse_density') for x in observe_dense_pauses(w,w[-1].closed_at)))
            one_way=[replace(b,open=4000+i,close=4000.8+i,high=4003+i,low=3998+i) for i,b in enumerate(w)]
            big_bodies=[replace(b,open=b.low,close=b.high) for b in w]
            missing=[replace(b,time=b.time+timedelta(hours=5)) if i else b for i,b in enumerate(w)]
            for tail in (one_way,big_bodies,missing):
                z=bars[:s]+tail
                c=_candidate(z,s,len(z)-1,PARAMETERS)
                self.assertFalse(impulse_density(z,s,len(z)-1,c))

