import json,unittest
from pathlib import Path
from dataclasses import replace
from datetime import timedelta
from ict_trader.core import Bar,instant
from ict_trader.dense_pauses import observe_dense_pauses
from ict_trader.structural_ranges import observe_structures
from ict_trader.viewport_history import recognize
from ict_trader.display_selection import select_balance_first
from tests.test_consolidation_invariants import transformed


class RevisitedExtensionTests(unittest.TestCase):
    def bars(self,name):
        rows=json.loads((Path(__file__).parent/'fixtures'/name).read_text('utf8'))
        return [Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in rows]

    def test_full_top_rectangle_is_observed_after_closed_rotations(self):
        for sign,offset in ((1,0),(-1,9000)):
            b=transformed(self.bars('h1_november_top_extension.json'),sign,offset)
            rows=observe_dense_pauses(b,b[-1].closed_at)
            target=next(x for x in rows if ':bodyrevisited12:' in x['id'] and x['observed_from']=='2026-11-05T04:00:00+00:00')
            self.assertEqual(target['known_at'],'2026-11-05T16:00:00+00:00')
            self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
            cutoff=instant(target['known_at'])
            self.assertFalse(any(x['id']==target['id'] for x in observe_dense_pauses(b,cutoff-timedelta(seconds=1))))
            prefix=observe_dense_pauses(b,cutoff)
            future=[replace(x,open=x.open+500,high=x.high+500,low=x.low+500,close=x.close+500) if x.closed_at>cutoff else x for x in b]
            self.assertEqual(prefix,observe_dense_pauses(future,cutoff))
            selected=select_balance_first(recognize({'bars':b,'period':'H1'})['records'])
            self.assertTrue(any(target['id'] in x for x in selected))

    def test_full_sloping_segment_keeps_original_and_residual_reversals(self):
        for sign,offset in ((1,0),(-1,9000)):
            b=transformed(self.bars('h1_october_revisited_channel.json'),sign,offset)
            out=observe_structures(b,b[-1].closed_at,short_channels=True)
            target=next(x for x in out['ranges'] if ':revisited:10:' in x['id'] and x['observed_from']=='2026-10-28T23:00:00+00:00')
            self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
            self.assertTrue(target['checks']['revisited_body']);self.assertTrue(target['checks']['full_amplitude_reversals'])
            cutoff=instant(target['known_at'])
            prefix=observe_structures(b,cutoff,short_channels=True)
            self.assertFalse(any(x['id']==target['id'] for x in observe_structures(b,cutoff-timedelta(seconds=1),short_channels=True)['ranges']))
            future=[replace(x,open=x.open+500,high=x.high+500,low=x.low+500,close=x.close+500) if x.closed_at>cutoff else x for x in b]
            self.assertEqual(prefix,observe_structures(future,cutoff,short_channels=True))
            selected=select_balance_first(recognize({'bars':b,'period':'H1'})['records'])
            self.assertTrue(any(':revisited:' in x and target['observed_from'] in x for x in selected))
            # First-observation anchors never change as the display extends.
            first=next(x for x in prefix['ranges'] if x['id']==target['id'])
            self.assertEqual(first['geometry'],target['geometry'])
            self.assertLess(instant(target['display_geometry']['frame'][1]['time']),instant(target['end_at']))

    def test_monotone_or_unrevisited_impulse_is_not_rescued(self):
        b=self.bars('h1_october_revisited_channel.json')
        trend=[replace(x,open=4000+i*2,close=4001+i*2,high=4003+i*2,low=3998+i*2) for i,x in enumerate(b)]
        self.assertFalse(any(':revisited:' in x['id'] for x in observe_structures(trend,trend[-1].closed_at,short_channels=True)['ranges']))
        self.assertFalse(any(':bodyrevisited' in x['id'] for x in observe_dense_pauses(trend,trend[-1].closed_at)))

    def test_prior_observer_identities_are_not_replaced(self):
        previous=json.loads((Path(__file__).parent/'fixtures/v15_extension_prior_identities.json').read_text('utf8'))
        for module,fixtures in previous.items():
            for fixture,identities in fixtures.items():
                b=self.bars(fixture);args={'short_channels':True} if module=='structure' else {}
                current=(observe_structures if module=='structure' else observe_dense_pauses)(b,b[-1].closed_at,**args)
                if module=='structure':current=current['ranges']
                self.assertTrue(set(identities)<={x['id'] for x in current})
