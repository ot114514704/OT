import json
import unittest
from pathlib import Path
from dataclasses import replace
from ict_trader.core import Bar,instant
from ict_trader.dense_pauses import observe_dense_pauses
from ict_trader.long_geometry import observe_long_geometry,line_value
from ict_trader.mt5_bridge import shape_record
from tests.test_consolidation_invariants import transformed


class WickAndExtensionTests(unittest.TestCase):
    def test_weekend_pause_preserves_actual_bars_and_rejects_weekday_missing_data(self):
        from datetime import timedelta
        raw=json.loads((Path(__file__).parent/'fixtures/h1_august_weekend_pause.json').read_text('utf8'))
        bars=[Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in raw]
        for scale,offset in ((1,0),(-1,9000)):
            b=transformed(bars,scale,offset)
            out=observe_dense_pauses(b,b[-1].closed_at)
            target=next(r for r in out if ':weekend24:' in r['id'])
            self.assertEqual(target['observed_from'],'2026-08-07T16:00:00+00:00')
            self.assertTrue(target['gaps']);self.assertFalse(target['confirmed'])
            self.assertFalse(target['score_included']);self.assertEqual(target['window'],24)
            at=instant(target['known_at'])
            self.assertTrue(any(r['id']==target['id'] for r in observe_dense_pauses(b,at)))
            shifted=[replace(x,time=x.time+timedelta(days=3)) for x in b]
            self.assertFalse(any(':weekend' in r['id'] for r in observe_dense_pauses(shifted,shifted[-1].closed_at)))

    def test_nested_native_pauses_are_found_inside_older_range_without_future_bars(self):
        raw=json.loads((Path(__file__).parent/'fixtures/h1_october_nested_pauses.json').read_text('utf8'))
        bars=[Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in raw]
        for scale,offset in ((1,0),(-1,9000)):
            b=transformed(bars,scale,offset)
            out=observe_dense_pauses(b,b[-1].closed_at)
            for start in ('2026-10-26T18:00:00+00:00','2026-10-27T19:00:00+00:00'):
                matches=[r for r in out if r['observed_from']==start and ':body' in r['id']]
                self.assertTrue(matches,start)
                target=matches[0];known=instant(target['known_at'])
                before=observe_dense_pauses(b,known)
                self.assertTrue(any(r['id']==target['id'] for r in before))
                self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
                self.assertLessEqual(target['window'],16)
            trend=[replace(x,open=4000+i*2,close=4001+i*2,high=4003+i*2,low=3998+i*2) for i,x in enumerate(b)]
            self.assertFalse(any(':body' in r['id'] for r in observe_dense_pauses(trend,trend[-1].closed_at)))

    def test_native_june_wick_pause_and_mirror_are_causal(self):
        raw=json.loads((Path(__file__).parent/'fixtures/h1_june_wick_balance.json').read_text('utf8'))
        bars=[Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in raw]
        for scale,offset in ((1,0),(-1,9000)):
            b=transformed(bars,scale,offset)
            full=observe_dense_pauses(b,b[-1].closed_at)
            target=next(x for x in full if x['metrics'].get('wick_balance') and x['observed_from'].startswith('2026-06-18T04'))
            self.assertEqual(target['known_at'],'2026-06-18T08:00:00+00:00')
            self.assertEqual(target['metrics']['oscillation']['completed_legs'],2)
            self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
            self.assertIn('长影线密集候选',shape_record('H1','structural',target))
            prefix=observe_dense_pauses(b,instant(target['known_at']))
            self.assertTrue(any(x['id']==target['id'] for x in prefix))
            self.assertFalse(any(x['id']==target['id'] for x in observe_dense_pauses(b,instant('2026-06-18T07:59:59+00:00'))))
        pause=bars[7:11]
        monotone=[replace(x,open=4310+i,close=4310.5+i,high=4330+i,low=4300+i) for i,x in enumerate(pause)]
        self.assertFalse(any(x['metrics'].get('wick_balance') for x in observe_dense_pauses(monotone,monotone[-1].closed_at)))

    def test_extension_uses_frozen_rails_contained_closed_bars_and_bridge_vertices(self):
        raw=json.loads((Path(__file__).parent/'fixtures/ascending_triangle_native_m15.json').read_text('utf8'))['bars']
        b=[Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=900) for x in raw]
        full=observe_long_geometry(b,b[-1].closed_at)['ranges']
        extended=[x for x in full if x.get('display_geometry')]
        self.assertTrue(extended)
        for x in extended:
            g=x['geometry'];d=x['display_geometry'];end=d['frame'][1]['time']
            self.assertGreaterEqual(end,g['frame'][1]['time'])
            self.assertEqual(d['upper'],g['upper']);self.assertEqual(d['lower'],g['lower'])
            self.assertAlmostEqual(d['frame'][1]['price'],line_value(g['upper'],end))
            self.assertAlmostEqual(d['frame'][2]['price'],line_value(g['lower'],end))
            self.assertGreater(d['frame'][1]['price'],d['frame'][2]['price'])
            row=shape_record('M15','geometric',x).split('\t')
            self.assertEqual(int(row[15]),int(instant(end).timestamp()))
        cutoff=b[52].closed_at
        prefix=observe_long_geometry(b,cutoff)['ranges']
        changed=b[:53]+[replace(x,open=x.open+500,close=x.close+500,high=x.high+500,low=x.low+500) for x in b[53:]]
        self.assertEqual(prefix,observe_long_geometry(changed,cutoff)['ranges'])
