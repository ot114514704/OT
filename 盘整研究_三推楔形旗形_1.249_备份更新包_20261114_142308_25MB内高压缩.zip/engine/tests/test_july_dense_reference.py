import json
import unittest
from pathlib import Path
from datetime import datetime
from dataclasses import replace
from ict_trader.core import Bar
from ict_trader.dense_pauses import observe_dense_pauses, _observe_dense_pauses, PARAMETERS
from tests.test_consolidation_invariants import transformed


class JulyDenseReferenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw=json.loads((Path(__file__).parent/'fixtures/h1_july_dense_reference.json').read_text('utf-8'))
        cls.bars=[Bar(datetime.fromisoformat(b['time']),*(b[k] for k in ('open','high','low','close')),0,3600) for b in raw['bars']]

    def test_five_native_pauses_and_mirrored_scaled_prices(self):
        expected={'2026-07-23T11','2026-07-24T13','2026-07-27T06','2026-07-27T17','2026-07-28T05'}
        for scale,offset in ((1,0),(-1,9000),(10,200)):
            bars=transformed(self.bars,scale,offset)
            out=observe_dense_pauses(bars,bars[-1].closed_at)
            starts={x['observed_from'][:13] for x in out if ':tight:' in x['id']}
            self.assertTrue(expected<=starts,(scale,starts))
            for x in out:
                self.assertFalse(x['confirmed']);self.assertFalse(x['score_included'])
            legacy=_observe_dense_pauses(bars,bars[-1].closed_at,PARAMETERS['windows'])
            self.assertTrue(all(x in out for x in legacy))

    def test_each_new_birth_is_causal_and_unclosed_changes_are_ignored(self):
        bars=self.bars;full=observe_dense_pauses(bars,bars[-1].closed_at)
        for record in [x for x in full if ':tight:' in x['id']]:
            cutoff=datetime.fromisoformat(record['known_at'])
            prefix=[b for b in bars if b.closed_at<=cutoff]
            at_birth=observe_dense_pauses(prefix,cutoff)
            row=next(x for x in at_birth if x['id']==record['id'])
            for key in ('high','low','metrics','checks','known_at','observed_from'):
                self.assertEqual(row[key],record[key])
            i=len(prefix)
            if i<len(bars):
                forming=replace(bars[i],high=99999.,low=1.,close=90000.)
                self.assertEqual(at_birth,observe_dense_pauses(prefix+[forming],cutoff))

    def test_directional_runs_and_single_bar_never_qualify(self):
        for sign in (-1,1):
            bars=[replace(b,open=1000+sign*i,close=1000+sign*i+.1*sign,
                high=1001+sign*i,low=999+sign*i) for i,b in enumerate(self.bars)]
            self.assertFalse(observe_dense_pauses(bars,bars[-1].closed_at))
        self.assertFalse(observe_dense_pauses(self.bars[:1],self.bars[0].closed_at))

if __name__=='__main__':unittest.main()
