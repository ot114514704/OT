import json
import unittest
from pathlib import Path
from dataclasses import replace
from datetime import timedelta
from ict_trader.core import Bar,instant
from ict_trader.dense_pauses import observe_dense_pauses,common_core_density,impulse_density,PARAMETERS
from ict_trader.ipda_ranges import _candidate
from ict_trader.viewport_history import recognize
from ict_trader.display_selection import select_balance_first
from ict_trader.mt5_bridge import shape_record
from tests.test_consolidation_invariants import transformed


class CommonCoreDensityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        rows=json.loads((Path(__file__).parent/'fixtures/h1_july15_common_core.json').read_text('utf8'))
        cls.bars=[Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in rows]
        cls.start=instant('2026-07-15T21:00:00+00:00')
        cls.known=instant('2026-07-16T00:00:00+00:00')

    def test_native_long_wick_pause_is_causal_symmetric_and_selected(self):
        for scale,offset in ((1,0),(-1,9000),(10,0)):
            bars=transformed(self.bars,scale,offset)
            records=observe_dense_pauses(bars,self.known)
            target=next(x for x in records if x['observed_from']==self.start.isoformat()
                        and x['metrics'].get('common_core_density'))
            self.assertEqual(target['known_at'],self.known.isoformat())
            self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
            self.assertFalse(target['metrics']['oscillation']['qualified'])
            self.assertEqual(target['metrics']['oscillation']['completed_legs'],1)
            self.assertFalse(any(x['id']==target['id'] for x in observe_dense_pauses(bars,self.known-timedelta(seconds=1))))
            changed=[replace(b,open=b.open+500,high=b.high+500,low=b.low+500,close=b.close+500)
                     if b.closed_at>self.known else b for b in bars]
            self.assertEqual(records,observe_dense_pauses(changed,self.known))
            detail=shape_record('H1','structural',target)
            self.assertIn('长影线共同接受区',detail)
            self.assertIn('不等于成熟双边盘整',detail)
            final=select_balance_first(recognize({'bars':bars,'period':'H1'})['records'])
            # The four-bar observer can represent the same complete cluster.
            # Require the cluster to survive, not duplicate 3/4-bar drawings.
            self.assertTrue(any(':core' in x and self.start.isoformat() in x for x in final))

    def test_existing_density_thresholds_remain_unchanged(self):
        s=next(i for i,b in enumerate(self.bars) if b.time==self.start)
        c=_candidate(self.bars,s,s+2,PARAMETERS)
        self.assertFalse(impulse_density(self.bars,s,s+2,c))
        self.assertTrue(common_core_density(self.bars,s,s+2,_candidate(self.bars,s,s+2,PARAMETERS)))

    def test_impulse_overlap_alone_and_monotone_closes_do_not_qualify(self):
        s=next(i for i,b in enumerate(self.bars) if b.time==self.start)
        tail=self.bars[s:s+3]
        # Keep common wicks but remove the observed endpoint reversal.
        monotone=[replace(b,open=4058+i,close=4059+i,high=4065,low=4050) for i,b in enumerate(tail)]
        # Small bodies and a reversal are insufficient without a common band.
        separated=[replace(b,high=4062.5 if i==0 else 4066 if i==1 else b.high,low=4063 if i==1 else b.low,
                           open=4063 if i==1 else b.open,close=4064 if i==1 else b.close)
                   for i,b in enumerate(tail)]
        for w in (monotone,separated):
            b=self.bars[:s]+w
            self.assertFalse(common_core_density(b,s,len(b)-1,_candidate(b,s,len(b)-1,PARAMETERS)))
        self.assertFalse(common_core_density(tail,0,2,_candidate(tail,0,2,PARAMETERS)))
        missing=self.bars[:s]+[replace(b,time=b.time+timedelta(hours=5)) for b in tail]
        self.assertFalse(common_core_density(missing,s,len(missing)-1,_candidate(missing,s,len(missing)-1,PARAMETERS)))
