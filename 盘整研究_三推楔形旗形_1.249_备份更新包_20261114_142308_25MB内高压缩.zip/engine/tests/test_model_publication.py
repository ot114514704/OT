"""Blocked validation/writes must not block independent market polling."""
import threading,unittest
from copy import deepcopy
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import Mock,patch
import app
from ict_trader.model_publication import PublicationRunner
from tests.executor_helpers import InlineExecutor
from tests.test_model_pipeline import DeferredExecutor
from tests.test_current_consolidation import chart,native_metadata
from tests.test_runtime_contract import LoopComplete


class PublicationTests(unittest.TestCase):
    def test_only_one_publication_and_revision_bound_errors_can_be_retried(self):
        executor=DeferredExecutor();runner=PublicationRunner(executor,lambda *a:{'done':True})
        self.assertTrue(runner.start({'model_revision':'a'}, {}, 'k',None))
        self.assertFalse(runner.start({'model_revision':'b'}, {}, 'k2',None))
        self.assertIsNone(runner.take_ready());self.assertEqual(len(executor.calls),1)
        executor.complete(0,error=OSError('disk failure'))
        revision,result,error=runner.take_ready()
        self.assertEqual(revision,'a');self.assertIsInstance(error,OSError)
        self.assertTrue(runner.start({'model_revision':'b'}, {}, 'k2',None))
        executor.complete(1)
        revision,result,error=runner.take_ready()
        self.assertEqual(revision,'b');self.assertTrue(result['done']);self.assertIsNone(error)

    def exercise(self,blocked_stage):
        original=deepcopy(app.STATE);sample=native_metadata(dict(charts={'M15':chart()},quote={'bid':100}))
        raw={'M15':[dict(closed_at='2026-01-01T01:00:00+00:00',close=100)]}
        changed=deepcopy(raw);changed['M15'][0]['close']=101
        started=threading.Event();release=threading.Event();finished=threading.Event();seen=[]
        ledger=Mock();ledger.public.side_effect=lambda r:r
        inspections=0
        def inspect(*args):
            nonlocal inspections
            inspections+=1
            if blocked_stage=='validation' and inspections==2:
                started.set()
                if not release.wait(3):raise TimeoutError('test validation unreleased')
            return dict(passed=True,issues=[])
        ledger.inspect.side_effect=inspect;ledger.persist.return_value=dict(passed=True)
        def save(*args):
            if blocked_stage=='persistence':
                started.set()
                if not release.wait(3):raise TimeoutError('test publication unreleased')
        with ThreadPoolExecutor(max_workers=1) as model_pool,ThreadPoolExecutor(max_workers=1) as publish_pool:
            class ModelExecutor:
                calls=0
                def submit(inner,fn,*args):
                    inner.calls+=1
                    executor=InlineExecutor() if inner.calls==1 or blocked_stage=='persistence' else model_pool
                    future=executor.submit(fn,*args)
                    if blocked_stage=='validation' and inner.calls==2:future.add_done_callback(lambda f:finished.set())
                    return future
            class PublishExecutor:
                def submit(inner,fn,*args):
                    future=publish_pool.submit(fn,*args)
                    if blocked_stage=='persistence':future.add_done_callback(lambda f:finished.set())
                    return future
            calls=0
            def native():
                nonlocal calls
                calls+=1
                return (changed if blocked_stage=='validation' else raw),deepcopy(sample['forming']),{**sample['quote'],'bid':100+calls,'ask':100.1+calls}
            def step(_):
                self.assertTrue(started.wait(1));seen.append(deepcopy(app.STATE))
                if len(seen)==3:
                    release.set();self.assertTrue(finished.wait(1))
                if len(seen)==4:raise LoopComplete()
            try:
                app.STATE.clear();app.STATE.update(status='starting',charts={})
                with patch.object(app,'load_seed',return_value=raw),patch.object(app,'calculate',return_value={'M15':chart()}),patch.object(app,'native',side_effect=native),patch.object(app,'save_snapshot',side_effect=save),patch.object(app.time,'sleep',side_effect=step):
                    with self.assertRaises(LoopComplete):app.worker(executor=ModelExecutor(),publication_executor=PublishExecutor(),freeze_store=ledger,history_store=False)
                self.assertEqual([x['quote']['bid'] for x in seen],[101,102,103,104])
                self.assertTrue(all(x['status']=='connected' for x in seen))
                if blocked_stage=='validation':self.assertTrue(all(x['analysis_running'] for x in seen[:3]))
                else:self.assertTrue(all(x['publication_running'] for x in seen[:3]))
            finally:
                release.set();app.STATE.clear();app.STATE.update(original)

    def test_actual_blocked_freeze_validation_keeps_reading_quotes(self):self.exercise('validation')
    def test_actual_blocked_model_persistence_keeps_reading_quotes(self):self.exercise('persistence')
