"""Actual simultaneous H1/M15 export, not an isolated recognition window."""
import json
import unittest
from pathlib import Path
from ict_trader.display_selection import select_balance_first, nested_overlap


class LiveDisplayOverlapTests(unittest.TestCase):
    def rows(self):
        return json.loads((Path(__file__).parent/'fixtures/nov9_live_display_overlap.json').read_text('utf8'))

    def test_native_pause_survives_later_wide_range_and_disabled_projection(self):
        rows=self.rows();original=list(rows)
        for direction,offset in ((1,0),(-1,9000),(10,300)):
            changed=[]
            for line in rows:
                a=line.split('\t')
                for hi,lo in ((7,8),(14,20),(16,18)):
                    x,y=float(a[hi])*direction+offset,float(a[lo])*direction+offset
                    # 7/8 are low/high; frame pairs are high/low.
                    a[hi],a[lo]=map(str,(min(x,y),max(x,y)) if hi==7 else (max(x,y),min(x,y)))
                changed.append('\t'.join(a))
            selected=select_balance_first(changed)
            self.assertEqual(len(selected),2)
            self.assertTrue(any(':return4:' in x for x in selected))
            self.assertTrue(any(':body12:' in x for x in selected))
            self.assertFalse(any('\tintraday\t' in x for x in selected))
            self.assertEqual(selected,select_balance_first(changed[::-1]))
            self.assertTrue(set(selected)<=set(changed))
        self.assertEqual(original,rows)

    def test_edge_exception_rejects_crossed_rails_duplicates_and_distant_stages(self):
        rows=[x.split('\t') for x in self.rows()]
        child=next(x for x in rows if ':return4:' in x[12])
        outer=next(x for x in rows if ':body12:' in x[12])
        self.assertTrue(nested_overlap(outer,child))
        for kind in ('channel','converging'):
            a=child.copy();a[2]=kind
            self.assertFalse(nested_overlap(outer,a))
        a=child.copy();a[13]=str(int(a[13])-3600)
        self.assertFalse(nested_overlap(outer,a))
        a=child.copy();a[5]=outer[5]
        self.assertFalse(nested_overlap(outer,a))
        a=child.copy();a[14]=a[16]='4200';a[18]=a[20]='4180'
        self.assertFalse(nested_overlap(outer,a))
        a=child.copy();a[0]='900'
        self.assertFalse(nested_overlap(outer,a))


if __name__=='__main__':unittest.main()
