"""Independent dense observers must retain their original facts and causality."""
from dataclasses import replace
import unittest
from unittest.mock import patch
from ict_trader import dense_pauses as dense
from tests.test_dense_pauses import bars_fixture
from tests.test_consolidation_invariants import transformed


class UncachedCandidates:
    def __init__(self,bars,asof):
        self.bars=dense.visible(bars,asof)

    def __call__(self,start,end):
        return dense._candidate(self.bars,start,end,dense.PARAMETERS,include_profile=False)


class DenseWindowCacheTests(unittest.TestCase):
    def test_independent_qualifiers_cannot_mutate_cached_evidence(self):
        bars=bars_fixture();cache=dense._DenseCandidateCache(bars,bars[-1].closed_at)
        original=cache(10,25)
        def containers(value):
            if isinstance(value,dict):
                return {id(value)}.union(*(containers(item) for item in value.values()))
            if isinstance(value,list):
                return {id(value)}.union(*(containers(item) for item in value))
            return set()
        with patch.object(dense,'_candidate',wraps=dense._candidate) as build:
            changed=cache(10,25)
            self.assertFalse(containers(changed)&containers(original))
            self.assertFalse(containers(changed)&containers(cache.windows[(10,25)]))
            changed['checks'].clear()
            changed['metrics']['oscillation']['completed_legs']=-100
            changed['metrics']['extra']=['mutable']
            self.assertEqual(cache(10,25),original)
            self.assertEqual(build.call_count,0)

    def test_scanner_matches_independent_calculation_and_reduces_work(self):
        bars=bars_fixture();counts=[]
        for cache_type in (dense._DenseCandidateCache,UncachedCandidates):
            with patch.object(dense,'_DenseCandidateCache',cache_type),patch.object(dense,'_candidate',wraps=dense._candidate) as build:
                result=dense.observe_dense_pauses(bars,bars[-1].closed_at)
                counts.append(build.call_count)
            if cache_type is UncachedCandidates:self.assertEqual(result,expected)
            else:expected=result
        self.assertLess(counts[0],counts[1])

    def test_cutoffs_mirrors_gaps_and_source_revisions_are_isolated(self):
        bars=bars_fixture()
        for scale,offset in ((1,0),(-1,300)):
            mirrored=transformed(bars,scale,offset)
            for b in (mirrored,mirrored[:32]+mirrored[40:]):
                for cutoff in (b[23].closed_at,b[-1].closed_at):
                    actual=dense.observe_dense_pauses(b,cutoff)
                    with patch.object(dense,'_DenseCandidateCache',UncachedCandidates):
                        self.assertEqual(actual,dense.observe_dense_pauses(b,cutoff))
                revised=b[:-1]+[replace(b[-1],high=500,close=400)]
                cutoff=b[-2].closed_at
                self.assertEqual(dense.observe_dense_pauses(revised,cutoff),dense.observe_dense_pauses(b,cutoff))
                with patch.object(dense,'_DenseCandidateCache',UncachedCandidates):
                    expected=dense.observe_dense_pauses(revised,revised[-1].closed_at)
                self.assertEqual(dense.observe_dense_pauses(revised,revised[-1].closed_at),expected)


if __name__=='__main__':unittest.main()
