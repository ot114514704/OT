import unittest
from concurrent.futures import ThreadPoolExecutor
from ict_trader.calculation_timing import CalculationTrace,measured


class CalculationTimingTests(unittest.TestCase):
    def test_results_errors_and_nested_contexts_preserved(self):
        marker=object()
        self.assertIs(measured('off',lambda:marker),marker)
        with CalculationTrace() as outer:
            self.assertIs(measured('first',lambda:marker),marker)
            with CalculationTrace() as inner:
                with self.assertRaisesRegex(ValueError,'same error'):
                    measured('failure',lambda:(_ for _ in ()).throw(ValueError('same error')))
            measured('second',lambda:None)
        self.assertEqual([r['stage'] for r in outer.stages],['first','second'])
        self.assertEqual([r['stage'] for r in inner.stages],['failure'])
        for row in outer.stages+inner.stages:
            self.assertGreaterEqual(row['wall_seconds'],0)
            self.assertGreaterEqual(row['thread_cpu_seconds'],0)

    def test_trace_not_leaked_to_other_threads(self):
        with CalculationTrace() as outer,ThreadPoolExecutor(max_workers=1) as pool:
            def compute():
                measured('untraced',lambda:None)
                with CalculationTrace() as own:measured('worker',lambda:None)
                return own.stages
            rows=pool.submit(compute).result()
            measured('parent',lambda:None)
        self.assertEqual([r['stage'] for r in outer.stages],['parent'])
        self.assertEqual([r['stage'] for r in rows],['worker'])
