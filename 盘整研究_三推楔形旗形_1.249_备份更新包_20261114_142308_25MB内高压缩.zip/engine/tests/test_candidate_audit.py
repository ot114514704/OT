"""Candidate-only formation audit rejects corrupt exports, not just old schemas."""
from copy import deepcopy
from dataclasses import replace
from datetime import timedelta
import json
from pathlib import Path
import unittest

from ict_trader.core import Bar,instant
from ict_trader.candidate_audit import candidate_evidence_errors
from ict_trader.dense_pauses import observe_dense_pauses
from ict_trader.structural_ranges import observe_structures
from ict_trader.long_geometry import observe_long_geometry
from tests.test_consolidation_invariants import transformed


class CandidateAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        def load(name):
            raw=json.loads((Path(__file__).parent/'fixtures'/name).read_text('utf-8'))
            if isinstance(raw,dict):raw=raw['bars']
            return [Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in raw]
        cls.dense=load('h1_nov9_returning_pause.json')
        cls.channel=load('h1_july_compact_channel.json')
        cls.mixed=load('h1_july_adjacent_stages.json')
        cls.examples=[]
        for family,bars,records in [
            ('structural',cls.dense,observe_dense_pauses(cls.dense,cls.dense[-1].closed_at)),
            ('structural',cls.channel,observe_structures(cls.channel,cls.channel[-1].closed_at,short_channels=True)['ranges']),
            ('geometric',cls.mixed,observe_long_geometry(cls.mixed,cls.mixed[-1].closed_at,compact_scales=True)['ranges'])]:
            for b in records:cls.examples.append((family,bars,b))

    def test_native_dense_compact_and_converging_exports_match_causal_formation(self):
        self.assertTrue(any(b['metrics'].get('returning_body_density') for _,_,b in self.examples))
        self.assertTrue(any(b['metrics'].get('compact_channel') for _,_,b in self.examples))
        self.assertTrue(any(k=='geometric' for k,_,_ in self.examples))
        for kind,bars,box in self.examples:
            with self.subTest(id=box['id']):
                original=deepcopy(box)
                self.assertEqual(candidate_evidence_errors(box,bars,kind),[])
                known=instant(box['first_observed_at'])
                future_changed=[replace(b,open=b.open+999,high=b.high+999,low=b.low+999,close=b.close+999)
                                if b.closed_at>known else b for b in bars]
                self.assertEqual(candidate_evidence_errors(box,future_changed,kind),[])
                self.assertEqual(box,original)

    def test_mutated_legs_geometry_checks_and_candidate_promotion_are_rejected(self):
        for kind,bars,box in self.examples:
            bad=deepcopy(box);bad['metrics']['oscillation']['completed_legs']+=1
            with self.subTest(id=box['id']):self.assertIn('candidate_frozen_metrics_source',candidate_evidence_errors(bad,bars,kind))
            bad=deepcopy(box);bad['confirmed']=True
            self.assertIn('candidate_confirmation_or_score',candidate_evidence_errors(bad,bars,kind))
            bad=deepcopy(box);key=next(iter(bad['checks']));bad['checks'][key]=False
            self.assertIn('candidate_formation_checks',candidate_evidence_errors(bad,bars,kind))
            if box.get('geometry'):
                bad=deepcopy(box);bad['geometry']['upper'][0]['price']+=1
                self.assertIn('candidate_frozen_geometry_source',candidate_evidence_errors(bad,bars,kind))

    def test_native_price_change_missing_source_unknown_observer_and_future_leg_fail(self):
        kind,bars,box=next(x for x in self.examples if x[2]['metrics'].get('returning_body_density'))
        changed=[replace(b,high=b.high+1) if b.time==instant(box['observed_from']) else b for b in bars]
        self.assertTrue(candidate_evidence_errors(box,changed,kind))
        missing=[b for b in bars if b.time!=instant(box['observed_from'])]
        self.assertIn('candidate_formation_source_coverage',candidate_evidence_errors(box,missing,kind))
        bad=deepcopy(box);bad['id']=bad['id'].replace(':return4:',':unrecognized:')
        self.assertIn('candidate_observer_unknown',candidate_evidence_errors(bad,bars,kind))
        bad=deepcopy(box);bad['metrics']['oscillation']['legs'][0]['reversal_observed_at']='2099-01-01T00:00:00+00:00'
        self.assertIn('candidate_frozen_metrics_source',candidate_evidence_errors(bad,bars,kind))

    def test_symmetric_price_transformation_keeps_audit_without_reclassifying_confirmation(self):
        for scale,offset in [(-1,9000),(10,300)]:
            bars=transformed(self.dense,scale,offset)
            boxes=observe_dense_pauses(bars,bars[-1].closed_at)
            b=next(x for x in boxes if x['metrics'].get('returning_body_density'))
            self.assertFalse(b['metrics']['oscillation']['qualified'])
            self.assertEqual(candidate_evidence_errors(b,bars,'structural'),[])


if __name__=='__main__':unittest.main()
