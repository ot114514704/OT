import json,unittest
from pathlib import Path
from dataclasses import replace
from ict_trader.core import Bar,instant
from ict_trader.long_geometry import observe_long_geometry
from ict_trader.mt5_bridge import shape_record
from ict_trader.display_selection import select_balance_first
from tests.test_consolidation_invariants import transformed

class PostDisplacementGeometryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw=json.loads((Path(__file__).parent/'fixtures/h1_july_post_displacement_triangle.json').read_text('utf8'))
        cls.bars=[Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in raw]

    def test_native_triangle_full_covered_span_is_causal_symmetric_and_selected(self):
        for scale,offset in ((1,0),(-1,9000)):
            bars=transformed(self.bars,scale,offset)
            out=observe_long_geometry(bars,bars[-1].closed_at,compact_scales=True)
            target=next(r for r in out['ranges'] if ':edge:12:' in r['id'])
            self.assertEqual(target['geometry']['subtype'],'triangle')
            self.assertEqual(target['geometry']['frame'][0]['time'],'2026-07-23T17:00:00+00:00')
            self.assertEqual(target['geometry']['frame'][1]['time'],'2026-07-24T04:00:00+00:00')
            self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
            self.assertNotIn('confirmed_boundary_pairs',target['checks'])
            self.assertTrue(any(p.get('anchor_kind')=='boundary_touch' for s in ('upper','lower') for p in target['geometry'][s]))
            known=instant(target['known_at'])
            prefix=observe_long_geometry(bars,known,compact_scales=True)
            self.assertEqual(target['geometry'],next(r for r in prefix['ranges'] if r['id']==target['id'])['geometry'])
            rows=select_balance_first([shape_record('H1','geometric',r) for r in out['ranges']])
            self.assertTrue(any(target['id'] in r for r in rows))
            changed=[replace(b,open=b.open+500,high=b.high+500,low=b.low+500,close=b.close+500) if b.closed_at>known else b for b in bars]
            self.assertEqual(prefix,observe_long_geometry(changed,known,compact_scales=True))

    def test_directional_leg_or_missing_prior_displacement_cannot_seed_boundary(self):
        b=self.bars
        trend=[replace(x,open=4000+i,close=4000.8+i,high=4002+i,low=3999+i) for i,x in enumerate(b)]
        self.assertFalse(observe_long_geometry(trend,trend[-1].closed_at,compact_scales=True)['ranges'])
        quiet=[replace(x,open=x.close,high=x.close+.1,low=x.close-.1) if x.time<instant('2026-07-23T17:00:00+00:00') else x for x in b]
        out=observe_long_geometry(quiet,quiet[-1].closed_at,compact_scales=True)
        self.assertFalse(any(':edge:12:' in r['id'] for r in out['ranges']))
