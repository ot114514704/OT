import json
import unittest
from pathlib import Path
from ict_trader.display_selection import select_balance_first,successive_formations


class FollowingTailOverlapTests(unittest.TestCase):
    def rows(self):
        return json.loads((Path(__file__).parent/'fixtures/may15_following_tail_overlap.json').read_text('utf8'))

    def test_actual_native_channel_and_later_box_both_survive(self):
        rows=self.rows();early=next(x for x in rows if '\tchannel\t' in x)
        later=next(x for x in rows if '\trectangle\t' in x)
        self.assertTrue(successive_formations(early.split('\t'),later.split('\t')))
        self.assertFalse(successive_formations(later.split('\t'),early.split('\t')))
        selected=select_balance_first(rows)
        self.assertEqual(set(selected),set(rows))
        self.assertEqual(selected,select_balance_first(rows[::-1]))
        # Selecting the two original records cannot stretch or merge rails.
        for line in selected:self.assertIn(line,rows)

    def test_mirrored_and_rescaled_prices_do_not_change_temporal_qualification(self):
        for scale,offset in ((-1,10000),(10,300)):
            rows=[]
            for line in self.rows():
                a=line.split('\t')
                for i,j in ((14,20),(16,18)):
                    x,y=float(a[i])*scale+offset,float(a[j])*scale+offset
                    a[i],a[j]=str(max(x,y)),str(min(x,y))
                rows.append('\t'.join(a))
            self.assertEqual(set(select_balance_first(rows)),set(rows))

    def test_concurrent_or_oversized_overlap_is_still_rejected(self):
        rows=[x.split('\t') for x in self.rows()]
        early=next(x for x in rows if x[2]=='channel');later=next(x for x in rows if x[2]=='rectangle')
        for field,value in ((5,str(int(later[13])+1)),(15,str(int(early[15])+3600)),(0,'900'),(3,'intraday')):
            changed=early.copy();changed[field]=value
            self.assertFalse(successive_formations(changed,later),(field,value))
        for field,value in ((5,str(int(early[15])-1)),(2,'converging'),(15,str(int(later[13])+3600))):
            changed=later.copy();changed[field]=value
            self.assertFalse(successive_formations(early,changed),(field,value))


if __name__=='__main__':unittest.main()
