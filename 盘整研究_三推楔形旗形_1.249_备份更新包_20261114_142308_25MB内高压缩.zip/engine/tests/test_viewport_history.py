"""Protocol and causal-data tests; no trade simulation or performance backtest."""
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from ict_trader.timeframes import TIMEFRAMES, consecutive_observations
from ict_trader.ipda_ranges import observe_ranges
from dataclasses import replace
from ict_trader.viewport_history import NativeBar, parse_request, process_request, recognize

UTC=timezone.utc


def snapshot(period='H1', token='chart-token', count=30, quote=123):
    start=datetime(2024,1,1,tzinfo=UTC)
    bars=[]
    for i in range(count):
        bar=NativeBar(start,100,102,98,101,0,seconds=TIMEFRAMES[period],calendar_month=period=='MN1')
        bars.append(bar);start=bar.closed_at
    body=['\t'.join(map(str,[int(b.time.timestamp()),int(b.closed_at.timestamp()),b.open,b.high,b.low,b.close,b.spread])) for b in bars]
    header=['IPDA_HISTORY','1',token,'XAUUSD',period,TIMEFRAMES[period],int(start.timestamp()),
            int(bars[0].time.timestamp()),int(start.timestamp()),count,quote]
    return '\n'.join(['\t'.join(map(str,header)),*body,f'END\t{token}\t{count}'])+'\n'


class ViewportHistoryTests(unittest.TestCase):
    def test_native_long_period_balance_crosses_only_exact_weekends(self):
        friday=datetime(2024,1,5,tzinfo=UTC)
        for period in ('H1','M15','H12','D1'):
            seconds=TIMEFRAMES[period]
            before=NativeBar(friday+timedelta(days=1,seconds=-seconds),100,102,98,100,0,seconds)
            monday=replace(before,time=friday+timedelta(days=3))
            self.assertEqual(consecutive_observations(before,monday),period in ('H12','D1'))
            self.assertFalse(consecutive_observations(before,replace(monday,time=monday.time+timedelta(days=1))))
            self.assertFalse(consecutive_observations(replace(before,calendar_weekends=False),monday))
        # A valid oscillating daily balance must not restart after each five-bar week.
        start=datetime(2024,1,1,tzinfo=UTC);bars=[]
        for i in range(30):
            while start.weekday()>=5:start+=timedelta(days=1)
            price=100+(1.1 if i%2 else -1.1)
            bars.append(NativeBar(start,price-.1,101.5,98.5,price,0,86400))
            start+=timedelta(days=1)
        ranges=observe_ranges(bars,bars[-1].closed_at)
        self.assertTrue(ranges['ranges'])
        strict=[replace(b,calendar_weekends=False) for b in bars]
        self.assertFalse(observe_ranges(strict,strict[-1].closed_at)['ranges'])

    def test_all_21_native_periods_and_calendar_month(self):
        self.assertEqual(len(TIMEFRAMES),21)
        for period,seconds in TIMEFRAMES.items():
            with self.subTest(period=period):
                request=parse_request(snapshot(period))
                self.assertEqual(request['seconds'],seconds)
                self.assertTrue(all(b.closed_at.timestamp()<=request['forming'] for b in request['bars']))
        bars=parse_request(snapshot('MN1'))['bars']
        self.assertEqual((bars[1].closed_at-bars[1].time).days,29)
        self.assertEqual((bars[13].closed_at-bars[13].time).days,28)
        self.assertEqual(bars[11].closed_at,datetime(2025,1,1,tzinfo=UTC))

    def test_reject_incomplete_forming_unordered_nonfinite_and_uncovered(self):
        text=snapshot();lines=text.splitlines()
        variants=['', '\n'.join(lines[:-1]),text.replace('END\tchart-token\t30','END\twrong\t30')]
        a=lines.copy();h=a[0].split('\t');h[6]=str(int(h[6])-1);a[0]='\t'.join(h);variants.append('\n'.join(a))
        a=lines.copy();a[1],a[2]=a[2],a[1];variants.append('\n'.join(a))
        a=lines.copy();v=a[1].split('\t');v[2]='NaN';a[1]='\t'.join(v);variants.append('\n'.join(a))
        a=lines.copy();h=a[0].split('\t');h[7]=str(int(h[7])-3600);a[0]='\t'.join(h);variants.append('\n'.join(a))
        for invalid in variants:
            with self.subTest(invalid=invalid[:40]),self.assertRaises(ValueError):parse_request(invalid)

    def test_calendar_wrong_close_rejected(self):
        lines=snapshot('MN1').splitlines();a=lines[2].split('\t');a[1]=str(int(a[0])+30*86400);lines[2]='\t'.join(a)
        with self.assertRaises(ValueError):parse_request('\n'.join(lines))

    def test_cache_reuses_closed_evidence_but_echoes_new_token(self):
        with TemporaryDirectory() as temp:
            path=Path(temp)/'viewport_test.request.tsv';cache=Path(temp)/'cache'
            path.write_text(snapshot(),encoding='utf-8')
            result=dict(records=[],state='样本不足',count=30,start=1,end=2)
            with patch('ict_trader.viewport_history.recognize',return_value=result) as scan:
                self.assertTrue(process_request(path,cache))
                path.write_text(snapshot(token='new',quote=999),encoding='utf-8')
                self.assertTrue(process_request(path,cache));self.assertEqual(scan.call_count,1)
            reply=path.with_name('viewport_test.reply.tsv').read_text('utf-8')
            self.assertEqual(reply.splitlines()[0].split('\t')[2],'new')
            self.assertEqual(reply.splitlines()[-1],'END\tnew\t0')

    def test_superseded_calculation_is_not_published(self):
        with TemporaryDirectory() as temp:
            path=Path(temp)/'viewport_test.request.tsv';path.write_text(snapshot(),encoding='utf-8')
            def changed(_):
                path.write_text(snapshot(token='changed'),encoding='utf-8')
                return dict(records=[],state='样本不足',count=30,start=1,end=2)
            with patch('ict_trader.viewport_history.recognize',side_effect=changed):
                self.assertFalse(process_request(path,Path(temp)/'cache'))
            self.assertFalse(path.with_name('viewport_test.reply.tsv').exists())

    def test_native_reference_geometry_exports_its_own_period(self):
        raw=json.loads((Path(__file__).parent/'fixtures/ascending_triangle_native_m15.json').read_text('utf-8'))['bars']
        bars=[NativeBar(datetime.fromisoformat(b['time']),*(b[k] for k in ('open','high','low','close')),0,900) for b in raw]
        result=recognize(dict(bars=bars,period='M15'))
        self.assertTrue(result['records'])
        for line in result['records']:
            fields=line.split('\t');self.assertEqual(len(fields),24);self.assertEqual(fields[0],'900')
            self.assertLessEqual(int(fields[5]),result['end'])
        # Time-scale transform is a protocol invariant, not a claim of native H4 accuracy.
        start=bars[0].time
        h4=[NativeBar(start+timedelta(hours=4*i),b.open,b.high,b.low,b.close,0,14400) for i,b in enumerate(bars)]
        result=recognize(dict(bars=h4,period='H4'))
        self.assertTrue(result['records'])
        self.assertTrue(all(line.split('\t')[0]=='14400' for line in result['records']))


if __name__=='__main__':unittest.main()
