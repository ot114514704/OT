"""Real mixed-history selection, plus nearby false overlap alternatives."""
import json,unittest
from pathlib import Path
from ict_trader.core import Bar,instant
from ict_trader.viewport_history import recognize
from ict_trader.display_selection import select_balance_first,adjacent_regions
from tests.test_consolidation_invariants import transformed
from tests.test_dense_pauses import row


def frame(key,start,end,high,low):
    a=row(key,'rectangle',start,end,dense=True).split('\t')
    a[14]=a[16]=str(high);a[18]=a[20]=str(low)
    return a


class AdjacentStageTests(unittest.TestCase):
    def test_native_top_pause_survives_the_following_downward_stage(self):
        raw=json.loads((Path(__file__).parent/'fixtures/h1_july_adjacent_stages.json').read_text('utf8'))
        original=[Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in raw]
        wanted=('dense_horizontal_pause_v1:density3:2026-07-22T20:00:00+00:00',
                'dense_horizontal_pause_v1:body10:2026-07-23T07:00:00+00:00',
                'long_converging_candidate_v1:edge:12:2026-07-24T05:00:00+00:00',
                'dense_horizontal_pause_v1:density3:2026-07-24T09:00:00+00:00')
        for sign,offset in ((1,0),(-1,9000)):
            bars=transformed(original,sign,offset)
            result=recognize({'bars':bars,'period':'H1'})
            before=list(result['records']);selected=select_balance_first(before)
            for identity in wanted:self.assertTrue(any(identity==x.split('\t')[12] for x in selected),identity)
            self.assertEqual(before,result['records'])
            # Selection never moves a boundary or invents a new source record.
            self.assertTrue(set(selected)<=set(before))
            self.assertEqual(selected,select_balance_first(list(reversed(before))))

    def test_only_small_distinct_corners_are_permitted(self):
        a=frame('first',0,100,120,100);b=frame('second',95,150,145,118)
        self.assertTrue(adjacent_regions(a,b));self.assertTrue(adjacent_regions(b,a))
        self.assertEqual(len(select_balance_first(['\t'.join(x) for x in (a,b)])),2)
        repeated=frame('repeated',95,150,120,100)
        broad=frame('too_much_time',70,150,145,118)
        crossed=frame('crossed',95,150,150,148);crossed[16]='-510';crossed[18]='-512'
        for x in (repeated,broad,crossed):self.assertFalse(adjacent_regions(a,x))
        invalid=frame('invalid',95,150,118,145)
        self.assertFalse(adjacent_regions(a,invalid))
        another_period=b.copy();another_period[0]='900'
        self.assertFalse(adjacent_regions(a,another_period))

