"""Actual isolated process lifetime/error checks with non-market fixtures."""
import time,unittest
from ict_trader.model_compute import IsolatedModelCalculator


def echo(connection):
    try:
        while True:
            _,raw=connection.recv()
            if raw.get('wait'):time.sleep(raw['wait'])
            if raw.get('failure'):reply=dict(ok=False,error='same failure',h1_cache={'builds':1})
            elif raw.get('invalid'):reply={'unexpected':True}
            else:reply=dict(ok=True,charts={'echo':raw},timings={'wall_seconds':0},h1_cache={'builds':1})
            connection.send(reply)
    except (EOFError,BrokenPipeError,OSError):pass
    finally:connection.close()


def exit_child(connection):connection.close()


class IsolatedModelTests(unittest.TestCase):
    def test_reply_is_copied_and_one_process_reused(self):
        calculator=IsolatedModelCalculator(timeout=5,target=echo)
        try:
            raw={'value':[1,2]};result=calculator.calculate(raw);pid=calculator.process_id
            result['echo']['value'].append(3)
            self.assertEqual(raw,{'value':[1,2]})
            self.assertEqual(calculator.calculate(raw),{'echo':raw})
            self.assertEqual(calculator.process_id,pid);self.assertEqual(calculator.starts,1)
            self.assertEqual(calculator.metadata()['h1_analysis_cache'],{'builds':1})
        finally:calculator.close()
        self.assertIsNone(calculator.process_id);self.assertIsNone(calculator.process)

    def test_math_error_keeps_process_but_not_previous_diagnostics(self):
        calculator=IsolatedModelCalculator(timeout=5,target=echo)
        try:
            calculator.calculate({});pid=calculator.process_id
            with self.assertRaisesRegex(RuntimeError,'same failure'):calculator.calculate({'failure':True})
            self.assertIsNone(calculator.last_timings);self.assertEqual(calculator.process_id,pid)
            self.assertEqual(calculator.calculate({'after':1}),{'echo':{'after':1}})
        finally:calculator.close()

    def test_timeout_recycles_only_owned_child_and_next_call_can_recover(self):
        calculator=IsolatedModelCalculator(timeout=.05,target=echo)
        try:
            with self.assertRaises(TimeoutError):calculator.calculate({'wait':2})
            self.assertIsNone(calculator.process);self.assertEqual(calculator.timeouts,1)
            calculator.timeout=5
            self.assertEqual(calculator.calculate({'after':2}),{'echo':{'after':2}})
            self.assertEqual(calculator.starts,2)
        finally:calculator.close()

    def test_dead_child_and_malformed_reply_cannot_be_accepted(self):
        calculator=IsolatedModelCalculator(timeout=5,target=exit_child)
        try:
            with self.assertRaises((EOFError,OSError)):calculator.calculate({})
            self.assertIsNone(calculator.process)
            calculator.target=echo
            with self.assertRaisesRegex(ValueError,'格式无效'):calculator.calculate({'invalid':True})
            self.assertIsNone(calculator.process)
        finally:calculator.close()
