"""Execution diagnostics must separate queue/CPU/collection without changing decisions."""
import unittest
from ict_trader.model_runner import LatestModelRunner
from tests.test_model_pipeline import DeferredExecutor
from tests.executor_helpers import InlineExecutor


class ModelTimingTests(unittest.TestCase):
    def test_queue_execution_and_collection_are_measured_separately(self):
        elapsed=[10.];cpu=[2.]
        def calculate(raw):
            elapsed[0]=19.;cpu[0]=5.
            return {'same_input':raw}
        executor=DeferredExecutor()
        runner=LatestModelRunner(executor,calculate,lambda:100,
            elapsed_clock=lambda:elapsed[0],cpu_clock=lambda:cpu[0])
        runner.start({'value':7},'key','native');job=runner.job
        self.assertIsNone(runner.timings(job))
        elapsed[0]=12.;executor.complete(0)
        elapsed[0]=23.;completed,model,error=runner.take_ready()
        self.assertIs(completed,job);self.assertIsNone(error)
        self.assertEqual(model,{'same_input':{'value':7}})
        self.assertEqual(runner.timings(job),dict(queue_seconds=2.,execution_wall_seconds=7.,
            execution_thread_cpu_seconds=3.,ready_to_collect_seconds=4.))

    def test_failed_calculation_keeps_error_and_complete_timing(self):
        elapsed=[1.];cpu=[1.]
        def calculate(raw):
            elapsed[0]=4.;cpu[0]=2.
            raise ValueError('original failure')
        executor=InlineExecutor()
        runner=LatestModelRunner(executor,calculate,lambda:100,
            elapsed_clock=lambda:elapsed[0],cpu_clock=lambda:cpu[0])
        runner.start({},'key','native')
        job,result,error=runner.take_ready()
        self.assertIsNone(result);self.assertIsInstance(error,ValueError)
        self.assertEqual(str(error),'original failure')
        self.assertEqual(runner.timings(job)['execution_wall_seconds'],3.)
        self.assertFalse(runner.metadata()['analysis_running'])

if __name__=='__main__':unittest.main()
