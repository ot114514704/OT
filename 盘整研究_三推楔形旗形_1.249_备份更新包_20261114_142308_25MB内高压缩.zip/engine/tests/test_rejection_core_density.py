import json,unittest
from pathlib import Path
from dataclasses import replace
from datetime import timedelta
from ict_trader.core import Bar,instant
from ict_trader.dense_pauses import observe_dense_pauses,rejection_core_density,common_core_density,PARAMETERS
from ict_trader.ipda_ranges import _candidate
from ict_trader.mt5_bridge import shape_record
from ict_trader.viewport_history import recognize
from ict_trader.display_selection import select_balance_first
from tests.test_consolidation_invariants import transformed


class RejectionCoreTests(unittest.TestCase):
    def bars(self,name):
        rows=json.loads((Path(__file__).parent/'fixtures'/name).read_text('utf8'))
        return [Bar(instant(x['time']),*(x[k] for k in ('open','high','low','close')),seconds=3600) for x in rows]

    def test_native_red_box_is_a_closed_causal_symmetric_short_candidate(self):
        original=self.bars('h1_july22_rejection_core.json')
        start=instant('2026-07-22T06:00:00+00:00');known=instant('2026-07-22T09:00:00+00:00')
        for sign,offset in ((1,0),(-1,9000),(10,0)):
            b=transformed(original,sign,offset);s=next(i for i,x in enumerate(b) if x.time==start)
            self.assertFalse(common_core_density(b,s,s+2,_candidate(b,s,s+2,PARAMETERS)))
            out=observe_dense_pauses(b,known)
            target=next(x for x in out if x['metrics'].get('rejection_core_density') and x['observed_from']==start.isoformat())
            self.assertFalse(target['confirmed']);self.assertFalse(target['score_included'])
            self.assertFalse(target['metrics']['oscillation']['qualified'])
            self.assertEqual(target['known_at'],known.isoformat())
            self.assertFalse(any(x['id']==target['id'] for x in observe_dense_pauses(b,known-timedelta(seconds=1))))
            changed=[replace(x,open=x.open+500,high=x.high+500,low=x.low+500,close=x.close+500) if x.closed_at>known else x for x in b]
            self.assertEqual(out,observe_dense_pauses(changed,known))
            self.assertIn('双侧影线密集候选',shape_record('H1','structural',target))
            selected=select_balance_first(recognize({'bars':b,'period':'H1'})['records'])
            self.assertTrue(any(target['id'] in x for x in selected))

    def test_one_way_large_body_absent_impulse_and_missing_bars_rejected(self):
        b=self.bars('h1_july22_rejection_core.json');s=next(i for i,x in enumerate(b) if x.time==instant('2026-07-22T06:00:00+00:00'));tail=b[s:s+3]
        one_way=[replace(x,open=4130+i*.5,close=4130.4+i*.5,high=4135,low=4125) for i,x in enumerate(tail)]
        big=[replace(x,open=x.low,close=x.high) for x in tail]
        one_sided=[replace(x,high=max(x.open,x.close)+.01) for x in tail]
        gap=[replace(x,time=x.time+timedelta(hours=5)) for x in tail]
        for w in (one_way,big,one_sided,gap):
            z=b[:s]+w
            self.assertFalse(rejection_core_density(z,s,len(z)-1,_candidate(z,s,len(z)-1,PARAMETERS)))
        self.assertFalse(rejection_core_density(tail,0,2,_candidate(tail,0,2,PARAMETERS)))

    def test_prior_observer_records_survive_and_full_mixed_history_shows_the_box(self):
        b=self.bars('h1_july_adjacent_stages.json');r=observe_dense_pauses(b,b[-1].closed_at)
        prior=json.loads((Path(__file__).parent/'fixtures/v17_july_dense_prior_ids.json').read_text('utf8'))
        self.assertTrue(set(prior)<={x['id'] for x in r})
        rows=select_balance_first(recognize({'bars':b,'period':'H1'})['records'])
        self.assertTrue(any(':core_reject3:2026-07-22T09:00:00+00:00' in x for x in rows))
