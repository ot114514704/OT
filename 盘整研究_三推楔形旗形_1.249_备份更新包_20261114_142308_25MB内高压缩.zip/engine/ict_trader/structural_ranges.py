"""Long-window price structures, explicitly separate from IPDA body confirmation.

No missing bars are filled. Cross-session observations remain candidates and
carry their coverage gaps. Every scale runs independently of the small boxes.
"""
from copy import deepcopy
from statistics import median
from dataclasses import replace
from .core import visible
from .oscillation import strong_oscillation

VERSION='price_structure_candidate_v5'
PARAMETERS=dict(windows_m15=[48,96,192],windows_h1=[24,48,96],edge_fraction=.20,
                edge_visits_min=2,crossings_min=4,efficiency_max=.30,
                width_atr_min=3.,width_atr_max=18.,slope_to_width_max=1.5,
                largest_body_to_width_max=.5,exit_closes=2,breakout_atr=.15)
CHECK_NAMES=dict(two_sided='双侧独立边缘测试',crossings='中部反复往返',balanced='方向效率受控',
                 strong_oscillation='强双向震荡筛选',
                 structural_width='结构幅度受控',bounded_drift='轨道漂移受控',
                 no_dominant_bar='单根实体未主导区间',last_inside='末次收盘在观察轨道内')


def candidate(w,mode='auto',*,qualified_only=False,compact=False,revisited=False):
    """Keep full diagnostics by default; scanners may skip rejected windows."""
    n=len(w)
    xs=[(b.time-w[0].time).total_seconds()/w[0].seconds for b in w] if compact else list(range(n))
    mid=sum(xs)/n;den=sum((x-mid)**2 for x in xs)
    slope=sum((x-mid)*b.close for x,b in zip(xs,w))/den
    atr=median(b.high-b.low for b in w)
    if atr<=0:return None
    # Detrending allows slow channels to be observed without confusing their
    # full vertical travel with the actual channel width.
    upper=[b.high-slope*x for x,b in zip(xs,w)]
    lower=[b.low-slope*x for x,b in zip(xs,w)]
    closes=[b.close-slope*x for x,b in zip(xs,w)]
    high=max(upper);low=min(lower);width=high-low
    if width<=0:return None
    tilted=mode!='horizontal' and abs(slope*xs[-1])/width>.5
    if not tilted:
        slope=0.;upper=[b.high for b in w];lower=[b.low for b in w];closes=[b.close for b in w]
        high=max(upper);low=min(lower);width=high-low
    travel=sum(abs(b.close-a.close) for a,b in zip(w,w[1:]))
    efficiency=abs(w[-1].close-w[0].close)/travel if travel else 0
    drift=abs(slope*xs[-1])/width
    physical_checks=dict(balanced=efficiency<=PARAMETERS['efficiency_max'],
                structural_width=PARAMETERS['width_atr_min']<=width/atr<=PARAMETERS['width_atr_max'],
                bounded_drift=drift<=PARAMETERS['slope_to_width_max'],
                no_dominant_bar=max(abs(b.close-b.open) for b in w)<=PARAMETERS['largest_body_to_width_max']*width,
                last_inside=low<=closes[-1]<=high)
    # These are the same final gates. A failed gate cannot be rescued by
    # oscillation or geometry, so the history scanner need not build either.
    if qualified_only and not all(physical_checks.values()):return None
    center=(high+low)/2;visits=[0,0];armed=[True,True];crossings=0;last_side=0;edge_tests=[]
    for b,u,l,c in zip(w,upper,lower,closes):
        side=1 if c>center else -1 if c<center else 0
        if side and last_side and side!=last_side:crossings+=1
        if side:last_side=side
        touches=[u>=high-PARAMETERS['edge_fraction']*width,l<=low+PARAMETERS['edge_fraction']*width]
        # A rejecting wick is still an observed boundary test even if its
        # close has crossed the midpoint. Repeated wicks in the same visit
        # remain one test: only a later non-touch bar closing across the
        # midpoint rearms that side. A bar spanning both bands supplies no
        # independently ordered test; OHLC cannot recover its intrabar path.
        if not all(touches):
            for edge,touch in enumerate(touches):
                if touch and armed[edge]:
                    visits[edge]+=1;armed[edge]=False
                    edge_tests.append(dict(side='upper' if edge==0 else 'lower',
                                           bar_open_at=b.time.isoformat(),known_at=b.closed_at.isoformat()))
            if not touches[0] and side<=0:armed[0]=True
            if not touches[1] and side>=0:armed[1]=True
    two_sided=min(visits)>=PARAMETERS['edge_visits_min']
    crossing_pass=crossings>=PARAMETERS['crossings_min']
    if qualified_only and not (two_sided and crossing_pass):return None
    oscillation=strong_oscillation(w,atr,width,slope)
    if qualified_only and not oscillation['qualified']:return None
    checks=dict(two_sided=two_sided,crossings=crossing_pass,strong_oscillation=oscillation['qualified'],**physical_checks)
    if compact:
        from .dense_pauses import compact_swings
        raw_threshold=max(.1*atr,.06*width);residual_threshold=max(.15*atr,.1*width)
        raw=compact_swings(w,raw_threshold/.25,raw_threshold/.20)
        residual=[replace(b,open=b.open-slope*x,high=b.high-slope*x,low=b.low-slope*x,close=b.close-slope*x) for x,b in zip(xs,w)]
        residual_swings=compact_swings(residual,residual_threshold/.25,residual_threshold/.20)
        both=lambda r:r['completed_legs']>=2 and r['up_legs']>0 and r['down_legs']>0
        checks=dict(compact_channel=tilted,raw_close_reversals=both(raw),residual_close_reversals=both(residual_swings),
            structural_width=1.25<=width/atr<=4.,bounded_drift=drift<=1.5,
            bounded_progress=efficiency<=.75,no_dominant_bar=physical_checks['no_dominant_bar'],
            small_bodies=sum(abs(b.close-b.open) for b in w)/n<=.65*atr,
            short_gaps_only=all((b.time-a.closed_at).total_seconds()<=3*3600 for a,b in zip(w,w[1:])))
        if revisited:
            # A wider counter-rotation is not a fresh impulse if its body was
            # actually revisited by later closed prices inside these rails.
            k=max(range(n),key=lambda i:abs(w[i].close-w[i].open));large=w[k]
            body=abs(large.close-large.open);direction=1 if large.close>large.open else -1
            later=w[k+1:]
            revisits=[b for b in later if (large.close-b.close)*direction>=.75*body]
            raw_full=compact_swings(w,atr,1.25*atr)
            checks.update(revisit_needed=not physical_checks['no_dominant_bar'],revisited_body=len(later)>=2 and bool(revisits),
                full_amplitude_reversals=both(raw_full),
                no_dominant_bar=body<=.8*width,
                bounded_progress=efficiency<=.5)
            if revisits:
                revisit=dict(bar_open_at=large.time.isoformat(),body=body,
                    first_revisited_at=revisits[0].closed_at.isoformat(),required_fraction=.75)
            else:revisit=None
        oscillation={**residual_swings,'qualified':both(residual_swings),'basis':'compact_channel_residual_closed_reversals'}
    gaps=[dict(after=a.closed_at.isoformat(),before=b.time.isoformat(),seconds=(b.time-a.closed_at).total_seconds())
          for a,b in zip(w,w[1:]) if a.closed_at!=b.time]
    # A rectangle keeps horizontal boundaries. Tilted candidates keep a
    # fixed regression slope anchored at first observation, never refitted.
    bodies_high=sorted(max(b.open,b.close)-slope*x for x,b in zip(xs,w))
    bodies_low=sorted(min(b.open,b.close)-slope*x for x,b in zip(xs,w))
    geometry=None
    if tilted:
        def point(index,price):return dict(time=w[index].time.isoformat(),price=price,known_at=w[-1].closed_at.isoformat())
        u=[point(0,high),point(n-1,high+slope*xs[-1])];l=[point(0,low),point(n-1,low+slope*xs[-1])]
        geometry=dict(upper=u,lower=l,frame=[u[0],u[1],l[1],l[0]],ready=True,validated=True,subtype='channel',
            known_at=w[-1].closed_at.isoformat(),projected=False,basis='frozen_regression_envelope',
            reason='首次观察时冻结的平行价格包络；端点为拟合边界，不冒充已确认摆动点')
    return dict(qualified=all(checks.values()),checks=checks,observed_from=w[0].time.isoformat(),geometry=geometry,
                first_observed_at=w[-1].closed_at.isoformat(),known_at=w[-1].closed_at.isoformat(),
                window=n,high=high,low=low,body_high=bodies_high[int((n-1)*.9)],body_low=bodies_low[int((n-1)*.1)],
                observed_high=max(b.high for b in w),observed_low=min(b.low for b in w),
                slope_per_bar=slope,frozen_atr=atr,shape='tilted' if tilted else 'rectangle',
                metrics=dict(upper_visits=visits[0],lower_visits=visits[1],edge_tests=edge_tests,crossings=crossings,oscillation=oscillation,
                             efficiency=efficiency,width_atr=width/atr,slope_to_width=drift,
                             **(dict(compact_channel=True,raw_close_oscillation=raw) if compact else {}),
                             **(dict(revisited_channel=True,revisited_body=revisit) if revisited else {})),
                gaps=gaps,confirmed=False,score_included=False,
                missing=['IPDA实体平衡确认未完成','机构积累/派发意图未验证']+
                        (['跨时段间隔内价格覆盖未验证'] if gaps else []))


def observe_structures(bars,asof,*,short_channels=False,_compact_scan=False,_revisited_scan=False):
    bars=visible(bars,asof)
    if not bars:return dict(version=VERSION,ranges=[],current=[],history=[])
    if any(a.time>=b.time or a.seconds!=b.seconds for a,b in zip(bars,bars[1:])):
        raise ValueError('Ordered homogeneous bars required')
    # Keep bar-count scales (not synthetic H1/M15 resampling) on native periods.
    windows=PARAMETERS['windows_h1' if bars[0].seconds>=3600 else 'windows_m15']
    # Horizontal balance and slow channels are separate hypotheses. A fitted
    # slope must not replace a wider horizontal bottom after the initial bounce.
    scales=[(n,mode) for n in windows for mode in ('horizontal','auto')]
    if short_channels:
        scales += [(n,'auto') for n in (8,12,16) if n not in windows]
        scales.sort(key=lambda key:(-key[0],key[1]!='horizontal'))
    if _compact_scan:scales=[(n,'auto') for n in (6,8,10)]
    active={};ranges=[];history=[];next_start={key:0 for key in scales}
    for i,b in enumerate(bars):
        for key in scales:
            n,mode=key;box=active.get(key)
            if box:
                # Advance by observed bars only. A gap invalidates any streak;
                # it does not imply a breakout, a sweep or a filled price path.
                gap=i and bars[i-1].closed_at!=b.time
                if _compact_scan and gap and (b.time-bars[i-1].closed_at).total_seconds()>3*3600:
                    box.update(active=False,status='数据间隔中止短通道候选')
                    del active[key];next_start[key]=i
                    continue
                if gap:
                    box['gaps'].append(dict(after=bars[i-1].closed_at.isoformat(),before=b.time.isoformat(),seconds=(b.time-bars[i-1].closed_at).total_seconds()))
                    if '跨时段间隔内价格覆盖未验证' not in box['missing']:box['missing'].append('跨时段间隔内价格覆盖未验证')
                    box['streak']=0
                offset=(b.time-bars[box['start_index']].time).total_seconds()/b.seconds if _compact_scan else i-box['start_index'];upper=box['high']+box['slope_per_bar']*offset;lower=box['low']+box['slope_per_bar']*offset
                # A frozen tilted rail can continue beyond the initial
                # physical high/low. Capping it there prematurely ended a
                # channel while price was still inside the observed rails.
                side=1 if b.close>upper+PARAMETERS['breakout_atr']*box['frozen_atr'] else -1 if b.close<lower-PARAMETERS['breakout_atr']*box['frozen_atr'] else 0
                if box['shape']=='tilted' and (not box['metrics'].get('revisited_channel') or not side):
                    g=deepcopy(box['geometry']);u0=g['upper'][0];l0=g['lower'][0]
                    u1=dict(time=b.time.isoformat(),price=upper,known_at=b.closed_at.isoformat())
                    l1=dict(time=b.time.isoformat(),price=lower,known_at=b.closed_at.isoformat())
                    g.update(upper=[u0,u1],lower=[l0,l1],frame=[u0,u1,l1,l0],known_at=b.closed_at.isoformat(),
                             extension_basis='frozen_rails_to_observed_closed_bar',observed_until=b.closed_at.isoformat())
                    box['display_geometry']=g
                box['streak']=box['streak']+1 if side and side==box['side'] else 1 if side else 0
                box.update(side=side,end_at=b.closed_at.isoformat(),last_upper=upper,last_lower=lower)
                if box['streak']>=PARAMETERS['exit_closes']:
                    box['status']='向上离开结构观察区' if side==1 else '向下离开结构观察区'
                    box['active']=False;del active[key];next_start[key]=i+1
                    history.append(dict(known_at=b.closed_at.isoformat(),event='structure_candidate_left',title=box['status'],
                                        detail='连续已收盘价格离开首次观察轨道；仅结束结构候选，不充当IPDA突破确认',
                                        range_id=box['id'],confirmed_bar_only=True))
                continue
            if i-next_start[key]+1<n:continue
            if _compact_scan:
                start=i-n+1
                if start<1 or bars[start-1].closed_at!=bars[start].time:continue
                prior=bars[start-1];atr=median(x.high-x.low for x in bars[start:i+1])
                if abs(prior.close-prior.open)<1.5*atr or abs(prior.close-prior.open)<.5*(prior.high-prior.low):continue
            c=candidate(bars[i-n+1:i+1],mode,qualified_only=not _compact_scan,compact=_compact_scan,revisited=_revisited_scan)
            if not c or not c['qualified']:continue
            if mode=='auto' and c['shape']!='tilted':continue
            box={**deepcopy(c), 'id':VERSION+(':revisited' if _revisited_scan else ':compact' if _compact_scan else '')+':'+str(n)+':'+mode+':'+b.closed_at.isoformat(),
                 'start_index':i-n+1,'end_at':b.closed_at.isoformat(),'active':True,
                 'status':'结构盘整候选','streak':0,'side':0,
                 'last_upper':c['high']+c['slope_per_bar']*(n-1),'last_lower':c['low']+c['slope_per_bar']*(n-1)}
            if c.get('geometry'):box['display_geometry']=deepcopy(c['geometry'])
            if _compact_scan:
                box['missing'].append('短斜向整理未完成双侧独立边缘测试；仅强位移后价格候选')
                box.update(last_upper=box['geometry']['frame'][1]['price'],last_lower=box['geometry']['frame'][2]['price'])
            ranges.append(box);active[key]=box
            history.append(dict(known_at=b.closed_at.isoformat(),event='structure_candidate_entered',title='出现长窗口结构候选',
                                detail=f"{n}根已收盘样本，双侧测试{c['metrics']['upper_visits']}/{c['metrics']['lower_visits']}次；边界与轨道此时冻结，仍待IPDA实体确认"+
                                       ('；包含数据间隔，未填补其间价格' if c['gaps'] else ''),range_id=box['id'],confirmed_bar_only=True))
    if short_channels and not _compact_scan:
        extra=observe_structures(bars,asof,short_channels=True,_compact_scan=True)
        revisited=observe_structures(bars,asof,short_channels=True,_compact_scan=True,_revisited_scan=True)
        ranges+=extra['ranges']+revisited['ranges'];active.update({r['id']:r for r in extra['current']+revisited['current']})
        history=sorted(history+extra['history']+revisited['history'],key=lambda e:e['known_at'])
    return dict(version=VERSION,parameters=PARAMETERS,ranges=ranges,current=list(active.values()),history=history[-24:],
                policy='独立长窗口价格观察；上下双边往返与受控漂移，不要求小实体；候选不计分，不预测方向；轨道只更新到当前已收盘时刻，跨时段数据覆盖缺项明确列出。')
