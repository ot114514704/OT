"""Shared calculation identity; archive identity remains stable across upgrades."""

CALCULATION_VERSION = 'viewport-history-1.17-backup-standard:dense-horizontal-compact-geometry-v21'
