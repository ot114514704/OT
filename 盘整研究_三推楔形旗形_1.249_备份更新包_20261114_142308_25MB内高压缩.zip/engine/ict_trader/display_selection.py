"""Outer horizontal balance first, then distinct inner formations.

Compact horizontal balance owns its candles before a fitted channel. This is
display selection only, not new confirmation, changed geometry or erased data.
"""
import re


def contains(outer, inner):
    if outer[0]!=inner[0] or outer[2]!='rectangle':return False
    a,b,c,d=map(float,(outer[13],outer[15],inner[13],inner[15]))
    if b<=a or d<=c or c<a or d>b or (d-c)/(b-a)>.70:return False
    high,low=float(outer[14]),float(outer[20])
    # Frozen pivot rails can extend slightly past a wick envelope at the
    # opposite rail's first anchor. Keep that genuine child, not a crossing box.
    tolerance=.02*(high-low)
    return high>low and max(float(inner[14]),float(inner[16]))<=high+tolerance and min(float(inner[18]),float(inner[20]))>=low-tolerance


def nested_overlap(outer,inner,*,allow_early_edge=True):
    """Independent inner ranges may protrude beyond a frozen outer box."""
    if outer[0]!=inner[0] or outer[2]!='rectangle':return False
    a,b,c,d=map(float,(outer[13],outer[15],inner[13],inner[15]))
    if b<=a or d<=c or d>b or (d-c)/(b-a)>.70:return False
    early_edge=c<a
    if early_edge:
        if not allow_early_edge:return False
        # A later wide observation can begin one native bar after an already
        # known short pause. Keep both facts rather than retrospectively erase
        # the early stage. This exception is only for nested horizontal native
        # structures, never intersecting fitted rails or comparable duplicates.
        if outer[3]!='structural' or inner[3]!='structural' or inner[2]!='rectangle':return False
        if (d-c)/(b-a)>.5 or a-c>min(float(inner[0]),.25*(d-c)):return False
        if int(inner[5])>=int(outer[5]):return False
    oh,ol=max(float(outer[14]),float(outer[16])),min(float(outer[18]),float(outer[20]))
    ih,il=max(float(inner[14]),float(inner[16])),min(float(inner[18]),float(inner[20]))
    return min(oh-ol,ih-il)>0 and min(oh,ih)-max(ol,il)>=(.8 if early_edge else .5)*min(oh-ol,ih-il)


def adjacent_regions(a,b):
    """Keep successive stages sharing only a small corner of their frames.

    Exit-following bars can overlap the next formation's birth. A short time
    intersection alone must not erase a distinct price acceptance level. Keep
    the same rail ordering throughout the overlap; crossed/repeated regions
    and substantial overlaps still compete for one representative.
    """
    if a[0]!=b[0]:return False
    a0,a1,b0,b1=map(float,(a[13],a[15],b[13],b[15]))
    left,right=max(a0,b0),min(a1,b1)
    if min(a1-a0,b1-b0)<=0 or not 0<right-left<=.25*min(a1-a0,b1-b0):return False
    direction=0
    for fraction in (1/6,1/2,5/6):
        t=left+(right-left)*fraction
        def rails(row,start,end):
            f=(t-start)/(end-start)
            return (float(row[14])+(float(row[16])-float(row[14]))*f,
                    float(row[20])+(float(row[18])-float(row[20]))*f)
        ah,al=rails(a,a0,a1);bh,bl=rails(b,b0,b1)
        width=min(ah-al,bh-bl)
        if width<=0 or max(0,min(ah,bh)-max(al,bl))>.25*width:return False
        side=1 if ah>=bh and al>=bl else -1 if ah<=bh and al<=bl else 0
        if not side or direction and side!=direction:return False
        direction=side
    return True


def successive_formations(early,later):
    """A completed small formation must survive a later broad observation.

    Only the small frame's following tail may overlap: its formation was
    already known before the later formation began. This is not permission
    for intersecting contemporary hypotheses or comparable repeated boxes.
    """
    if early[0]!=later[0] or early[3]=='intraday' or later[3]!='structural' or later[2]!='rectangle':return False
    a,b,c,d=map(int,(early[13],early[15],later[13],later[15]))
    if not a<c<b<=d or b-a>.5*(d-c):return False
    if int(early[5])>c or int(later[5])<b:return False
    return b-c<=.25*(b-a)


def select_balance_first(lines):
    # Native M15 records are available separately. Their H1 projections are
    # disabled by the indicator and must not suppress an actual H1 observation
    # before that period's toggle/filter is applied.
    rows=[line.split('\t') for line in lines]
    def rank(a):
        dense=a[12].startswith('dense_horizontal_pause_v1:')
        confirmed=a[3] in ('local','macro')
        # Actual converging anchors must not be swallowed by a fitted channel.
        parent=any(contains(a,b) for b in rows)
        tier=5 if parent and not dense else 4 if confirmed and a[2]=='rectangle' else 3 if a[2]=='converging' or dense else 2 if a[2]=='rectangle' else 1
        if dense and (':body' in a[12] or ':core' in a[12]) and tier==3:tier=3.25
        found=re.search(r'观察 (\d+) 根',a[23])
        if a[2] in ('channel','tilted') and found and int(found[1])<24:tier=2.5
        if a[2] in ('channel','tilted') and ':revisited:' in a[12]:tier=3.5
        hours=int(found[1])*int(a[0])/3600 if found else 0
        return (-tier,-min(48,hours),int(a[5]),a[1])
    def conflicts(a,b,allow_edge):
        # Frame times (not the status timestamp) are the actual painted span.
        return (a[0]==b[0] and min(int(a[15]),int(b[15]))>max(int(a[13]),int(b[13]))
                and not contains(a,b) and not contains(b,a)
                and not nested_overlap(a,b,allow_early_edge=allow_edge)
                and not nested_overlap(b,a,allow_early_edge=allow_edge)
                and not adjacent_regions(a,b))
    ordered=sorted(rows,key=rank)
    # Preserve existing native representatives first. Removing a disabled
    # projection must not promote another alternative which erases an earlier
    # representative elsewhere in history. Then fill the vacancies it caused.
    previous=[]
    for a in ordered:
        if not any(conflicts(a,b,False) for b in previous):previous.append(a)
    chosen=[a for a in previous if a[3]!='intraday']
    selected={a[1] for a in chosen}
    for a in ordered:
        if a[3]=='intraday' or a[1] in selected:continue
        if any(conflicts(a,b,True) for b in chosen):continue
        chosen.append(a);selected.add(a[1])
    # Extend the existing representative set; do not let new exceptions
    # reshuffle and erase representatives already kept by the earlier passes.
    for a in ordered:
        if a[3]=='intraday' or a[1] in selected:continue
        if any(conflicts(a,b,True) and not successive_formations(a,b)
               and not successive_formations(b,a) for b in chosen):continue
        chosen.append(a);selected.add(a[1])
    return ['\t'.join(a) for a in sorted(chosen,key=lambda a:(int(a[5]),a[1]))]
