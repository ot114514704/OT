"""Bounded background preparation/publication; the quote poller never joins it."""
from dataclasses import dataclass


@dataclass
class PreparedModel:
    charts: dict
    integrity: dict | None
    timings: dict | None = None


class PublicationRunner:
    """One publication in flight, no unbounded queue of old quote snapshots.

    Accepted model objects are immutable after publication. The owner passes a
    shallow state snapshot with those same immutable references. Completed
    receipts identify their model revision so a stale result cannot certify a
    newer model. Failures are returned to the owner for an explicit retry.
    """
    def __init__(self,executor,publish):
        self.executor=executor;self.publish=publish;self.future=None;self.revision=None

    def start(self,state,raw,key,source):
        if self.future is not None:return False
        self.revision=state.get('model_revision')
        self.future=self.executor.submit(self.publish,state,raw,key,source)
        return True

    def take_ready(self):
        if self.future is None or not self.future.done():return None
        future=self.future;revision=self.revision;self.future=None
        try:return revision,future.result(),None
        except Exception as exc:return revision,None,exc

    def metadata(self):
        return dict(publication_running=self.future is not None,publication_model_revision=self.revision)
