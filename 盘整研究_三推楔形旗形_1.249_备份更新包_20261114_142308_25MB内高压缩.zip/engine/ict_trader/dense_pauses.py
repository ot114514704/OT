"""Compact horizontal pauses, separate from confirmed IPDA body balance.

Closed price overlap and repeated two-sided swings are mandatory. A slope is
never removed to make a directional leg look sideways. Bounds freeze when the
pause first becomes observable; continuation context does not predict exit.
"""
from copy import deepcopy
from .core import visible,instant
from .ipda_ranges import _candidate
from .timeframes import consecutive_observations

VERSION = 'dense_horizontal_pause_v1'
PARAMETERS = dict(windows=[5,6,8,10,12,16,24,32],width_atr_max=5.5,
    efficiency_max=.30,overlap_min=.55,body_occupancy_min=.65,
    small_body_atr_max=.80,drift_max=.45,edge_tests_min=2,crossings_min=2)


def displacement_before(bars, start, atr):
    """Only the immediately preceding closed impulse, in either direction."""
    choices=[]
    if start<len(bars) and start and (bars[start].time-bars[start-1].closed_at).total_seconds()>3*3600:return None
    for n in (3,6,8,12):
        if start<n:continue
        prior=bars[start-n:start]
        if any((z.time-a.closed_at).total_seconds()>3*3600 for a,z in zip(prior,prior[1:])):continue
        net=prior[-1].close-prior[0].open
        path=abs(prior[0].close-prior[0].open)+sum(abs(z.close-a.close) for a,z in zip(prior,prior[1:]))
        if abs(net)>=2.5*atr and path and abs(net)/path>=.65:
            choices.append(dict(direction=1 if net>0 else -1,net_atr=abs(net)/atr,
                efficiency=abs(net)/path,from_at=prior[0].time.isoformat(),known_at=prior[-1].closed_at.isoformat()))
    return max(choices,key=lambda x:x['net_atr']) if choices else None


def compact_swings(bars, atr, width, *, include_first_open=False):
    """Completed close reversals in a short pause, never wick-implied paths.

    This lower-amplitude gate is restricted to separately qualified compact
    candidates. It does not change the IPDA confirmation or long-range gate.
    Short session gaps contain no fabricated observations; long gaps reset.
    """
    threshold=max(.25*atr,.20*width)
    direction=0;anchor=extreme=bars[0].open if include_first_open else bars[0].close;legs=[]
    for i,b in enumerate(bars):
        value=b.close
        if i and (b.time-bars[i-1].closed_at).total_seconds()>3*3600:
            direction=0;anchor=extreme=value;legs=[]
        if not direction:
            if abs(value-anchor)>=threshold:
                direction=1 if value>anchor else -1;extreme=value
        elif (value-extreme)*direction>=0:extreme=value
        elif (extreme-value)*direction>=threshold:
            legs.append(dict(direction=direction,amplitude=abs(extreme-anchor),
                             reversal_observed_at=b.closed_at.isoformat()))
            anchor=extreme;extreme=value;direction=-direction
    up=sum(x['direction']>0 for x in legs);down=len(legs)-up
    return dict(qualified=len(legs)>=3 and up>0 and down>0,completed_legs=len(legs),
                up_legs=up,down_legs=down,threshold=threshold,legs=legs,
                basis='compact_closed_price_reversals',known_at=bars[-1].closed_at.isoformat())


def compact_relay(bars,start,end,c):
    """Short, overlapping stall after an observed displacement, both directions."""
    w=bars[start:end+1];m=c['metrics'];atr=m['atr']
    impulse=displacement_before(bars,start,atr)
    if not impulse:return False
    width=c['liquidity_hi']-c['liquidity_lo']
    swings=compact_swings(w,atr,width)
    if len(w)==4:
        # Four alternating closes can complete only two reversals. This path
        # additionally requires the observed impulse and all density gates;
        # it is not a relaxation of longer-window/IPDA balance confirmation.
        swings={**swings,'qualified':swings['completed_legs']>=2 and swings['up_legs']>0 and swings['down_legs']>0,
                'basis':'four_closed_bar_relay_after_displacement'}
    mid=(max(b.close for b in w)+min(b.close for b in w))/2
    sides=[1 if b.close>mid else -1 if b.close<mid else 0 for b in w]
    visits=[s for i,s in enumerate(sides) if s and (not i or s!=sides[i-1])]
    checks={**c['checks'],'two_sided':visits.count(1)>=2 and visits.count(-1)>=2,
            'crossings':len(visits)-1>=3,'strong_oscillation':swings['qualified'],
            'preceding_displacement':True,'overlapping':m['overlap']>=.65,
            'small_bodies':m['mean_body_atr']<=.65,'compact_wicks':width<=4*atr,
            'no_dominant_bar':max(abs(b.close-b.open) for b in w)<=.5*width}
    if not all(checks.values()):return False
    c.update(checks=checks,qualified=True)
    m.update(oscillation=swings,highTests=visits.count(1),lowTests=visits.count(-1),
             crossings=len(visits)-1,compact_relay=True)
    return True


def tight_pause(bars,start,end,c):
    """Independent small-amplitude balance; never an IPDA confirmation.

    Three closed bars are only a displacement-pause candidate. Longer small
    ranges need two-sided close reversals or a completed reversal corroborated
    by repeated midline crossings and stricter overlap/drift limits.
    """
    w=bars[start:end+1];m=c['metrics'];atr=m['atr'];n=len(w)
    width=c['liquidity_hi']-c['liquidity_lo']
    impulse=displacement_before(bars,start,atr)
    if start and w[0].time==bars[start-1].closed_at:
        prior=bars[start-1];net=prior.close-prior.open
        if (abs(net)>=2*atr and abs(net)>=.7*(prior.high-prior.low)
                and abs(net)>=3*max(abs(b.close-b.open) for b in w)):
            impulse=dict(direction=1 if net>0 else -1,net_atr=abs(net)/atr,
                efficiency=1.,from_at=prior.time.isoformat(),known_at=prior.closed_at.isoformat(),
                basis='immediately_preceding_closed_displacement')
    swings=compact_swings(w,atr,width)
    if n==3:
        # A single completed reversal plus a return is the most three closes
        # can prove. Do not claim multiple completed oscillations.
        qualified=(impulse is not None and swings['completed_legs']>=1
                   and m['crossings']>=2 and m['efficiency']<=.20
                   and m['overlap']>=.75 and m['mean_body_atr']<=.35
                   and width<=1.5*atr)
        basis='three_closed_bar_displacement_pause'
    else:
        mid=(max(b.close for b in w)+min(b.close for b in w))/2
        sides=[1 if b.close>mid else -1 if b.close<mid else 0 for b in w]
        visits=[]
        for side in sides:
            if side and (not visits or side!=visits[-1]):visits.append(side)
        qualified=(n>=8 or impulse is not None) and swings['completed_legs']>=2 and swings['up_legs']>0 and swings['down_legs']>0
        qualified=qualified and visits.count(1)>=2 and visits.count(-1)>=2
        # A wider round trip may contain smaller overlapping rotations. Such
        # a dense observation remains a candidate, not a claim that both outer
        # boundaries have already been independently tested twice.
        basis='compact_two_sided_closed_balance'
        if not qualified and n>=8 and swings['completed_legs']>=1:
            qualified=qualified or (m['crossings']>=4 and m['efficiency']<=.20
                and m['overlap']>=.75 and m['mean_body_atr']<=.60
                and m['half_window_drift']<=.30)
            basis='dense_midline_rotations_with_completed_reversal'
    checks={k:v for k,v in c['checks'].items() if k not in ('strong_oscillation','two_sided')}
    checks.update(compact_price_action=bool(qualified),overlapping=m['overlap']>=.65,
        small_bodies=m['mean_body_atr']<=.65,compact_wicks=width<=4*atr,
        no_dominant_bar=max(abs(b.close-b.open) for b in w)<=.5*width)
    if impulse and n>=5 and m['crossings']>=3 and m['efficiency']<=.20:
        checks['no_drift']=m['half_window_drift']<=.60
    if not all(checks.values()):return False
    c.update(checks=checks,qualified=True,pause_impulse=impulse)
    m.update(oscillation={**swings,'qualified':True,'basis':basis},tight_pause=True,
             pause_basis=basis,compact_relay=bool(impulse))
    return True


def three_bar_stall(bars,start,end,c):
    """A tightly bounded three-close turn after a strong observed impulse.

    This proves one completed reversal only, not a fully established balance
    or a future reversal. High overlap and small bodies exclude displacement.
    """
    w=bars[start:end+1];m=c['metrics'];atr=m['atr']
    if len(w)!=3 or atr<=0 or any(a.closed_at!=b.time for a,b in zip(w,w[1:])):return False
    impulse=displacement_before(bars,start,atr)
    if not impulse or impulse['net_atr']<4:return False
    width=c['liquidity_hi']-c['liquidity_lo']
    body_width=max(max(b.open,b.close) for b in w)-min(min(b.open,b.close) for b in w)
    threshold=max(.15*atr,.20*body_width)
    swings=compact_swings(w,threshold/.25,threshold/.20)
    mid=(max(b.close for b in w)+min(b.close for b in w))/2
    sides=[1 if b.close>mid else -1 if b.close<mid else 0 for b in w]
    checks={k:v for k,v in c['checks'].items() if k not in ('strong_oscillation','two_sided')}
    checks.update(preceding_strong_displacement=True,one_completed_close_reversal=swings['completed_legs']==1,
        alternating_closes=all(sides) and sides[0]==sides[2] and sides[0]!=sides[1],
        balanced=m['efficiency']<=.4,overlapping=m['overlap']>=.85,
        small_bodies=m['mean_body_atr']<=.35,accepted_bodies=m['body_occupancy']>=.9,
        no_drift=m['half_window_drift']<=.3,compact_wicks=width<=1.5*atr,
        no_displacement_body=all(abs(b.close-b.open)<=.5*(b.high-b.low) for b in w))
    if not all(checks.values()):return False
    c.update(checks=checks,qualified=True,pause_impulse=impulse)
    m.update(three_bar_stall=True,tight_pause=True,pause_basis='three_close_stall_after_strong_displacement',
        oscillation={**swings,'qualified':True,'basis':'one_completed_close_reversal_only'})
    return True


def impulse_density(bars,start,end,c,*,common_core=False,rejection_core=False):
    """Dense acceptance after displacement, separate from mature balance.

    Three closes can prove only one reversal. A longer flat body cluster may
    show repeated wick rejection without amplitude-qualified close swings;
    report that limitation rather than infer an intrabar path from the wicks.
    """
    w=bars[start:end+1];m=c['metrics'];atr=m['atr'];n=len(w)
    if not 3<=n<=8 or atr<=0 or not start:return False
    if any((z.time-a.closed_at).total_seconds()>3*3600 for a,z in zip(bars[start-1:end],w)):return False
    impulse=displacement_before(bars,start,atr)
    prior=bars[start-1];net=prior.close-prior.open
    if abs(net)>=1.5*atr and abs(net)>=.6*(prior.high-prior.low):
        immediate=dict(direction=1 if net>0 else -1,net_atr=abs(net)/atr,efficiency=1.,
            from_at=prior.time.isoformat(),known_at=prior.closed_at.isoformat(),basis='immediately_preceding_closed_displacement')
        if not impulse or immediate['net_atr']>impulse['net_atr']:impulse=immediate
    if not impulse:return False
    width=c['liquidity_hi']-c['liquidity_lo']
    body_width=max(max(b.open,b.close) for b in w)-min(min(b.open,b.close) for b in w)
    threshold=max(.15*atr,.15*body_width)
    swings=compact_swings(w,threshold/.25,threshold/.20,include_first_open=True)
    prices=[w[0].open]+[b.close for b in w]
    changes=[z-a for a,z in zip(prices,prices[1:]) if abs(z-a)>1e-9*atr]
    turns=sum(a*z<0 for a,z in zip(changes,changes[1:]))
    path=sum(abs(z-a) for a,z in zip(prices,prices[1:]))
    endpoint_efficiency=abs(prices[-1]-prices[0])/path if path else 0.
    upper=sum(b.high-max(b.open,b.close)>=.1*atr for b in w)
    lower=sum(min(b.open,b.close)-b.low>=.1*atr for b in w)
    flat=(n>=5 and max(b.close for b in w)-min(b.close for b in w)<=.5*atr
        and abs(w[-1].close-w[0].close)<=.25*atr and m['overlap']>=.75
        and m['mean_body_atr']<=.3 and upper>=2 and lower>=2 and turns>=2)
    reversing=(swings['completed_legs']>=1 and turns>=1 and endpoint_efficiency<=.4
        and abs(prices[-1]-prices[0])<=.65*atr)
    # A long wick can lower adjacent overlap ratios while all closed bodies
    # continue accepting the very same price band. Inspect that common band
    # independently; never lower the existing observer's overlap threshold.
    core_low=max(b.low for b in w);core_high=min(b.high for b in w)
    core=(3<=n<=4 and reversing and core_high-core_low>=.15*atr
        and body_width<=(.4 if rejection_core else .5)*atr and m['mean_body_atr']<=.3
        and max(b.close for b in w)-min(b.close for b in w)<=(.4 if rejection_core else .35)*atr
        and abs(prices[-1]-prices[0])<=.25*atr
        and (not rejection_core or upper>=2 and lower>=2)
        and all(core_low-.25*atr<=min(b.open,b.close)
                and max(b.open,b.close)<=core_high+.25*atr for b in w))
    checks=dict(preceding_displacement=True,dense_acceptance=core if common_core else flat or reversing,
        overlapping=core if common_core else m['overlap']>=(.7 if n==3 else .65),small_bodies=m['mean_body_atr']<=.6,
        compact_body_range=body_width<=1.5*atr,compact_wicks=width<=3*atr,
        body_accepted=m['body_occupancy']>=.65,
        no_drift=m['half_window_drift']<=.45 or m['half_window_drift']*(c['hi']-c['lo'])<=.5*atr,
        no_dominant_bar=max(abs(b.close-b.open) for b in w)<=.65*width,
        no_displacement_body=sum(abs(b.close-b.open)<=.67*(b.high-b.low) for b in w)>=2*n/3
            and max(abs(b.close-b.open) for b in w)<=atr,
        last_close_near_prior_range=min(b.low for b in w[:-1])-.25*atr<=w[-1].close<=max(b.high for b in w[:-1])+.25*atr)
    if not all(checks.values()):return False
    c.update(checks=checks,qualified=True,pause_impulse=impulse)
    m.update(impulse_density=True,upper_rejections=upper,lower_rejections=lower,
        body_endpoint_efficiency=endpoint_efficiency,
        pause_basis='common_body_acceptance_after_displacement' if common_core else
            'flat_body_acceptance_after_displacement' if flat else 'short_reversal_after_displacement',
        oscillation={**swings,'qualified':False,'basis':'density_candidate_not_mature_two_sided_balance'})
    if common_core:m.update(common_body_core=dict(low=core_low,high=core_high),common_core_density=True)
    if rejection_core:m['rejection_core_density']=True
    return True


def common_core_density(bars,start,end,c):
    """Independent short observer for dense bodies amid uneven long wicks."""
    return impulse_density(bars,start,end,c,common_core=True)


def rejection_core_density(bars,start,end,c):
    """Independent tiny body cluster corroborated by both-sided wick rejects.

    Keep the old common-band observer untouched. This alternative has a
    tighter body envelope, two rejecting wicks each way, and the same closed
    endpoint reversal/impulse guards. It does not establish mature balance.
    """
    if common_core_density(bars,start,end,deepcopy(c)):return False
    return impulse_density(bars,start,end,c,common_core=True,rejection_core=True)


def returning_body_density(bars,start,end,c):
    """Four closed bodies revisit a shared band after a real impulse.

    Half-window medians can drift inside a tiny four-bar body envelope even
    though the final close has returned to its first open. Require the return,
    two completed body-scale reversals and an actual common price band
    together; this independent candidate never establishes IPDA balance.
    """
    w=bars[start:end+1];m=c['metrics'];atr=m['atr']
    if len(w)!=4 or not start or atr<=0:return False
    if any(a.closed_at!=z.time for a,z in zip(bars[start-1:end],w)):return False
    impulse=displacement_before(bars,start,atr)
    prior=bars[start-1];net=prior.close-prior.open
    if abs(net)>=1.5*atr and abs(net)>=.6*(prior.high-prior.low):
        immediate=dict(direction=1 if net>0 else -1,net_atr=abs(net)/atr,efficiency=1.,
            from_at=prior.time.isoformat(),known_at=prior.closed_at.isoformat(),
            basis='immediately_preceding_closed_displacement')
        if not impulse or immediate['net_atr']>impulse['net_atr']:impulse=immediate
    if not impulse:return False
    core_low=max(b.low for b in w);core_high=min(b.high for b in w)
    body_low=min(min(b.open,b.close) for b in w);body_high=max(max(b.open,b.close) for b in w)
    prices=[w[0].open]+[b.close for b in w]
    path=sum(abs(z-a) for a,z in zip(prices,prices[1:]))
    net_return=abs(prices[-1]-prices[0])
    swings=compact_swings(w,.4*atr,.5*(body_high-body_low),include_first_open=True)
    upper=sum(b.high-max(b.open,b.close)>=.08*atr for b in w)
    lower=sum(min(b.open,b.close)-b.low>=.08*atr for b in w)
    checks=dict(preceding_displacement=True,common_price_band=core_high-core_low>=.2*atr,
        overlapping=m['overlap']>=.75,body_envelope=body_high-body_low<=.8*atr,
        small_bodies=m['mean_body_atr']<=.45,
        no_displacement_body=max(abs(b.close-b.open) for b in w)<=.8*atr
            and all(abs(b.close-b.open)<=.67*(b.high-b.low) for b in w),
        compact_wicks=c['liquidity_hi']-c['liquidity_lo']<=2.5*atr,
        closed_return=net_return<=.15*atr and path>0 and net_return/path<=.2,
        two_completed_body_reversals=swings['completed_legs']>=2 and swings['up_legs']>0 and swings['down_legs']>0,
        two_sided_wick_rejections=upper>=2 and lower>=2,
        bodies_near_shared_band=body_low>=core_low-.35*atr and body_high<=core_high+.35*atr,
        last_close_inside=core_low-.15*atr<=w[-1].close<=core_high+.15*atr)
    if not all(checks.values()):return False
    c.update(checks=checks,qualified=True,pause_impulse=impulse)
    m.update(impulse_density=True,returning_body_density=True,upper_rejections=upper,lower_rejections=lower,
        common_body_core=dict(low=core_low,high=core_high),body_endpoint_efficiency=net_return/path,
        pause_basis='four_closed_bodies_returning_to_shared_band',
        oscillation={**swings,'qualified':False,'basis':'short_body_reversals_not_mature_two_sided_balance'})
    return True


def wick_balance(bars,start,end,c):
    """Repeated wick rejection with small, genuinely reversing closes.

    Wick density alone cannot establish a pause. Close reversals are measured
    on the body envelope so that repeated long wicks do not inflate their own
    amplitude gate. This is a price candidate, never IPDA confirmation.
    """
    w=bars[start:end+1];m=c['metrics'];atr=m['atr']
    if len(w)<4 or atr<=0:return False
    body_width=max(max(b.open,b.close) for b in w)-min(min(b.open,b.close) for b in w)
    threshold=max(.15*atr,.20*body_width)
    # Reuse the completed-close reversal counter with the body-based threshold.
    swings=compact_swings(w,threshold/.25,threshold/.20)
    upper=sum(b.high-max(b.open,b.close)>=.10*atr for b in w)
    lower=sum(min(b.open,b.close)-b.low>=.10*atr for b in w)
    wick_dense=sum((b.high-b.low)-abs(b.close-b.open)>=.5*(b.high-b.low) for b in w)
    checks={k:v for k,v in c['checks'].items() if k not in ('strong_oscillation','two_sided')}
    checks.update(wick_density=wick_dense>=.75*len(w),
        no_displacement_body=all(abs(b.close-b.open)<=.67*(b.high-b.low) for b in w),upper_rejections=upper>=2,
        lower_rejections=lower>=2,closed_reversals=swings['completed_legs']>=2 and swings['up_legs']>0 and swings['down_legs']>0,
        overlapping=m['overlap']>=.75,small_bodies=m['mean_body_atr']<=.50,
        body_balance=body_width<=1.5*atr,compact_wicks=c['liquidity_hi']-c['liquidity_lo']<=3*atr)
    if not all(checks.values()):return False
    c.update(checks=checks,qualified=True)
    m.update(wick_balance=True,upper_rejections=upper,lower_rejections=lower,
        wick_dense_bars=wick_dense,oscillation={**swings,'qualified':True,'basis':'wick_density_with_completed_body_scale_close_reversals'})
    return True


def body_scale_pause(bars,start,end,c):
    """Compact close balance whose reversals are scaled to its body envelope."""
    w=bars[start:end+1];m=c['metrics'];atr=m['atr']
    if len(w)<5 or atr<=0:return False
    impulse=displacement_before(bars,start,atr)
    if len(w)<8 and not impulse:return False
    width=c['liquidity_hi']-c['liquidity_lo']
    body_width=max(max(b.open,b.close) for b in w)-min(min(b.open,b.close) for b in w)
    threshold=max(.15*atr,.15*body_width)
    swings=compact_swings(w,threshold/.25,threshold/.20)
    mid=(max(b.close for b in w)+min(b.close for b in w))/2
    sides=[]
    for b in w:
        side=1 if b.close>mid else -1 if b.close<mid else 0
        if side and (not sides or sides[-1]!=side):sides.append(side)
    checks={k:v for k,v in c['checks'].items() if k not in ('strong_oscillation','two_sided')}
    max_body=max(abs(b.close-b.open) for b in w)
    revisited_large_bar=(len(w)>=8 and swings['completed_legs']>=4
        and max_body<=.75*width and sum(abs(z.close-a.close) for a,z in zip(w,w[1:]))>=3*width)
    checks.update(body_scale_reversals=swings['completed_legs']>=2 and swings['up_legs']>0 and swings['down_legs']>0,
        close_rotations=len(sides)>=3,crossings=len(sides)-1>=2,
        last_close_inside=min(b.low for b in w[:-1])<=w[-1].close<=max(b.high for b in w[:-1]),
        overlapping=m['overlap']>=.65,small_bodies=m['mean_body_atr']<=.65,
        compact_wicks=width<=4*atr,no_dominant_bar=max_body<=.5*width or revisited_large_bar)
    if not all(checks.values()):return False
    c.update(checks=checks,qualified=True,pause_impulse=impulse)
    m.update(tight_pause=True,pause_basis='body_scale_closed_rotations',
        oscillation={**swings,'qualified':True,'basis':'body_scale_closed_rotations'})
    return True


def revisited_body_pause(bars,start,end,c):
    """A larger rotation is accepted only after actual two-way revisits.

    Independent from the original observers: retain their frozen identities.
    This is a complete price-range candidate, never retroactive confirmation.
    """
    w=bars[start:end+1];m=c['metrics'];width=c['liquidity_hi']-c['liquidity_lo']
    if len(w)<10 or width<=0:return False
    path=sum(abs(z.close-a.close) for a,z in zip(w,w[1:]))
    checks={k:v for k,v in c['checks'].items() if k!='two_sided'}
    checks.update(completed_full_width_rotations=m['oscillation']['qualified'],
        overlapping=m['overlap']>=.8,small_bodies=m['mean_body_atr']<=.5,
        balanced=m['efficiency']<=.15,no_drift=m['half_window_drift']<=.2,
        compact_wicks=width<=3*m['atr'],revisited_price_path=path>=2*width,
        no_dominant_bar=max(abs(b.close-b.open) for b in w)<=.7*width)
    if not all(checks.values()):return False
    c.update(checks=checks,qualified=True)
    m.update(tight_pause=True,revisited_body_pause=True,pause_basis='revisited_full_width_closed_rotations')
    return True


def _copy_window_evidence(value):
    # Candidate evidence contains only JSON scalars, dicts and lists. Copy all
    # containers, including completed legs, without deepcopy's general-purpose
    # object reconstruction. Qualifiers must still own every mutable container.
    if isinstance(value,dict):
        return {key:(_copy_window_evidence(item) if isinstance(item,(dict,list)) else item)
                for key,item in value.items()}
    if isinstance(value,list):
        return [(_copy_window_evidence(item) if isinstance(item,(dict,list)) else item) for item in value]
    return value


class _DenseCandidateCache:
    """Reuse only pristine window metrics within one closed-input scan.

    Each independent observer receives its own recursive copy: its qualifier may
    mutate checks and nested oscillation evidence without affecting another
    observer. Nothing survives this invocation or a source-price revision.
    """
    def __init__(self,bars,asof):
        self.bars=visible(bars,asof)
        self.windows={}

    def __call__(self,start,end):
        key=(start,end)
        if key not in self.windows:
            self.windows[key]=_candidate(self.bars,start,end,PARAMETERS,include_profile=False)
        return _copy_window_evidence(self.windows[key])


def _observe_dense_pauses(bars, asof, windows, id_suffix='', qualifier=None,*,weekend_candidates=False,candidate_at=None):
    bars=visible(bars,asof); ranges=[]; active=None; segment=0
    for i,b in enumerate(bars):
        if i and not consecutive_observations(bars[i-1],b):
            gap=(b.time-bars[i-1].closed_at).total_seconds()
            if active:active['streak']=0
            # Short session pauses are recorded, never filled with candles.
            # A weekend/long missing section starts a new observation.
            weekend=(weekend_candidates and bars[i-1].seconds==b.seconds==3600
                and bars[i-1].time.weekday()==4 and b.time.weekday()==0 and 36*3600<=gap<=72*3600)
            if gap>3*3600 and not weekend:
                if active:active.update(active=False,status='数据间隔中止')
                active=None;segment=i
            elif active:
                active['gaps'].append(dict(after=bars[i-1].closed_at.isoformat(),before=b.time.isoformat()))
        if active:
            margin=.15*active['frozen_atr']
            side=1 if b.close>active['high']+margin else -1 if b.close<active['low']-margin else 0
            active['streak']=active['streak']+1 if side and side==active['side'] else int(bool(side))
            if active['streak']==1:active['first_outside_at']=b.time.isoformat()
            if not side:active.pop('first_outside_at',None)
            active.update(side=side,end_at=b.closed_at.isoformat(),status='横盘候选·边缘外收待跟进' if side else '横盘候选·区间内往返')
            if active['streak']>=2:
                active['display_end_at']=active['first_outside_at']
                active.update(active=False,status='向上离开横盘观察区' if side>0 else '向下离开横盘观察区')
                if active['preceding_direction']:
                    active['continuation_observed']=side==active['preceding_direction']
                    active['status']+='·'+('原方向中继延续已观察' if active['continuation_observed'] else '反向离开，中继未成立')
                active=None;segment=i
            continue
        for n in sorted(windows,reverse=True):
            if i-segment+1<n:continue
            c=(candidate_at(i-n+1,i) if candidate_at else
                _candidate(bars,i-n+1,i,PARAMETERS,include_profile=False))
            if not c:continue
            if qualifier:
                if not qualifier(bars,i-n+1,i,c):continue
            else:
                if not c['qualified'] and not (n<=12 and compact_relay(bars,i-n+1,i,c)):continue
                if n<8 and not c['metrics'].get('compact_relay') and not compact_relay(bars,i-n+1,i,c):continue
            m=c['metrics'];w=bars[i-n+1:i+1]
            # The wick envelope itself must be compact as well as the bodies.
            # This rejects a quiet close cluster following an isolated huge wick.
            if c['liquidity_hi']-c['liquidity_lo']>6*m['atr']:continue
            impulse=c.get('pause_impulse') or displacement_before(bars,i-n+1,m['atr'])
            trend=impulse['direction'] if impulse else 0
            metrics={**m,'upper_visits':m['highTests'],'lower_visits':m['lowTests']}
            gaps=[dict(after=a.closed_at.isoformat(),before=z.time.isoformat()) for a,z in zip(w,w[1:]) if a.closed_at!=z.time]
            active=dict(id=VERSION+id_suffix+':'+b.closed_at.isoformat(),observed_from=w[0].time.isoformat(),
                first_observed_at=b.closed_at.isoformat(),known_at=b.closed_at.isoformat(),end_at=b.closed_at.isoformat(),
                high=c['liquidity_hi'],low=c['liquidity_lo'],observed_high=c['liquidity_hi'],observed_low=c['liquidity_lo'],
                body_high=c['hi'],body_low=c['lo'],shape='rectangle',geometry=None,slope_per_bar=0.,window=n,frozen_atr=m['atr'],
                metrics=deepcopy(metrics),checks=deepcopy(c['checks']),overlap=m['overlap'],efficiency=m['efficiency'],
                profile={'tags':['rectangle']+(['relay'] if trend else [])},preceding_direction=trend,
                preceding_displacement=impulse,continuation_observed=False,
                recognition_basis='dense_horizontal_pause',active=True,confirmed=False,score_included=False,
                status='横盘候选·区间内往返',streak=0,side=0,gaps=gaps,
                missing=['仅价格密集横盘候选，未替代IPDA实体平衡确认','中继仅指前置趋势背景，后续突破方向未确认','跨休市或缺柱间隔不填造价格路径'])
            ranges.append(active);break
    return ranges


def observe_dense_pauses(bars, asof):
    candidates=_DenseCandidateCache(bars,asof)
    def observe(windows,id_suffix='',qualifier=None,**kwargs):
        return _observe_dense_pauses(bars,asof,windows,id_suffix,qualifier,
            candidate_at=candidates,**kwargs)
    # Independent short pass: a newly detectable four-bar pause must not take
    # over the old observer and erase its later five-/longer-bar identities.
    existing=observe(PARAMETERS['windows'])
    short=observe([4],':compact4')
    tight=observe([3]+list(range(5,17)),':tight',tight_pause)
    wick=observe(list(range(4,17)),':wick',wick_balance)
    # Each body scale continues to inspect the interior of an older wide box.
    # A single active hypothesis must not suppress a later nested pause.
    body=[r for n in (5,6,8,10,12,16) for r in observe([n],':body'+str(n),body_scale_pause)]
    weekend=[r for n in (24,32) for r in observe([n],':weekend'+str(n),body_scale_pause,weekend_candidates=True)
        if any((instant(g['before'])-instant(g['after'])).total_seconds()>3*3600 for g in r['gaps'])]
    micro=observe([3],':stall3',three_bar_stall)
    density=[r for n in (3,4,5,6,8) for r in observe([n],':density'+str(n),impulse_density)]
    common=[r for n in (3,4) for r in observe([n],':core'+str(n),common_core_density)]
    rejected_wicks=[r for n in (3,4) for r in observe([n],':core_reject'+str(n),rejection_core_density)]
    returning=observe([4],':return4',returning_body_density)
    revisited=[r for n in (10,12,16) for r in observe([n],':bodyrevisited'+str(n),revisited_body_pause)]
    # Suppress a near-identical formation already observable at this candidate's
    # birth. Compare formation windows only: future exit/extension must never
    # change whether an earlier candidate existed.
    def already_observed(new):
        from .core import instant
        for old in existing+short:
            if old['known_at']>new['known_at']:continue
            a,b,c,d=map(instant,(old['observed_from'],old['known_at'],new['observed_from'],new['known_at']))
            overlap=max(0.,(min(b,d)-max(a,c)).total_seconds())
            span=min((b-a).total_seconds(),(d-c).total_seconds())
            price=max(0.,min(old['high'],new['high'])-max(old['low'],new['low']))
            width=max(old['high'],new['high'])-min(old['low'],new['low'])
            if span>0 and overlap/span>=.8 and width>0 and price/width>=.8:return True
        return False
    tight=[x for x in tight if not already_observed(x)]
    wick=[x for x in wick if not already_observed(x)]
    body=[x for x in body if not already_observed(x)]
    weekend=[x for x in weekend if not already_observed(x)]
    micro=[x for x in micro if not already_observed(x)]
    density=[x for x in density if not already_observed(x)]
    common=[x for x in common if not already_observed(x)]
    rejected_wicks=[x for x in rejected_wicks if not already_observed(x)]
    returning=[x for x in returning if not already_observed(x)]
    revisited=[x for x in revisited if not already_observed(x)]
    return sorted(existing+short+tight+wick+body+weekend+micro+density+common+rejected_wicks+returning+revisited,key=lambda r:(r['known_at'],r['id']))
