"""MT5 standard periods. MN1 is a calendar month, not a 30-day candle."""
TIMEFRAMES = {**{f'M{n}': n * 60 for n in (1,2,3,4,5,6,10,12,15,20,30)},
              **{f'H{n}': n * 3600 for n in (1,2,3,4,6,8,12)},
              'D1': 86400, 'W1': 604800, 'MN1': 2592000}


def timeframe_seconds(name):
    return TIMEFRAMES[name.removeprefix('PERIOD_')]


def consecutive_observations(a, b):
    """Price observations, not synthetic candles or uninterrupted trading.

    Native H2-D1 balance scans may span exactly the Saturday/Sunday closure.
    Other gaps, ordinary Bars and the established H1/M15 model remain strict.
    Geometric line fitting retains its separate, stricter continuity checks.
    """
    if a.seconds != b.seconds:
        return False
    if a.closed_at == b.time:
        return True
    end = a.closed_at
    return bool(getattr(a, 'calendar_weekends', False) and
                getattr(b, 'calendar_weekends', False) and
                7200 <= a.seconds <= 86400 and end.weekday() == 5 and
                not (end.hour or end.minute or end.second or end.microsecond) and
                (b.time - end).total_seconds() == 2 * 86400)
