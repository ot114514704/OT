"""Current consolidation verdict, independent of score and data availability."""
from .core import instant
from math import isfinite
from .ipda_ranges import PARAMETERS as RANGE_PARAMETERS
from .sample_readiness import local_sample_readiness
from .candidate_observation import candidate_price_observations

VERSION='ipda_current_consolidation_v7'
CHECK_NAMES=dict(compact='区间幅度受控',balanced='低方向效率',overlapping='K线重叠',body_accepted='实体集中',small_bodies='小实体',no_drift='无明显单向漂移',two_sided='双边独立测试',crossings='中线往返',last_close_inside='收盘回到实体区',strong_oscillation='强双向震荡筛选')
PARAMETERS=dict(candidate_checks_min=7,poll_stale_seconds=15,quote_idle_seconds=30,bar_sync_grace_seconds=5)
BODY_CANDIDATE_REQUIRED=('compact','small_bodies','body_accepted','strong_oscillation')


def body_candidate_ready(candidate):
    checks=(candidate or {}).get('checks') or {}
    return (sum(v is True for v in checks.values())>=PARAMETERS['candidate_checks_min']
            and all(checks.get(k) is True for k in BODY_CANDIDATE_REQUIRED))


def select_body_candidate(candidates):
    """Eligibility precedes ranking; a failed prerequisite cannot hide a valid window.

    If none is eligible, keep the most informative failed window for diagnostics.
    Equal counts retain detector order, independent of price direction or outcome.
    """
    eligible=[c for c in candidates if body_candidate_ready(c)]
    return max(eligible or candidates,key=lambda c:sum(v is True for v in c['checks'].values()),default=None)


def classify(chart):
    rows=chart.get('phase_rows') or []
    if not rows:return dict(verdict='insufficient',label='证据不足',known_at=None,reason='尚无已确认K线分析',checks={},missing=['已确认K线分析'],range=None)
    row=rows[-1];e=row['consolidation_evidence'];box=e.get('range');candidate=None
    # An ended range retains its formation evidence. Its exit verdict is a
    # separate current observation, never a new candidate or active balance.
    frozen=box or e.get('ended')
    candidates=e.get('candidates') or []
    candidate=select_body_candidate(candidates)
    checks=frozen['checks'] if frozen else candidate['checks'] if candidate else {}
    near=body_candidate_ready(candidate)
    swing_row=(chart.get('swing_rows') or [{}])[-1]
    swing=swing_row.get('candidate')
    swing_valid=bool(swing and swing.get('qualified') is True and swing.get('confirmed') is False
                     and swing.get('score_included') is False and swing.get('checks')
                     and all(v is True for v in swing['checks'].values())
                     and instant(swing_row['known_at'])==instant(swing['known_at'])==instant(row['known_at']))
    candidate_basis=None
    if box:
        verdict='confirmed';reason='首次确认后冻结的实体平衡区仍有效；'+box['status']
    elif e.get('event')=='breakout_confirmed':
        verdict='not_consolidation';reason='连续越界收盘满足跟进条件，原盘整已退出；不等于已确认新的趋势'
    elif e.get('event')=='data_gap':
        verdict='insufficient';reason='数据间隔中止原区间，等待新连续样本'
    elif near:
        verdict='candidate';reason='多数局部平衡条件满足，尚缺完整确认；不由分数或形态单独确认'
        candidate_basis='body_balance'
    elif swing_valid:
        verdict='candidate';reason='显著双向折返满足摆动候选条件，实体平衡尚未确认；保留原阶段作为背景，不据此确认盘整、扫荡或突破'
        candidate_basis='swing_balance'
    elif row['phase'] in ('expansion','retracement','reversal'):
        verdict='not_consolidation';reason='当前识别为'+row['phase']+'，尚未满足盘整条件'
    else:
        verdict='insufficient';reason='没有有效冻结区间，局部平衡条件尚不足以作出盘整或非盘整结论'
    labels=dict(confirmed='已确认盘整',candidate='盘整候选',not_consolidation='非盘整',insufficient='证据不足')
    score_meta=row['fit_scores']['by_phase']['consolidation']
    score_window=(box or e.get('ended') or {}).get('window')
    if score_window is None and score_meta.get('checks_basis')=='current_candidate_window' and candidates:
        score_window=(candidates[0].get('metrics') or {}).get('window')
    return dict(version=VERSION,verdict=verdict,label=labels[verdict],known_at=row['known_at'],reason=reason,
                checks_known_at=frozen.get('known_at',row['known_at']) if frozen else row['known_at'],
                checks_basis='first_confirmation' if frozen else 'current_candidate_window',candidate_basis=candidate_basis,
                candidate_window=(candidate.get('metrics') or {}).get('window') if candidate_basis=='body_balance' else None,
                score_window=score_window,
                candidate_evidence=swing if candidate_basis=='swing_balance' else None,
                event=e.get('event'),checks={CHECK_NAMES.get(k,k):v for k,v in checks.items()},
                missing=[CHECK_NAMES.get(k,k) for k,v in checks.items() if v is not True]+(swing.get('missing',[]) if candidate_basis=='swing_balance' else [])+['高周期程序方向未验证','历史时区未核验'],
                range=frozen,range_state='active' if box else 'ended' if frozen else None,
                profile=frozen.get('profile') if frozen else (candidate or {}).get('profile'),
                score=row['fit_scores']['by_phase']['consolidation']['score'],score_eligibility=row['fit_scores']['by_phase']['consolidation'].get('eligibility'),score_policy='规则符合度/100，不用于确认盘整')


def state_history(chart,limit=24):
    """Reconstruct known-at transitions from causal rows, never from forming prices."""
    result=[];previous=None;previous_range=None;previous_basis=None
    swings={instant(r['known_at']):r for r in chart.get('swing_rows') or []}
    labels={'range_confirmed':'首次确认盘整','breakout_pending':'越界收盘，等待跟进',
            'breakout_confirmed':'突破确认，退出原盘整','data_gap':'数据间隔中止原盘整'}
    for row in chart.get('phase_rows') or []:
        swing=swings.get(instant(row['known_at']))
        report=classify({'phase_rows':[row],'swing_rows':[swing] if swing else []});e=row['consolidation_evidence'];box=e.get('range') or e.get('ended') or {}
        identity=box.get('id');event=e.get('event');verdict=report['verdict']
        meaningful=event in ('range_confirmed','range_reclaimed','breakout_pending','breakout_confirmed','data_gap')
        basis_changed=verdict==previous=='candidate' and report['candidate_basis']!=previous_basis
        changed=verdict!=previous or (identity is not None and identity!=previous_range) or basis_changed
        if meaningful or changed:
            kind=event if meaningful else 'window_start' if previous is None else 'candidate_basis_changed' if basis_changed else 'verdict_changed'
            if kind=='range_reclaimed':
                edge={'upper':'上侧','lower':'下侧','both':'双侧'}.get(e.get('sweep'))
                title=('扫荡'+edge+'流动性并收回') if edge else '越界收回，未证实流动性扫荡'
            elif kind=='window_start':title='样本窗口起点：'+report['label']
            elif kind=='candidate_basis_changed':title='盘整候选依据变化'
            else:title=labels.get(kind,'判定变为：'+report['label'])
            detail=report['reason']
            if kind=='range_reclaimed' and e.get('sweep_evidence'):
                evidence=e['sweep_evidence'];excursions=evidence.get('excursions') or {}
                first=min((x['first_excursion_at'] for x in excursions.values()),default=None)
                if first:detail+='；流动性刺出首次可知 '+first+'，至本棒收回才确认，不回填前棒事件'
            if kind=='breakout_pending':detail+=f"；连续外收{box.get('breakout_streak',0)}根，尚未满足退出条件"
            if kind=='breakout_confirmed':detail+=('；向上' if box.get('breakout_side')==1 else '；向下' if box.get('breakout_side')==-1 else '')
            result.append(dict(known_at=row['known_at'],event=kind,title=title,detail=detail,
                from_verdict=previous,to_verdict=verdict,label=report['label'],range_id=identity,candidate_basis=report['candidate_basis'],
                sweep=e.get('sweep'),checks_missing=[k for k,v in report['checks'].items() if v is not True],
                confirmed_bar_only=True))
        previous=verdict;previous_range=identity;previous_basis=report['candidate_basis']
    return result[-max(1,limit):]


def current_candidate_overlay(chart):
    """Draw the exact current verdict's candidate, using closed evidence only.

    This is a mutable observation, not a frozen/confirmed range or a score.
    Untagged body balance still has observable bounds. Slanted profiles keep
    their validated geometry requirement in both renderers.
    """
    report=classify(chart)
    if report['verdict']!='candidate':return None
    rows=chart.get('phase_rows') or [];bars=chart.get('bars') or []
    row=rows[-1]
    if not bars or bars[-1].get('forming') or bars[-1]['closed_at']!=row['known_at']:return None
    basis=report['candidate_basis']
    if basis=='body_balance':
        candidate=select_body_candidate(row['consolidation_evidence']['candidates'])
        window=candidate['metrics']['window']
        if len(bars)<window:return None
        start=bars[-window]['time'];low=candidate['lo'];high=candidate['hi']
        profile=candidate.get('profile') or {}
    elif basis=='swing_balance':
        candidate=report['candidate_evidence'];start=candidate['observed_from']
        low=candidate['low'];high=candidate['high'];profile={}
        window=sum(b['time']>=start for b in bars)
    else:return None
    return dict(id='current:'+basis+':'+row['known_at'],observed_from=start,
        known_at=row['known_at'],end_at=row['known_at'],low=low,high=high,
        profile=profile,window=window,candidate_basis=basis,active=True,
        confirmed=False,score_included=False,confirmed_bar_only=True,
        status='正在形成 · 候选未确认',boundary_basis='current_closed_candidate_window')


def body_candidate_observation(chart,bar,report=None):
    """Live price relative to the selected closed candidate, never a detector.

    Candidate bounds are observations of one window, not confirmed frozen
    rails. Keep them separate from both pivot geometry and confirmed ranges.
    """
    report=report or classify(chart)
    if report.get('verdict')!='candidate' or report.get('candidate_basis')!='body_balance':return None
    if not bar or bar.get('forming') is not True:return None
    try:
        known=instant(chart['closed_end'])
        if instant(report['known_at'])!=known or instant(bar['time'])!=known:return None
        candidate=select_body_candidate(chart['phase_rows'][-1]['consolidation_evidence']['candidates'])
        if not body_candidate_ready(candidate):return None
        window=candidate['metrics']['window']
        if window!=report['candidate_window']:return None
        low=candidate['lo'];high=candidate['hi'];outer_low=candidate['liquidity_lo'];outer_high=candidate['liquidity_hi']
        atr=candidate['metrics']['atr'];price=bar['close']
        values=(low,high,outer_low,outer_high,atr,price,bar['open'],bar['high'],bar['low'])
        if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not isfinite(v) for v in values):return None
        if not (atr>0 and outer_low<=low<high<=outer_high and bar['low']<=min(price,bar['open'])<=max(price,bar['open'])<=bar['high']):return None
    except (KeyError,TypeError,ValueError,OverflowError):return None
    tolerance=RANGE_PARAMETERS['breakout_atr']*atr
    if price>high+tolerance:
        code='above_threshold';message='末柱高于候选实体上沿及观察容差，等待收盘复核；候选尚未确认，不构成突破'
    elif price<low-tolerance:
        code='below_threshold';message='末柱低于候选实体下沿及观察容差，等待收盘复核；候选尚未确认，不构成突破'
    elif price>high or price<low:
        code='body_edge';message='末柱在候选实体边缘外、观察容差内；不改变候选资格'
    else:
        code='inside';message='末柱仍在候选实体区内；未收盘，不参与确认'
    crossed=[]
    if bar['high']>outer_high:crossed.append('upper')
    if bar['low']<outer_low:crossed.append('lower')
    if crossed:message+='；本柱曾越过候选窗口'+('高低点' if len(crossed)==2 else '高点' if crossed[0]=='upper' else '低点')+'，尚不计确认扫荡'
    return dict(known_at=report['known_at'],bar_open_at=bar['time'],window=window,code=code,message=message,
        price=price,low=low,high=high,observed_low=outer_low,observed_high=outer_high,
        threshold_low=low-tolerance,threshold_high=high+tolerance,wick_crossings=crossed,
        boundary_basis='latest_closed_body_candidate',boundaries_frozen=False,confirmed=False,score_included=False,
        policy='候选边缘仅来自所选已收盘窗口，可在下一次收盘后更新；不是斜线轨道或已确认冻结区间')


def forming_observation(chart,bar,box=None):
    """Display-only price position; never consumed by classifier, events or score."""
    rows=chart.get('phase_rows') or []
    if not rows or not bar or bar.get('forming') is not True:return None
    box=box if box is not None else rows[-1]['consolidation_evidence'].get('range')
    if not box or instant(bar['time'])!=instant(chart['closed_end']):return None
    price=bar['close'];buffer=RANGE_PARAMETERS['breakout_atr']*box['frozen_atr']
    outer=box.get('breakout_basis')=='liquidity'
    high=box['liquidity_high'] if outer else box['high'];low=box['liquidity_low'] if outer else box['low']
    upper=high+buffer;lower=low-buffer
    if price>upper:
        code='above_threshold';message='末柱价格高于上沿越界阈值，等待收盘及后续跟进；尚未确认突破'
    elif price<lower:
        code='below_threshold';message='末柱价格低于下沿越界阈值，等待收盘及后续跟进；尚未确认突破'
    elif price>high or price<low:
        code='outer_edge' if outer else 'body_edge';message='末柱价格在'+('外层流动性' if outer else '实体')+'区边缘外，仍在越界容差内；不改变已收盘判定'
    else:
        code='inside';message='末柱价格仍在冻结'+('外层流动性' if outer else '实体')+'区内；未收盘，不参与确认'
    crossed=[]
    if bar['high']>box['liquidity_high']:crossed.append('upper')
    if bar['low']<box['liquidity_low']:crossed.append('lower')
    if crossed:message+='；本柱曾刺出'+('双侧' if len(crossed)==2 else '上侧' if crossed[0]=='upper' else '下侧')+'流动性边缘，尚不计确认扫荡'
    return dict(code=code,message=message,bar_open_at=bar['time'],price=price,threshold_high=upper,threshold_low=lower,
                wick_crossings=crossed,confirmed=False,score_included=False,boundary_basis='frozen_liquidity_edges' if outer else 'frozen_body_balance')


def bar_sync(state,period,chart):
    """Compare native quote and bar labels in their shared terminal domain.

    No host-clock/terminal-timezone subtraction. This checks bar currency, not
    market hours, calibrated session identity, or the age of an unchanged quote.
    """
    try:
        bar=state['forming'][period];epoch=state['quote']['raw_epoch']
        if isinstance(epoch,bool) or not isinstance(epoch,(int,float)) or not isfinite(epoch):
            raise ValueError('Invalid terminal epoch')
        start=instant(bar['time']).timestamp();end=instant(bar['closed_at']).timestamp()
        duration={'H1':3600,'M15':900}[period]
        if bar.get('forming') is not True or end-start!=duration:raise ValueError('Invalid forming duration')
        grace=PARAMETERS['bar_sync_grace_seconds']
        if epoch>=end+grace:
            return dict(status='bars_lagging',reason='报价已进入后续周期，但本周期K线尚未同步',quote_after_bar_end_seconds=epoch-end)
        if epoch<start-grace:
            return dict(status='bars_unaligned',reason='末柱起点晚于报价，终端数据时序不一致')
        if instant(bar['time'])!=instant(chart['closed_end']):
            return dict(status='bars_unaligned',reason='末柱与已分析收盘时刻不连续，等待数据同步')
        return dict(status='aligned',reason='报价与本周期末柱同步；尚未核验会话时区')
    except (KeyError,TypeError,ValueError,OverflowError):
        return dict(status='bars_unverified',reason='缺少合法报价时标或末柱时标，无法核验K线当前性')


def live_reports(state,now):
    poll_age=max(0,now-state['polled_at']) if state.get('polled_at') is not None else None
    tick_age=max(0,now-state['last_tick_change_at']) if state.get('last_tick_change_at') is not None else None
    if state.get('status') in ('source_mismatch','source_unverified'):availability=state['status']
    elif state.get('status')=='disconnected':availability='disconnected'
    elif state.get('analysis_error'):availability='analysis_error'
    elif state.get('status')!='connected':availability='disconnected' if state.get('status')=='disconnected' else 'snapshot'
    elif poll_age is None or poll_age>PARAMETERS['poll_stale_seconds']:availability='stale'
    elif not state.get('quote'):availability='quote_missing'
    elif state['quote'].get('market_source',{}).get('status')!='verified':availability='source_unverified'
    elif state.get('model_origin')=='cached_history':availability='history_recalculating'
    elif tick_age is None or tick_age>PARAMETERS['quote_idle_seconds']:availability='quote_idle'
    else:availability='live'
    result={}
    for period,chart in state.get('charts',{}).items():
        report=classify(chart);observed=(state.get('latest_closed_end') or {}).get(period)
        readiness=local_sample_readiness(chart)
        pending=bool(state.get('model_origin')=='cached_history' or state.get('data_revision_pending') or observed and instant(observed)!=instant(chart['closed_end']))
        sync=bar_sync(state,period,chart)
        health=('analysis_pending' if pending else 'live' if sync['status']=='aligned' else sync['status']) if availability=='live' else availability
        macro=chart.get('macro_current')
        if macro:
            macro={**macro,'availability':health,'actionable_current':health=='live',
                   'forming_observation':forming_observation(chart,(state.get('forming') or {}).get(period),macro['range'])
                     if health=='live' and macro['verdict']=='confirmed' and macro.get('range') else None}
        result[period]={**report,'availability':health,'actionable_current':health=='live','poll_age_seconds':poll_age,
                        'sample_readiness':readiness,
                        'body_candidate_observation':body_candidate_observation(chart,(state.get('forming') or {}).get(period),report) if health=='live' else None,
                        'macro_context':macro,
                        'swing_candidate':(chart.get('swing_rows') or [{}])[-1].get('candidate'),
                        'candidate_observations':candidate_price_observations(chart,(state.get('forming') or {}).get(period)) if health=='live' else [],
                        'structural_candidates':chart.get('structural_current') or [],
                        'geometric_candidates':chart.get('geometric_current') or [],
                        'swing_observation':{k:v for k,v in (chart.get('swing_rows') or [{}])[-1].items() if k!='candidate'},
                        'quote_idle_seconds':tick_age,'analysis_pending':pending,'bar_sync':sync,
                        'forming_observation':forming_observation(chart,(state.get('forming') or {}).get(period)) if health=='live' else None}
    return result
