"""One-way, file-only export of accepted models to a read-only MT5 indicator."""
import hashlib
import json
from datetime import datetime
from math import isfinite
from pathlib import Path
import time
from .core import instant
from .current_consolidation import live_reports
from .candidate_observation import closed_candidate_position
from .timeframes import timeframe_seconds
from .display_selection import select_balance_first
from .history_generation import CALCULATION_VERSION


def _epoch(t):return int(instant(t).timestamp())
def _text(s):return str(s).replace('\t',' ').replace('\n',' ').replace('\r',' ')


def current_reclaim_side(box,known_at):
    """An earlier sweep count cannot qualify a later body-only reclaim."""
    sweep=box.get('last_sweep') or {}
    if (not known_at or not sweep.get('known_at') or not sweep.get('excursions')
            or instant(sweep['known_at'])!=instant(known_at)):return None
    return {'upper':'上侧','lower':'下侧','both':'双侧'}.get(sweep.get('side'))


def range_event_summary(report):
    """Closed-bar event only; never infer a sweep from forming observations."""
    if report.get('availability')!='live':return None
    event=report.get('event');box=report.get('range') or {}
    side={1:'向上',-1:'向下'}.get(box.get('breakout_side'),'')
    if event=='range_confirmed':return '首次确认实体平衡'
    if event=='breakout_pending':return f"{side}越界外收{box.get('breakout_streak',0)}根，待跟进"
    if event=='breakout_confirmed':return side+'突破退出原区间'
    if event=='data_gap':return '数据间隔中止原区间'
    if event=='range_reclaimed':
        swept=current_reclaim_side(box,report.get('known_at'))
        return swept+'流动性扫荡收回' if swept else '越界收回，未证实流动性扫荡'
    return None


def candidate_summary(report):
    if report.get('availability')!='live':return []
    items=report.get('candidate_observations') or []
    pending=sum(x['closed_position']['code']=='outside_pending' for x in items)
    outside=sum(x['forming_observation']['code'] in ('above_threshold','below_threshold') for x in items)
    crossed=sum(x['forming_observation']['code']=='rails_crossed' for x in items)
    parts=[]
    body=report.get('body_candidate_observation') or {}
    position={'inside':'区内','body_edge':'边缘','above_threshold':'上沿外','below_threshold':'下沿外'}.get(body.get('code'))
    if position:parts.append('实体候选末柱'+position+'(未确认)')
    if pending:parts.append(f'形态{pending}段收盘越界待跟进')
    if outside:parts.append(f'形态{outside}段末柱越界观察')
    if crossed:parts.append(f'形态{crossed}段边线交会待收盘')
    if items and not (pending or outside or crossed):parts.append('形态末柱区内/边缘观察')
    return parts


AVAILABILITY_NAMES=dict(analysis_pending='新收盘重算中',disconnected='MT5断连',stale='数据陈旧',
    quote_idle='暂无新报价',quote_missing='报价缺失',bars_lagging='K线数据滞后',
    bars_unaligned='报价与K线时序不一致',bars_unverified='K线当前性未核验',analysis_error='识别出错',
    snapshot='仅历史快照',history_recalculating='上次历史图表，等待实时重算',source_mismatch='行情来源不匹配',source_unverified='行情来源未核验')


def report_label(report):
    """A cached conclusion is historical whenever its period is unavailable."""
    if report.get('availability')=='live':return report.get('label','模型加载中')
    status=AVAILABILITY_NAMES.get(report.get('availability'),'当前不可用')
    return status+('（上次'+report['label']+'）' if report.get('known_at') and report.get('label') else '')


def closed_label_stamp(report):
    """Display the serialized terminal clock label, without inventing a timezone conversion."""
    try:
        stamp=datetime.fromisoformat(report['known_at'])
        if stamp.tzinfo is None or stamp.utcoffset() is None:raise ValueError('Missing clock domain')
        return stamp.strftime('%m-%d %H:%M')
    except (KeyError,TypeError,ValueError):return '时刻缺失'


def current_summary(report, companion=None):
    """Compact live context for existing MT5 builds, independent of history view."""
    parts=[('H1 ' if companion else '')+report_label(report)]
    if report.get('availability')=='live':
        event=range_event_summary(report)
        if event:parts.append(event)
        readiness=report.get('sample_readiness') or {}
        if readiness.get('status')=='collecting':
            prefix='间隔后' if readiness.get('reset_reason')=='data_gap' else '退出后' if readiness.get('reset_reason')=='breakout_confirmed' else '局部样本'
            parts.append(f"{prefix}{readiness['window_bars']}/{readiness['minimum_closed_bars']}根")
        macro=report.get('macro_context') or {}
        if macro.get('verdict')=='confirmed':parts.append('外层盘整有效')
        count=len(report.get('structural_candidates') or [])+len(report.get('geometric_candidates') or [])
        if count:parts.append(f'活动形态{count}段(未确认)')
        observation=report.get('forming_observation') or macro.get('forming_observation') or {}
        code=observation.get('code')
        if code in ('above_threshold','below_threshold'):
            parts.append('末柱'+('上沿' if code=='above_threshold' else '下沿')+'外观察，待收盘')
        elif code in ('outer_edge','body_edge'):parts.append('末柱边缘测试，未确认')
        parts.extend(candidate_summary(report))
    if companion:
        parts.append('M15 '+report_label(companion)+' · 收盘 '+closed_label_stamp(companion))
        event=range_event_summary(companion)
        if event:parts.append('M15 '+event)
        parts.extend('M15 '+s for s in candidate_summary(companion))
        # The existing indicator appends its own chart's close timestamp after
        # this summary. Name that period so it cannot look like the M15 time.
        parts.append('H1收盘')
    return ' / '.join(parts)


def chart_acknowledgements(directory,revision,sequence,now):
    """A file export alone does not prove that a native chart consumed it.

    Indicator receipts use this machine's file mtime, never broker timestamps.
    Partial writes and receipts left by a closed chart cannot qualify as attached.
    This verifies the loaded build/model, not the success of a mouse gesture.
    """
    charts=[]
    for path in sorted(Path(directory).glob('chart_*.tsv')):
        item=dict(chart_id=path.stem[6:],status='invalid_receipt')
        try:
            age=now-path.stat().st_mtime
            a=path.read_text('utf-8').strip().split('\t')
            if len(a)!=11 or a[0]!='IPDA_CHART':raise ValueError('receipt format')
            version=tuple(int(v) for v in a[1].split('.'))
            drawn,beat,first,follow,mouse,gestures=(int(a[i]) for i in (4,5,7,8,9,10))
            if not a[3].startswith('PERIOD_') or min(drawn,beat,first,gestures)<0 or follow not in (0,1) or mouse not in (0,1):
                raise ValueError('receipt fields')
            try:timeframe_seconds(a[3])
            except KeyError:raise ValueError('receipt period')
            item.update(version=a[1],model_revision=a[2],period=a[3][7:],
                age_seconds=round(max(0,age),1),drawn_count=drawn,heartbeat_sequence=beat,
                first_visible_bar=first,auto_scroll=bool(follow),mouse_scroll=bool(mouse),
                completed_gestures=gestures,health=a[6])
            if age < -5:item['status']='clock_mismatch'
            elif age>15:item['status']='stale_receipt'
            elif version<(1,5):item['status']='update_required'
            elif not revision or a[2]!=str(revision):item['status']='model_pending'
            elif not 0<=sequence-beat<=5 or a[6]=='stale':item['status']='heartbeat_pending'
            else:item['status']='attached'
        except (OSError,UnicodeError,ValueError):
            pass  # A concurrent partial receipt must not interrupt native polling.
        charts.append(item)
    status='attached' if any(c['status']=='attached' for c in charts) else 'unverified' if charts else 'awaiting_indicator'
    return dict(status=status,charts=charts)


def current_bridge_status(bridge,revision,now):
    """Revalidate cached receipts against the model currently served by the API.

    A model can be accepted before the next bridge export/indicator timer tick.
    The previous export's attached receipt must not certify that new model.
    This reads no files and never promotes a previously unverified receipt.
    """
    result=dict(bridge);indicator=bridge.get('indicator') or {};charts=[]
    updated=bridge.get('updated_at')
    valid_time=isinstance(updated,(int,float)) and not isinstance(updated,bool) and isfinite(updated) and now>=updated-5
    elapsed=max(0,now-updated) if valid_time else float('inf')
    for chart in indicator.get('charts') or []:
        item=dict(chart);age=item.get('age_seconds')
        valid_age=isinstance(age,(int,float)) and not isinstance(age,bool) and isfinite(age) and age>=0
        if valid_age and isfinite(elapsed):item['age_seconds']=round(age+elapsed,1)
        if item.get('status')=='attached':
            if not valid_age or not valid_time or age+elapsed>15:item['status']='stale_receipt'
            elif not revision or str(bridge.get('model_revision'))!=str(revision) or str(item.get('model_revision'))!=str(revision):
                item['status']='model_pending'
        charts.append(item)
    status='attached' if any(c.get('status')=='attached' for c in charts) else 'unverified' if charts else 'awaiting_indicator'
    result['indicator']={**indicator,'status':status,'charts':charts}
    result['expected_model_revision']=revision
    return result


def display_records(charts):
    """Export all loaded history; suppress only identical geometry per layer."""
    result=[]
    for period,c in charts.items():
        records=[]
        for kind,name in [('macro','macro_ranges'),('local','consolidations'),('structural','structural_ranges'),('geometric','geometric_ranges'),('intraday','intraday_structures')]:
            for box in c.get(name,[]):
                active=box.get('active',box.get('end_at')==c.get('closed_end') and not any(s in box.get('status','') for s in ('突破条件触发','中止')))
                record=shape_record(period,kind,dict(box,active=active))
                if record:records.append(record.split('\t'))
        if c.get('current_candidate'):
            record=shape_record(period,'candidate',c['current_candidate'])
            if record:records.append(record.split('\t'))
        chosen=[];seen=set()
        for a in sorted(records,key=lambda a:int(a[5]),reverse=True):
            key=tuple(a[2:4]+a[13:21])
            if key not in seen:chosen.append(a);seen.add(key)
        result.extend((int(a[5]),'\t'.join(a)) for a in chosen)
    return sorted(result)


def shape_explanation(period,kind,box,shape,geometry):
    """Describe measured evidence, never turn a drawing into a confirmation."""
    profile=box.get('profile') or {};tags=profile.get('tags',[])
    subtype=(geometry or {}).get('subtype')
    names={'ascending_triangle':'上升三角','descending_triangle':'下降三角',
           'symmetric_triangle':'对称收敛','triangle':'三角收敛',
           'rising_wedge':'上升楔形','falling_wedge':'下降楔形','channel':'倾斜通道'}
    name=names.get(subtype,'收敛/楔形') if shape!='rectangle' else ('压缩箱体' if 'compressed' in tags else '矩形箱体' if 'rectangle' in tags or box.get('shape')=='rectangle' else '水平区间')
    if 'relay' in tags:name+='·中继背景'
    if box.get('recognition_basis')=='dense_horizontal_pause':
        name={1:'上涨中继横盘',-1:'下跌中继横盘'}.get(box.get('preceding_direction'),'密集横盘')
        if (box.get('metrics') or {}).get('three_bar_stall'):name+='·三根短停顿'
    level={'macro':'外层','local':'局部','structural':'结构候选','geometric':'形态候选','intraday':'M15内层','candidate':'正在形成'}[kind]
    status=box['status']
    reclaim='扫荡收回' if current_reclaim_side(box,box.get('end_at')) else '越界收回'
    state='已离开' if '离开' in status else '已突破' if '突破条件触发' in status else '已中止' if '中止' in status else '已失效' if '失效' in status else '已结束' if '结束' in status or box.get('active') is False else reclaim if '假突破收回' in status else '越界待跟进' if status=='越界待跟进' else '候选' if kind in ('candidate','structural','geometric') or kind=='intraday' and not box.get('source_confirmed') else '进行中'
    title=f'{level}·{name}·{state}'
    candidate_position=closed_candidate_position(box,box.get('source_kind') if kind=='intraday' else kind)
    if candidate_position and candidate_position['code']=='outside_pending':
        title+='·越界待跟进'
    metrics=box.get('metrics') or {};checks=box.get('checks') or {}
    osc=box.get('oscillation') or metrics.get('oscillation') or {}
    facts=[]
    if box.get('window') is not None:facts.append(f"观察 {box['window']} 根")
    hi=box.get('high_tests',metrics.get('upper_visits'));lo=box.get('low_tests',metrics.get('lower_visits'))
    if hi is not None and lo is not None:facts.append(f'上/下沿测试 {hi}/{lo} 次')
    if osc.get('completed_legs') is not None:facts.append(f"完成摆动 {osc['completed_legs']} 段")
    if box.get('overlap') is not None:facts.append(f"K线重叠 {box['overlap']:.0%}")
    efficiency=box.get('efficiency',metrics.get('efficiency'))
    if efficiency is not None:facts.append(f'方向效率 {efficiency:.2f}')
    if shape!='rectangle' and geometry:
        ratio=geometry.get('contraction_ratio')
        if ratio is not None:facts.append(f'末/初轨道宽度 {ratio:.2f}')
        facts.append('已验证轨道覆盖' if geometry.get('validated') else '轨道待验证')
    if not facts:
        labels={'two_sided':'双边测试','strong_oscillation':'双向震荡','overlapping':'K线重叠','balanced':'低方向效率','crossings':'中线往返','covered_contraction':'收敛覆盖'}
        facts=[v+'满足' for k,v in labels.items() if checks.get(k) is True] or ['具体条件见网页证据；不补造缺失数值']
    brief='；'.join(facts[1:3] if len(facts)>2 and facts[0].startswith('观察') else facts[:2])
    known=box.get('first_observed_at') or box['known_at']
    detail=[f'{period} | {title}',f'状态：{status}',f"区间：{box['observed_from']} → {box['end_at']}",f'首次可知：{known}', '依据：'+'；'.join(facts)]
    if box.get('recognition_basis')=='dense_horizontal_pause':
        if metrics.get('impulse_density'):
            detail.append('强位移后密集停顿候选：小实体集中、价格交叠、受控净推进；不等于成熟双边盘整或反转确认')
            if metrics.get('returning_body_density'):
                core=metrics['common_body_core']
                detail.append(f"四根回访密集候选：共同价格区 {core['low']:.2f}—{core['high']:.2f}；末收盘回到首开盘附近，按实体尺度完成双向折返；不因短窗半段中位数移动而遗漏，也不当作成熟盘整确认")
            if metrics.get('common_core_density'):
                core=metrics['common_body_core']
                detail.append(f"长影线共同接受区 {core['low']:.2f}—{core['high']:.2f}：各根价格区间有共同交集，实体与收盘集中，并已完成一次收盘折返；影线不用于推断盘中路径")
                if metrics.get('rejection_core_density'):
                    detail.append('双侧影线密集候选：上、下拒绝各至少两根；实体包络不超过0.4倍区间均幅，净推进不超过0.25倍；仅补充短停顿，不构成成熟盘整确认')
            detail.append('实体近水平反复接受、上下影线拒绝；尚无幅度合格的完整收盘折返' if metrics.get('pause_basis')=='flat_body_acceptance_after_displacement' else '仅已观察的短收盘折返；双边独立测试及成熟震荡仍待验证')
            detail.append(f"影线拒绝：上{metrics['upper_rejections']}根／下{metrics['lower_rejections']}根；不推断柱内路径，不当作扫荡确认")
        elif metrics.get('wick_balance'):
            detail.append('长影线密集候选：多根上下影线拒绝、实体集中、低净位移及双向收盘折返；影线不推断柱内价格路径')
            detail.append(f"影线拒绝：上{metrics['upper_rejections']}根／下{metrics['lower_rejections']}根；不等于独立流动性扫荡确认")
        elif metrics.get('tight_pause'):
            detail.append('短横盘候选：原始价格密集重叠、小实体、低净位移及已完成折返；边沿测试次数按实际显示，不等于双边均已确认')
            basis_labels={'three_closed_bar_displacement_pause':'前置强位移后的三根已收盘短停顿',
                          'three_close_stall_after_strong_displacement':'强位移后三根高重叠小实体，仅一段已完成收盘折返；不代表趋势反转确认',
                          'body_scale_closed_rotations':'按实体范围检验已完成双向收盘折返及中线往返',
                          'revisited_full_width_closed_rotations':'完整范围已完成双向收盘折返；较大实体所在价格区被后续收盘反复回访，不将单根强位移直接算作盘整',
                          'compact_two_sided_closed_balance':'双向收盘折返及中线往返',
                          'dense_midline_rotations_with_completed_reversal':'已完成折返并伴随密集中线往返'}
            detail.append('候选依据：'+basis_labels.get(metrics.get('pause_basis'),'短横盘价格证据'))
        else:
            detail.append('密集横盘：未去趋势的原始价格；重叠、双边独立测试、完成折返、低净位移同时筛选')
        impulse=box.get('preceding_displacement')
        if impulse:
            detail.append(f"前置{'上涨' if impulse['direction']>0 else '下跌'}强位移：{impulse['net_atr']:.2f}倍区间均幅，方向效率{impulse['efficiency']:.2f}；截至{impulse['known_at']}")
            detail.append('同向外收跟进已观察' if box.get('continuation_observed') else '中继背景不代表已确认延续，等待边缘收盘跟进')
    if metrics.get('compact_channel'):
        detail.append('短斜向整理：前置强位移、原始收盘与轨道内收盘均有双向完成折返；仅候选，双侧独立边缘测试尚未完整')
        if metrics.get('revisited_channel'):
            revisit=metrics['revisited_body']
            detail.append(f"大实体反向回访：{revisit['bar_open_at']}的实体已被后续收盘反向回访至少75%，首次回访{revisit['first_revisited_at']}；保留完整原生整理段，仍只作为候选")
        detail.append(f"原始收盘完成折返 {metrics['raw_close_oscillation']['completed_legs']} 段；轨道按实际时间绘制，短休市间隔不填造K线")
    if box.get('breakout_basis') in ('body','liquidity'):
        detail.append(f"冻结实体：{box['low']:.2f} — {box['high']:.2f}；流动性：{box['liquidity_low']:.2f} — {box['liquidity_high']:.2f}")
        detail.append('退出依据：冻结'+('实体边界' if box['breakout_basis']=='body' else '流动性边缘')+'及容差后的连续收盘；与流动性扫荡分开')
        if status=='假突破收回':
            swept=current_reclaim_side(box,box.get('end_at'))
            detail.append('本次收回：'+(swept+'流动性扫荡已确认' if swept else '越界收回，未证实本次流动性扫荡'))
        if box.get('breakout_streak'):
            side={1:'向上',-1:'向下'}.get(box.get('breakout_side'),'')
            detail.append(f"结束前外收：{side}{box['breakout_streak']}根" if box.get('active') is False else f"最近外收：{side}{box['breakout_streak']}根，尚待跟进")
        sweep=box.get('last_sweep') or {}
        if sweep:
            side={'upper':'上侧','lower':'下侧','both':'双侧'}.get(sweep.get('side'),'待核验')
            detail.append(f"最近已确认扫荡：{side} · 收回可知 {sweep['known_at']}")
        pending=box.get('pending_liquidity_excursions') or {}
        if pending:
            edges='、'.join({'upper':'上侧','lower':'下侧'}.get(k,k) for k in pending)
            detail.append(('结束时' if box.get('active') is False else '当前')+edges+'刺出仍未确认收回，不计为已确认扫荡')
    if candidate_position:detail.append('最近收盘：'+candidate_position['message'])
    if shape=='rectangle':
        low=box.get('projection_low',box.get('liquidity_low',box.get('observed_low',box.get('low'))))
        high=box.get('projection_high',box.get('liquidity_high',box.get('observed_high',box.get('high'))))
        detail.append(f'绘制边缘：{low:.2f} — {high:.2f}')
    else:detail.append('边缘为随时间变化的趋势线；仅画已观察覆盖范围')
    if kind=='intraday':
        detail.append('M15 原生结构投影，不代表 H1 独立确认')
        detail.append('来源形成资格：M15 实体平衡已确认' if box.get('source_confirmed') is True else '来源资格：M15 候选未确认')
        detail.append('本投影不计 H1 确认分；是否仍有效见状态及来源结束时刻')
    elif kind in ('structural','geometric','candidate') or box.get('confirmed') is False:
        detail.append('资格：候选未确认，不计确认分')
    elif kind!='intraday':
        score=box.get('score') or {};value=score.get('score') if isinstance(score,dict) else None
        if value is not None:detail.append(f'规则符合度 {value}/100；不是概率或入场信号')
    if box.get('sweep_count') is not None:detail.append(f"已确认扫荡收回 {box['sweep_count']} 次；不预设必有假突破")
    missing=box.get('missing') or profile.get('missing') or []
    if missing:detail.append('待验证：'+'；'.join(str(x) for x in missing))
    detail.append('只用已收盘证据；机构意图和后续方向未验证')
    return title,brief,'~n~'.join(detail)


def shape_record(period,kind,box):
    profile=box.get('profile') or {};tags=profile.get('tags',[])
    shape=box.get('shape') or ('converging' if 'converging' in tags else 'tilted' if 'tilted' in tags else 'rectangle')
    geometry=box.get('display_geometry') or box.get('geometry') or profile.get('geometry')
    known=box.get('first_observed_at') or box['known_at']
    low=box.get('projection_low',box.get('liquidity_low',box.get('observed_low',box.get('low'))))
    high=box.get('projection_high',box.get('liquidity_high',box.get('observed_high',box.get('high'))))
    if shape in ('tilted','converging'):
        if not geometry or not geometry.get('validated'):return None
        frame=geometry['frame'];shape='channel' if geometry.get('subtype')=='channel' else 'converging'
    else:
        paint_end=box.get('display_end_at',box['end_at'])
        frame=[dict(time=box['observed_from'],price=high),dict(time=paint_end,price=high),
               dict(time=paint_end,price=low),dict(time=box['observed_from'],price=low)]
        shape='rectangle'
    identity=hashlib.sha256((period+':'+kind+':'+box['id']).encode()).hexdigest()[:16]
    label=('M15内层，非H1确认' if kind=='intraday' else '盘整候选' if kind=='candidate' else '形态候选' if kind in ('structural','geometric') else '实体平衡')+' · '+box['status']
    fields=[timeframe_seconds(period),identity,shape,kind,_epoch(box['observed_from']),_epoch(known),_epoch(box['end_at']),low,high,label,1 if box.get('active',False) else 0,box.get('source_period',period),box['id']]
    for p in frame:fields.extend([_epoch(p['time']),format(p['price'],'.10g')])
    fields.extend(shape_explanation(period,kind,box,shape,geometry))
    return '\t'.join(_text(x) for x in fields)


class MT5Bridge:
    def __init__(self,directory):
        self.directory=Path(directory);self.revision=None;self.sequence=0

    @classmethod
    def from_config(cls,path):
        path=Path(path)
        if not path.exists():return None
        config=json.loads(path.read_text('utf-8'))
        return cls(config['files_directory']) if config.get('enabled') is True else None

    def _write(self,name,body):
        self.directory.mkdir(parents=True,exist_ok=True)
        target=self.directory/name;temp=target.with_suffix('.tmp')
        temp.write_text(body,encoding='utf-8');temp.replace(target)

    def update(self,state,now=None):
        now=time.time() if now is None else now;revision=state.get('model_revision');charts=state.get('charts') or {}
        if revision and revision!=self.revision:
            rows=select_balance_first([r[1] for r in display_records(charts)])
            body='IPDA_SHAPES\t2\t'+str(revision)+'\tXAUUSD\t'+str(len(rows))+'\t'+CALCULATION_VERSION+'\n'+'\n'.join(rows)+'\nEND\t'+str(revision)+'\n'
            self._write('shapes.tsv',body);self.revision=revision
        reports=live_reports(state,now);self.sequence+=1
        fields=['IPDA_LIVE',1,self.sequence,revision or '',state.get('status','starting')]
        for period in ('H1','M15'):
            r=reports.get(period) or {}
            fields.extend([r.get('availability','snapshot'),current_summary(r,reports.get('M15') if period=='H1' else None),r.get('known_at','')])
        fields.extend([(state.get('quote') or {}).get('raw_time',''),int(now)])
        self._write('heartbeat.tsv','\t'.join(_text(x) for x in fields)+'\n')
        return dict(enabled=True,model_revision=self.revision,sequence=self.sequence,updated_at=now,
            indicator=chart_acknowledgements(self.directory,self.revision,self.sequence,now))
