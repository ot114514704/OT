"""One immutable model snapshot in flight; the market reader never waits on it."""
from copy import deepcopy
from dataclasses import dataclass
import time


@dataclass
class ModelJob:
    key: str
    raw: dict
    origin: str
    started_at: float
    future: object = None
    queued_tick: float = 0
    compute_started_tick: float | None = None
    compute_finished_tick: float | None = None
    thread_cpu_seconds: float | None = None


class LatestModelRunner:
    def __init__(self,executor,calculate,clock,*,elapsed_clock=time.perf_counter,cpu_clock=time.thread_time):
        self.executor=executor;self.calculate=calculate;self.clock=clock;self.job=None
        self.elapsed_clock=elapsed_clock;self.cpu_clock=cpu_clock

    def start(self,raw,key,origin):
        if self.job is not None:raise RuntimeError('Only one model calculation may run at a time')
        job=ModelJob(key,deepcopy(raw),origin,self.clock())
        job.queued_tick=self.elapsed_clock()
        def execute(input_raw):
            job.compute_started_tick=self.elapsed_clock();cpu_started=self.cpu_clock()
            try:return self.calculate(input_raw)
            finally:
                job.thread_cpu_seconds=max(0,self.cpu_clock()-cpu_started)
                job.compute_finished_tick=self.elapsed_clock()
        job.future=self.executor.submit(execute,job.raw)
        self.job=job

    def take_ready(self):
        job=self.job
        if job is None or not job.future.done():return None
        self.job=None
        try:return job,job.future.result(),None
        except Exception as exc:return job,None,exc

    def metadata(self):
        job=self.job
        return dict(analysis_running=job is not None,
                    analysis_started_at=job.started_at if job else None,
                    analysis_target_closed_end={p:r[-1]['closed_at'] for p,r in job.raw.items() if r and 'closed_at' in r[-1]} if job else None)

    def timings(self,job):
        """Completed job diagnostics only; clocks never affect acceptance."""
        if job.compute_started_tick is None or job.compute_finished_tick is None:return None
        return dict(queue_seconds=max(0,job.compute_started_tick-job.queued_tick),
                    execution_wall_seconds=max(0,job.compute_finished_tick-job.compute_started_tick),
                    execution_thread_cpu_seconds=job.thread_cpu_seconds,
                    ready_to_collect_seconds=max(0,self.elapsed_clock()-job.compute_finished_tick))
