"""Optional per-calculation measurements isolated to the executing context."""
from contextvars import ContextVar
from time import perf_counter,thread_time

_active=ContextVar('ipda_calculation_trace',default=None)


class CalculationTrace:
    def __init__(self):self.stages=[]
    def __enter__(self):
        self.token=_active.set(self)
        return self
    def __exit__(self,*error):_active.reset(self.token)


def measured(name,fn,*args,**kwargs):
    trace=_active.get()
    if trace is None:return fn(*args,**kwargs)
    wall=perf_counter();cpu=thread_time()
    try:return fn(*args,**kwargs)
    finally:trace.stages.append(dict(stage=name,wall_seconds=perf_counter()-wall,thread_cpu_seconds=thread_time()-cpu))
