"""One owned calculation process; native reads and HTTP never share its GIL."""
import multiprocessing as mp
import time


def _serve(connection):
    # Imported only in the child. No terminal SDK, HTTP server or file publisher
    # is started: only the existing closed-input mathematical calculation runs.
    from app import calculate,prepare_h1
    from .analysis_cache import H1AnalysisCache
    from .calculation_timing import CalculationTrace
    cache=H1AnalysisCache(prepare_h1)
    try:
        while True:
            request=connection.recv()
            if request[0]!='calculate':break
            wall=time.perf_counter();cpu=time.thread_time()
            try:
                with CalculationTrace() as trace:charts=calculate(request[1],h1_cache=cache)
                reply=dict(ok=True,charts=charts,timings=dict(wall_seconds=time.perf_counter()-wall,
                    thread_cpu_seconds=time.thread_time()-cpu,stages=trace.stages),h1_cache=cache.metadata())
            except Exception as exc:reply=dict(ok=False,error=str(exc),h1_cache=cache.metadata())
            connection.send(reply)
    except (EOFError,BrokenPipeError,OSError):pass
    finally:connection.close()


class IsolatedModelCalculator:
    """Sequential closed-bar jobs, no background queue and no external files.

    The parent still owns acceptance, source supersession, freeze validation and
    persistence. A child reply can never publish itself or become current.
    """
    def __init__(self,timeout=110,target=_serve):
        self.timeout=timeout;self.target=target;self.context=mp.get_context('spawn')
        self.process=None;self.connection=None;self.starts=0;self.timeouts=0
        self.last_timings=None;self.h1_cache=None;self.process_id=None

    def close(self):
        if self.connection:
            self.connection.close();self.connection=None
        if self.process:
            if self.process.is_alive():self.process.terminate()
            self.process.join(timeout=2)
            if self.process.is_alive():self.process.kill();self.process.join(timeout=2)
            self.process.close();self.process=None
        self.process_id=None

    def calculate(self,raw):
        self.last_timings=None
        if self.process is None or not self.process.is_alive():
            self.close();self.connection,child=self.context.Pipe()
            self.process=self.context.Process(target=self.target,args=(child,),daemon=True)
            try:self.process.start();self.process_id=self.process.pid
            except Exception:
                self.connection.close();self.connection=None;self.process=None
                raise
            finally:child.close()
            self.starts+=1;self.h1_cache=None
        try:
            self.connection.send(('calculate',raw))
            if not self.connection.poll(self.timeout):
                self.timeouts+=1
                raise TimeoutError('盘整计算超过独立进程时限；保留上次结果，下一次读取后重试')
            reply=self.connection.recv()
            if not isinstance(reply,dict) or type(reply.get('ok')) is not bool:
                raise ValueError('独立计算进程返回格式无效')
        except (EOFError,BrokenPipeError,OSError,TimeoutError,ValueError):
            self.close();raise
        self.h1_cache=reply.get('h1_cache')
        if not reply['ok']:raise RuntimeError(reply.get('error','独立盘整计算失败'))
        if not isinstance(reply.get('charts'),dict):
            self.close();raise ValueError('独立计算进程缺少图表')
        self.last_timings=reply.get('timings') or {}
        return reply['charts']

    def metadata(self):
        return dict(isolated=True,process_id=self.process_id,starts=self.starts,timeouts=self.timeouts,
                    timeout_seconds=self.timeout,h1_analysis_cache=self.h1_cache,last_timings=self.last_timings)
