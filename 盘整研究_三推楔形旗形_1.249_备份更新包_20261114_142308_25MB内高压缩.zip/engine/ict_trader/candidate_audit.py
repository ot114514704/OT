"""Verify one exported price candidate against its closed formation source.

This re-evaluates only the frozen formation, without scanning exits, measuring
returns or judging profitability. Candidate contracts never replace the
strong-oscillation requirements of a confirmed IPDA range.
"""
import re
from statistics import median
from .core import instant
from . import dense_pauses as dense
from .ipda_ranges import _candidate
from .structural_ranges import candidate as structure
from .long_geometry import candidate as convergence


def candidate_evidence_errors(box,bars,kind):
    errors=[]
    def require(ok,code):
        if not ok:errors.append(code)
    try:
        known=instant(box['first_observed_at']);start=instant(box['observed_from'])
        prefix=[b for b in bars if b.closed_at<=known]
        window=[b for b in prefix if b.time>=start]
        require(bool(window) and window[0].time==start and window[-1].closed_at==known
                and len(window)==box['window'],'candidate_formation_source_coverage')
        if errors:return errors
        previous=prefix[len(prefix)-len(window)-1] if len(prefix)>len(window) else None
        suffix=':'+box['first_observed_at'];identity=box['id']
        require(identity.endswith(suffix),'candidate_identity_time')
        if errors:return errors
        identity=identity[:-len(suffix)];n=len(window)
        if kind=='structural' and identity.startswith(dense.VERSION):
            observer=identity[len(dense.VERSION):]
            qualifiers={':compact4':None,':tight':dense.tight_pause,':wick':dense.wick_balance,
                        ':stall3':dense.three_bar_stall,':return4':dense.returning_body_density}
            choices=[(r':body(5|6|8|10|12|16)',dense.body_scale_pause),
                     (r':weekend(24|32)',dense.body_scale_pause),
                     (r':bodyrevisited(10|12|16)',dense.revisited_body_pause),
                     (r':density(3|4|5|6|8)',dense.impulse_density),
                     (r':core(3|4)',dense.common_core_density),
                     (r':core_reject(3|4)',dense.rejection_core_density)]
            qualifier=qualifiers.get(observer);recognized=observer=='' or observer in qualifiers
            for pattern,fn in choices:
                match=re.fullmatch(pattern,observer)
                if match:
                    qualifier=fn;recognized=n==int(match[1]);break
            require(recognized,'candidate_observer_unknown')
            if not recognized:return errors
            allowed={'':dense.PARAMETERS['windows'],':compact4':[4],':tight':[3]+list(range(5,17)),
                     ':wick':list(range(4,17)),':stall3':[3],':return4':[4]}
            require(n in allowed.get(observer,[n]),'candidate_observer_window')
            for a,b in zip(window,window[1:]):
                gap=(b.time-a.closed_at).total_seconds()
                weekend=(observer.startswith(':weekend') and a.seconds==b.seconds==3600
                         and a.time.weekday()==4 and b.time.weekday()==0 and 36*3600<=gap<=72*3600)
                require(gap<=3*3600 or weekend,'candidate_formation_gap')
            c=_candidate(prefix,len(prefix)-n,len(prefix)-1,dense.PARAMETERS)
            qualified=False
            if c:
                if qualifier:qualified=qualifier(prefix,len(prefix)-n,len(prefix)-1,c)
                else:
                    qualified=c['qualified'] or n<=12 and dense.compact_relay(prefix,len(prefix)-n,len(prefix)-1,c)
                    if qualified and n<8 and not c['metrics'].get('compact_relay'):
                        qualified=dense.compact_relay(prefix,len(prefix)-n,len(prefix)-1,c)
            require(bool(qualified and c and c['qualified']),'candidate_formation_unqualified')
            if not qualified:return errors
            m=c['metrics'];impulse=c.get('pause_impulse') or dense.displacement_before(prefix,len(prefix)-n,m['atr'])
            require(c['liquidity_hi']-c['liquidity_lo']<=6*m['atr'],'candidate_wick_envelope')
            expected=dict(high=c['liquidity_hi'],low=c['liquidity_lo'],body_high=c['hi'],body_low=c['lo'],
                          observed_high=c['liquidity_hi'],observed_low=c['liquidity_lo'],frozen_atr=m['atr'],
                          shape='rectangle',slope_per_bar=0.,geometry=None,checks=c['checks'],
                          metrics={**m,'upper_visits':m['highTests'],'lower_visits':m['lowTests']},
                          preceding_displacement=impulse,preceding_direction=impulse['direction'] if impulse else 0)
        elif kind=='structural':
            match=re.fullmatch(r'price_structure_candidate_v5(?::(compact|revisited))?:(\d+):(horizontal|auto)',identity)
            require(bool(match),'candidate_observer_unknown')
            if not match:return errors
            compact=bool(match[1]);require(n==int(match[2]),'candidate_observer_window')
            if compact:
                atr=median(b.high-b.low for b in window)
                require(previous is not None and previous.closed_at==window[0].time and
                        abs(previous.close-previous.open)>=1.5*atr and
                        abs(previous.close-previous.open)>=.5*(previous.high-previous.low),'candidate_preceding_displacement')
            expected=structure(window,match[3],compact=compact,revisited=match[1]=='revisited')
            require(bool(expected and expected['qualified']),'candidate_formation_unqualified')
            if not expected:return errors
            expected={k:expected[k] for k in ('high','low','body_high','body_low','observed_high','observed_low',
                'slope_per_bar','frozen_atr','shape','metrics','checks','geometry')}
        else:
            match=re.fullmatch(r'long_converging_candidate_v1(?::(edge))?:(\d+)',identity)
            require(bool(match),'candidate_observer_unknown')
            if not match:return errors
            require(n==int(match[2]),'candidate_observer_window')
            if match[1]:
                atr=median(b.high-b.low for b in window)
                require(previous is not None and previous.closed_at==window[0].time and
                        abs(previous.close-previous.open)>=1.2*atr and
                        abs(previous.close-previous.open)>=.6*(previous.high-previous.low),'candidate_preceding_displacement')
            expected=convergence(window,compact=n<24,edge_start=bool(match[1]))
            require(expected is not None,'candidate_formation_unqualified')
            if not expected:return errors
            expected={k:expected[k] for k in ('observed_high','observed_low','frozen_atr','shape','geometry','metrics','checks')}
        for key,value in expected.items():require(box.get(key)==value,'candidate_frozen_'+key+'_source')
        require(bool(box.get('checks')) and all(v is True for v in box['checks'].values()),'candidate_formation_checks')
        require(box.get('confirmed') is False and box.get('score_included') is False,'candidate_confirmation_or_score')
    except (KeyError,TypeError,ValueError,ZeroDivisionError) as exc:
        errors.append('candidate_schema_invalid:'+type(exc).__name__)
    return errors
