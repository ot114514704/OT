"""Recover complete accepted drawings after restart, never a current verdict.

JSON only; the source, calculation generation, engine and whole payload digest
must match. This cache is separate from native OHLC and the freeze ledger.
"""
from hashlib import sha256
import json
import math
from pathlib import Path
import time
from .core import instant

VERSION='accepted_chart_history_v1'


def _encoded(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')


def _source(source):
    if not isinstance(source,dict):raise ValueError('历史图表缺少来源')
    labels={k:source.get(k) for k in ('company','server','symbol')}
    if (source.get('status')!='verified' or labels['company']!='TradeMax Global Limited'
        or not isinstance(labels['server'],str) or not labels['server'].casefold().startswith('trademaxglobal-')
        or labels['symbol']!='XAUUSD'):
        raise ValueError('历史图表来源不匹配TMGM/XAUUSD')
    return labels


class AcceptedModelStore:
    def __init__(self,path,engine,generation):
        self.path=Path(path);self.engine=engine;self.generation=generation

    def _validate(self,body):
        if (body.get('version')!=VERSION or body.get('engine')!=self.engine
            or body.get('calculation_version')!=self.generation):
            raise ValueError('历史图表版本与当前引擎不匹配')
        _source({**body['source'],'status':'verified'})
        integrity=body['freeze_integrity']
        if integrity.get('passed') is not True or integrity.get('engine')!=self.engine:
            raise ValueError('历史图表未通过冻结证据校验')
        if not isinstance(body.get('model_revision'),str) or not body['model_revision']:
            raise ValueError('历史图表缺少版本号')
        for key in ('saved_at','model_updated_at'):
            stamp=body[key]
            if isinstance(stamp,bool) or not isinstance(stamp,(int,float)) or not math.isfinite(stamp) or stamp<=0:
                raise ValueError('历史图表时间无效')
        charts=body['charts']
        if set(charts)!= {'H1','M15'}:raise ValueError('历史图表缺少完整双周期')
        for period,c in charts.items():
            rows=c['bars'];phases=c['phase_rows'];end=instant(c['closed_end'])
            if c['period']!=period or not rows or not phases:raise ValueError('历史图表内容不完整')
            if instant(rows[-1]['closed_at'])!=end or instant(phases[-1]['known_at'])!=end:
                raise ValueError('历史图表收盘边界不一致')
            previous=None
            for row in rows:
                start=instant(row['time']);close=instant(row['closed_at'])
                if row.get('forming') or close<=start or close>end or (previous is not None and start<previous):
                    raise ValueError('历史图表含未收盘、重复或倒序K线')
                previous=close
                o,h,l,cost=(row[k] for k in ('open','high','low','close'))
                if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in (o,h,l,cost)):
                    raise ValueError('历史图表价格无效')
                if not l<=min(o,cost)<=max(o,cost)<=h:raise ValueError('历史图表OHLC无效')
            if any(instant(p['known_at'])>end for p in phases):raise ValueError('历史图表包含未来结论')
        return body

    def save(self,state):
        if state.get('status')!='connected' or state.get('model_origin')!='native' or state.get('data_revision_pending'):
            raise ValueError('只保存已接受的原生收盘模型')
        if any((state.get('latest_closed_end') or {}).get(p)!=c['closed_end'] for p,c in state['charts'].items()):
            raise ValueError('模型尚未追上原生收盘数据')
        body=dict(version=VERSION,engine=self.engine,calculation_version=self.generation,
                  source=_source(state.get('market_source')),freeze_integrity=state['freeze_integrity'],
                  charts=state['charts'],model_revision=state['model_revision'],
                  model_updated_at=state['model_updated_at'],saved_at=time.time())
        self._validate(body)
        encoded=_encoded(body)
        # Embed the already encoded JSON once. Encoding a full annotated model
        # twice would add avoidable GIL time to the independent quote reader.
        document=b'{"sha256":"'+sha256(encoded).hexdigest().encode('ascii')+b'","payload":'+encoded+b'}'
        self.path.parent.mkdir(parents=True,exist_ok=True)
        temp=self.path.with_suffix(self.path.suffix+'.tmp')
        temp.write_bytes(document);temp.replace(self.path)
        return dict(status='saved',model_revision=body['model_revision'],saved_at=body['saved_at'],bytes=len(document))

    def load(self):
        if not self.path.exists():return None
        doc=json.loads(self.path.read_text(encoding='utf-8'))
        body=doc['payload']
        if sha256(_encoded(body)).hexdigest()!=doc['sha256']:raise ValueError('历史图表完整性校验失败')
        return self._validate(body)
