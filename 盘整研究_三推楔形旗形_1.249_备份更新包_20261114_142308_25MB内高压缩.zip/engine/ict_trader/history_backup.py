"""Consistent, source-bound snapshots of the MT5 historical drawing index.

Restore missing indexes only. Existing destination databases are never replaced
or merged with a different scan's evidence. No terminal or trading API is used.
"""
import argparse
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import time
import tempfile
from .history_generation import CALCULATION_VERSION
from .timeframes import TIMEFRAMES

VERSION='native_history_archive_backup_v1'


def _digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def _scope(version,source,period):
    return hashlib.sha256((version+'\n'+source+'\n'+period).encode()).hexdigest()+'.sqlite3'


def _inspect(path):
    with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)) as db:
        if db.execute('PRAGMA quick_check').fetchall()!=[('ok',)]:raise ValueError('历史索引完整性校验失败')
        expected=dict(scans={'scope','evidence','start','end'},
                      records={'scope','id','start','end','known','cutoff','context','line'})
        for table,columns in expected.items():
            if {row[1] for row in db.execute('PRAGMA table_info('+table+')')}!=columns:
                raise ValueError('历史索引结构不匹配')
        return dict(scans=db.execute('SELECT COUNT(*) FROM scans').fetchone()[0],
                    records=db.execute('SELECT COUNT(*) FROM records').fetchone()[0])


def snapshot_archives(directory,destination,source,archive_version):
    directory=Path(directory);destination=Path(destination)
    destination.mkdir(parents=True,exist_ok=True)
    if (destination/'manifest.json').exists():raise FileExistsError('保留既有历史快照，请使用新目录')
    files=[]
    for period in TIMEFRAMES:
        name=_scope(archive_version,source,period);src=directory/name
        if not src.exists():continue
        target=destination/name
        if target.exists():raise FileExistsError(target)
        with closing(sqlite3.connect(src.resolve().as_uri()+'?mode=ro',uri=True)) as reader:
            with closing(sqlite3.connect(target)) as writer:reader.backup(writer,pages=256,sleep=.01)
        files.append(dict(file=name,period=period,sha256=_digest(target),bytes=target.stat().st_size,**_inspect(target)))
    report=dict(version=VERSION,source=source,archive_version=archive_version,
                calculation_version=CALCULATION_VERSION,created_at=time.time(),files=files,
                policy='Source-bound consistent SQLite backups. Restore missing indexes only; never overwrite existing databases.')
    (destination/'manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report


def restore_missing(snapshot,destination,source,archive_version):
    snapshot=Path(snapshot);destination=Path(destination)
    report=json.loads((snapshot/'manifest.json').read_text('utf-8'))
    if (report.get('version')!=VERSION or report.get('source')!=source or report.get('archive_version')!=archive_version
            or report.get('calculation_version')!=CALCULATION_VERSION):
        raise ValueError('历史快照来源或代际不匹配')
    verified=[]
    for item in report['files']:
        period=item['period']
        if period not in TIMEFRAMES or item['file']!=_scope(archive_version,source,period):raise ValueError('历史快照文件名无效')
        path=snapshot/item['file']
        if _digest(path)!=item['sha256'] or _inspect(path)!=dict(scans=item['scans'],records=item['records']):
            raise ValueError('历史快照摘要或记录数量不匹配')
        verified.append(item)
    destination.mkdir(parents=True,exist_ok=True);restored=[];preserved=[]
    for item in verified:
        target=destination/item['file']
        if target.exists():preserved.append(item['period']);continue
        # Build off-name, then publish atomically without replacing a DB created
        # by the worker meanwhile. The terminal never sees a partly copied DB.
        handle,name=tempfile.mkstemp(prefix='.history_restore_',suffix='.pending',dir=destination)
        pending=Path(name)
        try:
            with os.fdopen(handle,'wb') as writer, (snapshot/item['file']).open('rb') as reader:
                shutil.copyfileobj(reader,writer)
            if _digest(pending)!=item['sha256']:raise ValueError('恢复后的历史快照摘要不匹配')
            try:os.link(pending,target)
            except FileExistsError:preserved.append(item['period']);continue
        finally:pending.unlink(missing_ok=True)
        restored.append(item['period'])
    return dict(restored=restored,preserved_existing=preserved,existing_indexes_overwritten=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--restore',type=Path,required=True)
    parser.add_argument('--destination',type=Path,required=True)
    parser.add_argument('--source',required=True)
    args=parser.parse_args()
    from .viewport_history import VERSION as ARCHIVE_VERSION
    print(json.dumps(restore_missing(args.restore,args.destination,args.source,ARCHIVE_VERSION),ensure_ascii=False))


if __name__=='__main__':main()
