"""Versioned, source-separated history index. Geometry is stored verbatim.

Each scan is a replaceable snapshot, not an irreversible confirmation. Queries
prefer the most recent evidence for an identity. No merging or stretching rails.
"""
import hashlib
from contextlib import contextmanager
from pathlib import Path
import sqlite3


class HistoryArchive:
    def __init__(self, directory, version, source, period):
        scope = hashlib.sha256((version+'\n'+source+'\n'+period).encode()).hexdigest()
        directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
        self.path = directory/(scope+'.sqlite3')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.executescript('''
          CREATE TABLE IF NOT EXISTS scans (
            scope TEXT PRIMARY KEY, evidence TEXT, start INTEGER, end INTEGER);
          CREATE TABLE IF NOT EXISTS records (
            scope TEXT, id TEXT, start INTEGER, end INTEGER, known INTEGER,
            cutoff INTEGER, context INTEGER, line TEXT, PRIMARY KEY(scope,id));
          CREATE INDEX IF NOT EXISTS records_time ON records(start,end);
        ''')
        try:
            with db: yield db
        finally:
            db.close()

    def remember(self, request, result, evidence):
        start = int(request['bars'][0].time.timestamp())
        end = int(request['bars'][-1].closed_at.timestamp())
        scope = f'{start}:{end}'
        rows = []
        for line in result['records']:
            a = line.split('\t')
            if len(a)!=24 or int(a[0])!=request['seconds']:
                raise ValueError('History record period/schema mismatch')
            if int(a[5])>end: raise ValueError('History record uses future evidence')
            rows.append((scope,a[1],int(a[4]),int(a[6]),int(a[5]),end,end-start,line))
        with self.connect() as db:
            db.execute('INSERT OR REPLACE INTO scans VALUES (?,?,?,?)',(scope,evidence,start,end))
            # A correction to the same evidence window replaces that snapshot.
            db.execute('DELETE FROM records WHERE scope=?',(scope,))
            db.executemany('INSERT INTO records VALUES (?,?,?,?,?,?,?,?)',rows)

    def visible(self, left, right, forming):
        with self.connect() as db:
            rows = db.execute('''SELECT id,line,cutoff FROM records
                WHERE start<=? AND end>=? AND known<=? AND cutoff<=?
                ORDER BY cutoff DESC,context DESC,scope,id''',
                (right,left,forming,forming)).fetchall()
        picked = {}
        for identity,line,cutoff in rows:
            if identity not in picked: picked[identity]=(line,cutoff)
        return picked


def merge_visible(archive, request, result):
    """Merge current identities with stored formations across scan windows.

    Absence in a different scan window is not an invalidation: changing the
    left context changes the state machine's selected candidates. Same-window
    corrections are already replaced by remember() before this merge.

    Prior active-at-cutoff records are labelled historical observations, never
    described as the current live state. The request's state is kept separately.
    """
    current = {line.split('\t')[1]:line for line in result['records']}
    for identity,(line,cutoff) in archive.visible(request['left'],request['right'],request['forming']).items():
        a = line.split('\t')
        if identity in current: continue
        if a[10]=='1' and cutoff<result['end']:
            a[10]='0'; a[21]+='·历史片段末观察'
            a[23]+='~n~历史扫描截止：'+str(cutoff)+'；后续状态待覆盖，不代表现阶段仍在盘整'
        current[identity]='\t'.join(a)
    return [current[k] for k in sorted(current)]
