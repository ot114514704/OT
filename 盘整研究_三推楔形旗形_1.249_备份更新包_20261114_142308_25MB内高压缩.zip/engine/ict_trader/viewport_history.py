"""Read-only MT5 viewport recognition using candles exported by the indicator.

Runs in a separate process: historical scans never occupy the quote reader.
No credentials, SDK, orders or fabricated candles. Atomic replies are bound to
the chart, period and request token. Cached scans contain no account data.
"""
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import cached_property
from pathlib import Path
import hashlib
import json
import multiprocessing
import os
import time

from .core import Bar
from .timeframes import timeframe_seconds
from .ipda_ranges import observe_ranges, phase_evidence
from .macro_consolidation import PARAMETERS as MACRO_PARAMETERS
from .structural_ranges import observe_structures
from .dense_pauses import observe_dense_pauses
from .long_geometry import observe_long_geometry
from .mt5_bridge import display_records
from .history_archive import HistoryArchive, merge_visible
from .display_selection import select_balance_first
from .history_generation import CALCULATION_VERSION

VERSION = 'viewport-history-1.17-backup-standard'
MAX_BARS = 12000


@dataclass(frozen=True)
class NativeBar(Bar):
    calendar_month: bool = False
    calendar_weekends: bool = True

    @cached_property
    def closed_at(self):
        if not self.calendar_month:
            return super().closed_at
        return self.time.replace(year=self.time.year + (self.time.month == 12),
                                 month=self.time.month % 12 + 1, day=1)


def parse_request(text):
    lines = text.splitlines()
    if not lines:
        raise ValueError('Empty history snapshot')
    h = lines[0].split('\t')
    if not ((len(h)==11 and h[:2]==['IPDA_HISTORY','1']) or
            (len(h)==12 and h[:2]==['IPDA_HISTORY','2'] and h[11].strip())):
        raise ValueError('Invalid history header')
    token, symbol, period = h[2:5]
    seconds, forming, left, right, count = map(int, h[5:10])
    if not token or symbol != 'XAUUSD' or timeframe_seconds(period) != seconds:
        raise ValueError('Symbol/period mismatch')
    if not 1 <= count <= MAX_BARS or len(lines) != count + 2:
        raise ValueError('Incomplete or oversized candle snapshot')
    if lines[-1] != f'END\t{token}\t{count}':
        raise ValueError('Incomplete snapshot trailer')
    bars = []
    for line in lines[1:-1]:
        a = line.split('\t')
        if len(a) != 7: raise ValueError('Invalid candle')
        stamp, closed = map(int, a[:2])
        b = NativeBar(datetime.fromtimestamp(stamp, timezone.utc),
                      *(float(v) for v in a[2:]), seconds=seconds,
                      calendar_month=period == 'MN1')
        if b.calendar_month and (b.time.day != 1 or b.time.hour or b.time.minute or b.time.second):
            raise ValueError('Monthly candle must open at calendar month start')
        if int(b.closed_at.timestamp()) != closed or closed > forming:
            raise ValueError('Forming candle or wrong calendar close')
        if bars and bars[-1].closed_at > b.time:
            raise ValueError('Overlapping/out-of-order candles')
        bars.append(b)
    if left > right or left < int(bars[0].time.timestamp()) or right > int(bars[-1].closed_at.timestamp()):
        raise ValueError('Visible range is not covered')
    return dict(token=token, symbol=symbol, period=period, seconds=seconds,
                forming=forming, left=left, right=right, bars=bars,
                quote_time=int(h[10]), source=h[11] if len(h)==12 else None)


def recognize(request):
    bars=request['bars']; cutoff=bars[-1].closed_at
    chart={'closed_end':cutoff.isoformat()}
    for name,params,level,basis in [('macro_ranges',MACRO_PARAMETERS,'macro','liquidity'),
                                  ('consolidations',None,'local','body')]:
        observed=observe_ranges(bars,cutoff,parameters=params,level=level,breakout_basis=basis)
        boxes={}
        for row in observed['rows']:
            evidence=phase_evidence(row,bars)
            box=evidence['range'] or evidence['ended']
            if box:
                box['active']=evidence['range'] is not None
                boxes[box['id']]=box
        chart[name]=list(boxes.values())
    chart['structural_ranges']=observe_structures(bars,cutoff,short_channels=True)['ranges']+observe_dense_pauses(bars,cutoff)
    chart['geometric_ranges']=observe_long_geometry(bars,cutoff,compact_scales=True)['ranges']
    records=[line for _,line in display_records({request['period']:chart})]
    active=sum(bool(b.get('active')) for k in ('consolidations','macro_ranges') for b in chart[k])
    candidates=sum(bool(b.get('active')) for k in ('structural_ranges','geometric_ranges') for b in chart[k])
    state='已确认盘整' if active else '形态候选' if candidates else '未满足盘整条件'
    if len(bars)<24:state='样本不足'
    return dict(records=records, state=state, count=len(bars),
                start=int(bars[0].time.timestamp()), end=int(cutoff.timestamp()),
                version=VERSION)


def atomic_text(path,text):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(text,encoding='utf-8');tmp.replace(path)


def process_request(path, cache_dir):
    text=path.read_text('utf-8-sig');request=parse_request(text)
    # A changed token or quote does not invalidate identical closed evidence.
    key=hashlib.sha256((CALCULATION_VERSION+str(request['source'])+request['period']+'\n'+'\n'.join(text.splitlines()[1:-1])).encode()).hexdigest()
    cached=cache_dir/(key+'.json');start=time.monotonic()
    if cached.exists():result=json.loads(cached.read_text('utf-8'))
    else:
        result=recognize(request)
        cache_dir.mkdir(parents=True,exist_ok=True)
        atomic_text(cached,json.dumps(result,ensure_ascii=False))
    if request['source']:
        archive=HistoryArchive(cache_dir/'archive',VERSION,request['source'],request['period'])
        archive.remember(request,result,key)
        # Background pages only populate the persistent index. Foreground
        # scans retrieve complete matching formations across previous windows.
        if path.name.startswith('viewport_'):
            result={**result,'records':merge_visible(archive,request,result)}
    # Archive every measured record; suppress competing drawings only in the
    # response. Changing selection must never delete the historical evidence.
    if path.name.startswith('viewport_'):
        result={**result,'records':select_balance_first(result['records'])}
    # Do not publish an old view after the user has requested another one.
    if path.read_text('utf-8-sig') != text:return False
    fields=['IPDA_VIEW','1',request['token'],request['symbol'],request['period'],request['seconds'],
            result['start'],result['end'],request['left'],request['right'],
            result['state'],len(result['records']),result['count'],round(time.monotonic()-start,3)]
    reply='\t'.join(map(str,fields))+'\n'+'\n'.join(result['records'])
    if result['records']:reply+='\n'
    reply+=f"END\t{request['token']}\t{len(result['records'])}\n"
    atomic_text(path.with_name(path.name.replace('.request.tsv','.reply.tsv')),reply)
    return True


def serve(directory):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    seen={};parent=multiprocessing.parent_process()
    while parent is None or parent.is_alive():
        atomic_text(directory/'history_worker.json',json.dumps(dict(version=VERSION,pid=os.getpid(),updated_at=time.time())))
        # Process each chart once per pass; a noisy chart cannot starve another.
        paths=list(directory.glob('viewport_*.request.tsv'))+list(directory.glob('backfill_*.request.tsv'))
        # Visible requests first; at most one background page per pass.
        background_done=False
        for path in sorted(paths,key=lambda p:(p.name.startswith('backfill_'),p.stat().st_mtime)):
            try:
                background=path.name.startswith('backfill_')
                if background and background_done:continue
                stamp=path.stat().st_mtime_ns
                if seen.get(path)==stamp or time.time()-path.stat().st_mtime>180:continue
                process_request(path,directory/'history_cache')
                seen[path]=stamp
                if background:background_done=True
            except Exception as exc:
                # Partial writes and temporary sharing violations are retried.
                atomic_text(directory/'history_error.json',json.dumps(dict(file=path.name,error=str(exc),at=time.time())))
                try:
                    header=path.read_text('utf-8-sig').splitlines()[0].split('\t')
                    if len(header) in (11,12) and header[0]=='IPDA_HISTORY':
                        message=str(exc).replace('\n',' ').replace('\t',' ')
                        atomic_text(path.with_name(path.name.replace('.request.tsv','.error.tsv')),
                                    f'IPDA_ERROR\t1\t{header[2]}\t{message}\n')
                except (OSError,IndexError):pass
        time.sleep(.4)


def start_service(config):
    settings=json.loads(Path(config).read_text('utf-8'))
    if not settings.get('enabled'):return None
    process=multiprocessing.get_context('spawn').Process(target=serve,args=(settings['files_directory'],),daemon=True)
    process.start();return process
