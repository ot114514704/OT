"""Long-scale converging price candidates, independent of IPDA confirmation.

Search boundary pairs among already confirmed pivots, rather than the last two
minor turns. Freeze the chosen actual anchors at first observation. A candidate
is not a probability, an IPDA accumulation confirmation, or a direction call.
"""
from copy import deepcopy
from itertools import combinations
from statistics import median
from .core import instant,visible
from .oscillation import strong_oscillation
from .dense_pauses import compact_swings

VERSION='long_converging_candidate_v1'
PARAMETERS=dict(windows_m15=[24,36,48,96],windows_h1=[24,48],pivot_radius=3,
    minimum_anchor_span=12,minimum_overlap_bars=12,maximum_pivots_per_side=8,
    short_pivot_radius=1,short_anchor_span=4,short_overlap_bars=4,
    boundary_tolerance_atr=.15,single_edge_wick_coverage_min=.9,single_edge_close_coverage_min=.95,
    wick_coverage_min=.8,close_coverage_min=.9,contraction_max=.85,flat_width_fraction=.05,
    width_atr_min=3.,width_atr_max=18.,efficiency_max=.35,largest_body_to_width_max=.5,exit_closes=2)


def line_value(points,time):
    a,b=points;t=instant(time);ta=instant(a['time']);tb=instant(b['time'])
    return a['price']+(b['price']-a['price'])*(t-ta).total_seconds()/(tb-ta).total_seconds()


def candidate(bars,*,compact=False,edge_start=False):
    n=len(bars);short=bool(bars and (compact or bars[0].seconds<3600 and n<48))
    radius=PARAMETERS['short_pivot_radius'] if short else PARAMETERS['pivot_radius']
    min_span=PARAMETERS['short_anchor_span'] if short else PARAMETERS['minimum_anchor_span']
    min_overlap=PARAMETERS['short_overlap_bars'] if short else PARAMETERS['minimum_overlap_bars']
    if compact:min_span=2;min_overlap=2 if n<12 else 4
    if n<2*radius+min_overlap:return None
    if any(a.seconds!=b.seconds or (a.closed_at!=b.time and (not compact or not 0<(b.time-a.closed_at).total_seconds()<=3*3600)) for a,b in zip(bars,bars[1:])):return None
    # Compact native structures may cross a short session closure. Fit and
    # validate in elapsed time, matching the frozen rails used on later bars.
    coordinates=[(b.time-bars[0].time).total_seconds()/bars[0].seconds for b in bars]
    atr=median(b.high-b.low for b in bars)
    if atr<=0:return None
    highs=[];lows=[]
    if edge_start and compact:
        # A post-displacement boundary touch has no left-side pivot proof.
        # Its following CLOSED bar must corroborate that boundary instead.
        p=dict(index=0,time=bars[0].time.isoformat(),known_at=bars[1].closed_at.isoformat(),anchor_kind='boundary_touch')
        if bars[1].high<bars[0].high:highs.append({**p,'price':bars[0].high})
        if bars[1].low>bars[0].low:lows.append({**p,'price':bars[0].low})
    for i in range(radius,n-radius):
        b=bars[i];left=bars[i-radius:i];right=bars[i+1:i+radius+1]
        p=dict(index=i,time=b.time.isoformat(),known_at=bars[i+radius].closed_at.isoformat())
        if all(b.high>x.high for x in left) and all(b.high>=x.high for x in right):highs.append({**p,'price':b.high})
        if all(b.low<x.low for x in left) and all(b.low<=x.low for x in right):lows.append({**p,'price':b.low})
    tolerance=PARAMETERS['boundary_tolerance_atr']*atr
    def pairs(points,upper):
        result=[]
        for a,b in combinations(points[-PARAMETERS['maximum_pivots_per_side']:],2):
            if b['index']-a['index']<min_span:continue
            slope=(b['price']-a['price'])/(coordinates[b['index']]-coordinates[a['index']])
            values=[a['price']+slope*(x-coordinates[a['index']]) for x in coordinates]
            # Validate to the latest observed bar, not just the overlap between
            # the anchors: an old attractive line may already have been left.
            segment=range(a['index'],n)
            if upper:
                wick=sum(bars[i].high<=values[i]+tolerance for i in segment)/(n-a['index'])
                close=sum(bars[i].close<=values[i]+tolerance for i in segment)/(n-a['index'])
                last=bars[-1].close<=values[-1]+tolerance
            else:
                wick=sum(bars[i].low>=values[i]-tolerance for i in segment)/(n-a['index'])
                close=sum(bars[i].close>=values[i]-tolerance for i in segment)/(n-a['index'])
                last=bars[-1].close>=values[-1]-tolerance
            # One isolated wick can test outside a short rail; closes must remain
            # covered. Repeated outside wicks still reject the candidate.
            wick_limit=max(.8,1-1/(n-a['index'])) if compact else PARAMETERS['single_edge_wick_coverage_min']
            if last and wick>=wick_limit and close>=PARAMETERS['single_edge_close_coverage_min']:
                result.append(dict(points=[a,b],values=values))
        return result
    upper=pairs(highs,True);lower=pairs(lows,False)
    if not upper or not lower:return None
    travel=sum(abs(b.close-a.close) for a,b in zip(bars,bars[1:]));efficiency=abs(bars[-1].close-bars[0].close)/travel if travel else 0.
    physical_high=max(b.high for b in bars);physical_low=min(b.low for b in bars);width=physical_high-physical_low
    oscillation=strong_oscillation(bars,atr,width)
    # Small native-period triangles need their own amplitude scale. Actual
    # confirmed high/low pairs and all boundary coverage checks remain required.
    if compact and not oscillation['qualified'] and (edge_start or not oscillation['recent_impulse']) and not oscillation['unreversed_displacements']:
        oscillation=compact_swings(bars,atr,width)
        # Four confirmed boundary pivots are independently required above.
        # One completed close swing each way is enough to corroborate a
        # contracting shape; a third full-width leg can disappear as it narrows.
        oscillation={**oscillation,'qualified':oscillation['completed_legs']>=2 and oscillation['up_legs']>0 and oscillation['down_legs']>0,
                     'basis':'compact_convergence_two_sided_reversals_and_four_pivots'}
    checks=dict(balanced=efficiency<=PARAMETERS['efficiency_max'],strong_oscillation=oscillation['qualified'],
                structural_width=(1.25 if compact else PARAMETERS['width_atr_min'])<=width/atr<=PARAMETERS['width_atr_max'],
                no_dominant_bar=max(abs(b.close-b.open) for b in bars)<=(.70 if edge_start else PARAMETERS['largest_body_to_width_max'])*width)
    if not all(checks.values()):return None
    best=None;rank=None
    for u in upper:
        for l in lower:
            up=u['points'];low=l['points'];start=max(up[0]['index'],low[0]['index']);end=min(up[1]['index'],low[1]['index'])
            seeded=any(p.get('anchor_kind')=='boundary_touch' for p in up+low)
            if edge_start and not seeded:continue
            # Compact pairs often alternate (H,L,H,L). Requiring both second
            # anchors at the same time truncates a valid triangle. The rails
            # were already validated through the last CLOSED observation above;
            # include that observed span, never project into future candles.
            if compact:end=n-1
            overlap=end-start+1
            if overlap<min_overlap:continue
            uh,ul=u['values'][start],u['values'][end];lh,ll=l['values'][start],l['values'][end]
            if not 0<ul-ll<uh-lh or u['values'][-1]<=l['values'][-1]:continue
            contraction=(ul-ll)/(uh-lh)
            if contraction>PARAMETERS['contraction_max']:continue
            window=range(start,n)
            wick=sum(bars[i].high<=u['values'][i]+tolerance and bars[i].low>=l['values'][i]-tolerance for i in window)/(n-start)
            close=sum(l['values'][i]-tolerance<=bars[i].close<=u['values'][i]+tolerance for i in window)/(n-start)
            if wick<PARAMETERS['wick_coverage_min'] or close<PARAMETERS['close_coverage_min']:continue
            flat=PARAMETERS['flat_width_fraction']*(uh-lh);du=ul-uh;dl=ll-lh
            subtype='ascending_triangle' if abs(du)<=flat and dl>0 else 'descending_triangle' if abs(dl)<=flat and du<0 else 'triangle' if du<0 and dl>0 else 'rising_wedge' if du>0 and dl>0 else 'falling_wedge' if du<0 and dl<0 else None
            if not subtype:continue
            # Ranking uses time/coverage, never direction or future outcome.
            key=(overlap,min(wick,close),min(up[1]['index']-up[0]['index'],low[1]['index']-low[0]['index']),
                 tuple(sorted(p['index'] for p in up+low)))
            if rank is not None and key<=rank:continue
            rank=key
            def point(i,price):return dict(time=bars[i].time.isoformat(),price=price)
            strip=lambda p:{k:v for k,v in p.items() if k!='index'}
            geometry=dict(upper=[strip(p) for p in up],lower=[strip(p) for p in low],
                frame=[point(start,uh),point(end,ul),point(end,ll),point(start,lh)],
                ready=True,validated=True,subtype=subtype,projected=False,basis='long_scale_confirmed_boundary_pairs',
                known_at=max(p['known_at'] for p in up+low),pivot_radius=radius,contraction_ratio=contraction,
                reason='长尺度已确认锚点及截至首次观察的覆盖验证通过；仅画锚点与共同覆盖区间',
                gaps=[dict(after=a.closed_at.isoformat(),before=b.time.isoformat()) for a,b in zip(bars,bars[1:]) if a.closed_at!=b.time],
                validation=dict(overlap_bars=overlap,validation_bars=n-start,wick_coverage=wick,close_coverage=close,tolerance=tolerance))
            if seeded:
                geometry.update(basis='post_displacement_boundary_touch_and_confirmed_pivots',
                    reason='强位移后首根边界触点获后续收盘支持；其余锚点为已确认摆动点；触点不冒充左侧已确认拐点')
            best=dict(observed_from=bars[0].time.isoformat(),first_observed_at=bars[-1].closed_at.isoformat(),
                known_at=bars[-1].closed_at.isoformat(),window=n,shape='converging',geometry=geometry,
                observed_high=physical_high,observed_low=physical_low,frozen_atr=atr,checks={**checks,'confirmed_boundary_pairs':True,'covered_contraction':True,'last_close_inside':True},
                metrics=dict(efficiency=efficiency,width_atr=width/atr,overlap_bars=overlap,oscillation=oscillation,
                             contraction_ratio=contraction,wick_coverage=wick,close_coverage=close),
                confirmed=False,score_included=False,
                missing=['IPDA实体平衡确认独立判断','机构积累/派发意图未验证','截图人工边界尚未逐点精确复现'])
            if seeded:
                best['checks'].pop('confirmed_boundary_pairs',None)
                best['checks']['boundary_touch_and_confirmed_pivots']=True
                best['missing'].append('首根边界触点没有左侧局部拐点确认；仅独立形态候选')
    return best


def observe_long_geometry(bars,asof,*,compact_scales=False,_edge_scan=False):
    bars=visible(bars,asof)
    if not bars:return dict(version=VERSION,ranges=[],current=[],history=[])
    if any(a.time>=b.time or a.seconds!=b.seconds for a,b in zip(bars,bars[1:])):raise ValueError('Ordered homogeneous bars required')
    windows=list(PARAMETERS['windows_h1' if bars[0].seconds>=3600 else 'windows_m15']);active={};ranges=[];history=[]
    if compact_scales:windows=sorted(set(windows+[8,10,12,16]),reverse=True)
    if _edge_scan:windows=[8,10,12]
    for i,b in enumerate(bars):
        for n in windows:
            box=active.get(n)
            if box:
                g=box['geometry'];upper=line_value(g['upper'],b.time);lower=line_value(g['lower'],b.time)
                gap=i and bars[i-1].closed_at!=b.time
                side=1 if b.close>upper+PARAMETERS['boundary_tolerance_atr']*box['frozen_atr'] else -1 if b.close<lower-PARAMETERS['boundary_tolerance_atr']*box['frozen_atr'] else 0
                box['streak']=box['streak']+1 if side and side==box['side'] else 1 if side else 0
                box.update(end_at=b.closed_at.isoformat(),side=side)
                status='数据间隔中止斜线候选' if gap else '边线交会，斜线候选失效' if upper<=lower else ('向上离开斜线观察区' if side==1 else '向下离开斜线观察区') if box['streak']>=PARAMETERS['exit_closes'] else None
                if status:
                    box.update(status=status,active=False);del active[n]
                    history.append(dict(known_at=b.closed_at.isoformat(),event='long_geometry_ended',range_id=box['id'],title=status,
                        detail='结束长尺度形态候选；不充当IPDA确认或交易信号',confirmed_bar_only=True))
                elif not side:
                    # Keep original anchors and first-observation evidence frozen.
                    # Only the display span follows later CLOSED, contained bars.
                    display=deepcopy(g)
                    start=g['frame'][0]['time'];end=b.time.isoformat()
                    display['frame']=[dict(time=start,price=line_value(g['upper'],start)),
                        dict(time=end,price=upper),dict(time=end,price=lower),
                        dict(time=start,price=line_value(g['lower'],start))]
                    display.update(display_through=b.closed_at.isoformat(),
                        basis='frozen_rails_through_observed_contained_closes')
                    box['display_geometry']=display
                continue
            if i+1<n:continue
            compact=compact_scales and n<24
            if _edge_scan:
                start=i-n+1
                if start<1 or bars[start-1].closed_at!=bars[start].time:continue
                prior=bars[start-1];atr=median(x.high-x.low for x in bars[start:i+1])
                if abs(prior.close-prior.open)<1.2*atr or abs(prior.close-prior.open)<.6*(prior.high-prior.low):continue
            c=candidate(bars[i-n+1:i+1],compact=compact,edge_start=_edge_scan)
            if c is None:continue
            box={**deepcopy(c),'id':VERSION+(':edge' if _edge_scan else '')+':'+str(n)+':'+b.closed_at.isoformat(),'end_at':b.closed_at.isoformat(),
                 'active':True,'status':'长尺度收敛形态候选','side':0,'streak':0}
            active[n]=box;ranges.append(box)
            history.append(dict(known_at=b.closed_at.isoformat(),event='long_geometry_entered',range_id=box['id'],title='出现长尺度收敛候选',
                detail=f"{n}根已收盘样本；锚点需其后{PARAMETERS['short_pivot_radius'] if compact or bars[0].seconds<3600 and n<48 else PARAMETERS['pivot_radius']}根收盘可知；形态边界此时冻结，不计分",confirmed_bar_only=True))
    if compact_scales and not _edge_scan:
        extra=observe_long_geometry(bars,asof,compact_scales=True,_edge_scan=True)
        ranges+=extra['ranges'];history=sorted(history+extra['history'],key=lambda e:e['known_at'])
        return dict(version=VERSION,parameters=PARAMETERS,ranges=ranges,current=list(active.values())+extra['current'],history=history[-24:])
    return dict(version=VERSION,parameters=PARAMETERS,ranges=ranges,current=list(active.values()),history=history[-24:])
