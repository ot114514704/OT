"""Standalone read-only IPDA retracement workbench. Run: python app.py."""
import argparse
import json
import math
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from functools import partial

from ict_trader.core import Bar, instant
from ict_trader.model_runner import LatestModelRunner
from ict_trader.model_compute import IsolatedModelCalculator
from ict_trader.calculation_timing import CalculationTrace,measured
from ict_trader.model_publication import PreparedModel,PublicationRunner
from ict_trader.analysis_cache import H1AnalysisCache
from ict_trader.accepted_model import AcceptedModelStore
from ict_trader.history_generation import CALCULATION_VERSION
from ict_trader.native_reader import IsolatedNativeReader
from ict_trader.history_store import HistoryStore
from ict_trader.freeze_ledger import FreezeLedger,engine_fingerprint
from ict_trader.current_consolidation import live_reports, state_history, current_candidate_overlay
from ict_trader.macro_consolidation import analyze_macro
from ict_trader.source_revisions import source_revisions
from ict_trader.swing_balance import observe_swing_candidates, swing_history
from ict_trader.structural_ranges import observe_structures
from ict_trader.dense_pauses import observe_dense_pauses
from ict_trader.long_geometry import observe_long_geometry
from ict_trader.intraday_projection import attach_intraday_projection
from ict_trader.mt5_bridge import MT5Bridge,current_bridge_status
from ict_trader.reference_targets import attach_targets
from ict_trader.market_source import inspect_source, MarketSourceError
from ict_trader.phase_scores import attach_scores
from ict_trader.ipda_phases import detect_phases
from ict_trader.h1_channels import observe_channels
from ict_trader.cisd import observe_cisd
from ict_trader.delivery_context import build_delivery_context
from ict_trader.retracement_validation import attach_retracement_validation
from ict_trader.retracement_episodes import refine_retracement_phases

ROOT=Path(__file__).resolve().parent
SNAPSHOT_DIR=None
LOCK=threading.Lock()
STATE=dict(status='starting',message='正在读取独立项目数据',charts={},quote=None,analysis_error=None,model_revision=None)
STARTED_AT=time.time()
HISTORY_PROCESS=None

@dataclass(frozen=True)
class NativeRead:
    raw: dict
    forming: dict
    quote: object
    market_source: dict

    def __iter__(self):
        # Preserve the existing adapter's three-value unpacking contract.
        return iter((self.raw,self.forming,self.quote))

def row(b):
    return dict(time=b.time.isoformat(),closed_at=b.closed_at.isoformat(),open=b.open,high=b.high,low=b.low,close=b.close,spread=b.spread)

def analyze(raw, period, h1=None):
    seconds=3600 if period=='H1' else 900
    bars=[Bar(instant(b['time']),*(b[k] for k in ('open','high','low','close')),b.get('spread',0),seconds) for b in raw]
    if not bars:raise ValueError('没有已确认K线')
    if any(a.time>=b.time for a,b in zip(bars,bars[1:])):raise ValueError('行情时间重复或倒序')
    p=dict(period=period,bars=[row(b) for b in bars],evidence_bars=[row(b) for b in bars],window_end=bars[-1].closed_at.isoformat(),
           phases=measured(period+'.phases',detect_phases,bars,bars[-1].closed_at,timeframe_seconds=seconds,background_gap_seconds=3600 if period=='H1' else 0))
    if period=='H1':
        p['channels']=measured(period+'.channels',observe_channels,bars)
    else:
        p['background_channels']=h1['channels']
        p['h1_cisd']=h1['retracement_validation']['native_cisd']
        p['delivery_context']=measured(period+'.context',build_delivery_context,p)
    measured(period+'.scores',attach_scores,p)
    measured(period+'.retracement_validation',attach_retracement_validation,p)
    measured(period+'.retracement_phases',refine_retracement_phases,p,p['retracement_validation'])
    p['macro_consolidation']=measured(period+'.macro_ranges',analyze_macro,bars)
    p['swing_rows']=measured(period+'.swing_candidates',observe_swing_candidates,bars,bars[-1].closed_at)
    p['structural_consolidation']=measured(period+'.structures',observe_structures,bars,bars[-1].closed_at,short_channels=True)
    pauses=measured(period+'.dense_pauses',observe_dense_pauses,bars,bars[-1].closed_at)
    p['structural_consolidation']['ranges'].extend(pauses)
    p['structural_consolidation']['current'].extend(x for x in pauses if x['active'])
    p['long_geometry']=measured(period+'.long_geometry',observe_long_geometry,bars,bars[-1].closed_at,compact_scales=True)
    return p

def project(p):
    evidence={r['bar_open_at']:r for r in p['retracement_validation']['rows']}
    episodes={}
    for r in p['retracement_episodes']['rows']:
        e=r.get('episode') or r.get('ended')
        if not e:continue
        ev=evidence[r['bar_open_at']]
        previous=episodes.get(e['id'])
        terminated=ev['evidence_score']['eligibility'] in ('interrupted','contradicted')
        saved_score=previous['score'] if terminated and previous else ev['evidence_score']
        score_at=previous['score_known_at'] if terminated and previous else r['known_at']
        episodes[e['id']]=dict(**e,score=saved_score,score_known_at=score_at,
            terminal_score=ev['evidence_score'] if terminated else None,checks=r['checks'],missing=r['missing'],
            state=r['state'],observed_at=r['known_at'],protection_source=ev['protection_source'],
            available_pd_zones=ev['available_pd_zones'],end_reason=r.get('end_reason'))
    ranges={};range_events=[]
    for phase in p['phases']:
        ev=phase['consolidation_evidence'];box=ev['range'] or ev['ended']
        if box:
            ranges[box['id']]={**box,'observed_at':phase['known_at'],
                'score':phase['fit_scores']['by_phase']['consolidation'],
                'confirmation_score':ranges.get(box['id'],{}).get('confirmation_score',phase['fit_scores']['by_phase']['consolidation'])}
            if ev['event'] not in (None,'range_held'):
                range_events.append(dict(range_id=box['id'],known_at=phase['known_at'],event=ev['event'],sweep=ev['sweep'],side=box['breakout_side']))
    chart=dict(period=p['period'],bars=p['bars'],episodes=list(episodes.values())[-100:],
        latest=evidence[p['bars'][-1]['time']],closed_end=p['window_end'],
        phase_rows=[{k:r[k] for k in ('bar_open_at','known_at','phase','reason','fit_scores','consolidation_evidence')} for r in p['phases'][-700:]],
        current_history=state_history({'phase_rows':p['phases'],'swing_rows':p['swing_rows']}),
        macro_ranges=p['macro_consolidation']['ranges'],macro_current=p['macro_consolidation']['current'],macro_history=p['macro_consolidation']['history'],
        swing_rows=p['swing_rows'][-700:],swing_history=swing_history(p['swing_rows']),
        structural_ranges=p['structural_consolidation']['ranges'],structural_current=p['structural_consolidation']['current'],
        structural_history=p['structural_consolidation']['history'],
        geometric_ranges=p['long_geometry']['ranges'],geometric_current=p['long_geometry']['current'],geometric_history=p['long_geometry']['history'],
        phase_score_policy=p['phase_score_policy'],consolidations=list(ranges.values()),range_events=range_events[-200:],
        cisd=p['retracement_validation']['native_cisd']['events'][-100:])
    chart['current_candidate']=current_candidate_overlay(chart)
    return chart

def load_seed():
    result={}
    for period in ('H1','M15'):
        path=(SNAPSHOT_DIR or ROOT/'data')/f'{period}.json'
        if not path.exists():path=ROOT/'data'/f'{period}.json'
        result[period]=json.loads(path.read_text('utf-8'))
    return result

def prepare_h1(raw):
    """Retain the full displayed history and every H1 input actually read by M15.

    Intermediate H1 phase/validation objects not exported by project() are
    rebuilt when H1 changes, but need not be copied on every M15 update.
    """
    h=analyze(raw,'H1')
    return dict(chart=measured('H1.project',project,h),background=dict(channels=h['channels'],
                retracement_validation=dict(native_cisd=h['retracement_validation']['native_cisd'])))


def calculate(raw,*,h1_cache=None):
    h=measured('H1.prepare_or_reuse',h1_cache.get if h1_cache is not None else prepare_h1,raw['H1'])
    m=analyze(raw['M15'],'M15',h['background'])
    charts={'H1':h['chart'],'M15':measured('M15.project',project,m)}
    return measured('reference_targets',attach_targets,measured('intraday_projection',attach_intraday_projection,charts))

def market_quote(tick):
    """Reject malformed quotes without discarding independently valid bars."""
    if tick is None:return None
    try:
        bid=float(tick.bid);ask=float(tick.ask);stamp=float(tick.time)
        if not all(math.isfinite(v) for v in (bid,ask,stamp)):return None
        if bid<=0 or ask<bid or stamp<=0 or not stamp.is_integer():return None
        label=datetime.fromtimestamp(int(stamp),timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
        return dict(bid=bid,ask=ask,raw_epoch=int(stamp),raw_time=label)
    except (AttributeError,TypeError,ValueError,OverflowError,OSError):return None


def native():
    # Only market-data methods are exposed; no trading/account routes.
    import MetaTrader5 as mt
    if not mt.initialize(timeout=5000):raise RuntimeError('MT5初始化失败：'+str(mt.last_error()))
    try:
        if not mt.symbol_select('XAUUSD',True):raise RuntimeError('MT5没有XAUUSD品种')
        spec=mt.symbol_info('XAUUSD');tick=mt.symbol_info_tick('XAUUSD')
        if spec is None or not math.isfinite(spec.point) or spec.point<=0:
            raise RuntimeError('MT5 XAUUSD最小报价单位无效，无法转换点差')
        source=inspect_source(mt,spec)
        if source['status']!='verified':raise MarketSourceError(source)
        raw={};forming={}
        for period,tf,count,seconds in [('H1',mt.TIMEFRAME_H1,1001,3600),('M15',mt.TIMEFRAME_M15,3001,900)]:
            rates=mt.copy_rates_from_pos('XAUUSD',tf,0,count)
            if rates is None or len(rates)<40:raise RuntimeError(period+'历史行情不足')
            items=[]
            for r in rates:
                b=Bar(datetime.fromtimestamp(int(r['time']),timezone.utc),*(float(r[k]) for k in ('open','high','low','close')),
                      float(r['spread'])*spec.point,seconds)
                items.append(row(b))
            raw[period]=items[:-1];forming[period]={**items[-1],'forming':True}
        quote=market_quote(tick)
        if quote:quote['market_source']=source
        return NativeRead(raw,forming,quote,source)
    finally:mt.shutdown()

def save_snapshot(raw):
    """Cache failures must not change MT5 connection or model health."""
    directory=SNAPSHOT_DIR or ROOT/'data'
    directory.mkdir(parents=True,exist_ok=True)
    for period,rows in raw.items():
        temp=(directory/period).with_suffix('.tmp')
        temp.write_text(json.dumps(rows,separators=(',',':')),encoding='utf-8')
        temp.replace(directory/f'{period}.json')


def worker(*,executor=None,freeze_store=None,history_store=None,publication_executor=None,model_store=None):
    # The poller owns STATE and cache writes. The model thread receives only
    # an immutable closed-bar copy and never writes shared state directly.
    owned_executor=executor is None
    asynchronous=owned_executor or publication_executor is not None
    owned_publication_executor=asynchronous and publication_executor is None
    if owned_publication_executor:publication_executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='ipda_publish')
    native_reader=IsolatedNativeReader() if owned_executor else None
    history=history_store if history_store is not False else None
    if history_store is None and owned_executor:
        history=HistoryStore((SNAPSHOT_DIR or ROOT/'work'/'live_8773'/'data').parent/'native_history')
    bridge=None
    if owned_executor:
        try:bridge=MT5Bridge.from_config(ROOT/'mt5'/'bridge_settings.json')
        except Exception as exc:
            with LOCK:STATE['mt5_bridge_error']=str(exc)
    executor=executor or ThreadPoolExecutor(max_workers=1,thread_name_prefix='ipda_model')
    isolated_calculator=IsolatedModelCalculator() if owned_executor else None
    calculator=isolated_calculator.calculate if isolated_calculator is not None else calculate
    ledger=None if freeze_store is False else freeze_store
    if freeze_store is None:
        fingerprint=engine_fingerprint(Path(__file__).resolve().parent/'ict_trader')
        cache_root=(SNAPSHOT_DIR or ROOT/'work'/'live_8773'/'data').parent
        ledger=FreezeLedger(cache_root/'freeze_ledger'/(fingerprint+'.json'),fingerprint)
    chart_store=None if model_store is False else model_store
    if model_store is None and owned_executor:
        fingerprint=engine_fingerprint(ROOT/'ict_trader')
        chart_store=AcceptedModelStore((SNAPSHOT_DIR or ROOT/'work'/'live_8773'/'data').parent/'accepted_model.json',
                                       fingerprint,CALCULATION_VERSION)
    signature=None;cached_signature=None;accepted_raw={};latest_raw=None;latest_key=None
    error_key=None
    ledger_lock=threading.Lock()

    def prepare_model(raw):
        began=time.perf_counter();cpu_began=time.thread_time()
        with CalculationTrace() as trace:charts=calculator(raw)
        timings=dict(calculation_wall_seconds=time.perf_counter()-began,
                     calculation_thread_cpu_seconds=time.thread_time()-cpu_began,
                     stages=trace.stages)
        if isolated_calculator is not None:
            child_timing=isolated_calculator.last_timings or {}
            timings.update(calculation_process_wall_seconds=child_timing.get('wall_seconds'),
                           calculation_process_thread_cpu_seconds=child_timing.get('thread_cpu_seconds'),
                           stages=child_timing.get('stages',[]))
        integrity=None
        if ledger:
            try:
                began=time.perf_counter()
                with ledger_lock:
                    acquired=time.perf_counter();cpu_began=time.thread_time()
                    integrity=ledger.inspect(charts,raw)
                timings.update(freeze_lock_wait_seconds=acquired-began,
                               freeze_validation_wall_seconds=time.perf_counter()-acquired,
                               freeze_validation_thread_cpu_seconds=time.thread_time()-cpu_began)
            except Exception as exc:raise RuntimeError('冻结证据校验失败：'+str(exc)) from exc
        return PreparedModel(charts,integrity,timings)

    runner=LatestModelRunner(executor,prepare_model if asynchronous else calculator,time.time)

    def publish_model(state,raw,key,source):
        nonlocal cached_signature
        report={}
        if key is not None and key!=cached_signature:
            try:
                save_snapshot(raw)
                if ledger:
                    with ledger_lock:report['freeze_integrity']=ledger.persist(state['charts'],raw)
                if history:report['history_archive']=history.persist(raw,source)
                if chart_store:report['model_cache']=chart_store.save(state)
            except Exception as exc:report['cache_error']=str(exc)
            else:
                cached_signature=key;report['cache_error']=None
        if bridge:
            try:report.update(mt5_bridge=bridge.update(state),mt5_bridge_error=None)
            except Exception as exc:report['mt5_bridge_error']=str(exc)
        return report

    publisher=PublicationRunner(publication_executor,publish_model) if asynchronous else None

    def collect_publication():
        if publisher is None:return
        completed=publisher.take_ready()
        if completed is None:return
        revision,report,error=completed
        with LOCK:
            if error:STATE['publication_error']=str(error)
            else:
                STATE['publication_error']=None
                for key,value in report.items():
                    if key in ('mt5_bridge','mt5_bridge_error') or revision==STATE.get('model_revision'):STATE[key]=value

    def metadata():
        with LOCK:
            STATE.update(runner.metadata())
            if isolated_calculator is not None:
                model_worker=isolated_calculator.metadata()
                STATE['model_worker']=model_worker
                STATE['h1_analysis_cache']=model_worker['h1_analysis_cache']
            if native_reader:STATE['native_reader']=native_reader.metadata()
            if publisher:STATE.update(publisher.metadata())

    def collect():
        nonlocal signature,accepted_raw,error_key
        completed=runner.take_ready()
        if completed is None:return
        job,charts,error=completed
        prepared=charts if isinstance(charts,PreparedModel) else None
        if prepared is not None:charts=prepared.charts
        with LOCK:
            current=job.key==latest_key and STATE.get('status')=='connected'
            historical=job.origin=='snapshot' and latest_key is None
        if (current or historical) and not error and ledger:
            try:
                integrity=prepared.integrity if prepared is not None else ledger.inspect(charts,job.raw)
                with LOCK:STATE['freeze_integrity']=ledger.public(integrity)
                if not integrity['passed']:error=RuntimeError('冻结证据一致性校验失败，已保留上次模型；详见冻结校验记录')
            except Exception as exc:error=RuntimeError('冻结证据校验失败：'+str(exc))
        with LOCK:
            if not (current or historical):
                STATE['analysis_discarded_results']=STATE.get('analysis_discarded_results',0)+1
            elif error:
                error_key=job.key
                STATE.update(analysis_error=str(error))
                if historical and not STATE.get('charts'):STATE.update(message='初始识别失败')
            else:
                revision=source_revisions(accepted_raw,job.raw)
                signature=job.key;accepted_raw=job.raw;error_key=None
                model_revision=str(time.time_ns());now=time.time()
                STATE.update(charts=charts,analysis_error=None,model_updated_at=now,
                             model_revision=model_revision,model_origin='native' if current else job.origin,
                             model_input_origin=job.origin,
                             data_revision_pending=False,pending_data_revision=None,
                             analysis_finished_at=now,analysis_duration_seconds=max(0,now-job.started_at))
                preparation_timing=(prepared.timings or {}) if prepared is not None else {}
                STATE['analysis_timing']={**(runner.timings(job) or {}),**preparation_timing}
                if historical and STATE.get('status')=='starting':
                    STATE.update(status='snapshot',message='独立历史快照；正在连接MT5')
                if revision and current:
                    STATE['last_data_revision']={**revision,'recomputed_at':now,'model_revision':model_revision}
        metadata()

    def pending():
        if latest_key is None:return
        revision=source_revisions(accepted_raw,latest_raw) if latest_key!=signature else None
        with LOCK:STATE.update(data_revision_pending=bool(revision),pending_data_revision=revision)

    try:
        with LOCK:STATE['worker_heartbeat_at']=time.time()
        restored=None
        if chart_store:
            try:restored=chart_store.load()
            except Exception as exc:
                with LOCK:STATE['model_cache']=dict(status='rejected',error=str(exc))
            if restored:
                with LOCK:
                    STATE.update(charts=restored['charts'],model_origin='cached_history',
                                 model_revision='history:'+restored['model_revision'],
                                 model_updated_at=restored['model_updated_at'],
                                 message='已恢复上次完整图表；历史结果等待原生收盘重算',
                                 model_cache=dict(status='restored_history',saved_at=restored['saved_at']))
        try:
            if restored is None:
                seed=load_seed();runner.start(seed,json.dumps(seed,sort_keys=True),'snapshot')
                metadata();collect()
        except Exception as exc:
            with LOCK:STATE.update(analysis_error=str(exc),message='初始识别失败')
        while True:
            loop_started=time.monotonic();stage_started=loop_started;poll_stages={}
            should_cache=False
            def stage(name):
                nonlocal stage_started
                now=time.monotonic();poll_stages[name]=round(now-stage_started,4);stage_started=now
            with LOCK:STATE['worker_heartbeat_at']=time.time()
            try:
                reading=NativeRead(**native_reader.read()) if native_reader else native()
                raw,forming,quote=reading
                source=getattr(reading,'market_source',None) or (quote or {}).get('market_source')
                stage('native_read')
            except Exception as exc:
                latest_key=None;latest_raw=None
                source=getattr(exc,'market_source',None)
                with LOCK:
                    STATE.update(status=source['status'] if source else 'disconnected',message=str(exc),read_error=str(exc))
                    if source:STATE['market_source']=source
                # A seed may still become available as explicit history, but
                # disconnected/superseded native jobs cannot update the model.
                collect_publication();collect();metadata()
                stage('read_failure_and_collect')
            else:
                history_error=None
                if history:
                    try:
                        raw,report=history.prepare(raw,source)
                        with LOCK:STATE['history_archive']=report
                    except Exception as exc:history_error='历史存档读取/合并失败：'+str(exc)
                stage('history_prepare')
                key=None if history_error else json.dumps(raw,sort_keys=True)
                latest_raw=raw;latest_key=key
                with LOCK:
                    old=STATE.get('quote') or {}
                    if not history_error and (key==signature or key!=error_key):STATE['analysis_error']=None
                    if quote and quote!=old:STATE['last_tick_change_at']=time.time()
                    STATE.update(status='connected',message='MT5已连接',read_error=None,quote=quote,
                                 polled_at=time.time(),forming=forming,
                                 latest_closed_end={p:items[-1]['closed_at'] for p,items in raw.items() if items and 'closed_at' in items[-1]})
                    if source:STATE['market_source']=source
                    STATE['history_error']=history_error
                    previous_poll=STATE.get('previous_poll_at')
                    if previous_poll is not None:STATE['poll_interval_seconds']=round(STATE['polled_at']-previous_poll,4)
                    STATE['previous_poll_at']=STATE['polled_at']
                stage('publish_quote')
                # Compare against the latest successful read before accepting
                # a completed model. Older work is discarded, never queued up.
                collect_publication();collect();pending()
                if not history_error and runner.job is None and key!=signature:
                    try:runner.start(raw,key,'native')
                    except Exception as exc:
                        error_key=key
                        with LOCK:STATE.update(analysis_error=str(exc))
                    metadata();collect();pending()
                stage('model_collect_and_start')
                should_cache=not history_error and key==signature
                if not asynchronous and should_cache and key!=cached_signature:
                    try:
                        save_snapshot(raw)
                        if ledger:
                            integrity=ledger.persist(STATE['charts'],raw)
                            with LOCK:STATE['freeze_integrity']=integrity
                        if history:
                            report=history.persist(raw,source)
                            with LOCK:STATE['history_archive']=report
                    except Exception as exc:
                        with LOCK:STATE.update(cache_error=str(exc))
                    else:
                        cached_signature=key
                        with LOCK:STATE.update(cache_error=None)
                stage('persist_accepted_model')
                if history_error:
                    # Keep quotes and the previous accepted model available;
                    # never silently drop an unreadable historical prefix.
                    with LOCK:STATE['analysis_error']=history_error
            metadata()
            if publisher:
                with LOCK:publication_state=dict(STATE)
                publisher.start(publication_state,accepted_raw,signature if should_cache else None,source)
                metadata()
            elif bridge:
                # Export accepted model drawings only. File errors cannot
                # disconnect MT5, change a verdict or restart calculation.
                try:
                    with LOCK:bridge_state=dict(STATE)
                    exported=bridge.update(bridge_state)
                    with LOCK:STATE.update(mt5_bridge=exported,mt5_bridge_error=None)
                except Exception as exc:
                    with LOCK:STATE['mt5_bridge_error']=str(exc)
            stage('bridge_and_metadata')
            elapsed=time.monotonic()-loop_started
            with LOCK:
                STATE.update(worker_heartbeat_at=time.time(),poll_stage_seconds=poll_stages,poll_work_seconds=round(elapsed,4))
                if elapsed>2:STATE['last_slow_poll']=dict(at=time.time(),work_seconds=round(elapsed,4),stages=dict(poll_stages))
            # Target a two-second cycle rather than adding two seconds after
            # every read, cache commit and export. Slow work remains explicit.
            time.sleep(max(.05,2-elapsed))
    finally:
        if native_reader:native_reader.close()
        if owned_executor:executor.shutdown(wait=False,cancel_futures=True)
        if owned_publication_executor:publication_executor.shutdown(wait=False,cancel_futures=True)
        if isolated_calculator is not None:isolated_calculator.close()

def response_payload(state,now,include_charts=True):
    """Same current verdict for lightweight polls and full model snapshots."""
    payload={k:v for k,v in state.items() if include_charts or k!='charts'}
    if state.get('mt5_bridge'):
        payload['mt5_bridge']=current_bridge_status(state['mt5_bridge'],state.get('model_revision'),now)
    return {**payload,'api_version':'ipda_live_v1','server_now':now,
            'has_charts':bool(state.get('charts')),'current_consolidation':live_reports(state,now)}


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path=self.path.split('?')[0]
        if path=='/api/runtime':
            with LOCK:
                payload=dict(service='ipda_consolidation',project_root=str(ROOT),process_id=os.getpid(),started_at=STARTED_AT,
                             supervisor_pid=os.environ.get('IPDA_SUPERVISOR_PID'),server_now=time.time(),
                             worker_heartbeat_at=STATE.get('worker_heartbeat_at'),status=STATE.get('status'),
                             model_revision=STATE.get('model_revision'),
                             analysis_running=STATE.get('analysis_running',False),analysis_started_at=STATE.get('analysis_started_at'),
                             analysis_target_closed_end=STATE.get('analysis_target_closed_end'),
                             h1_analysis_cache=STATE.get('h1_analysis_cache'),
                             model_worker=STATE.get('model_worker'),
                             analysis_duration_seconds=STATE.get('analysis_duration_seconds'),
                             analysis_timing=STATE.get('analysis_timing'),
                             analysis_discarded_results=STATE.get('analysis_discarded_results',0),
                             history_worker_alive=bool(HISTORY_PROCESS and HISTORY_PROCESS.is_alive()),
                             history_worker_pid=HISTORY_PROCESS.pid if HISTORY_PROCESS else None)
            body=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode();mime='application/json; charset=utf-8'
        elif path in ('/api/state','/api/live'):
            with LOCK:
                payload=response_payload(STATE,time.time(),include_charts=path=='/api/state')
            body=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()
            mime='application/json; charset=utf-8'
        elif path in ('/reference/1.png','/reference/2.png','/reference/3.png','/reference/4.png','/reference/5.png','/reference/6.jpg','/reference/7.jpg','/reference/8.jpg','/reference/9.jpg','/reference/10.jpg','/reference/11.jpg','/reference/12.png','/reference/13.jpg','/reference/14.jpg','/reference/15.jpg','/reference/16.jpg','/reference/17.jpg'):
            body=(ROOT/'research'/'user_range_references'/path.split('/')[-1]).read_bytes();mime='image/jpeg' if path.endswith('.jpg') else 'image/png'
        elif path in ('/','/index.html','/app.js','/style.css'):
            name='index.html' if path=='/' else path[1:]
            body=(ROOT/'ui'/name).read_bytes();mime={'html':'text/html','js':'application/javascript','css':'text/css'}[name.split('.')[-1]]+'; charset=utf-8'
        else:self.send_error(404);return
        self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def log_message(self,*args):pass

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8773);parser.add_argument('--snapshot-dir',type=Path,default=None);args=parser.parse_args()
    SNAPSHOT_DIR=args.snapshot_dir.resolve() if args.snapshot_dir else ROOT/'work'/f'live_{args.port}'/'data'
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
    from ict_trader.viewport_history import start_service
    HISTORY_PROCESS=start_service(ROOT/'mt5'/'bridge_settings.json')
    def maintain_history_worker():
        global HISTORY_PROCESS
        while True:
            time.sleep(5)
            if HISTORY_PROCESS is not None and not HISTORY_PROCESS.is_alive():
                HISTORY_PROCESS.join(timeout=0)
                HISTORY_PROCESS=start_service(ROOT/'mt5'/'bridge_settings.json')
    threading.Thread(target=maintain_history_worker,daemon=True).start()
    threading.Thread(target=worker,daemon=True).start()
    print(f'IPDA retracement: http://127.0.0.1:{args.port}',flush=True)
    server.serve_forever()
