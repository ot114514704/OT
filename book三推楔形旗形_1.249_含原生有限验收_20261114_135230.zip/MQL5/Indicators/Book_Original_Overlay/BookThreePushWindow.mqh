#ifndef BOOK_THREE_PUSH_WINDOW
#define BOOK_THREE_PUSH_WINDOW
// HistoryBars is context size, never a reason to truncate the visible chart.
// Both overlays choose the identical closed native-bar window.
bool BTPWindowPlan(const int first,const int visible,const int available,const int requested,
                  int &start,int &count){
 if(first<0||visible<1||available<41||requested<100)return false;
 int right=MathMax(1,first-visible+1);
 // Tile by absolute native-bar index: both layers pick the same window,
 // small pans reuse it, and new live bars do not shift historical windows.
 int wanted=MathMax(1,right-160),absolute=available-1-wanted;
 int tileEnd=MathMin(available-2,(absolute/256+1)*256-1);
 start=MathMax(1,available-1-tileEnd);
 int required=first+161-start;
 int capacity=MathMax(MathMax(600,requested),required);
 count=MathMin(available-start,((capacity+255)/256)*256);
 return count>=40;
}
bool BTPWindowCovers(const int first,const int visible,const int oldLeft,const int oldRight){
 int right=MathMax(1,first-visible+1);
 return oldLeft>=first+160&&oldRight>=1&&oldRight<=MathMax(1,right-160);
}
#endif
