#property copyright "Original Book archive three-push overlay trial"
#property version "1.248"
#property indicator_chart_window
#property indicator_plots 0
#include "Machine1_UnifiedNativeLegacyPush.mqh"
#include "Machine1_UnifiedNativeColours.mqh"
#include "BookThreePushWindow.mqh"
input bool ShowNativeThreePush=true;
input int HistoryBars=4000;
input bool AllThreePushLabels=true; // false: legacy collision-filtered labels
input int MarketZigzagDepth=3;
input int MarketZigzagMaxBars=12000;
M1ULegacyPush nativeLocalThreePush[];
string nativePrefix,nativeSourceIdentity,nativeLocalThreePushRevision="";
string nativeThreePushGeometryRevision="",nativeThreePushDisplayRevision="",nativePushViewportKey="";
bool nativeLayoutPending=false,nativeCaptionsDirty=true;
bool showLargePush=true,showSmallPush=true;
bool showMarketZigzag=true;
string marketZigzagKey="",marketZigzagStatus="等待读取行情";
int marketZigzagSegments=0;
string overlayPreferenceKey="";
datetime loadedNewest=0,loadedOldest=0,loadedClosed=0;
int loadedStart=-1,loadedCount=0;
bool pending=true;
MqlRates overlayInputRows[];
long overlayInputRevision=0,overlayReads=0;
void NativeRulerReviewObject(string name){} // Original standalone review hooks have no admission effects.
void NativeLine(string name,datetime a,double ap,datetime b,double bp,color colour,int style){

 if(ObjectFind(0,name)<0)ObjectCreate(0,name,OBJ_TREND,0,a,ap,b,bp);

 ObjectMove(0,name,0,a,ap);ObjectMove(0,name,1,b,bp);

 ObjectSetInteger(0,name,OBJPROP_COLOR,colour);ObjectSetInteger(0,name,OBJPROP_STYLE,style);

 ObjectSetInteger(0,name,OBJPROP_RAY_RIGHT,false);ObjectSetInteger(0,name,OBJPROP_RAY_LEFT,false);

 ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);NativeRulerReviewObject(name);

}
bool NativePushChainFits(const int &cx[],const int &cy[],int width,int height,const int &xs[],const int &ys[],int used){

 if(used+3>18)return false;

 for(int j=0;j<3;j++){

  if(cx[j]<32||cx[j]>width-52||cy[j]<112||cy[j]>height-100)return false;

  for(int k=0;k<j;k++)if(MathAbs(cx[j]-cx[k])<40&&MathAbs(cy[j]-cy[k])<28)return false;

  for(int k=0;k<used;k++)if(MathAbs(cx[j]-xs[k])<76&&MathAbs(cy[j]-ys[k])<28)return false;

 }

 return true;

}
void NativePushMark(string name,const M1UPoint &point,string text,string tip,color colour){

 nativeCaptionsDirty=true;

 if(ObjectFind(0,name)<0)ObjectCreate(0,name,OBJ_TEXT,0,point.time,point.price);

 ObjectMove(0,name,0,point.time,point.price);

 ObjectSetInteger(0,name,OBJPROP_COLOR,colour);ObjectSetInteger(0,name,OBJPROP_FONTSIZE,10);

 ObjectSetInteger(0,name,OBJPROP_ANCHOR,point.kind==1?ANCHOR_LOWER:ANCHOR_UPPER);

 ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_BACK,false);

 ObjectSetString(0,name,OBJPROP_TEXT,text);ObjectSetString(0,name,OBJPROP_TOOLTIP,tip);

 NativeRulerReviewObject(name);

}
struct BKNMTFPivot { datetime time; double price; bool high; int index; };
void BKNMTFAppendPivot(BKNMTFPivot &out[],datetime t,double p,bool high,int index){
 int n=ArraySize(out);
 if(n>0&&out[n-1].high==high){
  bool replace=high?(p>=out[n-1].price):(p<=out[n-1].price);
  if(replace){out[n-1].time=t;out[n-1].price=p;out[n-1].index=index;}
  return;
 }
 BKNMTFPivot q;q.time=t;q.price=p;q.high=high;q.index=index;ArrayResize(out,n+1);out[n]=q;
}
int BKNMTFBuild(const MqlRates &rates[],int seconds,datetime cutoff,int depth,BKNMTFPivot &pivots[]){
 ArrayResize(pivots,0);int closed=0;
 for(int i=0;i<ArraySize(rates);i++){
  if(rates[i].time+seconds>cutoff)break;
  if(i>0&&rates[i].time<=rates[i-1].time)return -1;
  if(!MathIsValidNumber(rates[i].high)||!MathIsValidNumber(rates[i].low)||rates[i].high<rates[i].low)return -1;
  closed++;
 }
 if(depth<1||closed<depth*2+1)return 0;
 for(int i=depth;i<closed-depth;i++){
  bool is_high=true,is_low=true;
  for(int j=1;j<=depth;j++){
   // Rightmost plateau pivot; do not create a point on every equal bar.
   if(rates[i].high<rates[i-j].high||rates[i].high<=rates[i+j].high)is_high=false;
   if(rates[i].low>rates[i-j].low||rates[i].low>=rates[i+j].low)is_low=false;
  }
  // An outside bar cannot establish intrabar order from OHLC alone.
  if(is_high&&!is_low)BKNMTFAppendPivot(pivots,rates[i].time,rates[i].high,true,i);
  else if(is_low&&!is_high)BKNMTFAppendPivot(pivots,rates[i].time,rates[i].low,false,i);
 }
 return ArraySize(pivots);
}
void NativeRenderThreePush(){

 string geometry=nativeLocalThreePushRevision+"|"+IntegerToString(ShowNativeThreePush?1:0);

 geometry+="|"+IntegerToString(showLargePush?1:0)+"|"+IntegerToString(showSmallPush?1:0);
 string revision=geometry;

 int width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);

 nativePushViewportKey=IntegerToString(width)+"|"+IntegerToString(height)+"|"+IntegerToString(ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR))+"|"+IntegerToString(ChartGetInteger(0,CHART_SCALE))+"|"+DoubleToString(ChartGetDouble(0,CHART_PRICE_MIN),8)+"|"+DoubleToString(ChartGetDouble(0,CHART_PRICE_MAX),8);

 revision+="|"+nativePushViewportKey;

 if(!ShowNativeThreePush||nativeLocalThreePushRevision==""||ArraySize(nativeLocalThreePush)==0){if(nativeThreePushGeometryRevision!="")ObjectsDeleteAll(0,nativePrefix+"three_push_");nativeThreePushDisplayRevision="";nativeThreePushGeometryRevision="";return;}

 bool layout_ready=width>0&&height>0&&ChartGetDouble(0,CHART_PRICE_MAX)>ChartGetDouble(0,CHART_PRICE_MIN);

 if(!layout_ready)nativeLayoutPending=true;

 if(layout_ready&&nativeThreePushDisplayRevision==revision)return;

 bool geometry_changed=nativeThreePushGeometryRevision!=geometry;

 if(geometry_changed)ObjectsDeleteAll(0,nativePrefix+"three_push_");

 int label_x[],label_y[],labels_used=0;
 ArrayResize(label_x,MathMax(18,ArraySize(nativeLocalThreePush)*3));ArrayResize(label_y,MathMax(18,ArraySize(nativeLocalThreePush)*3));

 for(int i=ArraySize(nativeLocalThreePush)-1;i>=0;i--){

  M1ULegacyPush item=nativeLocalThreePush[i];
  if(!OverlayGroupEnabled(i))continue;

  string owner="three_push|"+nativeSourceIdentity;

  for(int p=0;p<6;p++)owner+="|"+IntegerToString(item.points[p].time)+"@"+DoubleToString(item.points[p].price,12);

  // Shared, collision-free owner registry: a pattern retains its colour when

  // a new candidate is inserted or the visible history window moves.

  color colour=M1RulerColour(owner);

  string base=nativePrefix+"three_push_"+IntegerToString(i)+"_";

  string role=item.parent>=0?(item.children>0?"中":"小"):(item.children>0?"大":"");

  string text=role+"三推候选 | nested_balanced_three_push_v4 | 平衡度="+DoubleToString(100*item.balance,1)+"/100 幅度比="+DoubleToString(item.amplitude_ratio,4)+" 重叠="+DoubleToString(item.overlaps[0],4)+","+DoubleToString(item.overlaps[1],4)+" | 同周期父="+IntegerToString(item.parent)+"；父周期未知；非入场";

  for(int j=0;j<3;j++)text+=" | 路径"+IntegerToString(j+1)+"="+(item.route_usable[j]?DoubleToString(item.route_prices[j],_Digits):"不可用");

  // Original local adapter joins push tips, not the five internal ZigZag legs.

  if(geometry_changed)OverlayPatternZigzag(base,item,colour);
  if(geometry_changed)for(int j=0;j<2;j++){

   M1UPoint a=item.points[j*2+1],b=item.points[j*2+3];

   NativeLine(base+IntegerToString(j),a.time,a.price,b.time,b.price,colour,STYLE_DASH);

   ObjectSetInteger(0,base+IntegerToString(j),OBJPROP_WIDTH,2);

   ObjectSetString(0,base+IntegerToString(j),OBJPROP_TOOLTIP,text);

  }

  if(!geometry_changed)for(int j=0;j<3;j++)ObjectDelete(0,base+"tip_"+IntegerToString(j));

  int cx[3],cy[3];bool visible=layout_ready;

  for(int j=0;j<3;j++)if(!ChartTimePriceToXY(0,0,item.points[j*2+1].time,item.points[j*2+1].price,cx[j],cy[j]))visible=false;

  if(visible&&(AllThreePushLabels||NativePushChainFits(cx,cy,width,height,label_x,label_y,labels_used)))for(int j=0;j<3;j++){
   if(AllThreePushLabels&&(cx[j]<0||cx[j]>width-40||cy[j]<40||cy[j]>height-35))continue;

   string mark=j==2?role+"三推 3":IntegerToString(j+1);

   if(j==2&&false /* numerical labels owned by unified score switch */)mark+=" 平衡 "+DoubleToString(100*item.balance,1);

   NativePushMark(base+"tip_"+IntegerToString(j),item.points[j*2+1],mark,text,colour);

   label_x[labels_used]=cx[j];label_y[labels_used]=cy[j];labels_used++;

  }

 }

 nativeThreePushDisplayRevision=layout_ready?revision:"";nativeThreePushGeometryRevision=geometry;

}

bool OverlaySameClosedRows(const MqlRates &left[],const MqlRates &right[]){
 if(ArraySize(left)!=ArraySize(right))return false;
 for(int i=0;i<ArraySize(left);i++){
  if(left[i].time!=right[i].time||left[i].open!=right[i].open||left[i].high!=right[i].high||left[i].low!=right[i].low||left[i].close!=right[i].close)return false;
 }
 return true;
}
bool OverlayValidClosedRows(const MqlRates &rows[],int seconds){
 if(seconds<=0||ArraySize(rows)<40)return false;
 for(int i=0;i<ArraySize(rows);i++)if(!M1UValidRate(rows[i])||(i>0&&rows[i].time<=rows[i-1].time))return false;
 return true;
}
void OverlayReadyStatus(){
 OverlayStatus("book三推试验板 1.248 · 每组三推ZigZag五段 · 行情ZZ："+marketZigzagStatus+" · 原盘整不变 · "+(AllThreePushLabels?"完整编号":"精选编号")+"");
}
// Book 1.302 BookGuidedMultiPeriodZigzag.mqh display convention. The original
// three-push owns these six anchors: no second depth-3 detector may move them.
void OverlayPatternZigzag(string base,const M1ULegacyPush &item,color colour){
 if(ArraySize(item.points)!=6)return;
 for(int j=1;j<6;j++){
  M1UPoint a=item.points[j-1],b=item.points[j];
  string name=base+"zz_"+IntegerToString(j);
  NativeLine(name,a.time,a.price,b.time,b.price,colour,STYLE_SOLID);
  ObjectSetInteger(0,name,OBJPROP_WIDTH,1);ObjectSetInteger(0,name,OBJPROP_BACK,false);
  ObjectSetString(0,name,OBJPROP_TOOLTIP,"Book ZigZag · 三推自有六个已确认摆点 · "+(j%2==1?"推进 "+IntegerToString((j+1)/2):"回撤 "+IntegerToString(j/2))+" · "+TimeToString(a.time,TIME_DATE|TIME_MINUTES)+" → "+TimeToString(b.time,TIME_DATE|TIME_MINUTES)+" · 三推首次可知 "+TimeToString(item.known,TIME_DATE|TIME_MINUTES)+"；不改原盘整/三推识别，不预判反转");
 }
}
bool OverlayGroupEnabled(int index){
 if(index<0||index>=ArraySize(nativeLocalThreePush))return false;
 return nativeLocalThreePush[index].parent<0?showLargePush:showSmallPush;
}
void OverlaySaveSwitches(){
 GlobalVariableSet(overlayPreferenceKey+"large",showLargePush?1:0);
 GlobalVariableSet(overlayPreferenceKey+"small",showSmallPush?1:0);
 GlobalVariableSet(overlayPreferenceKey+"market_zigzag",showMarketZigzag?1:0);
}
void OverlayStatus(string message){
 string n=nativePrefix+"status";
 if(ObjectFind(0,n)<0)ObjectCreate(0,n,OBJ_LABEL,0,0,0);
 ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_LEFT_LOWER);
 ObjectSetInteger(0,n,OBJPROP_XDISTANCE,14);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,44);
 ObjectSetInteger(0,n,OBJPROP_COLOR,clrOrchid);ObjectSetInteger(0,n,OBJPROP_FONTSIZE,10);
 ObjectSetString(0,n,OBJPROP_TEXT,message);
 ObjectSetString(0,n,OBJPROP_TOOLTIP,"原包三推独立图层；不改变、不过滤原盘整。原画法：同组同色，连接三个推进端点，编号1/2/3。闭合K线证据，非入场信号。");
}
void OverlayButtons(){
 int large=0,small=0;
 for(int j=0;j<ArraySize(nativeLocalThreePush);j++)if(nativeLocalThreePush[j].parent<0)large++;else small++;
 string ids[4]={"large","small","market_zigzag","example"};
 string texts[4]={showLargePush?"大三推 开":"大三推 关",showSmallPush?"小三推 开":"小三推 关",showMarketZigzag?"行情 ZigZag 开":"行情 ZigZag 关","定位可见三推"};
 for(int i=0;i<4;i++){
  string n=nativePrefix+ids[i];
  if(ObjectFind(0,n)<0)ObjectCreate(0,n,OBJ_BUTTON,0,0,0);
  ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_RIGHT_UPPER);
  ObjectSetInteger(0,n,OBJPROP_XDISTANCE,600-i*150);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,100);
  ObjectSetInteger(0,n,OBJPROP_XSIZE,140);ObjectSetInteger(0,n,OBJPROP_YSIZE,26);
  ObjectSetInteger(0,n,OBJPROP_COLOR,((i==0&&!showLargePush)||(i==1&&!showSmallPush)||(i==2&&!showMarketZigzag))?clrSilver:clrOrchid);
  ObjectSetInteger(0,n,OBJPROP_BGCOLOR,C'22,29,42');ObjectSetInteger(0,n,OBJPROP_FONTSIZE,10);
  ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,n,OBJPROP_ZORDER,200);
  ObjectSetString(0,n,OBJPROP_TEXT,texts[i]);
  ObjectSetString(0,n,OBJPROP_TOOLTIP,i==0?"大三推：原包同周期外层/独立组，共"+IntegerToString(large)+"组；不改变原盘整":i==1?"小三推：原包同周期有父组的嵌套三推，共"+IntegerToString(small)+"组":i==2?"普通行情连续ZigZag：Book原包depth摆点规则，当前图表任意周期，覆盖可见历史并随收盘更新；与每组三推五段折线独立；"+marketZigzagStatus:"定位当前已打开层级的最近一组三推");
 }
}
bool OverlayLoad(){
 int available=Bars(_Symbol,_Period);if(available<40){OverlayStatus("book三推试验板：等待原生历史K线；原图形仅作历史，不确认当前");return false;}
 int first=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
 int visible=(int)ChartGetInteger(0,CHART_VISIBLE_BARS);
 int start=1,count=0;
 if(!BTPWindowPlan(first,visible,available,HistoryBars,start,count))return false;
 datetime closed=iTime(_Symbol,_Period,1);
 // Exact closed OHLC equality below reuses the tiled shared window.
 MqlRates rows[];ArraySetAsSeries(rows,false);
 int copied=CopyRates(_Symbol,_Period,start,count,rows);
 overlayReads++;
 if(copied<40){OverlayStatus("book三推试验板：正在下载历史；保留旧图形，不确认当前");return false;}
 if(!OverlayValidClosedRows(rows,PeriodSeconds(_Period))){OverlayStatus("book三推试验板：原生OHLC无效或时间未排序；保留历史图形，当前证据不足");return false;}
 if(!pending&&OverlaySameClosedRows(rows,overlayInputRows)){
  loadedClosed=closed;loadedStart=start;loadedCount=copied;OverlayReadyStatus();return true;
 }
 datetime cutoff=rows[copied-1].time+PeriodSeconds(_Period);
 M1ULegacyPush next[];M1ULegacyPushBuild(rows,PeriodSeconds(_Period),cutoff,next);
 ArrayResize(nativeLocalThreePush,ArraySize(next));
 for(int i=0;i<ArraySize(next);i++)nativeLocalThreePush[i]=next[i];
 loadedStart=start;loadedCount=copied;loadedOldest=rows[0].time;loadedNewest=rows[copied-1].time;loadedClosed=closed;
 ArrayResize(overlayInputRows,copied);ArrayCopy(overlayInputRows,rows);overlayInputRevision++;
 nativeLocalThreePushRevision=IntegerToString(loadedOldest)+"|"+IntegerToString(loadedNewest)+"|"+IntegerToString(copied)+"|"+IntegerToString(overlayInputRevision);
 pending=false;
 OverlayReadyStatus();
 int f=FileOpen("BookOriginalOverlay_"+IntegerToString(ChartID())+".tsv",FILE_WRITE|FILE_TXT|FILE_UNICODE);
 if(f!=INVALID_HANDLE){
  FileWriteString(f,"version\t1.248\nsource\tUnified_1.133/nested_balanced_three_push_v4\nchart\t"+IntegerToString(ChartID())+"\nperiod\t"+IntegerToString(PeriodSeconds(_Period))+"\nloaded\t"+IntegerToString(copied)+"\ngroups\t"+IntegerToString(ArraySize(next))+"\nloaded_first\t"+IntegerToString(loadedOldest)+"\nloaded_last\t"+IntegerToString(loadedNewest)+"\nstart_shift\t"+IntegerToString(loadedStart)+"\ncutoff\t"+IntegerToString(cutoff)+"\navailable_bars\t"+IntegerToString(available)+"\n");
  for(int i=0;i<ArraySize(next);i++){
   string row=IntegerToString(next[i].known);
   for(int j=0;j<6;j++)row+="\t"+IntegerToString(next[i].points[j].time)+"@"+DoubleToString(next[i].points[j].price,_Digits);
   FileWriteString(f,row+"\n");
  }FileClose(f);
 }
 return true;
}
void OverlayMarketZigzag(){
 string prefix=nativePrefix+"market_zz_";
 if(!showMarketZigzag){ObjectsDeleteAll(0,prefix);marketZigzagKey="";marketZigzagSegments=0;marketZigzagStatus="已关闭";return;}
 int first=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR),visible=(int)ChartGetInteger(0,CHART_VISIBLE_BARS);
 int right=MathMax(0,first-visible+1),seconds=PeriodSeconds(_Period);
 datetime live=iTime(_Symbol,_Period,0),right_time=iTime(_Symbol,_Period,right);
 if(live<=0||right_time<=0||seconds<=0){marketZigzagStatus="等待读取原生行情";return;}
 datetime cutoff=(datetime)MathMin((long)live,(long)(right_time+seconds));
 int from=MathMax(1,iBarShift(_Symbol,_Period,cutoff-1,false));
 int required=MathMax(100,first-from+1+64+MarketZigzagDepth*2);
 int wanted=MathMin(required,MarketZigzagMaxBars);
 MqlRates rows[];ArraySetAsSeries(rows,false);
 int copied=CopyRates(_Symbol,_Period,from,wanted,rows);
 if(copied<MarketZigzagDepth*2+1){marketZigzagStatus="历史不足，正在加载";return;}
 ulong hash=1469598103934665603;
 for(int i=0;i<copied;i++){
  if(rows[i].time+seconds>cutoff)break;
  hash=(hash^(ulong)rows[i].time)*1099511628211;
  hash=(hash^(ulong)MathRound(rows[i].high/_Point))*1099511628211;
  hash=(hash^(ulong)MathRound(rows[i].low/_Point))*1099511628211;
 }
 string key=IntegerToString(cutoff)+":"+IntegerToString(copied)+":"+IntegerToString(hash);
 if(key==marketZigzagKey)return;
 BKNMTFPivot pivots[];int result=BKNMTFBuild(rows,seconds,cutoff,MarketZigzagDepth,pivots);
 if(result<0){marketZigzagStatus="历史OHLC无效，保留旧历史折线";return;}
 ObjectsDeleteAll(0,prefix);
 for(int i=1;i<result;i++){
  string name=prefix+IntegerToString(i);
  NativeLine(name,pivots[i-1].time,pivots[i-1].price,pivots[i].time,pivots[i].price,C'99,169,255',STYLE_SOLID);
  ObjectSetInteger(0,name,OBJPROP_WIDTH,2);ObjectSetInteger(0,name,OBJPROP_BACK,false);
  ObjectSetString(0,name,OBJPROP_TOOLTIP,"行情ZigZag · Book 1.302原包摆点 · depth="+IntegerToString(MarketZigzagDepth)+" · 仅已收盘 · "+TimeToString(pivots[i-1].time,TIME_DATE|TIME_MINUTES)+" → "+TimeToString(pivots[i].time,TIME_DATE|TIME_MINUTES)+" · 仅显示，不参与三推/盘整确认；末端可随新极值修订");
 }
 marketZigzagSegments=MathMax(0,result-1);marketZigzagKey=key;
 marketZigzagStatus=IntegerToString(marketZigzagSegments)+"段";
 if(required>MarketZigzagMaxBars)marketZigzagStatus+=" · 达到上限，请放大视窗或增加MaxBars";
 else if(copied<wanted)marketZigzagStatus+=" · 等待历史补齐";
 int f=FileOpen("BookMarketZigzag_"+IntegerToString(ChartID())+".tsv",FILE_WRITE|FILE_TXT|FILE_UNICODE);
 if(f!=INVALID_HANDLE){
  FileWriteString(f,"version\t1.248\nperiod\t"+IntegerToString(seconds)+"\ncutoff\t"+IntegerToString(cutoff)+"\nfirst\t"+IntegerToString(rows[0].time)+"\nlast\t"+IntegerToString(rows[copied-1].time)+"\nloaded\t"+IntegerToString(copied)+"\ndepth\t"+IntegerToString(MarketZigzagDepth)+"\nsegments\t"+IntegerToString(marketZigzagSegments)+"\n");
  for(int i=0;i<result;i++)FileWriteString(f,IntegerToString(pivots[i].time)+"\t"+DoubleToString(pivots[i].price,_Digits)+"\t"+IntegerToString(pivots[i].high?1:0)+"\n");FileClose(f);
 }
}
string overlayRenderKey="";
ulong overlayLastPoll=0,overlayLastView=0;
bool overlayViewPending=true;
bool OverlayViewQuiet(const ulong now,const ulong viewAt){return viewAt==0||now-viewAt>=200;}
string OverlayFrameKey(){
 return nativeLocalThreePushRevision+"|"+IntegerToString(ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR))+"|"+IntegerToString(ChartGetInteger(0,CHART_VISIBLE_BARS))+"|"+IntegerToString(ChartGetInteger(0,CHART_WIDTH_IN_PIXELS))+"|"+IntegerToString(ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS))+"|"+IntegerToString(showLargePush)+IntegerToString(showSmallPush)+IntegerToString(showMarketZigzag);
}
void OverlayRender(){
 string nextFrame=OverlayFrameKey();if(nextFrame==overlayRenderKey)return;overlayRenderKey=nextFrame;
 // Switches change the display selection before original label collision layout.
 NativeRenderThreePush();
 int f=FileOpen("BookOriginalSwitches_"+IntegerToString(ChartID())+".tsv",FILE_WRITE|FILE_TXT|FILE_UNICODE);
 if(f!=INVALID_HANDLE){
  int large=0,small=0;
  for(int i=0;i<ArraySize(nativeLocalThreePush);i++)if(OverlayGroupEnabled(i)){if(nativeLocalThreePush[i].parent<0)large++;else small++;}
  int zigzag=0;
  for(int j=ObjectsTotal(0)-1;j>=0;j--){string name=ObjectName(0,j);if(StringFind(name,nativePrefix+"three_push_")==0&&StringFind(name,"_zz_")>=0)zigzag++;}
  FileWriteString(f,"version\t1.248\nlarge_enabled\t"+IntegerToString(showLargePush)+"\nsmall_enabled\t"+IntegerToString(showSmallPush)+"\nselected_large\t"+IntegerToString(large)+"\nselected_small\t"+IntegerToString(small)+"\nzigzag_segments\t"+IntegerToString(zigzag)+"\nexpected_zigzag_segments\t"+IntegerToString((large+small)*5)+"\nclosed_input_revision\t"+IntegerToString(overlayInputRevision)+"\nclosed_input_reads\t"+IntegerToString(overlayReads)+"\n");FileClose(f);
 }
 OverlayMarketZigzag();OverlayButtons();OverlayReadyStatus();ChartRedraw();
}
int OnInit(){
 if(HistoryBars<100||HistoryBars>50000)return INIT_PARAMETERS_INCORRECT;
 if(MarketZigzagDepth<1||MarketZigzagDepth>20||MarketZigzagMaxBars<100||MarketZigzagMaxBars>50000)return INIT_PARAMETERS_INCORRECT;
 nativePrefix="BOOK_ORIGINAL_"+IntegerToString(ChartID())+"_"+IntegerToString(GetTickCount64())+"_";
 nativeSourceIdentity=AccountInfoString(ACCOUNT_SERVER)+"|"+_Symbol+"|"+IntegerToString(PeriodSeconds(_Period));
 overlayPreferenceKey="BookOverlay."+IntegerToString(ChartID())+".";
 if(GlobalVariableCheck(overlayPreferenceKey+"large"))showLargePush=GlobalVariableGet(overlayPreferenceKey+"large")>0;
 if(GlobalVariableCheck(overlayPreferenceKey+"small"))showSmallPush=GlobalVariableGet(overlayPreferenceKey+"small")>0;
 if(GlobalVariableCheck(overlayPreferenceKey+"market_zigzag"))showMarketZigzag=GlobalVariableGet(overlayPreferenceKey+"market_zigzag")>0;
 IndicatorSetString(INDICATOR_SHORTNAME,"book三推试验板 · 每组三推ZigZag 1.248");
 EventSetMillisecondTimer(100);OverlayButtons();OverlayStatus("book三推试验板：读取原包三推与行情ZigZag；原盘整保持不变");
 return INIT_SUCCEEDED;
}
int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[]){return rates_total;}
void OnTimer(){
 ulong now=GetTickCount64();if(!OverlayViewQuiet(now,overlayLastView))return;
 if(overlayLastPoll==0||now-overlayLastPoll>=2000){overlayLastPoll=now;if(OverlayLoad())OverlayRender();else{OverlayMarketZigzag();OverlayButtons();}}
 else if(overlayViewPending)OverlayRender();
 overlayViewPending=false;
}
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam){
 if(id==CHARTEVENT_CHART_CHANGE){overlayLastView=GetTickCount64();overlayViewPending=true;return;}
 if(id==CHARTEVENT_OBJECT_CLICK&&(sparam==nativePrefix+"large"||sparam==nativePrefix+"small")){
  if(sparam==nativePrefix+"large")showLargePush=!showLargePush;else showSmallPush=!showSmallPush;
  OverlaySaveSwitches();ObjectSetInteger(0,sparam,OBJPROP_STATE,false);OverlayRender();
 }
 if(id==CHARTEVENT_OBJECT_CLICK&&sparam==nativePrefix+"market_zigzag"){
  showMarketZigzag=!showMarketZigzag;OverlaySaveSwitches();ObjectSetInteger(0,sparam,OBJPROP_STATE,false);OverlayRender();
 }
 if(id==CHARTEVENT_OBJECT_CLICK&&sparam==nativePrefix+"example"){
  ObjectSetInteger(0,sparam,OBJPROP_STATE,false);
  int selected=-1;
  for(int i=ArraySize(nativeLocalThreePush)-1;i>=0;i--)if(OverlayGroupEnabled(i)){selected=i;break;}
  if(selected<0)return;
  M1ULegacyPush last=nativeLocalThreePush[selected];
  int shift=iBarShift(_Symbol,_Period,last.points[0].time,false);
  int width=(int)ChartGetInteger(0,CHART_VISIBLE_BARS);
  ChartSetInteger(0,CHART_AUTOSCROLL,false);ChartNavigate(0,CHART_END,-MathMax(0,shift-width+20));
 }
}
void OnDeinit(const int reason){EventKillTimer();if(nativePrefix!="")ObjectsDeleteAll(0,nativePrefix);}
