#ifndef BOOK_PA_VISUAL
#define BOOK_PA_VISUAL
// Display only. Never supplies points, trend context or classification gates.
string paFocus="";bool paDetails=false;
int paLabelX[],paLabelY[],paLabelW[],paLabels=0;
color PAInk(const int category){
 return category==1?C'255,183,77':category==2?C'56,189,248':category==3?C'52,211,153':C'181,199,222';
}
string PAState(const OverlayPA &o){
 return o.category==4?"背景待核":o.state==1?"收盘破线":o.state==2?"反向失效":o.state==3?"已终止":"候选";
}
string PAShort(const int i){
 OverlayPA o=paShapes[i];
 string n=o.category==1?(paGroups[i].direction>0?"上升反转楔形":"下降反转楔形"):
 o.category==2?(o.trend>0?"牛旗·平行":"熊旗·平行"):
 o.category==3?(o.trend>0?"牛旗·楔形":"熊旗·楔形"):
 (o.geometry==1?"平行三推轮廓":"收敛楔形轮廓");
 return "#"+IntegerToString(i+1)+" "+n+" · "+PAState(o);
}
// Reserve non-overlapping labels without dropping their underlying patterns.
int PALabelLane(const int x,const int anchorY,const int width,const int top,const int bottom,const int &xs[],const int &ys[],const int &ws[]){
 for(int lane=0;lane<24;lane++){
  int y=lane%2==0?anchorY-28-24*(lane/2):anchorY+18+24*(lane/2);
  if(y<top||y+20>bottom)continue;
  bool free=true;for(int k=0;k<ArraySize(xs);k++)if(x<xs[k]+ws[k]+6&&x+width+6>xs[k]&&y<ys[k]+24&&y+24>ys[k]){free=false;break;}
  if(free)return y;
 }
 return -1;
}
void PAPixelText(const string n,const int x,const int y,const string text,const color ink,const string tip,const int size=10){
 ObjectCreate(0,n,OBJ_LABEL,0,0,0);ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_LEFT_UPPER);
 ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);
 ObjectSetInteger(0,n,OBJPROP_FONTSIZE,size);ObjectSetString(0,n,OBJPROP_FONT,"Microsoft YaHei");ObjectSetInteger(0,n,OBJPROP_COLOR,ink);
 ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,n,OBJPROP_HIDDEN,true);ObjectSetInteger(0,n,OBJPROP_ZORDER,420);
 ObjectSetString(0,n,OBJPROP_TEXT,text);ObjectSetString(0,n,OBJPROP_TOOLTIP,tip);
}
void PANativeText(const string name,const datetime t,const double price,const string text,const color ink,const string tip,const int size){
 ObjectCreate(0,name,OBJ_TEXT,0,t,price);ObjectMove(0,name,0,t,price);
 ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_COLOR,ink);
 ObjectSetInteger(0,name,OBJPROP_FONTSIZE,size);ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");
 ObjectSetInteger(0,name,OBJPROP_BACK,false);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);ObjectSetInteger(0,name,OBJPROP_ZORDER,180);
 ObjectSetString(0,name,OBJPROP_TEXT,text);ObjectSetString(0,name,OBJPROP_TOOLTIP,tip);
}
void PALabel(const int i,const string id){
 string n=prefix+"g"+id+"text";
 if(!ShowPatternLabels){ObjectDelete(0,n);return;}
 OverlayPA o=paShapes[i];int x0,y0,x1,y1;
 if(!ChartTimePriceToXY(0,0,o.start,o.upper0,x0,y0)||!ChartTimePriceToXY(0,0,o.end,o.upper1,x1,y1)){ObjectDelete(0,n);return;}
 int w=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),h=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
 string caption=PAShort(i);int textWidth=MathMin(w-20,StringLen(caption)*11+12);
 int x=MathMax(8,MathMin(w-textWidth-8,(x0+x1)/2-textWidth/2));
 int y=PALabelLane(x,MathMin(y0,y1),textWidth,176,h-85,paLabelX,paLabelY,paLabelW);
 if(y<0){ObjectDelete(0,n);return;}
 int sub=0;datetime t;double price;
 if(!ChartXYToTimePrice(0,x,y,sub,t,price)||sub!=0){ObjectDelete(0,n);return;}
 PANativeText(n,t,price,caption,PAInk(o.category),PATip(i)+"\n点击边线、色块或标题查看单组详细说明。",10);
 int at=ArraySize(paLabelX);ArrayResize(paLabelX,at+1);ArrayResize(paLabelY,at+1);ArrayResize(paLabelW,at+1);
 paLabelX[at]=x;paLabelY[at]=y;paLabelW[at]=textWidth;paLabels++;
}
void PAPushLabels(const int i,const string base,const color ink){
 for(int j=0;j<3;j++){
  int at=2*j+1,x,y;M1UPoint p=paGroups[i].points[at];
  if(!ChartTimePriceToXY(0,0,p.time,p.price,x,y))continue;
  int sub=0;datetime t;double price;int py=y+(paGroups[i].direction>0?-17:6);
  if(ChartXYToTimePrice(0,x+4,py,sub,t,price)&&sub==0)
   PANativeText(base+"p"+IntegerToString(j+1),t,price,"P"+IntegerToString(j+1),ink,PATip(i),10);
 }
}
void PAVisualControls(){
 string n=prefix+"inspect";ObjectCreate(0,n,OBJ_BUTTON,0,0,0);
 ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_RIGHT_UPPER);ObjectSetInteger(0,n,OBJPROP_XDISTANCE,300);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,132);
 ObjectSetInteger(0,n,OBJPROP_XSIZE,140);ObjectSetInteger(0,n,OBJPROP_YSIZE,24);ObjectSetInteger(0,n,OBJPROP_FONTSIZE,10);
 ObjectSetInteger(0,n,OBJPROP_COLOR,clrWhite);ObjectSetInteger(0,n,OBJPROP_BGCOLOR,C'22,29,42');ObjectSetInteger(0,n,OBJPROP_ZORDER,400);
 ObjectSetString(0,n,OBJPROP_TEXT,paDetails?"旗楔说明 关":"旗楔说明 开");ObjectSetString(0,n,OBJPROP_TOOLTIP,"点击轮廓可突出单组并查看原三推六点、推动幅度与候选/破线说明。再次点击或关闭说明恢复。识别不变。");
 if(!enabled){ObjectDelete(0,prefix+"legend");return;}
 PAPixelText(prefix+"legend",12,176,"旗楔：橙=反转楔形  蓝=平行旗  绿=楔形旗  灰=背景待核；点击轮廓查看",clrSilver,"颜色表示分类，不代表做多做空信号。候选与收盘破线分开记录。",9);
}
void PAInspector(){
 ObjectsDeleteAll(0,prefix+"detail_");
 if(!enabled||!paDetails)return;
 int i=-1;for(int j=0;j<ArraySize(paGroups);j++)if(PAGroupId(paGroups[j])==paFocus){i=j;break;}
 if(i<0)return;
 int w=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),h=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
 int pw=MathMin(490,w-24),x=MathMax(12,w-pw-12),y=MathMax(210,h-290);
 string lines[];ArrayResize(lines,0);
 string text=PAShort(i)+"\n"+TimeToString(paShapes[i].start,TIME_DATE|TIME_MINUTES)+" → "+TimeToString(paShapes[i].end,TIME_DATE|TIME_MINUTES)+
 "\n三推幅度 P1 / P2 / P3："+DoubleToString(paGroups[i].amplitudes[0],2)+" / "+DoubleToString(paGroups[i].amplitudes[1],2)+" / "+DoubleToString(paGroups[i].amplitudes[2],2)+
 "\n首次可知："+TimeToString(paShapes[i].known,TIME_DATE|TIME_MINUTES)+
 "\n越轨记录："+(paShapes[i].event>0?TimeToString(paShapes[i].event,TIME_DATE|TIME_MINUTES):"未发生已收盘越轨")+"\n"+paShapes[i].reason+
 "\n原Book六点不变；P1/P2/P3标记原推动端点。\n候选/已破线不等于已证明后续趋势反转。";
 string parts[];int n=StringSplit(text,'\n',parts);int limit=MathMax(15,(pw-24)/13);
 for(int j=0;j<n;j++)for(int k=0;k<StringLen(parts[j]);k+=limit){int at=ArraySize(lines);ArrayResize(lines,at+1);lines[at]=StringSubstr(parts[j],k,limit);}
 int count=MathMin(11,ArraySize(lines)),ph=40+count*18;
 y=MathMin(y,MathMax(210,h-ph-70));
 string bg=prefix+"detail_bg";ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);
 ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,y);ObjectSetInteger(0,bg,OBJPROP_XSIZE,pw);ObjectSetInteger(0,bg,OBJPROP_YSIZE,ph);
 ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,C'13,21,32');ObjectSetInteger(0,bg,OBJPROP_COLOR,PAInk(paShapes[i].category));ObjectSetInteger(0,bg,OBJPROP_BORDER_TYPE,BORDER_FLAT);
 ObjectSetInteger(0,bg,OBJPROP_ZORDER,400);ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,bg,OBJPROP_HIDDEN,true);ObjectSetString(0,bg,OBJPROP_TOOLTIP,PATip(i));
 PAPixelText(prefix+"detail_close",x+12,y+8,"单组旗楔说明 · 点击此处关闭",PAInk(paShapes[i].category),PATip(i),10);
 for(int j=0;j<count;j++)PAPixelText(prefix+"detail_"+IntegerToString(j),x+12,y+32+j*18,lines[j],j==0?PAInk(paShapes[i].category):clrWhite,PATip(i),9);
}
#endif
