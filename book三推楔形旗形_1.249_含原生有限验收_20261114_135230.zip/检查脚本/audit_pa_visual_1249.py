from pathlib import Path
import re,json,hashlib,subprocess
from build_original_overlay import function
from audit_original_overlay import adapt
ROOT=Path(__file__).resolve().parents[2]; D=ROOT/'mt5/experiment/pa_shapes'; OUT=Path('D:/盘整研究资料/验收/三推旗楔_PA_1.249');OUT.mkdir(parents=True,exist_ok=True)
s=(D/'BookPAVisual.mqh').read_text('utf-8');f=function(s,'PALabelLane');f=re.sub(r'int PALabelLane\([^)]*\)', 'function PALabelLane(x,anchorY,width,top,bottom,xs,ys,ws)',f);f=adapt(f).replace('lane/2','Math.floor(lane/2)')
js='const assert=require("assert/strict");const ArraySize=a=>a.length;'+f+r'''
const checks=[];const test=(n,v)=>{assert.ok(v,n);checks.push(n);};
const xs=[],ys=[],ws=[];
for(let i=0;i<20;i++){
 const y=PALabelLane(100,400,230,202,750,xs,ys,ws);
 if(y<0)break;
 test('label stays in chart '+i,y>=202&&y+20<=750);
 test('label collision excluded '+i,ys.every(p=>Math.abs(y-p)>=24));
 xs.push(100);ys.push(y);ws.push(230);
}
test('dense labels find multiple slots',xs.length>=10);
test('disjoint horizontal label can use same row',PALabelLane(400,400,100,202,750,[100],[372],[230])===372);
test('no room suppresses caption only',PALabelLane(100,400,230,399,401,[],[],[])===-1);
process.stdout.write(JSON.stringify(checks));
'''
p=subprocess.run(['node','-e',js],capture_output=True,text=True,encoding='utf-8',timeout=15);assert p.returncode==0,p.stderr
baseline=Path('D:/盘整研究资料/备份/1.248_旗楔可视化修改前_20261113_212254')
unchanged=['BookThreePushPA.mqh','BookThreePushWindow.mqh','Machine1_UnifiedNativeKernel.mqh','Machine1_UnifiedNativeLegacyPush.mqh','Machine1_UnifiedNativeColours.mqh']
for name in unchanged:assert (D/name).read_bytes()==(baseline/name).read_bytes(),name
main=(D/'book三推形态_PA.mq5').read_text('utf-8'); display=(D/'BookPADisplay.mqh').read_text('utf-8')
event=function(main,'OnChartEvent');frame=function(display,'PAFrame')
assert 'PALoad(' not in event and 'M1ULegacyPushBuild(' not in event
assert 'M1ULegacyPushBuild(' not in frame
assert 'ChartTimePriceToXY' in s and 'ChartXYToTimePrice' in s
assert 'ObjectMove(0,name,0,t,price)' in s
assert 'OBJPROP_RAY_LEFT,false' in main and 'OBJPROP_RAY_RIGHT,false' in main
for side,p0,p1 in [('u','ua','ub'),('l','la','lb')]:
 assert f'Line(n+"h{side}",cached[k].time,{p0},cached[end].time,{p1},halo)' in display
 assert f'Line(n+"{side}",cached[k].time,{p0},cached[end].time,{p1},ink)' in display
assert 'Fill(n+"a",cached[k].time,ua,cached[end].time,ub,cached[end].time,lb,shade)' in display
assert 'Fill(n+"b",cached[k].time,ua,cached[end].time,lb,cached[k].time,la,shade)' in display
assert 'PALabel(' in frame and 'PAInspector();' in frame
report={'version':'1.249','checks':json.loads(p.stdout),'unchanged_model_files':{n:hashlib.sha256((D/n).read_bytes()).hexdigest() for n in unchanged},'geometry_flow_checks':['halo, border, fill share native bar-time/price vertices','no rail extension or vertical end caps','native text uses price/time coordinates after layout','price-axis and viewport size enter label layout key','inspector click has no model read/build','raw detector and PA classification byte-identical to 1.248'],'scope':'Actual MQL label-layout helper execution and production source invariants; no strategy backtest or latency measurement'}
(OUT/'visual_layout_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8');print(json.dumps({'checks':len(report['checks']),'model_files_unchanged':len(unchanged)},ensure_ascii=True))
