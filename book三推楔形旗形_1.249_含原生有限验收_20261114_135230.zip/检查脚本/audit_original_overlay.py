"""Execute archive numerical source on host; not an EX5 visual acceptance."""
from pathlib import Path
import copy
import hashlib
import json
import re
import subprocess
import zipfile
from build_original_overlay import OUT, ROOT, ARCHIVE, PREFIX, function

def adapt(source):
    source = re.sub(r'/\*.*?\*/|//[^\n]*', '', source, flags=re.S)
    source = re.sub(r'^\s*#.*$', '', source, flags=re.M)
    source = re.sub(r'struct\s+\w+\s*\{.*?\};', '', source, flags=re.S)
    def signature(m):
        names=[re.search(r'(\w+)\s*(?:\[\])?\s*$', p).group(1) for p in m[2].split(',')]
        return 'function '+m[1]+'('+','.join(names)+'){'
    source = re.sub(r'\b(?:void|bool|int|double)\s+((?:M1U|Overlay)\w+)\(([^)]*)\)\{', signature, source)
    source = re.sub(r'\b(?:int|double|bool)\s+(\w+)\[\];', r'let \1=[];', source)
    source = re.sub(r'\((?:datetime|double|int)\)', '', source)
    source = re.sub(r'\b(?:int|double|bool|datetime)\s+', 'let ', source)
    source = re.sub(r'(\w+)\[\](?=[,;])', r'\1=[]', source)
    # MQL integer division in the original median; JS has floating division.
    source = source.replace('values[n/2]', 'values[Math.floor(n/2)]').replace('values[n/2-1]', 'values[Math.floor(n/2)-1]')
    return source

def fixture(amps=(8,8,8), shifts=(0,2,4), down=False):
    rows=[dict(time=1700000000+i*3600,open=103,high=105,low=101,close=103) for i in range(24)]
    points=[]
    for j,amp in enumerate(amps):
        lo=100+shifts[j]; start=len(rows)
        for step in range(9):
            price=lo+amp*step/8
            rows.append(dict(time=1700000000+len(rows)*3600,open=price,
                             high=min(lo+amp,price+1.2),low=max(lo,price-1.2),
                             close=price+.1 if step<8 else price-.1))
        for idx,kind,price in [(start,-1,lo),(start+8,1,lo+amp)]:
            points.append(dict(index=idx,kind=kind,price=price,time=rows[idx]['time'],known=rows[idx]['time']+3600))
    if down:
        for row in rows:
            row.update(open=220-row['open'],high=220-row['low'],low=220-row['high'],close=220-row['close'])
        for p in points:p.update(price=220-p['price'],kind=-p['kind'])
    return dict(rates=rows,points=points,cutoff=rows[-1]['time']+3600)

def run():
    legacy=(OUT/'Machine1_UnifiedNativeLegacyPush.mqh').read_text('utf-8-sig')
    kernel=(OUT/'Machine1_UnifiedNativeKernel.mqh').read_text('utf-8-sig')
    src='\n'.join(function(kernel,n) for n in ['M1UCopy','M1UValidRate'])
    # Median returns double, while the standard extractor uses void/bool.
    median=legacy[legacy.index('double M1ULegacyMedian('):legacy.index('bool M1ULegacyPushQuality(')]
    src=adapt(src+'\n'+median+'\n'+function(legacy,'M1ULegacyPushQuality'))
    cases=[]
    for down in (False,True):
        value=fixture(down=down);cases.append(('parallel_three_push_accepted_'+str(down),value,True))
        early=copy.deepcopy(value);early['cutoff']-=1;cases.append(('future_last_point_rejected_'+str(down),early,False))
        wrong=copy.deepcopy(value);wrong['points'][3]['price']+=.2;cases.append(('misbound_price_rejected_'+str(down),wrong,False))
        flat=fixture(shifts=(0,.1,.2),down=down);cases.append(('horizontal_not_three_push_'+str(down),flat,False))
        double=fixture(amps=(8,8,16),shifts=(0,4,6),down=down);cases.append(('two_times_allowed_'+str(down),double,True))
        too_big=fixture(amps=(8,8,16.1),shifts=(0,4,6),down=down);cases.append(('larger_than_two_rejected_'+str(down),too_big,False))
        future=copy.deepcopy(value);future['rates'].append(dict(time=value['cutoff'],open=100,low=0,high=300,close=250))
        cases.append(('future_bars_do_not_change_'+str(down),future,True))
    js=r'''
const fs=require('fs'),i=JSON.parse(fs.readFileSync(0,'utf8'));
const ArraySize=a=>a.length,ArrayResize=(a,n)=>{while(a.length<n)a.push({});a.length=n;return n};
const MathIsValidNumber=Number.isFinite,MathMin=Math.min,MathMax=Math.max,MathAbs=Math.abs,DBL_MAX=Number.MAX_VALUE;
eval(i.source);
let results=[];
for(const [name,c,expected] of i.cases){
 let out={points:[],amplitudes:[],overlaps:[],centres:[],tips:[],bases:[],speeds:[],bar_overlaps:[],urgent:[],spikes:[],radii:[],route_sizes:[],route_prices:[],route_residuals:[],route_usable:[]};
 let accepted=M1ULegacyPushQuality(c.rates,c.points,0,3600,c.cutoff,out);
 if(accepted!==expected)throw Error(name+': '+accepted+' expected '+expected);
 results.push({name,passed:true,accepted});
}
process.stdout.write(JSON.stringify(results));
'''
    p=subprocess.run(['node','-e',js],input=json.dumps(dict(source=src,cases=cases)),capture_output=True,text=True,encoding='utf-8',timeout=30)
    assert p.returncode==0,p.stderr
    results=json.loads(p.stdout)
    provenance=json.loads((OUT/'PROVENANCE.json').read_text('utf-8'))
    with zipfile.ZipFile(ARCHIVE) as archive:
        for name,sha in provenance['original_files'].items():
            assert hashlib.sha256((OUT/name).read_bytes()).hexdigest()==sha
            assert (OUT/name).read_bytes()==archive.read(PREFIX+name)
        entry=archive.read(PREFIX+'Machine1_UnifiedNative.mq5').decode('utf-8-sig')
        overlay=(OUT/'book三推试验板.mq5').read_text('utf-8')
        strip_strings=lambda s:re.sub(r'\s+', '', re.sub(r'"(?:[^"\\]|\\.)*"','""',s))
        render=function(overlay,'NativeRenderThreePush')
        render=render.replace(' geometry+="|"+IntegerToString(showLargePush?1:0)+"|"+IntegerToString(showSmallPush?1:0);\n','')
        render=render.replace('  if(!OverlayGroupEnabled(i))continue;\n','')
        render=render.replace('  if(geometry_changed)OverlayPatternZigzag(base,item,colour);\n','')
        assert strip_strings(function(entry,'NativeRenderThreePush'))==strip_strings(render)
    # Execute the actual MQL display predicate: independent outer/inner toggles
    # include isolated groups as outer, and nested intermediate groups as inner.
    predicate=adapt(function(overlay,'OverlayGroupEnabled'))
    switch_js=r'''
const assert=require('assert/strict');
const ArraySize=a=>a.length;
let nativeLocalThreePush=[{parent:-1},{parent:0},{parent:1},{parent:-1}];
let showLargePush=true,showSmallPush=true;
'''+predicate+r'''
let cases=0;
for(const large of [false,true])for(const small of [false,true]){
 showLargePush=large;showSmallPush=small;
 assert.deepEqual([0,1,2,3].map(OverlayGroupEnabled),[large,small,small,large]);
 assert.equal(OverlayGroupEnabled(-1),false);assert.equal(OverlayGroupEnabled(4),false);cases++;
}
process.stdout.write(JSON.stringify({states:cases,passed:true}));
'''
    switched=subprocess.run(['node','-e',switch_js],text=True,capture_output=True,encoding='utf-8',timeout=10)
    assert switched.returncode==0,switched.stderr
    assert hashlib.sha256((ROOT/'mt5/IPDA_Consolidation.mq5').read_bytes()).hexdigest()==provenance['ipda_source_sha256']
    assert 'CombineShapes(' not in overlay and 'BTPAppend(' not in overlay
    assert 'ObjectDelete(0,name)' not in overlay # Original layer deletes only names under its private prefix.
    proof=dict(source_host_checks=results,display_switch_checks=json.loads(switched.stdout),original_dependencies_byte_identical=True,
               original_tip_renderer_geometry_preserved=True,
               ipda_source_unchanged=True,additional_consolidation_filter=False,
               original_book_project_modified=False,native_visual_verified=False,
               scope='Host execution of original numeric source plus compile/provenance; no EX5 runtime or visual claim.')
    (OUT/'AUDIT.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False,indent=2))

if __name__=='__main__':run()
