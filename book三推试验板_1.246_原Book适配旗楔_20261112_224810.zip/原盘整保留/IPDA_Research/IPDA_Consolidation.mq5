#property copyright "Local IPDA consolidation research"
#property version   "1.23"
#property indicator_chart_window
#property indicator_plots 0

// Read-only: no trading, DLL or network operations. Broker name scopes the cache.
input string InpFolder="IPDA_Consolidation";
input int InpFillAlpha=56;
input bool InpShowLabels=true;
input int InpLabelFontSize=8;
input bool InpCompactDisplay=true;
input bool InpScanLoadedHistory=true;

struct Shape
  {
   int seconds; string key,kind,geometry,label,title,summary,detail; bool active;
   datetime known,until,t[4]; double p[4];
  };
Shape shapes[];
Shape archive_shapes[],history_shapes[];
string history_file="",history_token="",history_loaded="",history_key="",history_status="历史识别准备中";
string history_generation="";
datetime history_from=0,history_to=0;
ulong history_sent=0;
string backfill_file="",backfill_token="",backfill_source="",backfill_status="全历史扫描准备中";
datetime backfill_origin=0,backfill_cursor=0,backfill_page_last=0;
ulong backfill_sent=0;
bool show_current=true;
int morphology=0; // all, horizontal, convergence/wedge, channel, relay
bool show_large=true,show_small=true;
string prefix,revision="",rendered_revision="",expected_revision="",last_beat="",health="模型加载中";
string h1_health="H1 模型加载中",m15_health="M15 模型加载中";
string h1_brief="H1 模型加载中",m15_brief="M15 模型加载中";
ulong last_change=0;
long heartbeat_written=0;
int tiles=0;
bool drag_active=false,drag_moved=false,dirty=true,previous_mouse_move=false,ready=false,view_pending=true;
bool previous_mouse_scroll=true,previous_mouse_wheel=true,previous_keyboard=true;
int wheel_remainder=0;
string owned[],view_key="";
int drag_x=0,drag_first=0,drag_completed=0,drawn_count=0;
double drag_bar_pixels=1;
ulong last_poll=0;
ulong last_drag_end=0;
ulong last_drag_event=0;
ulong last_ui_click=0;
int last_ui_x=0,last_ui_y=0;
bool ui_echo_pending=false;
int label_x[],label_y[],label_w[];
string selected_key="";
int detail_page=0,detail_pages=1,detail_width=0,detail_height=0;
bool detail_metrics=false;
bool show_h1=true,show_m15=false,compact=true;
string preference_key="";
int visible_total=0,hidden_count=0,selected_shapes[],paint_shapes[];
int frame_x[][4],frame_y[][4];

// Display-only selection. All frozen records remain in shapes[] and in the
// bridge archive. Never merge coordinates, qualification or confirmation time.
bool PeriodEnabled(const int seconds,const string kind,const bool h1,const bool m15)
  {
   // Native M15 rows already exist; do not draw their H1 projection twice.
   if(kind=="intraday")return false;
   if(seconds!=900 && seconds!=3600)return seconds==PeriodSeconds() && show_current;
   return (seconds==3600 && h1)||(seconds==900 && m15);
  }

bool MorphologyEnabled(const string geometry,const bool only_converging)
  {return !only_converging || geometry=="converging";}

bool ShapeTypeEnabled(const int i)
  {
   if(morphology==1)return shapes[i].geometry=="rectangle";
   if(morphology==2)return shapes[i].geometry=="converging";
   if(morphology==3)return shapes[i].geometry=="channel";
   if(morphology==4)return StringFind(shapes[i].title,"中继")>=0;
   return true;
  }

bool NestedRectangle(const int outer,const int inner)
  {
   return shapes[outer].seconds==shapes[inner].seconds && shapes[outer].geometry=="rectangle" &&
      InnerDisplayRegion(shapes[inner].t[0],shapes[inner].t[1],shapes[inner].p[0],shapes[inner].p[1],shapes[inner].p[3],shapes[inner].p[2],
                         shapes[outer].t[0],shapes[outer].t[1],shapes[outer].p[0],shapes[outer].p[1],shapes[outer].p[3],shapes[outer].p[2]);
  }

bool LargeRange(const int i)
  {
   // Size belongs to its native period, never the timeframe of this chart.
   // An enclosing same-period rectangle is the outer layer even if short.
   for(int j=0;j<ArraySize(shapes);j++)if(i!=j && NestedRectangle(i,j))return true;
   return FormationHours(shapes[i].seconds,shapes[i].detail)*3600/MathMax(1,shapes[i].seconds)>=48 || shapes[i].kind=="macro";
  }

bool NestedPriceOverlap(const int outer,const int inner)
  {
   if(shapes[outer].seconds!=shapes[inner].seconds || shapes[outer].geometry!="rectangle")return false;
   double a=(double)shapes[outer].t[0],b=(double)shapes[outer].t[1],c=(double)shapes[inner].t[0],d=(double)shapes[inner].t[1];
   if(b<=a || d<=c || c<a || d>b || (d-c)/(b-a)>0.70)return false;
   double oh=MathMax(shapes[outer].p[0],shapes[outer].p[1]),ol=MathMin(shapes[outer].p[2],shapes[outer].p[3]);
   double ih=MathMax(shapes[inner].p[0],shapes[inner].p[1]),il=MathMin(shapes[inner].p[2],shapes[inner].p[3]);
   return MathMin(oh-ol,ih-il)>0 && MathMin(oh,ih)-MathMax(ol,il)>=0.5*MathMin(oh-ol,ih-il);
  }

bool EarlyNestedPriceOverlap(const int outer,const int inner)
  {
   if(shapes[outer].seconds!=shapes[inner].seconds || shapes[outer].kind!="structural" || shapes[inner].kind!="structural" ||
      shapes[outer].geometry!="rectangle" || shapes[inner].geometry!="rectangle")return false;
   double a=(double)shapes[outer].t[0],b=(double)shapes[outer].t[1],c=(double)shapes[inner].t[0],d=(double)shapes[inner].t[1];
   if(b<=a || d<=c || c>=a || d>b || (d-c)/(b-a)>0.5)return false;
   if(a-c>MathMin(shapes[inner].seconds,0.25*(d-c)) || shapes[inner].known>=shapes[outer].known)return false;
   double oh=MathMax(shapes[outer].p[0],shapes[outer].p[1]),ol=MathMin(shapes[outer].p[2],shapes[outer].p[3]);
   double ih=MathMax(shapes[inner].p[0],shapes[inner].p[1]),il=MathMin(shapes[inner].p[2],shapes[inner].p[3]);
   return MathMin(oh-ol,ih-il)>0 && MathMin(oh,ih)-MathMax(ol,il)>=0.8*MathMin(oh-ol,ih-il);
  }

bool SuccessiveFormations(const int early,const int later)
  {
   if(shapes[early].seconds!=shapes[later].seconds || shapes[early].kind=="intraday" ||
      shapes[later].kind!="structural" || shapes[later].geometry!="rectangle")return false;
   double a=(double)shapes[early].t[0],b=(double)shapes[early].t[1],c=(double)shapes[later].t[0],d=(double)shapes[later].t[1];
   if(!(a<c && c<b && b<=d) || b-a>0.5*(d-c))return false;
   if(shapes[early].known>c || shapes[later].known<b)return false;
   return b-c<=0.25*(b-a);
  }

double ShapePriority(const int i)
  {
   bool dense=shapes[i].geometry=="rectangle" &&
      (StringFind(shapes[i].detail,"短横盘候选")>=0 || StringFind(shapes[i].detail,"强位移后密集停顿候选")>=0 ||
       StringFind(shapes[i].detail,"密集横盘：")>=0 || StringFind(shapes[i].detail,"长影线密集候选")>=0);
   if(!dense)for(int j=0;j<ArraySize(shapes);j++)if(i!=j && NestedRectangle(i,j))return 500000+MathMin(48,FormationHours(shapes[i].seconds,shapes[i].detail));
   int tier=(shapes[i].kind=="macro" || shapes[i].kind=="local") && shapes[i].geometry=="rectangle"?4:
      shapes[i].geometry=="converging" || StringFind(shapes[i].title,"中继")>=0?3:shapes[i].geometry=="rectangle"?2:1;
   double hours=FormationHours(shapes[i].seconds,shapes[i].detail);
   double rank=tier*100000+MathMin(48,hours);
   if(tier<4 && shapes[i].geometry=="rectangle" &&
      (StringFind(shapes[i].detail,"按实体范围")>=0 || StringFind(shapes[i].detail,"长影线共同接受区")>=0 ||
       StringFind(shapes[i].detail,"完整范围已完成双向收盘折返")>=0))rank=325000+MathMin(48,hours);
   if(shapes[i].geometry=="channel" && hours*3600/shapes[i].seconds<24)rank=250000+hours;
   if(shapes[i].geometry=="channel" && StringFind(shapes[i].detail,"大实体反向回访")>=0)rank=350000+MathMin(48,hours);
   return rank;
  }

double RailPrice(const double t,const double start,const double end,const double a,const double b)
  {return end<=start?a:a+(b-a)*(t-start)/(end-start);}

double PriceOverlap(const double ah,const double al,const double bh,const double bl)
  {
   double span=MathMax(ah,bh)-MathMin(al,bl);
   return span<=0?0:MathMax(0,MathMin(ah,bh)-MathMax(al,bl))/span;
  }

bool SameDisplayRegion(const double a0,const double a1,const double ah0,const double ah1,const double al0,const double al1,
                       const double b0,const double b1,const double bh0,const double bh1,const double bl0,const double bl1)
  {
   double da=a1-a0,db=b1-b0,left=MathMax(a0,b0),right=MathMin(a1,b1);
   if(da<=0 || db<=0 || right<=left)return false;
   // A truly smaller nested structure or an adjacent stage stays independent.
   if(MathMin(da,db)/MathMax(da,db)<0.50 || (right-left)/MathMin(da,db)<0.78)return false;
   double overlap=0;
   for(int k=0;k<3;k++)
     {
      double t=left+(right-left)*(k+0.5)/3;
      double ah=RailPrice(t,a0,a1,ah0,ah1),al=RailPrice(t,a0,a1,al0,al1);
      double bh=RailPrice(t,b0,b1,bh0,bh1),bl=RailPrice(t,b0,b1,bl0,bl1);
      if(ah<=al || bh<=bl)return false;
      overlap+=PriceOverlap(ah,al,bh,bl);
     }
   return overlap/3>=0.60;
  }

double DisplayPriority(const bool active,const string kind,const double bars)
  {
   // bars is the evidenced formation duration in hours, not wall-clock span.
   // Prioritise a complete observed stage. Saturation prevents an ever longer
   // rolling window from swallowing successive, already distinct stages.
   double rank=kind=="macro"?60:kind=="local"?50:kind=="structural"?30:25;
   return MathMin(48,MathMax(0,bars))*1000+((kind=="macro" || kind=="local")?200:0)+(active?100:0)+rank;
  }

double FormationHours(const int seconds,const string detail)
  {
   int at=StringFind(detail,"观察 ");
   if(at<0)return 0; // Missing evidence must not acquire a broad-range bonus.
   double bars=(double)StringToInteger(StringSubstr(detail,at+3));
   return MathMax(0,bars)*seconds/3600.0;
  }



bool ReadableFootprint(const bool active,const bool selected,const bool compact_view,const int width,const int height)
  {
   // Candle-span filtering already rejects single-bar fragments. A valid
   // three-bar relay must remain visible at the normal H1 history zoom.
   return !compact_view || active || selected || (width>=12 && height>=12);
  }

bool ReadableCandleSpan(const double full_span,const double visible_span)
  {return full_span>=2.0 && visible_span>=1.75;}

bool InnerDisplayRegion(const double a0,const double a1,const double ah0,const double ah1,const double al0,const double al1,
                        const double b0,const double b1,const double bh0,const double bh1,const double bl0,const double bl1)
  {
   double da=a1-a0,db=b1-b0;
   if(da<=0 || db<=da || da/db>0.70 || a0<b0 || a1>b1)return false;
   for(int k=0;k<3;k++)
     {
      double t=a0+da*k/2;
      double ah=RailPrice(t,a0,a1,ah0,ah1),al=RailPrice(t,a0,a1,al0,al1);
      double bh=RailPrice(t,b0,b1,bh0,bh1),bl=RailPrice(t,b0,b1,bl0,bl1);
      double tolerance=0.02*(bh-bl);
      if(ah<=al || bh<=bl || ah>bh+tolerance || al<bl-tolerance)return false;
     }
   return true;
  }

bool ValidDisplayFrame(const double t0,const double t1,const double h0,const double h1,const double l0,const double l1)
  {return t1>t0 && h0>l0 && h1>l1;}

bool AdjacentDisplayRegions(const double a0,const double a1,const double ah0,const double ah1,const double al0,const double al1,
                            const double b0,const double b1,const double bh0,const double bh1,const double bl0,const double bl1)
  {
   double left=MathMax(a0,b0),right=MathMin(a1,b1),span=MathMin(a1-a0,b1-b0);
   if(span<=0 || right<=left || right-left>0.25*span)return false;
   int direction=0;
   for(int k=0;k<3;k++)
     {
      double t=left+(right-left)*(k+0.5)/3;
      double ah=RailPrice(t,a0,a1,ah0,ah1),al=RailPrice(t,a0,a1,al0,al1);
      double bh=RailPrice(t,b0,b1,bh0,bh1),bl=RailPrice(t,b0,b1,bl0,bl1);
      double width=MathMin(ah-al,bh-bl);
      if(width<=0 || MathMax(0,MathMin(ah,bh)-MathMax(al,bl))>0.25*width)return false;
      int side=ah>=bh && al>=bl?1:ah<=bh && al<=bl?-1:0;
      if(side==0 || (direction!=0 && side!=direction))return false;
      direction=side;
     }
   return true;
  }

bool DisplayConflict(const int ap,const double a0,const double a1,const double ah0,const double ah1,const double al0,const double al1,
                     const int bp,const double b0,const double b1,const double bh0,const double bh1,const double bl0,const double bl1)
  {
   if(MathMin(a1,b1)<=MathMax(a0,b0))return false;
   // Successive levels may share a small corner during exit follow-through.
   // Keep actual crossing/repeated alternatives mutually exclusive.
   if(ap==bp)return !AdjacentDisplayRegions(a0,a1,ah0,ah1,al0,al1,b0,b1,bh0,bh1,bl0,bl1);
   // When both buttons are on, only a wholly contained M15 child can coexist
   // with its H1 parent. Partial intersections and crossing rails never coexist.
   if(ap==900 && bp==3600 && InnerDisplayRegion(a0,a1,ah0,ah1,al0,al1,b0,b1,bh0,bh1,bl0,bl1))return false;
   if(bp==900 && ap==3600 && InnerDisplayRegion(b0,b1,bh0,bh1,bl0,bl1,a0,a1,ah0,ah1,al0,al1))return false;
   return true;
  }

string GeometryNote(const string geometry,const string title,const string kind)
  {
   string note=geometry=="rectangle"?"水平边界内往返":geometry=="channel"?"沿倾斜双轨往返":"上下轨逐步收窄";
   if(StringFind(title,"已突破")>=0)return note+" · 已突破";
   if(StringFind(title,"已离开")>=0)return note+" · 已离开";
   if(StringFind(title,"已中止")>=0)return note+" · 已中止";
   return note+((kind=="local" || kind=="macro")?" · 平衡已确认":" · 候选未确认");
  }

string EvidenceNote(const string summary,const string detail)
  {
   string note=summary;int at=StringFind(detail,"方向效率 ");
   if(at>=0 && StringFind(note,"方向效率")<0)
     {
      string tail=StringSubstr(detail,at);int end=StringFind(tail,"；"),newline=StringFind(tail,"\n");
      if(end<0 || (newline>=0 && newline<end))end=newline;
      note+="；"+(end<0?tail:StringSubstr(tail,0,end));
     }
   return note;
  }

double SegmentDistance(const double px,const double py,const double ax,const double ay,const double bx,const double by)
  {
   double dx=bx-ax,dy=by-ay,length=dx*dx+dy*dy;
   double u=length>0?MathMax(0,MathMin(1,((px-ax)*dx+(py-ay)*dy)/length)):0;
   double ex=px-ax-u*dx,ey=py-ay-u*dy;
   return MathSqrt(ex*ex+ey*ey);
  }

bool LabelSpace(const int x,const int y,const int w,const int old_x,const int old_y,const int old_w)
  {return !(x<old_x+old_w+6 && x+w+6>old_x && y<old_y+36 && y+36>old_y);}

void DisplayButton(const string suffix,const string text,const int x,const int width,const bool enabled,const color c)
  {
   string name=prefix+suffix;ObjectCreate(0,name,OBJ_BUTTON,0,0,0);Own(name);
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,44);
   ObjectSetInteger(0,name,OBJPROP_XSIZE,width);ObjectSetInteger(0,name,OBJPROP_YSIZE,24);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");ObjectSetInteger(0,name,OBJPROP_FONTSIZE,9);
   ObjectSetString(0,name,OBJPROP_TEXT,text);ObjectSetInteger(0,name,OBJPROP_COLOR,enabled?c:clrSilver);
   ObjectSetInteger(0,name,OBJPROP_BGCOLOR,enabled?C'30,46,60':C'20,25,32');
   ObjectSetInteger(0,name,OBJPROP_BORDER_COLOR,enabled?c:clrDimGray);
   ObjectSetInteger(0,name,OBJPROP_STATE,false);ObjectSetInteger(0,name,OBJPROP_ZORDER,100);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
  }

void DisplayButtons()
  {
   DisplayButton("H1","H1 盘整 "+(show_h1?"开":"关"),12,108,show_h1,clrGold);
   DisplayButton("M15","M15 盘整 "+(show_m15?"开":"关"),126,114,show_m15,clrTurquoise);
   DisplayButton("MODE",compact?"简洁说明":"详细说明",246,96,compact,clrWhite);
   DisplayButton("HISTORY","历史起点",348,96,true,clrWhite);
   if(_Period!=PERIOD_H1 && _Period!=PERIOD_M15)
      DisplayButton("CURRENT",StringSubstr(EnumToString(_Period),7)+" 盘整 "+(show_current?"开":"关"),450,116,show_current,clrTurquoise);
   string types[]={"形态：全部","形态：横盘","收敛/楔形","形态：通道","形态：中继"};
   DisplayButton("MORPH",types[morphology],570,116,morphology!=0,clrLightSkyBlue);
   ObjectSetString(0,prefix+"MORPH",OBJPROP_TOOLTIP,"依次切换全部、水平箱体、收敛/楔形、倾斜通道、中继横盘；只筛选显示，不删除识别记录");
   DisplayButton("LARGE","大范围 "+(show_large?"开":"关"),12,108,show_large,clrGold);
   DisplayButton("SMALL","小范围 "+(show_small?"开":"关"),126,114,show_small,clrLightSkyBlue);
   ObjectSetInteger(0,prefix+"LARGE",OBJPROP_YDISTANCE,72);
   ObjectSetInteger(0,prefix+"SMALL",OBJPROP_YDISTANCE,72);
   ObjectSetString(0,prefix+"LARGE",OBJPROP_TOOLTIP,"先观察整体：同周期外层箱体、宏观区间或形成窗口至少48根的结构；候选不等于确认");
   ObjectSetString(0,prefix+"SMALL",OBJPROP_TOOLTIP,"再观察内部：同周期较短的箱体、收敛、楔形、通道和中继；与M15/H1开关独立组合");
   datetime first=FirstHistoryTime();
   ObjectSetString(0,prefix+"HISTORY",OBJPROP_TOOLTIP,"跳到终端已加载历史起点；"+backfill_status+"。可见段优先，历史按同一备份标准分段扫描并存档");
   ObjectSetString(0,prefix+"MODE",OBJPROP_TOOLTIP,"只切换说明详略；同层去重，保留同周期大小嵌套；全历史记录保留");
   ObjectSetString(0,prefix+"H1",OBJPROP_TOOLTIP,FeedFresh()?h1_health:"读取服务未更新；H1历史保留");
   ObjectSetString(0,prefix+"M15",OBJPROP_TOOLTIP,FeedFresh()?m15_health:"读取服务未更新；M15历史保留");
  }

datetime FirstHistoryTime()
  {
   datetime first=0;
   for(int i=0;i<ArraySize(shapes);i++)
      if(PeriodEnabled(shapes[i].seconds,shapes[i].kind,show_h1,show_m15) &&
         (first==0 || shapes[i].t[0]<first))first=shapes[i].t[0];
   return first;
  }

void SaveDisplayPreferences()
  {GlobalVariableSet(preference_key,(show_h1?1:0)+(show_m15?2:0)+(compact?4:0));
   GlobalVariableSet(preference_key+".Size",(show_large?1:0)+(show_small?2:0));}

void RestoreDisplayPreferences()
  {
   if(!GlobalVariableCheck(preference_key))return;
   int flags=(int)GlobalVariableGet(preference_key);
   if(flags<0 || flags>7)return;
   show_h1=(flags&1)!=0;show_m15=(flags&2)!=0;compact=(flags&4)!=0;
   if(GlobalVariableCheck(preference_key+".Size"))
     {int size=(int)GlobalVariableGet(preference_key+".Size");show_large=(size&1)!=0;show_small=(size&2)!=0;}
  }

string PeriodHealth(const string period,const string availability,const string summary,const string closed,const bool brief=false)
  {
   string body=summary;
   // The legacy H1 field also carries an M15 companion. Independent layer
   // switches use each period's own field and own close timestamp only.
   if(period=="H1")
     {
      if(StringFind(body,"H1 ")==0)body=StringSubstr(body,3);
      int companion=StringFind(body," / M15 ");
      if(companion>=0)body=StringSubstr(body,0,companion);
     }
   if(brief){int extra=StringFind(body," / ");if(extra>=0)body=StringSubstr(body,0,extra);}
   string stamp=StringSubstr(closed,5,11);StringReplace(stamp,"T"," ");
   string state=availability=="live"?"实时":availability=="analysis_pending"?"新收盘重算中":"当前不可用（"+availability+"）";
   return period+" "+state+" · "+body+" · 收盘 "+stamp;
  }

string SelectedHealth()
  {
   if(show_h1 && show_m15)return h1_brief+" | "+m15_brief;
   if(show_h1)return h1_brief;
   if(show_m15)return m15_brief;
   return "H1 / M15 图层已关闭，后台继续读取";
  }

void SelectDisplayShapes(const int width,const int height)
  {
   ArrayResize(selected_shapes,0);visible_total=0;
   ArrayResize(frame_x,ArraySize(shapes));ArrayResize(frame_y,ArraySize(shapes));
   int x0=0,x1=0,py=0;double price=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double bar_pixels=MathMax(1,(double)(width-65)/MathMax(1,ChartGetInteger(0,CHART_WIDTH_IN_BARS)));
   if(ChartTimePriceToXY(0,0,iTime(_Symbol,_Period,1),price,x0,py) &&
      ChartTimePriceToXY(0,0,iTime(_Symbol,_Period,0),price,x1,py) && x1>x0)bar_pixels=x1-x0;
   int candidates[];double ranks[];
   for(int i=0;i<ArraySize(shapes);i++)
     {
      if(!PeriodEnabled(shapes[i].seconds,shapes[i].kind,show_h1,show_m15))continue;
      if(!ValidDisplayFrame(shapes[i].t[0],shapes[i].t[1],shapes[i].p[0],shapes[i].p[1],shapes[i].p[3],shapes[i].p[2]))continue;
      int n=ArraySize(candidates);ArrayResize(candidates,n+1);ArrayResize(ranks,n+1);candidates[n]=i;
      ranks[n]=ShapePriority(i);
      // H1 supplies the outer context when both layers are enabled; an M15
      // duplicate may not suppress it. Valid contained M15 stages still pass.
      if(show_h1 && show_m15)
        {
         if(shapes[i].seconds==3600)ranks[n]+=1000000;
         // Once H1 owns the broad context, prefer evidenced inner M15 boxes
         // over overlapping geometric alternatives, retaining standard pauses.
         else if(shapes[i].kind=="macro" || shapes[i].kind=="local")ranks[n]+=100000;
        }
      // Within the same scale/qualification, keep the earliest known stage.
      // Later oversized alternatives cannot retroactively erase that stage.
      for(int j=n;j>0 && (ranks[j]>ranks[j-1] || (ranks[j]==ranks[j-1] &&
           (shapes[candidates[j]].known<shapes[candidates[j-1]].known ||
           (shapes[candidates[j]].known==shapes[candidates[j-1]].known && StringCompare(shapes[candidates[j]].key,shapes[candidates[j-1]].key)<0))));j--)
        {double rank=ranks[j-1];ranks[j-1]=ranks[j];ranks[j]=rank;int c=candidates[j-1];candidates[j-1]=candidates[j];candidates[j]=c;}
     }
   // Resolve alternatives over the entire received history BEFORE clipping to
   // the viewport, so panning/zooming cannot change the chosen interpretation.
   int representatives[];
   for(int n=0;n<ArraySize(candidates);n++)
     {
      int i=candidates[n];bool duplicate=false;
      for(int k=0;k<ArraySize(representatives);k++)
        {
         int j=representatives[k];
         if(NestedRectangle(i,j) || NestedRectangle(j,i))continue;
         if(NestedPriceOverlap(i,j) || NestedPriceOverlap(j,i))continue;
         if(DisplayConflict(shapes[i].seconds,shapes[i].t[0],shapes[i].t[1],shapes[i].p[0],shapes[i].p[1],shapes[i].p[3],shapes[i].p[2],
                            shapes[j].seconds,shapes[j].t[0],shapes[j].t[1],shapes[j].p[0],shapes[j].p[1],shapes[j].p[3],shapes[j].p[2])){duplicate=true;break;}
        }
      if(!duplicate){int count=ArraySize(representatives);ArrayResize(representatives,count+1);representatives[count]=i;}
     }
   // Preserve all prior representatives first, then restore independent
   // stages hidden only by narrowly overlapping formation/following frames.
   // New exceptions cannot reshuffle the old representative set.
   for(int pass=0;pass<2;pass++)for(int n=0;n<ArraySize(candidates);n++)
     {
      int i=candidates[n];bool duplicate=false;
      for(int k=0;k<ArraySize(representatives);k++)
        {
         int j=representatives[k];if(i==j){duplicate=true;break;}
         if(NestedRectangle(i,j) || NestedRectangle(j,i) || NestedPriceOverlap(i,j) || NestedPriceOverlap(j,i))continue;
         if(EarlyNestedPriceOverlap(i,j) || EarlyNestedPriceOverlap(j,i))continue;
         if(pass==1 && (SuccessiveFormations(i,j) || SuccessiveFormations(j,i)))continue;
         if(DisplayConflict(shapes[i].seconds,shapes[i].t[0],shapes[i].t[1],shapes[i].p[0],shapes[i].p[1],shapes[i].p[3],shapes[i].p[2],
                            shapes[j].seconds,shapes[j].t[0],shapes[j].t[1],shapes[j].p[0],shapes[j].p[1],shapes[j].p[3],shapes[j].p[2])){duplicate=true;break;}
        }
      if(!duplicate){int count=ArraySize(representatives);ArrayResize(representatives,count+1);representatives[count]=i;}
     }
   for(int slot=0;slot<ArraySize(representatives);slot++)
     {
      int i=representatives[slot],lo=0,hi=0,top=0,bottom=0;bool valid=true;
      if(!ShapeTypeEnabled(i) || (LargeRange(i)?!show_large:!show_small))continue;
      for(int k=0;k<4;k++)
        {
         int x,y;if(!ChartTimePriceToXY(0,0,shapes[i].t[k],shapes[i].p[k],x,y)){valid=false;break;}
         frame_x[i][k]=x;frame_y[i][k]=y;
         if(k==0){lo=hi=x;top=bottom=y;}else{lo=MathMin(lo,x);hi=MathMax(hi,x);top=MathMin(top,y);bottom=MathMax(bottom,y);}
        }
      if(!valid || hi<0 || lo>width || bottom<0 || top>height)continue;
      visible_total++;
      if(!ReadableCandleSpan((hi-lo)/bar_pixels,(MathMin(width-65,hi)-MathMax(0,lo))/bar_pixels))continue;
      if(!ReadableFootprint(shapes[i].active,shapes[i].key==selected_key,true,
           MathMin(width,hi)-MathMax(0,lo),MathMin(height,bottom)-MathMax(0,top)))continue;
      int count=ArraySize(selected_shapes);ArrayResize(selected_shapes,count+1);selected_shapes[count]=i;
     }
   hidden_count=visible_total-ArraySize(selected_shapes);
   // Paint broad backgrounds first so their fill cannot erase inner wedges.
   ArrayResize(paint_shapes,ArraySize(selected_shapes));
   ArrayCopy(paint_shapes,selected_shapes);
   for(int i=1;i<ArraySize(paint_shapes);i++)for(int j=i;j>0 && ShapeArea(paint_shapes[j])>ShapeArea(paint_shapes[j-1]);j--)
     {int previous=paint_shapes[j-1];paint_shapes[j-1]=paint_shapes[j];paint_shapes[j]=previous;}
  }

double ShapeArea(const int i)
  {return (double)(shapes[i].t[1]-shapes[i].t[0])*MathMax(0,(shapes[i].p[0]+shapes[i].p[1]-shapes[i].p[2]-shapes[i].p[3])/2);}

bool InsideShape(const int i,const int j)
  {
   return InnerDisplayRegion(shapes[i].t[0],shapes[i].t[1],shapes[i].p[0],shapes[i].p[1],shapes[i].p[3],shapes[i].p[2],
                             shapes[j].t[0],shapes[j].t[1],shapes[j].p[0],shapes[j].p[1],shapes[j].p[3],shapes[j].p[2]);
  }

bool HasInnerShape(const int index)
  {
   for(int n=0;n<ArraySize(selected_shapes);n++)if(selected_shapes[n]!=index && InsideShape(selected_shapes[n],index))return true;
   return false;
  }

color ShapeColor(const int index)
  {
   if(shapes[index].seconds==3600)return clrGold;
   if(shapes[index].geometry=="converging")return clrLightSkyBlue;
   return shapes[index].geometry=="channel"?clrMediumAquamarine:clrTurquoise;
  }

bool HeartbeatFresh(const long now_utc,const long written_utc,const ulong now_ticks,const ulong changed_ticks)
  {
   // Both wall clocks refer to this computer, never to the broker's labels.
   return written_utc>0 && now_utc>=written_utc-5 && now_utc-written_utc<=15 &&
      changed_ticks>0 && now_ticks>=changed_ticks && now_ticks-changed_ticks<=15000;
  }

bool ModelPainted(const string expected,const string loaded,const string rendered)
  {return expected!="" && expected==loaded && loaded==rendered;}

bool FeedFresh()
  {return HeartbeatFresh((long)TimeGMT(),heartbeat_written,GetTickCount64(),last_change);}

string DisplayHealth()
  {
   if(history_token!="" && history_loaded!=history_token)
     {
      string failure=ReadLine(history_file+".error.tsv"),fields[];
      if(StringSplit(failure,'\t',fields)==4 && fields[0]=="IPDA_ERROR" && fields[2]==history_token)
         return "历史识别暂不可用："+fields[3]+" · 保留已有图形，自动重试";
      return history_status+(GetTickCount64()-history_sent>30000?" · 等待后台历史服务":"");
     }
   if(history_loaded!="")
     {
      MqlTick tick;SymbolInfoTick(_Symbol,tick);
      return history_status+" · "+(!FeedFresh()?"报价服务未更新":TimeTradeServer()-tick.time>60?"报价停滞，保留收盘结论":"原生报价接入");
     }
   if(!FeedFresh())return "读取服务未更新或时钟不一致，历史保留";
   if(!ModelPainted(expected_revision,revision,rendered_revision))return "模型图形待同步，历史保留";
   return SelectedHealth();
  }

void Own(const string name)
  {
   for(int i=0;i<ArraySize(owned);i++)if(owned[i]==name)return;
   int n=ArraySize(owned);ArrayResize(owned,n+1);owned[n]=name;
  }

void DeleteGeometry()
  {
   for(int i=ArraySize(owned)-1;i>=0;i--)
      if(StringFind(owned[i],prefix+"LINE")==0 || StringFind(owned[i],prefix+"TEXT")==0)
        {ObjectDelete(0,owned[i]);ArrayRemove(owned,i,1);}
  }

string ViewKey()
  {
   return IntegerToString(ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR))+":"+
      IntegerToString(ChartGetInteger(0,CHART_WIDTH_IN_PIXELS))+":"+
      IntegerToString(ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0))+":"+
      IntegerToString(ChartGetInteger(0,CHART_SCALE))+":"+
      IntegerToString(Bars(_Symbol,_Period))+":"+
      IntegerToString(ChartGetInteger(0,CHART_SHIFT))+":"+
      DoubleToString(ChartGetDouble(0,CHART_SHIFT_SIZE),4)+":"+
      IntegerToString((long)iTime(_Symbol,_Period,0))+":"+
      DoubleToString(ChartGetDouble(0,CHART_PRICE_MIN,0),_Digits)+":"+
      DoubleToString(ChartGetDouble(0,CHART_PRICE_MAX,0),_Digits);
  }

void FillVisibility(const bool show)
  {
   for(int i=0;i<tiles;i++)ObjectSetInteger(0,prefix+"FILL"+IntegerToString(i),OBJPROP_TIMEFRAMES,show?OBJ_ALL_PERIODS:OBJ_NO_PERIODS);
   for(int i=0;i<ArraySize(owned);i++)if(StringFind(owned[i],prefix+"TEXT")==0)
      ObjectSetInteger(0,owned[i],OBJPROP_TIMEFRAMES,show?OBJ_ALL_PERIODS:OBJ_NO_PERIODS);
  }

void LatestButton()
  {
   string name=prefix+"LATEST";
   ObjectCreate(0,name,OBJ_BUTTON,0,0,0);Own(name);
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_RIGHT_UPPER);ObjectSetInteger(0,name,OBJPROP_XDISTANCE,90);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,42);
   ObjectSetInteger(0,name,OBJPROP_XSIZE,78);ObjectSetInteger(0,name,OBJPROP_YSIZE,23);ObjectSetInteger(0,name,OBJPROP_ZORDER,100);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,name,OBJPROP_TEXT,"回到最新");
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,9);ObjectSetInteger(0,name,OBJPROP_COLOR,clrWhite);ObjectSetInteger(0,name,OBJPROP_BGCOLOR,clrDarkSlateGray);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
  }

void Acknowledge()
  {
   int ack=FileOpen(InpFolder+"\\chart_"+IntegerToString(ChartID())+".tsv",FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ,0,CP_UTF8);
   if(ack==INVALID_HANDLE)return;
   FileWriteString(ack,"IPDA_CHART\t1.23\t"+rendered_revision+"\t"+EnumToString(_Period)+"\t"+IntegerToString(drawn_count)+"\t"+last_beat+"\t"+(!FeedFresh()?"stale":DisplayHealth())+
       "\t"+IntegerToString(ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR))+"\t"+IntegerToString(ChartGetInteger(0,CHART_AUTOSCROLL))+"\t"+IntegerToString(ChartGetInteger(0,CHART_MOUSE_SCROLL))+"\t"+IntegerToString(drag_completed));
   FileClose(ack);
  }

string ReadLine(const string name)
  {
   int f=FileOpen(InpFolder+"\\"+name,FILE_READ|FILE_TXT|FILE_ANSI|FILE_SHARE_READ|FILE_SHARE_WRITE,0,CP_UTF8);
   if(f==INVALID_HANDLE)return "";
   string s=FileReadString(f);FileClose(f);return s;
  }

void LoadShapes()
  {
   int f=FileOpen(InpFolder+"\\shapes.tsv",FILE_READ|FILE_TXT|FILE_ANSI|FILE_SHARE_READ|FILE_SHARE_WRITE,0,CP_UTF8);
   if(f==INVALID_HANDLE)return;
   string header=FileReadString(f),h[];
   if(StringSplit(header,'\t',h)<5 || h[0]!="IPDA_SHAPES" || h[1]!="2" || h[3]!=_Symbol || h[2]=="" || h[2]!=expected_revision){FileClose(f);return;}
   if(h[2]==revision && (ArraySize(h)<6 || h[5]==history_generation)){FileClose(f);return;}
   Shape incoming[];bool complete=false,valid=true;
   int expected=(int)StringToInteger(h[4]);
   while(!FileIsEnding(f))
     {
      string line=FileReadString(f),a[];
      if(line=="END\t"+h[2]){complete=true;break;}
      if(line=="")continue;
      if(StringSplit(line,'\t',a)<24){valid=false;break;}
      int n=ArraySize(incoming);ArrayResize(incoming,n+1);ParseShape(a,incoming[n]);
     }
   FileClose(f);
   // A failed/partial export must never erase the last complete snapshot.
   if(!ShapeSnapshotComplete(valid,complete,expected,ArraySize(incoming)))return;
   ArrayResize(archive_shapes,ArraySize(incoming));
   for(int j=0;j<ArraySize(incoming);j++)archive_shapes[j]=incoming[j];
   revision=h[2];
   if(ArraySize(h)>=6)AcceptHistoryGeneration(h[5]);
   CombineShapes();
   dirty=true;
  }

bool ShapeSnapshotComplete(const bool valid,const bool complete,const int expected,const int received)
  {
   return valid && complete && expected>=0 && received==expected;
  }

void AcceptHistoryGeneration(const string incoming)
  {
   if(incoming=="" || incoming==history_generation)return;
   history_generation=incoming;
   // Keep the last complete drawings and viewport while a new token is issued.
   // Never accept an in-flight response computed under the previous rules.
   history_key="";history_token="";
   backfill_source="";backfill_token="";backfill_cursor=0;
   history_status="识别规则更新，保留原图并重新核对历史";
   dirty=true;
  }

void ParseShape(string &a[],Shape &s)
  {
   s.seconds=(int)StringToInteger(a[0]);s.key=a[1];s.kind=a[3];s.geometry=a[2];
   s.known=(datetime)StringToInteger(a[5]);s.until=(datetime)StringToInteger(a[6]);s.label=a[9];s.active=(a[10]=="1");
   for(int k=0;k<4;k++){s.t[k]=(datetime)StringToInteger(a[13+k*2]);s.p[k]=StringToDouble(a[14+k*2]);}
   s.title=ArraySize(a)>=24?a[21]:a[9];s.summary=ArraySize(a)>=24?a[22]:"点击查看首次可知时间";
   s.detail=ArraySize(a)>=24?a[23]:a[9];StringReplace(s.detail,"~n~","\n");
  }

bool HistoryOwnsArchive(const int source_period,const int current_period,const long start,const long end,const long scan_from,const long scan_to)
  {
   // A finite scan cannot disprove a structure whose formation or ending
   // lies outside its candles. Retain the complete original in that case.
   return source_period==current_period && start>=scan_from && end<=scan_to;
  }

void CombineShapes()
  {
   ArrayResize(shapes,0);
   for(int i=0;i<ArraySize(archive_shapes);i++)
     {
      // The viewport's native candles own its source period. Keep unrelated
      // archived history and other-period overlays without duplicate frames.
      if(history_loaded!="" && HistoryOwnsArchive(archive_shapes[i].seconds,PeriodSeconds(),
         archive_shapes[i].t[0],archive_shapes[i].until,history_from,history_to))continue;
      int n=ArraySize(shapes);ArrayResize(shapes,n+1);shapes[n]=archive_shapes[i];
     }
   for(int i=0;i<ArraySize(history_shapes);i++)
     {
      bool duplicate=false;
      for(int j=0;j<ArraySize(shapes);j++)
         if(shapes[j].key==history_shapes[i].key){duplicate=true;break;}
      if(duplicate)continue;
      int n=ArraySize(shapes);ArrayResize(shapes,n+1);shapes[n]=history_shapes[i];
     }
  }

datetime NativeClose(const datetime opened)
  {
   if(_Period!=PERIOD_MN1)return opened+PeriodSeconds();
   MqlDateTime d;TimeToStruct(opened,d);d.day=1;d.mon++;if(d.mon>12){d.mon=1;d.year++;}
   return StructToTime(d);
  }

string HistorySource()
  {
   string source=AccountInfoString(ACCOUNT_COMPANY)+" | "+AccountInfoString(ACCOUNT_SERVER);
   StringReplace(source,"\t"," ");StringReplace(source,"\n"," ");return source;
  }

bool ExportHistory(const string file,const string token,const int newest,const int needed,const datetime left,const datetime right)
  {
   MqlRates rates[];ArraySetAsSeries(rates,false);
   int copied=CopyRates(_Symbol,_Period,newest,needed,rates);
   if(copied!=needed || copied<1)return false;
   string target=InpFolder+"\\"+file+".request.tsv",temporary=target+".tmp";
   int f=FileOpen(temporary,FILE_WRITE|FILE_TXT|FILE_ANSI,0,CP_UTF8);if(f==INVALID_HANDLE)return false;
   string period=StringSubstr(EnumToString(_Period),7);MqlTick tick;SymbolInfoTick(_Symbol,tick);
   FileWriteString(f,"IPDA_HISTORY\t2\t"+token+"\t"+_Symbol+"\t"+period+"\t"+IntegerToString(PeriodSeconds())+"\t"+
      IntegerToString(iTime(_Symbol,_Period,0))+"\t"+IntegerToString(left)+"\t"+IntegerToString(right)+"\t"+
      IntegerToString(copied)+"\t"+IntegerToString(tick.time)+"\t"+HistorySource()+"\n");
   for(int i=0;i<copied;i++)
      FileWriteString(f,IntegerToString(rates[i].time)+"\t"+IntegerToString(NativeClose(rates[i].time))+"\t"+DoubleToString(rates[i].open,10)+"\t"+
         DoubleToString(rates[i].high,10)+"\t"+DoubleToString(rates[i].low,10)+"\t"+DoubleToString(rates[i].close,10)+"\t"+
         DoubleToString(rates[i].spread*_Point,10)+"\n");
   FileWriteString(f,"END\t"+token+"\t"+IntegerToString(copied)+"\n");FileClose(f);
   return FileMove(temporary,0,target,FILE_REWRITE);
  }

void ScanLoadedHistory()
  {
   if(!InpScanLoadedHistory || _Symbol!="XAUUSD" || drag_active || history_generation=="")return;
   int total=Bars(_Symbol,_Period);if(total<2)return;
   string source=HistorySource(),period=StringSubstr(EnumToString(_Period),7);
   datetime origin=iTime(_Symbol,_Period,total-1);
   if(backfill_source!=source || backfill_origin!=origin)
     {
      backfill_source=source;backfill_origin=origin;backfill_cursor=0;backfill_token="";
      string saved=ReadLine(backfill_file+".progress.tsv"),p[];
      if(StringSplit(saved,'\t',p)==7 && p[0]=="IPDA_SCAN_1.18" && p[1]==period && p[2]==source && StringToInteger(p[3])==origin && p[6]==history_generation)
         backfill_cursor=(datetime)StringToInteger(p[4]);
     }
   if(backfill_token!="")
     {
      int f=FileOpen(InpFolder+"\\"+backfill_file+".reply.tsv",FILE_READ|FILE_TXT|FILE_ANSI|FILE_SHARE_READ|FILE_SHARE_WRITE,0,CP_UTF8);
      bool complete=false;string h[];
      if(f!=INVALID_HANDLE)
        {
         string header=FileReadString(f);int rows=0;
         if(StringSplit(header,'\t',h)==14 && h[0]=="IPDA_VIEW" && h[2]==backfill_token && h[3]==_Symbol && h[4]==period && StringToInteger(h[5])==PeriodSeconds())
            while(!FileIsEnding(f))
              {
               string line=FileReadString(f),a[];int n=StringSplit(line,'\t',a);
               if(n==3 && a[0]=="END"){complete=a[1]==backfill_token && StringToInteger(a[2])==rows && rows==StringToInteger(h[11]);break;}
               if(n!=24)break;rows++;
              }
         FileClose(f);
        }
      if(!complete)
        {
         if(GetTickCount64()-backfill_sent<60000)return;
         // Retry this page; never advance a checkpoint on a partial reply.
         backfill_token="";backfill_status="全历史扫描等待后台，当前页自动重试";
        }
      else
        {
         backfill_cursor=backfill_page_last;backfill_token="";history_key="";
         string target=InpFolder+"\\"+backfill_file+".progress.tsv",temporary=target+".tmp";
         int cp=FileOpen(temporary,FILE_WRITE|FILE_TXT|FILE_ANSI,0,CP_UTF8);
         if(cp!=INVALID_HANDLE)
           {
            FileWriteString(cp,"IPDA_SCAN_1.18\t"+period+"\t"+source+"\t"+IntegerToString(origin)+"\t"+IntegerToString(backfill_cursor)+"\t"+h[7]+"\t"+history_generation+"\n");
            FileClose(cp);FileMove(temporary,0,target,FILE_REWRITE);
           }
        }
     }
   // Use time anchors so a new bar cannot shift the saved page position.
   int next=backfill_cursor>0?iBarShift(_Symbol,_Period,backfill_cursor,true)-1:total-1;
   if(next<0 && backfill_cursor!=iTime(_Symbol,_Period,1)){backfill_cursor=0;next=total-1;}
   int done=total-1-MathMax(0,next);
   backfill_status=period+" 历史已扫描 "+IntegerToString(done)+"/"+IntegerToString(total-1)+" 根";
   if(next<1){backfill_status+=" · 已覆盖终端已加载范围";return;}
   if(history_loaded!=history_token)return; // the visible region always goes first
   int last=MathMax(1,next-1023),oldest=MathMin(total-1,next+512),newest=MathMax(1,last-192);
   string token="page_"+IntegerToString(GetTickCount64())+"_"+IntegerToString(GetMicrosecondCount());
   if(ExportHistory(backfill_file,token,newest,oldest-newest+1,iTime(_Symbol,_Period,next),NativeClose(iTime(_Symbol,_Period,last))))
     {backfill_token=token;backfill_page_last=iTime(_Symbol,_Period,last);backfill_sent=GetTickCount64();}
   else backfill_status+=" · 终端数据待加载，重试当前页";
  }

void RequestHistory()
  {
   if(drag_active || _Symbol!="XAUUSD")return;
   int total=Bars(_Symbol,_Period),first=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
   int visible=(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS);
   if(total<2 || first<1 || visible<1){history_status="等待终端历史数据";return;}
   first=MathMin(first,total-1);int right=MathMax(1,first-visible+1);
   datetime left_time=iTime(_Symbol,_Period,first),right_time=NativeClose(iTime(_Symbol,_Period,right));
   datetime forming=iTime(_Symbol,_Period,0);
   string key=IntegerToString(left_time)+":"+IntegerToString(right_time)+":"+IntegerToString(forming)+":"+IntegerToString(total);
   if(key==history_key && (history_loaded==history_token || GetTickCount64()-history_sent<45000))return;
   // Include context before and after the view. Only closed bars are exported;
   // index zero is never sent, even when the terminal's quote is stale.
   int oldest=MathMin(total-1,first+512),newest=MathMax(1,right-192),needed=oldest-newest+1;
   if(needed>12000){history_status="可见K线超过12000根，请放大后补算";return;}
   string token=IntegerToString(GetTickCount64())+"_"+IntegerToString(GetMicrosecondCount());
   if(!ExportHistory(history_file,token,newest,needed,left_time,right_time)){history_status="终端正在加载该段历史，自动重试";return;}
   string period=StringSubstr(EnumToString(_Period),7);
   history_token=token;
   history_key=key;history_sent=GetTickCount64();history_status=period+" 可见历史补算中 · "+IntegerToString(needed)+"根";dirty=true;
  }

void LoadHistory()
  {
   int f=FileOpen(InpFolder+"\\"+history_file+".reply.tsv",FILE_READ|FILE_TXT|FILE_ANSI|FILE_SHARE_READ|FILE_SHARE_WRITE,0,CP_UTF8);
   if(f==INVALID_HANDLE)return;
   string header=FileReadString(f),h[];
   if(StringSplit(header,'\t',h)!=14 || h[0]!="IPDA_VIEW" || h[1]!="1" || h[2]!=history_token || h[2]==history_loaded ||
      h[3]!=_Symbol || h[4]!=StringSubstr(EnumToString(_Period),7) || StringToInteger(h[5])!=PeriodSeconds()){FileClose(f);return;}
   Shape incoming[];bool complete=false;
   while(!FileIsEnding(f))
     {
      string line=FileReadString(f),a[];int count=StringSplit(line,'\t',a);
      if(count==3 && a[0]=="END"){complete=a[1]==history_token && StringToInteger(a[2])==ArraySize(incoming);break;}
      if(count!=24){FileClose(f);return;}
      int n=ArraySize(incoming);ArrayResize(incoming,n+1);ParseShape(a,incoming[n]);
     }
   FileClose(f);if(!complete || ArraySize(incoming)!=StringToInteger(h[11]))return;
   ArrayResize(history_shapes,ArraySize(incoming));for(int i=0;i<ArraySize(incoming);i++)history_shapes[i]=incoming[i];
   history_from=(datetime)StringToInteger(h[6]);history_to=(datetime)StringToInteger(h[7]);history_loaded=h[2];
   bool latest=history_to==NativeClose(iTime(_Symbol,_Period,1));
   history_status=h[4]+" "+(latest?"最新收盘：":"历史扫描截止：")+h[10]+" · 已扫描"+h[12]+"根 · "+TimeToString(history_to,TIME_DATE|TIME_MINUTES);
   CombineShapes();dirty=true;
   int ack=FileOpen(InpFolder+"\\"+history_file+".loaded.tsv",FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ,0,CP_UTF8);
   if(ack!=INVALID_HANDLE){FileWriteString(ack,header+"\n");FileClose(ack);}
  }

color LineColor(const string kind)
  {
   if(kind=="candidate")return clrLightSalmon;
   if(kind=="geometric")return clrLightSkyBlue;
   if(kind=="structural")return clrGold;
   if(kind=="macro")return clrMediumPurple;
   return clrTurquoise;
  }

void FillPolygon(uint &pixels[],const int width,const int height,const int top,int &xs[],int &ys[],const uint argb)
  {
   int minimum=height-1,maximum=0;
   for(int i=0;i<4;i++){minimum=MathMin(minimum,ys[i]-top);maximum=MathMax(maximum,ys[i]-top);}
   minimum=MathMax(0,minimum);maximum=MathMin(height-1,maximum);
   for(int y=minimum;y<=maximum;y++)
     {
      double cuts[];ArrayResize(cuts,0);double scan=y+top+0.5;
      for(int edge=0;edge<4;edge++)
        {
         int next=(edge+1)%4;
         if((ys[edge]<=scan && ys[next]>scan)||(ys[next]<=scan && ys[edge]>scan))
           {
            int n=ArraySize(cuts);ArrayResize(cuts,n+1);
            cuts[n]=xs[edge]+(scan-ys[edge])*(xs[next]-xs[edge])/(ys[next]-ys[edge]);
           }
        }
      ArraySort(cuts);
      for(int j=0;j+1<ArraySize(cuts);j+=2)
        {
         int left=MathMax(0,(int)MathCeil(cuts[j])),right=MathMin(width-1,(int)MathFloor(cuts[j+1]));
         for(int x=left;x<=right;x++)pixels[y*width+x]=argb;
        }
     }
  }

// Outline and fill share the exact same pixel vertices. Native OBJ_TREND
// endpoints can snap sub-hour M15 anchors differently on an H1 chart.
void StrokeSegment(uint &pixels[],const int width,const int height,const int top,
                   const double x0,const double y0,const double x1,const double y1,const uint argb,const int weight)
  {
   double dx=x1-x0,dy=y1-y0,low=0,high=1;
   double p[4],q[4];p[0]=-dx;p[1]=dx;p[2]=-dy;p[3]=dy;
   q[0]=x0;q[1]=width-1-x0;q[2]=y0-top;q[3]=top+height-1-y0;
   for(int i=0;i<4;i++)
     {
      if(MathAbs(p[i])<0.000001){if(q[i]<0)return;continue;}
      double r=q[i]/p[i];if(p[i]<0)low=MathMax(low,r);else high=MathMin(high,r);
      if(low>high)return;
     }
   double ax=x0+low*dx,ay=y0+low*dy,bx=x0+high*dx,by=y0+high*dy;
   int steps=MathMax(1,(int)MathCeil(MathMax(MathAbs(bx-ax),MathAbs(by-ay))));
   for(int i=0;i<=steps;i++)
     {
      int x=(int)MathRound(ax+(bx-ax)*i/steps),y=(int)MathRound(ay+(by-ay)*i/steps)-top;
      for(int yy=y;yy<y+weight;yy++)for(int xx=x;xx<x+weight;xx++)
         if(xx>=0 && xx<width && yy>=0 && yy<height)pixels[yy*width+xx]=argb;
     }
  }

void StatusLabel(const string value,const color text_color)
  {
   string name=prefix+"STATUS";
   ObjectCreate(0,name,OBJ_LABEL,0,0,0);Own(name);
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_XDISTANCE,12);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,22);
   ObjectSetInteger(0,name,OBJPROP_COLOR,text_color);ObjectSetInteger(0,name,OBJPROP_FONTSIZE,10);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,name,OBJPROP_TEXT,value);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
  }

void PixelText(const string name,const int x,const int y,const string text,const color c,const string tooltip,const int fontsize)
  {
   ObjectCreate(0,name,OBJ_LABEL,0,0,0);Own(name);
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");ObjectSetInteger(0,name,OBJPROP_FONTSIZE,fontsize);
   ObjectSetInteger(0,name,OBJPROP_COLOR,c);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
   ObjectSetInteger(0,name,OBJPROP_ZORDER,50);ObjectSetString(0,name,OBJPROP_TEXT,text);ObjectSetString(0,name,OBJPROP_TOOLTIP,tooltip);
  }

void ExplainShape(const int index,const int left,const int top,const int width,const int height,const color c)
  {
   // Compact title and geometry note near the boundary. If crowded, leave the
   // edge clickable rather than covering unrelated candles with a callout.
   int font=MathMax(7,MathMin(12,InpLabelFontSize));
   string title=shapes[index].title;int separator=StringFind(title,"·");
   if(separator>=0)title=StringSubstr(title,separator+1);
   title=(shapes[index].seconds==3600?"H1 ":shapes[index].seconds==900?"M15 ":StringSubstr(EnumToString(_Period),7)+" ")+title;
   if(StringLen(title)>25)title=StringSubstr(title,0,24)+"…";
   string note=compact?GeometryNote(shapes[index].geometry,shapes[index].title,shapes[index].kind):EvidenceNote(shapes[index].summary,shapes[index].detail);
   int w=MathMin(width-16,(MathMax(StringLen(title),StringLen(note))+1)*(font+3));
   int x=MathMax(8,MathMin(width-w-8,left)),y=MathMax(102,MathMin(height-42,top-38));
   bool found=false;
   for(int row=0;row<4;row++)
     {
      int candidate=y+row*37;if(candidate>height-42)break;bool free=true;
      for(int j=0;j<ArraySize(label_x);j++)
         if(!LabelSpace(x,candidate,w,label_x[j],label_y[j],label_w[j])){free=false;break;}
      if(free){y=candidate;found=true;break;}
     }
   if(!found || ArraySize(label_x)>=MathMax(4,width/180))return;
   int n=ArraySize(label_x);ArrayResize(label_x,n+1);ArrayResize(label_y,n+1);ArrayResize(label_w,n+1);
   label_x[n]=x;label_y[n]=y;label_w[n]=w;
   string base=prefix+"TEXT"+shapes[index].key;
   string tip=GeometryNote(shapes[index].geometry,shapes[index].title,shapes[index].kind)+"\n"+shapes[index].detail;
   PixelText(base,x,y,title,c,tip,font);
   PixelText(base+"NOTE",x,y+17,note,clrSilver,tip,MathMax(7,font-1));
  }

void CloseDetail()
  {
   detail_width=0;detail_height=0;
   for(int i=ArraySize(owned)-1;i>=0;i--)if(StringFind(owned[i],prefix+"DETAIL")==0){ObjectDelete(0,owned[i]);ArrayRemove(owned,i,1);}
  }

void PickDetail(const int x,const int y)
  {
   if(view_key!=ViewKey())return; // Never hit-test a stale screen frame.
   double nearest=7,area=1.0e30;int hit=-1;
   for(int slot=0;slot<ArraySize(selected_shapes);slot++)
     {
      int i=selected_shapes[slot],xs[4],ys[4];
      for(int k=0;k<4;k++){xs[k]=frame_x[i][k];ys[k]=frame_y[i][k];}
      for(int k=0;k<4;k++)
        {
         if(shapes[i].geometry=="channel" && (k==1 || k==3))continue;
         int next=(k+1)%4;double d=SegmentDistance(x,y,xs[k],ys[k],xs[next],ys[next]),a=ShapeArea(i);
         if(d<nearest || (d<=nearest+0.5 && d<=7 && a<area)){nearest=d;area=a;hit=i;}
        }
     }
   if(hit>=0){if(selected_key!=shapes[hit].key)detail_page=0;selected_key=shapes[hit].key;ShowDetail();}
  }

// Measure the exact OBJ_LABEL font in pixels, including Chinese characters.
// TextSetFont uses tenths of logical points: -90 matches label font size 9.
int DetailTextWidth(const string text)
  {
   uint w=0,h=0;
   if(detail_metrics && TextGetSize(text,w,h))return (int)w;
   return StringLen(text)*18; // Conservative fallback if native font metrics fail.
  }
int DetailChunkLength(const string text,const int start,const int width)
  {
   int low=1,high=StringLen(text)-start,best=0;
   while(low<=high)
     {
      int mid=(int)MathFloor((low+high)/2.0);
      if(DetailTextWidth(StringSubstr(text,start,mid))<=width){best=mid;low=mid+1;}
      else high=mid-1;
     }
   best=MathMax(1,best);
   // Keep UTF-16 surrogate pairs together.
   int last=(int)StringGetCharacter(text,start+best-1);
   if(last>=0xD800 && last<=0xDBFF && start+best<StringLen(text))best=best>1?best-1:2;
   return best;
  }
bool InsideDetail(const int x,const int y)
  {return detail_width>0 && x>=10 && x<=10+detail_width && y>=104 && y<=104+detail_height;}
void DetailPageButton(const string suffix,const int x,const int y,const string caption)
  {
   string name=prefix+"DETAIL_"+suffix;ObjectCreate(0,name,OBJ_BUTTON,0,0,0);Own(name);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,name,OBJPROP_XSIZE,72);ObjectSetInteger(0,name,OBJPROP_YSIZE,23);
   ObjectSetInteger(0,name,OBJPROP_BGCOLOR,C'28,47,65');ObjectSetInteger(0,name,OBJPROP_COLOR,clrWhite);
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,9);ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");
   ObjectSetInteger(0,name,OBJPROP_ZORDER,95);ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetString(0,name,OBJPROP_TEXT,caption);
  }
void ShowDetail()
  {
   CloseDetail();if(selected_key=="")return;
   int index=-1;for(int i=0;i<ArraySize(shapes);i++)if(shapes[i].key==selected_key){index=i;break;}
   if(index<0){selected_key="";return;}
   int width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   if(width<240 || height<180)return;
   int w=MathMin(660,width-24);
   detail_metrics=TextSetFont("Microsoft YaHei",-90,FW_NORMAL);
   uint font_w=0,font_h=0;int line_height=19;
   if(detail_metrics && TextGetSize("国Ag",font_w,font_h))line_height=MathMax(19,(int)font_h+4);
   string lines[],wrapped[],detail=shapes[index].detail;
   if(shapes[index].geometry=="converging")
     {
      double initial=shapes[index].p[0]-shapes[index].p[3],final_width=shapes[index].p[1]-shapes[index].p[2];
      detail+="\n形态复核："+shapes[index].title+"；上下边线按同一时段绘制并填色。";
      detail+="\n上轨价差 "+DoubleToString(shapes[index].p[1]-shapes[index].p[0],2)+"；下轨价差 "+DoubleToString(shapes[index].p[2]-shapes[index].p[3],2);
      if(initial>0)detail+="；末/初宽度 "+DoubleToString(final_width/initial,2);
      detail+="\n辨别标准：上平下升为上升三角；上降下平为下降三角；上降下升为三角收敛；双轨同向且收窄为楔形。";
      detail+="\n图例参考：资料图6、10、13、16的双轨收窄和嵌套结构；图中事后突破不提前计作确认。";
     }
   StringSplit(detail,'\n',lines);
   for(int i=0;i<ArraySize(lines);i++)
     {
      if(StringLen(lines[i])==0){int n=ArraySize(wrapped);ArrayResize(wrapped,n+1);wrapped[n]="";continue;}
      for(int at=0;at<StringLen(lines[i]);)
        {
         int length=DetailChunkLength(lines[i],at,w-32),n=ArraySize(wrapped);
         ArrayResize(wrapped,n+1);wrapped[n]=StringSubstr(lines[i],at,length);at+=length;
        }
     }
   int rows=MathMax(1,MathMin(24,(height-180)/line_height));
   detail_pages=MathMax(1,(int)MathCeil((double)ArraySize(wrapped)/rows));
   detail_page=MathMax(0,MathMin(detail_page,detail_pages-1));
   int start=detail_page*rows,count=MathMin(rows,ArraySize(wrapped)-start),h=count*line_height+64;
   detail_width=w;detail_height=h;
   string bg=prefix+"DETAIL_BG";ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);Own(bg);
   ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,10);ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,104);ObjectSetInteger(0,bg,OBJPROP_XSIZE,w);ObjectSetInteger(0,bg,OBJPROP_YSIZE,h);
   ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,C'15,25,38');ObjectSetInteger(0,bg,OBJPROP_COLOR,clrSlateGray);ObjectSetInteger(0,bg,OBJPROP_ZORDER,80);ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,bg,OBJPROP_HIDDEN,true);
   for(int i=0;i<count;i++)
     {string name=prefix+"DETAIL"+IntegerToString(i);PixelText(name,20,135+i*line_height,wrapped[start+i],clrWhite,shapes[index].detail,9);ObjectSetInteger(0,name,OBJPROP_ZORDER,90);}
   PixelText(prefix+"DETAIL_CLOSE",20,111,"盘整详细说明 · 点击关闭",clrGold,shapes[index].detail,9);ObjectSetInteger(0,prefix+"DETAIL_CLOSE",OBJPROP_ZORDER,95);
   int footer=139+count*line_height;
   if(detail_pages>1)
     {
      DetailPageButton("PREV",20,footer,"上一页");DetailPageButton("NEXT",100,footer,"下一页");
      PixelText(prefix+"DETAIL_PAGE",184,footer+2,IntegerToString(detail_page+1)+" / "+IntegerToString(detail_pages),clrSilver,"完整说明分页显示",9);
      ObjectSetInteger(0,prefix+"DETAIL_PAGE",OBJPROP_ZORDER,95);
     }
   ChartRedraw();
  }

void Render()
  {
   if(drag_active)return;
   if(_Symbol!="XAUUSD"){StatusLabel("盘整研究：仅支持原生 XAUUSD",clrOrange);return;}
   int seconds=PeriodSeconds();
   int width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   if(width<10 || height<10)return;
   string frame_view=ViewKey();
   int tile_height=MathMax(1,MathMin(height,3500000/width)),needed=(height+tile_height-1)/tile_height;
   DeleteGeometry();
   ArrayResize(label_x,0);ArrayResize(label_y,0);ArrayResize(label_w,0);
   int drawn=0;SelectDisplayShapes(width,height);
   for(int tile=0;tile<needed;tile++)
     {
      int top=tile*tile_height,h=MathMin(tile_height,height-top);uint pixels[];ArrayResize(pixels,width*h);ArrayInitialize(pixels,0);
      int shown=0;
      for(int slot=0;slot<ArraySize(paint_shapes);slot++)
        {
         int i=paint_shapes[slot];
         int xs[4],ys[4];
         for(int k=0;k<4;k++){xs[k]=frame_x[i][k];ys[k]=frame_y[i][k];}
         color line_color=ShapeColor(i);shown++;
         bool outer=HasInnerShape(i);
         int alpha=outer?MathMin(14,InpFillAlpha):InpFillAlpha;
         FillPolygon(pixels,width,h,top,xs,ys,ColorToARGB(line_color,(uchar)MathMax(0,MathMin(120,alpha))));
         for(int edge=0;edge<4;edge++)
           {
            // Keep the fill polygon closed, but do not draw channel end caps.
            if(shapes[i].geometry=="channel" && (edge==1 || edge==3))continue;
            int next=(edge+1)%4;
            StrokeSegment(pixels,width,h,top,xs[edge],ys[edge],xs[next],ys[next],ColorToARGB(line_color,255),outer?1:2);
           }
         
        }
      drawn=shown;string resource=prefix+"R"+IntegerToString(tile),bitmap=prefix+"FILL"+IntegerToString(tile);
      if(ResourceCreate(resource,pixels,width,h,0,0,width,COLOR_FORMAT_ARGB_NORMALIZE))
        {
         ObjectCreate(0,bitmap,OBJ_BITMAP_LABEL,0,0,0);Own(bitmap);
         ObjectSetInteger(0,bitmap,OBJPROP_XDISTANCE,0);ObjectSetInteger(0,bitmap,OBJPROP_YDISTANCE,top);
         ObjectSetInteger(0,bitmap,OBJPROP_BACK,true);ObjectSetInteger(0,bitmap,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,bitmap,OBJPROP_HIDDEN,true);
         ObjectSetInteger(0,bitmap,OBJPROP_ZORDER,-100);ObjectSetInteger(0,bitmap,OBJPROP_SELECTED,false);ObjectSetInteger(0,bitmap,OBJPROP_TIMEFRAMES,OBJ_ALL_PERIODS);
         ObjectSetString(0,bitmap,OBJPROP_BMPFILE,"::"+resource);
        }
     }
   for(int tile=needed;tile<tiles;tile++){ObjectDelete(0,prefix+"FILL"+IntegerToString(tile));ResourceFree(prefix+"R"+IntegerToString(tile));}
   tiles=needed;
   // Place labels in priority order after all geometry is painted.
   if(InpShowLabels)for(int slot=0;slot<ArraySize(selected_shapes);slot++)
     {
      int i=selected_shapes[slot];
      ExplainShape(i,frame_x[i][0],frame_y[i][0],width,height,ShapeColor(i));
     }
   // The terminal can rescale between chart API calls. Do not publish a frame
   // assembled against an obsolete viewport; retry all parts together.
   if(frame_view!=ViewKey()){FillVisibility(false);dirty=true;view_pending=true;return;}
   drawn_count=drawn;dirty=false;LatestButton();DisplayButtons();
   ShowDetail();
   ChartRedraw();
   // Loading file data is not a completed redraw, especially during a drag.
   rendered_revision=revision;
   bool current=FeedFresh() && ModelPainted(expected_revision,revision,rendered_revision);
   StatusLabel("盘整研究 1.23 | "+EnumToString(_Period)+" | "+DisplayHealth()+" | "+IntegerToString(drawn)+"/"+IntegerToString(visible_total)+" 段 · 实线含候选 · 点击边界看依据",current?clrTurquoise:clrOrange);
   view_key=frame_view;view_pending=false;
  }

int OnInit()
  {
   show_h1=(_Period==PERIOD_H1);show_m15=(_Period==PERIOD_M15);compact=InpCompactDisplay;
   preference_key="IPDA.Display."+IntegerToString(ChartID());
   RestoreDisplayPreferences();
   if(_Period!=PERIOD_H1 && _Period!=PERIOD_M15){show_h1=false;show_m15=false;}
   history_file="viewport_"+IntegerToString(ChartID())+"_"+StringSubstr(EnumToString(_Period),7);
   backfill_file="backfill_"+IntegerToString(ChartID())+"_"+StringSubstr(EnumToString(_Period),7);
   prefix="IPDA_"+IntegerToString(ChartID())+"_"+IntegerToString((int)(GetMicrosecondCount()%1000000))+"_";
   // Parameter dialogs wait for initialization. Never wait on the chart queue
   // or rasterize in that lifecycle callback; do this on the first timer tick.
   IndicatorSetString(INDICATOR_SHORTNAME,"IPDA Consolidation 1.23 (read-only)");EventSetMillisecondTimer(100);return INIT_SUCCEEDED;
  }
void OnDeinit(const int reason)
  {
   EventKillTimer();
   for(int i=0;i<ArraySize(owned);i++)ObjectDelete(0,owned[i]);
   if(ready)
     {
      ChartSetInteger(0,CHART_MOUSE_SCROLL,previous_mouse_scroll);
      ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,previous_mouse_move);
      ChartSetInteger(0,CHART_EVENT_MOUSE_WHEEL,previous_mouse_wheel);
      ChartSetInteger(0,CHART_KEYBOARD_CONTROL,previous_keyboard);
     }
   for(int i=0;i<tiles;i++)ResourceFree(prefix+"R"+IntegerToString(i));
  }
void OnTimer()
  {
   if(!ready)
     {
      previous_mouse_move=(bool)ChartGetInteger(0,CHART_EVENT_MOUSE_MOVE);
      previous_mouse_scroll=(bool)ChartGetInteger(0,CHART_MOUSE_SCROLL);
      previous_mouse_wheel=(bool)ChartGetInteger(0,CHART_EVENT_MOUSE_WHEEL);
      previous_keyboard=(bool)ChartGetInteger(0,CHART_KEYBOARD_CONTROL);
      // Disable native panning BEFORE the gesture starts. Switching it off
      // after the press lets MT5 and this handler both move the same chart.
      ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,true);ChartSetInteger(0,CHART_MOUSE_SCROLL,false);
      ChartSetInteger(0,CHART_EVENT_MOUSE_WHEEL,true);ChartSetInteger(0,CHART_KEYBOARD_CONTROL,true);
      ready=true;
     }
   // Quotes/new bars can change auto-scale without a mouse/chart event.
   // Observe the viewport every timer tick, not only every two-second poll.
   // Mouse-up outside the chart is not guaranteed to arrive in MT5. Expire
   // the gesture lease so hidden bitmap overlays cannot remain hidden forever.
   if(DragLeaseExpired(drag_active,GetTickCount64()-last_drag_event))FinishDrag();
   if(!drag_active){string current=ViewKey();if(current!=view_key){FillVisibility(false);dirty=true;}view_pending=false;}
   if(GetTickCount64()-last_poll<2000){if(dirty && !drag_active)Render();return;}
   last_poll=GetTickCount64();
   RequestHistory();LoadHistory();ScanLoadedHistory();
   ObjectSetString(0,prefix+"HISTORY",OBJPROP_TOOLTIP,backfill_status+"；点击跳到已加载历史起点");
   PixelText(prefix+"SCAN_PROGRESS",700,48,backfill_status,clrSilver,"仅已加载原生K线；扫描完成不等于每段都是盘整",8);
   string line=ReadLine("heartbeat.tsv"),a[];
   if(StringSplit(line,'\t',a)>=13 && a[0]=="IPDA_LIVE" && a[1]=="1" && StringToInteger(a[2])>0 && StringToInteger(a[12])>0)
     {
      if(a[2]!=last_beat){last_beat=a[2];last_change=GetTickCount64();}
      heartbeat_written=StringToInteger(a[12]);expected_revision=a[3];
      h1_health=PeriodHealth("H1",a[5],a[6],a[7]);
      m15_health=PeriodHealth("M15",a[8],a[9],a[10]);
      h1_brief=PeriodHealth("H1",a[5],a[6],a[7],true);
      m15_brief=PeriodHealth("M15",a[8],a[9],a[10],true);
      string updated=h1_health+" | "+m15_health;
      if(health!=updated)dirty=true;health=updated;
     }
   LoadShapes();
   if(dirty && !drag_active)Render();
   bool current=FeedFresh() && ModelPainted(expected_revision,revision,rendered_revision);
   StatusLabel("盘整研究 1.23 | "+EnumToString(_Period)+" | "+DisplayHealth()+" | "+IntegerToString(drawn_count)+"/"+IntegerToString(visible_total)+" 段 · 实线含候选 · 点击边界看依据",current?clrTurquoise:clrOrange);
   Acknowledge();
  }
bool OwnedUiClick(const string name)
  {
   return name==prefix+"MORPH" || name==prefix+"LARGE" || name==prefix+"SMALL" ||
          name==prefix+"CURRENT" || name==prefix+"H1" || name==prefix+"M15" || name==prefix+"MODE" ||
          name==prefix+"LATEST" || name==prefix+"HISTORY" ||
          StringFind(name,prefix+"DETAIL")==0 || StringFind(name,prefix+"TEXT")==0 || StringFind(name,prefix+"LINE")==0;
  }

bool UiEchoClick(const bool pending,const ulong elapsed,const int x,const int y,const int ui_x,const int ui_y)
  {return pending && elapsed<=300 && MathAbs(x-ui_x)<=3 && MathAbs(y-ui_y)<=3;}

void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
  {
   // MT5 can emit a chart CLICK after the same OBJECT_CLICK. A control
   // may already have closed/moved its panel, so old screen containment alone
   // cannot prevent that release from selecting a shape behind it.
   if(id==CHARTEVENT_OBJECT_CLICK && OwnedUiClick(sparam))
     {last_ui_click=GetTickCount64();last_ui_x=(int)lparam;last_ui_y=(int)dparam;ui_echo_pending=true;}
   if(id==CHARTEVENT_CLICK && ui_echo_pending)
     {
      bool echo=UiEchoClick(ui_echo_pending,GetTickCount64()-last_ui_click,(int)lparam,(int)dparam,last_ui_x,last_ui_y);
      ui_echo_pending=false;if(echo)return;
     }
   if(id==CHARTEVENT_OBJECT_CLICK && sparam==prefix+"MORPH")
     {morphology=(morphology+1)%5;selected_key="";CloseDetail();ObjectSetInteger(0,sparam,OBJPROP_STATE,false);dirty=true;return;}
   if(id==CHARTEVENT_OBJECT_CLICK && (sparam==prefix+"LARGE" || sparam==prefix+"SMALL"))
     {
      if(sparam==prefix+"LARGE")show_large=!show_large;else show_small=!show_small;
      SaveDisplayPreferences();selected_key="";CloseDetail();ObjectSetInteger(0,sparam,OBJPROP_STATE,false);dirty=true;return;
     }
   if(id==CHARTEVENT_CHART_CHANGE){if(ViewKey()!=view_key){FillVisibility(false);dirty=true;view_pending=true;ChartRedraw();}return;}
   if(id==CHARTEVENT_OBJECT_CLICK && sparam==prefix+"CURRENT")
     {show_current=!show_current;ObjectSetInteger(0,sparam,OBJPROP_STATE,false);dirty=true;return;}
   if(id==CHARTEVENT_OBJECT_CLICK && (sparam==prefix+"H1" || sparam==prefix+"M15" || sparam==prefix+"MODE"))
     {
      if(sparam==prefix+"H1")show_h1=!show_h1;
      if(sparam==prefix+"M15")show_m15=!show_m15;
      if(sparam==prefix+"MODE")compact=!compact;
      SaveDisplayPreferences();
      selected_key="";CloseDetail();ObjectSetInteger(0,sparam,OBJPROP_STATE,false);dirty=true;return;
     }
   if(id==CHARTEVENT_OBJECT_CLICK && sparam==prefix+"DETAIL_CLOSE")
     {selected_key="";CloseDetail();ChartRedraw();return;}
   if(id==CHARTEVENT_OBJECT_CLICK && (sparam==prefix+"DETAIL_PREV" || sparam==prefix+"DETAIL_NEXT"))
     {detail_page+=sparam==prefix+"DETAIL_NEXT"?1:-1;detail_page=MathMax(0,MathMin(detail_page,detail_pages-1));ShowDetail();return;}
   if(id==CHARTEVENT_OBJECT_CLICK && StringFind(sparam,prefix+"DETAIL")==0)return;
   if(id==CHARTEVENT_OBJECT_CLICK && !drag_moved && (StringFind(sparam,prefix+"TEXT")==0 || StringFind(sparam,prefix+"LINE")==0))
     {
      for(int i=0;i<ArraySize(shapes);i++)if(StringFind(sparam,shapes[i].key)>=0){if(selected_key!=shapes[i].key)detail_page=0;selected_key=shapes[i].key;ShowDetail();break;}
      if(drag_active)FinishDrag();return;
     }
   if(id==CHARTEVENT_OBJECT_CLICK && sparam==prefix+"LATEST")
     {drag_active=false;ChartSetInteger(0,CHART_AUTOSCROLL,true);ChartNavigate(0,CHART_END,0);ObjectSetInteger(0,sparam,OBJPROP_STATE,false);dirty=true;return;}
   if(id==CHARTEVENT_OBJECT_CLICK && sparam==prefix+"HISTORY")
     {
      int bar=Bars(_Symbol,_Period)-1;
      if(bar>=0)
        {
         drag_active=false;FillVisibility(false);
         ChartSetInteger(0,CHART_AUTOSCROLL,false);
         int target=MathMax((int)ChartGetInteger(0,CHART_WIDTH_IN_BARS)-1,bar+2);
         int current=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
         ChartNavigate(0,CHART_CURRENT_POS,current-target);
         dirty=true;view_pending=true;
        }
      ObjectSetInteger(0,sparam,OBJPROP_STATE,false);return;
     }
   if(id==CHARTEVENT_CLICK || id==CHARTEVENT_OBJECT_CLICK)
     {
      if(drag_active)FinishDrag();
      if(!InsideDetail((int)lparam,(int)dparam) && GetTickCount64()-last_drag_end>300)PickDetail((int)lparam,(int)dparam);
      return;
     }
   if(id==CHARTEVENT_MOUSE_WHEEL)
     {
      int x=(int)(short)lparam,y=(int)(short)(lparam>>16);
      int width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
      if(drag_active || InsideDetail(x,y) || x<0 || x>width-65 || y<100 || y>height-25)return;
      // CHART_MOUSE_SCROLL=false also disables native wheel panning.
      // Preserve horizontal wheel navigation, including partial wheel ticks.
      wheel_remainder+=(int)dparam;int steps=wheel_remainder/120;
      wheel_remainder-=steps*120;if(steps==0)return;
      int current=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
      int target=BoundFirstBar(current+steps*3,(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS),Bars(_Symbol,_Period));
      if(target!=current)
        {
         FillVisibility(false);ChartSetInteger(0,CHART_AUTOSCROLL,false);
         ChartNavigate(0,CHART_CURRENT_POS,current-target);dirty=true;ChartRedraw();
        }
      return;
     }
   if(id!=CHARTEVENT_MOUSE_MOVE)return;
   last_drag_event=GetTickCount64();
   bool left=(((uint)StringToInteger(sparam)&1)!=0);int x=(int)lparam,y=(int)dparam;
   int width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   if(left && !drag_active)
     {
      if(InsideDetail(x,y) || x<0 || x>width-65 || y<100 || y>height-25)return;
      drag_active=true;drag_moved=false;drag_x=x;drag_first=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
      int x0=0,x1=0,py=0;double price=SymbolInfoDouble(_Symbol,SYMBOL_BID);
      if(ChartTimePriceToXY(0,0,iTime(_Symbol,_Period,1),price,x0,py) && ChartTimePriceToXY(0,0,iTime(_Symbol,_Period,0),price,x1,py) && x1>x0)drag_bar_pixels=x1-x0;
      else drag_bar_pixels=MathMax(1,(double)(width-65)/MathMax(1,ChartGetInteger(0,CHART_WIDTH_IN_BARS)));
      // Arm the gesture without hiding a valid frame on a simple detail click.
      // Hide the screen-anchored bitmap only once actual panning begins.
      ChartSetInteger(0,CHART_AUTOSCROLL,false);return;
     }
   if(left && drag_active)
     {
      if(!drag_moved && MathAbs(x-drag_x)<4)return;
      if(!drag_moved)FillVisibility(false);
      // Absolute press anchor: returning to the starting pixel also restores
      // the starting bar. Never accumulate deltas against an already moved view.
      int target=DragFirstBar(drag_first,x-drag_x,drag_bar_pixels,(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS),Bars(_Symbol,_Period));
      int current=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
      if(target!=current){ChartNavigate(0,CHART_CURRENT_POS,current-target);drag_moved=true;ChartRedraw();}
      return;
     }
   if(!left && drag_active)
     FinishDrag();
  }
void FinishDrag()
  {
   drag_active=false;if(drag_moved){drag_completed++;last_drag_end=GetTickCount64();}
   drag_moved=false; // Do not suppress a later explanation click after a finished drag.
   dirty=true;
   // Draw on the next timer tick, outside the input handler.
  }
bool DragLeaseExpired(const bool active,const ulong idle_ms)
  {
   return active && idle_ms>=900;
  }
int BoundFirstBar(const int target,const int visible,const int total)
  {
   int maximum=MathMax(0,total-1),minimum=MathMin(maximum,MathMax(0,visible-1));
   return MathMax(minimum,MathMin(maximum,target));
  }
int DragFirstBar(const int first,const int pixels,const double bar_pixels,const int visible,const int total)
  {
   return BoundFirstBar(first+(int)MathRound(pixels/MathMax(1.0,bar_pixels)),visible,total);
  }
int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[])
  {view_pending=true;return rates_total;}
