#property version "1.246"
#property indicator_chart_window
#property indicator_plots 0
#include "BookThreePushPA.mqh"
input int HistoryBars=4000;
input bool ShowPAPatterns=true;
input bool StrictUserCriteria=false; // false: adapt to original Book balanced three-push
string prefix="",revision="";bool enabled=true;
MqlRates cached[];
void Status(string message,string detail){
 string n=prefix+"status";ObjectCreate(0,n,OBJ_LABEL,0,0,0);
 ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_LEFT_LOWER);ObjectSetInteger(0,n,OBJPROP_ANCHOR,ANCHOR_LEFT_LOWER);
 ObjectSetInteger(0,n,OBJPROP_XDISTANCE,12);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,30);
 ObjectSetInteger(0,n,OBJPROP_FONTSIZE,9);ObjectSetInteger(0,n,OBJPROP_COLOR,clrOrchid);
 ObjectSetString(0,n,OBJPROP_TEXT,message);ObjectSetString(0,n,OBJPROP_TOOLTIP,detail);
}
void Line(string n,datetime a,double ap,datetime b,double bp,color c){
 ObjectCreate(0,n,OBJ_TREND,0,a,ap,b,bp);ObjectMove(0,n,0,a,ap);ObjectMove(0,n,1,b,bp);
 ObjectSetInteger(0,n,OBJPROP_COLOR,c);ObjectSetInteger(0,n,OBJPROP_WIDTH,2);
 ObjectSetInteger(0,n,OBJPROP_RAY_LEFT,false);ObjectSetInteger(0,n,OBJPROP_RAY_RIGHT,false);ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
}
void Fill(string n,datetime a,double ap,datetime b,double bp,datetime c,double cp,color col){
 ObjectCreate(0,n,OBJ_TRIANGLE,0,a,ap,b,bp,c,cp);
 ObjectSetInteger(0,n,OBJPROP_FILL,true);ObjectSetInteger(0,n,OBJPROP_COLOR,col);
 ObjectSetInteger(0,n,OBJPROP_BACK,true);ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
}
void Refresh(){
 string button=prefix+"button";ObjectCreate(0,button,OBJ_BUTTON,0,0,0);
 ObjectSetInteger(0,button,OBJPROP_CORNER,CORNER_RIGHT_UPPER);ObjectSetInteger(0,button,OBJPROP_XDISTANCE,600);ObjectSetInteger(0,button,OBJPROP_YDISTANCE,132);
 ObjectSetInteger(0,button,OBJPROP_XSIZE,140);ObjectSetInteger(0,button,OBJPROP_YSIZE,24);
 ObjectSetInteger(0,button,OBJPROP_COLOR,clrOrchid);ObjectSetInteger(0,button,OBJPROP_BGCOLOR,C'22,29,42');
 ObjectSetString(0,button,OBJPROP_TEXT,enabled?"旗/楔分类 开":"旗/楔分类 关");
 int first=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR),visible=(int)ChartGetInteger(0,CHART_VISIBLE_BARS),sec=PeriodSeconds(_Period);
 datetime visibleLeft=iTime(_Symbol,_Period,first),visibleRight=iTime(_Symbol,_Period,MathMax(0,first-visible+1));
 int shift=MathMax(1,first-visible-160);MqlRates r[];ArraySetAsSeries(r,false);
 int count=CopyRates(_Symbol,_Period,shift,MathMin(HistoryBars,Bars(_Symbol,_Period)-shift),r);
 if(count<40){Status("三推旗楔：历史不足，保留上一幅结果","至少需要40根已收盘K线；当前读到"+IntegerToString(count)+"根。不以断连或历史不足代替非形态。");return;}
 bool large=!GlobalVariableCheck("BookOverlay."+IntegerToString(ChartID())+".large")||GlobalVariableGet("BookOverlay."+IntegerToString(ChartID())+".large")>0;
 bool small=!GlobalVariableCheck("BookOverlay."+IntegerToString(ChartID())+".small")||GlobalVariableGet("BookOverlay."+IntegerToString(ChartID())+".small")>0;
 string key=IntegerToString(first)+"|"+IntegerToString(visible)+"|"+IntegerToString(large)+IntegerToString(small)+IntegerToString(enabled);
 bool same=ArraySize(cached)==count;
 for(int i=0;same&&i<count;i++)if(cached[i].time!=r[i].time||cached[i].open!=r[i].open||cached[i].close!=r[i].close||cached[i].high!=r[i].high||cached[i].low!=r[i].low)same=false;
 if(same&&revision==key)return;
 M1ULegacyPush groups[];datetime cutoff=r[count-1].time+sec;
 M1ULegacyPushBuild(r,sec,cutoff,groups);
 ObjectsDeleteAll(0,prefix+"shape_");int shown=0,qualified=0;string exclusions="";
 int f=FileOpen("BookThreePushPA_"+IntegerToString(ChartID())+".tsv",FILE_WRITE|FILE_TXT|FILE_UNICODE);
 if(f!=INVALID_HANDLE)FileWriteString(f,"version\t1.246\nperiod\t"+IntegerToString(sec)+"\ncutoff\t"+IntegerToString(cutoff)+"\nknown\tstart\tend\tcategory\tstate\tevent\treason\n");
 for(int i=ArraySize(groups)-1;i>=0;i--){
  OverlayPA o;OverlayPAEvaluate(r,groups[i],sec,cutoff,o,StrictUserCriteria);
  if(f!=INVALID_HANDLE)FileWriteString(f,IntegerToString(groups[i].known)+"\t"+IntegerToString(groups[i].points[0].time)+"\t"+IntegerToString(groups[i].points[5].time)+"\t"+IntegerToString(o.category)+"\t"+IntegerToString(o.state)+"\t"+IntegerToString(o.event)+"\t"+o.reason+"\n");
  if(o.category==0){if(StringLen(exclusions)<2500)exclusions+=TimeToString(groups[i].known,TIME_DATE|TIME_MINUTES)+" · "+o.reason+"\n";continue;}qualified++;
  if(!enabled||(groups[i].parent<0?!large:!small))continue;
  if(o.end<visibleLeft||o.start>visibleRight||shown>=6)continue;
  string n=prefix+"shape_"+IntegerToString(i),tip=OverlayPAName(o)+"\n"+o.reason+"\nP1/P2/P3="+DoubleToString(groups[i].amplitudes[0],2)+"/"+DoubleToString(groups[i].amplitudes[1],2)+"/"+DoubleToString(groups[i].amplitudes[2],2)+"\n首次可知 "+TimeToString(o.known,TIME_DATE|TIME_MINUTES)+"；破线时刻 "+(o.event>0?TimeToString(o.event,TIME_DATE|TIME_MINUTES):"待发生")+"\n严格用户变体；前置30根效率0.55、位移3均幅、平行宽差15%、包络85%为工程参数。反向收盘破线不等于完整趋势反转，不作交易许可。";
  color col=o.category==1?clrOrchid:o.category==2?clrDeepSkyBlue:o.category==3?clrMediumAquamarine:clrLightSteelBlue;
  color shade=o.category==1?C'35,15,38':o.category==2?C'12,29,40':o.category==3?C'12,35,29':C'23,29,36';
  // Use the same native-bar positions for admission, borders and fill. In
  // particular, never interpolate a weekend in elapsed seconds on one layer
  // and in closed-bar indexes on the other layer.
  int a=-1,b=-1;for(int k=0;k<count;k++){if(r[k].time==o.start)a=k;if(r[k].time==o.end)b=k;}
  if(a<0||b<=a)continue;
  for(int k=a;k<b;k++){
   double ua=o.upper0+(o.upper1-o.upper0)*(k-a)/(b-a),ub=o.upper0+(o.upper1-o.upper0)*(k+1-a)/(b-a);
   double la=o.lower0+(o.lower1-o.lower0)*(k-a)/(b-a),lb=o.lower0+(o.lower1-o.lower0)*(k+1-a)/(b-a);
   string slice=n+"bar_"+IntegerToString(k-a);
   Line(slice+"upper",r[k].time,ua,r[k+1].time,ub,col);Line(slice+"lower",r[k].time,la,r[k+1].time,lb,col);
   Fill(slice+"fill_a",r[k].time,ua,r[k+1].time,ub,r[k+1].time,lb,shade);
   Fill(slice+"fill_b",r[k].time,ua,r[k+1].time,lb,r[k].time,la,shade);
   string parts[4]={"upper","lower","fill_a","fill_b"};for(int j=0;j<4;j++)ObjectSetString(0,slice+parts[j],OBJPROP_TOOLTIP,tip);
  }
  ObjectCreate(0,n+"label",OBJ_TEXT,0,o.end,o.upper1);ObjectSetInteger(0,n+"label",OBJPROP_COLOR,col);
  ObjectSetInteger(0,n+"label",OBJPROP_FONTSIZE,9);ObjectSetString(0,n+"label",OBJPROP_TEXT,OverlayPAName(o));
  ObjectSetString(0,n+"label",OBJPROP_TOOLTIP,tip);
  // The original six confirmed pivots provide the three drives and two returns.
  for(int j=1;j<6;j++){
   string leg=n+"zz_"+IntegerToString(j);
   Line(leg,groups[i].points[j-1].time,groups[i].points[j-1].price,groups[i].points[j].time,groups[i].points[j].price,col);
   ObjectSetInteger(0,leg,OBJPROP_WIDTH,1);ObjectSetString(0,leg,OBJPROP_TOOLTIP,tip+"\nZigZag辅助：原三推六点/五段，不改原锚点。");
  }
  shown++;
 }
 if(f!=INVALID_HANDLE){FileWriteString(f,"summary\tgroups="+IntegerToString(ArraySize(groups))+"\tqualified="+IntegerToString(qualified)+"\tshown="+IntegerToString(shown)+"\n");FileClose(f);}
 ArrayResize(cached,count);ArrayCopy(cached,r);revision=key;
 Status("三推旗楔 PA："+(enabled?"开":"关")+" · "+(StrictUserCriteria?"严格":"Book适配")+" · 原Book "+IntegerToString(ArraySize(groups))+"组 · 可画轮廓 "+IntegerToString(qualified)+"组 · 当前绘制 "+IntegerToString(shown)+"组",
        "只对原Book三推分型；不满足前置趋势、逐推衰减或规整边界时不强行归类。\n最近未归类原因：\n"+exclusions);
 ObjectSetString(0,button,OBJPROP_TOOLTIP,"严格PA分类："+IntegerToString(qualified)+"组符合几何/背景；可见显示"+IntegerToString(shown)+"组。最多6组说明以免遮挡。无资格仍保留原Book三推。只读取已收盘K线。三推与旗楔分类不等同。 ");ChartRedraw();
}
int OnInit(){if(HistoryBars<100||HistoryBars>50000)return INIT_PARAMETERS_INCORRECT;prefix="BOOK_PA_"+IntegerToString(ChartID())+"_"+IntegerToString(GetTickCount64())+"_";enabled=ShowPAPatterns;IndicatorSetString(INDICATOR_SHORTNAME,"book三推旗楔 PA 1.246");EventSetTimer(2);return INIT_SUCCEEDED;}
int OnCalculate(const int total,const int prev,const datetime &t[],const double &o[],const double &h[],const double &l[],const double &c[],const long &tv[],const long &v[],const int &s[]){return total;}
void OnTimer(){Refresh();}
void OnChartEvent(const int id,const long &l,const double &d,const string &s){if(id==CHARTEVENT_OBJECT_CLICK&&s==prefix+"button"){enabled=!enabled;revision="";ObjectSetInteger(0,s,OBJPROP_STATE,false);Refresh();}if(id==CHARTEVENT_CHART_CHANGE)Refresh();}
void OnDeinit(const int reason){EventKillTimer();ObjectsDeleteAll(0,prefix);}
