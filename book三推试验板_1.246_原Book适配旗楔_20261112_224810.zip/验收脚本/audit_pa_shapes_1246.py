"""Execute shipped MQL on fixtures/captured OHLC, never a strategy backtest."""
from pathlib import Path
import copy,hashlib,json,re,subprocess,zipfile,sys
from audit_original_overlay import adapt
from build_original_overlay import ARCHIVE,PREFIX,BOOK_ZIGZAG,function

ROOT=Path(__file__).resolve().parents[2]
SOURCE=Path(__file__).resolve().parent/'pa_shapes'
ARTIFACTS=Path('D:/盘整研究资料/验收/三推旗楔_PA_1.246')

def translated_source():
    mql=(SOURCE/'BookThreePushPA.mqh').read_text('utf-8')
    reference=BOOK_ZIGZAG.read_text('utf-8-sig')
    for name in ['BKNMTFAppendPivot','BKNMTFBuild']:
        assert function(mql,name)==function(reference,name),name
    kernel=(SOURCE/'Machine1_UnifiedNativeKernel.mqh').read_text('utf-8-sig')
    code=function(kernel,'M1UValidRate')+'\n'+mql[:mql.index('string OverlayPAName(')]
    code=re.sub(r'\b(?:void|int)\s+(BKNMTF\w+)\(([^)]*)\)\{',lambda m:'function '+m[1]+'('+','.join(re.search(r'(\w+)\s*(?:\[\])?\s*$',p).group(1) for p in m[2].split(','))+'){',code)
    code=adapt(code)
    code=re.sub(r'\bBKNMTFPivot\s+(\w+)=\[\];',r'let \1=[];',code)
    code=re.sub(r'\bBKNMTFPivot\s+(\w+);',r'let \1={};',code)
    code=re.sub(r'\bMqlRates\s+(\w+)=\[\];',r'let \1=[];',code)
    return re.sub(r'\bstring\s+','let ',code)

def fixture(trend=1,parallel=False):
    indices=[30,38,42,48,52,56] if parallel else [30,40,45,50,55,60]
    prices=[100,112,106,117,111,121] if parallel else [100,112,104,114,108,116]
    rows=[]
    for i in range(30):
        price=84+i*.5 if trend==1 else 116-i*.5
        rows.append(dict(time=1700000000+i*60,open=price,close=price,high=price+.35,low=price-.35))
    for i in range(30,indices[-1]+1):
        j=next(j for j in range(5) if indices[j]<=i<=indices[j+1])
        price=prices[j]+(prices[j+1]-prices[j])*(i-indices[j])/(indices[j+1]-indices[j])
        rows.append(dict(time=1700000000+i*60,open=price,close=price,high=price+.01,low=price-.01))
    points=[]
    for j,(i,price) in enumerate(zip(indices,prices)):
        kind=-1 if j%2==0 else 1
        rows[i]['low' if kind==-1 else 'high']=price
        points.append(dict(time=rows[i]['time'],known=rows[i]['time']+60,price=price,kind=kind))
    p=dict(points=points,direction=1,known=points[-1]['known'],amplitudes=[prices[j+1]-prices[j] for j in (0,2,4)])
    return dict(rows=rows,group=p,cutoff=p['known'],seconds=60)

def mirror(c):
    c=copy.deepcopy(c)
    for r in c['rows']:r.update(open=250-r['open'],close=250-r['close'],high=250-r['low'],low=250-r['high'])
    for p in c['group']['points']:p.update(price=250-p['price'],kind=-p['kind'])
    c['group']['direction']*=-1
    return c

def appended(c,close=90,low=None):
    c=copy.deepcopy(c)
    c['rows'].append(dict(time=c['cutoff'],open=close,close=close,high=close+.01,low=close-.01 if low is None else low))
    c['cutoff']+=60
    return c

def fixtures():
    cases=[]
    def add(name,c,category,state=0):cases.append(dict(name=name,case=c,category=category,state=state))
    for trend in (-1,1):
        for parallel in (False,True):
            c=fixture(trend,parallel)
            category=(0 if parallel else 1) if trend==1 else (2 if parallel else 3)
            add(f'geometry_context_{trend}_{parallel}',c,category)
            add(f'mirror_geometry_context_{trend}_{parallel}',mirror(c),category)
    base=fixture()
    for c,cat,state,name in [(appended(base),1,1,'expected_break'),(appended(base,130),1,2,'wrong_break'),(appended(base,114,90),1,0,'wick_reclaim'),(appended(fixture(-1)),3,1,'wedge_flag_break'),(appended(fixture(-1,True)),2,1,'parallel_flag_break')]:
        add(name,c,cat,state);add('mirror_'+name,mirror(c),cat,state)
    c=appended(base);c['cutoff']-=60;add('forming_bar_excluded',c,1)
    c['rows'][-1].update(open=9999,close=9999,high=9999,low=9999);add('future_extreme_no_change',copy.deepcopy(c),1)
    for name,mutate in [
      ('future_group',lambda c:c['group'].update(known=c['cutoff']+60)),
      ('future_point',lambda c:c['group']['points'][5].update(known=c['cutoff']+60)),
      ('amplitude_metadata',lambda c:c['group']['amplitudes'].__setitem__(1,12)),
      ('misbound_anchor',lambda c:c['group']['points'][3].update(price=114.2)),
      ('invalid_direction',lambda c:c['group'].update(direction=0)),
      ('direction_mismatch',lambda c:c['group'].update(direction=-1)),
      ('premature_pivot',lambda c:c['group']['points'][4].update(known=c['group']['points'][4]['time']-1)),
      ('invalid_ohlc',lambda c:c['rows'][35].update(high=c['rows'][35]['low']-1)),
      ('duplicate_time',lambda c:c['rows'][35].update(time=c['rows'][34]['time']))]:
        c=copy.deepcopy(base);mutate(c);add(name,c,0)
    c=appended(base);c['rows'][-1]['high']=c['rows'][-1]['low']-1;add('invalid_followup_no_confirmation',c,1,3)
    c=copy.deepcopy(base)
    for r in c['rows'][:30]:r.update(open=100,close=100,high=101,low=99)
    add('range_precontext_excluded',c,0)
    add('first_exit_frozen',appended(appended(base),130),1,1)
    c=copy.deepcopy(base)
    for r in c['rows'][44:]:r['time']+=172800
    for p in c['group']['points']:
        if p['time']>=base['rows'][44]['time']:p['time']+=172800;p['known']+=172800
    c['group']['known']+=172800;c['cutoff']+=172800
    add('bar_index_geometry_with_weekend_gap',c,1)
    c=copy.deepcopy(base)
    for r in c['rows']:r['time']=1700000000+120*((r['time']-1700000000)//60)
    for p in c['group']['points']:p['time']=1700000000+120*((p['time']-1700000000)//60);p['known']=p['time']+60
    c['group']['known']=c['group']['points'][-1]['known'];c['cutoff']=c['group']['known']
    add('sparse_sampling_not_native_period',c,0)
    # Ordered pre-pattern swing structure, despite a less smooth close path.
    c=copy.deepcopy(base)
    values=[82,83,84,85,86,88,90,89,88,87,86,85,84,85,86,88,90,92,94,93,92,91,90,89,88,89,90,92,94,96]
    for r,v in zip(c['rows'][:30],values):r.update(open=v,close=v,high=v+.35,low=v-.35)
    add('ordered_HH_HL_pretrend',c,1);add('mirrored_LH_LL_pretrend',mirror(c),1)
    c=copy.deepcopy(base);c['strict']=False
    add('adapted_converging_reversal_outline',c,1)
    c=fixture(-1,True);c['strict']=False;add('adapted_parallel_flag',c,2)
    c=copy.deepcopy(base);c['strict']=False
    for r in c['rows'][:30]:r.update(open=100,close=100,high=101,low=99)
    add('adapted_unknown_background_is_outline_only',c,4)
    add('adapted_unknown_background_mirror',mirror(c),4)
    c=copy.deepcopy(base);c['strict']=False;c['group']['points'][5]['price']=118;c['group']['amplitudes'][2]=10;c['rows'][-1]['high']=118
    add('adapted_nonshrinking_not_forced_reversal',c,4)
    return cases

HOST=r'''
const fs=require('fs'),input=JSON.parse(fs.readFileSync(0,'utf8'));
const ArraySize=a=>a.length,ArrayResize=(a,n)=>{while(a.length<n)a.push({});a.length=n;return n};
const MathIsValidNumber=Number.isFinite,MathMin=Math.min,MathMax=Math.max,MathAbs=Math.abs;
eval(input.source);
const evaluate=c=>{const o={};OverlayPAEvaluate(c.rows,c.group,c.seconds,c.cutoff,o,c.strict??true);return o;};
const checks=input.cases.map(t=>{const o=evaluate(t.case);if(o.category!==t.category||o.state!==t.state)
 throw Error(t.name+': '+JSON.stringify(o)+' expected '+t.category+'/'+t.state);return {name:t.name,passed:true};});
const native=input.native.map(c=>({period:c.period,bars:c.rows.length,groups:c.groups.map(group=>({known:group.known,
 start:group.points[0].time,end:group.points[5].time,...evaluate({...c,group})}))}));
process.stdout.write(JSON.stringify({checks,native}));
'''

def main():
    native=[];captured=ROOT/'work/threepush_completeness_20261110'
    full='--full-history' in sys.argv
    for period,seconds in [('H1',3600),('M15',900)]:
        rows=json.loads((captured/f'{period}_closed.json').read_text('utf-8'))
        if not full:rows=rows[-4000:]
        group_file=f'{period}_original_all_groups.json' if full else f'{period}_original_recent4000.json'
        groups=json.loads((captured/group_file).read_text('utf-8'))
        native.append(dict(period=period,seconds=seconds,rows=rows,groups=groups,cutoff=rows[-1]['time']+seconds))
    proc=subprocess.run(['node','-e',HOST],input=json.dumps(dict(source=translated_source(),cases=fixtures(),native=native)),capture_output=True,text=True,encoding='utf-8',timeout=90)
    assert proc.returncode==0,proc.stderr[-5000:]
    result=json.loads(proc.stdout)
    baseline=SOURCE.parent/'original_overlay'
    original=json.loads((baseline/'PROVENANCE.json').read_text('utf-8'))
    for name,expected in original['original_files'].items():
        assert hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()==expected,name
        assert (SOURCE/name).read_bytes()==(baseline/name).read_bytes(),name
    if ARCHIVE.exists():
        with zipfile.ZipFile(ARCHIVE) as archive:
            for name in original['original_files']:assert (SOURCE/name).read_bytes()==archive.read(PREFIX+name),name
    ARTIFACTS.mkdir(parents=True,exist_ok=True)
    native=result.pop('native')
    output_name='all_captured_native_classification.json' if full else 'captured_native_classification.json'
    (ARTIFACTS/output_name).write_text(json.dumps(native,ensure_ascii=False,indent=2),'utf-8')
    result.update(version='1.246',book_dependencies_match_previously_verified_baseline=True,archive_present_for_fresh_comparison=ARCHIVE.exists(),book_zigzag_functions_byte_identical=True,
                  mql_sha256=hashlib.sha256((SOURCE/'BookThreePushPA.mqh').read_bytes()).hexdigest(),native_visual_verified=False,
                  scope='Actual MQL numerical classifier translated to host JS; fixtures and captured native OHLC classification, no strategy backtest or accuracy claim.')
    for dest in [SOURCE/'PA_AUDIT.json',ARTIFACTS/'PA_AUDIT.json']:dest.write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps(dict(checks=len(result['checks']),native=[dict(period=n['period'],groups=len(n['groups']),classified=sum(g['category']>0 for g in n['groups'])) for n in native],artifacts=str(ARTIFACTS))))

if __name__=='__main__':main()
