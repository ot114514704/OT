#ifndef BOOK_PA_DISPLAY
#define BOOK_PA_DISPLAY
M1ULegacyPush paGroups[];
OverlayPA paShapes[];
string paDrawIds[],paDrawKeys[];
bool paViewPending=true,paDirty=true;
ulong paLastView=0,paLastPoll=0,paLastBuildUs=0;
int paBuilds=0,paFrames=0,paSubmitted=0,paQualified=0;
string paExclusions="",paFrameKey="";

bool PAQuiet(const ulong now,const ulong viewAt){return viewAt==0||now-viewAt>=200;}
bool PAPollDue(const ulong now,const ulong polledAt){return polledAt==0||now-polledAt>=2000;}
bool PASameRows(const MqlRates &a[],const MqlRates &b[]){
 if(ArraySize(a)!=ArraySize(b))return false;
 for(int i=0;i<ArraySize(a);i++)if(a[i].time!=b[i].time||a[i].open!=b[i].open||a[i].high!=b[i].high||a[i].low!=b[i].low||a[i].close!=b[i].close)return false;
 return true;
}
// Group adjacent native bars into one quadrilateral. Keep session-gap edges
// separate so its border and fill still use exactly the same bar coordinates.
int PATileEnd(const MqlRates &r[],const int from,const int last,const int seconds){
 int end=from+1;if(end>last)return last;
 if(r[end].time-r[from].time!=seconds)return end;
 while(end<last&&r[end+1].time-r[end].time==seconds)end++;
 return end;
}
color PABlend(const color ink,const color background,const int percent){
 uint value=0;
 for(int channel=0;channel<3;channel++){
  int shift=channel*8;uint a=((uint)ink>>shift)&255,b=((uint)background>>shift)&255;
  value|=(uint)((a*percent+b*(100-percent))/100)<<shift;
 }
 return (color)value;
}
string PAGroupId(const M1ULegacyPush &g){
 ulong hash=1469598103934665603;
 for(int j=0;j<6;j++)hash=(hash^(ulong)g.points[j].time)*1099511628211;
 return IntegerToString(hash);
}
string PATip(const int i){
 OverlayPA o=paShapes[i];
 string mode=StrictUserCriteria?"严格模式：逐推衰减，实体包络85%，平行宽差15%。":"Book适配：保留原三推；不强制逐推衰减，实体包络70%，平行宽差25%。";
 return OverlayPAName(o)+"\n"+o.reason+"\nP1/P2/P3="+DoubleToString(paGroups[i].amplitudes[0],2)+"/"+DoubleToString(paGroups[i].amplitudes[1],2)+"/"+DoubleToString(paGroups[i].amplitudes[2],2)+
 "\n首次可知 "+TimeToString(o.known,TIME_DATE|TIME_MINUTES)+"；越轨记录 "+(o.event>0?TimeToString(o.event,TIME_DATE|TIME_MINUTES):"无")+"\n"+mode+
 "\n前置趋势和收盘跟进独立核验；背景未验证只画轮廓，不确认反转/中继。参数是工程阈值，非概率。";
}
void PAButtons(){
 string n=prefix+"button";ObjectCreate(0,n,OBJ_BUTTON,0,0,0);
 ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_RIGHT_UPPER);ObjectSetInteger(0,n,OBJPROP_XDISTANCE,600);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,132);
 ObjectSetInteger(0,n,OBJPROP_XSIZE,140);ObjectSetInteger(0,n,OBJPROP_YSIZE,24);
 ObjectSetInteger(0,n,OBJPROP_COLOR,clrOrchid);ObjectSetInteger(0,n,OBJPROP_BGCOLOR,C'22,29,42');
 ObjectSetString(0,n,OBJPROP_TEXT,enabled?"旗/楔分类 开":"旗/楔分类 关");
 ObjectSetString(0,n,OBJPROP_TOOLTIP,"独立旗楔图层，保留原盘整与三推。模式："+(StrictUserCriteria?"严格":"原Book适配")+"。同屏最多6组，原数据中仍保留其他候选。");
}
bool PALoad(){
 int first=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR),visible=(int)ChartGetInteger(0,CHART_VISIBLE_BARS),seconds=PeriodSeconds(_Period);
 int right=MathMax(1,first-visible+1),available=Bars(_Symbol,_Period),start=MathMax(1,right-160),count=MathMin(HistoryBars,available-start);
 // Reuse a historical time window across panning and new live closes.
 // Read exact CLOSED OHLC again every poll to catch broker corrections.
 int oldCount=ArraySize(cached);
 if(oldCount>0&&right>160){
  int oldLeft=iBarShift(_Symbol,_Period,cached[0].time,false),oldRight=iBarShift(_Symbol,_Period,cached[oldCount-1].time,false);
  if(oldLeft>=first+160&&oldRight>=1&&oldRight<=MathMax(1,right-160)){start=oldRight;count=oldCount;}
 }
 if(count<40||seconds<=0){Status("三推旗楔：原生历史不足，保留旧图形","历史/周期尚未就绪，不作当前确认。");return false;}
 MqlRates rows[];ArraySetAsSeries(rows,false);int copied=CopyRates(_Symbol,_Period,start,count,rows);
 if(copied<40){Status("三推旗楔：正在读取历史，保留旧图形","未将暂时读数失败当作没有形态。");return false;}
 for(int i=0;i<copied;i++)if(!M1UValidRate(rows[i])||(i>0&&rows[i].time<=rows[i-1].time)){Status("三推旗楔：原生输入无效","已保留旧图形，等待有效已收盘输入。");return false;}
 if(PASameRows(rows,cached))return true;
 ulong began=GetMicrosecondCount();datetime cutoff=rows[copied-1].time+seconds;
 M1ULegacyPush next[];M1ULegacyPushBuild(rows,seconds,cutoff,next);
 ArrayResize(paGroups,ArraySize(next));ArrayResize(paShapes,ArraySize(next));paQualified=0;paExclusions="";
 for(int i=0;i<ArraySize(next);i++){
  paGroups[i]=next[i];OverlayPAEvaluate(rows,next[i],seconds,cutoff,paShapes[i],StrictUserCriteria);
  if(paShapes[i].category>0)paQualified++;
 }
 for(int i=ArraySize(next)-1;i>=0&&StringLen(paExclusions)<1800;i--)if(paShapes[i].category==0)paExclusions+=TimeToString(next[i].known,TIME_DATE|TIME_MINUTES)+" · "+paShapes[i].reason+"\n";
 ArrayResize(cached,copied);ArrayCopy(cached,rows);paBuilds++;paLastBuildUs=GetMicrosecondCount()-began;paDirty=true;
 return true;
}
void PADrawGroup(const int i,const string id,const color background){
 OverlayPA o=paShapes[i];string base=prefix+"g"+id,tip=PATip(i);
 color ink=o.category==1?clrOrchid:o.category==2?clrDeepSkyBlue:o.category==3?clrMediumAquamarine:clrLightSteelBlue;
 color shade=PABlend(ink,background,o.category==4?12:20);
 int a=-1,b=-1;for(int k=0;k<ArraySize(cached);k++){if(cached[k].time==o.start)a=k;if(cached[k].time==o.end)b=k;}
 if(a<0||b<=a)return;
 int tile=0;
 for(int k=a;k<b;){
  int end=PATileEnd(cached,k,b,PeriodSeconds(_Period));
  double ua=o.upper0+(o.upper1-o.upper0)*(k-a)/(b-a),ub=o.upper0+(o.upper1-o.upper0)*(end-a)/(b-a);
  double la=o.lower0+(o.lower1-o.lower0)*(k-a)/(b-a),lb=o.lower0+(o.lower1-o.lower0)*(end-a)/(b-a);
  string n=base+"s"+IntegerToString(tile++);
  Line(n+"u",cached[k].time,ua,cached[end].time,ub,ink);Line(n+"l",cached[k].time,la,cached[end].time,lb,ink);
  Fill(n+"a",cached[k].time,ua,cached[end].time,ub,cached[end].time,lb,shade);Fill(n+"b",cached[k].time,ua,cached[end].time,lb,cached[k].time,la,shade);
  string parts[4]={"u","l","a","b"};for(int j=0;j<4;j++)ObjectSetString(0,n+parts[j],OBJPROP_TOOLTIP,tip);
  paSubmitted+=4;k=end;
 }
 string label=base+"text";ObjectCreate(0,label,OBJ_TEXT,0,o.end,o.upper1);ObjectSetInteger(0,label,OBJPROP_COLOR,ink);
 ObjectSetInteger(0,label,OBJPROP_FONTSIZE,9);ObjectSetInteger(0,label,OBJPROP_SELECTABLE,false);ObjectSetString(0,label,OBJPROP_TEXT,OverlayPAName(o));ObjectSetString(0,label,OBJPROP_TOOLTIP,tip);paSubmitted++;
 for(int j=1;j<6;j++){
  string n=base+"z"+IntegerToString(j);Line(n,paGroups[i].points[j-1].time,paGroups[i].points[j-1].price,paGroups[i].points[j].time,paGroups[i].points[j].price,ink);
  ObjectSetInteger(0,n,OBJPROP_WIDTH,1);ObjectSetString(0,n,OBJPROP_TOOLTIP,tip+"\n原三推六点五段ZigZag，锚点未改。");paSubmitted++;
 }
}
void PAReceipt(const int shown){
 int f=FileOpen("BookThreePushPA_"+IntegerToString(ChartID())+".tsv",FILE_WRITE|FILE_TXT|FILE_UNICODE);if(f==INVALID_HANDLE)return;
 int count=ArraySize(cached);datetime cutoff=count>0?cached[count-1].time+PeriodSeconds(_Period):0;
 FileWriteString(f,"version\t1.247\nperiod\t"+IntegerToString(PeriodSeconds(_Period))+"\ncutoff\t"+IntegerToString(cutoff)+"\nenabled\t"+IntegerToString(enabled)+"\nstrict\t"+IntegerToString(StrictUserCriteria)+"\nknown\tstart\tend\tcategory\tstate\tevent\treason\n");
 for(int i=0;i<ArraySize(paShapes);i++)FileWriteString(f,IntegerToString(paShapes[i].known)+"\t"+IntegerToString(paShapes[i].start)+"\t"+IntegerToString(paShapes[i].end)+"\t"+IntegerToString(paShapes[i].category)+"\t"+IntegerToString(paShapes[i].state)+"\t"+IntegerToString(paShapes[i].event)+"\t"+paShapes[i].reason+"\n");
 FileWriteString(f,"summary\tgroups="+IntegerToString(ArraySize(paGroups))+"\tqualified="+IntegerToString(paQualified)+"\tshown="+IntegerToString(shown)+"\tbuilds="+IntegerToString(paBuilds)+"\tframes="+IntegerToString(paFrames)+"\tlast_model_us="+IntegerToString(paLastBuildUs)+"\tsubmitted="+IntegerToString(paSubmitted)+"\tfirst_visible="+IntegerToString(ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR))+"\n");FileClose(f);
}
void PAFrame(){
 if(ArraySize(cached)<40)return;
 int first=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR),visible=(int)ChartGetInteger(0,CHART_VISIBLE_BARS);
 datetime left=iTime(_Symbol,_Period,first),right=iTime(_Symbol,_Period,MathMax(0,first-visible+1));
 bool large=!GlobalVariableCheck("BookOverlay."+IntegerToString(ChartID())+".large")||GlobalVariableGet("BookOverlay."+IntegerToString(ChartID())+".large")>0;
 bool small=!GlobalVariableCheck("BookOverlay."+IntegerToString(ChartID())+".small")||GlobalVariableGet("BookOverlay."+IntegerToString(ChartID())+".small")>0;
 color background=(color)ChartGetInteger(0,CHART_COLOR_BACKGROUND);
 string key=IntegerToString(first)+"|"+IntegerToString(visible)+"|"+IntegerToString(large)+IntegerToString(small)+IntegerToString(enabled)+"|"+IntegerToString(background);
 if(!paDirty&&key==paFrameKey)return;
 string ids[],keys[];int selected[];ArrayResize(ids,0);ArrayResize(keys,0);ArrayResize(selected,0);
 for(int i=ArraySize(paGroups)-1;i>=0&&ArraySize(ids)<6;i--){
  OverlayPA o=paShapes[i];if(o.category==0||!enabled||(paGroups[i].parent<0?!large:!small)||o.end<left||o.start>right)continue;
  int at=ArraySize(ids);ArrayResize(ids,at+1);ArrayResize(keys,at+1);ArrayResize(selected,at+1);ids[at]=PAGroupId(paGroups[i]);selected[at]=i;
  keys[at]=IntegerToString(o.start)+"|"+IntegerToString(o.end)+"|"+DoubleToString(o.upper0,10)+"|"+DoubleToString(o.lower0,10)+"|"+DoubleToString(o.upper1,10)+"|"+DoubleToString(o.lower1,10)+"|"+IntegerToString(o.state)+"|"+IntegerToString(o.category)+"|"+IntegerToString(background)+"|"+PATip(i);
  for(int j=0;j<6;j++)keys[at]+="|"+IntegerToString(paGroups[i].points[j].time)+":"+DoubleToString(paGroups[i].points[j].price,10);
 }
 // Touch only changed or departing groups. Native time/price objects follow
 // the chart while dragging; there is no pixel fill frame to trail behind.
 bool changed=false;
 for(int j=0;j<ArraySize(paDrawIds);j++){
  bool keep=false;for(int k=0;k<ArraySize(ids);k++)if(ids[k]==paDrawIds[j]&&keys[k]==paDrawKeys[j])keep=true;
  if(!keep){ObjectsDeleteAll(0,prefix+"g"+paDrawIds[j]);changed=true;}
 }
 for(int k=0;k<ArraySize(ids);k++){
  bool keep=false;for(int j=0;j<ArraySize(paDrawIds);j++)if(ids[k]==paDrawIds[j]&&keys[k]==paDrawKeys[j])keep=true;
  if(!keep){PADrawGroup(selected[k],ids[k],background);changed=true;}
 }
 ArrayResize(paDrawIds,ArraySize(ids));ArrayResize(paDrawKeys,ArraySize(keys));for(int k=0;k<ArraySize(ids);k++){paDrawIds[k]=ids[k];paDrawKeys[k]=keys[k];}
 paFrames++;paFrameKey=key;paDirty=false;
 PAButtons();Status("三推旗楔 1.247 · "+(enabled?"开":"关")+" · "+(StrictUserCriteria?"严格":"Book适配")+" · 轮廓 "+IntegerToString(paQualified)+" · 可见 "+IntegerToString(ArraySize(ids)),"原Book "+IntegerToString(ArraySize(paGroups))+"组；仅已收盘输入改变才重算。背景未验证不作反转/中继确认。\n"+paExclusions);
 PAReceipt(ArraySize(ids));if(changed)ChartRedraw();
}
void PARefreshTimer(){
 if(!enabled)return; // A retained, disabled old instance must not duplicate work.
 ulong now=GetTickCount64();if(!PAQuiet(now,paLastView))return;
 if(PAPollDue(now,paLastPoll)){paLastPoll=now;PALoad();}
 PAFrame();paViewPending=false;
}
#endif
