#ifndef BOOK_THREE_PUSH_PA
#define BOOK_THREE_PUSH_PA
#include "Machine1_UnifiedNativeLegacyPush.mqh"
struct BKNMTFPivot { datetime time; double price; bool high; int index; };
void BKNMTFAppendPivot(BKNMTFPivot &out[],datetime t,double p,bool high,int index){
 int n=ArraySize(out);
 if(n>0&&out[n-1].high==high){
  bool replace=high?(p>=out[n-1].price):(p<=out[n-1].price);
  if(replace){out[n-1].time=t;out[n-1].price=p;out[n-1].index=index;}
  return;
 }
 BKNMTFPivot q;q.time=t;q.price=p;q.high=high;q.index=index;ArrayResize(out,n+1);out[n]=q;
}
int BKNMTFBuild(const MqlRates &rates[],int seconds,datetime cutoff,int depth,BKNMTFPivot &pivots[]){
 ArrayResize(pivots,0);int closed=0;
 for(int i=0;i<ArraySize(rates);i++){
  if(rates[i].time+seconds>cutoff)break;
  if(i>0&&rates[i].time<=rates[i-1].time)return -1;
  if(!MathIsValidNumber(rates[i].high)||!MathIsValidNumber(rates[i].low)||rates[i].high<rates[i].low)return -1;
  closed++;
 }
 if(depth<1||closed<depth*2+1)return 0;
 for(int i=depth;i<closed-depth;i++){
  bool is_high=true,is_low=true;
  for(int j=1;j<=depth;j++){
   // Rightmost plateau pivot; do not create a point on every equal bar.
   if(rates[i].high<rates[i-j].high||rates[i].high<=rates[i+j].high)is_high=false;
   if(rates[i].low>rates[i-j].low||rates[i].low>=rates[i+j].low)is_low=false;
  }
  // An outside bar cannot establish intrabar order from OHLC alone.
  if(is_high&&!is_low)BKNMTFAppendPivot(pivots,rates[i].time,rates[i].high,true,i);
  else if(is_low&&!is_high)BKNMTFAppendPivot(pivots,rates[i].time,rates[i].low,false,i);
 }
 return ArraySize(pivots);
}
// Strict USER variant, not a universal Brooks definition. Same-period context.
struct OverlayPA { int category,geometry,trend,state; datetime start,end,known,event; double upper0,lower0,upper1,lower1; string reason; };
void OverlayPAEvaluate(const MqlRates &r[],const M1ULegacyPush &p,int seconds,datetime cutoff,OverlayPA &o,bool strict){
 o.category=0;o.geometry=0;o.trend=0;o.state=0;o.event=0;o.reason="证据不足";
 if(seconds<=0||ArraySize(p.points)!=6||ArraySize(p.amplitudes)!=3||p.known>cutoff||(p.direction!=1&&p.direction!=-1))return;
 int ix[];ArrayResize(ix,6);
 for(int j=0;j<6;j++){
  ix[j]=-1;for(int k=0;k<ArraySize(r);k++)if(r[k].time==p.points[j].time){ix[j]=k;break;}
  if(ix[j]<0||p.points[j].known>cutoff||p.points[j].known<r[ix[j]].time+seconds||p.known<p.points[j].known||r[ix[j]].time+seconds>cutoff)return;
  if(p.points[j].kind!=1&&p.points[j].kind!=-1)return;
  double bound=p.points[j].kind==1?r[ix[j]].high:r[ix[j]].low;
  if(!MathIsValidNumber(p.points[j].price)||MathAbs(p.points[j].price-bound)>MathMax(1e-7,1e-9*MathAbs(bound))){o.reason="三推锚点未绑定原生高低点";return;}
  if(j>0&&(ix[j]<=ix[j-1]||p.points[j].kind==p.points[j-1].kind))return;
 }
 int a=ix[0],b=ix[5],n=30;
 o.start=p.points[0].time;o.end=p.points[5].time;o.known=p.known;
 if(p.direction!=(p.points[0].kind==-1?1:-1)){o.reason="三推方向与锚点不符";return;}
 if(a<n&&strict){o.reason="前置30根历史不足";return;}
 n=MathMin(n,a);if(n<5){o.reason="前置历史不足5根";return;}
 int regular=0;
 for(int k=a-n;k<=b;k++){
  if(!M1UValidRate(r[k])||(k>0&&r[k].time<=r[k-1].time)){o.reason="原生K线无效或时序错误";return;}
  if(k>a-n&&r[k].time-r[k-1].time==seconds)regular++;
 }
 if(regular<0.80*(b-a+n)){o.reason="周期历史稀疏：不能用日级采样冒充本周期三推";return;}
 double travel=0,scale=0;
 for(int k=a-n;k<a;k++){
  if(!M1UValidRate(r[k]))return;
  scale+=r[k].high-r[k].low;
  if(k>a-n)travel+=MathAbs(r[k].close-r[k-1].close);
 }
 scale/=n;double delta=r[a-1].close-r[a-n].close;
 bool enoughMove=scale>0&&travel>0&&MathAbs(delta)>=(strict?3.0:2.0)*scale;
 if(!enoughMove&&strict){o.reason="前置趋势位移不足：不归旗/楔";return;}
 o.trend=enoughMove?(delta>0?1:-1):0;
 // Original Book depth-3 ZigZag supplies independent pre-pattern diagnostics.
 // Its points never replace this group's six original anchors.
 MqlRates context[];ArrayResize(context,n);for(int j=0;j<n;j++)context[j]=r[a-n+j];
 BKNMTFPivot pre[];BKNMTFBuild(context,seconds,r[a-1].time+seconds,3,pre);
 double lastH=0,prevH=0,lastL=0,prevL=0;int nh=0,nl=0;
 for(int j=ArraySize(pre)-1;j>=0;j--){
  if(pre[j].high&&nh<2){if(nh==0)lastH=pre[j].price;else prevH=pre[j].price;nh++;}
  if(!pre[j].high&&nl<2){if(nl==0)lastL=pre[j].price;else prevL=pre[j].price;nl++;}
 }
 int zz=nh==2&&nl==2?(lastH>prevH&&lastL>prevL?1:lastH<prevH&&lastL<prevL?-1:0):0;
 // Clean HH/HL or LH/LL is a structural alternative to a smooth close path,
 // not an automatic trend assertion from the mere presence of three pushes.
 if(o.trend!=0&&MathAbs(delta)/travel<(strict?0.55:0.35)&&zz!=o.trend){o.trend=0;if(strict){o.reason="前置趋势不清晰：收盘推进与有序摆点均未验证";return;}}
 string zzNote=o.trend!=0&&zz==o.trend?"；前置ZigZag同向旁证":zz==0?"；前置ZigZag趋势未验证":"；前置ZigZag结构存在，趋势背景仍待核验";
 for(int j=0;j<3;j++){
  double measured=p.direction*(p.points[2*j+1].price-p.points[2*j].price);
  if(!MathIsValidNumber(p.amplitudes[j])||measured<=0||MathAbs(measured-p.amplitudes[j])>MathMax(1e-7,1e-9*MathAbs(measured))){o.reason="推动幅度与原生六点不符";return;}
 }
 bool shrinking=p.amplitudes[0]>p.amplitudes[1]&&p.amplitudes[1]>p.amplitudes[2];
 if(strict&&!shrinking){o.reason="未满足用户严格P1>P2>P3";return;}
 if(strict)for(int j=2;j<6;j++)if(p.direction*(p.points[j].price-p.points[j-2].price)<=0){o.reason="高低点未同向有序推进";return;}
 // Fit each rail through first/last same-side pivot; middle pivot must fit.
 int h=p.points[0].kind==1?0:1,l=1-h;
 double hs=(p.points[h+4].price-p.points[h].price)/(ix[h+4]-ix[h]);
 double ls=(p.points[l+4].price-p.points[l].price)/(ix[l+4]-ix[l]);
 o.upper0=p.points[h].price+hs*(a-ix[h]);o.lower0=p.points[l].price+ls*(a-ix[l]);
 o.upper1=o.upper0+hs*(b-a);o.lower1=o.lower0+ls*(b-a);
 double w0=o.upper0-o.lower0,w1=o.upper1-o.lower1;
 if(w0<=0||w1<=0||hs*p.direction<=0||ls*p.direction<=0){o.reason="边线交叉/不同向：排除";return;}
 double tol=MathMax(scale*(strict?0.25:0.50),MathMin(w0,w1)*(strict?0.15:0.35));
 if(MathAbs(p.points[h+2].price-(o.upper0+hs*(ix[h+2]-a)))>tol||MathAbs(p.points[l+2].price-(o.lower0+ls*(ix[l+2]-a)))>tol){o.reason="中间高低点偏离统一边界";return;}
 int inside=0;
 for(int k=a;k<=b;k++){
  double up=o.upper0+hs*(k-a),lo=o.lower0+ls*(k-a);
  if(MathMax(r[k].open,r[k].close)<=up+tol&&MathMin(r[k].open,r[k].close)>=lo-tol)inside++;
 }
 if((double)inside/(b-a+1)<(strict?0.85:0.70)){o.reason="实体不能被清晰双轨包络";return;}
 double widthTolerance=strict?0.15:0.25;
 bool parallel=MathAbs(w1-w0)<=widthTolerance*w0;
 bool converging=w1<(1.0-widthTolerance)*w0;
 if(!parallel&&!converging){o.reason="边界扩张：不归平行旗/收敛楔形";return;}
 o.geometry=parallel?1:2;
 if(!strict&&(o.trend==0||(o.trend==p.direction&&parallel))){
  o.category=4;o.reason="原Book三推几何轮廓；前置趋势/反转中继性质尚未核验";
 }else if(o.trend==p.direction){
  if(!converging){o.reason="同向平行三推：不归反转楔形或中继旗";return;}
  o.category=1;o.reason="同向收敛；末端衰竭仅为候选，不能预知趋势终点";
 }else{o.category=parallel?2:3;o.reason="逆前置趋势回调；中继仍待收盘破线";}
 if(!strict)o.reason+=shrinking?"；原Book适配，三推衰减":"；原Book适配，未满足逐推衰减";
 // Stop at first closed boundary exit; never infer intrabar path or reuse crossed rails.
 int expected=-p.direction;
 for(int k=b+1;k<ArraySize(r);k++){
  if(r[k].time+seconds>cutoff)break;
  if(!M1UValidRate(r[k])||r[k].time<=r[k-1].time){o.state=3;o.reason="跟进K线无效，停止判定";break;}
  double up=o.upper0+hs*(k-a),lo=o.lower0+ls*(k-a);
  if(up<=lo){o.state=3;o.reason="边线交会前未收盘破局";break;}
  int exit=r[k].close>up?1:(r[k].close<lo?-1:0);
  if(exit==0)continue;
  o.event=r[k].time+seconds;
  // A break predating six-point availability is reported, never backdated as confirmation.
  o.state=o.event<o.known?3:(exit==expected?1:2);
  if(o.event<o.known)o.reason+="；越轨早于形态可知，仅作历史结束记录，不倒签确认";
  break;
 }
 o.reason+=zzNote;
}
string OverlayPAName(const OverlayPA &o){
 if(o.category==4)return (o.geometry==1?"三推平行旗形轮廓":"三推收敛楔形轮廓")+"·背景未验证";
 string n=o.category==1?"三推反转楔形":o.category==2?"标准三推旗":o.category==3?"三推楔形旗":"普通三推";
 return n+(o.category==0?"·未归类":o.state==1?"·收盘破线":o.state==2?"·反向失效":o.state==3?"·已终止":"·候选");
}
#endif
