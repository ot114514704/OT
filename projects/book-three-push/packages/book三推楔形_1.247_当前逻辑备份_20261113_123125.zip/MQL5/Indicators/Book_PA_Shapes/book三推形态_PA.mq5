#property version "1.247"
#property indicator_chart_window
#property indicator_plots 0
#include "BookThreePushPA.mqh"
input int HistoryBars=4000;
input bool ShowPAPatterns=true;
input bool StrictUserCriteria=false; // false: adapt to original Book balanced three-push
string prefix="",revision="";bool enabled=true;
MqlRates cached[];
void Status(string message,string detail){
 string n=prefix+"status";ObjectCreate(0,n,OBJ_LABEL,0,0,0);
 ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_LEFT_LOWER);ObjectSetInteger(0,n,OBJPROP_ANCHOR,ANCHOR_LEFT_LOWER);
 ObjectSetInteger(0,n,OBJPROP_XDISTANCE,12);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,50);
 ObjectSetInteger(0,n,OBJPROP_FONTSIZE,9);ObjectSetInteger(0,n,OBJPROP_COLOR,clrOrchid);
 ObjectSetString(0,n,OBJPROP_TEXT,message);ObjectSetString(0,n,OBJPROP_TOOLTIP,detail);
}
void Line(string n,datetime a,double ap,datetime b,double bp,color c){
 ObjectCreate(0,n,OBJ_TREND,0,a,ap,b,bp);ObjectMove(0,n,0,a,ap);ObjectMove(0,n,1,b,bp);
 ObjectSetInteger(0,n,OBJPROP_COLOR,c);ObjectSetInteger(0,n,OBJPROP_WIDTH,2);
 ObjectSetInteger(0,n,OBJPROP_RAY_LEFT,false);ObjectSetInteger(0,n,OBJPROP_RAY_RIGHT,false);ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
}
void Fill(string n,datetime a,double ap,datetime b,double bp,datetime c,double cp,color col){
 ObjectCreate(0,n,OBJ_TRIANGLE,0,a,ap,b,bp,c,cp);
 ObjectSetInteger(0,n,OBJPROP_FILL,true);ObjectSetInteger(0,n,OBJPROP_COLOR,col);
 ObjectSetInteger(0,n,OBJPROP_BACK,true);ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
}
#include "BookPADisplay.mqh"
int OnInit(){
 if(HistoryBars<100||HistoryBars>50000)return INIT_PARAMETERS_INCORRECT;
 prefix="BPA_"+IntegerToString(ChartID())+"_"+IntegerToString(GetTickCount64())+"_";
 enabled=ShowPAPatterns;IndicatorSetString(INDICATOR_SHORTNAME,"book三推旗楔 PA 1.247");
 EventSetMillisecondTimer(100);PAButtons();return INIT_SUCCEEDED;
}
int OnCalculate(const int total,const int prev,const datetime &t[],const double &o[],const double &h[],const double &l[],const double &c[],const long &tv[],const long &v[],const int &s[]){return total;}
void OnTimer(){PARefreshTimer();}
void OnChartEvent(const int id,const long &l,const double &d,const string &s){
 if(id==CHARTEVENT_CHART_CHANGE){paLastView=GetTickCount64();paViewPending=true;return;}
 if(id==CHARTEVENT_OBJECT_CLICK&&s==prefix+"button"){
  enabled=!enabled;paDirty=true;ObjectSetInteger(0,s,OBJPROP_STATE,false);PAFrame();
 }
}
void OnDeinit(const int reason){EventKillTimer();ObjectsDeleteAll(0,prefix);}
