"""Execute the unchanged Book continuous-pivot routine; no strategy backtest."""
import json,re,subprocess
from build_original_overlay import OUT,BOOK_ZIGZAG,function
from audit_original_overlay import adapt

source=(OUT/'book三推试验板.mq5').read_text('utf-8')
reference=BOOK_ZIGZAG.read_text('utf-8-sig')
parts=[]
for name in ['BKNMTFAppendPivot','BKNMTFBuild']:
    original=function(reference,name);assert function(source,name)==original,name
    parts.append(original)
code='\n'.join(parts)
code=re.sub(r'\b(?:void|int)\s+(BKNMTF\w+)\(([^)]*)\)\{',lambda m:'function '+m[1]+'('+','.join(re.search(r'(\w+)\s*(?:\[\])?\s*$',p).group(1) for p in m[2].split(','))+'){',code)
code=adapt(code).replace('BKNMTFPivot q;','let q={};')
js=r'''
const assert=require('assert/strict');const ArraySize=a=>a.length,MathIsValidNumber=Number.isFinite;
const ArrayResize=(a,n)=>{a.length=n;};
'''+code+r'''
const checks=[];const check=(n,t)=>{assert.ok(t,n);checks.push(n);};
const prices=Array.from({length:150},(_,i)=>100+Math.sin(i/4)*8+Math.sin(i/13)*2);
const rows=prices.map((p,i)=>({time:1700000000+3600*i,open:p,high:p+1,low:p-1,close:p}));
let pivots=[];let cutoff=rows.at(-1).time+3600;
check('native price sequence yields continuous pivots',BKNMTFBuild(rows,3600,cutoff,3,pivots)>4);
check('right depth available before cutoff',pivots.every(p=>p.index+3<rows.length));
check('alternating pivots',pivots.every((p,i)=>i===0||p.high!==pivots[i-1].high));
check('bound to native high or low',pivots.every(p=>p.price===rows[p.index][p.high?'high':'low']));
const mirrored=rows.map(r=>({...r,high:220-r.low,low:220-r.high,open:220-r.open,close:220-r.close}));
let mp=[];BKNMTFBuild(mirrored,3600,cutoff,3,mp);
check('mirror symmetry',mp.length===pivots.length&&mp.every((p,i)=>p.time===pivots[i].time&&p.high!==pivots[i].high&&Math.abs(p.price-(220-pivots[i].price))<1e-12));
let future=[];BKNMTFBuild(rows.concat([{time:cutoff,high:9999,low:-9999}]),3600,cutoff,3,future);
check('unclosed and future extremes excluded',JSON.stringify(future)===JSON.stringify(pivots));
const shortened=rows.slice(0,100);let prefix=[],full=[];
BKNMTFBuild(shortened,3600,shortened.at(-1).time+3600,3,prefix);
BKNMTFBuild(rows,3600,shortened.at(-1).time+3600,3,full);
check('historical cutoff prefix causality',JSON.stringify(prefix)===JSON.stringify(full));
let bad=structuredClone(rows);bad[8].time=bad[7].time;
check('invalid chronology rejected',BKNMTFBuild(bad,3600,cutoff,3,[])===-1);
bad=structuredClone(rows);bad[8].high=NaN;
check('invalid prices rejected',BKNMTFBuild(bad,3600,cutoff,3,[])===-1);
check('flat plateau produces no invented pivots',BKNMTFBuild(Array.from({length:15},(_,i)=>({time:i*3600,high:101,low:99})),3600,15*3600,3,[])===0);
const plateau=[1,2,4,4,2,1].map((x,i)=>({time:3600*i,high:x,low:0}));let pp=[];
BKNMTFBuild(plateau,3600,6*3600,1,pp);
check('equal highs choose rightmost pivot',pp.length===1&&pp[0].index===3);
const outside=Array.from({length:7},(_,i)=>({time:i*3600,high:i===3?110:101,low:i===3?90:99}));
check('outside bar order not invented',BKNMTFBuild(outside,3600,7*3600,2,[])===0);
check('insufficient right evidence yields no pivot',BKNMTFBuild(rows.slice(0,6),3600,cutoff,3,[])===0);
process.stdout.write(JSON.stringify(checks));
'''
p=subprocess.run(['node','-e',js],capture_output=True,text=True,encoding='utf-8',timeout=15)
assert p.returncode==0,p.stderr
report=dict(version=json.loads((OUT/'PROVENANCE.json').read_text('utf-8'))['version'],original_book_pivot_functions_byte_identical=True,
            checks=json.loads(p.stdout),scope='Original MQL numerical functions executed on host fixtures; native visual acceptance remains separate.')
(OUT/'MARKET_ZIGZAG_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True))
