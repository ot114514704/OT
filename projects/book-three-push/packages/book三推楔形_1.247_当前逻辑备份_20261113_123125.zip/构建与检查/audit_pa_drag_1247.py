"""MQL cache/tiling guards and captured native object budgets; no latency claim."""
from pathlib import Path
import re,json,subprocess,hashlib
from audit_original_overlay import adapt
from build_original_overlay import function

ROOT=Path(__file__).resolve().parents[2]
DISPLAY=ROOT/'mt5/experiment/pa_shapes/BookPADisplay.mqh'
OUTPUT=Path('D:/盘整研究资料/验收/三推旗楔_PA_1.247')

def main():
    source=DISPLAY.read_text('utf-8')
    names=['PAQuiet','PAPollDue','PASameRows','PATileEnd']
    code='\n'.join(function(source,n) for n in names)
    code=re.sub(r'\b(?:bool|int)\s+(PA\w+)\(([^)]*)\)\{',lambda m:'function '+m[1]+'('+','.join(re.search(r'(\w+)\s*(?:\[\])?\s*$',p).group(1) for p in m[2].split(','))+'){',code)
    code=adapt(code)
    js=r'''
const assert=require('assert/strict');const ArraySize=a=>a.length;
'''+code+r'''
const checks=[];const check=(n,t)=>{assert.ok(t,n);checks.push(n);};
check('initial frame allowed',PAQuiet(100,0));
check('view event throttles expensive work',!PAQuiet(1000,900));
check('work resumes 200ms after final event',PAQuiet(1100,900));
check('poll due on initial load',PAPollDue(100,0));
check('poll not due at 1999ms',!PAPollDue(2999,1000));
check('poll due at 2000ms',PAPollDue(3000,1000));
const r=Array.from({length:400},(_,i)=>({time:1700000000+i*3600,open:100,high:102,low:99,close:101}));
check('same closed inputs reuse model',PASameRows(r,structuredClone(r)));
for(const name of ['time','open','high','low','close']){
 const b=structuredClone(r);b[200][name]+=.01;
 check('same-clock correction to '+name+' rebuilds',!PASameRows(r,b));
}
check('new closed bar rebuilds',!PASameRows(r,r.slice(1)));
check('continuous 400-bar shape has one tile',PATileEnd(r,0,399,3600)===399);
const gaps=structuredClone(r);for(let i=150;i<400;i++)gaps[i].time+=172800;
const spans=[];for(let k=0;k<399;){const end=PATileEnd(gaps,k,399,3600);spans.push([k,end]);k=end;}
check('session gap has two long runs and one bridge',JSON.stringify(spans)===JSON.stringify([[0,149],[149,150],[150,399]]));
check('tile coverage is complete',spans.reduce((s,[a,b])=>s+b-a,0)===399);
check('tile joins share exact native bar',spans.every((p,i)=>i===0||spans[i-1][1]===p[0]));
let work=0;for(let now=1000;now<=1990;now+=10)if(PAQuiet(now,now-10))work++;
check('100 continuous drag events trigger no refresh',work===0);
process.stdout.write(JSON.stringify(checks));
'''
    proc=subprocess.run(['node','-e',js],capture_output=True,text=True,encoding='utf-8',timeout=15)
    assert proc.returncode==0,proc.stderr
    main=(ROOT/'mt5/experiment/pa_shapes/book三推形态_PA.mq5').read_text('utf-8')
    event=function(main,'OnChartEvent')
    assert 'PALoad(' not in event and 'M1ULegacyPushBuild(' not in event
    assert 'M1ULegacyPushBuild(' not in function(source,'PAFrame')
    timer=function(source,'PARefreshTimer');assert timer.index('PAQuiet(')<timer.index('PALoad(')
    assert timer.index('if(!enabled)return;')<timer.index('PALoad(')
    assert 'PAPollDue(' in timer
    assert 'for(int k=a;k<b;k++)' not in source
    assert 'keys[k]==paDrawKeys[j]' in source and 'if(!keep){PADrawGroup(' in source
    wrapper=(ROOT/'mt5/experiment/original_overlay/book三推试验板.mq5').read_text('utf-8')
    wrapper_event=function(wrapper,'OnChartEvent')
    branch=wrapper_event.split('CHARTEVENT_CHART_CHANGE')[1].split('}')[0]
    assert 'OverlayRender(' not in branch and 'OverlayLoad(' not in branch
    assert 'if(nextFrame==overlayRenderKey)return;' in function(wrapper,'OverlayRender')
    original_hashes=json.loads((ROOT/'mt5/experiment/original_overlay/PROVENANCE.json').read_text('utf-8'))['original_files']
    for n,h in original_hashes.items():
        assert hashlib.sha256((ROOT/'mt5/experiment/original_overlay'/n).read_bytes()).hexdigest()==h
    OUTPUT.mkdir(parents=True,exist_ok=True)
    report={'version':'1.247','checks':json.loads(proc.stdout),'source_flow_checks':{'chart_event_does_not_rebuild_model':True,'quiet_period_before_model_read':True,'changed_groups_only':True,'Book_wrapper_chart_events_deferred':True,'original_Book_dependencies_unchanged':True},
            'continuous_400bar_object_budget':{'old':399*4+6,'new':4+6},
            'scope':'Host execution of the actual MQL guards and tiling helper plus source flow checks. Object budget is geometry arithmetic, not measured UI latency. Native drag/fill acceptance remains separate.'}
    (OUTPUT/'drag_cache_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps(report,ensure_ascii=True))

if __name__=='__main__':main()
