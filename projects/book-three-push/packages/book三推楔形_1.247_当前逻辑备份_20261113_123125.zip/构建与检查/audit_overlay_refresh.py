"""Execute closed-input cache guards from the actual generated MQL source."""
import json
import subprocess
from audit_original_overlay import adapt
from build_original_overlay import OUT, function

source = (OUT/'book三推试验板.mq5').read_text('utf-8')
kernel = (OUT/'Machine1_UnifiedNativeKernel.mqh').read_text('utf-8-sig')
code = adapt('\n'.join([
    function(kernel, 'M1UValidRate'),
    function(source, 'OverlaySameClosedRows'),
    function(source, 'OverlayValidClosedRows'),
]))
js = r'''
const assert=require('assert/strict');
const ArraySize=a=>a.length,MathIsValidNumber=Number.isFinite;
const MathMin=Math.min,MathMax=Math.max;
'''+code+r'''
const original=Array.from({length:40},(_,i)=>({time:1700000000+i*3600,open:100,high:103,low:99,close:102}));
let checks=[];
function check(name,truth){assert.ok(truth,name);checks.push(name);}
const clone=x=>structuredClone(x);
check('unchanged closed inputs reuse',OverlaySameClosedRows(original,clone(original)));
for(const field of ['time','open','high','low','close']){
 const corrected=clone(original);corrected[20][field]+=.01;
 check('same final timestamp with corrected '+field+' rebuilds',!OverlaySameClosedRows(original,corrected));
}
const shorter=clone(original).slice(1),longer=clone(original);longer.push({...original[39],time:original[39].time+3600});
check('shorter context rebuilds',!OverlaySameClosedRows(original,shorter));
check('longer context rebuilds',!OverlaySameClosedRows(original,longer));
check('valid closed rows accepted',OverlayValidClosedRows(original,3600));
for(const mutate of [r=>r.high=98,r=>r.low=104,r=>r.open=104,r=>r.close=98,r=>r.high=NaN,r=>r.low=Infinity]){
 const invalid=clone(original);mutate(invalid[20]);
 check('invalid OHLC rejected '+checks.length,!OverlayValidClosedRows(invalid,3600));
}
const duplicate=clone(original);duplicate[20].time=duplicate[19].time;
check('duplicate timestamp rejected',!OverlayValidClosedRows(duplicate,3600));
const reversed=clone(original);[reversed[20],reversed[21]]=[reversed[21],reversed[20]];
check('reversed timestamps rejected',!OverlayValidClosedRows(reversed,3600));
check('insufficient history rejected',!OverlayValidClosedRows(shorter,3600));
check('invalid period rejected',!OverlayValidClosedRows(original,0));
const weekend=clone(original);for(let i=20;i<40;i++)weekend[i].time+=48*3600;
check('session gaps do not change original admission',OverlayValidClosedRows(weekend,3600));
process.stdout.write(JSON.stringify(checks));
'''
result=subprocess.run(['node','-e',js],capture_output=True,text=True,encoding='utf-8',timeout=15)
assert result.returncode==0,result.stderr
load=function(source,'OverlayLoad')
assert load.index('CopyRates(')<load.index('OverlaySameClosedRows(')
assert 'MathMax(1,first-visible-160)' in load
assert 'ArrayResize(overlayInputRows,copied);ArrayCopy(overlayInputRows,rows)' in load
assert 'overlayInputRevision' in load
report=dict(version=json.loads((OUT/'PROVENANCE.json').read_text('utf-8'))['version'],
            checks=json.loads(result.stdout),read_before_reuse=True,forming_bar_excluded=True,
            scope='Host execution of actual MQL input guards plus source control-flow checks; native runtime remains separate.')
(OUT/'REFRESH_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
