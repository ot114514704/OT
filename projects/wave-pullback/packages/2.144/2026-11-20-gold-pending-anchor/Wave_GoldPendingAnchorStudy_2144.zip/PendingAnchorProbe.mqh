// Shadow probe. All bars and raw pivots are restricted to this cutoff.
bool ProbeOwnerPrefix(const MqlRates &bars[],int first,int end,const CSSPoint &point,int window){
 if(point.i-first<window)return false;
 for(int i=point.i-window;i<=end;i++){
  if(i==point.i)continue;
  double extreme=point.side>0?bars[i].high:bars[i].low;
  double advance=point.side*(extreme-point.price);
  if(advance>0||(advance==0&&i<point.i))return false;
 }
 return true;
}
CSSTail ProbeReaction(const MqlRates &bars[],int first,int end,int frame,
                     const CSSPoint &anchor,const WXPConfig &config){
 CSSTail tail={};
 tail.valid=true;tail.side=-anchor.side;tail.a=bars[anchor.i].time;tail.t=tail.a;
 tail.start=anchor.price;tail.tip=anchor.price;tail.pull=anchor.price;
 double noise=0;int samples=0;
 int warm=anchor.i-24>first?anchor.i-24:first;
 for(int k=warm;k<=end;k++){
  if(k>anchor.i)WXPObserve(tail,bars[k],true,noise,frame,config);
  if(tail.phase==WXP_INVALIDATED)break;
  double width=bars[k].high-bars[k].low;
  if(k>first)width=MathMax(width,MathMax(MathAbs(bars[k].high-bars[k-1].close),MathAbs(bars[k].low-bars[k-1].close)));
  samples++;noise+=(width-noise)/MathMin(24,samples);
 }
 return tail;
}
struct ProbeSnapshot { CSSTail rawActive,ownerPrefix,ownerHalf; };
ProbeSnapshot ProbePending(const MqlRates &bars[],const CSSPoint &raw[],int first,int end,int frame,
                          datetime formalOrigin,int window,const WXPConfig &config){
 ProbeSnapshot result={};
 if(formalOrigin<=0)return result;
 datetime cut=bars[end].time+frame;
 for(int i=ArraySize(raw)-1;i>=0;i--){
  CSSPoint anchor=raw[i];
  int age=end-anchor.i;
  if(age>=window||bars[anchor.i].time<=formalOrigin)break;
  if(anchor.known<=0||anchor.known>cut||age<config.minBars)continue;
  CSSTail tail=ProbeReaction(bars,first,end,frame,anchor,config);
  if(tail.phase!=WXP_ACTIVE||tail.acceptedKnown<=0||tail.acceptedKnown>cut||tail.ambiguous||tail.gap)continue;
  if(result.rawActive.a==0)result.rawActive=tail;
  if(!ProbeOwnerPrefix(bars,first,end,anchor,window))continue;
  if(result.ownerPrefix.a==0)result.ownerPrefix=tail;
  if(age>=window/2){result.ownerHalf=tail;break;}
 }
 return result;
}
