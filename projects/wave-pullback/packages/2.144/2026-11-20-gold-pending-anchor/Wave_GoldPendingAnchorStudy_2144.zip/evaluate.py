"""Measure causal lead and unmatched alerts against MT5 XAUUSD H1 replay."""
import argparse
from bisect import bisect_left
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
from statistics import median

from build_replay import PREVIOUS, ROOT


def read(path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def year(stamp):
    return datetime.fromtimestamp(stamp, timezone.utc).year


def formal_key(row):
    return (int(row["anchor"]), Decimal(row["anchor_price"]), -int(row["anchor_side"]),
            int(row["tail_tip_time"]), Decimal(row["tail_tip_price"]))


def probe_key(row, rule):
    return (int(row[rule + "_origin"]), Decimal(row[rule + "_origin_price"]), int(row[rule + "_direction"]),
            int(row[rule + "_peak"]), Decimal(row[rule + "_peak_price"]))


def summarize(alerts, opportunities):
    counts = Counter(event["outcome"] for event in alerts)
    matched = [event for event in alerts if event["outcome"] == "exact_later_formal"]
    eligible = [event for event in opportunities if event["pre_session_bars"] > 0]
    covered = [event for event in eligible if event["alert_first"] is not None]
    without_match = [event for event in alerts if event["outcome"] == "no_exact_formal_within_horizon"]
    evaluated = len(alerts) - counts["censored"]
    return {"alerts": len(alerts), "evaluated_alerts": evaluated, "outcomes": dict(counts),
            "matched_alert_fraction": len(matched) / evaluated if evaluated else None,
            "eligible_delayed_formal_events": len(eligible), "covered_delayed_formal_events": len(covered),
            "opportunity_coverage": len(covered) / len(eligible) if eligible else None,
            "covered_active_median_lead_bars": median(e["lead_bars"] for e in covered) if covered else None,
            "unmatched_diagnostics": dict(Counter(e["unmatched_detail"] for e in without_match)),
            "exact_match_visible_on_previous_close": sum(e["present_on_previous_close"] for e in matched),
            "alerts_redrawn_after_absence": sum(e["visible_runs"] > 1 for e in alerts),
            "alerts_with_revised_trough": sum(e["trough_changes"] > 0 for e in alerts)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--formal", type=Path, default=PREVIOUS / "build/target-gold-extended-after.csv")
    parser.add_argument("--probe", type=Path, default=ROOT / "build/pending-anchor.csv")
    parser.add_argument("--ohlc", type=Path, default=PREVIOUS / "data/XAUUSD_H1_extended_closed.csv")
    args = parser.parse_args()
    policy = json.loads((ROOT / "policy.json").read_text(encoding="utf-8"))
    frame, horizon = policy["frame_seconds"], policy["followup_trading_bars"]
    quotes, formal, probe = map(read, (args.ohlc, args.formal, args.probe))
    closes = [int(row["time"]) + frame for row in quotes]
    indices = {stamp: i for i, stamp in enumerate(closes)}
    assert closes == sorted(set(closes))
    assert len(quotes) - 200 == len(formal) == len(probe)
    assert [int(row["time"]) + frame for row in formal] == closes[200:]

    episodes, by_key, by_origin = {}, defaultdict(list), defaultdict(list)
    for f, p, visible in zip(formal, probe, closes[200:]):
        assert int(p["time"]) + frame == visible
        assert (p["formal_origin"], p["formal_phase"], p["formal_known"]) == (f["anchor"], f["phase"], f["accepted_known"])
        if f["phase"] != "2":
            continue
        key = formal_key(f)
        known = int(f["accepted_known"])
        episode = key, int(f["session"]), known
        if episode in episodes:
            continue
        condition = int(f["accepted_at"]) + frame
        session = int(f["session_known"])
        assert condition in indices and session <= known == visible and condition <= known
        item = {"visible": visible, "session": session, "condition": condition,
                "pre_session_bars": max(0, bisect_left(closes, session) - indices[condition])}
        episodes[episode] = item
        by_key[key].append(item)
        by_origin[key[:3]].append((key, item))

    deltas = [indices[e["visible"]] - indices[e["condition"]] for e in episodes.values()]
    worst_key, worst = max(episodes.items(), key=lambda pair: indices[pair[1]["visible"]] - indices[pair[1]["condition"]])
    report = {"policy": policy, "cutoffs": len(probe), "instrument": "XAUUSD", "period": "H1",
              "closed_bar_confirmation_clock": {"historical_field": "accepted_at is opening time of the qualifying bar",
                  "median_delay_bars": median(deltas), "max_delay_bars": max(deltas), "same_close": deltas.count(0),
                  "conditions_closed_before_anchor_visible": sum(e["pre_session_bars"] > 0 for e in episodes.values()),
                  "worst_case": {"origin": worst_key[0][0], "peak": worst_key[0][3], **worst}},
              "results": {}, "manual_accuracy": None}
    gate = policy["final_gate"]
    ledger = []
    for rule in policy["rules"]:
        tracks = defaultdict(list)
        for p, visible in zip(probe, closes[200:]):
            key = probe_key(p, rule)
            if not key[0]:
                continue
            condition = int(p[rule + "_condition_close"])
            trough = int(p[rule + "_trough"]), Decimal(p[rule + "_trough_price"])
            assert int(p["formal_origin"]) < key[0] < key[3] < trough[0] < visible
            assert key[2] in (-1, 1) and key[2] * (key[4] - key[1]) > 0
            assert 0 < key[2] * (key[4] - trough[1]) < key[2] * (key[4] - key[1])
            assert condition <= visible and condition in indices
            tracks[key].append((visible, trough))

        alerts_by_key, opportunities = {}, []
        for key, track in tracks.items():
            first = track[0][0]
            start = indices[first]
            prior = any(form["visible"] <= first for form in by_key[key])
            match = next((form["visible"] for form in by_key[key] if start < indices[form["visible"]] <= start + horizon), None)
            status = ("already_formal" if prior else "exact_later_formal" if match is not None else
                      "censored" if start + horizon >= len(closes) else "no_exact_formal_within_horizon")
            detail = None
            if status == "no_exact_formal_within_horizon":
                if any(other != key and start < indices[item["visible"]] <= start + horizon
                       for other, item in by_origin[key[:3]]):
                    detail = "same_origin_different_peak"
                elif any(indices[item["visible"]] > start + horizon for item in by_key[key]):
                    detail = "exact_after_horizon"
                else:
                    detail = "no_formal_active_at_same_origin_within_horizon"
            observed = {stamp for stamp, _ in track}
            event = {"rule": rule, "origin": key[0], "origin_price": str(key[1]), "direction": key[2], "peak": key[3],
                     "peak_price": str(key[4]), "first": first, "last": track[-1][0], "outcome": status,
                     "unmatched_detail": detail,
                     "formally_visible": match, "present_on_previous_close": match is not None and closes[indices[match] - 1] in observed,
                     "visible_runs": 1 + sum(indices[b[0]] > indices[a[0]] + 1 for a, b in zip(track, track[1:])),
                     "trough_changes": sum(a[1] != b[1] for a, b in zip(track, track[1:]))}
            alerts_by_key[key] = event
        for episode, item in episodes.items():
            key = episode[0]
            alert = alerts_by_key.get(key)
            is_early = alert and alert["outcome"] == "exact_later_formal" and alert["formally_visible"] == item["visible"]
            first = alert["first"] if is_early else None
            lead = indices[item["visible"]] - indices[first] if first is not None else None
            opportunities.append({**item, "alert_first": first, "lead_bars": lead})
        alerts = list(alerts_by_key.values())
        groups = {"all": (alerts, opportunities)}
        for label, years in (("development", gate["development_years"]), ("check", [gate["check_year"]])):
            groups[label] = ([e for e in alerts if year(e["first"]) in years],
                             [e for e in opportunities if year(e["visible"]) in years])
        scopes = {label: summarize(*events) for label, events in groups.items()}
        worst_alert = alerts_by_key.get(worst_key[0])
        scopes["worst_case_alert_first"] = worst_alert["first"] if worst_alert else None
        scopes["worst_case_lead_bars"] = indices[worst["visible"]] - indices[worst_alert["first"]] if worst_alert else None
        scopes["meets_gate"] = all((scopes[group][field] or 0) >= gate[minimum] for group in ("development", "check")
                                   for field, minimum in (("matched_alert_fraction", "min_matched_alert_fraction"),
                                                          ("opportunity_coverage", "min_opportunity_coverage"),
                                                          ("covered_active_median_lead_bars", "min_median_lead_bars")))
        report["results"][rule] = scopes
        ledger.extend(alerts)

    report["input_sha256"] = {name: sha256(path.read_bytes()).hexdigest() for name, path in
                             (("ohlc", args.ohlc), ("formal", args.formal), ("probe", args.probe))}
    (ROOT / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    with (ROOT / "build/pending-anchor-events.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(ledger[0]))
        writer.writeheader()
        writer.writerows(ledger)
    print(json.dumps({k: v["all"] for k, v in report["results"].items()}, indent=2))


if __name__ == "__main__":
    main()
