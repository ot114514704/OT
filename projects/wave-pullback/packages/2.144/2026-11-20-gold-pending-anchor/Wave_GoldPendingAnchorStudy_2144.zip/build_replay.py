"""Compile the shadow probe with the production-derived 2.144 gold harness."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess


ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "Wave_2.144_Experiment_20261119"
RULES = {"raw_active": "rawActive", "owner_prefix": "ownerPrefix", "owner_prefix_half_elapsed": "ownerHalf"}
FIELDS = ("origin", "origin_price", "direction", "peak", "peak_price", "trough", "trough_price", "condition_close")


def replace_once(text, needle, replacement):
    assert text.count(needle) == 1, needle
    return text.replace(needle, replacement)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--previous", type=Path, default=PREVIOUS)
    args = parser.parse_args()
    previous = args.previous.resolve()
    manifest = json.loads((previous / "build/css-harness-source.json").read_text(encoding="utf-8"))
    for name, expected in (
        ("build/generated_css.hpp", manifest["generated_sha256"]),
        ("src/book_unified_fusion_research/Machine1_FusionCausalSwings.mqh", manifest["production_source_sha256"]),
        ("src/book_unified_fusion_research/WavePullbackSession.mqh", manifest["session_source_sha256"]),
    ):
        assert sha256((previous / name).read_bytes()).hexdigest() == expected, name

    driver = previous / "tests/css_production_replay.cpp"
    source = re.sub(r'#include "(\.\./[^"]+)"', lambda m: '#include "' +
                    (driver.parent / m[1]).resolve().as_posix() + '"', driver.read_text(encoding="utf-8"))
    header = (ROOT / "PendingAnchorProbe.mqh").read_text(encoding="utf-8")
    header = header.replace("const MqlRates &bars[]", "const std::vector<MqlRates> &bars")
    header = header.replace("const CSSPoint &raw[]", "const std::vector<CSSPoint> &raw")
    source = replace_once(source, "struct Snapshot {", header + "\nstruct Snapshot {ProbeSnapshot probes;")
    source = replace_once(source, "config,session,result.tail,result.evidence,noise);\n return result;",
                          "config,session,result.tail,result.evidence,noise);\n"
                          " result.probes=ProbePending(b,raw,first,end,frame,result.tail.a,ExperimentOwnerWindow,config);\n"
                          " return result;")
    begin, end = source.index(' out<<"index,time,'), source.index(' int found=0;')
    columns = ",".join(["time", "formal_origin", "formal_phase", "formal_known"] +
                       [f"{rule}_{field}" for rule in RULES for field in FIELDS])
    source = source[:begin] + ' out<<"' + columns + '\\n";\n' + source[end:]
    begin = source.index("  auto pt=s.evidence.pushTarget")
    end = source.index(' std::printf(', begin)
    members = ",".join("s.probes." + name for name in RULES.values())
    source = source[:begin] + f"""  out<<b[i].time<<','<<s.tail.a<<','<<s.tail.phase<<','<<s.tail.acceptedKnown;
  for(const CSSTail &p:{{{members}}})
   out<<','<<p.a<<','<<p.start<<','<<p.side<<','<<p.t<<','<<p.tip<<','<<p.u<<','<<p.pull<<','<<p.acceptedKnown;
  out<<'\\n';
 }}
""" + source[end:]
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    cpp = build / "pending-anchor.cpp"
    cpp.write_text(source, encoding="utf-8")
    zig = Path(os.environ.get("WAVE_ZIG", ROOT.parent / "Wave_2.117_Experiment_20261118/test-tools/ziglang/zig.exe"))
    subprocess.run([str(zig), "c++", "-std=c++17", "-O2", str(cpp), "-o", str(build / "pending-anchor.exe")], check=True)


if __name__ == "__main__":
    main()
