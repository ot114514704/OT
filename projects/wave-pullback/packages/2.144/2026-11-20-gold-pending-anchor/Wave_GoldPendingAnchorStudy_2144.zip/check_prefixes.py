"""Validate truly truncated MT5 gold inputs against the full probe run."""
import argparse
import json
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

from build_replay import PREVIOUS, ROOT


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ohlc", type=Path, default=PREVIOUS / "data/XAUUSD_H1_extended_closed.csv")
    args = parser.parse_args()
    build = ROOT / "build"
    exe = build / "pending-anchor.exe"
    sample = args.ohlc.read_bytes().splitlines(keepends=True)
    full = (build / "pending-anchor.csv").read_bytes().splitlines(keepends=True)
    assert len(sample) - 200 == len(full)
    lengths = [6000, 12000, 16000]
    with TemporaryDirectory(prefix="wave-gold-probe-") as work:
        source = Path(work) / "prefix.csv"
        target = Path(work) / "trace.csv"
        for length in lengths:
            source.write_bytes(b"".join(sample[:length + 1]))
            subprocess.run([str(exe), str(source), str(target)], check=True)
            assert target.read_bytes().splitlines(keepends=True) == full[:length - 200 + 1], length
    result = {"instrument": "XAUUSD", "period": "H1", "prefix_lengths": lengths, "all_identical": True}
    (build / "prefix-check.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
