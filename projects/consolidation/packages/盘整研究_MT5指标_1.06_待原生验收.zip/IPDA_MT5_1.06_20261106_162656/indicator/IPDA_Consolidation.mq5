#property copyright "Local IPDA consolidation research"
#property version   "1.06"
#property indicator_chart_window
#property indicator_plots 0

// Read-only: no trading, DLL, network or account operations.
input string InpFolder="IPDA_Consolidation";
input int InpFillAlpha=38;
input bool InpShowLabels=true;
input int InpLabelFontSize=8;

struct Shape
  {
   int seconds; string key,kind,label,title,summary,detail; bool active;
   datetime known,until,t[4]; double p[4];
  };
Shape shapes[];
string prefix,revision="",rendered_revision="",expected_revision="",last_beat="",health="模型加载中";
ulong last_change=0;
long heartbeat_written=0;
int tiles=0;
bool drag_active=false,drag_moved=false,dirty=true,previous_mouse_move=false,ready=false,view_pending=true;
string owned[],view_key="";
int drag_x=0,drag_first=0,drag_completed=0,drawn_count=0;
double drag_bar_pixels=1;
ulong last_poll=0;
int label_x[],label_y[],label_w[];
string selected_key="";

bool HeartbeatFresh(const long now_utc,const long written_utc,const ulong now_ticks,const ulong changed_ticks)
  {
   // Both wall clocks refer to this computer, never to the broker's labels.
   return written_utc>0 && now_utc>=written_utc-5 && now_utc-written_utc<=15 &&
      changed_ticks>0 && now_ticks>=changed_ticks && now_ticks-changed_ticks<=15000;
  }

bool ModelPainted(const string expected,const string loaded,const string rendered)
  {return expected!="" && expected==loaded && loaded==rendered;}

bool FeedFresh()
  {return HeartbeatFresh((long)TimeGMT(),heartbeat_written,GetTickCount64(),last_change);}

string DisplayHealth()
  {
   if(!FeedFresh())return "读取服务未更新或时钟不一致，历史保留";
   if(!ModelPainted(expected_revision,revision,rendered_revision))return "模型图形待同步，历史保留";
   return health;
  }

void Own(const string name)
  {
   for(int i=0;i<ArraySize(owned);i++)if(owned[i]==name)return;
   int n=ArraySize(owned);ArrayResize(owned,n+1);owned[n]=name;
  }

void DeleteGeometry()
  {
   for(int i=ArraySize(owned)-1;i>=0;i--)
      if(StringFind(owned[i],prefix+"LINE")==0 || StringFind(owned[i],prefix+"TEXT")==0)
        {ObjectDelete(0,owned[i]);ArrayRemove(owned,i,1);}
  }

string ViewKey()
  {
   return IntegerToString(ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR))+":"+
      IntegerToString(ChartGetInteger(0,CHART_WIDTH_IN_PIXELS))+":"+
      IntegerToString(ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0))+":"+
      IntegerToString(ChartGetInteger(0,CHART_SCALE))+":"+
      DoubleToString(ChartGetDouble(0,CHART_PRICE_MIN,0),_Digits)+":"+
      DoubleToString(ChartGetDouble(0,CHART_PRICE_MAX,0),_Digits);
  }

void FillVisibility(const bool show)
  {
   for(int i=0;i<tiles;i++)ObjectSetInteger(0,prefix+"FILL"+IntegerToString(i),OBJPROP_TIMEFRAMES,show?OBJ_ALL_PERIODS:OBJ_NO_PERIODS);
  }

void LatestButton()
  {
   string name=prefix+"LATEST";
   ObjectCreate(0,name,OBJ_BUTTON,0,0,0);Own(name);
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_RIGHT_UPPER);ObjectSetInteger(0,name,OBJPROP_XDISTANCE,90);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,42);
   ObjectSetInteger(0,name,OBJPROP_XSIZE,78);ObjectSetInteger(0,name,OBJPROP_YSIZE,23);ObjectSetInteger(0,name,OBJPROP_ZORDER,100);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,name,OBJPROP_TEXT,"回到最新");
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,9);ObjectSetInteger(0,name,OBJPROP_COLOR,clrWhite);ObjectSetInteger(0,name,OBJPROP_BGCOLOR,clrDarkSlateGray);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
  }

void Acknowledge()
  {
   int ack=FileOpen(InpFolder+"\\chart_"+IntegerToString(ChartID())+".tsv",FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ,0,CP_UTF8);
   if(ack==INVALID_HANDLE)return;
   FileWriteString(ack,"IPDA_CHART\t1.06\t"+rendered_revision+"\t"+EnumToString(_Period)+"\t"+IntegerToString(drawn_count)+"\t"+last_beat+"\t"+(!FeedFresh()?"stale":DisplayHealth())+
       "\t"+IntegerToString(ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR))+"\t"+IntegerToString(ChartGetInteger(0,CHART_AUTOSCROLL))+"\t"+IntegerToString(ChartGetInteger(0,CHART_MOUSE_SCROLL))+"\t"+IntegerToString(drag_completed));
   FileClose(ack);
  }

string ReadLine(const string name)
  {
   int f=FileOpen(InpFolder+"\\"+name,FILE_READ|FILE_TXT|FILE_ANSI|FILE_SHARE_READ|FILE_SHARE_WRITE,0,CP_UTF8);
   if(f==INVALID_HANDLE)return "";
   string s=FileReadString(f);FileClose(f);return s;
  }

void LoadShapes()
  {
   int f=FileOpen(InpFolder+"\\shapes.tsv",FILE_READ|FILE_TXT|FILE_ANSI|FILE_SHARE_READ|FILE_SHARE_WRITE,0,CP_UTF8);
   if(f==INVALID_HANDLE)return;
   string header=FileReadString(f),h[];
   if(StringSplit(header,'\t',h)<4 || h[0]!="IPDA_SHAPES" || h[1]!="2" || h[3]!=_Symbol || h[2]=="" || h[2]!=expected_revision){FileClose(f);return;}
   if(h[2]==revision){FileClose(f);return;}
   ArrayResize(shapes,0);
   while(!FileIsEnding(f))
     {
      string line=FileReadString(f),a[];
      if(StringSplit(line,'\t',a)<21)continue;
      int n=ArraySize(shapes);ArrayResize(shapes,n+1);
      shapes[n].seconds=(int)StringToInteger(a[0]);shapes[n].key=a[1];shapes[n].kind=a[3];
      shapes[n].known=(datetime)StringToInteger(a[5]);shapes[n].until=(datetime)StringToInteger(a[6]);shapes[n].label=a[9];
      shapes[n].active=(a[10]=="1");
      for(int k=0;k<4;k++){shapes[n].t[k]=(datetime)StringToInteger(a[13+k*2]);shapes[n].p[k]=StringToDouble(a[14+k*2]);}
      shapes[n].title=ArraySize(a)>=24?a[21]:a[9];shapes[n].summary=ArraySize(a)>=24?a[22]:"点击查看首次可知时间";
      shapes[n].detail=ArraySize(a)>=24?a[23]:a[9]+"~n~首次可知 "+TimeToString(shapes[n].known);
      StringReplace(shapes[n].detail,"~n~","\n");
     }
   revision=h[2];FileClose(f);
   dirty=true;
  }

color LineColor(const string kind)
  {
   if(kind=="candidate")return clrLightSalmon;
   if(kind=="geometric")return clrLightSkyBlue;
   if(kind=="structural")return clrGold;
   if(kind=="macro")return clrMediumPurple;
   return clrTurquoise;
  }

void FillPolygon(uint &pixels[],const int width,const int height,const int top,int &xs[],int &ys[],const uint argb)
  {
   int minimum=height-1,maximum=0;
   for(int i=0;i<4;i++){minimum=MathMin(minimum,ys[i]-top);maximum=MathMax(maximum,ys[i]-top);}
   minimum=MathMax(0,minimum);maximum=MathMin(height-1,maximum);
   for(int y=minimum;y<=maximum;y++)
     {
      double cuts[];ArrayResize(cuts,0);double scan=y+top+0.5;
      for(int edge=0;edge<4;edge++)
        {
         int next=(edge+1)%4;
         if((ys[edge]<=scan && ys[next]>scan)||(ys[next]<=scan && ys[edge]>scan))
           {
            int n=ArraySize(cuts);ArrayResize(cuts,n+1);
            cuts[n]=xs[edge]+(scan-ys[edge])*(xs[next]-xs[edge])/(ys[next]-ys[edge]);
           }
        }
      ArraySort(cuts);
      for(int j=0;j+1<ArraySize(cuts);j+=2)
        {
         int left=MathMax(0,(int)MathCeil(cuts[j])),right=MathMin(width-1,(int)MathFloor(cuts[j+1]));
         for(int x=left;x<=right;x++)pixels[y*width+x]=argb;
        }
     }
  }

void StatusLabel(const string value,const color text_color)
  {
   string name=prefix+"STATUS";
   ObjectCreate(0,name,OBJ_LABEL,0,0,0);Own(name);
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_XDISTANCE,12);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,22);
   ObjectSetInteger(0,name,OBJPROP_COLOR,text_color);ObjectSetInteger(0,name,OBJPROP_FONTSIZE,10);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,name,OBJPROP_TEXT,value);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
  }

void PixelText(const string name,const int x,const int y,const string text,const color c,const string tooltip,const int fontsize)
  {
   ObjectCreate(0,name,OBJ_LABEL,0,0,0);Own(name);
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetString(0,name,OBJPROP_FONT,"Microsoft YaHei");ObjectSetInteger(0,name,OBJPROP_FONTSIZE,fontsize);
   ObjectSetInteger(0,name,OBJPROP_COLOR,c);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
   ObjectSetInteger(0,name,OBJPROP_ZORDER,50);ObjectSetString(0,name,OBJPROP_TEXT,text);ObjectSetString(0,name,OBJPROP_TOOLTIP,tooltip);
  }

void ExplainShape(const int index,const int left,const int top,const int width,const int height,const color c)
  {
   int font=MathMax(7,MathMin(12,InpLabelFontSize));
   int w=MathMin(width-10,MathMax(270,MathMin(440,((int)MathMax(StringLen(shapes[index].title),StringLen(shapes[index].summary))+8)*(font+3))));
   int x=MathMax(5,MathMin(width-w-5,left)),y=MathMax(72,MathMin(height-38,top-34));
   int best=y,best_x=x;double distance=DBL_MAX;bool found=false;
   for(int column=-1;column<width/(w+8);column++)for(int candidate=72;candidate<height-38;candidate+=34)
     {
      int candidate_x=column<0?x:5+column*(w+8);if(candidate_x+w>width-5)continue;
      bool free=true;
      for(int j=0;j<ArraySize(label_x);j++)
         if(candidate_x<label_x[j]+label_w[j]+5 && candidate_x+w+5>label_x[j] && candidate<label_y[j]+32 && candidate+32>label_y[j]){free=false;break;}
      double separation=MathAbs(candidate-y)+0.6*MathAbs(candidate_x-x);
      if(free && separation<distance){best=candidate;best_x=candidate_x;distance=separation;found=true;}
     }
   // Keep a label for every visible segment even in a densely zoomed-out view.
   // Zooming in expands space; clicking a label always opens its full evidence.
   if(found){y=best;x=best_x;}
   int n=ArraySize(label_x);ArrayResize(label_x,n+1);ArrayResize(label_y,n+1);ArrayResize(label_w,n+1);label_x[n]=x;label_y[n]=y;label_w[n]=w;
   string tag="#"+IntegerToString(index+1)+" ",base=prefix+"TEXT"+shapes[index].key;
   string bg=base+"BG";ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);Own(bg);
   ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,x-2);ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,y-1);ObjectSetInteger(0,bg,OBJPROP_XSIZE,w);ObjectSetInteger(0,bg,OBJPROP_YSIZE,31);
   ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,C'12,19,26');ObjectSetInteger(0,bg,OBJPROP_BORDER_TYPE,BORDER_FLAT);ObjectSetInteger(0,bg,OBJPROP_COLOR,C'12,19,26');
   ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,bg,OBJPROP_HIDDEN,true);ObjectSetInteger(0,bg,OBJPROP_ZORDER,45);ObjectSetString(0,bg,OBJPROP_TOOLTIP,shapes[index].detail);
   PixelText(base+"A",x,y,tag+shapes[index].title,c,shapes[index].detail,font);
   PixelText(base+"B",x,y+15,shapes[index].summary,clrSilver,shapes[index].detail,font);
   // The same number sits on the actual boundary, so displaced callouts stay traceable.
   string anchor=base+"ANCHOR";ObjectCreate(0,anchor,OBJ_TEXT,0,shapes[index].t[0],shapes[index].p[0]);Own(anchor);
   ObjectSetString(0,anchor,OBJPROP_TEXT,tag);ObjectSetString(0,anchor,OBJPROP_FONT,"Microsoft YaHei");
   ObjectSetInteger(0,anchor,OBJPROP_FONTSIZE,font);ObjectSetInteger(0,anchor,OBJPROP_COLOR,c);
   ObjectSetInteger(0,anchor,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,anchor,OBJPROP_HIDDEN,true);ObjectSetString(0,anchor,OBJPROP_TOOLTIP,shapes[index].detail);
  }

void CloseDetail()
  {
   for(int i=ArraySize(owned)-1;i>=0;i--)if(StringFind(owned[i],prefix+"DETAIL")==0){ObjectDelete(0,owned[i]);ArrayRemove(owned,i,1);}
  }

void ShowDetail()
  {
   CloseDetail();if(selected_key=="")return;
   int index=-1;for(int i=0;i<ArraySize(shapes);i++)if(shapes[i].key==selected_key){index=i;break;}
   if(index<0){selected_key="";return;}
   int width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   int w=MathMax(220,MathMin(660,width-24)),limit=MathMax(24,(w-24)/10);
   string lines[],wrapped[];StringSplit(shapes[index].detail,'\n',lines);
   for(int i=0;i<ArraySize(lines);i++)for(int at=0;at<StringLen(lines[i]);at+=limit)
     {int n=ArraySize(wrapped);ArrayResize(wrapped,n+1);wrapped[n]=StringSubstr(lines[i],at,limit);}
   int count=MathMin(ArraySize(wrapped),MathMax(1,(height-140)/17)),h=count*17+40;
   string bg=prefix+"DETAIL_BG";ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);Own(bg);
   ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,10);ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,74);ObjectSetInteger(0,bg,OBJPROP_XSIZE,w);ObjectSetInteger(0,bg,OBJPROP_YSIZE,h);
   ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,C'15,25,38');ObjectSetInteger(0,bg,OBJPROP_COLOR,clrSlateGray);ObjectSetInteger(0,bg,OBJPROP_ZORDER,80);ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,bg,OBJPROP_HIDDEN,true);
   for(int i=0;i<count;i++)
     {string name=prefix+"DETAIL"+IntegerToString(i);PixelText(name,20,105+i*17,wrapped[i],clrWhite,shapes[index].detail,9);ObjectSetInteger(0,name,OBJPROP_ZORDER,90);}
   PixelText(prefix+"DETAIL_CLOSE",20,81,"每段盘整说明 · 点击此处关闭",clrGold,shapes[index].detail,9);ObjectSetInteger(0,prefix+"DETAIL_CLOSE",OBJPROP_ZORDER,95);
   ChartRedraw();
  }

void Render()
  {
   if(drag_active)return;
   if(_Symbol!="XAUUSD"){StatusLabel("盘整研究：仅支持原生 XAUUSD",clrOrange);return;}
   int seconds=PeriodSeconds();
   if(seconds!=900 && seconds!=3600){StatusLabel("盘整研究：请选择 H1 或 M15",clrOrange);return;}
   int width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   if(width<10 || height<10)return;
   int tile_height=MathMax(1,MathMin(height,3500000/width)),needed=(height+tile_height-1)/tile_height;
   DeleteGeometry();
   ArrayResize(label_x,0);ArrayResize(label_y,0);ArrayResize(label_w,0);
   int drawn=0;
   for(int tile=0;tile<needed;tile++)
     {
      int top=tile*tile_height,h=MathMin(tile_height,height-top);uint pixels[];ArrayResize(pixels,width*h);ArrayInitialize(pixels,0);
      int shown=0;
      for(int i=ArraySize(shapes)-1;i>=0;i--)
        {
         if(shapes[i].seconds!=seconds)continue;
         int xs[4],ys[4];bool valid=true;int lo=0,hi=0,low_y=0,high_y=0;
         for(int k=0;k<4;k++)
           {
            if(!ChartTimePriceToXY(0,0,shapes[i].t[k],shapes[i].p[k],xs[k],ys[k])){valid=false;break;}
            if(k==0){lo=hi=xs[k];low_y=high_y=ys[k];}
            else {lo=MathMin(lo,xs[k]);hi=MathMax(hi,xs[k]);low_y=MathMin(low_y,ys[k]);high_y=MathMax(high_y,ys[k]);}
           }
         if(!valid || hi<0 || lo>width || high_y<0 || low_y>height)continue;
         color line_color=LineColor(shapes[i].kind);shown++;
         FillPolygon(pixels,width,h,top,xs,ys,ColorToARGB(line_color,(uchar)MathMax(0,MathMin(120,InpFillAlpha))));
         if(tile!=0)continue;
         for(int edge=0;edge<4;edge++)
           {
            string name=prefix+"LINE"+shapes[i].key+IntegerToString(edge);int next=(edge+1)%4;
            ObjectCreate(0,name,OBJ_TREND,0,shapes[i].t[edge],shapes[i].p[edge],shapes[i].t[next],shapes[i].p[next]);
            Own(name);
            ObjectSetInteger(0,name,OBJPROP_RAY_RIGHT,false);ObjectSetInteger(0,name,OBJPROP_RAY_LEFT,false);
            ObjectSetInteger(0,name,OBJPROP_COLOR,line_color);ObjectSetInteger(0,name,OBJPROP_WIDTH,shapes[i].active?3:2);ObjectSetInteger(0,name,OBJPROP_STYLE,STYLE_SOLID);
            ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
            ObjectSetString(0,name,OBJPROP_TOOLTIP,shapes[i].detail);
           }
         if(InpShowLabels || shapes[i].kind=="candidate")ExplainShape(i,lo,low_y,width,height,line_color);
        }
      drawn=shown;string resource=prefix+"R"+IntegerToString(tile),bitmap=prefix+"FILL"+IntegerToString(tile);
      if(ResourceCreate(resource,pixels,width,h,0,0,width,COLOR_FORMAT_ARGB_NORMALIZE))
        {
         ObjectCreate(0,bitmap,OBJ_BITMAP_LABEL,0,0,0);Own(bitmap);
         ObjectSetInteger(0,bitmap,OBJPROP_XDISTANCE,0);ObjectSetInteger(0,bitmap,OBJPROP_YDISTANCE,top);
         ObjectSetInteger(0,bitmap,OBJPROP_BACK,true);ObjectSetInteger(0,bitmap,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,bitmap,OBJPROP_HIDDEN,true);
         ObjectSetInteger(0,bitmap,OBJPROP_ZORDER,-100);ObjectSetInteger(0,bitmap,OBJPROP_SELECTED,false);ObjectSetInteger(0,bitmap,OBJPROP_TIMEFRAMES,OBJ_ALL_PERIODS);
         ObjectSetString(0,bitmap,OBJPROP_BMPFILE,"::"+resource);
        }
     }
   for(int tile=needed;tile<tiles;tile++){ObjectDelete(0,prefix+"FILL"+IntegerToString(tile));ResourceFree(prefix+"R"+IntegerToString(tile));}
   tiles=needed;
   drawn_count=drawn;dirty=false;LatestButton();
   ShowDetail();
   ChartRedraw();
   // Loading file data is not a completed redraw, especially during a drag.
   rendered_revision=revision;
   bool current=FeedFresh() && ModelPainted(expected_revision,revision,rendered_revision);
   StatusLabel("盘整研究 1.06 | "+EnumToString(_Period)+" | "+DisplayHealth()+" | "+IntegerToString(drawn)+" 段 · 左键拖动 / 点击说明",current?clrTurquoise:clrOrange);
   view_key=ViewKey();view_pending=false;
  }

int OnInit()
  {
   prefix="IPDA_"+IntegerToString(ChartID())+"_"+IntegerToString((int)(GetMicrosecondCount()%1000000))+"_";
   // Parameter dialogs wait for initialization. Never wait on the chart queue
   // or rasterize in that lifecycle callback; do this on the first timer tick.
   IndicatorSetString(INDICATOR_SHORTNAME,"IPDA Consolidation 1.06 (read-only)");EventSetMillisecondTimer(100);return INIT_SUCCEEDED;
  }
void OnDeinit(const int reason)
  {
   EventKillTimer();
   for(int i=0;i<ArraySize(owned);i++)ObjectDelete(0,owned[i]);
   if(ready){ChartSetInteger(0,CHART_MOUSE_SCROLL,true);ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,previous_mouse_move);}
   for(int i=0;i<tiles;i++)ResourceFree(prefix+"R"+IntegerToString(i));
  }
void OnTimer()
  {
   if(!ready)
     {
      previous_mouse_move=(bool)ChartGetInteger(0,CHART_EVENT_MOUSE_MOVE);
      ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,true);ChartSetInteger(0,CHART_MOUSE_SCROLL,true);ChartSetInteger(0,CHART_KEYBOARD_CONTROL,true);
      ready=true;
     }
   if(view_pending && !drag_active){string current=ViewKey();if(current!=view_key)dirty=true;view_pending=false;}
   if(GetTickCount64()-last_poll<2000){if(dirty && !drag_active)Render();return;}
   last_poll=GetTickCount64();
   string line=ReadLine("heartbeat.tsv"),a[];
   if(StringSplit(line,'\t',a)>=13 && a[0]=="IPDA_LIVE" && a[1]=="1" && StringToInteger(a[2])>0 && StringToInteger(a[12])>0)
     {
      if(a[2]!=last_beat){last_beat=a[2];last_change=GetTickCount64();}
      heartbeat_written=StringToInteger(a[12]);expected_revision=a[3];
      int offset=(_Period==PERIOD_H1?5:8);string availability=a[offset]=="live"?"实时":a[offset]=="analysis_pending"?"新收盘重算中":"当前不可用（"+a[offset]+"）";
      string stamp=StringSubstr(a[offset+2],5,11);StringReplace(stamp,"T"," ");
      string updated=availability+" · "+a[offset+1]+" · "+stamp;
      if(health!=updated)dirty=true;health=updated;
     }
   LoadShapes();
   if(dirty && !drag_active)Render();
   bool current=FeedFresh() && ModelPainted(expected_revision,revision,rendered_revision);
   StatusLabel("盘整研究 1.06 | "+EnumToString(_Period)+" | "+DisplayHealth()+" | "+IntegerToString(drawn_count)+" 段 · 左键拖动 / 点击说明",current?clrTurquoise:clrOrange);
   Acknowledge();
  }
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
  {
   if(id==CHARTEVENT_CHART_CHANGE){view_pending=true;return;}
   if(id==CHARTEVENT_OBJECT_CLICK && sparam==prefix+"DETAIL_CLOSE")
     {selected_key="";CloseDetail();ChartRedraw();return;}
   if(id==CHARTEVENT_OBJECT_CLICK && !drag_moved && (StringFind(sparam,prefix+"TEXT")==0 || StringFind(sparam,prefix+"LINE")==0))
     {
      for(int i=0;i<ArraySize(shapes);i++)if(StringFind(sparam,shapes[i].key)>=0){selected_key=shapes[i].key;ShowDetail();break;}
      if(drag_active)FinishDrag();return;
     }
   if(id==CHARTEVENT_OBJECT_CLICK && sparam==prefix+"LATEST")
     {drag_active=false;ChartSetInteger(0,CHART_MOUSE_SCROLL,true);ChartSetInteger(0,CHART_AUTOSCROLL,true);ChartNavigate(0,CHART_END,0);ObjectSetInteger(0,sparam,OBJPROP_STATE,false);dirty=true;return;}
   if((id==CHARTEVENT_CLICK || id==CHARTEVENT_OBJECT_CLICK) && drag_active)
     {FinishDrag();return;}
   if(id!=CHARTEVENT_MOUSE_MOVE)return;
   bool left=(((uint)StringToInteger(sparam)&1)!=0);int x=(int)lparam,y=(int)dparam;
   int width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   if(left && !drag_active)
     {
      if(x<0 || x>width-65 || y<70 || y>height-25)return;
      drag_active=true;drag_moved=false;drag_x=x;drag_first=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
      int x0=0,x1=0,py=0;double price=SymbolInfoDouble(_Symbol,SYMBOL_BID);
      if(ChartTimePriceToXY(0,0,iTime(_Symbol,_Period,1),price,x0,py) && ChartTimePriceToXY(0,0,iTime(_Symbol,_Period,0),price,x1,py) && x1>x0)drag_bar_pixels=x1-x0;
      else drag_bar_pixels=MathMax(1,(double)(width-65)/MathMax(1,ChartGetInteger(0,CHART_WIDTH_IN_BARS)));
      // Bitmap labels can consume the native drag. Handle the gesture once,
      // hide its hit-test surface and avoid re-rasterizing while held down.
      ChartSetInteger(0,CHART_MOUSE_SCROLL,false);ChartSetInteger(0,CHART_AUTOSCROLL,false);FillVisibility(false);ChartRedraw();return;
     }
   if(left && drag_active)
     {
      if(MathAbs(x-drag_x)<4)return; // A stationary click must not clamp/scroll one bar.
      int target=drag_first+(int)MathRound((x-drag_x)/drag_bar_pixels);
      int minimum=(int)ChartGetInteger(0,CHART_WIDTH_IN_BARS)-1;
      target=MathMax(minimum,MathMin(Bars(_Symbol,_Period)-1,target));
      int current=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
      if(target!=current){ChartNavigate(0,CHART_CURRENT_POS,current-target);drag_moved=true;ChartRedraw();}
      return;
     }
   if(!left && drag_active)
     FinishDrag();
  }
void FinishDrag()
  {
   drag_active=false;if(drag_moved)drag_completed++;
   drag_moved=false; // Do not suppress a later explanation click after a finished drag.
   ChartSetInteger(0,CHART_MOUSE_SCROLL,true);dirty=true;
   // Draw on the next timer tick, outside the input handler.
  }
int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[])
  {return rates_total;}
