$ErrorActionPreference = 'Stop'
$projectPath = Join-Path $PSScriptRoot 'engine'
if (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'installation.json')) {
    $projectPath = (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'installation.json') -Raw | ConvertFrom-Json).project_root
}
$pythonPath = Join-Path $projectPath '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $pythonPath)) {
    & py -3.12 -m venv (Join-Path $projectPath '.venv')
    if ($LASTEXITCODE -ne 0) { throw 'Install Python 3.12 x64, then run Setup.ps1 again.' }
}
& $pythonPath -m pip install -r (Join-Path $projectPath 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency setup failed. The existing terminal has not been changed.' }
Write-Output 'Python dependencies are ready. Run Start.ps1.'
