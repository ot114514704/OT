'use strict';
let state=null, selected=null, busy=false, viewCount=500, showMicro=true;
const shapeMeta={rectangle:{name:'箱体盘整',color:'#64d7d1'},compressed:{name:'极度压缩',color:'#b9a0ff'},tilted:{name:'倾斜盘整',color:'#e7bd73'},converging:{name:'收敛/楔形',color:'#82b9ff'},relay:{name:'中继盘整',color:'#ec99bb'}};
let receivedAt=0,networkDown=false;
const viewEnds={H1:null,M15:null};
const chartViews={};
const enabledShapes=new Set(Object.keys(shapeMeta));
function visibleTags(profile){return (profile?.tags||[]).filter(t=>enabledShapes.has(t))}
function shapeColor(profile){const tags=visibleTags(profile);return shapeMeta[tags.includes('converging')?'converging':tags[0]]?.color||'#66cfd4'}
const geometryNames={triangle:'三角收敛',ascending_triangle:'上升三角形',descending_triangle:'下降三角形',rising_wedge:'上升楔形',falling_wedge:'下降楔形',channel:'倾斜通道',broadening:'外扩连线（非通道）',flat_range:'水平连线（非倾斜通道）',unclassified:'连线形态待验证'};
function shapeText(profile){return visibleTags(profile).map(t=>shapeMeta[t].name).join('＋')||'盘整未归类'}
function matchesShape(profile){return profile?.tags?.length?visibleTags(profile).length>0:enabledShapes.size===5}
function rangePool(chart,kind){return (kind==='range'?chart.consolidations:kind==='geometric'?chart.geometric_ranges:kind==='intraday'?chart.intraday_structures:chart.structural_ranges)||[]}
function isMicro(box){return box?.level!=='macro' && Number(box?.window||0)<18 && !(box?.profile?.tags||[]).includes('converging')}
const $=id=>document.getElementById(id), fmt=x=>typeof x==='number'?x.toFixed(2):'待验证';
const stamp=t=>t?String(t).slice(5,16).replace('T',' '):'—';
function text(tag,value,cls){const e=document.createElement(tag);e.textContent=value;if(cls)e.className=cls;return e}
function draw(period){
 const chart=state.charts[period];if(!chart)return;
 let all=chart.bars.slice();const forming=state.forming?.[period];if(forming&&forming.time>all.at(-1).time)all.push(forming);
 const chosen=selected?.period===period?[...(chart.structural_ranges||[]),...(chart.geometric_ranges||[]),...(chart.intraday_structures||[]),...(chart.macro_ranges||[]),...(chart.consolidations||[])].find(e=>e.id===selected.id):null;
 const count=viewCount===0?all.length:viewCount;let end=all.length;
 if(chosen){const pos=all.findIndex(b=>b.time>=chosen.end_at);if(pos>=0)end=Math.min(all.length,pos+(chosen.level==='macro'?8:25))}
 if(viewEnds[period]){const pos=all.findIndex(b=>b.time>=viewEnds[period]);end=pos<0?all.length:pos+1;end=Math.max(Math.min(count,all.length),end)}
 const bars=all.slice(Math.max(0,end-count),end),canvas=$(period),rect=canvas.getBoundingClientRect(),w=rect.width,h=(period==='H1'?300:360)*Number($('chartSize').value),dpr=devicePixelRatio||1;
 chartViews[period]={all,end,count,barWidth:Math.max(.05,(w-80)/Math.min(count,end))};
 canvas.dataset.height=h;canvas.style.height=h+'px';canvas.width=w*dpr;canvas.height=h*dpr;const g=canvas.getContext('2d');g.scale(dpr,dpr);g.clearRect(0,0,w,h);
 const annotations=[];const pad={l:8,r:72,t:64,b:28},pw=w-pad.r-pad.l,ph=h-pad.t-pad.b;
 let lo=Math.min(...bars.map(b=>b.low)),hi=Math.max(...bars.map(b=>b.high));const margin=Math.max((hi-lo)*.07,1);lo-=margin;hi+=margin;
 const x=i=>pad.l+(i+.5)*pw/bars.length,y=v=>pad.t+(hi-v)/(hi-lo)*ph;
 const idx=t=>{let i=bars.findIndex(b=>b.time>=t);return i<0?bars.length:i};
 const pxTime=t=>{const ts=Date.parse(t),at=all.findIndex(b=>Date.parse(b.time)<=ts&&ts<=Date.parse(b.closed_at));return at<0?null:x(at-(end-bars.length)+(ts-Date.parse(all[at].time))/(Date.parse(all[at].closed_at)-Date.parse(all[at].time)))};
 const slanted=profile=>profile?.tags?.some(t=>t==='converging'||t==='tilted');
 function drawSlanted(profile,candidate=false){
 const geometry=profile?.geometry;if(!geometry?.ready||!geometry?.validated)return false;
 const px=pxTime;
 if([...geometry.frame,...geometry.upper,...geometry.lower].some(p=>px(p.time)===null))return false;
 g.save();g.beginPath();g.rect(pad.l,pad.t,pw,ph);g.clip();g.setLineDash([]);g.lineWidth=1.5;
 g.beginPath();geometry.frame.forEach((p,i)=>{const xx=px(p.time);i?g.lineTo(xx,y(p.price)):g.moveTo(xx,y(p.price))});g.closePath();g.fillStyle=candidate?'#74bde519':'#74bde52b';g.fill();g.stroke();
 for(const line of [geometry.upper,geometry.lower]){g.beginPath();g.moveTo(px(line[0].time),y(line[0].price));g.lineTo(px(line[1].time),y(line[1].price));g.stroke();
 if(geometry.basis!=='frozen_regression_envelope')for(const point of line){const xx=px(point.time);if(xx===null)continue;g.beginPath();g.arc(xx,y(point.price),2.5,0,Math.PI*2);g.fillStyle=g.strokeStyle;g.fill()}}
 g.restore();return true;
 }

 g.font='11px Segoe UI';for(let i=0;i<=5;i++){const yy=pad.t+i*ph/5;g.strokeStyle='#263449';g.beginPath();g.moveTo(pad.l,yy);g.lineTo(w-pad.r,yy);g.stroke();g.fillStyle='#8ba2bf';g.fillText((hi-i*(hi-lo)/5).toFixed(2),w-pad.r+8,yy+4)}
 // Large structures are an independent, longer-window observation. Solid
 // geometry is a visual convention; the candidate label stays explicit.
 const structures=(chart.structural_ranges||[]).filter(b=>b.end_at>=bars[0].time&&b.first_observed_at<=bars.at(-1).closed_at)
   .sort((a,b)=>b.window-a.window);
 const drawn=[];
 for(const box of structures){
 // Time containment alone must not hide a distinct nested box/channel.
 if(!showMicro&&chosen?.id!==box.id&&drawn.some(b=>b.shape===box.shape&&b.observed_from<=box.observed_from&&b.end_at>=box.end_at
    && Math.abs(b.observed_high-box.observed_high)<=.1*Math.min(b.frozen_atr,box.frozen_atr)
    && Math.abs(b.observed_low-box.observed_low)<=.1*Math.min(b.frozen_atr,box.frozen_atr)))continue;
 const left=Math.max(pad.l,x(idx(box.observed_from))-.5*pw/bars.length),right=Math.min(w-pad.r,x(idx(box.end_at)));
 if(right<=left)continue;
 const top=box.observed_high,bottom=box.observed_low;
 g.save();g.beginPath();g.rect(pad.l,pad.t,pw,ph);g.clip();g.setLineDash([]);g.lineWidth=2;
 g.strokeStyle=chosen?.id===box.id?'#ffe19c':'#efb977';g.fillStyle=chosen?.id===box.id?'#efb97738':'#efb97722';g.lineWidth=chosen?.id===box.id?3:2;
 if(box.shape==='tilted')drawSlanted({geometry:box.display_geometry||box.geometry},true);
 else {g.fillRect(left,y(top),right-left,y(bottom)-y(top));g.strokeRect(left,y(top),right-left,y(bottom)-y(top))}
 g.globalAlpha=.6;g.setLineDash([3,4]);const first=x(idx(box.first_observed_at));g.beginPath();g.moveTo(first,y(top));g.lineTo(first,y(bottom));g.stroke();g.restore();
 const target=(chart.reference_targets||[]).find(t=>t.range_id===box.id);
 drawn.push(box);annotations.push({x:left,text:(target?target.title+' · ':'')+'结构候选 · '+box.window+'棒 · '+(box.shape==='tilted'?'倾斜通道':'宽幅箱体')+' · '+(box.active?'观察中':'已离开')+(box.gaps.length?' · 含时段间隔':''),color:'#efb977',priority:target?0:10});
 }
 const geometrySeen=new Set();
 for(const box of (chart.geometric_ranges||[]).slice().sort((a,b)=>b.window-a.window)){
 if(box.end_at<bars[0].time||box.first_observed_at>bars.at(-1).closed_at)continue;
 const key=JSON.stringify([box.geometry.upper,box.geometry.lower]);if(geometrySeen.has(key)&&chosen?.id!==box.id)continue;geometrySeen.add(key);
 g.save();g.strokeStyle=chosen?.id===box.id?'#ffe19c':'#9bbdff';g.setLineDash([]);const plotted=drawSlanted({geometry:box.geometry},true);g.restore();if(!plotted)continue;
 const target=(chart.reference_targets||[]).find(t=>t.range_id===box.id);
 annotations.push({x:Math.max(pad.l,x(idx(box.observed_from))),text:(target?target.title+' · ':'')+'长尺度'+(geometryNames[box.geometry.subtype]||'收敛')+' · 形态候选 · '+box.status,color:'#9bbdff',priority:chosen?.id===box.id?-1:target?0:2});
 }
 if(period==='H1')for(const box of chart.intraday_structures||[]){
 if(box.end_at<bars[0].time||box.first_observed_at>bars.at(-1).closed_at)continue;
 const left=pxTime(box.observed_from),right=pxTime(box.end_at);if(left===null||right===null||right<=left)continue;
 const target=(chart.reference_targets||[]).find(t=>t.range_id===box.id),color=chosen?.id===box.id?'#ffe19c':'#72cfc5';
 g.save();g.beginPath();g.rect(pad.l,pad.t,pw,ph);g.clip();g.strokeStyle=color;g.fillStyle='#53cdd523';g.lineWidth=2;g.setLineDash([]);
 if(box.shape==='tilted'||box.shape==='converging')drawSlanted({geometry:box.display_geometry||box.geometry},true);
 else {g.fillRect(left,y(box.projection_high),right-left,y(box.projection_low)-y(box.projection_high));g.strokeRect(left,y(box.projection_high),right-left,y(box.projection_low)-y(box.projection_high))}
 g.restore();annotations.push({x:Math.max(pad.l,left),text:(target?target.title+' · ':'')+'M15内层'+(box.shape==='rectangle'?'箱体':geometryNames[box.geometry?.subtype]||'斜线待证')+' · '+(box.source_confirmed?'来源平衡已确认':'来源候选')+' · '+box.status+' · 非H1确认',color,priority:chosen?.id===box.id?-1:target?0:8});
 }
 // Outer balance is independently confirmed; formation extent is retrospective geometry.
 for(const box of chart.macro_ranges||[]){
 if(box.end_at<bars[0].time||box.known_at>bars.at(-1).closed_at)continue;
 const left=Math.max(pad.l,x(idx(box.observed_from))-.5*pw/bars.length),right=Math.min(w-pad.r,x(idx(box.end_at)));
 if(right<=left)continue;
 g.save();g.beginPath();g.rect(pad.l,pad.t,pw,ph);g.clip();g.setLineDash([]);g.lineWidth=2;g.strokeStyle='#b5a1f0';g.fillStyle='#a899e525';
 g.fillRect(left,y(box.liquidity_high),right-left,y(box.liquidity_low)-y(box.liquidity_high));g.strokeRect(left,y(box.liquidity_high),right-left,y(box.liquidity_low)-y(box.liquidity_high));
 g.setLineDash([5,5]);g.globalAlpha=.6;
 for(const v of [box.low,box.high]){g.beginPath();g.moveTo(left,y(v));g.lineTo(right,y(v));g.stroke()}
 const known=x(idx(box.known_at));g.beginPath();g.moveTo(known,y(box.liquidity_high));g.lineTo(known,y(box.liquidity_low));g.stroke();g.restore();
 annotations.push({x:left,text:'外层实体平衡 · '+box.window+'棒 · '+(box.status.includes('突破')?'已突破':box.status.includes('中止')?'已中止':box.breakout_streak?'越界待跟进':'有效')+' · 首次确认 '+stamp(box.known_at),color:'#b5a1f0'});
 }
 for(const box of chart.consolidations||[]){
 if(!showMicro&&isMicro(box)&&chosen?.id!==box.id)continue;
 if(!matchesShape(box.profile))continue;
 if(box.end_at<bars[0].time||box.known_at>bars.at(-1).closed_at)continue;
 const left=Math.max(pad.l,x(idx(box.observed_from))-.5*pw/bars.length),right=Math.min(w-pad.r,x(idx(box.end_at)));
 if(right<=left)continue;g.save();g.beginPath();g.rect(pad.l,pad.t,pw,ph);g.clip();
 g.strokeStyle=shapeColor(box.profile);g.setLineDash([]);
 if(slanted(box.profile))drawSlanted(box.profile);
 else {g.fillStyle=chosen?.id===box.id?'#53cdd53b':'#53cdd523';g.fillRect(left,y(box.high),right-left,y(box.low)-y(box.high));g.strokeRect(left,y(box.high),right-left,y(box.low)-y(box.high))}
 g.setLineDash([5,5]);g.globalAlpha=.55;const mid=(box.high+box.low)/2;
 g.beginPath();g.moveTo(left,y(mid));g.lineTo(right,y(mid));g.stroke();g.globalAlpha=1;
 g.setLineDash([2,4]);
 for(const v of [box.liquidity_low,box.liquidity_high]){g.beginPath();g.moveTo(left,y(v));g.lineTo(right,y(v));g.stroke()}
 const firstKnown=x(idx(box.known_at));g.setLineDash([3,4]);g.globalAlpha=.6;g.beginPath();g.moveTo(firstKnown,y(box.liquidity_high));g.lineTo(firstKnown,y(box.liquidity_low));g.stroke();g.globalAlpha=1;
 g.setLineDash([]);g.restore();
 const terminal=box.status.includes('突破条件触发')||box.status.includes('中止');
 const target=(chart.reference_targets||[]).find(t=>t.range_id===box.id);
 annotations.push({x:left,text:(target?target.title+' · ':'')+shapeText(box.profile)+(box.profile.geometry?.ready&&slanted(box.profile)?'（'+geometryNames[box.profile.geometry.subtype]+'）':'')+' · '+(terminal?'已结束':box.breakout_streak?'越界待确认':'平衡已确认')+' · 首次确认 '+stamp(box.known_at),color:shapeColor(box.profile),priority:chosen?.id===box.id?-1:target?0:10});
 }
 const phase=chart.phase_rows?.at(-1),evidence=phase?.consolidation_evidence;
 const candidate=chart.current_candidate;
 if(candidate&&matchesShape(candidate.profile)&&candidate.end_at>=bars[0].time&&candidate.known_at<=bars.at(-1).closed_at){
 const left=Math.max(pad.l,pxTime(candidate.observed_from)??pad.l),right=Math.min(w-pad.r,pxTime(candidate.end_at)??w-pad.r);
 g.save();g.beginPath();g.rect(pad.l,pad.t,pw,ph);g.clip();g.strokeStyle='#ed9793';g.lineWidth=3;g.setLineDash([]);
 const plotted=slanted(candidate.profile)?drawSlanted(candidate.profile,true):right>left;
 if(!slanted(candidate.profile)&&plotted){g.fillStyle='#ed97931c';g.fillRect(left,y(candidate.high),right-left,y(candidate.low)-y(candidate.high));g.strokeRect(left,y(candidate.high),right-left,y(candidate.low)-y(candidate.high))}g.restore();
 if(plotted)annotations.push({x:left,text:'正在形成 · '+(candidate.candidate_basis==='swing_balance'?'摆动盘整':shapeText(candidate.profile))+' · 候选未确认',color:'#ed9793',priority:-2});
 }
 const currentReport=state.current_consolidation?.[period],outer=currentReport?.macro_context;
 let currentText=evidence?.range?'局部：'+((evidence.range.profile?.tags||[]).map(t=>shapeMeta[t].name).join('＋')||'盘整未归类')+' · '+evidence.range.status+(matchesShape(evidence.range.profile)?'':'（已被筛选隐藏）'):candidate?'局部：'+shapeText(candidate.profile)+' · 候选未确认':'局部：'+(currentReport?.label||'证据不足');
 if(outer?.verdict==='confirmed')currentText+='；外层：已确认盘整 · '+outer.range.status;
 const ongoingGeometry=(chart.geometric_current||[]).length+(chart.structural_current||[]).length;
 if(ongoingGeometry)currentText+='；另有 '+ongoingGeometry+' 个正在观察的形态候选';
 $('shapeCurrent'+period).textContent=currentText+' · 已收盘依据截至 '+stamp(chart.closed_end);
 if(chosen?.level==='macro')$('shapeCurrent'+period).textContent='所选大盘整：'+chosen.status+' · 首次确认 '+stamp(chosen.known_at)+' · 内部小框单独保留';
 if(selected?.period===period&&['structural','geometric','intraday'].includes(selected.kind)&&chosen)$('shapeCurrent'+period).textContent=(selected.kind==='intraday'?'M15内层投影（非H1确认）：':'所选结构候选：')+chosen.status+' · 观察范围 '+fmt(chosen.projection_low??chosen.observed_low)+'—'+fmt(chosen.projection_high??chosen.observed_high);
 const asof=bars.at(-1).forming?bars.at(-2)?.closed_at:bars.at(-1).closed_at;
 const swing=asof?(chart.swing_rows||[]).filter(r=>r.known_at<=asof).at(-1)?.candidate:null;
 const established=asof&&[...(chart.consolidations||[]),...(chart.macro_ranges||[])].some(b=>b.known_at<=asof&&b.end_at>=asof);
 if(swing&&!established&&!(candidate?.candidate_basis==='swing_balance'&&candidate.known_at===swing.known_at)){
 const left=Math.max(pad.l,x(idx(swing.observed_from))-.5*pw/bars.length),right=Math.min(w-pad.r,x(idx(swing.known_at)));
 if(right>left){g.save();g.beginPath();g.rect(pad.l,pad.t,pw,ph);g.clip();g.strokeStyle='#ed9793';g.fillStyle='#ed97931c';g.lineWidth=1.5;g.setLineDash([]);g.fillRect(left,y(swing.high),right-left,y(swing.low)-y(swing.high));g.strokeRect(left,y(swing.high),right-left,y(swing.low)-y(swing.high));g.restore();annotations.push({x:left,text:'摆动盘整候选 · '+swing.metrics.pivot_count+'个已确认拐点 · 尚未确认平衡',color:'#ed9793'})}
 }
 for(let i=0;i<bars.length;i++){const b=bars[i],xx=x(i);g.strokeStyle=g.fillStyle=b.close>=b.open?'#58c6ad':'#e18499';g.globalAlpha=b.forming?.55:1;g.beginPath();g.moveTo(xx,y(b.high));g.lineTo(xx,y(b.low));g.stroke();g.fillRect(xx-Math.max(1,pw/bars.length*.28),y(Math.max(b.open,b.close)),Math.max(1,pw/bars.length*.56),Math.max(1,Math.abs(y(b.open)-y(b.close))))}g.globalAlpha=1;
 const lanes=[-Infinity,-Infinity,-Infinity];g.font='11px Segoe UI';
 for(const a of annotations.sort((a,b)=>(a.priority??10)-(b.priority??10))){let label=a.text;
 while(label.length>1&&g.measureText(label+'…').width+12>pw)label=label.slice(0,-1);
 if(label!==a.text)label+='…';
 const width=Math.min(pw,g.measureText(label).width+12),left=Math.max(pad.l,Math.min(a.x,w-pad.r-width));
 const lane=lanes.findIndex(end=>end<left-5);if(lane<0)continue;const top=5+lane*18;
 g.fillStyle='#101c2df2';g.fillRect(left,top,width,16);g.strokeStyle=a.color;g.strokeRect(left,top,width,16);g.fillStyle=a.color;g.fillText(label,left+6,top+12);lanes[lane]=left+width;
 }
 const ticks=Math.min(6,Math.max(1,Math.floor(pw/120)));
 g.fillStyle='#91a5bd';for(let i=0;i<bars.length;i+=Math.max(1,Math.ceil(bars.length/ticks)))g.fillText(stamp(bars[i].time),x(i),h-6);
 $('caption'+period).textContent=`${chosen?(['structural','geometric'].includes(selected.kind)?'所选结构候选':chosen.level==='macro'?'所选大盘整':'所选局部盘整'):viewEnds[period]?'历史浏览':'最新视图'} · ${stamp(bars[0].time)} → ${stamp(bars.at(-1).time)} · ${bars.length} 根可见 · 已加载历史 ${stamp(all[0].time)} → ${stamp(chart.closed_end)} · 确认识别截至 ${stamp(chart.closed_end)} · 最新末柱待下一根确认`;
}
function focusStructure(period,box,kind='structural'){
 selected={period,id:box.id,kind};viewEnds[period]=null;
 const bars=state.charts[period].bars;
 const span=bars.filter(b=>b.time>=box.observed_from&&b.time<=box.end_at).length;
 viewCount=Math.min(700,Math.max(kind==='intraday'?30:80,span+(kind==='intraday'?20:40)));
 const select=$('range');let option=select.querySelector('[data-zoom]');if(!option){option=document.createElement('option');option.dataset.zoom='true';select.append(option)}
 option.value=String(viewCount);option.textContent='定位 '+viewCount+' 根';select.value=String(viewCount);
 $(period).parentElement.querySelector('.phase-scores').open=true;render();$(period).scrollIntoView({block:'center',behavior:'smooth'});
}
function focusReference(period,review){
 const bars=state.charts[period].bars,first=bars.findIndex(b=>b.time===review.first_bar_open_at),last=bars.findIndex(b=>b.time===review.last_bar_open_at);
 if(first<0||last<first)return;
 selected=null;viewCount=Math.min(700,Math.max(80,last-first+40));viewEnds[period]=bars[Math.min(bars.length-1,last+20)].time;
 const select=$('range');let option=select.querySelector('[data-zoom]');if(!option){option=document.createElement('option');option.dataset.zoom='true';select.append(option)}
 option.value=String(viewCount);option.textContent='参考 '+viewCount+' 根';select.value=String(viewCount);
 render();$(period).scrollIntoView({block:'center',behavior:'smooth'});
}
function renderReferenceTargets(){
 const root=$('referenceTargets');if(!root)return;
 root.replaceChildren();
 const targets=Object.values(state.charts).flatMap(c=>c.reference_targets||[]);
 for(const t of targets){const card=text('article','','reference-target');
 card.append(text('strong',t.title),text('p',t.period+' · '+(t.matched?t.range_kind==='intraday'?'已定位M15内层，非H1确认':t.evidence_confirmed?'已定位实体平衡证据':'已定位结构候选':'仍待补全')));
 card.append(text('p',`图片参考范围 ${fmt(t.reference_low)}—${fmt(t.reference_high)}`,'caption'));
 if(t.matched){card.append(text('p',`原生边界 ${fmt(t.actual_low)}—${fmt(t.actual_high)} · ${stamp(t.observed_from)} → ${stamp(t.end_at)}`,'caption'));
 const button=text('button','定位这段盘整');button.onclick=()=>{const box=rangePool(state.charts[t.period],t.range_kind).find(b=>b.id===t.range_id);if(box)focusStructure(t.period,box,t.range_kind)};card.append(button)}
 else{const review=state.charts.M15.reference_reviews?.find(r=>r.image_id===t.source_image&&r.native_sequence_currently_verified);if(review){const button=text('button','查看待补位置');button.onclick=()=>focusReference('M15',review);card.append(button)}}
 card.append(text('p',t.reason,'caption'));root.append(card)}
}
function renderReferenceReviews(){
 const root=$('imageReferences');if(!root)return;
 const names={sequence_correspondence:'价格序列已有对应，原生片段未变化',pending:'尚待逐框标定',ambiguous:'价格序列对应不唯一',history_unavailable:'对应历史已不在当前样本',source_changed:'原生片段变化，需重核'};
 const figures=root.querySelectorAll('figure');
 for(const r of state.charts.M15.reference_reviews||[]){const figure=figures[r.image_id-1];if(!figure)continue;
 let panel=figure.querySelector('.reference-review');if(!panel){panel=text('div','','reference-review');figure.querySelector('figcaption').append(panel)}panel.replaceChildren();
 panel.append(text('p',names[r.status]||r.status,'caption'),text('p',r.reason,'caption'));
 if(r.native_sequence_currently_verified){panel.append(text('p',`原生序列 ${stamp(r.first_bar_open_at)} → ${stamp(r.last_bar_open_at)}；${r.extracted_body_count} 个可提取实体。历史时区、人工框起止及完整OHLC仍待核验。`,'caption'));
 const button=text('button','查看对应行情');button.onclick=()=>focusReference('M15',r);panel.append(button)}
 const targets=Object.values(state.charts).flatMap(c=>c.reference_targets||[]).filter(t=>t.source_image===r.image_id);
 for(const t of targets)panel.append(text('p',t.title+'：'+(t.matched?'已有独立模型证据可定位':'仍待补全')+'。','caption'));
 }
}
const phaseNames={consolidation:'盘整'};
const eligibilityNames={local_conditions_met:'局部条件满足',incomplete:'条件不完整',reference_missing:'参考缺失',contradicted:'结构矛盾',warmup:'样本不足',range_ended:'区间已结束',candidate:'盘整观察候选',interrupted:'盘整已中断',end_evidence_observed:'结束证据已观察'};
function renderPhaseScores(period){
 const c=state.charts[period],root=$('scores'+period);root.replaceChildren();
 if(selected?.period===period&&selected.kind==='intraday'){
 const b=rangePool(c,'intraday').find(b=>b.id===selected.id);if(!b)return;
 root.append(text('h3','M15强震荡内层 · 投影到H1'),text('p',`首次可知 ${stamp(b.first_observed_at)} · ${b.status} · ${fmt(b.projection_low)}—${fmt(b.projection_high)}`),text('p','小框在H1可能只有几根K线，形成证据来自原生M15已收盘数据。此投影不改变H1判定、评分或事件时刻。','caption'));return;
 }
 if(selected?.period===period&&selected.kind==='geometric'){
 const b=rangePool(c,'geometric').find(b=>b.id===selected.id);if(!b)return;const g=b.geometry,o=b.metrics.oscillation;
 root.append(text('h3','长尺度'+geometryNames[g.subtype]+' · 形态候选'),text('p',`首次观察 ${stamp(b.first_observed_at)} · ${b.status}`),text('p',`共同覆盖 ${g.validation.overlap_bars} 根 · 收盘覆盖 ${Math.round(g.validation.close_coverage*100)}% · 完成强摆动 ${o.completed_legs} 腿，单腿门槛 ${fmt(o.threshold)}`));
 for(const [side,points] of [['上沿',g.upper],['下沿',g.lower]])for(const p of points)root.append(text('p',`${side}锚点 ${stamp(p.time)} · ${fmt(p.price)} · 最早可知 ${stamp(p.known_at)}`,'caption'));
 root.append(text('p','锚点、形成条件和幅度门槛首次观察后冻结；候选不计入100分，也不充当IPDA实体平衡确认。只绘制锚点及共同覆盖区，不外推未来。','caption'));return;
 }
 if(selected?.period===period&&selected.kind==='structural'){
 const b=(c.structural_ranges||[]).find(b=>b.id===selected.id);if(!b)return;
 root.append(text('h3',`${b.window}棒 · ${b.shape==='tilted'?'倾斜通道':'宽幅箱体'}结构候选`),
 text('p',`形成窗口 ${stamp(b.observed_from)} · 首次观察 ${stamp(b.first_observed_at)} · ${b.status}`),
 text('p',`冻结观察框 ${fmt(b.observed_low)}—${fmt(b.observed_high)} · 最新退出边缘 ${fmt(b.last_lower)}—${fmt(b.last_upper)} · 双边测试 ${b.metrics.upper_visits}/${b.metrics.lower_visits} 次 · 中部往返 ${b.metrics.crossings} 次`),
 text('p','长窗口价格结构尚未完成IPDA实体平衡确认，不增加符合度分数。轨道在首次观察时冻结，形态不预测方向。','missing'));
 const names={two_sided:'双侧独立测试',crossings:'中部往返',balanced:'低方向效率',structural_width:'宽度受控',bounded_drift:'漂移受控',no_dominant_bar:'无主导单根实体',last_inside:'末次收盘在观察轨道内',strong_oscillation:'强双向震荡精选'};
 for(const [k,v] of Object.entries(b.checks))root.append(text('p',`${names[k]||k}：${v?'满足':'未满足'}`,'caption'));
 root.append(text('p','尚缺：'+b.missing.join('、'),'missing'));
 if(b.gaps.length)root.append(text('p',`包含 ${b.gaps.length} 处原始数据间隔，未补造其间价格；间隔后的外收重新计数。`,'caption'));
 for(const test of b.metrics.edge_tests||[])root.append(text('p',`${test.side==='upper'?'上沿':'下沿'}独立测试 · K线 ${stamp(test.bar_open_at)} · 收盘可知 ${stamp(test.known_at)}`,'caption'));
 if(b.metrics.oscillation)root.append(text('p',`完成强摆动 ${b.metrics.oscillation.completed_legs} 腿 · 单腿门槛 ${fmt(b.metrics.oscillation.threshold)}；${b.shape==='tilted'?'按首次冻结轨道去除整体斜率后检查双向折返':'按已收盘价格检查双向折返'}`,'caption'));
 return;
 }
 if(selected?.period===period&&selected.kind==='macro'){
 const b=c.macro_ranges.find(b=>b.id===selected.id);if(!b)return;
 root.append(text('h3','大盘整 · 外层平衡区'),text('p',`形成窗口 ${stamp(b.observed_from)} · 首次确认 ${stamp(b.known_at)} · 最后观察 ${stamp(b.observed_at)}`),text('p',`${b.status} · 外框 ${fmt(b.liquidity_low)}—${fmt(b.liquidity_high)} · 实体 ${fmt(b.low)}—${fmt(b.high)}`));
 root.append(text('p',`形成时 ${b.confirmation_score.score}/100 · 当前 ${b.score.score}/100；形成条件冻结，退出状态另列`,'caption'));
 const table=document.createElement('table');for(const part of b.score.components){const tr=document.createElement('tr');tr.append(text('td',part.name),text('td',`${part.points}/${part.weight} · ${part.status==='met'?'满足':part.status==='unknown'?'缺失':'未满足'}`,part.status==='met'?'pass':'missing'));table.append(tr)}root.append(table);
 root.append(text('p','大盘整独立于内部小框。外框为首次确认时的影线边缘；虚线为冻结实体边界和首次确认位置。形成窗口可回看，不能据此声称窗口起点已提前确认。缺口中止外层，突破后不回填合并。','caption'));return;
 }
 const episode=selected?.period===period?(c.consolidations||[]).find(e=>e.id===selected.id):null;
 if(selected?.period===period&&selected.kind==='range'&&!episode){root.append(text('p','所选区间已不在当前返回的历史中；请重新选择可见盘整。','missing'));return}
 // Each archived range carries its own final observed score and frozen facts.
 // The recent per-bar cache is not the history limit and must not substitute
 // another range's row when an old episode is selected.
 const rows=c.phase_rows||[],r=episode?{known_at:episode.observed_at,fit_scores:{by_phase:{consolidation:episode.score}}}:rows.at(-1);
 if(!r){root.append(text('p','评分模块加载中；需要服务完成重算。'));return}
 if(!r.fit_scores?.by_phase?.consolidation){root.append(text('p','所选时刻缺少评分记录；不使用其他时段的评分替代。','missing'));return}
 root.append(text('p',`${stamp(r.known_at)} · ${episode?'所选盘整时刻':'最新已收盘K线'}`));
 const key='consolidation',score=r.fit_scores.by_phase[key];
 root.append(text('p',`${phaseNames[key]}资格：${eligibilityNames[score.eligibility]||score.eligibility} · 未知权重 ${score.unknown_weight}/100`,'missing'));
 if(score.checks_basis==='first_confirmation')root.append(text('p',`形成依据冻结于 ${stamp(score.checks_known_at)}；${score.current_range_valid?'当前有效状态另由收盘跟进判断':'区间已结束，保留形成依据不代表当前仍在盘整'}`,'caption'));
 const table=document.createElement('table');for(const part of score.components){const tr=document.createElement('tr');tr.append(text('td',part.name),text('td',`${part.points}/${part.weight} · ${part.status==='met'?'满足':part.status==='partial'?'部分':part.status==='unknown'?'缺失':part.status==='blocked'?'前提阻断':'未满足'}`,part.status==='met'?'pass':'missing'));table.append(tr)}root.append(table);

 if(key==='consolidation'){const e=r.consolidation_evidence||{},b=episode||e.range||e.ended;
 if(b)root.append(text('p',`${b.status} · 实体 ${fmt(b.low)}—${fmt(b.high)} · 流动性边缘 ${fmt(b.liquidity_low)}—${fmt(b.liquidity_high)} · 首次确认 ${stamp(b.known_at)} · Brooks ${(episode?b.brooks_confirmed:e.brooks_confirmed)?'旁证同意':'未同意'}`));
 if(episode)root.append(text('p',`形成时 ${episode.confirmation_score?.score??'待验证'}/100 · 最后观察 ${score.score}/100；所选历史区间的归档依据，不代表当前行情。`,'caption'));
 const report=!episode?state.current_consolidation?.[period]:null;
 const current=report?.known_at===r.known_at?report:null;
 const profile=b?.profile||current?.profile;
 if(current&&!b){
 root.append(text('p',`当前判定：${current.label}；以下形态与主判定使用同一份已收盘证据。`,'caption'));
 if(current.candidate_basis==='body_balance')root.append(text('p',`候选判据窗口 ${current.candidate_window} 根；评分窗口 ${current.score_window??'待验证'} 根。候选资格与固定100分评分分别计算。`,'caption'));
 if(current.candidate_basis==='swing_balance')root.append(text('p','当前候选依据为显著双向摆动；下面的实体窗口形态仅作补充，不代表实体平衡已确认。','caption'));
 }
 if(!b&&!current)root.append(text('p','当前形态说明待同版已收盘模型同步。','missing'));
 if(profile){root.append(text('p',(b?'首次确认时形态：':current.verdict==='candidate'&&current.candidate_basis==='body_balance'?'所选候选窗口形态：':'实体窗口形态参考（不代表盘整确认）：')+(profile.tags.map(t=>shapeNames[t]).join('、')||'未归类')));
 const shapeTable=document.createElement('table');for(const [key,meta] of Object.entries(shapeMeta)){const value=profile.checks[key],tr=document.createElement('tr');tr.append(text('td',meta.name),text('td',value===true?'形态阈值满足':value===false?'形态阈值未满足':'前序证据缺失',value===true?'pass':'missing'));shapeTable.append(tr)}root.append(shapeTable);
 root.append(text('p',`形态指标：上沿斜率跨度 ${fmt(profile.metrics.upper_span_atr)} ATR · 下沿 ${fmt(profile.metrics.lower_span_atr)} ATR · 后半窗宽度/前半窗 ${fmt(profile.metrics.contraction_ratio)}`,'caption'));
 if(profile.tags.some(t=>t==='converging'||t==='tilted')&&profile.geometry)root.append(text('p','斜线依据：'+(geometryNames[profile.geometry.subtype]||'待确认')+'；'+profile.geometry.reason+'；'+(profile.geometry.validated?'形态与覆盖验证已通过':profile.geometry.morphology?.qualified===false?'仅保留锚点证据，不绘制有效斜线区':profile.geometry.ready?'可连接，但共同覆盖样本偏少':'证据不足，不以方框代替')+'；不外推未来边界','caption'));
 if(profile.tags.includes('converging')&&profile.geometry?.validation){const v=profile.geometry.validation;root.append(text('p',`连线共同覆盖 ${v.overlap_bars} 根 · 影线覆盖 ${Math.round(v.wick_coverage*100)}% · 收盘覆盖 ${Math.round(v.close_coverage*100)}%（边界覆盖率，不是胜率）`,'caption'))}
 root.append(text('p','缺失验证：'+profile.missing.join('、'),'missing'))}
 if(b){if(b.oscillation)root.append(text('p',`强双向震荡筛选：完成 ${b.oscillation.completed_legs} 腿 · 每腿至少 ${fmt(b.oscillation.threshold)} · 该资格条件不增加100分权重`,'caption'));
 root.append(text('p',`已确认扫荡收回 ${b.sweep_count} 次 · 最近：${b.last_sweep?b.last_sweep.side+' '+stamp(b.last_sweep.known_at):'未观察到'} · 越界连续收盘 ${b.breakout_streak} 根`));
 for(const [edge,record] of Object.entries(b.pending_liquidity_excursions||{}))root.append(text('p',`${edge==='upper'?'上侧':'下侧'}流动性曾越界 · 首次 ${stamp(record.first_excursion_at)} · 极值 ${fmt(record.extreme)} · 未确认收回，不计扫荡`,'missing'));
 if(b.last_sweep?.excursions)for(const [edge,record] of Object.entries(b.last_sweep.excursions))root.append(text('p',`最近${edge==='upper'?'上侧':'下侧'}扫荡：刺出首次可知 ${stamp(record.first_excursion_at)} → 收回确认 ${stamp(b.last_sweep.known_at)} · 极值 ${fmt(record.extreme)}`,'caption'));
 const events=(c.range_events||[]).filter(x=>x.range_id===b.id&&x.known_at<=r.known_at).slice(-6);
 for(const ev of events)root.append(text('p',`${stamp(ev.known_at)} · ${rangeEventNames[ev.event]||ev.event}${ev.sweep?' · '+ev.sweep:''}`,'caption'))}
 root.append(text('p','高周期关键位置与程序方向未核验；冻结边界按首次确认记录。扫荡与突破分开观察，尚不能推断机构意图。','caption'))}
}
const shapeNames={rectangle:'箱体盘整',compressed:'极度压缩',tilted:'倾斜盘整',converging:'收敛/楔形',relay:'中继背景'};
const rangeEventNames={range_confirmed:'首次确认',range_reclaimed:'越界/扫荡收回',breakout_pending:'越界待跟进',breakout_confirmed:'突破确认',data_gap:'数据间隔中止'};
function renderRanges(){
 const records=Object.entries(state.charts).flatMap(([period,c])=>[...(c.macro_ranges||[]),...(c.consolidations||[])].filter(box=>box.end_at>=c.bars[0].time&&(showMicro||!isMicro(box))&&(box.level==='macro'||matchesShape(box.profile))).map(box=>({period,box}))).sort((a,b)=>b.box.observed_at.localeCompare(a.box.observed_at));
 const structures=Object.entries(state.charts).flatMap(([period,c])=>(c.structural_ranges||[]).filter(b=>b.end_at>=c.bars[0].time).map(box=>({period,box}))).sort((a,b)=>b.box.first_observed_at.localeCompare(a.box.first_observed_at));
 const structureButtons=structures.map(({period,box})=>{const button=text('button',`${period} · ${box.window}棒结构候选 · ${stamp(box.observed_from)} → ${stamp(box.end_at)} · ${box.status}`,'episode');
 button.append(text('p',`${box.shape==='tilted'?'倾斜通道':'宽幅箱体'} · 双边测试 ${box.metrics.upper_visits}/${box.metrics.lower_visits} · ${box.gaps.length?'含时段间隔 · ':''}尚待实体确认，不计分`));
 button.onclick=()=>focusStructure(period,box);return button});
 const geometryButtons=Object.entries(state.charts).flatMap(([period,c])=>(c.geometric_ranges||[]).map(box=>({period,box}))).sort((a,b)=>b.box.first_observed_at.localeCompare(a.box.first_observed_at)).map(({period,box})=>{const button=text('button',`${period} · 长尺度${geometryNames[box.geometry.subtype]} · ${stamp(box.first_observed_at)} · ${box.status}`,'episode');button.onclick=()=>focusStructure(period,box,'geometric');return button});
 $('ranges').replaceChildren(...geometryButtons,...structureButtons,...records.map(({period,box})=>{const button=text('button',`${period} · ${box.level==='macro'?'外层实体平衡':'局部盘整'} · ${stamp(box.known_at)} → ${stamp(box.end_at)} · ${box.status} · 确认 ${box.confirmation_score.score}/100 · 当前 ${box.score.score}/100`,'episode'+(selected?.id===box.id&&selected?.period===period?' active':''));
 button.append(text('p',(box.profile.tags.map(t=>shapeNames[t]).join('、')||'实体平衡')+` · 流动性 ${fmt(box.liquidity_low)}—${fmt(box.liquidity_high)}`));
 button.onclick=()=>{viewEnds[period]=null;selected={period,id:box.id,kind:box.level==='macro'?'macro':'range'};$(period).parentElement.querySelector('.phase-scores').open=true;render()};return button}));
 if(!records.length&&!structures.length)$('ranges').append(text('p','尚无可展示的已确认盘整；候选及缺失证据见上方评分。'));
}
function renderShapeFilters(){
 const root=$('shapeFilters');if(!root.children.length){for(const [key,meta] of Object.entries(shapeMeta)){
 const label=text('label','','shape-toggle'),input=document.createElement('input');input.type='checkbox';input.checked=true;input.value=key;
 input.onchange=()=>{input.checked?enabledShapes.add(key):enabledShapes.delete(key);selected=null;render()};label.append(input,text('span',meta.name),text('small','0'));label.style.color=meta.color;root.append(label)}}
 for(const label of root.children){const key=label.querySelector('input').value;const counts=Object.values(state.charts).map(c=>(c.consolidations||[]).filter(b=>b.end_at>=c.bars[0].time&&b.profile?.tags.includes(key)).length);label.querySelector('small').textContent='H1 '+counts[0]+' / M15 '+counts[1]}
}
const healthNames={live:'实时读取正常',stale:'数据陈旧',quote_idle:'暂无新报价，当前性待核验',analysis_pending:'新收盘K线重算中',bars_lagging:'报价已更新，K线数据滞后',bars_unaligned:'报价与K线时序不一致',bars_unverified:'K线当前性未核验',analysis_error:'识别出错',disconnected:'MT5断连',snapshot:'仅历史快照',quote_missing:'报价缺失',network_down:'页面连接中断'};
Object.assign(healthNames,{source_mismatch:'行情来源不匹配TMGM/XAUUSD',source_unverified:'行情来源未核验'});
function currentHealth(r){
 if(networkDown)return 'network_down';
 if(!['live','quote_idle','quote_missing','analysis_pending'].includes(r.availability))return r.availability;
 const elapsed=Math.max(0,(performance.now()-receivedAt)/1000);
 return (r.poll_age_seconds??0)+elapsed>15?'stale':r.availability;
}
function renderNativeChartStatus(){
 const root=$('nativeChartStatus');if(!root)return;
 const bridge=state?.mt5_bridge;
 if(!bridge?.enabled&&!state?.mt5_bridge_error){root.textContent='';return}
 const elapsed=(performance.now()-receivedAt)/1000,serverNow=state.server_now,updated=bridge?.updated_at;
 const clockValid=Number.isFinite(elapsed)&&elapsed>=0&&Number.isFinite(serverNow)&&serverNow>0&&Number.isFinite(updated)&&updated>0&&serverNow>=updated-5;
 if(networkDown||!clockValid||Math.max(0,serverNow-updated)+elapsed>15){root.textContent='MT5 图表加载状态暂不可核验';return}
 if(state.mt5_bridge_error){root.textContent='MT5 图表同步异常：'+state.mt5_bridge_error;return}
 const indicator=bridge.indicator;
 // Receipt ages are already measured at server_now; add only browser elapsed
 // time, independently for each chart, without resetting age on an export.
 const attached=indicator?.charts?.filter(c=>c.status==='attached'&&Number.isFinite(c.age_seconds)&&c.age_seconds>=0&&c.age_seconds+elapsed<=15&&state.model_revision&&String(c.model_revision)===String(state.model_revision)&&String(bridge.model_revision)===String(state.model_revision))||[];
 root.textContent=attached.length?'MT5 图表已加载同版模型：'+attached.map(c=>c.period+' · v'+c.version+' · '+(c.auto_scroll?'跟随最新':'浏览历史')).join('；'):
 indicator?.status==='awaiting_indicator'?'MT5 图形已导出，尚未收到新版指标加载回执':
 'MT5 图形已导出，图表加载状态待核验（旧版、过期或尚未同步）';
}
function renderCurrentVerdicts(){
 renderNativeChartStatus();
 const root=$('currentVerdicts');if(!root)return;
 const key=JSON.stringify(Object.entries(state?.current_consolidation||{}).map(([p,r])=>[p,{...r,poll_age_seconds:null,quote_idle_seconds:null,availability:currentHealth(r)}]));
 if(root.dataset.renderKey===key)return;root.dataset.renderKey=key;root.replaceChildren();
 for(const period of ['H1','M15']){const r=state?.current_consolidation?.[period];const card=text('article','','current-card');
 if(!r){card.append(text('h3',period+' · 当前判定加载中'));root.append(card);continue}
 const health=currentHealth(r);
 const macro=r.macro_context,outerActive=macro?.verdict==='confirmed';
 const fresh=health==='live',pending=r.event==='breakout_pending';card.classList.add(fresh?(pending?'candidate':r.verdict):'unavailable');
 card.append(text('h3',period+' · '+(fresh?(outerActive?'大盘整内 · 局部'+(pending?'越界待跟进':r.label):pending?'盘整越界待跟进':r.label):'当前判定不可用')));
 card.append(text('p',(healthNames[health]||health)+' · 已收盘结论截至 '+stamp(r.known_at),'caption'));
 if(r.candidate_basis)card.append(text('p','候选依据：'+(r.candidate_basis==='swing_balance'?'显著双向折返；实体平衡尚未确认，评分仍按实体平衡规则':`${r.candidate_window??'—'}根已收盘K线，满足强双向震荡等候选条件；尚未确认盘整`),'caption'));
 if(r.candidate_basis==='body_balance'&&r.score_window&&r.score_window!==r.candidate_window)card.append(text('p',`评分另据原实体规则的${r.score_window}根窗口，与当前${r.candidate_window}根候选窗口分开；分数不用于候选资格`,'caption'));
 if(macro){const b=macro.range;card.append(text('p','外层：'+macro.label+(b?` · ${b.status} · ${fmt(b.liquidity_low)}—${fmt(b.liquidity_high)}`:'')+'；内部小框单独判断','caption'))}
 const large=r.structural_candidates||[];
 if(large.length){const c=large.reduce((a,b)=>a.window>b.window?a:b);card.append(text('p',`长窗口：${c.window}棒${c.shape==='tilted'?'倾斜通道':'宽幅箱体'}候选 · ${fmt(c.last_lower)}—${fmt(c.last_upper)} · 双边测试${c.metrics.upper_visits}/${c.metrics.lower_visits}次；${c.gaps.length?'跨时段覆盖待验证，':''}尚待实体平衡确认`,'caption'))}
 for(const b of r.geometric_candidates||[])card.append(text('p',`${fresh?'长尺度斜线候选':'上次斜线观察'}：${geometryNames[b.geometry.subtype]} · ${b.metrics.oscillation.completed_legs} 条完成强摆动 · 尚待实体平衡确认`,'caption'));
 if(fresh)for(const o of r.candidate_observations||[]){
 const obs=o.forming_observation,kind=o.shape==='tilted'?'通道':o.shape==='converging'?'收敛/楔形':'结构箱体';
 card.append(text('p',`${kind}候选：${o.closed_position.message}；${obs.message}（本柱轨道 ${fmt(obs.lower)}—${fmt(obs.upper)}）`,'forming-note'));
 }
 if(fresh&&r.body_candidate_observation){const o=r.body_candidate_observation;
 card.append(text('p',`实体平衡候选末柱：${o.message}（价格 ${fmt(o.price)}；${o.window}根窗口实体 ${fmt(o.low)}—${fmt(o.high)}；窗口高低点 ${fmt(o.observed_low)}—${fmt(o.observed_high)}）`,'forming-note'));
 card.append(text('p',o.policy,'caption'));
 }
 if(outerActive){const b=macro.range;card.append(text('p',`外层冻结实体 ${fmt(b.low)}—${fmt(b.high)} · 首次确认 ${stamp(b.known_at)}`,'caption'))}
 if(fresh&&macro?.forming_observation)card.append(text('p','大盘整末柱仅展示：'+macro.forming_observation.message,'forming-note'));
 if(r.swing_candidate){const c=r.swing_candidate;card.append(text('p',`${fresh?'摆动补充':'上次摆动观察'}：盘整候选 · ${c.metrics.pivot_count}个已确认拐点 · ${fmt(c.low)}—${fmt(c.high)}；尚未确认实体平衡，不增加分数`,'caption'));
 const evidence=text('details','','caption');evidence.append(text('summary','查看摆动候选依据与限制'));
 evidence.append(text('p',`观察 ${c.metrics.window} 根已收盘K线 · 上侧 ${c.metrics.upper_pivots} / 下侧 ${c.metrics.lower_pivots} 个拐点 · 边缘重复触及 ${c.metrics.upper_edge_touches ?? '—'} / ${c.metrics.lower_edge_touches ?? '—'} · 方向效率 ${c.metrics.efficiency.toFixed(2)} · 净推进/宽度 ${c.metrics.net_to_span.toFixed(2)} · 宽度 ${c.metrics.width_atr.toFixed(2)} ATR`));
 evidence.append(text('p',r.swing_observation?.reason||'候选边界随观察窗口更新，尚非冻结实体平衡边界'));
 evidence.append(text('p','尚缺：'+c.missing.join('、')));card.append(evidence)
 }else if(r.swing_observation?.event==='swing_candidate_ended')card.append(text('p','摆动观察：'+r.swing_observation.reason,'caption'));
 if(r.bar_sync&&r.bar_sync.status!=='aligned')card.append(text('p',r.bar_sync.reason,'missing'));
 if(!fresh)card.append(text('p','上次判定：'+r.label+'；等待数据恢复后复核。等待新鲜行情后恢复末柱位置观察','missing'));
 card.append(text('p','局部：'+r.reason?.replace(/当前识别为\w+，尚未满足盘整条件/,'当前结构尚未满足盘整条件'),'verdict-reason'));
 const samples=r.sample_readiness;
 if(samples?.status==='collecting'){
 card.append(text('p',(fresh?'样本进度：':'上次样本进度：')+samples.message,'caption'));
 if(samples.last_gap)card.append(text('p',`最近数据间隔：${stamp(samples.last_gap.previous_closed_at)} → ${stamp(samples.last_gap.next_open_at)}（终端时间标签，间隔原因未核验）`,'caption'));
 }
 if(r.range){const b=r.range;card.append(text('p',`${r.range_state==='ended'?'已结束区间':'局部'}实体 ${fmt(b.low)}—${fmt(b.high)} · 流动性 ${fmt(b.liquidity_low)}—${fmt(b.liquidity_high)}`,'caption'))}
 if(r.range&&Object.keys(r.range.pending_liquidity_excursions||{}).length)card.append(text('p','局部已收盘流动性越界尚未确认收回；不计扫荡次数','missing'));
 const obs=r.forming_observation;if(fresh&&obs)card.append(text('p','末柱仅展示：'+obs.message,'forming-note'));
 const tags=r.profile?.tags||[];card.append(text('p',(r.range_state==='ended'?'已结束区间形成形态：':'')+(tags.length?tags.map(t=>shapeMeta[t].name).join('＋'):'形态未归类')+(r.range_state==='ended'||r.score_eligibility==='range_ended'?' · 已结束区间形成依据 ':' · 符合度 ')+r.score+'/100（不作为确认门槛）','caption'));
 if(tags.some(t=>t==='tilted'||t==='converging')&&r.profile?.geometry?.morphology?.qualified===false)card.append(text('p','斜线形态未通过：'+r.profile.geometry.morphology.reason+'；窗口倾斜特征不代表已验证通道。','missing'));
 const failures=Object.entries(r.checks).filter(([k,v])=>v!==true).map(([k])=>k);if(failures.length)card.append(text('p','尚缺：'+failures.join('、'),'caption'));
 if(r.checks_basis==='first_confirmation')card.append(text('p','形成条件冻结于 '+stamp(r.checks_known_at)+(r.range_state==='ended'?'；原区间已结束，这些条件不代表当前仍在盘整':'；当前延续/退出另由收盘跟进判断'),'caption'));
 const button=text('button','查看局部判据');button.onclick=()=>{selected=null;$(period).parentElement.querySelector('.phase-scores').open=true;render()};card.append(button);
 if(macro?.range){const button=text('button','查看大盘整判据');button.onclick=()=>{viewEnds[period]=null;selected={period,id:macro.range.id,kind:'macro'};$(period).parentElement.querySelector('.phase-scores').open=true;render()};card.append(button)}
 root.append(card);
 }
}
function renderStateHistory(){
 const root=$('currentHistory');if(!root)return;
 const entries=Object.entries(state?.charts||{}).flatMap(([period,c])=>[...(c.current_history||[]).map(e=>({period:period+' · 局部',...e})),...(c.macro_history||[]).map(e=>({period:period+' · 外层平衡',...e})),...(c.swing_history||[]).map(e=>({period:period+' · 摆动候选',...e})),...(c.structural_history||[]).map(e=>({period:period+' · 长窗口结构',...e})),...(c.geometric_history||[]).map(e=>({period:period+' · 长尺度斜线',...e}))]).sort((a,b)=>Date.parse(b.known_at)-Date.parse(a.known_at)).slice(0,24);
 const key=JSON.stringify(entries);if(root.dataset.historyKey===key)return;root.dataset.historyKey=key;root.replaceChildren();
 for(const entry of entries){const item=text('article','','history-item');item.append(text('strong',entry.period+' · '+stamp(entry.known_at)+' · '+entry.title),text('p',entry.detail,'caption'));
 if(entry.checks_missing?.length)item.append(text('p','当时尚缺：'+entry.checks_missing.join('、'),'caption'));root.append(item)}
 if(!entries.length)root.append(text('p','尚无可展示的已收盘状态记录。'));
}
const consolidationConcepts=[
 {id:'balance',title:'实体平衡与双边交付',source:'IPDA · 实体边界资料；交付阶段视频 05:28–05:52、11:52–12:20',description:'实体集中、低效率、反复双边测试是局部价格代理；不把重叠直接解释成已证实的机构积累。'},
 {id:'liquidity',title:'上下流动性边缘',source:'IPDA · 冻结实体区与影线资料',description:'实体边界与形成时影线极值分开记录。刺出实体区并不等于扫到影线外的流动性。'},
 {id:'midpoint',title:'区间中线与往返',source:'阿尔布鲁克斯 · 三本高级篇整合 §3 区间篇',description:'冻结实体中线为区间位置参考；中线穿越与双边测试共同描述平衡，不是独立方向信号。'},
 ...Object.entries(shapeMeta).map(([id,m])=>({id,title:m.name,source:'本聊天 · 用户五类盘整框架',description:{rectangle:'近水平双边边界，使用实线方框和半透明色块。',compressed:'相对前序幅度压缩、小实体；未校准时区时不命名为亚洲区间。',tilted:'缓慢同向通道，以验证后的上下趋势线和半透明色块表示；仅凭倾斜不能断定诱导或未来反向。',converging:'三角或同向收缩楔形；用实线连接已确认高低点并填充半透明色块。锚点或共同覆盖不足时保留待证说明，不画有效形态框。',relay:'前序强位移之后的平衡候选；不承诺继续原方向。'}[id]})),
 {id:'breakout',title:'突破尝试、跟进与失败',source:'IPDA；阿尔布鲁克斯 · 三本高级篇整合 §2–3',description:'收盘越界先等待跟进；收回保留区间，连续跟进才退出。退出原区间不等于新趋势已确认。'},
 {id:'pda',title:'双向 PDA 不尊重',source:'IPDA · 交付阶段课程盘整条目',description:'这是课程的另一盘整解释；当前实体重叠代理不能替代 FVG/OB 双向失效验证。'},
 {id:'amd',title:'AMD：积累—扫荡—扩张',source:'IPDA · 交付阶段视频 07:30–10:10',description:'直接扩张和先扫荡后扩张均保留。需冻结范围、事前偏见、回收及反向位移；不能补造操纵或推断参与者身份。'},
 {id:'ce',title:'盘整扩张日',source:'每周每日概况 · 时间（二）PPT 5；DOC 第二个盘整扩张日',description:'新闻前盘整、新闻后扩张。没有日历证据时只能描述价格，不能断言新闻驱动。'},
 {id:'cme',title:'新闻前盘整操纵扩张日（CME）',source:'每周每日概况 · 时间（二）PPT 5、18',description:'先冻结偏见和范围，逆偏见扫荡后反向扩张；需新闻、顺序及时间证据。'},
 {id:'double',title:'双重扫荡日',source:'每周每日概况 · 时间（二）PPT 3、5、19–20',description:'早期顺偏见、纽约反向扫荡、再恢复扩张；两端各穿一次不充分。'},
 {id:'mec',title:'操纵扩张后盘整日',source:'每周每日概况 · 时间（二）PPT 5、21',description:'伦敦反向运动后扩张、纽约缺少跟进转为盘整；未结束会话不能判定全天不延续。'},
 {id:'seek',title:'寻找与毁灭日',source:'每周每日概况 · 时间（二）PPT 3、5、22',description:'典型路径是伦敦扫亚洲两端、纽约扫伦敦两端且缺少持续扩张；普通局部横盘不能代替会话验证。'},
 {id:'week_sweep',title:'盘整操纵后扩张周四极点',source:'每周每日概况 · 时间（三）PPT 13',description:'周一至周三盘整、周四越界、后续反向扩张。周四不必当日收回；外部范围、事前偏见与日历仍须核验。'},
 {id:'week_expansion',title:'盘整扩张周',source:'每周每日概况 · 时间（三）PPT 14',description:'周初盘整后在周四或周五扩张，不能固定首次突破日。课程与英文指南对直接扩张的取舍有差异，保留多候选。'},
 {id:'brooks',title:'Brooks 区间旁证',source:'阿尔布鲁克斯 · 三本高级篇整合 §1–4',description:'重叠、尾线、低方向性、中线往返和突破跟进仅作旁证；楔形、双顶或高潮不会自动成为主要趋势反转。'}
];
function conceptEvidence(id,period){
 const chart=state.charts[period],row=chart.phase_rows?.at(-1),e=row?.consolidation_evidence||{};
 const r=state.current_consolidation?.[period];
 if(!r||!row||r.known_at!==row.known_at)return '证据待同步：等待同版已收盘模型';
 const b=r.verdict==='confirmed'?e.range:null,checks=r.checks||{},profile=r.profile;
 const prefix=currentHealth(r)!=='live'?'历史参考 · ':'';
 let result='';
 if(id==='balance')result=b?'冻结实体平衡已确认':r?.label||'证据不足';
 else if(id==='liquidity')result=b?`${fmt(b.liquidity_low)}—${fmt(b.liquidity_high)}；扫荡收回 ${b.sweep_count} 次；未收回边缘 ${Object.keys(b.pending_liquidity_excursions||{}).length} 侧`:'尚无有效冻结流动性边缘';
 else if(id==='midpoint')result=b?`冻结中线 ${fmt((b.low+b.high)/2)}；形成时中线往返${checks['中线往返']?'满足':'未满足'}`:checks['中线往返']===true?'所选窗口中线往返满足，尚未冻结':'中线往返尚不足';
 else if(shapeMeta[id])result=profile?.checks?.[id]===true?(b?'形成时形态满足':r.verdict==='candidate'&&r.candidate_basis==='body_balance'?`仅形态候选 · ${r.candidate_window}根所选窗口`:`形态单项满足；当前${r.label}${r.candidate_basis==='swing_balance'?'依据为摆动，尚未确认实体平衡':''}`):profile?.checks?.[id]===false?'形态阈值未满足':'前序证据不足';
 else if(id==='breakout')result=rangeEventNames[e.event]||(b?'区间延续，未确认退出':'暂无有效区间突破事件');
 else if(id==='brooks')result=e.brooks_confirmed?'旁证同意，不替代IPDA判定':'旁证未同意或证据不足';
 else if(id==='amd')result=b?`范围已冻结；${b.sweep_count?'已观察到扫荡收回':'尚无已确认扫荡收回'}；事前偏见、DOL及有序位移未验证`:'完整路径未验证；允许直接扩张';
 else if(id==='pda')result='未实现双向 PDA 失效验证，不计确认';
 else if(id==='ce'||id==='cme')result='未验证：新闻日历、事前背景与完整顺序';
 else if(id.startsWith('week_'))result='未验证：周初冻结范围、周线偏见、日历与完整周内路径';
 else result='未验证：会话时区、事前偏见及完整日内路径';
 return prefix+result;
}
function renderConcepts(){
 const root=$('concepts');if(!root||!state?.charts?.H1)return;
 const output=consolidationConcepts.map(c=>({c,values:['H1','M15'].map(p=>conceptEvidence(c.id,p))}));
 const key=JSON.stringify(output);if(root.dataset.key===key)return;root.dataset.key=key;
 const open=new Set([...root.querySelectorAll('details[open]')].map(e=>e.dataset.id));root.replaceChildren();
 for(const {c,values} of output){const item=document.createElement('details');item.dataset.id=c.id;item.open=open.has(c.id);
 const summary=text('summary',c.title);item.append(summary,text('p',c.description),text('p','H1：'+values[0],'concept-status'),text('p','M15：'+values[1],'concept-status'),text('p','来源：'+c.source,'caption'));root.append(item)}
}
function render(){
 if(!state?.charts.H1)return;renderCurrentVerdicts();renderStateHistory();renderShapeFilters();renderReferenceTargets();renderReferenceReviews();renderRanges();draw('H1');draw('M15');renderPhaseScores('H1');renderPhaseScores('M15');renderConcepts();
}
async function fetchSnapshot(path,timeoutMs){
 const controller=new AbortController();let expired=false;
 const timer=setTimeout(()=>{expired=true;controller.abort()},timeoutMs);
 try{
 const response=await fetch(path,{signal:controller.signal,cache:'no-store'});
 if(!response.ok)throw Error((path==='/api/state'?'图表 ':'')+'HTTP '+response.status);
 return await response.json();
 }catch(e){if(expired)throw Error((path==='/api/state'?'图表快照':'实时行情')+'请求超时，稍后自动重试');throw e}
 finally{clearTimeout(timer)}
}
async function refresh(){if(busy)return;busy=true;try{
 let snapshotRequestedAt=performance.now();
 const tick=await fetchSnapshot('/api/live',10000);
 const changed=!state?.charts?.H1||tick.model_revision!==state.model_revision;
 if(changed&&tick.has_charts){snapshotRequestedAt=performance.now();state=await fetchSnapshot('/api/state',15000)}
 else state={...state,...tick,charts:state?.charts||{}};
 receivedAt=snapshotRequestedAt;networkDown=false;
 const q=state.quote;const moving=q&&state.status==='connected'&&(state.polled_at-state.last_tick_change_at)<30;
 const revision=state.last_data_revision;
 const source=state.market_source,sourceText=source?` · 来源 ${source.company||'经纪商待核验'} / ${source.server||'服务器待核验'} / ${source.symbol||'品种待核验'} · ${source.status==='verified'?'终端标签匹配':'来源未匹配'}`:'';
 $('status').textContent=`${state.status==='connected'?(moving?'MT5 数据连接正常':'MT5 已连接 · 最近30秒暂无新报价'):state.message}${q?` · Bid ${fmt(q.bid)} / Ask ${fmt(q.ask)} · 终端标签 ${q.raw_time}`:''}${state.analysis_error?' · 识别错误：'+state.analysis_error:''}${state.cache_error?' · 缓存保存失败（实时识别继续）：'+state.cache_error:''}${state.data_revision_pending?' · 历史K线修订正在重算':revision?' · 历史K线修订 '+revision.count+' 根已重算（'+Object.entries(revision.periods).map(([p,v])=>p+'自'+stamp(v.first_affected_at)).join('、')+'）':''}`;
 $('status').textContent+=sourceText+(state.analysis_running?' · 识别重算中，报价持续更新':'');
 const freeze=state.freeze_integrity;
 if(freeze)$('status').textContent+=freeze.passed?(freeze.previously_recorded?' · 已核对 '+freeze.previously_recorded+' 个既有区间冻结记录':' · 已建立本次区间冻结记录'):' · 冻结记录校验异常，保留上次模型';
 if(freeze?.source_revisions?.length)$('status').textContent+=' · '+freeze.source_revisions.length+' 项形成行情修订已记录';
 const archive=state.history_archive;
 if(archive?.periods)$('status').textContent+=' · 历史'+(archive.persisted?'已保存':'待保存')+' '+Object.entries(archive.periods).map(([p,v])=>p+' '+v.bars+'根').join(' / ');
 renderCurrentVerdicts();if(changed)render();else {draw('H1');draw('M15');renderConcepts()}
 }catch(e){networkDown=true;renderCurrentVerdicts();renderConcepts();$('status').textContent='连接中断：'+e.message+' · 已显示数据保留'}finally{busy=false}}
 function zoom(factor){
 const maximum=Math.max(30,...Object.values(chartViews).map(v=>v.all.length));
 viewCount=Math.max(30,Math.min(maximum,Math.round((viewCount||maximum)*factor)));
 const select=$('range');let option=select.querySelector('[data-zoom]');
 if(!option){option=document.createElement('option');option.dataset.zoom='true';select.append(option)}
 option.value=String(viewCount);option.textContent='缩放 '+viewCount+' 根';select.value=String(viewCount);render()
}
 $('range').onchange=()=>{viewCount=Number($('range').value);selected=null;viewEnds.H1=null;viewEnds.M15=null;render()};

 $('zoomIn').onclick=()=>zoom(.8);$('zoomOut').onclick=()=>zoom(1.25);$('chartSize').onchange=render;
 $('showMicro').onchange=()=>{showMicro=$('showMicro').checked;render()};
 for(const p of ['H1','M15'])$(p).addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY<0?.8:1.25)},{passive:false});$('latest').onclick=()=>{selected=null;viewEnds.H1=null;viewEnds.M15=null;render()};for(const period of ['H1','M15']){
 const canvas=$(period);canvas.tabIndex=0;canvas.setAttribute('aria-label',period+'行情图，左右拖动或方向键浏览历史');let drag=null;
 const pan=end=>{const view=chartViews[period];if(!view)return;const clamped=Math.max(Math.min(view.count,view.all.length),Math.min(view.all.length,end));
 viewEnds[period]=clamped===view.all.length?null:view.all[clamped-1].time;draw(period)};
 canvas.addEventListener('pointerdown',e=>{if(e.button!==0||!chartViews[period])return;
 const view=chartViews[period];drag={id:e.pointerId,x:e.clientX,end:view.end,barWidth:view.barWidth,moved:false};canvas.setPointerCapture(e.pointerId)});
 canvas.addEventListener('pointermove',e=>{if(!drag||e.pointerId!==drag.id)return;const dx=e.clientX-drag.x;if(!drag.moved&&Math.abs(dx)<4)return;
 drag.moved=true;selected=null;canvas.classList.add('dragging');pan(drag.end-Math.round(dx/drag.barWidth))});
 const finish=e=>{if(!drag||e.pointerId!==drag.id)return;const moved=drag.moved;drag=null;canvas.classList.remove('dragging');if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);if(moved)render()};
 canvas.addEventListener('pointerup',finish);canvas.addEventListener('pointercancel',finish);
 canvas.addEventListener('lostpointercapture',e=>{if(drag&&e.pointerId===drag.id){drag=null;canvas.classList.remove('dragging');render()}});
 canvas.addEventListener('keydown',e=>{const view=chartViews[period];if(!view)return;
 if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();selected=null;pan(view.end+(e.key==='ArrowLeft'?-1:1)*Math.max(1,Math.round(view.count*.1)));render()}
 if(e.key==='End'){e.preventDefault();selected=null;viewEnds[period]=null;render()}});
}
window.addEventListener('resize',render);refresh();setInterval(refresh,2000);setInterval(()=>{renderCurrentVerdicts();renderConcepts()},1000);
