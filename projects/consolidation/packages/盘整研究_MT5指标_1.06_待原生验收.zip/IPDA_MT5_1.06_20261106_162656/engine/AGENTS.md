# Project scope

Work on the standalone IPDA retracement project in this directory. The parent project is a source reference only; do not modify it as part of normal work here.

IPDA is primary. Brooks supplies corroboration only. H1 provides already-known background; M15 identifies contextual retracements. Keep incomplete evidence explicit. Scores are rule fit out of 100, not probabilities. Forming bars must never confirm an event or receive a confirmed score. Do not introduce broker orders. Do not run backtests unless requested.

Read README.md and extraction_manifest.json for runtime, provenance and limits. Source modules in ict_trader were copied at extraction time and can evolve independently here.
