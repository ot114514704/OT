// Verify archived explanations without depending on the recent per-bar cache.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
function element(){return {dataset:{},children:[],textContent:'',classList:{add(){}},
 append(...items){this.children.push(...items)},replaceChildren(){this.children=[]}}}
const roots=new Map(),root=id=>{if(!roots.has(id))roots.set(id,element());return roots.get(id)};
const context=vm.createContext({performance:{now:()=>1000},document:{getElementById:root,createElement:element}});
const source=fs.readFileSync('ui/app.js','utf8').split('async function refresh()')[0];
vm.runInContext(source,context);const run=code=>vm.runInContext(code,context);
const texts=node=>[node.textContent,...node.children.flatMap(texts)].join('\n');
const score={score:75,eligibility:'range_ended',unknown_weight:20,components:[],checks_basis:'first_confirmation',checks_known_at:'2026-01-01T01:00:00+00:00',current_range_valid:false};
const box={id:'old',known_at:score.checks_known_at,observed_at:'2026-01-01T03:00:00+00:00',status:'向下突破条件触发',
 low:98,high:102,liquidity_low:97,liquidity_high:103,profile:{tags:['rectangle'],checks:{rectangle:true},metrics:{},missing:[]},
 sweep_count:1,breakout_streak:2,score,confirmation_score:{...score,score:80},brooks_confirmed:true};
context.input=JSON.stringify({charts:{M15:{consolidations:[box],phase_rows:[{known_at:'2026-06-01T01:00:00+00:00'}]}}});
run("state=JSON.parse(input);selected={period:'M15',id:'old',kind:'range'};renderPhaseScores('M15');");
let output=texts(root('scoresM15'));
assert.ok(!output.includes('加载中'));assert.match(output,/形成时 80\/100 · 最后观察 75\/100/);
assert.match(output,/实体 98.00—102.00/);assert.match(output,/Brooks 旁证同意/);
assert.match(output,/首次确认时形态：箱体盘整/);
run("state.charts.M15.phase_rows=[];renderPhaseScores('M15');");
assert.equal(texts(root('scoresM15')),output);
run("selected.id='missing';renderPhaseScores('M15');");
assert.match(texts(root('scoresM15')),/所选区间已不在/);
run("selected.id='old';delete state.charts.M15.consolidations[0].score;renderPhaseScores('M15');");
assert.match(texts(root('scoresM15')),/缺少评分记录/);

let checked=0,outsideRecent=0;
if(process.argv[2]){
 context.input=fs.readFileSync(process.argv[2],'utf8');run('state=JSON.parse(input);');
 const initial=run('JSON.stringify(state)');
 const state=JSON.parse(context.input);
 for(const [period,chart] of Object.entries(state.charts))for(const b of chart.consolidations||[]){
  run(`selected={period:${JSON.stringify(period)},id:${JSON.stringify(b.id)},kind:'range'};renderPhaseScores(${JSON.stringify(period)});`);
  output=texts(root('scores'+period));
  assert.ok(output.includes(b.status),b.id);assert.ok(!output.includes('加载中'),b.id);
  assert.ok(output.includes(`实体 ${b.low.toFixed(2)}—${b.high.toFixed(2)}`),b.id);
  assert.ok(output.includes(`形成时 ${b.confirmation_score.score}/100 · 最后观察 ${b.score.score}/100`),b.id);
  if(b.observed_at<chart.phase_rows[0].known_at)outsideRecent++;
  checked++;
 }
 assert.equal(run('JSON.stringify(state)'),initial,'Reading history must not mutate live reports or archived evidence');
}
console.log(JSON.stringify({passed:true,checkedNativeRanges:checked,outsideRecentPhaseWindow:outsideRecent,
 scope:'Actual JS detail renderer execution; archived facts and score stay available independently of recent phase rows; no new physical UI acceptance'}));
