"""Close-time reuse must preserve causal cutoffs and replacement semantics."""
from copy import deepcopy
from dataclasses import asdict, replace
from datetime import datetime, timedelta, timezone
import unittest

from ict_trader.core import Bar, visible


class BarTimingTests(unittest.TestCase):
    def make_bar(self):
        return Bar(datetime(2026, 11, 5, 10, tzinfo=timezone(timedelta(hours=2))),
                   100, 102, 99, 101, seconds=900)

    def test_close_remains_utc_and_forming_cutoff_is_exclusive(self):
        bar=self.make_bar()
        close=datetime(2026, 11, 5, 8, 15, tzinfo=timezone.utc)
        self.assertEqual(bar.closed_at,close)
        self.assertEqual(visible([bar],close-timedelta(microseconds=1)),[])
        self.assertEqual(visible([bar],close),[bar])

    def test_replacing_time_or_period_cannot_reuse_previous_close(self):
        bar=self.make_bar();old_close=bar.closed_at
        moved=replace(bar,time=bar.time+timedelta(days=1))
        hourly=replace(bar,seconds=3600)
        self.assertEqual(moved.closed_at,old_close+timedelta(days=1))
        self.assertEqual(hourly.closed_at,old_close+timedelta(minutes=45))
        self.assertEqual(bar.closed_at,old_close)

    def test_copy_and_serialization_do_not_change_after_time_is_read(self):
        bar=self.make_bar();before=asdict(bar);before_hash=hash(bar)
        close=bar.closed_at
        self.assertEqual(asdict(bar),before)
        self.assertEqual(hash(bar),before_hash)
        copied=deepcopy(bar)
        self.assertEqual(copied,bar)
        self.assertEqual(copied.closed_at,close)
        self.assertEqual(replace(copied,seconds=300).closed_at,close-timedelta(minutes=10))


if __name__=='__main__':unittest.main()
