import json
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
import unittest

from ict_trader.core import Bar, instant
from ict_trader.shape_geometry import confirmed_geometry, frame_morphology
from ict_trader.mt5_bridge import shape_record


def frame(du, dl, width=10):
    return [dict(price=110), dict(price=110+du), dict(price=110-width+dl), dict(price=110-width)]


def candles(upper_drift, lower_drift):
    bars=[]
    for i in range(26):
        high=110+upper_drift*i+(.6 if i%8==1 else 0)
        low=100+lower_drift*i-(.6 if i%8==5 else 0)
        mid=(high+low)/2
        bars.append(Bar(datetime(2026,1,1,tzinfo=timezone.utc)+timedelta(minutes=15*i), mid-.05, high, low, mid+.05, 0, 900))
    return bars


class MorphologyTests(unittest.TestCase):
    def test_opposite_outward_rails_never_form_a_channel_despite_full_coverage(self):
        g=confirmed_geometry(candles(.1,-.1),atr=2)
        self.assertTrue(g['ready'])
        self.assertGreaterEqual(g['validation']['overlap_bars'],3)
        self.assertEqual(g['validation']['wick_coverage'],1)
        self.assertFalse(g['validated']);self.assertEqual(g['subtype'],'broadening')
        self.assertIn('外扩',g['reason'])

    def test_parallel_channels_remain_valid_in_both_directions(self):
        for direction in (-1,1):
            g=confirmed_geometry(candles(.1*direction,.1*direction),atr=2)
            self.assertTrue(g['validated']);self.assertEqual(g['subtype'],'channel')
            self.assertTrue(g['morphology']['same_direction'])

    def test_same_direction_alone_is_not_parallelism(self):
        for du,dl in ((2,.1),(-.1,-2)):
            m=frame_morphology(frame(du,dl),.3)
            self.assertFalse(m['qualified']);self.assertEqual(m['subtype'],'broadening')
        # Nearly equal slopes can still widen a very narrow rail excessively.
        self.assertFalse(frame_morphology(frame(2,1.9,width=.5),.01)['qualified'])
        self.assertTrue(frame_morphology(frame(2,1.9),.3)['qualified'])

    def test_horizontal_rails_are_not_tilted_and_contraction_is_direction_neutral(self):
        self.assertEqual(frame_morphology(frame(0,0),.3)['subtype'],'flat_range')
        for du,dl,name in ((0,1,'ascending_triangle'),(-1,0,'descending_triangle'),(-1,1,'triangle'),(1,2,'rising_wedge'),(-2,-1,'falling_wedge')):
            m=frame_morphology(frame(du,dl),.3)
            self.assertEqual(m['subtype'],name);self.assertTrue(m['qualified'])

    def test_translation_scale_and_price_reflection_preserve_qualification(self):
        for du,dl in ((2,2),(2,.1),(-1,1),(1,2),(0,1)):
            original=frame(du,dl);a=frame_morphology(original,.3)
            scaled=[dict(p,price=p['price']*7+1000) for p in original]
            b=frame_morphology(scaled,2.1)
            reflected=[dict(price=300-original[i]['price']) for i in (3,2,1,0)]
            c=frame_morphology(reflected,.3)
            self.assertEqual(a['subtype'],b['subtype']);self.assertEqual(a['qualified'],c['qualified'])
            self.assertAlmostEqual(a['relative_slope_difference'],b['relative_slope_difference'])

    def test_native_counterexample_preserves_anchors_and_refuses_mt5_polygon(self):
        fixture=json.loads((Path(__file__).parent/'fixtures/native_outward_rails.json').read_text(encoding='utf-8'))
        bars=[Bar(instant(r['time']),*(r[k] for k in ('open','high','low','close')),r.get('spread',0),900) for r in fixture['bars']]
        g=confirmed_geometry(bars,atr=fixture['atr'])
        old=fixture['old_geometry']
        for key in ('upper','lower','frame','known_at','validation','ready','contraction_ratio'):
            self.assertEqual(g[key],old[key],key)
        self.assertFalse(g['validated']);self.assertEqual(g['subtype'],'broadening')
        box=dict(id='native',observed_from=bars[0].time.isoformat(),known_at=bars[-1].closed_at.isoformat(),end_at=bars[-1].closed_at.isoformat(),profile=dict(tags=['tilted'],geometry=g))
        self.assertIsNone(shape_record('M15','candidate',box))
        # Future input cannot repair the historical geometry or alter its anchors.
        later=bars+[replace(bars[-1],time=bars[-1].closed_at,high=5000,close=4999)]
        self.assertEqual(confirmed_geometry(later[:len(bars)],atr=fixture['atr']),g)


if __name__=='__main__':unittest.main()
