import unittest
from dataclasses import replace
from datetime import datetime,timedelta,timezone
from ict_trader.core import Bar
from ict_trader.shape_geometry import confirmed_geometry
from ict_trader.consolidation_profile import profile


def sample(wedge=False):
    start=datetime(2026,1,1,tzinfo=timezone.utc);result=[]
    for i in range(12):
        high=(104+.05*i if wedge else 104-.15*i)+(.3 if i%3==1 else 0)
        low=(96+.5*i if wedge else 96+.15*i)-(.8 if i%3==2 else 0)
        mid=(high+low)/2
        result.append(Bar(start+timedelta(minutes=15*i),mid-.05,high,low,mid+.05,0,900))
    return result


class GeometryTests(unittest.TestCase):
    def test_validated_triangles_are_tagged_with_direction_neutral_geometry(self):
        for mode,subtype in [('triangle','triangle'),('ascending','ascending_triangle'),('descending','descending_triangle')]:
            bars=[]
            for i in range(26):
                h=104-(.1*i if mode!='ascending' else 0)+(.6 if i%8==1 else 0)
                l=96+(.1*i if mode!='descending' else 0)-(.6 if i%8==5 else 0)
                m=(h+l)/2
                bars.append(Bar(datetime(2026,1,1,tzinfo=timezone.utc)+timedelta(minutes=15*i),m-.05,h,l,m+.05,0,900))
            p=profile(bars,0,25,3)
            self.assertTrue(p['geometry']['validated']);self.assertEqual(p['geometry']['subtype'],subtype)
            self.assertIn('converging',p['tags'])

    def test_triangle_uses_confirmed_actual_highs_and_lows(self):
        bars=sample();geometry=confirmed_geometry(bars)
        self.assertTrue(geometry['ready']);self.assertEqual(geometry['subtype'],'triangle')
        by_time={b.time.isoformat():b for b in bars}
        for p in geometry['upper']:self.assertEqual(p['price'],by_time[p['time']].high)
        for p in geometry['lower']:self.assertEqual(p['price'],by_time[p['time']].low)
        for p in geometry['upper']+geometry['lower']:
            self.assertLess(p['time'],bars[-1].time.isoformat());self.assertLessEqual(p['known_at'],bars[-1].closed_at.isoformat())
        self.assertFalse(geometry['projected'])

    def test_rising_and_falling_wedges_are_symmetric(self):
        bars=sample(True);a=confirmed_geometry(bars)
        mirrored=[replace(b,open=200-b.open,high=200-b.low,low=200-b.high,close=200-b.close) for b in bars]
        b=confirmed_geometry(mirrored)
        self.assertEqual(a['subtype'],'rising_wedge');self.assertEqual(b['subtype'],'falling_wedge')
        # Both have only two common bars: subtype is observable, coverage is
        # still too short to promote either to a validated morphology.
        self.assertNotIn('converging',profile(bars,0,11,3)['tags']);self.assertNotIn('converging',profile(mirrored,0,11,3)['tags'])

    def test_monotonic_path_does_not_invent_swing_anchors(self):
        bars=sample();bars=[replace(b,high=110-i*.2,low=90+i*.2) for i,b in enumerate(bars)]
        g=confirmed_geometry(bars);self.assertFalse(g['ready']);self.assertNotIn('frame',g)

    def test_later_bars_do_not_rewrite_an_earlier_geometry(self):
        bars=sample();prefix=bars[:10];original=confirmed_geometry(prefix)
        mutated=bars[:10]+[replace(b,high=200,close=199) for b in bars[10:]]
        self.assertEqual(confirmed_geometry(mutated[:10]),original)

    def test_short_overlap_remains_explicitly_unvalidated(self):
        geometry=confirmed_geometry(sample())
        self.assertTrue(geometry['ready']);self.assertFalse(geometry['validated'])
        self.assertEqual(geometry['validation']['overlap_bars'],2)

    def test_arbitrary_anchor_lines_cannot_cut_through_many_candles(self):
        template=sample()
        highs=[108,108,109,110,109.8,109.3,108.5,107.5,103.8,104,103,102]
        lows=[91,91,91,91,90,91,92,93,94,95,94,95]
        bars=[replace(b,open=(h+l)/2,close=(h+l)/2,high=h,low=l) for b,h,l in zip(template,highs,lows)]
        g=confirmed_geometry(bars,atr=1)
        self.assertFalse(g['ready']);self.assertFalse(g['validated'])
        self.assertLess(g['validation']['wick_coverage'],.8)
        self.assertIn('未通过',g['reason'])

    def test_no_line_bridges_a_data_gap(self):
        bars=sample();bars[7:]=[replace(b,time=b.time+timedelta(minutes=15)) for b in bars[7:]]
        g=confirmed_geometry(bars);self.assertFalse(g['ready']);self.assertIn('缺口',g['reason'])
