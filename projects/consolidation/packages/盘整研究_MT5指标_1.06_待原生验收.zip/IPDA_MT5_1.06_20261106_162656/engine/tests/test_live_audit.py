"""Acceptance must reject deliberately corrupted snapshots, not just pass itself."""
import unittest
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from copy import deepcopy
from dataclasses import replace
from datetime import timedelta
import app
from ict_trader.live_audit import audit_payload, main
from tests.test_consolidation import fixture


class LiveAuditTests(unittest.TestCase):
    def test_unavailable_service_replaces_previous_success_report(self):
        with TemporaryDirectory() as directory:
            target=Path(directory)/'audit.json'
            target.write_text('{"passed": true}',encoding='utf-8')
            with patch('ict_trader.live_audit.urlopen',side_effect=OSError('connection refused')),patch('builtins.print'):
                self.assertEqual(main(['--output',str(target)]),1)
            result=json.loads(target.read_text(encoding='utf-8'))
            self.assertFalse(result['passed']);self.assertFalse(result['live_ready'])
            self.assertEqual(result['issues'][0]['code'],'snapshot_unavailable_or_invalid')

    def test_swing_history_cannot_claim_confirmation_or_future_observation(self):
        p=deepcopy(self.payload)
        p['charts']['M15']['swing_history']=[dict(known_at='2099-01-01T00:00:00+00:00',confirmed_bar_only=True,confirmed=True,score_included=False)]
        self.assert_issue(p,'history_not_closed');self.assert_issue(p,'swing_history_promotion')

    def test_live_report_with_invalid_ask_fails_acceptance(self):
        p=deepcopy(self.payload)
        p['current_consolidation']['M15'].update(actionable_current=True,availability='live',bar_sync={'status':'aligned'})
        for ask in (None,float('nan'),float('inf'),99):
            p['quote']=dict(bid=100,ask=ask,raw_epoch=1767225600)
            with self.subTest(ask=ask):self.assert_issue(p,'invalid_live_quote')

    def test_candidate_live_observation_cannot_use_missing_source_stale_data_or_confirm(self):
        p=deepcopy(self.payload);end=p['charts']['M15']['closed_end']
        p['current_consolidation']['M15']['candidate_observations']=[dict(range_id='not-active',
            known_at=end,confirmed=True,score_included=True,
            forming_observation=dict(bar_open_at=end,confirmed=True,score_included=True))]
        for code in ('candidate_observation_source','unavailable_candidate_observation',
                     'candidate_observation_promotion','candidate_forming_promotion'):
            self.assert_issue(p,code)

    def test_body_candidate_cannot_drop_required_oscillation_or_mismatch_drawn_window(self):
        p=deepcopy(self.payload);c=p['charts']['M15'];end=c['closed_end']
        p['current_consolidation']['M15'].update(verdict='candidate',candidate_basis='body_balance',
            candidate_window=24,checks={'强双向震荡筛选':False})
        c['current_candidate']=dict(known_at=end,end_at=end,observed_from=c['bars'][-2]['time'],
            low=100,high=110,window=12,confirmed=False,score_included=False,confirmed_bar_only=True,candidate_basis='body_balance')
        for code in ('body_candidate_prerequisites','body_candidate_window_mismatch','body_candidate_source_mismatch'):
            self.assert_issue(p,code)

    def test_verified_marker_with_wrong_broker_is_not_source_proof(self):
        p=deepcopy(self.payload)
        p['current_consolidation']['M15'].update(actionable_current=True,availability='live',bar_sync={'status':'aligned'})
        p['quote']=dict(bid=100,ask=101,raw_epoch=1767225600,market_source=dict(status='verified',company='Other Broker',server='TradeMaxGlobal-Live',symbol='XAUUSD'))
        self.assert_issue(p,'invalid_live_source')

    def test_body_candidate_position_cannot_claim_frozen_or_wrong_source_bounds(self):
        p=deepcopy(self.payload);c=p['charts']['M15'];end=c['closed_end']
        p['current_consolidation']['M15']['body_candidate_observation']=dict(
            known_at=end,bar_open_at=end,window=999,low=-1,high=999,observed_low=-2,observed_high=1000,
            price=100,confirmed=True,score_included=True,boundaries_frozen=True,boundary_basis='wrong')
        for code in ('body_observation_availability','body_observation_promotion','body_observation_bounds','body_observation_price_source'):
            self.assert_issue(p,code)

    @classmethod
    def setUpClass(cls):
        template=fixture()*2;start=template[0].time
        raw={p:[app.row(replace(b,time=start+timedelta(seconds=i*seconds),seconds=seconds)) for i,b in enumerate(template)] for p,seconds in [('H1',3600),('M15',900)]}
        cls.payload=app.response_payload(dict(status='snapshot',charts=app.calculate(raw),model_revision='synthetic'),100)

    def assert_issue(self,payload,code):
        result=audit_payload(payload)
        self.assertFalse(result['passed']);self.assertIn(code,[i['code'] for i in result['issues']])

    def test_legitimate_pipeline_snapshot_passes_without_mutation(self):
        p=deepcopy(self.payload);before=deepcopy(p)
        self.assertTrue(audit_payload(p)['passed']);self.assertFalse(audit_payload(p)['live_ready']);self.assertEqual(p,before)

    def test_changed_frozen_boundary_is_detected(self):
        p=deepcopy(self.payload)
        rows=[r for r in p['charts']['M15']['phase_rows'] if r['consolidation_evidence'].get('range')]
        self.assertGreater(len(rows),1)
        rows[1]['consolidation_evidence']['range']['low']-=.01
        self.assert_issue(p,'frozen_boundary_changed')

    def test_future_geometry_is_detected(self):
        p=deepcopy(self.payload);rows=p['charts']['M15']['phase_rows']
        r=next(r for r in rows if r['consolidation_evidence'].get('range'))
        g=r['consolidation_evidence']['range']['profile']['geometry']
        g['known_at']='2099-01-01T00:00:00+00:00'
        self.assert_issue(p,'geometry_known_at')
        p=deepcopy(self.payload)
        r=next(r for r in p['charts']['M15']['phase_rows'] if r['consolidation_evidence'].get('range'))
        g=r['consolidation_evidence']['range']['profile']['geometry']
        g['upper']=[dict(time=r['bar_open_at'],known_at=r['known_at'],price=101)]
        self.assert_issue(p,'anchor_confirmation_delay')

    def test_score_and_forming_contamination_are_detected(self):
        p=deepcopy(self.payload)
        p['charts']['M15']['phase_rows'][-1]['fit_scores']['by_phase']['consolidation']['components'][0]['weight']=99
        self.assert_issue(p,'score_denominator')
        p=deepcopy(self.payload);p['charts']['M15']['bars'][-1]['forming']=True
        self.assert_issue(p,'forming_in_closed_model')
        p=deepcopy(self.payload);p['current_consolidation']['M15']['forming_observation']=dict(confirmed=True,score_included=True,bar_open_at=p['charts']['M15']['closed_end'])
        self.assert_issue(p,'forming_confirmation_or_score')

    def test_stale_report_and_wrong_outer_exit_basis_are_detected(self):
        p=deepcopy(self.payload);p['current_consolidation']['M15']['known_at']='2025-01-01T00:00:00+00:00'
        self.assert_issue(p,'current_report_time')
        p=deepcopy(self.payload);self.assertTrue(p['charts']['M15']['macro_ranges'])
        p['charts']['M15']['macro_ranges'][0]['breakout_basis']='body'
        self.assert_issue(p,'macro_exit_basis')

    def test_current_candidate_cannot_be_promoted_or_extended_into_forming_bar(self):
        from ict_trader.current_consolidation import CHECK_NAMES
        p=deepcopy(self.payload);c=p['charts']['M15'];end=c['closed_end']
        checks={k:k!='two_sided' for k in CHECK_NAMES}
        c['phase_rows'][-1]['consolidation_evidence'].update(range=None,ended=None,
            candidates=[dict(lo=100,hi=110,metrics={'window':12},checks=checks)])
        p['current_consolidation']['M15'].update(verdict='candidate',candidate_basis='body_balance',
            candidate_window=12,checks={CHECK_NAMES[k]:v for k,v in checks.items()})
        c['current_candidate']=dict(known_at=end,end_at=end,observed_from=c['bars'][-12]['time'],
            low=100,high=110,window=12,confirmed=False,score_included=False,confirmed_bar_only=True,candidate_basis='body_balance')
        self.assertTrue(audit_payload(p)['passed'])
        c['current_candidate']['confirmed']=True;self.assert_issue(p,'current_candidate_promotion')
        c['current_candidate']['confirmed']=False;c['current_candidate']['end_at']='2099-01-01T00:00:00+00:00'
        self.assert_issue(p,'current_candidate_time')
        c['current_candidate']=None;self.assert_issue(p,'current_candidate_visibility')
