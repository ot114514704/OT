"""Early rejection must preserve every accepted structure and frozen detail."""
import math
import random
import unittest
from datetime import datetime,timedelta,timezone
from unittest.mock import patch

from ict_trader.core import Bar
from ict_trader import structural_ranges as structures


def samples(n,seed,drift=0.,gap=False):
    rng=random.Random(seed);start=datetime(2026,1,1,tzinfo=timezone.utc);bars=[]
    for i in range(n):
        center=100+drift*i+4*math.sin(i*.55)
        op=center+rng.uniform(-.6,.6);close=center+rng.uniform(-.6,.6)
        t=start+timedelta(minutes=15*(i+(4 if gap and i>=n//2 else 0)))
        bars.append(Bar(t,op,max(op,close)+rng.uniform(.2,1.1),min(op,close)-rng.uniform(.2,1.1),close,0,900))
    return bars


class StructureScanEquivalenceTests(unittest.TestCase):
    def test_fast_path_keeps_all_qualified_fields_for_both_sides_and_modes(self):
        accepted=0;rejected=0
        for seed in range(12):
            for n in (24,48,96,192):
                for drift in (0.,.15,-.15,.8,-.8):
                    bars=samples(n,seed,drift,gap=bool(seed%2))
                    for mode in ('horizontal','auto'):
                        full=structures.candidate(bars,mode)
                        fast=structures.candidate(bars,mode,qualified_only=True)
                        if full and full['qualified']:
                            accepted+=1;self.assertEqual(fast,full)
                        else:rejected+=1;self.assertIsNone(fast)
        self.assertGreater(accepted,0);self.assertGreater(rejected,0)

    def test_failed_physical_gate_skips_expensive_oscillation(self):
        bars=samples(96,1,drift=.8)
        with patch.object(structures,'strong_oscillation',wraps=structures.strong_oscillation) as observe:
            self.assertIsNone(structures.candidate(bars,'horizontal',qualified_only=True))
            observe.assert_not_called()

    def test_full_history_including_active_rails_and_gaps_is_identical(self):
        original=structures.candidate
        for drift in (0.,.08,-.08):
            bars=samples(240,7,drift,gap=True)
            fast=structures.observe_structures(bars,bars[-1].closed_at)
            with patch.object(structures,'candidate',side_effect=lambda w,mode,**kw:original(w,mode)):
                full=structures.observe_structures(bars,bars[-1].closed_at)
            self.assertEqual(fast,full)


if __name__=='__main__':unittest.main()
