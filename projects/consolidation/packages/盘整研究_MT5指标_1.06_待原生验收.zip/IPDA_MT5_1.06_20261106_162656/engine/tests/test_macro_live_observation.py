import unittest
from copy import deepcopy
from ict_trader.current_consolidation import live_reports
from tests import test_current_consolidation as fixtures


def state():
    s=fixtures.FormingDisplayTests().setup_state();c=s['charts']['M15']
    b=deepcopy(c['phase_rows'][0]['consolidation_evidence']['range'])
    b.update(level='macro',breakout_basis='liquidity')
    c['macro_current']=dict(verdict='confirmed',label='已确认盘整',range=b,score=80,known_at=c['closed_end'])
    return s


class MacroLiveObservationTests(unittest.TestCase):
    def test_local_body_breach_can_remain_inside_outer_balance(self):
        s=state();s['forming']['M15'].update(high=102,close=101.8)
        r=live_reports(s,101)['M15']
        self.assertEqual(r['forming_observation']['code'],'above_threshold')
        outer=r['macro_context']['forming_observation']
        self.assertEqual(outer['code'],'inside')
        self.assertEqual(outer['threshold_high'],102.3)
        self.assertEqual(outer['boundary_basis'],'frozen_liquidity_edges')
        self.assertFalse(outer['score_included']);self.assertFalse(outer['confirmed'])

    def test_outer_observation_survives_local_exit_without_mutating_model(self):
        s=state();c=s['charts']['M15'];row=c['phase_rows'][0]
        row['consolidation_evidence'].update(range=None,candidates=[]);row['phase']='expansion'
        original=deepcopy(s);base=live_reports(s,101)['M15']
        self.assertEqual(base['verdict'],'not_consolidation')
        self.assertIsNotNone(base['macro_context']['forming_observation'])
        self.assertEqual(s,original)
        s['forming']['M15'].update(high=106,close=105)
        moved=live_reports(s,101)['M15']['macro_context']
        self.assertEqual(moved['forming_observation']['code'],'above_threshold')
        self.assertEqual(moved['score'],80);self.assertEqual(moved['verdict'],'confirmed')
        self.assertEqual(moved['range'],original['charts']['M15']['macro_current']['range'])
        self.assertEqual(s['charts'],original['charts'])

    def test_unavailable_pending_or_ended_outer_cannot_display_live_forming(self):
        for mutate in (lambda s:s.update(status='disconnected'),lambda s:s.update(polled_at=50),
                       lambda s:s.update(latest_closed_end={'M15':'2026-01-01T01:15:00+00:00'}),
                       lambda s:s['charts']['M15']['macro_current'].update(verdict='not_consolidation')):
            s=state();mutate(s)
            r=live_reports(s,101)['M15']['macro_context']
            self.assertIsNone(r['forming_observation'])
