import unittest
import json
from pathlib import Path
from dataclasses import replace
from datetime import datetime,timedelta,timezone
from ict_trader.core import Bar,instant
from ict_trader.structural_ranges import observe_structures,candidate
from tests.test_consolidation_invariants import transformed


def fixture(count=100,slope=0):
    values=[0,2,4,2,0,-2,-4,-2]*20
    start=datetime(2026,1,1,tzinfo=timezone.utc)
    return [Bar(start+timedelta(hours=i),100+values[i]+slope*i-.2,
                100+values[i]+slope*i+.6,100+values[i]+slope*i-.6,
                100+values[i]+slope*i,0,3600) for i in range(count)]


class StructuralRangeTests(unittest.TestCase):
    def observe(self,bars,asof=None):return observe_structures(bars,asof or bars[-1].closed_at)

    def test_long_windows_are_independent_and_do_not_promote_confirmation(self):
        bars=fixture();r=self.observe(bars)
        self.assertEqual({b['window'] for b in r['current']},{24,48,96})
        for b in r['current']:
            self.assertFalse(b['confirmed']);self.assertFalse(b['score_included'])
            self.assertGreaterEqual(b['metrics']['upper_visits'],2)
            self.assertGreaterEqual(b['metrics']['lower_visits'],2)
            self.assertEqual(b['first_observed_at'],bars[b['window']-1].closed_at.isoformat())

    def test_frozen_bounds_prefix_causality_and_forming_exclusion(self):
        bars=fixture();full=self.observe(bars)
        for end in (24,48,72,96):
            r=self.observe(bars[:end]);known=bars[end-1].closed_at.isoformat()
            self.assertEqual(r['history'],[x for x in full['history'] if x['known_at']<=known])
            for b in r['ranges']:
                later=next(x for x in full['ranges'] if x['id']==b['id'])
                for key in ('high','low','body_high','body_low','slope_per_bar','first_observed_at','checks','metrics'):
                    self.assertEqual(b[key],later[key])
        changed=bars[:-1]+[replace(bars[-1],high=200,close=190)]
        self.assertEqual(self.observe(changed,bars[-2].closed_at),self.observe(bars[:-1]))

    def test_gaps_are_explicit_and_cannot_create_exit_streak(self):
        bars=fixture(48)
        tail=[replace(b,time=b.time+timedelta(days=3)) for b in fixture(56)[48:]]
        r=self.observe(bars+tail)
        for b in r['current']:
            self.assertTrue(b['gaps']);self.assertFalse(b['confirmed'])
            self.assertIn('跨时段间隔内价格覆盖未验证',b['missing'])

    def test_monotonic_and_isolated_spike_are_rejected(self):
        bars=fixture(48)
        trend=[replace(b,open=100+i,close=100.2+i,high=100.6+i,low=99.4+i) for i,b in enumerate(bars)]
        self.assertFalse(candidate(trend)['qualified'])
        bars[30]=replace(bars[30],high=160)
        self.assertFalse(candidate(bars)['checks']['two_sided'])

    def test_channel_mirror_scale_and_two_closed_exit(self):
        bars=fixture(48,.2);r=self.observe(bars)
        self.assertTrue(any(b['shape']=='tilted' for b in r['current']))
        for scale,offset in ((-1,300),(10,500)):
            mirror=self.observe(transformed(bars,scale,offset))
            self.assertEqual([b['checks'] for b in r['current']],[b['checks'] for b in mirror['current']])
            self.assertEqual([b['shape'] for b in r['current']],[b['shape'] for b in mirror['current']])
        for i in range(2):
            b=bars[-1];bars.append(Bar(b.closed_at,130+i,133+i,129+i,132+i,0,3600))
        self.assertFalse(self.observe(bars)['current'])
        self.assertTrue(all(not b['active'] for b in self.observe(bars)['ranges']))

    def test_horizontal_box_is_not_replaced_by_regression_channel(self):
        r=self.observe(fixture(48,.2))
        self.assertEqual({b['shape'] for b in r['current']},{'rectangle','tilted'})
        self.assertGreaterEqual(len([b for b in r['current'] if b['window']==48]),2)
        ids=[b['id'] for b in r['ranges']]
        self.assertEqual(len(ids),len(set(ids)))

    def test_channel_extends_fixed_rails_beyond_initial_physical_extremes(self):
        bars=fixture(80,.2);first=self.observe(bars[:48]);later=self.observe(bars)
        initial=next(b for b in first['current'] if b['window']==48 and b['shape']=='tilted')
        extended=next(b for b in later['ranges'] if b['id']==initial['id'])
        self.assertTrue(extended['active'])
        self.assertEqual(initial['geometry'],extended['geometry'])
        self.assertGreater(extended['last_upper'],initial['observed_high'])
        g=extended['display_geometry'];self.assertEqual(g['frame'][1]['time'],bars[-1].time.isoformat())
        self.assertEqual(g['observed_until'],bars[-1].closed_at.isoformat())
        self.assertAlmostEqual(g['frame'][1]['price'],initial['high']+initial['slope_per_bar']*79)
        self.assertEqual(self.observe(bars,bars[60].closed_at),self.observe(bars[:61]))

    def test_rejecting_wicks_count_but_adjacent_wicks_are_one_visit(self):
        # Upper rejections close below center; lower rejections close above.
        # The intervening non-touch close must rearm each boundary.
        start=datetime(2026,1,1,tzinfo=timezone.utc)
        values=[(99,105,98,99),(99,105,98,99),(99,101,98,99),
                (101,102,95,101),(101,102,95,101),(101,102,99,101)]*4
        bars=[Bar(start+timedelta(hours=i),o,h,l,c,0,3600) for i,(o,h,l,c) in enumerate(values)]
        c=candidate(bars,'horizontal')
        self.assertEqual((c['metrics']['upper_visits'],c['metrics']['lower_visits']),(4,4))
        for event in c['metrics']['edge_tests']:
            b=next(b for b in bars if b.time.isoformat()==event['bar_open_at'])
            self.assertEqual(event['known_at'],b.closed_at.isoformat())
        mirror=candidate(transformed(bars,-1,300),'horizontal')
        self.assertEqual(c['checks'],mirror['checks'])
        self.assertEqual([e['side'] for e in mirror['metrics']['edge_tests']],
                         ['lower' if e['side']=='upper' else 'upper' for e in c['metrics']['edge_tests']])

    def test_native_channel_extension_stops_after_two_closed_departures(self):
        raw=json.loads((Path(__file__).parent/'fixtures/channel_extension_native_h1.json').read_text('utf-8'))['bars']
        bars=[Bar(instant(b['time']),*(b[k] for k in ('open','high','low','close')),b.get('spread',0),3600) for b in raw]
        initial=self.observe(bars[:24]);first=next(b for b in initial['current'] if b['shape']=='tilted' and b['window']==24)
        self.assertEqual(first['first_observed_at'],'2026-09-29T20:00:00+00:00')
        prefix=[b for b in bars if b.closed_at<=instant('2026-09-30T18:00:00+00:00')]
        continuing=next(b for b in self.observe(prefix)['current'] if b['id']==first['id'])
        self.assertTrue(continuing['active']);self.assertEqual(continuing['streak'],1)
        self.assertGreater(continuing['last_upper'],first['observed_high'])
        # The next bar is still forming at 18:00. Its extreme values cannot
        # terminate the channel or move the display endpoint prematurely.
        forming=replace(bars[len(prefix)],close=1,low=1)
        self.assertEqual(self.observe(prefix+[forming],prefix[-1].closed_at),self.observe(prefix))
        ended=next(b for b in self.observe(bars)['ranges'] if b['id']==first['id'])
        self.assertFalse(ended['active']);self.assertEqual(ended['status'],'向下离开结构观察区')
        self.assertEqual(ended['end_at'],'2026-09-30T19:00:00+00:00')
        self.assertEqual(ended['display_geometry']['frame'][1]['time'],'2026-09-30T18:00:00+00:00')
        self.assertEqual(ended['display_geometry']['observed_until'],ended['end_at'])
        for key in ('geometry','high','low','slope_per_bar','metrics','first_observed_at'):
            self.assertEqual(first[key],ended[key])
        self.assertFalse(ended['confirmed']);self.assertFalse(ended['score_included'])

    def test_one_bar_touching_both_edges_cannot_supply_two_tests(self):
        bars=fixture(24)
        bars=[replace(b,high=105,low=95) for b in bars]
        c=candidate(bars,'horizontal')
        self.assertEqual(c['metrics']['edge_tests'],[])
        self.assertFalse(c['checks']['two_sided'])

    def test_native_high_box_is_observed_before_departure_without_future_bars(self):
        raw=json.loads((Path(__file__).parent/'fixtures/high_box_native_m15.json').read_text('utf-8'))['bars']
        bars=[Bar(instant(b['time']),*(b[k] for k in ('open','high','low','close')),0,900) for b in raw]
        cutoff=instant('2026-11-03T05:00:00+00:00');prefix=[b for b in bars if b.closed_at<=cutoff]
        before=self.observe(prefix);later=self.observe(bars)
        high=next(b for b in before['current'] if b['shape']=='rectangle' and b['observed_high']==3970.33)
        self.assertEqual(high['observed_low'],3934.85)
        self.assertEqual(high['first_observed_at'],cutoff.isoformat())
        self.assertEqual(high['metrics']['upper_visits'],2)
        self.assertIn('2026-11-03T02:30:00+00:00',[e['bar_open_at'] for e in high['metrics']['edge_tests']])
        ended=next(b for b in later['ranges'] if b['id']==high['id'])
        self.assertFalse(ended['active']);self.assertEqual(ended['status'],'向下离开结构观察区')
        self.assertEqual(ended['end_at'],'2026-11-03T06:00:00+00:00')
        for key in ('high','low','observed_high','observed_low','checks','metrics','first_observed_at'):
            self.assertEqual(high[key],ended[key])
        self.assertFalse(high['confirmed']);self.assertFalse(high['score_included'])
