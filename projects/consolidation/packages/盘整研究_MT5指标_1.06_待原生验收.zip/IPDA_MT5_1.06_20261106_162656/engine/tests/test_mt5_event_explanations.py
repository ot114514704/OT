"""Native labels must preserve the detector's body/liquidity distinction."""
import unittest
from copy import deepcopy
from dataclasses import replace
from ict_trader.ipda_ranges import phase_evidence
from ict_trader.mt5_bridge import current_summary,shape_record
from tests.test_consolidation import fixture,append,observe
from tests.test_liquidity_reclaim import mirror


def evidence(bars):
    e=phase_evidence(observe(bars)['rows'][-1],bars)
    b=deepcopy(e['range'] or e['ended']);b['active']=bool(e['range'])
    report=dict(label='已确认盘整' if e['range'] else '非盘整',availability='live',event=e['event'],
                known_at=bars[-1].closed_at.isoformat(),range=b)
    return b,report


class NativeEventExplanationTests(unittest.TestCase):
    def test_body_only_reclaim_does_not_borrow_current_or_previous_sweep(self):
        for earlier_sweep in (False,True):
            bars=[replace(b,high=102.2,low=98.6) for b in fixture()]
            if earlier_sweep:bars=append(bars,100,103,99,100)
            bars=append(bars,100,102.1,100,101.9)
            bars=append(bars,101.9,102.1,99,100)
            for data in (bars,mirror(bars)):
                b,r=evidence(data);before=deepcopy(b)
                self.assertEqual(r['event'],'range_reclaimed')
                self.assertEqual(b['sweep_count'],int(earlier_sweep))
                fields=shape_record('M15','local',b).split('\t')
                self.assertIn('·越界收回',fields[21]);self.assertNotIn('·扫荡收回',fields[21])
                self.assertIn('本次收回：越界收回，未证实本次流动性扫荡',fields[23])
                self.assertIn('未证实流动性扫荡',current_summary(r));self.assertEqual(b,before)
                if earlier_sweep:self.assertIn(b['last_sweep']['known_at'],fields[23])

    def test_liquidity_reclaim_has_correct_side_time_and_projection_qualification(self):
        bars=append(fixture(),100,103,99,102);bars=append(bars,100.8,101,99,100)
        for data,side in ((bars,'上侧'),(mirror(bars),'下侧')):
            b,r=evidence(data);f=shape_record('M15','local',b).split('\t')
            self.assertIn('·扫荡收回',f[21]);self.assertIn('本次收回：'+side+'流动性扫荡已确认',f[23])
            self.assertIn(r['known_at'],f[23]);self.assertIn(side+'流动性扫荡收回',current_summary(r))
            projected=dict(b,source_confirmed=True,confirmed=False,source_kind='range')
            f=shape_record('H1','intraday',projected).split('\t')
            self.assertIn('·扫荡收回',f[21]);self.assertIn('不代表 H1 独立确认',f[23])
            companion=current_summary(dict(label='证据不足',availability='live'),r)
            self.assertIn('M15 '+side+'流动性扫荡收回',companion)

    def test_unreclaimed_break_is_pending_then_exit_never_sweep(self):
        bars=append(fixture(),100,103,99,102)
        for data,side in ((bars,'向上'),(mirror(bars),'向下')):
            b,r=evidence(data);f=shape_record('M15','local',b).split('\t')
            self.assertIn('·越界待跟进',f[21]);self.assertIn('不计为已确认扫荡',f[23])
            self.assertIn('冻结实体：',f[23]);self.assertIn('流动性：',f[23])
            self.assertIn(side+'越界外收1根，待跟进',current_summary(r))
            r['availability']='analysis_pending';self.assertNotIn('外收',current_summary(r))
        bars=append(bars,102,105,101.5,104)
        for data,side in ((bars,'向上'),(mirror(bars),'向下')):
            b,r=evidence(data);f=shape_record('M15','local',b).split('\t')
            self.assertIn('·已突破',f[21]);self.assertIn('结束时',f[23])
            self.assertIn('已确认扫荡收回 0 次',f[23])
            self.assertIn(side+'突破退出原区间',current_summary(r))

    def test_gap_does_not_turn_an_unreclaimed_excursion_into_a_sweep(self):
        bars=append(fixture(),100,103,99,102);bars=append(bars,100,101,99,100,gap=15)
        b,r=evidence(bars);f=shape_record('M15','local',b).split('\t')
        self.assertIn('·已中止',f[21]);self.assertIn('结束时上侧刺出仍未确认收回',f[23])
        self.assertIn('数据间隔中止原区间',current_summary(r))
        self.assertNotIn('·扫荡收回',f[21])
