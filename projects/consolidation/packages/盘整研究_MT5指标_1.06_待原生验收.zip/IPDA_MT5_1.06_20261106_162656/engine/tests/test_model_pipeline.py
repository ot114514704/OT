"""Concurrency/ordering checks use synthetic data, never the live terminal."""
import unittest
from concurrent.futures import Future,ThreadPoolExecutor
from copy import deepcopy
import threading
from unittest.mock import Mock,patch
import app
from ict_trader.model_runner import LatestModelRunner
from tests.executor_helpers import InlineExecutor
from tests.test_runtime_contract import LoopComplete
from tests.test_current_consolidation import chart,native_metadata


class DeferredExecutor:
    def __init__(self,first_inline=False):self.calls=[];self.first_inline=first_inline
    def submit(self,fn,*args):
        f=Future();self.calls.append((f,fn,args))
        if self.first_inline and len(self.calls)==1:self.complete(0)
        return f
    def complete(self,index,error=None):
        f,fn,args=self.calls[index]
        if error:f.set_exception(error)
        else:f.set_result(fn(*args))


class ModelPipelineTests(unittest.TestCase):
    def raw(self,value):return {'M15':[dict(closed_at='2026-01-01T01:00:00+00:00',close=value)]}
    def model(self,raw):return {'M15':{**chart(),'marker':raw['M15'][0]['close']}}

    def test_runner_does_not_wait_and_snapshot_cannot_be_mutated_by_later_reads(self):
        executor=DeferredExecutor();runner=LatestModelRunner(executor,self.model,lambda:100)
        raw=self.raw(100);runner.start(raw,'a','native');raw['M15'][0]['close']=900
        self.assertIsNone(runner.take_ready())
        self.assertTrue(runner.metadata()['analysis_running'])
        with self.assertRaises(RuntimeError):runner.start(self.raw(101),'b','native')
        self.assertEqual(len(executor.calls),1)
        executor.complete(0);job,model,error=runner.take_ready()
        self.assertIsNone(error);self.assertEqual(model['M15']['marker'],100)
        self.assertEqual(job.raw['M15'][0]['close'],100);self.assertFalse(runner.metadata()['analysis_running'])

    def run_worker(self,raw_values,executor,step):
        original=deepcopy(app.STATE);seen=[]
        sample=native_metadata(dict(charts={'M15':chart()},quote={'bid':100}))
        samples=[]
        for i,value in enumerate(raw_values):
            if isinstance(value,Exception):samples.append(value)
            else:samples.append((self.raw(value),deepcopy(sample['forming']),{**sample['quote'],'bid':100+i,'ask':100.1+i}))
        def wait(_):
            seen.append(deepcopy(app.STATE));step(len(seen),executor)
            if len(seen)==len(raw_values):raise LoopComplete()
        try:
            app.STATE.clear();app.STATE.update(status='starting',charts={})
            with patch.object(app,'load_seed',return_value=self.raw(100)),patch.object(app,'calculate',side_effect=self.model),patch.object(app,'native',side_effect=samples),patch.object(app,'save_snapshot',Mock()) as save,patch.object(app.time,'sleep',side_effect=wait):
                with self.assertRaises(LoopComplete):app.worker(executor=executor,freeze_store=False)
            return seen,save
        finally:app.STATE.clear();app.STATE.update(original)

    def test_slow_superseded_result_cannot_replace_latest_model_or_enter_cache(self):
        executor=DeferredExecutor(first_inline=True)
        def step(n,e):
            if n==2:e.complete(1) # obsolete 101 result, after latest source is 102
            if n==3:e.complete(2) # compute only latest 103, skipping queued 102
        seen,save=self.run_worker([101,102,103,103],executor,step)
        self.assertEqual([s['quote']['bid'] for s in seen],[100,101,102,103])
        self.assertEqual([s['charts']['M15']['marker'] for s in seen],[100,100,100,103])
        self.assertTrue(all(s['analysis_running'] for s in seen[:3]))
        self.assertFalse(seen[-1]['analysis_running']);self.assertEqual(seen[-1]['analysis_discarded_results'],1)
        self.assertEqual([call[2][0]['M15'][0]['close'] for call in executor.calls],[100,101,103])
        self.assertEqual(save.call_count,1);self.assertEqual(save.call_args.args[0],self.raw(103))

    def test_obsolete_error_is_ignored_and_disconnect_does_not_publish_a_native_job(self):
        executor=DeferredExecutor(first_inline=True)
        def step(n,e):
            if n==1:e.complete(1,RuntimeError('obsolete 101 error'))
            if n==2:e.complete(2)
        seen,save=self.run_worker([101,102,RuntimeError('MT5 offline'),100],executor,step)
        self.assertIsNone(seen[1]['analysis_error'])
        self.assertEqual(seen[2]['status'],'disconnected')
        self.assertEqual(seen[2]['charts']['M15']['marker'],100)
        self.assertEqual(seen[-1]['charts']['M15']['marker'],100)
        self.assertEqual(seen[-1]['analysis_discarded_results'],2)
        save.assert_called_once_with(self.raw(100))

    def test_real_blocked_calculation_allows_multiple_market_reads(self):
        started=threading.Event();release=threading.Event();finished=threading.Event()
        original=deepcopy(app.STATE);sample=native_metadata(dict(charts={'M15':chart()},quote={'bid':100}));seen=[]
        with ThreadPoolExecutor(max_workers=1) as pool:
            class SeedThenThread:
                calls=0
                def submit(inner,fn,*args):
                    inner.calls+=1
                    return InlineExecutor().submit(fn,*args) if inner.calls==1 else pool.submit(fn,*args)
            def calculate(raw):
                if raw['M15'][0]['close']==101:
                    started.set()
                    if not release.wait(3):raise TimeoutError('test model never released')
                    finished.set()
                return self.model(raw)
            native_calls=0
            def native():
                nonlocal native_calls
                native_calls+=1
                return self.raw(101),deepcopy(sample['forming']),{**sample['quote'],'bid':100+native_calls,'ask':100.1+native_calls}
            def wait(_):
                self.assertTrue(started.wait(1));seen.append(deepcopy(app.STATE))
                if len(seen)==3:
                    release.set();self.assertTrue(finished.wait(1))
                if len(seen)==4:raise LoopComplete()
            try:
                app.STATE.clear();app.STATE.update(status='starting',charts={})
                with patch.object(app,'load_seed',return_value=self.raw(100)),patch.object(app,'calculate',side_effect=calculate),patch.object(app,'native',side_effect=native),patch.object(app,'save_snapshot'),patch.object(app.time,'sleep',side_effect=wait):
                    with self.assertRaises(LoopComplete):app.worker(executor=SeedThenThread(),freeze_store=False)
                self.assertEqual(native_calls,4)
                self.assertEqual([s['quote']['bid'] for s in seen],[101,102,103,104])
                self.assertEqual([s['charts']['M15']['marker'] for s in seen[:3]],[100,100,100])
                self.assertEqual(seen[-1]['charts']['M15']['marker'],101)
            finally:
                release.set();app.STATE.clear();app.STATE.update(original)
