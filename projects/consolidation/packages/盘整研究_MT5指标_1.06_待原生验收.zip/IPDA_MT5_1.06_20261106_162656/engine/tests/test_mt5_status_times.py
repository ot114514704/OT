from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import unittest

from ict_trader.mt5_bridge import current_summary, closed_label_stamp, MT5Bridge


def reports():
    return {'H1':dict(label='已确认盘整',known_at='2026-11-06T08:00:00+00:00',availability='live'),
            'M15':dict(label='盘整候选',known_at='2026-11-06T08:30:00+00:00',availability='live')}


class StatusTimeTests(unittest.TestCase):
    def test_companion_has_its_own_closed_time_and_native_suffix_is_named(self):
        r=reports();before=deepcopy(r);value=current_summary(r['H1'],r['M15'])
        self.assertTrue(value.startswith('H1 已确认盘整'))
        self.assertIn('M15 盘整候选 · 收盘 11-06 08:30',value)
        self.assertTrue(value.endswith('H1收盘'));self.assertEqual(r,before)
        # Same snapshot on an M15 chart has no H1 alias or mixed-period suffix.
        self.assertEqual(current_summary(r['M15']),'盘整候选')

    def test_unavailable_companion_does_not_keep_current_confirmation_or_observation(self):
        r=reports();m=r['M15'];m.update(label='已确认盘整',event='range_confirmed',
            body_candidate_observation={'code':'above_threshold'},macro_context={'verdict':'confirmed'})
        for state,text in [('analysis_pending','新收盘重算中'),('disconnected','MT5断连'),('stale','数据陈旧'),
                           ('quote_idle','暂无新报价'),('bars_lagging','K线数据滞后'),('source_mismatch','行情来源不匹配')]:
            with self.subTest(state=state):
                m['availability']=state;value=current_summary(r['H1'],m)
                self.assertIn('H1 已确认盘整',value)
                self.assertIn('M15 '+text+'（上次已确认盘整） · 收盘 11-06 08:30',value)
                self.assertNotIn('M15 已确认盘整',value)
                self.assertNotIn('首次确认',value);self.assertNotIn('末柱',value)
                self.assertNotIn('外层盘整有效',current_summary(m))

    def test_each_period_recovers_independently_and_historical_primary_is_explicit(self):
        r=reports();r['H1']['availability']='analysis_pending'
        value=current_summary(r['H1'],r['M15'])
        self.assertIn('H1 新收盘重算中（上次已确认盘整）',value)
        self.assertIn('M15 盘整候选 · 收盘 11-06 08:30',value)
        r['H1']['availability']='live';r['M15']['known_at']='2026-11-06T08:45:00+00:00'
        value=current_summary(r['H1'],r['M15'])
        self.assertNotIn('上次',value);self.assertIn('08:45',value);self.assertNotIn('08:30',value)

    def test_missing_or_invalid_stamp_is_not_replaced_with_host_or_other_period_time(self):
        for value in (None,'invalid','2026-11-06T08:30:00',5):
            self.assertEqual(closed_label_stamp({'known_at':value}),'时刻缺失')
        # Preserve serialized clock labels as the native indicator does.
        self.assertEqual(closed_label_stamp({'known_at':'2026-11-06T16:30:00+08:00'}),'11-06 16:30')
        self.assertEqual(closed_label_stamp({}),'时刻缺失')

    def test_compatible_heartbeat_carries_m15_time_without_changing_model_or_history(self):
        r=reports()
        with TemporaryDirectory() as folder,patch('ict_trader.mt5_bridge.live_reports',return_value=r):
            bridge=MT5Bridge(folder);state=dict(status='connected',model_revision='same',charts={})
            bridge.update(state,100);shape=Path(folder,'shapes.tsv').read_bytes()
            r['M15'].update(availability='quote_idle',known_at='2026-11-06T08:45:00+00:00')
            bridge.update(state,102)
            fields=Path(folder,'heartbeat.tsv').read_text(encoding='utf-8').strip().split('\t')
            self.assertEqual(len(fields),13);self.assertEqual(fields[3],'same')
            self.assertEqual(fields[5],'live');self.assertEqual(fields[8],'quote_idle')
            self.assertEqual(fields[7],r['H1']['known_at']);self.assertEqual(fields[10],r['M15']['known_at'])
            self.assertIn('M15 暂无新报价（上次盘整候选） · 收盘 11-06 08:45',fields[6])
            self.assertEqual(Path(folder,'shapes.tsv').read_bytes(),shape)


if __name__=='__main__':unittest.main()
