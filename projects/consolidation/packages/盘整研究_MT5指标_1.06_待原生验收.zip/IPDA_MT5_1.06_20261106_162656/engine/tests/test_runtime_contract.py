"""Adapter/worker contract checks with synthetic quotes; no terminal or backtest."""
import unittest
import json
from unittest.mock import patch,Mock
from types import SimpleNamespace
from copy import deepcopy
from tempfile import TemporaryDirectory
from pathlib import Path
import app
from tests.executor_helpers import InlineExecutor


class LoopComplete(Exception):pass


class RuntimeContractTests(unittest.TestCase):
    def test_invalid_quote_sides_and_times_are_not_serialized_as_live_quotes(self):
        valid=dict(bid=100.,ask=100.08,time=1767225600)
        for changes in ({'ask':float('nan')},{'ask':float('inf')},{'bid':float('nan')},
                        {'ask':99.},{'bid':0},{'time':0},{'time':float('inf')},
                        {'time':1767225600.5},{'time':1e30},{'ask':None}):
            with self.subTest(changes=changes):
                self.assertIsNone(app.market_quote(SimpleNamespace(**{**valid,**changes})))
        self.assertIsNone(app.market_quote(None));self.assertIsNone(app.market_quote(SimpleNamespace(bid=100)))
        result=app.market_quote(SimpleNamespace(**valid))
        self.assertEqual(result['raw_epoch'],valid['time'])
        self.assertEqual(json.loads(json.dumps(result,allow_nan=False)),result)

    def test_invalid_ask_retains_closed_bars_and_invalid_point_is_rejected(self):
        def rates(symbol,tf,start,count):
            return [dict(time=1767225600+i*(3600 if tf==1 else 900),open=100,high=102,low=98,close=100,spread=8) for i in range(41)]
        mt=SimpleNamespace(TIMEFRAME_H1=1,TIMEFRAME_M15=2,initialize=lambda **kw:True,shutdown=Mock(),
            symbol_select=lambda s,v:s=='XAUUSD',symbol_info=lambda s:SimpleNamespace(point=.01,name='XAUUSD'),
            account_info=lambda:SimpleNamespace(company='TradeMax Global Limited',server='TradeMaxGlobal-Live'),
            symbol_info_tick=lambda s:SimpleNamespace(bid=100.,ask=float('nan'),time=1767225600),copy_rates_from_pos=rates)
        with patch.dict('sys.modules',{'MetaTrader5':mt}):
            reading=app.native();raw,forming,quote=reading
            self.assertIsNone(quote);self.assertEqual(len(raw['M15']),40);self.assertTrue(forming['H1']['forming'])
            self.assertEqual(reading.market_source['status'],'verified')
            for point in (0,-.01,float('nan'),float('inf')):
                mt.symbol_info=lambda s:SimpleNamespace(point=point)
                with self.subTest(point=point),self.assertRaisesRegex(RuntimeError,'最小报价单位无效'):app.native()
        self.assertEqual(mt.shutdown.call_count,5)

    def test_wrong_source_is_rejected_before_reading_price_history(self):
        from ict_trader.market_source import MarketSourceError
        mt=SimpleNamespace(initialize=lambda **kw:True,shutdown=Mock(),symbol_select=lambda s,v:True,
            symbol_info=lambda s:SimpleNamespace(point=.01,name='XAUUSD'),symbol_info_tick=lambda s:None,
            account_info=lambda:SimpleNamespace(company='Other Broker',server='Other-Live'),copy_rates_from_pos=Mock())
        with patch.dict('sys.modules',{'MetaTrader5':mt}),self.assertRaises(MarketSourceError):app.native()
        mt.copy_rates_from_pos.assert_not_called();mt.shutdown.assert_called_once()

    def test_mt5_forming_changes_do_not_enter_closed_data(self):
        def rates(symbol,tf,start,count):
            return [dict(time=1767225600+i*(3600 if tf==1 else 900),open=100,high=102,low=98,close=100,spread=8) for i in range(41)]
        mt=SimpleNamespace(TIMEFRAME_H1=1,TIMEFRAME_M15=2,initialize=lambda **kw:True,shutdown=Mock(),
            symbol_select=lambda s,v:s=='XAUUSD',symbol_info=lambda s:SimpleNamespace(point=.01,name='XAUUSD'),
            account_info=lambda:SimpleNamespace(company='TradeMax Global Limited',server='TradeMaxGlobal-Live'),
            symbol_info_tick=lambda s:SimpleNamespace(bid=100.,ask=100.08,time=1767225600),copy_rates_from_pos=rates)
        with patch.dict('sys.modules',{'MetaTrader5':mt}):
            raw,forming,quote=app.native()
            def changed(*args):
                result=rates(*args);result[-1].update(close=101,high=105);return result
            mt.copy_rates_from_pos=changed
            updated,forming2,_=app.native()
        self.assertEqual(raw,updated)
        for p in ('H1','M15'):
            self.assertEqual(len(raw[p]),40);self.assertTrue(forming[p]['forming'])
            self.assertNotEqual(forming[p]['close'],forming2[p]['close'])
            self.assertAlmostEqual(raw[p][0]['spread'],.08)
        self.assertEqual(mt.shutdown.call_count,2)

    def test_worker_recalculates_only_when_closed_data_changes(self):
        seed={'H1':[{'close':100}],'M15':[{'close':100}]};changed=deepcopy(seed);changed['M15'][0]['close']=101
        samples=[(seed,{'M15':{'close':102}},{'bid':102}),(seed,{'M15':{'close':103}},{'bid':103}),
                 (changed,{'M15':{'close':104}},{'bid':104})]
        original=deepcopy(app.STATE)
        try:
            with TemporaryDirectory() as folder:
                root=Path(folder);(root/'data').mkdir()
                calculate=Mock(return_value={'H1':{},'M15':{}})
                with patch.object(app,'ROOT',root),patch.object(app,'load_seed',return_value=seed),patch.object(app,'native',side_effect=samples),patch.object(app,'calculate',calculate),patch.object(app.time,'sleep',side_effect=[None,None,LoopComplete]):
                    with self.assertRaises(LoopComplete):app.worker(executor=InlineExecutor())
                self.assertEqual(calculate.call_count,2) # unchanged native bars reuse the seed model
                self.assertEqual(calculate.call_args_list[-1].args[0],changed)
                self.assertEqual(app.STATE['forming']['M15']['close'],104)
        finally:
            app.STATE.clear();app.STATE.update(original)

class ResponsePayloadTests(unittest.TestCase):
    def test_cached_native_receipt_cannot_certify_a_new_model_before_export_or_reload(self):
        bridge=dict(enabled=True,model_revision='old',sequence=20,updated_at=100,
                    indicator=dict(status='attached',charts=[dict(status='attached',model_revision='old',age_seconds=1)]))
        state=dict(status='connected',charts={},model_revision='new',mt5_bridge=bridge)
        original=deepcopy(state)
        for full in (True,False):
            result=app.response_payload(state,101,full)['mt5_bridge']
            self.assertEqual(result['expected_model_revision'],'new')
            self.assertEqual(result['indicator']['status'],'unverified')
            self.assertEqual(result['indicator']['charts'][0]['status'],'model_pending')
        self.assertEqual(state,original)
        bridge['model_revision']='new' # Export alone is insufficient.
        self.assertEqual(app.response_payload(state,101)['mt5_bridge']['indicator']['status'],'unverified')
        bridge['indicator']['charts'][0]['model_revision']='new'
        self.assertEqual(app.response_payload(state,101)['mt5_bridge']['indicator']['status'],'attached')
        state['model_revision']=None
        self.assertEqual(app.response_payload(state,101)['mt5_bridge']['indicator']['status'],'unverified')

    def test_receipt_age_includes_time_since_cached_export_and_never_promotes_unverified(self):
        state=dict(status='connected',charts={},model_revision='r',mt5_bridge=dict(enabled=True,
            model_revision='r',updated_at=100,indicator=dict(status='attached',charts=[
                dict(status='attached',model_revision='r',age_seconds=14),
                dict(status='model_pending',model_revision='r',age_seconds=0)])))
        result=app.response_payload(state,102)['mt5_bridge']['indicator']
        self.assertEqual(result['status'],'unverified')
        self.assertEqual(result['charts'][0]['status'],'stale_receipt')
        self.assertEqual(result['charts'][0]['age_seconds'],16)
        self.assertEqual(result['charts'][1]['status'],'model_pending')
        state['mt5_bridge']['updated_at']=200
        self.assertEqual(app.response_payload(state,102)['mt5_bridge']['indicator']['status'],'unverified')

    def test_light_snapshot_matches_full_current_decisions_without_chart_history(self):
        from tests.test_current_consolidation import chart
        state=dict(status='connected',polled_at=100,last_tick_change_at=100,quote={'bid':100},charts={'M15':chart()},model_revision='revision-a')
        original=deepcopy(state)
        full=app.response_payload(state,101,True);light=app.response_payload(state,101,False)
        self.assertNotIn('charts',light);self.assertTrue(light['has_charts'])
        for key in ('current_consolidation','model_revision','server_now','quote','status'):self.assertEqual(full[key],light[key])
        self.assertEqual(state,original)

    def test_startup_without_model_is_explicit(self):
        light=app.response_payload(dict(status='starting',charts={},model_revision=None),100,False)
        self.assertFalse(light['has_charts']);self.assertEqual(light['current_consolidation'],{})
