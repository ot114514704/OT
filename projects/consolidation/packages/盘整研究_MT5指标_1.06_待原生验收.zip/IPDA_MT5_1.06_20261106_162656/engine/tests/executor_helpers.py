from concurrent.futures import Future


class InlineExecutor:
    """Deterministic completed futures for failure-isolation contract tests."""
    def submit(self,fn,*args):
        future=Future()
        try:future.set_result(fn(*args))
        except Exception as exc:future.set_exception(exc)
        return future
