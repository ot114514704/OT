// Exercise the verdict cards with active-candidate evidence, without a browser.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
function element(){return {dataset:{},children:[],textContent:'',classList:{add(){}},
 append(...items){this.children.push(...items)},replaceChildren(){this.children=[]}}}
const root=element(),input=fs.readFileSync(process.argv[2],'utf8');
const context=vm.createContext({input,performance:{now:()=>1000},document:{
 getElementById:id=>id==='currentVerdicts'?root:element(),createElement:element}});
vm.runInContext(fs.readFileSync('ui/app.js','utf8').split('async function refresh()')[0],context);
vm.runInContext('state=JSON.parse(input);receivedAt=1000;renderCurrentVerdicts();',context);
const texts=node=>[node.textContent,...node.children.flatMap(texts)].join('\n');
let output=texts(root);
assert.ok(output.includes('上沿外已收盘 1/2 根'));
assert.ok(output.includes('通道候选：')&&output.includes('收敛/楔形候选：'));
assert.ok(output.includes('末柱在候选上沿越界阈值外'));
assert.ok(output.includes('本柱轨道 96.00—106.00'));
vm.runInContext('state.current_consolidation.M15.candidate_window=24;state.current_consolidation.M15.score_window=12;renderCurrentVerdicts();',context);
output=texts(root);assert.ok(output.includes('24根已收盘K线'));
assert.ok(output.includes('评分另据原实体规则的12根窗口'));
vm.runInContext("state.current_consolidation.M15.availability='stale';renderCurrentVerdicts();",context);
output=texts(root);assert.ok(output.includes('当前判定不可用'));
assert.ok(!output.includes('末柱在候选上沿越界阈值外'));
console.log(JSON.stringify({passed:true,scope:'Synthetic verdict-card DOM execution; not visual or native live-signal acceptance'}));
