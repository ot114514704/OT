import unittest
from copy import deepcopy
from ict_trader.retracement_score import score_retracement,WEIGHTS


def fixture():
    keys=[x[0] for x in WEIGHTS]
    row=dict(state='retracement_active',end_reason=None,checks={k:True for k in keys},episode={'expansion':{'known_at':'prior'},'pd_contacts':[{'kind':'FVG','low':99,'high':101}]})
    ev=dict(protection_source='prior_validated_H1_channel',reference_direction=1,current_close=102,patterns={'sfp_cisd':True})
    return row,ev


class RetracementScoreTests(unittest.TestCase):
    def test_weights_fixed_and_unobserved_data_never_filled(self):
        r,e=fixture();s=score_retracement(r,e)
        self.assertEqual(sum(x['weight'] for x in s['components']),100)
        self.assertEqual(s['score'],90);self.assertEqual(s['unknown_weight'],10)
        self.assertTrue(s['end_sequence_observed']);self.assertFalse(s['entry_qualified']);self.assertIsNone(s['probability'])

    def test_no_pullback_no_background_points(self):
        r,e=fixture();r['episode']=None
        s=score_retracement(r,e);self.assertEqual(s['score'],0);self.assertEqual(s['stage'],'尚未形成回调')

    def test_broken_structure_and_interruptions_override_high_fit(self):
        r,e=fixture();r['checks']['structure_intact']=False
        s=score_retracement(r,e);self.assertEqual(s['score'],0);self.assertEqual(s['eligibility'],'contradicted');self.assertFalse(s['end_sequence_observed'])
        for reason in ('data_gap','parent_changed','consolidation'):
            r,e=fixture();r['end_reason']=reason
            s=score_retracement(r,e);self.assertEqual(s['score'],0);self.assertEqual(s['eligibility'],'interrupted')

    def test_ending_requires_ordered_sequence_not_total_score(self):
        r,e=fixture();e['patterns']['sfp_cisd']=False
        s=score_retracement(r,e);self.assertEqual(s['score'],85);self.assertFalse(s['end_sequence_observed']);self.assertEqual(s['stage'],'回调观察中')
        r['state']='resumed_without_full_sequence'
        self.assertIn('缺失',score_retracement(r,e)['stage'])

    def test_pd_hold_requires_contact_and_current_close(self):
        r,e=fixture();r['episode']['pd_contacts']=[]
        s=score_retracement(r,e);self.assertFalse(s['end_sequence_observed']);self.assertEqual(next(x for x in s['components'] if x['key']=='pd_respected')['status'],'unknown')
        r,e=fixture();e['current_close']=98
        s=score_retracement(r,e);self.assertFalse(s['end_sequence_observed']);self.assertEqual(next(x for x in s['components'] if x['key']=='pd_respected')['points'],0)

    def test_proxy_and_ob_are_discounted_and_input_unchanged(self):
        r,e=fixture();e['protection_source']='native_frozen_origin_proxy';r['episode']['pd_contacts'][0]['kind']='OB_proxy'
        before=deepcopy((r,e));s=score_retracement(r,e)
        self.assertEqual(next(x for x in s['components'] if x['key']=='structure_intact')['points'],12)
        self.assertEqual(next(x for x in s['components'] if x['key']=='pd_contact')['points'],5)
        self.assertEqual((r,e),before)
