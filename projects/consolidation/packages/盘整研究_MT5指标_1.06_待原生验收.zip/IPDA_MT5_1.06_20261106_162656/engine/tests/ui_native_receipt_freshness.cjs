// Execute the production native-chart status renderer with cached API receipts.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(process.argv[2]||'ui/app.js','utf8');
const root={textContent:''};let now=1000;
const context=vm.createContext({performance:{now:()=>now},document:{getElementById:()=>root}});
vm.runInContext(source.split('async function refresh()')[0],context);
const run=code=>vm.runInContext(code,context);
const receipt=(period,age)=>({status:'attached',model_revision:'r',period,version:'1.05',age_seconds:age,auto_scroll:false});
const base=()=>({server_now:1000,model_revision:'r',mt5_bridge:{enabled:true,updated_at:1000,model_revision:'r',
 indicator:{status:'attached',charts:[receipt('H1',14)]}}});
function load(value){now=1000;context.input=JSON.stringify(value);run('state=JSON.parse(input);receivedAt=1000;networkDown=false;renderNativeChartStatus()');}
function render(){run('renderNativeChartStatus()');return root.textContent;}
function loaded(period){assert.ok(root.textContent.includes(period+' · v1.05'),root.textContent);}
function unverified(){assert.ok(!root.textContent.includes('已加载同版模型'),root.textContent);}
load(base());loaded('H1');now=2000;render();loaded('H1');
now=2001;render();unverified(); // 14 seconds on server + 1.001 seconds in browser.
let fixture=base();fixture.mt5_bridge.indicator.charts.push(receipt('M15',1));load(fixture);
now=2001;render();loaded('M15');assert.ok(!root.textContent.includes('H1 · v1.05'));
const before=run('JSON.stringify(state)');now=16000;render();unverified();assert.equal(run('JSON.stringify(state)'),before);
load(base());run('networkDown=true');render();unverified();run('networkDown=false');render();loaded('H1');
now=5000;render();unverified();run('receivedAt=performance.now();state.mt5_bridge.indicator.charts[0].age_seconds=0');render();loaded('H1');
// A recent chart receipt cannot extend an expired bridge's freshness.
fixture=base();fixture.mt5_bridge.updated_at=986;fixture.mt5_bridge.indicator.charts[0].age_seconds=0;
load(fixture);now=2000;render();loaded('H1');now=2001;render();unverified();
fixture=base();fixture.mt5_bridge.updated_at=1005;fixture.mt5_bridge.indicator.charts[0].age_seconds=0;
load(fixture);loaded('H1');now=16000;render();loaded('H1');now=16001;render();unverified();
const bad=[
 ['missing receipt age','delete state.mt5_bridge.indicator.charts[0].age_seconds'],
 ['negative receipt age','state.mt5_bridge.indicator.charts[0].age_seconds=-1'],
 ['non-numeric receipt age','state.mt5_bridge.indicator.charts[0].age_seconds="0"'],
 ['non-finite receipt age','state.mt5_bridge.indicator.charts[0].age_seconds=NaN'],
 ['missing server time','delete state.server_now'],
 ['missing export time','delete state.mt5_bridge.updated_at'],
 ['non-finite server time','state.server_now=Infinity'],
 ['future export beyond tolerance','state.mt5_bridge.updated_at=1006'],
 ['invalid client receipt time','receivedAt=NaN'],
 ['client clock reversal','receivedAt=2000'],
 ['new API model before export','state.model_revision="next"'],
 ['new export before chart','state.mt5_bridge.model_revision="next"'],
 ['chart still old','state.mt5_bridge.indicator.charts[0].model_revision="old"'],
 ['pending native redraw','state.mt5_bridge.indicator.charts[0].status="model_pending"']
];
for(const [name,mutation] of bad){load(base());run(mutation);render();assert.ok(!root.textContent.includes('已加载同版模型'),name+': '+root.textContent);}
load(base());run("state.mt5_bridge.indicator={status:'awaiting_indicator',charts:[]}");render();assert.ok(root.textContent.includes('尚未收到'));
console.log(JSON.stringify({passed:true,invalid_cases:bad.length,scope:'Actual production status renderer: per-chart receipt age plus client elapsed time, bridge clock validity, mixed periods, version alignment, loss and recovery. No synthetic production feed or physical UI acceptance.'}));
