import unittest
from dataclasses import replace
from copy import deepcopy
from ict_trader.ipda_ranges import observe_ranges,PARAMETERS as LOCAL_PARAMETERS
from ict_trader.macro_consolidation import analyze_macro,PARAMETERS
from tests.test_consolidation import fixture,append,observe
from tests.test_consolidation_invariants import transformed


def base():
    bars=fixture()
    # The outer wick boundary leaves room beyond the strong body balance.
    bars[0]=replace(bars[0],high=103)
    for i in range(12):bars=append(bars,100.4 if i%2 else 99.4,101.5,98.5,100.5 if i%2 else 99.5)
    return bars


def outer(bars):return observe_ranges(bars,bars[-1].closed_at,parameters=PARAMETERS,level='macro',breakout_basis='liquidity')


class MacroConsolidationTests(unittest.TestCase):
    def test_internal_local_break_does_not_end_outer_balance(self):
        bars=base();frozen=deepcopy(outer(bars)['rows'][-1]['active'])
        self.assertIsNotNone(frozen)
        bars=append(bars,100.5,102,100.4,101.8)
        bars=append(bars,101.8,102,101.7,101.8)
        bars=append(bars,101.8,102,101.7,101.8)
        self.assertEqual(observe(bars)['rows'][-1]['event'],'breakout_confirmed')
        outer_row=outer(bars)['rows'][-1]
        self.assertIsNotNone(outer_row['active']);self.assertEqual(outer_row['event'],'range_held')
        self.assertEqual(outer_row['active']['liquidity_hi'],frozen['liquidity_hi'])
        bars=append(bars,102.3,104.2,102.2,104);bars=append(bars,104,105.5,103.8,105)
        self.assertEqual(outer(bars)['rows'][-1]['event'],'breakout_confirmed')

    def test_outer_prefix_mirror_freeze_and_gap(self):
        bars=base();bars=append(bars,100,104,99,100)
        bars=append(bars,100,101,99,100,gap=15)
        result=outer(bars)
        self.assertEqual(result['rows'][-1]['event'],'data_gap')
        for end in range(1,len(bars)+1):self.assertEqual(outer(bars[:end])['rows'],result['rows'][:end])
        mirror=outer(transformed(bars,-1,300))
        self.assertEqual([r['event'] for r in result['rows']],[r['event'] for r in mirror['rows']])
        self.assertEqual(result['rows'][-2]['sweep'],'upper');self.assertEqual(mirror['rows'][-2]['sweep'],'lower')
        self.assertEqual(LOCAL_PARAMETERS['windows'],[12,24])

    def test_outer_confirmation_is_not_backdated_to_formation_start(self):
        bars=base();macro=analyze_macro(bars)
        self.assertEqual(macro['current']['verdict'],'confirmed')
        box=macro['ranges'][0]
        self.assertEqual(box['observed_from'],bars[0].time.isoformat())
        self.assertEqual(box['known_at'],bars[23].closed_at.isoformat())
        self.assertNotEqual(analyze_macro(bars[:23])['current']['verdict'],'confirmed')
        self.assertEqual(box['breakout_basis'],'liquidity');self.assertEqual(box['level'],'macro')
        fit=box['score'];self.assertEqual(sum(c['weight'] for c in fit['components']),100)
        self.assertEqual(fit['unknown_weight'],20);self.assertEqual(fit['score'],80)
