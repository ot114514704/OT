"""Inject independent failures; never disconnect the real terminal or service."""
import unittest
from copy import deepcopy
from unittest.mock import patch,Mock
import app
from tests.test_runtime_contract import LoopComplete
from tests.test_current_consolidation import chart,native_metadata
from tests.executor_helpers import InlineExecutor


class WorkerFailureTests(unittest.TestCase):
    def test_wrong_source_preserves_model_and_cache_then_recovers(self):
        from ict_trader.market_source import MarketSourceError
        raw={'M15':[{'closed_at':'2026-01-01T01:00:00+00:00','close':100}]}
        sample=native_metadata(dict(charts={'M15':chart()},quote={'bid':100}))
        calc=Mock(return_value={'M15':chart()});save=Mock()
        source=dict(status='source_mismatch',company='Other Broker',server='Other-Live',symbol='XAUUSD',reason='source mismatch')
        a,b=self.run_worker(calc,native=[MarketSourceError(source),(raw,sample['forming'],sample['quote'])],save=save)
        self.assertEqual(a['status'],'source_mismatch');self.assertEqual(a['charts'],{'M15':chart()})
        r=app.response_payload(a,100)['current_consolidation']['M15']
        self.assertEqual(r['availability'],'source_mismatch');self.assertFalse(r['actionable_current'])
        self.assertIsNone(r['forming_observation'])
        self.assertEqual(b['status'],'connected');self.assertEqual(b['market_source']['status'],'verified')
        self.assertEqual(calc.call_count,1);save.assert_called_once()

    def run_worker(self,calculate,native=None,save=None,seed_error=None,iterations=2,freeze_store=False):
        original=deepcopy(app.STATE);seen=[]
        raw={'M15':[{'closed_at':'2026-01-01T01:00:00+00:00','close':100}]}
        sample=native_metadata(dict(charts={'M15':chart()},quote={'bid':100}))
        samples=native or [(raw,sample['forming'],sample['quote'])]*2
        def step(_):
            seen.append(deepcopy(app.STATE))
            if len(seen)==iterations:raise LoopComplete()
        try:
            app.STATE.clear();app.STATE.update(status='starting',charts={})
            with patch.object(app,'load_seed',side_effect=seed_error,return_value=raw),patch.object(app,'native',side_effect=samples),patch.object(app,'calculate',calculate),patch.object(app,'save_snapshot',save or Mock()),patch.object(app.time,'sleep',side_effect=step):
                with self.assertRaises(LoopComplete):app.worker(executor=InlineExecutor(),freeze_store=freeze_store)
            return seen
        finally:
            app.STATE.clear();app.STATE.update(original)

    def test_analysis_failure_keeps_quotes_and_previous_model_then_retries(self):
        old={'M15':chart()};new=deepcopy(old);new['M15']['marker']='new'
        calculate=Mock(side_effect=[old,RuntimeError('calculation failed'),new])
        sample=native_metadata(dict(charts={'M15':chart()},quote={'bid':100}))
        updated={'M15':[{'closed_at':'2026-01-01T01:00:00+00:00','close':101}]}
        a,b=self.run_worker(calculate,native=[(updated,sample['forming'],sample['quote'])]*2)
        self.assertEqual(a['status'],'connected');self.assertEqual(a['charts'],old)
        self.assertEqual(a['analysis_error'],'calculation failed')
        r=app.response_payload(a,a['polled_at']+1)['current_consolidation']['M15']
        self.assertEqual(r['availability'],'analysis_error');self.assertFalse(r['actionable_current'])
        self.assertIsNone(b['analysis_error']);self.assertEqual(b['charts'],new)
        self.assertEqual(calculate.call_count,3)

    def test_cache_failure_retries_without_recalculating_or_losing_live_verdict(self):
        calculate=Mock(return_value={'M15':chart()});save=Mock(side_effect=[OSError('disk full'),None])
        a,b=self.run_worker(calculate,save=save)
        self.assertEqual(a['status'],'connected');self.assertEqual(a['cache_error'],'disk full')
        self.assertIsNone(a['analysis_error']);self.assertIsNone(b['cache_error'])
        r=app.response_payload(a,a['polled_at']+1)['current_consolidation']['M15']
        self.assertEqual(r['availability'],'live');self.assertTrue(r['actionable_current'])
        self.assertEqual(calculate.call_count,1);self.assertEqual(save.call_count,2)
        self.assertEqual(a['model_revision'],b['model_revision'])

    def test_transport_failure_does_not_mask_or_erase_analysis_error(self):
        calculate=Mock(side_effect=RuntimeError('seed failed'))
        a,b=self.run_worker(calculate,native=[RuntimeError('MT5 unavailable')]*2)
        self.assertEqual(a['status'],'disconnected');self.assertEqual(a['read_error'],'MT5 unavailable')
        state=native_metadata(dict(status='disconnected',analysis_error='earlier model error',charts={'M15':chart()},quote={'bid':100}))
        r=app.response_payload(state,101)['current_consolidation']['M15']
        self.assertEqual(r['availability'],'disconnected');self.assertFalse(r['actionable_current'])

    def test_bad_seed_cannot_prevent_recovery_from_native_data(self):
        calculate=Mock(return_value={'M15':chart()})
        a,b=self.run_worker(calculate,seed_error=ValueError('invalid cache'))
        self.assertEqual(a['status'],'connected');self.assertIsNone(a['analysis_error'])
        self.assertEqual(calculate.call_count,1)

    def test_revision_is_pending_during_recompute_and_explicit_after_success(self):
        raw={'M15':[{'closed_at':'2026-01-01T01:00:00+00:00','close':100}]};changed=deepcopy(raw);changed['M15'][0]['close']=101
        sample=native_metadata(dict(charts={'M15':chart()},quote={'bid':100}));captured=[]
        def recompute(_):
            captured.append(deepcopy(app.STATE))
            self.assertTrue(app.STATE['data_revision_pending'])
            report=app.response_payload(app.STATE,app.STATE['polled_at']+1)['current_consolidation']['M15']
            self.assertEqual(report['availability'],'analysis_pending')
            return {'M15':chart()}
        calls=0
        def calculate(data):
            nonlocal calls
            calls+=1
            return recompute(data) if calls==2 else {'M15':chart()}
        samples=[(r,sample['forming'],sample['quote']) for r in (raw,changed)]
        a,b=self.run_worker(Mock(side_effect=calculate),native=samples)
        self.assertEqual(len(captured),1);self.assertFalse(b['data_revision_pending'])
        self.assertEqual(b['last_data_revision']['count'],1)
        self.assertEqual(b['last_data_revision']['model_revision'],b['model_revision'])

    def test_failed_revision_reverting_to_accepted_source_clears_obsolete_error(self):
        raw={'M15':[{'closed_at':'2026-01-01T01:00:00+00:00','close':100}]};changed=deepcopy(raw);changed['M15'][0]['close']=101
        sample=native_metadata(dict(charts={'M15':chart()},quote={'bid':100}))
        calc=Mock(side_effect=[{'M15':chart()},RuntimeError('bad revised model')])
        seen=self.run_worker(calc,native=[(r,sample['forming'],sample['quote']) for r in (raw,changed,raw)],iterations=3)
        self.assertEqual(seen[1]['analysis_error'],'bad revised model')
        self.assertIsNone(seen[2]['analysis_error']);self.assertFalse(seen[2]['data_revision_pending'])
        self.assertEqual(calc.call_count,2);self.assertNotIn('last_data_revision',seen[2])

    def test_freeze_guard_rejects_model_without_stopping_quotes_or_overwriting_cache(self):
        old={'M15':chart()};new=deepcopy(old);new['M15']['marker']='should never publish'
        calc=Mock(side_effect=[old,new]);save=Mock();ledger=Mock()
        ledger.inspect.side_effect=[dict(passed=True,issues=[]),dict(passed=False,issues=[{'code':'unexplained_frozen_change'}])]
        ledger.public.side_effect=lambda r:r
        sample=native_metadata(dict(charts=old,quote={'bid':100}))
        raw={'M15':[{'closed_at':'2026-01-01T01:00:00+00:00','close':101}]}
        seen=self.run_worker(calc,native=[(raw,sample['forming'],sample['quote'])],save=save,iterations=1,freeze_store=ledger)[0]
        self.assertEqual(seen['status'],'connected');self.assertEqual(seen['quote'],sample['quote'])
        self.assertEqual(seen['charts'],old);self.assertFalse(seen['freeze_integrity']['passed'])
        self.assertIn('冻结证据一致性校验失败',seen['analysis_error']);save.assert_not_called();ledger.persist.assert_not_called()

    def test_freeze_record_write_failure_keeps_quotes_and_retries_without_recompute(self):
        calc=Mock(return_value={'M15':chart()});ledger=Mock()
        ledger.inspect.return_value=dict(passed=True,issues=[])
        ledger.public.side_effect=lambda r:r
        ledger.persist.side_effect=[OSError('freeze record disk full'),dict(passed=True,issues=[])]
        first,last=self.run_worker(calc,freeze_store=ledger)
        self.assertEqual(first['status'],'connected');self.assertIn('disk full',first['cache_error'])
        self.assertIsNone(first['analysis_error']);self.assertIsNone(last['cache_error'])
        self.assertEqual(first['model_revision'],last['model_revision']);self.assertEqual(calc.call_count,1)
        self.assertEqual(ledger.persist.call_count,2)
