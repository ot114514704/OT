import time
import unittest
from ict_trader.native_reader import IsolatedNativeReader
from ict_trader.market_source import MarketSourceError


def hanging_child(conn):
    conn.recv()
    time.sleep(30)


def healthy_child(conn):
    try:
        while conn.recv() == 'read':
            conn.send(dict(ok=True, payload=dict(raw={'H1':[]}, forming={}, quote={'bid':100}, market_source={'status':'verified'})))
    except EOFError:
        pass


def wrong_source_child(conn):
    conn.recv()
    conn.send(dict(ok=False, source=dict(status='source_mismatch', reason='wrong source')))


class NativeIsolationTests(unittest.TestCase):
    def test_timeout_reaps_owned_child_then_recovers_and_reuses_process(self):
        reader=IsolatedNativeReader(timeout=.5, target=hanging_child)
        try:
            started=time.monotonic()
            with self.assertRaises(TimeoutError):reader.read()
            self.assertLess(time.monotonic()-started, 5)
            self.assertIsNone(reader.process)
            self.assertEqual(reader.metadata()['timeouts'],1)
            reader.target=healthy_child;reader.timeout=5
            self.assertEqual(reader.read()['quote']['bid'],100)
            pid=reader.process.pid
            self.assertEqual(reader.read()['market_source']['status'],'verified')
            self.assertEqual(reader.process.pid,pid)
            self.assertEqual(reader.restarts,2)
            self.assertGreaterEqual(reader.metadata()['duration_seconds'],0)
        finally:reader.close()

    def test_source_mismatch_is_preserved_across_process_boundary(self):
        reader=IsolatedNativeReader(timeout=5,target=wrong_source_child)
        try:
            with self.assertRaises(MarketSourceError) as caught:reader.read()
            self.assertEqual(caught.exception.market_source['status'],'source_mismatch')
        finally:reader.close()
