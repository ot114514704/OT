import unittest
from datetime import datetime,timedelta,timezone
from dataclasses import replace
from ict_trader.core import Bar
from ict_trader.swing_balance import observe_swing_candidates, swing_history
from tests.test_consolidation import observe
from tests.test_consolidation_invariants import transformed


def wide_swings():
    start=datetime(2026,1,1,tzinfo=timezone.utc);values=[100,103,106,103,100,97,94,97]*3;bars=[]
    for i,c in enumerate(values):
        o=values[i-1] if i else 100
        bars.append(Bar(start+timedelta(minutes=15*i),o,max(o,c)+.4,min(o,c)-.4,c,0,900))
    return bars


def candidates(bars,asof=None):return observe_swing_candidates(bars,asof or bars[-1].closed_at)


class SwingBalanceTests(unittest.TestCase):
    def test_candidate_exit_explains_failure_without_confirming_breakout(self):
        bars=wide_swings()
        for i in range(6):
            o=97+i*5
            bars.append(Bar(bars[-1].closed_at,o,o+5.4,o-.4,o+5,0,900))
        rows=candidates(bars);events=swing_history(rows)
        self.assertEqual(events[0]['event'],'swing_candidate_entered')
        self.assertEqual(events[-1]['event'],'swing_candidate_ended')
        self.assertIn('候选消失不等于已确认突破',events[-1]['detail'])
        self.assertTrue(events[-1]['checks_missing'])
        for e in events:
            self.assertTrue(e['confirmed_bar_only']);self.assertFalse(e['confirmed']);self.assertFalse(e['score_included'])
        mirrored=swing_history(candidates(transformed(bars,-1,300)))
        self.assertEqual(events,mirrored)

    def test_gap_ends_candidate_at_observation_not_before_and_continuation_is_quiet(self):
        bars=wide_swings();bars += [replace(b,time=b.time+timedelta(hours=6)) for b in bars]
        rows=candidates(bars)
        self.assertIsNone(rows[-1]['event']);self.assertIn('随观察窗口更新',rows[-1]['reason'])
        extra=replace(bars[-1],time=bars[-1].closed_at+timedelta(minutes=15))
        extended=candidates(bars+[extra]);self.assertEqual(extended[:-1],rows)
        last=extended[-1];self.assertEqual(last['event'],'swing_candidate_ended')
        self.assertEqual(last['known_at'],extra.closed_at.isoformat())
        self.assertIn('数据间隔',last['reason'])
        self.assertEqual(swing_history(extended,1)[0]['known_at'],extra.closed_at.isoformat())

    def test_large_body_swings_have_separate_candidate_without_false_confirmation(self):
        bars=wide_swings();c=candidates(bars)[-1]['candidate']
        self.assertIsNotNone(c);self.assertGreaterEqual(c['metrics']['pivot_count'],5)
        self.assertFalse(c['confirmed']);self.assertFalse(c['score_included'])
        self.assertIsNone(observe(bars)['rows'][-1]['active'])
        for p in c['pivots']:
            self.assertLess(p['time'],p['known_at']);self.assertLessEqual(p['known_at'],c['known_at'])

    def test_monotonic_motion_and_current_directional_impulse_are_rejected(self):
        bars=wide_swings();trend=[replace(b,open=100+i,close=101+i,high=101.4+i,low=99.6+i) for i,b in enumerate(bars)]
        self.assertIsNone(candidates(trend)[-1]['candidate'])
        tail=[]
        for i in range(6):
            o=97+i*5;tail.append(Bar(bars[-1].closed_at+timedelta(minutes=15*i),o,o+5.4,o-.4,o+5,0,900))
        self.assertIsNone(candidates(bars+tail)[-1]['candidate'])

    def test_single_remote_spike_is_not_a_swing_balance(self):
        bars=wide_swings()
        # One isolated excursion can create many alternating pivots around a
        # broad window, but it is not repeated boundary testing.
        bars[10]=replace(bars[10],high=bars[10].high+40,close=bars[10].close+1)
        row=candidates(bars)[-1]
        self.assertIsNone(row['candidate'])
        self.assertIn('上下边缘均有重复触及',row['reason'])

    def test_prefix_causality_and_forming_future_are_preserved(self):
        bars=wide_swings();full=candidates(bars)
        for n in range(1,len(bars)+1):self.assertEqual(candidates(bars[:n]),full[:n])
        self.assertEqual(candidates(bars,bars[-2].closed_at),full[:-1])
        mutated=bars[:-1]+[replace(bars[-1],high=999,close=998)]
        self.assertEqual(candidates(mutated,bars[-2].closed_at),full[:-1])

    def test_mirror_scale_and_data_gap(self):
        bars=wide_swings();a=candidates(bars)[-1]['candidate']
        for scale,offset in ((-1,300),(10,500)):
            b=candidates(transformed(bars,scale,offset))[-1]['candidate']
            self.assertIsNotNone(b);self.assertEqual(a['checks'],b['checks'])
            self.assertAlmostEqual(b['high'],offset+scale*a['high' if scale>0 else 'low'])
        bars[15:]=[replace(b,time=b.time+timedelta(minutes=15)) for b in bars[15:]]
        self.assertIsNone(candidates(bars)[-1]['candidate'])
