// Execute the real verdict-card renderer; no browser or order route required.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
function element(){return {dataset:{},children:[],textContent:'',classList:{add(){}},
 append(...items){this.children.push(...items)},replaceChildren(){this.children=[]}}}
const root=element(),input=fs.readFileSync(process.argv[2],'utf8');
const context=vm.createContext({input,performance:{now:()=>1000},document:{
 getElementById:id=>id==='currentVerdicts'?root:element(),createElement:element}});
vm.runInContext(fs.readFileSync('ui/app.js','utf8').split('async function refresh()')[0],context);
vm.runInContext('state=JSON.parse(input);receivedAt=1000;renderCurrentVerdicts();',context);
const texts=node=>[node.textContent,...node.children.flatMap(texts)].join('\n');
let output=texts(root),report=JSON.parse(input).current_consolidation.M15;
let o=report.body_candidate_observation;assert.ok(o);
assert.ok(output.includes('实体平衡候选末柱：'+o.message));
assert.ok(output.includes(`${o.window}根窗口实体 ${o.low.toFixed(2)}—${o.high.toFixed(2)}`));
assert.ok(output.includes(o.policy));
vm.runInContext("state.current_consolidation.M15.availability='stale';renderCurrentVerdicts();",context);
output=texts(root);assert.ok(output.includes('当前判定不可用'));assert.ok(!output.includes('实体平衡候选末柱：'));
console.log(JSON.stringify({passed:true,scope:'Real verdict-card DOM data rendering and stale suppression; not physical visual acceptance'}));
