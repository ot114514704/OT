// Real card/detail renderers must explain a failed morphology independently of coverage.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
function element(){return {dataset:{},children:[],textContent:'',classList:{add(){}},append(...items){this.children.push(...items)},replaceChildren(){this.children=[]}}}
const roots=new Map(),root=id=>{if(!roots.has(id))roots.set(id,element());return roots.get(id)};
const context=vm.createContext({performance:{now:()=>1000},document:{getElementById:root,createElement:element}});
vm.runInContext(fs.readFileSync('ui/app.js','utf8').split('async function refresh()')[0],context);
const run=code=>vm.runInContext(code,context),texts=node=>[node.textContent,...node.children.flatMap(texts)].join('\n');
const score={score:67,components:[],eligibility:'incomplete',unknown_weight:0};
const profile={tags:['tilted'],checks:{tilted:true,converging:false},metrics:{},missing:[],geometry:{ready:true,validated:false,subtype:'broadening',reason:'边线外扩',morphology:{qualified:false,reason:'边线外扩，不满足同向近似平行通道或收敛形态'}}};
const report={profile,known_at:'2026-11-06T08:00:00+00:00',availability:'live',verdict:'candidate',label:'盘整候选',reason:'实体平衡待确认',candidate_basis:'body_balance',candidate_window:12,score_window:12,score:67,checks:{}};
context.input=JSON.stringify({current_consolidation:{M15:report},charts:{M15:{phase_rows:[{known_at:report.known_at,fit_scores:{by_phase:{consolidation:score}}}]}}});
run('state=JSON.parse(input);receivedAt=1000;renderCurrentVerdicts();renderPhaseScores("M15");');
assert.match(texts(root('currentVerdicts')),/斜线形态未通过：边线外扩/);
let detail=texts(root('scoresM15'));
assert.match(detail,/外扩连线（非通道）/);
assert.match(detail,/仅保留锚点证据，不绘制有效斜线区/);
assert.ok(!detail.includes('共同覆盖样本偏少'));
assert.equal(run('state.current_consolidation.M15.score'),67);
run("state.current_consolidation.M15.profile.geometry={ready:true,validated:false,subtype:'triangle',reason:'共同覆盖样本不足，仅为锚点连线',morphology:{qualified:true}};renderPhaseScores('M15');");
detail=texts(root('scoresM15'));assert.match(detail,/共同覆盖样本偏少/);assert.ok(!detail.includes('外扩连线'));
console.log(JSON.stringify({passed:true,scope:'Production DOM functions distinguish morphology failure from insufficient overlap; not physical visual acceptance'}));
