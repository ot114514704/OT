"""Synthetic rolling-window/archive failures; no broker history replay."""
from copy import deepcopy
from datetime import datetime,timedelta,timezone
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch,Mock

import app
from ict_trader.history_store import HistoryStore
from tests.executor_helpers import InlineExecutor
from tests.test_current_consolidation import chart,native_metadata
from tests.test_runtime_contract import LoopComplete

SOURCE=dict(status='verified',company='TradeMax Global Limited',server='TradeMaxGlobal-Live',symbol='XAUUSD')


def sample(start=0,count=12):
    begin=datetime(2026,1,1,tzinfo=timezone.utc)
    rows=[]
    for i in range(start,start+count):
        time=begin+timedelta(minutes=15*i)
        rows.append(dict(time=time.isoformat(),closed_at=(time+timedelta(minutes=15)).isoformat(),
                         open=100,high=102,low=98,close=100,spread=.1))
    return {'M15':rows}


class HistoryStoreTests(unittest.TestCase):
    def test_roll_retains_prefix_and_survives_restart(self):
        with TemporaryDirectory() as folder:
            store=HistoryStore(folder);first=sample()
            merged,report=store.prepare(first,SOURCE)
            self.assertFalse(report['persisted']);self.assertEqual(list(Path(folder).glob('*.json')),[])
            store.persist(merged,SOURCE)
            later=sample(3);unchanged=deepcopy(later)
            extended,report=HistoryStore(folder).prepare(later,SOURCE)
            self.assertEqual(extended,sample(0,15));self.assertEqual(later,unchanged)
            self.assertFalse(report['persisted']);self.assertEqual(report['periods']['M15']['bars'],15)
            store.persist(extended,SOURCE)
            self.assertEqual(HistoryStore(folder).prepare(later,SOURCE)[0],extended)

    def test_native_corrections_and_missing_overlap_replace_archive(self):
        with TemporaryDirectory() as folder:
            store=HistoryStore(folder);store.persist(sample(),SOURCE)
            native=sample(3);native['M15'][2]['close']=101
            del native['M15'][4]
            merged,_=store.prepare(native,SOURCE)
            self.assertEqual(merged['M15'][:3],sample(0,3)['M15'])
            self.assertEqual(merged['M15'][3:],native['M15'])
            self.assertNotIn(sample(7,1)['M15'][0],merged['M15'])

    def test_gap_is_kept_without_fabricating_missing_bars(self):
        with TemporaryDirectory() as folder:
            store=HistoryStore(folder);store.persist(sample(),SOURCE)
            later=sample(20)
            merged,_=store.prepare(later,SOURCE)
            self.assertEqual(merged['M15'],sample()['M15']+later['M15'])

    def test_sources_are_isolated_and_unknown_source_is_rejected(self):
        with TemporaryDirectory() as folder:
            store=HistoryStore(folder);store.persist(sample(),SOURCE)
            other={**SOURCE,'server':'TradeMaxGlobal-Another'}
            self.assertEqual(store.prepare(sample(3),other)[0],sample(3))
            for source in (None,{**SOURCE,'status':'unverified'},{**SOURCE,'company':'Other Broker'}):
                with self.assertRaises(ValueError):store.prepare(sample(3),source)

    def test_forming_regression_or_bad_archive_cannot_overwrite_history(self):
        with TemporaryDirectory() as folder:
            store=HistoryStore(folder);store.persist(sample(),SOURCE)
            path=next(Path(folder).glob('*.json'));saved=path.read_bytes()
            bad=sample(3);bad['M15'][-1]['forming']=True
            with self.assertRaises(ValueError):store.prepare(bad,SOURCE)
            with self.assertRaises(ValueError):store.prepare(sample(2,8),SOURCE)
            self.assertEqual(path.read_bytes(),saved)
            path.write_text('{broken',encoding='utf-8')
            with self.assertRaises(ValueError):HistoryStore(folder).prepare(sample(3),SOURCE)
            self.assertEqual(path.read_text(encoding='utf-8'),'{broken')

    def test_worker_uses_retained_history_for_model_and_quotes_continue(self):
        with TemporaryDirectory() as folder:
            store=HistoryStore(folder);store.persist(sample(),SOURCE)
            seen,calculate=self.run_worker(store,[sample(3),sample(3)])
            self.assertEqual(calculate.call_args.args[0],sample(0,15))
            self.assertEqual(seen[-1]['charts']['M15']['first_time'],sample()['M15'][0]['time'])
            self.assertEqual(seen[-1]['history_archive']['periods']['M15']['bars'],15)
            self.assertTrue(seen[-1]['history_archive']['persisted'])
            self.assertEqual([s['quote']['bid'] for s in seen],[101,102])

    def test_archive_read_failure_keeps_model_and_quotes_then_recovers(self):
        with TemporaryDirectory() as folder:
            store=HistoryStore(folder);original_prepare=store.prepare
            with patch.object(store,'prepare',side_effect=[ValueError('bad archive'),original_prepare(sample(3),SOURCE),original_prepare(sample(3),SOURCE)]):
                seen,_=self.run_worker(store,[sample(3),sample(3)])
            self.assertEqual(seen[0]['charts']['M15']['first_time'],sample()['M15'][0]['time'])
            self.assertIn('bad archive',seen[0]['analysis_error'])
            self.assertEqual(seen[0]['status'],'connected')
            self.assertEqual([s['quote']['bid'] for s in seen],[101,102])
            self.assertIsNone(seen[1]['analysis_error']);self.assertIsNone(seen[1]['history_error'])

    def run_worker(self,store,raw_values):
        original=deepcopy(app.STATE);seen=[];native_state=native_metadata(dict(charts={'M15':chart()},quote={'bid':100}))
        reads=[app.NativeRead(raw,deepcopy(native_state['forming']),
                 {**native_state['quote'],'bid':101+i,'ask':101.1+i},SOURCE) for i,raw in enumerate(raw_values)]
        def calculate(raw):return {'M15':{**chart(),'first_time':raw['M15'][0]['time']}}
        def wait(_):
            seen.append(deepcopy(app.STATE))
            if len(seen)==len(raw_values):raise LoopComplete()
        try:
            app.STATE.clear();app.STATE.update(status='starting',charts={})
            with patch.object(app,'load_seed',return_value=sample()),patch.object(app,'native',side_effect=reads),patch.object(app,'calculate',side_effect=calculate) as model,patch.object(app,'save_snapshot',Mock()),patch.object(app.time,'sleep',side_effect=wait):
                with self.assertRaises(LoopComplete):app.worker(executor=InlineExecutor(),freeze_store=False,history_store=store)
            return seen,model
        finally:app.STATE.clear();app.STATE.update(original)


if __name__=='__main__':unittest.main()
