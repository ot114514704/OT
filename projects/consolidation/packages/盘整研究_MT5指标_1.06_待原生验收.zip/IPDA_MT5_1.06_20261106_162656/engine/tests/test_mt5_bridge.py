import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from ict_trader.mt5_bridge import MT5Bridge,shape_record,display_records,chart_acknowledgements,current_summary


def box():
    return dict(id='native-source',observed_from='2026-11-04T10:00:00+00:00',
        known_at='2026-11-04T16:00:00+00:00',end_at='2026-11-04T18:00:00+00:00',
        liquidity_low=4030,liquidity_high=4055,status='已结束',active=False)


class MT5BridgeTests(unittest.TestCase):
    def test_live_summary_distinguishes_outer_candidate_and_forming_price(self):
        report=dict(label='证据不足',availability='live',macro_context={'verdict':'confirmed'},
                    structural_candidates=[{}],geometric_candidates=[{}],forming_observation={'code':'below_threshold'})
        summary=current_summary(report,dict(label='非盘整',availability='live'))
        self.assertIn('证据不足',summary);self.assertIn('外层盘整有效',summary)
        self.assertIn('活动形态2段(未确认)',summary);self.assertIn('下沿外观察，待收盘',summary)
        self.assertIn('M15 非盘整',summary)
        report['availability']='analysis_pending'
        pending=current_summary(report,dict(label='已确认盘整',availability='disconnected'))
        self.assertNotIn('外层盘整有效',pending);self.assertNotIn('待收盘',pending)
        self.assertIn('M15 MT5断连',pending)

    def test_native_receipt_requires_fresh_loaded_build_and_model(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(chart_acknowledgements(tmp,'r',100,1000)['status'],'awaiting_indicator')
            path=Path(tmp)/'chart_7.tsv'
            def receipt(version='1.05',revision='r',beat=99,mtime=999,health='实时'):
                path.write_text(f'IPDA_CHART\t{version}\t{revision}\tPERIOD_H1\t18\t{beat}\t{health}\t250\t0\t1\t2',encoding='utf-8')
                os.utime(path,(mtime,mtime))
                return chart_acknowledgements(tmp,'r',100,1000)
            valid=receipt();self.assertEqual(valid['status'],'attached')
            self.assertEqual(valid['charts'][0]['first_visible_bar'],250)
            self.assertFalse(valid['charts'][0]['auto_scroll'])
            for kwargs,status in [({'mtime':980},'stale_receipt'),({'mtime':1010},'clock_mismatch'),
                ({'version':'1.04'},'update_required'),({'revision':'previous'},'model_pending'),
                ({'beat':80},'heartbeat_pending'),({'beat':101},'heartbeat_pending'),({'health':'stale'},'heartbeat_pending')]:
                with self.subTest(status=status,kwargs=kwargs):
                    actual=receipt(**kwargs);self.assertEqual(actual['status'],'unverified')
                    self.assertEqual(actual['charts'][0]['status'],status)

    @patch('ict_trader.mt5_bridge.live_reports',return_value={})
    def test_bad_receipt_does_not_stop_export_or_native_poll(self,reports):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp)/'chart_9.tsv').write_bytes(b'IPDA_CHART\t1.02\tpartial')
            result=MT5Bridge(tmp).update(dict(status='connected',model_revision='new',charts={}),1000)
            self.assertEqual(result['indicator']['charts'][0]['status'],'invalid_receipt')
            self.assertEqual(result['sequence'],1)
            self.assertTrue((Path(tmp)/'heartbeat.tsv').is_file())

    def test_duplicate_drawings_hidden_but_distinct_nested_box_preserved(self):
        from copy import deepcopy
        outer=box();duplicate=deepcopy(outer);duplicate['id']='same-boundary'
        inner=deepcopy(outer);inner.update(id='nested',liquidity_low=4040,liquidity_high=4045)
        charts={'M15':dict(consolidations=[outer,duplicate,inner])}
        before=deepcopy(charts);rows=display_records(charts)
        self.assertEqual(len(rows),2);self.assertEqual(charts,before)
        self.assertTrue(any('nested' in r[1] for r in rows))

    def test_rectangle_and_slanted_geometry_keep_actual_coordinates(self):
        b=box();fields=shape_record('M15','local',b).split('\t')
        self.assertEqual(len(fields),24);self.assertEqual(fields[:1],['900'])
        self.assertEqual(fields[2:4],['rectangle','local'])
        self.assertEqual([float(fields[i]) for i in (14,16,18,20)],[4055,4055,4030,4030])
        self.assertLess(int(fields[13]),int(fields[15]))
        b['shape']='tilted';self.assertIsNone(shape_record('H1','intraday',b))
        frame=[dict(time=b['observed_from'],price=4050),dict(time=b['end_at'],price=4060),
               dict(time=b['end_at'],price=4040),dict(time=b['observed_from'],price=4030)]
        b['display_geometry']=dict(validated=True,subtype='channel',frame=frame)
        fields=shape_record('H1','intraday',b).split('\t')
        self.assertEqual(fields[2],'channel');self.assertIn('非H1确认',fields[9])
        self.assertEqual([float(fields[i]) for i in (14,16,18,20)],[4050,4060,4040,4030])

    def test_overlapping_history_and_current_candidate_are_not_discarded(self):
        records=[dict(box(),id='old-'+str(i),liquidity_low=4030+i*.01) for i in range(80)]
        current=dict(box(),id='current',active=True,confirmed=False,score_included=False,status='正在形成 · 候选未确认')
        result=display_records({'H1':dict(consolidations=records,current_candidate=current)})
        self.assertEqual(len(result),81)
        self.assertTrue(any('\told-0\t' in r[1] for r in result))
        candidate=next(r[1].split('\t') for r in result if '\tcandidate\t' in r[1])
        self.assertEqual(candidate[10],'1');self.assertIn('候选未确认',candidate[9])

    @patch('ict_trader.mt5_bridge.live_reports',return_value={})
    def test_quote_poll_refreshes_heartbeat_without_rewriting_frozen_shapes(self,reports):
        with tempfile.TemporaryDirectory() as tmp:
            bridge=MT5Bridge(tmp);state=dict(status='connected',model_revision='first',charts={'M15':dict(consolidations=[box()])})
            bridge.update(state,100);path=Path(tmp)/'shapes.tsv';original=path.read_bytes()
            state['charts']['M15']['consolidations'][0]['liquidity_high']=9999
            bridge.update(state,102)
            self.assertEqual(path.read_bytes(),original)
            self.assertEqual((Path(tmp)/'heartbeat.tsv').read_text('utf-8').split('\t')[2],'2')
            state['model_revision']='second';bridge.update(state,104)
            self.assertIn('9999',path.read_text('utf-8'))

    def test_config_is_explicitly_enabled_and_separate(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'settings.json';self.assertIsNone(MT5Bridge.from_config(p))
            p.write_text(json.dumps(dict(enabled=False,files_directory=tmp)),encoding='utf-8')
            self.assertIsNone(MT5Bridge.from_config(p))
            p.write_text(json.dumps(dict(enabled=True,files_directory=tmp)),encoding='utf-8')
            self.assertEqual(MT5Bridge.from_config(p).directory,Path(tmp))

    def test_explanations_use_actual_evidence_and_keep_candidate_unconfirmed(self):
        b=dict(box(),shape='rectangle',window=24,high_tests=4,low_tests=2,
               overlap=.76,oscillation={'completed_legs':5},score={'score':80},
               missing=['上级方向未验证'])
        f=shape_record('M15','local',b).split('\t')
        self.assertIn('矩形箱体',f[21]);self.assertIn('已结束',f[21])
        self.assertIn('4/2 次',f[22]);self.assertIn('重叠 76%',f[23])
        self.assertIn('80/100',f[23]);self.assertIn('上级方向未验证',f[23])
        candidate=shape_record('M15','candidate',dict(b,confirmed=False,status='候选未确认',active=True)).split('\t')
        self.assertIn('候选未确认，不计确认分',candidate[23]);self.assertNotIn('80/100',candidate[23])

    def test_unclassified_geometry_not_mislabeled_as_standard_box_or_source_period(self):
        f=shape_record('H1','intraday',box()).split('\t')
        self.assertIn('水平区间',f[21]);self.assertIn('M15内层',f[21])
        self.assertIn('不代表 H1 独立确认',f[23]);self.assertNotIn('已确认扫荡',f[23])
        self.assertNotIn('双边测试满足',f[23])

    def test_projected_source_qualification_is_separate_from_h1_and_invalidated_shapes_are_terminal(self):
        source=dict(box(),confirmed=False,source_confirmed=True,active=True,status='区间延续')
        confirmed=shape_record('H1','intraday',source).split('\t')
        self.assertIn('M15 实体平衡已确认',confirmed[23])
        self.assertIn('本投影不计 H1 确认分',confirmed[23])
        self.assertNotIn('候选未确认',confirmed[23])
        source.update(source_confirmed=False,status='长尺度收敛形态候选')
        candidate=shape_record('H1','intraday',source).split('\t')
        self.assertIn('·候选',candidate[21]);self.assertIn('M15 候选未确认',candidate[23])
        source.update(active=False,status='边线交会，斜线候选失效')
        for kind in ('intraday','geometric'):
            f=shape_record('H1',kind,source).split('\t')
            self.assertTrue(f[21].endswith('已失效'));self.assertEqual(f[10],'0')
