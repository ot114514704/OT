import unittest
from copy import deepcopy
from ict_trader.reference_targets import attach_targets


class ReferenceTargetTests(unittest.TestCase):
    def charts(self):
        def box(ident,shape,start,first,end,low,high):
            return dict(id=ident,shape=shape,observed_from=start+'+00:00',first_observed_at=first+'+00:00',end_at=end+'+00:00',
                        observed_low=low,observed_high=high,window=48,status='已离开')
        return {'H1':{'structural_ranges':[box('top','rectangle','2026-10-09T03:00:00','2026-10-13T05:00:00','2026-10-14T16:00:00',4141.56,4217.3)]},
                'M15':{'structural_ranges':[box('middle','tilted','2026-10-22T04:30:00','2026-10-22T16:30:00','2026-10-22T17:30:00',4057.39,4124.01),
                box('bottom','rectangle','2026-11-02T01:15:00','2026-11-02T13:15:00','2026-11-02T16:00:00',3891.13,3919.34)]}}

    def test_bookmarks_match_actual_bounds_without_confirming_or_rewriting(self):
        charts=self.charts();before=deepcopy(charts)
        attach_targets(charts)
        targets=[t for c in charts.values() for t in c['reference_targets'] if t['source_image']==12]
        self.assertEqual(len(targets),3);self.assertTrue(all(t['matched'] for t in targets))
        self.assertTrue(all(t['confirmed'] is False for t in targets))
        for p,c in charts.items():self.assertEqual(c['structural_ranges'],before[p]['structural_ranges'])
        bottom=targets[-1];self.assertEqual(bottom['reference_low'],3845);self.assertEqual(bottom['actual_low'],3891.13)
        self.assertNotEqual(bottom['reference_low'],bottom['actual_low'])

    def test_missing_or_wrong_shape_does_not_invent_a_match(self):
        charts=self.charts();charts['H1']['structural_ranges'][0]['shape']='tilted';charts['M15']['structural_ranges']=[]
        attach_targets(charts)
        for t in (charts['H1']['reference_targets'][0],charts['M15']['reference_targets'][1]):
            self.assertFalse(t['matched']);self.assertIsNone(t['range_id']);self.assertNotIn('actual_low',t)

    def test_phone_box_and_convergence_use_their_own_evidence_kind(self):
        charts=self.charts();c=charts['M15']
        c['structural_ranges'].append(dict(id='high',shape='rectangle',observed_from='2026-11-02T16:00:00+00:00',
            first_observed_at='2026-11-03T05:00:00+00:00',end_at='2026-11-03T06:00:00+00:00',
            observed_low=3934.85,observed_high=3970.33,window=48,status='已离开'))
        c['consolidations']=[dict(id='triangle',observed_from='2026-11-03T11:00:00+00:00',known_at='2026-11-03T14:00:00+00:00',
            end_at='2026-11-03T14:45:00+00:00',liquidity_low=3895.5,liquidity_high=3910.55,window=12,status='已结束',
            profile=dict(tags=['converging'],geometry=dict(validated=True,subtype='triangle')))]
        attach_targets(charts);t={t['id']:t for t in c['reference_targets']}
        self.assertEqual((t['phone_high_box']['range_kind'],t['phone_high_box']['range_id']),('structural','high'))
        self.assertEqual((t['phone_converging_up']['range_kind'],t['phone_converging_up']['range_id']),('range','triangle'))
        self.assertFalse(t['phone_ascending_down']['matched'])
        self.assertTrue(t['phone_converging_up']['evidence_confirmed'])
        self.assertFalse(t['phone_converging_up']['confirmed'])

    def test_nearby_time_with_unrelated_price_cannot_be_reported_as_filled(self):
        charts=self.charts();charts['H1']['structural_ranges'][0].update(observed_low=4400,observed_high=4500)
        attach_targets(charts)
        self.assertFalse(charts['H1']['reference_targets'][0]['matched'])
