import unittest
from copy import deepcopy
from ict_trader.source_revisions import source_revisions


def rows():
    return [{'time':f'2026-01-01T0{i}:00:00+00:00','open':100,'high':102,'low':98,'close':100,'spread':.1} for i in range(4)]


class SourceRevisionTests(unittest.TestCase):
    def test_new_closed_bar_and_normal_window_roll_are_not_corrections(self):
        a=rows();b=a[1:]+[{**a[-1],'time':'2026-01-01T04:00:00+00:00'}]
        self.assertIsNone(source_revisions({'H1':a},{'H1':b}))

    def test_overlap_correction_and_missing_or_inserted_history_are_explicit(self):
        a=rows();b=deepcopy(a);b[1]['high']=103
        r=source_revisions({'H1':a},{'H1':b});self.assertEqual(r['count'],1)
        self.assertEqual(r['periods']['H1']['examples'][0]['fields'],['high'])
        r=source_revisions({'H1':a},{'H1':a[:1]+a[2:]})
        self.assertEqual(r['periods']['H1']['examples'][0]['kind'],'historical_missing')
        r=source_revisions({'H1':a[:1]+a[2:]},{'H1':a})
        self.assertEqual(r['periods']['H1']['examples'][0]['kind'],'historical_insert')

    def test_equivalent_timezones_and_empty_startup_do_not_invent_revisions(self):
        a=rows();b=deepcopy(a)
        b[1]['time']='2026-01-01T09:00:00+08:00'
        self.assertIsNone(source_revisions({'H1':a},{'H1':b}))
        self.assertIsNone(source_revisions({}, {'H1':a}))
