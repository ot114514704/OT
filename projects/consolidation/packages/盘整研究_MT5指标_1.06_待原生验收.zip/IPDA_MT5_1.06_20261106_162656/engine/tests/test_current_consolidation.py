import unittest
from copy import deepcopy
from datetime import datetime,timedelta
from ict_trader.current_consolidation import classify,live_reports,CHECK_NAMES,current_candidate_overlay


def chart():
    checks={k:True for k in CHECK_NAMES}
    row=dict(phase='undetermined',known_at='2026-01-01T01:00:00+00:00',fit_scores={'by_phase':{'consolidation':{'score':80}}},consolidation_evidence=dict(range=None,ended=None,event=None,candidates=[{'checks':checks,'profile':{'tags':[]}}]))
    return dict(closed_end=row['known_at'],phase_rows=[row])


def native_metadata(state):
    start=datetime.fromisoformat(state['charts']['M15']['closed_end'])
    state['quote']['raw_epoch']=start.timestamp()+1
    state['quote']['market_source']={'status':'verified'}
    state.setdefault('forming',{})['M15']=dict(time=start.isoformat(),closed_at=(start+timedelta(minutes=15)).isoformat(),forming=True)
    return state


class CurrentVerdictTests(unittest.TestCase):
    def multi_window_chart(self):
        c=chart();end=datetime.fromisoformat(c['closed_end'])
        c['bars']=[dict(time=(end-timedelta(minutes=15*(24-i))).isoformat(),
                       closed_at=(end-timedelta(minutes=15*(23-i))).isoformat()) for i in range(24)]
        top=deepcopy(c['phase_rows'][0]['consolidation_evidence']['candidates'][0])
        top.update(lo=90,hi=115,metrics={'window':12},profile={'tags':['tilted']})
        top['checks'].update(strong_oscillation=False,two_sided=False) # 8 conditions, failed prerequisite
        valid=deepcopy(top);valid.update(lo=99,hi=101,metrics={'window':24},profile={'tags':['rectangle']})
        valid['checks'].update(strong_oscillation=True,no_drift=False,crossings=False) # 7 with all prerequisites
        c['phase_rows'][0]['consolidation_evidence']['candidates']=[top,valid]
        c['phase_rows'][0]['fit_scores']['by_phase']['consolidation']['checks_basis']='current_candidate_window'
        c['phase_rows'][0]['phase']='expansion'
        return c

    def test_eligible_window_is_not_hidden_by_more_checks_with_failed_prerequisite(self):
        c=self.multi_window_chart();before=deepcopy(c);r=classify(c);overlay=current_candidate_overlay(c)
        self.assertEqual((r['verdict'],r['candidate_basis'],r['candidate_window']),('candidate','body_balance',24))
        self.assertTrue(r['checks']['强双向震荡筛选']);self.assertFalse(r['checks']['无明显单向漂移'])
        self.assertEqual((overlay['low'],overlay['high'],overlay['window']),(99,101,24))
        self.assertEqual(overlay['observed_from'],c['bars'][0]['time'])
        self.assertEqual(r['profile']['tags'],['rectangle']);self.assertEqual(r['score'],80)
        self.assertEqual(r['score_window'],12);self.assertEqual(c,before)
        c['phase_rows'][0]['consolidation_evidence']['candidates'].reverse()
        self.assertEqual(classify(c)['candidate_window'],24)
        self.assertEqual(current_candidate_overlay(c),overlay)

    def test_no_window_qualifies_retains_diagnostic_evidence_and_no_overlay(self):
        c=self.multi_window_chart();cs=c['phase_rows'][0]['consolidation_evidence']['candidates']
        cs[1]['checks']['strong_oscillation']=False
        r=classify(c)
        self.assertEqual(r['verdict'],'not_consolidation');self.assertIsNone(r['candidate_window'])
        self.assertEqual(r['profile']['tags'],['tilted']);self.assertIsNone(current_candidate_overlay(c))
        self.assertIn('强双向震荡筛选',r['missing']);self.assertEqual(r['score'],80)

    def test_multiple_eligible_windows_rank_without_overriding_exit_or_gap(self):
        c=self.multi_window_chart();e=c['phase_rows'][0]['consolidation_evidence']
        e['candidates'][0]['checks']['strong_oscillation']=True
        self.assertEqual(classify(c)['candidate_window'],12)
        for event,verdict in [('breakout_confirmed','not_consolidation'),('data_gap','insufficient')]:
            e['event']=event
            self.assertEqual(classify(c)['verdict'],verdict)
            self.assertIsNone(current_candidate_overlay(c))

    def test_untagged_current_overlay_uses_verdict_candidate_and_only_closed_bars(self):
        c=chart();e=c['phase_rows'][0]['consolidation_evidence']
        c['bars']=[dict(time='2026-01-01T00:00:00+00:00',closed_at=c['closed_end'])]
        best=e['candidates'][0];best.update(lo=100,hi=110,metrics={'window':1})
        weaker=deepcopy(best);weaker['hi']=999;weaker['checks']['two_sided']=False
        e['candidates'].insert(0,weaker);before=deepcopy(c)
        overlay=current_candidate_overlay(c)
        self.assertEqual(overlay['high'],110);self.assertEqual(overlay['profile']['tags'],[])
        self.assertFalse(overlay['confirmed']);self.assertFalse(overlay['score_included'])
        self.assertEqual(overlay['end_at'],c['closed_end']);self.assertEqual(c,before)
        c['bars'][-1]['forming']=True;self.assertIsNone(current_candidate_overlay(c))
        c=deepcopy(before);e=c['phase_rows'][0]['consolidation_evidence']
        e['event']='breakout_confirmed';self.assertIsNone(current_candidate_overlay(c))
        e['event']=None
        for candidate in e['candidates']:candidate['checks']['strong_oscillation']=False
        self.assertIsNone(current_candidate_overlay(c))

    def swing_chart(self):
        from tests.test_swing_balance import wide_swings,candidates
        c=chart();c['swing_rows']=candidates(wide_swings())
        c['closed_end']=c['phase_rows'][0]['known_at']=c['swing_rows'][-1]['known_at']
        c['phase_rows'][0]['phase']='expansion'
        c['phase_rows'][0]['consolidation_evidence']['candidates'][0]['checks']['small_bodies']=False
        return c

    def test_swing_evidence_changes_candidate_verdict_without_confirmation_or_score_change(self):
        c=self.swing_chart();before=deepcopy(c);r=classify(c)
        self.assertEqual(r['verdict'],'candidate');self.assertEqual(r['candidate_basis'],'swing_balance')
        self.assertEqual(r['score'],80);self.assertIsNone(r['range'])
        self.assertIn('实体平衡确认尚未完成',r['missing']);self.assertEqual(c,before)
        c['swing_rows'][-1]['candidate']=None
        self.assertEqual(classify(c)['verdict'],'not_consolidation')

    def test_swing_cannot_override_range_exit_gap_or_body_candidate(self):
        c=self.swing_chart();e=c['phase_rows'][0]['consolidation_evidence']
        for event,expected in [('breakout_confirmed','not_consolidation'),('data_gap','insufficient')]:
            e['event']=event;self.assertEqual(classify(c)['verdict'],expected)
        e['event']=None;e['candidates'][0]['checks']['small_bodies']=True
        self.assertEqual(classify(c)['candidate_basis'],'body_balance')
        e['range']=dict(checks={k:True for k in CHECK_NAMES},status='区间延续',profile={})
        self.assertEqual(classify(c)['verdict'],'confirmed');self.assertIsNone(classify(c)['candidate_basis'])

    def test_future_unqualified_or_scored_swing_evidence_cannot_change_current_verdict(self):
        for change in ('future','unqualified','scored'):
            c=self.swing_chart();s=c['swing_rows'][-1]
            if change=='future':s['candidate']['known_at']='2099-01-01T00:00:00+00:00'
            elif change=='unqualified':s['candidate']['checks']['no_current_impulse']=False
            else:s['candidate']['score_included']=True
            with self.subTest(change=change):self.assertEqual(classify(c)['verdict'],'not_consolidation')

    def test_high_score_does_not_confirm_and_missing_balance_is_explicit(self):
        c=chart();self.assertEqual(classify(c)['verdict'],'candidate')
        c['phase_rows'][0]['consolidation_evidence']['candidates'][0]['checks']['small_bodies']=False
        self.assertEqual(classify(c)['verdict'],'insufficient')
        c['phase_rows'][0]['phase']='expansion';self.assertEqual(classify(c)['verdict'],'not_consolidation')

    def test_range_and_exit_and_gap(self):
        c=chart();e=c['phase_rows'][0]['consolidation_evidence'];e['range']=dict(checks={k:True for k in CHECK_NAMES},status='越界待跟进',profile={})
        self.assertEqual(classify(c)['verdict'],'confirmed')
        e['range']=None;e['event']='breakout_confirmed';self.assertEqual(classify(c)['verdict'],'not_consolidation')
        e['event']='data_gap';self.assertEqual(classify(c)['verdict'],'insufficient')
        self.assertEqual(classify({})['verdict'],'insufficient')

    def test_freshness_is_independent_of_historical_verdict(self):
        state=dict(status='connected',polled_at=100,last_tick_change_at=100,quote={'bid':1},charts={'M15':chart()})
        native_metadata(state);original=deepcopy(state)
        self.assertEqual(live_reports(state,101)['M15']['availability'],'live')
        self.assertEqual(live_reports(state,120)['M15']['availability'],'stale')
        state['polled_at']=140;self.assertEqual(live_reports(state,141)['M15']['availability'],'quote_idle')
        state['status']='disconnected';r=live_reports(state,141)['M15'];self.assertFalse(r['actionable_current']);self.assertEqual(r['verdict'],'candidate')
        self.assertEqual(original['charts'],state['charts'])

    def test_new_closed_candle_pending_analysis_cannot_claim_live(self):
        state=dict(status='connected',polled_at=100,last_tick_change_at=100,quote={'bid':1},charts={'M15':chart()},latest_closed_end={'M15':'2026-01-01T01:15:00+00:00'})
        native_metadata(state)
        r=live_reports(state,101)['M15'];self.assertEqual(r['availability'],'analysis_pending');self.assertFalse(r['actionable_current'])

class FormingDisplayTests(unittest.TestCase):
    def setup_state(self):
        c=chart();c['phase_rows'][0]['consolidation_evidence']['range']=dict(low=99,high=101,liquidity_low=98,liquidity_high=102,frozen_atr=2,checks={k:True for k in CHECK_NAMES},status='区间延续',profile={})
        s=native_metadata(dict(status='connected',polled_at=100,last_tick_change_at=100,quote={'bid':100},charts={'M15':c}))
        s['forming']['M15'].update(open=100,high=100.5,low=99.5,close=100)
        return s

    def test_forming_excursion_never_changes_confirmed_verdict_or_score(self):
        s=self.setup_state();base=live_reports(s,101)['M15'];original=deepcopy(s)
        s['forming']['M15'].update(high=105,close=104)
        moved=live_reports(s,101)['M15'];self.assertEqual(moved['forming_observation']['code'],'above_threshold')
        self.assertFalse(moved['forming_observation']['confirmed']);self.assertFalse(moved['forming_observation']['score_included'])
        for key in ('verdict','score','checks','event','known_at','range'):self.assertEqual(base[key],moved[key])
        self.assertEqual(original['charts'],s['charts'])

    def test_body_edge_wick_and_mirror_thresholds(self):
        s=self.setup_state();b=s['forming']['M15'];b.update(high=103,close=101.1)
        a=live_reports(s,101)['M15']['forming_observation'];self.assertEqual(a['code'],'body_edge');self.assertEqual(a['wick_crossings'],['upper'])
        b.update(high=100.5,low=95,close=96)
        a=live_reports(s,101)['M15']['forming_observation'];self.assertEqual(a['code'],'below_threshold');self.assertEqual(a['wick_crossings'],['lower'])
        self.assertEqual(a['threshold_high'],101.3);self.assertEqual(a['threshold_low'],98.7)

    def test_misaligned_forming_data_is_not_displayed_against_old_range(self):
        s=self.setup_state();s['forming']['M15']['time']='2026-01-01T01:15:00+00:00'
        self.assertIsNone(live_reports(s,101)['M15']['forming_observation'])
        s['latest_closed_end']={'M15':'2026-01-01T01:15:00+00:00'}
        self.assertTrue(live_reports(s,101)['M15']['analysis_pending'])
        self.assertIsNone(live_reports(s,101)['M15']['forming_observation'])

class StateHistoryTests(unittest.TestCase):
    def test_swing_to_body_candidate_history_uses_only_matching_known_at(self):
        from ict_trader.current_consolidation import state_history
        from tests.test_swing_balance import wide_swings,candidates
        swings=candidates(wide_swings());first=deepcopy(chart()['phase_rows'][0])
        first['known_at']=swings[-1]['known_at'];first['phase']='expansion'
        first['consolidation_evidence']['candidates'][0]['checks']['small_bodies']=False
        second=deepcopy(first);second['known_at']=(datetime.fromisoformat(first['known_at'])+timedelta(minutes=15)).isoformat()
        second['consolidation_evidence']['candidates'][0]['checks']['small_bodies']=True
        full=state_history({'phase_rows':[first,second],'swing_rows':swings})
        self.assertEqual(full[0]['to_verdict'],'candidate');self.assertEqual(full[0]['candidate_basis'],'swing_balance')
        self.assertEqual(full[-1]['event'],'candidate_basis_changed');self.assertEqual(full[-1]['candidate_basis'],'body_balance')
        self.assertEqual(state_history({'phase_rows':[first],'swing_rows':swings}),full[:1])
        no_swing=state_history({'phase_rows':[first],'swing_rows':swings[:-1]})
        self.assertEqual(no_swing[-1]['to_verdict'],'not_consolidation')

    def make_rows(self):
        from datetime import datetime,timedelta,timezone
        rows=[];start=datetime(2026,1,1,tzinfo=timezone.utc)
        base=chart()['phase_rows'][0]
        box=dict(id='range1',low=99,high=101,liquidity_low=98,liquidity_high=102,frozen_atr=2,
                 checks={k:True for k in CHECK_NAMES},status='区间延续',profile={},breakout_streak=0,breakout_side=0)
        for i,event in enumerate((None,'range_confirmed','range_held','breakout_pending','range_reclaimed','breakout_confirmed')):
            row=deepcopy(base);row['known_at']=(start+timedelta(minutes=15*(i+1))).isoformat();e=row['consolidation_evidence'];e['event']=event
            if i>0:e['range']=deepcopy(box);e['candidates']=[]
            if event=='breakout_pending':e['range'].update(status='越界待跟进',breakout_streak=1,breakout_side=1)
            if event=='range_reclaimed':e['sweep']='upper'
            if event=='breakout_confirmed':
                e['ended']=e['range'];e['ended'].update(status='向上突破条件触发',breakout_side=1);e['range']=None
            rows.append(row)
        return rows

    def test_history_explains_events_and_omits_held_noise(self):
        from ict_trader.current_consolidation import state_history
        result=state_history({'phase_rows':self.make_rows()})
        self.assertEqual([e['event'] for e in result],['window_start','range_confirmed','breakout_pending','range_reclaimed','breakout_confirmed'])
        self.assertEqual(result[-1]['to_verdict'],'not_consolidation')
        self.assertIn('上侧',result[-2]['title'])
        self.assertTrue(all(e['confirmed_bar_only'] for e in result))

    def test_history_is_prefix_causal_and_does_not_mutate_rows(self):
        from ict_trader.current_consolidation import state_history
        rows=self.make_rows();before=deepcopy(rows);full=state_history({'phase_rows':rows})
        for n in range(1,len(rows)+1):
            self.assertEqual(state_history({'phase_rows':rows[:n]}),[e for e in full if e['known_at']<=rows[n-1]['known_at']])
        self.assertEqual(rows,before)
        self.assertEqual(len(state_history({'phase_rows':rows},limit=2)),2)
