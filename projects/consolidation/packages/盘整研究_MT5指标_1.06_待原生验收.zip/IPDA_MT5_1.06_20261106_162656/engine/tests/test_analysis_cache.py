from copy import deepcopy
from dataclasses import replace
from datetime import timedelta
from unittest.mock import Mock
import unittest

import app
from ict_trader.analysis_cache import H1AnalysisCache
from tests.test_consolidation import fixture


class AnalysisCacheTests(unittest.TestCase):
    def test_every_input_field_and_historical_revision_invalidates_the_entry(self):
        source=[dict(time='first',closed_at='one',open=100,high=105,low=95,close=101,spread=.1),
                dict(time='second',closed_at='two',open=101,high=105,low=95,close=102,spread=.1)]
        analyze=Mock(side_effect=lambda rows:dict(rows=deepcopy(rows)))
        cache=H1AnalysisCache(analyze);cache.get(source)
        # Dict insertion order is not a market change.
        reordered=[dict(reversed(list(row.items()))) for row in source]
        cache.get(reordered);self.assertEqual(analyze.call_count,1)
        for field in source[0]:
            revised=deepcopy(source);revised[0][field]='changed' if isinstance(revised[0][field],str) else revised[0][field]+.1
            self.assertEqual(cache.get(revised)['rows'],revised)
            cache.get(source)
        self.assertEqual(analyze.call_count,1+2*len(source[0]))
        cache.get(source[1:]);cache.get(source+[source[-1]])
        self.assertEqual(cache.metadata()['retained_bars'],3)

    def test_consumer_and_input_mutation_cannot_corrupt_private_cached_analysis(self):
        analyze=Mock(side_effect=lambda rows:dict(data=deepcopy(rows),nested=[{'price':100}]))
        cache=H1AnalysisCache(analyze);raw=[{'close':100}];first=cache.get(raw)
        first['nested'][0]['price']=999;first['data'][0]['close']=999
        second=cache.get(raw);self.assertEqual(second['nested'][0]['price'],100);self.assertEqual(second['data'][0]['close'],100)
        second['nested'][0]['price']=900;self.assertEqual(cache.get(raw)['nested'][0]['price'],100)
        raw[0]['close']=200;self.assertEqual(cache.get(raw)['data'][0]['close'],200);self.assertEqual(analyze.call_count,2)

    def test_failed_new_input_never_poisoned_or_misrepresented_as_a_cache_hit(self):
        analyze=Mock(side_effect=[{'result':100},RuntimeError('failed'),{'result':200}])
        cache=H1AnalysisCache(analyze);cache.get([{'close':100}])
        with self.assertRaisesRegex(RuntimeError,'failed'):cache.get([{'close':200}])
        self.assertEqual(cache.get([{'close':100}]),{'result':100})
        self.assertEqual(cache.get([{'close':200}]),{'result':200})
        self.assertEqual(cache.metadata()['builds'],2);self.assertEqual(analyze.call_count,3)

    def test_full_pipeline_is_identical_for_m15_updates_h1_revisions_and_projection_mutation(self):
        bars=fixture()*2;start=bars[0].time
        raw={p:[app.row(replace(b,time=start+timedelta(seconds=i*seconds),seconds=seconds)) for i,b in enumerate(bars)] for p,seconds in [('H1',3600),('M15',900)]}
        analyze=Mock(wraps=app.prepare_h1);cache=H1AnalysisCache(analyze)
        def original_pipeline(sample):
            h=app.analyze(sample['H1'],'H1');m=app.analyze(sample['M15'],'M15',h)
            return app.attach_targets(app.attach_intraday_projection({'H1':app.project(h),'M15':app.project(m)}))
        expected=original_pipeline(raw);first=app.calculate(raw,h1_cache=cache)
        self.assertEqual(first,expected)
        first['H1']['phase_rows'][0]['reason']='consumer mutation';first['H1']['bars'][0]['close']=-1
        first['H1']['intraday_structures'].append({'id':'mutated M15 projection'})
        for count in (len(bars)-2,len(bars)-1,len(bars)):
            sample={**raw,'M15':raw['M15'][:count]}
            expected=original_pipeline(sample)
            self.assertEqual(app.calculate(sample,h1_cache=cache),expected)
            self.assertEqual(app.calculate(sample),expected)
        self.assertEqual(analyze.call_count,1)
        revised=deepcopy(raw);revised['H1'][0]['spread']+=.1
        self.assertEqual(app.calculate(revised,h1_cache=cache),app.calculate(revised));self.assertEqual(analyze.call_count,2)
        # A new H1 close also invalidates; exact timestamp count matters.
        shortened={**raw,'H1':raw['H1'][:-1]}
        self.assertEqual(app.calculate(shortened,h1_cache=cache),app.calculate(shortened));self.assertEqual(analyze.call_count,3)
        self.assertEqual(raw['H1'][0]['close'],bars[0].close)

    def test_h1_preparation_keeps_display_and_m15_dependencies_without_internal_workspace(self):
        from unittest.mock import patch
        raw=[{'close':100}]
        full=dict(channels={'frozen':[{'price':100}]},retracement_validation={
            'native_cisd':{'events':[{'time':'known','price':101}]},'rows':['internal-validation']},
            phases=['internal-phases'],other_internal_work=['not-a-display-field'])
        displayed=dict(bars=deepcopy(raw),phase_rows=['visible-evidence'],consolidations=['all-history'])
        with patch.object(app,'analyze',return_value=full) as analyze,patch.object(app,'project',return_value=displayed) as project:
            cache=H1AnalysisCache(app.prepare_h1);first=cache.get(raw)
            first['chart']['bars'][0]['close']=999
            first['background']['channels']['frozen'][0]['price']=999
            second=cache.get(raw)
            self.assertEqual(second['chart']['bars'][0]['close'],100)
            self.assertEqual(second['background']['channels']['frozen'][0]['price'],100)
            self.assertEqual(second['background']['retracement_validation']['native_cisd'],full['retracement_validation']['native_cisd'])
            self.assertEqual(second['chart']['consolidations'],['all-history'])
            self.assertNotIn('phases',second);self.assertNotIn('rows',second['background']['retracement_validation'])
            analyze.assert_called_once_with(raw,'H1');project.assert_called_once_with(full)

    def test_internal_snapshot_preserves_aliases_without_sharing_with_consumers(self):
        from unittest.mock import patch
        shared=[dict(price=100)]
        output=dict(left=shared,right=shared,values=(None,True,False,1,1.25,'形态'))
        cache=H1AnalysisCache(Mock(return_value=output));raw=[dict(close=100)]
        first=cache.get(raw);first['left'][0]['price']=999
        second=cache.get(raw)
        self.assertIs(second['left'],second['right']);self.assertEqual(second['left'][0]['price'],100)
        self.assertEqual(second['values'],(None,True,False,1,1.25,'形态'))
        second['left'][0]['price']=888
        self.assertEqual(cache.get(raw)['right'][0]['price'],100)
        saved_bytes=cache.metadata()['snapshot_bytes'];self.assertGreater(saved_bytes,0)
        with patch('ict_trader.analysis_cache.pickle.dumps',side_effect=ValueError('snapshot failure')):
            with self.assertRaisesRegex(ValueError,'snapshot failure'):cache.get([dict(close=200)])
        self.assertEqual(cache.get(raw)['left'][0]['price'],100)
        self.assertEqual(cache.metadata()['snapshot_bytes'],saved_bytes)
        self.assertEqual(cache.metadata()['builds'],1)


if __name__=='__main__':unittest.main()
