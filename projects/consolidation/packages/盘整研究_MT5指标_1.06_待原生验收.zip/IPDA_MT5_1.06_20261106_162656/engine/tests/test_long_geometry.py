import json
import unittest
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
from datetime import timedelta
import app
from ict_trader.core import Bar,instant
from ict_trader.long_geometry import observe_long_geometry
from ict_trader.freeze_ledger import FreezeLedger
from tests.test_consolidation_invariants import transformed


class LongGeometryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw=json.loads((Path(__file__).parent/'fixtures/ascending_triangle_native_m15.json').read_text('utf-8'))['bars']
        cls.bars=[Bar(instant(b['time']),*(b[k] for k in ('open','high','low','close')),0,900) for b in raw]

    def observe(self,bars,asof=None):return observe_long_geometry(bars,asof or bars[-1].closed_at)

    def test_native_ascending_triangle_is_known_before_later_displacement(self):
        cutoff=instant('2026-10-23T13:15:00+00:00');r=self.observe(self.bars,cutoff)
        b=next(b for b in r['current'] if b['geometry']['subtype']=='ascending_triangle')
        self.assertEqual(b['first_observed_at'],cutoff.isoformat())
        self.assertEqual(b['geometry']['validation']['overlap_bars'],25)
        self.assertFalse(b['confirmed']);self.assertFalse(b['score_included'])
        self.assertTrue(b['checks']['strong_oscillation']);self.assertFalse(b['geometry']['projected'])
        bytime={b.time.isoformat():b for b in self.bars}
        for side,field in [('upper','high'),('lower','low')]:
            for p in b['geometry'][side]:
                self.assertEqual(p['price'],getattr(bytime[p['time']],field))
                self.assertEqual((instant(p['known_at'])-instant(p['time'])).total_seconds(),4*900)
                self.assertLessEqual(instant(p['known_at']),cutoff)

    def test_prefix_forming_and_frozen_geometry(self):
        full=self.observe(self.bars)
        for n in (48,49,54,60,64,68):
            prefix=self.observe(self.bars[:n]);known=self.bars[n-1].closed_at.isoformat()
            self.assertEqual(prefix['history'],[e for e in full['history'] if e['known_at']<=known])
            for b in prefix['ranges']:
                later=next(x for x in full['ranges'] if x['id']==b['id'])
                for key in ('geometry','checks','metrics','observed_from','first_observed_at'):
                    self.assertEqual(b[key],later[key])
        cutoff=self.bars[48].closed_at
        changed=self.bars[:49]+[replace(b,open=b.open+100,close=b.close+100,high=b.high+100,low=b.low+100) for b in self.bars[49:]]
        self.assertEqual(self.observe(changed,cutoff),self.observe(self.bars[:49]))

    def test_mirror_scale_and_gap_invalidation_are_symmetric(self):
        bars=self.bars[:49];baseline=next(b for b in self.observe(bars)['current'] if b['window']==48)
        for scale,offset in ((-1,9000),(10,500)):
            b=next(b for b in self.observe(transformed(bars,scale,offset))['current'] if b['window']==48)
            self.assertEqual(b['checks'],baseline['checks'])
            self.assertEqual(b['geometry']['subtype'],'descending_triangle' if scale<0 else 'ascending_triangle')
        gap=replace(self.bars[49],time=self.bars[49].time+timedelta(minutes=15))
        ended=next(b for b in self.observe(bars+[gap])['ranges'] if b['id']==baseline['id'])
        self.assertFalse(ended['active']);self.assertEqual(ended['status'],'数据间隔中止斜线候选')

    def test_ledger_rejects_anchor_drift_and_silent_active_identity_change(self):
        bars=self.bars[:49];observed=self.observe(bars)
        charts={'M15':dict(closed_end=bars[-1].closed_at.isoformat(),geometric_ranges=observed['ranges'],geometric_current=observed['current'])}
        raw={'M15':[app.row(b) for b in bars]}
        with TemporaryDirectory() as directory:
            ledger=FreezeLedger(Path(directory)/'freeze.json','new-geometry');ledger.persist(charts,raw)
            changed=deepcopy(charts);changed['M15']['geometric_ranges'][0]['geometry']['upper'][0]['price']+=1
            self.assertFalse(ledger.inspect(changed,raw)['passed'])
            removed=deepcopy(charts);removed['M15']['geometric_current']=[]
            self.assertFalse(ledger.inspect(removed,raw)['passed'])
            tail=self.bars[:63];later=self.observe(tail)
            new={'M15':dict(closed_end=tail[-1].closed_at.isoformat(),geometric_ranges=later['ranges'],geometric_current=later['current'])}
            self.assertTrue(ledger.inspect(new,{'M15':[app.row(b) for b in tail]})['passed'])
