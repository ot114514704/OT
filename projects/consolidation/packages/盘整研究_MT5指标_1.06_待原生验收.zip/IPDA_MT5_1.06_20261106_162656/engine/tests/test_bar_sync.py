"""Fresh quotes do not prove the candle series is current. No terminal required."""
import unittest
from copy import deepcopy
from datetime import datetime,timedelta
from ict_trader.current_consolidation import live_reports,PARAMETERS
from tests.test_current_consolidation import chart,native_metadata


def sample():
    s=native_metadata(dict(status='connected',polled_at=100,last_tick_change_at=100,
        quote={'bid':100},charts={'M15':chart()}))
    start=datetime.fromisoformat(s['charts']['M15']['closed_end'])
    s['charts']['H1']=deepcopy(s['charts']['M15'])
    s['forming']['H1']=dict(time=start.isoformat(),closed_at=(start+timedelta(hours=1)).isoformat(),forming=True)
    return s


class BarSyncTests(unittest.TestCase):
    def test_fresh_quotes_with_stale_m15_do_not_invalidate_current_h1(self):
        s=sample();before=deepcopy(s['charts'])
        s['quote']['raw_epoch']+=1000
        result=live_reports(s,101)
        self.assertEqual(result['H1']['availability'],'live')
        self.assertEqual(result['M15']['availability'],'bars_lagging')
        self.assertFalse(result['M15']['actionable_current'])
        self.assertIsNone(result['M15']['forming_observation'])
        self.assertEqual(result['M15']['verdict'],'candidate')
        self.assertEqual(s['charts'],before)

    def test_shared_terminal_time_shift_does_not_depend_on_host_timezone(self):
        s=sample();before=live_reports(s,101)
        for c in s['charts'].values():
            c['closed_end']=(datetime.fromisoformat(c['closed_end'])+timedelta(hours=8)).isoformat()
        for b in s['forming'].values():
            for key in ('time','closed_at'):b[key]=(datetime.fromisoformat(b[key])+timedelta(hours=8)).isoformat()
        s['quote']['raw_epoch']+=8*3600
        after=live_reports(s,101)
        for p in ('H1','M15'):
            self.assertEqual(before[p]['bar_sync'],after[p]['bar_sync'])
            self.assertEqual(after[p]['availability'],'live')

    def test_future_candles_and_missing_or_invalid_metadata_fail_closed(self):
        for mutate in (lambda s:s.pop('forming'),lambda s:s['quote'].pop('raw_epoch'),
                       lambda s:s['quote'].update(raw_epoch=float('nan')),
                       lambda s:s['forming']['M15'].update(closed_at='invalid')):
            s=sample();mutate(s);r=live_reports(s,101)['M15']
            self.assertEqual(r['availability'],'bars_unverified');self.assertFalse(r['actionable_current'])
        s=sample();s['quote']['raw_epoch']-=60
        self.assertEqual(live_reports(s,101)['M15']['availability'],'bars_unaligned')

    def test_rollover_grace_and_analysis_pending_are_separate(self):
        s=sample();end=datetime.fromisoformat(s['forming']['M15']['closed_at']).timestamp()
        s['quote']['raw_epoch']=end+PARAMETERS['bar_sync_grace_seconds']-1
        self.assertEqual(live_reports(s,101)['M15']['availability'],'live')
        s['quote']['raw_epoch']+=1
        self.assertEqual(live_reports(s,101)['M15']['availability'],'bars_lagging')
        s['latest_closed_end']={'M15':s['forming']['M15']['closed_at']}
        self.assertEqual(live_reports(s,101)['M15']['availability'],'analysis_pending')
        s['status']='disconnected'
        self.assertEqual(live_reports(s,101)['M15']['availability'],'disconnected')
