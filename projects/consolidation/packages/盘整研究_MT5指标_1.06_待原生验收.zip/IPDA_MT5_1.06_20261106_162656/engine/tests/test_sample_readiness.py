import unittest
from copy import deepcopy
from datetime import datetime,timedelta,timezone
from ict_trader.sample_readiness import local_sample_readiness
from ict_trader.current_consolidation import classify,live_reports
from ict_trader.mt5_bridge import current_summary
from tests.test_current_consolidation import chart,native_metadata


def samples(count=20,gap_after=None):
    c=chart();base=datetime(2026,1,1,tzinfo=timezone.utc);bars=[]
    for i in range(count):
        start=base+timedelta(hours=i+(1 if gap_after is not None and i>=gap_after else 0))
        bars.append(dict(time=start.isoformat(),closed_at=(start+timedelta(hours=1)).isoformat()))
    row=c['phase_rows'][0];row['consolidation_evidence']['candidates']=[]
    c['phase_rows']=[dict(deepcopy(row),known_at=b['closed_at']) for b in bars]
    c.update(bars=bars,closed_end=bars[-1]['closed_at'])
    return c


class SampleReadinessTests(unittest.TestCase):
    def test_gap_counts_only_contiguous_closed_samples_and_excludes_future_or_forming(self):
        c=samples(gap_after=15);before=deepcopy(c)
        result=local_sample_readiness(c)
        self.assertEqual((result['window_bars'],result['bars_needed']),(5,7))
        self.assertEqual(result['reset_reason'],'data_gap')
        self.assertEqual(result['last_gap']['next_open_at'],c['bars'][15]['time'])
        self.assertEqual(c,before)
        c['bars'].append(dict(time=c['closed_end'],closed_at='2026-01-02T00:00:00+00:00',forming=True))
        c['phase_rows'].append(dict(deepcopy(c['phase_rows'][-1]),known_at=c['closed_end']))
        self.assertEqual(local_sample_readiness(c),result)
        c['bars'][-1]['forming']=False
        self.assertEqual(local_sample_readiness(c),result)

    def test_breakout_resets_window_without_claiming_gap_or_erasing_continuity(self):
        c=samples();c['phase_rows'][16]['consolidation_evidence']['event']='breakout_confirmed'
        result=local_sample_readiness(c)
        self.assertEqual(result['continuous_closed_bars'],20)
        self.assertEqual((result['window_bars'],result['bars_needed']),(3,9))
        self.assertEqual(result['reset_reason'],'breakout_confirmed')
        self.assertIsNone(result['last_gap'])
        c['phase_rows'][-1]['consolidation_evidence']['event']='breakout_confirmed'
        self.assertEqual(local_sample_readiness(c)['window_bars'],0)
        c=samples(gap_after=15);c['phase_rows'][10]['consolidation_evidence']['event']='breakout_confirmed'
        self.assertEqual(local_sample_readiness(c)['reset_reason'],'data_gap')

    def test_ready_does_not_mean_confirmed_and_unaligned_or_absent_samples_are_unknown(self):
        c=samples();self.assertEqual(local_sample_readiness(c)['status'],'ready')
        self.assertEqual(classify(c)['verdict'],'insufficient')
        c['bars'].pop();self.assertIsNone(local_sample_readiness(c))
        self.assertIsNone(local_sample_readiness(chart()))
        c=samples(12);c['phase_rows'][-1]['consolidation_evidence']['range']={'id':'frozen'}
        self.assertEqual(local_sample_readiness(c)['status'],'active')

    def test_diagnostic_preserves_verdict_score_and_stale_summary_does_not_present_it_as_live(self):
        c=samples(gap_after=15);original=deepcopy(c);expected=classify(c)
        s=native_metadata(dict(status='connected',polled_at=100,last_tick_change_at=100,
                              quote={'bid':100},charts={'M15':c}))
        result=live_reports(s,101)['M15']
        for key in ('verdict','score','checks','event','known_at','range'):
            self.assertEqual(result[key],expected[key])
        self.assertEqual(c,original)
        self.assertEqual(result['sample_readiness']['bars_needed'],7)
        self.assertIn('间隔后5/12根',current_summary(result))
        result['availability']='stale'
        self.assertNotIn('5/12',current_summary(result))


if __name__=='__main__':unittest.main()
