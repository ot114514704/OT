// Render accepted closed snapshots; verify ended facts are explicitly historical.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
function element(){return {dataset:{},children:[],textContent:'',classList:{add(){}},
 append(...items){this.children.push(...items)},replaceChildren(){this.children=[]}}}
const root=element(),context=vm.createContext({performance:{now:()=>1000},document:{
 getElementById:id=>id==='currentVerdicts'?root:element(),createElement:element}});
vm.runInContext(fs.readFileSync('ui/app.js','utf8').split('async function refresh()')[0],context);
const texts=node=>[node.textContent,...node.children.flatMap(texts)].join('\n');
let cases=0;
for(const item of JSON.parse(fs.readFileSync(process.argv[2],'utf8'))){
 context.input=JSON.stringify(item.state);
 vm.runInContext('state=JSON.parse(input);receivedAt=1000;renderCurrentVerdicts();',context);
 const r=item.state.current_consolidation[item.period];let output=texts(root);
 assert.equal(r.range_state,'ended');assert.notEqual(r.verdict,'confirmed');
 assert.ok(output.includes(item.period+' · '+r.label),item.name);
 assert.ok(output.includes('已结束区间实体'),item.name);
 assert.ok(output.includes('已结束区间形成形态：'),item.name);
 assert.ok(output.includes('原区间已结束，这些条件不代表当前仍在盘整'),item.name);
 assert.ok(!output.includes('所选候选窗口形态'),item.name);
 assert.ok(output.includes(r.score+'/100（不作为确认门槛）'),item.name);
 vm.runInContext(`state.current_consolidation[${JSON.stringify(item.period)}].availability='stale';renderCurrentVerdicts();`,context);
 output=texts(root);assert.ok(output.includes('当前判定不可用'));assert.ok(output.includes('上次判定：'+r.label));
 assert.ok(output.includes('已结束区间形成形态：'));cases++;
}
assert.ok(cases>0);
console.log(JSON.stringify({passed:true,cases,scope:'Actual current-card renderer; ended formation vs current verdict and stale fallback, not physical UI acceptance'}));
