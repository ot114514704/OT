import unittest
from copy import deepcopy
from datetime import datetime, timedelta, timezone

from ict_trader.retracement_validation import build_retracement_validation, attach_retracement_validation
from ict_trader.cisd import observe_cisd


def fixture(mirror=False):
    start=datetime(2026,1,1,tzinfo=timezone.utc)
    candles=[(120,121,113,114),(114,115,108,109),(109,112,107,110),
             (110,111,105,106),(106,111.5,105.5,109),(109,110.5,108,110),
             (110,113.1,109.5,111),(111,111.2,103,104)]
    bars=[];phases=[]
    for i,(o,h,l,c) in enumerate(candles):
        if mirror:o,h,l,c=200-o,200-l,200-h,200-c
        time=(start+timedelta(minutes=15*i)).isoformat()
        closed=(start+timedelta(minutes=15*(i+1))).isoformat()
        bars.append(dict(time=time,closed_at=closed,open=o,high=h,low=l,close=c))
        phases.append(dict(id=str(i),bar_open_at=time,known_at=closed,
            phase='retracement' if i>=4 else 'expansion',
            reference_before=dict(direction=1 if mirror else -1,low=75 if mirror else 100,
                high=100 if mirror else 125,origin_at=start.isoformat(),origin_ref='IT:known'),
            metrics={'atr14_prior':2},pda_contacts=[]))
    return dict(bars=bars,phases=phases)


class RetracementValidationTests(unittest.TestCase):
    def test_cisd_freezes_first_open_beyond_eight_bars_and_two_bar_confirmation(self):
        start=datetime(2026,1,1,tzinfo=timezone.utc);bars=[];phases=[]
        values=[(100+i,101+i) for i in range(10)]+[(110,101),(101,99)]
        for i,(o,c) in enumerate(values):
            t=(start+timedelta(hours=i)).isoformat();end=(start+timedelta(hours=i+1)).isoformat()
            bars.append(dict(time=t,closed_at=end,open=o,close=c,high=max(o,c)+.1,low=min(o,c)-.1))
            phases.append(dict(bar_open_at=t,metrics={'atr14_prior':2}))
        early=observe_cisd(bars[:-1],phases[:-1],'H1')
        self.assertEqual(early['events'],[])
        self.assertEqual(len(early['early_hints']),1)
        self.assertEqual(early['early_hints'][0]['basis_open'],100)
        final=observe_cisd(bars,phases,'H1')['events'][-1]
        self.assertEqual(final['basis_open'],100)
        self.assertEqual(final['sequence_bars'],10)
        self.assertEqual(final['trigger_bars'],2)
        bars[-1]['close']=100.2;bars[-1]['low']=98
        self.assertEqual(observe_cisd(bars,phases,'H1')['events'],[])

    def test_ordered_sfp_cisd_and_mirror(self):
        reports=[build_retracement_validation(fixture(x)) for x in (False,True)]
        for report in reports:
            wick,trigger=report['rows'][-2:]
            self.assertEqual(wick['state'],'rejection_awaiting_followthrough')
            self.assertFalse(any(wick['patterns'].values()))
            self.assertTrue(trigger['patterns']['sfp_cisd'])
            self.assertTrue(trigger['patterns']['fvg_rejection'])
            self.assertEqual(trigger['state'],'continuation_candidate')
            self.assertFalse(trigger['entry_qualified'])
            self.assertIsNone(trigger['checks']['volume_contraction'])
            self.assertIsNone(trigger['checks']['lower_timeframe_confirmation'])
            self.assertLessEqual(trigger['evidence_score']['score'],100)
        self.assertEqual(reports[0]['rows'][-1]['evidence_score']['score'],reports[1]['rows'][-1]['evidence_score']['score'])

    def test_no_cisd_when_close_does_not_cross_sequence_open(self):
        data=fixture();data['bars'][-1].update(open=113,high=113.2,low=106,close=106.5)
        row=build_retracement_validation(data)['rows'][-1]
        self.assertTrue(row['checks']['directional_displacement'])
        self.assertEqual(row['cisd_open_level'],106)
        self.assertFalse(row['checks']['cisd'])
        self.assertFalse(row['patterns']['sfp_cisd'])

    def test_long_wick_is_not_sweep_unless_prior_extreme_crossed(self):
        data=fixture();data['bars'][-2].update(high=111.4,low=109.5,close=110.1)
        row=build_retracement_validation(data)['rows'][-2]
        self.assertFalse(row['checks']['sfp'])

    def test_structure_conflict_blocks_trigger(self):
        data=fixture();data['bars'][-1].update(open=126,high=127,low=125,close=126)
        row=build_retracement_validation(data)['rows'][-1]
        self.assertEqual(row['state'],'structure_challenge')
        self.assertFalse(any(row['patterns'].values()))

    def test_prefix_causality_and_input_immutable(self):
        data=fixture();before=deepcopy(data);full=build_retracement_validation(data)
        for n in range(1,len(data['bars'])+1):
            prefix={**data,'bars':data['bars'][:n],'phases':data['phases'][:n]}
            self.assertEqual(build_retracement_validation(prefix)['rows'],full['rows'][:n])
        self.assertEqual(data,before)
        for row in full['rows']:
            for zone in row['pd_contacts']:
                self.assertLessEqual(zone['known_at'],row['bar_open_at'])

    def test_h1_protection_overrides_local_opposite_reference(self):
        data=fixture();last=data['bars'][-1]
        data['phases'][-1]['reference_before'].update(direction=1,low=108)
        parent=dict(id='h1',direction=-1,first_known_at=data['bars'][0]['time'],
                    protected_price=125,protected_known_at=data['bars'][0]['time'],
                    snapshot_at=last['time'],validated_at=last['time'])
        data['delivery_context']={'rows':[dict(bar_open_at=last['time'],known_at=last['closed_at'],
            background_status='available',h1_before=parent,protection_crossed=False)]}
        row=build_retracement_validation(data)['rows'][-1]
        self.assertEqual(row['reference_direction'],-1)
        self.assertTrue(row['checks']['structure_intact'])
        self.assertEqual(row['protection_source'],'prior_validated_H1_channel')
        parent['snapshot_at']=last['closed_at']
        with self.assertRaises(ValueError):build_retracement_validation(data)

    def test_blend_idempotent_bounded_and_does_not_change_labels(self):
        data=fixture()
        for p in data['phases']:
            p['fit_scores']={'by_phase':{'retracement':{'score':80,'components':[
                dict(name='geometry',weight=100,points=80,status='partial',observed=True)]}}}
        labels=[p['phase'] for p in data['phases']]
        attach_retracement_validation(data);before=deepcopy(data)
        attach_retracement_validation(data)
        self.assertEqual(data,before)
        self.assertEqual(labels,[p['phase'] for p in data['phases']])
        for p in data['phases']:
            score=p['fit_scores']['by_phase']['retracement']
            self.assertEqual(sum(x['weight'] for x in score['components']),100)
            self.assertLessEqual(score['score'],100)
            self.assertGreaterEqual(score['score'],0)


if __name__=='__main__':unittest.main()
