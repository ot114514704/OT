"""Deterministic synthetic invariants; no market-history or strategy backtest."""
import random
import unittest
from dataclasses import replace
from datetime import timedelta
from ict_trader.ipda_ranges import observe_ranges
from tests.test_consolidation import fixture,append,observe


def transformed(bars,scale=1,offset=0):
    return [replace(b,open=offset+scale*b.open,close=offset+scale*b.close,
        high=offset+scale*(b.high if scale>0 else b.low),
        low=offset+scale*(b.low if scale>0 else b.high),spread=abs(scale)*b.spread) for b in bars]


def sequence(seed):
    rng=random.Random(seed);bars=fixture()
    # Alternating containment, false breaks, sustained moves and one time gap.
    for i in range(32):
        close=100+rng.uniform(-.7,.7)
        if 6<=i<=7:close=102+(i-6)*.3
        if 18<=i<=21:close=96-(i-18)*.8
        previous=bars[-1].close
        bars=append(bars,previous,max(previous,close)+rng.uniform(.1,1.8),
                    min(previous,close)-rng.uniform(.1,1.8),close,gap=15 if i==25 else 0)
    return bars


class ConsolidationInvariantTests(unittest.TestCase):
    def test_synthetic_lifecycles_are_price_unit_and_direction_symmetric(self):
        opposite={'upper':'lower','lower':'upper','both':'both',None:None}
        checked_events=set()
        for seed in range(8):
            bars=sequence(seed);baseline=observe(bars)['rows']
            checked_events.update(r['event'] for r in baseline)
            for scale,offset in ((.1,500),(10,10000),(-1,300)):
                rows=observe(transformed(bars,scale,offset))['rows']
                for original,current in zip(baseline,rows):
                    with self.subTest(seed=seed,scale=scale,known_at=original['known_at']):
                        self.assertEqual(current['event'],original['event'])
                        self.assertEqual(current['sweep'],opposite[original['sweep']] if scale<0 else original['sweep'])
                        for field in ('active','ended'):
                            a,b=original[field],current[field]
                            self.assertEqual(a is None,b is None)
                            if a is None:continue
                            self.assertEqual(a['checks'],b['checks'])
                            self.assertEqual(a['sweep_count'],b['sweep_count'])
                            self.assertEqual(a['streak'],b['streak'])
                            self.assertEqual(b['side'],a['side']*(1 if scale>0 else -1))
                            for hi,lo in (('hi','lo'),('liquidity_hi','liquidity_lo')):
                                self.assertAlmostEqual(b[hi],offset+scale*a[hi if scale>0 else lo],places=8)
                                self.assertAlmostEqual(b[lo],offset+scale*a[lo if scale>0 else hi],places=8)
                            self.assertAlmostEqual(b['atr'],abs(scale)*a['atr'],places=8)
        self.assertTrue({'range_confirmed','breakout_pending','range_reclaimed','breakout_confirmed'}.issubset(checked_events))

    def test_every_prefix_is_causal_across_gap_and_failed_break(self):
        bars=sequence(7);full=observe(bars)
        for end in range(1,len(bars)+1):
            self.assertEqual(observe(bars[:end])['rows'],full['rows'][:end])
            self.assertEqual(observe_ranges(bars,bars[end-1].closed_at)['rows'],full['rows'][:end])

    def test_both_edges_in_one_candle_do_not_imply_order_or_two_sweeps(self):
        bars=append(fixture(),100,104,96,100)
        r=observe(bars)['rows'][-1]
        self.assertEqual(r['sweep'],'both');self.assertEqual(r['active']['sweep_count'],1)
        self.assertEqual(set(r['sweep_evidence']['excursions']),{'upper','lower'})
        self.assertNotIn('first_side',r['sweep_evidence'])
        self.assertFalse(r['active']['pending_sweeps'])

    def test_forming_price_mutation_cannot_create_exit_or_recovery(self):
        bars=append(fixture(),100,104,99,102)
        forming=append(bars,102,106,90,100)
        cutoff=bars[-1].closed_at+timedelta(minutes=7)
        baseline=observe_ranges(forming,cutoff)
        for price in (80,100,130):
            mutated=forming[:-1]+[replace(forming[-1],high=max(106,price),low=min(90,price),close=price)]
            self.assertEqual(observe_ranges(mutated,cutoff),baseline)
