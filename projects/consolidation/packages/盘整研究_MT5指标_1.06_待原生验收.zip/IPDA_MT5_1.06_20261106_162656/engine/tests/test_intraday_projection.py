import unittest
from copy import deepcopy
from ict_trader.intraday_projection import attach_intraday_projection


class IntradayProjectionTests(unittest.TestCase):
    def test_serialized_confirmed_source_keeps_m15_qualification_and_its_own_clock(self):
        source=dict(id='accepted-without-flag',observed_from='2026-11-04T10:00:00+00:00',
            known_at='2026-11-04T16:00:00+00:00',end_at='2026-11-04T18:45:00+00:00',
            liquidity_low=4030,liquidity_high=4055,status='区间延续',profile=dict(tags=['rectangle']))
        charts=dict(H1=dict(bars=[dict(time='2026-11-01T00:00:00+00:00')],closed_end='2026-11-04T18:00:00+00:00'),
            M15=dict(consolidations=[source],closed_end=source['end_at']))
        original=deepcopy(charts['M15']);attach_intraday_projection(charts)
        projected=charts['H1']['intraday_structures'][0]
        self.assertTrue(projected['source_confirmed']);self.assertTrue(projected['active'])
        self.assertFalse(projected['confirmed']);self.assertFalse(projected['score_included'])
        self.assertEqual(charts['M15'],original)
        for status in ('向上突破条件触发','数据间隔中止','边线交会，斜线候选失效'):
            source['status']=status;source['active']=True
            attach_intraday_projection(charts)
            self.assertFalse(charts['H1']['intraday_structures'][0]['active'])
        source['status']='区间延续';source.pop('active');charts['M15']['closed_end']='2026-11-04T19:00:00+00:00'
        attach_intraday_projection(charts);self.assertFalse(charts['H1']['intraday_structures'][0]['active'])

    def test_geometric_source_does_not_gain_confirmation_from_projection(self):
        source=dict(id='candidate',observed_from='2026-11-04T10:00:00+00:00',
            known_at='2026-11-04T16:00:00+00:00',end_at='2026-11-04T18:00:00+00:00',
            observed_low=4030,observed_high=4055,status='长尺度收敛形态候选',active=True,confirmed=False)
        charts=dict(H1=dict(bars=[dict(time='2026-11-01T00:00:00+00:00')]),
            M15=dict(geometric_ranges=[source],closed_end=source['end_at']))
        attach_intraday_projection(charts);projected=charts['H1']['intraday_structures'][0]
        self.assertTrue(projected['active']);self.assertFalse(projected['source_confirmed'])
        self.assertFalse(projected['projection_confirmed'])

    def test_native_child_evidence_does_not_promote_h1_or_mutate_m15(self):
        source=dict(id='native-child',observed_from='2026-11-04T10:00:00+00:00',
            known_at='2026-11-04T16:00:00+00:00',end_at='2026-11-04T18:00:00+00:00',
            liquidity_low=4030,liquidity_high=4055,status='已结束',confirmed=True,
            score=dict(score=85),profile=dict(tags=['rectangle']))
        charts=dict(H1=dict(bars=[dict(time='2026-11-01T00:00:00+00:00')],verdict='证据不足'),
            M15=dict(consolidations=[source]))
        before=deepcopy(charts['M15']);attach_intraday_projection(charts)
        self.assertEqual(before,charts['M15']);self.assertEqual(charts['H1']['verdict'],'证据不足')
        child=charts['H1']['intraday_structures'][0]
        self.assertEqual(child['source_id'],source['id']);self.assertEqual(child['source_period'],'M15')
        self.assertFalse(child['projection_confirmed']);self.assertFalse(child['score_included'])
        self.assertFalse(child['confirmed']);self.assertTrue(child['source_confirmed'])
        self.assertEqual((child['projection_low'],child['projection_high']),(4030,4055))
        child['score']['score']=0
        self.assertEqual(source['score']['score'],85)

    def test_short_stop_and_unloaded_child_are_excluded(self):
        source=dict(id='short',observed_from='2026-11-04T10:00:00+00:00',known_at='2026-11-04T11:00:00+00:00')
        charts=dict(H1=dict(bars=[dict(time='2026-11-04T12:00:00+00:00')]),M15=dict(consolidations=[source]))
        attach_intraday_projection(charts);self.assertFalse(charts['H1']['intraday_structures'])

