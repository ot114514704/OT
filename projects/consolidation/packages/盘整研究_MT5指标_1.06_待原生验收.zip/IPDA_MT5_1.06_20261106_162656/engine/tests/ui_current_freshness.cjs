// Execute production current-card rendering with a cached live response.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
function element(){return {dataset:{},children:[],textContent:'',classList:{add(){}},
 append(...items){this.children.push(...items)},replaceChildren(){this.children=[]}}}
const root=element();let now=1000;
const context=vm.createContext({performance:{now:()=>now},document:{
 getElementById:id=>id==='currentVerdicts'?root:element(),createElement:element}});
vm.runInContext(fs.readFileSync('ui/app.js','utf8').split('async function refresh()')[0],context);
const texts=node=>[node.textContent,...node.children.flatMap(texts)].join('\n');
const messages=['局部位置样本','外层位置样本','轨道位置样本','实体候选位置样本'];
const report={availability:'live',poll_age_seconds:0,known_at:'2026-11-06T09:30:00',
 verdict:'confirmed',label:'已确认盘整',reason:'已收盘证据',checks:{compact:true},score:75,
 range:{low:100,high:110,liquidity_low:98,liquidity_high:112},
 forming_observation:{message:messages[0]},
 macro_context:{verdict:'confirmed',label:'外层已确认',range:{low:95,high:115,liquidity_low:93,liquidity_high:117,known_at:'2026-11-06T09:00:00'},forming_observation:{message:messages[1]}},
 candidate_observations:[{shape:'tilted',closed_position:{message:'收盘位置'},forming_observation:{message:messages[2],lower:100,upper:110}}],
 body_candidate_observation:{message:messages[3],price:105,window:24,low:100,high:110,observed_low:98,observed_high:112,policy:'末柱不确认'}};
// Every observation branch in one transport fixture, not a claim that all model
// qualifications coexist. The renderer must suppress each on stale transport.
const input={current_consolidation:{H1:structuredClone(report),M15:structuredClone(report)}};
context.input=JSON.stringify(input);
vm.runInContext('state=JSON.parse(input);receivedAt=1000;renderCurrentVerdicts()',context);
const assertLive=card=>{const output=texts(card);for(const message of messages)assert.ok(output.includes(message),message)};
const assertUnavailable=card=>{const output=texts(card);assert.ok(output.includes('当前判定不可用'));
 for(const message of messages)assert.ok(!output.includes(message),'stale forming observation leaked: '+message);
 assert.ok(output.includes('等待新鲜行情后恢复末柱位置观察'));
 assert.ok(output.includes('上次判定：已确认盘整'));
 assert.ok(output.includes('100.00—110.00'),'frozen closed evidence must remain');
 assert.ok(output.includes('75/100'),'closed score must remain');};
assertLive(root.children[0]);assertLive(root.children[1]);
vm.runInContext('networkDown=true;renderCurrentVerdicts()',context);
assertUnavailable(root.children[0]);assertUnavailable(root.children[1]);
vm.runInContext('networkDown=false;renderCurrentVerdicts()',context);assertLive(root.children[1]);
now=16000;vm.runInContext('renderCurrentVerdicts()',context);assertLive(root.children[1]);
now=16001;vm.runInContext('renderCurrentVerdicts()',context);assertUnavailable(root.children[0]);assertUnavailable(root.children[1]);
vm.runInContext('receivedAt=performance.now();renderCurrentVerdicts()',context);assertLive(root.children[1]);
// Server age and client elapsed time combine; fresh H1 must not hide stale M15.
vm.runInContext('state.current_consolidation.M15.poll_age_seconds=14;renderCurrentVerdicts()',context);
now+=1001;vm.runInContext('renderCurrentVerdicts()',context);assertLive(root.children[0]);assertUnavailable(root.children[1]);
for(const health of ['stale','analysis_pending','disconnected','bars_lagging','quote_idle','source_mismatch','snapshot']){
 context.health=health;
 vm.runInContext('receivedAt=performance.now();state.current_consolidation.M15.poll_age_seconds=0;state.current_consolidation.M15.availability=health;renderCurrentVerdicts()',context);
 assertLive(root.children[0]);assertUnavailable(root.children[1]);
}
vm.runInContext("state.current_consolidation.M15.availability='live';renderCurrentVerdicts()",context);assertLive(root.children[1]);
assert.equal(vm.runInContext('JSON.stringify(state)',context),JSON.stringify(input),'rendering must not mutate model evidence');
console.log(JSON.stringify({passed:true,scope:'Production renderer: client loss/elapsed age, independent periods, recovery, frozen evidence and model immutability; no physical UI acceptance'}));
