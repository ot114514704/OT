import unittest
from unittest.mock import Mock
import supervisor


class SupervisorTests(unittest.TestCase):
    def test_only_owned_matching_reader_is_restartable(self):
        info=dict(service='ipda_consolidation',project_root=str(supervisor.ROOT),process_id=42,worker_heartbeat_at=99)
        self.assertEqual(supervisor.assess(info,42,100),'healthy')
        self.assertEqual(supervisor.assess(info,None,100),'external_service')
        self.assertEqual(supervisor.assess(info,43,100),'foreign_service')
        self.assertEqual(supervisor.assess({**info,'service':'other'},42,100),'foreign_service')
        self.assertEqual(supervisor.assess({**info,'worker_heartbeat_at':1},42,200),'worker_unresponsive')

    def test_stop_never_touches_an_already_exited_process(self):
        child=Mock();child.poll.return_value=0
        supervisor.stop_child(child);child.terminate.assert_not_called()

    def test_windows_venv_interpreter_requires_the_own_supervisor_marker(self):
        info=dict(service='ipda_consolidation',project_root=str(supervisor.ROOT),process_id=99,worker_heartbeat_at=99,supervisor_pid='7')
        self.assertEqual(supervisor.assess(info,42,100,7),'healthy')
        self.assertEqual(supervisor.assess(info,42,100,8),'foreign_service')
        self.assertEqual(supervisor.assess({**info,'project_root':str(supervisor.ROOT.parent)},42,100,7),'foreign_service')

    def test_model_stall_is_detected_even_while_market_reader_heartbeat_moves(self):
        info=dict(service='ipda_consolidation',project_root=str(supervisor.ROOT),process_id=42,worker_heartbeat_at=499,
                  analysis_running=True,analysis_started_at=300)
        self.assertEqual(supervisor.assess(info,42,500),'model_unresponsive')
        self.assertEqual(supervisor.assess({**info,'analysis_started_at':490},42,500),'healthy')
        self.assertEqual(supervisor.assess({**info,'analysis_running':False},42,500),'healthy')
