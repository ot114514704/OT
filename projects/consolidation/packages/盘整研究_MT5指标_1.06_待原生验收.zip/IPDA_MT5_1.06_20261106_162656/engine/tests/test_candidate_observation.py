import unittest
from copy import deepcopy
from ict_trader.candidate_observation import candidate_price_observations
from ict_trader.current_consolidation import live_reports
from ict_trader.mt5_bridge import current_summary, shape_record
from tests.test_current_consolidation import chart, native_metadata


def state():
    c=chart();end=c['closed_end']
    common=dict(id='channel',shape='tilted',active=True,known_at=end,end_at=end,
        first_observed_at=end,observed_from='2026-01-01T00:00:00+00:00',
        frozen_atr=2,confirmed=False,score_included=False,side=1,streak=1,status='结构盘整候选')
    channel=dict(common,last_upper=104,last_lower=94,slope_per_bar=2)
    def point(time,price):return dict(time='2026-01-01T'+time+':00+00:00',price=price,known_at=end)
    geometry=dict(validated=True,upper=[point('00:00',110),point('00:30',108)],
        lower=[point('00:00',90),point('00:30',92)])
    triangle=dict(common,id='triangle',shape='converging',geometry=geometry,side=0,streak=0)
    c.update(structural_current=[channel],geometric_current=[triangle])
    s=native_metadata(dict(status='connected',polled_at=100,last_tick_change_at=100,quote={'bid':100},charts={'M15':c}))
    s['forming']['M15'].update(close=100,open=100,high=100,low=100)
    return s


class CandidateObservationTests(unittest.TestCase):
    def test_latest_observed_bar_uses_correct_rail_clock_without_mutating_source(self):
        s=state();before=deepcopy(s);report=live_reports(s,101)['M15'];items=report['candidate_observations']
        channel,triangle=[x['forming_observation'] for x in items]
        self.assertEqual((channel['lower'],channel['upper']),(96,106))
        self.assertEqual((triangle['lower'],triangle['upper']),(94,106))
        self.assertTrue(all(x['code']=='inside' for x in (channel,triangle)))
        self.assertEqual(items[0]['closed_position']['code'],'outside_pending')
        self.assertEqual(items[0]['closed_position']['streak'],1) # returning forming price cannot erase closed evidence
        self.assertEqual(s,before)

    def test_forming_changes_never_promote_exit_or_rewrite_verdict_score_and_lines(self):
        s=state();before=deepcopy(s['charts']);baseline=live_reports(s,101)['M15']
        for price,code in [(107,'above_threshold'),(106.1,'edge'),(93,'below_threshold'),(100,'inside')]:
            s['forming']['M15']['close']=price
            actual=live_reports(s,101)['M15']
            for x in actual['candidate_observations']:
                self.assertEqual(x['forming_observation']['code'],code)
                self.assertFalse(x['confirmed']);self.assertFalse(x['score_included'])
                self.assertFalse(x['forming_observation']['confirmed'])
            for key in ('verdict','score','checks','event','known_at','range'):
                self.assertEqual(actual[key],baseline[key])
        self.assertEqual(s['charts'],before)

    def test_reflected_price_and_slopes_are_direction_symmetric(self):
        s=state();s['forming']['M15']['close']=108
        original=live_reports(s,101)['M15']['candidate_observations'];mirrored=deepcopy(s)
        mirrored['forming']['M15']['close']=200-108
        c=mirrored['charts']['M15'];b=c['structural_current'][0]
        b.update(last_upper=200-b['last_lower'],last_lower=200-b['last_upper'],slope_per_bar=-b['slope_per_bar'],side=-1)
        g=c['geometric_current'][0]['geometry'];upper=deepcopy(g['upper']);lower=deepcopy(g['lower'])
        g['upper']=[dict(p,price=200-p['price']) for p in lower]
        g['lower']=[dict(p,price=200-p['price']) for p in upper]
        other=live_reports(mirrored,101)['M15']['candidate_observations']
        for a,b in zip(original,other):
            self.assertEqual(a['forming_observation']['code'],'above_threshold')
            self.assertEqual(b['forming_observation']['code'],'below_threshold')
            self.assertAlmostEqual(b['forming_observation']['lower'],200-a['forming_observation']['upper'])

    def test_closed_crossing_is_not_prematurely_invalidated_by_forming_line_intersection(self):
        s=state();g=s['charts']['M15']['geometric_current'][0]['geometry']
        g['upper'][1]['price']=100;g['lower'][1]['price']=100
        before=deepcopy(s['charts'])
        result=live_reports(s,101)['M15']['candidate_observations'][1]
        self.assertEqual(result['forming_observation']['code'],'rails_crossed')
        self.assertEqual(s['charts'],before);self.assertTrue(s['charts']['M15']['geometric_current'][0]['active'])

    def test_unavailable_pending_or_unaligned_market_suppresses_price_observations(self):
        for change in ('disconnected','stale','quote_idle','pending','gap','source'):
            s=state();now=101
            if change=='disconnected':s['status']='disconnected'
            elif change=='stale':now=116
            elif change=='quote_idle':s['last_tick_change_at']=50
            elif change=='pending':s['latest_closed_end']={'M15':'2026-01-01T01:15:00+00:00'}
            elif change=='gap':s['forming']['M15']['time']='2026-01-01T01:15:00+00:00'
            else:s['quote']['market_source']['status']='unverified'
            with self.subTest(change=change):self.assertEqual(live_reports(s,now)['M15']['candidate_observations'],[])

    def test_ended_old_or_future_candidates_cannot_gain_current_price_observation(self):
        for change in ('ended','old','future','future_anchor','invalid_price','not_forming'):
            s=state();c=s['charts']['M15'];b=c['geometric_current'][0];c['structural_current']=[]
            if change=='ended':b['active']=False
            elif change=='old':b['end_at']='2026-01-01T00:45:00+00:00'
            elif change=='future':b['first_observed_at']='2099-01-01T00:00:00+00:00'
            elif change=='future_anchor':b['geometry']['upper'][0]['known_at']='2099-01-01T00:00:00+00:00'
            elif change=='invalid_price':s['forming']['M15']['close']=float('nan')
            else:s['forming']['M15']['forming']=False
            with self.subTest(change=change):self.assertEqual(candidate_price_observations(c,s['forming']['M15']),[])

    def test_mt5_health_explains_pending_and_forming_without_promoting_candidate(self):
        s=state();s['forming']['M15']['close']=108
        r=live_reports(s,101)['M15'];summary=current_summary(dict(label='证据不足',availability='live'),r)
        self.assertIn('M15 形态1段收盘越界待跟进',summary)
        self.assertIn('M15 形态2段末柱越界观察',summary)
        r['availability']='stale';self.assertNotIn('末柱越界观察',current_summary(r))
        c=s['charts']['M15']['structural_current'][0]
        box=dict(c,shape='rectangle',observed_low=94,observed_high=104)
        fields=shape_record('M15','structural',box).split('\t')
        self.assertIn('越界待跟进',fields[21]);self.assertIn('1/2 根',fields[23]);self.assertIn('候选未确认',fields[23])
        ended=shape_record('M15','structural',dict(box,active=False,status='向上离开结构观察区')).split('\t')
        self.assertNotIn('越界待跟进',ended[21]);self.assertNotIn('1/2 根',ended[23])
