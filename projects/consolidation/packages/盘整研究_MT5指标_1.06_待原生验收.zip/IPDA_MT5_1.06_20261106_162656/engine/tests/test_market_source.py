import json
import unittest
from types import SimpleNamespace
from ict_trader.market_source import inspect_source


class MarketSourceTests(unittest.TestCase):
    def inspect(self,company='TradeMax Global Limited',server='TradeMaxGlobal-Live',symbol='XAUUSD'):
        account=SimpleNamespace(company=company,server=server,login='PRIVATE_LOGIN',balance='PRIVATE_BALANCE')
        return inspect_source(SimpleNamespace(account_info=lambda:account),SimpleNamespace(name=symbol))

    def test_verified_labels_do_not_expose_account_fields(self):
        result=self.inspect();self.assertEqual(result['status'],'verified')
        serialized=json.dumps(result)
        self.assertNotIn('PRIVATE',serialized);self.assertNotIn('login',result);self.assertNotIn('balance',result)

    def test_wrong_or_missing_metadata_never_matches(self):
        for kwargs in ({'company':'Other Broker'},{'server':'Other-Live'},{'symbol':'XAUUSD.fake'},
                       {'company':'TradeMax Global Limited copy'}):
            with self.subTest(kwargs=kwargs):self.assertEqual(self.inspect(**kwargs)['status'],'source_mismatch')
        self.assertEqual(self.inspect(company=None)['status'],'source_unverified')
        result=inspect_source(SimpleNamespace(account_info=lambda:None),SimpleNamespace(name='XAUUSD'))
        self.assertEqual(result['status'],'source_unverified')
