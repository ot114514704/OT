"""Keep ended formation facts separate from the latest closed-bar verdict."""
import unittest
from copy import deepcopy
from dataclasses import replace
from datetime import timedelta

import app
from ict_trader.current_consolidation import classify, live_reports, CHECK_NAMES
from ict_trader.live_audit import audit_payload
from tests.test_consolidation import fixture, append


def raw_for(bars):
    start=bars[0].time
    # Preserve gaps and use equivalent bar spacing in each period.
    return {p:[app.row(replace(b,time=start+(b.time-start)*(seconds/900),seconds=seconds))
               for b in bars] for p,seconds in [('H1',3600),('M15',900)]}


class EndedRangeEvidenceTests(unittest.TestCase):
    def assert_frozen(self,chart,expected_verdict,state):
        report=classify(chart);e=chart['phase_rows'][-1]['consolidation_evidence']
        box=e.get('range') or e['ended']
        self.assertEqual(report['verdict'],expected_verdict)
        self.assertEqual(report['range_state'],state)
        self.assertEqual(report['checks_basis'],'first_confirmation')
        self.assertEqual(report['checks_known_at'],box['known_at'])
        self.assertEqual(report['known_at'],chart['closed_end'])
        self.assertEqual(report['checks'],{CHECK_NAMES[k]:v for k,v in box['checks'].items()})
        self.assertEqual(report['profile'],box['profile'])
        self.assertEqual(report['range'],box)
        self.assertEqual(report['score'],chart['phase_rows'][-1]['fit_scores']['by_phase']['consolidation']['score'])
        return report

    def test_up_and_down_exits_retain_formation_but_never_confirm_current_balance(self):
        bars=append(append(fixture(),100,103,99,102),102,105,101.5,104)
        for direction in (1,-1):
            transformed=bars if direction==1 else [replace(b,open=200-b.open,high=200-b.low,low=200-b.high,close=200-b.close) for b in bars]
            charts=app.calculate(raw_for(transformed));before=deepcopy(charts)
            for chart in charts.values():
                report=self.assert_frozen(chart,'not_consolidation','ended')
                self.assertEqual(report['range']['breakout_side'],direction)
                self.assertLess(report['checks_known_at'],report['known_at'])
                self.assertIsNone(chart['current_candidate'])
            self.assertEqual(charts,before)

    def test_gap_termination_keeps_original_clock_and_next_bar_does_not_inherit_it(self):
        bars=append(fixture(),100,101,99,100,gap=15)
        charts=app.calculate(raw_for(bars))
        for chart in charts.values():
            report=self.assert_frozen(chart,'insufficient','ended')
            self.assertEqual(report['event'],'data_gap')
            self.assertLess(report['range']['end_at'],report['known_at'])
        following=app.calculate(raw_for(append(bars,100,101,99,100)))
        for chart in following.values():
            report=classify(chart)
            self.assertIsNone(report['range']);self.assertIsNone(report['range_state'])
            self.assertEqual(report['checks_basis'],'current_candidate_window')
            self.assertEqual(report['checks_known_at'],report['known_at'])
            self.assertIsNone(report['profile'])

    def test_active_and_ended_ranges_have_distinct_scope_and_audit_rejects_misattribution(self):
        bars=append(append(fixture(),100,103,99,102),102,105,101.5,104)
        for source,state,verdict in ((bars[:-1],'active','confirmed'),(bars,'ended','not_consolidation')):
            charts=app.calculate(raw_for(source))
            for c in charts.values():self.assert_frozen(c,verdict,state)
            payload=app.response_payload(dict(status='snapshot',charts=charts),100)
            self.assertTrue(audit_payload(payload)['passed'])
            for change,code in (({'checks_basis':'current_candidate_window'},'current_frozen_evidence_scope'),
                                ({'checks_known_at':charts['M15']['closed_end']},'current_frozen_evidence_scope'),
                                ({'profile':None},'current_frozen_evidence_source'),
                                ({'checks':{}},'current_frozen_evidence_source')):
                invalid=deepcopy(payload);invalid['current_consolidation']['M15'].update(change)
                self.assertIn(code,[i['code'] for i in audit_payload(invalid)['issues']])

    def test_forming_or_unavailable_prices_cannot_reactivate_ended_evidence(self):
        bars=append(append(fixture(),100,103,99,102),102,105,101.5,104)
        charts=app.calculate(raw_for(bars));end=charts['M15']['closed_end']
        from ict_trader.core import instant
        stamp=instant(end)
        state=dict(status='connected',charts={'M15':charts['M15']},polled_at=100,last_tick_change_at=100,
                   quote=dict(raw_epoch=stamp.timestamp()+1,market_source={'status':'verified'}),
                   forming={'M15':dict(time=end,closed_at=(stamp+timedelta(minutes=15)).isoformat(),
                                      forming=True,open=104,high=200,low=50,close=100)})
        for status,clock in (('connected',101),('connected',120),('disconnected',101)):
            state['status']=status;report=live_reports(state,clock)['M15']
            self.assertEqual(report['verdict'],'not_consolidation');self.assertEqual(report['range_state'],'ended')
            self.assertIsNone(report['forming_observation']);self.assertIsNone(report['body_candidate_observation'])


if __name__=='__main__':unittest.main()
