import unittest
from dataclasses import replace
from datetime import timedelta
from ict_trader.oscillation import strong_oscillation
from ict_trader.ipda_ranges import _candidate
from tests.test_consolidation import fixture
from tests.test_consolidation_invariants import transformed


class StrongOscillationTests(unittest.TestCase):
    def bars(self,values):
        first=fixture()[0]
        return [replace(first,time=first.time+timedelta(minutes=15*i),open=value-.1,high=value+.5,low=value-.5,close=value) for i,value in enumerate(values)]

    def test_small_center_wiggles_and_one_v_are_not_selected(self):
        weak=[replace(b,open=100+(.5 if i%2 else -.5)-.1,close=100+(.5 if i%2 else -.5)) for i,b in enumerate(fixture())]
        c=_candidate(weak,0,len(weak)-1)
        self.assertFalse(c['checks']['strong_oscillation']);self.assertFalse(c['qualified'])
        v=self.bars([104,103,102,101,100,99,98,99,100,101,102,103])
        self.assertFalse(strong_oscillation(v,1,6)['qualified'])

    def test_multiple_large_closed_legs_are_selected_and_scale_symmetric(self):
        bars=fixture();base=strong_oscillation(bars,3,2.3)
        self.assertTrue(base['qualified']);self.assertGreaterEqual(base['completed_legs'],3)
        for scale,offset in ((.1,500),(10,10000),(-1,300)):
            r=strong_oscillation(transformed(bars,scale,offset),abs(scale)*3,abs(scale)*2.3)
            self.assertTrue(r['qualified']);self.assertEqual(r['completed_legs'],base['completed_legs'])
            self.assertEqual(r['up_legs'],base['down_legs'] if scale<0 else base['up_legs'])
        for leg in base['legs']:
            self.assertGreaterEqual(leg['amplitude'],base['threshold'])
            self.assertLessEqual(leg['reversal_observed_at'],leg['known_at'])

    def test_channel_requires_residual_reversals_not_just_a_fitted_slope(self):
        flat=self.bars([100]*24)
        trend=[replace(b,open=b.open+i*.4,close=b.close+i*.4,high=b.high+i*.4,low=b.low+i*.4) for i,b in enumerate(flat)]
        self.assertFalse(strong_oscillation(trend,1,4,.4)['qualified'])
        swinging=self.bars(([100,103,100,97]*6))
        channel=[replace(b,open=b.open+i*.1,close=b.close+i*.1,high=b.high+i*.1,low=b.low+i*.1) for i,b in enumerate(swinging)]
        self.assertTrue(strong_oscillation(channel,1,7,.1)['qualified'])

    def test_expansion_after_oscillation_is_not_wrapped_as_another_range(self):
        bars=self.bars([100,104,100,96]*6+[100,104,108,112,116,120])
        # Even detrending must not conceal the unreclaimed raw expansion.
        r=strong_oscillation(bars,1,18,.3)
        self.assertFalse(r['qualified']);self.assertTrue(r['unreversed_displacements'])

    def test_missing_path_cannot_create_a_confirmed_swing(self):
        bars=self.bars([100,100,100,104,104,104,100,100,100,104,104,104])
        for start in (3,6,9):
            for i in range(start,len(bars)):bars[i]=replace(bars[i],time=bars[i].time+timedelta(days=1))
        r=strong_oscillation(bars,1,5)
        self.assertEqual(r['completed_legs'],0);self.assertFalse(r['qualified'])
