// Exercise the pure predicates from the actual MQ5 source in a JS VM.
// This checks clock/model state logic; it does NOT execute MQL or chart APIs.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const file=process.argv[2]||'mt5/IPDA_Consolidation.mq5';
const source=fs.readFileSync(file,'utf8');
function extract(name){
 const match=source.match(new RegExp('(?:bool|string) '+name+'\\([^)]*\\)\\s*\\{'));
 assert.ok(match,`Missing production helper ${name}`);
 const start=match.index;let end=start+match[0].length,depth=1;
 while(depth&&end<source.length){const ch=source[end++];if(ch==='{')depth++;if(ch==='}')depth--;}
 assert.equal(depth,0);
 return source.slice(start,end).replace(/^(bool|string) /,'function ')
  .replace(/const (long|ulong|string) /g,'').replace(/\(long\)/g,'');
}
let wall=1000,ticks=5000;
const context=vm.createContext({TimeGMT:()=>wall,GetTickCount64:()=>ticks,
 heartbeat_written:1000,last_change:5000,expected_revision:'new',revision:'new',rendered_revision:'old',health:'TEST_LIVE'});
for(const name of ['HeartbeatFresh','ModelPainted','FeedFresh','DisplayHealth'])vm.runInContext(extract(name),context);
const results=[];
function check(name,expression){assert.equal(vm.runInContext(expression,context),true,name);results.push({name,passed:true});}
check('old file on startup','!HeartbeatFresh(1000,980,5000,5000)');
check('fresh startup','HeartbeatFresh(1000,1000,5000,5000)');
check('unobserved stream','!HeartbeatFresh(1000,1000,5000,0)');
check('wall age at limit','HeartbeatFresh(1015,1000,5001,5000)');
check('wall age beyond limit','!HeartbeatFresh(1016,1000,5001,5000)');
check('stream age at limit','HeartbeatFresh(1000,1000,20000,5000)');
check('stream stopped','!HeartbeatFresh(1000,1000,20001,5000)');
check('stream resumes','HeartbeatFresh(1017,1017,22000,22000)');
check('future timestamp tolerance','HeartbeatFresh(1000,1005,5000,5000)');
check('future timestamp rejected','!HeartbeatFresh(1000,1006,5000,5000)');
check('missing timestamp','!HeartbeatFresh(1000,0,5000,5000)');
check('reversed monotonic time','!HeartbeatFresh(1000,1000,4999,5000)');
check('empty model','!ModelPainted("","","")');
check('heartbeat before file','!ModelPainted("new","old","old")');
check('loaded before rendered','!ModelPainted("new","new","old")');
check('wrong rendered model','!ModelPainted("new","new","other")');
check('matching rendered model','ModelPainted("new","new","new")');
check('deferred display','DisplayHealth().includes("模型图形待同步")');
context.rendered_revision='new';check('completed display','DisplayHealth()==="TEST_LIVE"');
wall=1060;check('expired file overrides status','DisplayHealth().includes("历史保留") && DisplayHealth()!=="TEST_LIVE"');
// Production wiring must not advance the receipt at file-load time.
const acknowledge=source.slice(source.indexOf('void Acknowledge()'),source.indexOf('string ReadLine('));
assert.match(acknowledge,/\\t"\+rendered_revision/);
const load=source.slice(source.indexOf('void LoadShapes()'),source.indexOf('color LineColor('));
assert.match(load,/h\[2\]!=expected_revision/);assert.doesNotMatch(load,/rendered_revision\s*=/);
const render=source.slice(source.indexOf('void Render()'),source.indexOf('int OnInit()'));
assert.ok(render.indexOf('ChartRedraw();')<render.indexOf('rendered_revision=revision;'));
console.log(JSON.stringify({passed:true,checks:results.length,wiring_checks:4,results,
 scope:'Pure production MQ5 predicates translated to JavaScript; chart wiring checked from source. Not native MQL execution or physical drag acceptance.'},null,2));
