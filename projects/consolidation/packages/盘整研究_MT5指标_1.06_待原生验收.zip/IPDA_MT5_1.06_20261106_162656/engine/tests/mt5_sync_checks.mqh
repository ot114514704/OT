// Injected into a temporary native validation build, absent from release EX5.
int sync_test_file=INVALID_HANDLE,sync_test_count=0,sync_test_failures=0;
void SyncCheck(const string name,const bool passed)
  {
   sync_test_count++;if(!passed)sync_test_failures++;
   FileWriteString(sync_test_file,name+"\t"+(passed?"PASS":"FAIL")+"\n");
  }
bool RunSyncChecks()
  {
   sync_test_file=FileOpen(InpFolder+"\\sync_1.06_validation.tsv",FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ,0,CP_UTF8);
   if(sync_test_file==INVALID_HANDLE)return false;
   SyncCheck("old_file_on_startup",!HeartbeatFresh(1000,980,5000,5000));
   SyncCheck("fresh_file_on_startup",HeartbeatFresh(1000,1000,5000,5000));
   SyncCheck("never_observed",!HeartbeatFresh(1000,1000,5000,0));
   SyncCheck("wall_age_at_limit",HeartbeatFresh(1015,1000,5001,5000));
   SyncCheck("wall_age_over_limit",!HeartbeatFresh(1016,1000,5001,5000));
   SyncCheck("stream_age_at_limit",HeartbeatFresh(1000,1000,20000,5000));
   SyncCheck("stream_stopped_despite_new_wall_time",!HeartbeatFresh(1000,1000,20001,5000));
   SyncCheck("stream_resumes",HeartbeatFresh(1017,1017,22000,22000));
   SyncCheck("future_at_tolerance",HeartbeatFresh(1000,1005,5000,5000));
   SyncCheck("future_over_tolerance",!HeartbeatFresh(1000,1006,5000,5000));
   SyncCheck("missing_written_time",!HeartbeatFresh(1000,0,5000,5000));
   SyncCheck("monotonic_clock_reversed",!HeartbeatFresh(1000,1000,4999,5000));
   SyncCheck("empty_model",!ModelPainted("","",""));
   SyncCheck("new_heartbeat_old_file",!ModelPainted("new","old","old"));
   SyncCheck("new_file_drag_deferred",!ModelPainted("new","new","old"));
   SyncCheck("different_rendered_model",!ModelPainted("new","new","other"));
   SyncCheck("render_completed",ModelPainted("new","new","new"));
   // Exercise the actual status composition without changing chart objects,
   // drawing data, or sending synthetic receipts to the production bridge.
   string old_expected=expected_revision,old_loaded=revision,old_rendered=rendered_revision,old_health=health;
   ulong old_change=last_change;long old_written=heartbeat_written;
   expected_revision="new";revision="new";rendered_revision="old";health="TEST_LIVE";
   last_change=GetTickCount64();heartbeat_written=(long)TimeGMT();
   SyncCheck("deferred_status",StringFind(DisplayHealth(),"模型图形待同步")>=0);
   rendered_revision="new";SyncCheck("completed_status",DisplayHealth()=="TEST_LIVE");
   heartbeat_written=(long)TimeGMT()-60;
   SyncCheck("old_file_overrides_live_status",StringFind(DisplayHealth(),"历史保留")>=0 && DisplayHealth()!="TEST_LIVE");
   expected_revision=old_expected;revision=old_loaded;rendered_revision=old_rendered;health=old_health;
   last_change=old_change;heartbeat_written=old_written;
   FileWriteString(sync_test_file,"SUMMARY\t"+IntegerToString(sync_test_count)+"\t"+IntegerToString(sync_test_failures)+"\t"+IntegerToString((long)TimeGMT())+"\n");
   FileClose(sync_test_file);return sync_test_failures==0;
  }
