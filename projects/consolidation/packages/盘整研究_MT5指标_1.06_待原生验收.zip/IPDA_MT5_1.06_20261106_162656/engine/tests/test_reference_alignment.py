import json
import unittest
from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from ict_trader.reference_alignment import attach_reference_reviews,segment_digest


class ReferenceAlignmentTests(unittest.TestCase):
    def test_current_native_segment_must_match_and_does_not_change_bars(self):
        bars=[dict(time='2026-01-01T00:00:00+00:00',open=100,high=101,low=99,close=100.5),
              dict(time='2026-01-01T00:15:00+00:00',open=100.5,high=102,low=100,close=101)]
        record=dict(image_id=1,status='sequence_correspondence',first_bar_open_at=bars[0]['time'],last_bar_open_at=bars[-1]['time'],
                    sequence_bar_count=2,native_segment_sha256=segment_digest(bars),confirmed=False,score_included=False,red_box_boundaries_verified=False)
        with TemporaryDirectory() as d:
            path=Path(d)/'alignment.json';path.write_text(json.dumps(dict(references=[record])),encoding='utf-8')
            with patch('ict_trader.reference_alignment.REPORT',path):
                charts={'M15':{'bars':deepcopy(bars)}};before=deepcopy(charts['M15']['bars'])
                attach_reference_reviews(charts);r=charts['M15']['reference_reviews'][0]
                self.assertTrue(r['native_sequence_currently_verified']);self.assertFalse(r['red_box_boundaries_verified'])
                self.assertEqual(charts['M15']['bars'],before)
                charts['M15']['bars'][0]['high']=102
                attach_reference_reviews(charts);r=charts['M15']['reference_reviews'][0]
                self.assertFalse(r['native_sequence_currently_verified']);self.assertEqual(r['status'],'source_changed')
                charts['M15']['bars'].pop()
                attach_reference_reviews(charts);self.assertEqual(charts['M15']['reference_reviews'][0]['status'],'history_unavailable')

    def test_equivalent_timestamp_numbers_and_spread_are_not_price_revisions(self):
        a=[dict(time='2026-01-01T00:00:00+00:00',open=100,high=101,low=99,close=100.5)]
        b=[dict(time='2026-01-01T08:00:00+08:00',open=100.,high=101.,low=99.,close=100.5,spread=2)]
        self.assertEqual(segment_digest(a),segment_digest(b))
