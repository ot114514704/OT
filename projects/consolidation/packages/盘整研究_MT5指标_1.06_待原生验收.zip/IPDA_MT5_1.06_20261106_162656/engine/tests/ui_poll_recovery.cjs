// Real loopback HTTP stalls/errors exercise the production polling function.
// Only HTTP is fault-injected; no MT5 feed or production service is interrupted.
const fs=require('node:fs'),vm=require('node:vm'),http=require('node:http'),assert=require('node:assert/strict');
const source=fs.readFileSync(process.argv[2]||'ui/app.js','utf8');
const nativeFetch=global.fetch,requests=[],calls=[],timers=new Map(),intervals=[];
let sequence=0,revision=1,failure=null,origin,context;
const held=[];
function payload(){const report={availability:'live',poll_age_seconds:0,known_at:'2026-11-06T09:45:00',
 verdict:'candidate',label:'盘整候选',checks:{compact:true},reason:'测试已收盘证据',score:60};
 return {has_charts:true,model_revision:String(revision),status:'connected',polled_at:100,last_tick_change_at:100,
 quote:{bid:100+revision,ask:100.1+revision,raw_time:'synthetic-'+revision},
 current_consolidation:{H1:structuredClone(report),M15:structuredClone(report)},
 charts:{H1:{bars:[]},M15:{bars:[]}}};}
const server=http.createServer((req,res)=>{
 requests.push(req.url);
 if(failure?.path===req.url){
  if(failure.mode==='headers'){held.push(res);return}
  if(failure.mode==='body'){res.writeHead(200,{'Content-Type':'application/json'});res.write('{"unfinished":');held.push(res);return}
  if(failure.mode==='http'){res.writeHead(503);res.end('unavailable');return}
  if(failure.mode==='json'){res.writeHead(200,{'Content-Type':'application/json'});res.end('{invalid');return}
  if(failure.mode==='disconnect'){req.socket.destroy();return}
 }
 res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(payload()));
});
function element(){return {dataset:{},children:[],textContent:'',classList:{add(){}},
 append(...items){this.children.push(...items)},replaceChildren(){this.children=[]}}}
const elements=new Map(),texts=node=>[node.textContent,...node.children.flatMap(texts)].join('\n');
const node=id=>{if(!elements.has(id))elements.set(id,element());return elements.get(id)};
const run=code=>vm.runInContext(code,context);
async function until(predicate,label){const end=Date.now()+4000;while(!predicate()){
 if(Date.now()>end)throw Error('Timed out waiting for '+label);await new Promise(resolve=>setTimeout(resolve,5));}}
async function bounded(promise){let timer;try{return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('poll did not settle')),4000)})])}finally{clearTimeout(timer)}}
(async()=>{try{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin='http://127.0.0.1:'+server.address().port;
 context=vm.createContext({performance,AbortController,document:{getElementById:node,createElement:element},window:{addEventListener(){}},
  fetch:(path,options)=>{calls.push({path,options});return nativeFetch(origin+path,options)},
  setTimeout:(fn,ms)=>{const id=++sequence;timers.set(id,{fn,ms});return id},clearTimeout:id=>timers.delete(id),
  setInterval:(fn,ms)=>{intervals.push({fn,ms});return intervals.length}});
 // Keep production acquisition, status rendering, busy gate and retry schedule.
 vm.runInContext(source.slice(0,source.indexOf(' function zoom(')),context);
 run('draw=()=>{};render=()=>renderCurrentVerdicts();renderConcepts=()=>{}');
 vm.runInContext(source.slice(source.lastIndexOf("window.addEventListener('resize'")),context);
 await until(()=>run('state?.model_revision===\"1\"&&!busy'),'initial success');
 assert.equal(intervals.filter(i=>i.ms===2000).length,1);
 const poll=intervals.find(i=>i.ms===2000).fn;
 run("viewEnds.H1='2026-10-01T00:00:00';viewEnds.M15='2026-10-02T00:00:00'");
 const scenarios=[];
 for(const path of ['/api/live','/api/state'])for(const mode of ['headers','body']){
  const before=run('JSON.stringify(state)'),oldRevision=run('state.model_revision');
  revision++;failure={path,mode};const start=requests.length,callStart=calls.length;
  const pending=poll();await until(()=>requests.slice(start).includes(path),'stalled '+path+' '+mode);
  assert.equal(run('busy'),true);await poll();
  assert.equal(calls.length-callStart,path==='/api/state'?2:1,'single-flight polling');
  assert.equal(timers.size,1,'stalled HTTP must have a bounded timeout');
  const timeout=[...timers.values()][0];assert.equal(timeout.ms,path==='/api/live'?10000:15000);
  timeout.fn();await bounded(pending);
  assert.equal(run('busy'),false);assert.equal(run('networkDown'),true);
  assert.ok(calls.at(-1).options.signal.aborted,'actual HTTP request must be cancelled');
  assert.equal(run('JSON.stringify(state)'),before,'failed snapshot must not partly replace model');
  assert.equal(timers.size,0,'timeout must be cleaned up');
  assert.ok(node('status').textContent.includes('请求超时'));
  assert.ok(texts(node('currentVerdicts')).includes('当前判定不可用'));
  failure=null;await bounded(poll());
  assert.equal(run('networkDown'),false);assert.equal(run('busy'),false);
  assert.equal(run('state.model_revision'),String(revision));assert.notEqual(run('state.model_revision'),oldRevision);
  assert.equal(run('viewEnds.H1'),'2026-10-01T00:00:00');assert.equal(run('viewEnds.M15'),'2026-10-02T00:00:00');
  assert.equal(timers.size,0);scenarios.push({path,mode,recovered:true});
 }
 for(const path of ['/api/live','/api/state'])for(const mode of ['http','json','disconnect']){
  const before=run('JSON.stringify(state)');revision++;failure={path,mode};
  await bounded(poll());assert.equal(run('busy'),false);assert.equal(run('networkDown'),true);
  assert.equal(run('JSON.stringify(state)'),before);assert.equal(timers.size,0);
  if(mode==='http')assert.ok(node('status').textContent.includes('HTTP 503'));
  failure=null;await bounded(poll());assert.equal(run('state.model_revision'),String(revision));
  assert.equal(run('networkDown'),false);assert.equal(timers.size,0);scenarios.push({path,mode,recovered:true});
 }
 // Late data from a cancelled response cannot overwrite a recovered snapshot.
 const recovered=run('JSON.stringify(state)');for(const res of held)if(!res.destroyed)res.end(JSON.stringify({model_revision:'old-late'}));
 await new Promise(resolve=>setTimeout(resolve,30));assert.equal(run('JSON.stringify(state)'),recovered);
 assert.ok(calls.every(c=>c.options?.cache==='no-store'));
 console.log(JSON.stringify({passed:true,scenarios,scope:'Production polling with real loopback HTTP header/body stalls, HTTP/JSON/socket errors, cancellation, scheduled retry, atomic model replacement and history-view preservation. Timers triggered deterministically; production MT5 feed untouched.'}));
 }finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}
})().catch(error=>{console.error(error);process.exitCode=1});
