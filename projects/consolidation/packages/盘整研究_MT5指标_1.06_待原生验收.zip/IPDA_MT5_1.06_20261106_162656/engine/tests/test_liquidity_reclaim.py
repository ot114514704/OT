"""Causal multi-bar liquidity excursions, distinct from body-boundary breaks."""
import unittest
from dataclasses import replace
from ict_trader.ipda_ranges import phase_evidence
from tests.test_consolidation import fixture,append,observe


def mirror(bars):
    return [replace(b,open=200-b.open,high=200-b.low,low=200-b.high,close=200-b.close) for b in bars]


class LiquidityReclaimTests(unittest.TestCase):
    def test_excursion_on_previous_bar_is_confirmed_only_when_reclaimed(self):
        bars=append(fixture(),100,103,99,102)
        before=observe(bars)['rows'][-1]
        self.assertEqual(before['event'],'breakout_pending');self.assertIsNone(before['sweep'])
        self.assertEqual(before['active']['sweep_count'],0)
        # Recovery bar does not itself reach the original 101.5 liquidity edge.
        bars=append(bars,100.8,101,99,100)
        for data,side in [(bars,'upper'),(mirror(bars),'lower')]:
            rows=observe(data)['rows'];r=rows[-1]
            self.assertEqual(r['event'],'range_reclaimed');self.assertEqual(r['sweep'],side)
            self.assertEqual(r['active']['sweep_count'],1)
            evidence=r['sweep_evidence']['excursions'][side]
            self.assertEqual(evidence['first_excursion_at'],data[-2].closed_at.isoformat())
            self.assertEqual(r['sweep_evidence']['known_at'],data[-1].closed_at.isoformat())
            self.assertFalse(r['active']['pending_sweeps'])
            self.assertEqual(observe(data[:-1])['rows'],rows[:-1])

    def test_unreclaimed_breakout_does_not_become_sweep(self):
        bars=append(fixture(),100,103,99,102);bars=append(bars,102,105,101.5,104)
        for data in (bars,mirror(bars)):
            r=observe(data)['rows'][-1]
            self.assertEqual(r['event'],'breakout_confirmed');self.assertIsNone(r['sweep'])
            self.assertEqual(r['ended']['sweep_count'],0)
            self.assertTrue(phase_evidence(r,data)['ended']['pending_liquidity_excursions'])

    def test_body_tolerance_cannot_substitute_for_return_through_liquidity(self):
        # A narrow wick edge can sit inside the body breakout ATR buffer.
        bars=[replace(b,open=100+(.5 if i%2 else -.5)-.1,close=100+(.5 if i%2 else -.5),high=100.51,low=99.39) for i,b in enumerate(fixture())]
        self.assertIsNotNone(observe(bars)['rows'][-1]['active'])
        bars=append(bars,100.50,100.8,100.4,100.55)
        r=observe(bars)['rows'][-1]
        self.assertIsNone(r['sweep']);self.assertEqual(r['active']['sweep_count'],0)
        bars=append(bars,100.5,100.6,100,100.4)
        r=observe(bars)['rows'][-1]
        self.assertEqual(r['sweep'],'upper');self.assertEqual(r['active']['sweep_count'],1)

    def test_recovered_excursion_is_not_recounted_by_inside_bars(self):
        bars=append(fixture(),100,103,99,102)
        bars=append(bars,100.8,101,99,100)
        bars=append(bars,100,101,99,100.3)
        r=observe(bars)['rows'][-1]
        self.assertEqual(r['event'],'range_held');self.assertEqual(r['active']['sweep_count'],1)
        # A fresh wick excursion and recovery is a distinct observed event.
        bars=append(bars,100,104,99,100)
        self.assertEqual(observe(bars)['rows'][-1]['active']['sweep_count'],2)

    def test_gap_discards_pending_excursion_instead_of_inventing_recovery(self):
        bars=append(fixture(),100,103,99,102);bars=append(bars,100,101,99,100,gap=15)
        r=observe(bars)['rows'][-1]
        self.assertEqual(r['event'],'data_gap');self.assertIsNone(r['sweep'])
        self.assertIsNone(r['active']);self.assertEqual(r['ended']['sweep_count'],0)
