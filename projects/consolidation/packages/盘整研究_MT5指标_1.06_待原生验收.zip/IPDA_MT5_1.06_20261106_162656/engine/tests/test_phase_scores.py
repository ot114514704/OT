import unittest
from dataclasses import asdict,replace
from datetime import datetime,timedelta,timezone
from ict_trader.core import Bar
from ict_trader.ipda_phases import detect_phases
from ict_trader.phase_scores import attach_scores


def fixture():
    start=datetime(2026,1,1,tzinfo=timezone.utc)
    values=[100+(.8 if i%2 else -.8) for i in range(32)]+[102,104,106]
    return [Bar(start+timedelta(minutes=15*i),c-.1,101 if i<32 else c+1,99 if i<32 else c-1,c,0,900) for i,c in enumerate(values)]


def payload(bars):
    return attach_scores(dict(evidence_bars=[dict(asdict(b),time=b.time.isoformat(),closed_at=b.closed_at.isoformat()) for b in bars],phases=detect_phases(bars,bars[-1].closed_at)))


class ScoresTests(unittest.TestCase):
    def test_ended_range_retains_formation_evidence_without_current_qualification(self):
        from ict_trader.current_consolidation import classify
        phases=payload(fixture())['phases']
        ended=next(p for p in phases if p['consolidation_evidence']['event']=='breakout_confirmed')
        before=phases[phases.index(ended)-1]
        fit=ended['fit_scores']['by_phase']['consolidation'];prior=before['fit_scores']['by_phase']['consolidation']
        self.assertEqual(fit['components'][:8],prior['components'][:8])
        self.assertEqual(fit['score'],75);self.assertEqual(fit['unknown_weight'],20)
        self.assertEqual(fit['eligibility'],'range_ended');self.assertFalse(fit['current_range_valid'])
        self.assertEqual(fit['checks_known_at'],ended['consolidation_evidence']['ended']['known_at'])
        self.assertEqual(classify({'phase_rows':[ended]})['verdict'],'not_consolidation')

    def test_gap_preserves_known_evidence_but_ends_range_and_stays_insufficient(self):
        from ict_trader.current_consolidation import classify
        bars=fixture()[:33];bars[-1]=replace(bars[-1],time=bars[-1].time+timedelta(minutes=15))
        phases=payload(bars)['phases'];ended=phases[-1]
        self.assertEqual(ended['consolidation_evidence']['event'],'data_gap')
        fit=ended['fit_scores']['by_phase']['consolidation']
        self.assertEqual(fit['eligibility'],'range_ended');self.assertEqual(fit['unknown_weight'],20)
        self.assertEqual(fit['components'][:8],phases[-2]['fit_scores']['by_phase']['consolidation']['components'][:8])
        self.assertEqual(classify({'phase_rows':[ended]})['verdict'],'insufficient')

    def test_fixed_denominator_and_explicit_unknown_context(self):
        for p in payload(fixture())['phases']:
            for s in p['fit_scores']['by_phase'].values():
                self.assertEqual(sum(c['weight'] for c in s['components']),100)
                self.assertEqual(s['unknown_weight']+s['known_weight'],100)
                self.assertGreaterEqual(s['unknown_weight'],20)
                self.assertTrue(0<=s['score']<=80)
                self.assertEqual(s['score'],round(sum(c['points'] for c in s['components'])))

    def test_prefix_causal_and_direction_symmetric(self):
        bars=fixture();full=payload(bars)['phases']
        for n in (1,12,24,32,34):self.assertEqual(payload(bars[:n])['phases'],full[:n])
        mirrored=[replace(b,open=200-b.open,high=200-b.low,low=200-b.high,close=200-b.close) for b in bars]
        for a,b in zip(full,payload(mirrored)['phases']):
            self.assertEqual([s['score'] for s in a['fit_scores']['by_phase'].values()],[s['score'] for s in b['fit_scores']['by_phase'].values()])
