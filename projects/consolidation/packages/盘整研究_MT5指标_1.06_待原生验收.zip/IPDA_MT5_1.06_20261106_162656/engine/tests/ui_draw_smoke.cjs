// Execute the chart drawing code against the current HTTP snapshot without
// launching a browser. This checks drawing contracts, not rendered appearance.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
(async()=>{
 const response=await fetch('http://127.0.0.1:8773/api/state');assert.ok(response.ok);
 const payload=await response.json(),ops=[],elements=new Map(),stack=[];
 const g={dash:[],strokeStyle:'',fillStyle:'',globalAlpha:1,path:[],
  setLineDash(a){this.dash=a},save(){stack.push({dash:this.dash,strokeStyle:this.strokeStyle,fillStyle:this.fillStyle,globalAlpha:this.globalAlpha})},
  restore(){Object.assign(this,stack.pop())},measureText(s){return {width:s.length*7}},
  strokeRect(...args){ops.push({type:'frame',color:this.strokeStyle,dash:this.dash.slice(),args})},
  fillRect(...args){ops.push({type:'fill',color:this.fillStyle,args})},fillText(value){ops.push({type:'text',value})},
  beginPath(){this.path=[]},moveTo(x,y){this.path.push([x,y])},lineTo(x,y){this.path.push([x,y])},
  fill(){ops.push({type:'polygon_fill',color:this.fillStyle,points:this.path.slice(),dash:this.dash.slice()})}};
 for(const key of ['scale','clearRect','rect','clip','closePath','stroke','arc'])g[key]=()=>{};
 function element(id){if(!elements.has(id))elements.set(id,{value:id==='chartSize'?'1':'500',dataset:{},style:{},children:[],
  getBoundingClientRect:()=>({width:1400,height:360}),getContext:()=>g,textContent:'',append(child){this.children.push(child)},
  querySelector(){return this.children.find(x=>x.dataset?.zoom)||null},parentElement:{querySelector:()=>({open:false})},scrollIntoView(){}});return elements.get(id)}
 const context=vm.createContext({document:{getElementById:element,createElement:()=>({dataset:{}})},devicePixelRatio:1,input:JSON.stringify(payload)});
 const source=fs.readFileSync('ui/app.js','utf8').split('async function refresh()')[0];
 vm.runInContext(source,context);
 vm.runInContext("state=JSON.parse(input); viewCount=700; draw('H1'); draw('M15');",context);
 const frames=ops.filter(o=>o.type==='frame');
 assert.ok(frames.some(o=>o.color==='#efb977'),'long-window structures must draw');
 assert.ok(frames.every(o=>o.dash.length===0),'all outer frames must be solid');
 assert.ok(ops.some(o=>o.type==='fill'&&o.color==='#efb97722'),'structural frames need translucent fill');
 assert.ok(ops.some(o=>o.type==='text'&&o.value.includes('结构候选')),'candidate qualification must remain visible');
 assert.ok(element('captionH1').textContent.includes('700 根可见'));
 // Full-history mode must include the oldest loaded candle for both periods,
 // without a current-candidate classification hiding the historical overlays.
 vm.runInContext("selected=null;viewEnds.H1=null;viewEnds.M15=null;viewCount=0;draw('H1');draw('M15');",context);
 for(const period of ['H1','M15']){
  const actual=vm.runInContext(`({count:chartViews.${period}.count,end:chartViews.${period}.end,total:chartViews.${period}.all.length})`,context);
  assert.equal(actual.count,actual.total);assert.equal(actual.end,actual.total);
  assert.ok(element('caption'+period).textContent.includes(payload.charts[period].bars[0].time.slice(5,16).replace('T',' ')));
 }
 const candidate=payload.charts.H1.current_candidate;
 if(candidate){
  assert.equal(candidate.confirmed,false);assert.equal(candidate.score_included,false);
  assert.ok(element('shapeCurrentH1').textContent.includes('候选'));
  assert.ok(ops.some(o=>o.type==='text'&&o.value.includes('正在形成')),'untagged current candidate must remain visible');
 }
 vm.runInContext('viewCount=700;',context);
 const targets=Object.values(payload.charts).flatMap(c=>c.reference_targets||[]);
 assert.equal(targets.length,11);assert.ok(targets.filter(t=>t.source_image===12).every(t=>t.matched),'three broad regions need a real evidence match');
 assert.ok(targets.find(t=>t.id==='phone_high_box').matched,'wick rejections must recover the requested high box');
 const ascending=targets.find(t=>t.id==='phone_ascending_down');assert.equal(ascending.matched,true,'outer triangle needs independent long geometry');
 assert.equal(ascending.evidence_confirmed,false,'long morphology must remain a candidate');
 vm.runInContext("render=()=>{draw('H1');draw('M15')};",context);
 const focused=[];
 for(const target of targets.filter(t=>t.matched)){
  const period=JSON.stringify(target.period),id=JSON.stringify(target.range_id);
  const pool=target.range_kind==='range'?'consolidations':target.range_kind==='geometric'?'geometric_ranges':target.range_kind==='intraday'?'intraday_structures':'structural_ranges';
  vm.runInContext(`focusStructure(${period},state.charts[${period}][${JSON.stringify(pool)}].find(b=>b.id===${id}),${JSON.stringify(target.range_kind)});`,context);
  const view=vm.runInContext(`(()=>{const v=chartViews[${period}];return {first:v.all[Math.max(0,v.end-viewCount)].time,last:v.all[v.end-1].closed_at}})()`,context);
  assert.ok(view.first<=target.observed_from,'focus must retain the whole formation window');
  assert.ok(view.last>=target.end_at,'focus must retain the end of the region');
  focused.push(target.title);
  if(target.id==='middle_channel'||target.id==='phone_ascending_down'){
   const box=payload.charts[target.period][pool].find(b=>b.id===target.range_id);
   assert.ok(box.geometry?.validated,'slanted frame needs validated geometry');
   assert.ok(ops.some(o=>o.type==='polygon_fill'&&o.points.length===4&&o.points[0][1]!==o.points[1][1]&&o.dash.length===0),'trend lines must enclose translucent slanted area');
  }
 }
 const reviews=payload.charts.M15.reference_reviews||[];
 assert.equal(reviews.length,17);assert.equal(reviews.filter(r=>r.native_sequence_currently_verified).length,4);
 for(const r of reviews.filter(r=>r.native_sequence_currently_verified)){
  vm.runInContext(`focusReference('M15',state.charts.M15.reference_reviews.find(r=>r.image_id===${r.image_id}));`,context);
  const view=vm.runInContext("(()=>{const v=chartViews.M15;return {first:v.all[Math.max(0,v.end-viewCount)].time,last:v.all[v.end-1].time}})()",context);
  assert.ok(view.first<=r.first_bar_open_at&&view.last>=r.last_bar_open_at,'reference lookup must retain the matched sequence');
 }
 assert.ok(ops.some(o=>o.type==='frame'&&o.color==='#ffe19c'),'focused structure needs highlight');
 const summary={frame_count:frames.length,solid_frames:true,structural_fill:true,candidate_labels:true,focused,sequence_review_images:reviews.filter(r=>r.native_sequence_currently_verified).map(r=>r.image_id),scope:'Node模拟Canvas绘图与定位契约，不是浏览器视觉验收'};
 console.log(JSON.stringify(summary));
})().catch(e=>{console.error(e);process.exitCode=1});
