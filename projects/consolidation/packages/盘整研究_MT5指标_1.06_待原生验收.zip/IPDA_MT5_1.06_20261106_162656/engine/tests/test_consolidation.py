import unittest
from datetime import datetime,timedelta,timezone
from dataclasses import replace
from copy import deepcopy
from ict_trader.core import Bar
from ict_trader.ipda_ranges import observe_ranges,phase_evidence
from ict_trader.consolidation_profile import profile


def fixture():
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    # Repeated closed-price swings span 2.2 against a 3.0 bar range. The
    # former +/-0.5 wiggle is intentionally too weak for the new selector.
    return [Bar(t+timedelta(minutes=15*i),100+(1.1 if i%2 else -1.1)-.1,101.5,98.5,100+(1.1 if i%2 else -1.1),0,900) for i in range(12)]


def append(bars,o,h,l,c,gap=0):
    return bars+[Bar(bars[-1].closed_at+timedelta(minutes=gap),o,h,l,c,0,900)]


def observe(bars,asof=None):return observe_ranges(bars,asof or bars[-1].closed_at)


class ConsolidationTests(unittest.TestCase):
    def test_entry_freeze_sweep_reclaim_and_exit(self):
        bars=fixture();initial=observe(bars)['rows'][-1]['active'];self.assertIsNotNone(initial)
        bars=append(bars,100,103,99,100)
        row=observe(bars)['rows'][-1];self.assertEqual(row['sweep'],'upper');self.assertEqual(row['event'],'range_reclaimed')
        self.assertEqual(row['active']['hi'],initial['hi']);self.assertEqual(row['active']['liquidity_hi'],initial['liquidity_hi'])
        self.assertEqual(row['active']['sweep_count'],1)
        bars=append(bars,100,103,99,102)
        self.assertEqual(observe(bars)['rows'][-1]['event'],'breakout_pending')
        bars=append(bars,102,105,101.5,104)
        result=observe(bars);row=result['rows'][-1];self.assertEqual(row['event'],'breakout_confirmed');self.assertIsNone(row['active'])
        self.assertEqual(phase_evidence(row,bars)['ended']['end_at'],bars[-1].closed_at.isoformat())
        bars=append(bars,104,105,103,104)
        self.assertFalse(observe(bars)['rows'][-1]['candidates'])

    def test_no_sweep_required_for_breakout(self):
        bars=append(fixture(),100,103,99,102);bars=append(bars,102,105,101.5,104)
        row=observe(bars)['rows'][-1];self.assertEqual(row['event'],'breakout_confirmed');self.assertEqual(row['ended']['sweep_count'],0)

    def test_forming_future_and_prefix_do_not_change_past(self):
        bars=append(fixture(),100,103,99,100);bars=append(bars,100,106,99,105)
        original=deepcopy(bars);full=observe(bars)
        for n in (1,11,12,13):self.assertEqual(observe(bars[:n])['rows'],full['rows'][:n])
        self.assertEqual(observe(bars,bars[-2].closed_at)['rows'],full['rows'][:-1])
        self.assertEqual(bars,original)
        mutated=bars[:-1]+[replace(bars[-1],high=1000,close=999)]
        self.assertEqual(observe(mutated)['rows'][:-1],full['rows'][:-1])

    def test_gap_ends_range_and_does_not_bridge(self):
        bars=append(fixture(),100,101,99,100,gap=15)
        row=observe(bars)['rows'][-1];self.assertEqual(row['event'],'data_gap');self.assertIsNone(row['active']);self.assertFalse(row['candidates'])

    def test_profiles_mirror_and_unknown_context(self):
        bars=fixture();a=profile(bars,0,11,3)
        mirror=[replace(b,open=200-b.open,high=200-b.low,low=200-b.high,close=200-b.close) for b in bars]
        b=profile(mirror,0,11,3)
        self.assertEqual(a['tags'],b['tags']);self.assertIn('rectangle',a['tags'])
        self.assertIsNone(a['checks']['relay']);self.assertIsNone(a['checks']['compressed'])

    def test_convergence_and_tilt_are_separate_morphologies(self):
        bars=fixture()
        converging=[replace(b,high=103-i*.15,low=97+i*.15) for i,b in enumerate(bars)]
        # Shrinking envelopes alone have no confirmed pivot anchors.
        self.assertNotIn('converging',profile(converging,0,11,3)['tags'])
        tilted=[replace(b,open=b.open+i*.3,close=b.close+i*.3,high=b.high+i*.3,low=b.low+i*.3) for i,b in enumerate(bars)]
        self.assertIn('tilted',profile(tilted,0,11,3)['tags'])
        self.assertIsNone(observe(tilted)['rows'][-1]['active'])

    def test_compression_requires_prior_range_context(self):
        base=fixture();prior=base
        narrow=[]
        for i,b in enumerate(base):
            t=prior[-1].closed_at+timedelta(minutes=15*i)
            narrow.append(replace(b,time=t,open=100,high=100.3,low=99.7,close=100.05))
        self.assertIn('compressed',profile(prior+narrow,12,23,.6)['tags'])

    def test_relay_requires_prior_impulse_and_does_not_predict_exit(self):
        base=fixture();prior=[]
        for i,b in enumerate(base):
            prior.append(replace(b,open=90+i,high=91.1+i,low=89.9+i,close=91+i))
        rest=[replace(b,time=prior[-1].closed_at+timedelta(minutes=15*i),open=b.open+2,high=b.high+2,low=b.low+2,close=b.close+2) for i,b in enumerate(base)]
        evidence=profile(prior+rest,12,23,3)
        self.assertIn('relay',evidence['tags']);self.assertEqual(evidence['relay_direction'],1)
        self.assertTrue(any('延续' in x for x in evidence['missing']))
