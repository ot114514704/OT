import unittest
from copy import deepcopy

from ict_trader.current_consolidation import live_reports,body_candidate_observation
from ict_trader.mt5_bridge import current_summary
from tests import test_current_consolidation as current_fixture


def state():
    c=current_fixture.CurrentVerdictTests().multi_window_chart()
    c['phase_rows'][-1]['consolidation_evidence']['candidates'][1].update(liquidity_lo=98,liquidity_hi=102)
    c['phase_rows'][-1]['consolidation_evidence']['candidates'][1]['metrics']['atr']=2
    s=current_fixture.native_metadata(dict(status='connected',polled_at=100,last_tick_change_at=100,quote={'bid':100},charts={'M15':c}))
    s['forming']['M15'].update(open=100,close=100,high=100,low=100)
    return s


class BodyCandidateObservationTests(unittest.TestCase):
    def test_uses_selected_eligible_window_and_never_the_score_window(self):
        s=state();before=deepcopy(s);r=live_reports(s,101)['M15'];o=r['body_candidate_observation']
        self.assertEqual((o['window'],o['low'],o['high']),(24,99,101))
        self.assertEqual((o['observed_low'],o['observed_high']),(98,102))
        self.assertEqual(r['score_window'],12);self.assertFalse(o['boundaries_frozen'])
        self.assertEqual(o['code'],'inside');self.assertEqual(s,before)

    def test_moving_forming_price_cannot_confirm_exit_sweep_or_score(self):
        s=state();before=deepcopy(s['charts']);baseline=live_reports(s,101)['M15']
        for price,code in [(102.5,'above_threshold'),(101.1,'body_edge'),(97.5,'below_threshold'),(100,'inside')]:
            s['forming']['M15'].update(close=price,high=103,low=97)
            r=live_reports(s,101)['M15'];o=r['body_candidate_observation']
            self.assertEqual(o['code'],code);self.assertFalse(o['confirmed']);self.assertFalse(o['score_included'])
            self.assertEqual(o['wick_crossings'],['upper','lower'])
            self.assertIn('尚不计确认扫荡',o['message'])
            for k in ('verdict','score','checks','event','known_at','range'):self.assertEqual(r[k],baseline[k])
        self.assertEqual(s['charts'],before)

    def test_direction_reflection_and_exact_thresholds(self):
        s=state();b=s['forming']['M15']
        for up,down in [(101.3,98.7),(101.3001,98.6999),(102.5,97.5)]:
            b.update(close=up,high=up,low=100);a=live_reports(s,101)['M15']['body_candidate_observation']
            b.update(close=down,high=100,low=down);z=live_reports(s,101)['M15']['body_candidate_observation']
            self.assertEqual(z['code'],'below_threshold' if a['code']=='above_threshold' else a['code'])
            self.assertAlmostEqual(z['threshold_low'],200-a['threshold_high'])

    def test_stale_pending_disconnected_and_superseded_candidates_are_suppressed(self):
        for condition in ('stale','pending','disconnected','idle','gap','exit','unqualified','old_time'):
            s=state();now=101;e=s['charts']['M15']['phase_rows'][-1]['consolidation_evidence']
            if condition=='stale':now=116
            elif condition=='pending':s['latest_closed_end']={'M15':'2026-01-01T01:15:00+00:00'}
            elif condition=='disconnected':s['status']='disconnected'
            elif condition=='idle':s['last_tick_change_at']=50
            elif condition=='gap':e['event']='data_gap'
            elif condition=='exit':e['event']='breakout_confirmed'
            elif condition=='unqualified':e['candidates'][1]['checks']['strong_oscillation']=False
            else:s['forming']['M15']['time']='2026-01-01T01:15:00+00:00'
            with self.subTest(condition=condition):self.assertIsNone(live_reports(s,now)['M15']['body_candidate_observation'])

    def test_invalid_prices_or_bounds_do_not_get_live_positions(self):
        for condition in ('nan','bool','invalid_ohlc','inverted_bounds','missing_atr','not_forming'):
            s=state();c=s['charts']['M15'];b=s['forming']['M15'];candidate=c['phase_rows'][-1]['consolidation_evidence']['candidates'][1]
            if condition=='nan':b['close']=float('nan')
            elif condition=='bool':b['close']=True
            elif condition=='invalid_ohlc':b['close']=103
            elif condition=='inverted_bounds':candidate['hi']=90
            elif condition=='missing_atr':candidate['metrics'].pop('atr')
            else:b['forming']=False
            with self.subTest(condition=condition):self.assertIsNone(body_candidate_observation(c,b))

    def test_mt5_own_and_h1_companion_explain_the_same_provisional_position(self):
        s=state();s['forming']['M15'].update(close=103,high=103)
        r=live_reports(s,101)['M15']
        self.assertIn('实体候选末柱上沿外(未确认)',current_summary(r))
        self.assertIn('M15 实体候选末柱上沿外(未确认)',current_summary(dict(label='证据不足',availability='live'),r))
        r['availability']='stale';self.assertNotIn('末柱上沿外',current_summary(r))


if __name__=='__main__':unittest.main()
