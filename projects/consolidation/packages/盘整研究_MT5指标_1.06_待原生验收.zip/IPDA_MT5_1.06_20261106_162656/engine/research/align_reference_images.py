"""Offline screenshot/native sequence correspondence; no trading simulation.

Run from project root with the optional research requirements installed.
Pixel grid/spacing calibrations are manually inspected inputs, not OCR facts.
This locates a possible native sequence, never confirms the user's red boxes.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from ict_trader.reference_alignment import segment_digest

CALIBRATIONS={
    6:dict(phase=-3,step=34.94,grid=[[358,3975.45],[1525,3896.95]]),
    7:dict(phase=5,step=8.75,grid=[[363,3979.65],[1527,3888.15]]),
    8:dict(phase=3,step=11.67,grid=[[358,3970.95],[1526,3872.45]]),
    10:dict(phase=5,step=11.67,grid=[[360,4065.95],[1525,3965.45]]),
}


def extract(path,calibration):
    a=np.asarray(Image.open(path).convert('RGB'));r,g,b=[a[:,:,i].astype(int) for i in range(3)]
    up=(g>100)&(b>80)&(g>r*1.7)&(b>r*1.5)&(b<g*1.35)
    down=(r>130)&(g>60)&(g<125)&(b>55)&(b<135)&(abs(g-b)<35)&(r>g*1.5)&(r<g*3.8)
    mask=up|down;phase=calibration['phase'];step=calibration['step']
    (y1,p1),(y2,p2)=calibration['grid'];unit=(p1-p2)/(y2-y1)
    def price(y):return p1-(y-y1)*unit
    bodies=[];slots=int((1100-phase)/step)+1
    for slot in range(slots):
        x=phase+step*slot;radius=max(1,int(step*.23));xs=np.arange(max(0,int(round(x))-radius),min(1100,int(round(x))+radius+1))
        if len(xs)<2:continue
        ys=np.flatnonzero(mask[450:1620,xs].sum(axis=1)>=max(2,len(xs)*.55))+450
        if not len(ys):continue
        groups=np.split(ys,np.flatnonzero(np.diff(ys)>1)+1);body=max(groups,key=len)
        if len(body)<2 or body[0]==450 or body[-1]==1619:continue
        direction=1 if up[np.ix_(body,xs)].sum()>down[np.ix_(body,xs)].sum() else -1
        bodies.append(dict(slot=slot,top=price(int(body[0])),bottom=price(int(body[-1])),direction=direction))
    return bodies,slots,unit


def align(raw,bodies,slots,unit):
    offsets=np.asarray([b['slot'] for b in bodies]);top=np.asarray([b['top'] for b in bodies]);bottom=np.asarray([b['bottom'] for b in bodies]);direction=np.asarray([b['direction'] for b in bodies])
    opens=np.asarray([float(b['open']) for b in raw]);closes=np.asarray([float(b['close']) for b in raw])
    results=[]
    for start in range(len(raw)-slots+1):
        at=start+offsets
        errors=(abs(top-np.maximum(opens[at],closes[at]))+abs(bottom-np.minimum(opens[at],closes[at])))/2
        mismatch=float(np.mean(direction!=np.where(closes[at]>=opens[at],1,-1)))
        # Capped pixel errors tolerate arrows and labels, but are not an
        # accuracy/probability estimate. Record uncapped median/mean as well.
        score=float(np.mean(np.minimum(errors/unit,30))+15*mismatch)
        results.append(dict(index=start,score=score,median_price_error=float(np.median(errors)),
                            mean_price_error=float(np.mean(errors)),direction_mismatch_fraction=mismatch))
    results.sort(key=lambda x:x['score'])
    return results[:3]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--raw',type=Path,default=ROOT/'work/live_8773/data/M15.json')
    p.add_argument('--output',type=Path,default=ROOT/'research/user_range_references/native_alignment_review.json')
    args=p.parse_args();raw=json.loads(args.raw.read_text('utf-8'))
    manifest=json.loads((ROOT/'research/user_range_references/manifest.json').read_text('utf-8'))
    reports=[]
    for reference in manifest['references']:
        ident=reference['id'];path=ROOT/'research/user_range_references'/reference['file']
        entry=dict(image_id=ident,image_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                   title=reference['title'],raw_candle_alignment_verified=False,timezone_verified=False,
                   red_box_boundaries_verified=False,confirmed=False,score_included=False)
        if ident not in CALIBRATIONS:
            entry.update(status='pending',reason='尚未完成截图价格序列与红框逐段标定；未将图片框补造成自动确认')
        else:
            calibration=CALIBRATIONS[ident];bodies,slots,unit=extract(path,calibration)
            ranking=align(raw,bodies,slots,unit)
            if not ranking:raise ValueError('Native sample too short for reference '+str(ident))
            best=ranking[0];segment=raw[best['index']:best['index']+slots]
            separation=ranking[1]['score']-best['score'] if len(ranking)>1 else 0
            evidence=best['score']<20 and best['median_price_error']<1 and separation>8
            for r in ranking:
                index=r.pop('index');r.update(first_bar_open_at=raw[index]['time'],last_bar_open_at=raw[index+slots-1]['time'])
            entry.update(status='sequence_correspondence' if evidence else 'ambiguous',calibration=calibration,
                         calibration_source='人工读取图片网格与等间距K线中心；截图箭头/细实体可产生提取误差',
                         extracted_body_count=len(bodies),sequence_bar_count=slots,price_per_pixel=unit,
                         first_bar_open_at=segment[0]['time'],last_bar_open_at=segment[-1]['time'],
                         native_segment_sha256=segment_digest(segment),ranking=ranking,ranking_separation=separation,
                         reason='连续实体价格与涨跌顺序有明显对应；像素提取有箭头/标线误差，尚不证明全部OHLC或红框边界精确对齐')
        reports.append(entry)
    result=dict(version='reference_sequence_alignment_v1',source_file=str(args.raw),
                raw_sample_start=raw[0]['time'],raw_sample_end=raw[-1]['time'],references=reports,
                method='逐一比较可用的连续实体顶部/底部及涨跌顺序；不使用截图时间标签来强配序列',
                score_policy='均值(min(实体价格误差/每像素价格,30))+15*方向不一致比例；仅检索距离，不是符合度或概率',
                limitations=['人工像素校准尚待复核','匹配不提供历史时区证明','红框起止和盘整资格另行检查','不运行收益回测，不向实时模型注入截图价格'])
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps([dict(image=x['image_id'],status=x['status'],start=x.get('first_bar_open_at'),best=x.get('ranking',[None])[0]) for x in reports],ensure_ascii=False))


if __name__=='__main__':main()
