"""Versioned rule-fit scores; never probabilities, signals or original ICT weights."""
from .core import instant

VERSION = 'ipda_rule_fit_body_balance_v4'
POLICY = {
    'version': VERSION, 'maximum': 100, 'local_points': 80, 'context_points': 20,
    'meaning': '规则符合度，不是胜率、置信概率或入场建议；权重为未校准工程假设',
    'context': 'HTF关键位置10分、HTF程序方向10分；当前未核实，不给分且保留未知',
    'segment': '仅对截至回放时刻已收盘的片段棒取算术平均，并显示最低/最高；不择最高值代表全段',
    'hard_limits': '参考范围缺失或关键条件矛盾时标出不具备资格，分数不能覆盖该状态',
    'source': 'research/price_courses/ipda_phase_rules.json',
}
SOURCE_SECONDS = {'expansion':[766,816],'retracement':[226,273],
                  'reversal':[816,851],'consolidation':[712,740]}


def _clip(v):
    return max(0., min(1., v))


def score_bar(p, b, prior):
    if p['bar_open_at'] != b['time'] or instant(p['known_at']) != instant(b['closed_at']):
        raise ValueError('Score must use the matching closed candle')
    ref = p['reference_before']; m = p['metrics']; atr = m['atr14_prior']
    warm = bool(atr and atr > 0)
    before = [x for x in prior if instant(x['closed_at']) <= instant(b['time'])
              and instant(x['time']) >= instant(p['run_start'])][-6:]
    net = m['net3']; motion = 1 if net > 0 else -1 if net < 0 else 0
    breakout = len(before) == 6 and ((motion == 1 and b['close'] > max(x['high'] for x in before)) or
                                   (motion == -1 and b['close'] < min(x['low'] for x in before)))
    intact = bool(ref and (b['close'] >= ref['low'] if ref['direction'] == 1 else b['close'] <= ref['high']))
    inside = bool(ref and ref['low'] <= b['close'] <= ref['high'])
    reverse = bool(ref and motion == -ref['direction'])
    depth = ((ref['high']-b['close']) if ref and ref['direction']==1 else
             (b['close']-ref['low']) if ref else 0)
    pda = [f for f in p['pda_contacts'] if instant(f['known_at']) <= instant(b['time'])]
    respected = bool(ref and any(b['close'] >= f['low'] if ref['direction']==1 else b['close'] <= f['high'] for f in pda))
    body_reverse = max(0, -(b['close']-b['open'])*ref['direction']) if ref else 0
    result = {}
    def add(phase, criteria, eligibility):
        parts=[]
        for name, weight, ratio, value in criteria:
            known = (warm or phase=='consolidation') and ratio is not None
            points = round(weight*_clip(ratio), 2) if known else 0
            parts.append({'name':name,'weight':weight,'points':points,
                          'source_rule': ('research/ipda_consolidation_rules.json' if p.get('consolidation_evidence') else 'research/brooks_chart_import/range-detector.original.js') if phase=='consolidation' else POLICY['source']+'#'+phase,
                          'source_seconds': [] if phase=='consolidation' else SOURCE_SECONDS[phase],
                          'epistemic_label':'engineering_measure_and_weight_for_source_concept_not_source_formula',
                          'status':'met' if known and points == weight else 'partial' if points else 'unmet' if known else 'unknown',
                          'observed':value})
        for name in ('HTF关键位置已验证','HTF程序方向已验证'):
            parts.append({'name':name,'weight':10,'points':0,'status':'unknown','observed':'未核实，不使用父周期涨跌代替'})
        result[phase]={'score':round(sum(c['points'] for c in parts)),
                       'earned_points':round(sum(c['points'] for c in parts),2),
                       'known_weight':sum(c['weight'] for c in parts if c['status']!='unknown'),
                       'unknown_weight':sum(c['weight'] for c in parts if c['status']=='unknown'),
                       'eligibility':eligibility if warm or phase=='consolidation' else 'warmup', 'components':parts}
    add('expansion',[
        ('3棒净位移 / 1 ATR',30,abs(net)/atr if warm else None,m['net3']),
        ('3棒方向效率 / 0.60',25,m['efficiency3']/.6,m['efficiency3']),
        ('收盘越过此前6棒极值',25,float(breakout) if len(before)==6 else None,breakout),
    ],'local_conditions_met' if breakout and warm and abs(net)>=atr and m['efficiency3']>=.6 else 'incomplete')
    add('retracement',[
        ('已有参考且收盘在其范围内',25,float(inside) if ref else None,inside if ref else '无参考'),
        ('3棒方向逆原参考',20,float(reverse) if ref else None,reverse if ref else '无参考'),
        ('回撤深度 / 0.7 ATR',20,depth/(.7*atr) if warm and ref else None,round(depth,4) if ref else '无参考'),
        ('范围内已知同向FVG接触',10,float(bool(pda)) if ref else None,len(pda)),
        ('接触后收盘未穿FVG远端',5,float(respected) if ref else None,respected),
    ],'reference_missing' if not ref else 'contradicted' if not intact else 'incomplete' if not inside or not reverse else 'local_conditions_met')
    add('reversal',[
        ('收盘穿过原参考起点',30,float(not intact) if ref else None,not intact if ref else '无参考'),
        ('3棒方向逆原参考',15,float(reverse) if ref else None,reverse if ref else '无参考'),
        ('反向实体 / 0.65 ATR',20,body_reverse/(.65*atr) if warm and ref else None,round(body_reverse,4) if ref else '无参考'),
        ('原参考起点来自事前确认IT',15,float(not ref['origin_ref'].startswith('lookback')) if ref else None,ref['origin_ref'] if ref else '无参考'),
    ],'reference_missing' if not ref else 'contradicted' if intact else 'local_conditions_met' if reverse and warm and body_reverse>=.65*atr else 'incomplete')
    observed=p.get('consolidation_evidence') or p.get('brooks_range',{}); box=observed.get('range'); rm=observed.get('metrics')
    if observed.get('candidates'):rm=observed['candidates'][0]['metrics']
    frozen=box or (observed.get('ended') if p.get('consolidation_evidence') else None)
    if frozen:
        rm=dict(overlap=frozen['overlap'],efficiency=frozen['efficiency'],
                width_atr=(frozen['high']-frozen['low'])/frozen['frozen_atr'],
                highTests=frozen['high_tests'],lowTests=frozen['low_tests'],crossings=frozen['crossings'])
        rm.update({k:frozen.get(k) for k in ('body_occupancy','mean_body_atr','half_window_drift')})
    def ratio(key,fn): return fn(rm[key]) if rm and rm.get(key) is not None else None
    def value(key): return rm.get(key) if rm else '连续12棒不足或区间已结束'
    if p.get('consolidation_evidence'):
        add('consolidation',[
            ('相邻K线重叠 ≥ 0.50',10,ratio('overlap',lambda v:v/.5),value('overlap')),
            ('低方向效率 ≤ 0.30',10,ratio('efficiency',lambda v:(1-v)/.7),value('efficiency')),
            ('实体范围 ≤ 5.5倍稳健均幅',10,ratio('width_atr',lambda v:5.5/v if v>0 else 0),value('width_atr')),
            ('至少80%实体集中于区间',10,ratio('body_occupancy',lambda v:v/.8),value('body_occupancy')),
            ('平均实体 ≤ 0.65倍稳健均幅',10,ratio('mean_body_atr',lambda v:.65/v if v>0 else 1),value('mean_body_atr')),
            ('前后半窗价格漂移 ≤ 45%区间',10,ratio('half_window_drift',lambda v:.45/v if v>0 else 1),value('half_window_drift')),
            ('双边各2次独立往返测试',10,min(rm['highTests'],rm['lowTests'])/2 if rm else None,[value('highTests'),value('lowTests')]),
            ('中线至少2次穿越',5,ratio('crossings',lambda v:v/2),value('crossings')),
            ('冻结区间尚未确认突破',5,float(bool(box)) if rm or observed.get('ended') else None,box['status'] if box else observed.get('event')),
        ],'range_ended' if observed.get('ended') else 'local_conditions_met' if box else 'incomplete' if rm else 'warmup')
        result['consolidation'].update(checks_basis='first_confirmation' if frozen else 'current_candidate_window',
            checks_known_at=frozen['known_at'] if frozen else p['known_at'],current_range_valid=bool(box))
    else:add('consolidation',[
        ('12棒重叠 ≥ 0.50',15,ratio('overlap',lambda v:v/.5),value('overlap')),
        ('12棒低方向效率 ≤ 0.30',15,ratio('efficiency',lambda v:(1-v)/.7),value('efficiency')),
        ('12棒范围 ≤ 4.5倍均幅',10,ratio('width_atr',lambda v:4.5/v if v>0 else 0),value('width_atr')),
        ('上下沿各至少2次测试',20,min(rm['highTests'],rm['lowTests'])/2 if rm else None,[value('highTests'),value('lowTests')]),
        ('中线至少2次穿越',10,ratio('crossings',lambda v:v/2),value('crossings')),
        ('已识别且尚未确认突破',10,float(bool(box)) if rm or observed.get('ended') else None,box['status'] if box else observed.get('event')),
    ],'local_conditions_met' if box else 'incomplete' if rm else 'warmup' if not observed.get('ended') else 'range_ended')
    return {'version':VERSION,'known_at':p['known_at'],'by_phase':result,'probability':None}


def attach_scores(payload):
    bars = payload['evidence_bars']; index = {b['time']: i for i,b in enumerate(bars)}
    for p in payload['phases']:
        i=index[p['bar_open_at']]
        p['fit_scores']=score_bar(p,bars[i],bars[max(0,i-6):i])
    payload['phase_score_policy']=POLICY
    # Session/killzone evidence is attached after scoring and is deliberately
    # informational until the historical terminal clock/DST proof is valid.
    # Standalone project: historical clock/session proof remains unknown.
    # Weekly/daily profile context is kept separate from local phase scores.
    # The guard can expose observed structure and protection levels without
    # turning an unverified profile into a direction or score.
    # HTF context stays explicitly unknown; no parent service dependency.
    return payload
