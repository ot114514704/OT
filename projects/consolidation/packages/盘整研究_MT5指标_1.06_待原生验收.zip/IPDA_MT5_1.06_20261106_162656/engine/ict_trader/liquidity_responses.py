"""Price responses around confirmed swing levels; no order-pool inference.

All observations are made at bar close. Same-bar range breach and inside close
are observable together; OHLC cannot reconstruct all intrabar price paths.
"""
from .core import instant, visible
from .structure_breaks import observe_structure_breaks
from .candle_evidence import measure_candles

DEFINITION = 'confirmed_swing_cross_close_response_v1'
SOURCE = 'research/liquidity_response_rules.json'


def observe_liquidity_responses(bars, asof, records=None):
    """Rebuild references and first breaches, then follow closes within each run.

    Optional records have the same trusted geometry contract as
    observe_structure_breaks; future-known records remain excluded.
    """
    past = visible(bars, instant(asof))
    breaks = observe_structure_breaks(past, asof, records)
    return _responses_from_validated_breaks(past, asof, breaks)


def _responses_from_validated_breaks(past, asof, breaks):
    """Internal reuse of breaks freshly computed from this exact visible prefix."""
    positions = {instant(b.time): i for i, b in enumerate(past)}
    measurements = {r['bar_open_at']: r for r in measure_candles(past, asof)}
    chains, events = [], []
    for crossing in breaks['events']:
        if crossing['kind'] != 'wick_cross':
            continue
        first_index = positions[instant(crossing['bar_open_at'])]
        price, side = crossing['reference_price'], crossing['reference_side']
        base = {k: crossing[k] for k in (
            'reference_id', 'reference_tier', 'reference_side', 'reference_price',
            'reference_pivot_at', 'reference_known_at', 'timeframe_seconds', 'run_start')}
        base.update(chain_id=crossing['id'], definition=DEFINITION,
                    qualification='price_response_only', source_rule=SOURCE)
        chain_events = []

        def emit(kind, bar, **extra):
            item = {**base, 'id': f'{crossing["id"]}:response:{kind}:{bar.closed_at.isoformat()}',
                    'kind': kind, 'observed_at': bar.closed_at.isoformat(),
                    'bar_open_at': instant(bar.time).isoformat(),
                    'open': bar.open, 'high': bar.high, 'low': bar.low, 'close': bar.close,
                    **extra}
            if kind != 'tracking_gap':
                item['candle_evidence'] = measurements[item['bar_open_at']]
            chain_events.append(item)
            events.append(item)

        emit('extreme_cross', past[first_index])
        previous_relation = None
        last_directional = None
        previous = None
        gap = False
        last_observation = crossing['observed_at']
        for bar in past[first_index:]:
            if previous is not None and bar.time != previous.closed_at:
                emit('tracking_gap', bar, gap_start=previous.closed_at.isoformat(),
                     gap_end=instant(bar.time).isoformat())
                gap = True
                break
            signed = (bar.close-price) * (1 if side == 'high' else -1)
            relation = 'outside' if signed > 0 else 'inside' if signed < 0 else 'at_level'
            if relation != previous_relation:
                if relation == 'inside' and last_directional != 'inside':
                    kind = 'reclaim'
                elif relation == 'outside' and last_directional == 'inside':
                    kind = 'rebreak'
                else:
                    kind = 'close_' + relation
                emit(kind, bar, close_relation=relation,
                     same_bar_as_first_cross=(bar.time == past[first_index].time))
            if relation != 'at_level':
                last_directional = relation
            previous_relation = relation
            previous = bar
            last_observation = bar.closed_at.isoformat()
        chains.append({**base, 'first_cross_at': crossing['observed_at'],
                       'first_cross_bar_open_at': crossing['bar_open_at'],
                       'events': chain_events, 'latest_close_relation': previous_relation,
                       'last_observation_at': last_observation,
                       'tracking_status': 'stopped_at_gap' if gap else 'open_at_last_visible_bar',
                       'action': 'abstain'})
    events.sort(key=lambda e: (instant(e['observed_at']), e['chain_id'],
                              0 if e['kind'] == 'extreme_cross' else 1))
    return {'asof': instant(asof).isoformat(), 'definition': DEFINITION, 'source_rule': SOURCE,
            'qualification': 'price_response_only', 'action': 'abstain',
            'chains': chains, 'events': events,
            'pre_activation_crosses_excluded': sum(e['kind']=='wick_cross' for e in breaks['stale_refs']),
            'limits': ['No actual order quantities or participant intent inferred',
                       'No SFP/MSS/entry qualification; repeated closes outside do not prove continuation',
                       'Equal close is neither reclaim nor outside close',
                       'Same-bar observations have no reconstructed intrabar path',
                       'Missing data stops tracking; no continuation across the gap']}
