"""Display-only current price against frozen candidate rails.

These observations never update a detector, extend a drawn frame, or confirm
an exit. Structural rails advance by observed bars; pivot rails use their
original time anchors, matching their respective closed-bar observers.
"""
from math import isfinite
from .core import instant
from .structural_ranges import PARAMETERS as STRUCTURAL
from .long_geometry import PARAMETERS as GEOMETRIC, line_value


def closed_candidate_position(box, kind):
    if kind not in ('structural', 'geometric') or box.get('active') is not True:
        return None
    side=box.get('side', 0);streak=box.get('streak', 0)
    required=(STRUCTURAL if kind=='structural' else GEOMETRIC)['exit_closes']
    pending=side in (-1, 1) and 0<streak<required
    return dict(code='outside_pending' if pending else 'inside', side=side if pending else 0,
        streak=streak if pending else 0, required_closes=required,
        message=(('上' if side==1 else '下')+f'沿外已收盘 {streak}/{required} 根，离开候选区待跟进；尚非确认突破')
        if pending else '最近收盘未满足离开条件；仍为形态候选')


def candidate_price_observations(chart, bar):
    if not bar or bar.get('forming') is not True:
        return []
    try:
        end=instant(chart['closed_end']);start=instant(bar['time'])
        if start!=end:return []
        price=bar['close']
        if isinstance(price,bool) or not isinstance(price,(int,float)) or not isfinite(price):return []
    except (KeyError,TypeError,ValueError):
        return []
    result=[]
    for kind, field in (('structural','structural_current'),('geometric','geometric_current')):
        for box in chart.get(field) or []:
            closed=closed_candidate_position(box,kind)
            if not closed:continue
            try:
                if instant(box['end_at'])!=end or instant(box.get('first_observed_at') or box['known_at'])>end:continue
                if kind=='structural':
                    # Exactly one next, observed bar. Never use wall-clock gap
                    # duration to advance the regression-per-observed-bar rail.
                    upper=box['last_upper']+box['slope_per_bar']
                    lower=box['last_lower']+box['slope_per_bar']
                    tolerance=STRUCTURAL['breakout_atr']*box['frozen_atr']
                    basis='frozen_rails_at_observed_forming_bar'
                else:
                    g=box['geometry']
                    if g.get('validated') is not True:continue
                    if any(instant(p['known_at'])>end for p in g['upper']+g['lower']):continue
                    upper=line_value(g['upper'],start);lower=line_value(g['lower'],start)
                    tolerance=GEOMETRIC['boundary_tolerance_atr']*box['frozen_atr']
                    basis='frozen_pivot_lines_at_observed_forming_bar'
                if not all(isfinite(v) for v in (upper,lower,tolerance)) or tolerance<=0:continue
            except (KeyError,TypeError,ValueError,ZeroDivisionError):
                continue
            if upper<=lower:
                code='rails_crossed';message='本柱时刻两条边线已交会，等待收盘复核候选失效；不再视为有效区内空间'
            elif price>upper+tolerance:
                code='above_threshold';message='末柱在候选上沿越界阈值外，等待收盘及后续跟进；未确认突破'
            elif price<lower-tolerance:
                code='below_threshold';message='末柱在候选下沿越界阈值外，等待收盘及后续跟进；未确认突破'
            elif price>upper or price<lower:
                code='edge';message='末柱在候选边缘外、越界容差内；不改变候选资格'
            else:
                code='inside';message='末柱仍在候选轨道内；未收盘，不参与确认'
            result.append(dict(range_id=box['id'],kind=kind,shape=box['shape'],known_at=chart['closed_end'],
                closed_position=closed,confirmed=False,score_included=False,
                forming_observation=dict(code=code,message=message,bar_open_at=bar['time'],price=price,
                    upper=upper,lower=lower,threshold_high=upper+tolerance,threshold_low=lower-tolerance,
                    boundary_basis=basis,confirmed=False,score_included=False)))
    return result
