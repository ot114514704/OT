"""Closed-candle measurements for review, never an ICT displacement verdict."""
from statistics import median

from .core import instant, visible

DEFINITION = 'closed_candle_prior_range_measurements_v1'
SOURCE = 'research/candle_evidence_rules.json'


def measure_candles(bars, asof, lookback=20):
    """Use only preceding contiguous candles for the range baseline.

    A complete baseline requires exactly ``lookback`` prior bars. No partial
    baseline is substituted after a gap; zero baselines never produce infinity.
    Ratios describe this timeframe and cannot qualify a higher-timeframe MSS.
    """
    if type(lookback) is not int or not 1 <= lookback <= 500:
        raise ValueError('lookback must be an integer from 1 to 500')
    past = visible(bars, asof)
    if any(b.time <= a.time for a, b in zip(past, past[1:])):
        raise ValueError('Ordered unique bars required')
    if past and any(b.seconds != past[0].seconds for b in past):
        raise ValueError('One homogeneous timeframe required')
    rows, history = [], []
    for i, bar in enumerate(past):
        if i == 0 or past[i-1].closed_at != bar.time:
            history = []
        prior = history[-lookback:]
        baseline = median(b.high-b.low for b in prior) if len(prior) == lookback else None
        span, body = bar.high-bar.low, abs(bar.close-bar.open)
        rows.append({
            'definition': DEFINITION, 'source_rule': SOURCE,
            'bar_open_at': instant(bar.time).isoformat(),
            'known_at': bar.closed_at.isoformat(), 'timeframe_seconds': bar.seconds,
            'direction': 'up' if bar.close > bar.open else 'down' if bar.close < bar.open else 'flat',
            'range_price': span, 'body_price': body,
            'body_range_ratio': body/span if span > 0 else None,
            'close_location': (bar.close-bar.low)/span if span > 0 else None,
            'baseline_lookback': lookback, 'baseline_bars': len(prior),
            'baseline_first_open_at': instant(prior[0].time).isoformat() if prior else None,
            'baseline_last_closed_at': prior[-1].closed_at.isoformat() if prior else None,
            'prior_median_range_price': baseline,
            'baseline_status': 'insufficient_history' if baseline is None else 'zero_range' if baseline == 0 else 'available',
            'range_to_prior_median': span/baseline if baseline is not None and baseline > 0 else None,
            'body_to_prior_median': body/baseline if baseline is not None and baseline > 0 else None,
            'qualification': 'measurements_only_not_displacement_or_entry_confirmation',
        })
        history.append(bar)
    return rows
