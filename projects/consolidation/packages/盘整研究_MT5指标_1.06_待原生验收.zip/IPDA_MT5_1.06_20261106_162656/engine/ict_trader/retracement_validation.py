"""User-specified IPDA retracement scenarios, measured at closed candles.

This is an engineering interpretation, not a statement of institutional intent
or a calibrated trading signal. Lower timeframes and volume are never inferred.
"""
from collections import Counter
from statistics import mean
from bisect import bisect_right
from copy import deepcopy
from .core import instant
from .cisd import observe_cisd
from .program_context import attach_program_context

VERSION = 'ipda_retracement_sequence_v1'
PARAMETERS = dict(body_atr=.65, body_ratio=.6, wick_ratio=.4, cisd_basis='first_open_of_entire_contiguous_counter_sequence')
SOURCE = 'research/price_courses/retracement_user_rules.json'


def _evidence_score(checks, protection_source, contacts, ratio, speed):
    """Fixed denominator: unknown observations never inflate the score."""
    parts = []
    def add(name, weight, value, observed):
        points = round(weight * value, 2) if value is not None else 0
        parts.append(dict(name=name, weight=weight, points=points,
            status='unknown' if value is None else 'met' if value == 1 else 'partial' if value else 'unmet',
            observed=observed, source_rule=SOURCE,
            epistemic_label='uncalibrated_engineering_weight'))
    intact = checks['structure_intact']
    add('主参考结构保持（起点代理仅获部分分）', 25,
        None if intact is None else (1 if protection_source != 'native_frozen_origin_proxy' else .6) if intact else 0,
        protection_source if intact else '未满足' if intact is False else '缺少保护位')
    add('回调平均实体弱于此前推进', 10, None if ratio is None else float(ratio < 1), ratio)
    add('回调逐棒净速度弱于此前推进', 5, None if speed is None else float(speed < 1), speed)
    add('触及事前已知同向PD区域（OB候选半分）', 20,
        1 if any(z['kind'] == 'FVG' for z in contacts) else .5 if contacts else 0, len(contacts))
    add('接触后未收盘越过PD远端', 5, float(checks['pd_respected']), checks['pd_respected'])
    add('局部极值刺破并收回 SFP', 10, float(checks['sfp']), checks['sfp'])
    add('顺主方向实体位移', 5, float(checks['directional_displacement']), checks['directional_displacement'])
    add('收盘跨越事前逆向K线序列开盘价 CISD', 10, float(checks['cisd']), checks['cisd'])
    add('事前已验证H1同向背景', 10,
        None if checks['h1_alignment'] is None else float(checks['h1_alignment']), checks['h1_alignment'])
    return dict(score=round(sum(p['points'] for p in parts), 2), maximum=100,
        unknown_weight=sum(p['weight'] for p in parts if p['status']=='unknown'),
        components=parts, probability=None)


def build_retracement_validation(payload):
    phases = {p['bar_open_at']: p for p in payload.get('phases', [])}
    bars = sorted({b['time']: b for b in payload.get('evidence_bars', [])+
                   payload.get('bars', [])}.values(), key=lambda b:b['time'])
    native_cisd=observe_cisd(bars,payload.get('phases',[]),payload.get('period','M15'))
    cisd_by_time={e['bar_open_at']:e for e in native_cisd['events']}
    higher_cisd=(payload.get('h1_cisd') or {}).get('events',[])
    higher_times=[instant(e['known_at']) for e in higher_cisd]
    context = {r['bar_open_at']: r for r in payload.get('delivery_context', {}).get('rows', [])}
    h1_rows = payload.get('channels', {}).get('rows', []) if payload.get('period')=='H1' else []
    h1_times = [instant(r['known_at']) for r in h1_rows]
    rows, run, zones, pivots = [], [], [], []
    previous = None
    for b in bars:
        if run and run[-1]['closed_at'] != b['time']:
            run, zones, pivots, previous = [], [], [], None
        p = phases.get(b['time'])
        if p and instant(p['known_at']) != instant(b['closed_at']):
            raise ValueError('Retracement observation requires the matching candle close')
        ref = (p or {}).get('reference_before') or {}
        h1 = context.get(b['time'], {})
        if h1 and instant(h1['known_at']) != instant(b['closed_at']):
            raise ValueError('Future or mismatched H1 context')
        parent = h1.get('h1_before') if h1.get('background_status')=='available' else None
        if parent and instant(parent.get('snapshot_at', parent['protected_known_at'])) > instant(b['time']):
            raise ValueError('H1 background must be known before this candle')
        native_parent = None
        if h1_rows:
            pos = bisect_right(h1_times, instant(b['time']))-1
            if pos>=0 and (instant(b['time'])-h1_times[pos]).total_seconds()<3600:
                native_parent = h1_rows[pos].get('active')
        primary = parent if parent and parent.get('validated_at') else native_parent if native_parent and native_parent.get('validated_at') else None
        d = ref.get('direction')
        atr = ((p or {}).get('metrics') or {}).get('atr14_prior') or 0
        body = abs(b['close']-b['open'])
        span = max(b['high']-b['low'], 1e-9)
        origin = ref.get('origin_at','')
        identity = (origin, d, ref.get('origin_ref'))
        protected = (ref.get('low') if d == 1 else ref.get('high')) if ref else None
        protection_source = 'native_confirmed_IT_origin' if ref and not ref.get('origin_ref','lookback').startswith('lookback') else 'native_frozen_origin_proxy'
        if primary:
            d, protected = primary['direction'], primary['protected_price']
            origin = primary.get('start_at', primary['first_known_at'])
            identity = (primary['id'], d)
            protection_source = 'prior_validated_H1_channel'
        intact = (b['close']-protected)*d >= 0 if protected is not None and d in (-1,1) else None
        displaced = bool(d in (-1,1) and atr>0 and (b['close']-b['open'])*d>=.65*atr and body/span>=.6)
        contacts=[]
        if d in (-1,1):
            for z in zones + (p or {}).get('pda_contacts', []):
                if (z.get('direction')==d and z.get('known_at','')<=b['time']
                    and z.get('formed_at','')>=origin and not z.get('invalidated')
                    and b['high']>=z['low'] and b['low']<=z['high']):
                    item={k:z[k] for k in ('low','high','known_at','formed_at','direction')}
                    item['kind']=z.get('kind','FVG')
                    if item not in contacts: contacts.append(item)
        respected=[z for z in contacts if b['close']>=z['low']] if d==1 else [z for z in contacts if b['close']<=z['high']]
        # Only pivots confirmed by a prior close are eligible as sweep levels.
        sfp=None
        for pv in reversed(pivots):
            if d not in (-1,1) or pv['side']!=('high' if d==-1 else 'low') or pv['known_at']>b['time'] or pv['time']<origin:
                continue
            swept=b['high']>pv['price'] and b['close']<pv['price'] if d==-1 else b['low']<pv['price'] and b['close']>pv['price']
            if swept:sfp=pv;break
        wick=(b['high']-max(b['open'],b['close'])) if d==-1 else (min(b['open'],b['close'])-b['low'])
        rejection=bool(respected and (wick/span>=.4 or body/span<=.1))
        # Freeze the opening price of the contiguous counter-direction candle
        # sequence BEFORE the trigger bar. A large body alone is insufficient.
        counter=[]
        if d in (-1,1):
            for a in reversed(run):
                if a['time']<origin or (a['close']-a['open'])*d>=0:break
                counter.insert(0,a)
        prior=previous if previous and previous['identity']==identity else None
        threshold=counter[0]['open'] if counter else prior.get('threshold') if prior and prior['rejection'] else None
        sequence_start=counter[0]['time'] if counter else prior.get('sequence_start') if prior and prior['rejection'] else None
        cisd=bool(displaced and threshold is not None and (b['close']-threshold)*d>0)
        native_event=cisd_by_time.get(b['time'])
        if native_event and native_event['direction']==d and native_event['sequence_start']>=origin:
            cisd=True;threshold=native_event['basis_open'];sequence_start=native_event['sequence_start']
            displaced=True
        prior_contacts=prior['respected'] if prior else []
        pullback=bool((p and p['phase']=='retracement') or counter or
            (d in (-1,1) and (b['close']-b['open'])*d<0) or (prior and prior['pullback'] and prior['rejection']))
        sfp_cisd=bool(pullback and intact and prior and prior['sfp'] and prior['rejection'] and cisd)
        fvg_rejection=bool(pullback and intact and prior and prior['rejection'] and displaced and any(
            z['kind']=='FVG' and ((b['close']<z['low']) if d==-1 else (b['close']>z['high'])) for z in prior_contacts))
        ob_rejection=bool(pullback and intact and cisd and any(z['kind']=='OB_proxy' for z in respected+prior_contacts))
        counter_observed=counter+([b] if d in (-1,1) and (b['close']-b['open'])*d<0 else [])
        counter_start=counter_observed[0]['time'] if counter_observed else b['time']
        base_bodies=[abs(a['close']-a['open']) for a in run[-24:] if origin<=a['time']<counter_start and
                     d in (-1,1) and (a['close']-a['open'])*d>0]
        ratio=mean(abs(a['close']-a['open']) for a in counter_observed)/mean(base_bodies) if counter_observed and base_bodies and mean(base_bodies)>0 else None
        speed=abs(counter_observed[-1]['close']-counter_observed[0]['open'])/len(counter_observed)/mean(base_bodies) if counter_observed and base_bodies and mean(base_bodies)>0 else None
        h1_challenge=h1.get('protection_crossed') is True
        state=('structure_challenge' if intact is False or h1_challenge else
               'continuation_candidate' if sfp_cisd or fvg_rejection or ob_rejection else
               'rejection_awaiting_followthrough' if pullback and rejection else
               'pd_contact' if pullback and contacts else 'retracement_observing' if pullback else 'not_retracement')
        if p:
            evidence_contacts=contacts+([z for z in prior_contacts if z not in contacts] if pullback and prior else [])
            evidence_sfp=sfp or (prior['sfp'] if pullback and prior else None)
            checks=dict(structure_intact=intact, pd_contact=bool(evidence_contacts), sfp=bool(evidence_sfp),
                        pd_respected=any(b['close']>=z['low'] if d==1 else b['close']<=z['high'] for z in evidence_contacts),
                        rejection_wick=rejection, cisd=cisd, directional_displacement=displaced,
                        weak_body_relative_to_expansion=None if ratio is None else ratio<1,
                        h1_alignment=None if not parent or not parent.get('validated_at') else parent['direction']==d and not h1_challenge,
                        volume_contraction=None, lower_timeframe_confirmation=None)
            missing=[k for k,v in checks.items() if v is None or v is False]
            higher_pos=bisect_right(higher_times,instant(b['time']))-1
            higher_event=higher_cisd[higher_pos] if higher_pos>=0 else None
            resonance=None
            if higher_event and native_event and (instant(b['time'])-instant(higher_event['known_at'])).total_seconds()<=24*3600:
                resonance=higher_event['direction']==native_event['direction']
            rows.append(dict(phase_id=p['id'],bar_open_at=b['time'],known_at=b['closed_at'],
                phase=p['phase'],state=state,reference_direction=d,protected_price=protected,
                reference_id=primary['id'] if primary else str(identity),reference_origin=origin,
                available_pd_zones=[deepcopy(z) for z in zones if z['direction']==d and
                    z['known_at']<=b['time'] and z['formed_at']>=origin and not z.get('invalidated')][-12:],
                protection_source=protection_source,h1_context=h1.get('relation','not_available'),
                checks=checks,missing=missing,pd_contacts=contacts,sfp_reference=sfp,
                evidence_contacts=evidence_contacts,evidence_sfp_reference=evidence_sfp,
                evidence_score=_evidence_score(checks,protection_source,evidence_contacts,ratio,speed),
                native_cisd=native_event,h1_cisd_before=higher_event,cisd_resonance=resonance,
                cisd_sequence_start=sequence_start,cisd_open_level=threshold,
                counter_body_ratio=ratio,counter_speed_ratio=speed,patterns=dict(sfp_cisd=sfp_cisd,fvg_rejection=fvg_rejection,ob_rejection=ob_rejection),
                entry_qualified=False))
        previous=dict(identity=identity,respected=respected,sfp=sfp,rejection=rejection,
                      threshold=threshold,sequence_start=sequence_start,
                      pullback=pullback and intact is not False and not (sfp_cisd or fvg_rejection or ob_rejection))
        # Invalidate after this observation, and add newly formed zones after
        # decisions: no same-bar FVG/OB contact manufactured from future data.
        for z in zones:
            if (z['direction']==1 and b['close']<z['low']) or (z['direction']==-1 and b['close']>z['high']):z['invalidated']=True
        if len(run)>=2:
            a=run[-2]
            direction=1 if b['low']>a['high'] else -1 if b['high']<a['low'] else 0
            if direction:
                zones.append(dict(kind='FVG',direction=direction,low=a['high'] if direction==1 else b['high'],
                    high=b['low'] if direction==1 else a['low'],formed_at=a['time'],known_at=b['closed_at']))
            mid=run[-1]
            if mid['high']>a['high'] and mid['high']>=b['high']:
                pivots.append(dict(side='high',price=mid['high'],time=mid['time'],known_at=b['closed_at']))
            if mid['low']<a['low'] and mid['low']<=b['low']:
                pivots.append(dict(side='low',price=mid['low'],time=mid['time'],known_at=b['closed_at']))
        if displaced and len(run)>=6 and (b['close']>max(a['high'] for a in run[-6:]) if d==1 else b['close']<min(a['low'] for a in run[-6:])):
            opposite=next((a for a in reversed(run[-4:]) if (a['close']-a['open'])*d<0),None)
            if opposite:
                zones.append(dict(kind='OB_proxy',direction=d,low=opposite['low'],high=opposite['high'],
                                  formed_at=opposite['time'],known_at=b['closed_at']))
        run.append(b)
        pivots=pivots[-48:]
        zones=[z for z in zones if not z.get('invalidated')][-100:]
    return dict(definition=VERSION,parameters=PARAMETERS,rows=rows,native_cisd=native_cisd,summary=dict(Counter(r['state'] for r in rows)),
        source=SOURCE,
        policy='IPDA回撤证据链；OB仅为工程候选，Breaker未实现。保护位为同周期冻结起点代理，不宣称等同有效LH/MSS。影线不等于SFP，反包不等于CISD；阈值未校准，M1/M5及真实成交量未接入，不给胜率或入场授权。')


def attach_retracement_validation(payload):
    """Add the sequence evidence to retracement fit without changing phase labels."""
    report=build_retracement_validation(payload)
    payload['retracement_validation']=report
    by_time={r['bar_open_at']:r for r in report['rows']}
    for p in payload.get('phases',[]):
        fits=p.get('fit_scores')
        if not fits or p['bar_open_at'] not in by_time:continue
        old=fits['by_phase']['retracement']
        geometry=deepcopy(old.get('geometry_before_sequence',old))
        row=by_time[p['bar_open_at']];evidence=row['evidence_score']
        parts=[]
        for prefix,group in [('几何',geometry['components']),('证据',evidence['components'])]:
            for original in group:
                c=deepcopy(original);c['name']=prefix+' · '+c['name']
                c['weight']/=2;c['points']=round(c['points']/2,3);parts.append(c)
        eligibility=('contradicted' if row['state']=='structure_challenge' else
                     'reference_missing' if row['checks']['structure_intact'] is None else
                     'sequence_candidate' if row['state']=='continuation_candidate' else 'incomplete')
        fits['by_phase']['retracement']=dict(score=round(sum(c['points'] for c in parts)),
            earned_points=round(sum(c['points'] for c in parts),2),
            known_weight=sum(c['weight'] for c in parts if c['status']!='unknown'),
            unknown_weight=sum(c['weight'] for c in parts if c['status']=='unknown'),
            components=parts,eligibility=eligibility,geometry_before_sequence=geometry,
            evidence_score=evidence['score'],blend='geometry_50_sequence_50',version=VERSION)
    payload['retracement_score_policy']=dict(version=VERSION,source=SOURCE,
        blend='原局部几何50% + 回调序列证据50%；结构冲突单独阻断，不由总分抵消',
        meaning='规则符合度；未校准、非胜率。阶段标签不由分数自动改写。',
        weights=dict(structure=25,momentum=15,pd_array=25,sweep=10,restart=15,h1_alignment=10))
    attach_program_context(payload)
    return payload
