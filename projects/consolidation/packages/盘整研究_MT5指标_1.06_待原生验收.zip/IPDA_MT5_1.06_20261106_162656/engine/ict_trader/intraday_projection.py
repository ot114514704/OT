"""Show native M15 child structures on H1 without promoting H1 confirmation."""
from copy import deepcopy
from .core import instant


def attach_intraday_projection(charts):
    h1=charts.get('H1');m15=charts.get('M15')
    if not h1 or not m15:return charts
    items=[]
    for kind,name in [('range','consolidations'),('structural','structural_ranges'),('geometric','geometric_ranges')]:
        for source in m15.get(name,[]):
            first=source.get('first_observed_at') or source['known_at']
            duration=(instant(first)-instant(source['observed_from'])).total_seconds()
            if not 3*3600<=duration<=12*3600 or source['observed_from']<h1['bars'][0]['time']:continue
            # Keep first formation facts; the projection is a drawing aid,
            # never a new H1 event, source candle or scoring contribution.
            item=deepcopy(source);item.update(id='M15-on-H1:'+source['id'],source_period='M15',source_kind=kind,
                source_id=source['id'],projection_confirmed=False,score_included=False)
            # Accepted local ranges already carry a first-confirmation time;
            # their serialized records do not require a `confirmed` flag.
            # This preserves M15 formation qualification, never H1 qualification.
            item['source_confirmed']=kind=='range' and source.get('confirmed') is not False
            ended=any(word in source.get('status','') for word in ('突破条件触发','中止','结束','离开','失效'))
            item['active']=not ended and (source['active'] is True if 'active' in source else
                bool(m15.get('closed_end') and source.get('end_at') and instant(source['end_at'])==instant(m15['closed_end'])))
            item['confirmed']=False
            tags=(source.get('profile') or {}).get('tags',[])
            item['shape']=source.get('shape') or ('converging' if 'converging' in tags else 'tilted' if 'tilted' in tags else 'rectangle')
            item['projection_low']=source.get('liquidity_low',source.get('observed_low'))
            item['projection_high']=source.get('liquidity_high',source.get('observed_high'))
            item['first_observed_at']=first
            if source.get('profile'):item['geometry']=source['profile'].get('geometry')
            g=item.get('display_geometry') or item.get('geometry')
            if item['shape'] in ('tilted','converging') and g and g.get('validated'):
                points=g['upper']+g['lower']+g['frame']
                item['source_observed_from']=item['observed_from']
                item['observed_from']=min(p['time'] for p in points)
                item['projection_low']=min(p['price'] for p in points)
                item['projection_high']=max(p['price'] for p in points)
            items.append(item)
    h1['intraday_structures']=items
    return charts
