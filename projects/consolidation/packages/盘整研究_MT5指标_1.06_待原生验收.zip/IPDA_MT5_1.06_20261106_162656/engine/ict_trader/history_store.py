"""Keep accepted native closed history as the terminal's read window rolls.

The fresh native window replaces its entire covered interval (including gaps).
Only the older prefix is retained. Unverified seed data and forming bars never
enter this archive. An archive is committed only after model acceptance.
"""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path

from .core import Bar, instant

VERSION='native_closed_history_v1'
PERIOD_SECONDS={'H1':3600,'M15':900}


def source_identity(source):
    source=source or {}
    identity={k:str(source.get(k,'')).strip().casefold() for k in ('company','server','symbol')}
    if (source.get('status')!='verified' or identity['company']!='trademax global limited'
            or not identity['server'].startswith('trademaxglobal-') or identity['symbol']!='xauusd'):
        raise ValueError('历史保存需要已核对的TMGM原生XAUUSD来源')
    return identity


def validate_closed(raw):
    if not isinstance(raw,dict) or not raw or set(raw)-set(PERIOD_SECONDS):
        raise ValueError('历史周期无效')
    for period,rows in raw.items():
        if not isinstance(rows,list) or not rows:raise ValueError(period+'历史为空')
        previous=None
        for row in rows:
            if row.get('forming'):raise ValueError('未收盘K线不得进入历史存档')
            bar=Bar(instant(row['time']),*(row[k] for k in ('open','high','low','close')),
                    row.get('spread',0),PERIOD_SECONDS[period])
            if instant(row['closed_at'])!=bar.closed_at:raise ValueError('历史K线收盘时刻无效')
            if previous is not None and bar.time<=previous:raise ValueError('历史K线重复或倒序')
            previous=bar.time


class HistoryStore:
    def __init__(self,directory):
        self.directory=Path(directory)
        self.accepted={}

    def _key(self,source):
        identity=source_identity(source)
        key=sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()
        return key,identity

    def _load(self,key,identity):
        if key in self.accepted:return self.accepted[key]
        path=self.directory/(key+'.json')
        raw={}
        if path.exists():
            data=json.loads(path.read_text(encoding='utf-8'))
            if data.get('version')!=VERSION or data.get('source')!=identity:
                raise ValueError('历史存档版本或行情来源不匹配')
            raw=data['raw'];validate_closed(raw)
        self.accepted[key]=raw
        return raw

    @staticmethod
    def describe(raw,persisted):
        return dict(version=VERSION,persisted=persisted,
            periods={p:dict(bars=len(rows),first_open_at=rows[0]['time'],last_closed_at=rows[-1]['closed_at'])
                     for p,rows in raw.items()},
            scope='本项目已接收的同源原生已收盘历史；不代表经纪商全部历史')

    def prepare(self,incoming,source):
        key,identity=self._key(source)
        validate_closed(incoming)
        previous=self._load(key,identity)
        if previous and set(previous)!=set(incoming):raise ValueError('历史存档周期缺失')
        merged={}
        for period,rows in incoming.items():
            old=previous.get(period,[])
            if old and instant(rows[-1]['closed_at'])<instant(old[-1]['closed_at']):
                raise ValueError(period+'原生已收盘行情倒退，暂不覆盖历史')
            start=instant(rows[0]['time'])
            prefix=[b for b in old if instant(b['time'])<start]
            # Do not union rows inside the new interval: a missing bar from
            # that interval must remain missing, with its gap visible.
            merged[period]=deepcopy(prefix+rows)
        return merged,self.describe(merged,merged==previous)

    def persist(self,raw,source):
        key,identity=self._key(source)
        merged,_=self.prepare(raw,source)
        if merged!=raw:raise ValueError('待保存模型遗漏已保留的历史前缀')
        self.directory.mkdir(parents=True,exist_ok=True)
        path=self.directory/(key+'.json');temp=path.with_suffix('.tmp')
        temp.write_text(json.dumps(dict(version=VERSION,source=identity,raw=raw),
                                   ensure_ascii=False,separators=(',',':')),encoding='utf-8')
        temp.replace(path)
        self.accepted[key]=deepcopy(raw)
        return self.describe(raw,True)
