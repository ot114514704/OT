"""Causal consolidation: body balance first, Brooks geometry as corroboration.

Thresholds are explicit engineering hypotheses, not purported institutional code.
Only closed bars are accepted. Frozen bounds and first-known times never backfill.
"""
from copy import deepcopy
from statistics import median
from .core import visible
from .consolidation_profile import profile
from .oscillation import strong_oscillation

VERSION='ipda_body_balance_ranges_v5'
PARAMETERS=dict(windows=[12,24],width_atr_max=5.5,efficiency_max=.30,
                overlap_min=.50,body_occupancy_min=.80,small_body_atr_max=.65,
                drift_max=.45,edge_tests_min=2,crossings_min=2,
                breakout_atr=.15,breakout_closes=2,acceptance_closes=3)
SOURCE_REFS=[
 'research/ipda_nested_sources/88ae239848f1bb1c5baff4002859c905.jpg',
 'research/ipda_nested_sources/647b1106bc3813d102fdf338c5c35709.jpg',
 'research/brooks_chart_import/range-detector.original.js']
POLICY='以实体平衡区、双边往返和低方向效率识别盘整；影线极值另列流动性边缘。边界首次确认后冻结；假突破收回保留区间，突破需要收盘跟进。Brooks只作独立验证；阈值为待校准工程参数。'


def _quantile(values,fraction):
    values=sorted(values);at=(len(values)-1)*fraction;i=int(at)
    return values[i]+(values[min(i+1,len(values)-1)]-values[i])*(at-i)


def _candidate(bars,start,end,parameters=None):
    params=parameters or PARAMETERS
    w=bars[start:end+1];n=len(w)
    body_hi=[max(b.open,b.close) for b in w];body_lo=[min(b.open,b.close) for b in w]
    hi=_quantile(body_hi,.9);lo=_quantile(body_lo,.1);width=hi-lo;mid=(hi+lo)/2
    tr=[max(b.high-b.low,abs(b.high-w[k-1].close),abs(b.low-w[k-1].close)) if k else b.high-b.low for k,b in enumerate(w)]
    atr=median(tr)
    if width<=0 or atr<=0:return None
    travel=sum(abs(b.close-a.close) for a,b in zip(w,w[1:]))
    efficiency=abs(w[-1].close-w[0].close)/travel if travel else 0
    overlap=sum(max(0,min(a.high,b.high)-max(a.low,b.low))/max(1e-9,min(a.high-a.low,b.high-b.low)) for a,b in zip(w,w[1:]))/(n-1)
    occupancy=sum(l>=lo-.1*atr and h<=hi+.1*atr for l,h in zip(body_lo,body_hi))/n
    body_atr=sum(abs(b.close-b.open) for b in w)/n/atr
    drift=abs(median(b.close for b in w[n//2:])-median(b.close for b in w[:n//2]))/width
    upper=lower=crossings=0;up_armed=down_armed=True;last_side=0
    for k,b in enumerate(w):
        side=1 if b.close>mid else -1 if b.close<mid else 0
        if side and last_side and side!=last_side:crossings+=1
        if side:last_side=side
        # One bar cannot count as both an upper and lower independent visit.
        if up_armed and body_hi[k]>=hi-.2*width and b.close>mid:upper+=1;up_armed=False
        if down_armed and body_lo[k]<=lo+.2*width and b.close<mid:lower+=1;down_armed=False
        if b.close<=mid:up_armed=True
        if b.close>=mid:down_armed=True
    oscillation=strong_oscillation(w,atr,width)
    metrics=dict(atr=atr,width_atr=width/atr,efficiency=efficiency,overlap=overlap,oscillation=oscillation,
                 highTests=upper,lowTests=lower,crossings=crossings,body_occupancy=occupancy,
                 mean_body_atr=body_atr,half_window_drift=drift,window=n)
    checks=dict(compact=width/atr<=params['width_atr_max'],balanced=efficiency<=params['efficiency_max'],
                overlapping=overlap>=params['overlap_min'],body_accepted=occupancy>=params['body_occupancy_min'],small_bodies=body_atr<=params['small_body_atr_max'],
                no_drift=drift<=params['drift_max'],two_sided=upper>=params['edge_tests_min'] and lower>=params['edge_tests_min'],crossings=crossings>=params['crossings_min'],
                last_close_inside=lo-.1*atr<=w[-1].close<=hi+.1*atr,strong_oscillation=oscillation['qualified'])
    return dict(hi=hi,lo=lo,liquidity_hi=max(b.high for b in w),liquidity_lo=min(b.low for b in w),
                profile=profile(bars,start,end,atr),metrics=metrics,checks=checks,qualified=all(checks.values()),start=start)


def observe_ranges(bars,asof,parameters=None,level='local',breakout_basis='body'):
    params=parameters or PARAMETERS
    if breakout_basis not in ('body','liquidity'):raise ValueError('Unknown breakout basis')
    bars=visible(bars,asof);rows=[];ranges=[];active=None;segment=0
    if any(a.time>=b.time or a.seconds!=b.seconds for a,b in zip(bars,bars[1:])):raise ValueError('Ordered homogeneous bars required')
    for i,b in enumerate(bars):
        event=None;ended=None;candidates=[];sweep=None;sweep_evidence=None
        if i and bars[i-1].closed_at!=b.time:
            if active:
                active['status']='数据间隔中止';ended=deepcopy(active);event='data_gap'
            active=None;segment=i
        if active:
            # Retain excursions over several closed bars until an actual reclaim.
            # Outside closes that become a sustained breakout are never counted as sweeps.
            for edge,crossed,extreme in [('upper',b.high>active['liquidity_hi'],b.high),('lower',b.low<active['liquidity_lo'],b.low)]:
                if crossed:
                    record=active['pending_sweeps'].get(edge)
                    if record:record.update(extreme=max(record['extreme'],extreme) if edge=='upper' else min(record['extreme'],extreme),last_excursion_at=b.closed_at.isoformat())
                    else:active['pending_sweeps'][edge]=dict(first_excursion_at=b.closed_at.isoformat(),last_excursion_at=b.closed_at.isoformat(),extreme=extreme)
            upper=active['liquidity_hi'] if breakout_basis=='liquidity' else active['hi']
            lower=active['liquidity_lo'] if breakout_basis=='liquidity' else active['lo']
            side=1 if b.close>upper+params['breakout_atr']*active['atr'] else -1 if b.close<lower-params['breakout_atr']*active['atr'] else 0
            previous_side=active['side']
            if side and side!=previous_side:active['break_start']=i
            active['streak']=active['streak']+1 if side and side==previous_side else 1 if side else 0
            active['side']=side
            if side:
                first=bars[active['break_start']]
                distance=(b.close-(upper if side>0 else lower))*side
                follow=(b.close-first.close)*side>0 and (abs(b.close-first.open)>=.35*active['atr'] or distance>=.5*active['atr'])
                accepted=active['streak']>=params['acceptance_closes'] or active['streak']>=params['breakout_closes'] and follow
                if accepted:
                    active['status']='向上突破条件触发' if side>0 else '向下突破条件触发'
                    active['end']=i;active['breakIndex']=i;segment=i+1;ended=deepcopy(active);active=None;event='breakout_confirmed'
                else:
                    active['end']=i;active['status']='越界待跟进';event='breakout_pending'
            else:
                recovered={}
                for edge,record in active['pending_sweeps'].items():
                    if (edge=='upper' and b.close<=active['liquidity_hi']) or (edge=='lower' and b.close>=active['liquidity_lo']):recovered[edge]=deepcopy(record)
                if recovered:sweep='both' if len(recovered)==2 else next(iter(recovered))
                if sweep:
                    sweep_evidence=dict(side=sweep,known_at=b.closed_at.isoformat(),excursions=recovered)
                    active['sweep_count']+=1;active['last_sweep']=deepcopy(sweep_evidence)
                    for edge in recovered:del active['pending_sweeps'][edge]
                active['end']=i;active['status']='假突破收回' if previous_side or sweep else '区间延续'
                event='range_reclaimed' if previous_side or sweep else 'range_held'
        elif event!='data_gap':
            for n in reversed(params['windows']):
                if i-segment+1>=n:
                    c=_candidate(bars,i-n+1,i,params)
                    if c:candidates.append(c)
            chosen=next((c for c in candidates if c['qualified']),None)
            if chosen:
                active=dict(id=len(ranges)+1,level=level,breakout_basis=breakout_basis,start=chosen['start'],confirmed=i,end=i,
                            hi=chosen['hi'],lo=chosen['lo'],liquidity_hi=chosen['liquidity_hi'],liquidity_lo=chosen['liquidity_lo'],
                            **chosen['metrics'],checks=chosen['checks'],profile=chosen['profile'],sweep_count=0,last_sweep=None,pending_sweeps={},status='区间延续',streak=0,side=0)
                ranges.append(active);event='range_confirmed'
        rows.append(dict(known_at=b.closed_at.isoformat(),active=deepcopy(active),ended=ended,event=event,sweep=sweep,sweep_evidence=sweep_evidence,
                         candidates=candidates))
    return dict(version=VERSION,parameters=params,policy=POLICY,rows=rows,ranges=ranges)


def phase_evidence(observation,bars,brooks=None):
    def timed(r):
        if not r:return None
        return dict(id=VERSION+(':macro:' if r.get('level')=='macro' else ':')+bars[r['confirmed']].time.isoformat(),level=r.get('level','local'),breakout_basis=r.get('breakout_basis','body'),low=r['lo'],high=r['hi'],
                    liquidity_high=r['liquidity_hi'],liquidity_low=r['liquidity_lo'],
                    observed_from=bars[r['start']].time.isoformat(),known_at=bars[r['confirmed']].closed_at.isoformat(),
                    end_at=bars[r['end']].closed_at.isoformat(),status=r['status'],breakout_side=r['side'],breakout_streak=r['streak'],
                    frozen_atr=r['atr'],efficiency=r['efficiency'],overlap=r['overlap'],high_tests=r['highTests'],low_tests=r['lowTests'],
                    crossings=r['crossings'],body_occupancy=r['body_occupancy'],mean_body_atr=r['mean_body_atr'],half_window_drift=r['half_window_drift'],window=r['window'],
                    oscillation=r['oscillation'],
                    profile=r['profile'],sweep_count=r['sweep_count'],last_sweep=r['last_sweep'],pending_liquidity_excursions=r['pending_sweeps'],checks=r['checks'],boundary_basis='frozen_body_balance',brooks_confirmed=bool(brooks and brooks['active']))
    return dict(version=VERSION,range=timed(observation['active']),ended=timed(observation['ended']),event=observation['event'],
                sweep=observation['sweep'],sweep_evidence=observation.get('sweep_evidence'),candidates=observation['candidates'],source_refs=SOURCE_REFS,
                brooks_confirmed=bool(brooks and brooks['active']))
