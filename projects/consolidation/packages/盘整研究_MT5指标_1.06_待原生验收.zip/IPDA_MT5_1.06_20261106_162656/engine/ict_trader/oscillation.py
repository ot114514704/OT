"""Strong bidirectional close excursions; a selection gate, never a score."""
PARAMETERS=dict(minimum_leg_atr=.6,minimum_leg_width_fraction=.25,minimum_completed_legs=3,
                recent_bars=6,impulse_atr=1.5,impulse_efficiency=.75,
                displacement_windows=[3,6],displacement_atr=2.5,displacement_width_fraction=.6,
                displacement_efficiency=.8,displacement_reclaim_fraction=.35,displacement_outside_fraction=.2)


def strong_oscillation(bars,atr,width,slope_per_bar=0.):
    known=bars[-1].closed_at.isoformat() if bars else None
    threshold=max(PARAMETERS['minimum_leg_atr']*atr,PARAMETERS['minimum_leg_width_fraction']*width)
    result=dict(qualified=False,known_at=known,threshold=threshold,completed_legs=0,up_legs=0,down_legs=0,
                basis='frozen_channel_residual_closes' if slope_per_bar else 'closed_prices',legs=[],recent_impulse=False,unreversed_displacements=[],
                policy='只统计收盘价格达到幅度门槛、再反向达到同等门槛的完成摆动；影线和末柱不补造往返，阈值仅在本次观察时刻可知')
    if len(bars)<4 or atr<=0 or width<=0:return result
    values=[b.close-slope_per_bar*i for i,b in enumerate(bars)]
    low=high=0;direction=0;extreme=0;anchor=None;legs=[]
    def add_leg(start,end,reversal):
        motion=1 if values[end]>values[start] else -1
        legs.append(dict(direction=motion,amplitude=abs(values[end]-values[start]),
            from_bar=bars[start].time.isoformat(),to_bar=bars[end].time.isoformat(),
            reversal_observed_at=bars[reversal].closed_at.isoformat(),known_at=known))
    for i,value in enumerate(values):
        if i and bars[i-1].closed_at!=bars[i].time:
            low=high=extreme=i;direction=0;anchor=None
            continue
        if direction==0:
            if value<values[low]:low=i
            if value>values[high]:high=i
            if value-values[low]>=threshold:anchor=low;extreme=i;direction=1
            elif values[high]-value>=threshold:anchor=high;extreme=i;direction=-1
        elif direction==1:
            if value>=values[extreme]:extreme=i
            elif values[extreme]-value>=threshold:
                add_leg(anchor,extreme,i);anchor=extreme;extreme=i;direction=-1
        else:
            if value<=values[extreme]:extreme=i
            elif value-values[extreme]>=threshold:
                add_leg(anchor,extreme,i);anchor=extreme;extreme=i;direction=1
    recent_start=max(0,len(bars)-PARAMETERS['recent_bars'])
    for i in range(recent_start+1,len(bars)):
        if bars[i-1].closed_at!=bars[i].time:recent_start=i
    recent=values[recent_start:];travel=sum(abs(b-a) for a,b in zip(recent,recent[1:]));net=abs(recent[-1]-recent[0])
    impulse=net>=PARAMETERS['impulse_atr']*atr and travel>0 and net/travel>=PARAMETERS['impulse_efficiency']
    displacements=[];minimum=max(PARAMETERS['displacement_atr']*atr,PARAMETERS['displacement_width_fraction']*width)
    for length in PARAMETERS['displacement_windows']:
        for end in range(length-1,len(bars)):
            start=end-length+1
            if start<6:continue
            move=bars[end].close-bars[start].open
            # Most short windows cannot reach the displacement threshold.
            # Reject them before slicing, continuity checks and path summation;
            # no later condition can make a below-threshold move qualify.
            if abs(move)<minimum:continue
            section=bars[start:end+1]
            if any(a.closed_at!=b.time for a,b in zip(section,section[1:])):continue
            travel=abs(section[0].close-section[0].open)+sum(abs(b.close-a.close) for a,b in zip(section,section[1:]))
            if travel<=0 or abs(move)/travel<PARAMETERS['displacement_efficiency']:continue
            side=1 if move>0 else -1
            prior=[b.close for b in bars[:start]];residual=values[:start]
            raw_excursion=(section[-1].close-(max(prior) if side>0 else min(prior)))*side
            residual_excursion=(values[end]-(max(residual) if side>0 else min(residual)))*side
            # A large ordinary range leg is desirable. Exclude a displacement
            # only when it also leaves the previously observed price envelope;
            # small channel drift must not turn every strong swing into exit.
            if max(raw_excursion,residual_excursion)<max(.15*atr,PARAMETERS['displacement_outside_fraction']*width):continue
            reclaimed=any((section[-1].close-b.close)*side>=PARAMETERS['displacement_reclaim_fraction']*abs(move) for b in bars[end+1:])
            if not reclaimed:displacements.append(dict(from_bar=section[0].time.isoformat(),to_bar=section[-1].time.isoformat(),direction=side,net=abs(move),known_at=known))
    ups=sum(p['direction']==1 for p in legs);downs=len(legs)-ups
    result.update(qualified=len(legs)>=PARAMETERS['minimum_completed_legs'] and ups>0 and downs>0 and not impulse and not displacements,
                  completed_legs=len(legs),up_legs=ups,down_legs=downs,legs=legs,recent_impulse=impulse,unreversed_displacements=displacements)
    return result
