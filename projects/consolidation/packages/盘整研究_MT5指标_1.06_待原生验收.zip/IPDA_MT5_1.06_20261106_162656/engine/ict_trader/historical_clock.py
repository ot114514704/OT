"""Validate independently evidenced MT5 historical clock coverage.

The live MT5 calibration proves only a short current interval.  Historical
session analysis needs a separate, auditable proof with explicit raw-time
segments, offsets, DST coverage, and evidence references.  This module only
validates that contract; it never guesses an offset from a date or a Boolean.
"""

from __future__ import annotations

from datetime import timedelta
from math import isfinite

from .core import instant

VERSION = "mt5_historical_clock_proof_v2"


def validate_proof(proof):
    """Return a serializable validation report for a historical clock proof.

    A valid proof is deliberately stricter than the current-tick calibration:
    it must state ``status=verified``, explicitly attest to historical DST
    coverage, and provide non-overlapping, evidenced raw-time segments.
    Validation checks the contract, not the authenticity of evidence references.
    UTC mappings must also be unambiguous; a clock transition needs explicit
    segments rather than extrapolation of today's offset.
    """
    errors = []
    if not isinstance(proof, dict):
        return {"definition": VERSION, "valid": False,
                "errors": ["proof must be an object"], "segments": []}
    if proof.get("status") != "verified":
        errors.append("status must be verified")
    if proof.get("historical_dst_verified") is not True:
        errors.append("historical_dst_verified must be true")
    source = proof.get("source")
    if source is not None and not isinstance(source, (str, dict, list)):
        errors.append("source must be text or an object/list when present")
    raw_segments = proof.get("segments")
    if not isinstance(raw_segments, list) or not raw_segments:
        errors.append("segments must be a non-empty list")
        return {"definition": VERSION, "valid": not errors,
                "errors": errors, "segments": []}

    segments = []
    for index, segment in enumerate(raw_segments):
        if not isinstance(segment, dict):
            errors.append(f"segment {index} must be an object")
            continue
        if not segment.get("evidence"):
            errors.append(f"segment {index} needs evidence")
        try:
            start = instant(segment["raw_start"])
            end = instant(segment["raw_end"])
            if isinstance(segment["offset_seconds"], bool):
                raise ValueError("Boolean offset")
            offset = float(segment["offset_seconds"])
            if not isfinite(offset):
                raise ValueError("Nonfinite offset")
            utc_start = start - timedelta(seconds=offset)
            utc_end = end - timedelta(seconds=offset)
        except (KeyError, AttributeError, OverflowError, TypeError, ValueError):
            errors.append(f"segment {index} has invalid interval or offset")
            continue
        if not start < end:
            errors.append(f"segment {index} must have raw_start before raw_end")
        segments.append({
            "raw_start": start.isoformat(),
            "raw_end": end.isoformat(),
            "offset_seconds": offset,
            "utc_start": utc_start.isoformat(),
            "utc_end": utc_end.isoformat(),
            "evidence": segment.get("evidence"),
        })

    ordered = sorted(segments, key=lambda item: item["raw_start"])
    for previous, current in zip(ordered, ordered[1:]):
        if instant(previous["raw_end"]) > instant(current["raw_start"]):
            errors.append("segments overlap")
            break
    utc_ordered = sorted(segments, key=lambda item: item["utc_start"])
    for previous, current in zip(utc_ordered, utc_ordered[1:]):
        if instant(previous["utc_end"]) > instant(current["utc_start"]):
            errors.append("normalized UTC segments overlap")
            break

    valid = not errors and len(ordered) == len(raw_segments)
    report = {"definition": VERSION, "valid": valid, "errors": errors,
              "segments": ordered,
              "validation_scope": "contract_and_intervals_only_not_evidence_authentication"}
    if ordered:
        report["coverage"] = {
            "raw_start": ordered[0]["raw_start"],
            "raw_end": ordered[-1]["raw_end"],
            "offsets_seconds": sorted({s["offset_seconds"] for s in ordered}),
            "utc_start": utc_ordered[0]["utc_start"],
            "utc_end": max(s["utc_end"] for s in utc_ordered),
        }
    return report


def _covers(proof, start, end, domain):
    report = validate_proof(proof)
    if not report["valid"]:
        return False
    start, end = instant(start), instant(end)
    if not start < end:
        return False
    cursor = start
    for segment in sorted(report["segments"], key=lambda item: item[f"{domain}_start"]):
        segment_start = instant(segment[f"{domain}_start"])
        segment_end = instant(segment[f"{domain}_end"])
        if segment_end <= cursor:
            continue
        if segment_start > cursor:
            return False
        cursor = max(cursor, segment_end)
        if cursor >= end:
            return True
    return False


def covers(proof, raw_start, raw_end):
    """Return whether valid segments continuously cover a raw-time interval."""
    return _covers(proof, raw_start, raw_end, "raw")


def covers_utc(proof, utc_start, utc_end):
    """Check normalized UTC coverage using raw minus offset for each segment.

    Already-normalized bar times must never be compared with raw bounds.
    Half-open segments may meet exactly, but gaps and overlaps are rejected.
    This checks temporal coverage, not bar origin or evidence authenticity.
    """
    return _covers(proof, utc_start, utc_end, "utc")


def proof_is_valid(proof):
    """Small predicate for callers that only need the gate decision."""
    return validate_proof(proof)["valid"]
