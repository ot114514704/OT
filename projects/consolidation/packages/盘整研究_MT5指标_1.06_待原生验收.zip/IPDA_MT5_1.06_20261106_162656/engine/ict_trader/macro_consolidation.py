"""Independent outer balance, never a retrospective merge of local boxes."""
from .ipda_ranges import observe_ranges,phase_evidence,PARAMETERS as LOCAL_PARAMETERS
from .current_consolidation import classify,state_history,CHECK_NAMES

VERSION='ipda_macro_balance_v2'
PARAMETERS={**LOCAL_PARAMETERS,'windows':[24,48,72]}
POLICY='独立观察24/48/72根连续已收盘K线。形成条件与局部盘整相同；首次确认冻结实体及影线边缘。外层退出检查冻结影线边缘，不因内部小框突破退出，不跨缺口拼接。图形可回看形成窗口，首次确认时间另列。'


def score(e):
    box=e.get('range') or e.get('ended');checks=box['checks'] if box else {}
    weights=dict(overlapping=10,balanced=10,compact=10,body_accepted=10,small_bodies=10,no_drift=10,two_sided=10,crossings=5)
    components=[dict(name=CHECK_NAMES[k],weight=w,points=w if checks.get(k) is True else 0,status='met' if checks.get(k) is True else 'unmet' if k in checks else 'unknown') for k,w in weights.items()]
    components.append(dict(name='外层尚未确认突破',weight=5,points=5 if e.get('range') else 0,status='met' if e.get('range') else 'unmet'))
    components.extend(dict(name=name,weight=10,points=0,status='unknown') for name in ('HTF关键位置','HTF程序方向'))
    return dict(score=sum(x['points'] for x in components),maximum=100,components=components,unknown_weight=sum(x['weight'] for x in components if x['status']=='unknown'),meaning='规则符合度，不作确认门槛')


def analyze_macro(bars):
    observations=observe_ranges(bars,bars[-1].closed_at,parameters=PARAMETERS,level='macro',breakout_basis='liquidity')
    rows=[];ranges={}
    for b,observation in zip(bars,observations['rows']):
        e=phase_evidence(observation,bars);fit=score(e)
        row=dict(bar_open_at=b.time.isoformat(),known_at=b.closed_at.isoformat(),phase='undetermined',consolidation_evidence=e,fit_scores={'by_phase':{'consolidation':fit}})
        rows.append(row)
        box=e['range'] or e['ended']
        if box:ranges[box['id']]={**box,'observed_at':row['known_at'],'score':fit,'confirmation_score':ranges.get(box['id'],{}).get('confirmation_score',fit)}
    current=classify(dict(phase_rows=rows));current['level']='macro';current['version']=VERSION
    return dict(version=VERSION,parameters=PARAMETERS,policy=POLICY,current=current,ranges=list(ranges.values()),history=state_history(dict(phase_rows=rows)))
