"""Lines between already confirmed local highs/lows; no future projection."""
from statistics import median
from math import isclose

VERSION='confirmed_swing_geometry_v3'
PARAMETERS=dict(minimum_overlap_bars=3,boundary_tolerance_atr=.15,wick_coverage_min=.8,close_coverage_min=.9)
MORPHOLOGY_PARAMETERS=dict(channel_slope_difference_max=.20,channel_width_change_max=.10)


def frame_morphology(frame,tolerance):
    """Qualify shape separately from candle coverage on the same time span.

    Direction and parallelism use price changes over the common interval,
    not angles in screen pixels or slopes measured over different intervals.
    """
    uh,ul,ll,lh=[p['price'] for p in frame]
    du=ul-uh;dl=ll-lh;first=uh-lh;last=ul-ll
    # Interpolation can leave machine-precision width differences on parallel rails.
    narrowing=last<first and not isclose(last,first,rel_tol=1e-10)
    motion=max(abs(du),abs(dl))
    flat=min(tolerance,.05*motion)
    difference=abs(du-dl)/motion if motion else 0.
    width_change=abs(last-first)/first
    parallel=du*dl>0 and difference<=MORPHOLOGY_PARAMETERS['channel_slope_difference_max'] and width_change<=MORPHOLOGY_PARAMETERS['channel_width_change_max']
    subtype=('ascending_triangle' if narrowing and abs(du)<=flat and dl>0 else
             'descending_triangle' if narrowing and abs(dl)<=flat and du<0 else
             'triangle' if du<0 and dl>0 else
             'rising_wedge' if narrowing and du>0 and dl>0 else
             'falling_wedge' if narrowing and du<0 and dl<0 else
             'channel' if parallel else 'flat_range' if not motion else
             'broadening' if last>first else 'unclassified')
    qualified=subtype in ('ascending_triangle','descending_triangle','triangle','rising_wedge','falling_wedge','channel')
    return dict(qualified=qualified,subtype=subtype,upper_change=du,lower_change=dl,
        same_direction=du*dl>0,relative_slope_difference=difference,relative_width_change=width_change,
        parameters=MORPHOLOGY_PARAMETERS,
        reason='边线形态条件满足；仍需共同样本和价格覆盖验证' if qualified else
               '边线外扩，不满足同向近似平行通道或收敛形态' if subtype=='broadening' else
               '两边线水平；不属于倾斜通道或收敛形态' if subtype=='flat_range' else '边线形态条件不足')

def confirmed_geometry(bars,atr=None):
    if any(a.closed_at!=b.time or a.seconds!=b.seconds for a,b in zip(bars,bars[1:])):
        return dict(version=VERSION,upper=[],lower=[],ready=False,validated=False,reason="数据不连续，禁止跨缺口连接",basis="last_two_confirmed_swing_points",projected=False)
    highs=[];lows=[]
    for i in range(1,len(bars)-1):
        a,b,c=bars[i-1:i+2]
        if a.closed_at!=b.time or b.closed_at!=c.time:continue
        point=dict(time=b.time.isoformat(),known_at=c.closed_at.isoformat())
        if b.high>a.high and b.high>=c.high:highs.append({**point,'price':b.high})
        if b.low<a.low and b.low<=c.low:lows.append({**point,'price':b.low})
    upper=highs[-2:];lower=lows[-2:]
    result=dict(version=VERSION,upper=upper,lower=lower,ready=False,validated=False,reason='需至少两个已确认高点及两个已确认低点',basis='last_two_confirmed_swing_points',projected=False)
    if len(upper)<2 or len(lower)<2:return result
    from .core import instant
    start=max(instant(upper[0]['time']),instant(lower[0]['time']))
    end=min(instant(upper[-1]['time']),instant(lower[-1]['time']))
    def value(points,time):
        a,b=points;ta,tb=instant(a['time']),instant(b['time'])
        return a['price']+(b['price']-a['price'])*(time-ta).total_seconds()/(tb-ta).total_seconds()
    if end<=start:return {**result,'reason':'高低点连线缺少共同已观察区间'}
    uh,ul=value(upper,start),value(upper,end);lh,ll=value(lower,start),value(lower,end)
    if uh<=lh or ul<=ll:return {**result,'reason':'连线已交叉，不绘制有效形态框'}
    frame=[dict(time=start.isoformat(),price=uh),dict(time=end.isoformat(),price=ul),dict(time=end.isoformat(),price=ll),dict(time=start.isoformat(),price=lh)]
    scale=atr if atr is not None else median(b.high-b.low for b in bars)
    window=[b for b in bars if start<=instant(b.time)<=end]
    if scale<=0:return {**result,'reason':'幅度不可验证，禁止绘制有效形态框'}
    tolerance=PARAMETERS['boundary_tolerance_atr']*scale
    morphology=frame_morphology(frame,tolerance)
    wick=sum(b.high<=value(upper,instant(b.time))+tolerance and b.low>=value(lower,instant(b.time))-tolerance for b in window)/len(window)
    close=sum(value(lower,instant(b.time))-tolerance<=b.close<=value(upper,instant(b.time))+tolerance for b in window)/len(window)
    covered=wick>=PARAMETERS['wick_coverage_min'] and close>=PARAMETERS['close_coverage_min']
    enough=len(window)>=PARAMETERS['minimum_overlap_bars']
    validation=dict(overlap_bars=len(window),wick_coverage=wick,close_coverage=close,tolerance=tolerance,parameters=PARAMETERS)
    reason='连线穿越过多K线，边界覆盖验证未通过' if not covered else '共同覆盖样本不足，仅为锚点连线' if not enough else morphology['reason'] if not morphology['qualified'] else '已确认锚点、形态及边界覆盖验证通过；仅绘制已覆盖区间'
    return {**result,'ready':covered,'validated':covered and enough and morphology['qualified'],'reason':reason,'frame':frame,'subtype':morphology['subtype'],'morphology':morphology,
            'validation':validation,'contraction_ratio':(ul-ll)/(uh-lh),'known_at':max(p['known_at'] for p in upper+lower)}
