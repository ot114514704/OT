"""Read only broker/server/symbol labels; never expose account identifiers."""
VERSION='tmgm_source_labels_v1'


class MarketSourceError(RuntimeError):
    def __init__(self,source):
        self.market_source=source
        super().__init__(source['reason'])


def inspect_source(mt,spec):
    try:account=mt.account_info()
    except Exception:account=None
    def label(obj,key):
        value=getattr(obj,key,None)
        return value.strip() if isinstance(value,str) else ''
    company=label(account,'company');server=label(account,'server');symbol=label(spec,'name')
    complete=bool(company and server and symbol)
    matched=(company.casefold()=='trademax global limited' and
             server.casefold().startswith('trademaxglobal-') and symbol=='XAUUSD')
    status='verified' if matched else 'source_mismatch' if complete else 'source_unverified'
    reasons=dict(verified='终端经纪商、服务器及XAUUSD标签匹配本项目TMGM来源配置',
                 source_mismatch='终端来源不匹配TMGM/XAUUSD配置，暂停读取和重算，保留原模型',
                 source_unverified='缺少经纪商、服务器或品种标签，暂停读取和重算，保留原模型')
    return dict(version=VERSION,status=status,company=company,server=server,symbol=symbol,reason=reasons[status])
