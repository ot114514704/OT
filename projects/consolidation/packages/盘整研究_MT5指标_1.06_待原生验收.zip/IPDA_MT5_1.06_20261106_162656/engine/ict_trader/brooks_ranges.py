"""Direct port of the user's Brooks chart's detectRanges, with causal snapshots.

Source copy: research/brooks_chart_import/range-detector.original.js.
Thresholds are that chart's engineering rules, not a formula claimed by Brooks.
H1 changes only the expected candle interval; no gap filling or source mixing.
"""
from copy import deepcopy
from .core import visible

VERSION = 'brooks_user_chart_ranges_v1'
PARAMETERS = dict(window=12, width_atr_max=4.5, efficiency_max=.3,
                  overlap_min=.5, high_tests_min=2, low_tests_min=2,
                  crossings_min=2, breakout_atr=.15, breakout_closes=2)
POLICY = '直接移植阿尔布鲁克斯图表的12棒规则；冻结边界，连续2根收盘越过0.15倍冻结均幅才结束；缺棒重置。H1仅替换周期长度，阈值尚未校准。'


def observe_ranges(bars, asof, *, sources=None):
    bars = visible(bars, asof)
    if not bars:
        return dict(version=VERSION, parameters=PARAMETERS, policy=POLICY, rows=[], ranges=[])
    if any(b.seconds != bars[0].seconds for b in bars) or any(b.time <= a.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Ordered homogeneous closed bars required')
    if sources is not None and len(sources) < len(bars):
        raise ValueError('Source label required for each bar')
    ranges=[]; rows=[]; active=None; segment=0; n=12
    for i,b in enumerate(bars):
        event=None; ended=None; metrics=None
        if i and (bars[i-1].closed_at != b.time or sources is not None and sources[i] != sources[i-1]):
            if active:
                active['status']='数据间隔中止'; ended=deepcopy(active)
                event='data_gap'
            active=None; segment=i
        if active:
            side=1 if b.close>active['hi']+.15*active['atr'] else -1 if b.close<active['lo']-.15*active['atr'] else 0
            active['streak']=active['streak']+1 if side and side==active['side'] else 1 if side else 0
            active['side']=side
            if active['streak']>=2:
                active['status']='向上突破条件触发' if side>0 else '向下突破条件触发'
                active['breakIndex']=i; ended=deepcopy(active); active=None; event='breakout_confirmed'
            else:
                active['end']=i; active['status']='越界待跟进' if side else '区间延续'
                event='breakout_pending' if side else 'range_held'
        elif i-segment>=n-1:
            start=i-n+1; w=bars[start:i+1]
            hi=max(x.high for x in w); lo=min(x.low for x in w); width=hi-lo
            atr=sum(max(x.high-x.low,abs(x.high-w[k-1].close) if k else 0,
                        abs(x.low-w[k-1].close) if k else 0) for k,x in enumerate(w))/n
            travel=sum(abs(x.close-w[k].close) for k,x in enumerate(w[1:]))
            efficiency=abs(w[-1].close-w[0].close)/travel if travel else 0
            overlap=0; high_tests=0; low_tests=0; crossings=0; mid=(hi+lo)/2
            for k in range(1,n):
                a,c=w[k-1],w[k]
                overlap+=max(0,min(a.high,c.high)-max(a.low,c.low))/max(1e-9,min(a.high-a.low,c.high-c.low))
                if (a.close-mid)*(c.close-mid)<0: crossings+=1
                if k<n-1:
                    if c.high>a.high and c.high>=w[k+1].high and c.high>=hi-width*.25: high_tests+=1
                    if c.low<a.low and c.low<=w[k+1].low and c.low<=lo+width*.25: low_tests+=1
            overlap/=n-1
            metrics=dict(atr=atr,width_atr=width/atr if atr else None,efficiency=efficiency,
                         overlap=overlap,highTests=high_tests,lowTests=low_tests,crossings=crossings)
            if atr>0 and width/atr<=4.5 and efficiency<=.3 and overlap>=.5 and high_tests>=2 and low_tests>=2 and crossings>=2:
                active=dict(id=len(ranges)+1,start=start,confirmed=i,end=i,hi=hi,lo=lo,
                            **{k:v for k,v in metrics.items() if k!='width_atr'},status='区间延续',streak=0,side=0)
                ranges.append(active); event='range_confirmed'
        rows.append(dict(known_at=b.closed_at.isoformat(),active=deepcopy(active),ended=ended,event=event,metrics=metrics))
    return dict(version=VERSION,parameters=PARAMETERS,policy=POLICY,rows=rows,ranges=ranges)


def phase_evidence(observation, bars):
    """Map original index coordinates to timestamps without backdating knowledge."""
    r=observation['active']; ended=observation['ended']
    def timed(z):
        if not z: return None
        return dict(id=VERSION+':'+bars[z['confirmed']].time.isoformat(),
                    low=z['lo'],high=z['hi'],observed_from=bars[z['start']].time.isoformat(),
                    known_at=bars[z['confirmed']].closed_at.isoformat(),
                    end_at=bars[z['end']].closed_at.isoformat(),status=z['status'],
                    breakout_side=z['side'],breakout_streak=z['streak'],frozen_atr=z['atr'],
                    efficiency=z['efficiency'],overlap=z['overlap'],high_tests=z['highTests'],
                    low_tests=z['lowTests'],crossings=z['crossings'])
    return dict(version=VERSION,range=timed(r),ended=timed(ended),event=observation['event'],
                metrics=observation['metrics'],source='research/brooks_chart_import/range-detector.original.js')
