"""Contextual pullback fit with prerequisite gates and independent evidence groups."""
VERSION='ipda_retracement_fit_v2'
SOURCE='research/price_courses/retracement_score_v2.json'
WEIGHTS=[('prior_expansion','前置扩张与突破',15,'前提'),('structure_intact','事前保护位保持',20,'结构'),
 ('weak_body','回撤实体弱于扩张',5,'受控回撤'),('slow_speed','回撤净速度慢于扩张',5,'受控回撤'),('overlap','回撤K线重叠',5,'受控回撤'),
 ('pd_contact','接触事前已知PD区域',10,'PD反应'),('pd_respected','接触后PD远端保持',5,'PD反应'),
 ('sfp','扫荡已确认局部极值并收回',5,'结束证据'),('cisd','顺主方向CISD',5,'结束证据'),('ordered_end','PD＋SFP后顺向CISD组合',5,'结束证据'),
 ('h1_alignment','事前H1背景一致',10,'背景验证'),('volume','真实成交量验证',5,'补充验证'),('micro_confirmation','M1/M5确认',5,'补充验证')]
POLICY=dict(version=VERSION,maximum=100,meaning='回调规则符合度，非胜率或入场授权；权重为待校准工程假设',
            gates='必须先有扩张及已形成回调；结构破坏、数据缺口、背景改变、进入盘整阻断有效资格；分数不能解除阻断',
            groups={'前提':15,'结构':20,'受控回撤':15,'PD反应':15,'结束证据':15,'背景验证':10,'补充验证':10})


def score_retracement(row,evidence):
    episode=row.get('episode') or row.get('ended');checks=dict(row['checks'])
    state=row['state'];reason=row.get('end_reason')
    interrupted=reason in ('data_gap','parent_changed','consolidation') or state=='consolidation'
    broken=checks.get('structure_intact') is False or state=='structure_challenge'
    has_pullback=bool(episode and episode.get('expansion') and checks.get('prior_expansion'))
    gate='structure_invalid' if broken else 'interrupted' if interrupted else 'no_retracement' if not has_pullback else None
    # Fresh structure/context alone cannot score a pullback that has not formed.
    contacts=(episode or {}).get('pd_contacts',[])
    d=evidence.get('reference_direction');close=evidence.get('current_close')
    contact=bool(contacts) if has_pullback else False
    # Respect must be checked at this close, not inherited from an earlier touch.
    # The episode builder supplies this check from its current causal observation.
    respected=(any(close>=z['low'] if d==1 else close<=z['high'] for z in contacts) if close is not None and d in (-1,1) else checks.get('pd_respected')) if contact else None
    ordered=bool(evidence.get('patterns',{}).get('sfp_cisd') and checks.get('sfp') is True and checks.get('cisd') is True and respected is True and contact)
    values={**checks,'prior_expansion':has_pullback,'pd_contact':contact,'pd_respected':respected,'ordered_end':ordered,
            'volume':None,'micro_confirmation':None}
    parts=[]
    for key,name,weight,group in WEIGHTS:
        value=values.get(key);factor=1. if value is True else 0.
        observed=value
        if key=='structure_intact' and factor and evidence.get('protection_source')=='native_frozen_origin_proxy':
            factor=.6;observed='窗口极值代理，仅计60%结构分'
        if key=='pd_contact' and factor and not any(z.get('kind')=='FVG' for z in contacts):
            factor=.5;observed='仅OB候选接触，区域证据计50%'
        points=round(weight*factor,2)
        if gate:points=0
        status='unknown' if value is None else 'blocked' if gate and value is True else 'met' if points==weight else 'partial' if points else 'unmet'
        parts.append(dict(key=key,name=name,weight=weight,points=points,group=group,status=status,observed=observed,source_rule=SOURCE))
    eligibility='contradicted' if broken else 'interrupted' if interrupted else 'reference_missing' if not has_pullback else 'reference_missing' if checks.get('structure_intact') is None else 'end_evidence_observed' if ordered else 'candidate'
    stage='结构失效' if broken else '回调中断' if interrupted else '尚未形成回调' if not has_pullback else '保护位待验证' if checks.get('structure_intact') is None else '结束证据已观察' if ordered else '恢复推进但结束组合缺失' if state=='resumed_without_full_sequence' else '回调观察中'
    unknown=sum(p['weight'] for p in parts if p['status']=='unknown')
    return dict(version=VERSION,score=round(sum(p['points'] for p in parts),2),maximum=100,earned_points=round(sum(p['points'] for p in parts),2),
                known_weight=100-unknown,unknown_weight=unknown,components=parts,eligibility=eligibility,stage=stage,
                blockers=([gate] if gate else [])+(['protection_unverified'] if has_pullback and checks.get('structure_intact') is None else []),
                end_sequence_observed=bool(ordered and not gate and checks.get('structure_intact') is True),
                missing=[p['name'] for p in parts if p['status'] not in ('met',)],probability=None,entry_qualified=False)
