"""Compare M15 delivery with the H1 envelope already known at its open.

The H1 update at the same close is reported separately, never used as prior
bias. This joins price observations; it does not establish a DOL or an entry.
"""
from bisect import bisect_right
from .core import instant

VERSION = 'h1_m15_delivery_context_v1'


def build_delivery_context(payload, asof=None):
    cutoff = instant(asof or payload['window_end'])
    snapshots = [r for r in payload.get('background_channels', {}).get('rows', [])
                 if instant(r['known_at']) <= cutoff]
    times = [instant(r['known_at']) for r in snapshots]
    if any(a >= b for a, b in zip(times, times[1:])):
        raise ValueError('H1 snapshots must be unique and ordered')
    for r, known in zip(snapshots, times):
        for key in ('active', 'ended'):
            p = r.get(key)
            if not p:
                continue
            for name in ('first_known_at', 'protected_known_at', 'validated_at', 'end_at', 'invalidated_at'):
                if p.get(name) and instant(p[name]) > known:
                    raise ValueError('Future H1 evidence in an earlier snapshot')
            for item in p.get('breaks', []) + p.get('displacement_evidence', []):
                if instant(item['known_at']) > known:
                    raise ValueError('Future H1 supporting evidence')
            reversal = p.get('reversal') or {}
            if reversal.get('confirmed_at') and instant(reversal['confirmed_at']) > known:
                raise ValueError('Future H1 reversal confirmation')

    phases = {p['bar_open_at']: p for p in payload['phases'] if instant(p['known_at']) <= cutoff}
    rows, previous_open = [], None
    for b in payload['bars']:
        opened, closed = instant(b['time']), instant(b['closed_at'])
        if closed > cutoff:
            continue
        if closed <= opened or (previous_open is not None and opened <= previous_open):
            raise ValueError('Ordered closed bars required')
        previous_open = opened
        phase = phases.get(b['time'])
        if not phase:
            continue
        if instant(phase['known_at']) != closed:
            raise ValueError('Phase must belong to this observation close')
        index = bisect_right(times, opened) - 1
        snapshot = snapshots[index] if index >= 0 else None
        age = (opened - times[index]).total_seconds() if index >= 0 else None
        # An hour without its expected closed snapshot is explicitly stale.
        status = ('missing' if snapshot is None else 'stale' if age >= 3600
                  else 'available' if snapshot.get('active') else 'no_active_channel')
        parent = snapshot.get('active') if status == 'available' else None
        background = None
        crossed, location = None, 'missing'
        movement = phase['direction']
        relation = 'background_' + status
        if parent:
            direction = parent['direction']
            if direction not in (-1, 1):
                raise ValueError('Directional H1 background required')
            background = {k: parent[k] for k in ('id', 'direction', 'first_known_at',
                'validated_at', 'protected_price', 'protected_known_at', 'low', 'high')}
            background['snapshot_at'] = snapshot['known_at']
            crossed = (b['close'] - parent['protected_price']) * direction < 0
            location = ('below' if b['close'] < parent['low'] else
                        'above' if b['close'] > parent['high'] else 'inside')
            if crossed:
                relation = 'protection_challenge'
            elif not parent['validated_at']:
                relation = 'background_candidate'
            elif movement == direction:
                relation = 'aligned_local_delivery'
            elif movement == -direction:
                relation = ('countertrend_inside_background' if location == 'inside'
                            else 'countertrend_unresolved')
            else:
                relation = 'local_direction_unresolved'
        # A confirmed range remains an independent phase, including when its
        # close also challenges protection (retained in protection_crossed).
        if phase['phase'] == 'consolidation':
            relation = 'independent_consolidation'

        update = None
        close_index = bisect_right(times, closed) - 1
        if close_index > index:
            r = snapshots[close_index]
            p, ended = r.get('active'), r.get('ended')
            reversal = (p or {}).get('reversal') or {}
            update = {'known_at': r['known_at'], 'active_channel_id': p['id'] if p else None,
                'direction': p['direction'] if p else None,
                'invalidated_channel_id': ended['id'] if ended and ended.get('invalidated_at') == r['known_at'] else None,
                'validated_now': bool(p and p.get('validated_at') == r['known_at']),
                'reversal_confirmed_now': reversal.get('confirmed_at') == r['known_at']}
        rows.append({'bar_open_at': b['time'], 'known_at': phase['known_at'], 'phase_id': phase['id'],
            'phase': phase['phase'], 'movement_direction': movement, 'relation': relation,
            'background_status': status, 'age_at_open_seconds': age, 'h1_before': background,
            'range_location': location, 'protection_crossed': crossed, 'h1_close_update': update})
    return {'definition': VERSION, 'rows': rows, 'entry_qualified': False,
        'htf_program_validated': False, 'source_rules': [
            'research/price_courses/ipda_phase_rules.json#expansion',
            'research/price_courses/ipda_phase_rules.json#retracement',
            'research/ipda_chart_refinement_rules.json'],
        'policy': 'M15开盘前已知H1背景用于比较，当前收盘的新H1证据单列。逆向且仍在已验证H1范围内为回调候选；M15穿越保护位只作挑战，H1失效与反转按H1自身规则确认。盘整独立保留，缺失或满一小时未更新的背景不补齐；不改变原生阶段或评分。'}
