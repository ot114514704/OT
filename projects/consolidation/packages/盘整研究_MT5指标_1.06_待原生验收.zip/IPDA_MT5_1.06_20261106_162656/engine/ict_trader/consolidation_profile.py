"""Morphology hypotheses; these labels never confirm accumulation or trade direction."""
from statistics import median
from .shape_geometry import confirmed_geometry

PARAMETERS=dict(flat_span_atr=.35,tilted_span_atr=.5,contraction_ratio=.7,geometry_contraction_max=.95,convergence_span_atr=.35,
                compression_atr_ratio=.6,compression_body_atr=.25,
                relay_net_atr=2.,relay_efficiency=.6)


def profile(bars,start,end,atr):
    w=bars[start:end+1];n=len(w)
    def span(values):
        mid=(len(values)-1)/2;den=sum((i-mid)**2 for i in range(len(values)))
        return sum((i-mid)*v for i,v in enumerate(values))/den*(len(values)-1) if den else 0.
    up=span([b.high for b in w])/atr;down=span([b.low for b in w])/atr
    half=n//2;a=w[:half];z=w[half:]
    first=max(b.high for b in a)-min(b.low for b in a)
    last=max(b.high for b in z)-min(b.low for b in z)
    body=sum(abs(b.close-b.open) for b in w)/n/atr
    prior=bars[max(0,start-12):start]
    contiguous=all(x.closed_at==y.time for x,y in zip(prior+w[:1],(prior+w[:1])[1:]))
    prior_atr=median(b.high-b.low for b in prior) if len(prior)>=6 and contiguous else None
    contraction=last/first if first else 1.
    geometry=confirmed_geometry(w,atr=atr)
    checks={
        'rectangle':abs(up)<=PARAMETERS['flat_span_atr'] and abs(down)<=PARAMETERS['flat_span_atr'],
        'compressed':atr/prior_atr<=PARAMETERS['compression_atr_ratio'] and body<=PARAMETERS['compression_body_atr'] if prior_atr else None,
        'tilted':up*down>0 and min(abs(up),abs(down))>=PARAMETERS['tilted_span_atr'] and body<=.65,
        'converging':down-up>=PARAMETERS['convergence_span_atr'] and geometry.get('contraction_ratio',1)<=PARAMETERS['geometry_contraction_max']
                     and geometry.get('validated',False) and geometry.get('subtype')!='channel',
        'relay':None,
    }
    direction=0
    if len(prior)>=6 and prior_atr:
        p=prior[-6:];net=p[-1].close-p[0].open
        travel=abs(p[0].close-p[0].open)+sum(abs(y.close-x.close) for x,y in zip(p,p[1:]))
        checks['relay']=abs(net)>=PARAMETERS['relay_net_atr']*prior_atr and bool(travel) and abs(net)/travel>=PARAMETERS['relay_efficiency']
        if checks['relay']:direction=1 if net>0 else -1
    return dict(tags=[k for k,v in checks.items() if v is True],checks=checks,
                metrics=dict(upper_span_atr=up,lower_span_atr=down,contraction_ratio=contraction,
                             mean_body_atr=body,prior_atr=prior_atr,current_atr=atr),
                geometry=geometry,relay_direction=direction,known_at=bars[end].closed_at.isoformat(),
                missing=['机构建仓及诱导意图未验证','历史时区及亚盘归属未验证','突破方向与中继延续尚待后续证据'],
                policy='五类可重叠；形态标签不是盘整资格，不预测方向；倾斜结构未满足实体平衡时仅列候选。')
