"""Compare overlapping CLOSED source samples; normal rolling/new bars are not revisions."""
from .core import instant

FIELDS=('open','high','low','close','spread')


def source_revisions(previous,current):
    def indexed(rows):
        return {instant(r.get('time') or r['closed_at']).isoformat():r for r in rows if r.get('time') or r.get('closed_at')}
    periods={}
    for period,rows in current.items():
        a=indexed(previous.get(period,[]));b=indexed(rows)
        if not a or not b:continue
        lo=max(min(a),min(b));hi=min(max(a),max(b))
        changed=[]
        for t in sorted(set(a)|set(b)):
            if not lo<=t<=hi:continue
            if t not in a:changed.append(dict(time=t,kind='historical_insert',fields=[]))
            elif t not in b:changed.append(dict(time=t,kind='historical_missing',fields=[]))
            else:
                fields=[k for k in FIELDS if a[t].get(k)!=b[t].get(k)]
                if fields:changed.append(dict(time=t,kind='historical_correction',fields=fields))
        if changed:periods[period]=dict(count=len(changed),first_affected_at=changed[0]['time'],last_affected_at=changed[-1]['time'],examples=changed[:8])
    return dict(count=sum(p['count'] for p in periods.values()),periods=periods) if periods else None
