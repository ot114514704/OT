"""Explain closed-sample availability without changing recognition or scoring."""
from .core import instant
from .ipda_ranges import PARAMETERS


def local_sample_readiness(chart):
    rows=chart.get('phase_rows') or []
    if not rows:return None
    known=instant(rows[-1]['known_at'])
    bars=[b for b in chart.get('bars') or []
          if not b.get('forming') and instant(b['closed_at'])<=known]
    if not bars or instant(bars[-1]['closed_at'])!=known:return None
    start=len(bars)-1
    while start and instant(bars[start-1]['closed_at'])==instant(bars[start]['time']):
        start-=1
    continuous=len(bars)-start
    gap=(dict(previous_closed_at=bars[start-1]['closed_at'],next_open_at=bars[start]['time'])
         if start else None)
    reset_at=instant(bars[start]['time'])
    reset_reason='data_gap' if gap else 'loaded_start'
    exits=[instant(r['known_at']) for r in rows
           if r.get('consolidation_evidence',{}).get('event')=='breakout_confirmed'
           and reset_at<=instant(r['known_at'])<=known]
    if exits:
        reset_at=max(exits);reset_reason='breakout_confirmed'
    available=sum(instant(b['closed_at'])>reset_at for b in bars[start:])
    minimum=min(PARAMETERS['windows'])
    active=bool(rows[-1].get('consolidation_evidence',{}).get('range'))
    needed=0 if active else max(0,minimum-available)
    status='active' if active else 'collecting' if needed else 'ready'
    if status=='collecting':
        prefix={'data_gap':'数据间隔后','breakout_confirmed':'原盘整退出后','loaded_start':'当前已加载窗口内'}[reset_reason]
        message=f'{prefix}已积累 {available}/{minimum} 根已收盘K线，还需 {needed} 根才能评估局部实体平衡窗口'
    elif active:
        message='已有冻结实体平衡区；当前延续或退出由后续已收盘K线判断'
    else:
        message=f'局部至少 {minimum} 根的已收盘窗口已具备；仍需满足双向震荡及其他形成条件'
    return dict(status=status,known_at=rows[-1]['known_at'],continuous_closed_bars=continuous,
                minimum_closed_bars=minimum,window_bars=min(minimum,available),bars_needed=needed,
                reset_reason=reset_reason,reset_at=reset_at.isoformat(),last_gap=gap,message=message,
                scope='仅解释局部实体平衡样本；不替代外层、摆动或斜线候选判定',
                confirmed_bar_only=True,score_included=False)
