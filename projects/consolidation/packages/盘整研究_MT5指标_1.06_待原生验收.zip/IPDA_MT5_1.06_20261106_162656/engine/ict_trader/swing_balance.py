"""Reference-driven bidirectional swing candidates, separate from confirmed balance."""
from statistics import median
from .core import visible
from .oscillation import strong_oscillation

VERSION='ipda_swing_balance_candidate_v3'
CHECK_NAMES=dict(repeated_turns='显著交替拐点数量',two_sided='上下侧均有重复拐点',
                 strong_oscillation='强双向震荡筛选',
                 low_efficiency='方向效率受控',contained_net_motion='净推进占区间比例受控',
                 bounded_width='区间宽度受控',last_close_inside='末次收盘在候选范围内',
                 no_current_impulse='近期没有强单向扩张',
                 repeated_boundary_tests='上下边缘均有重复触及')
PARAMETERS=dict(windows=[12,24,48,72],minimum_pivots=5,minimum_side_pivots=2,
                minimum_leg_atr=.75,efficiency_max=.35,net_to_span_max=.65,
                width_atr_max=10.,edge_tolerance_atr=.15,recent_impulse_atr=1.5,recent_efficiency_min=.75)


def _candidate(w):
    if any(a.closed_at!=b.time or a.seconds!=b.seconds for a,b in zip(w,w[1:])):return None
    atr=median(max(b.high-b.low,abs(b.high-w[i-1].close),abs(b.low-w[i-1].close)) if i else b.high-b.low for i,b in enumerate(w))
    if atr<=0:return None
    pivots=[]
    for i in range(1,len(w)-1):
        a,b,c=w[i-1:i+2]
        high=b.high>a.high and b.high>=c.high;low=b.low<a.low and b.low<=c.low
        if high==low:continue # outside bars cannot establish intrabar ordering
        point=dict(side='upper' if high else 'lower',price=b.high if high else b.low,time=b.time.isoformat(),known_at=c.closed_at.isoformat())
        if not pivots:pivots.append(point);continue
        last=pivots[-1]
        if point['side']==last['side']:
            if (point['price']-last['price'])*(1 if high else -1)>0:pivots[-1]=point
        elif (point['price']-last['price'])*(1 if high else -1)>=PARAMETERS['minimum_leg_atr']*atr:pivots.append(point)
    upper=[p for p in pivots if p['side']=='upper'];lower=[p for p in pivots if p['side']=='lower']
    if not upper or not lower:return None
    hi=max(p['price'] for p in upper);lo=min(p['price'] for p in lower);span=hi-lo
    if span<=0:return None
    edge_tolerance=PARAMETERS['edge_tolerance_atr']*atr
    # A single remote spike must not turn an impulse/retracement into a
    # swing-balance candidate.  Both outer edges need two independently
    # observed pivot tests; this is deliberately symmetric and causal.
    upper_edge_touches=sum(abs(p['price']-hi)<=edge_tolerance for p in upper)
    lower_edge_touches=sum(abs(p['price']-lo)<=edge_tolerance for p in lower)
    travel=sum(abs(b.close-a.close) for a,b in zip(w,w[1:]));net=abs(w[-1].close-w[0].close)
    efficiency=net/travel if travel else 0
    recent=w[-6:];recent_net=abs(recent[-1].close-recent[0].close);recent_travel=sum(abs(b.close-a.close) for a,b in zip(recent,recent[1:]))
    impulse=recent_net>=PARAMETERS['recent_impulse_atr']*atr and recent_travel>0 and recent_net/recent_travel>=PARAMETERS['recent_efficiency_min']
    oscillation=strong_oscillation(w,atr,span)
    checks=dict(repeated_turns=len(pivots)>=PARAMETERS['minimum_pivots'],two_sided=min(len(upper),len(lower))>=PARAMETERS['minimum_side_pivots'],strong_oscillation=oscillation['qualified'],
        low_efficiency=efficiency<=PARAMETERS['efficiency_max'],contained_net_motion=net/span<=PARAMETERS['net_to_span_max'],
        bounded_width=span/atr<=PARAMETERS['width_atr_max'],last_close_inside=lo-PARAMETERS['edge_tolerance_atr']*atr<=w[-1].close<=hi+PARAMETERS['edge_tolerance_atr']*atr,
        no_current_impulse=not impulse,
        repeated_boundary_tests=upper_edge_touches>=PARAMETERS['minimum_side_pivots'] and lower_edge_touches>=PARAMETERS['minimum_side_pivots'])
    return dict(version=VERSION,qualified=all(checks.values()),checks=checks,low=lo,high=hi,pivots=pivots,
        observed_from=w[0].time.isoformat(),known_at=w[-1].closed_at.isoformat(),confirmed=False,score_included=False,
        metrics=dict(window=len(w),atr=atr,pivot_count=len(pivots),upper_pivots=len(upper),lower_pivots=len(lower),oscillation=oscillation,
                     upper_edge_touches=upper_edge_touches,lower_edge_touches=lower_edge_touches,
                     edge_tolerance=edge_tolerance,efficiency=efficiency,net_to_span=net/span,width_atr=span/atr),
        missing=['实体平衡确认尚未完成','人工框的时间与价格边界尚未精确对齐','机构意图、新闻及会话背景未验证'],
        policy='从用户红框参考提取的摆动价格代理；上下外边缘各需至少两次已观察触及，避免把单次冲高/下杀包成盘整；不要求小实体，不替代已确认盘整，不增加评分，不预测突破方向。')


def observe_swing_candidates(bars,asof):
    bars=visible(bars,asof);rows=[];previous=None
    for i,b in enumerate(bars):
        candidates=[_candidate(bars[i-n+1:i+1]) for n in reversed(PARAMETERS['windows']) if i+1>=n]
        candidate=next((c for c in candidates if c and c['qualified']),None)
        assessed=[c for c in candidates if c]
        best=max(assessed,key=lambda c:sum(c['checks'].values()),default=None)
        missing=[CHECK_NAMES[k] for k,v in best['checks'].items() if not v] if best else ['连续样本或可确认的双边拐点不足']
        if candidate:
            event='swing_candidate_entered' if previous is None else None
            reason='已收盘样本仍满足显著双向折返条件；候选边界随观察窗口更新，尚非冻结实体平衡边界'
        else:
            event='swing_candidate_ended' if previous is not None else None
            reason='所有观察窗口均未满足摆动候选条件；'
            if i and bars[i-1].closed_at!=b.time:reason+='数据间隔中止连续观察'
            elif best:reason+=f"最接近的{best['metrics']['window']}根窗口尚缺："+'、'.join(missing)
            else:reason+='连续样本或可确认的双边拐点不足'
            if event:reason+='；候选消失不等于已确认突破，也不推断新趋势'
        rows.append(dict(known_at=b.closed_at.isoformat(),candidate=candidate,event=event,
                         reason=reason,checks_missing=[] if candidate else missing,
                         confirmed_bar_only=True))
        previous=candidate
    return rows


def swing_history(rows,limit=24):
    """Only entry/exit changes, reconstructed at their closed-bar observation time."""
    titles=dict(swing_candidate_entered='出现摆动盘整候选',swing_candidate_ended='摆动候选条件不再满足')
    return [dict(known_at=r['known_at'],event=r['event'],title=titles[r['event']],detail=r['reason'],
                 checks_missing=r['checks_missing'],confirmed_bar_only=True,confirmed=False,score_included=False)
            for r in rows if r.get('event') in titles][-max(1,limit):]
