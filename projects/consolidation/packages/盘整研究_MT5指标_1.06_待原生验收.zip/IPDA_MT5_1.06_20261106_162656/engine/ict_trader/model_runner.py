"""One immutable model snapshot in flight; the market reader never waits on it."""
from copy import deepcopy
from dataclasses import dataclass


@dataclass
class ModelJob:
    key: str
    raw: dict
    origin: str
    started_at: float
    future: object = None


class LatestModelRunner:
    def __init__(self,executor,calculate,clock):
        self.executor=executor;self.calculate=calculate;self.clock=clock;self.job=None

    def start(self,raw,key,origin):
        if self.job is not None:raise RuntimeError('Only one model calculation may run at a time')
        job=ModelJob(key,deepcopy(raw),origin,self.clock())
        job.future=self.executor.submit(self.calculate,job.raw)
        self.job=job

    def take_ready(self):
        job=self.job
        if job is None or not job.future.done():return None
        self.job=None
        try:return job,job.future.result(),None
        except Exception as exc:return job,None,exc

    def metadata(self):
        job=self.job
        return dict(analysis_running=job is not None,
                    analysis_started_at=job.started_at if job else None,
                    analysis_target_closed_end={p:r[-1]['closed_at'] for p,r in job.raw.items() if r and 'closed_at' in r[-1]} if job else None)
