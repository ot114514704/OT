"""Read-only reference correspondence, kept outside live confirmation/score."""
import hashlib
import json
from pathlib import Path
from .core import instant

REPORT=Path(__file__).resolve().parents[1]/'research/user_range_references/native_alignment_review.json'


def segment_digest(bars):
    records=[dict(time=instant(b['time']).isoformat(),**{k:float(b[k]) for k in ('open','high','low','close')}) for b in bars]
    return hashlib.sha256(json.dumps(records,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def attach_reference_reviews(charts):
    chart=charts.get('M15')
    if chart is None:return charts
    chart['reference_reviews']=[]
    if not REPORT.exists():return charts
    report=json.loads(REPORT.read_text('utf-8'))
    for source in report['references']:
        r={**source,'role':'reference_sequence_review','native_sequence_currently_verified':False}
        if r['status']=='sequence_correspondence':
            bars=[b for b in chart.get('bars',[]) if instant(r['first_bar_open_at'])<=instant(b['time'])<=instant(r['last_bar_open_at'])]
            if len(bars)!=r['sequence_bar_count']:
                r.update(status='history_unavailable',reason='对应历史序列不在本次原生样本中；不沿用旧匹配资格')
            elif segment_digest(bars)!=r['native_segment_sha256']:
                r.update(status='source_changed',reason='对应原生OHLC已变化，需要重新核对截图序列；不沿用旧匹配资格')
            else:r['native_sequence_currently_verified']=True
        chart['reference_reviews'].append(r)
    return charts
