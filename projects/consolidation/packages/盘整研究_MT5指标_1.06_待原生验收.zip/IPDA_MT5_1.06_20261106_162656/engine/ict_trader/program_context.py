"""Source requirements for HTF program confirmation, separate from H1 geometry."""
import json
from hashlib import sha256
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def _last_known_channel(payload):
    """Return the latest already-known H1 envelope without using forming data."""
    rows=(payload.get('background_channels') or {}).get('rows') or []
    for row in reversed(rows):
        active=row.get('active')
        if active and active.get('direction') in (-1, 1):
            return {
                'direction': active.get('direction'),
                'id': active.get('id'),
                'known_at': row.get('known_at'),
                'protected_price': active.get('protected_price'),
                'protected_known_at': active.get('protected_known_at'),
                'status': active.get('status'),
            }
    return None


def _last_week_observation(payload):
    weeks=(payload.get('history_analysis') or {}).get('weeks') or []
    if not weeks:
        return None
    w=weeks[-1]
    change=w.get('change')
    direction=1 if isinstance(change,(int,float)) and change>0 else -1 if isinstance(change,(int,float)) and change<0 else 0
    return {
        'label': w.get('label'), 'start': w.get('start'), 'end': w.get('end'),
        'open': w.get('open'), 'close': w.get('close'), 'change': change,
        'observed_direction': direction,
        'known_at': w.get('end'),
    }


def attach_direction_guard(payload):
    """Attach a read-only weekly/daily direction and protection guard.

    H1 structure is an observed background envelope.  Daily/weekly profile
    direction still requires frozen session boundaries and an independent
    historical clock/DST proof, so this function never feeds phase scores.
    """
    channel=_last_known_channel(payload)
    week=_last_week_observation(payload)
    payload['program_direction_guard']={
        'definition':'ipda_program_direction_guard_v1',
        'status':'blocked_historical_clock',
        'h1_structure': channel or {'direction':None,'status':'unavailable'},
        'weekly_observed': week or {'observed_direction':None,'status':'unavailable'},
        'daily_profile': {'direction':None,'status':'unknown','reason':'历史日线会话边界与时钟/DST未核验'},
        'protection_use': 'H1保护位只作为结构参考；未核验日线/每周概况不得确认扩张方向。',
        'expansion_direction': None,
        'missing': [
            'historical_clock_and_DST_proof',
            'frozen_daily_boundaries',
            'independent_prior_bias_and_DOL',
        ],
        'directional_use':'not_used_for_phase_score_or_entry',
        'policy':'每周/每日概况用于确认H1结构方向和保护位的一致性；在时钟/DST证据未完成前只显示观察值，不把亚欧美盘或银弹假设变成方向。'
    }
    return payload


def attach_program_context(payload):
    paths=['research/knowledge.json','research/ipda_nested_sources/weekly_inherited_rules.json',
           'research/price_courses/daily_structure_visual_review.json']
    sources=[];rules={}
    for file in paths:
        raw=(ROOT/file).read_bytes();data=json.loads(raw)
        sources.append(dict(path=file,sha256=sha256(raw).hexdigest()))
        if data.get('profiles'):
            rules['weekly' if 'weekly' in file else 'daily']=[dict(id=p['id'],required_facts=p['required_facts']) for p in data['profiles']]
    payload['program_context_validation']=dict(definition='source_bound_program_requirements_v1',sources=sources,rules=rules,
        h1_protection='回调评分优先采用本棒开盘前已验证H1通道保护位；CISD反向是挑战证据，不能自动取消保护位。',
        daily_direction=None,weekly_direction=None,program_validated=False,
        missing=[
            dict(code='historical_clock',detail='原始终端标签到UTC/纽约的历史偏移与DST覆盖未核验；不据此确认亚欧美盘顺序。'),
            dict(code='daily_boundaries',detail='未冻结D1会话边界及日线缺口口径，不能用H1通道替代日线摆点。'),
            dict(code='prior_bias_and_dol',detail='经典每日/每周概况要求事前方向与DOL记录；缺少独立带时间戳记录。'),
            dict(code='daily_swing_sequence',detail='日线程序待验证：先收盘破既有摆点，再形成不破起点的回撤摆点；以右侧棒完成时间冻结保护位。'),
            dict(code='profile_completion',detail='仅已发生的会话/交易日证据可参与；不能把后续纽约/周四周五的结果回填到此前评分。')],
        policy='资料提供待验证条件，不能凭星期或某盘固定判多空。概况作程序方向的一致性核对，不能循环产生其本来要求的事前偏见。')
    return payload
