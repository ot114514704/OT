"""Causal IPDA phase candidates, explicitly separate from the lecturer's HTF program.

Thresholds below are frozen engineering hypotheses, not numbers from the video.
Every row is a decision at a candle close; earlier rows are never relabelled.
"""
from statistics import mean

from .core import instant, visible
from .structure import hierarchy
from .brooks_ranges import observe_ranges as observe_brooks, phase_evidence as brooks_evidence
from .ipda_ranges import observe_ranges, phase_evidence, PARAMETERS as RANGE_PARAMETERS

VERSION='ipda_m15_body_balance_v4'
PARAMETERS={'atr_bars':14,'expansion_lookback':6,'impulse_bars':3,
            'impulse_atr':1.0,'impulse_efficiency':0.6,
            'consolidation':RANGE_PARAMETERS,'pullback_atr':0.7,
            'origin_lookback':24,'reversal_body_atr':0.65}
SOURCES={'expansion':[766,816],'retracement':[226,273],
         'reversal':[816,851],'consolidation':[712,740],'undetermined':[920,955]}


def detect_phases(bars,asof,*,timeframe_seconds=900,background_gap_seconds=0):
    bars=visible(bars,asof)
    if not bars:return []
    if timeframe_seconds not in (900,3600) or any(b.seconds!=timeframe_seconds for b in bars):
        raise ValueError('Homogeneous M15 or explicitly requested H1 required')
    if background_gap_seconds not in (0,3600) or (background_gap_seconds and timeframe_seconds!=3600):
        raise ValueError('Only H1 background may explicitly carry over one missing hour')
    definition=VERSION if timeframe_seconds==900 else 'ipda_h1_body_balance_v3'
    range_rows=observe_ranges(bars,asof)['rows']
    brooks_rows=observe_brooks(bars,asof)['rows']
    events=hierarchy(bars,asof)
    by_known=sorted((e for e in events if e['tier']=='IT'),key=lambda e:e['known_at'])
    event_cursor=0;known_it={'high':None,'low':None};run=[];trs=[];fvgs=[]
    anchor=None;box=None;stable=0;previous_phase='undetermined';rows=[]
    for index,b in enumerate(bars):
        brooks=brooks_evidence(brooks_rows[index],bars)
        balance=phase_evidence(range_rows[index],bars,brooks_rows[index])
        box=balance['range']
        if run and (b.time-run[-1].closed_at).total_seconds()>background_gap_seconds:
            run=[];trs=[];fvgs=[];anchor=None;stable=0;known_it={'high':None,'low':None};previous_phase='undetermined'
        # Only structures known before this bar opens can be its reference.
        while event_cursor<len(by_known) and instant(by_known[event_cursor]['known_at'])<=b.time:
            e=by_known[event_cursor]
            if run and e['run_start']==run[0].time.isoformat():known_it[e['side']]=e
            event_cursor+=1
        atr=mean(trs[-14:]) if len(trs)>=14 else None
        prior=run[-6:];window=(run+[b])[-8:]
        net3=b.close-(run[-2].open if len(run)>=2 else b.open)
        # Efficiency uses consecutive closes, including the first open.
        three=(run+[b])[-3:]
        path3=abs(three[0].close-three[0].open)+sum(abs(y.close-x.close) for x,y in zip(three,three[1:]))
        er3=abs(net3)/path3 if path3 else 0.0
        overlap=mean(max(0,min(x.high,y.high)-max(x.low,y.low))/max(min(x.high-x.low,y.high-y.low),1e-9)
                     for x,y in zip(window,window[1:])) if len(window)>1 else 0.0
        path8=abs(window[0].close-window[0].open)+sum(abs(y.close-x.close) for x,y in zip(window,window[1:]))
        er8=abs(b.close-window[0].open)/path8 if path8 else 0.0
        width=max(x.high for x in window)-min(x.low for x in window)
        impulse=0
        if atr and len(prior)==6 and abs(net3)>=atr and er3>=.6:
            if net3>0 and b.close>max(x.high for x in prior):impulse=1
            elif net3<0 and b.close<min(x.low for x in prior):impulse=-1
        stable=1 if box else 0
        pda=[]
        if anchor:
            for f in fvgs:
                if (not f['invalidated'] and f['direction']==anchor['direction'] and
                    f['formed_at']>=anchor['origin_at'] and f['known_at']<=b.time.isoformat() and
                    f['low']>=anchor['low'] and f['high']<=anchor['high'] and
                    b.low<=f['high'] and b.high>=f['low']):
                    pda.append({k:v for k,v in f.items() if k!='invalidated'})
        prior_anchor=dict(anchor) if anchor else None
        phase='undetermined';direction=0;behavior='未达到位移阈值'
        reason='证据不足，等待位移、结构或持续重叠；不强制套入四种阶段。'
        if box:
            phase='consolidation';direction=0
            reason=f"IPDA 实体平衡区：{box['window']}棒内双边至少各2次独立测试、中线至少2次穿越；低方向效率、K线重叠且实体集中，无明显单向漂移，首次确认后冻结边界。"
            reason+=' 当前'+box['status']+'；2根越界收盘且继续推进，或3根持续外收才确认离开；影线扫荡收回仍属盘整。'
            reason+=' Brooks独立几何验证'+('同意。' if box['brooks_confirmed'] else '尚未同意。')
            behavior=box['status']
        elif atr:
            broke_origin=bool(anchor and ((anchor['direction']==1 and b.close<anchor['low']) or
                                         (anchor['direction']==-1 and b.close>anchor['high'])))
            if anchor and broke_origin and (impulse==-anchor['direction'] or
                    (b.close-b.open)*anchor['direction']<=-.65*atr):
                phase='reversal';direction=-anchor['direction']
                reason='反向位移且收盘穿过此前冻结的局部参考起点；局部方向切换候选，HTF 反转尚待验证。'
            elif impulse:
                direction=impulse
                if anchor and impulse==-anchor['direction'] and not broke_origin:
                    phase='retracement'
                    reason='局部反向扩张仍在已有参考范围内，暂列回调候选；若起点失守需重新评估反转。'
                else:
                    phase='expansion'
                    reason='3 棒净位移达到前 14 棒均幅，方向效率达标，且收盘越过此前 6 棒极值。'
            elif anchor and not broke_origin:
                retrace=(anchor['high']-b.close) if anchor['direction']==1 else (b.close-anchor['low'])
                opposite=len(run)>=2 and (b.close-run[-2].close)*anchor['direction']<0
                if retrace>=.7*atr and (opposite or previous_phase=='retracement'):
                    phase='retracement';direction=-anchor['direction']
                    reason='从参考扩张端回撤至少 0.7 倍均幅，仍在原范围内；等待范围内 PDA 反应。'
                elif previous_phase in ('expansion','reversal','retracement') and (
                    (anchor['direction']==1 and b.close>anchor['high']) or
                    (anchor['direction']==-1 and b.close<anchor['low'])):
                    phase='expansion';direction=anchor['direction']
                    reason='收盘延伸了此前方向的局部范围，观察到顺向交付继续。'
                elif previous_phase in ('expansion','reversal') and retrace<.7*atr:
                    phase='expansion';direction=anchor['direction']
                    behavior='位移后的延续观察，本棒未必产生新位移'
                    reason='此前扩张尚未出现达到回撤阈值的逆向运动、重叠盘整或起点失效，暂保留扩张延续候选。'
            if impulse:behavior=('向上' if impulse==1 else '向下')+'扩张观察'
        if phase=='retracement' and pda:
            respected=any(b.close>=f['low'] if anchor['direction']==1 else b.close<=f['high'] for f in pda)
            reason+=' 已接触事前形成的同向 FVG，'+('收盘未穿越其远端。' if respected else '收盘穿越其远端，反应待证。')
        missing=['HTF关键位置与程序方向未验证','DOL未冻结','时区、时段与新闻背景未验证']
        if phase=='retracement' and not pda:missing.append('尚未观察到范围内已知FVG接触；其他PDA未检测')
        if phase=='reversal':missing.append('局部参考失效不等于高周期反转')
        alternatives=[]
        if phase=='retracement':alternatives=['HTF方向可能不同；同一局部运动也可能属于反转或另一层扩张']
        if phase=='expansion':alternatives=['当前方向扩张也可能是更高周期的回调']
        if phase=='consolidation':alternatives=['等待突破方向；不预测向上或向下']
        # Start a new local reference only after an observed expansion/reversal.
        if phase in ('expansion','reversal') and (anchor is None or direction!=anchor['direction']):
            side='low' if direction==1 else 'high';ref=known_it[side]
            recent=run[-24:]+[b]
            if ref and instant(ref['pivot_at'])>=recent[0].time and (
                ref['price']<b.close if direction==1 else ref['price']>b.close):
                origin=ref['price'];origin_at=ref['pivot_at'];ref_id=ref['id'];ref_known=ref['known_at']
            else:
                chosen=min(prior+[b],key=lambda x:x.low) if direction==1 else max(prior+[b],key=lambda x:x.high)
                origin=chosen.low if direction==1 else chosen.high;origin_at=chosen.time.isoformat()
                ref_id='lookback_extreme:'+origin_at;ref_known=b.closed_at.isoformat()
            anchor={'direction':direction,'low':origin if direction==1 else b.low,
                    'high':b.high if direction==1 else origin,'origin_at':origin_at,
                    'known_at':b.closed_at.isoformat(),'origin_ref':ref_id,'origin_known_at':ref_known,
                    'qualification':'local_structure_proxy_not_HTF_program'}
        elif anchor:
            if anchor['direction']==1:anchor['high']=max(anchor['high'],b.high)
            else:anchor['low']=min(anchor['low'],b.low)
            if prior_anchor and ((prior_anchor['direction']==1 and b.close<prior_anchor['low']) or
                                (prior_anchor['direction']==-1 and b.close>prior_anchor['high'])) and phase not in ('reversal','consolidation'):
                anchor=None
        rows.append({'id':definition+':'+b.time.isoformat(),'bar_open_at':b.time.isoformat(),
            'known_at':b.closed_at.isoformat(),'phase':phase,'direction':direction,
            'behavior':behavior,'reason':reason,'status':'unvalidated_candidate' if phase!='undetermined' else 'undetermined',
            'source_seconds':SOURCES[phase],'run_start':(run[0].time if run else b.time).isoformat(),
            'reference_before':prior_anchor,'reference_after':dict(anchor) if anchor else None,
            'consolidation_box':dict(box) if box else None,'brooks_range':brooks,'consolidation_evidence':balance,'pda_contacts':pda,
            'metrics':{'atr14_prior':round(atr,6) if atr else None,'net3':round(net3,6),
                       'efficiency3':round(er3,6),'overlap8':round(overlap,6),'efficiency8':round(er8,6),
                       'range8':round(width,6),'consolidation_confirmations':stable},
            'missing':missing,'alternatives':alternatives,'definition':definition})
        # Update FVG lifecycle only after the close decision, never retroactively.
        for f in fvgs:
            if (f['direction']==1 and b.close<f['low']) or (f['direction']==-1 and b.close>f['high']):f['invalidated']=True
        if len(run)>=2 and run[-2].closed_at==run[-1].time and run[-1].closed_at==b.time:
            a=run[-2]
            if b.low>a.high:fvgs.append({'direction':1,'low':a.high,'high':b.low,'formed_at':a.time.isoformat(),'known_at':b.closed_at.isoformat(),'invalidated':False})
            elif b.high<a.low:fvgs.append({'direction':-1,'low':b.high,'high':a.low,'formed_at':a.time.isoformat(),'known_at':b.closed_at.isoformat(),'invalidated':False})
        tr=max(b.high-b.low,abs(b.high-run[-1].close),abs(b.low-run[-1].close)) if run else b.high-b.low
        trs.append(tr);run.append(b);previous_phase=phase
    return rows
