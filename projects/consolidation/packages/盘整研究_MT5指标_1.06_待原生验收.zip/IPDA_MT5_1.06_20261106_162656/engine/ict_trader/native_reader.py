"""Bound native SDK calls so a stuck terminal cannot hold the HTTP process GIL."""
from dataclasses import asdict
import multiprocessing as mp
import time
from .market_source import MarketSourceError


def _serve(connection):
    from app import native
    try:
        while connection.recv() == 'read':
            try:
                response = dict(ok=True, payload=asdict(native()))
            except Exception as exc:
                response = dict(ok=False, error=str(exc), source=getattr(exc, 'market_source', None))
            connection.send(response)
    except (EOFError, BrokenPipeError, OSError):
        pass
    finally:
        connection.close()


class IsolatedNativeReader:
    """Own exactly one read-only child; kill only that child on a deadline."""
    def __init__(self, timeout=10, target=_serve):
        self.timeout = timeout
        self.target = target
        self.context = mp.get_context('spawn')
        self.process = None
        self.connection = None
        self.restarts = 0
        self.timeouts = 0
        self.last_duration = None

    def metadata(self):
        return dict(isolated=True, process_id=self.process.pid if self.process else None,
                    starts=self.restarts, timeouts=self.timeouts, duration_seconds=self.last_duration)

    def close(self):
        if self.connection:
            self.connection.close()
            self.connection = None
        if self.process:
            if self.process.is_alive():
                self.process.terminate()
            self.process.join(timeout=2)
            if self.process.is_alive():
                self.process.kill()
                self.process.join(timeout=2)
            self.process.close()
            self.process = None

    def read(self):
        started=time.monotonic()
        if self.process is None or not self.process.is_alive():
            self.close()
            self.connection, child = self.context.Pipe()
            self.process = self.context.Process(target=self.target, args=(child,), daemon=True)
            try:
                self.process.start()
            except Exception:
                self.connection.close();self.connection=None;self.process=None
                raise
            finally:
                child.close()
            self.restarts += 1
        try:
            self.connection.send('read')
            if not self.connection.poll(self.timeout):
                self.timeouts += 1
                raise TimeoutError(f'MT5行情读取超过{self.timeout}秒，已回收读取进程；保留历史并自动重连')
            reply = self.connection.recv()
        except (OSError, EOFError, TimeoutError):
            self.close()
            raise
        finally:
            self.last_duration=round(time.monotonic()-started,3)
        if not reply.get('ok'):
            if reply.get('source'):
                raise MarketSourceError(reply['source'])
            raise RuntimeError(reply.get('error', 'MT5行情读取失败'))
        return reply['payload']
