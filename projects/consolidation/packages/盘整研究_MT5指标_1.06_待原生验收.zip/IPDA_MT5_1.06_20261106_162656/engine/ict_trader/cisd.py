"""Native-timeframe, closed-candle CISD observations; no macro reversal inference."""
from .core import instant

VERSION='cisd_first_sequence_open_v1'


def observe_cisd(bars, phases, timeframe):
    metrics={p['bar_open_at']:p.get('metrics',{}) for p in phases}
    events=[];early=[];run=[];sequence=[];pending=None;side=0
    for b in bars:
        if run and run[-1]['closed_at']!=b['time']:
            run=[];sequence=[];pending=None;side=0
        move=1 if b['close']>b['open'] else -1 if b['close']<b['open'] else 0
        atr=metrics.get(b['time'],{}).get('atr14_prior')
        if not atr and len(run)>=14:
            past=run[-15:]
            spans=[max(a['high']-a['low'],abs(a['high']-past[j-1]['close']),abs(a['low']-past[j-1]['close']))
                   if j else a['high']-a['low'] for j,a in enumerate(past)]
            atr=sum(spans[-14:])/14
        if move and side and move!=side and sequence:
            pending=dict(direction=move,start=sequence[0]['time'],basis=sequence[0]['open'],
                         last_open=sequence[-1]['open'],basis_known_at=sequence[-1]['closed_at'],
                         sequence_bars=len(sequence),triggers=[],emitted=False,early_emitted=False)
        if pending and move==pending['direction'] and len(pending['triggers'])<2:
            pending['triggers'].append(b)
            trigger=pending['triggers']
            body=sum(abs(x['close']-x['open']) for x in trigger)
            span=sum(x['high']-x['low'] for x in trigger)
            strong=bool(atr and atr>0 and body>=.65*atr and span>0 and body/span>=.6)
            crossed=(b['close']-pending['basis'])*move>0
            item=dict(id=f'{timeframe}:CISD:{b["time"]}',timeframe=timeframe,direction=move,
                bar_open_at=b['time'],known_at=b['closed_at'],sequence_start=pending['start'],
                sequence_bars=pending['sequence_bars'],basis_open=pending['basis'],
                basis_known_at=pending['basis_known_at'],last_candle_open=pending['last_open'],
                trigger_bars=len(trigger),body_atr=round(body/atr,4) if atr else None,
                body_ratio=round(body/span,4) if span else 0,
                qualification='closed_native_CISD_candidate_not_daily_reversal_or_entry')
            if strong and crossed and not pending['emitted']:
                if instant(pending['basis_known_at'])>instant(trigger[0]['time']):raise ValueError('Future CISD basis')
                events.append(item);pending['emitted']=True
            elif strong and not crossed and (b['close']-pending['last_open'])*move>0 and not pending['early_emitted']:
                early.append({**item,'qualification':'last_open_cross_only_not_strict_CISD'})
                pending['early_emitted']=True
        if move==side and move:sequence.append(b)
        elif move:sequence=[b];side=move
        else:sequence=[];side=0;pending=None
        run.append(b)
    return dict(definition=VERSION,timeframe=timeframe,events=events,early_hints=early,
        policy='严格基准固定为此前连续逆向序列第一根开盘价；末根开盘越过仅早期提示。最多两根同向实体的累计位移确认；只看收盘。CISD独立于MSS，不自动改变H1/日线方向。')
