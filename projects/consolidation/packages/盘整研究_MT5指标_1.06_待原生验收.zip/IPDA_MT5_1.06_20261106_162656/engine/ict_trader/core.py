from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from functools import cached_property
from math import isfinite
from zoneinfo import ZoneInfo
import csv

UTC = timezone.utc
NY = ZoneInfo('America/New_York')

def instant(value):
    dt = datetime.fromisoformat(value) if isinstance(value, str) else value
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ValueError('Timezone-aware timestamp required')
    return dt.astimezone(UTC)

@dataclass(frozen=True)
class Bar:
    time: datetime
    open: float
    high: float
    low: float
    close: float
    spread: float = 0.0  # price units; MT5 points must be converted using symbol.point
    seconds: int = 300

    def __post_init__(self):
        instant(self.time)
        if self.seconds <= 0 or not all(isfinite(x) for x in (self.open,self.high,self.low,self.close,self.spread)):
            raise ValueError('Invalid duration or nonfinite OHLC/spread')
        if self.low > min(self.open,self.close) or self.high < max(self.open,self.close) or self.low > self.high or self.spread < 0:
            raise ValueError('Invalid OHLC/spread')

    # Bar is immutable. Reuse its UTC close instant across the independent
    # scanners; dataclasses.replace creates a fresh Bar (and a fresh cache).
    @cached_property
    def closed_at(self):
        return instant(self.time) + timedelta(seconds=self.seconds)

def load_bars(path, seconds=300):
    with open(path, encoding='utf-8-sig', newline='') as f:
        bars = [Bar(instant(r['time']), *(float(r[k]) for k in ('open','high','low','close','spread')), seconds) for r in csv.DictReader(f)]
    if any(b.time <= a.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Duplicate or out-of-order timestamps')
    return bars

def visible(bars, asof):
    cutoff = instant(asof)
    return [b for b in bars if b.closed_at <= cutoff]

def aggregate(bars, seconds, asof):
    """UTC aligned, complete contiguous buckets only. Never includes forming bars."""
    groups = {}
    for b in visible(bars, asof):
        if b.time.microsecond or seconds % b.seconds or int(b.time.timestamp()) % b.seconds:
            raise ValueError('Unsupported/alignment-mismatched base timeframe')
        key = int(b.time.timestamp()) // seconds * seconds
        groups.setdefault(key, []).append(b)
    result = []
    for key, group in sorted(groups.items()):
        step = group[0].seconds
        if any(b.seconds != step for b in group):
            raise ValueError('Mixed base durations')
        expected = list(range(key, key+seconds, step))
        if [int(b.time.timestamp()) for b in group] != expected:
            continue
        if datetime.fromtimestamp(key+seconds, UTC) > instant(asof):
            continue
        result.append(Bar(datetime.fromtimestamp(key,UTC), group[0].open,
                          max(b.high for b in group), min(b.low for b in group),
                          group[-1].close, max(b.spread for b in group), seconds))
    return result

def clock_convert(raw, policy):
    """Convert a raw historical timestamp only under a DST-backed proof."""
    raw = instant(raw)
    # Import lazily to avoid the proof module importing ``core.instant``
    # during module initialization.  A current-tick calibration is not enough
    # to authorize historical conversion.
    from .historical_clock import validate_proof
    report = validate_proof(policy)
    if not report['valid']:
        raise ValueError('Historical clock proof is not verified: ' + '; '.join(report['errors']))
    matches = [s for s in report['segments'] if instant(s['raw_start']) <= raw < instant(s['raw_end'])]
    if len(matches) != 1 or not matches[0].get('evidence'):
        raise ValueError('Missing/overlapping clock coverage or evidence')
    return raw - timedelta(seconds=matches[0]['offset_seconds'])

def ny_day_bounds(day):
    start = datetime.fromisoformat(str(day)).replace(tzinfo=NY)
    # Build the next LOCAL midnight, never add a fixed 24 hours to UTC.
    end = (start + timedelta(days=1)).replace(hour=0,minute=0,second=0)
    return start.astimezone(UTC), end.astimezone(UTC)

def features(bars, asof):
    """Engineering observations, not automatic ICT qualifications."""
    past = visible(bars, asof)
    htf = {}
    for name, seconds in [('M15',900),('H1',3600),('H4',14400)]:
        rows = aggregate(past,seconds,asof)
        if rows:
            b = rows[-1]
            htf[name] = {'closed_at':b.closed_at.isoformat(), 'high':b.high,'low':b.low,
                         'close':b.close, 'midpoint':(b.high+b.low)/2,
                         'position': 'premium' if past[-1].close > (b.high+b.low)/2 else 'discount',
                         'definition':'last complete UTC bucket; not a selected ICT dealing range'}
    swings = []
    for i in range(2,len(past)-2):
        window = past[i-2:i+3]
        if any(y.time != x.closed_at for x,y in zip(window,window[1:])):
            continue
        b = past[i]
        if all(b.high > x.high for j,x in enumerate(window) if j != 2):
            swings.append({'kind':'swing_high','level':b.high,'pivot_at':b.time.isoformat(),'known_at':window[-1].closed_at.isoformat()})
        if all(b.low < x.low for j,x in enumerate(window) if j != 2):
            swings.append({'kind':'swing_low','level':b.low,'pivot_at':b.time.isoformat(),'known_at':window[-1].closed_at.isoformat()})
    fvg = []
    for a,b,c in zip(past,past[1:],past[2:]):
        if b.time != a.closed_at or c.time != b.closed_at:
            continue
        if c.low > a.high:
            fvg.append({'side':'bullish','low':a.high,'high':c.low,'known_at':c.closed_at.isoformat()})
        elif c.high < a.low:
            fvg.append({'side':'bearish','low':c.high,'high':a.low,'known_at':c.closed_at.isoformat()})
    return {'asof':instant(asof).isoformat(),'bars':len(past),'htf':htf,'swings':swings[-20:],'fvg':fvg[-20:],
            'qualification':'geometric_research_proxies_not_complete_ICT_signal'}
