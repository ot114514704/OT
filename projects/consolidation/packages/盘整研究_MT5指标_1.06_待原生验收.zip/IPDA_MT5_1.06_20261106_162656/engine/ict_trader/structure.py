"""Causal geometric swing hierarchy, one component of the source-based context.

Reference: advanced_structure video 105-240s and ICT PDF physical pp199-202.
Three-bar short swings and nested same-side swings are an explicit strict-price
research interpretation. Rebalancing ITH/ITL, HTF-location qualification, bias,
MMXM and a tradeable stop are NOT inferred from these geometric observations.
Relative HH/LH/HL/LL labels compare confirmed prices within one tier and
contiguous run; they are not an implementation of an external SMC indicator.
"""
from .core import aggregate, instant, visible

DEFINITION = 'strict_three_bar_nested_same_side_v1'
SOURCE = {'video_key':'advanced_structure', 'start':105, 'end':240,
          'pdf_physical_pages':[199,200,202]}


def hierarchy(bars, asof):
    """Immutable confirmation records; never upgrade the earlier ST record.

Each new IT/LT record inherits the latest parent confirmation time. Equal
extremes do not qualify in this version. No hierarchy may cross missing bars.
    """
    past = visible(bars, asof)
    if not past:
        return []
    seconds = past[0].seconds
    if any(b.seconds != seconds for b in past):
        raise ValueError('One homogeneous timeframe required')
    if any(b.time <= a.time for a,b in zip(past,past[1:])):
        raise ValueError('Duplicate or out-of-order bars')
    runs = [[]]
    for b in past:
        if runs[-1] and b.time != runs[-1][-1].closed_at:
            runs.append([])
        runs[-1].append(b)
    result = []
    for run in runs:
        for side, attr in [('low','low'),('high','high')]:
            compare = (lambda a,b:a<b) if side=='low' else (lambda a,b:a>b)
            previous = []
            for a,b,c in zip(run,run[1:],run[2:]):
                price = getattr(b,attr)
                if compare(price,getattr(a,attr)) and compare(price,getattr(c,attr)):
                    previous.append({
                        'id':f'{seconds}:ST:{side}:{instant(b.time).isoformat()}',
                        'label':'STL' if side=='low' else 'STH', 'tier':'ST',
                        'side':side, 'price':price, 'timeframe_seconds':seconds,
                        'pivot_at':instant(b.time).isoformat(),
                        'known_at':c.closed_at.isoformat(),
                        'parents':[f'bar:{instant(x.time).isoformat()}' for x in (a,b,c)],
                        'run_start':instant(run[0].time).isoformat(),
                        'definition':DEFINITION})
            result.extend(previous)
            for tier in ('IT','LT'):
                higher = []
                for a,b,c in zip(previous,previous[1:],previous[2:]):
                    if compare(b['price'],a['price']) and compare(b['price'],c['price']):
                        higher.append({**b,
                            'id':f'{seconds}:{tier}:{side}:{b["pivot_at"]}',
                            'label':tier+('L' if side=='low' else 'H'), 'tier':tier,
                            'known_at':max(instant(x['known_at']) for x in (a,b,c)).isoformat(),
                            'parents':[x['id'] for x in (a,b,c)]})
                result.extend(higher)
                previous = higher
    ordered = sorted(result,key=lambda r:(instant(r['known_at']),r['pivot_at'],r['tier'],r['side']))
    references = {}
    for event in ordered:
        # Compare only already-confirmed events at exactly the same level.
        # This runs after hierarchy construction so IT/LT records cannot inherit
        # an ST comparison, and chart-window filtering cannot erase context.
        key = (event['timeframe_seconds'], event['tier'], event['side'], event['run_start'])
        reference = references.get(key)
        comparison = {'label':None, 'reference_id':None,
                      'reference_price':None, 'reference_known_at':None}
        if reference is not None:
            price, prior = event['price'], reference['price']
            if price == prior:
                label = 'equal_'+event['side']
            elif event['side'] == 'high':
                label = 'HH' if price > prior else 'LH'
            else:
                label = 'HL' if price > prior else 'LL'
            comparison = {'label':label, 'reference_id':reference['id'],
                          'reference_price':prior, 'reference_known_at':reference['known_at']}
        event['comparison'] = comparison
        references[key] = event
    return ordered


def multi_frame_structure(bars, asof, chart_start=None):
    """Independent frame observations; labels never assign HTF/MTF/LTF roles.

    Chart records are restricted by pivot time, but confirmation uses all past
    context. They are not truncated to the latest twelve summary-table rows.
    """
    start = instant(chart_start) if chart_start is not None else None
    from .structure_breaks import observe_structure_breaks
    from .liquidity_responses import _responses_from_validated_breaks
    cutoff = instant(asof)
    if start is not None and start > cutoff:
        raise ValueError('Chart start must not follow cutoff')
    frames = {}
    for name,seconds in [('M5',300),('M15',900),('H1',3600)]:
        rows = aggregate(bars,seconds,asof)
        records = hierarchy(rows,asof)
        breaks = observe_structure_breaks(rows,asof,records=records)
        responses = _responses_from_validated_breaks(rows,asof,breaks)
        response_chains = [c for c in responses['chains'] if start is not None and
                           any(start <= instant(e['bar_open_at']) < cutoff for e in c['events'])]
        frames[name] = {
            'bars':len(rows), 'events':{
                tier:[x for x in records if x['tier']==tier][-12:]
                for tier in ('ST','IT','LT')},
            'chart_events': [x for x in records if start is not None
                             and start <= instant(x['pivot_at']) < cutoff],
            'counts':{tier:sum(x['tier']==tier for x in records) for tier in ('ST','IT','LT')},
            'liquidity_responses': {
                'definition':responses['definition'], 'source_rule':responses['source_rule'],
                'qualification':responses['qualification'], 'action':'abstain',
                'chains':response_chains, 'limits':responses['limits'],
                'pre_activation_crosses_excluded':responses['pre_activation_crosses_excluded'],
                'scope':'Chains with a new observation in the chart window; their earlier causal history is retained.'},
            'breaks':{
                'definition':breaks['definition'],
                'qualification':'observation_only',
                'events':[x for x in breaks['events'] if start is not None
                          and start <= instant(x['bar_open_at']) < cutoff],
                'stale_refs':[x for x in breaks['stale_refs'] if start is not None
                              and start <= instant(x['reference_known_at']) <= cutoff],
                'all_history_counts':{tier:{kind:sum(x['reference_tier']==tier and x['kind']==kind
                                                   for x in breaks['events'])
                                            for kind in ('wick_cross','close_break')}
                                      for tier in ('ST','IT','LT')},
                'stale_on_activation_count':len(breaks['stale_refs']),
                'scope':'Displayed events belong to bars opened in the chart window; summary counts use all visible history. No BOS/CHoCH/MSS qualification.'}}
    return {'asof':instant(asof).isoformat(), 'definition':DEFINITION,
            'source':SOURCE, 'frames':frames,
            'qualification':'geometry_only_context_and_rebalance_qualification_pending',
            'roles':{'HTF':None,'LTF':None,'MTF_micro_optional':None},
            'alignment':'complete contiguous UTC buckets under selected clock hypothesis',
            'uncertainty':['equal_extremes_excluded_by_version', 'gap_breaks_hierarchy',
                           'rebalancing_IT_not_detected','context_does_not_follow_from_geometry']}
