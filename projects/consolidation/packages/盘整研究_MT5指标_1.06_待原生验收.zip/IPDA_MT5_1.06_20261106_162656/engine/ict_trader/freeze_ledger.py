"""Cross-snapshot immutable range evidence, persisted separately from prices.

A revised formation source may explain revised evidence. Missing source coverage
or unchanged source cannot explain a change to an already frozen identity.
"""
from copy import deepcopy
from bisect import bisect_left,bisect_right
from hashlib import sha256
import json
from pathlib import Path
import time
from .core import instant
from .ipda_ranges import PARAMETERS as RANGE_PARAMETERS

VERSION='range_freeze_ledger_v1'
ENGINE_FILES=('ipda_ranges.py','consolidation_profile.py','shape_geometry.py','macro_consolidation.py','structural_ranges.py','long_geometry.py','oscillation.py','swing_balance.py','freeze_ledger.py')
BODY_FIELDS=('observed_from','known_at','low','high','liquidity_low','liquidity_high','frozen_atr','checks','profile','oscillation')
STRUCTURE_FIELDS=('observed_from','first_observed_at','window','high','low','body_high','body_low',
                  'observed_high','observed_low','slope_per_bar','frozen_atr','shape','metrics','checks','geometry')
GEOMETRY_FIELDS=('observed_from','first_observed_at','window','observed_high','observed_low','frozen_atr','shape','metrics','checks','geometry')


def engine_fingerprint(directory):
    digest=sha256()
    for name in ENGINE_FILES:
        digest.update(name.encode());digest.update((Path(directory)/name).read_bytes())
    return digest.hexdigest()


def _source(index,start,end):
    indexed,opens,closes=index
    left=bisect_left(opens,instant(start));right=bisect_right(closes,instant(end))
    before=indexed[max(0,left-12):left];formation=indexed[left:right]
    complete=bool(formation and instant(formation[0]['time'])==instant(start) and instant(formation[-1]['closed_at'])==instant(end))
    def digest(rows):
        values=[dict(time=instant(r['time']).isoformat(),closed_at=instant(r['closed_at']).isoformat(),
                     **{k:float(r[k]) if r.get(k) is not None else None for k in ('open','high','low','close')}) for r in rows]
        return sha256(json.dumps(values,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return dict(complete=complete,digest=digest(before+formation),formation_digest=digest(formation),context_digest=digest(before))


def observations(charts,raw):
    entries={}
    for period,c in charts.items():
        rows=[r for r in raw.get(period,[]) if r.get('time') and r.get('closed_at')]
        index=(rows,[instant(r['time']) for r in rows],[instant(r['closed_at']) for r in rows])
        for kind,name,fields in [('local','consolidations',BODY_FIELDS),('macro','macro_ranges',BODY_FIELDS),
                                 ('structural','structural_ranges',STRUCTURE_FIELDS),('geometric','geometric_ranges',GEOMETRY_FIELDS)]:
            for box in c.get(name,[]):
                identity=period+':'+kind+':'+box['id']
                facts={k:deepcopy(box[k]) for k in fields}
                known=box['first_observed_at'] if kind in ('structural','geometric') else box['known_at']
                entries[identity]=dict(period=period,kind=kind,range_id=box['id'],facts=facts,
                                       source=_source(index,box['observed_from'],known))
    return entries


def active_ranges(charts,raw):
    result={}
    for period,c in charts.items():
        rows=c.get('phase_rows') or []
        local=rows[-1].get('consolidation_evidence',{}).get('range') if rows else None
        macro=c.get('macro_current') or {}
        for kind,box in [('local',local),('macro',macro.get('range') if macro.get('verdict')=='confirmed' else None)]:
            if not box:continue
            source=[r for r in raw.get(period,[]) if r.get('time') and r.get('closed_at')]
            index=(source,[instant(r['time']) for r in source],[instant(r['closed_at']) for r in source])
            known=c['closed_end'];streak=box.get('breakout_streak',0)
            prior=[r for r in source if instant(r['closed_at'])<=instant(known)]
            first=prior[-streak] if streak and len(prior)>=streak else None
            result[period+':'+kind]=dict(period=period,kind=kind,range_id=box['id'],last_observed_at=known,
                box={k:deepcopy(box.get(k)) for k in ('id','observed_from','low','high','liquidity_low','liquidity_high','frozen_atr','breakout_basis','breakout_streak','breakout_side')},
                break_first=deepcopy(first),source=_source(index,box['observed_from'],known))
        for box in c.get('geometric_current',[]):
            source=[r for r in raw.get(period,[]) if r.get('time') and r.get('closed_at')]
            index=(source,[instant(r['time']) for r in source],[instant(r['closed_at']) for r in source])
            result[period+':geometric:'+str(box['window'])]=dict(period=period,kind='geometric',range_id=box['id'],last_observed_at=c['closed_end'],
                box={k:deepcopy(box[k]) for k in ('id','observed_from','geometry','frozen_atr','side','streak')},
                source=_source(index,box['observed_from'],c['closed_end']))
    return result


def _exit_after(previous,rows):
    """Explain an identity ending using ONLY bars after its last observation."""
    box=previous['box'];last=instant(previous['last_observed_at'])
    if not any(instant(r['closed_at'])==last for r in rows if r.get('closed_at')):return None
    if previous['kind']=='geometric':
        from .long_geometry import line_value,PARAMETERS as GEOMETRY_PARAMETERS
        streak=box['streak'];old_side=box['side']
        for b in rows:
            if not b.get('time') or instant(b['closed_at'])<=last:continue
            if instant(b['time'])!=last:return 'data_gap'
            g=box['geometry'];upper=line_value(g['upper'],b['time']);lower=line_value(g['lower'],b['time'])
            if upper<=lower:return 'line_intersection'
            tolerance=GEOMETRY_PARAMETERS['boundary_tolerance_atr']*box['frozen_atr']
            side=1 if b['close']>upper+tolerance else -1 if b['close']<lower-tolerance else 0
            streak=streak+1 if side and side==old_side else 1 if side else 0
            if streak>=GEOMETRY_PARAMETERS['exit_closes']:return 'closed_departure'
            old_side=side;last=instant(b['closed_at'])
        return None
    upper=box['liquidity_high'] if box.get('breakout_basis')=='liquidity' else box['high']
    lower=box['liquidity_low'] if box.get('breakout_basis')=='liquidity' else box['low']
    streak=box.get('breakout_streak') or 0;old_side=box.get('breakout_side') or 0;first=previous.get('break_first')
    for b in rows:
        if not b.get('time') or instant(b['closed_at'])<=last:continue
        if instant(b['time'])!=last:return 'data_gap'
        side=1 if b['close']>upper+RANGE_PARAMETERS['breakout_atr']*box['frozen_atr'] else -1 if b['close']<lower-RANGE_PARAMETERS['breakout_atr']*box['frozen_atr'] else 0
        if side and side!=old_side:first=b
        streak=streak+1 if side and side==old_side else 1 if side else 0;old_side=side
        if side and first:
            distance=(b['close']-(upper if side>0 else lower))*side
            follow=(b['close']-first['close'])*side>0 and (abs(b['close']-first['open'])>=.35*box['frozen_atr'] or distance>=.5*box['frozen_atr'])
            if streak>=RANGE_PARAMETERS['acceptance_closes'] or streak>=RANGE_PARAMETERS['breakout_closes'] and follow:return 'breakout_confirmed'
        last=instant(b['closed_at'])
    return None


class FreezeLedger:
    def __init__(self,path,engine):
        self.path=Path(path);self.engine=engine;self.entries={};self.active={};self.revision_log=[];self.read_error=None
        if self.path.exists():
            try:
                data=json.loads(self.path.read_text(encoding='utf-8'))
                if data.get('version')!=VERSION or data.get('engine')!=engine:raise ValueError('冻结记录版本或规则指纹不匹配')
                if not isinstance(data['entries'],dict):raise ValueError('冻结记录缺少合法区间映射')
                for entry in data['entries'].values():
                    if not isinstance(entry,dict) or not isinstance(entry.get('facts'),dict) or not isinstance(entry.get('source'),dict):raise ValueError('冻结记录区间格式无效')
                    if not isinstance(entry['source'].get('digest'),str) or not isinstance(entry['source'].get('complete'),bool):raise ValueError('冻结记录来源摘要无效')
                self.entries=data['entries'];self.revision_log=data.get('source_revisions',[])
                if not isinstance(self.revision_log,list):raise ValueError('冻结记录修订日志无效')
                self.active=data.get('active_ranges',{})
                if not isinstance(self.active,dict) or any(not isinstance(r,dict) or not isinstance(r.get('box'),dict) or not r.get('last_observed_at') for r in self.active.values()):raise ValueError('冻结记录活动区间格式无效')
            except (OSError,ValueError,KeyError,TypeError) as exc:self.read_error=str(exc);self.entries={};self.active={};self.revision_log=[]

    def inspect(self,charts,raw):
        current=observations(charts,raw);active=active_ranges(charts,raw);issues=[];revisions=[];matched=0
        if self.read_error:issues.append(dict(code='ledger_unreadable',detail=self.read_error))
        for identity,new in current.items():
            old=self.entries.get(identity)
            if not old:continue
            matched+=1
            if new['facts']==old['facts']:
                if not new['source']['complete']:new['source']=deepcopy(old['source'])
                continue
            previous=old.get('source') or {}
            changed=[k for k in new['facts'] if new['facts'][k]!=old['facts'].get(k)]
            # Compare the OLD formation interval against today's source. A
            # shifted timestamp must not manufacture its own "source change".
            rows=[r for r in raw.get(new['period'],[]) if r.get('time') and r.get('closed_at')]
            index=(rows,[instant(r['time']) for r in rows],[instant(r['closed_at']) for r in rows])
            old_known=old['facts'].get('first_observed_at') or old['facts']['known_at']
            same_scope=_source(index,old['facts']['observed_from'],old_known)
            formation_changed=bool(previous.get('formation_digest') and same_scope['formation_digest']!=previous['formation_digest'])
            context_changed=bool(previous.get('context_digest') and same_scope['context_digest']!=previous['context_digest'])
            explained=formation_changed or context_changed and set(changed)<={'profile'}
            immutable_time=bool(set(changed)&{'known_at','first_observed_at'})
            if new['source']['complete'] and same_scope['complete'] and previous.get('complete') and explained and not immutable_time:
                revisions.append(dict(identity=identity,range_id=new['range_id'],period=new['period'],kind=new['kind'],
                                      changed_fields=changed,
                                      previous_bounds={k:v for k,v in old['facts'].items() if k in ('low','high','liquidity_low','liquidity_high','observed_low','observed_high')},
                                      updated_bounds={k:v for k,v in new['facts'].items() if k in ('low','high','liquidity_low','liquidity_high','observed_low','observed_high')},
                                      reason='formation_source_changed'))
            else:
                issues.append(dict(code='unexplained_frozen_change',identity=identity,period=new['period'],range_id=new['range_id'],
                                   changed_fields=[k for k in new['facts'] if new['facts'][k]!=old['facts'].get(k)],
                                   source_coverage_complete=bool(new['source']['complete'] and previous.get('complete'))))
        for key,previous in self.active.items():
            if active.get(key,{}).get('range_id')==previous['range_id']:continue
            rows=[r for r in raw.get(previous['period'],[]) if r.get('time') and r.get('closed_at')]
            index=(rows,[instant(r['time']) for r in rows],[instant(r['closed_at']) for r in rows])
            source=_source(index,previous['box']['observed_from'],previous['last_observed_at'])
            old_source=previous.get('source') or {}
            revised=source['complete'] and old_source.get('complete') and source['digest']!=old_source.get('digest')
            if revised:
                revisions.append(dict(period=previous['period'],range_id=previous['range_id'],kind=previous['kind'],reason='active_source_changed'))
            elif not _exit_after(previous,rows):
                issues.append(dict(code='unexplained_active_identity_change',period=previous['period'],kind=previous['kind'],range_id=previous['range_id']))
        return dict(version=VERSION,engine=self.engine,passed=not issues,checked_ranges=len(current),previously_recorded=matched,
                    source_revisions=revisions,issues=issues,checked_at=time.time(),_entries=current,_active=active)

    @staticmethod
    def public(report):return {k:v for k,v in report.items() if not k.startswith('_')}

    def persist(self,charts,raw):
        report=self.inspect(charts,raw)
        if not report['passed']:raise ValueError('冻结记录一致性校验未通过')
        entries={**self.entries,**report['_entries']}
        revisions=(self.revision_log+[dict(r,observed_at=report['checked_at']) for r in report['source_revisions']])[-100:]
        self.path.parent.mkdir(parents=True,exist_ok=True)
        data=dict(version=VERSION,engine=self.engine,updated_at=time.time(),entries=entries,active_ranges=report['_active'],source_revisions=revisions)
        temp=self.path.with_suffix('.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8');temp.replace(self.path)
        self.entries=entries;self.active=report['_active'];self.revision_log=revisions
        return self.public(report)
