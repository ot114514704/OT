"""Long-scale converging price candidates, independent of IPDA confirmation.

Search boundary pairs among already confirmed pivots, rather than the last two
minor turns. Freeze the chosen actual anchors at first observation. A candidate
is not a probability, an IPDA accumulation confirmation, or a direction call.
"""
from copy import deepcopy
from itertools import combinations
from statistics import median
from .core import instant,visible
from .oscillation import strong_oscillation

VERSION='long_converging_candidate_v1'
PARAMETERS=dict(windows_m15=[24,36,48,96],windows_h1=[24,48],pivot_radius=3,
    minimum_anchor_span=12,minimum_overlap_bars=12,maximum_pivots_per_side=8,
    short_pivot_radius=1,short_anchor_span=4,short_overlap_bars=4,
    boundary_tolerance_atr=.15,single_edge_wick_coverage_min=.9,single_edge_close_coverage_min=.95,
    wick_coverage_min=.8,close_coverage_min=.9,contraction_max=.85,flat_width_fraction=.05,
    width_atr_min=3.,width_atr_max=18.,efficiency_max=.35,largest_body_to_width_max=.5,exit_closes=2)


def line_value(points,time):
    a,b=points;t=instant(time);ta=instant(a['time']);tb=instant(b['time'])
    return a['price']+(b['price']-a['price'])*(t-ta).total_seconds()/(tb-ta).total_seconds()


def candidate(bars):
    n=len(bars);short=bool(bars and bars[0].seconds==900 and n<48)
    radius=PARAMETERS['short_pivot_radius'] if short else PARAMETERS['pivot_radius']
    min_span=PARAMETERS['short_anchor_span'] if short else PARAMETERS['minimum_anchor_span']
    min_overlap=PARAMETERS['short_overlap_bars'] if short else PARAMETERS['minimum_overlap_bars']
    if n<2*radius+min_overlap:return None
    if any(a.closed_at!=b.time or a.seconds!=b.seconds for a,b in zip(bars,bars[1:])):return None
    atr=median(b.high-b.low for b in bars)
    if atr<=0:return None
    highs=[];lows=[]
    for i in range(radius,n-radius):
        b=bars[i];left=bars[i-radius:i];right=bars[i+1:i+radius+1]
        p=dict(index=i,time=b.time.isoformat(),known_at=bars[i+radius].closed_at.isoformat())
        if all(b.high>x.high for x in left) and all(b.high>=x.high for x in right):highs.append({**p,'price':b.high})
        if all(b.low<x.low for x in left) and all(b.low<=x.low for x in right):lows.append({**p,'price':b.low})
    tolerance=PARAMETERS['boundary_tolerance_atr']*atr
    def pairs(points,upper):
        result=[]
        for a,b in combinations(points[-PARAMETERS['maximum_pivots_per_side']:],2):
            if b['index']-a['index']<min_span:continue
            slope=(b['price']-a['price'])/(b['index']-a['index'])
            values=[a['price']+slope*(i-a['index']) for i in range(n)]
            # Validate to the latest observed bar, not just the overlap between
            # the anchors: an old attractive line may already have been left.
            segment=range(a['index'],n)
            if upper:
                wick=sum(bars[i].high<=values[i]+tolerance for i in segment)/(n-a['index'])
                close=sum(bars[i].close<=values[i]+tolerance for i in segment)/(n-a['index'])
                last=bars[-1].close<=values[-1]+tolerance
            else:
                wick=sum(bars[i].low>=values[i]-tolerance for i in segment)/(n-a['index'])
                close=sum(bars[i].close>=values[i]-tolerance for i in segment)/(n-a['index'])
                last=bars[-1].close>=values[-1]-tolerance
            if last and wick>=PARAMETERS['single_edge_wick_coverage_min'] and close>=PARAMETERS['single_edge_close_coverage_min']:
                result.append(dict(points=[a,b],values=values))
        return result
    upper=pairs(highs,True);lower=pairs(lows,False)
    if not upper or not lower:return None
    travel=sum(abs(b.close-a.close) for a,b in zip(bars,bars[1:]));efficiency=abs(bars[-1].close-bars[0].close)/travel if travel else 0.
    physical_high=max(b.high for b in bars);physical_low=min(b.low for b in bars);width=physical_high-physical_low
    oscillation=strong_oscillation(bars,atr,width)
    checks=dict(balanced=efficiency<=PARAMETERS['efficiency_max'],strong_oscillation=oscillation['qualified'],
                structural_width=PARAMETERS['width_atr_min']<=width/atr<=PARAMETERS['width_atr_max'],
                no_dominant_bar=max(abs(b.close-b.open) for b in bars)<=PARAMETERS['largest_body_to_width_max']*width)
    if not all(checks.values()):return None
    best=None;rank=None
    for u in upper:
        for l in lower:
            up=u['points'];low=l['points'];start=max(up[0]['index'],low[0]['index']);end=min(up[1]['index'],low[1]['index'])
            overlap=end-start+1
            if overlap<min_overlap:continue
            uh,ul=u['values'][start],u['values'][end];lh,ll=l['values'][start],l['values'][end]
            if not 0<ul-ll<uh-lh or u['values'][-1]<=l['values'][-1]:continue
            contraction=(ul-ll)/(uh-lh)
            if contraction>PARAMETERS['contraction_max']:continue
            window=range(start,n)
            wick=sum(bars[i].high<=u['values'][i]+tolerance and bars[i].low>=l['values'][i]-tolerance for i in window)/(n-start)
            close=sum(l['values'][i]-tolerance<=bars[i].close<=u['values'][i]+tolerance for i in window)/(n-start)
            if wick<PARAMETERS['wick_coverage_min'] or close<PARAMETERS['close_coverage_min']:continue
            flat=PARAMETERS['flat_width_fraction']*(uh-lh);du=ul-uh;dl=ll-lh
            subtype='ascending_triangle' if abs(du)<=flat and dl>0 else 'descending_triangle' if abs(dl)<=flat and du<0 else 'triangle' if du<0 and dl>0 else 'rising_wedge' if du>0 and dl>0 else 'falling_wedge' if du<0 and dl<0 else None
            if not subtype:continue
            # Ranking uses time/coverage, never direction or future outcome.
            key=(overlap,min(wick,close),min(up[1]['index']-up[0]['index'],low[1]['index']-low[0]['index']),
                 tuple(sorted(p['index'] for p in up+low)))
            if rank is not None and key<=rank:continue
            rank=key
            def point(i,price):return dict(time=bars[i].time.isoformat(),price=price)
            strip=lambda p:{k:v for k,v in p.items() if k!='index'}
            geometry=dict(upper=[strip(p) for p in up],lower=[strip(p) for p in low],
                frame=[point(start,uh),point(end,ul),point(end,ll),point(start,lh)],
                ready=True,validated=True,subtype=subtype,projected=False,basis='long_scale_confirmed_boundary_pairs',
                known_at=max(p['known_at'] for p in up+low),pivot_radius=radius,contraction_ratio=contraction,
                reason='长尺度已确认锚点及截至首次观察的覆盖验证通过；仅画锚点与共同覆盖区间',
                validation=dict(overlap_bars=overlap,validation_bars=n-start,wick_coverage=wick,close_coverage=close,tolerance=tolerance))
            best=dict(observed_from=bars[0].time.isoformat(),first_observed_at=bars[-1].closed_at.isoformat(),
                known_at=bars[-1].closed_at.isoformat(),window=n,shape='converging',geometry=geometry,
                observed_high=physical_high,observed_low=physical_low,frozen_atr=atr,checks={**checks,'confirmed_boundary_pairs':True,'covered_contraction':True,'last_close_inside':True},
                metrics=dict(efficiency=efficiency,width_atr=width/atr,overlap_bars=overlap,oscillation=oscillation,
                             contraction_ratio=contraction,wick_coverage=wick,close_coverage=close),
                confirmed=False,score_included=False,
                missing=['IPDA实体平衡确认独立判断','机构积累/派发意图未验证','截图人工边界尚未逐点精确复现'])
    return best


def observe_long_geometry(bars,asof):
    bars=visible(bars,asof)
    if not bars:return dict(version=VERSION,ranges=[],current=[],history=[])
    if any(a.time>=b.time or a.seconds!=b.seconds for a,b in zip(bars,bars[1:])):raise ValueError('Ordered homogeneous bars required')
    windows=PARAMETERS['windows_h1' if bars[0].seconds==3600 else 'windows_m15'];active={};ranges=[];history=[]
    for i,b in enumerate(bars):
        for n in windows:
            box=active.get(n)
            if box:
                g=box['geometry'];upper=line_value(g['upper'],b.time);lower=line_value(g['lower'],b.time)
                gap=i and bars[i-1].closed_at!=b.time
                side=1 if b.close>upper+PARAMETERS['boundary_tolerance_atr']*box['frozen_atr'] else -1 if b.close<lower-PARAMETERS['boundary_tolerance_atr']*box['frozen_atr'] else 0
                box['streak']=box['streak']+1 if side and side==box['side'] else 1 if side else 0
                box.update(end_at=b.closed_at.isoformat(),side=side)
                status='数据间隔中止斜线候选' if gap else '边线交会，斜线候选失效' if upper<=lower else ('向上离开斜线观察区' if side==1 else '向下离开斜线观察区') if box['streak']>=PARAMETERS['exit_closes'] else None
                if status:
                    box.update(status=status,active=False);del active[n]
                    history.append(dict(known_at=b.closed_at.isoformat(),event='long_geometry_ended',range_id=box['id'],title=status,
                        detail='结束长尺度形态候选；不充当IPDA确认或交易信号',confirmed_bar_only=True))
                continue
            if i+1<n:continue
            c=candidate(bars[i-n+1:i+1])
            if c is None:continue
            box={**deepcopy(c),'id':VERSION+':'+str(n)+':'+b.closed_at.isoformat(),'end_at':b.closed_at.isoformat(),
                 'active':True,'status':'长尺度收敛形态候选','side':0,'streak':0}
            active[n]=box;ranges.append(box)
            history.append(dict(known_at=b.closed_at.isoformat(),event='long_geometry_entered',range_id=box['id'],title='出现长尺度收敛候选',
                detail=f"{n}根已收盘样本；锚点需其后{PARAMETERS['pivot_radius']}根收盘可知；形态边界此时冻结，不计分",confirmed_bar_only=True))
    return dict(version=VERSION,parameters=PARAMETERS,ranges=ranges,current=list(active.values()),history=history[-24:])
