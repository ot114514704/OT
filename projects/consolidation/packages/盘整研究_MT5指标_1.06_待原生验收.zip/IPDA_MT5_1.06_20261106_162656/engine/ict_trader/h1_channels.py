"""Causal, broad H1 delivery envelopes with explicit structural validation.

An envelope is not a fitted parallel trend channel. Local consolidation remains
consolidation inside the envelope; it does not terminate a directional thesis.
"""
from copy import deepcopy


def observe_channels(bars):
    if any(b.seconds != 3600 for b in bars):
        raise ValueError('H1 required')
    if any(a.time >= b.time for a,b in zip(bars,bars[1:])):
        raise ValueError('Increasing timestamps required')
    wing=4; high=None; low=None; broken=set(); active=None; rows=[]; origin_index=0; previous_ended=None
    displacement_history=[]
    for i,b in enumerate(bars):
        ended=None
        if i and (b.time-bars[i-1].closed_at).total_seconds()>72*3600:
            if active:
                ended=deepcopy(active);ended['status']='ended';ended['end_reason']='超过72小时数据缺口，方向证据不连续'
            active=None; high=None; low=None; origin_index=i;previous_ended=None;displacement_history=[]
        j=i-wing
        if j-wing>=origin_index:
            window=bars[j-wing:j+wing+1];center=bars[j]
            if all(center.high>x.high for x in window if x is not center):high=(j,center.high)
            if all(center.low<x.low for x in window if x is not center):low=(j,center.low)
        prior=bars[max(origin_index,i-14):i]
        atr=sum(max(x.high-x.low,abs(x.high-bars[k-1].close),abs(x.low-bars[k-1].close)) if k else x.high-x.low
                for k,x in enumerate(bars[max(origin_index,i-14):i],start=max(origin_index,i-14)))/len(prior) if len(prior)>=14 else None
        # User's IPDA material distinguishes directional displacement from a
        # slow drift through a pivot. Thresholds are explicit research choices.
        three=bars[max(origin_index,i-2):i+1]
        contiguous=len(three)==3 and all(a.closed_at==z.time for a,z in zip(three,three[1:]))
        net=b.close-three[0].open
        path=abs(three[0].close-three[0].open)+sum(abs(z.close-a.close) for a,z in zip(three,three[1:]))
        efficiency=abs(net)/path if path else 0
        prior_six=bars[max(origin_index,i-6):i]
        motion=1 if net>0 else -1
        escaped=len(prior_six)==6 and (b.close>max(x.high for x in prior_six) if motion==1 else b.close<min(x.low for x in prior_six))
        if atr and contiguous and escaped and abs(net)>=atr and efficiency>=.6:
            displacement_history.append(dict(direction=motion,start_at=three[0].time.isoformat(),known_at=b.closed_at.isoformat(),net_atr=round(abs(net)/atr,3),efficiency=round(efficiency,3)))
        if active:
            crossed=(b.close-active['protected_price'])*active['direction']<0
            active['invalid_closes']=active.get('invalid_closes',0)+1 if crossed else 0
            displacement=atr and (b.close-b.open)*active['direction']<=-.65*atr
            if crossed and (displacement or active['invalid_closes']>=2):
                ended=deepcopy(active);ended['status']='ended';ended['end_reason']='H1收盘突破已确认延续结构的保护位，并有反向实体位移或连续两次收盘确认';ended['invalidated_at']=b.closed_at.isoformat();active=None
                previous_ended=ended
        event=None
        for direction,pivot in ((1,high),(-1,low)):
            if pivot and (direction,pivot[0]) not in broken and (b.close-pivot[1])*direction>0:
                broken.add((direction,pivot[0]));event=dict(direction=direction,pivot_at=bars[pivot[0]].time.isoformat(),price=pivot[1],known_at=b.closed_at.isoformat())
                opposite=low if direction==1 else high
                if active is None and opposite and atr:
                    start=opposite[0];origin=opposite[1]
                    if (b.close-origin)*direction>0:
                        span=bars[start:i+1]
                        active=dict(id='h1-channel-'+bars[start].time.isoformat()+'-'+str(direction),start_at=bars[start].time.isoformat(),end_at=b.closed_at.isoformat(),
                                    first_known_at=b.closed_at.isoformat(),validated_at=None,direction=direction,origin_price=origin,origin_at=bars[start].time.isoformat(),protected_price=origin,protected_known_at=b.closed_at.isoformat(),
                                    high=max(x.high for x in span),low=min(x.low for x in span),breaks=[],status='candidate',observed_bars=len(span),start_index=start,atr_at_start=atr)
                        if previous_ended and direction==-previous_ended['direction']:
                            active['reversal']={'prior_channel_id':previous_ended['id'],'prior_direction':previous_ended['direction'],
                                'prior_was_validated':previous_ended['validated_at'] is not None,'broken_protection':previous_ended['protected_price'],
                                'first_known_at':b.closed_at.isoformat(),'protection_broken_at':previous_ended['invalidated_at'],
                                'confirmed_at':None,'status':'candidate','qualification':'H1_structure_reversal_not_daily_trend_confirmation'}
                if active and direction==active['direction']:
                    # Move protection only after another continuation break has
                    # confirmed the intervening swing, never on a mere pullback.
                    if active['breaks'] and opposite and bars[opposite[0]].time.isoformat()>active['breaks'][-1]['pivot_at']:
                        if (opposite[1]-active['protected_price'])*direction>0:
                            active['protected_price']=opposite[1];active['protected_known_at']=b.closed_at.isoformat()
                    active['breaks'].append(event)
        if active:
            active['end_at']=b.closed_at.isoformat();active['high']=max(active['high'],b.high);active['low']=min(active['low'],b.low)
            active['observed_bars']=i-active['start_index']+1
            progress=(b.close-active['origin_price'])*active['direction']/active['atr_at_start']
            active['progress_atr']=round(progress,3)
            support=[d for d in displacement_history if d['direction']==active['direction'] and d['start_at']>=active['start_at']]
            active['displacement_evidence']=deepcopy(support[-8:])
            active['validation_missing']=[name for name,ok in (
                ('两次同向已确认结构突破',len(active['breaks'])>=2),
                ('净推进至少3 ATR',progress>=3),('观察至少12根H1',active['observed_bars']>=12),
                ('有效率的位移收盘突破',bool(support))) if not ok]
            if active['validated_at'] is None and not active['validation_missing']:
                active['validated_at']=b.closed_at.isoformat();active['status']='validated'
                if active.get('reversal') and active['reversal']['prior_was_validated']:
                    active['reversal']['confirmed_at']=b.closed_at.isoformat();active['reversal']['status']='structure_confirmed'
        rows.append(dict(known_at=b.closed_at.isoformat(),active=deepcopy(active),ended=ended))
    return dict(version='h1_delivery_envelope_v3_displacement',rows=rows,
                policy='H1左右各4棒确认摆动；至少两次同向结构突破、净推进≥起点ATR的3倍、≥12根H1，并观察到连续3棒净位移≥前14棒ATR、效率≥0.60且收盘越过前6棒极值，才验证扩张背景。内部回调不切断完整趋势；后续同向突破确认中间回调后才推进保护位，反向位移收盘或连续两次收盘突破保护位才失效。盘整仍单独识别；FVG、时段与DOL不是强制补出的证据。数值为工程假设，规则验证不代表预测准确率。')
