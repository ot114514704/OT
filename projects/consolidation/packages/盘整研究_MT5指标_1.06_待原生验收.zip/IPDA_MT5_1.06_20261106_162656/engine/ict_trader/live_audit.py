"""Read-only structural acceptance of one /api/state snapshot, not a backtest."""
import argparse
import json
from math import isfinite
from pathlib import Path
from urllib.request import urlopen
from .core import instant


def audit_payload(payload):
    issues=[];counts=dict(closed_bars=0,phase_rows=0,frozen_observations=0,geometry_profiles=0,score_tables=0,swing_candidates=0,structural_candidates=0,geometric_candidates=0)
    def check(ok,code,where):
        if not ok:issues.append(dict(code=code,where=where))
    def fit(score,where):
        if not score:return
        parts=score.get('components',[]);counts['score_tables']+=1
        check(sum(x['weight'] for x in parts)==100,'score_denominator',where)
        check(all(0<=x['points']<=x['weight'] for x in parts),'score_component_bounds',where)
        check(0<=score['score']<=100,'score_bounds',where)
    def geometry(profile,known_at,where):
        g=(profile or {}).get('geometry')
        if not g:return
        counts['geometry_profiles']+=1
        check(g.get('projected') is False,'geometry_future_projection',where)
        if g.get('known_at'):check(instant(g['known_at'])<=instant(known_at),'geometry_known_at',where)
        for point in g.get('upper',[])+g.get('lower',[]):
            check(instant(point['time'])<instant(point['known_at'])<=instant(known_at),'anchor_known_at',where)
            if g.get('basis')=='frozen_regression_envelope':
                check(instant(point['known_at'])==instant(known_at),'envelope_known_at',where)
            else:check((instant(point['known_at'])-instant(point['time'])).total_seconds()>=(g.get('pivot_radius',1)+1)*seconds,'anchor_confirmation_delay',where)
        for point in g.get('frame',[]):check(instant(point['time'])<=instant(known_at),'frame_future_time',where)
    def oscillation(o,known_at,where):
        check(bool(o) and o.get('qualified') is True,'strong_oscillation_gate',where)
        if not o:return
        check(o['completed_legs']>=3 and o['up_legs']>0 and o['down_legs']>0 and not o['recent_impulse'] and not o['unreversed_displacements'],
              'strong_oscillation_evidence',where)
        check(instant(o['known_at'])==instant(known_at),'oscillation_known_at',where)
        for leg in o['legs']:
            check(leg['amplitude']>=o['threshold'] and instant(leg['from_bar'])<instant(leg['to_bar'])<instant(leg['reversal_observed_at'])<=instant(leg['known_at'])==instant(known_at),
                  'oscillation_leg_causality',where)
    charts=payload.get('charts') or {}
    integrity=payload.get('freeze_integrity')
    if integrity:check(integrity.get('passed') is True,'cross_snapshot_freeze_integrity','freeze_integrity')
    check(set(charts)=={'H1','M15'},'periods_present','charts')
    for period,chart in charts.items():
        bars=chart['bars'];rows=chart['phase_rows'];end=instant(chart['closed_end']);seconds=3600 if period=='H1' else 900
        check(bool(bars and rows),'model_rows_present',period)
        if not bars or not rows:continue
        counts['closed_bars']+=len(bars);counts['phase_rows']+=len(rows)
        check(instant(bars[-1]['closed_at'])==end,'closed_end_matches_bar',period)
        check(instant(rows[-1]['known_at'])==end,'closed_end_matches_phase',period)
        check(all(instant(a['time'])<instant(b['time']) for a,b in zip(bars,bars[1:])),'bar_order',period)
        for b in bars:
            check(not b.get('forming',False) and instant(b['closed_at'])<=end,'forming_in_closed_model',period+':'+b['time'])
            check((instant(b['closed_at'])-instant(b['time'])).total_seconds()==seconds,'bar_duration',period+':'+b['time'])
        frozen={}
        for row in rows:
            where=period+':'+row['known_at'];known=instant(row['known_at'])
            check(known<=end,'phase_future_time',where)
            fit(row['fit_scores']['by_phase']['consolidation'],where)
            e=row['consolidation_evidence'];box=e.get('range') or e.get('ended')
            if box:
                counts['frozen_observations']+=1
                immutable={k:box[k] for k in ('low','high','liquidity_low','liquidity_high','frozen_atr','known_at','checks','profile')}
                if box['id'] in frozen:check(immutable==frozen[box['id']],'frozen_boundary_changed',where)
                else:frozen[box['id']]=immutable
                check(instant(box['known_at'])<=known,'range_confirmation_future',where)
                check(box['liquidity_low']<=box['low']<=box['high']<=box['liquidity_high'],'range_boundary_order',where)
                geometry(box.get('profile'),row['known_at'],where)
                oscillation(box.get('oscillation'),box['known_at'],where)
            for candidate in e.get('candidates') or []:geometry(candidate.get('profile'),row['known_at'],where)
        for box in chart.get('macro_ranges',[]):
            where=period+':macro:'+box['known_at']
            check(instant(box['observed_from'])<instant(box['known_at'])<=instant(box['end_at'])<=end,'macro_time_order',where)
            check(box.get('breakout_basis')=='liquidity','macro_exit_basis',where)
            geometry(box.get('profile'),box['known_at'],where)
            oscillation(box.get('oscillation'),box['known_at'],where)
            fit(box.get('score'),where);fit(box.get('confirmation_score'),where+':formation')
        for box in chart.get('structural_ranges',[]):
            counts['structural_candidates']+=1
            where=period+':structural:'+box['first_observed_at']
            check(instant(box['observed_from'])<instant(box['first_observed_at'])<=instant(box['end_at'])<=end,'structural_time_order',where)
            check(box.get('confirmed') is False and box.get('score_included') is False,'structural_candidate_promotion',where)
            check(box['observed_low']<box['observed_high'] and box['low']<box['high'],'structural_boundary_order',where)
            check(box['metrics']['upper_visits']>=2 and box['metrics']['lower_visits']>=2 and all(box['checks'].values()),'structural_boundary_tests',where)
            check(not box['gaps'] or '跨时段间隔内价格覆盖未验证' in box['missing'],'structural_gap_disclosure',where)
            oscillation(box['metrics'].get('oscillation'),box['first_observed_at'],where)
            if box.get('geometry'):geometry({'geometry':box['geometry']},box['first_observed_at'],where)
            display=box.get('display_geometry')
            if display and display.get('extension_basis'):
                check(display['extension_basis']=='frozen_rails_to_observed_closed_bar' and display.get('projected') is False,
                      'channel_extension_basis',where)
                check(instant(display['known_at'])==instant(display['observed_until'])<=instant(box['end_at']),
                      'channel_extension_known_at',where)
                for point in display['frame']:
                    check(instant(point['time'])<instant(display['known_at']),'channel_extension_future',where)
                for side,bound in [('upper','high'),('lower','low')]:
                    for point in display[side]:
                        index=sum(instant(box['observed_from'])<=instant(b['time'])<=instant(point['time']) for b in bars)-1
                        expected=box[bound]+box['slope_per_bar']*index
                        check(abs(point['price']-expected)<1e-6,'channel_extension_refitted',where)
            for event in box['metrics'].get('edge_tests',[]):
                check(instant(box['observed_from'])<=instant(event['bar_open_at'])<instant(event['known_at'])<=instant(box['first_observed_at']),
                      'structural_edge_test_causality',where)
        for box in chart.get('geometric_ranges',[]):
            counts['geometric_candidates']+=1;where=period+':geometric:'+box['id']
            check(instant(box['observed_from'])<instant(box['first_observed_at'])<=instant(box['end_at'])<=end,'long_geometry_time_order',where)
            check(box.get('confirmed') is False and box.get('score_included') is False,'long_geometry_promotion',where)
            minimum=4 if box['window']<48 and period=='M15' else 12
            check(box['geometry'].get('validated') is True and box['geometry']['validation']['overlap_bars']>=minimum,'long_geometry_coverage',where)
            geometry({'geometry':box['geometry']},box['first_observed_at'],where)
            oscillation(box['metrics'].get('oscillation'),box['first_observed_at'],where)
        for box in chart.get('intraday_structures',[]):
            where=period+':intraday:'+box['id']
            check(period=='H1' and box.get('source_period')=='M15' and box.get('projection_confirmed') is False and
                  box.get('confirmed') is False and box.get('score_included') is False,'intraday_h1_promotion',where)
            names={'range':'consolidations','structural':'structural_ranges','geometric':'geometric_ranges'}
            source=next((b for b in charts.get('M15',{}).get(names.get(box.get('source_kind'),''),[]) if b['id']==box.get('source_id')),None)
            check(source is not None,'intraday_source_missing',where)
            if source:
                check(box.get('source_confirmed') is (box.get('source_kind')=='range' and source.get('confirmed') is not False),
                      'intraday_source_qualification_changed',where)
                terminal=any(word in source.get('status','') for word in ('突破条件触发','中止','结束','离开','失效'))
                if terminal:check(box.get('active') is False,'intraday_terminal_claims_active',where)
                check(box['first_observed_at']==(source.get('first_observed_at') or source['known_at']) and box['end_at']==source['end_at'],
                      'intraday_source_time_changed',where)
                check(box.get('display_geometry')==source.get('display_geometry'),'intraday_source_geometry_changed',where)
        for target in chart.get('reference_targets',[]):
            where=period+':reference:'+target['id']
            check(target.get('confirmed') is False and target.get('role')=='historical_review_bookmark','reference_promoted_to_confirmation',where)
            if target.get('matched'):
                kind=target.get('range_kind','structural')
                box=next((b for b in chart.get('consolidations' if kind=='range' else 'geometric_ranges' if kind=='geometric' else 'intraday_structures' if kind=='intraday' else 'structural_ranges',[]) if b['id']==target['range_id']),None)
                check(box is not None,'reference_range_missing',where)
                if box:
                    low,high=(box['liquidity_low'],box['liquidity_high']) if kind=='range' else (box['projection_low'],box['projection_high']) if kind=='intraday' else (box['observed_low'],box['observed_high'])
                    check(target['actual_low']==low and target['actual_high']==high,'reference_actual_bounds_changed',where)
                    check(bars[0]['time']<=box['observed_from']<=bars[-1]['time'],'reference_history_unavailable',where)
        for review in chart.get('reference_reviews',[]):
            check(review.get('confirmed') is False and review.get('score_included') is False and review.get('red_box_boundaries_verified') is False,
                  'reference_review_promoted',period+':reference_image:'+str(review['image_id']))
            if review.get('native_sequence_currently_verified'):
                from .reference_alignment import segment_digest
                segment=[b for b in bars if instant(review['first_bar_open_at'])<=instant(b['time'])<=instant(review['last_bar_open_at'])]
                check(len(segment)==review['sequence_bar_count'] and segment_digest(segment)==review['native_segment_sha256'],
                      'reference_native_sequence_changed',period+':reference_image:'+str(review['image_id']))
        for kind in ('current_history','macro_history','swing_history','structural_history','geometric_history'):
            for event in chart.get(kind,[]):
                check(event.get('confirmed_bar_only') is True and instant(event['known_at'])<=end,'history_not_closed',period+':'+kind)
                if kind=='swing_history':
                    check(event.get('confirmed') is False and event.get('score_included') is False,'swing_history_promotion',period)
        for row in chart.get('swing_rows',[]):
            check(row.get('confirmed_bar_only') is True and instant(row['known_at'])<=end,'swing_observation_not_closed',period)
            c=row.get('candidate')
            if not c:continue
            counts['swing_candidates']+=1
            check(instant(c['known_at'])==instant(row['known_at'])<=end,'swing_candidate_time',period)
            check(c.get('confirmed') is False and c.get('score_included') is False,'swing_candidate_promotion',period)
            for p in c['pivots']:
                check(instant(p['known_at'])<=instant(c['known_at']) and (instant(p['known_at'])-instant(p['time'])).total_seconds()>=2*seconds,'swing_pivot_causality',period)
        r=(payload.get('current_consolidation') or {}).get(period)
        check(bool(r),'current_report_present',period)
        if not r:continue
        check(instant(r['known_at'])==end,'current_report_time',period)
        evidence=(chart.get('phase_rows') or [{}])[-1].get('consolidation_evidence') or {}
        frozen=evidence.get('range') or evidence.get('ended')
        if frozen:
            from .current_consolidation import CHECK_NAMES
            check(r.get('range')==frozen,'current_frozen_range_source',period)
            check(r.get('range_state')==('active' if evidence.get('range') else 'ended')
                  and r.get('checks_basis')=='first_confirmation'
                  and r.get('checks_known_at')==frozen['known_at'],'current_frozen_evidence_scope',period)
            check(r.get('checks')=={CHECK_NAMES.get(k,k):v for k,v in frozen['checks'].items()}
                  and r.get('profile')==frozen.get('profile'),'current_frozen_evidence_source',period)
        overlay=chart.get('current_candidate')
        check(bool(overlay)==(r.get('verdict')=='candidate'),'current_candidate_visibility',period)
        if overlay:
            check(overlay.get('confirmed') is False and overlay.get('score_included') is False
                  and overlay.get('confirmed_bar_only') is True,'current_candidate_promotion',period)
            check(instant(overlay['known_at'])==instant(overlay['end_at'])==end
                  and instant(overlay['observed_from'])<end,'current_candidate_time',period)
            check(overlay.get('candidate_basis')==r.get('candidate_basis'),'current_candidate_basis',period)
            check(isfinite(overlay['low']) and isfinite(overlay['high']) and overlay['low']<overlay['high'],
                  'current_candidate_bounds',period)
            geometry(overlay.get('profile'),overlay['known_at'],period+':current_candidate')
        if r.get('candidate_basis')=='swing_balance':
            c=r.get('candidate_evidence') or {}
            check(r.get('verdict')=='candidate' and c.get('confirmed') is False and c.get('score_included') is False
                  and c.get('qualified') is True and bool(c.get('checks')) and all(v is True for v in c['checks'].values())
                  and instant(c['known_at'])==end,'swing_current_contract',period)
        if r.get('candidate_basis')=='body_balance':
            from .current_consolidation import BODY_CANDIDATE_REQUIRED, CHECK_NAMES, PARAMETERS as CURRENT_PARAMETERS
            checks=r.get('checks') or {}
            check(all(checks.get(CHECK_NAMES[k]) is True for k in BODY_CANDIDATE_REQUIRED)
                  and sum(v is True for v in checks.values())>=CURRENT_PARAMETERS['candidate_checks_min'],
                  'body_candidate_prerequisites',period)
            check(bool(overlay and r.get('candidate_window')==overlay.get('window')),'body_candidate_window_mismatch',period)
            evidence=(chart.get('phase_rows') or [{}])[-1].get('consolidation_evidence') or {}
            source=next((c for c in evidence.get('candidates') or [] if (c.get('metrics') or {}).get('window')==r.get('candidate_window')),None)
            check(bool(source and overlay and source['lo']==overlay['low'] and source['hi']==overlay['high']
                       and checks=={CHECK_NAMES.get(k,k):v for k,v in source['checks'].items()}),'body_candidate_source_mismatch',period)
        body_observation=r.get('body_candidate_observation')
        if body_observation:
            o=body_observation;forming=(payload.get('forming') or {}).get(period) or {}
            check(r.get('availability')=='live' and r.get('verdict')=='candidate' and r.get('candidate_basis')=='body_balance',
                  'body_observation_availability',period)
            check(o.get('confirmed') is False and o.get('score_included') is False and o.get('boundaries_frozen') is False,
                  'body_observation_promotion',period)
            check(instant(o['known_at'])==instant(o['bar_open_at'])==end,'body_observation_time',period)
            source=next((c for c in chart['phase_rows'][-1]['consolidation_evidence'].get('candidates',[])
                         if (c.get('metrics') or {}).get('window')==r.get('candidate_window')),None)
            check(bool(source and o.get('window')==r.get('candidate_window') and
                       (o.get('low'),o.get('high'),o.get('observed_low'),o.get('observed_high'))==
                       (source.get('lo'),source.get('hi'),source.get('liquidity_lo'),source.get('liquidity_hi'))),
                  'body_observation_bounds',period)
            check(forming.get('forming') is True and o.get('price')==forming.get('close') and
                  o.get('boundary_basis')=='latest_closed_body_candidate','body_observation_price_source',period)
        if r.get('actionable_current'):
            q=payload.get('quote') or {}
            source=q.get('market_source') or {}
            check(source.get('status')=='verified' and str(source.get('company','')).strip().casefold()=='trademax global limited'
                  and str(source.get('server','')).strip().casefold().startswith('trademaxglobal-')
                  and source.get('symbol')=='XAUUSD','invalid_live_source',period)
            bid=q.get('bid');ask=q.get('ask');epoch=q.get('raw_epoch')
            valid_quote=all(isinstance(v,(int,float)) and not isinstance(v,bool) and isfinite(v) for v in (bid,ask,epoch))
            valid_quote=bool(valid_quote and 0<bid<=ask and epoch>0 and float(epoch).is_integer())
            check(valid_quote,'invalid_live_quote',period)
            check(r.get('availability')=='live' and r.get('bar_sync',{}).get('status')=='aligned','live_health_contract',period)
            check(not payload.get('data_revision_pending'),'revision_pending_claims_live',period)
        for layer in (r,r.get('macro_context') or {}):
            obs=layer.get('forming_observation')
            if obs:
                check(obs.get('confirmed') is False and obs.get('score_included') is False,'forming_confirmation_or_score',period)
                check(instant(obs['bar_open_at'])==end,'forming_observation_alignment',period)
        sources={box['id']:box for field in ('structural_current','geometric_current') for box in chart.get(field) or []}
        for observation in r.get('candidate_observations') or []:
            source=sources.get(observation.get('range_id'))
            check(bool(source and source.get('active') is True and instant(source['end_at'])==end),'candidate_observation_source',period)
            check(r.get('availability')=='live','unavailable_candidate_observation',period)
            check(observation.get('confirmed') is False and observation.get('score_included') is False,'candidate_observation_promotion',period)
            obs=observation.get('forming_observation') or {}
            check(obs.get('confirmed') is False and obs.get('score_included') is False,'candidate_forming_promotion',period)
            check(instant(observation['known_at'])==instant(obs['bar_open_at'])==end,'candidate_observation_alignment',period)
    current={p:{k:r.get(k) for k in ('availability','label','known_at')} for p,r in (payload.get('current_consolidation') or {}).items()}
    live_ready=set(current)=={'H1','M15'} and all(r['availability']=='live' for r in current.values())
    return dict(audit_version='live_model_acceptance_v1',passed=not issues,live_ready=live_ready,current=current,model_revision=payload.get('model_revision'),server_now=payload.get('server_now'),quote_raw_time=(payload.get('quote') or {}).get('raw_time'),market_source=payload.get('market_source'),status=payload.get('status'),freeze_integrity=integrity,counts=counts,issues=issues,
                scope='单次模型快照结构验收；冻结检查仅涵盖本次返回的历史观察；不证明市场识别准确率或盈利能力')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--url',default='http://127.0.0.1:8773/api/state');parser.add_argument('--output',type=Path)
    args=parser.parse_args(argv)
    try:
        with urlopen(args.url,timeout=20) as response:payload=json.load(response)
        result=audit_payload(payload)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        result=dict(audit_version='live_model_acceptance_v1',passed=False,live_ready=False,
                    issues=[dict(code='snapshot_unavailable_or_invalid',detail=str(exc))],
                    scope='本次快照读取或结构解析失败，不能沿用上次验收结果')
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False));return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
