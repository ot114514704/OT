"""Causal price breaches of confirmed swing references.

This is an independent research definition, not BOS, CHoCH, MSS, liquidity
sweep qualification, or a reproduction of the user's compiled SMC indicator.
Wick and close are independent first-observation rules. An OHLC bar does not
reveal the intrabar order when several references are breached together.
"""
from math import isfinite

from .core import instant, visible


DEFINITION = 'confirmed_swing_independent_wick_close_v1'
KINDS = ('wick_cross', 'close_break')


def _crosses(bar, side, price, kind):
    value = (bar.high if side == 'high' else bar.low) if kind == 'wick_cross' else bar.close
    return value > price if side == 'high' else value < price


def _bar_fields(bar):
    return {
        'bar_open_at': instant(bar.time).isoformat(),
        'bar_closed_at': bar.closed_at.isoformat(),
        'bar_open_price': bar.open,
        'bar_high': bar.high,
        'bar_low': bar.low,
        'bar_close': bar.close,
    }


def observe_structure_breaks(bars, asof, records=None):
    """Observe each reference/kind once, only using complete homogeneous bars.

    ``records`` may contain future hierarchy records: known_at > asof records
    are ignored. If omitted, hierarchy is computed locally. Supplied records
    must include the full bar context containing their pivot, run start and
    confirmation; their hierarchy qualification is supplied by the caller.

    For each kind separately, a crossing on a bar with open > pivot_at and
    close <= reference.known_at is stale_on_activation. It consumes that rule
    without creating a retrospective event. Thus a prior wick breach does not
    suppress a later first close breach. Such a close event explicitly carries
    prior_wick_before_activation=True, and is not described as a fresh sweep.

    Post-activation bars must open >= reference.known_at. Every event is
    observed at bar close, including wick observations. ``wick_cross`` means
    the high/low strictly exceeds the level; it does not require the close to
    return inside, so the same bar can also produce ``close_break``. References
    never carry across missing bars. Multiple references and kinds can share
    observed_at; sorting the output does not establish their intrabar order.

    eligible_refs records eligibility *at activation*, not a claim that a rule
    remains unconsumed now. Both activation lists and events are append-stable.
    """
    cutoff = instant(asof)
    past = visible(bars, cutoff)
    result = {
        'asof': cutoff.isoformat(),
        'definition': DEFINITION,
        'qualification': 'observation_only',
        'events': [],
        'stale_refs': [],
        'eligible_refs': [],
    }
    if records is None:
        # structure.multi_frame_structure may call this module with its own
        # records; importing only for the standalone path avoids a cycle.
        from .structure import hierarchy
        records = hierarchy(past, cutoff)
    known_records = [r for r in records if instant(r['known_at']) <= cutoff]
    if not past:
        if known_records:
            raise ValueError('Confirmed references require their complete bar context')
        return result
    seconds = past[0].seconds
    if any(b.seconds != seconds for b in past):
        raise ValueError('One homogeneous timeframe required')
    if any(b.time <= a.time for a, b in zip(past, past[1:])):
        raise ValueError('Duplicate or out-of-order bars')

    runs = [[]]
    for bar in past:
        if runs[-1] and bar.time != runs[-1][-1].closed_at:
            runs.append([])
        runs[-1].append(bar)
    contexts = {}
    for run in runs:
        contexts[instant(run[0].time)] = (
            run,
            {instant(b.time): i for i, b in enumerate(run)},
            {b.closed_at: i for i, b in enumerate(run)},
        )

    seen_ids = set()
    for reference in known_records:
        ref_id = reference['id']
        if not isinstance(ref_id, str) or not ref_id or ref_id in seen_ids:
            raise ValueError('Unique nonempty reference IDs required')
        seen_ids.add(ref_id)
        side, tier, price = reference['side'], reference['tier'], reference['price']
        if side not in ('high', 'low') or tier not in ('ST', 'IT', 'LT'):
            raise ValueError('Expected a high/low ST, IT or LT reference')
        if reference['timeframe_seconds'] != seconds or not isfinite(price):
            raise ValueError('Reference timeframe/price does not match bar context')
        pivot_at = instant(reference['pivot_at'])
        known_at = instant(reference['known_at'])
        run_start = instant(reference['run_start'])
        context = contexts.get(run_start)
        if context is None:
            raise ValueError('Reference run start is outside supplied bar context')
        run, opens, closes = context
        pivot_index, confirmation_index = opens.get(pivot_at), closes.get(known_at)
        if pivot_index is None or confirmation_index is None or confirmation_index < pivot_index:
            raise ValueError('Reference pivot and confirmation must belong to the same run')
        if getattr(run[pivot_index], side) != price:
            raise ValueError('Reference price must equal the pivot bar extreme')
        base = {
            'reference_id': ref_id,
            'reference_tier': tier,
            'reference_side': side,
            'reference_price': price,
            'reference_pivot_at': pivot_at.isoformat(),
            'reference_known_at': known_at.isoformat(),
            'timeframe_seconds': seconds,
            'run_start': run_start.isoformat(),
            'direction': 'up' if side == 'high' else 'down',
            'definition': DEFINITION,
            'qualification': 'observation_only',
        }

        # Do not turn an earlier breach into a later confirmation-time trade.
        pre_activation = run[pivot_index+1:confirmation_index+1]
        stale = {
            kind: next((bar for bar in pre_activation
                        if _crosses(bar, side, price, kind)), None)
            for kind in KINDS
        }
        prior_wick = stale['wick_cross'] is not None
        remaining = set()
        for kind in KINDS:
            activation = {
                **base, 'kind': kind, 'observed_at': known_at.isoformat(),
                'prior_wick_before_activation': prior_wick,
            }
            if stale[kind] is not None:
                result['stale_refs'].append({
                    **activation, **_bar_fields(stale[kind]),
                    'status': 'stale_on_activation',
                })
            else:
                result['eligible_refs'].append({
                    **activation, 'status': 'eligible_on_activation',
                })
                remaining.add(kind)

        # Contiguous run: bar after the confirmation bar opens at known_at.
        for index in range(confirmation_index+1, len(run)):
            if not remaining:
                break
            bar = run[index]
            for kind in KINDS:
                if kind in remaining and _crosses(bar, side, price, kind):
                    result['events'].append({
                        **base, **_bar_fields(bar),
                        'id': f'{ref_id}:{kind}:{bar.closed_at.isoformat()}',
                        'kind': kind, 'observed_at': bar.closed_at.isoformat(),
                        'prior_wick_before_activation': prior_wick,
                    })
                    remaining.remove(kind)

    for key in ('events', 'stale_refs', 'eligible_refs'):
        result[key].sort(key=lambda x: (
            instant(x['observed_at']), x['reference_id'], KINDS.index(x['kind'])))
    return result
