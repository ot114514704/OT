"""Locate requested missing regions in existing, independent model evidence.

These are review bookmarks, not new confirmations or hand-inserted price bars.
The approximate screenshot levels remain separate from native detected bounds.
"""
import json
from pathlib import Path
from .core import instant
from .reference_alignment import attach_reference_reviews

TARGETS=json.loads((Path(__file__).resolve().parents[1]/'research/reference_targets.json').read_text('utf-8'))['targets']


def target_pool(chart,kind):
    return chart.get('consolidations' if kind=='range' else 'geometric_ranges' if kind=='geometric' else 'intraday_structures' if kind=='intraday' else 'structural_ranges',[])


def target_bounds(box,kind):
    return (box['liquidity_low'],box['liquidity_high']) if kind=='range' else (box['projection_low'],box['projection_high']) if kind=='intraday' else (box['observed_low'],box['observed_high'])


def attach_targets(charts):
    attach_reference_reviews(charts)
    for c in charts.values():c['reference_targets']=[]
    for target in TARGETS:
        chart=charts.get(target['period'])
        if not chart:continue
        start=instant(target['start']);end=instant(target['end']);kind=target.get('range_kind','structural')
        def compatible(b):
            if kind=='range':
                p=b.get('profile') or {};g=p.get('geometry') or {}
                return target['shape'] in p.get('tags',[]) and (not target.get('geometry_subtype') or g.get('validated') and g.get('subtype')==target['geometry_subtype'])
            if kind=='geometric':
                g=b.get('geometry') or {}
                return b['shape']==target['shape'] and g.get('validated') and (not target.get('geometry_subtype') or g.get('subtype')==target['geometry_subtype'])
            if kind=='intraday':return b['shape']==target['shape']
            return b['shape']==target['shape']
        matches=[b for b in target_pool(chart,kind) if compatible(b)
                 and start<=instant(b['observed_from'])<instant(b.get('first_observed_at',b.get('known_at')))<=end]
        def quality(b):
            # Prefer a physically relevant price span; never overwrite the
            # detector's boundaries with the screenshot's approximate scale.
            low,high=target_bounds(b,kind)
            overlap=max(0,min(high,target['reference_high'])-max(low,target['reference_low']))
            distance=abs((high+low)/2-(target['reference_high']+target['reference_low'])/2)
            return (overlap-distance*.2,b['window'])
        def price_related(b):
            low,high=target_bounds(b,kind);ref_width=target['reference_high']-target['reference_low'];width=high-low
            overlap=max(0,min(high,target['reference_high'])-max(low,target['reference_low']))
            distance=abs((high+low)/2-(target['reference_high']+target['reference_low'])/2)
            return min(width,ref_width)>0 and overlap/min(width,ref_width)>=.6 and distance<=.5*max(width,ref_width)
        matches=[b for b in matches if price_related(b)]
        box=max(matches,key=quality,default=None)
        report={**target,'range_kind':kind,'matched':bool(box),'role':'historical_review_bookmark','alignment_status':'approximate','confirmed':False,
                'range_id':box['id'] if box else None,
                'reason':target.get('matched_note','按图片位置找到独立模型证据；红框起止尚非逐像素对齐，当前状态与确认资格独立判断') if box else target.get('missing_reason','本次原生样本未匹配到对应结构，仍待核对，未补造确认')}
        if box:
            low,high=target_bounds(box,kind)
            report.update(observed_from=box['observed_from'],first_observed_at=box.get('first_observed_at',box.get('known_at')),end_at=box['end_at'],
                          actual_low=low,actual_high=high,status=box['status'],window=box['window'],evidence_confirmed=kind=='range')
        chart['reference_targets'].append(report)
    return charts
