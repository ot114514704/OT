"""Causal, context-relative pullback episodes, separate from native local phases.

Prices describe observations, not participant intent. Numeric thresholds are
versioned hypotheses. A recognition timestamp never moves backwards.
"""
from copy import deepcopy
from collections import Counter
from statistics import mean
from .retracement_score import score_retracement, POLICY as SCORE_POLICY

VERSION = 'ipda_context_pullback_episodes_v1'
PARAMETERS = dict(start_depth_atr=.7, start_counter_closes=2,
                  resume_consecutive_closes=2, small_body_ratio=1., overlap=.5)
SOURCE = 'research/price_courses/retracement_user_rules.json'


def build_retracement_episodes(payload, evidence):
    phases = {p['bar_open_at']: p for p in payload['phases']}
    bars = {b['time']: b for b in payload.get('evidence_bars', []) + payload['bars']}
    rows=[]; prior=[]; leg=None; episode=None; identity=None; blocked=False
    for r in evidence['rows']:
        b=bars[r['bar_open_at']]; p=phases[b['time']]; d=r['reference_direction']
        key=r['reference_id']; end_reason=None; ended=None
        gap=bool(prior and prior[-1]['closed_at']!=b['time'])
        changed=key!=identity
        if gap or changed or p['phase']=='consolidation' or r['checks']['structure_intact'] is False:
            end_reason=('data_gap' if gap else 'parent_changed' if changed else
                        'consolidation' if p['phase']=='consolidation' else 'protection_broken')
            if episode:
                ended=deepcopy(episode);ended.update(status=end_reason,resolved_known_at=b['closed_at'])
            episode=None;leg=None
            if gap or changed: prior=[];blocked=False
            if r['checks']['structure_intact'] is False: blocked=True
        identity=key
        atr=p.get('metrics',{}).get('atr14_prior') or 0
        body=abs(b['close']-b['open']); span=max(b['high']-b['low'],1e-9)
        displacement=bool(d in (-1,1) and atr and (b['close']-b['open'])*d>=.65*atr and body/span>=.6)
        before=prior[-6:]
        breakout=bool(d in (-1,1) and len(before)==6 and
            (b['close']>max(a['high'] for a in before) if d==1 else b['close']<min(a['low'] for a in before)))
        net3=(b['close']-prior[-2]['open'])*d if len(prior)>=2 and d in (-1,1) else 0
        path=sum(abs(a['close']-a['open']) for a in prior[-2:]+[b])
        drive=bool(atr and breakout and (displacement or (net3>=atr and net3/max(path,1e-9)>=.6)))
        native_event=r.get('native_cisd')
        counter_cisd=bool(native_event and native_event['direction']==-d) if d in (-1,1) else False
        label=p['phase']; direction=p.get('direction',0); state='no_preceding_expansion'
        snapshot=None; macro=r['protection_source']=='prior_validated_H1_channel'
        if p['phase']=='consolidation': state='consolidation'
        elif blocked:
            state='structure_challenge'
            label=p['phase'] if not macro and p['phase']=='reversal' else 'undetermined'
        elif d in (-1,1) and atr:
            if leg and not episode:
                depth=(leg['extreme']-b['close'])*d
                moves=prior[-2:]+[b]
                counters=sum((a['close']-a['open'])*d<0 for a in moves)
                if depth>=.7*atr and (counter_cisd or (counters>=2 and (b['close']-b['open'])*d<0)):
                    # Anchor geometry at the prior known extreme, but expose it
                    # only at this close. Never backfill phase classifications.
                    observed=[a for a in prior if a['time']>=leg['extreme_at']]+[b]
                    episode=dict(id=key+':R:'+b['time'],parent_id=key,direction=-d,
                        primary_direction=d,start_at=leg['extreme_at'],first_known_at=b['closed_at'],
                        end_at=b['closed_at'],known_at=b['closed_at'],low=min(a['low'] for a in observed),
                        high=max(a['high'] for a in observed),resume_level=leg['extreme'],
                        protected_price=r['protected_price'],expansion=deepcopy(leg),
                        counter_cisd_at=b['closed_at'] if counter_cisd else None,
                        resume_closes=0,bars=0,body_sum=0,overlap_sum=0,wick_count=0,
                        pd_contacts=[],status='observing',fvg_contacts=[])
            if episode:
                episode['bars']+=1; episode['body_sum']+=body
                if prior:
                    a=prior[-1]
                    episode['overlap_sum']+=max(0,min(a['high'],b['high'])-max(a['low'],b['low']))/max(a['high']-a['low'],span)
                episode['wick_count']+=int((span-body)/span>=.5)
                episode.update(end_at=b['closed_at'],known_at=b['closed_at'],
                    low=min(episode['low'],b['low']),high=max(episode['high'],b['high']))
                if counter_cisd and not episode['counter_cisd_at']:episode['counter_cisd_at']=b['closed_at']
                for z in r['pd_contacts']:
                    if z not in episode['pd_contacts']:episode['pd_contacts'].append(deepcopy(z))
                episode['fvg_contacts']=[z for z in episode['pd_contacts'] if z['kind']=='FVG']
                ratio=episode['body_sum']/episode['bars']/max(leg['body_mean'],1e-9)
                overlap=episode['overlap_sum']/episode['bars']
                distance=abs(b['close']-episode['resume_level'])
                speed=distance/episode['bars']/max(leg['speed'],1e-9)
                breached_pd=any((b['close']-z['low'])*d<0 if d==1 else b['close']>z['high'] for z in episode['pd_contacts'])
                counter_force=bool(counter_cisd and body>=atr and body/span>=.6)
                risk=counter_force and breached_pd
                episode['resume_closes']=episode['resume_closes']+1 if (b['close']-episode['resume_level'])*d>0 else 0
                strict_end=bool(r['patterns']['sfp_cisd'] and r['checks']['pd_respected'])
                state=('counter_displacement_warning' if risk else 'end_sequence_observed' if strict_end else
                       'pd_repair' if r['pd_contacts'] else 'retracement_active' if episode['counter_cisd_at'] else 'retracement_candidate')
                episode.update(status=state,body_ratio=round(ratio,4),speed_ratio=round(speed,4),
                    overlap=round(overlap,4),wick_fraction=round(episode['wick_count']/episode['bars'],4),
                    depth_fraction=round(distance/max(abs(leg['extreme']-leg['origin_price']),1e-9),4))
                label='retracement';direction=-d
                # Two closes through the old extreme describe actual resumption,
                # but never fabricate a missing SFP/CISD confirmation sequence.
                if strict_end or episode['resume_closes']>=2:
                    state='end_sequence_observed' if strict_end else 'resumed_without_full_sequence'
                    episode['status']=state;episode['resolved_known_at']=b['closed_at']
                    ended=deepcopy(episode); snapshot=deepcopy(episode)
                    episode=None;label='expansion';direction=d;leg=None
                else:snapshot=deepcopy(episode)
            elif leg:state='expansion_context'
            elif label=='retracement' or (macro and label=='reversal'):
                # Local countertrend labels remain in native_phase, not promoted
                # into macro reversal or an ungrounded retracement.
                label='undetermined';state='awaiting_expansion_reference'
            if not episode and drive:
                seq=prior[-2:]+[b]
                if not leg:
                    origin=min(a['low'] for a in seq) if d==1 else max(a['high'] for a in seq)
                    leg=dict(id=key+':D:'+b['time'],parent_id=key,direction=d,start_at=seq[0]['time'],
                        known_at=b['closed_at'],origin_price=origin,extreme=b['high'] if d==1 else b['low'],
                        extreme_at=b['time'],body_mean=mean(abs(a['close']-a['open']) for a in seq),
                        speed=abs(b['close']-seq[0]['open'])/len(seq),structure_break_at=b['closed_at'])
                if label=='undetermined':label='expansion';direction=d
            if leg and not episode and (b['high']>leg['extreme'] if d==1 else b['low']<leg['extreme']):
                leg['extreme']=b['high'] if d==1 else b['low'];leg['extreme_at']=b['time']
        checks=dict(prior_expansion=bool(snapshot or leg),structure_intact=r['checks']['structure_intact'],
            counter_cisd=bool(snapshot and snapshot['counter_cisd_at']),
            weak_body=None if not snapshot else snapshot['body_ratio']<1,
            slow_speed=None if not snapshot else snapshot['speed_ratio']<1,
            overlap=None if not snapshot else snapshot['overlap']>=.5,
            pd_contact=bool(snapshot and snapshot['pd_contacts']),pd_respected=r['checks']['pd_respected'],
            sfp=r['checks']['sfp'],cisd=r['checks']['cisd'],displacement=r['checks']['directional_displacement'],
            h1_alignment=r['checks']['h1_alignment'],dol=None,session=None,volume=None,micro_confirmation=None)
        rows.append(dict(bar_open_at=b['time'],known_at=b['closed_at'],phase=label,direction=direction,
            native_phase=p['phase'],state=state,episode=snapshot,ended=ended,end_reason=end_reason,
            checks=checks,missing=[k for k,v in checks.items() if v is not True]))
        prior.append(b)
    return dict(version=VERSION,parameters=PARAMETERS,rows=rows,
        summary=dict(Counter(r['state'] for r in rows)),source=SOURCE,
        policy='先有位移突破，再观察逆向回调；短暂顺势棒不断段。PD＋SFP＋顺向CISD为本周期结束组合；仅延伸旧极值单列缺项。盘整、缺棒、换背景、保护位破坏分开。深度超过70%仅提示，不自动宣判反转。')


def refine_retracement_phases(payload, report):
    model=build_retracement_episodes(payload,report); payload['retracement_episodes']=model
    by_time={r['bar_open_at']:r for r in model['rows']}
    evidence={r['bar_open_at']:r for r in report['rows']}
    closes={b['time']:b['close'] for b in payload['bars']}
    for p in payload['phases']:
        r=by_time[p['bar_open_at']];ev=evidence[p['bar_open_at']]
        p['native_observation']={k:deepcopy(p[k]) for k in ('phase','direction','reason','behavior','status') if k in p}
        p['phase']=r['phase'];p['direction']=r['direction'];p['retracement_state']=r['state']
        if r['episode'] or r['phase']!=r['native_phase']:
            p['reason']='以事前保护位和已观察扩张为背景，逐棒维护完整回调；状态：'+r['state']+'。'
            p['behavior']='回调中的短暂顺势波动不断段；盘整与结构挑战单独处理'
            p['status']='contextual_observation_not_trade_confirmation'
        ev['episode_state']=r['state'];ev['episode']=r['episode'];ev['sop_checks']=r['checks'];ev['sop_missing']=r['missing']
        score=score_retracement(r,{**ev,'current_close':closes[r['bar_open_at']]})
        ev['evidence_score']=deepcopy(score)
        if p.get('fit_scores'):
            old=p['fit_scores']['by_phase']['retracement']
            p['fit_scores']['by_phase']['retracement']={**score,
                'geometry_before_sequence':deepcopy(old.get('geometry_before_sequence',old))}
    payload['retracement_score_policy']=deepcopy(SCORE_POLICY)
    return payload
