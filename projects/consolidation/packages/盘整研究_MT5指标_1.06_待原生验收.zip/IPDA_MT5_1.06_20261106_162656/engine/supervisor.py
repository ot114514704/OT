"""Local, user-session supervisor for the read-only 8773 market reader."""
import argparse
import ctypes
import hashlib
import json
import logging
from math import isfinite
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from urllib.request import urlopen

ROOT=Path(__file__).resolve().parent
WORK=ROOT/'work'/'live_8773'
STATUS=WORK/'supervisor.json'
STOP=WORK/'stop.request'
RESTART=WORK/'restart.request'
URL='http://127.0.0.1:8773/api/runtime'
TIMEOUT=120


def assess(info,owned_pid,now,supervisor_pid=None):
    if not isinstance(info,dict):return 'foreign_service'
    if info.get('service')!='ipda_consolidation' or Path(info.get('project_root','')).resolve()!=ROOT:
        return 'foreign_service'
    if owned_pid is None:return 'external_service'
    # On Windows the venv pythonw launcher can leave a second interpreter
    # process serving the socket.  It still carries our supervisor marker;
    # accept that exact marker while retaining the project-root/service checks.
    if info.get('process_id')!=owned_pid and info.get('supervisor_pid')!=str(supervisor_pid):return 'foreign_service'
    heartbeat=info.get('worker_heartbeat_at')
    if not (isinstance(heartbeat,(int,float)) and not isinstance(heartbeat,bool) and isfinite(heartbeat) and 0<=now-heartbeat<=TIMEOUT):return 'worker_unresponsive'
    if info.get('analysis_running') is True:
        started=info.get('analysis_started_at')
        if not (isinstance(started,(int,float)) and not isinstance(started,bool) and isfinite(started) and 0<=now-started<=TIMEOUT):return 'model_unresponsive'
    return 'healthy'


def port_free():
    try:
        with socket.socket() as sock:sock.bind(('127.0.0.1',8773))
        return True
    except OSError:return False


def stop_child(child):
    # Popen retains the exact process handle; never terminate an adopted listener.
    if child is not None and child.poll() is None:
        child.terminate()
        try:child.wait(timeout=10)
        except subprocess.TimeoutExpired:child.kill();child.wait(timeout=10)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--stop',action='store_true');parser.add_argument('--restart',action='store_true');args=parser.parse_args()
    WORK.mkdir(parents=True,exist_ok=True)
    if args.stop:STOP.write_text(str(time.time()),encoding='utf-8');return 0
    if args.restart:RESTART.write_text(str(time.time()),encoding='utf-8');return 0
    if os.name!='nt':raise RuntimeError('The installed supervisor requires Windows')
    from ctypes import wintypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.CreateMutexW.argtypes=[ctypes.c_void_p,wintypes.BOOL,wintypes.LPCWSTR];kernel.CreateMutexW.restype=wintypes.HANDLE
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    handle=kernel.CreateMutexW(None,False,'Local\\IPDA8773-'+hashlib.sha256(str(ROOT).casefold().encode()).hexdigest()[:20])
    if not handle:raise ctypes.WinError(ctypes.get_last_error())
    if ctypes.get_last_error()==183:kernel.CloseHandle(handle);return 0
    log=logging.getLogger('ipda_supervisor');log.setLevel(logging.INFO)
    handler=RotatingFileHandler(WORK/'supervisor.log',maxBytes=2_000_000,backupCount=2,encoding='utf-8');log.addHandler(handler)
    child=None;stream=None;started=0;failures=0;restarts=0;previous=None;next_start=0
    def publish(state,detail=''):
        nonlocal previous
        payload=dict(supervisor_pid=os.getpid(),updated_at=time.time(),state=state,detail=detail,
                     child_pid=child.pid if child and child.poll() is None else None,restarts=restarts)
        temp=STATUS.with_suffix('.tmp');temp.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(STATUS)
        if (state,detail)!=previous:log.info(json.dumps(payload,ensure_ascii=False));previous=(state,detail)
    try:
        while not STOP.exists():
            now=time.time()
            if RESTART.exists():
                RESTART.unlink()
                if child:
                    publish('restarting','local maintenance request');stop_child(child);child=None
                    if stream:stream.close();stream=None
                    next_start=now;failures=0
            if child and child.poll() is not None:
                publish('child_exited',str(child.returncode));child=None
                if stream:stream.close();stream=None
                next_start=now+min(60,5*max(1,restarts))
            try:
                with urlopen(URL,timeout=5) as response:info=json.load(response)
                state=assess(info,child.pid if child else None,time.time(),os.getpid())
                failures=failures+1 if state in ('worker_unresponsive','model_unresponsive') else 0
                publish(state)
            except (OSError,ValueError,TypeError):
                failures+=1
                if child:state='starting' if now-started<TIMEOUT else 'http_unresponsive'
                else:state='port_free' if port_free() else 'port_occupied'
                publish(state)
            if child and failures>=3 and now-started>TIMEOUT and state in ('worker_unresponsive','http_unresponsive','model_unresponsive'):
                publish('restarting','owned reader failed repeated health checks')
                stop_child(child);child=None
                if stream:stream.close();stream=None
                next_start=time.time()+5;failures=0
            if child is None and state=='port_free' and now>=next_start:
                log_path=WORK/'reader.log'
                if log_path.exists() and log_path.stat().st_size>2_000_000:log_path.replace(WORK/'reader.previous.log')
                stream=log_path.open('ab',buffering=0)
                env={**os.environ,'IPDA_SUPERVISOR_PID':str(os.getpid())}
                child=subprocess.Popen([sys.executable,'-X','utf8',str(ROOT/'app.py'),'--port','8773','--snapshot-dir',str(WORK/'data')],
                    cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                started=time.time();restarts+=1;failures=0;publish('starting')
            time.sleep(5)
        publish('stopping','requested by local stop marker');stop_child(child);publish('stopped')
        return 0
    finally:
        stop_child(child)
        if stream:stream.close()
        kernel.CloseHandle(handle)


if __name__=='__main__':raise SystemExit(main())
