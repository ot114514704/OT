$ErrorActionPreference = 'Stop'
$installation = Join-Path $PSScriptRoot 'installation.json'
if (-not (Test-Path -LiteralPath $installation)) { throw 'Run Install.ps1 first.' }
$projectPath = (Get-Content -LiteralPath $installation -Raw | ConvertFrom-Json).project_root
$pythonPath = Join-Path $projectPath '.venv\Scripts\python.exe'
$pythonWindowless = Join-Path $projectPath '.venv\Scripts\pythonw.exe'
if (-not (Test-Path -LiteralPath $pythonWindowless)) { throw 'Run Setup.ps1 to install the Python 3.12 runtime dependencies first.' }
$runtime = $null
try { $runtime = Invoke-RestMethod -Uri 'http://127.0.0.1:8773/api/runtime' -TimeoutSec 3 } catch { }
if ($runtime) {
    if ($runtime.service -ne 'ipda_consolidation' -or $runtime.project_root -ne $projectPath) { throw 'Port 8773 belongs to another project. It was not stopped.' }
    Write-Output 'The installed project is already running on http://127.0.0.1:8773/'; exit 0
}
& $pythonPath -c 'import MetaTrader5, tzdata, numpy'
if ($LASTEXITCODE -ne 0) { throw 'Run Setup.ps1 first.' }
$stopPath = Join-Path $projectPath 'work\live_8773\stop.request'
if (Test-Path -LiteralPath $stopPath) { Remove-Item -LiteralPath $stopPath }
Start-Process -FilePath $pythonWindowless -ArgumentList ('"' + (Join-Path $projectPath 'supervisor.py') + '"') -WorkingDirectory $projectPath -WindowStyle Hidden
Write-Output 'Reader started. Keep MT5 logged in. First model can take about one minute. Check http://127.0.0.1:8773/ for connection and indicator receipt.'
